

# Generated at 2022-06-12 08:59:13.511201
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        a = ExceptionMixin()
        fn = a.exception()
        def handle():
            pass
        fn(handle)
        fn1 = a.exception()
        fn1(handle)
    except Exception as err:
        print(err)
        print('The function "exception" is not correct')


"""
Test for class ExceptionMixin
"""
if __name__ == '__main__':
    print('start testing')

    test_ExceptionMixin_exception()

    print('test is over!')

# Generated at 2022-06-12 08:59:21.537004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    app = Sanic('test_ExceptionMixin_exception')
    test_exception_mixin = TestExceptionMixin()
    blueprint = Blueprint(
        'test_blueprint', url_prefix='/test',
        host='test_blueprint_host')(test_exception_mixin)

    @app.listener('before_server_start')
    def init_blueprint_exception_handler(app, loop):
        test_exception_mixin._apply_exception_handler = mock.MagicMock()


# Generated at 2022-06-12 08:59:35.099128
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.common import Blueprint
    from sanic.models.exception import ExceptionMixin

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            self.exceptions = []
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            self.exceptions.append(handler)

    test_bp = Blueprint('test')
    test_bp.__class__ = TestExceptionMixin

    def test_1(*args, **kwargs):
        pass

    def test_2(*args, **kwargs):
        pass

    test_bp.exception(Exception)(test_1)
    test_bp.exception([Exception])(test_2)

    assert len(test_bp.exceptions) == 1


# Generated at 2022-06-12 08:59:35.705128
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 08:59:43.394146
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.views import HTTPMethodView
    from sanic.models.futures import FutureException
    from sanic.testing import SanicTestClient

    class MyException(SanicException):
        pass

    blueprint = Blueprint(__name__, url_prefix='/app')

    @blueprint.exception(MyException)
    def handler(request, exception):
        return text(exception.name)

    @blueprint.exception(MyException)
    def handler2(request, exception):
        return text(exception.status_code)

    @blueprint.get('/')
    def handler3(request):
        raise MyException

    app = Sanic(__name__)


# Generated at 2022-06-12 08:59:44.548344
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception()
    def handler(request, exception):
        pass

# Generated at 2022-06-12 08:59:49.904696
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import uuid
    from sanic import Blueprint
    from sanic.models.futures import FutureException

    from utils import MockRequest
    from utils import MockResponse

    # Instance of the class under test
    class ExceptionMixinTest(Blueprint, ExceptionMixin):
        pass

    # Apply exception handler to all server decorators.
    def _apply_exception_handler(self, handler: FutureException):
        self.exception_handler = handler.handler

    ExceptionMixinTest._apply_exception_handler = _apply_exception_handler

    # Create Blueprint instance
    blueprint = ExceptionMixinTest(__name__, url_prefix='test')

    # Define exception handler

# Generated at 2022-06-12 08:59:59.855347
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import html, text
    from sanic.websocket import WebSocketProtocol
    import pytest

    @pytest.fixture
    def bp():
        return Blueprint("Test")

    @pytest.fixture
    def app(bp):
        app = Sanic("Test")
        app.blueprint(bp)
        return app

    @pytest.mark.asyncio
    async def test_add_exception_to_app(app):
        @app.exception(NotFound)
        def _func(request, exception):
            return html("test")

        request, response = app.test_client.get("/")
       

# Generated at 2022-06-12 09:00:05.670152
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    
    # the blueprint, which is a subclass of ExceptionMixin
    blueprint = Blueprint('test blueprint')
    
    @blueprint.exception(Exception)
    def handle_exception():
        print('Exceptions has been handled.')

    # test whether the FutureException handler has been added to the container
    assert blueprint._future_exceptions != set()

# Generated at 2022-06-12 09:00:15.603174
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    mixin = ExceptionMixin()
    @mixin.exception(IndexError)
    def index_error_handler(request, exception):
        print("index error")
    
    @mixin.exception(IndexError, apply=False)
    def index_error_handler2(request, exception):
        print("index error apply")

    assert isinstance(index_error_handler, FutureException)
    assert isinstance(index_error_handler2, FutureException)
    assert mixin._future_exceptions == {index_error_handler, index_error_handler2}

# Generated at 2022-06-12 09:00:18.199391
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:00:25.353485
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def exception_decorator(handler):
        return handler

    class ExceptionMixinImpl(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass


    def test():
        mixinImpl = ExceptionMixinImpl()

        # Case 1: exceptions is a tuple
        assert len(mixinImpl._future_exceptions) == 0
        @mixinImpl.exception((Exception,))
        def exception_handler():
            pass
        assert len(mixinImpl._future_exceptions) == 1

        # Case 2: exceptions is a list
        assert len(mixinImpl._future_exceptions) == 1
        @mixinImpl.exception([Exception,])
        def exception_handler():
            pass
        assert len(mixinImpl._future_exceptions) == 2

    test()

# Generated at 2022-06-12 09:00:31.185243
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_bp', url_prefix="test")
    assert len(bp._future_exceptions) == 0
    try:
        @bp.exception(ValueError)
        def handle_exception(request, err):
            return text('Internal server error')
    except NotImplementedError:
        pass
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:00:37.363293
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyBluePrint(ExceptionMixin):
        pass

    blueprint = MyBluePrint()

    @blueprint.exception([ZeroDivisionError, TypeError])
    def my_exception_handler(request, exception):
        return "500 Server error"

    assert "500 Server error" == my_exception_handler({}, ZeroDivisionError)
    assert "500 Server error" == my_exception_handler({}, TypeError)

# Generated at 2022-06-12 09:00:46.943413
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint("test_blueprint")
    assert bp._future_exceptions == set()
    expected = set()

    @bp.exception(BaseException)
    async def handler(request, exception):
        pass

    expected.add(FutureException(handler, (BaseException,)))

    assert bp._future_exceptions == expected
    # error handling is not implemented yet
    # assert bp.error_handler == {
    #     (BaseException,): handler
    # }

    # test multiple exceptions as an iterable
    @bp.exception([ZeroDivisionError, ValueError])
    async def handler2(request, exception):
        pass

    expected.add(FutureException(handler2, (ZeroDivisionError, ValueError)))
    assert bp._future_exceptions == expected
   

# Generated at 2022-06-12 09:00:52.127847
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_class(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_obj = test_class()
    @test_obj.exception(Exception)
    def exception_handler():
        pass
    assert len(test_obj._future_exceptions) == 1

# Generated at 2022-06-12 09:00:59.250911
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blp import Blueprint

    from sanic.models.exceptions import FutureException

    bp = Blueprint("test", url_prefix="/test")

    @bp.exception(RuntimeError)
    def handler_exc(request, exception):
        pass

    @bp.exception(FileNotFoundError)
    def handler_exc2(request, exception):
        pass

    assert len(bp._future_exceptions) == 2

    assert isinstance(bp._future_exceptions, list)

    assert isinstance(bp._future_exceptions[0], FutureException)
    assert bp._future_exceptions[0].handler == handler_exc
    assert bp._future_exceptions[0].exceptions[0] == RuntimeError

    assert isinstance(bp._future_exceptions[1], FutureException)

# Generated at 2022-06-12 09:01:05.106370
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    m = Mixin()
    @m.exception(ValueError)
    def my_func(request, e):
        return "value"

    assert len(m._future_exceptions) == 1
    assert m._future_exceptions.pop().exceptions == (ValueError,)

# Generated at 2022-06-12 09:01:05.648356
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 09:01:10.353374
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self._exception_handler = handler

    t = TestExceptionMixin()

    def test_handler():
        return 4
    try:
        t.exception(ValueError, apply=False)(test_handler)()
    except ValueError:
        pass

# Generated at 2022-06-12 09:01:21.893487
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """ test exception method in ExceptionMixin class
    """
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, exception: FutureException):
            raise NotImplementedError
    te_m = TestExceptionMixin()
    assert hasattr(te_m, 'exception')
    assert callable(te_m.exception)
    assert te_m.exception(Exception) != None

    

# Generated at 2022-06-12 09:01:27.795564
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test')
    blueprint.exception(Exception)(lambda x: None)
    blueprint.exception(Exception)(lambda x: None)
    blueprint.exception(ValueError)(lambda x: None)
    blueprint.exception(ValueError)(lambda x: None)
    blueprint.exception(ValueError)(lambda x: None)
    blueprint.exception([Exception, ValueError])(lambda x: None)

    assert len(blueprint._future_exceptions) == 5

# Generated at 2022-06-12 09:01:28.311673
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert 1

# Generated at 2022-06-12 09:01:31.835408
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exc_mixin = ExceptionMixin()
    @exc_mixin.exception(NotImplementedError)
    def test():
        return 0
    assert test.__name__ == 'test'
    with pytest.raises(NotImplementedError):
        test()
    assert len(exc_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:01:41.445667
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic()

    bp = Blueprint('bp')

    @bp.exception
    def bp_exception_handler(request, exception):
        return text('bp')

    @app.exception
    def exception_handler(request, exception):
        return text('app')

    @app.route('/bp')
    def bp_test(request):
        raise NotImplementedError

    @app.route('/bp_exception')
    def bp_exception_test(request):
        raise NotImplementedError

    app.blueprint(bp)

    request, response = app.test_client.get('/bp')
    assert response.text == 'app'


# Generated at 2022-06-12 09:01:50.414444
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.slugified import Slugified

    class MyApp(Slugified, ExceptionMixin, Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    app = MyApp("sanic-test-app")

    @app.exception(ZeroDivisionError)
    def handler(app, request, exception):
        return text("ok")

    resp = app.test_client.get("/")
    assert resp.status == 200
    assert resp.text == "ok"

# Generated at 2022-06-12 09:01:52.511546
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    s = ExceptionMixin()

    def f():
        pass
    
    # f = s.exception(TypeError)
    # assert f() == 'TypeError'

# Generated at 2022-06-12 09:01:54.672774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class blueprint(ExceptionMixin):
        pass

    blueprint = blueprint()
    blueprint.exception(ValueError, apply=True)
    assert blueprint._future_exceptions

# Generated at 2022-06-12 09:01:55.944487
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO(KNR)
    # Class ExceptionMixin, method exception
    assert True

# Generated at 2022-06-12 09:02:00.153771
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
	class FakeExceptionMixin(ExceptionMixin):
		def __init__(self):
			pass
		def _apply_exception_handler(self,handler):
			pass

	object = FakeExceptionMixin()
	assert isinstance(object, ExceptionMixin)
	assert hasattr(object, '_future_exceptions')

# Generated at 2022-06-12 09:02:15.350807
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class UnderTest(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._test = 0

        def _apply_exception_handler(self, handler):
            self._test = 1
            assert handler._handler(
                "Some Error") == "Some Error + My Exceptions"

    exception_mixin = UnderTest()


    @exception_mixin.exception(Exception)
    def test_handler(exception):
        return str(exception) + " + My Exceptions"

    assert exception_mixin._test == 1

# Generated at 2022-06-12 09:02:17.848730
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @Sanic.exception(Exception)
    def global_exception_handler(request, exception):
        pass
    assert isinstance(Sanic.exception(Exception), Callable)

# Generated at 2022-06-12 09:02:26.369661
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test case for method exception of class ExceptionMixin
    """
    exceptions = Set()
    em = ExceptionMixin()
    em._apply_exception_handler = lambda x: exceptions.add(x)

    @em.exception(Exception)
    def exception_handler(request, exception):
        return text('OK')

    assert len(em._future_exceptions) == 1
    assert Exception in em._future_exceptions.pop().exceptions

    assert len(exceptions) == 1
    assert Exception in exceptions.pop().exceptions

    @em.exception(Exception, apply=False)
    def exception_handler(request, exception):
        return text('OK')

    assert len(em._future_exceptions) == 1
    assert Exception in em._future_exceptions.pop().exceptions


# Generated at 2022-06-12 09:02:27.102700
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:02:29.436050
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    obj = ExceptionMixin()
    assert obj.exception(1, 2)
    assert obj.exception(1, 2, 3)
    assert obj.exception(apply=True)

# Generated at 2022-06-12 09:02:37.547868
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Sample global exception handler function
    def global_exception_handler(request, exception):
        print(type(exception), exception)
        return response.text('Bad Request', 400)
    
    # Sample local exception handler function
    def local_exception_handler(request, exception):
        print(type(exception), exception)
        return response.text('Bad Request', 400)
    
    # Creating a blueprint route
    bp = Blueprint('bp', url_prefix='/bp')
    
    @bp.route('/greet/<name:[a-zA-Z]>')
    async def greet(request, name):
        return response.text(f'Hello {name}')

    # Global exception handling for the blueprint
    bp.exception([Exception])(global_exception_handler)
    
    # Sample local

# Generated at 2022-06-12 09:02:42.342864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)(lambda x: x)


# Generated at 2022-06-12 09:02:45.723611
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Example(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    example = Example()
    @example.exception(ValueError)
    def handler(request, exception):
        pass
    example._future_exceptions.pop()
    assert handler is not None
    assert handler == example._future_exceptions.pop().handler

# Generated at 2022-06-12 09:02:53.012134
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import HTTPResponse

    bp = Blueprint('test_bp')

    exceptions = [ValueError]

    @bp.exception(exceptions, True)
    def handle_exception(request, exception):
        response = HTTPResponse(body=exception)
        return response

    assert len(bp._future_exceptions) == 1
    future_exception = next(iter(bp._future_exceptions))
    assert future_exception.handler == handle_exception


# Generated at 2022-06-12 09:02:58.701759
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionHandler(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == handler_func


    @ExceptionHandler.exception(Exception)
    def handler_func():
        pass

    assert len(ExceptionHandler._future_exceptions) == 1
    future_exception = ExceptionHandler._future_exceptions.pop()
    assert future_exception.handler == handler_func

# Generated at 2022-06-12 09:03:19.216969
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinImpl(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    impl = ExceptionMixinImpl()

    def error_handler(*args):
        pass

    h1 = impl.exception(Exception)(error_handler)
    h2 = impl.exception(ValueError)(error_handler)

    assert len({h1, h2}) == 2

# Generated at 2022-06-12 09:03:20.957755
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint

    blueprint = Blueprint("test")
    blueprint.exception()(lambda _: None)
    assert "exception" in dir(blueprint)

# Generated at 2022-06-12 09:03:21.792995
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:03:28.366944
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sample:
        def __init__(self):
            self._future_exceptions = set()
        def _apply_exception_handler(self, handler: FutureException):
            return handler
    sample = Sample()
    assert isinstance(
        sample.exception(Exception),
        types.FunctionType
    )
    assert isinstance(
        sample.exception(
            Exception,
            Exception,
            Exception
        ),
        types.FunctionType
    )
    handler = sample.exception(
        [Exception, Exception]
    )
    handler = sample.exception(
        [Exception, Exception]
    )(handler)

# Generated at 2022-06-12 09:03:36.411569
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  from sanic.app import Sanic
  from sanic.blueprints import Blueprint
  from sanic.exceptions import ServerError

  blueprint = Blueprint('test_blueprint', url_prefix='/test_blueprint')

  @blueprint.exception(ServerError)
  async def server_error_handler(request, exception):
      return response.text('Internal server error', 500)

  def test_server_error_handler(_):
    assert blueprint._future_exceptions

  test_server_error_handler(_)



# Generated at 2022-06-12 09:03:42.178945
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic import response
    from sanic.views import HTTPMethodView
    from sanic.exceptions import URLBuildError
    from sanic import Sanic

    class View1(HTTPMethodView):
        def get(self, request):
            return response.text("OK")

    class View2(HTTPMethodView):
        def get(self, request):
            return response.text("OK")

    class MyView(HTTPMethodView):
        def get(self, request):
            return response.text("OK")

    blue_print = Blueprint("my_blueprint", url_prefix="/test")
    view1 = View1.as_view("view1")

# Generated at 2022-06-12 09:03:50.803439
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test add a Exception
    from sanic.views import HTTPMethodView
    from sanic.exceptions import InvalidUsage
    class TestView(HTTPMethodView, ExceptionMixin):
        def get(self, request):
            return 'OK'

        @exception(InvalidUsage, apply=False)
        def exception(self, request, exception):
            return 'This is an exception'

        @exception([InvalidUsage], apply=False)
        def exception(self, request, exception):
            return 'This is an exception'

    # Test delete a Exception
    test_view = TestView()
    assert len(test_view._future_exceptions) == 2
    assert test_view._future_exceptions.pop().exceptions[0] == InvalidUsage
    assert test_view._future_exceptions.pop().exceptions

# Generated at 2022-06-12 09:03:57.916851
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import asyncio
    from sanic import Sanic, Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse, text

    # Initialize the Sanic application
    app = Sanic('test_ExceptionMixin_exception')

    # Define the web handler
    @app.route('/y')
    async def bp_handler(request: Request):
        return text('OK')

    # Test the method ExceptionMixin.exception
    @app.exception(Exception)
    async def old_handler(request: Request, exception):
        return text('OK')

    # Test the method ExceptionMixin.exception

# Generated at 2022-06-12 09:04:04.040418
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        pass
    blueprint = Blueprint()
    @blueprint.exception(ValueError, IOError, apply=False)
    def handler():
        pass
    assert len(blueprint._future_exceptions) == 1
    future_exception = list(blueprint._future_exceptions)[0]
    assert future_exception.handler == handler
    assert isinstance(future_exception.exceptions, tuple)
    assert len(future_exception.exceptions) == 2


# Generated at 2022-06-12 09:04:07.837169
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self):
            super().__init__()

    bp = Blueprint()
    @bp.exception(Exception)
    def handle_exception(request, exception):
        return 'exception'

    assert len(bp._future_exceptions) == 1
    fex = bp._future_exceptions.pop()
    assert fex.handler(None, None) == 'exception'

# Generated at 2022-06-12 09:04:42.044070
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Hello:
        def a(self):
            pass

    class Hi(ExceptionMixin):
        def __init__(self):
            super()
            self.a = Hello()

    hi = Hi()

    @hi.exception(Exception)
    def test(self, exception):
        return True

    assert hi.a.test(Exception)

# Generated at 2022-06-12 09:04:45.031892
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        class Object(ExceptionMixin):
            def __init__(self):
                pass

            @Object.exception(ValueError, return_value=1)
            def func_for_exception(self, request, exception):
                pass
    except AttributeError as e:
        print("AttributeError: " + str(e))

# Generated at 2022-06-12 09:04:45.538804
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:04:50.249369
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print("_apply_exception_handler")

    test_exception_mixin = TestExceptionMixin()
    def test_handler():
        print("test_handle")

    test_exception_mixin.exception(test_handler)

# Generated at 2022-06-12 09:04:54.430055
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    test_exception_mixin = TestExceptionMixin()
    try:
        @test_exception_mixin.exception(Exception)
        def return_true(foo):
            return True
    except TypeError:
        return False
    else:
        return True

# Generated at 2022-06-12 09:05:01.747180
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from collections import namedtuple
    import pytest

    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound, ServerError
    from sanic.models.futures import FutureException

    class DummySanicClass:
        def add_exception_handler(self, handler):
            return handler

    test_object = ExceptionMixin(DummySanicClass())

    dummy_exception_handler = lambda request, exception: None

    namedtuple_TestValues = namedtuple("TestValues", ["apply", "exceptions", "expected_set_size"])
    test_values = [
        namedtuple_TestValues(True, (NotFound, ServerError), 2),
        namedtuple_TestValues(True, (NotFound,), 1),
    ]


# Generated at 2022-06-12 09:05:06.363273
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprints import Blueprint

    blueprint = Blueprint(__name__)
    blueprint.exception([Exception], name="name", age=1)(print)
    
    future_exception = FutureException(print, (Exception,))
    assert blueprint._future_exceptions.pop() == future_exception

# Generated at 2022-06-12 09:05:13.724553
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.handlers import SanicException
    from sanic.handlers import ErrorHandler

    bl = Blueprint("blueprint_test", url_prefix="/test")
    bl.error_handler.error_handlers = {}
    bl.error_handler.blueprint = bl
    bl.error_handler.application = None

    @bl.exception(SanicException)
    def test_handler(request, exception):
        return 'test_handler'

    assert len(bl._future_exceptions) == 1
    assert isinstance(bl._future_exceptions.pop(), FutureException)


# Generated at 2022-06-12 09:05:22.144182
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    class TestException(Exception):
        pass
    blueprint = TestExceptionMixin()

    def test_handler(*args, **kwargs):
        return "Test"
    blueprint.exception(TestException, apply=False)(test_handler)

    future_exception = blueprint._future_exceptions.pop()
    assert future_exception.exceptions == TestException
    assert future_exception.handler == test_handler

# Generated at 2022-06-12 09:05:25.322911
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    obj = TestExceptionMixin()
    obj.exception(KeyError, NameError, apply=False)

# Generated at 2022-06-12 09:06:38.787275
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.handlers import (
        RequestHandler,
        RequestParameters,
        RequestHandlerException
    )
    import unittest.mock

    bp = Blueprint(__name__)

    @bp.exception(Exception)
    def test_handler(request: RequestHandler,
                     exc: RequestHandlerException,
                     parameters: RequestParameters,
                     *args, **kwargs):
        pass

    assert isinstance(bp.exception, unittest.mock.Mock)
    assert isinstance(test_handler, unittest.mock.Mock)
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions == set(
        [FutureException(test_handler, (Exception,))]
    )

# Generated at 2022-06-12 09:06:39.424155
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    pass

# Generated at 2022-06-12 09:06:42.345350
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    @Blueprint.exception(Exception, apply=False)
    async def catch_all(request, exception):
        print("I catch all")

    assert catch_all.__name__ == "catch_all"

# Generated at 2022-06-12 09:06:46.012714
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:06:49.307476
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test if the format of calling exception() method is correct
    # The input object has to be an list
    # The type of return object has to be a function
    class Test(ExceptionMixin):
        pass
    test = Test()
    assert type(test.exception()) == type(test.exception([])[1])

# Generated at 2022-06-12 09:06:53.060633
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = A()
    def hello():
        nonlocal a
        a.exception(Exception)(lambda e: e)
        a.exception([Exception])(lambda e: e)
        a.exception(Exception, apply=False)(lambda e: e)
    hello()

# Generated at 2022-06-12 09:06:57.402390
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class TestExceptionMixin(ExceptionMixin):
        @property
        def request(self):
            return None
        pass

    # Act
    test_exception_mixin = TestExceptionMixin()
    future_exception = FutureException(test_exception_mixin.exception, [test_exception_mixin])

    # Assert
    assert len(test_exception_mixin._future_exceptions) > 0

# Generated at 2022-06-12 09:07:02.304216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.blueprints import Blueprint

    blueprint_exception = Blueprint("my_blueprint", url_prefix="/my_blueprint")
    @blueprint_exception.exception(Exception)
    async def handler_exception_blueprint(request, exception):
        pass
    assert isinstance(blueprint_exception, Blueprint)
    with pytest.raises(Exception):
        @blueprint_exception.exception(Exception)
        async def handler_exception_blueprint(request, exception):
            pass

# Generated at 2022-06-12 09:07:11.178937
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage

    # Unit test for args
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    test = TestExceptionMixin()
    @test.exception(Exception)
    def handler(*args, **kwargs):
        pass
    # check the property future_exceptions
    assert len(test._future_exceptions) == 1
    handler_exceptions = [x.exceptions for x in test._future_exceptions]
    assert (Exception,InvalidUsage) in handler_exceptions
    handler_list = [x.handler for x in test._future_exceptions]
    assert handler in handler_list
    # Unit test for kwargs

# Generated at 2022-06-12 09:07:14.924294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Bp(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = Bp()
    @bp.exception(BaseException)
    def xxx(request, exception):
        pass
    assert len(bp._future_exceptions) == 1
