

# Generated at 2022-06-12 08:59:18.946165
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO(py3.8): FutureWarning: The behavior of this method will change in future
    # versions.  Use specific 'len(elem)' or 'elem is not None' test instead.
    CaughtException: Exception = Exception

    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._exception_handlers: Dict[Type, Callable] = {}
            self._arguments_for_exception_handlers: Dict[Type, Dict] = {}

        def _apply_exception_handler(self, handler: FutureException):
            self._exception_handlers[handler.exception] = handler
            self._arguments_for_exception_handlers = handler.kw

# Generated at 2022-06-12 08:59:29.072282
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.futures import FutureException
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    class TestExceptionMixin(ExceptionMixin, HTTPMethodView):
        def get(self, request: Request):
            return HTTPResponse(text='Hello, world!')

        def post(self, request: Request):
            return HTTPResponse(text='Hello, world!')

    app = Sanic(__name__)

    testExceptionMixin = TestExceptionMixin
    testExceptionMixin.exceptions = []
    testExceptionMixin.decorators = []
    testExceptionMixin.view_class = HTT

# Generated at 2022-06-12 08:59:38.088405
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for ExceptionMixin exception method

    :return:
    """
    from sanic.models.blueprints import Blueprint

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @TestExceptionMixin.exception(ZeroDivisionError)
    async def zero_error(request, err):
        assert isinstance(err, ZeroDivisionError)


# Generated at 2022-06-12 08:59:44.447153
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = MockExceptionMixin()
    future_exception = None

    @bp.exception([ValueError, TypeError])
    async def handler(request, exception):
        raise exception

    assert len(bp._future_exceptions) == 1
    for i in bp._future_exceptions:
        future_exception = i
        assert future_exception.handler == handler
        assert future_exception.exceptions == (ValueError, TypeError)

    with pytest.raises(ValueError) as exception:
        future_exception.handler("request", ValueError)

    assert str(exception.value) == "ValueError()"

# Generated at 2022-06-12 08:59:47.795227
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass

    class MyClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.args == {'x': 'y'}
            assert handler.exceptions == (MyException,)
            assert handler.handler(1, x='y') == None
    
    myclass = MyClass()
    myclass.exception(MyException)(lambda *args, **kwargs: None)(x='y')



# Generated at 2022-06-12 08:59:52.156080
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        @route("/")
        def handler(request):
            return text("OK")

        handler(Request("GET", "/"))
        assert False
    except Exception as e:
        assert str(e) == "OK"

test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:00:00.400623
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SanicMock(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    sanic_mock = SanicMock()
    assert sanic_mock._future_exceptions == set()
    assert sanic_mock._future_exceptions is not None

    @sanic_mock.exception(TypeError)
    def exception_handler_test(error=None):
        pass

    assert len(sanic_mock._future_exceptions) == 1

# Generated at 2022-06-12 09:00:07.064964
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == handler_func
            assert handler.exceptions == (Exception, )

    my_exception_mixin = MyExceptionMixin()
    @my_exception_mixin.exception(Exception)
    def handler_func():
        pass
    assert len(my_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:00:13.892060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    test_blueprint = Blueprint("test_blueprint", url_prefix="/test/")

    """
    Test for apply=True
    """
    @test_blueprint.exception(Exception)
    def test_handler(request, exception):
        return exception

    assert(isinstance(list(test_blueprint._future_exceptions)[0], FutureException))

    """
    Test for apply=False
    """
    @test_blueprint.exception(Exception, apply=False)
    def test_handler(request, exception):
        return exception

    assert(isinstance(list(test_blueprint._future_exceptions)[0], FutureException))

# Generated at 2022-06-12 09:00:17.243890
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class M(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print(handler)

    m = M()
    m.exception()

# Generated at 2022-06-12 09:00:24.286585
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass
    a = A()
    # a._apply_exception_handler = MagicMock(return_value=None)
    # a._future_exceptions = MagicMock(return_value=set())
    def test_function(a):
        pass
    # test_function = MagicMock(return_value=None)
    a.exception(test_function)
    assert a._future_exceptions != set()

# Generated at 2022-06-12 09:00:28.310149
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # this test is getting green and the assert is passing but it's not working
    # and it's not finding the function exception.
    em = ExceptionMixin()
    em.exception(ValueError,FileNotFoundError,apply=True)

# Generated at 2022-06-12 09:00:32.805033
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handlers == (Exception, AssertionError)

    blueprint_test = ExceptionMixinTest()
    blueprint_test.exception(Exception, AssertionError,apply=True)(print)

# Generated at 2022-06-12 09:00:44.037288
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test that apply is True by default
    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler is handlerFunction
            assert handler.exceptions == (KeyError,)
            assert apply

    apply = False
    @Test().exception(KeyError)
    def handlerFunction():
        pass
    apply = True

    # Test that apply is set to True when it is not specified
    class Test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler is handlerFunction
            assert handler.exceptions == (KeyError,)
            assert apply

    apply = False
    @Test().exception(KeyError, apply=apply)
    def handlerFunction():
        pass
    apply = True

    # Test that apply is

# Generated at 2022-06-12 09:00:45.873830
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_ExceptionMixin = ExceptionMixin()
    assert test_ExceptionMixin.exception is ExceptionMixin.exception

# Generated at 2022-06-12 09:00:52.978768
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeException(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            handler.handler("test")

    fake = FakeException()
    assert fake._future_exceptions == set()
    fake_func = fake.exception("test")
    assert fake_func == "test"

# Generated at 2022-06-12 09:00:53.693366
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestBlueprint(ExceptionMixin):
        pass


# Generated at 2022-06-12 09:00:59.945434
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import Sanic
    from sanic.exceptions import SanicException
    from sanic.testing import HOST, PORT
    from sanic.response import json

    app = Sanic(__name__)
    bp = Blueprint('test', url_prefix='test')

    @bp.exception(SanicException)
    def ignore_exception(request, exception):
        return json({'exception': str(exception)})

    @bp.route('/')
    def handler(request):
        raise SanicException('Testing exception handler')
    bp.get('/ignore_exception')(handler)

    @bp.route('/assert')
    def assertion_handler(request):
        assert False, 'Testing assertion failure'


# Generated at 2022-06-12 09:01:03.110210
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception(): 
    def handler():
        pass
    exc = ExceptionMixin()
    exc.exception(apply=True)(handler)
    assert len(exc._future_exceptions) == 1

# Generated at 2022-06-12 09:01:04.825980
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ex = ExceptionMixin()
    r = ex.exception() # noqa
    assert r

# Generated at 2022-06-12 09:01:13.541135
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    # Verify that there is no exception handler for a blueprint
    bp = Blueprint('test')
    assert len(bp._future_exceptions) == 0

    # Add a exception handler for a blueprint
    @bp.exception(Exception)
    def handler(request, exception):
        return text('Internal Server Error', status=500)

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:01:24.222443
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    It is necessary to check if the blueprint is correctly created.
    """
    from sanic.exceptions import ServerError
    from sanic.blueprints import Blueprint
    from sanic import response

    blueprint = Blueprint('test', '/test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        """
        Handler to be called when a ServerError (500) is raised while handling a request.
        """
        return response.text('Internal Server Error', 500)

    @blueprint.route('/test')
    def func(request):
        """
        It is necessary to validate the instance of the exception
        """
        raise ServerError

    assert isinstance(blueprint.exception_handlers[0], tuple)

# Generated at 2022-06-12 09:01:30.522569
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Base:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    class A(ExceptionMixin, Base):
        def __init__(self, *args, **kwargs) -> None:
            Base.__init__(self, *args, **kwargs)

    a = A()
    assert a.exception is Base.exception
    assert a._future_exceptions == set()

# Generated at 2022-06-12 09:01:35.791788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = _ExceptionMixin()
    assert exception_mixin._future_exceptions == set()

    @exception_mixin.exception(Exception)
    def handler():
        pass

    future_exception = FutureException(handler, (Exception,))
    assert exception_mixin._future_exceptions == {future_exception}

# Generated at 2022-06-12 09:01:43.276091
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test_Blueprint(ExceptionMixin):
        def __init__(self) -> None:
            super().__init__()
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)
    
    method_exception = Test_Blueprint()
    @method_exception.exception([KeyError, ValueError])
    def exception_handler(request, exception):
        """A handler to catch global exceptions."""
        return response.text('{}'.format(exception), 500)

    assert len(method_exception._future_exceptions) == 1

# Generated at 2022-06-12 09:01:51.155187
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    app = Sanic('test_ExceptionMixin_exception')

    FutureException.reset_count()

    @app.exception(Exception)
    def handler(request, exception):
        pass

    @app.exception([ValueError, NameError], apply=False)
    def handler(request, exception):
        pass

    assert len(app._future_exceptions) == 2
    FutureException.reset_count()

    assert_raises(
        TypeError, app.exception, [ValueError, NameError], apply=False)

# Generated at 2022-06-12 09:01:55.269536
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("exception_test")
    blueprint.exception(Exception)(lambda:print("exception"))

    app = Sanic("exception_test")
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler.__name__ == "lambda"

# Generated at 2022-06-12 09:01:58.929215
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    mixin = TestExceptionMixin()
    assert mixin.exception(Exception)
    assert mixin.exception([Exception])
    assert mixin.exception(Exception, apply=False)
    assert mixin._future_exceptions

# Generated at 2022-06-12 09:02:06.842206
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    app = Sanic('test_ExceptionMixin_exception')

    class Test(ExceptionMixin):

        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            assert type(handler) == FutureException
            assert type(handler.exceptions) == tuple
            assert type(handler.handler) == function

    @Test().exception([NameError])
    def handler(request, exception):
        return text('Internal Server Error', status=500)

    route = app.add_route(handler, '/')

    try:
        a = b
    except NameError:
        request, response = app.test_client.get('/')
        assert response.status == 500

# Generated at 2022-06-12 09:02:16.146123
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup test data
    Endpoint_0 = Endpoint(None, None, None, None, None, None, None, None)
    Endpoint_1 = Endpoint(None, None, None, None, None, None, None, None)
    Endpoint_2 = Endpoint(None, None, None, None, None, None, None, None)
    Endpoint_3 = Endpoint(None, None, None, None, None, None, None, None)
    Endpoint_4 = Endpoint(None, None, None, None, None, None, None, None)
    Endpoint_5 = Endpoint(None, None, None, None, None, None, None, None)
    Endpoint_6 = Endpoint(None, None, None, None, None, None, None, None)

# Generated at 2022-06-12 09:02:29.753012
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    class Temp(ExceptionMixin, sanic.Sanic):
        def add_route(self, handler, uri, methods=frozenset({'GET'})):
            return sanic.response.text("success")

        def _apply_exception_handler(self, handler):
            return handler

    app = Temp()

    @app.exception(IndexError)
    def nicehandler(request, exception):
        return sanic.response.text('failed')

    @app.route('/')
    def index(request):
        raise IndexError

    request, response = app.test_client.get('/')
    assert response.text == 'failed'

    @app.exception(apply=False)
    def nicehandler2(request, exception):
        return sanic.response.text('failed')

   

# Generated at 2022-06-12 09:02:37.547425
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic_project.app as app

    @app.exception(ZeroDivisionError)
    def zero_division(request: Request, exception):
        return text("You can't divide by zero!", 400)

    # assert exists in app.exception_handler
    print(app.exception_handler)
    print(app.exception_handler.exception_list)
    print(app.exception_handler.exception_list[0])
    print(app.exception_handler.exception_list[0].handler)

    assert isinstance(app.exception_handler, dict)
    assert len(app.exception_handler) == 1
    assert isinstance(app.exception_handler[ZeroDivisionError], app.exception_handler.handler)
    assert app.exception_handler[ZeroDivisionError].handler

# Generated at 2022-06-12 09:02:45.986948
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import MagicMock
    from sanic.models.futures import FutureException
    from sanic import Sanic

    blueprint = MagicMock()
    blueprint._apply_exception_handler = MagicMock()
    blueprint._future_exceptions = MagicMock()

    blueprint._future_exceptions.add = MagicMock()
    blueprint._future_exceptions.append = MagicMock()

    blueprint._future_exceptions = []
    blueprint.exception(KeyError, apply=True)("")
    blueprint.exception([KeyError], apply=True)("")
    blueprint.exception(KeyError)("")
    blueprint.exception(KeyError, apply=False)("")
    blueprint.exception([KeyError])("")

    exception = FutureException("", KeyError)
    blueprint._future

# Generated at 2022-06-12 09:02:46.552699
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:02:47.090161
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 09:02:53.010352
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    @Blueprint.exception(apply=True)
    def handle_exception(request, exception):
        pass

    bp = Blueprint('test_bp')
    bp.exception(IOError)(handle_exception)
    assert isinstance(bp._future_exceptions, set)
    assert len(bp._future_exceptions) == 1
    assert type(bp._future_exceptions.pop()) == FutureException

# Generated at 2022-06-12 09:03:01.438215
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler):
            self._future_exceptions.add(handler)

    test_object = TestClass()

    @test_object.exception(Exception)
    def handler(request, error , *args, **kwargs):
        pass

    assert len(test_object._future_exceptions) == 1

    @test_object.exception(Exception)
    def handler2(request, error , *args, **kwargs):
        pass

    assert len(test_object._future_exceptions) == 2

# Generated at 2022-06-12 09:03:10.718794
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from unittest.mock import Mock
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class ExampleBlueprint(Blueprint):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    @ExampleBlueprint.exception(SanicException, [ValueError, Exception], apply=False)
    def example_exception_handler(request, exception):
        pass

    @ExampleBlueprint.exception(apply=False)
    def example_exception_handler_2(request, exception):
        pass

    """
    The first decorator contains [SanicException, [ValueError, Exception]]
    The second decorator contains []
    """
    assert len(ExampleBlueprint._future_exceptions) == 2


# Generated at 2022-06-12 09:03:14.096214
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = Blueprint('blueprint')

    @bp.exception(Exception, apply=True)
    def exception_handler(request, exception):
        return response.text('Server error!')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-12 09:03:21.840498
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ObjectExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    class ExceptionTest(Exception):
        pass

    class ExceptionTestTwo(Exception):
        pass

    class ExceptionTestThree(Exception):
        pass

    def handler(request, exception):
        print(request, exception)

    def handler_wrong(request, exception, test):
        print(request, exception)

    obj = ObjectExceptionMixin()

    with pytest.raises(TypeError):
        obj.exception(ExceptionTest)(handler_wrong)

    @obj.exception(ExceptionTest)
    def test_handler(request, exception):
        pass

    assert len(obj._future_exceptions) == 1

# Generated at 2022-06-12 09:03:39.515899
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    bp = Blueprint()
    @bp.exception(ValueError)
    def test(request, exception):
        try:
            raise ValueError
        except Exception as e:
            exception = e
        return None

    assert bp.exception is not None



# Generated at 2022-06-12 09:03:49.164120
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.exceptions import abort
    from sanic.response import text
    from sanic.request import Request

    blueprint1 = Blueprint('blueprint1', url_prefix='/test')

    @blueprint1.exception(AssertionError, apply=False)
    async def handle_exception(request: Request, exception: AssertionError):
        return text('Exception handled')

    @blueprint1.exception(SanicException)
    async def handle_sanic_exception(request: Request, exc: SanicException):
        return text('SanicException handled')

    @blueprint1.route('/')
    async def handler(request: Request):
        return abort(404, 'Not found')

    request1, response1

# Generated at 2022-06-12 09:03:56.057532
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    import pytest

    @pytest.fixture()
    def bp():
        return Blueprint("test", url_prefix="/test")

    @pytest.fixture()
    def bp_te(bp):
        bp.exception(Exception)(lambda r, e: None)
        return bp

    def test_exception_type(bp_te):
        assert bp_te._future_exceptions == set(
            [FutureException(lambda r, e: None, (Exception,))])

    def test_exception_return(bp):
        def handler():
            pass

        exception_handler = bp.exception(handler)
        assert exception_handler(Exception) is not None

# Generated at 2022-06-12 09:04:03.437453
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()

        def _apply_exception_handler(self, handler):
            pass

    @TestExceptionMixin().exception(KeyError)
    def handler(request, exception):
        return '{}'.format(exception)

    assert handler.__name__ == 'handler'
    assert handler.__globals__['exceptions'][0] == KeyError
    assert handler(0, 0) == '0'

# Generated at 2022-06-12 09:04:06.773226
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def test_handler(e):
        print("Test Exception")
    from sanic.blueprints import Blueprint
    blueprint = Blueprint("test_ExceptionMixin_exception")
    blueprint.exception(IndexError)(test_handler)
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-12 09:04:14.205711
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint, Sanic
    from sanic.response import text
    from sanic.models import Route
    from sanic.warning import Warning
    from sanic.exceptions import ServerError, SanicException


    class ExceptionMixinMock(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler
            self.handler.apply(app=app)

    app = Sanic(__name__)
    bp = Blueprint('test_bp', url_prefix='/bp')
    bp.handle_exception = ExceptionMixinMock()
    bp.exception(ServerError)(lambda r, e: text("Server Error", status=500))
    bp.exception(SanicException)(lambda r, e: text("Sanic Exception", status=500))

# Generated at 2022-06-12 09:04:19.993060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text

    exception_mixin = ExceptionMixin()
    blueprint = Blueprint("test_blueprint", url_prefix="/test", strict_slashes=True)
    blueprint.exception = exception_mixin.exception

    @blueprint.exception(ZeroDivisionError)
    def divide_error(request, exception):
        return text("Error: {}".format(exception))

    assert divide_error.bp == blueprint

    assert divide_error.handler is not None
    assert divide_error.handler.exceptions is not None
    assert divide_error.handler.exceptions.exception_class is ZeroDivisionError

# Generated at 2022-06-12 09:04:25.178074
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_ExceptionMixin = TestExceptionMixin()
    assert len(test_ExceptionMixin._future_exceptions) == 0
    @test_ExceptionMixin.exception(
        Exception,
        apply=True
        )
    def test():
        return 1
    assert len(test_ExceptionMixin._future_exceptions) == 1

# Generated at 2022-06-12 09:04:34.837786
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_blueprint = Blueprint("test_blueprint", url_prefix='/test')
    assert test_blueprint._future_exceptions == set()

    @test_blueprint.exception(Exception)
    def handle_request_exception(request, exception):
        return 'Exception raised'

    assert len(test_blueprint._future_exceptions) == 1
    future_exception = test_blueprint._future_exceptions.pop()
    assert len(future_exception.exceptions) == 1
    assert Exception in future_exception.exceptions
    assert future_exception.handler == handle_request_ex

# Generated at 2022-06-12 09:04:42.439513
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # 1. Test that a exception handler is added to the set of
    #    future_exceptions when exception() decorator is used.

    class DummyError(Exception):
        pass

    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert False

    dummyExceptionMixin = DummyExceptionMixin()

    def dummy_handler():
        assert False

    @dummyExceptionMixin.exception(DummyError)
    def foo():
        pass

    assert len(dummyExceptionMixin._future_exceptions) == 1

    # 2. Test that a exception handler is added to the set of
    #    future_

# Generated at 2022-06-12 09:05:16.310041
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-12 09:05:23.262788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.response import json
    from sanic.exceptions import ServerError

    bp = Blueprint('test_ExceptionMixin')

    @bp.exception(ServerError)
    def server_error(request, exception):
        return json({'exception': 'server error'}, status=500)

    @bp.route('/')
    def index(request):
        raise ServerError

    @bp.route('/custom')
    def custom(request):
        raise ServerError('my custom error', status_code=400)

    app = Blueprint.group(bp, url_prefix='/blueprint')
    request, response = app.test_client.post('/blueprint')
    assert response.status == 500
    assert response.json == {'exception': 'server error'}

    request, response

# Generated at 2022-06-12 09:05:29.072269
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MkBlueprint:
        def apply_exception_handler(self, handler: FutureException):
            pass

    bp = MkBlueprint()
    bp.__class__ = ExceptionMixin
    assert bp.exception(Exception)(lambda req, exc: None) is not None
    assert bp.exception(Exception)(lambda req, exc, *args, **kwargs: None) is not None
    assert bp.exception(Exception)(lambda req, exc, *args, **kwargs: None).__name__ == "exception"

# Generated at 2022-06-12 09:05:39.196814
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class CustomException(Exception):
        pass

    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.options = kwargs.pop('options', {})
            super(Blueprint, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self.options['handler'] = handler

    class App:
        def __init__(self, exception_handler) -> None:
            self.exception_handler = exception_handler

    class RequestFactory:
        def __init__(self, status_code, is_handler=False) -> None:
            self.status_code = status_code
            self.is_handler = is_handler


# Generated at 2022-06-12 09:05:42.728676
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMix(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    em = ExceptionMix()
    @em.exception(Exception)
    def handler(request, exception):
        pass
    len(em._future_exceptions) == 1



# Generated at 2022-06-12 09:05:51.347046
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # mock for class Sanic
    class SanicMock:
        @staticmethod
        def exception(*exc):
            if len(exc) == 0:
                return exc
            elif isinstance(exc[0], list):
                return tuple(*exc)
            return exc

    # mock for class Blueprint
    class BlueprintMock:
        sanic = SanicMock()
        future_exceptions = []

    # mock for class ExceptionMixin
    class ExceptionMixinMock:
        def __init__(self, blueprint):
            self.blueprint = blueprint

        def _apply_exception_handler(self, handler: FutureException):
            self.blueprint.future_exceptions.append(handler)

    exceptions = [ValueError, TypeError]
    blueprint = BlueprintMock()
    exception_mixin = ExceptionMixinMock

# Generated at 2022-06-12 09:05:58.205915
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test MixedInException.exception() without apply
    class MixedInExceptionChild(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass
    mixed_obj = MixedInExceptionChild()
    mixed_obj.exception(ValueError,apply=False)
    assert(mixed_obj._future_exceptions.pop().handler == ValueError)
    
    # Test MixedInException.exception() with apply
    mixed_obj = MixedInExceptionChild()
    mixed_obj.exception(ValueError)
    assert(mixed_obj._future_exceptions.pop().handler == ValueError)

    # Test MixedInException.exception() with decorator
    mixed_obj = MixedInExceptionChild()
    @mixed_obj.exception(ValueError)
    def f():
        pass

# Generated at 2022-06-12 09:06:05.900984
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pdb; pdb.set_trace()
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_bp", url_prefix="/test", host="example.com")
    app = Sanic("test_app")
    app.blueprint(bp)
    assert len(app.exception_handlers) == 0
    assert len(bp._exception_handlers) == 0

    @bp.exception(ValueError)
    def handler(request, exception):
        assert exception is not None
        return text("Ok")

    assert len(bp._exception_handlers) == 1
    assert len(app.exception_handlers) == 0
    assert bp._exception_handlers[0].handler is handler

# Generated at 2022-06-12 09:06:11.848033
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExcepClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler):
            return handler.handler()

    test_obj = TestExcepClass()

    def test_handler(request, exc):
        return "Handler called"

    @test_obj.exception(Exception)
    def func_to_return_handler(request, exc):
        return test_handler(request, exc)

    assert func_to_return_handler() == "Handler called"

# Generated at 2022-06-12 09:06:15.930762
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    test = Test()

    @test.exception(ValueError)
    def exception_handler(request, exception):
        pass

    assert len(test._future_exceptions) == 1
    assert test._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-12 09:07:25.203127
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    If a method "exception" is present in class ExceptionMixin, then it should
    return a decorated method to handle global exceptions.
    """
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert(handler == "dummy_handler")

    blueprint = ExceptionMixinTest()
    assert(blueprint.exception()("dummy_handler") == "dummy_handler")

# Generated at 2022-06-12 09:07:30.222439
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock

    exception_mixin = ExceptionMixin()
    exception_mixin._apply_exception_handler = Mock()
    decorated_function = exception_mixin.exception([Exception])
    assert exception_mixin._future_exceptions == set()
    decorated_function(Mock())
    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._apply_exception_handler.called




# Generated at 2022-06-12 09:07:37.644867
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.exceptions import SanicException
    from sanic.blueprints import Blueprint

    class MyException(Exception):
        pass

    blueprint_1 = Blueprint('my_blueprint1')
    blueprint_2 = Blueprint('my_blueprint2')

    @blueprint_1.exception(MyException)
    def exception_handler(request, exception):
        raise MyException

    @blueprint_2.exception(SanicException)
    def exception_handler(request, exception):
        raise MyException

    assert len(blueprint_1._future_exceptions) == 1
    future_exception = next(iter(blueprint_1._future_exceptions))
    assert future_exception == FutureException(exception_handler, (MyException,))
    assert future_

# Generated at 2022-06-12 09:07:40.457440
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def f():
        pass
    class SubExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert 1
    SubExceptionMixin().exception(Exception)(f)

# Generated at 2022-06-12 09:07:42.642135
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    mixin = ExceptionMixin()
    assert mixin._future_exceptions == set()
    assert isinstance(mixin.exception, types.FunctionType)


# Generated at 2022-06-12 09:07:52.044057
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class FakeBlueprint:

        def __init__(self, *args, **kwargs) -> None:
            self._handlers = []
            self._future_exceptions = set()

        def handler(self, handler, exc_type=None, apply=True):
            self._handlers.append(handler)

    from sanic.exceptions import SanicException

    bp = FakeBlueprint()
    bp.exception(Exception, apply=False)
    assert len(bp._future_exceptions) == 1
    bp.exception(SanicException, apply=False)
    assert len(bp._future_exceptions) == 2
    assert bp._future_exceptions == set(
        [
            FutureException(None, (Exception,)),
            FutureException(None, (SanicException,)),
        ]
    )

# Generated at 2022-06-12 09:07:59.694889
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json

    class CustomException(SanicException):
        pass

    blueprint = Blueprint('api_v1', url_prefix='/v1', version='1')
    exception = blueprint.exception([CustomException])
    @blueprint.route('/test_for_exception')
    def test_for_exception():
        raise CustomException("Not a good error")

    @exception
    def exception_handler(request, exception):
        return json({'error': str(exception)}, status=200)
    app = Sanic(__name__)
    app.blueprint(blueprint)
    _, response = app.test_client.get("/v1/test_for_exception")
    assert response

# Generated at 2022-06-12 09:08:05.081971
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import HTTPResponse
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler
    TestExceptionMixin._future_exceptions = set()
    TestExceptionMixin.__init__()

    method_exception = TestExceptionMixin.exception
    @method_exception(ValueError, apply=True)
    def handler(request, exception):
        return HTTPResponse("Nothing")
    assert handler is not None

# Generated at 2022-06-12 09:08:12.181477
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import HTTPException
    from sanic.blueprints import Blueprint
    from sanic.models.functions import _handler

    class TestBlueprint(Blueprint, ExceptionMixin):
        def __init__(self, name, url_prefix=None, version=None):
            super(TestBlueprint, self).__init__(name, url_prefix, version)

        @property
        def _deferred_handlers(self):
            return set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_blueprint = TestBlueprint('test')

    @test_blueprint.exception(HTTPException)
    @_handler
    def test_handler():
        return 'test'
# End unit test


# Generated at 2022-06-12 09:08:14.316040
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint(__name__)

    @bp.exception(Exception)
    def test_exception(request, exception):
        return text("An exception has been raised {}".format(exception))

    assert len(bp._future_exceptions) == 1