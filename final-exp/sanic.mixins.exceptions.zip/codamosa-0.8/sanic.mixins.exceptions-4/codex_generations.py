

# Generated at 2022-06-12 08:59:06.217664
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic():
        class Blueprint():
            class TestExceptionMixin(ExceptionMixin):
                def _apply_exception_handler(self, handler):
                    self.handler = handler

                def __init__(self):
                    super().__init__()
                    self.handler = None

        def __init__(self):
            self.blueprint = Sanic.Blueprint.TestExceptionMixin()

    exception_mixin = Sanic().blueprint
    # Test for no exception
    exception_mixin.exception(ValueError)(lambda request, exception: None)
    assert exception_mixin.handler.handler(None, None) is None
    # Test for one exception
    exception_mixin.exception(TypeError)(lambda request, exception: None)
    assert exception_mixin.handler.handler(None, None) is None

# Generated at 2022-06-12 08:59:13.722077
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()

    assert test_exception_mixin._future_exceptions == set()
    test_exception_mixin.exception(IndexError, KeyError)(print)
    test_exception_mixin._apply_exception_handler = lambda hanler: print('')
    assert test_exception_mixin._future_exceptions != set()

# Generated at 2022-06-12 08:59:16.512453
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    TestExceptionMixin()

# Generated at 2022-06-12 08:59:17.089563
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False

# Generated at 2022-06-12 08:59:23.296787
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_ExceptionMixin',url_prefix='/')
    blueprint.exception(Exception)(lambda request, exception: print(exception))
    blueprint.exception(Exception, apply=False)(lambda request, exception: print(exception))
    blueprint.exception([Exception, TypeError])(lambda request, exception: print(exception))
    assert blueprint._future_exceptions.__len__() == 3

# Generated at 2022-06-12 08:59:35.099255
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    class FakeClass:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    class ExceptionHandler:
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, request, exception):
            return None

    bp = Blueprint('test', url_prefix='test')
    args = (ExceptionHandler,)
    kwargs = {}
    fn = bp.exception(ExceptionHandler)
    fn(*args, **kwargs)

# Generated at 2022-06-12 08:59:38.583986
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin1(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions == (Exception,)

    ex = ExceptionMixin1()
    @ex.exception(Exception)
    def handler(request, exception):
        pass

# Generated at 2022-06-12 08:59:41.654819
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        pass
    bp = Blueprint()
    @bp.exception(ValueError, TypeError)
    def handler(request, exception):
        print('Exception: %s' % exception)
    assert bp._future_exceptions == {FutureException(handler, (ValueError, TypeError))}

# Generated at 2022-06-12 08:59:46.433667
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestException(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            print("Exception handler has been applied")

    test_exception = TestException()
    test_exception.exception(Exception)

# Generated at 2022-06-12 08:59:57.683715
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionHandler:
        def __init__(self):
            self.exception_handler = None
            self.exceptions = None

    class TestExceptionMixin:
        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler = handler.handler
            self.exceptions = handler.exceptions

    test_obj = TestExceptionMixin()
    test_obj.__init__()

    # Test for passing only one exception
    @test_obj.exception(Exception)
    def exception_handler(request, exception):
        return 'OK'

    assert test_obj.exception_handler == exception_handler
    assert test_obj.exceptions == (Exception, )

    # Test for passing multiple exceptions

# Generated at 2022-06-12 09:00:06.427766
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    class CustomBlueprint(Blueprint, ExceptionMixin):
        pass

    # Instance
    cb = CustomBlueprint("custom_blueprint")

    @cb.exception(apply=True)
    def handle_exception(request, exception):
        return "handle_exception"

    assert cb._future_exceptions

    # Unit test
    def test_cb_exception():
        handle_exception()

    handle_exception()

# Generated at 2022-06-12 09:00:13.892318
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    # set test enviorment
    class Test_machine(unittest.TestCase):
        def setUp(self):
            class Blueprint(ExceptionMixin):
                _future_exceptions = set()
                def apply_exception_handler(self, handler):
                    self._future_exceptions.add(handler)
            self.print_machine = Blueprint()
        def tearDown(self):
            self.print_machine = None
        def test_normal(self):
            @self.print_machine.exception(ZeroDivisionError)
            def div(x, y):
                return x/y
            self.assertEqual(div(10, 5), 2)
            self.assertEqual(div(10, 5), 2)
            self.assertEqual(div(10, 5), 2)
   

# Generated at 2022-06-12 09:00:18.773262
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint(__name__)
    @bp.exception(Exception)
    def handler():
        pass
    assert len(bp._future_exceptions) == 1
    assert len(bp._future_exceptions[0].exceptions) == 1

# Generated at 2022-06-12 09:00:23.257074
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  class TestExceptionMixin(ExceptionMixin):
    def _apply_exception_handler(self, handler: FutureException):
      return handler

  test_exception_mixin = TestExceptionMixin()

  exception_handler = test_exception_mixin.exception(Exception, apply=False)
  exception_handler(lambda *args, **kwargs: 'exception handler')

  assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:00:25.292453
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Should return nothing (not implemented yet)
    ExceptionMixin().exception()

# Generated at 2022-06-12 09:00:25.892302
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:00:30.189587
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass
    a = A()
    @a.exception(KeyError, 404,  apply=True)
    def handler(request, exception):
        raise NotImplementedError  # noqa

    assert len(a._future_exceptions) == 1

# Generated at 2022-06-12 09:00:41.499231
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.exceptions import SanicException

    blue_print = Blueprint("blueprint")

    @blue_print.exception(SanicException)
    def handle_sanic_exception(request, exception):
        print("Catch an exception")


# Generated at 2022-06-12 09:00:48.175884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test Arguments
    args = ('except1', 'except2')

    # Create an instance of ExceptionMixin for testing
    ex_mixin = ExceptionMixin()

    # Call decorator of method exception
    decorator = ex_mixin.exception(*args)
    handler_exception = decorator(lambda: None)

    # Get all future exceptions that have been registered
    future_exceptions = ex_mixin._future_exceptions

    # Check length of future_exceptions
    assert isinstance(future_exceptions, set)
    assert len(future_exceptions) == 1

    # Check elements of future_exceptions
    assert handler_exception in future_exceptions



# Generated at 2022-06-12 09:00:55.875823
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Mock:
        pass

    mock = Mock()
    mock._future_exceptions = set()

    @mock.exception
    def test(request, exception):
        return f'oops! An exception occurred: {exception}'  

    assert len(mock._future_exceptions) == 1

    future_exception = list(mock._future_exceptions)[0]
    print(future_exception._handler('request', 'exception'))
    

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:01:05.862035
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Bp(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.exceptions= set()

        def _apply_exception_handler(self, handler):
            self.exceptions.add(handler)

    bp = Bp()
    @bp.exception(Exception)
    def handler(request, exception):
        pass
    assert len(bp.exceptions) == 1

# Generated at 2022-06-12 09:01:16.142145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.blueprint import Blueprint, Group

    app = Sanic('test_exception')
    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(Exception, apply=True)
    def exception_handler(request: Request, exception: Exception):
        return HTTPResponse(
            status=500,
            text="Internal Server Error")

    @bp.route('/')
    async def handler(request: Request):
        raise Exception('test')

    bp.group = Group()
    bp.group.routes = []
    bp.group.routes.append(bp.routes[0])

# Generated at 2022-06-12 09:01:25.894073
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # ------------------------------------------------------------ #
    # exception(apply=True)
    # The parameter apply is True
    # ------------------------------------------------------------ #
    # Case 1: 
    # ------------------------------------------------------------ #
    from sanic.models.future import Future, FutureResult
    from sanic.blueprints import Blueprint
    from utils import CustomException
    
    def test_exception_handler():
        print("Inside exception handler")
    
    blueprint = Blueprint('test_exception_apply_true', url_prefix='test')
    blueprint.exception(CustomException, apply=True)(test_exception_handler)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == test_exception_handler

    # Case 2: 
    # ------------------------------------------------------------ #
    from sanic.models.future import Future, FutureResult
   

# Generated at 2022-06-12 09:01:29.666564
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    def test_handler():
        pass

    bp = Blueprint("test")
    bp.exception(Exception)(test_handler)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions == {
        FutureException(test_handler, (Exception,))
    }

# Generated at 2022-06-12 09:01:35.133730
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.blueprints import Blueprint

    app = Sanic("test_exception_mixing")

    bp = Blueprint("bp", url_prefix="/test")

    @bp.exception(Exception)
    def test_exception_handler(request, exception):
        return text("Ouch!  You have an exception")

    app.blueprint(bp)

    request, response = app.test_client.get("/test/test_exception_handler")
    assert response.status == 500

    request, response = app.test_client.get("/test/test_exception_handler")
    assert response.status == 500
    assert response.text == "Ouch!  You have an exception"

# Generated at 2022-06-12 09:01:40.030258
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    app = Sanic()
    bp = MyExceptionMixin(app)
    assert isinstance(bp, ExceptionMixin)
    assert hasattr(bp, '_future_exceptions')

# Generated at 2022-06-12 09:01:44.720448
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class app:
        pass
    
    class Mixin(ExceptionMixin):
        
        def _apply_exception_handler(self, handler):
            pass
        
        def _clear_exception_handler(self, handler):
            pass
    
    def test_handler(request, exception):
        return exception
    
    mixin = Mixin()
    mixin.exception(test_handler)
    assert len(mixin._future_exceptions) == 1
    assert list(mixin._future_exceptions)[0].handler == test_handler

# Generated at 2022-06-12 09:01:50.913935
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.blueprint import BlueprintContainer

    bp = Blueprint("bp_test", url_prefix="/test")

    assert hasattr(bp, "exception")
    assert isinstance(bp, ExceptionMixin)
    assert isinstance(bp, BlueprintContainer)

    @bp.exception(ValueError, apply=True)
    def handle_value_error(request, exception):
        raise Exception("testing exception handler")

    bp.exception(IndexError)

# Generated at 2022-06-12 09:01:59.662871
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class User:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

        def exception(self, *exceptions, apply=True):
            """
            This method enables the process of creating a global exception
            handler for the current blueprint under question.

            :param args: List of Python exceptions to be caught by the handler
            :param kwargs: Additional optional arguments to be passed to the
                exception handler

            :return a decorated method to handle global exceptions for any
                route registered under this blueprint.
            """

            def decorator(handler):
                nonlocal apply
                nonlocal exceptions


# Generated at 2022-06-12 09:02:07.625908
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprint import Blueprint
    from sanic.server import HttpProtocol
    from sanic import Sanic

    application = Sanic(__name__)
    sub_blueprint = Blueprint('sub_blueprint')
    sub_blueprint2 = Blueprint('sub_blueprint2')

    sub_blueprint.exception(IndexError)(lambda request, exception: 'hi')
    sub_blueprint.exception(IndexError)(lambda request, exception: 'hio')
    assert len(sub_blueprint._future_exceptions) == 1
    assert sub_blueprint._future_exceptions.pop() == FutureException(
        lambda request, exception: 'hio',
        (IndexError,)
    )

# Generated at 2022-06-12 09:02:19.622866
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return handler

    em = _ExceptionMixin()
    @em.exception(AssertionError)
    def handler():
        pass

    assert isinstance(handler, types.FunctionType)
    assert handler in [e.handler for e in em._future_exceptions]

# Generated at 2022-06-12 09:02:27.555243
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExcpetionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    # Create an object of TestExcpetionMixin
    test_object = TestExcpetionMixin()
    assert test_object._future_exceptions == set()

    # Create a list of exceptions
    exceptions = [ValueError, Exception]

    # Create a decorator
    def decorator(handler):
        assert handler == handle_exception
        return handle_exception

    # Call method exception with 'exceptions' and 'decorator'
    test_object.exception(exceptions, apply=True)(decorator)
    assert len(test_object._future_exceptions) == 1  # noqa



# Generated at 2022-06-12 09:02:33.932577
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    def exception_handler(request, exception):
        return None

    test_exception_mixin = TestExceptionMixin()
    exception_decorator = test_exception_mixin.exception(ArithmeticError)
    exception_decorator(exception_handler)

# Generated at 2022-06-12 09:02:40.672785
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_fake1(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
        def _apply_exception_handler(self, handler):
            pass

    a = ExceptionMixin_fake1()
    @a.exception(ValueError)
    def fake():
        pass
    @a.exception(ValueError)
    def fake1():
        pass
    assert len(a._future_exceptions) == 2

# Generated at 2022-06-12 09:02:47.005016
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return NotImplementedError

    # (1) test if test_handler is returned by ExceptionMixin.exception
    #      with apply = False
    test_handler = lambda x:x
    test_exception = TestExceptionMixin()
    assert test_handler == test_exception.exception(IOError, apply=False)(test_handler)

    # (2) test if test_future_exception is added to self._future_exceptions
    #     set when test_handler is decorated by ExceptionMixin.exception
    test_future_exception = FutureException(test_handler, [IOError])
    assert test_future_exception in test_exception._future_exceptions

# Generated at 2022-06-12 09:02:53.462693
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    m = ExceptionMixinTest()
    assert m._future_exceptions == set()
    @m.exception
    def exception_handler(request, exception):
        return str(exception)
    assert m._future_exceptions != set()
    for fe in m._future_exceptions:
        assert exception_handler == fe.handler
        assert () == fe.exceptions

# Generated at 2022-06-12 09:02:55.034813
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    with ExceptionMixin() as mixin:
        mixin.exception()

# Generated at 2022-06-12 09:03:02.858008
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyException(Exception):
        pass

    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    dummy_exception_mixin = DummyExceptionMixin()

    @dummy_exception_mixin.exception(DummyException)
    async def dummy_exception_handler(request, exception, *args, **kwargs):
        pass

    future_exception = FutureException(
        dummy_exception_handler, (DummyException, ))
    assert dummy_exception_mixin._future_exceptions == {future_exception}

# Generated at 2022-06-12 09:03:03.383786
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:03:08.983502
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixinException(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    test_object = TestExceptionMixinException()

    @test_object.exception(Exception, apply=False)
    def test_function(request, exception):
        return request + exception

    assert test_function(1, "a") == "1a"

# Generated at 2022-06-12 09:03:28.988376
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ABC():
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(2)
    # print(exception_mixin.exception())

test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:03:30.384267
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ExceptionMixin()

# Generated at 2022-06-12 09:03:31.914797
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint('test_bp')
    blueprint.exception(Exception, ValueError)(lambda x: x)
    assert all(map(lambda x: isinstance(x, FutureException), blueprint._future_exceptions))



# Generated at 2022-06-12 09:03:39.857529
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView

    app = Sanic('test_ExceptionMixin_exception')

    class ExampleView(HTTPMethodView, ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(HTTPMethodView, self).__init__(*args, **kwargs)
            ExceptionMixin.__init__(self, *args, **kwargs)

        def get(self):
            raise Exception('error')

    view = ExampleView.as_view()
    view.exception(Exception)(lambda request, exc: 'Internal Server Error')
    app.add_route(view, '/')

    request, response = app.test_client.get('/')

    assert response.status == 500

# Generated at 2022-06-12 09:03:43.495475
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_restplus.api import Api
    from sanic_restplus.namespace import Namespace

    app = Api()
    ns = Namespace(app)
    ns.exception(Exception)(lambda: None)

# Generated at 2022-06-12 09:03:44.583979
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    b = Blueprint("test")
    b.exception([a,b])

# Generated at 2022-06-12 09:03:52.490470
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestException(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert handler._handler is exception_handler
            assert handler._exceptions == exceptions

    @TestException.exception(HTTPException, Exception, apply=False)
    async def exception_handler(request, exception):
        assert request
        assert exception

    assert len(TestException._future_exceptions) == 1
    exceptions = TestException._future_exceptions.pop()._exceptions
    assert isinstance(exceptions[0], HTTPException)
    assert isinstance(exceptions[1], Exception)



# Generated at 2022-06-12 09:03:56.159115
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text

    @Blueprint.exception([TypeError])
    async def handle_exception(request, exception):
        return text('Internal server error', 500)

    assert isinstance(handle_exception, Blueprint)
    assert handle_exception
    assert handle_exception.exception_handlers



# Generated at 2022-06-12 09:04:05.880052
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    @TestExceptionMixin.exception(ValueError)
    def handle_value_error(request, exception):
        return "ValueError Occurred"

    @TestExceptionMixin.exception([ValueError, MemoryError], apply=False)
    def handle_value_memory_error(request, exception):
        return "ValueError or MemoryError Occurred"

    t = TestExceptionMixin()

    assert len(t._future_exceptions) == 2
    has_handle_value_error = False
    has_handle_value_memory_error = False
    for fe in t._future_exceptions:
        assert issubclass(fe.exception, Exception)
        assert isinstance(fe.handler, types.FunctionType)

# Generated at 2022-06-12 09:04:10.426234
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__, url_prefix="test")
    blueprint.exception(Exception)
    blueprint.exception(IndexError)
    blueprint.exception(ValueError)

    blueprint.exception([AttributeError, ArithmeticError])

    blueprint.exception(Exception, apply=False)
    blueprint.exception(ValueError, apply=False)

# Generated at 2022-06-12 09:04:47.036440
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import ServerError
    from sanic.exceptions import NotFound
    from sanic.exceptions import URLBuildError
    from sanic.exceptions import InvalidUsage


    base_exception_list = [ServerError, NotFound, URLBuildError, InvalidUsage]
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler is not None

    exception_mixin = MyExceptionMixin()

    @exception_mixin.exception(base_exception_list)
    def get_base_exception_handler(request, exception):
        assert exception is not None

    exception = ServerError()
    exception_handler = get_base_exception_handler(None, exception)
    assert exception_handler is not None
    assert get_

# Generated at 2022-06-12 09:04:54.765460
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    blueprint = Blueprint('blueprint')

    # test for decorator exception and apply=False
    @blueprint.exception(ZeroDivisionError, apply=False)
    def handler_exception_false(_req, _err):
        return 'hello world'

    # test for decorator exception and apply=True
    @blueprint.exception(ZeroDivisionError, apply=True)
    def handler_exception_true(_req, _err):
        return 'hello world'

    # test for decorator exception
    @blueprint.exception(ZeroDivisionError)
    def handler_exception(_req, _err):
        return 'hello world'

    # test for decorator exception

# Generated at 2022-06-12 09:05:02.008254
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest

    class TestExceptionMixin(ExceptionMixin, object):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()
            self._exception_applied = None

        def _apply_exception_handler(self, handler: FutureException):
            self._exception_applied = handler

    # create blueprint and test the exception method
    blueprint = TestExceptionMixin()

    @blueprint.exception((ValueError,), apply=False)
    def exception_handler(request, exception):
        return True

    assert isinstance(exception_handler.__self__, FutureException)

    assert len(blueprint._future_exceptions) == 1

    assert blueprint._exception_applied is None

    # create another exception, and verify that the previous exception
    # had not been applied

# Generated at 2022-06-12 09:05:10.656529
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exceptions = list()
            self.handlers = list()
        
        def _apply_exception_handler(self, handler: FutureException):
            self.exceptions.append(handler.exceptions)
            self.handlers.append(handler.handler)
    
    class _B(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exceptions = list()
            self.handlers = list()
        

# Generated at 2022-06-12 09:05:20.502021
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.response import text
    from sanic.views import CompositionView
    from sanic.exceptions import Forbidden, ServerError
    from sanic.websocket import WebSocketProtocol, ConnectionClosed
    from unittest import TestCase

    class ExceptionMixin_test(TestCase):
        def test_ExceptionMixin_exception_1(self):

            bp = Blueprint(url_prefix='test', name='test_ExceptionMixin_exception')

            @bp.exception([Forbidden, ServerError], apply=False)
            async def handler(request, error):
                return text('{}', status=error.status_code)


# Generated at 2022-06-12 09:05:28.717272
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest

    class ExceptionMixinTest(unittest.TestCase, ExceptionMixin):

        def __init__(self, *args, **kwargs):
            super(ExceptionMixinTest, self).__init__()
            ExceptionMixin.__init__(self, *args, **kwargs)

        @ExceptionMixin.exception(AssertionError)
        def test_exception_handler(self):
            pass

    exception_mixin: ExceptionMixinTest = ExceptionMixinTest(
        'method exception of class ExceptionMixin'
    )

    assert isinstance(exception_mixin, ExceptionMixin)
    assert isinstance(
        exception_mixin._future_exceptions.pop(),
        FutureException
    )

# Generated at 2022-06-12 09:05:31.923107
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        pass

    dut = DummyExceptionMixin()
    assert isinstance(dut._future_exceptions, Set)
    assert dut.exception is not None

# Generated at 2022-06-12 09:05:34.907386
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    @ExceptionMixin.exception()
    def handler():
        return 'Function test'

    # Action
    handler()

    # Assert
    assert handler() == 'Function test'

# Generated at 2022-06-12 09:05:40.197918
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinSubclass(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            assert(handler._handler == decorator_handler)
            assert(handler._exceptions == (ValueError,))

    ex_mixin = ExceptionMixinSubclass()

    @ex_mixin.exception(ValueError)
    def decorator_handler(error):
        pass

# Generated at 2022-06-12 09:05:44.760983
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    try:
        testExceptionMixin = TestExceptionMixin()
        exception_handler = testExceptionMixin.exception()
        exception_handler(FutureException(lambda exception: None,
                                          "TypeError"))
    except:
        assert False
    assert True

# Generated at 2022-06-12 09:06:49.380389
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert not hasattr(ExceptionMixin, "exception")

# Generated at 2022-06-12 09:06:53.790489
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self) -> None:
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    try:
        t = TestExceptionMixin()
        assert t._future_exceptions == set()
        t.exception(1,2,3)(4)
        assert t._future_exceptions
    finally:
        pass
    #assert 0

# Generated at 2022-06-12 09:06:57.738210
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return "test class"

    test = TestClass()
    result = test.exception(Exception)(lambda *args, **kwargs: None)
    assert isinstance(result, FunctionType)



# Generated at 2022-06-12 09:07:02.672973
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.view import View
    class ViewExceptionMixin(View, ExceptionMixin):
        pass

    view = ViewExceptionMixin()

    @view.exception(Exception)
    def error_handler(request, exception):
        return 'Internal server error'
    assert len(view._future_exceptions) == 1
    assert view._future_exceptions[0].handler_mock == error_handler
    assert view._future_exceptions[0].exceptions == (Exception)
    assert view._future_exceptions[0].handler == error_handler

# Generated at 2022-06-12 09:07:08.265383
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_class(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = test_class()
    @a.exception(ValueError)
    def test_exception(self, request, exception):
        return 'exception'
    assert a._future_exceptions == {FutureException(test_exception, (ValueError,)) }

# Generated at 2022-06-12 09:07:16.951339
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SomeClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)

        def some_method(self, handler: FutureException):
            nonlocal apply
            nonlocal exceptions

            if isinstance(exceptions[1], list):
                exceptions = tuple(*exceptions)

            future_exception = FutureException(handler, exceptions)
            self._future_exceptions.add(future_exception)
            if apply:
                self._apply_exception_handler(future_exception)
            return handler

        def test_exception_case1(self):
            # test case 1: exception not in list and apply is True
            exceptions = [IndexError, KeyError]
            apply = True
            result = self.some_method(exceptions, apply)



# Generated at 2022-06-12 09:07:26.223590
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create an instance of class ExceptionMixin
    class DummyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_instance = DummyExceptionMixin()
    # case 1:
    # test_instance._future_exceptions is empty
    # create a new FutureException
    # add the FutureException to _future_exceptions
    # call decorator
    @test_instance.exception([Exception])
    def visible_dummy_handler(request, exception):
        print(exception)
        pass
    # after exception() is called, test_instance._future_exceptions should
    # contain the new FutureException
    result = len(test_instance._future_exceptions)
    expected = 1
    assert result == expected
    # case 2:
    #

# Generated at 2022-06-12 09:07:27.692116
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    bp = Blueprint("test_bp")
    assert bp.exception

# Generated at 2022-06-12 09:07:33.567300
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class DummyExceptionMixin(ExceptionMixin):
        def start(self):
            print(self._future_exceptions)
            for exception in self._future_exceptions:
                self._apply_exception_handler(exception)

    dummy = DummyExceptionMixin()
    assert not dummy._future_exceptions
    decorator = dummy.exception(Exception, apply=False)

    def handler(request, exception):
        print('here is the handler')

    decorated = decorator(handler)
    assert len(dummy._future_exceptions) == 1
    assert dummy._future_exceptions.__contains__(FutureException(decorated, (Exception, )))
    dummy.start()

# Generated at 2022-06-12 09:07:41.822686
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.exceptions import SanicException
    from sanic_restplus import Api as RestPlusApi
    from sanic_restplus import Namespace as RestPlusNamespace
    from sanic_restplus import Resource as RestPlusResource

    from sanic.log import access_logger
    from sanic.response import json as json_response

    # Create an instance of Sanic
    app = Sanic('test_ExceptionMixin_exception')

    # Create an instance of Blueprint
    blueprint = Blueprint('test_bp', __name__)

    # Create an instance of Api
    api_bp_1 = RestPlusApi(blueprint=blueprint)

    # Create an instance of SanicException