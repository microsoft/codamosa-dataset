

# Generated at 2022-06-12 08:59:11.602307
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic(__name__)

    @app.exception(ZeroDivisionError)
    async def handler(request, exception):
        return json({"Exception": "{}".format(exception)})

    @app.route("/")
    def handler(request):
        1 / 0

    request, response = app.test_client.get("/")

    assert response.status == 500
    assert await response.json() == {"Exception": "<class 'ZeroDivisionError'>"}

# Generated at 2022-06-12 08:59:20.490220
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()

    # test if decorator exception is created without applying and without exception arguments
    with pytest.raises(TypeError):
        @test_exception_mixin.exception()
        def test_future_exception():
            pass

    # test if decorator exception is created without applying and with wrong exception arguments
    with pytest.raises(TypeError):
        @test_exception_mixin.exception((Exception,))
        def test_future_exception():
            pass

    # test if decorator exception is created without applying and with correct exception arguments
    @test_exception_mixin.exception((BaseException,))
    def test_future_exception():
        pass


# Generated at 2022-06-12 08:59:25.743207
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

        def helpfunc(self):
            pass

    testexceptionmixin = TestExceptionMixin()

    @testexceptionmixin.exception(ValueError)
    def testfunc():
        pass

    assert len(testexceptionmixin._future_exceptions) == 1

# Generated at 2022-06-12 08:59:28.848904
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test with normal input
    blueprint = Blueprint("api_v1")
    try:
        blueprint.exception(ValueError, apply=True)
    except Exception:
        assert False
    assert True

# Generated at 2022-06-12 08:59:34.502280
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from . import Sanic
    app = Sanic('test_exception_mixin_exception')

    @app.exception(Exception)
    def exception_handler(request, exception):
        assert isinstance(request, Request)
        assert isinstance(exception, Exception)
        return text('Exception caught!')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'Exception caught!'

# Generated at 2022-06-12 08:59:35.783398
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 08:59:42.010260
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(Exception, BaseException, apply=False)
    def exception_handler(request, exception):
        return request

    assert blueprint._future_exceptions == set()

    future_exception = FutureException(exception_handler, (Exception, BaseException))
    blueprint._future_exceptions.add(future_exception)

    assert future_exception in blueprint._future_exceptions
    assert blueprint._future_exceptions == {future_exception}

# Generated at 2022-06-12 08:59:50.552030
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView, View

    app = Sanic()

    class MyView(View):
        pass

    @app.route('/test_exception')
    def handler(request):
        return text('OK')

    @app.exception(Exception)
    def handler_exception(request, exception):
        return text('Internal Server Error', status=500)

    request, response = app.test_client.get('/test_exception')
    assert response.status == 200

    request, response = app.test_client.get('/none')
    assert response.status == 404


# Generated at 2022-06-12 09:00:00.400975
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import json
    import json as json_module

    bp = Blueprint("test_bp", url_prefix="test")

    @bp.exception(Exception)
    def handler(request, exception):
        return json({"code": 501, "content": "exception"})
    
    @bp.get("/test", name="test_exception_route")
    def test_exception_route(request):
        raise Exception("test exception")

    app = bp.as_globals()

    _, response = app.test_client.get("/test/test")
    json_response = json_module.loads(response.text)

    assert response.status == 501
    assert json_response == {"code": 501, "content": "exception"}

# Generated at 2022-06-12 09:00:07.726146
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage

    class Test(ExceptionMixin):

        @property
        def future_exceptions(self):
            return self._future_exceptions.copy()

        def _apply_exception_handler(self, future_exception):
            pass

    test = Test()

    @test.exception(InvalidUsage)
    def handler(request, exception):
        raise exception

    future_exception = FutureException(
        handler=handler, exceptions=(InvalidUsage,)
    )

    assert future_exception in test.future_exceptions

# Generated at 2022-06-12 09:00:15.547586
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception1 = test_exception_mixin.exception(ZeroDivisionError)(lambda x: x)
    test_exception2 = test_exception_mixin.exception(ZeroDivisionError, IndexError)(lambda x: x)
    test_exception3 = test_exception_mixin.exception([ZeroDivisionError, IndexError])(lambda x: x)

    assert len(test_exception_mixin._future_exceptions) == 3
    assert (ZeroDivisionError, ()) in test_exception_mixin._future_exceptions

    assert test_exception1 is not None
    assert test

# Generated at 2022-06-12 09:00:22.537495
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # for test
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            self._exception = None
            self.foo = 0
            self.bar = 0

        def _apply_exception_handler(self, handler: FutureException):
            self._exception = handler

        def exception(self, *args):
            self.foo = 1
            self.bar = 1
            return self

    mixin = TestExceptionMixin()
    mixin.exception(404)
    assert mixin.foo == 1
    assert mixin.bar == 1
    # test end

# Generated at 2022-06-12 09:00:25.938209
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(ValueError)
    def exception_handler(request, exception):
        return request.response.text(
            f"Oops..Something went wrong: {exception}", status=500
        )

# Generated at 2022-06-12 09:00:26.952473
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-12 09:00:33.515956
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.helpers import extract_unspecified
    bp = Blueprint('test', url_prefix='/')

    @bp.exception([Exception])
    def error(request, exception):
        pass

    assert bp.has_exception_handler
    assert len(bp._future_exceptions) == 1
    exceptions = extract_unspecified(bp.error_handler, 'exceptions')
    assert exceptions == [Exception]

# Generated at 2022-06-12 09:00:37.892702
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Fake:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            return
        
        def test_method(self, *exceptions, apply=True):
            def decorator(handler):
                nonlocal apply
                nonlocal exceptions
                future_exception = FutureException(handler, exceptions)
                self._future_exceptions.add(future_exception)
                if apply:
                    self._apply_exception_handler(future_exception)
                return handler
            return decorator
    class TestException(Exception):
        pass
    test = Fake()
    assert len(test._future_exceptions) == 0

# Generated at 2022-06-12 09:00:46.032627
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._future_exceptions = set()
            self._exception_handler = None

        def _apply_exception_handler(self, handler):
            self._exception_handler = handler

    # Test with apply=False
    test_class = TestClass()
    @test_class.exception(AttributeError, AssertionError, apply=False)
    def test_function(request, exception):
        pass

    assert len(test_class._future_exceptions) == 1
    assert test_class._exception_handler is None

# Generated at 2022-06-12 09:00:51.316698
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    bp = Blueprint('bp')

    @bp.exception([ServerError])
    async def server_error_handler(request, exception):
        return 'Got {}'.format(exception), exception.status_code

    assert bp.name == 'bp'

# Generated at 2022-06-12 09:00:55.840745
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        @app.get("/")
        @app.exception(ValueError, apply=False)
        def exception_handler(request, exception):
            return json({"exception": exception.__class__.__name__})
    except Exception as ex:
        pytest.fail("Exception unexpected: " + ex.__doc__)



# Generated at 2022-06-12 09:00:56.528228
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:01:06.221688
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    testExceptionClass = TestExceptionClass()

    def handler():
        pass

    testExceptionClass.exception(Exception)(handler)

# Generated at 2022-06-12 09:01:16.807929
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_exception', 'test_exception')

    @blueprint.exception(Exception, apply=True)
    async def handler1(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1

    future_exception = next(iter(blueprint._future_exceptions))
    assert future_exception.handler == handler1
    assert isinstance(future_exception.exceptions, tuple)
    assert len(future_exception.exceptions) == 1
    assert Exception in future_exception.exceptions
    assert not future_exception.kwargs

    @blueprint.exception([ValueError, TypeError], apply=True)
    async def handler2(request, exception):
        pass


# Generated at 2022-06-12 09:01:26.339732
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test exception decorator with apply is false
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(Exception, apply=False)
    assert len(exception_mixin._future_exceptions) == 0

    # Test exception decorator with apply is true
    with raises(NotImplementedError):
        exception_mixin.exception(Exception)()

    # Test exception decorator with multiple exceptions
    exceptions = {KeyError, ValueError}
    exception_mixin.exception(*exceptions)
    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.pop()
    assert future_exception.handler is None
    assert future_exception.exceptions is exceptions

    # Test exception decorator with list of exceptions

# Generated at 2022-06-12 09:01:31.240032
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from blueprint.blueprint import Blueprint

    @Blueprint.exception(ZeroDivisionError)
    def zero_division_error_handler(request, exception):
        return text('zero_division_error_handler')

    blueprint = Blueprint('Test', url_prefix='bp-test')
    blueprint.add_exception(zero_division_error_handler, ())

    assert len(blueprint._future_exceptions) == 2
    assert blueprint.exception_handler is not None

# Generated at 2022-06-12 09:01:31.712444
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:01:39.614660
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.exceptions import InvalidUsage

    exc_blu = Blueprint('exc_blu', url_prefix='/exc_blu')

    @exc_blu.exception(InvalidUsage, apply=True)
    async def exc_handler(request, exception):
        pass

    assert exc_handler == exc_handler
    assert len(exc_blu._future_exceptions) == 1

    future_exception = FutureException(exc_handler, InvalidUsage)
    assert future_exception in exc_blu._future_exceptions

# Generated at 2022-06-12 09:01:45.968520
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test Cases:
    # 1- Test exception with missing parameter
    # 2- Test exception with empty parameter
    # 3- Test exception with invalid parameter
    # 4- Test exception with missing apply parameter
    # 5- Test exception with invalid apply parameter
    # 6- Test exception with missing decorator
    # 7- Test exception with invalid decorator

    # Test Case 1: exception with missing parameter
    with pytest.raises(TypeError):
        exception()

    # Test Case 2: exception with empty parameter
    with pytest.raises(TypeError):
        exception(Exception)

    # Test Case 3: exception with invalid parameter
    with pytest.raises(TypeError):
        exception(Exception, 'invalid')

    # Test Case 4: exception with missing apply parameter

# Generated at 2022-06-12 09:01:53.630407
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class mock_blueprint:
        def __init__(self):
            pass

        def _apply_exception_handler(self, handler: FutureException):
            pass


    class my_exception(ExceptionMixin, mock_blueprint):
        pass

    exception = my_exception()
    def handler(request, exception):
        pass
    def handler1(request, exception):
        return True

    assert len(exception._future_exceptions) == 0

    exception.exception(handler)
    assert len(exception._future_exceptions) == 1
    exception.exception(handler1)
    assert len(exception._future_exceptions) == 2

# Generated at 2022-06-12 09:01:57.532123
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = Sanic()
    @bp.exception(Exception)
    def error_handler(request, exception):
        pass
    assert len(bp._future_exceptions) == 1



# Generated at 2022-06-12 09:02:02.782106
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from unittest.mock import property
    # set up
    blueprint = Blueprint('test', url_prefix='test')
    blueprint.exception(Exception, apply=False)

    # test
    assert isinstance(blueprint._future_exceptions, set)
    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), 
                    FutureException)

# Generated at 2022-06-12 09:02:15.494863
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    a = A()
    assert isinstance(a.exception(Exception), types.FunctionType)
    assert isinstance(a.exception([Exception]), types.FunctionType)


# Generated at 2022-06-12 09:02:24.663086
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global exception_handler
    exception_handler = None
    class ExceptionMixinImplementation1:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()
            self._apply_exception_handler(None)
        def _apply_exception_handler(self, handler: FutureException):
            global exception_handler
            exception_handler = handler
    class ExceptionMixinImplementation2:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()
            self._apply_exception_handler(None)
        def _apply_exception_handler(self, handler: FutureException):
            global exception_handler
            exception_handler = handler

# Generated at 2022-06-12 09:02:34.316331
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test1(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exception==(Exception,)
            assert handler.handler.__name__=="handler"
            assert handler.kwargs=={"kwargs_test":"test"}

    test1=Test1()
    test1.exception(Exception,kwargs_test="test")(handler)

    class Test2(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exception == (Exception, Exception)
            assert handler.handler.__name__ == "handler"
            assert handler.kwargs == {"kwargs_test": "test"}

    test2 = Test2()
    test2.exception([Exception,Exception], kwargs_test="test")(handler)

# Generated at 2022-06-12 09:02:41.162160
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    BlueprintApp = Blueprint

    hello_blueprint = BlueprintApp('hello', url_prefix='/hello')

    @hello_blueprint.exception(Exception)
    async def handle_exception(request, exception):
        pass

    try:
        assert handle_exception
        assert hello_blueprint._future_exceptions
    except AssertionError as e:
        print(e)
    else:
        print("Test for method exception of class ExceptionMixin passed.")

# Generated at 2022-06-12 09:02:45.377322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test = TestExceptionMixin()

    @test.exception(
        (ZeroDivisionError, ),
        apply=True,
        test_future_exception=1
    )
    def test_handler(request, exception):
        return request.path

    assert not hasattr(test, "_future_exceptions")
    assert test_handler(1, 2) == 1

# Generated at 2022-06-12 09:02:54.412306
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create a class which derives from ExceptionMixin
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return

    # Create a test object
    t = TestExceptionMixin()

    # Test case: test the case that handler is a method
    def handler():
        return

    t.exception(AttributeError, SyntaxError)(handler)
    assert handler in t._future_exceptions

    # Test case: test the case that apply is True
    def handler_1():
        return

    t.exception(AttributeError, SyntaxError, apply=True)(handler_1)
    assert handler_1 in t._future_exceptions

    # Test case: test the

# Generated at 2022-06-12 09:02:59.065163
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self):
            self.test_test = None
        def _apply_exception_handler(self, handler):
            self.test_test = handler
            
    a = A()
    @a.exception(NameError, apply=True)
    def d():
        return 1
    assert a.test_test.handler == d

# Generated at 2022-06-12 09:03:01.366931
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        raise ExceptionMixin.exception(Exception)(lambda request: None)
    except NotImplementedError:
        pass
    except:
        assert False

# Generated at 2022-06-12 09:03:03.056032
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = ExceptionMixin()
    assert a._future_exceptions == set()
    a.exception()

# Generated at 2022-06-12 09:03:08.351051
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        class ExceptionMixinTest(ExceptionMixin):
            pass
        mixin = ExceptionMixinTest()
        def exception_handler(*args, **kwargs):
            return "test"
        mixin.exception(ValueError, apply=False)(exception_handler)
    except Exception as e:
        assert False, "Can not run method exception, error {}.".format(e)
    else:
        assert True

# Generated at 2022-06-12 09:03:31.069813
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import SanicException
    from sanic_exception import SanicExceptionHandlersMixin
    from sanic.request import Request
    from sanic.response import HTTPResponse

    def handler1():
        pass

    def handler2():
        pass

    def handler3():
        pass

    sanic_app = Sanic('test_SanicExceptionHandlersMixin_test_exception')
    sanic_app.config.from_object(
        'sanic_exception.config.default_config.DefaultConfig')

    blueprint = SanicExceptionHandlersMixin(
        'test1', 
        url_prefix='/test1', 
        strict_slashes=True)
    blueprint.add_exception_handler(handler1)

# Generated at 2022-06-12 09:03:39.382079
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_exception(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            self.handler = handler
            self.exceptions = handler.exceptions

    obj = ExceptionMixin_exception()
    @obj.exception(Exception)
    def banana(request, exception):
        pass

    assert not hasattr(obj, 'handler')
    assert not hasattr(obj, 'exceptions')
    obj._apply_exception_handler(obj._future_exceptions.pop())
    assert hasattr(obj, 'handler')
    assert obj.handler == banana
    assert hasattr(obj, 'exceptions')
    assert obj.exceptions == (Exception,)

    class CustomException1(BaseException):
        pass

    class CustomException2(BaseException):
        pass


# Generated at 2022-06-12 09:03:44.889717
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinExample(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return "test_ExceptionMixin_exception"
    ExceptionMixinExampleInstance = ExceptionMixinExample()
    @ExceptionMixinExampleInstance.exception(Exception, apply=False)
    def name_error_handler(request, exception):
        return 1
    assert name_error_handler.__name__ == "name_error_handler"

# Generated at 2022-06-12 09:03:47.928513
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def handler(r, e):
        x=1
    assert handler.__name__ == "handler"
    assert len(ExceptionMixin._future_exceptions) == 0

# Generated at 2022-06-12 09:03:53.538240
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # this is a test
    class Mock_ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(Mock_ExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    em = Mock_ExceptionMixin()

    @em.exception(Exception)
    def handler():
        pass

    assert len(em._future_exceptions) == 1
    assert any([fe.handler == handler for fe in em._future_exceptions])

# Generated at 2022-06-12 09:03:57.307990
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler():
            pass

    test = TestExceptionMixin()

    try:
        @test.exception(list)
        def test_handler():
            pass
    except Exception:
        assert True

    try:
        @test.exception(Exception)
        def test_handler():
            pass
    except Exception:
        assert False

# Generated at 2022-06-12 09:04:06.213751
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Future(ExceptionMixin):
        def __init__(self, blueprint, request, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return

        def route(self, uri, methods=frozenset({'GET'}), host=None,
                  strict_slashes=False, stream=False):
            def decorator(handler):
                # Register route.
                return handler

            return decorator

    @Future.exception(Exception)
    def handler(request, exception):
        # An handler of the type exception for any route of the future
        return

    @Future.route(uri='/', methods={'GET'})
    def get(request):
        return request

# Generated at 2022-06-12 09:04:11.909049
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  class MyExceptionMixin(ExceptionMixin):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
  
  my_exception_mixin = MyExceptionMixin()
  my_exception_mixin.exception(Exception)(lambda *args: True)
  assert len(my_exception_mixin._future_exceptions) == 1
  assert len(my_exception_mixin._future_exceptions.pop().exceptions) == 1

# Generated at 2022-06-12 09:04:16.401744
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprint import Blueprint

    blueprint = Blueprint('test_ExceptionMixin_exception')
    blueprint.exception(IndexError)(lambda: print('Test exception IndexError'))

    assert blueprint._future_exceptions.__len__() == 1

# Generated at 2022-06-12 09:04:23.866206
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    class CustomView(HTTPMethodView):
        def __init__(self):
            pass

        async def get(self, request):
            return text('I am get method')

        async def post(self, request):
            return text('I am post method')

    @BP.exception(ServerError)
    def other_exception_handler(request, exception):
        return text('global exception handler')

    @BP.exception(ServerError)
    def other_exception_handler(request, exception):
        return text('exception handler')

    BP = Blueprint('MyBlueprint', url_prefix='test')

# Generated at 2022-06-12 09:04:59.978624
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_ExceptionMixin:
        bp_exception = ExceptionMixin()
        
    T = test_ExceptionMixin()
    # test exception,assert exception is not None
    T.bp_exception.exception('a')

    # test exception is None,assert ExceptionNone is None
    try:
        T.bp_exception.exception()
    except Exception:
        assert Exception is None

# Generated at 2022-06-12 09:05:08.550828
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient
    from sanic.blueprints import Blueprint

    # Set up the blueprint object
    bp = Blueprint("test_bp")
    client = SanicTestClient(bp)

    @bp.exception([Exception])
    async def handler(request, exception):
        return HTTPResponse(body="It works!")

    # Test that the decorator works
    assert len(bp._future_exceptions) == 1

    # Test that the handler works
    request_uri = "/"
    request, response = client.get(request_uri)
    assert response.status == 200
    assert response.body == b"It works!"
    assert type(response) == HTTPResponse

# Generated at 2022-06-12 09:05:09.076379
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:05:15.412216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import json
    from sanic.models import FutureException
    from .models import async_return_arg

    app = Sanic('test_ExceptionMixin_exception')

    @app.route('/error')
    async def handler_error(request):
        raise Exception('Test!')

    @app.exception(Exception, apply=True)
    def handler_exception(request, exception):
        return json({'error': exception})

    request, response = app.test_client.get('/error')
    assert response.json == {'error': 'Test!'}

    assert isinstance(app.exceptions[0], FutureException)
    assert app.exceptions[0].handler == handler_exception

# Generated at 2022-06-12 09:05:21.628686
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    mixin = TestExceptionMixin()

    @mixin.exception(IndexError)
    def foo(request, exception):
        return 'foo'

    @mixin.exception(IndexError, KeyError)
    def bar(request, exception):
        return 'bar'

    assert len(mixin._future_exceptions) == 2
    assert isinstance(foo, SanicExceptionHandler)
    assert isinstance(bar, SanicExceptionHandler)

# Generated at 2022-06-12 09:05:24.856117
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    context = ExceptionMixin()
    future_exception = FutureException('handler', 'exceptions')
    context._future_exceptions.add(future_exception)
    assert context._future_exceptions == {future_exception}

# Generated at 2022-06-12 09:05:31.029961
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-12 09:05:39.473045
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    app = sanic.Sanic('test_ExceptionMixin_exception')
    bp1 = sanic.Blueprint('test_bp')

    class ExceptionHandler:
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self):
            return 1

    @bp1.exception(Exception, apply=False)
    def handle_exception(request, exception):
        return 1

    @bp1.route('/')
    def handler(request):
        raise Exception('test_bp')

    app.blueprint(bp1)
    request, response = app.test_client.get('/')
    assert response.status == 1

# Generated at 2022-06-12 09:05:47.903620
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    _bp = Blueprint('test', url_prefix='test')

    @_bp.exception(ValueError)
    def handle_value_error(request: Request, exception):
        """
        An exception handler returns a HTTPResponse object
        """
        return HTTPResponse(text="Oops! An exception occurred. {}".format(exception),
                            status=500)

    @_bp.route('/')
    def index(request):
        """
        A view function raises a ValueError exception
        """
        raise ValueError('value error!')

    assert hasattr(_bp, 'handle_value_error')

    _bp.add_route(index, 'index', '/')


# Generated at 2022-06-12 09:05:50.859528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class RouteUsageExample(ExceptionMixin):
        def __init__(self):
            self.app
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return ""



# Generated at 2022-06-12 09:07:07.242846
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureException

    bp = Blueprint('test_bp', url_prefix='test')
    future_exception = FutureException(handler=str, exceptions=(SanicException,))
    assert bp._future_exceptions == set()
    assert bp.exception not in bp.__dict__
    assert bp.exception(SanicException) not in bp.__dict__
    assert bp._future_exceptions == set([future_exception])

    bp.exception(SanicException, apply=False)
    assert bp._future_exceptions == set([future_exception])
    assert bp.exception not in bp.__dict__
    assert bp.exception

# Generated at 2022-06-12 09:07:08.988720
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:07:16.972969
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, exceptions: Set[FutureException] = set()):
            self.exceptions = exceptions

        def _apply_exception_handler(self, handler: FutureException):
            self.exceptions.add(handler)

    my_exception_mixin = MyExceptionMixin()
    @my_exception_mixin.exception(ValueError)
    def my_handler():
        return 5

    assert(my_exception_mixin.exceptions == {
        FutureException(my_handler, (ValueError, ))})
    assert(my_exception_mixin._future_exceptions == {
        FutureException(my_handler, (ValueError, ))})

# Generated at 2022-06-12 09:07:21.983598
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    import pytest

    my_bp = Blueprint("my_bp")

    @my_bp.exception(Exception)
    def handler_exception(request, exception):
        assert isinstance(exception, SanicException)

    with pytest.raises(SanicException):
        raise SanicException("SanicException")

# Generated at 2022-06-12 09:07:29.061372
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import json
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    bp = Blueprint('test_bp')

    @bp.exception(ZeroDivisionError)
    def exception_handler(request, exception):
        return json({"exception": str(exception)})

    @bp.route('/')
    def handler(request):
        1 / 0

    app.blueprint(bp)

    request, response = app.test_client.get('/')

    assert response.json == {"exception": "division by zero"}
    assert response.status == 500

# Generated at 2022-06-12 09:07:32.245550
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exc_mixin = ExceptionMixin()

    def handler(request, exception):
        pass

    exc_mixin.exception(ValueError)(handler)

    fex = FutureException(handler, (ValueError,))
    assert fex in exc_mixin._future_exceptions
    assert exc_mixin._future_exceptions.pop() == fex

# Generated at 2022-06-12 09:07:32.653744
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 09:07:40.669995
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.exception(Exception)(self.exception_handler)

        def exception_handler(self, request, exception):
            print(exception)

    testExceptionMixin = TestExceptionMixin()
    print(type(testExceptionMixin._future_exceptions))
    print(type(testExceptionMixin._future_exceptions.__next__().exceptions))
    print(testExceptionMixin._future_exceptions.__next__().exceptions)
    print(type(testExceptionMixin._future_exceptions.__next__().handler))
    print(testExceptionMixin._future_exceptions.__next__().handler)

if __name__ == "__main__":
    test_ExceptionMixin_ex

# Generated at 2022-06-12 09:07:50.338172
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Holder:
        def __init__(self):
            self.x = None
    h = Holder()

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            h.x = handler

    t = TestExceptionMixin()
    f1 = t.exception(Exception)(f2)
    assert f1 is f2
    assert h.x.handler is f1
    assert h.x.exceptions == (Exception,)
    assert h.x in t._future_exceptions

    f3 = t.exception(Exception, Exception)(f4)
    assert f3 is f4
    assert h.x.handler is f3
    assert h.x.exceptions == (Exception, Exception)
    assert h.x in t._future_exceptions


# Generated at 2022-06-12 09:07:57.798883
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    class B(Blueprint, ExceptionMixin):
        pass

    bp = B('test_ExceptionMixin', url_prefix='/test')

    async def handler(request, *args, **kwargs):
        return 'handled exception'

    bp.exception(apply=False)(handler)

    assert bp._future_exceptions == {
        FutureException(handler, ())
    }

    app = Sanic('test_ExceptionMixin')
    bp.register(app)

    assert app.error_handler.exception_handlers == {}

    bp.exception()(handler)

    assert app.error_handler.exception_handlers == {
        tuple(): handler
    }