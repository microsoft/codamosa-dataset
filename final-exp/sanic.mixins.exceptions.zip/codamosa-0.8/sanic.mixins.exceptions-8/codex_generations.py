

# Generated at 2022-06-12 08:59:12.015767
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blue_print = Blueprint("test_blueprint", url_prefix='/test')
    @blue_print.exception(ValueError)
    def test_global_exception_handler(request, exception):
        return text("No error found!")

    assert blue_print._future_exceptions

# Generated at 2022-06-12 08:59:20.743275
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_ExceptionMixin_exception')

    # exception接收的第一个参数如果是列表的话，应该是可以被展开的
    # test_ExceptionMixin_exception_v1
    @bp.exception([IOError, ImportError])
    def handler_error(request: Request, exception: Exception):
        return HTTPResponse('OK', status=200)

    app.blueprint(bp)

    # test_Exception

# Generated at 2022-06-12 08:59:30.306919
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(TestExceptionMixin, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
          assert isinstance(handler, FutureException)

    test_exceptionmixin = TestExceptionMixin()

    @test_exceptionmixin.exception([Exception])
    def exception_handler(request, exception):
        """
        :param request: current request object
        :param exception: exception object
        """
        return None
    assert isinstance(exception_handler, types.FunctionType)


# Generated at 2022-06-12 08:59:38.088401
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler
    
    exception_mixin_test = ExceptionMixinTest()

    def func(): pass
    exception_mixin_test.exception(Exception)(func)

    assert type(exception_mixin_test._future_exceptions) is set
    assert len(exception_mixin_test._future_exceptions) is 1
    assert type(exception_mixin_test.handler) is FutureException

# Generated at 2022-06-12 08:59:39.842691
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint  = Blueprint("test_bp")
    blueprint.exception(Exception)

# Generated at 2022-06-12 08:59:52.069385
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    sanic.app.app.init(__name__, None)

    class ExceptionMixinTester(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    exception_mixin_tester = ExceptionMixinTester()
    exception_mixin_tester.exception(IndexError)("@exception")
    exception_mixin_tester.exception(ZeroDivisionError)("@exception")
    exception_mixin_tester.exception(IndexError, ZeroDivisionError)("@exception")

# Generated at 2022-06-12 08:59:54.547709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    E = ExceptionMixin()

    @E.exception(Exception)
    def handler(request, exception):
        pass

    assert len(E._future_exceptions) == 1

# Generated at 2022-06-12 09:00:05.416319
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    
    class TestClass(ExceptionMixin):
        pass
    
    obj = TestClass()

    # Test exception method
    @obj.exception(apply=True)
    def test1(request, exception):
        print("exception")
    
    # AssertionError: The decorated function is not a Callable.
    @obj.exception(apply=False)
    def test2():
        print("exception")

    with pytest.raises(AssertionError) as e:
        test2()
    assert str(e.value) == 'The decorated function is not a Callable.'

    # IndexError: tuple index out of range
    # List of Python exceptions to be caught by the handler
    @obj.exception([])
    def test3(request, exception):
        print("exception")

# Generated at 2022-06-12 09:00:06.091987
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin().exception

# Generated at 2022-06-12 09:00:11.469037
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.handlers import ErrorHandler

    class bp(ExceptionMixin):
        @staticmethod
        def _apply_exception_handler(handler):
            pass

    class request:
        pass

    # Pass an integer as the first parameter
    with pytest.raises(Exception):
        @bp.exception(1, 2)
        def handler(request):
            pass

    # Pass an empty list of exception
    with pytest.raises(Exception):
        @bp.exception([])
        def handler(request):
            pass

    # Pass a list with only one exception.
    @bp.exception([Exception])
    def handler(request):
        pass

    # Pass a list with the exception Exception
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-12 09:00:23.134937
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage

    class ExampleExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(ExceptionMixin, self).__init__(*args, **kwargs)
            self.exception_handler = None

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler = handler

    class OtherException(Exception):
        pass

    exception_mixin = ExampleExceptionMixin()

    @exception_mixin.exception(InvalidUsage, OtherException)
    def test_handler(*args, **kwargs):
        return True, args, kwargs

    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin.exception_handler is not None

# Generated at 2022-06-12 09:00:28.358829
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class blueprint(ExceptionMixin):
        pass

    blueprint_inst = blueprint()
    blueprint_inst.exception(IndexError)(lambda x: x)
    future_ex = blueprint_inst._future_exceptions.pop()

    assert(future_ex.exceptions[0] == IndexError)

# Generated at 2022-06-12 09:00:35.739112
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    tc = TestClass()
    cnt = 0

    @tc.exception(Exception)
    def exception_handler(request, exception):
        nonlocal cnt
        cnt += 1

    with pytest.raises(Exception):
        exception_handler("something is wrong")

    assert cnt == 1

# Generated at 2022-06-12 09:00:46.099059
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # mock
    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    # case 1: apply = True
    mex = MockExceptionMixin()
    @mex.exception(Exception)
    def mocked_handler():
        pass
    assert isinstance(mex._future_exceptions, set)
    fe = next(iter(mex._future_exceptions))
    assert isinstance(fe, FutureException)
    assert fe.handler == mocked_handler
    assert fe.exceptions == (Exception,)
    # case 2: apply = False
    mex = MockExceptionMixin()
    @mex.exception(Exception, apply=False)
    def mocked_handler():
        pass

# Generated at 2022-06-12 09:00:47.866294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # excm=ExceptionMixin()
    # excm.exception("hello")
    assert True

# Generated at 2022-06-12 09:00:53.432923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint_instance = Blueprint.blueprint_instance
    blueprint_instance._future_exceptions = set()

    @blueprint_instance.exception(apply=False)
    def global_exception_handler(request, exception):
        pass

    assert len(blueprint_instance._future_exceptions) == 1

# Generated at 2022-06-12 09:00:58.429464
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class FakeBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    app_bp = FakeBlueprint()

    @app_bp.exception(Exception)
    async def test_handler(request, exception):
        raise exception

    assert len(app_bp._future_exceptions) == 1
    exc_handler = app_bp._future_exceptions.pop()
    assert exc_handler.exceptions == (Exception,)
    assert exc_handler.handler == test_handler
    assert exc_handler.kwargs == {}

# Generated at 2022-06-12 09:00:59.396265
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # the method under test
    pass

# Generated at 2022-06-12 09:00:59.988718
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:01:05.431705
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Call method exception of class ExceptionMixin to get decorated method
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    bp = Blueprint(__name__)
    assert issubclass(bp.__class__, ExceptionMixin)
    decorated_function = bp.exception(NotFound)(lambda request: None)
    assert decorated_function is not None

# Generated at 2022-06-12 09:01:10.972153
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException
    from sanic.blueprints import Blueprint
    bp = Blueprint("testbp")
    bp.exception([SanicException])(lambda exc: "test")
    bp._apply_exception_handler(None)

# Generated at 2022-06-12 09:01:16.808414
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic import response

    test_app = Sanic('test_app')

    # Define Blueprint Object
    class BlueprintExceptionMixinTest(ExceptionMixin):
        pass

    @BlueprintExceptionMixinTest.exception(Exception)
    def exception_handler(request, exception):
        return response.text(str(exception))

  

# Generated at 2022-06-12 09:01:17.379665
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:01:26.941027
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.views import HTTPMethodView

    class TestExceptionMixin(ExceptionMixin, HTTPMethodView):
        def __init__(self):
            super().__init__()
            self.route = self.route(self)

        @staticmethod
        def route(cls):
            return '/exception'

        @ExceptionMixin.exception(Exception)
        def handler(self, request, exception):
            return None

    exception_mixin = TestExceptionMixin()

    future_exception = None
    for item in exception_mixin._future_exceptions:
        if isinstance(item, FutureException):
            future_exception = item
            break

    assert isinstance(future_exception, FutureException)
    assert future_ex

# Generated at 2022-06-12 09:01:33.991147
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_exception_mixin = TestExceptionMixin()
    # Test method exception with no exception
    @test_exception_mixin.exception()
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    test_future_exception = test_exception_mixin._future_exceptions.pop()
    assert test_future_exception.handler == test_handler
    assert len(test_future_exception.exceptions)

# Generated at 2022-06-12 09:01:41.595678
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class TestException(Exception):
        pass

    def dummy_exception_handler(request: Request, exception: TestException, *args, **kwargs):
        return HTTPResponse("exception handler", status=200)

    bp = Blueprint("test", url_prefix=None)
    bp.exception(TestException)(dummy_exception_handler)

    assert bp._future_exceptions == set({FutureException(handler=dummy_exception_handler, exceptions=(TestException,))})

# Generated at 2022-06-12 09:01:48.653841
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import SanicException
    from sanic.models.sanic_blueprint import Blueprint
    from sanic.response import html

    blueprint = Blueprint('test_ExceptionMixin_exception')
    blueprint.exception([SanicException], apply=False)(lambda x, y: html('OK'))
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions

# Generated at 2022-06-12 09:01:56.843709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    class FakeExceptionMixin(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = set()
            self._exception_handler = None
            pass


    exception_mixin = FakeExceptionMixin()
    exception_list = [Exception('FakeException')]

    # When
    @exception_mixin.exception(*exception_list, apply=False)
    def fake_handler(request, exception):
        return 'Fake handler'

    # Then
    assert fake_handler != None
    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._future_exceptions.pop().handler == fake_handler
    assert exception_mixin._future_exceptions.pop().exceptions == exception_list

# Generated at 2022-06-12 09:02:01.404518
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @sanic.blueprint('test_ExceptionMixin')
    class ExceptionMixinClass(ExceptionMixin):
        pass

    @ExceptionMixinClass.exception(Exception)
    def handle_exceptions(*args, **kwargs):
        pass

    assert handle_exceptions() is None
    assert len(ExceptionMixinClass._future_exceptions) == 1


# Generated at 2022-06-12 09:02:06.263519
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.counter = 0
        
        def _apply_exception_handler(self, handler: FutureException):
            self.counter += 1

    mock = MockExceptionMixin()
    @mock.exception(Exception, apply=False)
    def handler():
        return

    assert(len(mock._future_exceptions) == 0)
    # call exception again
    @mock.exception(Exception)
    def handler1():
        return
    assert(len(mock._future_exceptions) == 1)
    assert(mock.counter == 1)
    # call with list of exceptions
    @mock.exception([Exception, Exception])
    def handler2():
        return

# Generated at 2022-06-12 09:02:18.769340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        url_prefix = ""
        name = ""

        def _apply_exception_handler(self, handler: FutureException):
            return None

    class Request:
        def __init__(self):
            self.app = None

    class Application:
        def __init__(self):
            self.request_class = Request

    bp = Blueprint()
    bp.name = "exception"

    @bp.exception(Exception)
    def foo(request, exception):
        return exception


    app = Application()
    request = app.request_class()
    request.app = app

    res = foo(request, Exception("foo"))
    assert res is not None

# Generated at 2022-06-12 09:02:23.300174
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    @exception_mixin.exception(Exception)
    def exp_hand():
        pass

    @exception_mixin.exception(ZeroDivisionError)
    def exp_hand_2():
        pass

    @exception_mixin.exception(ValuError, NameError)
    def exp_hand_3():
        pass

# Generated at 2022-06-12 09:02:29.692816
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """Unit test for method exception of class ExceptionMixin"""
    class FutureExceptionMock:
        def __init__(self, handler, exceptions):
            self._handler = handler
            self._exceptions = exceptions

        def match(self, exception):
            return exception in self._exceptions

    class ExceptionMixinMock:
        def __init__(self):
            self._future_exceptions = []

        def _apply_exception_handler(self, handler):
            self._future_exceptions.append(handler)

    # Expected exception is raised
    exception_mixin = ExceptionMixinMock()
    exception_mixin.exception([ValueError, NameError])(lambda: None)
    assert isinstance(exception_mixin._future_exceptions[0], FutureExceptionMock)
    assert exception_mixin._future_

# Generated at 2022-06-12 09:02:35.972702
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args):
            super(TestExceptionMixin, self).__init__()
            self.is_called = False

        def _apply_exception_handler(self, handler):
            self.is_called = True

    test_ExceptionMixin = TestExceptionMixin()

    @test_ExceptionMixin.exception(apply=False)
    def handler():
        pass

    assert not test_ExceptionMixin.is_called
    assert test_ExceptionMixin._future_exceptions

# Generated at 2022-06-12 09:02:44.811066
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint("test_bp")
    bp2 = Blueprint("test_bp2")

    @bp.exception(NotFound)
    def test1(request, exception):
        pass

    @bp2.exception([NotFound])
    def test2(request, exception):
        pass

    assert test1 == test2
    assert test1 in bp._future_exceptions
    assert test1 in bp2._future_exceptions
    assert test2 in bp._future_exceptions
    assert test2 in bp2._future_exceptions



# Generated at 2022-06-12 09:02:49.135221
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test_class = type("TestClass", (ExceptionMixin, ), {
        "_apply_exception_handler": lambda x: lambda y: print("hello world")
    })
    test_object = test_class()
    assert test_object.exception(ValueError)

# Generated at 2022-06-12 09:02:53.701422
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Object(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException) -> None:
            return

    obj = Object()
    @obj.exception(IndexError, KeyError)
    def handler(request, exception):
        assert isinstance(exception, (IndexError, KeyError))
        return "It's an IndexError or KeyError!"
    assert handler() == "It's an IndexError or KeyError!"

# Generated at 2022-06-12 09:03:00.094311
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_restplus import Api
    from sanic import Sanic
    app = Sanic()

    api = Api(app, decorators=[ExceptionMixin])

    @api.exception(Exception)
    def handle_exception(request, exception):
        """
        Add a test for handle_exception.
        """
        return "It works."

    @api.route('/test_exception')
    def test_exception(request):
        raise Exception
    return app


# Generated at 2022-06-12 09:03:00.726191
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Add more unit tests
    pass

# Generated at 2022-06-12 09:03:06.423475
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeApp:
        def exception(self, *exceptions, **kwargs):
            pass
    from types import FunctionType
    fakeapp = FakeApp()
    exceptionmixin = ExceptionMixin()
    exceptionmixin._app = fakeapp
    assert exceptionmixin.exception is ExceptionMixin.exception
    exception_handler = exceptionmixin.exception(AssertionError)
    assert callable(exception_handler)
    assert isinstance(exception_handler, FunctionType)

# Generated at 2022-06-12 09:03:19.407187
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint("test_bp", __name__, url_prefix="/")

    @bp.exception(Exception)
    def testing_exception(request, exception):
        pass
    # testing_exception is an internal attribute of ExceptionMixin
    # It's a set contains every FutureException decorated with @bp.exception(Exception)
    assert bp.testing_exception.pop() == FutureException(testing_exception, (Exception,))

# Generated at 2022-06-12 09:03:22.748651
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Class(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None: pass
        def _apply_exception_handler(self, handler: FutureException): pass

    @Class().exception(Exception)
    def func(): pass

    assert isinstance(func, types.FunctionType)

# Generated at 2022-06-12 09:03:29.743716
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    import unittest.mock

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler

    test_instance = TestExceptionMixin()

    with unittest.mock.patch.object(test_instance, '_apply_exception_handler') as mocker:
        assert test_instance.exception(ZeroDivisionError, apply=False)
        mocker.assert_not_called()
        assert len(test_instance._future_exceptions) == 1

        assert test_instance.exception(ZeroDivisionError)
        assert mocker.call_count == 1
        assert len(test_instance._future_exceptions) == 2

# Generated at 2022-06-12 09:03:35.322741
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BluePrint(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def handler(self):
            pass

    blueprint = BluePrint()
    blueprint.exception(ValueError, KeyError,apply=True)(blueprint.handler)

    assert blueprint._future_exceptions[0].exceptions == {ValueError, KeyError}

# Generated at 2022-06-12 09:03:39.019970
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    test_mixin = TestExceptionMixin()
    @test_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_mixin._future_exceptions) == 1
    assert test_mixin._future_exceptions.pop() == FutureException(test_handler, (Exception,))

# Generated at 2022-06-12 09:03:46.577278
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler
    # setup for test
    test_exception_bp = blueprint()

    @test_exception_bp.exception(Exception)
    def test_bp_exception_handler(request: Request, exception: Exception):
        pass

    # verify test result
    assert(isinstance(test_exception_bp.handler, FutureException))
    assert(test_exception_bp.handler.handler == test_bp_exception_handler)
    assert(test_exception_bp.handler.exceptions == [Exception])

# Generated at 2022-06-12 09:03:52.014368
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    
    def test_function():
        pass

    blueprint = Blueprint("test_blueprint", url_prefix="test/prefix")
    decorator = blueprint.exception(ZeroDivisionError, NameError)(test_function)
    assert decorator == test_function
    assert len(blueprint._future_exceptions) == 1
    future_exception = list(blueprint._future_exceptions)[0]
    assert future_exception.handler == test_function

# Generated at 2022-06-12 09:03:52.530356
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:03:58.913339
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Foo(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    foo = Foo()
    assert foo._future_exceptions == set()

    @foo.exception(ValueError)
    def handle_my_exception(request, exception):
        return response.text('exception handled')

    assert len(foo._future_exceptions) > 0
    assert foo._future_exceptions == set([FutureException(handle_my_exception, (ValueError,))])


# Generated at 2022-06-12 09:04:07.089548
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class RuleMixin:
        def apply_rule(self, rule, *, methods, uri, host=None, subdomain=None,
                       strict_slashes=None, stream=None, provide_automatic_options=None,
                       status_code=None, headers=None):
            raise NotImplementedError  # noqa

    class Blueprint(ExceptionMixin,RuleMixin):
        def _apply_exception_handler(self, handler):
            print(handler)
        def rule(self, uri, methods=None, host=None, subdomain=None,
                 strict_slashes=None, stream=None, provide_automatic_options=None,
                 status_code=None, headers=None):
            raise NotImplementedError  # noqa


# Generated at 2022-06-12 09:04:25.258985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    future_exception = FutureException(Exception, Exception)
    future_exception_instance = ExceptionMixin()

# Generated at 2022-06-12 09:04:26.071904
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert 'a' == 'a'

# Generated at 2022-06-12 09:04:34.226576
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create blueprint
    blueprint = Blueprint("test_blueprint")
    # create a test exception
    exception = ValueError("test exception")
    # create a test method for raise exception
    def test_method(request):
        raise exception
    # use decorator of method exception
    @blueprint.exception(ValueError)
    # define a test handler for the exception
    def test_handler(request, exception):
        assert exception == exception
        assert request == request
    
    # test if exception is caught
    blueprint.add_route(test_method, '/test')
    blueprint.route('/test')[0].handler(request=None)

# Generated at 2022-06-12 09:04:34.993571
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False


# Generated at 2022-06-12 09:04:39.490846
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def a(self, handler):
            return handler
        def _apply_exception_handler(self, handler):
            self.a(handler)

    def handler(request, exception):
        return "handle " + str(exception)

    @Test().exception(Exception, apply=True)
    def handler(request, exception):
        return "handle " + str(exception)

    assert Test()._future_exceptions

# Generated at 2022-06-12 09:04:41.908417
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic.blueprints
    blueprint = sanic.blueprints.Blueprint(__name__)
    blueprint.exception(Exception)(None)

if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:04:47.121629
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test for NotImplementedError
    with pytest.raises(NotImplementedError):
        obj = ExceptionMixin()
        obj.exception(NotImplementedError)
    # Test for TypeError
    with pytest.raises(TypeError):
        obj = ExceptionMixin()
        obj.exception(NotImplementedError)()
    # assert
    with pytest.raises(TypeError):
        obj = ExceptionMixin()
        obj.exception(NotImplementedError)
    # assert
    assert isinstance(obj, ExceptionMixin)

# Generated at 2022-06-12 09:04:51.905724
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @cls_exception.exception(Exception)
    def handler(request, exception):
        pass
    assert len(cls_exception._future_exceptions) == 1
    exception = iter(cls_exception._future_exceptions).__next__()
    assert exception.handler == handler
    assert len(exception.exceptions) == 1
    assert Exception in exception.exceptions


# Generated at 2022-06-12 09:04:58.577988
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint("test_bp", url_prefix="test")
    @blueprint.exception(NotFound, apply=True)
    def not_found_handler(request, exception):
        return text("Not found", 404)

    assert len(blueprint._future_exceptions) == 1
    future_exception = list(blueprint._future_exceptions)[0]
    assert future_exception.exceptions == (NotFound,)
    assert future_exception.handler(None, None) == text("Not found", 404)

# Generated at 2022-06-12 09:04:59.101518
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:05:32.135321
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    assert TestExceptionMixin().exception(ValueError, apply = True)

# Generated at 2022-06-12 09:05:38.302424
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  from unittest import mock

  exception_mixin = ExceptionMixin()

  # Unit test for method exception: object is None
  assert exception_mixin.exception(None) == None
  # Unit test for method exception: object is not None
  exception_mixin._apply_exception_handler = mock.Mock()
  exception_mixin.exception(None)
  exception_mixin._apply_exception_handler.assert_called_once()

# Generated at 2022-06-12 09:05:43.507711
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestingExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    app = TestingExceptionMixin()
    assert isinstance(app, TestingExceptionMixin)
    assert isinstance(app, ExceptionMixin)
    assert app._future_exceptions == set()

    @app.exception(IndexError)
    def handler():
        print("hello")

    assert len(app._future_exceptions) == 1
    assert callable(handler)
    assert handler.__name__ == "handler"
    assert handler.__doc__ == "handler(IndexError)"
    for _handler in app._future_exceptions:
        assert callable(_handler.handler)
        assert _handler.handler.__name__ == "handler"

# Generated at 2022-06-12 09:05:51.620756
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.response import json as sanic_json

    class ExceptionMixin_test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            print('test_ExceptionMixin_exception')

    app = Sanic('test_ExceptionMixin_exception')
    app.config.KEEP_ALIVE = False

    mixin_test = ExceptionMixin_test()

    @app.route('/')
    @mixin_test.exception()
    def test_mixin_exception(request):
        return sanic_json({'OK': True})

    request, response = app.test_client.get('/')
    assert response.status == 200



# Generated at 2022-06-12 09:05:58.374377
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic import exceptions
    from sanic.types import RegexType
    class TestException(exceptions.SanicException):
        pass
    app = Sanic(__name__)
    app.config.ERROR_HANDLER_MAX_FLAGS = 1
    bp = Blueprint('test', url_prefix='test')
    other_bp = Blueprint('other_test', url_prefix='test')
    def handler(request, exception):
        return text(exception.message)
    @bp.exception(Exception, apply=True)
    def handle_exception(request, exception):
        return text(exception.message)

# Generated at 2022-06-12 09:06:03.105430
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A:
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
        def _apply_exception_handler(self, handler):
            raise NotImplementedError
    a = A()
    @a.exception(ZeroDivisionError, apply=True)
    def test():
        return True
    assert(test() == True)
    assert(type(a._future_exceptions.pop()) == FutureException)

# Generated at 2022-06-12 09:06:06.229096
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic import Blueprint

    blueprint = Blueprint("test_bp")
    blueprint.exception(ValueError)
    blueprint.exception('ValueError')
    blueprint.exception([ZeroDivisionError, ValueError])
    blueprint.exception(apply=False)



# Generated at 2022-06-12 09:06:07.109781
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin.exception.__name__ == 'exception'

# Generated at 2022-06-12 09:06:07.576899
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:06:11.747839
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptionMixin = ExceptionMixin()

    def handler(request, exception):
        print('got exception')


    handler_wrapper = exceptionMixin.exception(ValueError)(handler)

    assert handler_wrapper == handler
    assert ValueError in exceptionMixin._future_exceptions
    assert len(exceptionMixin._future_exceptions) == 1

# Generated at 2022-06-12 09:07:17.679907
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin.exception(ExceptionMixin, [Exception], apply=True)


# Generated at 2022-06-12 09:07:26.847237
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = FutureException(lambda x:x, Exception)
    b = FutureException(lambda x:x, Exception)
    c = FutureException(lambda x:x, TypeError)
    d = FutureException(lambda x:x, IndexError)
    e = FutureException(lambda x:x, OSError)

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)

    test = TestExceptionMixin()
    @test.exception(Exception)
    def test_exception_handler():
        return 1


# Generated at 2022-06-12 09:07:33.870125
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.blueprints import Blueprint
    from excute import excute_exception
    from sanic.exceptions import ServerError
    from sanic.response import text

    class TestClass(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.bp = Blueprint('test_exception_mixin', url_prefix='ex')
            self._apply_exception_handler = excute_exception

    # test for decorator
    @TestClass().exception(ServerError)
    def test_exception_handler(request, exception):
        return text('Exception handler was called!')

    test_class = TestClass()
    test_class.bp.exception(ServerError)

    # test for wrap

# Generated at 2022-06-12 09:07:39.708679
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    def example_handler(request, *args, **kwargs):
        print("this is example exception handler")

    app = Sanic()

    bp = Blueprint("test", url_prefix=r"test")
    bp.exception(Exception)(example_handler)

    @bp.route("/test", methods=['GET', 'POST'])
    async def test(request):
        raise Exception
        return text("Hello")

    app.blueprint(bp)

# Generated at 2022-06-12 09:07:46.629128
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    exception = ExceptionMixin()
    bp = Blueprint(__name__)

    @bp.exception(ValueError)
    def return_value_error(request, exception):
        return 'ValueError'

    @bp.exception(KeyError)
    def return_value_error(request, exception):
        return 'KeyError'

    exception_handler_collection = bp.exception_handler_collection

    exception_handler_collection.exception_dict[ValueError]
    exception_handler_collection.exception_dict[KeyError]

# Generated at 2022-06-12 09:07:54.872835
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    class BluePrint(ExceptionMixin):
        pass
    blueprint_1 = BluePrint()
    blueprint_2 = BluePrint()
    exception_1 = Exception
    exception_2 = ZeroDivisionError
    exception_3 = KeyError

    # act
    decorated_1 = blueprint_1.exception(exception_1)(None)
    decorated_2 = blueprint_1.exception(exception_1,exception_2)(None)
    decorated_3 = blueprint_2.exception([exception_1,exception_2,exception_3])(None)

    # assert
    assert next(iter(blueprint_1._future_exceptions)).handler == None
    assert len(blueprint_1._future_exceptions) == 2

# Generated at 2022-06-12 09:08:02.538695
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    class TestFuture(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(TestFuture, self).__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            nonlocal exception_handler
            exception_handler.append(handler)

    exception_handler = []
    app = Sanic(__name__)
    future = TestFuture(app)

    @future.exception(IndexError)
    def handler_IndexError(request, exception):
        return request, exception

    @future.exception([IndexError])
    def handler_IndexError(request, exception):
        return request, exception


# Generated at 2022-06-12 09:08:10.551009
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test function decorator
    def decorator(handler):
        print('In function decorator')
        return handler

    def handler(handler):
        print('In handler')
    
    # Test future exception
    class FutureException:
        def __init__(self, handler, exceptions):
            self.handler = handler
            self.exceptions = exceptions
    
    # Test class ExceptionMixin
    class ExceptionMixin:
        def __init__(self):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler):
            print('In apply exception handler')
    
    # Test apply exception handler
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TestExceptionMixin, self).__init__()

    # Test pass

# Generated at 2022-06-12 09:08:16.675113
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    MixinTest = type("MixinTest", (ExceptionMixin, object), {})
    
    # Test the decorator without arguments
    mixin = MixinTest()
    def test_func():
        pass
    mixin.exception(test_func)

    actual = mixin._future_exceptions
    expected = {FutureException(test_func, tuple({None}))}
    assert actual == expected

    # Test the decorator with arguments
    mixin = MixinTest()
    def test_func2():
        pass
    mixin.exception([ValueError, TypeError], apply=False)(test_func2)

    actual = mixin._future_exceptions
    expected = {FutureException(test_func2, tuple({ValueError, TypeError}))}
    assert actual == expected

    # Test the decorator with arguments of

# Generated at 2022-06-12 09:08:19.411553
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class bp(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa
    @bp.exception(Exception)
    def exception_handler(request, exception):
        return 'Hello'

    bp._apply_exception_handler(exception_handler)