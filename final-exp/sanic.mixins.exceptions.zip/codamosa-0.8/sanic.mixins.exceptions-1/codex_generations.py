

# Generated at 2022-06-12 08:59:13.615262
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.exceptions import abort
    from sanic.response import json
    bp = Blueprint('test')

    @bp.exception(ValueError)
    def handle_request_exception(request, exception):
        abort(404, "Error!")

    @bp.route('/test')
    async def test(request):
        raise ValueError()

    app = bp.create_app()
    request, response = app.test_client.get('/test')
    assert response.status == 404
    assert response.json == {"message": "Error!"}


# Generated at 2022-06-12 08:59:19.610857
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.response import text
    bp1 = Blueprint("test_bp", url_prefix="/test")

    @bp1.exception(ValueError)
    async def v_error(request, exception):
        return text('ValueError caught')

    @bp1.route('/test')
    async def test(request):
        raise ValueError('not valid')

    request, response = bp1.create_url_adapter(None).match('/test/test')
    assert response.body == b'ValueError caught'

# Generated at 2022-06-12 08:59:24.892646
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print("Testing ExceptionMixin exception method")
    bp = BlueprintTest("test")
    assert bp._future_exceptions == set()

    @bp.exception(ValueError, apply=True)
    def exception(request, exception):
        print("exception")
        bp._value += 1

    assert bp._value == 1
    assert len(bp._future_exceptions) == 1


# Generated at 2022-06-12 08:59:28.138133
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception()
    def handle_exception(request, exception):
        return exception

    assert handle_exception.__name__ == "handle_exception"

# Generated at 2022-06-12 08:59:37.796912
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    import asyncio
    from unittest.mock import MagicMock
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.models.futures import FutureException

    class MockExceptionMixin(ExceptionMixin, Blueprint):
        # Mock class ExceptionMixin
        def __init__(self, name):
            ExceptionMixin.__init__(self)
            Blueprint.__init__(self, name, url_prefix='/')
            self._apply_exception_handler = MagicMock()
            self._apply_exception_handler.return_value = None

        def test_uri(self):
            pass


# Generated at 2022-06-12 08:59:41.722761
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        pass
    test_class = TestClass()
    @test_class.exception(ValueError)
    def test_method(request, error):
        return error.args
    with pytest.raises(ValueError) as excinfo:
        test_method({}, ValueError("test exception"))
    assert 'test exception' in str(excinfo.value)

# Generated at 2022-06-12 08:59:52.070235
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException, ServerError
    from sanic.models.futures import FutureException

    class DummyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert isinstance(handler, FutureException)
            assert handler.exceptions == (SanicException,)
            assert handler.handler(None) == "SanicException"

    dummyclass = DummyClass()
    @dummyclass.exception(SanicException)
    def dummy_handler(request):
        return "SanicException"


# Generated at 2022-06-12 09:00:02.222581
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)
    
    test_instance = TestExceptionMixin()
    test_exception_handler_1 = test_instance.exception(Exception)
    assert len(test_instance._future_exceptions) == 0
    
    test_instance._apply_exception_handler(test_exception_handler_1)
    assert len(test_instance._future_exceptions) == 1

# Generated at 2022-06-12 09:00:06.707752
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from functools import wraps
    from sanic import exceptions
    from sanic.exceptions import NotFound, InvalidUsage
    @ExceptionMixin.exception(NotFound)
    def error_handler(request, exception):
        return "404 error"
    assert error_handler(object, NotFound) == "404 error"

#Suite Test

# Generated at 2022-06-12 09:00:14.046951
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testExceptionMixinObject(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions = set()
            self._future_exceptions.add(handler)
    testExceptionMixin = testExceptionMixinObject()
    @testExceptionMixin.exception(IndexError, KeyError)
    def test_exception1():
        return
    @testExceptionMixin.exception([IndexError, KeyError])
    def test_exception2():
        return
    @testExceptionMixin.exception(KeyError, apply = False)
    def test_exception3():
        return

# Generated at 2022-06-12 09:00:22.971816
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def test_handler(self):
            return 'test'

    try:
        test = TestExceptionMixin()
        raises(NotImplementedError, test._apply_exception_handler, NotImplementedError)
        test.exception(NotImplementedError)(test.test_handler)
        raises(ValueError, test.exception, [NotImplementedError, ValueError])

        assert len(test._future_exceptions) == 1
        assert test._future_exceptions.pop().handler.__name__ == 'test_handler'
    finally:
        del TestExceptionMixin
        del test

# Generated at 2022-06-12 09:00:25.740288
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception()
    def exception_handler():
        raise ArithmeticError()

    assert exception_handler() == ArithmeticError()

# Generated at 2022-06-12 09:00:36.992674
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print('\nTest ExceptionMixin.exception()')
    from sanic.models.endpoints import Endpoint
    from sanic.models.sanic_app import SanicApp
    import sanic.exceptions

    class TestExceptionMixin(ExceptionMixin):
        def apply_exception_handler(self, exception: FutureException):
            return super()._apply_exception_handler(exception)

    class TestSanicApp(SanicApp):
        def exception(*args, **kwargs):
            return super().exception(*args, **kwargs)

    # Test exception handler
    def test_handler(*args):
        print('This is a test handler')
        print('Args: ', *args)

    # Create a new Sanic application
    app = TestSanicApp()

    # Expected output

# Generated at 2022-06-12 09:00:38.359009
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    pass
    # Act
    # Assert
    pass



# Generated at 2022-06-12 09:00:43.359606
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTests(ExceptionMixin):
        pass

    xException = ExceptionMixinTests()
    @xException.exception([ValueError], {})
    def test_function(request, exception):
        return "{} - {}".format(request, exception)
    test_function(1, 2)


# Generated at 2022-06-12 09:00:54.041779
# Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-12 09:00:57.584395
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    bp = Blueprint('test') 
    @bp.exception(ZeroDivisionError)
    def handler(request, exception):
        return request
    @bp.exception(ZeroDivisionError)
    def handler1(request, exception):
        return request 
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:01:05.302728
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException


    class CustomException(SanicException):
        pass


    bp = Blueprint("foo")


    @bp.exception([Exception, CustomException])
    def handler(request, exception):
        return request.url

    assert len(bp._future_exceptions) == 1
    future_exception = list(bp._future_exceptions)[0]
    assert future_exception.handler == handler
    assert future_exception.exceptions == (Exception, CustomException)

# Generated at 2022-06-12 09:01:09.929181
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Raise an exception if the exception method is not implemented
    # for the class which extends the ExceptionMixin
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

    m = MockExceptionMixin()
    try:
        m.exception()(None)
    except Exception as e:
        assert str(e) == 'NotImplementedError: No exceptions defined'

# Generated at 2022-06-12 09:01:14.138314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(ValueError)
    def exception(): pass

    assert(len(test_exception_mixin._future_exceptions) == 1)

# Generated at 2022-06-12 09:01:25.489896
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Server(ExceptionMixin):
        def __init__(self):
            super(Server, self).__init__()
            self._exception_handler = None

        def _apply_exception_handler(self, handler):
            self._exception_handler = handler
    server = Server()
    @server.exception(apply=False)
    def error_handler(request, exception):
        pass
    assert server._exception_handler == None
    f = server._future_exceptions.pop()
    server._apply_exception_handler(f)
    assert server._exception_handler == f

# Generated at 2022-06-12 09:01:28.584168
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

    blueprint_test = Blueprint()
    blueprint_test.exception(ZeroDivisionError)
    blueprint_test.exception(ValueError)

# Generated at 2022-06-12 09:01:33.226574
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    parsed_test_mixin = TestExceptionMixin()

    @parsed_test_mixin.exception(Exception)
    def test_function(self, request, exception):
        print("Exception {}".format(exception))

    parsed_test_mixin._apply_exception_handler(
        FutureException(test_function, tuple(Exception)))

    parsed_test_mixin.find_handler('post', '/test_function', 'test_function')

# Generated at 2022-06-12 09:01:42.300106
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class bp(ExceptionMixin):
        pass

    @bp.exception()
    def exception_handler(request, exception):
        return None

    @bp.route('/')
    def index(request):
        return request.json()['a']

    bp.exception(IndexError, apply=False)

    import json
    from sanic.request import Request
    from sanic.exceptions import ServerError

    request = Request('GET', '/', data=json.dumps({'a': 'b'}))
    response = bp.handle_request(request)
    assert response is None

    request = Request('GET', '/', data=json.dumps({'a': 'b'}))
    response = bp.handle_request(request)
    assert response.status == 500
    assert response.body.decode

# Generated at 2022-06-12 09:01:44.381174
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test without optional arguments
    # TODO: implement
    pass

# Generated at 2022-06-12 09:01:49.431768
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint("test", url_prefix="test")
    @blueprint.exception(Exception)
    def handler(request, exception):
        return {"test": True}
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-12 09:01:55.032418
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            return None

    exception_mixin = TestExceptionMixin()
    handler = lambda request: "ok"
    @exception_mixin.exception(Exception)
    def test_routes():
        return handler

    assert test_routes() == handler

# Generated at 2022-06-12 09:01:58.293346
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
	bp = Blueprint.create()
	bp = ExceptionMixin(bp, 'test', url_prefix='/test')
	bp.exception(Exception)(lambda: print('exception'))
	assert len(bp._future_exceptions) == 1


# Generated at 2022-06-12 09:02:01.993229
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestException(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            print(handler)
    test = TestException()
    test.exception('a')
    print(test._future_exceptions)

test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:02:07.477487
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinMock(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)

    exm = ExceptionMixinMock()
    @exm.exception(Exception, foo='bar')
    def test(req, ex, foo):
        return (ex, foo)

    assert len(exm._future_exceptions) == 1
    assert test(None, Exception(), None) == (Exception(), 'bar')

# Generated at 2022-06-12 09:02:18.553536
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

        class E(ExceptionMixin):
            def _apply_exception_handler(self, handler: FutureException):
                pass
        e = E()
        assert e._future_exceptions == set()
        assert e.exception(1,2,3)() is not None

# Generated at 2022-06-12 09:02:26.995085
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import  ServerError
    from sanic.response import json
    from unittest import TestCase
    from unittest.mock import MagicMock
    import json

    blueprint = Blueprint("test_server_exception")
    blueprint.exception(ServerError)(lambda request, exception: json({"code": "error_message"}))
    blueprint.exception(TypeError)(lambda request, exception: json({"code": "error_message2"}))


    class TestExceptionMixin(ExceptionMixin, TestCase):
        def test_apply_exception_handler(self):
            request = MagicMock()
            request.app = MagicMock()
            request.app.add_exception_handler = MagicMock()

# Generated at 2022-06-12 09:02:35.259583
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def hello():
        return "hello"
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin.exception(None)(hello)() == "hello"
    assert test_exception_mixin.exception([None])(hello)() == "hello"
    assert test_exception_mixin.exception(None, apply=False)(hello)() == "hello"
    assert test_exception_mixin.exception([None], apply=False)(hello)() == "hello"

# Generated at 2022-06-12 09:02:37.335985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        pass

    test = Test()
    test.exception(BaseException)

# Generated at 2022-06-12 09:02:45.377311
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint('bp', url_prefix='/test')

    @bp.exception(NotFound)
    def handler(request, exception):
        assert exception.status_code == 404

    @bp.route('/foo')
    def handler(request):
        return {}

    for bp_ in (bp, ExceptionMixin):
        bp.add_route(handler, 'GET', '/foo')
        app = bp_.create_app()
        request, _ = app.asgi_create()
        response = app.asgi_run(request, error_handler=app.error_handler)

        assert response[0] == 404

# Generated at 2022-06-12 09:02:52.700839
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class bp(ExceptionMixin):
        def __init__(self):
            super(bp, self).__init__()
            self._apply_exception_handler = lambda x: None

    b = bp()

    # Test if exceptions are wrapped in a list
    @b.exception(list(range(3)))
    def f(req, e):
        return req, e

    assert type(b._future_exceptions) == set
    assert len(b._future_exceptions) == 1
    assert type(b._future_exceptions.pop()) == FutureException

# Generated at 2022-06-12 09:02:57.498944
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    app = sanic.Sanic()
    class testExceptionMixin(ExceptionMixin):
        pass
    test = testExceptionMixin()
    @test.exception(apply=False)
    def handler(request, exception):
        print(exception)
    test._apply_exception_handler(handler)
    assert isinstance(handler, FutureException)



# Generated at 2022-06-12 09:03:01.252989
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self):
            pass
    bp = Blueprint()
    def exception_handler():
        pass
    bp.exception(1,2,3, apply = False)(exception_handler)
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:03:10.473056
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.abstracts import blue_print
    from sanic.models.futures import FutureException

    def test_exception(request, *args, **kwargs):
        return 'test'

    class test_ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            # noqa
            return handler

    @blue_print(test_ExceptionMixin)
    class test_blueprint(Blueprint):
        pass

    exceptions = [
        IndexError,
        ZeroDivisionError,
    ]

    test_blueprint.exception(*exceptions)(test_exception)
    future_exceptions = test_blueprint._future_exceptions

    assert len(future_exceptions) == 1
    future_exception

# Generated at 2022-06-12 09:03:13.765200
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    my_object = ExceptionMixin()

    def my_handler():
        pass
    assert len(my_object._future_exceptions) == 0
    my_object.exception('InvalidUsage')(my_handler)
    assert len(my_object._future_exceptions) == 1

# Generated at 2022-06-12 09:03:37.349354
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTestCase(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    instance = ExceptionMixinTestCase()
    decorated = instance.exception(Exception)
    assert isinstance(decorated, types.FunctionType)
    assert decorated.__name__ == 'handler'
    assert len(instance._future_exceptions) == 1
    decorated(None)


if __name__ == '__main__':
    pytest.main(args=[__file__])

# Generated at 2022-06-12 09:03:42.962001
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    class MyBlueprint(Blueprint):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def exception_handler(self, request, exception):
            return exception

    bp = MyBlueprint("test", url_prefix="/test")

    @bp.exception(NotFound)
    def not_found(request, exception):
        return exception

    request,  = bp.create_test_request("/")
    assert bp.handle_request(request) == None

    request,  = bp.create_test_request("/test/test")
    assert bp.handle_request(request) == None

    request,  = bp.create_test_request

# Generated at 2022-06-12 09:03:48.161245
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test", url_prefix="test")
    assert isinstance(bp, Blueprint)
    assert isinstance(bp, ExceptionMixin)
    # TODO: 
    # 1. test the case that the exception handler is not decorated by the method
    #    exception.
    # 2. test the case that the exception handler is decorated by the method
    #    exception.

# Generated at 2022-06-12 09:03:50.150203
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(request, exception):
        pass

    blueprint = ExceptionMixin()
    blueprint.exception(HTTPException)(handler)
    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-12 09:03:57.423092
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    obj = ExceptionMixin()
    # Test case 1: apply=False, @exception()
    assert not obj._future_exceptions
    decorator = obj.exception(apply=False)
    @decorator
    def test1():
        pass
    ret = obj._future_exceptions
    assert len(ret) == 1
    handler, exception, args, kwargs = ret.pop()
    assert handler == test1
    assert len(exception) == 0
    assert args == ()
    assert kwargs == {}

    # Test case 2: apply=True, @exception(Exception)
    obj = ExceptionMixin()
    decorator = obj.exception(Exception)
    @decorator
    def test2():
        pass
    ret = obj._future_exceptions
    assert len(ret) == 1


# Generated at 2022-06-12 09:04:01.285585
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def handler(request, *args, **kwargs):
        return 'handler'

    args = ['exception']
    apply = True
    exceptions = ()

    assert handler == ExceptionMixin.exception(handler, *args, apply=apply)

# Generated at 2022-06-12 09:04:06.113466
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Test(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
            self._apply_exception_handler = lambda x: None
            super().__init__(*args, **kwargs)

    obj = Test()
    @obj.exception()
    def handler():
        pass
    assert obj._future_exceptions is not None
    assert len(obj._future_exceptions) == 1

# Generated at 2022-06-12 09:04:13.741986
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create a class for testing
    class Blueprint:
        ''' A small class for testing ExceptionMixin class'''
        def __init__(self):
            self.views = []
            self.before_request = {}
            self.after_request = {}
            self.before_websocket = {}
            self.after_websocket = {}
            self.error_handler = {}
            self.error_handlers = []
            self.websocket_handlers = []
            self.websocket_routes = {}
            self.auto_options = []
            self.before_route = {}
            self.after_route = {}
            self.exception(Exception, ValueError)(lambda *a, **k: None)

    blueprint = Blueprint()

    # Unit tests

# Generated at 2022-06-12 09:04:14.263434
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 09:04:18.447682
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException) -> None:
            pass

    app = Sanic()

    @app.exception(ZeroDivisionError)
    def handler_zero_division_error(request, exception):
        pass

    future_exception = FutureException(handler_zero_division_error, (ZeroDivisionError,))
    assert future_exception in app._future_exceptions

# Generated at 2022-06-12 09:04:51.558024
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('test')

    assert isinstance(bp.exception(ValueError)(print), types.FunctionType)


# Generated at 2022-06-12 09:04:53.330207
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = ExceptionMixin()
    blueprint.exception(KeyError)
    assert blueprint._future_exceptions

# Generated at 2022-06-12 09:05:00.928348
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    # create a blueprint
    test_blueprint = Blueprint("my_test_blueprint", "test_blueprint")

    # decorate the method with different exceptions
    @test_blueprint.exception(ZeroDivisionError)
    def zero_div(request, exception):
        return request, exception

    # decorate the method with different exceptions
    @test_blueprint.exception(IndexError, ValueError)
    def zero_div(request, exception):
        return request, exception

    # decorate the method with different exceptions
    @test_blueprint.exception([IndexError, ValueError])
    def zero_div(request, exception):
        return request, exception

    # check the blueprint methods
    assert test_blueprint.exception_handlers[ZeroDivisionError] == zero_

# Generated at 2022-06-12 09:05:09.678146
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinChild(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return handler.handler

    # define functions to be used in method exception
    def handler(*args, **kwargs):
        return "value of function handler"

    # define ExceptionMixinChild object
    exception_mixin_child = ExceptionMixinChild()

    # call method exception
    result = exception_mixin_child.exception(handler, apply=True)

    assert result == "value of function handler"
    assert len(exception_mixin_child._future_exceptions) == 1

    # call method exception

# Generated at 2022-06-12 09:05:19.618057
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    
    class TestExceptions:
        def __init__(self, *args):
            pass
        def handler(self):
            pass

    TestExceptions.__name__ = 'TestExceptions'
    TestExceptionMixin.__name__ = 'TestExceptionMixin'
    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    assert test_exception_mixin.exception(TestExceptions)
    assert test_exception_mixin._future_exceptions == {FutureException(TestExceptions.handler, (TestExceptions,))}
    # TestExceptions found in FutureException

# Generated at 2022-06-12 09:05:26.579686
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest import TestCase
    from sanic.exceptions import InvalidUsage

    class Exception(ExceptionMixin, TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception = Exception()

    @exception.exception(InvalidUsage)
    def handler(request, exception):
        return

    assert(len(exception._future_exceptions) == 1)
    assert(type(handler) == exception._future_exceptions.pop().handler)

# Generated at 2022-06-12 09:05:32.898171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import exceptions
    from sanic.models.views import View
    # from sanic.models.futures import FutureException
    from sanic.app import Sanic
    app = Sanic(name="test_sanic")
    view = View(app)

    def test_handle_func(request, exception):
        return {"test": "handle_func"}

    assert not view._future_exceptions
    view.exception(exceptions.SanicException)(test_handle_func)
    assert view._future_exceptions
    view._apply_exception_handler(view._future_exceptions.pop())
    test_request, _ = app.test_client.get("/")
    assert test_request.json == {'test': 'handle_func'}



# Generated at 2022-06-12 09:05:41.317520
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json

    class TExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(TExceptionMixin, self).__init__()

        async def get(self, request) -> HTTPResponse:
            return json({"msg": "get method"})

        def _apply_exception_handler(self, handler):
            return handler

    app = Sanic("test_ExceptionMixin_exception")
    blueprint_ = Blueprint("test_ExceptionMixin_exception_blueprint_")
    exception_mixin = TExceptionMixin()
    exception_mixin.exception([HTTPException, ValueError])(app.exception)
    blueprint_.add_route(exception_mixin.get, "/")
    app.blueprint(blueprint_)
    request, response = app

# Generated at 2022-06-12 09:05:49.804160
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import text
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException, ServerError
    bp = Blueprint('test_bp')

    @bp.exception(Exception)
    def handler(request, exception):
        return text("default_exception_handler", 500)

    @bp.route("/")
    def index(request):
        raise SanicException("Some Sanic exception")

    @bp.route("/2")
    def index2(request):
        raise ServerError("Some server error")

    @bp.route("/NonExistentHandler")
    def index3(request):
        raise Exception("Some exception")

    app = bp.create_app()
    request, response = app.test_client.get("/")
    assert response.status == 500
   

# Generated at 2022-06-12 09:05:53.886646
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    class bp(ExceptionMixin):
        def __init__(self):
            pass

    b = bp()

    # act
    @b.exception(ValueError)
    def blah(request, value):
        pass

    # assert
    assert b._future_exceptions is not None

# Generated at 2022-06-12 09:07:02.802480
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    em = TestExceptionMixin()
    @em.exception(IndexError)
    def handler(exception):
        return exception
    assert len(em._future_exceptions) == 1

# Generated at 2022-06-12 09:07:10.231762
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    mixin = ExceptionMixin(name="")
    exception_future_1 = ("a", "b")
    exception_future_2 = ("c", "d")

    # Act
    mixin.exception(exception_future_1)
    mixin.exception(exception_future_2)

    # Assert
    assert tuple(mixin._future_exceptions)[0].exceptions == (
        exception_future_1,
    )
    assert tuple(mixin._future_exceptions)[1].exceptions == (
        exception_future_2,
    )

# Generated at 2022-06-12 09:07:17.680349
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.app import Sanic
    app = Sanic(__name__)

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(Exception)
    def handler(request, exception):
        pass
    app.blueprint(blueprint)

    blueprint_exceptions = blueprint._future_exceptions
    assert len(blueprint_exceptions) == 1
    exception: FutureException = next(iter(blueprint_exceptions))

    handler = exception.handler
    assert handler() == None
    
    exceptions: tuple = exception.exceptions
    assert len(exceptions) == 1
    exception = exceptions[0]
    assert exception == Exception

# Generated at 2022-06-12 09:07:26.847464
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    # Test exception with parameters apply = True, exceptions = Exception
    exception_mixin_test = ExceptionMixinTest()
    exception_mixin_test.exception(Exception, apply=True)(lambda: None)
    assert type(exception_mixin_test._future_exceptions.pop()) is sanic.models.futures.FutureException

    # Test exception with parameters apply = False, exceptions = [Exception]
    exception_mixin_test = ExceptionMixinTest()
    exception_mixin_test.exception([Exception], apply=False)(lambda: None)

# Generated at 2022-06-12 09:07:33.669884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_test import Sanic
    from sanic.models.blueprint import Blueprint
    from sanic.models.exception import SanicException
    sanic = Sanic(__name__)
    blueprint = Blueprint("test", url_prefix="test")
    
    @blueprint.exception(SanicException)
    def test(request, exception: SanicException):
        pass

    blueprint.add_exception_handler(sanic)
    blueprint.register(sanic, url_prefix="test")

    found = False
    for exception in sanic.error_handler.exception_handlers:
        if exception[0].__name__ == "test" and \
            exception[1] == SanicException:
            found = True
            break
    assert found

# Generated at 2022-06-12 09:07:36.929271
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(name="test")
    blueprint.exception(Exception)(lambda x: x)

    assert blueprint.get_exception_handlers() is not None
    assert blueprint.get_exception_handlers()[0].handler is not None

# Generated at 2022-06-12 09:07:39.021932
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception()
    def handler_exception(request, exception):
        return 'future_exception'

    assert callable(handler_exception) == True

# Generated at 2022-06-12 09:07:45.235853
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class DummyClass():
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    exc = DummyClass()

    @exc.exception(apply=True)
    def handler():
        pass

    assert handler == exc._future_exceptions[0].handler
    assert exc._future_exceptions[0].exceptions == []

# Generated at 2022-06-12 09:07:50.950640
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import SanicError

    class TestClass(ExceptionMixin):
        pass

    test_class = TestClass()
    assert test_class._future_exceptions == set()
    assert test_class.exception(SanicError)
    assert test_class._future_exceptions == set()
    assert test_class._apply_exception_handler
    assert test_class.exception(ExceptionMixin, apply=False)
    assert test_class._future_exceptions == set()

# Generated at 2022-06-12 09:07:54.767412
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test = TestExceptionMixin()
    assert test.exception(NotImplementedError)