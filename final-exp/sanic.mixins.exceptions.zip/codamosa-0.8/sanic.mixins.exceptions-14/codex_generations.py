

# Generated at 2022-06-12 08:58:58.782146
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO
    # assert True
    pass


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 08:59:03.001553
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('exception_handler', url_prefix='exceptions')

    @blueprint.exception([ValueError])
    def exception_handler(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1

    blueprint._apply_exception_handler(blueprint._future_exceptions.pop())

    assert len(blueprint._future_exceptions) == 0


# Generated at 2022-06-12 08:59:14.181538
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    sanic = Sanic()
    assert len(sanic._future_exceptions) == 0

    # test case 1:
    @sanic.exception(apply=False)
    def exception_handler(request, exception):
        raise NotImplementedError  # noqa

    assert len(sanic._future_exceptions) == 1
    assert sanic._future_exceptions == set([
        FutureException(exception_handler, ())
    ])
    assert isinstance(sanic._future_exceptions, set)

    # test case 2:
    @sanic.exception
    def exception_handler2(request, exception):
        raise NotImplementedError 

# Generated at 2022-06-12 08:59:15.013763
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 08:59:20.706730
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic(__name__)

    def exception(request, exception):
        return json({'exception': 'Exception handler'})

    @app.route('/')
    def test(request):
        return json({'test': 'Test handler'})

    app.exception([KeyError, StopIteration])(exception)

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json == {'test': 'Test handler'}

    try:
        raise KeyError
    except KeyError:
        request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.json == {'exception': 'Exception handler'}


# Generated at 2022-06-12 08:59:21.304907
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False

# Generated at 2022-06-12 08:59:27.602194
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(Exception)
    def exception_handler():
        pass

    assert isinstance(exception_handler, ExceptionMixin)

# Generated at 2022-06-12 08:59:35.177622
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic:
        def _exception(self, FutureException):
            pass
    class A(ExceptionMixin):
        pass

    assert hasattr(A, 'exception')
    sanic = Sanic()
    a = A()
    assert isinstance(a, ExceptionMixin)
    a.exception(TypeError, ZeroDivisionError)(lambda x, y: x/y)
    assert len(a._future_exceptions) == 1
    exceptions = a._future_exceptions.copy()
    assert len(exceptions) == 1
    for exception in exceptions:
        assert isinstance(exception, FutureException)
        assert len(exception.exceptions) == 2


if __name__ == '__main__':
    test_ExceptionMixin_exception()



# Generated at 2022-06-12 08:59:43.085122
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint, Sanic
    from sanic.response import html
    bp = Blueprint('bp', url_prefix='/test')

    @bp.exception(Exception)
    def ex_handler(request, exception):
        return html('<h1>Internal server error</h1>')

    app = Sanic(__name__)
    app.blueprint(bp)
    app.error_handler.add(Exception, ex_handler)

    assert '/test/test1/' in app.router.routes_names


# # Unit test for method exception_handler of class ExceptionMixin
# def test_ExceptionMixin_exception_handler():
#     from  sanic import Blueprint
#     bp = Blueprint('bp', url_prefix='/test')

#     @bp.route('/test1/')

# Generated at 2022-06-12 08:59:49.279677
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.models.exception_handler import apply_exception_handler

    app = Sanic('test_ExceptionMixin_exception')
    apply_exception_handler(app, FutureException(None, None))
    a = ExceptionMixin()
    assert a._future_exceptions == set()
    a.exception(Exception)
    assert a._future_exceptions == {FutureException(None, (Exception,))}

# Generated at 2022-06-12 09:00:01.931633
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.request import Request
    from sanic.models.response import HTTPResponse
    import json

    bp = Blueprint("test_bp")
    @bp.exception(Exception)
    def exception_handler(request: Request, exception: Exception):
        return HTTPResponse(json.dumps({"error": "nous avons trouve une erreur"}), status=500)

    @bp.route("/exception")
    async def test_exception(request: Request):
        raise Exception()

    assert isinstance(bp, ExceptionMixin)
    from sanic.server import HttpProtocol

# Generated at 2022-06-12 09:00:09.468273
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        fixtures = None

        def _apply_exception_handler(self, handler: FutureException):
            MyExceptionMixin.fixtures = set()
            MyExceptionMixin.fixtures.add(handler)

    x = MyExceptionMixin()

    @x.exception(Exception, Exception)
    def error(request, exception):
        return exception

    assert len(x._future_exceptions) == 1
    fe = x._future_exceptions.pop()

    assert fe.exceptions == (Exception, Exception)
    assert fe.handler == error
    assert MyExceptionMixin.fixtures == set([fe])

# Generated at 2022-06-12 09:00:15.412955
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    import sys

    blueprint = Blueprint('TestBlueprint', url_prefix='/test_blueprint')

    # Test decorator without exception
    exception_without_exception = blueprint.exception()
    assert exception_without_exception

    # Test decorator with exception
    exception_with_exception = blueprint.exception(Exception, ValueError)
    assert exception_with_exception

    global_exception_handler = exception_with_exception(lambda: 1)
    assert isinstance(global_exception_handler, type(lambda: 1))


    # Test decorator with system exception
    exception_with_system_exception = blueprint.exception(SystemExit)
    assert exception_with_system_exception

    global_exception_handler = exception_with_system_exception(lambda: 1)


# Generated at 2022-06-12 09:00:24.019803
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # check exception is callable
    e = ExceptionMixin()
    is_callable = callable(e.exception)
    assert is_callable == True # noqa

    # make sure exception callable returns a decorator
    @e.exception()
    def get_exception():
        return 1
    is_decorator = callable(get_exception)
    assert is_decorator == True # noqa

    # make sure a decorator can be returned without error
    @e.exception(Exception)
    def get_exception():
        return 2
    is_decorator = callable(get_exception)
    assert is_decorator == True # noqa

    # make sure exception can be called with list as argument

# Generated at 2022-06-12 09:00:32.094254
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import SanicException

    class TestExceptionMixin(object):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self, *args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    def exception_handler(*args, **kwargs):
        pass

    t = TestExceptionMixin()
    t.exception(SanicException)(exception_handler)
    assert len(t._future_exceptions) == 1

# Generated at 2022-06-12 09:00:38.137493
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            print(handler)

    t = TestExceptionMixin()
    t.exception(ValueError)(lambda a: a)


# Generated at 2022-06-12 09:00:47.387570
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print("test exception ...")
    class TestSanic():
        def __init__(self):
            self.exception_handlers = set()

        def register_exception(self, exception_class, *args, **kwargs):
            self.exception_handlers.add((exception_class, args, kwargs))

    class TestObject(ExceptionMixin):
        def __init__(self):
            super(TestObject, self).__init__()
            self._apply_exception_handler = self.__register_exception

        def __register_exception(self, handler):
            for e in handler.exceptions:
                self.sanic.register_exception(e, handler=handler.handler,
                                              status_code=400)


# Generated at 2022-06-12 09:00:57.141822
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
            return super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    # check if decorator is returned
    # check if future_exception is added to set and applied
    # check if decorator is returned
    # check if future_exception is added to set and not applied
    # check if decorator is returned
    # check if future_exception is added to set and applied
    # check behavior with a list of exceptions
    # check behavior with multiple exceptions
    # check behavior without exceptions and without apply
    # check behavior with exceptions and without apply
    # check

# Generated at 2022-06-12 09:01:05.256968
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from  sanic import Sanic
    from sanic.blueprints import Blueprint
    class MyClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(MyClass, self).__init__(*args, **kwargs)
    
    app = MyClass(Sanic('test'))
    bp = MyClass(Blueprint('test'))

    bp.exception()
    bp.exception(Exception)
    bp.exception(Exception, apply=False)
    bp.exception(Exception, Exception)

# Generated at 2022-06-12 09:01:09.445927
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint_instance = Blueprint(__name__)
    blueprint_instance.exception(ZeroDivisionError)(lambda request, exception: print(exception))
    assert blueprint_instance._future_exceptions != set()
    blueprint_instance._apply_exception_handler = lambda x: x
    blueprint_instance.exception(ZeroDivisionError, apply=False)(
        lambda request, exception: print(exception)
    )

# Generated at 2022-06-12 09:01:22.144103
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from functools import wraps

    bp = Blueprint(name='test')

    assert len(bp._future_exceptions) == 0

    @bp.exception(Exception, 'custom error')
    def handler(error, request, exception='custom error'):
        return request, exception

    decorated_handler = bp._future_exceptions.pop()
    assert isinstance(decorated_handler, FutureException)
    assert decorated_handler.handler == handler
    assert decorated_handler.exceptions == (Exception, 'custom error')



# Generated at 2022-06-12 09:01:30.812247
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import Future
    from sanic.models.futures import FutureException
    from sanic.models.route import Route

    application = Application()
    exception_mixin = ExceptionMixin()

    def test_handler(request, exception):
        pass

    exception_mixin.exception(AttributeError, test_key="test_value")(test_handler)

    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._future_exceptions.pop() == FutureException(test_handler, (AttributeError), test_key="test_value")

    assert len(application._future_exceptions) == 0
    assert len(application._route_futures) == 0


# Generated at 2022-06-12 09:01:34.425508
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test if exception method create one FutureException
    """
    from sanic import Blueprint

    bp = Blueprint("test_exception")
    @bp.exception(Exception)
    def exception_handler(request, exception):
        return text("Exception: %s" % exception)

    assert len(bp._future_exceptions) == 1

    ex = list(bp._future_exceptions)[0]
    assert ex.handler == exception_handler
    assert ex.exceptions == (Exception,)

# Generated at 2022-06-12 09:01:40.682426
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    '''
    def test_instance(self):

    def test_args(self):

    def test_kwargs(self):

    def func(self, addr):
        @self.exception(TimeoutError)
        def handler(*args, **kwargs):
            args = (lambda *args, **kwargs: args)
            kwargs = (lambda *args, **kwargs: kwargs)
            return kwargs
        return self.endpoint(addr)(handler)
    '''
    pass

# Generated at 2022-06-12 09:01:48.412923
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_tester(ExceptionMixin):
        def __init__(self):
            self.test_exception = False

        def _apply_exception_handler(self, handler: FutureException):
            self.test_exception = True

    @ExceptionMixin_tester.exception(ZeroDivisionError, apply=False)
    def handler():
        pass

    assert isinstance(handler(), types.FunctionType)
    assert not ExceptionMixin_tester().test_exception

# Generated at 2022-06-12 09:01:56.944588
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock, patch

    mock_handler = Mock()
    mock_future_exception = Mock()

    with patch("sanic_restplus.ExceptionMixin._apply_exception_handler", new=Mock()) as mock_apply_exception_handler:
        with patch("sanic_restplus.FutureException", new=Mock(return_value=mock_future_exception)) as mock_FutureException:
            exception_mixin = ExceptionMixin()
            exception_mixin.exception("ExceptionType1", "ExceptionType2")(mock_handler)
            assert mock_future_exception.handler == mock_handler
            mock_FutureException.assert_called_once_with(mock_handler, ("ExceptionType1", "ExceptionType2"))
            assert mock_future_exception in exception_mix

# Generated at 2022-06-12 09:02:01.175369
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    # Unit test for method exception of class ExceptionMixin when
    # decorator is not applied
    # GIVEN
    appl = Blueprint(name="appl")
    @appl.exception(Exception)
    def test_exception(request, exception):
        pass
    assert len(appl._future_exceptions) == 1

# Generated at 2022-06-12 09:02:04.054869
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # BluePrint object
    from sanic import Blueprint
    from sanic.models.futures import FutureException
    from .BP_test_paths import test_paths
    bp = Blueprint("test", url_prefix="/test")

    @bp.exception(ValueError)
    def handle_exception(request, exception):
        pass

    test_paths(bp)
    assert len(bp._future_exceptions) == 1
    assert isinstance(next(iter(bp._future_exceptions)), FutureException)

# Generated at 2022-06-12 09:02:09.469907
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.response import json
    from sanic.decorators import response
    from sanic.exceptions import ServerError

    app = sanic.Sanic('test_ExceptionMixin')
    bp = Blueprint('test_ExceptionMixin', url_prefix='test')
    @bp.exception(ServerError)
    @response.json
    async def catch(request, exception):
        return {'status': 500, 'message': 'error'}
    @bp.route('/')
    async def index(request):
        return json({'sanic': 'rocks'})
    app.blueprint(bp)

# Generated at 2022-06-12 09:02:09.919024
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:02:26.665774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # This creates a blueprint object first
    blueprint = Blueprint(__name__)
    @blueprint.listener('before_server_start')
    def before_start(app, loop):
        app.bind('exception')

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        pass

    blueprint.exception(apply=False)(exception_handler)

    # Unit test for method _apply_exception_handler of class Blueprint
    @blueprint.listener('before_server_start')
    def before_start(app, loop):
        app.bind('exception')

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        pass

    blueprint.exception(apply=False)(exception_handler)

# Generated at 2022-06-12 09:02:35.034213
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class UnderTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            nonlocal append_fn
            append_fn(handler)

    def append_fn(handler):
        nonlocal under_test
        under_test._future_exceptions.add(handler)

    under_test = UnderTest()
    exception = under_test.exception(Exception)("test_ExceptionMixin_exception")
    assert exception
    assert isinstance(under_test, UnderTest)
    assert under_test._future_exceptions[0].handler == "test_ExceptionMixin_exception"

# Generated at 2022-06-12 09:02:43.672069
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class NewClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

    new_class = NewClass()

    def exception_handler():
        pass

    new_class.exception(Exception)(exception_handler)

    assert len(new_class._future_exceptions) == 1
    future_exception = list(new_class._future_exceptions)[0]
    assert future_exception._handler == exception_handler
    assert future_exception._exceptions == (Exception,)
    assert not future_exception._kwargs

# Generated at 2022-06-12 09:02:47.270560
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    endpoint = 'exception'
    kwargs = {'apply': True}
    exception_list = ['exc1', 'exc2', 'exc3']
    bp = SanicBlueprint(endpoint)
    bp.exception(*exception_list, **kwargs)


# Generated at 2022-06-12 09:02:52.309300
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    my_future_exceptions: Set[FutureException] = set()
    def handler(*args, **kwargs):
        pass

    exceptions = (ValueError,)
    future_exception = FutureException(handler, exceptions)
    my_future_exceptions.add(future_exception)

    #assert my_future_exceptions == set(_future_exceptions)

# Generated at 2022-06-12 09:03:00.390105
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    # Test exception raise
    with pytest.raises(NotImplementedError):
        ExceptionMixin().exception(int, str)
    
    # Test decorator
    bp = Blueprint('test', '/')
    @bp.exception(int, str)
    def test_execption(request, exception):
        pass
    assert len(bp._future_exceptions) == 1

    # Test exception with a list of exception
    bp = Blueprint('test', '/')
    @bp.exception([int, str])
    def test_execption(request, exception):
        pass
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:03:03.688596
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__)

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        assert 1 == 2  # noqa

    with raises(AssertionError):
        exception_handler(Exception())


# Generated at 2022-06-12 09:03:09.335534
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testClass(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self,handler):
            self._future_exceptions = set()

    testClass_instance = testClass()
    @testClass_instance.exception(Exception)
    def testFunc():
        return 'testFunc'
    assert testFunc() == 'testFunc'

# Generated at 2022-06-12 09:03:16.277618
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    '''
    >>> class MySanic(ExceptionMixin):
    ...     def _apply_exception_handler(self, handler: FutureException):
    ...         print('applied')
    ...         pass
    >>> my_sanic = MySanic()
    >>> @my_sanic.exception(1)
    ... def handle_exception(request, exc):
    ...     print('handle_exception')
    ...     pass
    ... 
    >>> handle_exception
    <function MySanic.handle_exception at 0x10e6d4378>
    >>> applied
    applied
    '''
    pass



# Generated at 2022-06-12 09:03:19.379408
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint("test_blueprint", url_prefix="/test")
    @blueprint.exception(ValueError)
    def any_handler(request, exception):
        return text("oops")
    blueprint.exception(ValueError)(any_handler)

# Generated at 2022-06-12 09:03:41.794198
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.future import Future
    from sanic.models.blueprint import Blueprint
    from sanic.models.futures import FutureException

    app = Sanic("test_ExceptionMixin_exception", strict_slashes=True)
    blueprint = Blueprint("test_ExceptionMixin_exception")

    # option 1
    @blueprint.exception(ZeroDivisionError)
    def handler1(request, exception):
        pass

    # option 2
    @blueprint.exception([ZeroDivisionError, ValueError])
    def handler2(request, exception):
        pass

    # option 3
    @blueprint.exception(apply=False)(ZeroDivisionError)
    def handler3(request, exception):
        pass

    # option 4

# Generated at 2022-06-12 09:03:45.619288
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin:
        def __init__(self):
            self._future_exceptions = set()
            self._apply_exception_handler = MagicMock()

    mixin = MockExceptionMixin()
    mixin.exception(Exception)
    assert len(mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:03:49.377489
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # arrange
    bp = create_exception_mixin()
    # act
    @bp.exception(Exception)
    def exception_handler(request, exception):
        pass
    # assert
    assert len(bp._future_exceptions) == 1


# Generated at 2022-06-12 09:03:55.446502
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("Test", url_prefix="/test")

    @bp.exception(Exception)
    def test_function(request, exception):
        pass

    assert bp.exceptions == set()
    assert bp.has_exception_handler is False

    bp._apply_exception_handler(bp._future_exceptions.pop())
    assert bp.exceptions == set()
    assert bp.has_exception_handler is False

    @bp.exception(ValueError)
    def exception_callback(request, exception):
        return text("Internal server error", 500,
                    headers=None)

# Generated at 2022-06-12 09:04:05.643038
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self) -> None:
            super().__init__()
            self.__exception_handler = None

        def _apply_exception_handler(self, handler: FutureException):
            self.__exception_handler = handler

    @ExceptionMixinTest().exception(Exception)
    def handler_exception():
        return True

    assert handler_exception() is True
    assert ExceptionMixinTest().__exception_handler.handler == handler_exception
    assert ExceptionMixinTest().__exception_handler.exceptions == (Exception,)

    @ExceptionMixinTest().exception([ZeroDivisionError, TypeError])
    def handler_zero_division_type_error():
        return True

    assert handler_zero_division_type_error() is True
   

# Generated at 2022-06-12 09:04:10.319287
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockClass:
        def __init__(self):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler):
            pass

    mock = MockClass()
    assert mock._future_exceptions == set()

    @mock.exception()
    def mock_handler():
        pass

    assert len(mock._future_exceptions) == 1

# Generated at 2022-06-12 09:04:12.460873
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint(name="", import_name="")
    blueprint.exception(IndexError, Exception)(handler)
    
    assert(len(blueprint._future_exceptions) == 2)


# Generated at 2022-06-12 09:04:12.833139
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:04:14.712450
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def f_exception(handler):
        return handler()
    em = ExceptionMixin()
    em.exception(apply=False)(f_exception)
    assert len(em._future_exceptions) == 1
    assert f_exception in em._future_exceptions

# Generated at 2022-06-12 09:04:17.316294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint(__name__)

    @bp.exception(Exception)
    def override_handler(request, exception):
        assert isinstance(exception, Exception)
        pass



# Generated at 2022-06-12 09:04:52.513852
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("test", url_prefix="test")
    blueprint.exception(ZeroDivisionError)(lambda e: e)

# Generated at 2022-06-12 09:04:55.516888
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest.mock as mock
    from sanic.app import Sanic

    app = Sanic()

    @app.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(app.listeners['exception']) == 1

# Generated at 2022-06-12 09:05:01.661949
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    assert len(A()._future_exceptions) == 0

    A().exception(KeyError)(print)
    assert len(A()._future_exceptions) == 1

    A().exception([KeyError])(print)
    assert len(A()._future_exceptions) == 2

    A().exception([KeyError, IndexError])(print)
    assert len(A()._future_exceptions) == 3

    A().exception([KeyError, [IndexError], 1, 2])(print)
    assert len(A()._future_exceptions) == 3

# Generated at 2022-06-12 09:05:07.644178
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic import Blueprint

    app = Sanic(__name__)
    bp= Blueprint(__name__)
    @bp.exception(Exception)
    def handle_my_exception(request, exception):
        pass

    app.blueprint(bp)
    assert app.is_request_stream.__name__ == 'is_request_stream'
    assert app.request_middleware[0].__name__ == 'before_server_start'



# Generated at 2022-06-12 09:05:12.154575
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = Blueprint()
    # decorator
    @blueprint.exception(ValueError)
    def test_handler(request: Request, exception: Exception):
        pass

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == \
        FutureException(test_handler, (ValueError,))

# Generated at 2022-06-12 09:05:21.245558
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.request import Request
    from sanic.response import json
    from sanic.exceptions import SanicException
    from sanic.app import Sanic

    # Create a Blueprint
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test_blueprint', url_prefix='test')
    blueprint.exception(SanicException)(lambda request, exception: json({'error': exception.exception}))

    # Create a Sanic application with the Blueprint
    app = Sanic('exception-test')
    app.blueprint(blueprint)

    @app.route('/0')
    def handler_0(request):
        raise SanicException("0")

    @app.route('/1')
    def handler_1(request):
        raise Exception("1")

    # Add a same exception handler but with a different url

# Generated at 2022-06-12 09:05:29.924996
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self.error_handler = None
            self.error_handler_args = None
            self.error_handler_kwargs = None

        def error_handler(self, request, exception):
            self.error_handler = exception
            self.error_handler_args = request
            self.error_handler_kwargs = exception

    s = Sanic()

    @s.exception(Exception)
    def handler(request, exception):
        pass

    assert isinstance(s._future_exceptions, set)
    assert len(s._future_exceptions) == 1

    handler(None, None)

    assert s.error_handler == handler
    assert s.error_handler_args

# Generated at 2022-06-12 09:05:39.980377
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    from unittest import mock
    from sanic.blueprints import Blueprint

    def fake_apply_exception_handler(handler):
        pass

    class FakeExceptionMixin(ExceptionMixin):
        _apply_exception_handler = fake_apply_exception_handler

    blueprint1 = Blueprint('test_blueprint')
    blueprint1.exception(Exception)
    blueprint1.exception(Exception, apply=False)
    blueprint1.exception([Exception, ValueError], apply=False)
    assert len(blueprint1._future_exceptions) == 3
    
    blueprint2 = Blueprint('test_blueprint')
    blueprint2.exception = mock.Mock()
    blueprint2.exception(Exception)
    blueprint2.exception.assert_called_once()
    

# Generated at 2022-06-12 09:05:44.478369
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    fake_exception_mixin = FakeExceptionMixin()
    @fake_exception_mixin.exception(Exception)
    def fake_handler(request, exception):
        pass
    assert(fake_exception_mixin._future_exceptions)


# Generated at 2022-06-12 09:05:51.436868
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Creating an instance of ExceptionMixin
    future_exception_obj = FutureException(handler = None, exceptions = (1,2, "str"))
    exc_mixin_obj = ExceptionMixin()
    exc_mixin_obj._future_exceptions.add(future_exception_obj)
    exc_mixin_obj._future_exceptions
    assert len(exc_mixin_obj._future_exceptions) == 1
    assert list(exc_mixin_obj._future_exceptions)[0].exceptions[0] == 1
    assert list(exc_mixin_obj._future_exceptions)[0].handler == None

# Generated at 2022-06-12 09:07:10.113519
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.blueprints import Blueprint

    class CustomException(Exception):
        pass

    class CustomException2(Exception):
        pass

    bp = Blueprint(__name__)

    @bp.exception(CustomException, apply=True)
    def exception_handler(request, exception):
        return response.text('I caught an exception!')

    @bp.exception([CustomException, CustomException2], apply=True)
    def exception_handler_list(request, exception):
        return response.text('I caught an exception!')

    @bp.exception(CustomException, apply=True)
    def exception_handler2(request, exception):
        return response.text('I caught an exception!')


# Generated at 2022-06-12 09:07:14.331509
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, Blueprint

    bp = Blueprint('test_bp')
    bp.exception(ValueError)(lambda x: None)
    bp.exception(ValueError, Apply=False)(lambda x: None)

    app = Sanic()
    bp.register(app)
    assert bp.name == 'test_bp'



# Generated at 2022-06-12 09:07:15.150342
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO!
    pass

# Generated at 2022-06-12 09:07:21.208334
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()

    # This class is used to test ExceptionMixin mixin class
    class MyTestClass:
        pass

    @bp.exception([AttributeError], apply=True)
    def handle_exception(_attr):
        return "Alamuerte"

    my_test_class = MyTestClass()
    my_test_class._future_exceptions = bp._future_exceptions

    # Success test case
    assert my_test_class.handle_exception(AttributeError) == "Alamuerte"

# Generated at 2022-06-12 09:07:29.891003
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.called = False

        def _apply_exception_handler(self, handler):
            self.called = True
            assert(type(handler) == set)
            assert(len(handler) == 1)
            assert(type(list(handler)[0]) == FutureException)
            assert(len(list(handler)[0].exception_types) == 1)
            assert(list(handler)[0].exception_types == (1,))

    test_mixin = TestExceptionMixin()
    @test_mixin.exception(1)
    def dummyHandler():
        pass
    assert(test_mixin.called == True)

# Generated at 2022-06-12 09:07:31.987302
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.exceptions import NotFound

    bluprint = Blueprint('example')
    bluprint.exception(NotFound)(lambda req: req)

# Generated at 2022-06-12 09:07:33.317680
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_name')
    blueprint.exception(IndexError, ValueError)

# Generated at 2022-06-12 09:07:41.508378
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.exceptions import TestException

    app = Sanic('test_ExceptionMixin_exception')

    @app.exception(TestException)
    def handler_function(request, exception):
        pass

    @app.exception([TestException])
    def handler_function(request, exception):
        pass

    @app.exception(apply=False)
    def handler_function(request, exception):
        pass

    @app.exception([TestException], apply=False)
    def handler_function(request, exception):
        pass

    @app.blueprint.exception(TestException)
    def handler_function(request, exception):
        pass

    @app.blueprint.exception([TestException])
    def handler_function(request, exception):
        pass


# Generated at 2022-06-12 09:07:42.463758
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin().exception

# Generated at 2022-06-12 09:07:47.012297
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exceptionMixin = ExceptionMixin()
    @exceptionMixin.exception(NotImplementedError)
    def test_exception(request, exception):
        print("Not implemented exception")
    assert (exceptionMixin._future_exceptions.__sizeof__() > 0)