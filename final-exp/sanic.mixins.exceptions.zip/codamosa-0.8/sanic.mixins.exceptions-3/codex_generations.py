

# Generated at 2022-06-12 08:59:07.763774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from typing import Any
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    blueprint = Blueprint("My bp", url_prefix="/bp", strict_slashes=False)
    app = Sanic(__name__)

    # create a blueprint that has an exception handler
    @blueprint.exception(Exception)
    async def handler(request: Any, exception: Exception):
        pass

    assert isinstance(blueprint, ExceptionMixin)
    assert isinstance(blueprint, Blueprint)
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-12 08:59:18.169985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test project: https://github.com/pytest-dev/pytest-sanic/pull/15
    from sanic.app import Sanic
    from sanic import exceptions

    from sanic.response import json

    app = Sanic("test_ExceptionMixin_exception")

    @app.exception(exceptions.NotFound)
    def ignore_404s(request, exception):
        return json({"status": "ok"})

    @app.exception(exceptions.RequestTimeout)
    def request_timeout(request, exception):
        return json({"status": "timeout"})

    @app.exception(exceptions.ServerError)
    def server_error(request, exception):
        return json({"status": "error"})

    @app.route("/")
    async def test(request):
        raise

# Generated at 2022-06-12 08:59:26.934755
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class SanicTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            print("handler apply!")
            raise NotImplementedError  # noqa
    exc = SanicTest()
    assert exc._future_exceptions == set()
    @exc.exception(KeyError)
    def test(request, exception):
        print("this is a handler")


# test_ExceptionMixin_exception()

# Generated at 2022-06-12 08:59:35.170989
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a mock for class Sanic
    class MockSanic:
        def __init__(self):
            self._exception_handlers = {}

        def exception(self, *exceptions, apply=True):
            def decorator(handler):
                nonlocal apply
                nonlocal exceptions

                for exception in exceptions:
                    self._exception_handlers[exception] = handler
                return handler

            return decorator

    # create a mock for class Blueprint
    class MockBlueprint(ExceptionMixin):
        def register(self, *args, **kwargs):
            pass

    class MockRequest:
        def __init__(self):
            self.args = {}
            self.body = {}
            self.files = {}
            self.headers = {}
            self.form = {}
            self.method = ""
            self.query

# Generated at 2022-06-12 08:59:39.147603
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class SanicExample(ExceptionMixin):
        pass
    
    app = SanicExample()
    
    def handler():
        print("Success!")
        
    try:
        app.exception(KeyError)(handler)
        
    except NotImplementedError:
        print("Failed!")  
        return
    
    print("Success!")
    

if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 08:59:41.134896
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models import Model

    class SampleModel(Model):
        pass
    exc = ExceptionMixin()
    exc_1 = ExceptionMixin()
    exc_2 = ExceptionMixin()
    exc_1.__init__(exc_2)

# Generated at 2022-06-12 08:59:48.757873
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic import Blueprint
    bp = Blueprint('test_exception', url_prefix='tests')
    @bp.exception(ZeroDivisionError, apply=True)
    def zero_division_handler(request, exception):
        return text('zero division error')
    app = sanic.Sanic('test_exception')
    try:
        app.blueprint(bp)
    except KeyError:
        pass
    request, response = app.test_client.get('/tests/exception')
    assert response.text == 'zero division error'

# Generated at 2022-06-12 08:59:53.362505
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint_obj = Blueprint('test_ExceptionMixin_exception')
    blueprint_obj.exception(ValueError)(print)
    print(blueprint_obj._future_exceptions)
    assert blueprint_obj._future_exceptions == { FutureException(print, (ValueError,)) }

# Generated at 2022-06-12 09:00:03.934617
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    class MyException(Exception):
        pass

    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(MyExceptionMixin, self).__init__(*args, **kwargs)
            self.app = Sanic('test_ExceptionMixin_exception')

        def _apply_exception_handler(self, handler):
            self.app.error_handler.add(handler)


    ex = MyExceptionMixin()
    @ex.exception(Exception)
    async def test_handler(request, exception):
        pass

    assert len(ex._future_exceptions) == 1
    assert len(ex.app.error_handler._exception_handler) == 1

# Generated at 2022-06-12 09:00:12.066348
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest import mock
    from sanic.blueprints import Blueprint
    from common.testing import AsyncMock
    
    mock_bp = mock.create_autospec(Blueprint)
    mock_bp._apply_exception_handler = AsyncMock()
    mock_bp._future_exceptions = set()
    mock_handler = mock.Mock()
    mock_exceptions = mock.Mock()
    
    assert mock_bp._future_exceptions == set()
    
    @mock_bp.exception(mock_exceptions)
    def test_decorator(request, response):
        return response
    
    test_decorator(mock.Mock(), mock.Mock())
    
    assert len(mock_bp._future_exceptions) == 1
    assert mock_bp

# Generated at 2022-06-12 09:00:18.912643
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    bp = Blueprint(__name__)

    @bp.exception(Exception)
    def handle_request_exception(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert len(bp._future_exceptions.pop().exceptions) == 1

# Generated at 2022-06-12 09:00:22.024451
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception('test_exception_1', 'test_exception_2')
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:00:29.700394
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # create a class
    class TestClass:
        def __init__(self, *args, **kwargs):
            self._future_exceptions: Set[FutureException] = set()
    TestClass.__bases__ += (ExceptionMixin,)

    # create a class object
    testclass = TestClass()

    test_exception = RuntimeError("test")

    def test_handler():
        raise test_exception

    # call method exception of class ExceptionMixin
    testclass.exception(RuntimeError)(test_handler)



# Generated at 2022-06-12 09:00:30.698609
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    a = ExceptionMixin()

# Generated at 2022-06-12 09:00:38.691027
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print("Unit test for method exception of class ExceptionMixin...")
    from sanic.models.blueprint import Blueprint
    from types import MethodType

    test_parameters = (
        ("Exception-1"),
        ("Exception-1", "Exception-2"),
        ["Exception-1"],
        ["Exception-1", "Exception-2"],
    )
    for parameters in test_parameters:
        bp = Blueprint("testing")
        bp.exception(*parameters)
        assert type(bp.exception) is MethodType

    print("Done!\n")


# Generated at 2022-06-12 09:00:47.673580
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    blueprint = Blueprint(None)
    blueprint._apply_exception_handler = lambda x : -1


    # Test 1 (exceptions is a tuple)
    @blueprint.exception(Exception, NameError)
    def exc_handler(request, exception):
        assert request != None
        assert exception != None
        return "Exception Thrown"

    assert "Exception Thrown" == exc_handler(None, None)

    # Test 2 (exceptions is a list)
    @blueprint.exception([Exception, NameError])
    def exc_handler(request, exception):
        assert request != None
        assert exception != None
        return "Exception Thrown"

    assert "Exception Thrown" == exc_handler(None, None)

    # Test 3 (exceptions is a type)

# Generated at 2022-06-12 09:00:48.198123
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True == True

# Generated at 2022-06-12 09:00:55.618418
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Foo(ExceptionMixin):
        pass

    foo = Foo()
    assert foo._future_exceptions == set()
    @foo.exception(Exception)
    def handler(request, exception):
        return exception

    assert len(foo._future_exceptions) == 1
    future_exception = foo._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.exceptions == (Exception,)

    try:
        raise Exception
    except Exception as exception:
        assert handler(None, exception) == exception

# Generated at 2022-06-12 09:01:04.779322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import CompositionView
    from sanic.blueprints import Blueprint

    # GIVEN
    blueprint = Blueprint(__name__)
    composition_view = CompositionView.create_class(
        blueprint,
        route_prefix=None,
    )
    composition_view.exception = ExceptionMixin.exception.__get__(composition_view, composition_view.__class__)

    # WHEN
    @blueprint.exception(Exception, apply=False)
    def exception_handler(request, exception):
        pass

    # THEN
    assert len(composition_view._future_exceptions) == 1

# Generated at 2022-06-12 09:01:10.064880
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(args, kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return

    em = TestExceptionMixin()
    @em.exception(Exception)
    def test_function():
        pass
    assert len(em._future_exceptions) > 0
    for item in em._future_exceptions:
        assert item.handler != None
        assert item.handle_this_exception != None
    return

# Generated at 2022-06-12 09:01:17.215516
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Set up
    @ExceptionMixin.exception(ValueError)
    def try_int(x):
        return int(x)

    # Exercise
    try_int("xx")

# Generated at 2022-06-12 09:01:24.468547
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

        def exception_handler(self, request, exception):
            # Do something
            pass

    exception_mixin_test = ExceptionMixinTest()

    @exception_mixin_test.exception(Exception)
    def tester(request, exception):
        pass

    future_exception = FutureException(tester, Exception)
    assert future_exception in exception_mixin_test._future_exceptions


# Generated at 2022-06-12 09:01:31.593744
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    blueprint = Blueprint("Test")
    assert blueprint._apply_exception_handler is None
    assert blueprint._future_exceptions == set()

    def handler(request, exception):
        return "ExceptionMixin"

    blueprint.exception(handler, BaseException, apply=True)(handler)
    assert blueprint._apply_exception_handler is not None
    assert blueprint._future_exceptions != set()

    def handler2(request, exception):
        return "ExceptionMixin2"

    blueprint.exception(handler2, BaseException, apply=True)(handler2)
    assert blueprint._apply_exception_handler is not None
    assert blueprint._future_exceptions != set()

# Generated at 2022-06-12 09:01:34.584247
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    import sys
    import types

# Generated at 2022-06-12 09:01:43.372438
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FutureException1(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, args, kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    class ClientRequest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, args, kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    class ServerApp(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, args, kwargs)


# Generated at 2022-06-12 09:01:50.343242
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    bp = Blueprint(name=__name__)
    @bp.exception(NotFound)
    def handler(request, exception):
        return json(
            {"message": "Nothing here, sorry", "status": 404, "code": "404"},
            status=404,
        )
    assert isinstance(bp, Blueprint)
    assert isinstance(handler, Blueprint)


# Generated at 2022-06-12 09:01:55.074429
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import text

    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint("name", url_prefix="test")

    @bp.exception(NotFound)
    def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))

    assert ignore_404s in bp._future_exceptions



# Generated at 2022-06-12 09:02:04.386023
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.exceptions import InvalidUsage
    from unittest import mock

    class Model(HTTPMethodView, ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            def wrapper(request):
                request.future_exceptions = self._future_exceptions
                return handler(request)
            return wrapper

    # Create a blueprint
    blueprint = Blueprint('blueprint_test', url_prefix='test')

    # Create a model
    model = Model()

    # Mock original decorator to make sure it is not called
    original_decorator = mock.Mock()

# Generated at 2022-06-12 09:02:06.203022
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Dummy(ExceptionMixin):
        pass

    dummy = Dummy()
    exception = dummy.exception(ValueError)
    assert exception



# Generated at 2022-06-12 09:02:11.716341
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage
    exception_mixin = ExceptionMixin()
    exceptions = [InvalidUsage]
    def state_handler(request, exception):
        print(str(exception))
    future_exception = FutureException(state_handler, exceptions)
    assert exception_mixin._future_exceptions == set()
    exception_mixin._apply_exception_handler = lambda x: None
    assert exception_mixin.exception(*exceptions) == state_handler
    assert exception_mixin._future_exceptions == {future_exception}


# Generated at 2022-06-12 09:02:23.746589
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class B(ExceptionMixin):
        pass

    @B.exception(ValueError)
    def handler(request, exception):
        assert exception.__class__ is ValueError
        return True

    exception = FutureException(handler, (ValueError,))
    b = B()
    assert exception in b._future_exceptions
    assert b._apply_exception_handler(exception) is True

# Generated at 2022-06-12 09:02:29.913300
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test_ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.add_exception = None
            
        def _apply_exception_handler(self, handler: FutureException):
            self.add_exception = handler
            
    class test_exception_handler:
        def __init__(self, *args, **kwargs):
            self.arg = args
            self.kwargs = kwargs
            
    class test_list_exception_handler:
        def __init__(self, *args, **kwargs):
            self.arg = args
            self.kwargs = kwargs
            
    t = test_ExceptionMixin()

# Generated at 2022-06-12 09:02:36.849451
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class testExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exception_mixin_object = testExceptionMixin()
    # test case 1: list of exceptions
    @exception_mixin_object.exception([Exception,IOError])
    def exception_handler():
        pass
    # test case 2: no args exception
    @exception_mixin_object.exception()
    def exception_handler():
        pass
    # test case 3: list of args exception
    @exception_mixin_object.exception(Exception,[IOError,FileNotFoundError])
    def exception_handler():
        pass

# Generated at 2022-06-12 09:02:45.848397
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint(name='test_ExceptionMixin_exception', url_prefix='test')

    blueprint.exception(SanicException)(lambda request, exception: text('SanicException test'))

    @blueprint.route('/')
    async def bp_exception_test(request):
        return text('Hello world!')

    request, response = blueprint.create_http_request(url='/', method='GET')
    result = blueprint.handle_request(request)
    assert result.body == b'Hello world!'

    request, response = blueprint.create_http_request(url='/', method='GET')
    result = blueprint.handle_request(request)

# Generated at 2022-06-12 09:02:51.974534
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    a = A()
    @a.exception('+')
    def handle(a):
        print(a)

    assert isinstance(a._future_exceptions, set)
    assert len(a._future_exceptions) == 1
    assert isinstance(a._future_exceptions.pop(), FutureException)

# Generated at 2022-06-12 09:03:00.672419
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            ExceptionMixin.__init__(self, *args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @ExceptionMixinTest.exception(Exception)
    def exception_handler(request, exception):
        return 'global exception handler'

    assert len(ExceptionMixinTest._future_exceptions) == 1
    assert len(ExceptionMixinTest._future_exceptions) == 1
    assert (ExceptionMixinTest._future_exceptions.pop().handler ==
            exception_handler)

# Generated at 2022-06-12 09:03:08.837560
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    mock_self = Mock()
    mock_handler = Mock()
    mock_exceptions = []
    mock_kwargs = {}

    mock_self._future_exceptions = set()
    mock_self._apply_exception_handler = MagicMock()

    decorator = ExceptionMixin.exception(mock_self, mock_exceptions, **mock_kwargs)
    decorated_handler = decorator(mock_handler)

    mock_self._future_exceptions.add(FutureException(mock_handler, mock_exceptions))
    mock_self._apply_exception_handler.assert_called_with(FutureException(mock_handler, mock_exceptions))
    assert decorated_handler == mock_handler

# Generated at 2022-06-12 09:03:12.612351
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler is not None

    a = A()
    a.exception(Exception)(lambda request: False)

    a._future_exceptions.clear()

    a.exception(Exception, apply=False)(lambda request: False)
    assert len(a._future_exceptions) == 1

# Generated at 2022-06-12 09:03:20.521775
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound

    class Sample(ExceptionMixin):
        def __init__(self):
            super().__init__()

    to_be_tested = Sample()
    exception_to_be_handled = NotFound("hello")
    caught = False

    @to_be_tested.exception(exception_to_be_handled)
    def exception_handler(request, exception):
        nonlocal caught
        caught = True
        assert request == "sample_request"
        assert exception == exception_to_be_handled

    to_be_tested._apply_exception_handler(
        next(iter(to_be_tested._future_exceptions)))

    to_be_tested.handle_request("sample_request", exception_to_be_handled)

    assert caught

# Generated at 2022-06-12 09:03:22.465314
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    mix_in = ExceptionMixin()
    assert mix_in.exception
    assert mix_in._future_exceptions == set()

# Generated at 2022-06-12 09:03:38.932547
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test exception decorator
    assert True

# Generated at 2022-06-12 09:03:48.848975
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest():
        def __init__(self):
            pass

    import sys
    from unittest.mock import MagicMock
    from unittest.mock import patch
    testClass = ExceptionMixinTest()
    testClass.__class__ = ExceptionMixin

    mock_func = MagicMock()
    mock_future_exception = MagicMock()
    mock_exc = sys.exc_info()

# Generated at 2022-06-12 09:03:55.239776
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    print("Create instance of Mixin")
    inst = ExceptionMixin()

    print("Test function decorator 'exception'")
    def handler1():
        pass
    def handler2():
        pass
    inst.exception(KeyError, apply=False)(handler1)
    inst.exception(apply=False)(handler2)
    assert inst._future_exceptions == {FutureException(handler1, (KeyError,)),
                                       FutureException(handler2, tuple())}

    # Test that args is 'tuple'
    inst.exception(handler=handler1, args=[IndexError])
    assert inst._future_exceptions == {FutureException(handler1, tuple())}

# Generated at 2022-06-12 09:03:59.508443
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    def handler(*args):
        return "done"

    blueprint = Blueprint(__name__, url_prefix='/test')
    blueprint.exception(ValueError)(handler)



# Generated at 2022-06-12 09:04:04.557508
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    app = Sanic("test_ExceptionMixin_exception")

    @app.exception(Exception)
    async def error_handler(request, exception):
        pass

    assert len(app._future_exceptions) == 1

    @app.exception([IndexError, KeyError])
    async def error_handler_1(request, exception):
        pass

    assert len(app._future_exceptions) == 2

# Generated at 2022-06-12 09:04:06.407570
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = ExceptionMixin()
    result = bp.exception(Exception)(bp.exception)
    assert result(Exception)(bp.exception) == bp.exception

# Generated at 2022-06-12 09:04:13.109178
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # initialize an ExceptionMixin instance
    class ExceptionMixinSubClass(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    obj = ExceptionMixinSubClass()

    # test if the method returns a decorator
    assert callable(obj.exception(Exception))
    assert callable(obj.exception(Exception, Exception))

    # test if the method decorates a function
    @obj.exception(Exception)
    def fn1():
        pass
    @obj.exception(Exception, Exception)
    def fn2():
        pass
    assert fn1() == fn2()

# Generated at 2022-06-12 09:04:20.100349
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    app = Sanic()
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            app.error_handler.add(handler.exceptions, handler)

    em = TestExceptionMixin()
    @em.exception(Exception)
    def handler(request, exception):
        ...

    assert len(em._future_exceptions) == 1
    assert len(app.error_handlers[Exception]) == 1
    assert app.error_handlers[Exception][0].__name__ == 'handler'

    @em.exception(ValueError, apply=False)
    def handler2(request, exception):
        ...

    assert len(em._future_exceptions) == 2
    assert len(app.error_handlers[Exception])

# Generated at 2022-06-12 09:04:25.958748
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinMock(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            handler_copy = handler

        def exception_handler_test_func():
            pass

    # Test case 1: With exception
    b = ExceptionMixinMock()

    @b.exception(Exception)
    def exception_handler_test_func():
        pass

    # Test case 2: Without exception
    b = ExceptionMixinMock()

    @b.exception()
    def exception_handler_test_func():
        pass

# Generated at 2022-06-12 09:04:32.234235
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    class ExceptionMixinTest(ExceptionMixin, Blueprint):
        def _apply_exception_handler(self, handler: FutureException):
            assert self._future_exceptions == {handler}
            assert handler.exceptions == ("KeyError",)
            assert handler.handler == "hello"
    exceptionMixinTest = ExceptionMixinTest('blueprint', '/blueprint')
    exceptionMixinTest.exception("KeyError")("hello")

# Generated at 2022-06-12 09:05:11.427719
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self.exceptions = {}
            self.apply = None
        
        def _apply_exception_handler(self, handler: FutureException):
            self.exceptions = handler.exceptions
            self.apply = handler.apply
    
    def my_exceptions():
        """
        This method enables the process of creating a global exception
        handler for the current blueprint under question.

        :param args: List of Python exceptions to be caught by the handler
        :param kwargs: Additional optional arguments to be passed to the
            exception handler

        :return a decorated method to handle global exceptions for any
            route registered under this blueprint.
        """
        return "exception"

# Generated at 2022-06-12 09:05:18.349391
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            pass

    test_exception_mixin = TestExceptionMixin()

    # Test positive case
    @test_exception_mixin.exception(IndexError)
    def handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:05:21.855366
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    test = ExceptionMixin()
    @test.exception(Exception)
    def exceptionhandler(request, exception):
        pass

    assert len(test._future_exceptions) == 1
    assert isinstance(test._future_exceptions.pop(), FutureException)


# Generated at 2022-06-12 09:05:26.649792
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Prepare an instance of the ExceptionMixin
    exception_mixin_instance = ExceptionMixin()

    # Create a test method
    def test_method(request, response):
        response.text = 'method'

    # Call the decorator
    exception_mixin_instance.exception(Exception)(test_method)
    # Check that the method is added in the set
    assert exception_mixin_instance._future_exceptions

# Generated at 2022-06-12 09:05:29.992691
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test_bp", url_prefix='/test_bp')
    bp.exception(Exception)(print)
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().exception is Exception


# Generated at 2022-06-12 09:05:36.453098
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    mock_exception_mixin = MockExceptionMixin()
    @mock_exception_mixin.exception(TypeError)
    def decorator(a):
        return a*a
    assert decorator(3) == 9

# Generated at 2022-06-12 09:05:36.981803
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:05:41.804038
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler
    test_blueprint = TestBlueprint()

    @test_blueprint.exception(Exception)
    def exception_handler(request, exception):
        return True

    exception_handler(1, Exception)

    list_of_future_exceptions = [
        FutureException(exception_handler, (Exception,))
    ]
    assert test_blueprint._future_exceptions == set(list_of_future_exceptions)

# Generated at 2022-06-12 09:05:46.941912
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    bp = Blueprint('test', '/test')
    # Act
    @bp.exception(Exception)
    def handler(request, exception):
        print(exception)
    # Assert
    # assert len(bp._future_exceptions) == 1
    # assert bp._future_exceptions[0].handler == handler
    # assert bp._future_exceptions[0]._exception_class == Exception
    assert bp.exception(Exception) == handler

# Generated at 2022-06-12 09:05:51.586322
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound

    class FakeBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler.__name__ == "handler"
            assert handler.exceptions[0] == NotFound

    from sanic.exceptions import NotFound

    @FakeBlueprint.exception(NotFound)
    def handler(request, exception):
        pass

# Generated at 2022-06-12 09:06:56.914721
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO
    pass

# Generated at 2022-06-12 09:07:00.896473
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint("blue")

    def exception_handler(request, exception):
        return "OK"

    blueprint.exception(ValueError, apply=False)(exception_handler)
    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1

    future_exception = next(iter(blueprint._future_exceptions))
    assert future_exception.handler is exception_handler

# Generated at 2022-06-12 09:07:09.145059
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionStub(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.future_exceptions = set()
            self.b = BlueprintStub(self)

        def _apply_exception_handler(self, handler: FutureException):
            self.future_exceptions.add(handler)

    class BlueprintStub:
        def __init__(self, app):
            self.app = app

    ex = ExceptionStub()

    # method exception
    @ex.exception(Exception)
    def exception_handler():
        return "exception"

    assert ex.future_exceptions
    assert ex.b.app is ex



# Generated at 2022-06-12 09:07:17.847792
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic import Sanic
    from nose.tools import assert_equal

    class BlueprintEx(Blueprint, ExceptionMixin):
        pass

    app = Sanic(__name__)
    blueprintEx = BlueprintEx("BlueprintEx")

    @blueprintEx.route("/")
    def blueprint_ex_handler(request):
        return text("I am a blueprint exception handler")

    @blueprintEx.exception(Exception)
    def blueprint_exception_handler(*args, **kwargs):
        return text("I am blueprint global exception handler")

    blueprintEx.register(app)

    @app.route("/")
    def normal_handler(request):
        return text("I am a normal handler")


# Generated at 2022-06-12 09:07:20.917937
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    blueprint = Blueprint("test_bp", url_prefix="/test/bp")

    assert len(blueprint._future_exceptions) == 0
    assert blueprint.exception is ExceptionMixin.exception

# Generated at 2022-06-12 09:07:28.634354
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class BlueprintWithException(ExceptionMixin):
        def __init__(self):
            self.before_request_funcs = set()
            self.after_request_funcs = set()
            self.__init__()

        def _apply_exception_handler(self, handler: FutureException):
            self.before_request_funcs.add(handler.handler)

    blueprint = BlueprintWithException()
    @blueprint.exception(Exception, apply=False)
    def handler_test():
        pass

    assert len(blueprint.before_request_funcs) == 1
    assert blueprint._future_exceptions != set()
    assert isinstance(tuple(blueprint._future_exceptions)[0], FutureException)

# Generated at 2022-06-12 09:07:34.823057
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models import Blueprint
    from sanic.response import json
    from sanic.exceptions import SanicException

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception([SanicException])
    def exception_handler(request, exception):
        return json(exception.__class__.__name__)

    @bp.route('/0')
    def handler(request):
        raise SanicException()

    assert exception_handler(None, SanicException()) == json('SanicException')
    assert handler(None).body == b'SanicException'

    @bp.exception([SanicException], apply=False)
    def another_exception_handler(request, exception):
        pass

    @bp.route('/1')
    def another_handler(request):
        raise

# Generated at 2022-06-12 09:07:43.942877
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.exceptions import NotFound
    from sanic.exceptions import ServerError

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin: TestExceptionMixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(NotFound, apply=False)
    def exception_handler(self, request, exc):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert isinstance(test_exception_mixin._future_exceptions[0].exceptions, set)

# Generated at 2022-06-12 09:07:50.474642
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_test(ExceptionMixin):
        def __init__(self):
            pass

        def _apply_exception_handler(self, handler: FutureException):
            pass

        def get_exceptions(self):
            return self._future_exceptions

    obj_ExceptionMixin = ExceptionMixin_test()
    assert not obj_ExceptionMixin.get_exceptions()
    @obj_ExceptionMixin.exception(Exception)
    def my_exception_handler():
        pass
    assert len(obj_ExceptionMixin.get_exceptions()) == 1

# Generated at 2022-06-12 09:07:51.281409
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Add unit test
    pass