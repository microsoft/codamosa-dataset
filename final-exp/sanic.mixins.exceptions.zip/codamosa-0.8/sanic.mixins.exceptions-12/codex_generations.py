

# Generated at 2022-06-12 08:59:13.667924
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    #Create an instance of ExceptionMixin
    em = ExceptionMixin()
    #Create list of exceptions
    exceptions = [ValueError, ZeroDivisionError, OSError]
    #Create handler
    def handler(request, exception):
        pass
    #Call method exception
    @em.exception(*exceptions)
    def func(request, exception):
        handler(request, exception)
    #Check if the instance of FutureException is contained in attribute _future_exceptions
    assert em._future_exceptions == {FutureException(func, exceptions)}

# Generated at 2022-06-12 08:59:18.475304
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from blueprintapp.app import MyApp

    app = MyApp()

    @app.blueprint("/blueprint")
    class Blueprint(ExceptionMixin):
        pass

    @Blueprint.exception(KeyError)
    def exception_handler(request, exception):
        return "exception_handler"

    assert len(next(iter(Blueprint.get_blueprint().handlers_dict.values())).handlers) == 1

# Generated at 2022-06-12 08:59:29.071268
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
        Unit tests for the method `exception`
    """

    class Model(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        @property
        def future_exceptions(self):
            return self._future_exceptions

        def _apply_exception_handler(self, handler):
            pass

    # Test without args
    model = Model()

    def _handler():
        pass

    _exception = model.exception(_handler)
    assert _exception.__name__ == "_handler"
    assert isinstance(model.future_exceptions.pop(), FutureException)

    # Test with args
    model = Model()

    _exception = model.exception(IndexError, _handler)
    assert _ex

# Generated at 2022-06-12 08:59:29.559700
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 08:59:32.872486
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for method exception of class ExceptionMixin
    """
    try:
        from sanic.server import Sanic
        from sanic.blueprints import Blueprint
        blueprint = Blueprint(name="blueprint test", url_prefix="/")
        blueprint.exception(ZeroDivisionError, ValueError)(lambda: None)
        assert True
    except:
        assert False



# Generated at 2022-06-12 08:59:38.924621
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.response import json
    from typing import Tuple
    from sanic.exceptions import ServerError
    from sanic.views import HTTPMethodView
    from sanic.models.exceptions import ExceptionMixin

    test_exception_list = [ValueError, ServerError]

    class UserExceptionView(HTTPMethodView, ExceptionMixin):
        def get(self, request):
            return json({"hello": "world"})

    exception_view = UserExceptionView.as_view()

    @exception_view.exception(*test_exception_list, apply=True)
    def exception_handler(request, exception):
        return json({"exception": "global exception handler"}, status=500)

    app = Sanic(__name__)
    app.add_

# Generated at 2022-06-12 08:59:39.730895
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO: Implement test case
    assert False

# Generated at 2022-06-12 08:59:52.069594
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint, Sanic
    bp = Blueprint('bp')
    @bp.exception(Exception)
    def handler(request, exception):
        pass
    assert len(bp._future_exceptions) == 1
    assert not isinstance(bp.exception, Sanic.exception)
    assert isinstance(bp.exception, Blueprint.exception)
    assert str(bp.exception.__name__) == 'exception'
    assert str(bp.exception.__qualname__) == 'Blueprint.exception'
    app = Sanic()
    app.blueprint(bp)
    assert len(bp._future_exceptions) == 0
    assert isinstance(bp.exception, Sanic.exception)
    assert not isinstance(bp.exception, Blueprint.exception)

# Generated at 2022-06-12 09:00:01.434387
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('sanic_test')
    bp1 = Blueprint('bp1')

    @bp1.exception(apply=True)
    def exception_handler(request, exception):
        return text('Exception has occured')

    app.blueprint(bp1)
    assert len(app.error_handler.handlers) == 1

    @bp1.exception()
    def exception_handler1(request, exception):
        return text('Exception has occured')

    with pytest.raises(TypeError):
        app.blueprint(bp1)

    assert isinstance(bp1.exception, ExceptionMixin.exception)

# Generated at 2022-06-12 09:00:05.415420
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blp = ExceptionMixin()
    @blp.exception([IndexError, ValueError])
    def handler(request, exception):
        return "handler"
    assert "handler" == handler(None, IndexError)
    assert None == handler(None, KeyError)

# Generated at 2022-06-12 09:00:14.008430
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions == (TypeError,)
            assert handler.handler is not None
            assert handler.kwargs is not None

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(TypeError)(Exception)
    test_exception_mixin.exception(TypeError, apply=False)(Exception)

# Generated at 2022-06-12 09:00:18.433938
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, Blueprint
    app = Sanic()
    bp = Blueprint('test')
    assert not hasattr(bp, '_future_exceptions')
    bp.exception()
    assert hasattr(bp, '_future_exceptions')

# Generated at 2022-06-12 09:00:23.526709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestException(Exception):
        pass

    def test_exception_handler():
        pass

    blueprint = ExceptionMixin()

    blueprint.exception(TestException)(test_exception_handler)

    # check future_exception
    assert len(blueprint._future_exceptions) == 1
    assert (TestException in blueprint._future_exceptions.pop().exceptions)

    # check handler
    assert (blueprint._future_exceptions.pop().handler ==
            test_exception_handler)

# Generated at 2022-06-12 09:00:27.638468
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_handler = exception_mixin.exception(ValueError)

    assert exception_handler is not None
    assert len(exception_mixin._future_exceptions) == 0



# Generated at 2022-06-12 09:00:35.400361
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import InvalidUsage

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = Blueprint(name='test', url_prefix='/test')

    @bp.exception(InvalidUsage)
    def error_handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-12 09:00:41.543169
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic
    from sanic.testing import create_asyncio_test_loop

    loop = create_asyncio_test_loop()

    class Server(sanic.Sanic, ExceptionMixin):
        def _enter_asyncio_context(self, loop):
            self._loop = loop

        def _apply_exception_handler(self, handler):
            pass


# Generated at 2022-06-12 09:00:45.405479
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class NameClass(ExceptionMixin):
        pass
    a = NameClass()
    @a.exception(Exception)
    def test():
        pass
    assert isinstance(a._future_exceptions, set)
    assert a._future_exceptions == {FutureException(test, (Exception,))}


# Generated at 2022-06-12 09:00:55.692994
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureException
    from sanic.response import text

    app = Sanic("test_ExceptionMixin_exception")

    bp = Blueprint("test_exception")

    @bp.exception(SanicException)
    def sanic_exception(request, exception):
        return text("It is a sanic exception")

    try:
        app.register_blueprint(bp)
    except NotImplementedError:
        pass
    else:
        pytest.fail("ExceptionMixin._apply_exception_handler is not implemented")

    future_exceptions = bp._future_exceptions
    # 1. Check if decorator returned the function in decor

# Generated at 2022-06-12 09:01:06.261193
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass
    class MyBlueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    mybp = MyBlueprint()
    @mybp.exception([MyException])
    def handle_exception(request, exception):
        '''
        function to handle exception
        '''
        assert exception == MyException
    # test exception handler
    try:
        raise MyException
    except MyException as error:
        handle_exception(MyException, error)
    # test exception passed to blueprint
    future_exception = mybp._future_exceptions.pop()
    assert future_exception.handler == handle_exception
    assert future_exception.exceptions == (MyException, )

# Generated at 2022-06-12 09:01:08.307489
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    result = ExceptionMixin.exception(ExceptionMixin,HTTPException)
    assert result == decorator(handler)

# Generated at 2022-06-12 09:01:13.903390
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("Test")

# Generated at 2022-06-12 09:01:21.720835
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    from sanic.exceptions import ServerError

    bp = Blueprint('my_bp')

    exception_type_list = [ServerError]

    async def exception_handler(request, exception):
        pass

    bp.exception(*exception_type_list)(exception_handler)

    assert len(bp._future_exceptions) == 1
    fe = bp._future_exceptions.pop()
    assert len(fe.exceptions) == len(exception_type_list)
    assert fe.handler == exception_handler


# Generated at 2022-06-12 09:01:22.261433
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:01:22.853152
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:01:26.928139
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyException(Exception):
        pass
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    e = MyExceptionMixin()
    assert isinstance(e.exception(MyException)(lambda: None), types.FunctionType)


# Generated at 2022-06-12 09:01:31.730854
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    blueprint = Blueprint(__name__)
    blueprint.exception(Exception)(handler)
    blueprint_instance = blueprint.as_handler()

    assert exception in blueprint_instance.exception_handlers
    assert isinstance(blueprint_instance.exception_handlers[exception], FutureException)
    assert blueprint_instance.exception_handlers[exception].handler == handler


# Generated at 2022-06-12 09:01:41.446079
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.response import HTTPResponse
    from sanic.exceptions import ServerError
    from sanic.exceptions import RequestTimeout

    app = Sanic()
    bp = Blueprint('bp', url_prefix='/blah')

    @bp.exception(ServerError, RequestTimeout)
    def handler(request, exception, *args, **kwargs):
        if exception is ServerError:
            return HTTPResponse(body='ServerError', status=500)
        return HTTPResponse(body='RequestTimeout', status=408)

    @bp.route('/500')
    def handler_500(request):
        raise ServerError()

    @bp.route('/408')
    def handler_408(request):
        raise RequestTimeout

# Generated at 2022-06-12 09:01:49.126884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint(name='exception_mixin')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        pass

    future_exception = FutureException(handler=handler, exceptions=[SanicException])
    future_exceptions = blueprint._future_exceptions
    assert len(future_exceptions) == 1
    assert future_exception in future_exceptions

# Generated at 2022-06-12 09:01:57.263429
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Sanic:
        def __init__(self):
            self.error_handler = None

    class Blueprint(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self.name = 'test'
            self.sanic = Sanic()
            self._exceptions = []

        def _apply_exception_handler(self, handler: FutureException):
            self._exceptions.append(handler)

    @Blueprint.exception(Exception)
    def exception_handler(request, exception):
        return 'global handler'

    assert exception_handler(None, None) == 'global handler'
    bp = Blueprint()
    bp.exception_handler
    assert bp._exceptions[0].handler(None, None) == 'global handler'

# Generated at 2022-06-12 09:02:06.111158
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import BluePrint
    blueprint = BluePrint(name="test")

    @blueprint.exception(NameError)
    def name_error_handler(request, exception):
        return text("This will be executed due to name error occured")

    @blueprint.exception([RuntimeError,KeyError])
    def run_time_error_handler(request, e):
        return text("This will be executed due to runtime error occured")

    @blueprint.exception(ValueError)
    def value_error_handler(request, e):
        return text("This will be executed due to value error occured")

    @blueprint.route('/Nameerror')
    def name_error(request):
        raise NameError("this is test")


# Generated at 2022-06-12 09:02:15.916943
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @ExceptionMixin.exception(apply = False)
    def handler():
        pass
    assert isinstance(handler, types.FunctionType)



# Generated at 2022-06-12 09:02:18.442335
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    my_future_exception = set()
    my_class = ExceptionMixin(my_future_exception)
    assert my_class._future_exceptions == set()

# Generated at 2022-06-12 09:02:20.403273
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    assert exception_mixin._future_exceptions == set()
    assert exception_mixin.exception() != ''

# Generated at 2022-06-12 09:02:28.143462
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class ExceptionMixinStub(ExceptionMixin):
        def __init__(self):
            super(ExceptionMixinStub, self).__init__()
            self.handler = lambda: None
            self.exceptions = (ValueError, TypeError)
            self.future_exceptions = set()

        def _apply_exception_handler(self, future_exception: FutureException):
            self.future_exceptions.add(future_exception)

    mixin_stub = ExceptionMixinStub()

    # Act
    mixin_stub.exception(Exception, apply=False)(mixin_stub.handler)

    # Assert
    assert len(mixin_stub._future_exceptions) == 1
    assert mixin_stub.handler == mixin_stub._future_ex

# Generated at 2022-06-12 09:02:31.969985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('foo')
    blueprint.exception(Exception)

    assert blueprint._future_exceptions != set()
    assert type(blueprint._future_exceptions) == set

# Generated at 2022-06-12 09:02:33.681635
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    e=ExceptionMixin()
    e.exception(ValueError)(lambda x: x + 1)
    assert len(e._future_exceptions) == 1

# Generated at 2022-06-12 09:02:41.324701
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException) -> None:
            # Do nothing
            return None
    # Create class
    exception_mixin = TestExceptionMixin()
    # Decorator
    @exception_mixin.exception()
    def test_handler():
        # Do nothing
        return True
    list_handler = list(exception_mixin._future_exceptions)
    assert len(list_handler) == 1
    assert list_handler[0] == FutureException(test_handler)

# Generated at 2022-06-12 09:02:41.841630
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 09:02:45.805474
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import json

    blueprint = Blueprint("test_exception", url_prefix="test")
    blueprint._apply_exception_handler = lambda x: x

    @blueprint.exception(ZeroDivisionError)
    def zero_division_handler(request, exception):
        return json({"error": "You can not divide on zero."})

    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-12 09:02:54.712800
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import ServerError, Abort

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    
    # decorate a handler
    @test_exception_mixin.exception(ServerError, apply=False)
    def handler(request, exception):
        return 'Decorated handler'
    assert test_exception_mixin._future_exceptions == {
        FutureException(handler, (ServerError,))
    }

    # decorate a handler with a list

# Generated at 2022-06-12 09:03:10.389655
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass


#####################################################################
#

# Generated at 2022-06-12 09:03:19.184693
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound

    class test_class(ExceptionMixin):
        def add_route(self, uri, handler):
            assert handler == "handler"
            assert isinstance(uri, str) and not uri

    class test_class1(ExceptionMixin):
        def add_route(self, uri, handler):
            assert handler == "handler"
            assert isinstance(uri, str) and not uri

    class test_class2(ExceptionMixin):
        def add_route(self, uri, handler):
            assert handler == "handler"
            assert isinstance(uri, str) and not uri

    _ = test_class()
    _1 = test_class1()
    _2 = test_class2()


# Generated at 2022-06-12 09:03:25.069340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    obj = ExceptionMixin()
    # raise NotImplementedError
    # assert obj._future_exceptions is not None


####################################################################
#    Copyright (c) 2016 by www.bux.blog.br                        #
#                                                                  #
#    Permission is hereby granted, free of charge, to any          #
#    person obtaining a copy of this software and associated       #
#    documentation files (the "Software"), to deal in the          #
#    Software without restriction, including without limitation    #
#    the rights to use, copy, modify, merge, publish,              #
#    distribute, sublicense, and/or sell copies of the Software,   #
#    and to permit persons to whom the Software is furnished to do #
#    so, subject to the following conditions:                      #
#                                                                  #
#    The above copyright notice

# Generated at 2022-06-12 09:03:25.644619
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:03:31.538746
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # we will use the class CreateExceptionMixin, which inherits from ExceptionMixin
    # to test the exception method, so we will mock it
    class CreateExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    create_exception_mixin = CreateExceptionMixin()
    # we first use the decorator but without exceptions
    # there should be no exception
    @create_exception_mixin.exception()
    def handler():
        pass
    # we test the result
    assert len(create_exception_mixin._future_exceptions) == 1
    # now we use the decorator with exceptions
    # there should be no exception
    @create_exception_mixin.exception(Exception)
    def handler():
        pass
    # we test the

# Generated at 2022-06-12 09:03:38.037383
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler):
            self._future_exceptions.add(handler)

    bp = Blueprint()
    @bp.exception(IndexError)
    def handler(request, exception):
        pass

    handler = bp._future_exceptions.pop()
    assert handler.handler == handler
    assert handler.exceptions == (IndexError,)

# Generated at 2022-06-12 09:03:43.906431
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.request import Request

    sanic = Sanic(__name__)

    @sanic.exception(Exception)
    def error_handler(request: Request, exception: Exception):
        return "", 500
    
    request, response = sanic.test_client.get('/exception')
    assert response.status == 500
    assert response.text == 'Error', 'Error'


# Generated at 2022-06-12 09:03:49.199421
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Bluprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    blueprint = Bluprint()
    @blueprint.exception(Exception)
    def handle_exception(request, exception):
        pass
    assert len(blueprint._future_exceptions) == 1
    for future_exception in blueprint._future_exceptions:
        assert future_exception.handler is handle_exception

# Generated at 2022-06-12 09:03:49.695622
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:03:57.113512
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    app = Sanic(__name__)
    class Foo(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    foo = Foo()
    @foo.exception(Exception)
    def test_handler(request, exception):
        pass
    def test_handler2(request, exception):
        pass
    @foo.exception(Exception, apply=False)
    def test_handler3(request, exception):
        pass
    assert isinstance(foo._future_exceptions.pop(), FutureException)
    foo.exception(Exception, apply=False)(test_handler)
    assert isinstance(foo._future_exceptions.pop(), FutureException)
    foo.exception(Exception, apply=False)(test_handler2)

# Generated at 2022-06-12 09:04:36.917885
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint, rv
    from sanic.models.futures import ExceptionHandler, FutureException
    
    class MyBlueprint(Blueprint, ExceptionMixin):
        def _apply_exception_handler(self, handler):
            nonlocal _apply_exception_handler
            _apply_exception_handler = handler

    my_bp = MyBlueprint("blueprint", url_prefix="/blueprint")
    
    @my_bp.exception(ZeroDivisionError)
    def _exception_handler(request, exception):
        pass
    
    # on of the handlers is ZeroDivisionError
    assert isinstance(_apply_exception_handler, FutureException)
    assert _apply_exception_handler.exceptions == (ZeroDivisionError,)
    assert _apply_exception_handler.handler is _

# Generated at 2022-06-12 09:04:40.921491
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Model(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    @Model.exception(Exception)
    def handler(request, e):
        return "That's all folks!"

    model = Model()
    assert model._future_exceptions == {FutureException(handler, (Exception,))}

# Generated at 2022-06-12 09:04:43.021864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    mixin = ExceptionMixin()
    assert len(mixin._future_exceptions) == 0

    @mixin.exception(Exception)
    def test_handler(request, exception):
        return None

    assert len(mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:04:51.312887
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint, Sanic
    from sanic import response
    from sanic.models.futures import FutureException

    app = Sanic("Example Blueprint App")
    blueprint = Blueprint("Example Blueprint", url_prefix="/example")
    blueprint._apply_exception_handler = lambda manifest: manifest

    @blueprint.exception(BaseException)
    def handler(request, exception):
        return response.json({"error": str(exception)}, 500)

    app.blueprint(blueprint)

    @app.route("/users")
    def users(request):
        raise KeyError()

    request, response = app.test_client.get("/example/users")

    assert response.status == 500
    assert response.json == {"error": "KeyError('KeyError')"}

# Generated at 2022-06-12 09:04:57.425600
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    class ExceptionBp(ExceptionMixin, Blueprint):
        def _apply_exception_handler(self, handler):
            print(handler)

    bp = ExceptionBp('/')

    print(bp._future_exceptions)

    @bp.exception(ZeroDivisionError, ValueError)
    async def handle_error(request, exception):
        pass

    print(bp._future_exceptions)


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:05:03.566399
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            pass

    tm = TestExceptionMixin()
    assert len(tm._future_exceptions) == 0


    @tm.exception()
    def error_handler(handler):
        pass

    assert len(tm._future_exceptions) == 1
    e = tm._future_exceptions.pop()
    assert isinstance(e, FutureException)
    assert e.handler is error_handler
    assert e.args == tuple()

# Generated at 2022-06-12 09:05:09.146101
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def decorator(handler):
        return handler

    em = ExceptionMixin()
    em._apply_exception_handler = decorator

    def handler():
        pass

    em.exception(Exception)(handler)

    assert em._future_exceptions == {FutureException(handler, (Exception,))}

    @em.exception(Exception)
    def handler():
        pass

    assert em._future_exceptions == {FutureException(handler, (Exception,))}

# Generated at 2022-06-12 09:05:19.110211
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = []

        def _apply_exception_handler(self, handler):
            self._future_exceptions.append(handler)

    # test normal case
    mock_blueprint = MockExceptionMixin()
    @mock_blueprint.exception(Exception)
    def handle_exception(handler_exception):
        return handler_exception.exception_type.__name__
    assert handle_exception(Exception('test')) == 'Exception'
    assert mock_blueprint._future_exceptions == [FutureException(
        handle_exception, (Exception,))]

    # test class case
    mock_blueprint = MockExceptionMixin()

# Generated at 2022-06-12 09:05:20.437832
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    ExceptionMixin("test").exception("Exception")

# Generated at 2022-06-12 09:05:25.130317
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.models.blueprint import Blueprint

    class MyBlueprint(Blueprint):
        pass

    app = Sanic()
    bp = MyBlueprint(__name__, url_prefix='/test/')
    bp.exception(Exception)(lambda: True)
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:06:33.994133
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock
    from sanic.response import HTTPResponse

    blueprint_mock = Mock()
    blueprint_mock.name = "blueprint_mock"
    blueprint_mock.exception = ExceptionMixin.exception.__get__(blueprint_mock)

    assert blueprint_mock._future_exceptions == set()

    @blueprint_mock.exception(Exception)
    def exception_handler(request, exc):
        return HTTPResponse(text=exc)

    assert blueprint_mock._future_exceptions
    assert len(blueprint_mock._future_exceptions) == 1

    blueprint_mock._apply_exception_handler = Mock()
    blueprint_mock._apply_exception_handler.return_value = "handler"

    blueprint_

# Generated at 2022-06-12 09:06:38.067868
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exc = TestClass()
    assert len(exc._future_exceptions) == 0
    @exc.exception(AssertionError)
    def _handle_exc(exc):
        pass
    assert len(exc._future_exceptions) == 1

# Generated at 2022-06-12 09:06:42.936454
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Foo(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass
    foo = Foo()
    @foo.exception(1,2,3)
    def bar():
        return 'bar'

    fe = FutureException(bar, (1,2,3))
    assert fe == list(foo._future_exceptions)[0]

# Generated at 2022-06-12 09:06:43.627114
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 09:06:48.220878
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Dummy(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    dummy = Dummy()

    @dummy.exception(Exception, apply=True)
    def handle_exception(request, exception):
        pass

    assert len(dummy._future_exceptions) == 1

# Generated at 2022-06-12 09:06:55.360829
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import Mock
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    bp = Blueprint('name', url_prefix='/prefix')
    app = Sanic()

    @bp.exception(ValueError)
    def handler1(request, exception):
        Mock()
    handler1.__name__ = 'handler1'

    assert bp._future_exceptions == {FutureException(handler1, ({ValueError},))}

    @bp.exception([ValueError, TypeError])
    def handler2(request, exception):
        Mock()
    handler2.__name__ = 'handler2'

    assert bp._future_exceptions == {
        FutureException(handler1, ({ValueError},)),
        FutureException(handler2, ({ValueError, TypeError},))
    }



# Generated at 2022-06-12 09:06:57.766545
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinExtended(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return None

    exception_mixin = ExceptionMixinExtended()
    exception_mixin.exception([Exception])

# Generated at 2022-06-12 09:07:05.306622
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for method exception of class ExceptionMixin.
    """

    arguments = {
        'args': [Exception],
        'apply': True
    }

    future_exception = FutureException(handler=Exception, exceptions=Exception)
    expected_output = {
        future_exception
    }

    # mock class Blueprint
    Blueprint = Blueprint('route', url_prefix='prefix')

    # mock class ExceptionMixin
    ExceptionMixin_mock = ExceptionMixin(Blueprint, 'url_prefix', 'name')
    ExceptionMixin_mock._future_exceptions.add(future_exception)

    # mock method handler(*args, **kwargs)
    def handler(*args, **kwargs):
        pass


# Generated at 2022-06-12 09:07:10.809284
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        return exception

    assert test_exception_mixin._future_exceptions

# Generated at 2022-06-12 09:07:15.803165
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Note: now ExceptionMixin has been used by Blueprint and Sanic class, therefore
    # we create a dummy class including ExceptionMixin.
    class DummyExceptionMixin(ExceptionMixin):
        pass
    dummy = DummyExceptionMixin()
    # Because dummy doesn't have self._apply_exception_handler method,
    # a NotImplementedError will be raised here.
    with pytest.raises(NotImplementedError):
        dummy.exception(Exception)(print)