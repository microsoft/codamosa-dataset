

# Generated at 2022-06-12 08:59:11.202769
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    bp = Blueprint('bp', url_prefix='/bp')
    app = Sanic(__name__)

    @bp.exception(Exception)
    def handle_exception(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    exception = bp._future_exceptions.pop()
    assert isinstance(exception, FutureException)
    assert exception.handler == handle_exception
    assert exception.exceptions == (Exception,)
    assert exception.kwargs == {}

# Generated at 2022-06-12 08:59:15.071782
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeBlueprint(ExceptionMixin):
        pass

    fb = FakeBlueprint()
    assert fb._future_exceptions == set()
    fb.exception(Exception)(print)
    assert len(fb._future_exceptions) == 1
    
    

# Generated at 2022-06-12 08:59:20.129889
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import NotFound
    exception_mixin = ExceptionMixin()
    assert not exception_mixin._future_exceptions
    exception_mixin.exception(NotFound)(lambda x: None)
    assert len(exception_mixin._future_exceptions) == 1
    future_exception = exception_mixin._future_exceptions.pop()
    assert isinstance(future_exception, FutureException)
    assert future_exception.exceptions == (NotFound,)

# Generated at 2022-06-12 08:59:28.173311
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test")

    # TODO: Need a better mock library
    class MockException1(Exception):
        pass

    class MockException2(Exception):
        pass

    @bp.exception([MockException1, MockException2])
    def e_handler(*args, **kwargs):
        pass

    assert len(bp._future_exceptions) == 1

    future_exception = list(bp._future_exceptions)[0]
    assert future_exception.handler == e_handler
    assert future_exception.exceptions == (MockException1, MockException2)

# Generated at 2022-06-12 08:59:31.324491
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Given
    from sanic.blueprints import Blueprint

    bp = Blueprint.exception_handler(None)
    bp.exception(Exception)

    # When
    # Then
    assert bp._future_exceptions == {FutureException(None, (Exception,))}

# Generated at 2022-06-12 08:59:34.267420
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic

    app = Sanic('test_ExceptionMixin_exception')

    # Test method exception() of class ExceptionMixin
    @app.exception(Exception)
    def handlerException(request, exception):
        return "exception"

    # Check run method
    request, response = app.test_client.get('/')
    assert response.text == "exception"



# Generated at 2022-06-12 08:59:38.515146
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class X(ExceptionMixin):
        pass
    
    x = X()

    def exception_handler(request, exception):
        pass

    x.exception(exception_handler, [Exception])

    assert len(x._future_exceptions) == 1

    class E:
        pass

    assert not x._future_exceptions.pop().matches(E)
    assert x._future_exceptions.pop().matches(Exception)

# Generated at 2022-06-12 08:59:44.956182
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.remove(handler)

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler1(request, exception):
        pass

    @test_exception_mixin.exception([Exception])
    def test_handler2(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 2

# Generated at 2022-06-12 08:59:52.347092
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        @ExceptionMixin.exception(Exception)
        def handler(self, request, exception):
            return exception
    
    blueprint = Blueprint()
    assert blueprint.handler
    assert blueprint._future_exceptions
    assert blueprint._future_exceptions == {FutureException(handler = blueprint.handler, exceptions = (Exception,))}

# Generated at 2022-06-12 09:00:00.218003
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Create a fake blueprint
    class Blueprint:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

    blueprint = Blueprint()

    # Apply method
    handler = ExceptionMixin.exception(
        blueprint, [ZeroDivisionError, FileNotFoundError]
    )

    # Create a fake request
    class Request:
        pass
    request = Request()

    # Apply function handler
    handler(request)

    # Check result
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-12 09:00:07.304341
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.router import _RuleTemplate
    from sanic.routing import Rule
    handler = ExceptionMixin()
    rule = Rule(template=_RuleTemplate("/route"), methods={'GET'})
    decorator = handler.exception()(rule)
    assert rule == decorator
    future_exception = handler._future_exceptions[0]
    assert future_exception.handler == rule

# Generated at 2022-06-12 09:00:12.099831
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            self._future_exceptions = set()
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            raise NotImplementedError

    def mock_handler():
        pass

    with pytest.raises(NotImplementedError):
        MockExceptionMixin().exception(ValueError)(mock_handler)

# Generated at 2022-06-12 09:00:14.477072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__)
    assert blueprint.exception(NotImplementedError)



# Generated at 2022-06-12 09:00:18.150349
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_ExceptionMixin_exception')
    blueprint.exception(Exception)(lambda request, exception: None)
    assert blueprint._future_exceptions

# Generated at 2022-06-12 09:00:19.517717
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert issubclass(ExceptionMixin, object)


# Generated at 2022-06-12 09:00:28.833305
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test with correct diffrent input type
    exp = BaseException()
    bp = Blueprint("test", url_prefix="/test")

    @bp.exception(TypeError)
    async def handle_error(request, exception):
        return text("Exception: " + str(exception))
    
    assert bp._future_exceptions
    assert bp._future_exceptions[0].handler.__name__ == "handle_error"

    @bp.exception([TypeError, ValueError])
    async def handle_error(request, exception):
        return text("Exception: " + str(exception))

    assert bp._future_exceptions[1].handler.__name__ == "handle_error"


# Generated at 2022-06-12 09:00:40.206430
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic, Blueprint
    from sanic.response import json
    from unittest import TestCase

    app = Sanic('test_sanic_bp_exception_handler')
    bp = Blueprint('test_bp')
    @bp.exception([ValueError])
    def exception_handler(request, exception):
        return json({'error': exception})
    @bp.route('/')
    def handler(request):
        raise ValueError('ValueError')
    app.blueprint(bp)

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.json.get('error') == 'ValueError'


# Generated at 2022-06-12 09:00:47.732308
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text
    
    bp = Blueprint("test")

    @bp.exception(ServerError)
    def handle_exception(request, exception):
        return text("Internal server error", status=500)

    bp.name = "test"
    bp.error_handler_spec = {"ServerError":[handle_exception]}
    exception_list = bp.exception_list
    assert exception_list[0].handler == handle_exception
    assert exception_list[0].exceptions == (ServerError,)
    assert exception_list[0].exceptions is not (ServerError,)

# Generated at 2022-06-12 09:00:53.640601
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_mixin = TestExceptionMixin()

    @test_mixin.exception(Exception, apply=False)
    def exception_handler(request, exception):
        pass

    assert len(test_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:00:56.963484
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint:
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    bp = Blueprint()
    bp.exception(Exception, Exception)

# Generated at 2022-06-12 09:01:09.148691
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    my_bp = Blueprint(name="My_bp")

    def handler():
        raise ValueError

    def handle_exception():
        raise ValueError

    my_bp.exception(ValueError)(handler)
    assert my_bp.exception(ValueError).__name__ == "decorator"

    my_bp.exception(ValueError)(handle_exception)
    assert my_bp.exception(ValueError)(handle_exception).__name__ == "handle_exception"
    assert my_bp._future_exceptions[0].handler.__name__ == "handler"
    assert my_bp._future_exceptions[1].handler.__name__ == "handle_exception"
    assert len(my_bp._future_exceptions) == 2

# Generated at 2022-06-12 09:01:19.479594
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def exception():
        from sanic.blueprints import Blueprint
        from sanic.models.futures import FutureException
        from sanic.views import HTTPMethodView

        class A(ExceptionMixin, HTTPMethodView):
            def get(self):
                pass

        bp = Blueprint('bp')
        bp.add_route(A.as_view(), '/', methods=["GET"])

        bp.get('/').status_code == 200; assert bp._future_exceptions == set()

        try:
            bp.exception(Exception)(lambda x: x)
        except NotImplementedError:
            pass

        try:
            bp.exception(Exception, apply=False)(lambda x: x)
        except NotImplementedError:
            pass

        assert bp._future

# Generated at 2022-06-12 09:01:20.347452
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
  pass

# Generated at 2022-06-12 09:01:29.319193
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    from unittest.mock import Mock

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler):
            return True

    test_mixin = TestExceptionMixin()

    def func():
        pass

    func.__name__ = 'test_func'
    func = test_mixin.exception(Exception)(Mock())

    for future_exception in test_mixin._future_exceptions:
        assert isinstance(future_exception, FutureException)
        assert future_exception.handler == Mock()
        assert isinstance(future_exception.exceptions, tuple)
        assert future_exception.exceptions == (Exception,)

    return True

# Generated at 2022-06-12 09:01:35.275812
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test the exception if exceptions is None
    # assert exception(None)
    # print("Test exception(None): passed")

    # Test the exception if apply is False
    # assert exception(None, apply=False)
    # print("Test exception(None, apply=False): passed")

    # Test the exception if exception is a tuple
    # assert exception( (None) )
    # print("Test exception( (None) ): passed")

    # Test the exception if exception is a list
    # assert exception( [None] )
    # print("Test exception( [None] ): passed")
    pass

test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:01:43.921856
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test for method exception of class ExceptionMixin
    """
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint
    from unittest.mock import Mock
    from unittest.mock import MagicMock

    def exception_handler(*args):
        return args

    blueprint = Blueprint('test', url_prefix='/test/')
    assert not blueprint._future_exceptions
    blueprint.exception(apply=False)(exception_handler)
    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(),
                      FutureException)
    mock = Mock()
    mock.attach_mock(MagicMock(side_effect=Exception), '_apply_exception_handler')

# Generated at 2022-06-12 09:01:45.262792
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert True

# Generated at 2022-06-12 09:01:54.383635
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    future_exception = FutureException(Exception, Exception)
    future_exceptions = set()

    class TestExceptionMixin:
        def __init__(self):
            self._future_exceptions = future_exceptions

        def _apply_exception_handler(self, handler: FutureException):
            nonlocal future_exception
            nonlocal future_exceptions

            future_exception = handler

            assert handler is not None
            assert handler in future_exceptions

    e = TestExceptionMixin()

    assert e._future_exceptions == set()

    @e.exception(Exception)
    def exception():
        pass

    assert e._future_exceptions == {future_exception}

    assert future_exception.handler == exception
    assert future_exception.exceptions == (Exception,)

test_ExceptionMixin_ex

# Generated at 2022-06-12 09:02:02.349799
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._exception_handlers = {}
            super().__init__(args, kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self._exception_handlers.update({type(handler): handler})

    global_exception = TestExceptionMixin()
    @global_exception.exception(Exception)
    def exception_handler(request, exception):
        return None

    assert len(global_exception._future_exceptions) == 1
    assert len(global_exception._exception_handlers) == 1



# Generated at 2022-06-12 09:02:03.221521
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    raise NotImplementedError  # noqa

# Generated at 2022-06-12 09:02:20.516930
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.exceptions import SanicException

    class TestException(SanicException):
        pass

    app = Sanic('test_ExceptionMixin_exception')
    test_bp = Blueprint('test_bp', url_prefix='test1')

    @test_bp.exception((TestException,))
    def process_exception1(request, exception):
        pass

    @test_bp.exception((TestException,))
    def process_exception2(request, exception):
        pass

    @test_bp.exception((TestException,), apply=False)
    def process_exception3(request, exception):
        pass

    assert process_exception1 in test_bp.handler_functions.values()

# Generated at 2022-06-12 09:02:28.220248
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    with pytest.raises(NotImplementedError):
        ExceptionMixin().exception()

    # Sanic instance
    app = Sanic(name=__name__)

    @app.exception(IndexError)
    def exception_handler_with_exception_as_parameter(request, exception):
        return text("Exception handler with one exception as parameter")

    # Sanic blueprint
    bp = Sanic.blueprint(name=__name__)

    @bp.exception(IndexError)
    def exception_handler_with_exception_as_parameter_in_blueprint(
        request, exception
    ):
        return text("Exception handler with one exception as parameter in"
                    "blueprint")

    app.blueprint(bp)

    # Test if the exception handler work

# Generated at 2022-06-12 09:02:33.860453
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class UnitTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    test = UnitTest()
    def test_handler(request, exception):
        return "test_handler"

    test.exception(ValueError)(test_handler)
    assert test._future_exceptions == {FutureException(test_handler, (ValueError,))}

# Generated at 2022-06-12 09:02:43.908217
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Case 1: test with no exception handler
    # mock an object
    class BlueprintMock:
        def __init__(self):
            self._future_exceptions = set()
    # mock object of ExceptionMixin
    mixin = ExceptionMixin()

    try:
        # call method exception
        mixin.exception(CallbackMock)
    except:
        assert True
    else:
        assert False
    # Case 2: test with one exception handler and one exception
    # mock an object
    class BlueprintMock:
        def __init__(self):
            self._future_exceptions = set()
    # mock object of ExceptionMixin
    mixin = ExceptionMixin()

    # mock a callback function
    class CallbackMock:
        def __init__(self):
            self._exc_info = None
   

# Generated at 2022-06-12 09:02:46.936423
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(Exception)
    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._future_exceptions[0].handler == Exception

# Generated at 2022-06-12 09:02:52.592856
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    from exception_mixin import ExceptionMixin
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exception_mixin = ExceptionMixinTest()
    global_exceptions = (Exception,)
    apply = True

    # Act and Assert
    exception_mixin.exception(*global_exceptions, apply=apply)

# Generated at 2022-06-12 09:03:01.796680
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()
            self.applied_exception = None

        def _apply_exception_handler(self, handler: FutureException):
            self.applied_exception = handler
            return

    def test_handler():
        pass

    m = TestExceptionMixin()
    m.exception(test_handler)
    assert len(m._future_exceptions) == 1
    assert isinstance(m._future_exceptions.pop(), FutureException)
    assert isinstance(m.applied_exception, FutureException)
    assert m.applied_exception.handler == test_handler


if __name__ == '__main__':
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:03:02.952373
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass


# Generated at 2022-06-12 09:03:08.275573
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ApplicationException(ExceptionMixin):
        pass
    app = ApplicationException()
    assert not app._future_exceptions
    # test
    app.exception(Exception, apply=True)(lambda : 1)
    assert len(app._future_exceptions) == 1
    # test exception
    with pytest.raises(NotImplementedError):
        app._apply_exception_handler(None)

# Generated at 2022-06-12 09:03:14.726916
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            pass
    
    blueprint = Blueprint()

    # Test for the exception without any parameters
    @blueprint.exception()
    def exception():
        pass
    blueprint._future_exceptions.pop().handler()

    # Test for the exception with parameters
    @blueprint.exception(ValueError, x=3)
    def exception():
        pass
    # TODO: Checking the exception
    # blueprint._future_exceptions.pop().handler()

    # Test for the exception without any parameters and without apply flag
    @blueprint.exception(apply=False)
    def exception():
        pass
    #

# Generated at 2022-06-12 09:03:38.874961
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json
    from sanic.blueprints import Blueprint
    from sanic.views import HTTPMethodView
    from sanic.constants import HTTP_METHODS
    
    bp = Blueprint("bp_exception_test")
    
    bp.exception(IndexError)(
        lambda request, exception: json({
            "error": str(exception),
            "message": "An index error occurred"
        }, status=500))


# Generated at 2022-06-12 09:03:45.796967
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            assert isinstance(handler, FutureException)
            assert handler.exceptions == {'a'}
            assert handler.handler == 10
            assert handler.kwargs == {'a':1}

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(['a'], a=1)
    def test_exception():
        return 1
    assert test_exception() == 1
    return True

# Generated at 2022-06-12 09:03:50.728565
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic_openapi import doc

    class Foo(ExceptionMixin):
        pass

    foo = Foo()

    @foo.exception(Exception)
    def exception_handler(request, exception):
        return "exception_handler is called."

    assert len(foo._future_exceptions) == 1
    assert (exception_handler in list(foo._future_exceptions)[0].handler.handlers)

# Generated at 2022-06-12 09:03:53.609367
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('test_blueprint', url_prefix='/test')
    e_mixin = ExceptionMixin()
    assert hasattr(e_mixin, 'exception')
    assert isinstance(e_mixin.exception, types.MethodType)

# Generated at 2022-06-12 09:03:56.873509
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class test(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions = [handler]

    a = test()
    @a.exception(Exception)
    def my_func(req, res):
        pass
    assert my_func in a._future_exceptions

# Generated at 2022-06-12 09:04:06.247997
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super(ExceptionMixin, self).__init__()

        def _apply_exception_handler(self, handler: FutureException):
            return

    # Test with and without custom kwargs
    testExceptionMixin = TestExceptionMixin()
    @testExceptionMixin.exception(ValueError)
    def exception_handler():
        return

    # Test on the exception handler
    assert(exception_handler)

    # Test on the number of FutureException objects
    assert(len(testExceptionMixin._future_exceptions) == 1)

    # Test on the first object of the set
    futureException_ = testExceptionMixin._future_exceptions.pop()

    # Test on the handler attribute
    assert(futureException_.handler == exception_handler)

# Generated at 2022-06-12 09:04:09.927181
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    app = Blueprint("Test")
    @app.exception(ValueError)
    def handler(request, exceptions):
        return "OK"

    assert len(app._future_exceptions) == 1
    assert app._future_exceptions.pop().handler == handler

# Generated at 2022-06-12 09:04:12.104891
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    @exception()
    def handler(request, exception):
        return request

    @exception(ValueError)
    def handler(request, exception):
        return request

    assert handler.__name__ == 'handler'

# Generated at 2022-06-12 09:04:14.210646
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()
    decorated_handler = exception_mixin.exception(ValueError)(handler)
    assert decorated_handler == handler
    exception_mixin.exception(ValueError)(handler)
    assert len(exception_mixin._future_exceptions) == 1


# Generated at 2022-06-12 09:04:20.205035
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        _apply_exception_handler = NotImplemented

    test_mode = TestExceptionMixin()
    @test_mode.exception(BaseException, apply=False)
    def ExceptionHandler():
        print("base")

    assert(len(test_mode._future_exceptions) == 1)
    assert(ExceptionHandler in test_mode._future_exceptions)

    @test_mode.exception([Exception, ValueError], apply=False)
    def ExceptionHandler2():
        print("comprehension")
    
    assert(len(test_mode._future_exceptions) == 2)
    assert(ExceptionHandler2 in test_mode._future_exceptions)

# Generated at 2022-06-12 09:04:55.309403
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    '''
    Unit test function for the method "exception" of class ExceptionMixin
    '''
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic import Sanic

    app = Sanic()
    bp = Blueprint('test')

    @bp.exception(ZeroDivisionError)
    def zero_division(request, exception):
        return text('zero division')

    @app.route('/')
    def test(request):
        return 1 / 0

    app.blueprint(bp)
    request, response = app.test_client.get('/')
    assert response.status == 500
    assert response.text == 'zero division'

# Generated at 2022-06-12 09:05:00.081528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    testapp = Blueprint.testapp()

    @testapp.exception(ZeroDivisionError)
    def test1(request, exception):
        return text("test1")
    
    @testapp.exception([ZeroDivisionError, TypeError])
    def test2(request, exception):
        return text("test2")

    assert test1.__name__ == "test1"
    assert test2.__name__ == "test2"

# Generated at 2022-06-12 09:05:08.823561
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import Forbidden, NotFound
    from sanic.blueprints import Blueprint

    bp = Blueprint("test", url_prefix="/test")

    @bp.exception(Forbidden)
    def custom_forbidden(request, exception):
        pass

    @bp.exception(apply=False)([NotFound, KeyError])
    def custom_not_found(request, exception):
        pass

    assert len(bp._future_exceptions) == 2

    for future_exception in bp._future_exceptions:
        if isinstance(future_exception.exceptions[0], Forbidden):
            assert future_exception.handler == custom_forbidden
        elif isinstance(future_exception.exceptions[0], NotFound):
            assert future_exception.handler == custom_not_found

# Generated at 2022-06-12 09:05:16.015844
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self.count = 0
        
        def _apply_exception_handler(self, handler):
            self.count += 1
    
    test = ExceptionMixinTest()
    exception_handler = test.exception(NotImplementedError, apply = False)
    assert len(test._future_exceptions) == 1
    assert test.count == 0
    test.exception(NotImplementedError, apply = True)
    assert test.count == 1

# Generated at 2022-06-12 09:05:22.385670
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sanic.blueprint
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    args = []
    kwargs = {}

    exception_mixin = TestExceptionMixin(*args, **kwargs)
    assert(isinstance(exception_mixin, TestExceptionMixin))

    @exception_mixin.exception()
    def test_exception_handler():
        pass
    assert(test_exception_handler() is None)

# Generated at 2022-06-12 09:05:26.460981
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    t = TestExceptionMixin()
    @t.exception(ValueError, apply = True)
    def test_method(request, exception):
        return "test"
    assert t._future_exceptions.pop().handler.__name__ == test_method.__name__




# Generated at 2022-06-12 09:05:33.003951
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic()

    bp = Blueprint('bp', url_prefix='/bp', version=1)

    # Check exception handler with apply = True
    @bp.exception(Exception)
    def bp_exception_handler(request, exception):
        return 'This is an exception'

    assert bp.has_exception_handler(Exception) == True

    @bp.route('/test', methods=['GET'])
    async def test(request):
        return 'This is a test func'

    app.blueprint(bp)
    request, response = app.test_client.get('/bp/test')
    assert response.status == 200
    assert response.text == 'This is a test func'

    request, response = app.test_

# Generated at 2022-06-12 09:05:35.945849
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    TestExceptionMixin().exception(Exception)(print)

# Generated at 2022-06-12 09:05:42.592791
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Test method exception of class ExceptionMixin
    """
    from sanic.blueprints import Blueprint

    class TestBlueprint(Blueprint, ExceptionMixin):
        def __init__(self, *_args, **_kwargs):
            pass

    bp = TestBlueprint()
    assert isinstance(bp._future_exceptions, set)

    @bp.exception(BaseException, apply=False)
    def handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert id(handler) == id(bp._future_exceptions.pop().handler)

    exception_list = [TypeError, ValueError]
    @bp.exception(*exception_list)
    def handler2(request, exception):
        pass


# Generated at 2022-06-12 09:05:50.484719
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from .Blueprint import Blueprint
    from .Blueprint import BlueprintGroup
    from .Blueprint import BlueprintSetupState

    blueprint = Blueprint('name', '/prefix')
    blueprint.setup_state = BlueprintSetupState.GLOBAL
    blueprint.url_prefix = ''
    blueprint._blueprint_group = BlueprintGroup()
    blueprint.name = 'sanic_main'
    blueprint.group.host = None
    blueprint.host = None
    blueprint.host_matching = True

    def test_func(request, *args, **kwargs):
        return True

    future_exception = blueprint.exception([Exception])(test_func)

    assert future_exception.handler == test_func
    assert future_exception.exceptions == (Exception,)

# Generated at 2022-06-12 09:06:59.786789
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ClassA(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class ClassB(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @ClassA.exception(Exception, apply=False)
    def throw_exception():
        raise Exception()

    @ClassB.exception(Exception, apply=True)
    def throw_exception_and_apply():
        raise Exception()

    ClassA.throw_exception()
   

# Generated at 2022-06-12 09:07:08.989268
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic import exceptions

    app = Sanic('test_ExceptionMixin_exception')
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(Blueprint, self).__init__(*args, **kwargs)
    
    blueprint = Blueprint(__name__)

    @blueprint.exception(exceptions.FileNotFound)
    async def handler(request, exception): pass

    @blueprint.exception([exceptions.InvalidUsage, exceptions.FileNotFound])
    async def handler2(request, exception): pass

    exception: FutureException = blueprint._future_exceptions.pop()
    assert exception.name == 'handler'
    assert exception.exceptions[0] == exceptions.FileNotFound
    assert exception.ex

# Generated at 2022-06-12 09:07:17.509959
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint
    from sanic.response import json
    from sanic.views import CompositionView

    bp = Blueprint('test', url_prefix='test2')
    bp.route('/')(lambda r: r)

    @bp.exception(Exception)
    def test(request, exception):
        return json({'exception': 'occurred'})

    @bp.route('/exception', methods=['GET'])
    def exception(request):
        raise Exception('test')

    assert len(bp.exception_handlers) == 1
    assert isinstance(bp.exception_handlers[0], FutureException)
    assert bp.exception_handlers[0].handler == test
    assert bp.exception_hand

# Generated at 2022-06-12 09:07:22.495908
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert len(self._future_exceptions) == 1
            assert handler == self._future_exceptions.pop()

    @Blueprint.exception(Exception)
    def handler(request, **kwargs):
        pass

    assert len(Blueprint._future_exceptions) == 0



# Generated at 2022-06-12 09:07:26.883122
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from mini_lambda import Lambda, x, y
    from sanic import Blueprint

    blueprint = Blueprint("test")
    blueprint.exception(Exception)

    @blueprint.route("/")
    def test(request):
        return "Hello"

    blueprint(Lambda(x + y), Lambda(x + y))

    assert str(blueprint) == 'Blueprint("test")'

# Generated at 2022-06-12 09:07:33.892359
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    blueprint = Blueprint('blueprint', url_prefix='/blueprint')

    # Unit test for exception decorator with one exception type
    @blueprint.exception(IOError)
    def handler(*args, **kwargs):
        pass

    @blueprint.exception([IOError])
    def handler_list(*args, **kwargs):
        pass

    assert len(blueprint._future_exceptions) == 2
    assert len(blueprint._future_exceptions_apply) == 0
    assert len(blueprint._future_exceptions_factory) == 0

    assert blueprint._future_exceptions_apply == set()


# Generated at 2022-06-12 09:07:42.359289
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Http(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler

    # case 1:
    #   apply = True and exceptions = (Exception)
    http = Http()
    @http.exception(Exception)
    def handler():
        pass
    assert handler == http.handler.handler

    # case 2:
    #   apply = False and exceptions = (Exception)
    http = Http()
    @http.exception(Exception, apply=False)
    def handler2():
        pass
    assert http.handler is None

    # case 3:
    #   apply = True and exceptions = ([Exception])
    http = H

# Generated at 2022-06-12 09:07:50.060900
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler):
            pass

    try:
        TestExceptionMixin().exception()(lambda: None)
    except TypeError as e:
        assert str(e) == 'exception() missing 1 required positional argument: \'exceptions\''
    else:
        assert False

    TestExceptionMixin().exception(Exception)(lambda: None)
    TestExceptionMixin().exception(Exception, Exception)(lambda: None)
    TestExceptionMixin().exception([Exception])

# Generated at 2022-06-12 09:07:54.733090
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(Exception)
    def handler(request, exception):
        return response.text('foo')

    app = Sanic('test_ExceptionMixin_exception')
    app.blueprint(blueprint)

    request, response = app.test_client.get('/test/user/15')
    assert response.text == 'foo'

# Generated at 2022-06-12 09:07:59.693916
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import HTTPMethodView
    from sanic import Sanic

    app = Sanic(__name__)

    blueprint = Blueprint('test_bp', url_prefix='/bp')

    class ExceptionView(ExceptionMixin, HTTPMethodView):
        decorators = [blueprint.exception(Exception)]

        def get(self, request):
            return text('OK')

    blueprint.add_route(ExceptionView.as_view(), '/')
    app.blueprint(blueprint)