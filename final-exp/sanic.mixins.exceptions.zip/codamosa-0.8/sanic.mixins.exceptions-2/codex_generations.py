

# Generated at 2022-06-12 08:59:04.375953
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # write your code here
    pass



# Generated at 2022-06-12 08:59:14.369522
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    test_bp = Blueprint('test')

    @test_bp.exception(Exception)
    def ex1(request, exception):
        pass

    assert len(test_bp._future_exceptions) == 1
    assert isinstance(test_bp._future_exceptions.pop(), FutureException)

    @test_bp.exception([Exception, Exception])
    def ex2(request, exception):
        pass

    assert len(test_bp._future_exceptions) == 2
    assert isinstance(test_bp._future_exceptions.pop(), FutureException)
    assert isinstance(test_bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-12 08:59:23.638016
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.views import HTTPMethodView

    class MyView(ExceptionMixin, HTTPMethodView):
        def get(self, request):
            return text('I am get method')

        def post(self, request):
            return text('I am post method')

    view = MyView.as_view()
    app = Sanic('test_ExceptionMixin')

    @app.exception(Exception)
    def exception_handler(request, exception):
        return text('I am error handler', 500)

    @view.exception(Exception)
    def exception_handler(request, exception):
        return text('I got exception: %s'%exception, 500)

    request, response = app.test_client.get('/')

    assert response.text == 'I am get method'

# Generated at 2022-06-12 08:59:35.169467
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import os
    import sys
    import unittest
    from unittest import mock
    current_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, current_dir + "/../../")
    from sanic.models.exception_mixin import ExceptionMixin
    from sanic.models.futures import FutureException

    class TestExceptionMixin(ExceptionMixin):

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_mixin = TestExceptionMixin()

    @test_mixin.exception()
    def handler():
        pass

    assert len(test_mixin._future_exceptions) == 1
    exception = test_mixin._future_exceptions.pop()
    assert exception.handler == handler

# Generated at 2022-06-12 08:59:36.129246
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 08:59:42.010707
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import abort

    class TestException(Exception):
        pass

    bp = Blueprint("bp")

    @bp.exception(TestException)
    def handler(request, exception):
        return abort(500)

    @bp.route("/")
    async def hello(request):
        raise TestException()

    app = bp.as_app()

    request, response = app.test_client.get("/")

    assert response.status == 500
    assert response.text == "Internal Server Error"

# Generated at 2022-06-12 08:59:50.142416
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import ServerError
    from sanic.blueprints import Blueprint

    class MyBlueprint(ExceptionMixin, Blueprint):
        pass

    my_blueprint = MyBlueprint(name='my_bp')

    async def my_exception_handler(request, exception):
        print(exception)

    my_blueprint.exception(ServerError)(my_exception_handler)

    assert len(my_blueprint._future_exceptions) == 1

    exception = my_blueprint._future_exceptions.pop()
    assert exception.exception_types == (ServerError,)
    assert exception.handler == my_exception_handler

# Generated at 2022-06-12 08:59:58.803368
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.base import Sanic
    from sanic.blueprints import Blueprint

    blueprint1 = Blueprint("test")

    class TestException(BaseException):
        pass

    # create a Blueprint and add exception handler
    @blueprint1.exception(TestException)
    def exception_handler(request, exception):
        return response.text("runtime TestException occurs")

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(blueprint1)

    @app.route("/")
    def handler(request):
        raise TestException("test")

    request, response = app.test_client.get("/")
    assert response.text == "runtime TestException occurs"



# Generated at 2022-06-12 08:59:59.849494
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert False, "TODO: Implement"

# Generated at 2022-06-12 09:00:09.616560
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        pass
    blueprint = Blueprint()
    @blueprint.exception(RuntimeError, apply=True)
    def exception_handler1(request, exception):
        print("Showing custom 500 error page for general errors")
        import builtins
        builtins.response_code = 500
        return response.html('Internal Server Error')

    @blueprint.exception(RuntimeError, apply=True)
    def exception_handler2(request, exception):
        print("Showing custom 500 error page for general errors")
        import builtins
        builtins.response_code = 500
        return response.html('Internal Server Error')
        
    assert exception_handler1 in blueprint._future_exceptions
    assert exception_handler2 in blueprint._future_exceptions

# Generated at 2022-06-12 09:00:21.943902
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.bluerprint import Blueprint
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    from sanic.models.futures import FutureException
    from sanic import response
    import pytest
    class HTTPMethodView1(HTTPMethodView):
        def __init__(self):
            sanic = Sanic("name")
            blueprint = Blueprint("name", url_prefix="/")
            blueprint.add_route(self.get, '/', methods=['GET'])
            blueprint.exception([ValueError])(self.handler)
            sanic.blueprint(blueprint)

        @staticmethod
        def get():
            raise ValueError()


# Generated at 2022-06-12 09:00:32.675729
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    import pytest

    class MockHTTPMethodView(HTTPMethodView):
        class _ExceptionMixin:
            def __init__(self, *args, **kwargs):
                self._future_exceptions: Set[FutureException] = set()

        def exception(self, *exceptions, apply=True):
            def decorator(handler):
                nonlocal apply
                nonlocal exceptions

                if isinstance(exceptions[0], list):
                    exceptions = tuple(*exceptions)

                future_exception = FutureException(handler, exceptions)
                self._future_exceptions.add(future_exception)
                if apply:
                    self._ExceptionMixin._apply_exception_

# Generated at 2022-06-12 09:00:43.921411
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    def apply_exception_handler(_):
        pass

    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()
            self._apply_exception_handler = apply_exception_handler

    a = A()
    # Unit test: no args
    try:
        a.exception()
    except TypeError:
        pass
    else:
        assert False, 'exception method must throw TypeError when no args'
    # Unit test: valid args
    handler = lambda x: x
    a.exception(handler)
    assert a._future_exceptions.pop() == FutureException(handler, ())
    # Unit test: invalid args
    try:
        a.exception(*[0])
    except TypeError:
        pass

# Generated at 2022-06-12 09:00:49.583119
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint
    bp = Blueprint('test_ExceptionMixin_exception')
    ExceptionMixin.__init__(bp)
    try:
        @bp.exception(Exception)
        def exception_handler(request, exception):
            pass
        assert isinstance(bp._future_exceptions.pop(), FutureException)
    except Exception as e:
        print(e)
        raise e

# Generated at 2022-06-12 09:00:52.947009
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

    class TestException(Exception):
        pass

    def test_exception_handler():
        pass

    bp = TestExceptionMixin()
    test_handler = bp.exception(ValueError, TestException)(test_exception_handler)
    assert test_handler in bp._future_exceptions

# Generated at 2022-06-12 09:00:57.502709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    blueprint_mock = Blueprint_Mock()
    blueprint_mock.name = "test_name"
    blueprint_mock._apply_exception_handler = MagicMock()

    # Act
    exception_handler = blueprint_mock.exception(ValueError)
    exception_handler(object)

    # Assert
    assert blueprint_mock._future_exceptions
    assert len(blueprint_mock._future_exceptions) == 1


# Generated at 2022-06-12 09:01:07.692151
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic import Blueprint
    app = Sanic(__name__)
    bp = Blueprint('bp1')

    # Test exception decorator with args and apply

    @bp.exception(Exception, apply=True)
    def handler(request, exception):
        return None  # noqa

    assert len(bp._future_exceptions) == 1

    assert isinstance(bp._future_exceptions, set)

    assert next(iter(bp._future_exceptions)).handler == handler

    assert next(iter(bp._future_exceptions)).exceptions == (Exception,)

    # Test exception decorator with args and apply

    @bp.exception(Exception)
    def handler(request, exception):
        return None  # noqa

    assert len(bp._future_exceptions) == 2


# Generated at 2022-06-12 09:01:18.170340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import register_exception

    class MyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exceptions_registered = []

        def _apply_exception_handler(self, handler: FutureException):
            self.exceptions_registered.append(handler)

    class MyException(Exception):
        pass

    mixin = MyExceptionMixin()
    mixin.exception(MyException)(handler=lambda req, resp: resp)
    assert len(mixin.exceptions_registered) == 1

    exception_mapping = register_exception(MyException)
    assert exception_mapping[3] == MyExceptionMixin.exceptions_registered[0].handler

# Generated at 2022-06-12 09:01:20.034596
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    mixin = ExceptionMixin()
    @exception_decorator
    def handler():
        pass
    assert True

# Generated at 2022-06-12 09:01:26.418284
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException

    class TestException(Exception):
        pass

    class TestClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    def raise_exception(request, e):
        raise e

    @TestClass.exception(TestException)
    def my_handler(request, exception):
        pass

    assert len(TestClass._future_exceptions) == 1
    assert my_handler == TestClass._future_exceptions.pop()

# Generated at 2022-06-12 09:01:35.133638
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.exceptions import SanicException

    app = Sanic('exception_mixin_test')

    class FooException(SanicException):
        def __init__(self):
            super().__init__(
                'This is my foo error.', status_code=407
            )
            self.name = 'foo_exception'

    @app.route('/')
    @app.exception(FooException)
    def handler(request, exception):
        return text('Exception was handled!')

    request, response = app.test_client.get('/')
    assert response.text == 'Exception was handled!'

# Generated at 2022-06-12 09:01:43.784258
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import pytest
    from sanic.models.futures import FutureException
    from sanic.config import EXCEPTION_HANDLER
    from sanic.exceptions import default_exception_handler

    # Arrange
    class CustomException(Exception):
        pass

    class SimpleExceptionMixin(ExceptionMixin):
        config = {
            EXCEPTION_HANDLER: default_exception_handler
        }
    
    simple_exception_mixin = SimpleExceptionMixin()
    def fake_apply_exception_handler(handler: FutureException):
        pass

    # Act
    simple_exception_mixin._apply_exception_handler = fake_apply_exception_handler

    @simple_exception_mixin.exception(apply=False)
    def handler_without_exception_args():
        pass

# Generated at 2022-06-12 09:01:49.908092
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        pass

    blueprint = Blueprint()
    blueprint._apply_exception_handler = (
        lambda future_exception: None
    )

    @blueprint.exception(IndexError)
    def handler(request, exception):
        pass

    future_exception = FutureException(handler, (IndexError,))
    assert future_exception in blueprint._future_exceptions

# Generated at 2022-06-12 09:01:58.293593
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self.args = args
            self.kwargs = kwargs
        def _apply_exception_handler(self, handler: FutureException) -> None:
            self.args = handler.args
            self.kwargs = handler.kwargs
            self.exceptions = handler.exceptions

    a = A()
    assert a._future_exceptions == set()

    @a.exception(apply=True)
    def f1():
        pass

    assert f1 == A().exception(apply=True)(f1)
    assert a._future_exceptions == {FutureException(f1, ())}
    assert a.exceptions == ()
    assert a.args is None
    assert a.kwargs is None



# Generated at 2022-06-12 09:02:04.825989
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blues import Blueprint

    blueprint = Blueprint('test_blueprint', url_prefix='test')
    blueprint.exception(ValueError)('handler')
    blueprint.exception([ValueError, TypeError])('handler')

    assert blueprint._future_exceptions

    blueprint = Blueprint('test_blueprint', url_prefix='test')
    blueprint.exception(ValueError)('handler', apply=False)
    blueprint.exception([ValueError, TypeError])('handler', apply=False)

    assert not blueprint._future_exceptions

# Generated at 2022-06-12 09:02:08.588497
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    sanic = Sanic()
    sanic.add_exception(Exception, lambda e: print('e'))
    assert len(sanic.exception_handlers[Exception]) == 1
    sanic.blueprint(endpoint_prefix='api')(lambda: sanic)
    assert sanic.blueprints['api'].exception(Exception)

# Generated at 2022-06-12 09:02:15.569240
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import ExceptionHandler

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            func_exception_handler = ExceptionHandler(
                                            handler.handler, exception=handler.exceptions)

        def exception_handler(self, request, exception):
            return 'test_exception_handler'

    exception_mixin = TestExceptionMixin()
    assert(exception_mixin.exception([ZeroDivisionError])(exception_mixin.exception_handler))

# Generated at 2022-06-12 09:02:19.552039
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    bp = Blueprint('bp')
    assert len(bp._future_exceptions) == 0

    @bp.exception(NotFound, apply=True)
    def handler(request, exception):
        return exception

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-12 09:02:27.720671
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    path = '/'

    # Create a mock object of class Sanic

    from sanic.app import Sanic
    sanic_object = Sanic('test_ExceptionMixin_exception')

    # Create a mock object of class Blueprint

    from sanic.blueprints import Blueprint
    blueprint_object = Blueprint('test_ExceptionMixin_exception',url_prefix=path)

    # Attach blueprint to the app

    blueprint_object.attach(sanic_object)

    blueprint_object.exception(ZeroDivisionError, apply = True)(handler)
    assert blueprint_object._future_exceptions.__len__() == 1

    blueprint_object._future_exceptions.clear()
    assert blueprint_object._future_exceptions.__len__() == 0

    def handler(request,exception):
        return exception



# Generated at 2022-06-12 09:02:35.001573
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_test(ExceptionMixin):
        class handler_test:
            pass
        def _apply_exception_handler(self, handler: FutureException):
            pass
    testcase = ExceptionMixin_test()
    assert testcase.exception(ExceptionMixin_test.handler_test, [ValueError, TypeError])(ExceptionMixin_test.handler_test).__name__ == 'handler_test'
    assert testcase._future_exceptions == {FutureException(ExceptionMixin_test.handler_test, (ValueError, TypeError))}


# Generated at 2022-06-12 09:02:46.464715
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyMock(ExceptionMixin):
        def __init__(self):
            self.mock_func = mock.MagicMock()

        def _apply_exception_handler(self, handler):
            self.mock_func(handler)

    obj = MyMock()
    decorator = obj.exception(Exception)
    @decorator
    def handler():
        return

    assert len(obj._future_exceptions) == 1
    assert obj.mock_func.called

# Generated at 2022-06-12 09:02:52.199549
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import HttpException
    from sanic.blueprints import Blueprint
    b = Blueprint('unit_test')
    @b.exception(HttpException)
    def handler(request, exception):
        assert isinstance(exception, HttpException)
        return 'exception has been handled'
    result = handler(1, None)
    assert result == 'exception has been handled'

# Generated at 2022-06-12 09:02:57.415553
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MockBlueprint(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, x):
            self.x = x

    mock = MockBlueprint()
    @mock.exception(IndexError)
    def handler():
        pass
    assert mock.x.handler == handler
    assert mock.x.exceptions == (IndexError,)

# Generated at 2022-06-12 09:03:04.386192
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprints import Blueprint
    from sanic.models.exceptions import GlobalExceptionHandler

    bp = Blueprint(name=__name__, url_prefix='/prefix/')

    @bp.exception(Exception, apply=False)
    async def my_handler(request, exception):
        return text('OK')

    future_exception = bp._future_exceptions.pop()

    assert isinstance(future_exception, FutureException)
    assert future_exception.handler == my_handler
    assert future_exception.exceptions == (Exception,)

    # Test _apply_exception_handler method
    global_handler = GlobalExceptionHandler()
    # global_handler._apply_exception_handler(future_exception)
    #
    # try:
    #     1 / 0
    # except Exception as

# Generated at 2022-06-12 09:03:07.902150
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint(__name__)
    blueprint.exception(AssertionError)(print)
    assert blueprint._future_exceptions
    assert blueprint._future_exceptions[0].exceptions == AssertionError

# Generated at 2022-06-12 09:03:13.649512
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.exceptions import ServerError

    app = Sanic('test_exception')

    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert self._future_exceptions == set()

            handler(app, ServerError)
            assert {handler} == self._future_exceptions

    mixin = MockExceptionMixin()

    @mixin.exception(apply=False)
    def exception_handler(_, _2):
        pass

    assert {exception_handler} == mixin._future_exceptions

# Generated at 2022-06-12 09:03:19.593881
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Blueprint(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super(Blueprint, self).__init__(*args, **kwargs)

    app = Blueprint()
    def test_exception_handler(request, exception):
        pass

    @app.exception(apply=False)
    def test_exception_handler(request, exception):
        pass

    assert len(app._future_exceptions) == 1
    assert isinstance(app._future_exceptions.pop(), FutureException)


# Generated at 2022-06-12 09:03:23.303275
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinImplement(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    es = ExceptionMixinImplement()
    assert es._future_exceptions == set()
    @es.exception()
    def handler():
        pass
    assert es._future_exceptions != set()

# Generated at 2022-06-12 09:03:28.499273
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test set up
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_ExceptionMixin_exception")
    app = Sanic("test_ExceptionMixin_exception")
    bp.register(app)

    @bp.exception([Exception])
    def default_error_handler(request, exception):
        return text("Exception has been handled!")

    # Tests
    assert app.exception_handler == default_error_handler

# Generated at 2022-06-12 09:03:35.860976
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__()
        def _apply_exception_handler(self, handler: FutureException):
            pass

    obj = TestExceptionMixin(Exception)

    @obj.exception(Exception)
    def my_handler(a, b):
        return a + b

    print(my_handler(0,0))

# Generated at 2022-06-12 09:03:57.989476
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.model import Model
    from sanic.models.blueprint import Blueprint
    from sanic.models.router import Router

    class MyModel(Model):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class MyBlueprint(Blueprint):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class MyRouter(Router):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    path = 'test'
    model = MyModel('test', [])
    router = MyRouter('test')
    blueprint = MyBlueprint('test')

    # Unit test for function router.

# Generated at 2022-06-12 09:04:01.836162
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic

    bp = Sanic('exception_test')
    bp.blueprint(__name__)
    # Do not test anything for now, because of ExceptionMixin is an abstract class
    # which does not implemented in anywhere yet.
    assert True

# Generated at 2022-06-12 09:04:08.574916
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinExampleClass(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    # Try 1 - successful
    try:
        ExceptionMixinExampleClass().exception(NotImplementedError)(lambda: None)
    except Exception as e:
        raise e

    # Try 2 - code exception
    try:
        ExceptionMixinExampleClass().exception(NotImplementedError, apply=False)(1)
        raise AssertionError
    except AssertionError:
        raise
    except Exception as e:
        print(type(e))
        print(str(e))

    # Try 3 - code exception

# Generated at 2022-06-12 09:04:14.681954
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # 1. Test when apply = True
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

    test = TestExceptionMixin()
    @test.exception(IndexError)
    def func(x):
        raise IndexError

    test._apply_exception_handler(list(test._future_exceptions)[0])
    with pytest.raises(IndexError):
        func(1)

    # 2. Test when apply = False
    test = TestExceptionMixin()
    @test.exception(IndexError, apply=False)
    def func(x):
        raise IndexError
    with pytest.raises(IndexError):
        func(1)

# Generated at 2022-06-12 09:04:15.545605
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
   # not implemented
   pass

# Generated at 2022-06-12 09:04:21.545756
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.response import json
    from sanic.exceptions import Forbidden

    EXCEPTION_LIST = [Exception]
    EXCEPTION_KEYWORDS = {'status_code': 403}

    def exception_handler(request, exception):
        return json({'error': 'Unknown'}, status=exception_KEYWORDS['status_code'])

    app = Blueprint(__name__)
    app.exception(
        *EXCEPTION_LIST,
        **EXCEPTION_KEYWORDS
    )(exception_handler)

    assert len(app._future_exceptions) == 1
    future_exception = app._future_exceptions.pop()
    assert future_exception.exceptions == EXCEPTION_LIST

# Generated at 2022-06-12 09:04:28.892248
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    def test_func_exception_handler():
        pass

    test_exception_mixin.exception(ValueError, apply=True)(test_func_exception_handler)

    exception = next(iter(test_exception_mixin._future_exceptions))
    assert (exception.handler == test_func_exception_handler)
    assert (exception.exceptions == (ValueError, ))

# Generated at 2022-06-12 09:04:37.987914
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self.test_future_exceptions = None

        def _apply_exception_handler(self, handler: FutureException):
            self.test_future_exceptions = handler

    @TestExceptionMixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert isinstance(exception_handler, types.FunctionType)

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin.test_future_exceptions == None

    exception_handler("request", Exception("exception"))
    assert test_exception_mixin.test_future_exceptions._handler == exception_handler
    assert test_exception_mixin.test

# Generated at 2022-06-12 09:04:44.881407
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.exceptions import ServerError
    from sanic.models.blueprints import Blueprint
    from sanic.models.endpoints import Endpoint

    app = Sanic('test_ExceptionMixin_exception')
    blueprint = Blueprint('test', url_prefix='/test')

    def exception_handler(request, exception):
        raise ServerError('Exception Handled', status_code=500)

    blueprint.exception(ZeroDivisionError)(exception_handler)

    @blueprint.route('/')
    def test(request):
        return 1/0

    app.blueprint(blueprint)
    endpoint = Endpoint('test', test, defaults={})
    expected = ServerError('Exception Handled', status_code=500)

    assert len(blueprint._future_exceptions) == 1

# Generated at 2022-06-12 09:04:52.980233
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    # Setup
    app = None
    bp = Blueprint(__name__)
    exceptions = Exception, RuntimeError

    # Test
    @bp.exception(Exception)
    async def test_exception(request, exception):
        pass

    assert len(bp._future_exceptions) == 1

    future_exception = set(bp._future_exceptions).pop()

    assert future_exception.handler == test_exception
    assert future_exception.exceptions == exceptions

    @bp.exception(Exception, apply=False)
    async def another_exception(request, exception):
        pass

    assert len(bp._future_exceptions) == 2
    assert set(bp._future_exceptions).pop() != future_exception

# Generated at 2022-06-12 09:05:25.753902
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler):
            return handler
    
    @_ExceptionMixin.exception()
    def exc_handler(request, exception):
        return exception
    
    assert isinstance(exc_handler, types.MethodType)

# Generated at 2022-06-12 09:05:31.439051
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Blueprint

    class bp(Blueprint, ExceptionMixin):
        def __init__(self):
            super(bp, self).__init__()

        def _apply_exception_handler(self, handler: FutureException):
            handler.apply()

    bp_test = bp()

    @bp_test.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(bp_test._future_exceptions) == 1

    with pytest.raises(Exception):
        with bp_test.catch_all_exceptions():
            raise Exception()



# Generated at 2022-06-12 09:05:40.457422
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    from sanic.exceptions import SanicException
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError

    class TestException(SanicException):
        pass

    class TestException2(SanicException):
        pass

    @TestExceptionMixin.exception(TestException, TestException2, apply=False)
    async def handler(request, exception):
        pass

    assert len(TestExceptionMixin._future_exceptions) == 1
    future_exception = next(iter(TestExceptionMixin._future_exceptions))
    assert future_exception._handler == handler
    assert future_exception._ex

# Generated at 2022-06-12 09:05:49.184858
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            ExceptionMixin.__init__(self)
            self.called = False
            self.result = None
            self.exceptions = None
            self.apply = None

        @ExceptionMixin.exception('test')
        def test(self, *args, **kwargs):
            self.called = True
            self.result = (args, kwargs)

        def _apply_exception_handler(self, handler):
            self.apply = handler

    t = ExceptionMixinTest()
    assert t.called is False
    t.test('b', b=2)
    assert t.called is True
    assert t.apply._handler == t.test
    assert t.apply._exceptions == ('test',)

# Generated at 2022-06-12 09:05:56.204132
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.abstract_model import AbstractModel
    from sanic.models.futures import FutureException

    class DummyBlueprint(ExceptionMixin, AbstractModel):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler(1) == 1

    blueprint = DummyBlueprint("/test", [])

    @blueprint.exception(KeyError)
    def handle_keyerror(request, exception):
        return exception.args

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(
        handle_keyerror, (KeyError,)
    )

# Generated at 2022-06-12 09:06:00.976858
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class UnitTestExceptionMixin(ExceptionMixin):
        pass
    unit_test_exception_mixin = UnitTestExceptionMixin()
    assert unit_test_exception_mixin._future_exceptions == set()
    assert unit_test_exception_mixin.__class__.__name__ == 'UnitTestExceptionMixin'
    assert UnitTestExceptionMixin.__name__ == 'UnitTestExceptionMixin'
    assert ExceptionMixin.__name__ == 'ExceptionMixin'

# Generated at 2022-06-12 09:06:08.326534
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return None
    # note: if update the above _ExceptionMixin, you
    # need to change the following code:

    exception_mixin = _ExceptionMixin()
    def handler():
        return None
    # case 1:
    print("test case 1:")
    exceptions = [None]
    exception_mixin.exception(exceptions)(handler)
    # case 2:
    print("test case 2:")
    exceptions = [None, None]
    exception_mixin.exception(exceptions)(handler)
    # case 3:
    print("test case 3:")
    exceptions = [[None, None], None]
    exception_mixin.exception(exceptions)(handler)
    #

# Generated at 2022-06-12 09:06:15.710378
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class blueprint(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler
        def test_handler(self, request):
            return 'hello world'

    args_1 = (ValueError, )
    kwargs_1 = {'apply' : True}
    args_2 = (ValueError, ZeroDivisionError)
    kwargs_2 = {'apply' : True}
    args_3 = ([ValueError, ZeroDivisionError], )
    kwargs_3 = {'apply' : True}
    args_4 = ([ValueError, ZeroDivisionError], )
    kwargs_4 = {'apply' : False}

    print('\nUnit testing for method "exception" of class "ExceptionMixin"')


# Generated at 2022-06-12 09:06:21.497628
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixin_Test(ExceptionMixin):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    class Sanic:
        pass

    sanic = Sanic()
    sanic.error_handler = set()

    @ExceptionMixin_Test.exception(Exception)
    def my_handler(request, exception):
        return text('Internal server error', 500)

    assert isinstance(sanic.error_handler, set) == True

    assert my_handler(1, 1) == "Internal server error"

# Generated at 2022-06-12 09:06:28.571458
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    '''
    该方法需要传入一个元组和可选的参数，可选参数中可以传入一个True类型的apply参数，默认传入False,也可以传入一个装饰器
    '''
    class ExceptionMixinTest:
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()


# Generated at 2022-06-12 09:07:37.680474
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        pass
    a = A()
    assert len(a._future_exceptions) == 0

    @a.exception(Exception)
    def foo():
        pass
    assert len(a._future_exceptions) == 1
    assert a._future_exceptions == {FutureException(foo, (Exception,))}

    a._apply_exception_handler = lambda x: x
    @a.exception(Exception, apply=False)
    def bar():
        pass
    assert len(a._future_exceptions) == 2
    assert a._future_exceptions == {
        FutureException(bar, (Exception,)),
        FutureException(foo, (Exception,)),
    }

# Generated at 2022-06-12 09:07:39.854406
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    args = ()
    kwargs = {}
    Decorator = MagicMock()
    Decorator.assert_called_once_with(args, kwargs)


# Generated at 2022-06-12 09:07:49.567871
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView, ExceptionMixin):
        def my_custom_handler(*args, **kwargs):
            return json({'hi': 'there'})

        def sub1_get(self, request, *args, **kwargs):
            return json({'hi': 'there'})

        def sub2_get(self, request, *args, **kwargs):
            return json({'hi': 'there'})

        def sub2_post(self, request, *args, **kwargs):
            return json({'hi': 'there'})

        def sub3_get(self, request, *args, **kwargs):
            return json({'hi': 'there'})

    view = MyView.as_

# Generated at 2022-06-12 09:07:50.061841
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:07:56.428527
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    expected_result = None

    class DummyExceptionMixin(ExceptionMixin):

        def __init__(self):
            super().__init__()
            self.apply = False

        def _apply_exception_handler(self, handler: FutureException):
            assert handler.exceptions == tuple(*expected_result)

            self.apply = True

    @DummyExceptionMixin().exception(expected_result)
    def dummy_handler(*args, **kwargs):
        assert args == tuple(*expected_result)
        assert kwargs == {}

    assert dummy_handler()
    assert DummyExceptionMixin().apply
    assert dummy_handler in DummyExceptionMixin()._future_exceptions

# Generated at 2022-06-12 09:08:04.023412
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest import mock

    from sanic import Blueprint
    from sanic.models.futures import FutureException

    bp = Blueprint("test")

    # Test for calling without argument
    with mock.patch.object(bp, "_apply_exception_handler") as mock_apply_exception_handler:
        with pytest.raises(TypeError):
            bp.exception()

    # Test for calling with arguments
    with mock.patch.object(bp, "_apply_exception_handler") as mock_apply_exception_handler:
        bp.exception(Exception)

    exception_set = set()
    exception_set.add(FutureException(mock_apply_exception_handler, (Exception,)))

    assert bp._future_exceptions == exception_set

    # Test for calling with arguments

# Generated at 2022-06-12 09:08:11.805012
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.exceptions import InvalidUsage
    from sanic import Sanic
    from sanic.blueprints import BluePrint
    from sanic.request import Request

    app = Sanic()

    @app.exception(InvalidUsage)
    def exception_handler(request, exception):
        return 'global'

    bp = BluePrint('test')

    @bp.exception(InvalidUsage)
    def exception_handler(request, exception):
        return 'blueprint'

    @bp.route('/')
    def handler(request):
        return 'OK'

    bp.register(app)
    request, response = app.test_client.get('/')
    assert response.text == 'OK'
    request, response = app.test_client.get('/exception')
    assert response.text == 'global'

# Generated at 2022-06-12 09:08:17.887167
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FakeRequest:
        def __init__(self, obj):
            self.app = obj

    class FakeBlueprint:
        def __init__(self, obj):
            self.blueprints = [obj]

    class FakeServer:
        def register_exception(self, exception):
            self.exception = exception
            return exception

    class FakeObject(ExceptionMixin):
        def __init__(self):
            super(FakeObject, self).__init__()

        def _apply_exception_handler(self, handler):
            return handler

    a = FakeObject()
    request = FakeRequest(a)
    blueprint = FakeBlueprint(a)
    server = FakeServer()

    def fake_handler(request, exception):
        pass
    a.exception(Exception)(fake_handler)

# Generated at 2022-06-12 09:08:21.301352
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class myExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    myExceptionMixin_test = myExceptionMixin()
    myExceptionMixin_test.exception(Exception)
    assert len(myExceptionMixin_test._future_exceptions) == 1

# Generated at 2022-06-12 09:08:24.986956
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from unittest.mock import create_autospec, ANY
    from sanic.blueprints.exceptions import blueprint

    blueprint = blueprint.__class__()
    blueprint.add_route = create_autospec(blueprint.add_route)

    # test
    blueprint.exception()

    blueprint.add_route.assert_called_once_with(ANY, ANY, ANY, ANY, ANY)
