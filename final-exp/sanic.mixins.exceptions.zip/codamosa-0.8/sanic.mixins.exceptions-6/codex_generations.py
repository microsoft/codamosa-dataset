

# Generated at 2022-06-12 08:59:16.051269
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class ExceptionMixinFake(ExceptionMixin):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.register_exception_handler = None
            self.args = None
            self.kwargs = None

        def _apply_exception_handler(self, handler):
            self.register_exception_handler = handler
            self.args = handler.exceptions
            self.kwargs = handler.kwargs

    # Test 1 - ExceptionMixin::exception - happy path
    exception_mixin = ExceptionMixinFake()
    @exception_mixin.exception(KeyError)
    def fake_handler(*args, **kwargs):
        return None
    assert exception_mixin.register_exception_handler is not None

# Generated at 2022-06-12 08:59:25.745385
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    class TestExceptionMixin(ExceptionMixin):

        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            print("handler applied")
            pass

    testExceptionMixin = TestExceptionMixin()

    def decorator(handler):
        nonlocal apply
        nonlocal exceptions

        future_exception = FutureException(handler, exceptions)
        testExceptionMixin._future_exceptions.add(future_exception)

        # if apply:
        #     self._apply_exception_handler(future_exception)

        return handler

    class Test:
        def pass_exception(e, *args, **kwargs):
            exceptions = e

    test = Test()

# Generated at 2022-06-12 08:59:35.496604
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.views import HTTPMethodView
    app = Sanic(__name__)
    bp = Blueprint('Test', url_prefix='/test')

    @bp.exception(Exception)
    def handler(request, exception):
        return text('Sanic Test Exception')

    @bp.route('/', methods=['GET'])
    def handler(request):
        return text('Sanic Test')

    class Handler(HTTPMethodView):
        @bp.exception(Exception)
        def get(self, request):
            return text('Sanic Test Exception')

        def post(self, request):
            return text('Sanic Test')

    bp.add

# Generated at 2022-06-12 08:59:42.757577
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.base import BaseModel
    from sanic.exceptions import SanicException


    class X(BaseModel, ExceptionMixin):
        pass

    class A(SanicException):
        pass

    class B(SanicException):
        pass


    x = X()
    @x.exception(A,B)
    def y(*args, **kwargs):
        pass
    assert type(x._future_exceptions) == set
    assert len(x._future_exceptions) == 1
    assert type(x._future_exceptions.pop()) == FutureException
    assert type(x.exception(A,B)) == functions.FunctionType
    assert len(x._future_exceptions) == 1


# Generated at 2022-06-12 08:59:48.178524
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    app = Flask(__name__)

    class MockExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = MockExceptionMixin()
    @exception_mixin.exception(AssertionError)
    def error_handler(request, exception):
        return "Exception handled successfully."

    assert error_handler(app.request) == "Exception handled successfully."

# Generated at 2022-06-12 08:59:58.670866
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint(
        'error',
        url_prefix='/test/test',
    )

    @blueprint.exception(Exception)
    def test_exc(request, exception):
        pass

    @blueprint.exception(ValueError, apply=False)
    def test_exc_val_error(request, exception):
        pass

    @blueprint.exception(ValueError, apply=True)
    def test_exc_val_error_apply(request, exception):
        pass

    # Error with apply exception 
    assert len(blueprint._future_exceptions) == 2
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-12 09:00:05.373216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    exception_mixin = ExceptionMixin()

    @exception_mixin.exception(TypeError, apply=True)
    def func(request, exception):
        return 'could not parse JSON'

    assert(len(exception_mixin._future_exceptions) == 1)
    f = exception_mixin._future_exceptions.pop()
    assert(f.handler == func)
    assert(f.exceptions == (TypeError,))

# Generated at 2022-06-12 09:00:13.144646
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    from unittest.mock import MagicMock

    class ExceptionMixinTest(ExceptionMixin, unittest.TestCase):
        def __init__(self):
            super().__init__()

        def test_exception_plain(self):
            mock = MagicMock()
            self.exception(Exception)(mock)
            self.assertIn(mock, self._future_exceptions)

        def test_exception_with_args(self):
            mock = MagicMock()
            self.exception(Exception, apply=False)(mock)
            self.assertIn(mock, self._future_exceptions)

        def test_exception_list_of_args(self):
            mock = MagicMock()
            self.exception([Exception])(mock)

# Generated at 2022-06-12 09:00:22.937936
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Class(ExceptionMixin):
        pass

    @Class.exception(KeyError, apply=False)
    def keyerror_handler(request, exception):
        pass

    @Class.exception([KeyError, ValueError])
    def keyerror_valueerror_handler(request, exception):
        pass

    @Class.exception(KeyError, apply=False, optional_argument=27)
    def keyerror_handler_with_optional_argument(request, exception, *, optional_argument=None):
        assert optional_argument == 27

    class1 = Class()

    assert len(class1._future_exceptions) == 3

# Generated at 2022-06-12 09:00:27.245674
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    future_exception = FutureException(Exception, (Exception,))
    exception_mixin = ExceptionMixin()
    exception_mixin._future_exceptions.add(future_exception)
    assert future_exception in exception_mixin._future_exceptions



# Generated at 2022-06-12 09:00:37.381523
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class FutureExceptionTest:
        pass


    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException) -> None:
            pass


    @TestExceptionMixin.exception(FutureExceptionTest)
    def handler(request, exception):
        pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 1
    assert isinstance(list(test_exception_mixin._future_exceptions)[0].handler,
                      types.FunctionType)

# Generated at 2022-06-12 09:00:39.748481
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Initialize the object
    class BP:
        pass

    bp = ExceptionMixin()
    # Test function
    bp.exception(Exception)

# Generated at 2022-06-12 09:00:44.393838
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test = TestExceptionMixin()
    @test.exception(Exception)
    def handler(request, exception):
        return request, exception
    assert handler(1, 2) == (1, 2)

# Generated at 2022-06-12 09:00:54.599226
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    def make_tests(test_inputs: dict, expected: list) -> None:
        for test_input in test_inputs:
            actual: list = []
            test_obj = TestExceptionMixin()
            @test_obj.exception(test_input)
            def handler(request, exception):
                actual.append(request)
                actual.append(exception)
            handler(1, 2)
            assert actual == expected

    make_tests({
        list([ValueError]),
        tuple([ValueError]),
        (list([ValueError])),
        (tuple([ValueError])),
    },
        [1, 2]
    )

# Generated at 2022-06-12 09:01:05.106255
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.testing import HOST, PORT
    from sanic.response import json
    from sanic.models.futures import FutureException

    app = Sanic(__name__)
    expected_result = {"test": True}
    blueprint_each = Blueprint("test_blueprint_each", url_prefix="/v1")

    @blueprint_each.exception(NotFound, apply=False)
    async def handler_first(request, exception):
        return json({"test": True})

    @blueprint_each.route("/exception")
    async def handler_second(request):
        return json({"test": True})

    app.blueprint(blueprint_each)
    current_result

# Generated at 2022-06-12 09:01:11.577711
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.models.futures import FutureException
    from sanic.blueprints import Blueprint

    from tests.utils import SanicTestClient

    app = Sanic("test_ExceptionMixin_exception")

    bp = Blueprint("test_bp", url_prefix="test")

    @bp.listener("before_server_start")
    def before_server_start(app, loop):
        nonlocal bp
        bp._initialize(app)

    # normal exception
    @bp.exception(Exception, apply=False)
    def handle_exception(request, exception):
        return text("Exception")

    @bp.exception(Exception)
    def handle_exception_with_apply(request, exception):
        return text("Exception")


# Generated at 2022-06-12 09:01:19.357630
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_mixin = TestExceptionMixin()
    @test_mixin.exception(Exception)
    def func(request, exception, *args, **kwargs):
        pass
    assert len(test_mixin._future_exceptions) == 1
    assert test_mixin._future_exceptions.pop().handler == func

if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-12 09:01:27.046953
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    errors = {'errors': ["Not found"]}
    exception_mixin = MyExceptionMixin()
    handler = exception_mixin.exception(NotFoundError)(lambda request, exception : errors)
    assert isinstance(handler, type(lambda : None))
    assert handler(None, None) == errors
    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._future_exceptions.pop().handler == handler
    assert exception_mixin._future_exceptions == set()

# Generated at 2022-06-12 09:01:32.102736
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class Futures(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
    futures = Futures()
    @futures.exception(RuntimeError)
    def handler(request, exception):
        pass
    @futures.exception(RuntimeError, apply=False)
    def handler(request, exception):
        pass
    assert futures._future_exceptions.__len__() == 2

# Generated at 2022-06-12 09:01:33.924619
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    try:
        ExceptionMixin().exception()
    except NotImplementedError:
        pass



# Generated at 2022-06-12 09:01:41.636668
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        pass
    exc_mixin = TestExceptionMixin()

    def handler():
        pass

    exc_mixin.exception(ZeroDivisionError, apply=True)(handler)

    assert exc_mixin._future_exceptions != set()

# Generated at 2022-06-12 09:01:50.054179
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class MyExceptionMixin(ExceptionMixin):
        def __init__(self) -> None:
            super().__init__()
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            self._future_exceptions.add(handler)

    my_exception_mixin = MyExceptionMixin()
    my_exception_mixin.exception(IndexError)
    assert len(my_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-12 09:01:58.441788
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    from unittest.mock import Mock, MagicMock

    class TestingExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    future_exception = FutureException(Mock(), {RuntimeError})
    testing_exception_mixin = TestingExceptionMixin()
    testing_exception_mixin.exception(RuntimeError, apply=False)
    assert testing_exception_mixin._future_exceptions == {future_exception}
    assert future_exception.handler is None
    assert future_exception.exceptions == {RuntimeError}

    class TestingExceptionMixinWithHandlers(ExceptionMixin):
        def __init__(self):
            super().__

# Generated at 2022-06-12 09:02:05.243780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.exceptions import SanicException

    class DummyError(Exception):
        pass

    class DummyClass():
        def __init__(self):
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            handler.handler("test_module_name", "test_module_lineno", "test_module_filename")

    dummy_class = DummyClass()
    dummy_class.exception(SanicException, DummyError, "TestError")(print)

# Generated at 2022-06-12 09:02:12.391532
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    # create a instance of ExceptionMixin
    class FakeExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler):
            return handler

    # create a instance of Blueprint
    blueprint = Blueprint('fake_exception')
    blueprint.__class__.__bases__ = (FakeExceptionMixin,)

    # create a handler of exception
    @blueprint.exception(Exception)
    def handler(request, exception):
        return request, exception

    exception = SanicException('fake')
    request = 'fake'

    expected = (request, exception)
    actual = handler(request, exception)
    assert actual == expected

# Generated at 2022-06-12 09:02:19.171906
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.models.blueprint import BlueprintMixin
    from sanic.models.blueprint import BlueprintExceptionHandlerMixin

    bp = BlueprintMixin(BlueprintExceptionHandlerMixin(Sanic()), 'test')

    @bp.exception((Exception,), apply=False)
    def test(request, exception):
        return 1

    assert len(bp._future_exceptions) == 1
    assert test(1, Exception) == 1



# Generated at 2022-06-12 09:02:21.742501
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin.exception.__code__.co_argcount == 1
    assert ExceptionMixin.exception.__code__.co_varnames == ('handler',)

# Generated at 2022-06-12 09:02:24.772607
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class C:
        def handler(*args, **kwargs):
            pass
    c = C()
    c.exception = ExceptionMixin.exception
    c.exception(TypeError,ValueError, apply=False)(c.handler)

# Generated at 2022-06-12 09:02:29.118294
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            return None

    _test = _TestExceptionMixin()
    _test.exception(Exception)



# Generated at 2022-06-12 09:02:37.019993
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    global_exceptions = None
    def _apply_exception_handler(self, handler: FutureException):
        global global_exceptions
        global_exceptions = handler

    def _handler():
        pass
    _exceptions = {Exception}


    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            self._future_exceptions = set()

        def _apply_exception_handler(self, handler: FutureException):
            _apply_exception_handler(self, handler)

    mixin = TestExceptionMixin()
    mixin.exception(_handler, _exceptions)
    assert global_exceptions.handler == _handler
    assert global_exceptions.exceptions == _exceptions

# Generated at 2022-06-12 09:02:53.816983
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(A, self).__init__(*args, **kwargs)

    @A.exception(ValueError, KeyError)
    def value_error(request):
        raise ValueError('ValueError')

    @A.exception(IndexError, KeyError)
    def key_error(request):
        raise KeyError('KeyError')

    a = A()
    try:
        value_error(a)
    except ValueError:
        pass
    except KeyError:
        assert False
    try:
        key_error(a)
    except KeyError:
        pass
    except ValueError:
        assert False
# END Unit test for method exception of class ExceptionMixin

# Generated at 2022-06-12 09:03:02.580083
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    class TestException(unittest.TestCase):
        def test_exception(self):
            from sanic.models.futures import FutureException
            from sanic.blueprints import Blueprint
            from sanic.app import Sanic
            bp = Blueprint("test", url_prefix="/test")

            @bp.exception(ValueError)
            def errorhandler(request, exception):
                return text("Error")

            app = Sanic("test_exception")
            bp.register(app)

            # the length of the future_exception equals to 1
            self.assertEqual(len(bp._future_exceptions), 1)

            # The element of _future_exception is a FutureException
            self.assertIsInstance(next(iter(bp._future_exceptions)), FutureException)

            #

# Generated at 2022-06-12 09:03:11.482367
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # GIVEN
    class MockExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exception = decorator_with_args(self.exception)
            self.handler = None
            self.exceptions = None

        def _apply_exception_handler(self, handler: FutureException):
            self.handler = handler
            self.exceptions = handler.exceptions

        def decorator_with_args(self, decorator):
            """
            This decorator allows decorators to be called with arguments.
            """

            def wrapper(*args, **kwargs):
                def new_decorator(func):
                    return decorator(func, *args, **kwargs)

                return new_decor

# Generated at 2022-06-12 09:03:18.811705
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class _ExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    with pytest.raises(NotImplementedError):
        _ExceptionMixin()._apply_exception_handler(None)

    future_exception = FutureException(None, (Exception, ))
    exception_mixin = _ExceptionMixin()
    assert exception_mixin is not None

    # Test if the method exception is callable
    @exception_mixin.exception(Exception)
    def _test_exception(request, exception):
        pass

    assert future_exception in exception_mixin._future_exceptions

# Generated at 2022-06-12 09:03:24.819964
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test case 1: exception method
    from sanic.exceptions import SanicException
    from sanic.models.blueprint import blueprint
    from sanic.models.exception import exception
    from sanic.models.exception import ExceptionMixin
    import asyncio
    import json
    import pytest
    @exception(SanicException)
    def handler(request, exception):
        return json({"exception": exception.__class__.__name__})
    # Init ExceptionMixin
    exception_mixin = ExceptionMixin()
    exception_mixin.exception(SanicException)
    # Test case 2: exception method with isinstance

# Generated at 2022-06-12 09:03:29.891275
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.generator import Generator
    from sanic.models.request import Request
    from sanic.models.response import Response
    from sanic.models.route import Route

    generator = Generator()
    request = Request(generator)
    response = Response(generator)
    route = Route(None, None, 'GET')
    blueprint = Blueprint(None)
    blueprint.route = route

    def handler():
        return None
    future_exception = blueprint.exception(Exception)(handler)
    assert isinstance(future_exception, FutureException)

# Generated at 2022-06-12 09:03:35.027718
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """Unit test for exception method of class ExceptionMixin"""
    args = ('a', 'b')
    d = ExceptionMixin()
    assert(len(d._future_exceptions) == 0)

    def test(): pass
    d.exception(*args)(test)
    assert(len(d._future_exceptions) == 1)

# Generated at 2022-06-12 09:03:40.075195
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():

    def exception_handler(*args, **kwargs):
        pass

    from sanic.blueprints import Blueprint

    blueprint = Blueprint('blueprint')
    blueprint.exception(exception_handler)

    # Check if the method exception_handler is correctly stored in self._future_exceptions
    future_exceptions = blueprint._future_exceptions
    assert len(future_exceptions) == 1
    future_exception = future_exceptions.pop()
    assert future_exception._handler == exception_handler
    assert len(future_exception._args) == 0
    assert len(future_exception._kwargs) == 0

# Generated at 2022-06-12 09:03:45.218685
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Setup
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = ExceptionMixinTest()

    @test.exception(Exception)
    async def test_exception(request, exception):
        return test

    # Confirm handler is returned
    assert test_exception == test._future_exceptions.pop().handler

# Generated at 2022-06-12 09:03:46.041724
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert ExceptionMixin().exception

# Generated at 2022-06-12 09:04:06.214955
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # check type of method ExceptionMixin.exception
    assert callable(ExceptionMixin.exception)
    # check number of arguments of method ExceptionMixin.exception
    assert ExceptionMixin.exception.__code__.co_argcount == 2
    # check if an exception is raised when the first argument is not a list
    error = None
    try:
        ExceptionMixin.exception('arg')
    except Exception as exc:
        error = exc
    assert error

# Generated at 2022-06-12 09:04:13.819720
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.base import Blueprint
    class TestMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.args[0](Exception("test")) == "test"
    class TestBlueprint(Blueprint, TestMixin):
        def __init__(self):
            Blueprint.__init__(self)
            TestMixin.__init__(self)
    test_mixin = TestBlueprint()
    # test basic 
    @test_mixin.exception()
    def test_basic(request, exception: Exception):
        assert isinstance(exception, Exception)
        return str(exception)
    # test overwrite

# Generated at 2022-06-12 09:04:19.287941
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic("test_ExceptionMixin_exception")
    bp = Blueprint('test_ExceptionMixin_exception_bp')

    @bp.exception(Exception)
    def handle_request_exception(request, exception):
        return text("Oops! Something went wrong")

    app.blueprint(bp)
    current_bp = app.router.routes_namespace['test_ExceptionMixin_exception_bp']

    current_bp._exception_handler[Exception] == handle_request_exception

# Generated at 2022-06-12 09:04:27.638063
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import unittest
    from sanic import Blueprint
    test_ExceptionMixin_exception_blueprint = Blueprint(name="test_ExceptionMixin_exception_blueprint")

    @test_ExceptionMixin_exception_blueprint.exception(Exception)
    def test_ExceptionMixin_exception_handler(request, exception):
        pass

    assert len(test_ExceptionMixin_exception_blueprint._future_exceptions) == 1
    assert next(iter(test_ExceptionMixin_exception_blueprint._future_exceptions))[0] == test_ExceptionMixin_exception_handler
    assert len(next(iter(test_ExceptionMixin_exception_blueprint._future_exceptions))) == 2

# Generated at 2022-06-12 09:04:31.885508
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.exceptions import SanicException, NotFound

    app = Sanic('test_sanic')
    @app.exception(NotFound)
    def not_found(request, exception):
        return text('Not found.')
    #assert callable(not_found)

# Generated at 2022-06-12 09:04:40.084916
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    bp = Blueprint('test', url_prefix='/test')

    @bp.exception(404)
    def exception_handler(e):
        return 'test'

    @bp.route('/test')
    def test(request):
        return 'test'

    app = Sanic('test_ExceptionMixin')
    app.blueprint(bp)

    request, response = app.test_client.get('/test')
    assert response.status == 404

    request, response = app.test_client.get('/haha')
    assert response.status == 404

    app = Sanic('test_ExceptionMixin')
    app.blueprint(bp, apply=False)

    request, response = app.test_client.get('/test')
    assert response.status == 404


# Generated at 2022-06-12 09:04:46.241492
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Initialize a dummy ExceptionMixin
    dummy_ExceptionMixin = ExceptionMixin()
    # Initialize a dummy exception class called CustomException
    class CustomException(Exception):
        pass
    # Declare a dummy function called exceptionHandler
    def exceptionHandler(request, exception, *args, **kwargs):
        pass
    # Execute the exception method of dummy_ExceptionMixin
    dummy_ExceptionMixin.exception(CustomException)(exceptionHandler)
    # Assert that the method works correctly
    assert len(dummy_ExceptionMixin._future_exceptions) == 1
    assert isinstance(list(dummy_ExceptionMixin._future_exceptions)[0].exceptions[0], CustomException)
    assert list(dummy_ExceptionMixin._future_exceptions)[0].handler == exceptionHandler

# Generated at 2022-06-12 09:04:50.120738
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    blueprint = Blueprint(__name__, url_prefix='/blueprint')

    @blueprint.exception(Exception)
    def handler(request, exception):
        return 'An error occurred'

    assert blueprint.handler_exception(None, None) == 'An error occurred'

# Generated at 2022-06-12 09:04:55.947929
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic import Sanic
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.handlers import ErrorHandler
    from sanic.response import json

    def test_handler(request, exception):
        return json({"test": "passed"}, status=exception.status_code)

    app = Sanic(__name__)

    exception_bp = Blueprint("test_bp")

    exception_bp.exception(SanicException)(test_handler)

    exception_bp.register(app, "/test_bp")

    @app.route("/test")
    def test_route(request):
        raise SanicException("Exception test", status_code=500)


# Generated at 2022-06-12 09:05:01.502305
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # test for method exception of class ExceptionMixin
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            return handler

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0
    @test_exception_mixin.exception(Exception)
    def test_decorator(request, exception):
        print('exception')
        return exception
    assert len(test_exception_mixin._future_exceptions) == 1
    test_decorator()

# Generated at 2022-06-12 09:05:36.219908
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_blueprint')
    assert blueprint.exception(404) == blueprint.exception(404)
    assert blueprint.exception(404) != blueprint.exception(401)


# Generated at 2022-06-12 09:05:38.922257
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    """
    Unit test for method exception of class ExceptionMixin
    """
    ob = ExceptionMixin()
    def handler(handler):
        return handler

    ob.exception(handler)

# Generated at 2022-06-12 09:05:44.052863
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    args = ('arg1', 'arg2')
    kwargs = {'kwarg1': 'kwarg1 value', 'kwarg2': 'kwarg2 value'}

    blueprint = Blueprint('blueprint', url_prefix='/blueprint')

    @blueprint.exception(*args, **kwargs)
    def exception_handler():
        pass

    assert blueprint.exception_handlers[exception_handler] == args

# Generated at 2022-06-12 09:05:50.937780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()
        def _apply_exception_handler(self, handler: FutureException):
            pass
        
    test_obj = TestExceptionMixin()
    assert len(test_obj._future_exceptions) == 0
    
    @test_obj.exception(NameError, apply=True)
    def test_handler(error):
        return True
    assert len(test_obj._future_exceptions) == 1
    assert test_handler(NameError) is True

# Generated at 2022-06-12 09:05:56.660239
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # import here, because otherwise there will be a circular import
    from sanic.blueprints import Blueprint

    class BlueprintChild(Blueprint, ExceptionMixin):
        pass

    exception = Exception()
    blueprint_child = BlueprintChild('test', url_prefix='/blueprint')

    @blueprint_child.exception(exception)
    def error_handler(request: Request, exception: Exception):
        return None

    assert len(blueprint_child._future_exceptions) == 1
    assert blueprint_child._exception_handlers == {exception: error_handler}

# Generated at 2022-06-12 09:05:57.543106
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # TODO
    pass


# Generated at 2022-06-12 09:05:58.599597
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass
#test function for method exception of class ExceptionMixin




# Generated at 2022-06-12 09:06:04.171800
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    os.environ["SANIC_CONFIG_MODULE"] = 'test.test_config'

    bp = Blueprint("unit_test")

    @bp.exception()
    def handler(request, exception):
        return text("OK")

    bp._apply_exception_handler(bp._future_exceptions.pop())

    app = Sanic()
    app.blueprint(bp)
    request, response = app.test_client.get("/")
    assert response.text == "OK"

    os.environ["SANIC_CONFIG_MODULE"] = ""

# Generated at 2022-06-12 09:06:10.073351
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    import sys
    import pytest
    from sanic import Sanic

    class TestException(Exception):
        pass


    class FakeExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass


    obj_fakeexc_mixin = FakeExceptionMixin()
    # noinspection PyTypeChecker
    obj_fakeexc_mixin.exception(TestException)(TestException)
    assert len(obj_fakeexc_mixin._future_exceptions) == 1



# Generated at 2022-06-12 09:06:11.332422
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass


if __name__ == "__main__":
    test_ExceptionMixin_exception()

# Generated at 2022-06-12 09:07:22.026573
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    exception = ExceptionMixinTest()

# Generated at 2022-06-12 09:07:22.848125
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    assert hasattr(ExceptionMixin(), 'exception')

# Generated at 2022-06-12 09:07:23.609396
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:07:31.679332
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.exceptions import SanicException

    blueprint = Blueprint("test", url_prefix="test")

    exception = blueprint.exception(SanicException)
    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.__len__() == 1

    blueprint = Blueprint("test", url_prefix="test")

    exception = blueprint.exception((SanicException))
    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.__len__() == 1

    blueprint = Blueprint("test", url_prefix="test")

    exception = blueprint.exception({"error": SanicException, "code": 500})
    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.__len__() == 1


# Generated at 2022-06-12 09:07:32.104997
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    pass

# Generated at 2022-06-12 09:07:40.003879
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.exceptions import NotFound

    class MockClass(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            # Do nothing
            return

    class MockHandler:
        def __init__(self, *args, **kwargs) -> None:
            pass

    @MockClass.exception(NotFound)
    def _not_found(request, exception):
        """
        This method handles NotFound exception responses
        """
        pass

    assert len(MockClass._future_exceptions) == 1
    assert MockClass._future_exceptions[0].handler == MockHandler
    assert Mock

# Generated at 2022-06-12 09:07:41.132231
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = ExceptionMixin()
    blueprint.exception()
    pass

# Generated at 2022-06-12 09:07:50.710437
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic._exceptions import _exception_handler as e_handler
    from sanic._exceptions import add_default_exception_handler
    from sanic._exceptions import server_error_handler, error_handler
    from sanic._exceptions import add_default_error_handler
    from sanic._exceptions import default_exception_handler
    from sanic.kernal import Sanic
    sanic_app = Sanic('test_ExceptionMixin_exception')

    @sanic_app.exception(Exception)
    def handler(request, exception):
        return text('OK')

    @sanic_app.exception(Exception)
    async def handler2(request, exception):
        return text('OK')

    @sanic_app.exception([Exception])
    def handler3(request, exception):
        return

# Generated at 2022-06-12 09:07:58.436718
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.request import Request
    from sanic.response import HTTPResponse

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            # fulfill the future exception
            request = Request()
            request.app = "test"
            request.body = ""

            response = handler(request, Exception)
            assert isinstance(response, HTTPResponse)
            assert response.status == '200'
            assert response.body == 'hello'

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, ex):
        return HTTPResponse('hello')


# Generated at 2022-06-12 09:08:00.848475
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    blueprint = Blueprint('test', url_prefix='/test')
    blueprint.exception(IndexError, ZeroDivisionError)
    blueprint.exception(IndexError, ZeroDivisionError, apply=False)