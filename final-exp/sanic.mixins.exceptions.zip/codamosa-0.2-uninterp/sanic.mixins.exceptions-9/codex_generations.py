

# Generated at 2022-06-18 05:28:26.585546
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:28:36.429976
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My exception")

    bp = Blueprint("test_bp", url_prefix="/test")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"exception": str(exception)})

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)


# Generated at 2022-06-18 05:28:45.074664
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    test_exception_mixin.exception(Exception)
    assert len(test_exception_mixin._future_exceptions) == 1
    test_exception_mixin.exception(Exception)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:28:47.497636
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test', url_prefix='test')
    blueprint.exception(Exception)(lambda x: x)
    assert blueprint._future_exceptions

# Generated at 2022-06-18 05:28:53.733817
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(MyException)
    def handler(request, exception):
        return text('Exception handler')

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:28:58.404204
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:00.916639
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    blueprint = Blueprint('test_blueprint')
    blueprint.exception(Exception)(lambda x: x)
    assert blueprint._future_exceptions

# Generated at 2022-06-18 05:29:07.633914
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:14.077145
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test_exception', url_prefix='test_exception')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Not found', status=404)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._exception_handlers
    assert blueprint._exception_handlers.pop()

# Generated at 2022-06-18 05:29:20.068524
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:27.965309
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('OK')

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == handler


# Generated at 2022-06-18 05:29:33.869780
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('I caught an exception')

    assert blueprint._future_exceptions

    future_exception = blueprint._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.exceptions == (SanicException,)

# Generated at 2022-06-18 05:29:43.603388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:53.927884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    class MyBlueprint(Blueprint, ExceptionMixin):
        def __init__(self, name, url_prefix=None):
            Blueprint.__init__(self, name, url_prefix)
            ExceptionMixin.__init__(self)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = MyBlueprint('test')

    @blueprint.exception(MyException)
    def handler(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:29:59.325096
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:04.736289
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)(lambda x: x)
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler(Exception) == Exception

# Generated at 2022-06-18 05:30:14.218459
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

        def post(self, request):
            return json({"received": True})

    bp = Blueprint("test_bp", url_prefix="/test_bp")
    bp.add_route(MyView.as_view(), "/test_bp")

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({"exception": True}, status=500)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler

# Generated at 2022-06-18 05:30:18.041807
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:22.988385
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = TestExceptionMixin()

    @exception_mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:30:28.926238
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:30:39.085770
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Exception handler')

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:30:45.238317
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My exception")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return text("Exception handled")

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)

    request, response = app.test_client.get("/")

    assert response.text == "Exception handled"

# Generated at 2022-06-18 05:30:50.583227
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:56.960883
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test', url_prefix='/test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Internal server error', 500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:31:04.700250
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:31:10.058223
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:31:15.131396
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    @exception_mixin_test.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-18 05:31:19.769620
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    blueprint = Blueprint(__name__)
    assert blueprint._future_exceptions == set()

    @blueprint.exception(Exception)
    def handler(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:31:22.990469
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Not found', status=404)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._exception_handler(None, NotFound()) == text('Not found', status=404)

# Generated at 2022-06-18 05:31:29.795051
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0
    test_exception_mixin.exception(Exception)(lambda x: x)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:31:45.848526
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._apply_exception_handler = self._apply_exception_handler_test

        def _apply_exception_handler_test(self, handler: FutureException):
            assert handler.handler == handler_test
            assert handler.exceptions == (Exception,)

    @TestExceptionMixin().exception(Exception)
    def handler_test():
        pass

# Generated at 2022-06-18 05:31:54.569412
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exception_handler_applied = False

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler_applied = True

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin.exception_handler_applied == False
    test_exception_mixin.exception(Exception)(lambda: None)
    assert test_exception_mixin.exception_handler_applied == True

# Generated at 2022-06-18 05:32:01.845811
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class TestException(SanicException):
        pass

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_blueprint = Blueprint('test_blueprint')
    test_blueprint.exception(TestException)(lambda: None)
    assert len(test_blueprint._future_exceptions) == 1
    assert len(test_exception_mixin._future_exceptions) == 0

# Generated at 2022-06-18 05:32:06.682587
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint('test_bp')

    @bp.exception(SanicException)
    def handler(request, exception):
        return text('Exception handler')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:10.693620
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:32:16.848151
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class TestException(SanicException):
        pass

    bp = Blueprint('test_bp', url_prefix='/test')

    @bp.exception(TestException)
    def handle_test_exception(request, exception):
        return text('Exception handled')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handle_test_exception

# Generated at 2022-06-18 05:32:23.042803
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint("test_blueprint")

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        return "exception"

    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:32:29.935165
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.name}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:35.988296
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    class MyBlueprint(Blueprint, ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = MyBlueprint('test', url_prefix='/test')

    @blueprint.exception(MyException)
    def handler(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:41.874013
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:33:04.763847
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:33:10.116154
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    bp = Blueprint('test_bp')
    bp.exception(MyException)(lambda request, exception: None)
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler is not None

# Generated at 2022-06-18 05:33:15.133891
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception, apply=False)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:33:24.879865
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My exception")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return text("It works!", status=500)

    request, response = bp.as_handler(create_app())(
        create_request(url="/", method="GET")
    )

    assert response.status == 500

# Generated at 2022-06-18 05:33:34.614771
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.route import Route
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import NotFound
    from sanic.models.exceptions import ServerError
    from sanic.models.exceptions import InvalidUsage
    from sanic.models.exceptions import Forbidden
    from sanic.models.exceptions import RequestTimeout
    from sanic.models.exceptions import PayloadTooLarge
    from sanic.models.exceptions import Unauthorized
    from sanic.models.exceptions import TooManyRequests
    from sanic.models.exceptions import MethodNotAllowed
    from sanic.models.exceptions import FileNotFound
    from sanic.models.exceptions import URLNotFound
    from sanic.models.exceptions import NotSupported

# Generated at 2022-06-18 05:33:40.990482
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    bp = Blueprint('test_bp')

    @bp.exception(SanicException)
    def handler(request, exception):
        return text('internal error', 500)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:47.323369
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    class MyException(SanicException):
        pass

    bp = Blueprint("test_exception")

    @bp.exception(MyException)
    def handler(request, exception):
        return text("Exception handled")

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:55.355867
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text
    from sanic.views import CompositionView

    blueprint = Blueprint('test_exception', url_prefix='test')

    @blueprint.exception(NotFound)
    def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))

    @blueprint.route('/')
    def handler(request):
        raise NotFound("Sorry, no way.")

    app = CompositionView()
    app.add(blueprint)

    request, response = app.test_client.get('/')
    assert response.text == "Yep, I totally found the page: http://test/"

# Generated at 2022-06-18 05:33:58.848752
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def ignore_404s(request, exception):
        return json({'status': 'ok'})

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == ignore_404s

# Generated at 2022-06-18 05:34:09.281172
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprint import Blueprint
    from sanic.models.route import Route
    from sanic.models.request import Request
    from sanic.models.response import HTTPResponse
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import InvalidUsage
    from sanic.models.exceptions import ServerError
    from sanic.models.exceptions import NotFound
    from sanic.models.exceptions import Forbidden
    from sanic.models.exceptions import RequestTimeout
    from sanic.models.exceptions import PayloadTooLarge
    from sanic.models.exceptions import UnsupportedMediaType
    from sanic.models.exceptions import MethodNotSupported
    from sanic.models.exceptions import Unauthorized
   

# Generated at 2022-06-18 05:34:47.204773
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:34:54.738093
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Arrange
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    # Act
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    # Assert
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:34:59.709693
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    def test_handler():
        pass
    test_exception_mixin.exception(Exception)(test_handler)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:35:02.770855
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def handle_exception(request, exception):
        return text('Exception handled!')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handle_exception

# Generated at 2022-06-18 05:35:12.452231
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:18.860623
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint('test_blueprint', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Exception: %s' % exception)

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(handler, (SanicException,))

# Generated at 2022-06-18 05:35:23.447571
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception')
    blueprint.exception(ServerError)(lambda request, exception: text('OK'))
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler(None, None) == 'OK'

# Generated at 2022-06-18 05:35:28.508727
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:35:39.595160
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My exception")

    blueprint = Blueprint("test_exception")
    blueprint.add_route(MyView.as_view(), "/")

    @blueprint.exception(MyException)
    def handler(request, exception):
        return json({"error": "My exception"})

    app = Sanic("test_exception")
    app.blueprint(blueprint)

    request, response = app.test_client.get("/")
    assert response.status == 500

# Generated at 2022-06-18 05:35:44.559707
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint("test_bp")

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({"exception": exception.name})

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:00.514081
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert test_exception_mixin._future_exceptions

# Generated at 2022-06-18 05:37:07.561291
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:37:13.597563
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:37:18.132282
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:37:25.761348
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    blueprint = Blueprint("test_ExceptionMixin_exception")

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text("Exception handler")

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:30.694535
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(ServerError)
    async def handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions == {
        FutureException(handler, (ServerError,))
    }

# Generated at 2022-06-18 05:37:35.680443
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test_bp', url_prefix='test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:41.333749
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop() == FutureException(test_handler, (Exception,))

# Generated at 2022-06-18 05:37:50.478248
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        pass

    bp = Blueprint('test', url_prefix='/test')

    @bp.exception(MyException)
    def handler(request, exception):
        return text('Exception handled')

    @bp.route('/')
    def index(request):
        raise MyException('test')

    app = Sanic('test_ExceptionMixin_exception')
    app.blueprint(bp)
    request, response = app.test_client.get('/test/')
    assert response.text == 'Exception handled'

    # Test for HTTPMethodView
   

# Generated at 2022-06-18 05:37:56.423141
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.name}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler