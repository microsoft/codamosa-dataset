

# Generated at 2022-06-18 05:28:24.936528
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:28:33.360069
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:28:43.151041
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:28:48.441128
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:28:53.734292
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Exception: %s' % exception)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:29:02.219156
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:12.224221
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_exception_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:29:18.122175
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('internal server error', 500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:29:26.634267
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:33.894792
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:42.468547
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:29:50.797376
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:57.533496
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    class MyBlueprint(Blueprint, ExceptionMixin):
        pass

    bp = MyBlueprint('test_bp', url_prefix='/test_bp')

    @bp.exception(ServerError)
    def handler_exception(request, exception):
        return text('Internal Server Error', status=500)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler_exception

# Generated at 2022-06-18 05:30:03.903187
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(MyException)
    def handler(request, exception):
        return 'exception'

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:30:08.745942
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:30:16.751728
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprint import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint("test_blueprint")

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text("OK")

    assert len(blueprint._future_exceptions) == 1
    future_exception = next(iter(blueprint._future_exceptions))
    assert isinstance(future_exception, FutureException)
    assert future_exception.handler == handler
    assert future_exception.exceptions == (SanicException,)

# Generated at 2022-06-18 05:30:22.392767
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:30.553691
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:39.673776
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:50.338104
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:31:04.324663
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class MyException(SanicException):
        pass

    class MyBlueprint(Blueprint, ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            @self.exception(MyException)
            def exception_handler(request: Request, exception: MyException):
                return HTTPResponse(
                    status=exception.status_code,
                    text=exception.description
                )

    bp = MyBlueprint('test_bp')

    @bp.route('/')
    def handler(request):
        raise MyException('test', status_code=500)

    request, response = bp.handle

# Generated at 2022-06-18 05:31:07.613022
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:31:10.719339
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:31:16.161171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Not found', status=404)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:31:24.568258
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:31:29.300947
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:31:39.337199
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    app = Blueprint.create_app(__name__)
    app.blueprint(MyView.as_view())

    @app.exception(MyException)
    def handler(request, exception):
        return json({"exception": exception.__class__.__name__}, status=500)

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.json == {"hello": "world"}

# Generated at 2022-06-18 05:31:47.688471
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class TestException(SanicException):
        pass

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(TestException)
    def test_exception_handler(request, exception):
        return 'exception handler'

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop()
    assert blueprint._exception_handler_args == {TestException}
    assert blueprint._exception_handler_func(None, TestException) == 'exception handler'

# Generated at 2022-06-18 05:31:56.109225
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:32:01.356855
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:32:17.593162
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert isinstance(test_exception_mixin._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:32:25.819207
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler


# Generated at 2022-06-18 05:32:31.892099
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def handler(request, exception):
        return text('Not Found', status=404)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:38.743851
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        status_code = 400

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("OK")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return text("Exception handler", 400)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

    app = bp.create_app()
    request, response = app.test

# Generated at 2022-06-18 05:32:44.849633
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:51.927787
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    exception_mixin_test.exception(Exception)(lambda x: x)
    assert len(exception_mixin_test._future_exceptions) == 1
    assert exception_mixin_test._future_exceptions.pop().handler(Exception) == Exception

# Generated at 2022-06-18 05:32:57.921201
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    assert test_exception_mixin.exception(Exception)
    assert test_exception_mixin._future_exceptions == {FutureException(test_exception_mixin.exception(Exception), (Exception,))}

# Generated at 2022-06-18 05:33:05.234177
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:10.820233
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test_bp', url_prefix='test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:13.742197
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint('test_blueprint')
    blueprint.exception(Exception)(lambda x: x)
    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:33:35.631915
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text('I am view')

    blueprint = Blueprint('test_blueprint')
    blueprint.add_route(MyView.as_view(), '/')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('I am the exception handler', 500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:42.318820
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    bp = Blueprint('test_bp')
    @bp.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', status=500)

    assert len(bp._future_exceptions) == 1
    future_exception = bp._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.exceptions == (ServerError,)

# Generated at 2022-06-18 05:33:50.598844
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:57.795125
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.models.futures import FutureException

    blueprint = Blueprint('test_blueprint', url_prefix='test')
    blueprint.exception(SanicException)(lambda request, exception: text('OK'))

    class MyView(HTTPMethodView):
        def get(self, request):
            raise SanicException('test')

    blueprint.add_route(MyView.as_view(), '/')

    assert len(blueprint._future_exceptions) == 1
    future_exception = blueprint._future_exceptions.pop()
    assert isinstance(future_exception, FutureException)

# Generated at 2022-06-18 05:34:05.962684
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:34:10.906122
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert test_exception_mixin._future_exceptions != set()

# Generated at 2022-06-18 05:34:16.370277
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:34:22.391538
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_exception', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('internal server error', 500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._exception_handler

# Generated at 2022-06-18 05:34:27.125583
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    def test_handler():
        pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(test_handler)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:34:37.939979
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import InvalidUsage
    from sanic.models.exceptions import ServerError
    from sanic.models.exceptions import NotFound
    from sanic.models.exceptions import FileNotFound
    from sanic.models.exceptions import RequestTimeout
    from sanic.models.exceptions import PayloadTooLarge
    from sanic.models.exceptions import MethodNotSupported
    from sanic.models.exceptions import Unauthorized
    from sanic.models.exceptions import Forbidden
    from sanic.models.exceptions import NotAcceptable
    from sanic.models.exceptions import UnsupportedMediaType
    from sanic.models.exceptions import PreconditionFailed

# Generated at 2022-06-18 05:35:15.848637
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:35:21.813966
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:35:26.341904
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:35:34.623102
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:40.381713
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    bp = Blueprint("test_bp")

    @bp.exception(ServerError)
    def handler(request, exception):
        return text("Exception handler")

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:35:47.224852
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:57.936513
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"exception": "handled"}, status=500)

    request, response = bp.test_client.get("/")
    assert response.status == 200
    assert response.json == {"hello": "world"}

    request, response

# Generated at 2022-06-18 05:36:05.307517
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:36:09.476120
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    assert len(exception_mixin_test._future_exceptions) == 0

    @exception_mixin_test.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-18 05:36:12.088579
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:37:33.150319
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:37:38.354171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0
    @test_exception_mixin.exception(Exception)
    def test_exception_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:37:45.903452
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:37:48.382483
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:37:56.495953
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:38:01.592852
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:38:06.491000
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:38:14.720452
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:38:19.973021
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exceptions import SanicException

    class MyException(SanicException):
        pass

    blueprint = Blueprint("test")

    @blueprint.exception(MyException)
    def handler(request, exception):
        return "test"

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1

    future_exception = list(blueprint._future_exceptions)[0]
    assert future_exception.handler == handler
    assert future_exception.exceptions == (MyException,)