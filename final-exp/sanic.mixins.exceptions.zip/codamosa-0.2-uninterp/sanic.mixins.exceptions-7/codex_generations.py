

# Generated at 2022-06-18 05:28:21.523055
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:28:24.237369
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:28:34.465442
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:28:43.812029
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:28:47.987391
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_blueprint', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('internal server error', 500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:28:54.857620
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert test_exception_mixin._future_exceptions != set()

# Generated at 2022-06-18 05:29:01.948531
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert isinstance(test_exception_mixin._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:29:07.293208
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test_bp')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Not found', status=404)

    assert blueprint._future_exceptions

    future_exception = next(iter(blueprint._future_exceptions))
    assert future_exception.handler == handler
    assert future_exception.exceptions == (NotFound,)

# Generated at 2022-06-18 05:29:12.752665
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert test_exception_mixin._future_exceptions == {FutureException(test_handler, (Exception,))}

# Generated at 2022-06-18 05:29:20.297907
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:28.973530
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:33.961717
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:41.835583
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(NotFound)
    def handler(request, exception):
        return json({'exception': 'NotFound'}, status=404)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop() == FutureException(handler, (NotFound,))

# Generated at 2022-06-18 05:29:49.586774
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:54.479994
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:29:59.744347
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:05.888318
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:15.395864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My exception")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"exception": str(exception)}, status=exception.status_code)

    app = bp.create_app()
    request, response = app.test_client.get("/")
    assert response.status == 500

# Generated at 2022-06-18 05:30:19.422183
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint('test_bp')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('I caught an exception!')

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:30:27.470265
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = ExceptionMixinTest()

    @exception_mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(exception_mixin._future_exceptions) == 1
    assert exception_mixin._future_exceptions.pop() == FutureException(exception_handler, (Exception,))

# Generated at 2022-06-18 05:30:42.101258
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    blueprint = Blueprint("test_exception_mixin", url_prefix="/test")
    blueprint.add_route(MyView.as_view(), "/")

    @blueprint.exception(NotFound)
    def ignore_404s(request, exception):
        return json({"status": "ok"})

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == ignore_404s

    # Test for multiple exceptions

# Generated at 2022-06-18 05:30:52.391929
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    class MyOtherException(SanicException):
        pass

    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(MyException)
    def handler(request, exception):
        return text('Exception handler')

    @blueprint.exception([MyOtherException, MyException])
    def handler2(request, exception):
        return text('Exception handler 2')

    assert len(blueprint._future_exceptions) == 2
    assert blueprint._future_exceptions == {
        FutureException(handler, (MyException,)),
        FutureException(handler2, (MyOtherException, MyException))
    }

# Generated at 2022-06-18 05:30:59.941110
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:31:06.102440
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    assert exception_mixin_test._future_exceptions == set()

    @exception_mixin_test.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(exception_mixin_test._future_exceptions) == 1
    assert exception_mixin_test._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:31:13.248166
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    assert exception_mixin_test._future_exceptions == set()

    @exception_mixin_test.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(exception_mixin_test._future_exceptions) == 1
    assert Exception in exception_mixin_test._future_exceptions.pop().exceptions

# Generated at 2022-06-18 05:31:22.947103
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json
    from sanic.views import HTTPMethodView

    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return json({'exception': 'server error'}, status=500)

    @blueprint.route('/')
    def handler(request):
        raise ServerError('server error', status_code=500)

    app = Sanic('test_ExceptionMixin_exception')
    app.blueprint(blueprint)

    request, response = app.test_client.get('/')

    assert response.json == {'exception': 'server error'}
    assert response.status == 500


# Unit

# Generated at 2022-06-18 05:31:31.438868
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    bp = Blueprint("test_exception")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"error": "my exception"}, status=500)

    app = Sanic("test_exception")
    app.blueprint(bp)

    request, response = app.test_client.get("/")

# Generated at 2022-06-18 05:31:38.224106
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:31:49.363296
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    blueprint = Blueprint("test_blueprint")
    blueprint.add_route(MyView.as_view(), "/")

    @blueprint.exception(NotFound)
    def ignore_404s(request, exception):
        return json({"status": 404, "message": "Not found"})

    request, response = blueprint.create_test_request_and_response(
        uri="/", method="GET"
    )
    assert response.status == 200
    assert response.json == {"hello": "world"}

# Generated at 2022-06-18 05:31:56.537237
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.server import HttpProtocol
    from sanic.views import HTTPMethodView

    class TestException(SanicException):
        pass

    class TestView(HTTPMethodView):
        def get(self, request):
            raise TestException("Test")

    class TestBlueprint(Blueprint):
        def register(self, app, options):
            app.add_route(TestView.as_view(), "/test")

    class TestApp(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.blueprint(TestBlueprint())


# Generated at 2022-06-18 05:32:07.262171
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class TestException(SanicException):
        pass

    blueprint = Blueprint('test_blueprint')
    blueprint.exception(TestException)(lambda request, exception: None)
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler is not None

# Generated at 2022-06-18 05:32:12.812157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    @exception_mixin_test.exception(Exception)
    def exception_handler():
        pass

    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-18 05:32:21.014450
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("OK")

    bp = Blueprint("test_bp", url_prefix="/test")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return text("OK")

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop() == FutureException(handler, (MyException,))

# Generated at 2022-06-18 05:32:26.338249
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    blueprint = Blueprint("test_ExceptionMixin_exception")

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return json({"exception": exception.__class__.__name__})

    assert blueprint._future_exceptions

    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:31.056560
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint('test_bp')
    bp.exception(SanicException)(lambda request, exception: None)
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-18 05:32:35.679128
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    bp = Blueprint(name='test', url_prefix='test')

    @bp.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:44.105055
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.models.futures import FutureException

    class TestException(SanicException):
        pass

    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = Blueprint('test', url_prefix='test')
    bp.exception(TestException)(lambda request, exception: text('Test'))
    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:32:52.674551
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text("I'm get method.")

        def post(self, request):
            return text("I'm post method.")

    bp = Blueprint('test_bp', url_prefix='test')
    bp.add_route(MyView.as_view(), '/')

    @bp.exception(NotFound)
    def ignore_404s(request, exception):
        return text("Yep, I totally found the page: {}".format(request.url))

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop

# Generated at 2022-06-18 05:32:57.089796
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def not_found_handler(request, exception):
        return text('Not Found', status=404)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == not_found_handler

# Generated at 2022-06-18 05:33:05.103486
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:33:23.547162
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:33:27.914169
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint("test_bp", url_prefix="/test")

    @bp.exception(Exception)
    def handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:33:33.272555
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    blueprint = Blueprint('test_blueprint')
    blueprint.exception(MyException)(lambda request, exception: None)
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler(None, None) is None

# Generated at 2022-06-18 05:33:39.487230
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    bp = Blueprint('test_bp')

    @bp.exception(ServerError)
    async def handler(request, exception):
        return text('Exception handler')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:45.707009
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:52.168500
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:33:57.149190
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    assert test_exception_mixin.exception(Exception)
    assert test_exception_mixin._future_exceptions != set()

# Generated at 2022-06-18 05:34:07.629966
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.exception_handler = None

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler = handler

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)(lambda x: x)
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin.exception_handler is not None
    assert test_exception_mixin.exception_handler.handler is not None
    assert test_exception_mixin.exception_handler.exceptions == (Exception,)

# Generated at 2022-06-18 05:34:11.882683
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    class MyException(SanicException):
        pass

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(MyException)
    def handler(request, exception):
        return text('Exception handled!')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:34:18.071308
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:34:56.819667
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.futures import FutureException
    from sanic.models.blueprint import Blueprint

    blueprint = Blueprint("test_blueprint", url_prefix="/test")

    @blueprint.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:35:02.457657
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    exception_mixin_test = ExceptionMixinTest()
    assert exception_mixin_test._future_exceptions == set()

    @exception_mixin_test.exception(Exception)
    def exception_handler(request, exception):
        return exception

    assert exception_mixin_test._future_exceptions == {FutureException(exception_handler, (Exception,))}

# Generated at 2022-06-18 05:35:10.755010
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('OK')

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(handler, (SanicException,))

# Generated at 2022-06-18 05:35:13.912934
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:20.781300
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:26.215525
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    class MyBlueprint(Blueprint, ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    bp = MyBlueprint('test')

    @bp.exception(MyException)
    def handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:35:36.520499
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My error message")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"error": str(exception)}, status=exception.status_code)

    app = Sanic("test_app")
    app.blueprint(bp)

    request, response = app.test_client.get("/")
   

# Generated at 2022-06-18 05:35:41.749953
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    exception_mixin_test.exception(Exception)
    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-18 05:35:47.189872
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:56.047317
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:37:18.704703
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.route import Route
    from sanic.models.exceptions import SanicException

    class TestException(SanicException):
        pass

    class TestException2(SanicException):
        pass

    class TestException3(SanicException):
        pass

    class TestException4(SanicException):
        pass

    class TestException5(SanicException):
        pass

    class TestException6(SanicException):
        pass

    class TestException7(SanicException):
        pass

    class TestException8(SanicException):
        pass

    class TestException9(SanicException):
        pass

    class TestException10(SanicException):
        pass

    class TestException11(SanicException):
        pass


# Generated at 2022-06-18 05:37:28.859017
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:37:33.896689
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('internal server error', 500)

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:38.479951
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint

    bp = Blueprint('test_bp', url_prefix='test')
    assert bp._future_exceptions == set()

    @bp.exception(Exception)
    def handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions == {FutureException(handler, (Exception,))}

# Generated at 2022-06-18 05:37:43.956515
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class A(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    a = A()
    @a.exception(Exception)
    def handler(request, exception):
        pass
    assert len(a._future_exceptions) == 1
    assert a._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:51.560290
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json

    blueprint = Blueprint('test_blueprint', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return json({'exception': exception.__class__.__name__}, status=500)

    assert blueprint._future_exceptions
    assert blueprint._exception_handlers
    assert blueprint._exception_handlers[SanicException] == handler

    @blueprint.exception([SanicException, Exception])
    def handler2(request, exception):
        return json({'exception': exception.__class__.__name__}, status=500)

    assert blueprint._future_exceptions
    assert blueprint._exception_handlers
    assert blueprint

# Generated at 2022-06-18 05:38:00.473134
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            raise ServerError("Something bad happened", status_code=500)

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(ServerError)
    def handler(request, exception):
        return text("Exception occurred: {}".format(exception))

    request, response = bp.as_request(
        "GET", "/", headers={"Host": "localhost"}
    )
    assert response.text == "Exception occurred: Something bad happened"

# Generated at 2022-06-18 05:38:04.635342
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_bp', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('internal server error', 500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:38:09.540913
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:38:16.698104
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1