

# Generated at 2022-06-18 05:28:24.930303
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:28:29.620057
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._exception_handlers
    assert blueprint._exception_handlers.pop()

# Generated at 2022-06-18 05:28:35.401208
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:28:42.624901
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return json({'error': 'Internal Server Error'}, 500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:28:45.455398
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:28:49.976543
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:28:56.146768
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            return handler

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        return exception

    assert test_handler(None, Exception) == Exception

# Generated at 2022-06-18 05:29:02.899488
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='test')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Not found', status=404)

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(handler, (NotFound,))


# Generated at 2022-06-18 05:29:08.297373
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    assert test_exception_mixin.exception(Exception)
    assert test_exception_mixin._future_exceptions != set()

# Generated at 2022-06-18 05:29:14.037167
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import InvalidUsage
    from sanic.response import text

    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(InvalidUsage)
    def handler_exception(request, exception):
        return text('OK')

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-18 05:29:22.364207
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:30.111930
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:38.173979
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import NotFound

    blueprint = Blueprint("test_blueprint", url_prefix="/test")

    @blueprint.exception(SanicException)
    def sanic_exception_handler(request, exception):
        return "SanicException"

    @blueprint.exception(NotFound)
    def not_found_exception_handler(request, exception):
        return "NotFound"

    assert len(blueprint._future_exceptions) == 2

    future_exception = FutureException(
        sanic_exception_handler, (SanicException,)
    )
    assert future_exception in blueprint._future_exceptions

    future_

# Generated at 2022-06-18 05:29:43.526190
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint("test_bp", url_prefix="/test")

    @bp.exception(NotFound)
    def handler(request, exception):
        return text("Exception handler")

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop() == FutureException(handler, (NotFound,))

# Generated at 2022-06-18 05:29:53.846552
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert len(test_exception_mixin._future_exceptions.pop().exceptions) == 1
    assert Exception in test_exception_mixin._future_exceptions.pop().exceptions

# Generated at 2022-06-18 05:30:01.458639
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    # Test for method exception of class ExceptionMixin
    # We will create a dummy class which inherits from ExceptionMixin
    # and test if the method exception works as expected
    class DummyExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    dummy_exception_mixin = DummyExceptionMixin()
    # Test if the method exception returns a decorator
    assert callable(dummy_exception_mixin.exception())
    # Test if the method exception returns a decorator which returns a function
    assert callable(dummy_exception_mixin.exception()(lambda: None))
    # Test if the method exception

# Generated at 2022-06-18 05:30:09.946891
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:16.492814
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    def test_handler():
        pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)(test_handler)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:22.025869
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_bp')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('internal error', 500)

    assert blueprint.error_handler.keys() == {SanicException}

    @blueprint.exception([SanicException, Exception])
    def handler2(request, exception):
        return text('internal error', 500)

    assert blueprint.error_handler.keys() == {SanicException, Exception}

# Generated at 2022-06-18 05:30:27.628963
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:40.430220
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:49.438985
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:53.449490
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Not found', status=404)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:31:03.610506
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My Exception")

    bp = Blueprint("test_ExceptionMixin_exception")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"exception": str(exception)}, status=500)

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)

    request, response = app.test_client.get

# Generated at 2022-06-18 05:31:10.896093
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:31:19.989041
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import SanicException

    class TestException(SanicException):
        pass

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(TestException)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_ex

# Generated at 2022-06-18 05:31:29.579907
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            raise ServerError("Oops!", status_code=500)

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(ServerError)
    def handler(request, exception):
        return text("Exception handled!")

    request, response = bp.handle_request(
        bp.app.create_request("/", "GET")
    )
    assert response.text == "Exception handled!"

# Generated at 2022-06-18 05:31:36.521578
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json

    bp = Blueprint('test_ExceptionMixin_exception', url_prefix='test')

    @bp.exception(NotFound)
    def handler(request, exception):
        return json({'exception': exception.name}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:31:40.984356
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:31:50.051342
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:05.090805
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:08.923017
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:14.801356
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint("test_bp")

    @bp.exception(NotFound)
    def handler(request, exception):
        return text("Not Found")

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:21.741352
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0
    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:32:25.722626
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('test_bp', url_prefix='test')
    bp.exception(Exception)(lambda request, exception: None)
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler is not None

# Generated at 2022-06-18 05:32:33.806983
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        return 'test_handler'

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:32:38.887783
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:32:47.141364
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert isinstance(test_exception_mixin._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:32:55.709265
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureException

    class TestException(SanicException):
        pass

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.exception_handler_applied = False

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler_applied = True

    bp = Blueprint('test', url_prefix='/test')
    bp.exception(TestException)(lambda request, exception: None)
    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-18 05:33:00.381348
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_mixin = TestExceptionMixin()
    @test_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:21.105884
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:31.896764
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import ServerError
    from sanic.models.exceptions import URLBuildError
    from sanic.models.exceptions import RequestTimeout
    from sanic.models.exceptions import PayloadTooLarge
    from sanic.models.exceptions import InvalidUsage
    from sanic.models.exceptions import NotFound
    from sanic.models.exceptions import FileNotFound
    from sanic.models.exceptions import Unauthorized
    from sanic.models.exceptions import Forbidden
    from sanic.models.exceptions import MethodNotSupported
    from sanic.models.exceptions import ServerError
    from sanic.models.exceptions import HeaderNotFound


# Generated at 2022-06-18 05:33:37.397972
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:33:46.004965
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0
    test_exception_mixin.exception(Exception)(lambda x: x)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:52.204662
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    test_exception_mixin.exception(Exception)(lambda: None)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:58.923059
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("Something went wrong")

    bp = Blueprint("test_bp", url_prefix="/test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"error": "Something went wrong"}, status=500)

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)

    request, response = app.test_client

# Generated at 2022-06-18 05:34:07.950050
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:34:13.821109
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import SanicExceptionHandler
    from sanic.models.exceptions import SanicExceptionHandlerList
    from sanic.models.exceptions import SanicExceptionHandlerListItem
    from sanic.models.exceptions import SanicExceptionHandlerListItemList
    from sanic.models.exceptions import SanicExceptionHandlerListItemListItem
    from sanic.models.exceptions import SanicExceptionHandlerListItemListItemList
    from sanic.models.exceptions import SanicExceptionHandlerListItemListItemListItem
    from sanic.models.exceptions import SanicExceptionHandlerListItemListItemListItemList
    from sanic.models.exceptions import SanicExceptionHandlerListItemListItemListItemListItem

# Generated at 2022-06-18 05:34:21.804240
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(handler, (SanicException,))

# Generated at 2022-06-18 05:34:25.177140
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exceptions import SanicException

    blueprint = Blueprint(__name__)
    blueprint.exception(SanicException)(lambda request, exception: None)
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler is not None

# Generated at 2022-06-18 05:35:11.399004
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:16.153544
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    blueprint = Blueprint('test', url_prefix='/test')

    @blueprint.exception(NotFound)
    def exception_handler(request, exception):
        return text('Exception handler')

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:35:22.702199
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:29.236324
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import ServerError
    from sanic.models.exceptions import NotFound
    from sanic.models.exceptions import Forbidden
    from sanic.models.exceptions import RequestTimeout
    from sanic.models.exceptions import RequestEntityTooLarge
    from sanic.models.exceptions import UnsupportedMediaType
    from sanic.models.exceptions import PayloadTooLarge
    from sanic.models.exceptions import URITooLong
    from sanic.models.exceptions import MethodNotAllowed
    from sanic.models.exceptions import NotAcceptable
    from sanic.models.exceptions import Unauthorized
    from sanic.models.exceptions import Forbidden

# Generated at 2022-06-18 05:35:35.126972
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    blueprint = Blueprint('test', url_prefix='/test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Exception: %s' % exception)

    assert blueprint.exception_handlers[0].handler == handler
    assert blueprint.exception_handlers[0].exceptions == (ServerError,)

# Generated at 2022-06-18 05:35:42.672656
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text
    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(ServerError)
    async def handler(request, exception):
        return text('Exception handler')

    assert len(bp._future_exceptions) == 1
    future_exception = bp._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.exceptions == (ServerError,)

# Generated at 2022-06-18 05:35:48.328557
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:35:55.816661
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)(lambda: None)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:36:05.670554
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My message")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"exception": exception.args[0]}, status=500)

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)

    request, response = app.test_client.get("/")


# Generated at 2022-06-18 05:36:09.185536
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Not Found', status=404)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:33.467738
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:37:38.652253
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_exception_mixin = TestExceptionMixin()
    def test_handler():
        pass
    test_exception_mixin.exception(test_handler)
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:37:43.850383
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint('test_blueprint', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Exception: %s' % exception)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:48.686017
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:37:53.022765
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            assert handler.handler == handler
            assert handler.exceptions == (Exception,)

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)(handler)

# Generated at 2022-06-18 05:37:58.844778
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text
    from sanic.models.futures import FutureException

    bp = Blueprint('test', url_prefix='/test')

    @bp.exception(ServerError)
    async def handler(request, exception):
        return text('OK')

    assert len(bp._future_exceptions) == 1

    future_exception = FutureException(handler, (ServerError,))
    assert future_exception in bp._future_exceptions

# Generated at 2022-06-18 05:38:06.199557
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.exception_handler = None

        def _apply_exception_handler(self, handler: FutureException):
            self.exception_handler = handler

    test_mixin = TestExceptionMixin()
    @test_mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert test_mixin.exception_handler.handler == exception_handler
    assert test_mixin.exception_handler.exceptions == (Exception,)
    assert test_mixin.exception_handler.kwargs == {}

    test_mixin = TestExceptionMixin()

# Generated at 2022-06-18 05:38:15.344549
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from unittest.mock import patch

    class TestException(SanicException):
        pass

    class TestView(HTTPMethodView):
        def get(self, request: Request):
            return HTTPResponse(text="OK")

    blueprint = Blueprint("test", url_prefix="/test")
    blueprint.add_route(TestView.as_view(), "/")

    @blueprint.exception(TestException)
    def exception_handler(request: Request, exception: TestException):
        return HTTPResponse(text="OK")


# Generated at 2022-06-18 05:38:19.165128
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert test_exception_mixin._future_exceptions