

# Generated at 2022-06-18 05:28:14.722935
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:28:19.688742
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    exception_mixin_test.exception(Exception)
    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-18 05:28:22.910796
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:28:31.177470
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Internal server error', 500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-18 05:28:35.805666
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin = TestExceptionMixin()
    assert len(exception_mixin._future_exceptions) == 0

    @exception_mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:28:43.687593
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:28:49.098441
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.name}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:28:54.071180
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)(lambda: None)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:01.479890
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler


# Generated at 2022-06-18 05:29:09.210640
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.request import Request
    from sanic.models.futures import FutureException

    class MyException(SanicException):
        pass

    class MyBlueprint(Blueprint, ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = MyBlueprint('test_blueprint')

    @blueprint.exception(MyException)
    def handler(request: Request, exception: MyException):
        return json({'exception': 'MyException'})

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(handler, (MyException,))

# Generated at 2022-06-18 05:29:18.435436
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    bp = Blueprint('test_bp')

    @bp.exception(MyException)
    def my_exception_handler(request, exception):
        return text('my_exception_handler')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop() == FutureException(my_exception_handler, (MyException,))

# Generated at 2022-06-18 05:29:29.253607
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    bp = Blueprint("test_exception")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handle_exception(request, exception):
        return json({"exception": "handled"}, status=exception.status_code)

    app = bp.create_app()
    request, response = app.test_client.get("/")

# Generated at 2022-06-18 05:29:36.503859
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:43.525964
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:29:50.532609
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint("test_blueprint", url_prefix="/test")

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text("Internal Server Error", status=500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:29:56.693617
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:04.502802
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:09.777484
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json

    blueprint = Blueprint('test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return json({'exception': 'SanicException'})

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:30:15.026616
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    bp = Blueprint('test_bp')

    @bp.exception(MyException)
    def handler(request, exception):
        pass

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:30:19.971327
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(NotFound)
    def handler_not_found(request, exception):
        return text('Not found', status=404)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler_not_found

# Generated at 2022-06-18 05:30:30.698326
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text
    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop() == FutureException(handler, (ServerError,))

# Generated at 2022-06-18 05:30:42.015390
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My exception")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"error": str(exception)}, status=exception.status_code)

    app = Sanic("test_sanic_exception")
    app.blueprint(bp)


# Generated at 2022-06-18 05:30:49.859792
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:52.241089
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:59.941376
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import SanicException

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        pass

    assert blueprint._future_exceptions == {
        FutureException(handler, (SanicException,))
    }

# Generated at 2022-06-18 05:31:05.004168
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:31:10.684340
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Not found', status=404)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-18 05:31:19.805709
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super(TestExceptionMixin, self).__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler


# Generated at 2022-06-18 05:31:24.291875
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    bp = Blueprint('test_bp')

    @bp.exception(MyException)
    def my_exception_handler(request, exception):
        return text('my_exception_handler')

    @bp.exception([MyException, Exception])
    def my_exception_handler2(request, exception):
        return text('my_exception_handler2')

    assert len(bp._future_exceptions) == 2
    assert bp._future_exceptions == {
        FutureException(my_exception_handler, (MyException,)),
        FutureException(my_exception_handler2, (MyException, Exception))
    }

# Generated at 2022-06-18 05:31:29.136047
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0
    test_exception_mixin.exception(Exception)(lambda x: x)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:31:40.928838
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return json({'exception': 'NotFound'})

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:31:48.764159
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    @exception_mixin_test.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(exception_mixin_test._future_exceptions) == 1
    assert exception_mixin_test._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:31:57.077235
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:03.744909
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:07.836193
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic('test_ExceptionMixin_exception')
    bp = Blueprint('test_ExceptionMixin_exception')

    @bp.exception(Exception)
    def handler(request, exception):
        return text('Exception: %s' % exception)

    app.blueprint(bp)
    request, response = app.test_client.get('/')
    assert response.text == 'Exception: Not Found'

# Generated at 2022-06-18 05:32:14.098969
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('internal server error', status=500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-18 05:32:19.789917
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.name}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1

    future_exception = bp._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.exceptions == (ServerError,)

# Generated at 2022-06-18 05:32:24.670481
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint('test_bp')

    @bp.exception(SanicException)
    def handler(request, exception):
        return text('Exception handler')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:32.741461
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:36.391858
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:56.399621
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test_exception', url_prefix='test_exception')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', 500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:04.908436
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    assert len(exception_mixin_test._future_exceptions) == 0

    @exception_mixin_test.exception(Exception)
    def exception_handler():
        pass

    assert len(exception_mixin_test._future_exceptions) == 1
    assert exception_mixin_test._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:33:10.518060
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint(__name__)

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text(str(exception))

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:15.023192
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:22.106031
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:33:28.265987
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:33:34.030705
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:42.283035
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:33:49.763590
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_exception_mixin', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Exception handler')

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._exception_handler(None, SanicException()) == text('Exception handler')

# Generated at 2022-06-18 05:33:55.308766
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:34:34.937216
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:34:42.785533
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.models.futures import FutureException

    class MyException(SanicException):
        pass

    class MyException2(SanicException):
        pass

    class MyException3(SanicException):
        pass

    class MyException4(SanicException):
        pass

    class MyException5(SanicException):
        pass

    class MyException6(SanicException):
        pass

    class MyException7(SanicException):
        pass

    class MyException8(SanicException):
        pass

    class MyException9(SanicException):
        pass

    class MyException10(SanicException):
        pass

    class MyException11(SanicException):
        pass


# Generated at 2022-06-18 05:34:45.808998
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert test_exception_mixin._future_exceptions

# Generated at 2022-06-18 05:34:52.321516
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def exception_handler(request, exception):
        return 'exception handler'

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:34:56.672914
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:35:02.930784
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class MyException(SanicException):
        pass

    class MyException2(SanicException):
        pass

    class MyException3(SanicException):
        pass

    class MyException4(SanicException):
        pass

    class MyException5(SanicException):
        pass

    class MyException6(SanicException):
        pass

    class MyException7(SanicException):
        pass

    class MyException8(SanicException):
        pass

    class MyException9(SanicException):
        pass

    class MyException10(SanicException):
        pass

    class MyException11(SanicException):
        pass

    class MyException12(SanicException):
        pass


# Generated at 2022-06-18 05:35:09.164873
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint("test_bp", url_prefix="/test")

    @bp.exception(SanicException)
    def handler(request, exception):
        return text("OK")

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:35:14.227833
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(SanicException)
    def handle_exception(request, exception):
        pass

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handle_exception

# Generated at 2022-06-18 05:35:19.742157
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', status=500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-18 05:35:25.417388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('OK')

    assert blueprint._future_exceptions
    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop() == FutureException(handler, (SanicException,))

# Generated at 2022-06-18 05:36:35.826714
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError

    blueprint = Blueprint("test_blueprint", url_prefix="/test")

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text("OK")

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:36:38.443023
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    @exception_mixin_test.exception(Exception)
    def exception_handler(request, exception):
        pass
    assert len(exception_mixin_test._future_exceptions) == 1

# Generated at 2022-06-18 05:36:44.852722
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:36:49.517783
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:36:54.665700
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    bp = Blueprint('test', url_prefix='test')

    @bp.exception(SanicException)
    def handler(request, exception):
        return text('Exception: %s' % exception)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:01.470818
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.testing import SanicTestClient
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("Something bad happened")

    class MyBlueprint(Blueprint):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.add_route(MyView.as_view(), "/")

    app = Sanic("test_ExceptionMixin_exception")

# Generated at 2022-06-18 05:37:07.008046
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test_bp', url_prefix='test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', status=500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:12.530687
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.name}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:37:17.304363
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_exception_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:37:22.958944
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)