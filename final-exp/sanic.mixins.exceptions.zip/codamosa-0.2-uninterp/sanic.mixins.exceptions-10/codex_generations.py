

# Generated at 2022-06-18 05:28:29.077986
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My message")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"exception": str(exception)}, status=exception.status_code)

    app = Sanic("test_app")
    app.blueprint(bp)

    request, response = app.test_client.get("/")
   

# Generated at 2022-06-18 05:28:36.051672
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:28:42.714911
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    class MyException(SanicException):
        pass

    bp = Blueprint('test_bp')

    @bp.exception(MyException)
    def handler(request, exception):
        return text('Exception handled!')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:28:49.003573
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            raise NotImplementedError  # noqa

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        return exception

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:28:55.515830
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(ValueError)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:04.000518
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:11.119296
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.name})

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:29:19.543334
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:24.024704
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)

# Generated at 2022-06-18 05:29:32.001108
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:29:41.059900
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def handler_404(request, exception):
        return text('Not Found', status=404)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler_404

# Generated at 2022-06-18 05:29:52.090765
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException('My exception')

    blueprint = Blueprint('test_ExceptionMixin_exception')
    blueprint.add_route(MyView.as_view(), '/')

    @blueprint.exception(MyException)
    def handler(request, exception):
        return json({'exception': str(exception)}, status=500)

    app = Sanic('test_ExceptionMixin_exception')
    app.blueprint(blueprint)

    request, response = app.test_client.get

# Generated at 2022-06-18 05:29:56.528456
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixin_test(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test = ExceptionMixin_test()
    @test.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test._future_exceptions) == 1
    assert test._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:07.594083
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        pass

    bp = Blueprint("test_bp", url_prefix="/test")

    @bp.exception(MyException)
    def handler(request, exception):
        return text("Exception handled")

    @bp.route("/")
    def handler(request):
        raise MyException("Test exception")

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

    @bp.route("/")
    async def handler(request):
        raise MyException("Test exception")

# Generated at 2022-06-18 05:30:11.928084
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException

    blueprint = Blueprint(__name__)
    blueprint.exception(Exception)(lambda request, exception: None)

    assert len(blueprint._future_exceptions) == 1
    assert isinstance(blueprint._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:30:18.115291
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def handler(request, exception):
        return text('Not Found', status=404)

    assert len(bp._future_exceptions) == 1

    future_exception = bp._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.exceptions == (NotFound,)

# Generated at 2022-06-18 05:30:26.609488
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:30:31.679153
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:30:42.259071
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"exception": exception.__class__.__name__})

    assert len(bp._future_exceptions) == 1

# Generated at 2022-06-18 05:30:52.671935
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import ServerError

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    blueprint = Blueprint('test', url_prefix='test')
    blueprint.exception(SanicException)(lambda request, exception: None)
    blueprint.exception(ServerError, apply=False)(lambda request, exception: None)
    assert len(blueprint._future_exceptions) == 2

# Generated at 2022-06-18 05:31:02.489321
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test", url_prefix="/test")
    assert bp._future_exceptions == set()
    @bp.exception(Exception)
    def handler(request, exception):
        pass
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop() == FutureException(handler, (Exception,))

# Generated at 2022-06-18 05:31:13.972820
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        status_code = 400

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My message")

    bp = Blueprint("test_bp", url_prefix="/test")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"error": exception.args[0]}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler

# Generated at 2022-06-18 05:31:18.449623
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass
    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert test_exception_mixin._future_exceptions

# Generated at 2022-06-18 05:31:26.671388
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self):
            super().__init__()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:31:35.200628
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    @TestExceptionMixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(TestExceptionMixin._future_exceptions) == 1
    assert TestExceptionMixin._future_exceptions.pop() == FutureException(exception_handler, (Exception,))

# Generated at 2022-06-18 05:31:40.929076
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert isinstance(
        list(test_exception_mixin._future_exceptions)[0], FutureException
    )

# Generated at 2022-06-18 05:31:50.003357
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

    @test_exception_mixin.exception([Exception, ValueError])
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 2

# Generated at 2022-06-18 05:31:56.070893
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def not_found_handler(request, exception):
        return response.text('Not found', status=404)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == not_found_handler

# Generated at 2022-06-18 05:31:58.670325
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test_bp")
    assert bp._future_exceptions == set()
    assert bp.exception(Exception)
    assert bp._future_exceptions != set()

# Generated at 2022-06-18 05:32:04.098481
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:19.143751
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert isinstance(test_exception_mixin._future_exceptions.pop(), FutureException)

# Generated at 2022-06-18 05:32:25.825074
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import text

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def handler(request, exception):
        return text('Not found', status=404)

    assert len(bp._future_exceptions) == 1
    future_exception = bp._future_exceptions.pop()
    assert future_exception.handler == handler
    assert future_exception.exceptions == (NotFound,)

# Generated at 2022-06-18 05:32:35.642864
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My exception")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return text("Exception handled")

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)

    request, response = app.test_client.get("/")

    assert response.text == "Exception handled"

# Generated at 2022-06-18 05:32:43.491888
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class ExceptionMixinTest(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    exception_mixin_test = ExceptionMixinTest()
    assert exception_mixin_test._future_exceptions == set()

    @exception_mixin_test.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(exception_mixin_test._future_exceptions) == 1
    assert exception_mixin_test._future_exceptions.pop().handler == exception_handler

# Generated at 2022-06-18 05:32:48.525585
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(NotFound)
    def handler(request, exception):
        return json({'exception': 'NotFound'}, status=404)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:32:52.868253
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:32:57.922619
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def exception_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert exception_handler.__name__ == 'exception_handler'

# Generated at 2022-06-18 05:33:04.728127
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.name}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:07.565508
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint(__name__)
    assert bp.exception(Exception)


# Generated at 2022-06-18 05:33:13.355695
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler():
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:33:34.065726
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json
    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.name}, status=exception.status_code)

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:42.590692
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:33:52.632821
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.models.futures import FutureException
    from sanic.models.exceptions import SanicException

    class TestException(SanicException):
        pass

    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_blueprint = Blueprint('test_blueprint', url_prefix='/test')
    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(TestException)(lambda request, exception: None)
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test

# Generated at 2022-06-18 05:33:56.334991
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound

    blueprint = Blueprint('test_ExceptionMixin_exception')

    @blueprint.exception(NotFound)
    def handler(request, exception):
        return text('Exception handler')

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:33:59.611199
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    blueprint = Blueprint('test_bp', url_prefix='test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return json({'exception': 'server error'})

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint._future_exceptions == set()

# Generated at 2022-06-18 05:34:05.359627
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(Exception)
    def handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:34:10.261412
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text

    blueprint = Blueprint('test', url_prefix='test')

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return text('Internal Server Error', status=500)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:34:18.151675
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_blueprint')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Internal Server Error', status=500)

    assert blueprint._future_exceptions
    assert blueprint._future_exceptions.pop()
    assert blueprint.exception_handler_funcs
    assert blueprint.exception_handler_funcs[SanicException] == handler


# Generated at 2022-06-18 05:34:24.725587
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert len(test_exception_mixin._future_exceptions) == 0

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:34:32.194474
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.response import json

    bp = Blueprint('test_bp', url_prefix='test')

    @bp.exception(NotFound)
    def ignore_404s(request, exception):
        return json({'status': 'ok'})

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == ignore_404s

# Generated at 2022-06-18 05:35:11.909266
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test_ExceptionMixin_exception', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Exception: %s' % exception)

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:35:15.924809
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json

    blueprint = Blueprint('test_blueprint', url_prefix='test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    assert blueprint.error_handler_spec[SanicException] == handler

    @blueprint.exception([SanicException, Exception])
    def handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    assert blueprint.error_handler_spec[SanicException] == handler
    assert blueprint.error_handler_spec[Exception] == handler

# Generated at 2022-06-18 05:35:20.279697
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint("test_bp")
    assert bp._future_exceptions == set()
    @bp.exception(Exception)
    def handler(request, exception):
        pass
    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:35:25.047237
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json

    bp = Blueprint('test_bp')

    @bp.exception(ServerError)
    def handler(request, exception):
        return json({'exception': exception.__class__.__name__})

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == handler

# Generated at 2022-06-18 05:35:35.240705
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.models.blueprint import Blueprint
    from sanic.models.exceptions import SanicException
    from sanic.models.exceptions import ServerError
    from sanic.models.exceptions import NotFound
    from sanic.models.exceptions import InvalidUsage
    from sanic.models.exceptions import RequestTimeout
    from sanic.models.exceptions import PayloadTooLarge
    from sanic.models.exceptions import FileTooLarge
    from sanic.models.exceptions import HeaderNotFound
    from sanic.models.exceptions import UnsupportedMediaType
    from sanic.models.exceptions import UnprocessableEntity
    from sanic.models.exceptions import MethodNotSupported
    from sanic.models.exceptions import RangeNotSatisfiable
    from sanic.models.exceptions import ExpectationFailed

# Generated at 2022-06-18 05:35:42.784503
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    assert test_exception_mixin.exception(Exception)
    assert test_exception_mixin._future_exceptions != set()

# Generated at 2022-06-18 05:35:48.638495
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_exception_handler(request, exception):
        pass
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:35:59.491351
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyException(SanicException):
        pass

    class MyView(HTTPMethodView):
        def get(self, request):
            raise MyException("My exception")

    bp = Blueprint("test_bp")
    bp.add_route(MyView.as_view(), "/")

    @bp.exception(MyException)
    def handler(request, exception):
        return json({"error": str(exception)}, status=exception.status_code)

    app = Sanic("test_ExceptionMixin_exception")
    app.blueprint(bp)


# Generated at 2022-06-18 05:36:05.043072
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    class TestException(SanicException):
        pass

    blueprint = Blueprint('test', url_prefix='/test')

    @blueprint.exception(TestException)
    def test_exception_handler(request, exception):
        return 'test exception'

    assert len(blueprint._future_exceptions) == 1
    assert blueprint._future_exceptions.pop().handler == test_exception_handler

# Generated at 2022-06-18 05:36:09.505488
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:37:27.326360
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    bp = Blueprint('test_bp', url_prefix='test')
    assert bp._future_exceptions == set()
    @bp.exception(Exception)
    def handler(request, exception):
        pass
    assert len(bp._future_exceptions) == 1
    assert isinstance(bp._future_exceptions.pop(), FutureException)


# Generated at 2022-06-18 05:37:36.062249
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import json
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return json({"hello": "world"})

    blueprint = Blueprint("test_exception")
    blueprint.add_route(MyView.as_view(), "/")

    @blueprint.exception(ServerError)
    def handler(request, exception):
        return json({"error": "Internal Server Error"}, status=500)

    assert len(blueprint.exception_handlers) == 1
    assert blueprint.exception_handlers[0].handler == handler
    assert blueprint.exception_handlers[0].exceptions == (ServerError,)

# Generated at 2022-06-18 05:37:41.879692
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            self._future_exceptions: Set[FutureException] = set()

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler == test_handler

# Generated at 2022-06-18 05:37:49.748877
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()
    test_exception_mixin.exception(Exception)(lambda x: x)
    assert len(test_exception_mixin._future_exceptions) == 1
    assert test_exception_mixin._future_exceptions.pop().handler(Exception) == Exception

# Generated at 2022-06-18 05:37:58.891326
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import ServerError
    from sanic.response import text
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request):
            return text('I am get method')

        def post(self, request):
            return text('I am post method')

    bp = Blueprint('test_bp', url_prefix='test')
    bp.add_route(MyView.as_view(), '/myview')

    @bp.exception(ServerError)
    def server_error_handler(request, exception):
        return text('I am server error handler')

    assert len(bp._future_exceptions) == 1
    assert bp._future_exceptions.pop().handler == server_error_

# Generated at 2022-06-18 05:38:02.961165
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    assert test_exception_mixin._future_exceptions == set()

    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:38:09.060499
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def _apply_exception_handler(self, handler: FutureException):
            pass

    test_exception_mixin = TestExceptionMixin()
    @test_exception_mixin.exception(Exception)
    def test_handler(request, exception):
        pass

    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:38:14.167118
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    class TestExceptionMixin(ExceptionMixin):
        def _apply_exception_handler(self, handler: FutureException):
            pass

    def test_handler():
        pass

    test_exception_mixin = TestExceptionMixin()
    test_exception_mixin.exception(Exception)(test_handler)
    assert len(test_exception_mixin._future_exceptions) == 1

# Generated at 2022-06-18 05:38:18.816026
# Unit test for method exception of class ExceptionMixin
def test_ExceptionMixin_exception():
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException
    from sanic.response import text

    blueprint = Blueprint('test', url_prefix='/test')

    @blueprint.exception(SanicException)
    def handler(request, exception):
        return text('Internal server error', 500)

    assert blueprint._future_exceptions
    assert blueprint._exception_handlers
    assert blueprint._exception_handlers[SanicException] == handler