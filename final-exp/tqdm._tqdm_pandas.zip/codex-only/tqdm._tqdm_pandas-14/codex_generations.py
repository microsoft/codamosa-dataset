

# Generated at 2022-06-24 09:35:56.431494
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame
    from pandas.api.types import is_string_dtype
    import pandas as pd
    import numpy as np
    import os
    import contextlib
    #from tqdm import tqdm_notebook  # noqa

    # Add `tqdm_notebook` in order to test it.
    # Test Notebook backend
    original_tqdm = tqdm
    tqdm = getattr(tqdm.tqdm_notebook, 'tqdm', tqdm)

    # Unit test for function tqdm_pandas
    TEST_STRING_FUN = lambda x: x.title()
    TEST_DATA_FUN = lambda x: pd.DataFrame(x)

# Generated at 2022-06-24 09:36:03.693150
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm_pandas

    df = DataFrame({'str': ['h', 'e', 'l', 'l', 'o'] * 10})
    for __ in tqdm_pandas(df.groupby('str').progress_apply(len)):
        pass

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:11.665352
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(
        {'a': np.random.randint(0, 100, (100000,)),
         'b': np.random.randint(0, 100, (100000,))})

    # Register tqdm instance with `pandas.core.groupby.DataFrameGroupBy.progress_apply`
    with tqdm(total=len(df['a'].unique())) as t:
        t.set_description('test_tqdm_pandas')
        tqdm_pandas(t)
        df.groupby('a')['b'].progress_apply(lambda x: x ** 2).sum()

        # Yeah, we're done here
        t.close()

# Generated at 2022-06-24 09:36:15.903377
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    df = pd.DataFrame([4, 2, 3, 1])
    tqdm_pandas(tqdm)
    assert df.progress_apply(lambda x: x + 1)[0] == 5

# Generated at 2022-06-24 09:36:18.114544
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from time import sleep
    from tqdm.contrib.tests import dummy_df
    tqdm_pandas(tqdm(total=3, desc='my tqdm'))
    dummy_df.groupby('a').progress_apply(lambda x: sleep(0.1))

# Generated at 2022-06-24 09:36:24.483688
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_notebook, trange

    for tcls in (tqdm, tqdm_notebook, trange):
        tcls_pandas = tqdm_pandas(tcls)

        df = pd.DataFrame({'a': list(range(10)), 'b': list(range(10, 0, -1))})
        for cls in (pd.DataFrame, pd.Series):
            for it in cls([df, df]).groupby('a').progress_apply(
                    lambda x: x*x.a.cumsum() + x.b.cummin(), convert_dtype=True):
                assert(cls(it).equals(cls(df)))

        df = pd.DataFrame

# Generated at 2022-06-24 09:36:33.668350
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests `tqdm.pandas`.
    """
    import pandas as pd
    import numpy as np
    import math
    from tqdm import tqdm_pandas, tqdm

    pd.DataFrame.progress_apply = lambda self, func, iterate_over, **kwargs: \
        tqdm_pandas(self.apply(func, iterate_over, **kwargs))

    N = 1000
    df = pd.DataFrame(np.random.randint(N, size=(N, 4)), columns=['A', 'B', 'C', 'D'])
    df['E'] = df['A'].progress_apply(math.sqrt)

# Generated at 2022-06-24 09:36:43.290804
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas
    import numpy
    import tqdm
    tqdm_pandas(tqdm)
    df = pandas.DataFrame(numpy.random.randint(0, 100, (100000, 6)))
    means = df.groupby(0).progress_apply(numpy.mean)
    assert len(means) == 100
    print(means)

# Safely import tqdm.tqdm_gui, if available
try:
    from .gui import tqdm_gui
except ImportError:
    pass

# If not in IPython, and have IPython, use the IPython backend

# Generated at 2022-06-24 09:36:50.222691
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:36:55.094088
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm_pandas(total=100) as pbar:
        for x in range(100):
            pbar.update()
    # Regression tests for #979
    tqdm_pandas(tqdm(total=0, file=sys.stdout), file=sys.stdout)
    tqdm_pandas(tqdm(total=0, file=sys.stdout, position=0),
                file=sys.stdout, position=0)
    tqdm_pandas(tqdm(total=0, file=sys.stdout, position=1),
                file=sys.stdout, position=1)

# Generated at 2022-06-24 09:37:06.698028
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_pandas

    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(total=100))  # delayed case
    tqdm_pandas(tqdm(total=100), leave=False)  # delayed case
    tqdm_pandas(tqdm(), leave=False)  # delayed case
    df = pd.DataFrame({'x': [1, 2, 3, 4, 5]})
    df.groupby('x')\
        .progress_apply(lambda x: x.count(),
                       tqdm_kwargs={'leave': False, 'total': len(df)})



# Generated at 2022-06-24 09:37:12.492298
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return None

    def progress_apply_func(x):
        return x.max() - x.min()

    df = pd.DataFrame({'col': range(10)})
    df.groupby('col').progress_apply(progress_apply_func)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:19.461112
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy

    try:
        from tqdm.pandas import tqdm_pandas
    except ImportError:
        from tqdm import tqdm_pandas

    n = 1000000
    df = pandas.DataFrame(numpy.random.rand(n, 5), columns=list('ABCDE'))
    tqdm_pandas(tqdm_kwargs={'desc': 'test'})
    for col in df:
        df[col] = df[col].progress_apply(
            lambda x: x * 2)  # pandas.core.groupby.DataFrameGroupBy.progress_apply
    with tqdm_pandas(total=len(df)) as pbar:
        df.apply(lambda x: x * 2, axis=1).progress_

# Generated at 2022-06-24 09:37:26.242455
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        pd.Series(range(1000)).progress_apply(lambda x: x**x)
        pd.DataFrame(range(1000)).progress_apply(lambda x: x**x)
        pd = None
    except (TypeError, ImportError):
        pass


if __name__ == "__main__":
    from .main import _test_func
    _test_func(test_tqdm_pandas)

# Generated at 2022-06-24 09:37:30.629676
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    from pandas import DataFrame

    @tqdm.tqdm_pandas
    def some_apply_after(df):
        return df.x.sum()

    df = DataFrame({'x': [1, 2, 3, 4]})
    assert some_apply_after(df) == 10


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:40.703866
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm_pandas
    from tqdm.autonotebook import trange

    tqdm_pandas(tqdm_kwargs={'desc': 'A'})
    tqdm_pandas(tqdm_kwargs={'desc': 'A'})
    tqdm_pandas(tqdm_kwargs={'desc': 'A'})
    tqdm_pandas(tqdm_kwargs={'desc': 'A'})
    tqdm_pandas(tqdm_kwargs={'desc': 'A'})
    tqdm_pandas(tqdm_kwargs={'desc': 'A'})

# Generated at 2022-06-24 09:37:46.331895
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    import numpy as np

    from tqdm import tqdm

    N = 1000

    try:
        from pandas import DataFrame
    except ImportError:
        DataFrame = pd.Series

    df = DataFrame(np.random.random([N, N]))

    # Works
    with tqdm(total=N) as pbar:
        df.progress_apply(lambda x: x**2, axis=1,
                          progress_apply=pbar.update)

    # Fails
    with tqdm(total=N) as pbar:
        def f(x): return x**2
        df.progress_apply(f, axis=1, progress_apply=pbar.update)

    # Works

# Generated at 2022-06-24 09:37:48.173996
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    tqdm_pandas(tqdm.tqdm_notebook)

# Generated at 2022-06-24 09:37:53.256263
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    pd.DataFrame([1, 2, 3]).progress_apply(lambda x: x + 1,
                                           deprecated_t_unless_tqdm_off=tqdm.tqdm(
                                               total=3, desc='test', leave=False))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:00.438756
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test tqdm_pandas"""
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        # Trigger a warning.
        tqdm_pandas(tqdm)
        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)
        assert "Please use `tqdm.pandas(...)` instead" in str(w[-1].message)



# Generated at 2022-06-24 09:38:08.392805
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _range
    from tqdm.pandas import trange

    n = 10
    with trange(n) as t:
        dt = t.tqdm_pandas()
        for i in _range(n):
            assert (dt.handle == t), "External loop handle not preserved!"
            dt.update(i)
            assert (dt.n == i), "External loop progress not preserved!"
            assert (t.n == i), "External loop progress not updated!"
            assert (dt.handle == t), "External loop handle not preserved!"

# Generated at 2022-06-24 09:38:10.719405
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(range(100)))



# Generated at 2022-06-24 09:38:12.312992
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas
    assert pandas.__name__ == 'tqdm.pandas'

# Generated at 2022-06-24 09:38:18.923226
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from string import ascii_letters as ascii
    import random, time
    df = pd.Series([random.choice(ascii) for _ in range(100000)])

    # dummy class
    class tqdm:
        @staticmethod
        def pandas(tqdm):  # this is the actual code, with print statements:
            assert isinstance(tqdm, type(tqdm)), \
                'tqdm(...) required for tqdm_pandas(tqdm, ...)'
            assert getattr(tqdm, '__name__', '').startswith('tqdm_')
            print('pandas "groupby" apply...')
            time.sleep(0.5)  # artificial sleep


# Generated at 2022-06-24 09:38:26.950846
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import tqdm, TqdmDeprecationWarning
    import warnings

    with warnings.catch_warnings():
        warnings.filterwarnings(
            'ignore',
            category=TqdmDeprecationWarning,
            message='Please use `tqdm.pandas(...)'
        )
        tqdm_pandas(tqdm)

    try:
        DataFrameGroupBy.progress_apply
    except AttributeError:
        raise AssertionError(
            'method `DataFrameGroupBy.progress_apply` is not registered')

# Generated at 2022-06-24 09:38:38.497504
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # NOTE: tests may raise DeprecationWarning for tqdm_pandas function
    from .std import tqdm
    from pandas import DataFrame

    # Test with a tqdm instance
    test_inst = tqdm()
    assert(test_inst.registry == {})

    tqdm_pandas(test_inst)
    assert(test_inst.registry[DataFrame].__name__ ==
           'tqdm_pandas_apply_progress')

    # Test with tqdm class with deprecated __name__ attribute
    test_class = type(type(tqdm)('Tqdm', (tqdm,), {})('TestTqdmName', ()
                                                      ))('TestTqdmName', ())
    assert(test_class.registry == {})

    tqdm_

# Generated at 2022-06-24 09:38:48.797237
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0,100,size=(100000, 4)),
                      columns=list('ABCD'))

    # Apply tqdm_pandas on pandas
    tqdm_pandas(tqdm)
    res = df.groupby('A').progress_apply(lambda x: x)
    assert (df.columns == res.columns).all()
    assert (df.index == res.index).all()

    # Apply tqdm_pandas on tqdm
    tqdm_pandas(tqdm)
    res = df.groupby('A').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:38:57.645842
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    data = {'a': [1, 2, 3, 4, 5], 'b': [5, 4, 3, 2, 1]}
    df = DataFrame(data)

    for _ in tqdm(df.groupby('b').progress_apply(lambda x: x)):
        pass

    tqdm_pandas(tqdm, leave=False)(df.groupby('b').progress_apply(lambda x: x))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:08.217127
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import warnings

    # creating a dataframe
    df = pd.DataFrame(np.random.randint(low=0, high=100, size=(100000, 4)),
                      columns=['A', 'B', 'C', 'D'])

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")

        # Create test cases
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(total=100))

        # Check for deprecation warnings
        for v in w:
            assert issubclass(v.category, TqdmDeprecationWarning)

# Generated at 2022-06-24 09:39:10.331519
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class tclass:
        class __name__:
            startswith = lambda self, x: True

    tqdm_pandas(tclass)

# Generated at 2022-06-24 09:39:21.194708
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import sys
    import io
    import tqdm as tqdm

    def test_function(x):
        return x

    # Create a pandas dataframe with 3 columns and 10 rows
    df = pd.DataFrame(np.arange(30).reshape(10, 3),
                      columns=['a', 'b', 'c'])

    # Capture stdout
    with io.StringIO() as buf, redirect_stdout(buf):
        tqdm.pandas(**{'file': sys.stdout})
        # Apply a function to each row using the tqdm_pandas() function
        df.progress_apply(test_function, axis=1)
        captured_stdout = buf.getvalue()

    tqdm_text = captured

# Generated at 2022-06-24 09:39:28.463783
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    # using a dummy DataFrame
    df = pd.DataFrame(data={"X": range(30),
                            "Y": range(10, 40),
                            "Z": range(100, 130)})

    # without tqdm_pandas
    df_new = df.groupby("X").sum()
    print("\n", df_new, sep="")

    # with tqdm_pandas
    tqdm_pandas(tqdm.tqdm)
    df_new = df.groupby("X").progress_apply(sum)
    print("\n", df_new, sep="")

    # with tqdm_pandas (disabled)
    tqdm.pandas(disable=True)
    df_

# Generated at 2022-06-24 09:39:36.922168
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import random
    from tqdm.autonotebook import tqdm
    from time import sleep

    def f(x):
        sleep(0.005)
        return x + random.uniform(size=len(x))

    # Setup
    tqdm_kwargs = dict()
    try:
        tqdm_kwargs['file'] = open('/dev/null', 'x')
    except FileExistsError:
        tqdm_kwargs['file'] = open('/dev/null', 'w')

    # Test
    with tqdm(**tqdm_kwargs) as tqdm_obj:
        tqdm_pandas(tqdm_obj)

# Generated at 2022-06-24 09:39:43.269202
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    try:
        import pandas_datareader.data as web  # noqa
        haspd = True
    except ImportError:
        haspd = False
    # Testing import
    assert tqdm_pandas is not None
    # Testing function
    with tqdm(total=int(1e6)) as t:
        assert hasattr(t, 'pandas')
        df = pd.DataFrame(np.random.randint(1, 100, (int(1e6), 2)))
        res = df.groupby(0).progress_apply(lambda x: x[1].mean())
        for _ in res.head().values:
            t.update()
    # Testing function using pandas_datare

# Generated at 2022-06-24 09:39:51.049170
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, tnrange
    from tqdm import trange

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # Python 2

    def _pandas_version_geq_(version):
        try:
            return pd.__version__ >= version
        except AttributeError:
            # __version__ was introduced in pandas v0.18
            return False


# Generated at 2022-06-24 09:40:01.242721
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    from tqdm.std import tqdm as tqdm_f
    from pandas import DataFrame

    import random
    import io
    import sys

    # Test tqdm_pandas for TqdmType
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, desc="D")
    tqdm_pandas(tqdm, desc="D", leave=False)
    tqdm_pandas(tqdm, desc="D", ascii=True)
    tqdm_pandas(tqdm, desc="D", ncols=80)
    tqdm_pandas(tqdm, desc="D", miniters=1)
    tqdm

# Generated at 2022-06-24 09:40:07.262865
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm(total=10, file=sys.stdout, desc='test') as t:
        tqdm_pandas(t)
    with tqdm(total=10, file=sys.stdout, desc='test') as t:
        tqdm_pandas(t.__class__, file=t.fp)


# Setup for tqdm_pandas

# Generated at 2022-06-24 09:40:14.956370
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    types = {'a': int, 'b': str, 'c': float}
    data = pd.DataFrame(np.random.randint(100, size=(10**4, 3)),
                        columns=list(types.keys()))
    for column in types.keys():
        data[column] = data[column].astype(types[column])

    with tqdm_pandas(total=data.shape[0]) as pbar:
        data.groupby('a').progress_apply(lambda x: x)
    assert pbar.n == data.shape[0]
    assert pbar.nmin == 1
    assert pbar.unique_since_restart == 1

# Generated at 2022-06-24 09:40:24.820260
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np


# Generated at 2022-06-24 09:40:35.844680
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm)

    def f(x):
        time.sleep(1e-4)
        return len(str(x))

    for n in range(2):
        df = DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
        df.groupby('a').progress_apply(f)
        df.groupby('a').progress_apply(f, meta=['a', 'b'])
        df.progress_apply(f)  # global
        df.progress_apply(f, axis=1)  # specifically global
        df.progress_apply(f, axis=1)  # specifically global
        df.progress_apply(f, axis=1)

# Generated at 2022-06-24 09:40:41.636254
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    t = tqdm_pandas(lambda *a, **k: None)
    df = pandas.DataFrame([[1, 2], [3, 4]])
    if hasattr(df.groupby('0'), 'progress_apply'):
        try:
            with tqdm(total=100) as t:
                df.groupby('0').progress_apply(t)
        except (TypeError, AttributeError):
            pass

# Generated at 2022-06-24 09:40:46.118188
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # testing deprecation call
    import tqdm.pandas
    tqdm.pandas.tqdm_pandas("", file=None)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:53.421234
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _deprecated_get_instances
    from tqdm import tqdm
    from tqdm import tnrange
    from tqdm import trange
    from tqdm import tqdm_notebook

    for iter_range in range(6):
        if iter_range == 0:
            cls = tqdm
        elif iter_range == 1:
            cls = tnrange
        elif iter_range == 2:
            cls = trange
        elif iter_range == 3:
            cls = tqdm_notebook
        else:
            cls = tqdm(iterable=range(0))
        tqdm_pandas(tclass=cls)

    # Multiple instances of trange/tqdm

# Generated at 2022-06-24 09:41:02.045921
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange
    from tqdm.pandas import tqdm_pandas

    # Create sample dataframe
    df = pd.DataFrame({'foo': np.random.randint(100, size=100),
                       'bar': np.random.randint(100, size=100)})

    # Create group by
    g = df.groupby('foo')

    # Progress apply
    p = g.progress_apply(lambda x: x.bar.sum())

    # Register tqdm
    tqdm_pandas(tqdm)
    if not isinstance(p, type(tqdm(range(10)))):
        raise AssertionError("Progress apply failed to register tqdm")

    #

# Generated at 2022-06-24 09:41:11.907253
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from time import sleep
    from tqdm import tqdm, trange
    from tqdm._utils import _supports_unicode
    from tqdm._tqdm_pandas import tqdm_pandas

    try:
        pd.Series().progress_apply
    except AttributeError:
        return  # not pandas 1.x

    # Straightforward test
    for i in trange(10):
        sleep(0.01)
    tqdm_pandas(tqdm())  # tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(desc='pandas'))  # tqdm_pandas(tqdm(desc='pandas'))
    t

# Generated at 2022-06-24 09:41:21.639772
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm, trange
    from numpy import random
    from time import sleep

    try:
        tqdm.pandas(tclass=trange)
        assert(False), "Please use `tqdm.pandas(...)` instead of `tqdm_pandas()`."
    except DeprecationWarning:
        pass

    try:
        tqdm_pandas(tclass=trange)
        assert(False), "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`."
    except DeprecationWarning:
        pass


# Generated at 2022-06-24 09:41:33.341918
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
        Unit test for tqdm_pandas
    """
    import pandas as pd
    import numpy as np
    import tqdm
    import os
    import sys

    # Create a fake pandas dataframe
    df = pd.DataFrame({'col1': np.random.randint(0, 10, 10),
                       'col2': np.random.randint(0, 10, 10),
                       'col3': np.random.randint(0, 10, 10)})

    with tqdm.tqdm_pandas(ncols=60) as t:
        t.pandas_apply(df.groupby('col1').col2.sum())
        t.pandas_apply(df.groupby('col1').col2.sum())

    # assert that we haven

# Generated at 2022-06-24 09:41:47.508166
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import random

    def _test(tfunc, df, quiet=False):
        err_msg = ("\n"
                   "Column `tqdm` gives iteration values in `DataFrame`:\n"
                   "{0}\n"
                   "Instead of:\n"
                   "[1, 2, 3, ..., {1}]\n"
                   "for the column `tqdm` in:\n"
                   "{0}\n".format(df.tqdm, len(df)))
        # Test with `DataFrame`
        assert isinstance(df.tqdm, Series), err_msg
        # Test with `DataFrameGroupBy.progress_apply`
        assert isinstance(df.groupby('tqdm').progress_apply(len), Series), err_msg
        # Test

# Generated at 2022-06-24 09:41:55.113475
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    a = np.arange(1000)
    b = a[::-1]
    # construct a pandas dataframe
    df = pd.DataFrame({'a': a, 'b': b})

    # register the panda progress bar with tqdm
    # after that, you can use the proress bar
    # whenever you iterate a DataFrame object
    tqdm_pandas(tqdm)
    for i, row in tqdm(df.iterrows()):
        pass
    # close the progress bar after the loop
    tqdm.close()

    # you can also use the progress bar
    # when you use a `GroupBy` object
    df.groupby('a').progress_apply(lambda x: x)
    df.groupby

# Generated at 2022-06-24 09:41:58.802755
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Also requires pandas to be installed
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return

    # Dummy data
    pdf = pd.DataFrame({'x': np.array([1., 2., 3.], dtype=np.float),
                        'y': np.array([1, 2, 3], dtype=np.int),
                        'z': ['a', None, 'c']})

    # Simple test
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    for _ in pdf.groupby('z').progress_apply(tqdm_pandas):
        pass

    # Delayed adapter test
    import tqdm

    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:42:04.636629
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from random import random
    from copy import copy

    def test_func(df):
        return df['a'].sum()

    def test_func_star(df):
        return df['a'].sum() * df['b'].sum()

    def test_func_raise(df):
        if df['b'].sum() > 0:
            raise RuntimeError
        else:
            return df['a'].sum()

    a = [random() for _ in range(1000)]
    b = [random() for _ in range(1000)]
    df = pd.DataFrame()
    df['a'] = a
    df['b'] = b

    # Default tqdm_pandas
    print('Default tqdm_pandas:')

# Generated at 2022-06-24 09:42:13.006719
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _range
    from pandas import DataFrame
    from random import random

    def square(x):
        from time import sleep
        sleep(random() / 5.0)
        return x ** 2

    t = tqdm_pandas(total=100, desc='Progress', mininterval=0.2, miniters=1)
    df = DataFrame({'x': list(range(100))})
    df = df.groupby(['x']).progress_apply(square)
    for _ in t(list(df.x)):
        pass
    assert t.n == 100



# Generated at 2022-06-24 09:42:20.536182
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import pandas as pd
    import numpy as np
    from tqdm import tqdm as tqdm_module

    # we reuse the decorator for unit-testing
    # because we want to test it's behaviour
    # over a mock DataFrameGroupBy object

    class DataFrameGroupBy:
        def progress_apply(self, func, *args, **kwargs):
            assert isinstance(func, tqdm_module)
            assert hasattr(func, 'total')
            assert hasattr(func, '_instances')

            assert func.total == kwargs['total']
            assert len(func._instances) == 1

            assert func.disable is True
            assert func.leave is True
            return pd.DataFrame(np.random.rand(10, 10))


# Generated at 2022-06-24 09:42:28.437866
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Create a pd.DataFrame
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.arange(1, 100))

    # Create a pd.DataFrame groupby object
    gby = df.groupby(df[0] % 2)

    # Apply tqdm
    tqdm_pandas(tqdm(leave=True))
    gby.progress_apply(lambda x: x)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:42:31.654014
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook
    assert tqdm_pandas(tqdm) == tqdm.pandas()
    assert tqdm_pandas(tqdm_notebook) == tqdm_notebook.pandas()

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:38.679694
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm.auto as tqdm
    from pandas import DataFrame
    from numpy import random
    from time import sleep

    def func(df):
        sleep(0.01)
        return df.x.sum()

    try:
        df = DataFrame(dict(x=random.rand(1000)))
        df = df.groupby(0).progress_apply(func)
    except Exception:
        print("ERROR:")
        raise
    else:
        print("SUCCESS")

# Generated at 2022-06-24 09:42:43.036299
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    assert 'DataFrameGroupBy' in tqdm.tqdm_pandas(tqdm.tqdm(),
                                                   desc='Pandas').__class__.__dict__

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:52.027582
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for `tqdm_pandas`. """
    import numpy as np
    import pandas as pd
    from tqdm import tqdm_pandas
    with tqdm_pandas(total=10) as t:  # Python 2.7+
        df = pd.DataFrame({'A': [10, 20, 30, 40, 50],
                           'B': [1, 2, 3, 4, 5],
                           'C': [1.1, 2.2, 3.3, 4.4, 5.5]})
        df = pd.DataFrame(np.random.randn(100000, 5), columns=['a', 'b', 'c', 'd', 'e'])

# Generated at 2022-06-24 09:43:01.755121
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Unit tests for `tqdm` estimates for `pandas`.
    '''
    from .tqdm import tnrange as trange
    from .utils import format_sizeof
    from .tqdm import tqdm
    from .tqdm import trange
    from .tqdm import TqdmTypeError
    from .tqdm import TqdmKeyError
    from .tqdm import TqdmDeprecationWarning
    from .tqdm import __version__ as tqdm_version
    from os import getenv
    import warnings

    # Global variables
    setup = False
    try:
        import numpy as np
    except ImportError:
        try:
            import pandas as pd
        except ImportError:
            return  # No point in running without `pandas`


# Generated at 2022-06-24 09:43:10.285383
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import random
    random.seed(2)
    # Create a pandas dataframe data
    df = pandas.DataFrame(random.sample(range(1, 101), 100), columns=['value'])
    # Test groupby method
    df.groupby(['value']).progress_apply(lambda x: x)
    # Test agg method
    df.progress_apply(lambda x: x, axis=0)
    # Test apply method
    df.progress_apply(lambda x: x, axis=1)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:20.437841
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.random((10000, 10000)))

    tqdm.pandas()
    # Using `progress_apply` instead of `apply` will display a progress bar while
    # executing the `lambda` function
    df.progress_apply(lambda x: x**2)
    # Using `progress_map` instead of `map` will display a progress bar while
    # executing the `lambda` function
    df.progress_map(lambda x: x**2)
    # Using `progress_apply` instead of `apply` will display a progress bar while
    # executing the `lambda` function
    df.progress_apply(lambda x: x**2, axis=1)  # `apply` along the rows


# Generated at 2022-06-24 09:43:28.599066
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_pandas
    df = pd.DataFrame({'a': [1, 2, 3], 'b': ['a', 'b', 'c']})
    tqdm_pandas(tqdm())
    assert df.groupby('b').progress_apply(len) == df.groupby('b').apply(len)
    tqdm_pandas(tqdm(total=10))
    assert df.groupby('b').progress_apply(len) == df.groupby('b').apply(len)


# Test regression in issue #3

# Generated at 2022-06-24 09:43:34.913056
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas

    # test progress_apply
    df = pd.DataFrame(dict(A=np.arange(50)))
    df.groupby('A').progress_apply(lambda x: x)
    tqdm_pandas(tqdm())  # no raise


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:40.345597
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm.pandas
    if tqdm.pandas.__file__ != __file__:
        raise ImportError("The tqdm.pandas module is currently broken by "
                          "an installation issue. Please reinstall it.")
    try:
        import pandas
        df = pandas.DataFrame({'a': list(range(10))})
        progress = tqdm_pandas(df.groupby('a')['a'].progress_apply)
        assert 'pandas' in progress.__module__
    except ImportError:
        pass
    tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm.tqdm, total=10)

# Generated at 2022-06-24 09:43:50.769329
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:44:02.383159
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from time import sleep
    from tqdm import tqdm
    # -- Basic test (shouldn't print anything) -- #
    @tqdm_pandas(tqdm)
    def min_func(x):
        sleep(0.5)
        return float(np.min(x))

    df = pd.DataFrame([np.random.random(1000) for _ in range(100)])
    assert df.progress_apply(min_func).sum() > 0

    # -- Basic test (not suppressing) -- #
    @tqdm_pandas(tqdm, disable=False)
    def min_func(x):
        sleep(0.5)
        return float(np.min(x))

    df = pd.DataFrame

# Generated at 2022-06-24 09:44:09.343811
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_gui
    try:
        with tqdm_gui(leave=True) as t:
            tqdm_pandas(t)
            pd.DataFrame(range(100)).progress_apply(lambda x: x + 1)
    except NameError:
        pass  # No PySide2
    with tqdm(leave=True) as t:
        tqdm_pandas(t)
        pd.DataFrame(range(100)).progress_apply(lambda x: x + 1)

# Generated at 2022-06-24 09:44:14.319154
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    with tqdm(total=len(range(100)), mininterval=0.0) as t:
        def progress(x):
            t.update()
            return x * x
        assert (pd.DataFrame({'a': range(100)})['a'].progress_apply(progress).sum() ==
                sum(x * x for x in range(100)))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:24.106860
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np
    from tqdm import tqdm
    from .tqdm import tqdm_pandas

    df = pandas.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.progress_apply(tqdm_pandas)
    df.progress_apply(tqdm_pandas(tqdm))
    df.progress_apply(tqdm_pandas(tqdm(desc='test')))
    tqdm_pandas(tqdm(desc='test'))(df.progress_apply)
    tqdm_pandas(tqdm(desc='test'))(df.groupby('0').progress_apply)

# Generated at 2022-06-24 09:44:34.255352
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import io

    df = pd.DataFrame(data={'A': [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                            'B': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]})

    # error when tqdm is not called
    with pytest.raises(AttributeError):
        with tqdm.tqdm_pandas(total=len(df)):
            _ = df.groupby('A').progress_apply(lambda x: x ** 2)

    # lowest level code path

# Generated at 2022-06-24 09:44:40.586958
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        from tqdm import tqdm_gui  # raise ImportError if tqdm-gui not installed
        assert tqdm_gui
    except ImportError:
        pass
    tqdm_pandas(tqdm, total=10)


# Register function tqdm_pandas with `pandas.core.groupby.DataFrameGroupBy.progress_apply` using the new register decorator

# Generated at 2022-06-24 09:44:46.944647
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test function `tqdm_pandas`."""
    from tqdm import TqdmDeprecationWarning

    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm())


# Plumbing to allow other packages to customise the tqdm_notebook function
_tqdm_notebook_custom_instances = {}



# Generated at 2022-06-24 09:44:57.124395
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    # Create DataFrame
    df = pd.DataFrame(
        {'a': ["Mary", "Jim", "John"],
         'b': [5, 3, 6],
         'c': [4.0, 2.5, 5.5]},
        index=[1, 2, 3])

    with tqdm.tqdm(total=len(df.index)) as t:
        t.set_description('default')
        df.groupby('a').progress_apply(lambda x: x)
    with tqdm.tqdm(total=len(df.index)) as t:
        t.set_description('None')
        df.groupby('a', progress_kwargs={'t': None}).progress_apply(lambda x: x)

# Generated at 2022-06-24 09:45:07.887370
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    try:
        import pandas as pd
    except ImportError:
        return True

    with tqdm_pandas() as t:
        t.pandas(desc='Loading dataframe...')
        df = pd.DataFrame(
            [[i, j] for i in range(10000) for j in range(1000)])

    with tqdm_pandas() as t:
        t.pandas(desc='Loading dataframe...')
        df = pd.DataFrame(
            [[j, i] for i in range(10000) for j in range(1000)])

    with tqdm_pandas() as t:
        t.pandas(desc='Loading dataframe...')

# Generated at 2022-06-24 09:45:13.464528
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_kwargs = {
        'total': 10,
        'desc': 'test',
        'unit': 'test_unit',
        'unit_scale': True,
        'mininterval': 0.1,
        'miniters': 1,
        'dynamic_ncols': True,
        'position': 0,
        'leave': True,
        'smoothing': 0.1,
        'ascii': True,
        'bar_format': 'test',
        'initial': 5,
        'postfix': {'x': 1},
        'unit_divisor': 1,
        'maxinterval': 1,
    }

    # test tqdm_pandas(tqdm)
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:45:23.855919
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import __version__ as pd_ver
    from tqdm import tqdm

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        from pandas.core.groupby import GroupBy as DataFrameGroupBy

    if pd_ver < '0.18.0':
        dfg = DataFrameGroupBy
    else:
        dfg = DataFrameGroupBy._python_apply_general

    def no_tqdm_apply(self, func, *args, **kwargs):
        return func(*args, **kwargs)

    @dfg.register
    @functools.wraps(dfg)
    def progress_apply(self, func, *args, **kwargs):
        """
        Progress apply wrapper
        """

# Generated at 2022-06-24 09:45:27.485008
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    df = DataFrame({'col1': [1, 2, 3], 'col2': [4, 5, 6]})
    df.groupby(by="col1").progress_apply(lambda x: tqdm_pandas(tqdm()))

# Generated at 2022-06-24 09:45:33.975198
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame()
    df["text"] = [str(i) * 100 for i in np.random.randint(10, size=200)]
    l = [1, 2, 3, 4, 5]
    for _ in tqdm_pandas(tqdm(l)):
        df.groupby('text').progress_apply(lambda x: x)
    for _ in tqdm_pandas(tqdm(l)):
        df.groupby('text').progress_apply(lambda x: x)
    for _ in tqdm_pandas(tqdm(l)):
        df.progress_apply(lambda x: x)

# Generated at 2022-06-24 09:45:39.606944
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    import pandas as pd
    import numpy as np
    pd.DataFrame({'a': np.random.rand(10 ** 5)}).groupby('a').progress_apply(tqdm)


# Monkey-patch pandas.core.groupby.DataFrameGroupBy.progress_apply

# Generated at 2022-06-24 09:45:45.484646
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame({'a': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                       'b': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                       'c': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]})

    try:
        import tqdm

        df.groupby('a').progress_apply(lambda x: x)
    except AttributeError:
        tqdm_pandas(tqdm)
    finally:
        df.groupby('a').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()