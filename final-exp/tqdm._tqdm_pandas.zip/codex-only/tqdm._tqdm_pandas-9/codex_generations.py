

# Generated at 2022-06-24 09:35:45.260507
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # test DataFrameGroupBy.progress_apply
    df = pd.DataFrame({'a': [1] * 3 + [2] * 5 + [3] * 2,
                       'b': [4, 5, 6, 7, 8, 9, 10, 11, 12]})
    gp = df.groupby('a')

    def square(x):
        return x ** 2
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    try:
        assert (gp.progress_apply(square) == gp.apply(square)).all()
    finally:
        sys.stdout = old_stdout

    # test DataFrame.progress_apply

# Generated at 2022-06-24 09:35:49.407740
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(deprecated_t=tqdm.tqdm(total=8))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:35:56.466399
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd, tqdm
    df = pd.DataFrame({'a': list(range(500)),
                       'b': list(range(500))})
    tqdm.pandas(desc='my bar!')
    df.groupby('a').progress_apply(lambda x: x**2)
    tqdm.pandas(desc='my bar!')
    df.progress_apply(lambda x: x**2, axis=1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:07.885503
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd
    df = pd.DataFrame(range(100), columns=['n'])
    assert df.groupby('n').progress_apply(
        lambda x: x,
        tclass=tqdm).equals(df)
    assert df.groupby('n').progress_apply(
        lambda x: x,
        tclass=tqdm_pandas).equals(df)
    assert df.groupby('n').progress_apply(
        lambda x: x,
        tclass=tqdm_pandas(tqdm)).equals(df)

# Generated at 2022-06-24 09:36:13.056602
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm

    tqdm_pandas(tqdm)

    with tqdm.pandas(leave=False) as pandas_tqdm:
        assert isinstance(pandas_tqdm, tqdm)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:36:21.272878
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas, tnrange

    # Test tqdm_pandas
    for _ in tqdm_pandas(tnrange(10)):
        pass

    df = pd.DataFrame({'a': [1,2,3], 'b': [2,3,4]})

    # Test tqdm_pandas(tqdm)
    for _ in tqdm_pandas(tqdm(), total=10):
        pass

    # Test tqdm_pandas(tqdm())
    for _ in tqdm_pandas(tqdm()):
        pass

    # Test tqdm_pandas(tqdm(total=10))

# Generated at 2022-06-24 09:36:26.073984
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    a = pd.DataFrame({"x": range(100)})

    tqdm_pandas(tqdm(total=a.groupby('x').progress_apply(lambda x: x + 1).__len__()))

    # Regressions:
    tqdm_pandas(tqdm(file=sys.stdout))
    tqdm_pandas(type('tqdm', (object,), {}))  # delayed
    tqdm_pandas(type('tqdm_notebook', (object,), {}))  # delayed


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:34.854059
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:36:44.385484
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''Unit test for function tqdm_pandas'''
    from tqdm.autonotebook import tqdm
    from pandas import DataFrame, Series

    tqdm_pandas(tqdm)

    DataFrame(dict(a=[1, 2, 3], b=[4, 5, 6])).groupby(
        'a').progress_apply(lambda x: x)
    Series([7, 8, 9]).progress_apply(lambda x: x)
    DataFrame(dict(a=[1, 2, 3], b=[4, 5, 6])).progress_apply(lambda x: x)
    Series([7, 8, 9]).progress_apply(lambda x: x)
    tqdm_pandas(tqdm())

if __name__ == '__main__':
    test_tq

# Generated at 2022-06-24 09:36:49.734432
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas  # We assume pandas is installed, otherwise fail

    tqdm_pandas(pandas)  # tqdm-pandas <= v0.4.0
    tqdm_pandas(pandas.tqdm)  # tqdm-pandas <= v0.4.0
    tqdm_pandas(pandas.tqdm, bar_format='{l_bar}{r_bar}')  # tqdm-pandas <= v0.5.0


# Generated at 2022-06-24 09:36:57.570115
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
        from pandas.util.testing import assert_frame_equal
    except ImportError:
        return
    from tqdm import tqdm

    data = {'col1': [1, 2], 'col2': [3, 4]}
    df1 = DataFrame(data)

    # Using deprecated `tqdm_pandas`, pandas 0.24.2
    with tqdm(total=len(df1), ascii=True) as pbar:
        df1_nan = df1.progress_apply(
            lambda x: np.nan if x['col1'] == 1 else x['col1'], axis=1)
        pbar.update()

# Generated at 2022-06-24 09:37:06.746242
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from pandas import DataFrame

    t = trange(4)
    df = DataFrame([0, 1, 2, 3])

    t.pandas(total=4)
    df.groupby(0).progress_apply(lambda x: x)

    try:
        tqdm_pandas(t)
        assert False
    except:
        pass

    try:
        trange(4).pandas()
        assert False
    except:
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:12.539305
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    def main():
        testframe = pd.DataFrame(range(10))
        for x in tqdm(testframe.groupby(0), total=len(testframe.groupby(0)),
                      **tqdm.__dict__):
            pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:19.288403
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(
        {'a': list(range(100000)) + list(range(100000))})
    with tqdm(total=df.size) as pbar:
        pbar.set_description("my bar!")
        tqdm_pandas(pbar)
        df.groupby('a').progress_apply(lambda x: x)
    tqdm_pandas(tqdm(total=df.size))
    df.groupby('a').progress_apply(lambda x: x)


# Main auto-support for `tqdm --pandas`
if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:26.485332
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    df = DataFrame({'1': [1, 2, 3]})
    df.groupby('1').progress_apply(lambda x: x)
    tqdm_pandas(tqdm())
    df.groupby('1').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:32.744915
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import pandas
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    df = pd.DataFrame({'foo': np.random.randint(0, 20, size=1000)})
    df['bar'] = df['foo'].apply(lambda x: x**x, meta=tqdm)
    pandas.tqdm_pandas(tqdm)
    df['bar'] = df['foo'].progress_apply(lambda x: x**x, meta=tqdm)
    pandas.tqdm_pandas(tqdm)
    df['bar'] = df['foo'].progress_apply(lambda x: x**x, meta=tqdm())

# Generated at 2022-06-24 09:37:42.268866
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from math import nan

    df = pd.DataFrame(
        {
            'x': [1, 2, 3, nan, 5, nan, 7, 8],
            'y': [1, nan, 3, 4, nan, 6, 7, nan],
        },
        index=list('abcdefgh'),
    )

    out = list(
        df.groupby('x').progress_apply(
            lambda grp: grp.apply(
                lambda col: col.dropna().mean() if col.name == 'x' else col.dropna().sum(),
                axis=0,
            ),
        ),
    )
    assert len(out) == 5


# Generated at 2022-06-24 09:37:53.006405
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df2 = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

    def sqrt(x):
        return x**(1/2.0)

    import time
    for t_ in tqdm(range(5)):
        time.sleep(0.1)

    for t_ in tqdm_pandas(range(5)):
        time.sleep(0.1)

    for t_ in tqdm(tqdm(range(5))):
        time.sleep(0.1)


# Generated at 2022-06-24 09:38:04.425285
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    """
    # Check case of tqdm being a class
    import tqdm
    tqdm_pandas(tqdm.tqdm)

    # Check case of tqdm already in instantiated form
    tqdm_pandas(tqdm.tqdm())

    # Check that this works with tqdm_notebook
    try:
        import tqdm.notebook
        tqdm_pandas(tqdm.notebook.tqdm)
        tqdm_pandas(tqdm.notebook.tqdm())
    except AttributeError:
        print("tqdm_notebook could not be imported")

    # Check that this works with tqdm_gui

# Generated at 2022-06-24 09:38:10.258773
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    try:
        import pandas  # NOQA
        tqdm_pandas(tqdm())  # NOQA
    except Exception as e:
        raise AssertionError(
            "tqdm_pandas unit test failed: {}".format(e)) from e


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:17.844606
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Do not run the unit test if pandas is missing
    try:
        import pandas
    except ImportError:
        return

    # Make some data
    test_data = []
    for i in range(100):
        test_data.append((np.random.randint(0, 10), np.random.randint(0, 10)))
    test_df = pd.DataFrame.from_records(test_data, columns=['a', 'b'])

    def my_mean(x):
        return x.mean()

    def my_apply(x):
        return x.apply(my_mean)

    # Test the timer

# Generated at 2022-06-24 09:38:24.747975
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except:
        return
    from tqdm import tqdm, tqdm_notebook
    from random import randint

    N = 1000000
    df = pd.DataFrame(dict(A=[randint(0, 100) for _ in range(N)]))
    for tclass in [tqdm, tqdm_notebook]:
        tclass.pandas(desc="pandas: ")
        df.groupby("A").progress_apply(lambda x: x)

# Generated at 2022-06-24 09:38:34.632073
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        import warnings
        warnings.warn('pandas not found.')
        return True

    if not hasattr(pd, 'core'):  # pragma: no cover
        return True

    if not hasattr(pd.core, 'groupby'):  # pragma: no cover
        return True

    if not hasattr(pd.core.groupby, 'DataFrameGroupBy'):  # pragma: no cover
        return True

    from tqdm import tqdm, trange
    tqdm_pandas(tqdm)
    tqdm_pandas(trange)
    return False



# Generated at 2022-06-24 09:38:41.318989
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        import tqdm

        df = pd.DataFrame({'x': [1, 2, 3, 4]})
        with tqdm.pandas(total=len(df)) as pbar:
            assert isinstance(
                df.groupby('x').progress_apply(lambda x: len(x)),
                pd.DataFrame
            )
    except ImportError:
        pass

# Generated at 2022-06-24 09:38:50.279260
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from collections import OrderedDict
    from tqdm import trange

    # define a simple func
    def inc(x):
        return x + 1

    # create 100K row pandas df
    df = pd.DataFrame(OrderedDict([
        ('a', np.arange(10 ** 5)),
        ('b', np.random.randn(10 ** 5)),
        ('c', ['foo'] * 10 ** 5)
    ]))

    # create 10K row pandas df
    df_10k = pd.DataFrame(OrderedDict([
        ('a', np.arange(10 ** 4)),
        ('b', np.random.randn(10 ** 4)),
        ('c', ['foo'] * 10 ** 4)
    ]))

# Generated at 2022-06-24 09:38:59.063995
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tqdm(total=10), leave=False)
    try:
        pd.DataFrame({'a': [1, 2]}).groupby('a').progress_apply(lambda x: x)
    except AttributeError:
        return
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tqdm(total=10), leave=False)


# If the user hasn't created a tqdm instance, automatically create one and
# register.

# Generated at 2022-06-24 09:39:08.486468
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    a0, a1 = np.array(range(1000)), np.array(range(1000))
    s0, s1 = pd.Series(a0), pd.Series(a1)

    def square(x):
        return x ** 2

    ret_prog = None
    for _ in tqdm(range(10), ncols=80):
        ret_prog = square(s0).progress_apply(square)
    assert np.all(ret_prog == square(s1))
    assert np.all(ret_prog == square(s0))

    tqdm_pandas(tqdm())

    ret_default = None

# Generated at 2022-06-24 09:39:12.176920
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    for tclass in (tqdm, tqdm_notebook, tqdm_gui, tqdm_pandas):
        tqdm_pandas(tclass)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:23.123558
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    tqdm_pandas(tqdm)
    df = pd.DataFrame([1, 2, 3, 4, 5])
    with tqdm.tqdm(total=df.shape[0]) as pbar:
        df.progress_apply(
            lambda x: pbar.update(), axis=1)
    df = pd.DataFrame([1, 2, 3, 4, 5])
    with tqdm.tqdm("Iterating", total=df.shape[0]) as pbar:
        df.progress_apply(
            lambda x: pbar.update(), axis=1)
    df = pd.DataFrame([1, 2, 3, 4, 5])

# Generated at 2022-06-24 09:39:34.578157
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    "Tests for `tqdm_pandas` pandas extension."
    # from tqdm.auto import tqdm

    # print('\nTesting `tqdm.pandas` extension: ...')
    # df = pd.DataFrame({'x': [1, 2, 3, 4]})
    # with tqdm(total=len(df), file=sys.stdout,
    #           ncols=120, mininterval=0.1, miniters=1,
    #           desc='0%') as t:
    #     df.groupby('x').progress_apply(lambda x: t.update(1))
    #     t.desc = '100%'

    # print('')

    # deprecated functionality
    # assert tqdm_pandas(lambda x: x, file

# Generated at 2022-06-24 09:39:40.538601
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm_pandas

    def demo(df):
        return df

    tqdm_pandas(demo)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(DataFrame()))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:48.899502
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    with tqdm(total=100) as t:
        df = pd.DataFrame({'a': range(100)})
        tqdm_pandas(t)
        df.groupby('a').progress_apply(lambda x: x**2)
    with tqdm(total=100) as t:
        df = pd.DataFrame({'a': range(100)})
        tqdm_pandas(t)
        df.groupby('a').progress_apply(lambda x: x**2)
    with tqdm(total=100) as t:
        df = pd.DataFrame({'a': range(100)})
        tqdm_pandas(t)
        df.groupby('a').progress_apply(lambda x: x**2)

# Generated at 2022-06-24 09:39:59.815094
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, desc='foo')
    tqdm_pandas(tqdm, desc='foo', total=3)


# Register tqdm with pandas
tqdm_pandas(tqdm)

# =============================================================================
# Documentation
# =============================================================================

docstrings = getdoc(tqdm).replace('\n.. code:: python\n\n', '')

if docstrings.count('tqdm_') == 1:
    docstrings = '\n'.join(
        line[5:] if line.startswith('    ') else line
        for line in docstrings.split('\n'))


# Generated at 2022-06-24 09:40:10.678450
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    tqdm.pandas(tqdm.tqdm)
    N = 100000
    df = pd.DataFrame({'value': np.random.rand(N)})
    def some_function(x):
        return x * 2
    # Test GroupBy.progress_apply
    df.groupby(df.value // 0.1).progress_apply(some_function)
    # Test DataFrame.progress_apply
    df.progress_apply(some_function)
    # Test DataFrame.progress_apply w/ axis=1
    df.progress_apply(some_function, axis=1)
    df['value_apply'] = df.progress_apply(some_function)

# Generated at 2022-06-24 09:40:16.174447
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from pandas.util.testing import assert_frame_equal

    print('Testing tqdm_pandas()')
    n = 100
    df1 = pd.DataFrame(np.random.rand(n, n))
    df2 = pd.DataFrame(np.random.rand(n, n))
    df3 = pd.concat([df1, df2])

    # Test with delayed class construction
    tclass = tqdm_pandas(total=len(df1))
    df1.progress_apply(lambda x: x, axis=0, broadcast=True)

    # Test with instance
    tclass = tqdm_pandas(total=len(df1))

# Generated at 2022-06-24 09:40:25.829530
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    import numpy as np
    from tqdm.auto import tqdm

    def f(x):
        return x

    df = pandas.DataFrame(
        data=np.random.randn(10000, 5),
        columns=list('abcde'),
        index=['{:04}'.format(i) for i in range(10000)])
    assert __name__ not in ('__main__', '__builtin__')
    # Prints which plugin is registered
    tqdm_pandas(tqdm)
    # Will create and register a new instance (quiet by default)
    tqdm_pandas(tqdm, leave=True)
    # Test `progress_apply`

# Generated at 2022-06-24 09:40:34.438730
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _deprecate_module
    tqdm_pandas(_deprecate_module("5.0.0"))
    from tqdm import tqdm_notebook
    tqdm_pandas(tqdm_notebook)
    try:
        from tqdm import tqdm
        tqdm_pandas(tqdm)
    except:  # pragma: no cover
        pass


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:42.830529
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Unit test for function `tqdm_pandas`. Tests the large data case,
    as well as the delayed adaptor case.
    '''
    from tqdm.auto import tqdm

    def test_func(df):
        return df

    try:
        import pandas as pd
    except ImportError:
        return True  # pandas not installed

    # test large data case
    df = pd.DataFrame(np.random.randn(100000, 5))
    df_gb = df.groupby('c')
    df_gb.progress_apply = tqdm_pandas(df_gb.progress_apply)
    _ = df_gb.progress_apply(test_func)
    _ = tqdm_pandas(tqdm).groupby('c').progress_

# Generated at 2022-06-24 09:40:52.352625
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmTypeError, TqdmDeprecationWarning, trange
    from tqdm.contrib import _TqdmPandasDeprecation
    try:
        import pandas
    except ImportError:
        return
    pd = pandas
    originals = {
        'pandas': pd.core.groupby.DataFrameGroupBy._progress_apply
    }
    tqdm = tqdm_pandas(tqdm)
    with tqdm(total=100, file=tqdm.tqdm_pandas_default_miniters) as t:
        assert pd.core.groupby.DataFrameGroupBy._progress_apply._original is \
            originals['pandas']
        pd.core.groupby.DataFrameGroupBy._

# Generated at 2022-06-24 09:41:01.254977
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm._tqdm_test_examples import incr_df

    pd.core.groupby.DataFrameGroupBy.progress_apply = lambda self, func: func()

    def test_df(tqdm_cls=tqdm):
        tqdm_pandas(tqdm_cls)
        incr_df()

    with tqdm(unit='B', unit_scale=True, miniters=1,
              desc='Test tqdm_pandas [tqdm wrapper]') as t:
        tqdm_pandas(t)
        incr_df()


# Generated at 2022-06-24 09:41:11.532698
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm_pandas as tpd
    try:  # Python 3
        from unittest import TestCase
    except ImportError:  # Python 2
        from unittest2 import TestCase
    try:  # Python >= 3.7
        from unittest.mock import patch
    except (ImportError, AttributeError):  # Python < 3.7 or < 3.3
        from mock import patch
    import pandas

    class TestTqdmPandas(TestCase):
        """Test case for tqdm_pandas"""
        def test_tqdm_pandas(self):
            with patch('tqdm._tqdm.tqdm_pandas.tqdm_pandas') as mock_tpd:
                tpd.tqdm_pandas(total=100)

# Generated at 2022-06-24 09:41:21.074873
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .auto import tqdm as deprecation_warning
    from .tqdm import tqdm
    from .std import tqdm as class_case
    deprecation_warning.pandas()
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(class_case)
    tqdm_pandas(class_case(total=10))
    try:
        tqdm_pandas(None, leave=True)  # pragma: no cover
    except TypeError:
        pass
    else:  # pragma: no cover
        raise ValueError("Did not raise TypeError on invalid arguments")


del sys, os, time

# Generated at 2022-06-24 09:41:32.283049
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Testing feature of `tqdm.pandas`.
    """
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    np.random.seed(1234567)
    df = pd.DataFrame({"a": np.random.randn(1e6)})
    df = df.groupby(
        "a", as_index=False, sort=False, group_keys=False).progress_apply(len)
    df = pd.DataFrame({"a": np.random.randn(1e6)})

    # Test tqdm.pandas()
    df = df.groupby("a", as_index=False, sort=False, group_keys=False).progress_apply(
        len)

# Generated at 2022-06-24 09:41:39.675596
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    total = pd.DataFrame(np.random.randint(0, 100, size=(100, 4)), columns=list('ABCD'))
    t = trange(10)
    t.pandas(total=len(total))
    total = total.groupby('A').progres

# Generated at 2022-06-24 09:41:44.468187
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    # Example 1
    NUM_ROWS = 100
    df = pd.DataFrame({
        'a': range(NUM_ROWS),
        'b': range(NUM_ROWS),
        'c': np.random.rand(NUM_ROWS)
    })

    # unit test 1
    df.groupby('a').progress_apply(lambda x: np.sum(x))
    df.groupby('a', as_index=False).progress_apply(lambda x: np.sum(x))
    tqdm.pandas()
    df.groupby('a').progress_apply(lambda x: np.sum(x))

# Generated at 2022-06-24 09:41:50.198154
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import pandas as pd
    import numpy as np

    # Dummy dataset
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)),
                      columns=list('ABCDEF'))

    # Compute mean of each column
    results = {}
    for col in df.columns:
        results[col] = df[col].progress_apply(lambda _: _.mean())


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:00.734801
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random
    from pandas.util.testing import assert_frame_equal

    # Setup pandas DataFrame
    df = DataFrame({'col1': random.randint(0, 100, 100), 'col2': random.randint(
        0, 100, 100), 'col3': ['a', 'b', 'c', 'd']*25, 'col4': ['w', 'x', 'y', 'z']*25})

    # Create DataFrame copies
    df_copy = df.copy()
    df_copy2 = df.copy()

    # Create function to simulate progress_apply
    def f(x):
        return len(x)

    # Create tqdm_pandas instance
    tqdm_pandas(tqdm(total=len(df)))



# Generated at 2022-06-24 09:42:10.806853
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm

    def func(x):
        """Test function"""
        return x

    df = DataFrame(Series(tuple(range(50))))
    tqdm_pandas(tqdm(total=df.shape[0]))
    df.progress_apply(func)

    df = DataFrame(Series(tuple(range(50))))
    tqdm_pandas(tqdm, total=df.shape[0])
    df.progress_apply(func)

    df = DataFrame(Series(tuple(range(50))))
    tqdm_pandas(tqdm(total=df.shape[0]), leave=False)
    df.progress_apply(func, axis=1)


# Generated at 2022-06-24 09:42:17.192989
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if sys.version_info >= (3, 0):
        try:
            import pandas as pd
            import numpy as np

            # Test progress_apply
            df = pd.DataFrame({'A': np.random.randn(100000), 'B': np.random.randn(100000)})
            list(tqdm_pandas(tqdm(total=len(df)), file=sys.stderr)(df.groupby('A')['B'].progress_apply(lambda x: x.sum())))
        except ImportError:
            pass

# Test all examples in README.md

# Generated at 2022-06-24 09:42:21.550504
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    tqdm.pandas(tqdm)  # register tqdm instance with pandas
    data = pd.DataFrame(np.random.randn(10, 2), columns=['a', 'b'])
    data.groupby('a').progress_apply(lambda x: x ** 2)
    data.groupby('a').progress_apply(lambda x: x ** 2)  # invokes .regis

# Generated at 2022-06-24 09:42:31.919711
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .std import tqdm
    from .gui import tqdm_notebook
    from .gui import tqdm_gui

    for cls, gui in ((tqdm, False), (tqdm_notebook, True)):
        with warnings.catch_warnings(record=True) as w:
            # Cause all warnings to always be triggered.
            warnings.simplefilter("always")
            # Trigger a warning.
            tqdm_pandas(cls, mininterval=0.1, bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]')
            # Verify some things
            assert len(w) == 1
            assert issubclass(w[-1].category, DeprecationWarning)

# Generated at 2022-06-24 09:42:41.285524
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import tqdm

    try:
        tqdm.pandas(tqdm_kwargs={'desc': 'test_tqdm_pandas'})

        def progress_apply(self, func, *args, **kwargs):
            kwargs['desc'] += '-progress_apply'
            return super(DataFrameGroupBy, self).progress_apply(func, *args, **kwargs)

        DataFrameGroupBy.progress_apply = progress_apply

        tqdm_pandas(tqdm, desc='test_tqdm_pandas')
        assert False  # should raise TqdmDeprecationWarning
    except TqdmDeprecationWarning as e:
        pass

   

# Generated at 2022-06-24 09:42:46.654794
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    @tqdm_pandas
    def func(df, col):
        for i in range(100):
            pass
        return df[col] * 2

    try:  # Make sure pandas is installed
        import pandas as pd
    except ImportError:
        print("pandas not found")
        return

    df = pd.DataFrame({'a': range(300)})

    res = func(df, 'a')
    assert (df['a'] * 2 == res).all()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:54.446287
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    df = DataFrame([[1, 2], [3, 4]], columns=list('AB'))

    # Defaults to enabling pandas.core.groupby.DataFrameGroupBy.progress_apply
    tqdm(total=len(df), leave=False)
    assert (tqdm._instances == [])

    # Test delayed adapter
    tqdm_pandas(tqdm)
    assert (tqdm._instances == [])

    # Test same as tqdm(...).pandas(...)
    tqdm_pandas(tqdm, total=len(df), leave=False)
    assert (tqdm._instances == [])

    # Test same as tqdm.pandas()
    tq

# Generated at 2022-06-24 09:43:00.226519
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    try:
        import pandas
        # Please test on your application!
        df = pandas.DataFrame(np.random.randint(1, 10, (1000000, 1)),
                              columns=['y'])
        df.groupby('y').progress_apply(lambda x: x)
    except ImportError:
        pass

# Generated at 2022-06-24 09:43:07.077137
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import pandas_profiling

    df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 4)), columns=list('ABCD'))
    tqdm_pandas(tclass=df.groupby('A').progress_apply(lambda x: x['B'].sum()))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:12.339234
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy

    # Simple checks
    tqdm_pandas(DataFrameGroupBy)
    tqdm_pandas(type(DataFrameGroupBy))
    tqdm_pandas(trange(10))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:21.772742
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, pandas
    try:
        import pandas
    except ImportError:
        return

    try:
        df = pandas.DataFrame({'a': list(range(100000))})
    except:
        return

    try:
        tqdm_pandas(tqdm, total=len(df))
        tqdm_pandas(tqdm, total=len(df))
        tqdm_pandas(tqdm, total=len(df))
        tqdm_pandas(tqdm, total=len(df))
    except:
        pass

    pandas.DataFrame({'a': list(range(100000))}).groupby('a').progress_apply(
        lambda x: x)

# Generated at 2022-06-24 09:43:32.525700
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    from tqdm.test import TqdmDeprecationWarning
    import io
    import sys

    with io.StringIO() as buf, redirect_stdout(buf):
        with pytest.warns(TqdmDeprecationWarning):
            tqdm_pandas(tqdm, file=sys.stderr)
        assert "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`" in buf.getvalue()


# Generated at 2022-06-24 09:43:37.241915
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [1, 4, 9]})

    # Passing a class
    with tqdm(total=len(df)) as t:
        tqdm_pandas(t)
        res = df.groupby('a').progress_apply(lambda x: x['b'].sum())
        assert (list(res.values) == [1, 13, 9])

    # Passing an instance
    with tqdm(total=len(df)) as t:
        tqdm_pandas(t)
        res = df.groupby('a').progress_apply(lambda x: x['b'].sum())
        assert (list(res.values) == [1, 13, 9])

    # Passing a delayed instance

# Generated at 2022-06-24 09:43:39.913068
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .std import tqdm
    t = tqdm(range(100))
    tqdm_pandas(t)
    t.pandas()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:45.495063
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        from pytest import importorskip  # pylint: disable=missing-docstring
        importorskip("pandas")
    else:
        tqdm_pandas(pd)

# Run unit test for function tqdm_pandas
test_tqdm_pandas()

# Generated at 2022-06-24 09:43:53.313230
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange
    import pandas as pd
    from pandas import DataFrame, Series

    # series
    tqdm.pandas(desc="series tqdm")
    df = pd.DataFrame({'a': range(10), 'b': range(10, 20)})
    assert isinstance(df['a'].progress_apply(int), Series)
    assert isinstance(df['a'].progress_apply(float), Series)

    # tqdm_pandas
    assert isinstance(df['a'].map(tqdm_pandas, trange(0)), Series)
    assert isinstance(df['a'].map(tqdm_pandas, trange(0)).pipe(tqdm, total=9),
                      Series)
    assert isinstance

# Generated at 2022-06-24 09:44:01.637250
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import tqdm.contrib.test_tqdm

    df = pd.DataFrame({'a': range(10000)})
    if tqdm.contrib.test_tqdm.have_pandas:
        with tqdm.contrib.test_tqdm.tqdm(total=len(df)) as t:
            _ = df.progress_apply(lambda x: x, axis=1)
            t.update(len(df))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:09.439996
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, concat
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib.concurrent import process_map

    if sys.version_info < (3,):
        # Check pandas  14.0+
        if pd.__version__[:5] < '0.14.':
            raise unittest.SkipTest('pandas < 0.14')

    def my_function(x):
        return x

    def my_function2(x):
        return x + 1

    def my_function3(x):
        return x + 2

    def my_function4(x):
        return x + 3

    df = DataFrame(np.random.randn(50, 7))
    data = [df] * 25

    # test progress

# Generated at 2022-06-24 09:44:15.295538
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame(
        {'col_1': list(range(0, 100))}
    )

    expected = {
        'col_1': [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
    }

    def square(x):
        return x ** 2

    # Lazy tqdm
    tqdm_pandas(tqdm)

    actual = df.groupby('col_1').progress_apply(lambda x: square(x)).to_dict()
    assert expected == actual

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:20.968886
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._tqdm import tqdm
    from pandas import DataFrame
    import numpy as np

    with tqdm(total=10) as bar:
        DataFrame(np.random.rand(1000, 1000)).progress_apply(lambda x: x*2, axis=0)
        bar.update(10)
    assert bar.n == 10

# Generated at 2022-06-24 09:44:29.431700
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm)
    try:
        DataFrame(dict(a=range(10), b=range(10))).groupby('a').progress_apply(
            lambda x: x['b'].sum())
        raise RuntimeError("ERROR")
    except Exception:
        pass
    finally:
        tqdm.pandas.deprecated = False  # type: ignore


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:36.984270
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        import numpy
    except ImportError:
        return
    tqdm_pandas(tqdm)
    n = int(1e4)
    tqdm_pandas(tqdm(total=n))
    df = pandas.DataFrame({'a': numpy.random.randint(0, 1000, size=n),
                           'b': numpy.random.random(size=n),
                           'c': [1] * n,
                           })
    _ = df.groupby('a').progress_apply(len)


test_tqdm_pandas()

# Generated at 2022-06-24 09:44:46.532479
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Unit tests for the `tqdm.pandas` decorator.

    import pandas as pd
    from tqdm import tqdm, tqdm_pandas

    # Simplest pandas test
    pd.Series(range(10)).progress_apply(time.sleep)
    # > |██████████████▉ | 8.8/10 [00:00<00:00, 22.79it/s]

    # A bit more involved test
    df = pd.DataFrame({'a': range(10), 'b': range(10, 0, -1)})
    df = df.groupby('a').progress_apply(lambda x: x * 2)
    # > |██████████████▉ | 8.8/10 [00:00<00:00, 22.79it/s]
    assert list

# Generated at 2022-06-24 09:44:52.787489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    list_of_dfs = [pd.DataFrame(np.random.randn(10, 10))
                   for _ in range(100)]
    concat_df = pd.concat(list_of_dfs)
    with tqdm_pandas(total=len(concat_df)) as prg_bar:
        concat_df.progress_apply(lambda x: x+1, axis=1)

# Generated at 2022-06-24 09:44:59.877181
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.contrib.decorators import register_tqdm_pandas
    import os

    def function(x):
        return x

    with register_tqdm_pandas(tclass=tqdm_pandas):
        pd.Series.progress_apply(lambda x: function(x))
        pd.DataFrame.progress_apply(lambda x: function(x),
                                    axis=1,
                                    progress_kwargs=dict(total=10),
                                    file=os.devnull)
    pd.core.groupby.DataFrameGroupBy.progress_apply = None

# Generated at 2022-06-24 09:45:08.433301
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time

    n = 10000
    tdf = pd.DataFrame(np.random.randn(n, 4))

    with tqdm_pandas(tclass=tqdm, leave=False, total=n) as g:
        # Perform your expensive operations with the original DataFrame
        time.sleep(3)  # some heavy computation
        tdf = tdf.fillna(0)  # replace NaN values with zero
        tdf.groupby(0).progress_apply(lambda x: x**2)
        # Update the progress bar
        g.update()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:17.686973
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    from pandas import DataFrame
    from pandas import Series
    from numpy import random
    from itertools import product

    df = DataFrame(random.random((10000, 10000)))
    for p in product(['auto', 'notebook', 'instant'], ['n', 'l']):
        tqdm_pandas(tqdm(pandas=p[0], leave=p[1]))
        df.progress_apply(lambda x: x + 1)
        with tqdm(pandas=p[0], leave=p[1]) as t:
            t.pandas(df.progress_apply)

    tqdm_pandas(tqdm)  # test adapter

# Generated at 2022-06-24 09:45:26.839376
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_notebook, trange
    from pandas.core.groupby import DataFrameGroupBy

    def in_ipython():
        try:
            from IPython import get_ipython
            return get_ipython() is not None
        except:
            return False

    for tclass in [tqdm, tqdm_notebook]:
        try:
            if in_ipython():
                tclass(range(1), leave=True, disable=None)
        except:
            continue

        tqdm_pandas(tclass)
        assert hasattr(DataFrameGroupBy, 'progress_apply')
        assert callable(getattr(DataFrameGroupBy, 'progress_apply'))


# Generated at 2022-06-24 09:45:33.193665
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # Using a StringIO object to avoid printing to stdout
    buf = StringIO()
    a = np.reshape(np.arange(100), (10, 10))
    df = pd.DataFrame(a, columns=list('abcdefghij'))
    tqdm_pandas(tqdm(df.groupby(list('abcdefghij')), file=buf, leave=False),
                file=buf, leave=False)
    assert buf.getvalue() == ''


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:41.824564
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .cli import main
    from .utils import format_sizeof

    main(["--unit_test",
          "--disable_progress_bar",
          '--miniters=1',
          '--desc="test %s"' % format_sizeof(42),
          "--ascii",
          "--leave",
          "--mininterval=0",
          "--unit_scale",
          "--unit='B'",
          "--dynamic_ncols",
          "--postfix=False",
          "--sysinfo='%CPU'",
          "--tqdm_cls='tqdm.tqdm_pandas'"])

