

# Generated at 2022-06-24 09:35:56.431844
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    obj_test = DataFrame(
        {'a': [3, 2, 1, 0], 'b': [0, 1, 2, 3]}, dtype=float)
    obj_test['a'].progress_apply(lambda x: x ** 2)
    with tqdm() as t:
        obj_test['a'].progress_apply(lambda x: x ** 2)
        t.close()


# Re-parse command-line arguments
if __name__ == '__main__':
    import optparse

    parser = optparse.OptionParser()
    parser.add_option('--pandas', dest='pandas', action='store_true',
                      help='applies function on pandas',)

# Generated at 2022-06-24 09:36:07.847896
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas.
    """
    import tqdm
    import pandas as pd
    import numpy as np

    def test_function(data):
        return np.random.randn(1)

    df = pd.DataFrame({
        'a': [1, 2, 3],
        'b': [4, 5, 6],
        'c': [7, 8, 9],
        'd': [10, 11, 12],
        'e': [13, 14, 15]
    })

    result = df.groupby('a').apply(tqdm_pandas(test_function))
    assert isinstance(result, pd.Series)
    assert len(result) == 3

# Generated at 2022-06-24 09:36:17.784445
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm
    # example adapted from:
    # http://stackoverflow.com/questions/22687228/pandas-groupby-and-apply-returning-series

    def test_func(chunk):
        # mock processing
        chunk['compute_col'] = 0
        return chunk

    # example dataframe
    df = pandas.DataFrame({'key': ['foo', 'bar', 'baz'] * 100,
                           'value': range(300)})

    # compute and display the progress bar
    tqdm_pandas(tqdm())
    df = df.groupby(['key']).progress_apply(test_func)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:26.996075
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm.autonotebook import tqdm  # monkey patch pandas

    # Setup data
    start = np.datetime64('2015-01-01T00:00:00')
    end = np.datetime64('2015-01-01T00:01:00')
    N = 1000
    data = pd.DataFrame({
        'time': np.linspace(start, end, N),
        'col1': np.random.randn(N),
        'col2': np.random.randn(N),
        'col3': np.random.randn(N),
    }).set_index('time')

    # Function 1
    def square_plus_1(x):
        return

# Generated at 2022-06-24 09:36:35.636602
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'user': ['user_00001', 'user_00002', 'user_00001', 'user_00001', 'user_00002'],
                       'ratings': [8, 7, 3, 5, 6],
                       'movies': ['movie_00001', 'movie_00002', 'movie_00003', 'movie_00004', 'movie_00001']})

    # Unit test for tqdm_pandas
    tqdm_pandas(tqdm.tqdm, desc='tqdm_pandas unit test')

    # Unit test for tqdm_pandas(tqdm)
    tqdm_pandas(tqdm.tqdm())

    # Unit test for tqdm

# Generated at 2022-06-24 09:36:42.573124
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import trange
    import numpy as np

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('tqdm._tqdm.write') as mock_write:
        tqdm_pandas(tqdm)

    with patch('tqdm._tqdm.write') as mock_write:
        tqdm_pandas(trange(1))

    df = pd.DataFrame(np.random.rand(1000, 1))
    with patch('tqdm._tqdm.write') as mock_write:
        tqdm_pandas(df.groupby(0).progress_apply)

    # A valid test case, but

# Generated at 2022-06-24 09:36:51.557941
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    try:
        import pandas
    except ImportError:
        return
    import numpy as np
    import tqdm

    df = pandas.DataFrame({'x': np.random.randint(0, 100, size=(int(1e6))),
                           'y': np.random.randint(0, 100, size=(int(1e6)))})
    gb = df.groupby('x')

    tqdm_pandas(tqdm.tqdm)
    res1 = gb.progress_apply(sum)
    assert res1.sum() == df['y'].sum()
    tqdm_pandas(tqdm.tqdm, leave=True)  # test `leave`
    res

# Generated at 2022-06-24 09:37:02.211427
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.tests import tests

    pd.DataFrame.progress_apply = tests.FakeDataFrame
    tqdm_pandas(tqdm(
        bar_format="{l_bar}%s{bar}%s{r_bar}" % (
            tests.unicode_cap(0x25A0, 0xE2, 0x96, 0xA0),
            tests.unicode_cap(0x25A1, 0xE2, 0x96, 0xA1)),
        total=3,
        disable=None))
    tqdm_pandas(tqdm(bar_format="{percentage:3.0f}% {bar}",
                     total=3))


# Generated at 2022-06-24 09:37:12.681623
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    def test_fn(x):
        return x

    df = pd.DataFrame({
        'a': [1, 2, 3, 4],
        'b': [5, 6, 7, 8],
        'c': [9, 10, 11, 12],
        'd': [13, 14, 15, 16],
    })
    tqdm_pandas(tqdm, df=df, total=df.shape[0])
    df.progress_apply(test_fn)
    tqdm_pandas(tqdm, df=df, total=df.shape[1])
    df.progress_apply(test_fn, axis=1)


if __name__ == "__main__":
    test_tqdm_

# Generated at 2022-06-24 09:37:18.794536
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return None

    # 1. Test for case tqdm_pandas(tqdm, ...)
    sys.stdout.seek(0)
    sys.stdout = io.StringIO()
    tqdm_pandas(tqdm, total=0, mininterval=1, maxinterval=1)
    s = sys.stdout.getvalue()
    assert s, "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`." in s

    # 2. Test for case tqdm_pandas(tqdm(...))
    sys.stdout.seek(0)
    sys.stdout = io.StringIO()
    tqdm_pandas

# Generated at 2022-06-24 09:37:28.917965
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Ensure that all options are accepted
    for t, options in [
        (tqdm, dict(total=100)),
        (partial(tqdm, total=100), {}),
        (partial(tqdm, total=100, file=sys.stdout), dict()),
        (partial(tqdm, total=100, file=sys.stdout, disable=False), dict()),
        (partial(tqdm, total=100, smoothing=0), dict()),
        (tqdm_notebook, dict(total=100)),
        (tqdm_gui, dict(total=100)),
    ]:
        tqdm_pandas(t, **options)

    # Ensure that delayed adapter handling is accepted
    tqdm_pandas(tqdm, total=100)
    tqdm_

# Generated at 2022-06-24 09:37:36.322725
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm.pandas(tqdm)

    df = pd.DataFrame({"a": range(1000), "b": range(1000)})
    res = df.groupby('b').progress_apply(lambda x: x)
    if not res.equals(df):
        raise ValueError("Test fail")

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:43.710984
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas
    tqdm_pandas(tqdm)

    # Single-threaded progress bar
    N = 100
    df = pd.DataFrame(np.random.randint(0, 100, size=(N, 4)), columns=list('ABCD'))
    print("--- Single-threaded progress bar ---")
    res = df.groupby('A')['B'].progress_apply(lambda x: x ** 2).sum()
    print("\nSum:", res)

    # Multi-threaded progress bar
    from multiprocessing import Pool
    num_cores = 4


# Generated at 2022-06-24 09:37:53.289242
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:37:57.875255
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    iqr = tqdm_pandas(tqdm=tqdm)
    try:
        iqr([1, 2, 3, 4, 5], [1, 2, 3, 4, 5], [1, 2, 3, 4, 5])
    except AssertionError:
        pass



# Generated at 2022-06-24 09:38:09.041737
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._tqdm import tqdm_pandas as original_tqdm_pandas
    from tqdm._tqdm_gui import tqdm_pandas as original_gui_tqdm_pandas


# Generated at 2022-06-24 09:38:17.084912
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:  # Pandas
        import pandas
        pandas.DataFrame().groupby().progress_apply(lambda x: x)
    except ImportError:  # pragma: no cover
        return
    else:  # pragma: no cover
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(total=100))
        pytest.raises(TypeError, lambda: tqdm_pandas(tqdm_gui).pandas())
        pytest.raises(TypeError, lambda: tqdm_pandas(tqdm_gui(total=100)).pandas())
        pytest.raises(TypeError,
                      lambda: tqdm_pandas(tqdm_notebook).pandas())

# Generated at 2022-06-24 09:38:26.988495
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from pandas import DataFrame
    from io import StringIO
    from unittest import TestCase
    from sys import stderr

    class TqdmTest(TestCase):
        def test_basic(self):
            """Test that tqdm_pandas is a public function"""
            test = '[1/6] '
            with trange(6, file=StringIO()) as t:
                df = DataFrame({'A': [5, 4, 3, 2, 1, 0]})
                tqdm_pandas(t)
                df.groupby('A')['A'].progress_apply(lambda x: x**2)
                self.assertTrue(t.get_lock().read().startswith(test))


# Generated at 2022-06-24 09:38:38.537712
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm

    # test module initialization
    from tqdm import tqdm_pandas
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tqdm.tqdm_notebook)

    # test no-op
    tqdm_pandas(tqdm.pandas(tqdm))
    tqdm_pandas(tqdm.pandas(tqdm(total=10)))

    # test function
    import pandas as pd
    df = pd.DataFrame({'a': ['bar', 'baz', 'foo']*10, 'b': range(30)})

# Generated at 2022-06-24 09:38:48.858345
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return None
    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        return None

    def progress_apply_original(self, func, *args, **kwargs):
        try:
            from tqdm import tqdm  # gated by try/except
            from tqdm import TqdmDeprecationWarning
            import warnings
            with warnings.catch_warnings(record=True):
                warnings.simplefilter('ignore', TqdmDeprecationWarning)  # NOQA
                kwargs.setdefault('tqdm', tqdm)
        except:
            pass  # user does not use tqdm

        return self._python_apply_general(
            func, *args, **kwargs)



# Generated at 2022-06-24 09:38:52.932604
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import dl_tqdm
    dl_tqdm.tqdm_pandas(dl_tqdm.tqdm)


# Shortcut to display Pandas dataframe applying tqdm

# Generated at 2022-06-24 09:39:02.036198
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    "Unit tests for tqdm_pandas"
    import pandas as pd
    import numpy as np
    # Construct some simple data and pandas objects
    N = 100
    df = pd.DataFrame({'x': range(N), 'y': range(N)})
    # Register progress bar with pandas.apply()
    from tqdm import tqdm
    tqdm_pandas(tqdm(total=len(df['x'])))
    # Test DataFrame.apply()
    df['x'].apply(lambda x: np.sqrt(x))
    # Test DataFrame.progress_apply()
    df['x'].progress_apply(lambda x: np.sqrt(x))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:12.778473
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # Test pandas apply()
    df = pd.DataFrame([
        {'a': 1},
        {'a': 2},
        {'a': 3},
        {'a': 4},
        {'a': 5},
        {'a': 6},
    ])
    tqdm_pandas(tqdm)
    it = df.groupby('a').progress_apply(lambda x: x + 1)


# Generated at 2022-06-24 09:39:22.691543
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange

    print('Testing tqdm_pandas ...', end='')
    df = pd.DataFrame([dict(val=1), dict(val=2), dict(val=3), dict(val=4)])
    for t in (tqdm(total=4), trange(4)):
        sum = df.groupby(df['val'] % 2).progress_apply(lambda x: x.val.sum())
        assert sum.loc[0] == 6
        assert sum.loc[1] == 4

    print('OK')


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:25.980938
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    # direct call
    tqdm_pandas(tqdm(total=2))
    tqdm_pandas(tqdm_notebook(total=2))

    # delayed adapter call
    tqdm_pandas(tqdm, total=2)
    tqdm_pandas(tqdm_notebook, total=2)

# Generated at 2022-06-24 09:39:35.637371
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from pandas import testing

    df = pd.DataFrame({"A": [1,2,3,4,5], "B": [6,7,8,9,10]})
    tqdm_pandas(tqdm)

    testing.assert_frame_equal(  # do nothing
        df.groupby('A').progress_apply(lambda x:x),
        df.groupby('A').apply(lambda x:x)
    )

    testing.assert_frame_equal(  # right result
        df.groupby('A').progress_apply(lambda x:x+1),
        df.groupby('A').apply(lambda x:x+1)
    )

# Generated at 2022-06-24 09:39:40.085395
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    from .tqdm import TqdmDeprecationWarning

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

        tqdm_pandas(tqdm)
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)

        tqdm_pandas(tqdm())
        assert len(w) == 2
        assert issubclass(w[-1].category, TqdmDeprecationWarning)

# Generated at 2022-06-24 09:39:48.484831
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm
    from tqdm._tqdm_pandas import _tqdm_pandas

    # create a sample dataframe
    d = {"0": np.arange(1000),
         "1": np.random.randint(low=0, high=100, size=1000)}
    df = pd.DataFrame(d)

    def f(x):
        import pandas as pd
        import numpy as np
        return (np.sum((x[1] * x[0]), axis=0), pd.DataFrame(x.std()).T)

    # tqdm_pandas should work for _tqdm_pandas objects

# Generated at 2022-06-24 09:39:53.809318
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'a': np.random.random_sample(size=1000000)})
    df.groupby(['a']).progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:02.140540
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        import pandas as pd  # NOQA
        assert tqdm_pandas(
            tclass=tqdm(total=10), leave=False).__class__ == tqdm(
                total=10, leave=False).__class__
        assert tqdm_pandas(tclass=tqdm(total=10)).__class__ == tqdm(
            total=10).__class__
        assert tqdm_pandas(tclass=tqdm(total=10), file=None).__class__ == tqdm(
            total=10, file=None).__class__
    except ImportError:
        pass

# Generated at 2022-06-24 09:40:06.763521
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tclass = tqdm(total=1000)
    tqdm_pandas(tclass)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=1000))



# Generated at 2022-06-24 09:40:15.181723
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    N = 10000000
    a = np.random.rand(N)
    b = np.random.rand(N)
    da = pd.DataFrame(a)
    db = pd.DataFrame(b)
    tqdm_pandas(tqdm.tqdm)
    result = da.progress_apply(lambda v: (v - b) ** 2, axis=1)
    assert result.shape == da.shape
    assert result.sum().iloc[0] > 0  # should be non-zero
    tqdm.tqdm.pandas(tqdm.tqdm)  # register again
    tqdm.tqdm.pandas()  # remove registration



# Generated at 2022-06-24 09:40:21.043843
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd

    tqdm_pandas(tqdm)

    df = pd.DataFrame(dict(x=range(1000)))
    df.groupby('x').progress_apply(str)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:34.746069
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm
    except ImportError:
        from unittest.mock import MagicMock
        tqdm = sys.modules['tqdm'] = MagicMock()
    try:
        import pandas
    except ImportError:
        from unittest.mock import MagicMock
        pandas = sys.modules['pandas'] = MagicMock()
    tqdm.pandas = lambda *_, **__: _
    assert tqdm_pandas(tclass=tqdm, n=1, total=2) == (1, 2)
    tqdm.tqdm = lambda *_, **__: _
    assert tqdm_pandas(tclass=tqdm.tqdm, n=1, total=2) == (1, 2)
   

# Generated at 2022-06-24 09:40:43.108770
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange
    from time import sleep
    from functools import partial

    # Set up a helper function and some fake data
    df_flights = pd.DataFrame(np.random.randint(0, 100, size=(100000, 4)),
                              columns=list('ABCD'))
    apply_f = lambda x: pd.Series([x.sum()], index=['SUM'])

    # Parallel tests
    # ---------------
    # Progress bar should not go above 100
    tqdm.pandas(tclass=partial(tqdm, total=len(df_flights)))
    df_flights.progress_apply(apply_f)

    # Check that all the tested progress bars can handle interrupted progress


# Generated at 2022-06-24 09:40:51.178192
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm_pandas(tqdm.tqdm(total=1))

    type(tqdm).pandas = lambda deprecated_t: None
    import pandas
    old_tqdm = pandas.core.groupby.DataFrameGroupBy.progress_apply
    tqdm_pandas(tqdm.tqdm(total=1))
    assert old_tqdm != pandas.core.groupby.DataFrameGroupBy.progress_apply

    tqdm_pandas(tqdm.tqdm)
    assert old_tqdm == pandas.core.groupby.DataFrameGroupBy.progress_apply
    del pandas.core.groupby.DataFrameGroupBy.progress_apply


if __name__ == '__main__':
    test_

# Generated at 2022-06-24 09:41:00.234359
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests on function tqdm_pandas.
    """
    import pandas as pd

    frame = pd.DataFrame(range(100))

    # Test basic usage: no errors
    with tqdm_pandas(total=len(frame), desc='test_basic') as pbar:
        frame.progress_apply(lambda x: x**2, axis=1)

    # Test input as tqdm.tqdm: no errors
    with tqdm_pandas(tqdm(total=len(frame), desc='test_tqdm')) as pbar:
        frame.progress_apply(lambda x: x**2, axis=1)

    # Test deprecated usage: errors

# Generated at 2022-06-24 09:41:10.433350
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        print("Skipping test_tqdm_pandas: pandas not installed")
        return
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO  # py3
    from tqdm import trange

    def random_df(n=3, m=3):
        df = pandas.DataFrame.from_items(
            [(str(i), [random() for j in range(m)]) for i in range(n)])
        return df

    def nop(x):
        return x

    dfs = [random_df() for i in range(10)]
    args = [(df,) for df in dfs]

    out = StringIO()

# Generated at 2022-06-24 09:41:20.300547
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import concat
    from pandas import read_csv
    from pandas import read_excel
    from pandas import read_hdf
    from pandas import read_sql
    from pandas import read_table
    from pandas import read_parquet
    from pandas import read_feather
    from pandas import read_sas
    from pandas import read_stata
    from pandas import read_pickle

    from pandas import to_datetime
    from pandas import to_numeric
    from pandas import to_timedelta

    from pandas import date_range
    from pandas import Period
    from pandas import Timestamp

    from pandas import Categorical
    from pandas import qcut
    from pandas import cut
    from pandas import Interval

# Generated at 2022-06-24 09:41:31.729088
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_gui
    try:
        from pandas import DataFrame, Series
    except ImportError:
        from pandas.core.api import DataFrame, Series

    tqdm(first=100)
    tqdm(total=100)
    tqdm(desc='ABC')
    tqdm(ascii=True)
    tqdm(unit='def', unit_scale=True)
    tqdm(leave=False)
    tqdm(mininterval=0.1)
    tqdm(miniters=10)
    tqdm(gui=True)
    tqdm(ncols=120)
    tqdm(bar_format='{r_bar}{bar}{l_bar}')
    tq

# Generated at 2022-06-24 09:41:42.606710
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Check disallow of positional arg
    with pytest.raises(TypeError):
        tqdm_pandas(tqdm)
    # Check disallow of nested positional arg
    with pytest.raises(TypeError):
        tqdm_pandas(tqdm(total=100))
    # Check allow dispatch to tqdm.pandas
    tqdm_pandas(tqdm_bar, total=100)
    assert tqdm_bar.pandas_count == 1


if __name__ == "__main__":
    from tqdm._tqdm import tqdm
    import pandas as pd

    df = pd.DataFrame()
    df["x"] = range(1000000)


# Generated at 2022-06-24 09:41:52.039425
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    all_ok = True            # flag if any of the tests failed

    # we can't test the first use case because tqdm is not imported yet.
    # # first use case: tqdm_pandas(tqdm, ...)
    # with pytest.raises(TqdmDeprecationWarning):
    #     tqdm_pandas(tqdm, ...)

    # second use case: tqdm_pandas(tqdm(...))
    class tqdm_class(tqdm):
        def __init__(self, **tqdm_kwargs):
            super(tqdm_class, self).__init__(**tqdm_kwargs)
            self._deprecated_adapter_called = False
            self._deprecated_adapter_args = tqdm_kwargs

# Generated at 2022-06-24 09:42:02.274510
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit tests for tqdm_pandas
    """
    import pandas as pd

    if pd:  # pragma: no cover
        try:
            try:
                from pandas import Series, DataFrame
            except ImportError:
                from pandas.core.series import Series
                from pandas.core.frame import DataFrame

            series_case = Series(range(10))
            dataframe_case = DataFrame(dict(a=series_case))

            for case in (series_case, dataframe_case):
                for func in (case.apply, case.progress_apply, case.groupby,
                             case.groupby('a').progress_apply):
                    func(lambda x: x, axis=1).to_frame()
        except ImportError:
            pass

# Generated at 2022-06-24 09:42:11.972645
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, pandas
    from pandas import DataFrame

    with tqdm(*tqdm(range(10))(), disable=True) as t:
        DataFrame(range(10)).groupby('length_10').progress_apply(lambda x: x)
    with tqdm(*tqdm(range(10))()) as t:
        DataFrame(range(10)).groupby('length_10').progress_apply(lambda x: x)
    pandas(tqdm(range(10)), *tqdm(range(10))())
    tqdm_pandas(tqdm)
    tqdm_pandas(type('tqdm', (tqdm, ), {'__name__': 'tqdm_tqdm'}))

# Generated at 2022-06-24 09:42:15.100956
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, ascii=True)



# Generated at 2022-06-24 09:42:21.931174
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:42:31.922928
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .std import tqdm

    t = tqdm(total=1)
    t.pandas()
    t.pandas(leave=True)
    t.pandas(leave=False)

    t = tqdm(total=1)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, leave=True)
    tqdm_pandas(tqdm, leave=False)

    t = tqdm(total=1)
    tqdm_pandas(t)
    tqdm_pandas(t, leave=True)
    tqdm_pandas(t, leave=False)

    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:42:41.285233
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import pandas as pd
    import numpy as np
    import tqdm

    def test_func(df):
        return len(df)

    df = pd.DataFrame(np.random.random((100, 3)), columns=list('ABC'))
    df.groupby(df.A).progress_apply(test_func)

    # test delayed adapter
    tqdm.tqdm_pandas('tqdm')
    df = pd.DataFrame(np.random.random((100, 3)), columns=list('ABC'))
    df.groupby(df.A).progress_apply(test_func)
    # test deprecated class decorator
    tqdm.tqdm_pandas()
    df = pd

# Generated at 2022-06-24 09:42:50.807462
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import concat
    from pandas import date_range
    from math import exp, log
    from random import uniform
    from tqdm.auto import trange

    total = int(4e4)
    tdf = DataFrame(
        {'DATE': date_range('2011-01-01', periods=total),
         'VAL': [uniform(0, 1) for _ in range(total)]})
    with trange(4) as t:
        for i in t:
            t.set_description('Loop #%i' % i)
            if i == 0:
                tdf.groupby('DATE').progress_apply(log)
            elif i == 1:
                tdf.groupby('DATE').progress_transform(exp)

# Generated at 2022-06-24 09:43:00.578692
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    from .std import tqdm

    # Test that pandas's progress_apply is detected
    tqdm_pandas(tqdm, total=1)
    tqdm_pandas(tqdm(total=1))

    def fail_func_reducer(df):
        return pd.Series(dict(fail=df.values[0][0]))

    try:
        pd.DataFrame([[0], [1]]).sum().progress_apply(fail_func_reducer)
    except Exception:
        return
    else:
        raise RuntimeError("should've raised an Exception")

# Generated at 2022-06-24 09:43:05.912162
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    test = pd.DataFrame(np.random.randint(1, 100, (10000, 2)))
    result = test.groupby(0).progress_apply(lambda x: x.sum())
    assert result.sum() == test.sum().sum()
    del test, result, pd

    import pandas as pd
    import numpy as np
    import tqdm

    test = pd.DataFrame(np.random.randint(1, 100, (10000, 2)))
    tqdm.pandas(ncols=80)
    result = test.groupby(0).progress_apply(lambda x: x.sum())
    tqdm.tqdm_pandas(ncols=80)

# Generated at 2022-06-24 09:43:16.207388
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

# Generated at 2022-06-24 09:43:23.872942
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import test_tqdm_pandas
    test_tqdm_pandas()

test_tqdm_pandas()

del test_tqdm_pandas

# pandas_v >= 0.25.0.dev0
if float(pandas_v_major + '.' + pandas_v_minor) >= 0.25:  # pragma: no cover
    try:
        import pandas
        pandas.core.window.Expanding.progress_apply = \
            pandas.api.indexers.Expanding.progress_apply
    except:  # pragma: no cover
        pass

# pandas_v >= 0.24.0.dev0

# Generated at 2022-06-24 09:43:34.371180
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'a': [1, 2, 3],
                       'b': ['abc', 'def', 'ghi'],
                       'c': [True, True, False]})

    l = list(df.groupby(['a', 'b', 'c']).progress_apply(lambda x: x))
    assert l == [df.iloc[:1], df.iloc[1:2], df.iloc[2:3]]

    with tqdm.tqdm(total=len(df['a']), desc='groups') as pbar:
        l = list(df.groupby('a').progress_apply(lambda x: x + 1, pbar=pbar))

# Generated at 2022-06-24 09:43:38.739761
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    df = pd.DataFrame(np.random.normal(size=(1000000, 1)))
    with tqdm(total=len(df)) as pbar:  # Initialise
        def wrapped(x):
            pbar.update()  # Progress update
            return x * 2  # Return value

        df.progress_apply(wrapped)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:49.229222
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return None

    nrows = 100000
    df = pd.DataFrame()
    df['a'] = np.random.randn(nrows)
    df['b'] = np.random.randn(nrows)
    df['c'] = np.random.choice([False, True], size=(nrows,))

    def slow_square(x):
        from time import sleep
        sleep(0.1)
        return x**2

    df['d'] = df['a'].progress_apply(slow_square)

    tol = 10.
    assert np.abs(df['a'].var() - df['d'].var()) < tol


if __name__ == '__main__':
    test_

# Generated at 2022-06-24 09:44:00.592045
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy

    # Test for delayed adapter case (tqdm -> tqdm_pandas)
    tqdm_pandas(tqdm)

    # Test for delayed adapter case (tqdm_notebook -> tqdm_pandas)
    from tqdm.notebook import tqdm_notebook  # this is slow...
    tqdm_pandas(tqdm_notebook)

    # Test for tqdm-wrapped case (tqdm_pandas(tqdm))
    tqdm_pandas(tqdm())

    # Test for tqdm-wrapped case (tqdm_pandas(tqdm_notebook))
   

# Generated at 2022-06-24 09:44:10.929019
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.notebook import tqdm
    import pandas as pd

    df = pd.DataFrame([[0, 2, 3], [3, 1, 2], [1, 1, 2], [1, 2, 0]])
    df.columns = 'a b c'.split()
    df.sum(axis=1)

    with tqdm(total=df.shape[0], desc='fancyprogress') as pbar:
        df.progress_apply(lambda row: pbar.update())
        pbar.close()

    df = pd.DataFrame([[0, 2, 3], [3, 1, 2], [1, 1, 2], [1, 2, 0]])
    df.columns = 'a b c'.split()
    df.sum(axis=1)


# Generated at 2022-06-24 09:44:21.494054
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from random import randint, random
    from time import sleep
    from tqdm import tqdm, tqdm_notebook, trange
    from tqdm.pandas import tqdm_pandas
    from tqdm.pandas import TqdmTypeError

    tqdm_pandas(tqdm)

    df = pd.DataFrame({'x': [random() for _ in range(10000)]})

    with trange(10) as t:
        for i in t:
            df.x.progress_apply(lambda x: sleep(0.001))
            t.set_postfix(i=i, n=len(df.x), n_uneven=len(
                df.x) * (i % 2))  # fake uneven postfix
       

# Generated at 2022-06-24 09:44:29.289210
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_notebook as tqdm
    df = pd.DataFrame(
        {'strings': np.random.choice(
            ['ab', 'cd', 'ef', 'gh', 'ij'], 1000)},
        index=pd.date_range(
            start='2016-01-01', periods=1000))
    tqdm_pandas(tqdm)
    df.groupby('strings').progress_apply(len)

# Generated at 2022-06-24 09:44:39.117998
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
    except ImportError:
        # pandas not installed
        return

    from tqdm import tqdm
    from tqdm import TqdmTypeError, TqdmKeyError

    # Assert exception is raised
    try:
        # Wrong number of arguments
        tqdm_pandas(tqdm)
        raise AssertionError
    except TqdmTypeError:
        pass

    # Unsupported (kw)arguments
    try:
        tqdm_pandas(tqdm, foo=1)
        raise AssertionError
    except TqdmKeyError:
        pass

    # Return the correct type
    assert isinstance(tqdm_pandas(tqdm('')), tqdm)

    # Check DataFrameGroupBy.progress

# Generated at 2022-06-24 09:44:48.135005
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm_pandas`
    """
    from tqdm.autonotebook import tqdm as tqdm_auto
    from tqdm.std import tqdm as tqdm_std
    from pandas import DataFrame, read_csv
    from functools import partial
    import os
    from os.path import dirname
    from numpy import mean
    from sys import stderr
    from re import match

    assert match(r'^[0-9]\.[0-9]$', read_csv(
        'requirements.txt').columns[0])  # use same pandas

    # test pandas API
    x = tqdm_auto(total=10)
    DataFrame(x).progress_apply(x.update)
    x.close()

    #

# Generated at 2022-06-24 09:44:57.385251
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    total = df[0].count()

    # `progress_apply` uses `desc`
    def display(df, i):
        tqdm_pandas(tqdm(desc="{key}".format(key=i), total=total))
        return df


# Generated at 2022-06-24 09:45:07.886921
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import numpy as np
        import pandas as pd
        import dataframe_iterator
    except ImportError:
        print('Skipping pandas unit test. Install pandas for more tests.')
        return

    # warm-ups for adaption detection
    try:
        from tqdm.auto import tqdm
    except ImportError:
        tqdm = getattr(__import__('tqdm'), 'tqdm')

    from tqdm.contrib import DummyTqdmFile  # Lazy dep

    try:
        tqdm.pandas(desc='test', leave=True, nested=True)
    except TypeError:
        try:
            tqdm.pandas(nested=True, leave=True)
        except TypeError:
            pass


# Generated at 2022-06-24 09:45:12.221596
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy.random import random
    from tqdm import tqdm

    df = DataFrame({'x': random(100), 'y': random(100)})

    # test tqdm_pandas as decorator
    @tqdm_pandas
    def test_func(df, x):
        return df.progress_apply(lambda _: sum(x), axis=1)

    test_func(df, [0, 1])
    test_func(df, [0, 1, 2])

    # test registration of tqdm instance
    tqdm_pandas(tqdm(desc='register test'))
    df.groupby('x').x.progress_apply(lambda x: sum(x))



# Generated at 2022-06-24 09:45:18.118282
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    N = 100000
    df = pd.DataFrame({'x': np.random.randint(-N, N, (N,))}, index=np.arange(N))
    tqdm_pandas(tqdm())
    df.groupby('x').progress_apply(lambda x: x.sum())

# Generated at 2022-06-24 09:45:27.204643
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:45:33.830689
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    try:
        import pandas as pd
    except ImportError:
        return
    assert tqdm_pandas.__doc__
    with tqdm_pandas(total=1) as t:
        assert t.total == 1
        assert str(t)
    with tqdm_pandas(total=1, file=open(os.devnull, 'w')) as t:
        assert t.total == 1
        assert str(t)
    with tqdm_pandas(total=1, disable=False) as t:
        assert t.total == 1
        assert str(t)
    tqdm_pandas(total=1, disable=True)

# Generated at 2022-06-24 09:45:43.217532
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import warnings
    import pandas as pd
    import numpy as np
    import tqdm

    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    with warnings.catch_warnings(record=True) as w:
        tqdm.tqdm_pandas(tqdm.tqdm())  # This should NOT trigger a DeprecationWarning
        tqdm.tqdm_pandas(tqdm.tqdm_notebook())
        tqdm.tqdm_pandas(tqdm.tqdm_gui())
        tqdm.tqdm_pandas(tqdm.tqdm_pandas())

# Generated at 2022-06-24 09:45:51.482127
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]], columns=list('abc'))
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm.pandas
    df.groupby('a').progress_apply(lambda x: x.sum())
    assert isinstance(pd.core.groupby.DataFrameGroupBy.progress_apply,
                      tqdm)  # delay adapter

if __name__ == "__main__":
    test_tqdm_pandas()