

# Generated at 2022-06-24 09:35:50.603597
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        # no pandas
        return

    import tqdm
    from tqdm._tqdm import tqdm

    df = pandas.DataFrame({"a": range(10), "b": range(10)})
    with tqdm(total=len(df)) as pbar:
        def mysum(x):
            pbar.update()
            return sum(x)
        _ = df.progress_apply(mysum)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:35:58.650131
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Setup
    import pandas as pd
    from tqdm import tqdm

    # Test
    try:
        tqdm_pandas(tqdm)
        N = 100000
        df = pd.DataFrame({'a': [1, 2, 3] * (int(N / 3)),
                           'b': list(range(N)),
                           'c': [3, 4, 2] * (int(N / 3))})
        print(df.groupby('a').progress_apply(lambda x: x))
    except Exception as e:
        print(e)
    finally:
        tqdm_pandas.deprecated_t.close()


if __name__ == '__main__':
    test_tqdm_pandas()

# Aliases
# tqdm

# Generated at 2022-06-24 09:36:08.771043
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    import pandas as pd
    import numpy as np
    # DataFrame creation
    df = pd.DataFrame(np.random.randint(1, 10, (1000000, 4)),
                      columns=list('ABCD'))
    # Basic tqdm_pandas application
    tqdm_pandas(tqdm(total=df.shape[0]))(df.groupby('A').sum)
    # Delayed tqdm_pandas application
    tqdm_pandas()(df.groupby('A').sum)
    # Deprecated tqdm_pandas application
    tqdm_pandas(tqdm())(df.groupby('A').sum)
    # Corrupted delayed tqdm_pandas application

# Generated at 2022-06-24 09:36:17.077916
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        from tqdm import tqdm

        a = pd.DataFrame(np.random.randn(10000, 10000))
        with tqdm(total=a.shape[0], file=open(os.devnull, 'w')) as pbar:
            a.apply(lambda x: x * x, axis=1, progress_bar=pbar)

    except Exception as e:
        return False
    return True


if __name__ == '__main__':
    print("tqdm_pandas: %s" % test_tqdm_pandas())

# Generated at 2022-06-24 09:36:22.355715
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from numpy import arange
    from pandas import DataFrame
    from tqdm import tqdm
    tqdm_pandas(tqdm())
    assert DataFrame({"x": arange(10)}).groupby("x").progress_apply(lambda x: x)
    tqdm_pandas(tqdm(N=100))
    assert DataFrame({"x": arange(10)}).groupby("x").progress_apply(lambda x: x)
    assert DataFrame({'x': arange(10)}).groupby('x').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:36:32.680903
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import trange
    from tqdm import tqdm_pandas  # noqa
    from tqdm._tqdm.tests.common import new_bool_property

    tqdm_pandas(trange)
    n = 1000
    df = pd.DataFrame({
        'A': pd.Series(np.random.randn(n)),
        'B': pd.Series(np.random.randn(n)),
    })

    def f(x):
        return x['A'] + x['B']

    pd.DataFrame.progress_apply = new_bool_property('progress_apply')
    for progress_apply in (False, True):
        df.progress_apply = progress_apply

# Generated at 2022-06-24 09:36:42.721096
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
  """Basic test for `tqdm.pandas()`"""
  from pandas import DataFrame
  from pandas.core.groupby import DataFrameGroupBy
  from tqdm import tnrange, tqdm_pandas, trange
  from tqdm.autonotebook import tqdm

  class Dummy:
    """Dummy object for testing"""

    def __init__(self, data, tqdm_cls):
      self.data = data
      self.tqdm_class = tqdm_cls

    def apply(self, func, **kwargs):
      """Dummy apply"""
      with self.tqdm_class() as pbar:
        for datum in pbar(self.data):
          func(datum)


# Generated at 2022-06-24 09:36:49.793830
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange
    from numpy.random import uniform, normal
    from time import sleep

    df = pd.DataFrame({"x": uniform(size=10000),
                       "y": uniform(size=10000),
                       "z": uniform(size=10000),
                       "w": uniform(size=10000)})
    df.index = normal(size=len(df))
    grouped = df.groupby(["x", "y", "z"])

    # `tqdm.pandas` regroups `groupby` operations
    with tqdm(total=len(grouped)) as pbar:
        res = grouped.progress_apply(lambda x: x.w.sum(), pbar=pbar)

    # `tqdm.pandas` regroups

# Generated at 2022-06-24 09:36:55.295528
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm)

    try:
        import numpy as np
        tqdm_pandas(tqdm)
    except ImportError:
        pass

    # DataFrame
    df = pd.DataFrame(np.random.randn(10000, 6))
    df.progress_apply(lambda x: x, axis=1)

    # Series
    df = pd.Series(np.random.randn(10000))
    df.progress_apply(lambda x: x)

# Generated at 2022-06-24 09:37:00.949155
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame(np.random.randint(0,10,(1000,3)), columns=list('ABC'))
    tqdm.pandas(desc="test")
    df.groupby('A').progress_apply(lambda x: x)
    tqdm.pandas(desc="test")
    df.groupby('A').progress_apply(lambda x: x)

    tqdm.tqdm_pandas(tclass=tqdm.tqdm, desc="test")
    df.groupby('A').progress_apply(lambda x: x)
    tqdm.tqdm_pandas(tclass=tqdm.tqdm(desc="test"))
    df.groupby

# Generated at 2022-06-24 09:37:11.228621
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        # Introduce a test case for the compatibility with the deprecated tqdm_pandas(tqdm, ...)
        import pandas as pd
        tqdm_pandas(tqdm, desc='pandas')
        from tqdm.pandas import tqdm_pandas as tqdm_pandas_new
        import random

        df = pd.DataFrame({'x': [random.random() for _ in range(1000)]})
        df.groupby('x').progress_apply(lambda g: g**2)
        assert True
    except Exception as e:
        pass

# Registers tqdm_pandas(tqdm, ...) for compatibility with the deprecated tqdm_pandas(tqdm, ...)
tqdm_pandas = t

# Generated at 2022-06-24 09:37:17.741499
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({
        'x': [1, 2, 3],
        'y': [-1, -2, -3]
    })

    try:
        with tqdm.pandas() as t:
            df.progress_apply(tqdm.tqdm.write, axis=1, args=('TEST',))
            assert t.disable
    except Exception as e:
        # If this fails, it means that tqdm_pandas was not yet registered
        raise e from None


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:28.563304
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm, trange
    import pandas as pd
    import numpy as np
    from time import sleep

    @tqdm_pandas
    def apply_func(df):
        sleep(0.1)
        return df

    N = 100
    D = 10
    x = np.random.rand(N, D)
    df = pd.DataFrame(x, columns=["x-{0:04d}".format(i) for i in range(D)])
    df.head()

    # test_tqdm
    df1 = apply_func(df)
    assert np.all(df.values == df1.values)
    # test_trange
    with tqdm.external_write_mode():
        df2 = apply_func(df)


# Generated at 2022-06-24 09:37:38.553412
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import trange
    from numpy.random import uniform
    df = DataFrame({'a': uniform(size=1000000), 'b': uniform(size=1000000)})
    for obj in (trange, lambda *a, **k: trange(0, *a, **k)):
        t = obj(1, desc='test_tqdm_pandas')
        res = tqdm_pandas(t, leave=False)(df.groupby('a').progress_apply)(lambda x: x)
        assert isinstance(res, DataFrame)


# ===========================================================================
# Monkey-patch pandas.core.groupby.DataFrameGroupBy.progress_apply
# ===========================================================================

# Generated at 2022-06-24 09:37:41.042981
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    df = DataFrame([1, 2, 3, 4, 5, 6])

    for i in tqdm_pandas(tqdm(df.groupby(0), total=len(df)), desc='groupby'):
        pass

# Generated at 2022-06-24 09:37:52.644947
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame
    import numpy as np
    # This DataFrame has a shape of (8,16) and (32,64)
    # To enable the progress bar, the number of elements
    # should be greater than or equal to the value of
    # pandas.core.groupby.DataFrameGroupBy.progress_apply
    # which is set to 100_000 by default.
    df1 = DataFrame(np.random.randint(0, 10, size=(8, 16)))
    df2 = DataFrame(np.random.randint(0, 10, size=(32, 64)))


# Generated at 2022-06-24 09:37:58.987739
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randn(10, 4))
    df.groupby(0).progress_apply(lambda x: x)
    df.groupby(0).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:09.456501
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Function test
    import pandas as pd
    import numpy as np
    import tqdm
    with tqdm.tqdm_pandas(leave=True) as t:
        tqdm.tqdm_pandas(t)
        df = pd.DataFrame({'a': np.random.randint(0, 100, size=100)})
        df.groupby('a').progress_apply(lambda x: x)
    # Class test
    class Tqdm:
        def __init__(self, leave, total=None, **kwargs):
            self.total = total
            self.leave = leave
    tqdm_pandas(Tqdm(leave=True), total=100)


if __name__ == "__main__":
    test_tqdm_pand

# Generated at 2022-06-24 09:38:17.378687
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:38:27.202463
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    with tqdm.tests.test_tqdm_pandas(tqdm_pandas):
        import pandas as pd
        from numpy.random import rand
        from time import sleep
        try:
            from pandas.util.testing import (
                assert_frame_equal, assert_series_equal)
        except ImportError:
            from pandas.util.compat import assert_frame_equal, assert_series_equal

        def timesleep(x, *args, **kwargs):
            sleep(0.01)
            return x
        df1 = pd.DataFrame({'x': rand(1000)})
        df2 = df1.progress_apply(timesleep, 1, foo=10, bar=20)
        assert_frame_equal(df1, df2)

       

# Generated at 2022-06-24 09:38:38.655936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({'A': np.arange(100), 'B': np.arange(100, 0, -1)})

    def wrapped(df):
        return pd.DataFrame({'A': df['A'].values**2,
                             'B': df['B'].values**2})

    df_new = df.groupby('A').progress_apply(wrapped)

    assert isinstance(df_new, pd.DataFrame)
    assert np.all(df['A']**2 == df_new['A'])


# Generated at 2022-06-24 09:38:46.556512
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    pd.core.groupby.GroupBy.progress_apply = tqdm_pandas
    df = pd.DataFrame({'col1': np.random.randint(0, 100, size=1000),
                       'col2': np.random.randint(0, 100, size=1000)})
    grouped = df.groupby('col1')
    grouped.apply(lambda x: x)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:49.331133
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Trigger tqdm_pandas warnings, to ensure they're working
    """
    tqdm_pandas(None)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:59.988410
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    tqdm = tqdm_pandas(tqdm)
    assert tqdm is not None

    # tqdm is registered
    df = pd.DataFrame(list(range(100)), columns=['column'])
    df = df.groupby(df.column // 10).progress_apply(lambda x: x ** 2)
    assert df.column.sum() == 328350

    tqdm = tqdm_pandas(tqdm, total=30)
    assert tqdm is not None

    # tqdm is registered
    df = pd.DataFrame(list(range(100)), columns=['column'])

# Generated at 2022-06-24 09:39:09.998134
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    # with tqdm.tqdm()
    with tqdm_pandas(tqdm(total=len(dfx), desc='tqdm_pandas')) as t:
        df_new = dfx.groupby(['label', 'group'])['val'].progress_apply(
            lambda x: x.sum())

    # with tqdm_pandas
    with tqdm_pandas(total=len(dfx), desc='tqdm_pandas') as t:
        df_new = dfx.groupby(['label', 'group'])['val'].progress_apply(
            lambda x: x.sum())


if __name__ == '__main__':
    test_tqdm_pandas

# Generated at 2022-06-24 09:39:20.848457
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import pandas as pd
    df = pd.DataFrame({'x': range(10000)})

    try:
        tqdm_pandas(tqdm(**defaults))  # delayed adapter case
    except RuntimeError:
        pass
    else:
        raise AssertionError("Should fail because .progress_apply not defined")

    tqdm_pandas(tqdm(**defaults), **defaults)  # deprecated case

    try:
        df.groupby('x', **defaults).progress_apply(lambda x: x)  # deprecated case
    except AttributeError:
        pass
    else:
        raise AssertionError("Should fail because .progress_apply not defined")

    # new case
    tq

# Generated at 2022-06-24 09:39:27.870671
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test function tqdm_pandas"""
    try:
        import pandas as pd
        pd.DataFrame([x for x in tqdm_pandas(range(10))])
        pd.DataFrame([x for x in tqdm_pandas(tqdm(range(10)))])
    except:
        pass


try:
    from pandas.core.groupby import GroupBy
except ImportError:
    GroupBy = object

try:
    from pandas.core.groupby import DataFrameGroupBy
except ImportError:
    DataFrameGroupBy = object

try:
    from pandas.core.groupby import SeriesGroupBy
except ImportError:
    SeriesGroupBy = object



# Generated at 2022-06-24 09:39:36.740004
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    import sys

    # Get the name of the module that is running the unit test
    module_name = sys.modules['__main__'].__file__

    # Create a DataFrame with 20 rows
    df = pd.DataFrame({'A': np.random.randint(1, 100, size=20),
                       'B': np.random.randint(1, 100, size=20)})
    df_size = len(df.index)
    tqdm_kwargs = {'desc': module_name, 'total': df_size}

# Generated at 2022-06-24 09:39:43.882450
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tnrange
    import pandas
    from random import randint

    N = 1000
    M = 100
    L = 10
    with tnrange(M) as t:
        t.pandas(desc='apply')
        df = pandas.DataFrame(index=range(N))
        for i in t:
            df['some_column_{:03d}'.format(i)] = [randint(0, L) for _ in range(N)]

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:51.460561
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # Generate pandas dataframe
    N, C = 100, 10
    df = pd.DataFrame(
        {'col{:d}'.format(i): np.random.choice(
            np.arange(-1000, 1000), size=N)
         for i in range(C)})

    # Test with 'tqdm' or 'tqdm_notebook'
    tqdm_pandas(tqdm, desc='testing')
    df.groupby('col0').progress_apply(lambda x: (x + 1).mean())
    df.groupby('col0').progress_apply(
        lambda x: (x + 1).mean(), axis=1)
    tqdm_pandas(tqdm, desc='testing')

# Generated at 2022-06-24 09:40:01.564618
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm as tqdm_factory
    from tqdm import tqdm_notebook as tqdm_notebook_factory
    from tqdm import tqdm_gui as tqdm_gui_factory
    from tqdm import tqdm_pandas

    import pandas as pd

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        from pandas.core.groupby.groupby import DataFrameGroupBy

    df = pd.DataFrame({'A': [0, 0, 1, 1], 'B': [0, 1, 0, 1], 'C': [0, 1, 1, 0]})

    tqdm_pandas(tqdm_factory)
    assert 'progress_apply' in dir

# Generated at 2022-06-24 09:40:11.752482
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd

        df = pd.DataFrame(np.random.randn(100, 3))
        df.progress_apply(lambda x: x ** 2)
        with closing(StringIO()) as our_file:
            tqdm_pandas(tqdm(
                file=our_file, leave=True, total=len(df)),
                desc="UnitTest-test_tqdm_pandas")
            df.progress_apply(lambda x: x ** 2)
            assert "UnitTest-test_tqdm_pandas" in our_file.getvalue()
    except ImportError:
        pass

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:17.496341
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .tqdm_gui import tqdm
    from pandas import DataFrame

    t = tqdm(total=10)
    tqdm_pandas(t)
    df = DataFrame({'x': range(10), 'y': range(10)})
    df.groupby('x').progress_apply(lambda x: x)

    t = tqdm(total=10)
    tqdm_pandas(t)
    df = DataFrame({'x': range(10), 'y': range(10)})
    df.groupby('x').progress_apply(lambda x: x)

    tqdm_pandas(tqdm)
    df = DataFrame({'x': range(10), 'y': range(10)})

# Generated at 2022-06-24 09:40:27.358242
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        raise unittest.SkipTest("pandas not installed")
    try:
        import numpy as np
        assert np
    except ImportError:
        raise unittest.SkipTest("numpy not installed")

    # import tqdm_pandas after pandas to keep error message coherent
    from tqdm import tqdm
    from tqdm.pandas import tqdm_pandas

    test = unittest.TestCase()

    def tqdm_pandas_bar(*args, **kwargs):
        if 'tqdm_class' in kwargs:  # legacy
            kwargs['tclass'] = kwargs.pop('tqdm_class')

# Generated at 2022-06-24 09:40:30.985095
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm() as pbar:
        tqdm_pandas(pbar)

# Generated at 2022-06-24 09:40:39.377627
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    # Test tqdm instance
    t = tqdm(**{'total': 10})
    tqdm_pandas(t)

    # Test deprecated tqdm instance
    t = tqdm(**{'total': 10})
    tqdm_pandas(t)

    # Test tqdm class
    tqdm_pandas(tclass=tqdm, **{'total': 10})


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:49.528890
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Tests function tqdm_pandas"""
    try:
        import pandas as pd
    except ImportError:
        print('Optional package Pandas not found, skip unit test.', file=sys.stderr)
        return None

    tqdm_pandas(tqdm, leave=False)
    assert pd.core.groupby.DataFrameGroupBy.progress_apply.__name__ == \
        '_progress_apply'  # not yet overridden
    assert pd.core.groupby.SeriesGroupBy.progress_apply.__name__ == \
        '_progress_apply'  # not yet overridden

    tqdm_pandas(tqdm)
    assert pd.core.groupby.DataFrameGroupBy.progress_apply.__name__ == 'tqdm_wrapper'

# Generated at 2022-06-24 09:40:54.492577
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    tqdm = tqdm_pandas(tqdm=None)
    test_pd = pd.DataFrame({'col': [np.random.random(i) for i in [10, 1000, 100]]})
    test_pd.groupby('col').progress_apply(lambda x: np.mean(x))



# Generated at 2022-06-24 09:41:02.911050
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit tests for tqdm_pandas"""
    from tqdm import tqdm
    from numpy import random
    from pandas import DataFrame
    # Generate pandas dataframe
    df = DataFrame({'Norm': random.randn(1000000),
                    'Exp': random.randn(1000000) * 100,
                    'Binomial': random.randint(low=0, high=2, size=1000000),
                    'Multinomial': random.randint(low=0, high=10, size=1000000)
                    })

    # Using tqdm as iterator
    with tqdm(total=len(df)) as pbar:

        def wrapped(self, f, *args, **kwargs):
            pbar.update()
            return f(*args, **kwargs)

        tqdm

# Generated at 2022-06-24 09:41:12.255990
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    from pandas.util.testing import assert_frame_equal

    # Table that will be used
    df = pd.DataFrame(np.random.random((100, 5)))

    # Compute Columns Sums
    def apply_func(x):
        return x.sum()

    # Compute Columns Sums with tqdm
    def apply_func_tqdm(x):
        for i in tqdm(range(len(x))):
            x = x.sum()
        return x

    # Test without tqdm
    df_sum = df.apply(apply_func, axis=0)
    df_sum_tqdm = df.apply(apply_func_tqdm, axis=0)



# Generated at 2022-06-24 09:41:21.793601
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import pandas as tqdm_pandas
    import pandas as pd
    import numpy as np
    N = 100000
    try:
        import pandas.core.groupby.DataFrameGroupBy;
        assert hasattr(pandas.core.groupby.DataFrameGroupBy,
                       'progress_apply')
    except BaseException:
        tqdm_pandas = None

    if tqdm_pandas:
        df = pd.DataFrame({
            'user': np.random.randint(
                0, 1000, size=N),
            'item': np.random.randint(
                0, 1000, size=N),
            'value': np.random.randn(N)
        })

# Generated at 2022-06-24 09:41:33.509242
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        pytest.skip("pandas not found.")
    from tqdm.pandas import tqdm_pandas

    a = list(range(1000))

    # Test 1
    for i in tqdm_pandas(a, ascii=True, unit_scale=True, unit='items', desc='1st loop'):
        pass

    # Test 2
    for i in tqdm_pandas(a, ascii=True, unit_scale=True, unit='items',
                         desc='2nd loop'):
        pass

    # Test 3

# Generated at 2022-06-24 09:41:42.034515
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Simple unit tests to verify that arguments can be passed
    to Pandas wrapped function, using tqdm and tqdm_pandas
    """
    import pandas as pd
    import numpy as np
    import time
    import warnings

    dummy_df = pd.DataFrame(np.random.randn(20000, 2), columns=['col1', 'col2'])

    def dummy_function_to_progress(df):
        return df.mean()

    def test_on_tqdm():
        from tqdm import tqdm

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")


# Generated at 2022-06-24 09:41:50.055413
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert not hasattr(pandas, '_tqdm_default')
    tqdm_pandas(tqdm)
    assert hasattr(pandas, '_tqdm_default')
    tqdm_pandas(tqdm_notebook)
    assert hasattr(pandas, '_tqdm_default')
    assert pandas._tqdm_default.__name__ == 'tqdm_notebook'
    try:
        import pandas; pandas.__version__
    except ImportError:
        return
    import pandas as pd
    df = pd.DataFrame({'a': [1, 2, 3, 4, 5], 'b': [6, 7, 8, 9, 0]})
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:41:54.652986
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    try:
        import pandas
    except ImportError:
        return

    progress_bar = tqdm.tqdm(total=100)
    progress_bar.pandas()


test_tqdm_pandas()

# Generated at 2022-06-24 09:42:04.939029
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    import numpy as np

    @tqdm_pandas(tqdm)
    def adder(x):
        """adds 2 to `x`"""
        return x + 2

    data = {'col': np.arange(100)}
    df = pd.DataFrame(data)
    tqdm.pandas(desc="test_pandas")
    df['col'] = df['col'].progress_apply(adder)


# Generated at 2022-06-24 09:42:08.500141
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy.random import randn

    # Create a pandas dataframe for testing
    df = DataFrame(randn(10000, 2))
    df.groupby(df.index // 100).progress_apply(lambda x: x * 2)

# Generated at 2022-06-24 09:42:12.973152
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)), columns=list('ABCDEF'))
    tqdm.pandas(desc="my bar!")
    df.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-24 09:42:20.508293
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:42:29.000995
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        import tqdm
    except ImportError:
        import warnings
        warnings.warn(
            'Tests of tqdm.pandas() require tqdm, which could not be imported')
    else:
        df = pd.DataFrame({'x': [1, 2, 3, 4]})
        with tqdm.tqdm(total=len(df)) as pbar:
            assert isinstance(df.groupby('x').progress_apply(lambda _: None),
                              pd.core.groupby.DataFrameGroupBy)
            pbar.update()

# Generated at 2022-06-24 09:42:36.999761
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    import tqdm
    # test pandas progress_apply
    df = pd.DataFrame(np.random.rand(1000), columns=['a'])
    df['b'] = 0
    for i in tqdm_pandas(df.groupby(df.a.apply(lambda x: int(x * 10)))):  # df.progress_apply will be call
        time.sleep(1e-6)
    assert df.b.sum() == 0


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:42.266065
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        import pandas
    except ImportError:
        return
    else:
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm())


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:46.508252
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit tests for function `tqdm_pandas`.

    """
    from tqdm.tests.test_pandas import test_tqdm_pandas as _test_tqdm_pandas

    _test_tqdm_pandas(tqdm_pandas)

# Generated at 2022-06-24 09:42:54.358031
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy

    class DummyDataFrameGroupBy(DataFrameGroupBy):
        def progress_apply(self, *args, **kwargs):
            return super(DummyDataFrameGroupBy, self).progress_apply(
                *args, **kwargs)

    data = DataFrame()
    data['word'] = ['egg', 'apple', 'egg', 'apple']
    data['length'] = [3, 5, 3, 5]
    data['word_length'] = data.groupby('word').progress_apply(
        lambda x: x['length'].sum())

    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:42:59.303029
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas
    df = pd.DataFrame({'a': range(100), 'b': ['a'] * 100})

    @tqdm_pandas
    def g(df):
        return df

    g(df)



# Generated at 2022-06-24 09:43:05.235881
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with pytest.raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)
    with pytest.raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm_notebook)
    with pytest.raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm_gui)


# Generated at 2022-06-24 09:43:15.396448
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # check that pandas is installed
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest("pandas is not installed, skipping pandas test")

    # check that tqdm was imported
    if not getattr(tqdm_pandas, '_tqdm', None):
        raise unittest.SkipTest("tqdm is not imported")

    # unit test to ensure that tqdm_pandas() registers with pandas
    # (unless already registered) and returns the tqdm instance
    t = tqdm_pandas(total=1)
    assert isinstance(t, tqdm_pandas._tqdm)
    assert pd.core.groupby.DataFrameGroupBy.progress_apply == tqdm_pandas.pand

# Generated at 2022-06-24 09:43:20.768693
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas
    """
    import pandas as pd
    import numpy as np

    data = pd.DataFrame(np.random.random(10000))
    with tqdm_pandas(total=data.shape[0]) as pbar:  # can use tqdm_gui, optional kwargs, etc
        data.progress_apply(lambda x: x**2)
        pbar.update()

# Generated at 2022-06-24 09:43:31.093162
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd


# Generated at 2022-06-24 09:43:39.057091
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib import pandas
    import numpy as np

    df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})

    def func(x):
        return x

    df_new = df.groupby('x').progress_apply(func)
    assert pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]}).equals(df_new)

    with tqdm() as progress:
        df_new = df.groupby('x').progress_apply(func, progress=progress)
    assert pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]}).equals

# Generated at 2022-06-24 09:43:49.602163
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    from tqdm import TqdmDeprecationWarning

    test = pd.DataFrame(
        [[0, 0, 1, 2], [4, 5, 6, 7], [8, 9, 10, 11]],
        index=['a', 'b', 'c'],
        columns=['d', 'e', 'f', 'g']
    )

    test_copy = test.copy()

    def test_func(*args, **kwargs):
        if len(args) == 1:
            args = args[0]
        args.progress_apply(lambda x: x+1)
        args.progress_apply(lambda x: x+1)
        return args

    with tqdm(total=2) as t:
        test_

# Generated at 2022-06-24 09:43:58.501147
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from pandas import Series

    s = Series(range(10))
    tqdm_pandas(trange(1), file=sys.stdout)
    tqdm_pandas(trange(1))
    with trange(1) as t:
        tqdm_pandas(t)
    with trange(1) as t:
        tqdm_pandas(t, file=sys.stdout)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:07.289073
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Instantiate tqdm
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy import random

    # Generate random dataframe with 10 dates and 10 values
    df = DataFrame({'dates': random.randint(999999999, size=10),
                    'values': random.rand(10)})

    # Group dataframe by dates and compute sum
    df_grouped = df.groupby(
        'dates').progress_apply(
        lambda x: x['values'].sum())

    with tqdm(total=100) as pbar:
        for i in range(100):
            pbar.update(1)
            assert i == df['values'].progress_apply(
                lambda x: i)['values'].sum()

# Generated at 2022-06-24 09:44:14.319062
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm, trange
    import pandas as pd
    import numpy as np
    import time
    import os, io

    def f(x):
        time.sleep(0.01)
        return x

    def g(x):
        # NB: no sleeps; should be fast, so `tqdm` is not updated
        #  until all results are gathered at the end
        return x

    try:
        from IPython.core.display import clear_output
        clear_output  # silence pyflakes
    except ImportError:
        clear_output = None

    # tests for tqdm_notebook
    if clear_output:
        Series = pd.Series(np.random.rand(100))

# Generated at 2022-06-24 09:44:24.107602
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for tqdm_pandas"""
    import pandas as pd

    # Create test DataFrame
    df = pd.DataFrame()
    df['a'] = [1, 2, 3, 4, 5]

    from tqdm.auto import tqdm
    # Register tqdm instance
    tqdm_pandas(tqdm())
    if pd.__version__ < '1.0':
        # Before pandas 1.0
        for _ in df.groupby("a").progress_apply(lambda x: x):
            pass
    else:
        # After pandas 1.0
        for _ in df.groupby("a").progress_apply(lambda x: x):
            pass
    # Print the DataFrame
    print(df)



# Generated at 2022-06-24 09:44:33.500865
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import tqdm

    # test registration without options
    tqdm_pandas(tclass=tqdm.tqdm)

    # test registration with options
    tqdm_pandas(tclass=tqdm.tqdm, desc='test')

    # test deferred registration
    tqdm_pandas(tclass=tqdm, desc='test')

    # test deferred registration with tqdm_* name
    tqdm_pandas(tclass=tqdm.tqdm_gui, desc='test')


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:43.293035
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test that tqdm_pandas works in Python 2 and 3"""
    # setup
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import pandas
    import numpy as np

    data = [['2019-03-01', 1, 4], ['2019-03-01', 2, 5], ['2019-03-02', 1, 6],
            ['2019-03-02', 2, 7], ['2019-03-03', 1, 8], ['2019-03-03', 2, 9]]
    df = pandas.DataFrame(data, columns=['date', 'id', 'A'])
    dates = pandas.date_range('2019-01-01', '2019-01-10')

    # test pandas.core.groupby.DataFrameGroupBy.progress_

# Generated at 2022-06-24 09:44:48.652703
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Testing tqdm_pandas"""
    try:
        import pandas as pd
    except ImportError:
        return

    with tqdm(total=10 ** 6) as t:
        pd.DataFrame([1] * 10 ** 6).progress_apply(lambda x: t.update())

    try:
        t.pandas()
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise e

# Generated at 2022-06-24 09:44:57.854542
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    df = pd.DataFrame({'integers': [1, 2, 3, 4],
                       'strings': ['x', 'y', 'z', 'w']})
    df.groupby('integers').progress_apply(lambda x: x)
    df.groupby('integers').progress_apply(lambda x: x, tqdm_kwargs={'mininterval': 0.01})
    df.groupby('integers').progress_apply(lambda x: x, tqdm_kwargs={})
    df.groupby('integers').progress_apply(lambda x: x, tclass=tqdm)

# Generated at 2022-06-24 09:45:07.927123
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame, Series
    try:
        from pandas.core.groupby import DataFrameGroupBy, SeriesGroupBy
    except ImportError:
        # Old pandas
        from pandas.core.groupby import PanelGroupBy as DataFrameGroupBy
        from pandas.core.groupby import TimeSeriesGroupBy as SeriesGroupBy

    from tqdm import tqdm

    tqdm_pandas(tqdm)

    assert hasattr(DataFrameGroupBy, 'progress_apply')
    assert hasattr(SeriesGroupBy, 'progress_apply')

    assert callable(DataFrameGroupBy.progress_apply)
    assert callable(SeriesGroupBy.progress_apply)


# Generated at 2022-06-24 09:45:14.198166
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame({
        'col1': np.random.randn(100),
        'col2': np.random.randn(100),
        'col3': np.random.randn(100)
    })

    def f(df):
        return df.sum()

    res1 = df.groupby('col1').progress_apply(f)
    res2 = df.groupby('col1').progress_apply(f, args=(), kwargs={})
    tqdm_pandas(tqdm)
    res3 = df.groupby('col1').progress_apply(f)
    tqdm_pandas(tqdm, leave=True)
    res4 = df

# Generated at 2022-06-24 09:45:20.148925
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for class `tqdm_pandas`

    :return: True if no exception found.
    """
    import tqdm
    try:
        import pandas
    except ImportError:
        return True  # module pandas not installed, skip test

    tqdm.tqdm_pandas(tqdm.tqdm, total=10)
    return True

# Generated at 2022-06-24 09:45:25.262034
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm(total=100), desc="first-desc")
    tqdm_pandas(tqdm, total=100, desc="second-desc")
    tqdm_pandas(tqdm_notebook(total=100), desc="third-desc")
    tqdm_pandas(tqdm_notebook, total=100, desc="fourth-desc")

# Generated at 2022-06-24 09:45:32.214453
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    N = 100
    df = pd.DataFrame({'x': [i for i in range(N)]})
    assert list(df.groupby(lambda x: 0).progress_apply(lambda g: g['x'].sum())) == [
        sum(range(N))]
    assert list(tqdm(df.groupby(lambda x: 0)).progress_apply(lambda g: g['x'].sum())) == [
        sum(range(N))]
    assert list(tqdm(df).groupby(lambda x: 0).progress_apply(lambda g: g['x'].sum())) == \
        [sum(range(N))]

# Generated at 2022-06-24 09:45:38.718054
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame({"A": [1, 2, 3]})
    tqdm_pandas(tqdm(total=1))  # Unit test
    assert list(df.progress_apply(lambda a: a + 1)) == [2, 3, 4]

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:43.041841
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    for deprecated in [True, False]:
        for tclass in [tqdm, tqdm_pandas]:
            for tclass in [tqdm_pandas, tqdm]:
                tqdm_pandas(tclass())
                tqdm_pandas(tclass(deprecated=deprecated),
                            deprecated=deprecated)



# Generated at 2022-06-24 09:45:52.176768
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    df = pd.DataFrame(np.random.random((20, 20)), columns=[i for i in range(20)], index=[i for i in range(20)])

    import tqdm
    tqdm_pandas(tqdm, df.groupby(0).progress_apply(lambda x: x))
    tqdm_pandas(tqdm(total=20), df.groupby(0).progress_apply(lambda x: x))

    from tqdm import trange
    tqdm_pandas(trange(20), df.groupby(0).progress_apply(lambda x: x))


if __name__ == "__main__":
    test_tqdm_pandas()