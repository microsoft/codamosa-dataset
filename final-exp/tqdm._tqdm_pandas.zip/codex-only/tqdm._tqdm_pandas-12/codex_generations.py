

# Generated at 2022-06-24 09:35:46.350203
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    t = tqdm_pandas(tqdm())
    # Assert that None is returned if tqdm_pandas is called with no arguments
    assert t is None, 'tqdm_pandas should not return anything if called with no ' \
                      'arguments'
    # Assert that pandas is properly integrating with tqdm
    a = pd.DataFrame({'x': [1, 2, 3, 4, 5, 6, 7], 'y': [1, 2, 3, 4, 5, 6, 7]})
    b = a.groupby('y').progress_apply(lambda x: x)
    assert isinstance(b, pd.core.frame.DataFrame), 'groupby.progress_apply should ' \
                                

# Generated at 2022-06-24 09:35:55.928257
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas


try:
    from pandas import DataFrame
except ImportError:
    pass
else:
    DataFrame.progress_apply = tqdm_pandas(DataFrame.progress_apply)
    # Unit test for tqdm_pandas injection
    def test_DataFrame_progress_apply():
        df = DataFrame([[1, 2], [3, 4]])
        df.progress_apply(lambda x: x + 1)
        df.progress_apply(lambda x: x + 1, axis=0)


if __name__ == '__main__':
    sys.exit(not test_tqdm_pandas())

# Generated at 2022-06-24 09:36:07.384076
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    # Simple test
    N = 100
    df = pd.DataFrame({'x': range(N)})

    with tqdm(total=N) as pbar:
        def func(x):
            pbar.update()
            return x

        res = df.progress_apply(func)
        assert (res == df).all().all()
        assert pbar.n == N

    # Test adapter
    tqdm_pandas(tqdm, total=N)
    res = df.progress_apply(func)
    assert (res == df).all().all()

    tqdm_pandas(tqdm, total=N)

# Generated at 2022-06-24 09:36:12.913427
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from time import sleep
    from tqdm import tqdm
    from pandas import DataFrame

    df = DataFrame({'a': [1, 4, 5, 6], 'b': [3, 6, 7, 17]})
    tqdm_pandas(tqdm(total=df.shape[0]))
    df.progress_apply(lambda x: sleep(0.5))

# Generated at 2022-06-24 09:36:21.183510
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm import trange
    from tqdm import tqdm_notebook
    #from tqdm import tnrange
    from tqdm import tqdm_pandas
    from random import random
    from time import sleep
    n = 100000
    t = trange(n, file=sys.stdout)
    d = pd.DataFrame(np.random.random((n, n)))
    tqdm_pandas(t, desc='Pandas 1')
    d.progress_apply(lambda x: random())
    tqdm_pandas(t, desc='Pandas 2')
    for _ in d.progress_apply(lambda x: random()):
        pass
    tqdm

# Generated at 2022-06-24 09:36:26.020522
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import random
    import tqdm.contrib.pandas
    df = pd.DataFrame(np.random.randn(100, 100),
                      columns=['a' + str(i) for i in range(100)])
    tqdm.contrib.pandas.tqdm_pandas(tqdm.tqdm)  # register the default `tqdm`
    res = df.groupby(by=[df.a50, df.a51]).progress_apply(lambda x: x)
    print("\nDone\n")

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:34.020370
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    from tqdm import tqdm_pandas

    df = pd.DataFrame({'id': range(10000),
                       'val': np.random.random(10000)})
    df2 = df.copy()

    tqdm_pandas(tqdm())  # pandas >= v0.20.0
    for _ in tqdm_pandas(df.groupby('id'), 'mean'):
        pass

    tqdm_pandas(tqdm())  # pandas < v0.20.0
    for _ in df2.groupby('id').progress_apply(np.mean):
        pass

# Generated at 2022-06-24 09:36:43.586494
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    input = pd.DataFrame(np.random.randn(10000, 4))
    result = input.progress_apply(sum, axis=1)
    for i in tqdm(range(100)):
        input.progress_apply(sum, axis=1)
    for i in tqdm_pandas(range(100)):
        input.progress_apply(sum, axis=1)
    for i in tqdm_pandas(tqdm(range(100))):
        input.progress_apply(sum, axis=1)
    try:
        tqdm_pandas(tqdm_pandas(tqdm(range(100))))
    except Exception as e:
        assert isinstance

# Generated at 2022-06-24 09:36:48.929300
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        import numpy
        N = 10000
        data = pandas.DataFrame({'A': numpy.random.randint(
            0, 100, size=N), 'B': numpy.random.randint(0, 100, size=N)})
        data.progress_apply(lambda row: 1 / (row['A'] + 1) / (row['B'] + 1), axis=1)
    except Exception as e:
        print(e)
        raise

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:56.512123
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import unittest
    import pandas as pd
    from tqdm import tqdm

    class TqdmPandasTest(unittest.TestCase):
        def setUp(self):
            self.n, self.p = 100, 4
            self.df = pd.DataFrame(np.random.rand(self.n, self.p))
            self.df[0] = np.random.randint(0, 2, self.n)


# Generated at 2022-06-24 09:37:02.721309
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame

    def my_func(df):
        return df + 2

    df = DataFrame({"a": [1, 2, 3],
                    "b": [4, 5, 6],
                    "c": [7, 8, 9]})

    df_new = df.groupby('a').progress_apply(my_func)

    return df_new

# Generated at 2022-06-24 09:37:13.022102
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    # data
    n = 1000000
    df = pd.DataFrame({'a': np.random.randint(0, 100, size=n),
                       'b': np.random.randint(0, 100, size=n),
                       'c': np.random.randint(0, 100, size=n),
                       'd': np.random.randint(0, 100, size=n)})

    @tqdm_pandas
    def f(x):
        return x

    @tqdm_pandas(tqdm=tqdm.tqdm)
    def g(x):
        return x

    for f in (f, g):
        for _ in f(df).itertuples():
            pass


# Generated at 2022-06-24 09:37:19.182569
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    # Old style
    import tqdm
    try:
        tqdm_pandas(tqdm)
        assert False, 'Should have failed to instantiate'
    except TypeError:
        pass
    # New style
    tqdm_pandas(tqdm.tqdm)
    # Test that it works
    df = pd.DataFrame([[1, 2], [3, 4]])
    df.groupby('A').progress_apply(lambda g: g+1)
    return

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:29.125011
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, trange

    # Test: tqdm_pandas(tclass, **tqdm_kwargs)
    # Test: TqdmTypeError
    try:
        tqdm_pandas(tqdm(10))
    except TypeError:
        pass
    else:
        raise RuntimeError("TqdmTypeError not raised")

    # Test: TqdmDeprecationWarning
    try:
        tqdm_pandas(tqdm, desc="deprecated")
    except DeprecationWarning:
        pass
    else:
        raise RuntimeError("TqdmDeprecationWarning not raised")

    # Test: "Please use `tqdm.pandas(...)` instead of `tqdm

# Generated at 2022-06-24 09:37:30.337013
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:37:40.492892
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randn(10000, 2))

    # default use of tqdm
    with tqdm(total=df.shape[0]) as pbar:
        def update(*a):
            pbar.update()
        df.progress_apply(update)

    # register `tqdm` with pandas
    tqdm_pandas(tqdm)
    with tqdm(total=df.shape[0]) as pbar:
        df.progress_apply(lambda x: pbar.update())

    # Use with `pandas.DataFrameGroupBy.progress_apply`, `max_rows` and `desc` kwargs
   

# Generated at 2022-06-24 09:37:46.235485
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import tqdm
    assert (hasattr(pandas, 'core'))
    assert (hasattr(pandas.core, 'groupby'))
    assert (hasattr(pandas.core.groupby, 'DataFrameGroupBy'))
    assert (hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply'))

    tqdm_pandas(tqdm)
    assert (hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply'))

    pandas.core.groupby.DataFrameGroupBy.progress_apply = None
    tqdm_pandas(tqdm)
    assert (hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply'))

# Generated at 2022-06-24 09:37:53.340739
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.contrib import pandas
    try:
        import pandas
    except ImportError:
        return
    try:
        # noinspection PyUnresolvedReferences
        pandas.DataFrame  # verify pandas version supports patched progress_apply
    except AttributeError:
        return
    tqdm_pandas(tqdm)
    tqdm_pandas(pandas)


# ------------------------------------------------------------------------------
# Register with pandas.core.groupby.DataFrameGroupBy.progress_apply
# ------------------------------------------------------------------------------

# Generated at 2022-06-24 09:38:04.628664
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        try:
            import pandas.core.groupby
            assert False
        except ImportError:
            pass
        return

    # Setup
    import pandas as pd
    import numpy as np

    def test_apply(x):
        return x, np.mean(x)

    df = pd.DataFrame(np.array([np.arange(10), np.arange(10)]).T,
                      columns=['col_0', 'col_1'])
    f = lambda x: x  # noqa: E731

    # Test
    with tqdm_pandas(desc='tqdm_pandas'):
        # Test apply
        assert isinstance(df.apply(f, axis=0), pd.DataFrame)


# Generated at 2022-06-24 09:38:14.092032
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    try:
        df = pd.DataFrame({'A': np.arange(1000)})
        def func(x):
            return x * 2
        df.groupby('A').progress_apply(func)
    except Exception as e:
        print(e)
        return False
    return True


if __name__ == '__main__':
    from tqdm.autonotebook import tqdm as orig_tqdm
    from tqdm import tqdm
    from tqdm.contrib.tests import dummy_cli
    from tqdm._utils import _term_move_up
    from tqdm._utils import _range
    from tqdm.tests import get_opts, _range


# Generated at 2022-06-24 09:38:19.312211
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    tqdm.pandas()
    n = 100
    df = pd.DataFrame(np.random.randint(0, n, size=(n, 4)), columns=list('ABCD'))
    df.groupby('A').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:38:28.245760
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    `python3 -m tqdm.notebook.tqdm_pandas`
    :return:
    """

    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return

    pd.options.mode.chained_assignment = None  # default='warn'

    with tqdm.notebook.tqdm_pandas() as progress_bar:
        progress_bar.pandas()
        df = pd.DataFrame(
            np.random.randint(0, 100, (100000, 6)),
            columns=['a', 'b', 'c', 'd', 'e', 'f'])

# Generated at 2022-06-24 09:38:39.821053
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return

    df = pd.DataFrame({'a': np.random.randint(0, 100, 1000),
                       'b': np.random.randint(-50, 50, 1000),
                       'c': np.random.random(1000)})
    with tqdm(total=len(df), leave=True) as t:
        for i in t:
            pass

    with tqdm(total=len(df), leave=True) as t:
        for i in df.groupby('a').progress_apply(lambda x: len(x)):
            t.update()
        assert t.n == len(df)

    tqdm_pandas(tqdm)  # register the `tqdm`

# Generated at 2022-06-24 09:38:47.458265
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .gui import tqdm
    from .utils import _range
    from pandas import DataFrame

    for tqdm_class in [tqdm, tqdm.gui, tqdm.gui.tqdm]:
        for i in _range(3):
            tqdm_pandas(tqdm_class)
            DataFrame(range(10)).groupby(0).progress_apply(lambda x: x**2)
    tqdm_pandas(tqdm.tqdm)
    DataFrame(range(10)).groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-24 09:38:53.566276
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(total=10, file=sys.stdout))
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(total=10, file=sys.stdout))
    except ImportError:
        pass

# Generated at 2022-06-24 09:39:02.489643
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return
    N = 1000
    df = pd.DataFrame(np.random.randint(0, 100, size=(N, 4)), columns=list('ABCD'))

    with closing(StringIO()) as our_file:
        first_t = tqdm(total=N, file=our_file)
        tqdm_pandas(first_t, file=our_file)
        _ = df.groupby('A').progress_apply(lambda x: x)
        assert first_t == tqdm(total=N, file=our_file)
        try:
            from pandas.api.types import is_list_like
        except ImportError:
            return
        # Check that it works with a `

# Generated at 2022-06-24 09:39:13.657973
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:39:22.559185
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas
    from tqdm import tqdm

    li = [1, 2, 3, 4, 5]
    df = pandas.DataFrame(li)
    for _ in tqdm(pandas.Series(li)):
        pass
    for _ in tqdm_pandas(df.groupby(0)):
        pass
    for _ in tqdm_pandas(tqdm(df.groupby(0))):
        pass


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:34.473877
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:39:44.493278
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    from types import MethodType
    from pandas.core.groupby import DataFrameGroupBy
    from pandas.core.groupby import SeriesGroupBy

    # create a wrapped version of `DataFrame.groupby` with progress bar
    def progress_apply(self, func, *args, **kwargs):
        with tqdm(total=len(self), leave=None) as pbar:
            def wrapper(x):
                pbar.update()
                return func(x)
            return self.apply(wrapper, *args, **kwargs)

    DataFrameGroupBy.progress_apply = MethodType(progress_apply, None)
    SeriesGroupBy.progress_apply = Method

# Generated at 2022-06-24 09:39:51.839008
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    from tqdm import tqdm
    from tqdm._tqdm_pandas import tqdm_pandas

    df = pd.DataFrame(
        [i for i in range(10)], columns=['x'])

    # Test for backward compatibility
    with tqdm(range(10)) as t:
        df.progress_apply(t.update)

    # Test for classes
    with tqdm(range(10)) as t:
        tqdm_pandas(t, lambda x: x)
        df.progress_apply(lambda x: x)

    # Test for functions
    with tqdm_pandas(lambda x: x, desc='test') as t:
        df.progress_apply(lambda x: x)



# Generated at 2022-06-24 09:39:58.407749
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    from pandas import DataFrame
    from numpy import random

    t = tqdm(total=100)
    tqdm_pandas(t)
    df = DataFrame(random.randint(0, 10, (100, 3)))
    gr = df.groupby(0)
    gr.progress_apply(lambda x: x)
    assert t.n == 100


# Generated at 2022-06-24 09:40:05.502762
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from pandas import DataFrame

    # Test tqdm_pandas deprecated
    with tqdm.tests.enter_leave_state(miniters=0, mininterval=0):
        with pytest.warns(TqdmDeprecationWarning):
            tqdm_pandas(tqdm)

    # Test tqdm_pandas deprecated
    with tqdm.tests.enter_leave_state(miniters=0, mininterval=0):
        with pytest.warns(TqdmDeprecationWarning):
            tqdm_pandas(tqdm(desc="test"))

    # Check if tqdm is registered

# Generated at 2022-06-24 09:40:11.402240
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm.pandas
    df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    for _ in tqdm.pandas.progress_apply(df, lambda x: x):
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:16.967376
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if hasattr(__builtins__, '__IPYTHON__'):
        pytest.skip("pandas not available in IPython")
    tqdm_pandas(tqdm(leave=False))
    tqdm_pandas(tqdm(leave=False), leave=False)
    tqdm_pandas(tqdm(leave=None))
    tqdm_pandas(tqdm(leave=None), leave=True)
    tqdm_pandas(tqdm, leave=False)
    tqdm_pandas(tqdm, leave=None)
    with pytest.raises(tqdm.TqdmDeprecationWarning):
        tqdm_pandas(tqdm(leave=False), leave=True)

# Generated at 2022-06-24 09:40:26.094290
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame(index=range(10000), columns=['col1'])
    df.progress_apply(lambda x: x + 1)
    df.progress_apply(lambda x: x + 1, axis=1)
    with tqdm(total=None) as t1:
        df.progress_apply(lambda x: x + 1, axis=1, tqdm_kwargs=dict(t1=t1))
    df.progress_apply(lambda x: x + 1, axis=1, tqdm_kwargs=dict(t=t1))


# Generated at 2022-06-24 09:40:34.245934
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    try:
        from tqdm import tqdm
    except ImportError:
        print("Skip test_tqdm_pandas")
        return
    df = pd.DataFrame(np.random.randint(0, 10, (10000, 4)), columns=list('abcd'))
    with tqdm(total=len(df), unit_scale=False) as pbar:
        len(df.groupby(list('abcd')).progress_apply(lambda x: x**2))
        assert pbar.n == len(df)

# Generated at 2022-06-24 09:40:41.731440
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import numpy as np

    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm.pandas.progress_apply

    data = {'gender': ['M'] * 5 + ['F'] * 5,
            'score': [10, 20, 30, 40, 50, 100, 90, 80, 70, 60]}
    df = pd.DataFrame(data)
    df.groupby(['gender']).progress_apply(np.mean)

# Register tqdm_pandas with tqdm
tqdm = tqdm.pandas = tqdm_pandas

# Generated at 2022-06-24 09:40:47.466118
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    msg = 'This is a test'
    with tqdm.external_write_mode():
        tqdm_pandas(tqdm, msg)
        tqdm_pandas(tqdm(msg))
        tqdm_pandas(tqdm.tqdm, msg)
        tqdm_pandas(tqdm.tqdm(msg))

test_tqdm_pandas()

# Generated at 2022-06-24 09:40:54.368558
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from contextlib import redirect_stdout
    from tqdm import tqdm, trange, TqdmExperimentalWarning, tqdm_gui
    from tqdm.autonotebook import tqdm as tqdm_notebook
    from tqdm.contrib import CFile
    from unittest import TestCase

    tqdm_kwargs = {'smoothing': 0, 'dynamic_ncols': True,
                   'bar_format': '{l_bar}{bar}| {n_fmt}/{total_fmt} [{remaining}]'}

    class PandasMock(object):
        _instances = []

        def __init__(self, iterable_func=iter, desc=''):
            self._instances.append(self)
            self.desc = desc
            self

# Generated at 2022-06-24 09:41:02.812884
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame(dict(
        a=[1, 2, 3], b=['a', 'b', 'c'], c=[9, 10, 11]))
    tqdm_pandas(df.groupby('b').progress_apply(len))
    tqdm_pandas(tqdm(df.groupby('b')).progress_apply(len))
    df = pd.DataFrame(dict(
        a=[1, 2, 3],
        b=pd.Index(['a', 'b', 'c']),
        c=[9, 10, 11]))
    tqdm_pandas(df.groupby('b').progress_apply(len))

# Generated at 2022-06-24 09:41:12.183549
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from itertools import product

    from tqdm import tqdm

    tqdm_pandas(tqdm, desc='')
    tqdm_pandas(tqdm(desc=''))
    import pandas as pd
    df = pd.DataFrame({'a': pd.Series(list(range(20))), 'b': pd.Series(list(range(20)))})
    df.progress_apply(lambda row: pd.Series(list(product(row['a'], row['b']))), axis=1)
    tqdm_pandas(tqdm, desc='')
    tqdm_pandas(tqdm(desc=''))
    tqdm_pandas(tqdm(desc=''), desc='')
    tqdm

# Generated at 2022-06-24 09:41:16.094071
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm._utils import _range
    from pandas import DataFrame

    tqdm_pandas(tqdm, df=DataFrame({'test': _range(10000)}))

# Generated at 2022-06-24 09:41:23.571745
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test to make sure tqdm_pandas works as expected.
    """
    import os

    import pandas as pd
    from pandas.util.testing import makeCustomDataframe as mkdf

    assert 'TQDM_PYTHON_PANDAS_IN_PROGRESS' not in os.environ
    tdf = pd.DataFrame(index=range(1))
    tdf = tdf.groupby(tdf.index).progress_apply(lambda x: x)  # noqa
    assert 'TQDM_PYTHON_PANDAS_IN_PROGRESS' in os.environ
    import tqdm

    tqdm.pandas(desc="my-progress")

# Generated at 2022-06-24 09:41:30.470396
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    @tqdm_pandas
    def apply_func(df):
        return df.apply(lambda x: x**2)

    N = 100
    df = pd.DataFrame(np.random.randn(N, 2))

    apply_func(df)

if __name__ == '__main__':
    from tqdm import __version__
    print('\ntqdm {v} pandas integration test:'.format(v=__version__))
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:42.605656
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import trange

    # Case 0: Test deprecated tqdm_pandas(tqdm)
    with trange(10, desc='tqdm_pandas(tqdm)') as t:
        t.set_postfix(
            tqdm_pandas=True,
            DataFrameGroupBy_tqdm_pandas_before=pd.Series(range(10)).groupby('x'),
            DataFrameGroupBy_tqdm_pandas_after=tqdm_pandas(tqdm)
        )
    assert t.n == 10
    # Case 1: Test deprecated tqdm_pandas(tqdm())

# Generated at 2022-06-24 09:41:50.335547
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def pandas_test(cls):
        def inner(**tqdm_kwargs):
            from pandas.core.groupby import DataFrameGroupBy
            from tqdm import tqdm_notebook

            DataFrameGroupBy.progress_apply = lambda x, func, *args, **kwargs: func(
                *args, **kwargs)

            return cls(**tqdm_kwargs)
        return inner

    tqdm_pandas(pandas_test)
    df = pd.DataFrame({'a': list(range(10))})
    with tqdm_pandas(total=df.groupby('a').ngroups) as t:
        df.groupby('a').progress_apply(lambda x: print(t.update()))

#

# Generated at 2022-06-24 09:42:00.804565
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame({'x': np.random.rand(100)})

    with tqdm(total=df.shape[0]) as pbar:
        def test_func(x):
            pbar.update()
            return x

        df['x'].progress_apply(test_func)

    tqdm_pandas(tqdm)

    with tqdm(total=df.shape[0]) as pbar:
        def test_func(x):
            pbar.update()
            return x

        df['x'].progress_apply(test_func)

    # Will not raise exception:
    tqdm_pandas(type(tqdm))


# Generated at 2022-06-24 09:42:10.874086
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.pandas import tqdm_pandas

    def test_func(x):
        return x * x

    df = pd.DataFrame(dict(a=range(100), b=range(100)))
    tqdm.pandas()
    r = df.groupby('b').progress_apply(test_func)

    r = df.groupby('b').apply(test_func)
    tqdm_pandas(tqdm())

    # using a lambda for the progress bar (for testing purposes)
    r = df.groupby('b').progress_apply(test_func)

    # using a progress bar with custom parameters

# Generated at 2022-06-24 09:42:18.750548
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, TqdmDeprecationWarning

    def f_to_test(a, b):
        """Test function to be `progress_apply`ed."""
        return a * b
    # --
    N = 10
    a = np.random.randn(N, 1)
    b = np.random.randn(N, 1)
    data = {'a': a, 'b': b}
    test_df = pd.DataFrame(data)
    test_df_groupby = test_df.groupby(lambda x: 0)
    # --
    tqdm_pandas(tqdm)
    test_df_groupby.progress_apply(f_to_test)

    TqdmDeprec

# Generated at 2022-06-24 09:42:28.964531
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import string

    df = pd.DataFrame(
        {'A': np.random.randint(1, size=100),
         'B': np.random.randint(1, size=100),
         'C': [x for x in string.ascii_lowercase[:100]]
         })
    df.groupby('A', group_keys=False).progress_apply(
        lambda x: x.nlargest(5, 'B')  # noqa: E731
    )
    with tqdm(total=10) as t:
        # delayed adapter case
        tqdm_pandas(t)
        df.groupby('A').progress_apply(lambda x: x.nlargest(5, 'B'))  # noqa: E731

# Generated at 2022-06-24 09:42:38.567773
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for the decorator.
    """
    import pandas as pd

    # pylint: disable=unused-variable
    @tqdm_pandas
    def f(df):
        '''do nothing'''
        return df

    # pylint: enable=unused-variable


# Generated at 2022-06-24 09:42:44.823175
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    # Test progress_apply
    with tqdm(total=100, unit='B', unit_scale=True, unit_divisor=1024) as t:
        df = DataFrame({'col1': (range(100))})
        df.groupby('col1').progress_apply(lambda _: t.update())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:53.341928
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import numpy as np
    import pandas as pd
    import pandas.util.testing as pdt

    def _check_tqdm_cls(tqdm_cls):
        n_rows = 5
        pdt.N = n_rows
        df = pdt.makeDataFrame()
        tqdm_cls.pandas(desc='pandas_tqdm', leave=True, file=get_tqdm_proxy())
        df.groupby('A').progress_apply(lambda x: x)
        tqdm_cls.pandas(desc='pandas_tqdm', leave=False, file=get_tqdm_proxy())
        df.groupby('A').progress_apply(lambda x: x)


# Generated at 2022-06-24 09:42:59.137565
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Unit test for function tqdm_pandas
    '''
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(total=111, desc='tqdm_pandas',
                     unit_scale=10, mininterval=0.5))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:09.353171
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    from tqdm.contrib.tests.pandas_tests import df
    import pandas as pd

    for desc in ('', 'desc'):
        for total in (5, None):
            tqdm.pandas(desc=desc, total=total)
            res = df.progress_apply(lambda x: x)
            assert res.equals(df)  # assert no side-effects
            res = df.groupby('aa').progress_apply(lambda x: x)
            assert res.equals(df.groupby('aa').apply(lambda x: x))  # assert no side-effects

    df2 = df.copy()
    df2['bb'] = pd.Categorical(df2['bb'])

# Generated at 2022-06-24 09:43:17.628603
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    "Test tqdm_pandas"
    import pandas as pd
    import numpy as np
    from tqdm.auto import trange

    def pow_with_tqdm_pandas(v, e):
        return v.progress_apply(lambda s: s ** e)

    df = pd.DataFrame({'d': np.random.randn(10000000)})
    for i in trange(1, 10):
        df = pow_with_tqdm_pandas(df, i)
    assert df['d'].sum() < .001



# Generated at 2022-06-24 09:43:19.438009
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert (tqdm_pandas(tqdm(range(5))) ==
            tqdm.pandas(range(5)))



# Generated at 2022-06-24 09:43:29.390113
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from pandas import DataFrame
    from numpy.random import randn
    from time import sleep

    df = DataFrame(randn(5, 5))

    # Register `tqdm` with `pandas.core.groupby.DataFrameGroupBy.progress_apply`
    tqdm_pandas(tqdm())

    # Now you can use `progress_apply` instead of `apply`
    df.groupby(0).progress_apply(lambda x: x ** 2)

    # Register `tqdm` with `pandas.core.groupby.DataFrameGroupBy.progress_apply`
    # and suppress warnings
    tqdm_pandas(tqdm(), disable=True)

    # Now you can use `progress_apply` instead of `

# Generated at 2022-06-24 09:43:37.308262
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from numpy.random import randint
    from pandas import DataFrame

    def test_func(x, y, z):
        return z - x ** y

    df = DataFrame(randint(0, 10, (10000, 3)), columns=['a', 'b', 'c'])

    # regular
    df.groupby(['a']).progress_apply(test_func, y=2, z=15.1)

    # delayed
    tqdm_pandas(tqdm_notebook, leave=False)
    df.groupby(['a']).progress_apply(test_func, y=2, z=15.1)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:39.419206
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame

    with tqdm_pandas() as t:
        df = DataFrame()
        df.grouper(0).progress_apply(lambda x: None)



# Generated at 2022-06-24 09:43:49.933568
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm import tqdm

    df = pd.DataFrame(
        {'integers': list(range(10)),
         'floats': [float(x) for x in range(10)],
         'strings': [str(x) for x in range(10)],
         'bools': [bool(x % 2) for x in range(10)]})
    df.groupby('bools')['integers'].progress_apply(lambda x: x)
    df.groupby('bools')['integers'].progress_apply(lambda x: x + 1)

# Generated at 2022-06-24 09:43:56.886606
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    df = DataFrame({'A': range(int(1e3)), 'B': range(int(1e3))})
    # df.groupby('A').progress_apply(lambda x: x)  # old deprecated way
    df.groupby('A').apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:05.887257
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    pd = pandas.DataFrame({'a': [1, 2, 3, 4], 'b': [5, 6, 7, 8]})
    def f(x):
        return x * 2
    out = tqdm_pandas(pd.progress_apply(f, axis=1))
    assert out.equals(pd.apply(f, axis=1))
    
    # Same with missing values
    pd = pandas.DataFrame({'a': [1, 2, 3, 4], 'b': [5, 6, 7, 8]})
    pd['a'][2] = float('NaN')
    def f(x):
        return x * 2
    out = tqdm_pandas(pd.progress_apply(f, axis=1))
    assert out.equ

# Generated at 2022-06-24 09:44:14.379738
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    from pandas.util.testing import network

    if not network.is_reachable('travis-ci.org'):
        df = pd.DataFrame(
            columns=['a', 'b'], dtype=float).append(
            {'a': 1., 'b': 2.}, ignore_index=True).append(
                {'a': 3., 'b': 4.}, ignore_index=True)
        num = df.groupby('a').progress_apply(lambda x: x['b'])
        assert num[0] == 2.

        tqdm.pandas(leave=False)
        num = df.groupby('a').progress_apply(lambda x: x['b'])
        assert num[0] == 2.

       

# Generated at 2022-06-24 09:44:20.047409
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    class TqdmTest:
        def __init__(self, total):
            self.total = total

        def pandas(self, deprecated_t):
            pass

    tt = TqdmTest(total=100)
    tqdm_pandas(tt)

# Generated at 2022-06-24 09:44:25.127373
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm)

    def f(df):
        # increase reference count of df
        df['col2'] = df.col1 * 2

    DataFrame({'col1': [1, 2, 3]}).groupby(
        'col1').progress_apply(f)
    tqdm.pandas(total=3)
    DataFrame({'col1': [1, 2, 3]}).groupby(
        'col1').progress_apply(f)

# Generated at 2022-06-24 09:44:35.357589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm

    def func(df):
        return np.log(df.x**2)

    df = pd.DataFrame({'x': range(100)})
    with tqdm.utils.disable_deprecation_warnings():
        assert df.groupby(df.x % 2).progress_apply(func) is df.groupby(df.x % 2).apply(func)

    with tqdm.tqdm_pandas(tqdm.tqdm, leave=False) as tclass:
        assert df.groupby(df.x % 2).progress_apply(func) is df.groupby(df.x % 2).apply(func)
        assert tclass._instances


# Generated at 2022-06-24 09:44:39.232217
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd, tqdm
    df = pd.DataFrame({'a': list(range(20))})
    tqdm_pandas(tqdm.tqdm)
    assert all(df.groupby('a').progress_apply(lambda x: x)['a'] == df['a'])
    tqdm_pandas(type=tqdm.tqdm)
    assert all(df.groupby('a').progress_apply(lambda x: x)['a'] == df['a'])
    tqdm_pandas(tqdm.tqdm(unit='B'))
    assert all(df.groupby('a').progress_apply(lambda x: x)['a'] == df['a'])



# Generated at 2022-06-24 09:44:47.636792
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.pandas import tqdm_pandas   # import tqdm_pandas
    import pandas as pd

    df_range = pd.DataFrame({'comb1': [1, 2, 3, 4],
                             'comb2': [9, 10, 11, 12],
                             'comb3': [17, 18, 19, 20]})

    df_range['comb4'] = df_range.progress_apply(
        lambda x: x['comb1'] + x['comb2'], axis=1)
    # assert df_range.iloc[3, 3] == 16
    assert df_range.iloc[3, 3] == 16



# Generated at 2022-06-24 09:44:52.254206
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({"A": [], "B": []})
    try:
        with tqdm.tqdm_pandas(df):
            pass
    except:
        tqdm.tqdm_pandas(tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:00.566448
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame([{'foo': 0}, {'foo': 1}, {'foo': 2}])

    def square_it(x):
        return x * x

    for i in (tqdm_pandas, tqdm_pandas.pandas):
        df_result = df.groupby('foo').progress_apply(
            square_it)
        if i != tqdm_pandas.pandas:
            assert df_result.index.tolist() == [0, 1, 2]
        else:
            assert df_result.index.tolist() == [0.0, 1.0, 2.0]
        assert df_result.tolist() == [0, 1, 4]


# # ---> register tqdm with

# Generated at 2022-06-24 09:45:06.613740
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas

    df = pd.DataFrame(data={'a': [1, 2, 4, 8]})
    df['b'] = df.a.progress_apply(lambda x: x ** 2)
    df['c'] = df.b.apply(lambda x: x ** 2)
    df.head()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:13.626629
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit tests for function `tqdm_pandas`."""
    import pandas as pd
    from pandas.testing import assert_frame_equal
    from tqdm.contrib.test_tqdm_pandas import test_df_copy

    progress_df = test_df_copy.copy()
    progress_df['c'] = progress_df.progress_apply(
        lambda x: x['a'] + x['b'], axis=1)
    assert_frame_equal(progress_df, test_progress_df)

    # nested pandas
    tqdm_pandas(test_df_copy.groupby('a').progress_apply(lambda x: x['b']))

    # nested apply

# Generated at 2022-06-24 09:45:20.461505
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas
    tqdm_pandas(tqdm)
    df = pd.DataFrame({'A': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                       'B': [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]})
    df.groupby('A').progress_apply(lambda x: x)


# Generated at 2022-06-24 09:45:27.380489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Tests for tqdm_pandas """
    from tqdm import tqdm

    # Check legacy approach
    tclass = tqdm(total=100)
    tqdm_pandas(tclass)
    assert True

    # Check decorator approach
    @tqdm
    def x():
        return

    tqdm_pandas(x)
    assert True

    # Check verbose
    tqdm_pandas(x, verbose=1)
    assert True


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:33.915429
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pytest import raises
    from tqdm import tqdm

    # Test that tqdm raises an exception when passed an iterator
    with raises(AssertionError):
        tqdm_pandas(iter(range(10)))

    # Test that tqdm raises an exception when passed a tqdm instance
    with raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm(range(10)))

    # Test that tqdm raises an exception when passed a tqdm instance
    with raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)

    # Test that tqdm raises no exception when passed a tqdm class

# Generated at 2022-06-24 09:45:41.721023
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    t = tqdm.tqdm(total=100)
    t.close()
    assert not t._instances

    t = tqdm.tqdm(total=100)
    tqdm_pandas(t)
    t.close()
    assert not t._instances

    tqdm_pandas(tqdm)
    t = tqdm.tqdm(total=100)
    t.close()
    assert not t._instances


if __name__ == "__main__":
    test_tqdm_pandas()