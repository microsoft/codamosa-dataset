

# Generated at 2022-06-24 09:35:46.631849
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.utils import _term_move_up
    from tqdm import trange
    from tqdm.contrib.tests import discretize


# Generated at 2022-06-24 09:35:51.637425
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from pandas.util.testing import assert_series_equal
    from numpy.random import random
    from numpy import isnan

    s = Series(random(10))
    a = s.groupby(s.rank()).progress_apply(lambda x: x ** 2).reset_index(drop=True)
    b = s ** 2
    assert_series_equal(a, b)  # random seed may fail


# Generated at 2022-06-24 09:35:55.101824
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from numpy.random import rand

    N = 100
    df = pd.DataFrame(rand(N, 3))
    df.progress_apply(lambda x: x**2)

    with tqdm(_range(10)) as t:
        for i in t:
            df.progress_apply(lambda x, i=i: x**i)


if __name__ == '__main__':
    from tqdm import tqdm
    test_tqdm_pandas()

# Generated at 2022-06-24 09:35:58.496326
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import pandas as pd
    import numpy as np
    with tqdm(total=10, file=sys.stdout) as pbar:
        pd.DataFrame({'a': [np.nan] * 10, 'b': [np.nan] * 10}).groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:36:08.735119
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    t = tqdm(range(4), desc=__name__, ascii=True)
    t.pandas()
    assert hasattr(t, 'pandas')

    # check old API
    t2 = tqdm(range(4), desc=__name__, ascii=True)
    tqdm_pandas(t2)
    assert hasattr(t, 'pandas')

    # check delayed adapter
    t3 = tqdm(range(4), desc=__name__, ascii=True)
    tqdm_pandas(tqdm, desc=__name__)
    assert hasattr(t3, 'pandas')


# Set tqdm pandas callback
tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:36:18.600901
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if hasattr(pd, 'set_option'):
        # Alias for pytest file output
        from tqdm import trange
        from tqdm.auto import tqdm
        from typing import Generator, Generator

        try:
            bar = tqdm(range(10))
        except:
            tqdm = trange

        # Cannot inline `tqdm` because it would raise a DeprecationWarning
        @tqdm_pandas(tqdm)
        def identity(x):
            yield x

        assert type(identity(pd.Series(list(range(10))))) == pd.core.series.Series

        @tqdm_pandas
        def identity(x):
            return x


# Generated at 2022-06-24 09:36:23.322969
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    # Create a test DataFrame
    df = pd.DataFrame(zip(range(1000), range(1000)), columns=['A', 'B'])

    # Test the basic usage of tqdm_pandas
    df.groupby('A').progress_apply(lambda x: None)

    # Test the basic usage of tqdm_pandas
    df.progress_apply(lambda x: None)

    # Test the basic usage of tqdm_pandas
    pd.concat([df, df]).progress_apply(lambda x: None)

    # Test the basic usage of tqdm_pandas
    df.apply(lambda x: None)



# Generated at 2022-06-24 09:36:30.636228
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib.tests import tclass
    from tqdm._tqdm import tqdm

    tqdm.pandas(tclass)

    df = pd.DataFrame({'text': np.random.randint(100, size=100000)})
    for _ in tqdm(df.groupby('text').progress_apply(len), total=100000):
        pass


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-24 09:36:39.754920
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        with tqdm_pandas(tqdm(ncols=30, mininterval=0.5)):
            import random
            import pandas as pd
            import numpy as np

            NUM_ROWS = int(1e6)
            args = {'col_%d' % i: np.random.randn(NUM_ROWS) for i in range(5)}
            args['col_large'] = np.random.randn(NUM_ROWS * 10)
            df = pd.DataFrame(args)
            df.groupby('col_0').progress_apply(lambda x: x[::-1])
        assert True
    except:
        assert False

# Generated at 2022-06-24 09:36:47.552481
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm import tqdm

    assert hasattr(tqdm, 'pandas')
    tqdm_pandas(tqdm)

    df = pd.DataFrame({'a': [1, 2, 3, 4], 'b': [1, 2, 3, 4]})

    for _ in df.groupby('a').progress_apply(lambda x: x):
        pass

    for _ in df.groupby('a').progress_apply(lambda x: x):
        pass


if __name__ == "__main__":
    r = test_tqdm_pandas()

# Generated at 2022-06-24 09:36:52.602457
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from random import randint
    from tqdm import trange

    # Create a pandas dataframe
    df = pd.DataFrame({'Animal': ['Falcon', 'Falcon',
                                  'Parrot', 'Parrot'],
                       'Max Speed': [380., 370., 24., 26.]})
    # Create a pandas groupby object
    group_obj = df.groupby(['Animal'])
    # Create a progress bar with trange
    for i in trange(5, desc='1st loop'):
        # Calculate the mean of each group
        for animal, animal_df in tqdm_pandas(group_obj):
            result = animal_df['Max Speed'].mean()
            assert isinstance(result, float)



# Generated at 2022-06-24 09:36:56.484489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random

    df = DataFrame(random.randint(0, 100, (100000, 6)))
    try:
        df.groupby(0).progress_apply(lambda x: x**2)
    except AttributeError:
        # AttributeError in pandas 0.18.0 / python 3.5.1:
        # https://github.com/noamraph/tqdm/issues/468
        pass

# Generated at 2022-06-24 09:37:07.905448
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from datetime import datetime
    from pandas import DataFrame
    from tqdm import tqdm
    from tqdm import tnrange

    # Setup
    t = tnrange(10)
    # Test for tnrange
    tqdm_pandas(t)
    assert t.unit_name == "it"

    # Setup
    t = tnrange(10, 10, desc="my bar!", unit="foo")
    # Test for tnrange
    tqdm_pandas(t)
    assert t.unit_name == "foo"

    # Setup

# Generated at 2022-06-24 09:37:11.360832
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    # test tqdm function
    tqdm_pandas(tqdm)

    # test tqdm class
    tqdm_pandas(type(tqdm()))

# Generated at 2022-06-24 09:37:18.971630
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return

    # test adapter
    try:
        import pandas_tdm
    except ImportError:
        pass
    else:
        if pandas_tdm.__name__.startswith('tqdm.'):
            # tqdm_notebook is imported before tqdm_pandas (see package-exclude)
            warnings.warn(TqdmDeprecationWarning(
                "`import tqdm_notebook, import tqdm_pandas` is no longer supported. "
                "Please use `from tqdm.contrib import pandas` with IPython / Jupyter.",
                fp_write=sys.stderr.write))
        return

    # Test pandas.Series.

# Generated at 2022-06-24 09:37:28.987348
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm, trange
    import numpy as np
    # Test progress_apply with not nested index
    df = pd.DataFrame(np.random.randn(100, 100), columns=list('abcdefghij'))
    with tqdm(total=len(df)) as pbar:
        def apply_func(x):
            pbar.update()
            return x
        df.progress_apply(apply_func)
    # Test apply with nested index
    df = pd.DataFrame(np.random.randn(100, 100), columns=list('abcdefghij'))
    with tqdm(total=len(df), ascii=True) as pbar:
        def apply_func(x):
            pbar.update()


# Generated at 2022-06-24 09:37:39.109118
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        import tqdm.auto as tqdm

        df = pd.DataFrame({'x': np.random.randn(10000)})
        with tqdm.tqdm(total=len(df)) as progress_bar:
            # register the progress_bar with pandas
            tqdm.pandas(progress_bar)
            # now you can use progress_apply instead of apply
            df.progress_apply(lambda x: x)
    except Exception as e:
        tqdm.tqdm.write(str(e), file=sys.stderr)
        raise

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:44.111418
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    df = pandas.DataFrame({'x': range(10000),
                           'y': [float(i) ** 0.5 for i in range(10000)]})
    for cls in [tqdm, tqdm_gui]:
        cls.pandas(desc="test_tqdm_pandas")(df.groupby)('x').progress_apply(
            lambda g: g.y.sum())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:53.485911
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import gc
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return
    from tqdm.auto import trange
    from tqdm import tqdm
    from tqdm.contrib import DummyTqdmFile, DummyTqdmFileObj

    # Obtain a DataFrame and a series
    df = pd.DataFrame(np.random.rand(200, 2))
    s = df[0]

    f = DummyTqdmFileObj(sys.stdout)
    tqdm_pandas(tqdm(file=f))

    with tqdm(total=len(df), file=f) as t:
        def progress_f(*args, **kwargs):
            t.update()
            return gc.collect()


# Generated at 2022-06-24 09:38:04.628933
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Tests for `tqdm_pandas`.
    '''
    from tqdm import trange
    tr = trange(5)
    try:
        tqdm_pandas(tr)
    except DeprecationWarning as e:
        assert str(e) == "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm(...))`."
    tqdm_pandas(trange, file=tr.fp)
    try:
        tqdm_pandas(trange, file=tr.fp)
    except DeprecationWarning as e:
        assert str(e) == "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`."



# Generated at 2022-06-24 09:38:14.091893
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from io import StringIO
    from pandas import DataFrame
    from tqdm import tqdm, tqdm_pandas

    df = DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})

    # test using tqdm class directly
    for _ in tqdm_pandas(tqdm, total=len(df)):
        pass

    # test using tqdm generator
    for _ in tqdm_pandas(tqdm(total=len(df))):
        pass

    # test passing arguments to tqdm
    with StringIO() as buf:
        # test using tqdm class directly
        for _ in tqdm_pandas(tqdm, total=len(df), file=buf):
            pass
        assert buf.getvalue

# Generated at 2022-06-24 09:38:23.211335
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Arrange
    if sys.version_info >= (3, 0):
        from io import StringIO
        s = StringIO()
    else:
        from StringIO import StringIO
        s = StringIO()

    pandas_kwargs = {"df": pd.DataFrame([{"a": 1}] * 100),
                     "progress_bar": True}

    # Act
    tqdm_pandas(tqdm(total=100, file=s, miniters=1))
    pd.DataFrame.groupby.progress_apply(**pandas_kwargs)

    # Assert
    assert True


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:27.485899
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    pd.DataFrame(
        {'a': list(range(100)), 'b': list(range(100)), 'c': list(range(100))}
    ).groupby(['b']).progress_apply(lambda x: sum(x))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:38.037196
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    from tqdm._utils import _term_move_up

    tqdm_pandas(tqdm)

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)), columns=list('ABCDEF'))
    # We MUST call `progress_apply` instead of `apply`
    # in order to leave one line for displaying the progress bar
    # (instead of filling the whole screen with output).
    df.groupby(0).progress_apply(lambda x: x**2)

    # The progress bar remains there,
    # but it is empty and can be removed with the following:
    _term_move_up()

# Generated at 2022-06-24 09:38:48.381331
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests that tqdm_pandas uses the latest tqdm.pandas interface.
    """
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')

        import tqdm
        import pandas as pd
        import numpy as np

        # Test tqdm_pandas with custom kwargs (no 'tqdm_class' argument)
        tqdm_kwargs = {'total': 100}
        tqdm_pandas(tqdm.tqdm, **tqdm_kwargs)
        assert issubclass(pd.core.groupby.DataFrameGroupBy.progress_apply.tqdm, tqdm.tqdm)
        assert pd.core.groupby.DataFrameGroupBy.progress_apply.t

# Generated at 2022-06-24 09:38:59.748955
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    assert sys.version_info.major == 3
    assert pd.__version__ >= '0.17.0'
    from tqdm import tqdm

    # default tqdm progress bar
    with tqdm(total=1) as t:
        df = pd.DataFrame()
        df['A'] = [1, 2, 3, 4]
        df['B'] = [5, 6, 7, 8]
        df['C'] = [4, 3, 2, 1]
        df.groupby('A').progress_apply(lambda x: x * 2)
        t.update(1)

    # default tqdm progress bar after reset
    with tqdm(total=1) as t:
        df = pd.DataFrame()

# Generated at 2022-06-24 09:39:05.261497
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    df = DataFrame([1, 2, 3, 4, 5, 6])
    tqdm_pandas(tqdm, df.groupby(0).apply(lambda _: _))
    tqdm_pandas(tqdm(df.groupby(0).apply(lambda _: _)))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:15.897957
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # No Side-Effects
    try:
        import tqdm._tqdm as tqdm
        tqdm.pandas
    except AttributeError:
        return
    # No-op case
    tqdm.pandas()
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, ncols=42, mininterval=0.1)
    # Deprecated cases
    tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm.tqdm, ncols=42, mininterval=0.1)
    # Adapter cases

# Generated at 2022-06-24 09:39:25.695630
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # Make sure tqdm_pandas registers the right function
    old_func = pd.core.groupby.DataFrameGroupBy.progress_apply
    import tqdm.pandas
    tqdm.pandas.tqdm_pandas(unit_scale=True)
    assert pd.core.groupby.DataFrameGroupBy.progress_apply != old_func

    # Make sure tqdm_pandas doesn't break if it's called again on the same tqdm instance
    old_func = pd.core.groupby.DataFrameGroupBy.progress_apply
    tqdm.pandas.tqdm_pandas(unit_scale=True)
    assert pd.core.groupby.DataFrameGroupBy.progress_apply == old_func



# Generated at 2022-06-24 09:39:35.701364
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    from .tests_tqdm import with_propagation_disabled
    from .utils import FormatCustomText, is_master_process
    from multiprocessing.pool import Pool
    if not is_master_process():
        return

    with tqdm.tqdm(total=42) as t:
        t.set_description('testtqd')
        t.set_postfix({'lol': 1})
        tqdm_pandas(t)
        with tqdm.tqdm(total=42) as t2:
            t2.set_description('testtqd')
            t2.set_postfix({'lol': 1})
            tqdm_pandas(t2)


# Generated at 2022-06-24 09:39:41.943026
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    import numpy as np
    from tqdm._utils import _term_move_up

    df = pd.DataFrame({'animal': ['falcon', 'dog', 'spider',
                                  'fish', 'cat', 'falcon']})
    tqdm_pandas(tqdm)
    try:
        df.groupby('animal').progress_apply(lambda x: x)
        assert False
    except TypeError as e:
        assert 'progress_apply' in str(e)
        tqdm_pandas(tqdm())
        df.groupby('animal').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:39:50.097165
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""

# Generated at 2022-06-24 09:40:00.763492
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas """
    import tqdm.auto as tqdm
    # Test pandas not installed
    try:
        import pandas
        del pandas
    except ImportError:
        try:
            # Test pandas mode
            tqdm_pandas(tqdm)
        except ImportError:
            pass
        else:
            raise Exception("Error: pandas should not be available")

    # Test pandas installed
    try:
        import pandas
    except ImportError:
        raise Exception("Error: pandas should be available")
    else:
        # Test pandas mode
        try:
            tqdm_pandas(tqdm)
        except Exception:
            raise Exception("Error: pandas should be available")



# Generated at 2022-06-24 09:40:10.150876
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    pd = __import__('pandas')
    if pd is not None:
        from pandas import DataFrame

        tqdm_pandas(tqdm.tqdm)
        df = DataFrame({'a': [1, 1, 2],
                        'b': [1, 2, 3]}, columns=['a', 'b'])
        assert list(df.groupby('a').progress_apply(lambda g: g)) == [
            (1, DataFrame({'b': [1, 2]}, index=[0, 1])),
            (2, DataFrame({'b': [3]}, index=[2]))
        ]

# Generated at 2022-06-24 09:40:16.655161
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.utils import _range
    for n in _range(5):
        df = pd.DataFrame({'x': [1, 2, 3] * 1000})
        tclass = tqdm(df.x, nested=True)
        tqdm_pandas(tclass, nested=True)
        for _ in df.x.progress_apply(lambda x: x):
            pass
        tqdm_pandas(tqdm)
        for _ in df.x.progress_apply(lambda x: x):
            pass
        tqdm_pandas(tclass)
        for _ in df.x.progress_apply(lambda x: x):
            pass
        tqdm_pandas(tqdm())

# Generated at 2022-06-24 09:40:25.937569
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import TestCase, pretest_posttest, SkipTest
    from tqdm.auto import tqdm
    from tqdm.contrib.tests import pandas, _range

    def tqdm_pandas_mock(t, **kwargs):
        return t.copy()

    tqdm_orig = tqdm_pandas


# Generated at 2022-06-24 09:40:35.390662
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from tqdm.contrib import pandas as tqdm_pandas
    try:
        import pandas as pd
    except ImportError:
        return
    N_TESTS, N_TESTS_CONTRIB = 20, 3
    range_tup = (range(N_TESTS), range(N_TESTS_CONTRIB))
    if hasattr(tqdm_pandas.tqdm, 'pandas'):
        tqdm_pandas.tqdm.pandas(tqdm_pandas.tqdm(*range_tup))
        tqdm_pandas.tqdm.pandas(tqdm_pandas.tqdm)
    tqdm_

# Generated at 2022-06-24 09:40:42.685931
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd, tqdm
    # Setup
    tqdm_pandas(tqdm, smoothing=0)
    assert tqdm.tqdm.default_mininterval == 0

    # Tests
    df = pd.DataFrame({"x": [1, 2, 3]})
    with tqdm.tqdm(total=len(df), smoothing=0) as progress:
        df.groupby("x").progress_apply(lambda df: None, meta=('x', 'f8'))
        assert progress.n == len(df)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:49.861942
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import numpy as np
    import pandas as pd
    from pandas.util.testing import assert_series_equal
    from tqdm import tqdm_notebook
    import warnings

    def dummy_progress(*a, **kw):
        """Dummy function, to detect DataFrameGroupBy.progress_apply"""
        return True

    def sum_sq(x):
        """Dummy function, to sum and square entries"""
        return np.sum(x) ** 2

    N = 10
    np.random.seed(0)
    df = pd.DataFrame({'key': np.random.randint(0, N / 2, size=N),
                       'val': np.random.randn(N)})
    df_sum_sq = df.group

# Generated at 2022-06-24 09:40:59.154276
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm.autonotebook import tqdm
    from tqdm.utils import _range

    tqdm.pandas()
    df = pd.DataFrame({'x': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]})
    try:
        __import__('dask.dataframe')
    except ImportError:
        pass
    else:
        ddf = df.sample(100000).pipe(lambda df: df[:].compute())
        ddf.groupby('x').x.progress_apply(lambda x: x)
    df.groupby('x').x.progress_apply(lambda x: x)

# Generated at 2022-06-24 09:41:08.476299
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas

    df = pd.DataFrame({'a': np.random.randint(0, 100, (10000,))})
    tqdm_pandas(tqdm(total=len(df)))
    df.groupby('a').progress_apply(lambda x: x ** 2)
    # raise tqdm_deprecation_warning


if __name__ == '__main__':
    test_tqdm_pandas()


# for gb in pd.read_csv(THIS_DIR + '/../data/test-sets.csv', chunksize=10000,
#                       names=['id', 'set'], skiprows=1):

# Generated at 2022-06-24 09:41:09.746442
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm())


# Main function

# Generated at 2022-06-24 09:41:18.320549
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_notebook, tqdm_gui
    from tqdm.std import tqdm
    from time import sleep

    for i in tqdm_pandas(tqdm([1, 2, 3, 4, 5], desc="123")):
        sleep(.25)
    for i in tqdm_pandas(tqdm_notebook([1, 2, 3, 4, 5], desc="123"), gui=True):
        sleep(.25)
    for i in tqdm_pandas(tqdm_gui([1, 2, 3, 4, 5], desc="123")):
        sleep(.25)



# Generated at 2022-06-24 09:41:22.423204
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import numpy as np
        import pandas as pd
    except ImportError:
        return
    df = pd.DataFrame({'a': np.linspace(0, 1e5, 1e5)})
    tqdm_pandas(tqdm(df), total=len(df))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:31.380456
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    def test_func(x):
        import time
        time.sleep(.01)
        return x

    # Test if pandas API is available
    if not hasattr(pd, 'DataFrame'):
        return

    # Test if pandas API is working
    df = pd.DataFrame([1, 2, 3], columns=['a'])
    res = df.groupby('a').progress_apply(test_func)
    assert (res == df).all().all()

    # Test deprecated API
    df = pd.DataFrame([1, 2, 3], columns=['a'])
    res = df.groupby('a').progress_apply(test_func)
    assert (res == df).all().all()

    # Test deprecated API with tqdm instance

# Generated at 2022-06-24 09:41:42.606138
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    try:
        import pandas_dataframe
        from pandas_dataframe import dtypes
        from pandas_dataframe.groupby import DataFrameGroupBy
        from pandas_dataframe.series import Series
        from pandas_dataframe.generic import NDFrame
    except ImportError:
        print("Skipping tqdm_pandas test with pandas_dataframe")
        return

    n = 10
    df = pd.DataFrame({
        'a': np.random.randn(n),
        'b': np.random.randint(0, 100, size=n),
        'c': np.random.randint(0, 1000, size=n),
    })
    assert isinstance(df, NDFrame)

    tqdm_p

# Generated at 2022-06-24 09:41:47.188784
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(0, index=range(10),
                      columns=list('abcdefghijklmnopqrstuvwxyz'))
    tqdm_pandas(tqdm(total=df.shape[0]))

    tqdm_pandas(tqdm(total=df.shape[0]), desc='bar')

    tqdm_pandas(tqdm(), desc='bar')
    df.progress_apply(lambda x: x ** 2)

    tqdm_pandas(tqdm(), desc='bar')
    df.groupby('a').progress_apply(lambda x: x ** 2)

    tqdm_pandas(tqdm(), desc='bar')

# Generated at 2022-06-24 09:41:55.099449
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def test_pandas_desc(cls, **kwargs):
        try:
            import pandas
            return pandas
        except:
            return False

    def test_pandas_desc2(cls, **kwargs):
        try:
            from pandas import DataFrame
            tqdm_pandas(cls)
            series = pandas.Series(range(1000))
            series.progress_map(lambda x: x)
            series.progress_apply(lambda x: x)
            DataFrame(list(range(100)),
                      columns=['A']).progress_apply(lambda x: x, axis=1)
            return True
        except:
            return False

    assert test_pandas_desc2(tqdm(desc="test"))

# Generated at 2022-06-24 09:41:57.652805
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm
    tqdm.pandas(tqdm)
    df = pd.DataFrame(np.random.random(size=(10**6, 10**1)))
    df.groupby(df.index // 10).progress_apply(lambda x: x**2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:04.977140
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame({
        'amount': np.random.randint(1, 20, (10, )),
        'price': np.random.random((10, ))
    })
    tqdm_pandas(tqdm)
    grpby = df.groupby('amount').progress_apply(
        lambda x: x['price'].mean()
    )


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:13.224393
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm import tqdm

    print(pd.__version__)
    df = pd.DataFrame({'a': list(range(10))})
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas(tqdm,
                                                                  unit='row',
                                                                  leave=True).__call__
    df.groupby('a').progress_apply(lambda x: x.sum())

    # Test that tqdm is delayed until pandas' apply is called
    result = []

    class MockTqdm:
        def __init__(self):
            raise AssertionError("tqdm should not be called too early")


# Generated at 2022-06-24 09:42:14.376097
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    tqdm.tqdm_pandas()

# Generated at 2022-06-24 09:42:21.499109
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    from tqdm import trange

    def dummy_func(df):
        """
        Adds new column "dummy" to df with random numbers
        """
        df["dummy"] = np.random.rand(len(df))

    df = pd.DataFrame({"A": ["a", "b", "c", "d", "e"]})
    tqdm_pandas(tqdm(total=len(df), desc="Progress"))
    df.groupby("A").progress_apply(dummy_func)
    assert "dummy" in df

    tqdm_pandas(tqdm)
    df.groupby("A").progress_apply(dummy_func)
    assert "dummy"

# Generated at 2022-06-24 09:42:31.229592
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    # Create dataframe with a column of random numbers
    df = pd.DataFrame({'x': np.random.normal(size=100)})
    # Run tqdm on it
    res = df.groupby(['x']).progress_apply(np.mean)
    assert isinstance(res, pd.DataFrame)
    # Run tqdm on it (via function)
    res = tqdm_pandas(tqdm)(df.groupby(['x'])).progress_apply(np.mean)
    assert isinstance(res, pd.DataFrame)

# Generated at 2022-06-24 09:42:39.222231
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    assert hasattr(tqdm, 'pandas')
    import pandas as pd
    import numpy as np
    d = {'x': np.random.normal(size=1000000)}
    df = pd.DataFrame(d)
    o = 0.
    for x in tqdm(df.groupby('x').progress_apply(lambda x: o)):
        pass
    assert x > 0


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:48.947215
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    import pandas as pd
    import numpy as np
    n = 10000000
    df = pd.DataFrame({
        'a': np.random.randn(n),
        'b': np.random.randn(n)
    })
    tqdm_pandas(tqdm(), desc='Testing tqdm_pandas', leave=False)(
        df.groupby(['a']).progress_apply(lambda x: x + 1))
    tqdm_pandas(tqdm_notebook(), desc='Testing tqdm_pandas', leave=False)(
        df.groupby(['a']).progress_apply(lambda x: x + 1))



# Generated at 2022-06-24 09:43:00.016064
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd 
        import numpy as np
        import collections
        import itertools
        import random
        import sys
        import warnings
    except ImportError as e:
        sys.exit('Please install `Pandas` before running the unit test.\n'
                 '$ pip install pandas\n'
                 '$ python -m unittest tqdm.tests.test_tqdm_pandas')

    n = 1000000
    random.seed(0)
    df = pd.DataFrame({'a': list(np.random.random(n))})
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        c = df.groupby(df.a // 0.1).progress_apply(lambda x: x)

    assert len(c) == n

# Generated at 2022-06-24 09:43:06.386370
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas

    df_test = pd.DataFrame({"x": [0, 1, 2, 3, 4],
                            "y": [5, 6, 7, 8, 9]})
    res = df_test.groupby("x").progress_apply(lambda x: 2 * x)

    assert res.tolist() == [x * 2 for x in range(5)]

# Generated at 2022-06-24 09:43:16.935986
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import pandas.util.testing as pdt

    df = pdt.makeDataFrame()
    pd.set_option('mode.chained_assignment', None)
    df["A"][0] = 100
    assert not df["A"].equals(df.groupby('C').progress_apply(lambda x: x))

    # Show that the progress_apply won't work with a normal decorator.
    assert not df["A"].equals(df.groupby('C').apply(tqdm(lambda x: x)))

    # But will work with tqdm_pandas
    assert df["A"].equals(df.groupby('C').progress_apply(tqdm(lambda x: x)))

if __name__ == "__main__":
    test_tq

# Generated at 2022-06-24 09:43:24.189557
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # check that raises Exception on tqdm instead of tqdm_notebook
    try:
        tqdm_pandas(tqdm.tqdm)
    except tqdm.TqdmDeprecationWarning:
        pass
    else:
        raise AssertionError("should have raised TqdmDeprecationWarning")

    # check that raises Exception on tqdm.tqdm instead of tqdm_notebook.tqdm
    try:
        tqdm_pandas(tqdm)
    except tqdm.TqdmDeprecationWarning:
        pass
    else:
        raise AssertionError("should have raised TqdmDeprecationWarning")

    # check that don't raises Exception on tqdm_notebook

# Generated at 2022-06-24 09:43:34.568440
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    _pandas = sys.modules['pandas']
    _groupby = sys.modules['pandas.core.groupby.DataFrameGroupBy']

    _registered = False
    for f in _groupby.progress_apply._signature:
        if f.__name__ == 'tqdm':
            _registered = True
    assert not _registered

    tqdm_pandas(tqdm)

    _registered = False
    for f in _groupby.progress_apply._signature:
        if f.__name__ == 'tqdm':
            _registered = True
    assert _registered

    tqdm_pandas(tqdm)

    _registered = False

# Generated at 2022-06-24 09:43:41.220256
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def my_func():
        pass

    kwargs_ = {'total': 100, 'file': None, 'mininterval': 0.1}

    # tqdm is a function
    def tqdm(*a, **kw):
        return my_func

    tqdm_pandas(tqdm, **kwargs_)
    assert pd.DataFrame([]).progress_apply.t_kwargs == kwargs_
    assert pd.Series([]).progress_apply.t_kwargs == kwargs_
    assert pd.Series([]).progress_map.t_kwargs == kwargs_
    assert pd.DataFrame([]).progress_apply.t_func == my_func
    assert pd.Series([]).progress_apply.t_func

# Generated at 2022-06-24 09:43:48.546135
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit tests for tqdm_pandas()
    """
    import pandas as pd
    from tqdm import tqdm

    tqdm_pandas(tqdm, mininterval=0.1)
    df = pd.DataFrame([dict(year=i, month=i + 1) for i in range(10)])
    # simple apply
    df.groupby('year').progress_apply(lambda x: x)
    # .agg()
    df.groupby('year').progress_apply('mean')

# Generated at 2022-06-24 09:43:53.202058
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    from pandas import DataFrame
    tqdm_pandas(tqdm)
    df = DataFrame([(x, x + 1) for x in range(4)], columns=['A', 'B'])
    assert df.groupby('A').progress_apply(lambda x: x) is not None

# Generated at 2022-06-24 09:43:58.499370
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    with tqdm.tqdm_pandas() as t:
        pd.DataFrame({'a': range(100)})['a'].progress_apply(lambda x: x**2)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:07.289450
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm._utils import _supports_unicode
    from tqdm import tqdm

    tqdm_pandas(tqdm)

    test_df = DataFrame([1, 2, 3, 4, 5])
    res = test_df.groupby(by=[1, 2, 3, 4, 5]).progress_apply(lambda x: x)
    assert res.equals(test_df)
    assert 'Pandas' in tqdm.format_dict

    test_df.progress_apply(lambda x: None)
    tqdm.pandas(desc="Test tqdm_pandas", leave=True)
    test_df.progress_apply(lambda x: None)
    tp = tqdm(total=0)
    tqdm_p

# Generated at 2022-06-24 09:44:08.498486
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)


# Define DataFrameGroupBy.progress_apply()

# Generated at 2022-06-24 09:44:15.536502
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm
    from numpy.random import rand
    from random import randint

    # Registering the tqdm instance
    tqdm_pandas(tqdm(desc="Pandas Progress"))

    # Generating DataFrame
    df = pd.DataFrame()
    df['col1'] = [randint(1, 100) for x in range(10)]
    df['col2'] = [randint(1, 100) for x in range(10)]

    # Example of progress_apply methods
    df['col3'] = df.progress_apply(lambda x: x['col1'] * x['col2'], axis=1)

# Generated at 2022-06-24 09:44:24.535596
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    import tqdm
    _deprecated_pandas_error = None

    def deprecated_pandas(*args, **kwargs):
        global _deprecated_pandas_error
        _deprecated_pandas_error = args + tuple(kwargs.values())

    def _test_tqdm_pandas(tqdm_kwargs):
        if 'pandas' in tqdm_kwargs:
            del tqdm_kwargs['pandas']
        tqdm_kwargs.setdefault('file', tqdm.sys.stderr)
        # TqdmDeprecationWarning should be printed after function returns
        global _deprecated_pandas_error

# Generated at 2022-06-24 09:44:34.520936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from .std import tqdm

    # Test 1: Make sure the decorator registers itself
    try:
        from pandas.core.groupby import DataFrameGroupBy
    except Exception:
        pass

# Generated at 2022-06-24 09:44:44.488359
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests function `tqdm_pandas`.
    """
    import pandas as pd

    # Create a dummy dataframe with two columns
    df = pd.DataFrame({'a': [1, 2], 'b': [3, 4]})

    # Test progress bar
    from tqdm import tqdm
    tqdm_pandas(tqdm, unit='row')
    for el in df.groupby('a').progress_apply(lambda x: x):
        pass
    for el in tqdm(df.groupby('a').progress_apply(lambda x: x), unit='row'):
        pass
    for el in tqdm_pandas(tqdm, unit='row')(df.groupby('a').progress_apply(lambda x: x)):
        pass

   

# Generated at 2022-06-24 09:44:50.515766
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from random import sample

    def f():
        return [sample(range(100), 3) for i in range(100)]

    df = DataFrame(f())
    df = df.groupby(0).progress_apply(sum)

    tqdm_pandas(tqdm, leave=False)
    df2 = df.groupby(0).progress_apply(sum)

    assert df.equals(df2), "groupby failed with progress_apply"
    if __name__ == '__main__':
        print("Success")

# Generated at 2022-06-24 09:44:59.326388
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm.tqdm, total=100)


if __name__ == '__main__':
    from tqdm._utils import _term_move_up
    import pandas as pd
    import numpy as np
    from pandas.util import testing as pdt

    with tqdm.tqdm() as pbar:
        for i in range(4):
            pbar.write('abcd')
            _term_move_up()
            time.sleep(0.1)
        pbar.close()
    print()

    tqdm.tqdm.pandas()
    pdt.N = 100
    df_ = pd.DataFrame(np.random.randint(0, 100, (100, 6)))

# Generated at 2022-06-24 09:45:08.432368
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas """
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas  # tqdm_notebook
    # tqdm_pandas(tqdm)  # can use `tqdm.pandas` instead
    df = pd.DataFrame({'A': np.random.randint(0, 100, size=100)})
    df.groupby('A').progress_apply(lambda x: x**2)  # can use `progress_map` instead
    # NOTE: `tqdm_notebook` can be used by changing `tqdm` to `tqdm_notebook` here.
    # tqdm_pandas(tqdm_notebook)  # can use

# Generated at 2022-06-24 09:45:14.499354
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd

    n = 100
    df = pd.DataFrame({
        'int': [n] * n,
        'float': [n / 2] * n,
        'str': [str(n) for _ in range(n)],
    })
    assert isinstance(tqdm_pandas(tqdm), None)
    # assert isinstance(tqdm_pandas(tqdm, desc='test'), None)
    # assert isinstance(tqdm_pandas(tqdm(desc='test')), None)
    # assert isinstance(tqdm_pandas(tqdm), None)
    # assert isinstance(tqdm_pandas(tqdm(desc='test')), None

# Generated at 2022-06-24 09:45:24.433225
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import pandas.core.groupby
    if sys.version_info[0] >= 3:
        import pandas.core.groupby as pandas_core_groupby
        if not hasattr(pandas_core_groupby, '__dict__'):
            # python3.3 has no __dict__ in pandas.core.groupby
            return
    progress_apply = pandas.core.groupby.DataFrameGroupBy.progress_apply
    assert 'tqdm' not in progress_apply.__dict__

    from tqdm.contrib import pandas
    assert hasattr(progress_apply, 'tqdm')
    assert progress_apply.__dict__['tqdm'] is pandas

# Generated at 2022-06-24 09:45:32.784600
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import terminaltables
    except ImportError:
        return
    from tqdm._utils import _term_move_up

    def print_progress(t, n):
        table = terminaltables.AsciiTable([["Progress", t]])
        t.fp.write(_term_move_up() + table.table)

    def test_dummy1():
        t = tqdm_pandas(tqdm(total=10))
        df = pd.DataFrame({'a': range(10), 'b': range(10)})
        df.groupby(['a'])['b'].progress_apply(print_progress, t, n=2)

    def test_dummy2():
        t = tqdm_pandas()
        df = p

# Generated at 2022-06-24 09:45:42.565259
# Unit test for function tqdm_pandas