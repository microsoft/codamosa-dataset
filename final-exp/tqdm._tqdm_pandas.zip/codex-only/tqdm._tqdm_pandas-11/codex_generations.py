

# Generated at 2022-06-24 09:35:56.003369
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(
        dict(
            Value=np.random.randint(0, 100, 100),
            Status=np.random.choice(
                ['A', 'B', 'C'], 100)
        )
    )
    import tqdm
    tqdm.pandas(desc='test_tqdm_pandas')
    res = df.groupby('Status')['Value'].progress_apply(lambda x: x.sum())
    assert 'test_tqdm_pandas' in str(res)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:07.512078
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        warnings.warn("Cannot test function 'tqdm_pandas': pandas not found",
                      ImportWarning)
        return
    try:
        import numpy as np
    except ImportError:
        warnings.warn("Cannot test function 'tqdm_pandas': numpy not found",
                      ImportWarning)
        return

    from tqdm import tqdm
    from tqdm import tqdm_gui

    pd.DataFrame([[1, 2], [3, 4]]).groupby(0).agg([np.sum, np.mean])
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_gui)
    tqdm_pandas(tqdm())


# Generated at 2022-06-24 09:36:16.356657
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    tqdm_pandas(tqdm(total=10))

    df = pd.DataFrame({'x': np.arange(10)})
    df.groupby('x').progress_apply(lambda g: g + 1)

    tqdm_pandas(tqdm(total=10), file=sys.stdout)

    df = pd.DataFrame({'x': np.arange(10)})
    df.groupby('x').progress_apply(lambda g: g + 1)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:20.763738
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    with tqdm_pandas(total=20, leave=True, file=sys.stdout, unit='B') as pbar:
        import pandas as pd
        _ = pd.DataFrame([range(10) for _ in range(10)], columns=list('abcdefghij')).groupby('a').progress_apply(lambda x: x+1)

# Generated at 2022-06-24 09:36:26.108613
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from tqdm import tnrange
    from tqdm.auto import tqdm
    from tqdm.utils import _supports_unicode
    from pandas import DataFrame, Series

    def identity(x):
        from time import sleep
        sleep(0.01)
        return x

    try:
        from pandas.core.groupby import GroupBy  # pandas<0.20
    except ImportError:
        from pandas.core.groupby import DataFrameGroupBy as GroupBy  # pandas>=0.20

    df = DataFrame({'a': [1, 2, 3], 'b': [3, 4, 5]})

# Generated at 2022-06-24 09:36:34.886055
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests the `tqdm_pandas` function against existing `tqdm.pandas`
    """

    # Install random progressbar
    n = 10
    import numpy as np
    df = pd.DataFrame({'x': np.random.random(n)})
    t = tqdm(total=n)
    res = t + df.groupby(df.x // 0.1).progress_apply(series_to_string)
    # Check res for equality with what tqdm.pandas would return
    res2 = t + df.groupby(df.x // 0.1).progress_apply(series_to_string)
    assert res == res2
    # Check res for equality with what tqdm.pandas would return

# Generated at 2022-06-24 09:36:44.424840
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    df = pd.DataFrame(np.random.random((100, 100)))
    t = tqdm_pandas(tqdm(total=df.shape[0]))
    # result should be a new dataframe
    assert isinstance(df.progress_apply(lambda x: x**3, axis=0), pd.DataFrame)
    # callback should be called
    assert hasattr(t, 'callback') and hasattr(t.callback, 'update')
    # tqdm should be closed
    assert not t.is_active


if __name__ == '__main__':
    try:
        test_tqdm_pandas()
    except ImportError as e:
        print(e)

# Generated at 2022-06-24 09:36:49.783180
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for ``tqdm_pandas``
    """
    import pandas as pd
    import numpy as np
    from tqdm import trange

    df = pd.DataFrame(
        {'A': list('aabbcc'),
         'B': np.random.randint(0, 100, size=(6,)),
         'C': np.random.randint(0, 100, size=(6,))},
        index=pd.date_range('20170301', periods=6))
    tqdm_pandas(trange(10))
    with trange(10) as t:
        t.pandas(df['B'].groupby(df['A']).agg(np.std))


if __name__ == '__main__':
    test_tqdm_

# Generated at 2022-06-24 09:36:57.728942
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    df = pd.DataFrame(dict(
        a=['aa', 'bb', 'cc', 'dd'],
        b=[1, 2, 3, 4],
    ))

    # No exception expected
    tqdm_pandas(tqdm_gui())
    tqdm_pandas(tqdm_notebook())
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm, file=None)
    tqdm_pandas(tqdm_gui, file=None)
    tqdm_pandas(tqdm_notebook, file=None)
    tqdm_pandas(tqdm, file=sys.stderr)


# Generated at 2022-06-24 09:37:09.133222
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas, tqdm_gui
    from time import sleep

    print("Testing tqdm_pandas (tqdm_notebook)")

    df = pd.DataFrame(pd.np.random.randint(0, 100, (100000, 6)))
    df.columns = ["a", "b", "c", "d", "e", "f"]

    def square(x):
        sleep(0.001)
        return x ** 2

    tqdm_pandas(tqdm_gui())

    # NB: tqdm_pandas will be deprecated soon; use tqdm.pandas(gui=...) instead.

# Generated at 2022-06-24 09:37:17.709099
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'A': [1, 2, 3], 'B': [2, 3, 4]})

    # optional
    with tqdm.tqdm(total=len(df)) as t:
        df.groupby('A').progress_apply(lambda x: t.update())
        tqdm_pandas(t, file=sys.stdout)

        df.groupby('A').progress_apply(lambda x: x)
        tqdm_pandas(t, file=sys.stdout)

    df = pd.DataFrame({'A': [1, 2, 3], 'B': [2, 3, 4]})
    df.groupby('A').progress_apply(lambda x: x)

    tqdm_

# Generated at 2022-06-24 09:37:27.977616
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        from unittest.mock import patch
    except ImportError:  # Python < 3.3
        from mock import patch

    @patch('pandas.core.groupby.DataFrameGroupBy.progress_apply')
    @patch('tqdm.tqdm')
    def test(mocktqdm, mockapply):
        tqdm_pandas(mocktqdm)
        pd.DataFrame([]).groupby([]).progress_apply(None)
        assert mockapply.called

    test()
    print('tqdm_pandas passed')


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:29.458738
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas()

# Generated at 2022-06-24 09:37:35.868198
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm_pandas`."""
    import numpy as np
    import pandas as pd

    n = 1000
    df = pd.DataFrame({'a': np.random.randint(0, 100, n)})
    t = df.groupby('a').progress_apply(lambda x: x)
    assert "progress_apply" in repr(t)


# Test compatibility with IPython

# Generated at 2022-06-24 09:37:41.828070
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for `tqdm_pandas` """
    from tqdm._utils import _supports_unicode  # type: ignore
    from tqdm import tqdm
    from pandas import DataFrame, read_table
    from numpy import random
    from time import sleep
    for i in tqdm(range(5), desc='tqdm decorator', unit='i'):
        sleep(.1)
    for i in tqdm(range(5), desc='tqdm instance', unit='i'):
        sleep(.1)
    for i in tqdm(range(5), desc='tqdm deprecated', unit='i'):
        sleep(.1)
    for i in tqdm(range(5), desc='tqdm', unit='i'):
        sleep(.1)


# Generated at 2022-06-24 09:37:51.608789
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    def f(x):
        return x + 1

    df = pd.DataFrame(np.arange(100, dtype=np.intc))
    # tqdm.pandas(desc='f')
    # tqdm_pandas(tqdm, desc='f')
    tqdm_pandas(tqdm(desc='f'))

    assert df.progress_apply(f).sum().values[0] == (100 * 101) / 2
    assert df.progress_apply(f, axis=0).sum().values[0] == 100



# Generated at 2022-06-24 09:38:02.580791
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from itertools import product
    from random import randint
    from tqdm import tqdm

# Generated at 2022-06-24 09:38:08.700612
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.cli import tqdm
    from tqdm.pandas import tqdm_pandas
    import pandas as pd

    df = pd.DataFrame({'a': [1, 2, 3, 4, 5], 'b': [0, 0, 0, 0, 0]})
    tqdm_pandas(tqdm())
    df.groupby(['a']).progress_apply(lambda x: x)

# Generated at 2022-06-24 09:38:15.197123
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({'x': range(10000),
                       'y': range(10000)})
    _ = df.groupby('x').progress_apply(lambda x: sum(x))
    _ = df.groupby('y').progress_apply(lambda x: sum(x))

    tqdm_pandas(tqdm(leave=False))
    _ = df.groupby('x').progress_apply(lambda x: sum(x))
    _ = df.groupby('y').progress_apply(lambda x: sum(x))

# Generated at 2022-06-24 09:38:25.589573
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas  # noqa
    except ImportError:
        raise unittest.SkipTest("Skipping test_tqdm_pandas: "
                                "pandas is not installed")
    from pandas import DataFrame, Series

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm().__class__)
    assert re.match(
        r'^\d+/\d+ [\*_]?$',
        DataFrame([1, 2, 3]).groupby(Series([0, 0, 1])).progress_apply(len)._repr_html_())


# Initialise the tqdm.pandas module
tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:38:34.090205
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Try tqdm_pandas
    test_df = pd.DataFrame(np.random.randint(0, 100, size=[2000000, 6]))
    test_df.groupby(0).progress_apply(lambda x: x**2)
    tqdm_pandas(pandas=True)
    test_df.groupby(0).progress_apply(lambda x: x**2)
    tqdm_pandas(pandas=False)
    test_df.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-24 09:38:39.908006
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    df = pd.DataFrame({"A": range(5)})
    df.groupby("A").progress_apply(lambda _: None)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:49.401541
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    # This function tests deprecated features, so silence deprecation warnings
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter('ignore', category=DeprecationWarning)

        tqdm = tqdm_pandas(tqdm)
        assert tqdm.__name__ == 'tqdm'
        assert isinstance(tqdm, type)
        tqdm = tqdm_pandas(tqdm())
        assert tqdm.__name__ == 'tqdm'
        assert not isinstance(tqdm, type)

        from pandas import DataFrame

        df = DataFrame({'a': range(1000)})

# Generated at 2022-06-24 09:38:59.987849
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_df = pd.DataFrame({'a': [1, 2, 3], 'b': [10.0, 20.0, 30.0]})

    def myfunc(x):
        return x

    # Test deprecated version which gives warning
    t = tqdm_pandas(tqdm(total=test_df.shape[0]), desc='test', leave=False)
    try:
        for _ in test_df.progress_apply(myfunc, axis=1, pipe=t):
            time.sleep(0.1)
    except NameError:
        pass

    import tqdm
    t = tqdm.pandas(desc='test', leave=False)

# Generated at 2022-06-24 09:39:09.997887
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    import numpy as np
    df = pd.DataFrame({'x': np.random.normal(size=int(1e5)),
                       'y': np.random.normal(size=int(1e5))})

    def squarenorm(x):
        return (x['x'] ** 2 + x['y'] ** 2) ** .5

    # Create a dummy tqdm instance for testing
    t = type(str("DummyTqdm"), (object, ), {
        'update': lambda self, n: None,
        'close': lambda self: None,
        '__new__': lambda self: self
    })()
    t.pandas = lambda deprecated_t=None, **kwargs: None

    # Unit test
   

# Generated at 2022-06-24 09:39:20.847761
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    import numpy as np
    import pandas as pd

    def test_function(x):
        return np.random.choice([1, 2, 3, 4, 5])

    # Make a pandas dataframe
    data = np.array([[1, 2, 3],
                     [4, 5, 6],
                     [7, 8, 9]])
    df = pd.DataFrame(data, columns=['a', 'b', 'c'])
    tqdm_pandas(tqdm, show=False)
    assert df.groupby('a').progress_apply(test_function).sum() == 32
    tqdm_pandas(tqdm, show=True)

# Generated at 2022-06-24 09:39:26.801875
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(total=100))
    tqdm_pandas(tqdm(total=100), desc='Testing')

    df = pd.DataFrame(np.random.randint(0, 100, (1000, 1)))
    df.groupby(0).progress_apply(lambda x: x * 2)

# Generated at 2022-06-24 09:39:30.685444
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from tqdm import tqdm_notebook
    except ImportError:
        pass
    else:
        tqdm_notebook(desc='test').pandas(desc='test')

# Generated at 2022-06-24 09:39:41.639082
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # data preparation
    N = 1000
    df_train = pd.DataFrame({
        'user_id': [str(i) for i in range(N)],
        'age': [i % 10 + 10 for i in range(N)]
    })
    # Run
    try:
        res = df_train.groupby('user_id').progress_apply(len)
    except TypeError:
        try:
            res = df_train.groupby('user_id').progress_apply(len)
        except TypeError:
            return

    from tqdm import TqdmDeprecationWarning

# Generated at 2022-06-24 09:39:49.850833
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import random
    from pandas import DataFrame

    def tqdm_f(*args, **kwargs):
        return list(tqdm.tqdm(*args, **kwargs))

    df = DataFrame({'A': range(100), 'B': range(100)})

    tqdm_kwargs = {'total': len(df)}
    actual_output = df.groupby('A').progress_apply(random.random)
    expected_output = df.groupby('A').apply(tqdm_f, **tqdm_kwargs, func=random.random)
    assert expected_output == actual_output

    # Test delayed adapter case

# Generated at 2022-06-24 09:40:00.724910
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmDeprecationWarning)
        pd.DataFrame.progress_apply(pd.DataFrame(np.random.randint(0, 2, size=(1, 4)),
                                                 columns=list('WXYZ')), func=lambda x: x, axis=0)

    with warnings.catch_warnings(record=True) as w:
        warnings.filterwarnings("always", category=TqdmExperimentalWarning)

# Generated at 2022-06-24 09:40:11.481120
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    from pandas import DataFrame
    from tqdm import tqdm
    tqdm.pandas(desc="Test-pandas")
    df = DataFrame({
        "a": np.random.randint(0, 50, 10000),
        "b": np.random.randint(0, 50, 10000)
    })

    df_groupby = df.groupby("a")
    df_groupby.progress_apply(lambda x: x)

    # Test delayed adapter case
    tqdm_pandas(tqdm)

    # Test deprecated adapter case (deprecated)
    tqdm_pandas(tqdm(desc="deprecated-adapter"))


# Add `pandas` attribute to tqdm

# Generated at 2022-06-24 09:40:17.017465
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame, Series
    from numpy import random as rd

    # Create a test Series and DataFrame
    s = Series(rd.rand(100000))
    df = DataFrame({'float': Series(rd.rand(100000)),
                    'int': Series(rd.randint(0, 100000, 100000)),
                    'year': Series(rd.randint(1980, 2016, 100000))})

    # Register and deregister `tqdm` with `pandas`
    tqdm_pandas(tqdm)
    df.progress_apply(lambda x: x.sum())
    tqdm_pandas(tqdm, leave=False)
    df.progress_apply(lambda x: x.sum())

    # Dereg

# Generated at 2022-06-24 09:40:20.071456
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=100))

# Generated at 2022-06-24 09:40:30.604491
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    tqdm_pandas(tqdm)

    # smoke tests
    df = pd.DataFrame(np.random.rand(1000, 1000))
    df.progress_apply(lambda x: x + 1)
    df = pd.DataFrame([1, 1, 2, 3, 4, 5, 6])
    df.progress_apply(lambda x: x + 1)


# Automatically register `tqdm` with the `DataFrame.progress_apply`
# if tqdm is imported before pandas
if 'pandas' in sys.modules:
    import pandas as pd
    import tqdm

# Generated at 2022-06-24 09:40:36.845244
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame([1, 2, 3])
    tqdm_pandas(df.groupby(df[0]).progress_apply(lambda x: x))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:43.002835
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm.pandas
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm.tqdm, desc='foo')
    # deprecated
    tqdm_pandas(tqdm.tqdm())
    tqdm_pandas(tqdm.tqdm(desc='bar'))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:49.881747
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    import numpy as np
    import pandas as pd

    # define test function
    def foo(x):
        return np.sum(x ** 2)

    df = pd.DataFrame(np.random.randint(0, 10, size=(100000, 4)), columns=list('ABCD'))
    tqdm_pandas(tqdm)

    # groupby
    res = df.groupby('A').progress_apply(foo)
    assert isinstance(res, pd.Series)

    # apply
    res = df.progress_apply(foo)
    assert isinstance(res, pd.Series)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:55.919797
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm(total=3, unit='child') as t:
        tqdm_pandas(t)  # noqa
        t.update(2)
    assert not t.leave
    with tqdm(total=3) as t:
        tqdm_pandas(t)   # noqa
        t.update(2)
    assert t.leave


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:41:03.883344
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # test adapter
    d = tqdm_pandas(tqdm, desc=str('unit test'))
    assert isinstance(d, type)
    assert d.__name__.startswith('tqdm_')

    # test deprecated function
    t = tqdm_pandas(tqdm(desc=str('unit test')))
    assert isinstance(t, tqdm)
    assert isinstance(t._deprecated_alias, tqdm)

    # test DataFrameGroupBy interface
    s = pd.Series(list('abcdefghij'))
    assert s.groupby(s).progress_apply(len).equals(s.groupby(s).apply(len))

    # TODO: test Series interface



# Generated at 2022-06-24 09:41:13.700619
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for tqdm_pandas."""
    from pandas import DataFrame
    from tqdm import tqdm
    import numpy as np
    from ._tqdm_pandas import my_func

    df = DataFrame({'xs': np.random.randn(10000)})
    assert tqdm_pandas(tqdm())(df.groupby(df.xs > 0).progress_apply,
                               my_func) is not None
    assert tqdm_pandas(tqdm)(df.groupby(df.xs > 0).progress_apply,
                             my_func) is not None
    assert "tqdm_pandas is deprecated" in repr(tqdm_pandas)

# Generated at 2022-06-24 09:41:20.850076
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    import sys
    from tqdm import tqdm, TqdmDeprecationWarning
    tclass = tqdm(range(10))
    tqdm_pandas(tclass)
    assert hasattr(tclass, 'pandas')
    with TqdmDeprecationWarning(fp_write=sys.stderr.write):
        tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, file=sys.stderr)

# Generated at 2022-06-24 09:41:32.207338
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import tqdm

    def _test_tqdm_pandas_t(tfunc, targs, tkwargs, expected_output):
        # Construct a Pandas groupby object
        test_data = {'a': [1, 3, 5, 7, 9], 'b': [2, 4, 6, 8, 10]}
        df = DataFrame(test_data)
        gb = df.groupby('a')

        # Apply tqdm_pandas to the Pandas dataframe
        tqdm_pandas(tfunc, **tkwargs)

        # Call function tfunc on the Pandas dataframe

# Generated at 2022-06-24 09:41:41.023530
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np

        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
        with tqdm(total=100) as t:  # Intentionally too small to fail quickly
            df.groupby(0).progress_apply(lambda x: x ** 2)
    except:
        print('Please install `pandas` for unit tests.', file=sys.stderr)
        raise


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:49.729057
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    from pandas import DataFrame

    # create a test dataframe
    df = DataFrame({'a':[list(range(1000)),list(range(1000))]})

    # create a progress bar
    bar = tqdm(total=len(df))

    # register the progress bar with the test dataframe
    tqdm_pandas(bar)

    # apply a dummy function to the test dataframe
    df.progress_apply(lambda x: [i**2 for i in x])

    # assert that the progress bar worked as expected
    assert bar.n == len(df)

# create a function to check if function are being run as part of a unit test, e.g. nosetests
# http://stackoverflow.com/questions/3041986

# Generated at 2022-06-24 09:41:56.728887
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import TqdmDeprecationWarning

    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(lambda x: x)
    from tqdm import tqdm
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:06.328305
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.util.testing import assert_frame_equal
    from tqdm import tqdm

    # Generate DataFrame in memory
    df = DataFrame(np.random.randn(10, 3))

    # Apply tqdm_pandas with simple lambda
    pbdf = df.progress_apply(lambda x: x, axis=0)

    # Apply tqdm_pandas with tqdm
    pbdf2 = df.progress_apply(lambda x: tqdm(x), axis=0)

    # Apply tqdm_pandas with tqdm_gui(tqdm)
    pbdf3 = df.progress_apply(lambda x: tqdm_gui(tqdm(x)), axis=0)

    # Apply tqdm_pand

# Generated at 2022-06-24 09:42:14.427374
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Deprecation warnings can't be unit-tested
    try:
        import warnings
        warnings.filterwarnings('ignore', category=TqdmDeprecationWarning)
    except:
        pass
    test_axis = range if PY3 else xrange
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm(total=1))
    try:
        # adapts pandas.DataFrame.progress_apply
        import pandas as pd
        df = pd.DataFrame(dict(a=range(100), b=range(100)))
        df.progress_apply(lambda x: x, axis=1)
    except ImportError:
        pass
    except Exception as e:
        raise e
tqdm_pandas.__test__ = False  #

# Generated at 2022-06-24 09:42:18.164466
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas  # NOQA
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm())

        import numpy as np  # NOQA
        df = pd.DataFrame({'x': np.random.randn(100)})
        df.groupby(0).progress_apply(lambda x: x)
    except Exception:
        pass

# Generated at 2022-06-24 09:42:28.399144
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return  # Ignore this test if pandas is not installed.

    from tqdm import tqdm
    from tqdm.pandas import tqdm as tqdmp
    import pandas as pd

    df = pd.DataFrame({'x': range(1000), 'y': range(1000)})
    ret = df.groupby('y').progress_apply(lambda o: o)
    assert repr(ret) == repr(df)
    assert repr(ret) == repr(df.groupby('y').apply(lambda o: o))

    ret = df.groupby('y').progress_apply(lambda o: o)
    assert repr(ret) == repr(df)

# Generated at 2022-06-24 09:42:34.844957
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange

    # Declare pandas DataFrame
    df = pd.DataFrame(np.ones((100, 100)), columns=['col1'] * 100)

    # Test tclass as instance
    t1_inst = trange(1, leave=False)
    tqdm_pandas(t1_inst)
    assert t1_inst.__class__.__name__ == 'tqdm_notebook'
    assert t1_inst.__class__.__module__ == 'tqdm.notebook'

    # Test tclass as class type
    t2_class = tqdm
    tqdm_pandas(t2_class)

# Generated at 2022-06-24 09:42:43.181753
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    """Unit test for function `tqdm_pandas`.
    """
    import pandas as pd
    import numpy as np
    from tqdm.pandas import tqdm_pandas
    from tqdm import tqdm

    if hasattr(pd.core.groupby.DataFrameGroupBy, 'progress_apply'):
        df = pd.DataFrame(np.random.randint(0, 10, (100000, 6)))
        tqdm_pandas(tqdm(ascii=True, position=0))  # Dynamic tqdm instance
        tdf = df.groupby(0).progress_apply(lambda x: x)
    else:
        raise ImportError('pandas <0.18 is not supported.')

# Generated at 2022-06-24 09:42:52.137839
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from io import StringIO
    from tqdm import tqdm

    # test using pandas.SeriesGroupBy.progress_apply()
    df = pandas.DataFrame({"x": ["a", "b", "c", "a", "b"],
                           "y": [1, 2, 3, 4, 5]})

    sio = StringIO()
    tqdm_pandas(tqdm(unit="B", unit_scale=True, smoothing=0.25,
                     mininterval=0.25, miniters=1, file=sio),
                df.groupby("x").y.apply(sum), total=3)
    assert sio.getvalue() == "20.00B [00:00, 67.99B/s]\n"

    # test using pandas

# Generated at 2022-06-24 09:43:01.755093
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    from tqdm import tqdm, tqdm_pandas, TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)
        dataframe = pd.DataFrame(
            [dict(a=1, b=2), dict(a=2, b=3), dict(a=3, b=4), dict(a=4, b=5)])
        # Default options are the same
        dataframe.groupby('a').progress_apply(lambda _: _)
        tqdm_pandas(tqdm)
        dataframe.groupby('a').progress_apply(lambda _: _)
        # Also works with tqdm_

# Generated at 2022-06-24 09:43:11.921790
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({"A": [1, 2, 3], "B": [2, 3, 4]})
    df.groupby('A').progress_apply(lambda x: x.sum())

    if '__IPYTHON__' not in globals():
        tqdm_pandas(tqdm, desc="test_tqdm_pandas")
        tqdm_pandas(tqdm(desc="test_tqdm_pandas"))


# Test for compatibility with tqdm_notebook
# This is only for the testing purposes.
# You should not actually use both tqdm_notebook and tqdm_pandas together.

# Generated at 2022-06-24 09:43:21.571326
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    N = 3000000
    df = pd.DataFrame({'A': np.linspace(1, N, N),
                       'B': np.random.uniform(0, 1, N),
                       'C': np.random.choice(['a', 'b', 'c'], N)})
    df2 = pd.DataFrame({'A': np.linspace(1, N, N),
                        'B': np.random.uniform(0, 1, N),
                        'C': np.random.choice(['a', 'b', 'c'], N)})

# Generated at 2022-06-24 09:43:32.282344
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import trange, tqdm_pandas
    from tqdm.auto import tqdm

    with trange(2) as t:
        for i in t:
            assert i in [0, 1]
    # test tqdm pandas
    tqdm._instances.clear()
    with tqdm(total=1) as t:
        df = pd.DataFrame(dict(A=np.random.randint(0, 5, 100),
                               B=np.random.randint(0, 5, 100)),
                          columns=['A', 'B'])
        try:
            x = df.groupby('A').progress_apply(len)
        except AttributeError:
            tqdm_pandas

# Generated at 2022-06-24 09:43:39.812600
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import pandas.testing as pdt

    min_periods = 1

    class MyTqdm(tqdm):
        @property
        def remaining(self):
            return self.total - self.n

    def foo(x):
        sleep(0.01)
        return x * 2

    class BarTqdm(tqdm):
        def update(self, n=1, postfix=None, **kwargs):
            if postfix is not None:
                self.set_postfix(postfix)
            super(BarTqdm, self).update(n=n, **kwargs)

    class BazTqdm(tqdm):
        @property
        def remaining(self):
            return self.total - self.n

    # Test with a

# Generated at 2022-06-24 09:43:45.699083
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert hasattr(tqdm, 'pandas')
    assert callable(tqdm.pandas)
    assert hasattr(tqdm, '__version__')
    assert tqdm.__version__.split('.') >= ['4', '43', '0']


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:51.269838
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm

    # Test deprecated import
    tqdm_pandas(tqdm(total=100))

    class tclass:
        @classmethod
        def pandas(cls, deprecated_t=None, **tqdm_kwargs):
            return cls(ncols=120, **tqdm_kwargs)

    # Test deprecated use
    tqdm_pandas(tclass)



# Generated at 2022-06-24 09:43:56.888044
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas
    import numpy
    tn = tqdm.tqdm_notebook()
    df = pandas.DataFrame(numpy.random.rand(100000, 100))
    df.progress_apply(lambda x: None, axis=1, t=tn)

# Generated at 2022-06-24 09:44:03.264174
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    import pandas as pd

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})

    def apply_test(x):
        df2 = x.copy()
        df2['c'] = df2['a'] + df2['b']
        return df2

    with tqdm_pandas(total=len(df)):
        df = df.groupby('a').progress_apply(apply_test)



# Generated at 2022-06-24 09:44:11.667318
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, __version__

    np.random.seed(0)
    df = pd.DataFrame(np.random.rand(1e6, 3))
    with tqdm.pandas(desc=f"Test (v{__version__})", leave=True) as t:
        f = lambda x: x.rolling(100).mean()
        t.pandas_series = lambda s: tqdm_pandas(t.tqdm_gui(s), desc=str(s.name), leave=True)
        df.apply(f)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:22.459181
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm._tqdm import tqdm

    try:
        from pandas.core.groupby.generic import DataFrameGroupBy
    except ImportError:
        from pandas.core.groupby import DataFrameGroupBy

    assert hasattr(DataFrameGroupBy, 'progress_apply'), \
        "Please install `tqdm` via `pip install tqdm` and/or `conda install tqdm` ."

    t = tqdm()
    tqdm_pandas(t)
    with t:
        df = pd.DataFrame({'a': range(10)})
        df.groupby(0).progress_apply(lambda x: x)

    # Note: `tqdm.pandas(...)` is still more recommended than `tqdm_p

# Generated at 2022-06-24 09:44:30.464941
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import os

    def transform(df):
        df['c'] = df['a'] + df['b']
        return df

    pi = pd.DataFrame(np.random.randint(0, 100, (100000, 2)), columns=list('ab'))
    with tqdm(total=len(pi),
              file=open(os.devnull, "w"),
              miniters=0,
              mininterval=0) as t:
        tqdm_pandas(t, desc='Apply')
        pi = pi.groupby('a').progress_apply(transform)

# Generated at 2022-06-24 09:44:34.860108
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    pd = __import__('pandas')
    tqdm_pandas(tqdm, leave=False)
    pd.DataFrame({'c': [1, 2, 3]}).groupby('c').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:39.104073
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    # Convert a string to upper case
    def strToUpper(s):
        return s.upper()

    # Create a tqdm instance and register it with the pandas data frame
    tqdm_pandas(tqdm, smoothing=0.5)

    import pandas as pd

    df = pd.DataFrame(["a", "b", "c", "d"] * 100000)

    # This should return a tqdm instance
    ret = df.groupby(0, sort=False).progress_apply(strToUpper)

    from tqdm import tqdm_notebook

    # Create a tqdm instance and register it with the pandas data frame

# Generated at 2022-06-24 09:44:48.136792
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from functools import partial
    from tqdm import tqdm
    from tqdm.notebook import tqdm as tqdm_notebook

    try:
        import pandas as pd, numpy as np
    except ImportError:
        return

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(partial(tqdm, leave=True))

    df_groupby = pd.DataFrame({'a': range(10), 'b': range(10)}).groupby('b')
    df_groupby.progress_apply(lambda x: np.sum(x))


test_tqdm_pandas()
 
# =============================================================================
# Main
# =============================================================================


# Generated at 2022-06-24 09:44:57.383768
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import tqdm
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm.tqdm)
        tqdm_pandas(tqdm.tqdm)
        df = pd.DataFrame({"a": range(100), "b": range(100, 200)})
        for i in tqdm.tqdm(df.groupby("a")):
            pass
    except:
        raise
    else:
        tqdm.tqdm_pandas(tqdm)
        tqdm.tqdm_pandas(tqdm.tqdm)
        tqdm.tqdm_pandas(tqdm.tqdm)
        df = pd.Data

# Generated at 2022-06-24 09:45:07.887854
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:45:11.677169
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    df = pd.DataFrame({'X': np.random.randn(25)})
    with tqdm(total=len(df)) as t:
        def progress(x):
            t.update()
            return x
        df.groupby(df['X'] > 0).progress_apply(progress)



# Generated at 2022-06-24 09:45:22.006007
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_cli = tqdm_pandas(tqdm)
    assert tqdm_cli.__name__ == 'tqdm_pandas'
    tqdm_cli = tqdm_pandas(tqdm, desc='test')
    assert tqdm_cli == tqdm(desc='test').pandas
    tqdm_cli = tqdm_pandas(tqdm_notebook, desc='test')
    assert tqdm_cli == tqdm_notebook(desc='test').pandas
    tqdm_cli = tqdm_pandas(tqdm(desc='test'))
    assert tqdm_cli == tqdm(desc='test').pandas

# Generated at 2022-06-24 09:45:27.024570
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    tqdm.tqdm_pandas(tqdm.tqdm, smoothing=1)
    df = pd.DataFrame(np.random.randint(0, 1000, (10**6, 2)), columns=list('AB'))
    df.groupby('A').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:45:33.715259
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'a': [1, 2]})
    tqdm_kwargs = {'desc': 'test'}
    tqdm_pandas(tqdm, **tqdm_kwargs)
    df.groupby('a').progress_apply(lambda x: x + 1)
    tqdm_pandas(tqdm.tqdm_notebook, **tqdm_kwargs)
    tqdm_pandas(tqdm.tqdm_notebook, **tqdm_kwargs)
    assert isinstance(df.groupby('a').progress_apply(lambda x: x + 1),
                      pd.DataFrame)


if __name__ == '__main__':
    import pytest


# Generated at 2022-06-24 09:45:35.948195
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    pd = tqdm_pandas(tqdm())

# Generated at 2022-06-24 09:45:44.179891
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, read_csv
    from tqdm.pandas import tqdm_pandas
    df = DataFrame({'A': [1, 2, 3], 'B': [2, 3, 4]})
    try:
        tqdm_pandas(df.progress_apply(int))
    except Exception:
        raise Exception("Failed to register tqdm on pandas")
    try:
        tqdm_pandas(tqdm(df.progress_apply(int)))
    except Exception:
        raise Exception("Failed to register tqdm on pandas")
    try:
        tqdm_pandas(df.progress_apply(str))
    except Exception:
        raise Exception("Failed to register tqdm on pandas")

# Generated at 2022-06-24 09:45:52.701924
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas, tqdm

    df = pd.DataFrame({'x': np.random.randint(1, 5, 100),
                       'y': np.random.randint(1, 4, 100),
                       'z': np.random.randint(1, 6, 100),
                       'a': np.random.randint(1, 7, 100)})
    df.groupby(['x', 'y', 'z']).progress_apply(
        len)  # raises AttributeError without tqdm_pandas(...)