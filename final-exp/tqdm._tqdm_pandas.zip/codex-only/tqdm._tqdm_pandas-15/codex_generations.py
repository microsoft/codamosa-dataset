

# Generated at 2022-06-24 09:35:46.280280
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas."""
    from tqdm.pandas import tqdm
    from pandas import DataFrame
    from numpy import random

    def test_apply(x, *args, **kwargs):
        return random.rand(1)[0]

    df = DataFrame({'A': [1, 2], 'B': [3, 4]})
    tqdm_pandas(tqdm)  # tqdm_pandas(type(tqdm))
    # asserts that progress_apply terminates
    df.groupby('B').progress_apply(test_apply)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)
        tqdm_pandas(tqdm)


# Generated at 2022-06-24 09:35:54.401949
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        tqdm_pandas(1)
    except TypeError as e:
        assert 'got an unexpected keyword argument' in str(e)
    else:
        raise AssertionError('TypeError not raised.')

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm, desc='foo')


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:35:58.791473
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import random
    import pandas as pd
    from tqdm import tqdm

    frame = pd.DataFrame({'a': [random.random() for __ in range(100)],
                          'b': [random.random() for __ in range(100)]})
    tqdm_pandas(tqdm)
    frame.groupby('a').progress_apply(lambda x: x ** 2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:08.841048
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for `tqdm_pandas` """
    from pandas import DataFrame
    try:
        from pandas import Series
    except ImportError:
        # older pandas
        from pandas import TimeSeries as Series
    from tqdm import tqdm, TqdmTypeError

    # case: no parallelism
    s = Series(['a', 'b', 'c'])
    assert (s.groupby(s).progress_apply(str) == s).all()
    try:
        assert (s.groupby(s).progress_apply(str) == s).all()
    except TqdmTypeError:
        # older pandas
        pass

# Generated at 2022-06-24 09:36:18.710675
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randn(100, 3), columns=list('ABC'))
    from tqdm import tqdm
    from tqdm import trange
    from tqdm import tnrange
    from tqdm import tqdm_notebook


# Generated at 2022-06-24 09:36:20.192982
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm = tqdm_pandas(tqdm)
    assert type(tqdm).__name__ == 'tqdm_notebook'

# Generated at 2022-06-24 09:36:25.879620
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Ensure that tqdm_pandas is fully functional
    """
    from tqdm import tqdm, tqdm_notebook
    import pandas as pd
    import numpy as np

    # Check tqdm and tqdm_notebook
    DataFrame = pd.DataFrame(
        {'a': np.random.rand(200), 'b': np.random.rand(200), 'c': 0})

# Generated at 2022-06-24 09:36:34.757725
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas
    import pandas as pd
    from random import random, randrange
    from time import sleep

    data = [random() for _ in range(100)]
    df = pd.DataFrame(data, columns=['value'])

    # Create a tqdm instance that you want to reuse
    t = pandas(total=df.index.size, **tqdm_kwargs)
    # ... create the tqdm instance and register it with pandas
    t.pandas(**tqdm_kwargs)

    # Ensure tqdm_gui(leave=True) works as expected
    t = pandas(total=10, **tqdm_kwargs)
    t.pandas(**tqdm_kwargs)

# Generated at 2022-06-24 09:36:44.303054
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from math import factorial

    try:
        import pandas
        pd = pandas
    except ImportError:
        return

    # Test pandas=True
    t = tqdm_pandas()
    assert isinstance(t, tqdm)
    assert t.disable is False

    # Test pandas=False
    t = tqdm_pandas(pandas=False)
    assert isinstance(t, tqdm)
    assert t.disable is True

    # Test DataFrameGroupBy
    if pd.__version__.split('.') >= ['0', '18', '0']:
        test_df = pd.DataFrame([range(100)] * 10).T
        t = tqdm_pandas()
        test_df.groupby(lambda x: x // 10).progress

# Generated at 2022-06-24 09:36:49.634366
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest("Optional package pandas is missing.")

    # Setup
    df = DataFrame({
        'a': [1, 2, 3, 4, 5],
        'b': [1.1, 2.2, 3.3, 4.4, 5.5],
    })

    # Test 1
    pbar = tqdm(total=len(df))
    tqdm_pandas(pbar)
    df.groupby('a').progress_apply(lambda g: 1)
    pbar.close()

    # Test 2
    pbar = tqdm(total=len(df))

# Generated at 2022-06-24 09:36:56.713527
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from tqdm import tqdm_notebook
        _ = tqdm_notebook
    except:
        return
    # Test tqdm_notebook
    tqdm_pandas(tqdm_notebook)
    assert tqdm_notebook.pandas().__class__.__name__.startswith('tqdm_notebook')

    # Test tqdm_notebook(...)
    tqdm_pandas(tqdm_notebook(total=10))
    assert tqdm_notebook(total=10).pandas().__class__.__name__.startswith(
        'tqdm_notebook')

    # Test tqdm_notebook(tqdm_notebook(...))
 

# Generated at 2022-06-24 09:37:04.609826
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import trange
    from pandas import DataFrame

    trials = DataFrame({'id': range(100)})
    for desc in ['id', 'tqdm', 'trange', 'tqdm.trange']:
        for n in [1, 2, 10]:
            tqdm_pandas(getattr(tqdm, desc), total=n)
            trials.groupby(['id']).progress_apply(lambda x: x)

# Generated at 2022-06-24 09:37:14.314259
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    from tqdm import tqdm
    from tqdm import TqdmTypeError, TqdmKeyError

    # does nothing, passes through
    with tqdm(range(10), desc='testing') as t:
        assert t == t.pandas(total=10)
    with tqdm(range(10), desc='testing 2') as t:
        assert t == tqdm_pandas(t)
    with tqdm(range(10), desc='testing 3') as t:
        assert t == tqdm_pandas(t, total=10)

    # raise error when not provided to pandas

# Generated at 2022-06-24 09:37:23.697205
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import Series, DataFrame

    def foo(x):
        for i in range(10000):
            x += i
        return x

    # Series
    s = Series(range(1000))
    s.progress_apply(foo)

    # DataFrame
    df = DataFrame({'a': range(1000), 'b': range(1000)})
    df.progress_apply(foo, axis=1)

if __name__ == '__main__':
    from tqdm import tqdm, trange
    from pandas import Series, DataFrame

    def foo(x):
        for i in range(10000):
            x += i
        return x

    # Series
    s = Series(range(1000))
    s.progress_apply(foo)

    # DataFrame


# Generated at 2022-06-24 09:37:27.902531
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    x = numpy.zeros(10)
    y = pandas.Series(x)
    z = y.groupby(y)
    tqdm_pandas(z.progress_apply, lambda x: x)


if __name__ == "__main__":
    test_tqdm_pandas()



# Generated at 2022-06-24 09:37:31.284419
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:  # pragma: no cover
        return  # skip test if pandas is not installed
    tqdm_pandas(tqdm)



# Generated at 2022-06-24 09:37:41.288300
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm

    print("tqdm_pandas unit test")

    def testing_func(x):
        return np.random.rand()

    df = pd.DataFrame(np.random.random((10, 10)))

    with tqdm(total=1) as t:
        print("Testing function manually")
        df.progress_apply(testing_func).reset_index(drop=True)
        t.update(1)

    with tqdm(total=1) as t:
        print("Testing function with built-in adapter")
        df.progress_apply(testing_func).reset_index(drop=True)
        t.update(1)

    with tqdm(total=1) as t:
        print

# Generated at 2022-06-24 09:37:52.645741
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import concat
    import pandas
    from tqdm.pandas import tqdm_pandas

    tqdm_pandas(tqdm)

    # Test SeriesGroupBy
    x = DataFrame({"a": [1, 2, 3]})
    assert x.groupby('a').progress_apply(lambda x: x.sum())["a"].tolist() == [1, 2, 3]

    # Test DataFrameGroupBy
    x = DataFrame({"a": [1, 2, 3], "b": [1, 2, 3]})
    assert concat(x.groupby('a').progress_apply(lambda x: x.sum())).tolist() == \
        [1, 2, 3, 2, 4, 6]

    #

# Generated at 2022-06-24 09:38:04.011251
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmDeprecationWarning
    from tqdm.contrib import pandas
    try:
        tqdm.pandas(leave=False)
    except TqdmDeprecationWarning:
        pass
    try:
        pandas.tqdm_pandas(tqdm)
    except TqdmDeprecationWarning:
        pass
    try:
        from tqdm.contrib import pandas
        pandas.tqdm_pandas(tqdm)
    except TqdmDeprecationWarning:
        pass
    try:
        tqdm.pandas(tqdm)
    except TqdmDeprecationWarning:
        pass

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:13.679933
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    from pandas import DataFrame
    from tqdm import tqdm
    from pandas import DataFrame as pDataFrame
    import pandas as pd

    tqdm_pandas(tclass=tqdm)
    tqdm_pandas(tclass=tqdm(total=1))

    try:
        pd.__version__ >= '0.25'
        pDataFrame.progress_apply = pDataFrame.apply
    except AttributeError:
        pass
    # raise exception if pandas is not installed
    DataFrame().progress_apply(lambda x: x + 1)
    # same test but with deprecated names
    DataFrame().progress_apply(lambda x: x + 1)


# if __name__ == "__main__":  # pragma: no cover
#

# Generated at 2022-06-24 09:38:19.157880
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test tqdm_pandas function with int and str input dataframe"""

    test_dataframe = pd.DataFrame({'a':[1,2,3], 'b': ['a','b','c']})
    tqdm_pandas(tclass=tqdm, total=len(test_dataframe))
    assert test_dataframe.progress_apply(lambda x: x) is not None

# Generated at 2022-06-24 09:38:24.705483
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from ._tqdm_pandas import tqdm_pandas
    tqdm_pandas(tqdm(total=1e6), desc="Unit test", mininterval=0.25)
    # Must also test the delayed adapter (for `tqdm.pandas` calls)
    tqdm_pandas(tqdm, total=1e6, desc="Unit test", mininterval=0.25)

# Generated at 2022-06-24 09:38:28.795299
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm = tqdm_pandas(tqdm)
    import pandas as pd
    df = pd.DataFrame({'test': [1, 2, 3]})
    df.groupby('test').progress_apply(lambda x: 1)

# Generated at 2022-06-24 09:38:40.295225
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame({'a': np.random.randint(0, 100, (100000,)),
                       'b': np.random.randint(0, 100, (100000,))})

    tqdm_pandas(tqdm)

    # Can be used as a decorator
    @tqdm_pandas
    def progress_apply(df, func):
        return df.groupby('a').progress_apply(func)

    # Can also be used as a regular function
    res = progress_apply(df, lambda x: x.rolling(window=3).mean())
    assert len(res) == len(df)


if __name__ == '__main__':
    test_t

# Generated at 2022-06-24 09:38:43.612058
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Test old usage
    >>> tqdm_pandas(tqdm, ncols=80)
    Test new usage
    >>> tqdm_pandas(tqdm(ncols=80))
    '''
    pass

# Generated at 2022-06-24 09:38:46.841047
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm(desc='loading') as t:
        tqdm_pandas(t, ascii=False, total=100)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:53.111882
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from tqdm.pandas import tqdm_pandas
    import numpy as np

    df = DataFrame(np.random.randint(0, 100, (100000, 6)))
    # Register instance
    tqdm_pandas(tqdm(leave=False))

    # Test on DataFrame
    df.groupby(0).progress_apply(lambda x: x**2)
    # Test on Series
    df[0].progress_apply(lambda x: x**2)

    # Test pandas.core.window.Rolling.progress_apply
    df.rolling(10).progress_apply(lambda x: x.sum())

# Generated at 2022-06-24 09:38:56.460982
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame
    with tqdm.pandas(desc="test") as t:
        DataFrame(range(100)).progress_apply(lambda x: x)

# Generated at 2022-06-24 09:39:05.263316
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    # noinspection PyUnresolvedReferences
    data = pd.DataFrame(dict(a=np.random.random(1000),
                             b=np.random.random(1000),
                             c=np.random.random(1000)))

    # Test for `progress_apply` method
    # noinspection PyUnresolvedReferences
    c = data.groupby('a').progress_apply(lambda x: x + 1)

    # Test for `agg` method
    # noinspection PyUnresolvedReferences
    c = data.groupby('a').progress_agg(lambda x: x.mean() + x.std())

    # Test for `transform` method
    # noinspection PyUnresolvedReferences
    c = data

# Generated at 2022-06-24 09:39:15.898780
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit tests of tqdm_pandas function.
    """
    try:
        import pandas
    except ImportError:
        return

    from tqdm import tqdm
    from tqdm import trange
    from tqdm._utils import _term_move_up

    tqdm_kwargs = dict(miniters=1, smoothing=0)
    df = pandas.DataFrame({'a': [1, 2, 3]})

    # Test that tqdm_pandas(tqdm(...)) != tqdm.pandas(...)
    # Essentially, that the tqdm instance is passed as the deprecated_t
    # argument
    # tqdm_pandas(tqdm(...))
    with CaptureStdout() as cs1:
        tqdm

# Generated at 2022-06-24 09:39:23.395578
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({'a': [1, 3, 5, 7], 'b': ['b', 'c', 'd', 'e']})
    try:
        import tqdm as tqdm_v4
        tqdm_v4.tqdm_reset()
        tqdm_pandas(tqdm_v4, total=len(df.groupby('b')))
        df.groupby('b').progress_apply(lambda g: g)
    except AttributeError:
        pass

# Generated at 2022-06-24 09:39:27.118421
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        import pandas
        tqdm_pandas(tqdm)
    except Exception:
        pass

# Generated at 2022-06-24 09:39:35.759351
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import random
    random.seed(0)
    N = 100
    df = pd.DataFrame({'x': [random.random() for _ in range(N)],
                       'y': [random.random() for _ in range(N)]})
    # Apply
    out = df.groupby('x').progress_apply(lambda x: np.sum(x['y']))
    from tqdm import tqdm

    # nose tests
    assert isinstance(tqdm(
        unit_scale=True, total=N), tqdm)  # Check that tqdm is called correctly
    assert out  # Check that `out` is not empty

# Generated at 2022-06-24 09:39:45.381013
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas as tp
    tp(tqdm)  # should not throw an error.

    def my_pow(n):
        return n ** 2

    # Without tqdm_pandas
    df = pd.DataFrame(np.random.randint(1, 10, (1, 10)))
    df.apply(my_pow)

    tp(tqdm)
    # With tqdm_pandas
    df = pd.DataFrame(np.random.randint(1, 10, (1, 10)))
    df.progress_apply(my_pow)  # should print a progress bar


if __name__ == "__main__":
    test_t

# Generated at 2022-06-24 09:39:52.361130
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    tqdm.pandas(ascii=True)

    df = pd.DataFrame()
    df['A'] = np.random.randint(0, 1000, size=(1000,))

    tclass = tqdm(total=df.shape[0])
    df['A'].progress_apply(lambda x: np.sqrt(x))

    tqdm.pandas(ascii=True, mininterval=0.01)

    tqdm.pandas = lambda **n: tqdm(**n)

    tclass = tqdm(total=df.shape[0])

# Generated at 2022-06-24 09:39:54.472312
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:40:02.345757
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x**2)


if __name__ == '__main__':
    from tqdm import tqdm
    import numpy as np
    import pandas as pd
    tqdm_pandas(tqdm)
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-24 09:40:12.996263
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    import numpy as np
    from tqdm.notebook import tqdm

    @tqdm_pandas
    def adder(df):
        df = pd.DataFrame(df)
        return df.x * df.y * df.z

    df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 3)),
                      columns=list('xyz'))
    for _ in tqdm(range(5)):
        adder(df)

# Try to import pandas
if PANDAS_INSTALLED:
    from tqdm import tqdm, trange
    from . import pandas_groupby


# Generated at 2022-06-24 09:40:19.147700
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import trange, tqdm
    from tqdm import TqdmKeyError, TqdmDeprecationWarning

    # Test 1
    try:
        tqdm_pandas(tqdm(tclass=tqdm.tqdm_notebook), total=100)
    except TqdmDeprecationWarning:
        pass
    else:
        raise AssertionError('tqdm_pandas() should have raised a TqdmDeprecationWarning')

    # Test 2
    try:
        tqdm_pandas(tqdm, total=100)
    except TqdmDeprecationWarning:
        pass
    else:
        raise AssertionError('tqdm_pandas() should have raised a TqdmDeprecationWarning')



# Generated at 2022-06-24 09:40:30.004704
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for `tqdm_pandas`.
    """
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from pandas.util.testing import assert_frame_equal

    # pd.DataFrame(pd.read_csv('test/test_pandas.csv')).progress_apply(lambda x: x, axis=1)  # NOQA

    df = pd.DataFrame({
        'col': np.arange(500)//10,
        'val': np.arange(500)//10
    })
    tqdm_pandas(tqdm)
    df_out = df.progress_apply(lambda x: x, axis=1)

# Generated at 2022-06-24 09:40:35.994051
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`"""
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(pandas=True))
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(pandas=True))


# Monkey-patch pandas
try:
    import pandas as pd
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm.progress_apply
except ImportError:
    pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:43.926777
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    from pandas import DataFrame, Series

    df = DataFrame({'a': [1,2,3], 'b': [5,5,5]})
    with tqdm(total=len(df), file=sys.stdout) as pbar:
        def update(*a, **k):
            pbar.update()
        df.progress_apply(update)

        def inc_series(s):
            ret = s.sum()
            for i in range(ret):
                pbar.update()
            return ret
        print('\n', df.progress_apply(inc_series))  # noqa

    tqdm_pandas(df.a.apply(lambda x: x**2))

    # delayed adapter
    tqdm_p

# Generated at 2022-06-24 09:40:51.856009
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import pandas.util.testing as pd_testing
    from tqdm.autonotebook import tqdm
    from tqdm import trange

    df = pd_testing.makeTimeDataFrame()
    df = df.reindex(trange(df.index[~df.index.duplicated(keep='first')].size))
    assert (df.progress_apply(lambda x: x + 1) == df + 1).all().all()
    assert (df.progress_apply(lambda x: x + 1) == 2).all().any()
    assert (df.progress_apply(lambda x: x + 1) == 2).all().all()
    assert (df.progress_apply(lambda x: x + 1) == 2).all().any()

    df

# Generated at 2022-06-24 09:40:58.949516
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd

        df = pd.DataFrame(
            {'x': list(range(10))},
            index=pd.date_range('1/1/2000', periods=10))
        import tqdm
        tqdm.tqdm_pandas(tqdm.tqdm(), leave=False)

        assert (df.groupby(lambda x: x.strftime("%m")).progress_apply(len) ==
                df.groupby(lambda x: x.strftime("%m")).apply(len))
    except ImportError:
        pass

# Generated at 2022-06-24 09:41:05.553494
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame
    from .tests_tqdm import closing
    from .tests import pretest_posttest_testsuite

    with closing(StringIO()) as our_file:
        with tqdm(
                total=5,
                file=our_file,
                desc="pandas") as t:
            def pandas_test(x):
                t.update()
                time.sleep(0.01)
            df = DataFrame(list(range(5)))
            df.progress_apply(pandas_test)
            assert t.n == 5


# Generated at 2022-06-24 09:41:13.654063
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm._tqdm_pandas import _tqdm_pandas

    def _test_apply_func(df):
        len(df)

    df = pd.DataFrame({"a": range(10), "b": range(10, 0, -1)})

    tqdm_pandas(tqdm())
    df.groupby("a").progress_apply(_test_apply_func)

    _tqdm_pandas.deprecated_t = tqdm()
    df.groupby("a").progress_apply(_test_apply_func)

# Generated at 2022-06-24 09:41:22.562719
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def adapt_tqdm(tclass, **tqdm_kwargs):
        """
        Registers the given `tqdm` instance with
        `pandas.core.groupby.DataFrameGroupBy.progress_apply`.
        Should be equivalent to `tclass.pandas(...)`
        """
        from pandas import DataFrameGroupBy
        from functools import partial
        from tqdm import tqdm as _tqdm

        if 'desc' in tqdm_kwargs:  # needs `total=` interface
            assert 'total' not in tqdm_kwargs
            tqdm_kwargs['total'] = np.nan

        def tqdm_wrapper(apply_func, *args, **kwargs):
            if isinstance(args[0], DataFrameGroupBy):
                return _t

# Generated at 2022-06-24 09:41:28.249531
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        pass
    else:
        df = pandas.DataFrame({'A': [1, 2, 3, 4], 'B': [4, 3, 2, 1]})
        df = df.groupby('B').progress_apply(lambda x: None)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:34.210436
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        from tqdm import tqdm
    except ImportError:
        return
    # Test tqdm_pandas(tqdm, ...) case [adapter case]
    tqdm(leave=False).pandas(total=0)
    df = pd.DataFrame(range(1000))
    grouped = df.groupby(0)
    next(iter(df.itertuples()))
    next(iter(grouped.progress_apply(lambda x: x)))
    next(iter(grouped.progress_apply(lambda x: x, leave=True)))
    next(iter(grouped.progress_apply(lambda x: x, leave=True, total=None)))
    # Test tqdm_pandas(tqdm(...)) case
    next

# Generated at 2022-06-24 09:41:37.423019
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm as tcls

    # Test deprecated form without arguments
    tqdm_pandas(tcls)

    # Test deprecated form with arguments
    tqdm_pandas(tcls, file=sys.stderr)

    # Test non-deprecated form without arguments
    tcls.pandas()

    # Test non-deprecated form with arguments
    tcls.pandas(total=5)

# Generated at 2022-06-24 09:41:45.938880
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas

    # Test case 1
    tqdm_pandas(tqdm)

    # Test case 2
    tclass = tqdm()
    tqdm_pandas(tclass)

    # Test case 3
    tclass = tqdm(**{'desc': 'test'})
    tqdm_pandas(tclass)


if __name__ == '__main__':
    # Run unit tests
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 09:41:49.817831
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Must not raise any exception
    import pandas as pd
    pd.DataFrame(['a'] * 100).progress_apply(lambda x: x)
    import tqdm
    tqdm.pandas()
    pd.DataFrame(['a'] * 100).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:00.238847
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm, trange
    from tqdm.utils import _supports_unicode

    try:
        pd.DataFrame([""]).progress_apply(lambda x: None)
    except:
        from nose import SkipTest
        raise SkipTest("pandas not installed")


# Generated at 2022-06-24 09:42:04.094678
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`"""
    import pandas as pd
    import numpy as np
    import warnings


# Generated at 2022-06-24 09:42:12.620383
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    import pandas as pd
    import pandas.core.groupby
    import numpy as np
    import timeit
    import itertools
    import warnings

    # Version check
    if pd.__version__.split('.') < ['0', '17', '0']:
        raise ValueError('Requires pandas>=0.17.0')

    # Test tqdm_pandas(...)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(total=1))

    # Test delayed tqdm_pandas(...)
    tqdm.pandas(tqdm=tqdm)

# Generated at 2022-06-24 09:42:18.020968
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        t = tqdm(total=100)
        tqdm_pandas(t)
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm, total=100)
        tqdm_pandas(tqdm(), total=100)
        pd.DataFrame([1, 2, 3]).groupby(tqdm_pandas(tqdm)).progress_apply(lambda x: 1)
    except ImportError:
        pass

# Generated at 2022-06-24 09:42:23.256513
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm
    import pytest
    pandas_series = pd.Series(np.random.randint(1, 10, size=5))
    pandas_dataframe = pd.DataFrame(
        np.random.randint(1, 10, size=(5, 5)), columns=['a', 'b', 'c', 'd', 'e'])

    # Interactive nested progress bars with DataFrameGroupBy.progress_apply
    with pytest.warns(TqdmDeprecationWarning):
        with tqdm.pandas(desc='pandas_series') as t1:
            t1.pandas_series.progress_apply(
                lambda x: time.sleep(x / 10) if x > 5 else x)

# Generated at 2022-06-24 09:42:31.933829
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .std import tqdm_pandas as _tqdm_pandas
    from .std import tqdm as _tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame()
    df['a'] = np.arange(5)
    df['b'] = np.arange(5, 10)
    df.groupby('a').progress_apply(lambda x: x)
    _tqdm_pandas(_tqdm, leave=False)
    df.groupby('a').progress_apply(lambda x: x)
    _tqdm_pandas(_tqdm())
    df.groupby('a').progress_apply(lambda x: x)
    _tqdm_pandas(_tqdm(), leave=False)
   

# Generated at 2022-06-24 09:42:41.285527
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    tqdm_pandas(pandas.core.groupby.DataFrameGroupBy.progress_apply)
    tqdm_pandas(get_tqdm(0))
    tqdm_pandas(get_tqdm(0), desc='Foo')
    try:
        import pandas as pd
        from tqdm import tqdm

        def fun(df):
            assert isinstance(df, pd.DataFrame)
            return df

        pd.DataFrame({}).groupby('foo').progress_apply(fun)
        for t in [tqdm, tqdm_pandas]:
            t(pclass=pd.DataFrame).groupby('foo').progress_apply(fun)
    except ImportError:
        pass



# Generated at 2022-06-24 09:42:47.537124
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm
    tqdm.pandas(tqdm(total=4))
    tqdm.pandas(tqdm(total=4))
    tqdm_pandas(tqdm(total=4))
    tqdm_pandas(tqdm(total=4))

# Compatibility with multiprocessing
_tqdm_pandas_original_apply = None



# Generated at 2022-06-24 09:42:52.513037
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from .utils import silence

    df = DataFrame({'a': range(4)})
    with silence():
        for _ in tqdm_pandas(tqdm(total=len(df))):
            df.progress_apply(lambda x: x)


if __name__ == '__main__':
    # Test the module
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:58.541022
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm, tqdm_pandas
    tqdm_pandas(tqdm)
    try:
        DataFrame({"A": [], "B": []}).groupby('A').progress_apply(lambda x: x)
    except Exception as e:
        # import traceback; traceback.print_exc()
        raise e

# Generated at 2022-06-24 09:43:08.823234
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    from tqdm.contrib.test_tqdm import with_setup, pretest, posttest
    import pandas as pd

    def tqdm_pandas_setup(*args, **kwargs):
        tqdm = tqdm_gui(*args, **kwargs)
        tqdm.pandas(**kwargs)

    def tqdm_pandas_teardown(*args, **kwargs):
        tqdm = tqdm_gui(*args, **kwargs)
        tqdm.pandas(deprecated_t=tqdm)


# Generated at 2022-06-24 09:43:19.053607
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas. """
    from tqdm import TqdmTypeError
    import pandas as pd
    from pandas.core.groupby import DataFrameGroupBy

    # create pd.DataFrame with 3 columns
    df = pd.DataFrame({"A": [1,2,3,4,5], "B": [10,20,30,40,50], "C": [100,200,300,400,500]})
    # print df
    #    A   B    C
    # 0  1  10  100
    # 1  2  20  200
    # 2  3  30  300
    # 3  4  40  400
    # 4  5  50  500

    # create DataFrameGroupBy object

# Generated at 2022-06-24 09:43:25.599465
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests tqdm_pandas(...) by comparing with the deprecated
    tqdm(...).pandas(...)
    """
    import pandas as pd
    from tqdm.autonotebook import tqdm, trange
    try:  # python-3.4
        from importlib import reload
    except ImportError:  # python-2.7
        from imp import reload
    from tqdm._tqdm import tqdm as _tqdm

    # from tqdm import tqdm_pandas
    from tqdm._tqdm_notebook import tqdm as _tqdm_notebook
    if not hasattr(_tqdm, 'pandas'):
        _tqdm = reload(_tqdm)

# Generated at 2022-06-24 09:43:35.368858
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randn(200000, 3) * np.random.randint(0, 100))

    tqdm_pandas(tqdm, smoothing=0)
    df.groupby('A').progress_apply(lambda x: len(x))
    tqdm_pandas(tqdm)
    df.groupby('A').progress_apply(lambda x: len(x))
    tqdm_pandas(tqdm, smoothing=0.01)
    df.groupby('A').progress_apply(lambda x: len(x))

    tqdm_pandas(tqdm)
    df.groupby('A').progress_transform(lambda x: len(x))
    tq

# Generated at 2022-06-24 09:43:40.804212
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    # Shortcut to the deprecated pandas adapter:
    def tqdm_pandas_depr(tclass, **tqdm_kwargs):
        return tqdm_pandas(tclass, **tqdm_kwargs)
    # just in case it's not registered before :/
    tqdm_pandas_depr(tqdm)
    from pandas import Series, DataFrame
    import numpy as np

    C = 10**4
    df = DataFrame({'x': np.random.randint(0, C, size=C),
                    'y': np.random.randint(0, C, size=C)})
    df.groupby('x').progress_apply(lambda x: x.y + x.y.sum())


# Generated at 2022-06-24 09:43:50.905302
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    pd.DataFrame(range(100)).groupby(0).progress_apply(lambda x: x)
    pd.DataFrame(range(100)).groupby(0).apply(lambda x: x)
    with tqdm(total=10) as t:
        pd.DataFrame(range(100)).groupby(0).progress_apply(lambda x: x, t=t)
    with tqdm(total=10) as t:
        pd.DataFrame(range(100)).groupby(0).apply(
            lambda x: x, t=t, leave=False)  # no tqdm
    with tqdm(total=10) as t:
        pd.DataFrame(range(100)).groupby(0).progress

# Generated at 2022-06-24 09:44:02.507001
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _range
    from pandas import DataFrame
    import pandas._testing as pdt
    import numpy as np

    df = DataFrame({'col': np.random.randint(100, size=100)})
    assert (df.groupby('col', sort=False).progress_apply(len) == 1).all()

    def test_no_tqdm(*args, **kwargs):
        return len(args[0])

    df.groupby('col', sort=False).progress_apply = test_no_tqdm

    with pytest.raises(AttributeError, match=r".*'NoneType' object has no attribute 'update'"):
        (df.groupby('col', sort=False).progress_apply(len) == 1).all()


# Generated at 2022-06-24 09:44:07.252295
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy.random import randint
    from numpy import arange
    from tqdm import tqdm_pandas

    with tqdm_pandas(miniters=1) as t:
        df = DataFrame(randint(0, 10, (1000000, 1)),
                       columns=['foo'], dtype=str)
        df = t.progress_apply(len, axis=1)

# Generated at 2022-06-24 09:44:11.812216
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np
    import tqdm

    pbar = tqdm.tqdm_pandas(tqdm.tqdm(total=10))
    pbar.update(0)
    arr = np.random.rand(100, 100)
    df = pandas.DataFrame(arr)
    df.progress_apply(lambda x: x)
    pbar.update(1)

# Generated at 2022-06-24 09:44:21.862475
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    df = pd.DataFrame({'col1': range(10000),
                       'col2': range(10000, 20000)})

    tqdm.pandas(desc='my bar')
    df.groupby('col1').progress_apply(lambda x: x**2)
    tqdm.pandas()
    df.groupby('col1').progress_apply(lambda x: x**2)
    # deprecated syntaxes
    tqdm_pandas(tqdm, desc='my bar')
    tqdm_pandas(tqdm())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:31.007158
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    import tqdm

    @tqdm.pandas(desc="MyProgressBar!")
    def progress_apply(df, func, column_name, axis=0):
        return df.progress_apply(func, axis=axis)

    df = pd.DataFrame({"x": np.random.rand(100)}, index=pd.date_range('2018-01-01', periods=100))
    result = progress_apply(df, lambda x: x, "x")

    # Uncomment the following line to print the DataFrame.
    # print(result)

    # Cleanup
    df, result = None, None


test_tqdm_pandas()

# Generated at 2022-06-24 09:44:40.543401
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    def tqdm_pandas_wrapper(pd_type, **tqdm_kwargs):
        tqdm_pandas(pd_type, **tqdm_kwargs)

    df = DataFrame({'A': [0, 1, 2], 'B': [3, 4, 5]})
    df.groupby('A').progress_apply(sum)

    tqdm_pandas_wrapper(tqdm)
    df.groupby('A').progress_apply(sum)

    tqdm_pandas_wrapper(tqdm(ascii=True))
    df.groupby('A').progress_apply(sum)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:49.294173
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import Series, DataFrame

    # Series
    s = Series(range(1, 10))
    s.groupby(lambda x: x % 2).progress_apply(lambda x: x + 1)
    tqdm_pandas(tqdm(total=1, unit='test'), total=1)
    # DataFrame
    df = DataFrame(dict(a=s, b=s))
    df.groupby('a').progress_apply(lambda x: x + 1)
    df.groupby('b').progress_apply(lambda x: x + 1)
    tqdm_pandas(tqdm(total=1, unit='test'), total=1)
    # with custom `total`

# Generated at 2022-06-24 09:44:58.329378
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test tqdm_pandas function"""
    import pandas as pd
    import numpy as np
    import tqdm
    # ======== Test case 1 ======== #
    df = pd.DataFrame({'x': [1, 2, 3, 4], 'y': [5, 6, 7, 8]})
    with tqdm.trange(len(df)) as t:
        tqdm_pandas(t)
        df.groupby('x').progress_apply(lambda x: sum(x))
        t.reset(ncols=80)
    with tqdm.trange(len(df)) as t:
        tqdm_pandas(t)
        df.groupby('x').progress_apply(lambda x: sum(x))
        t.close()

    # =====

# Generated at 2022-06-24 09:45:03.694983
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        tqdm_pandas(tqdm(total=10))
        for _ in pd.DataFrame([1]).progress_apply([lambda x: x]):
            pass
    except Exception as e:
        print(e)
        assert False


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:11.766862
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame
    from pandas import Series
    from pandas import GroupBy
    from pandas.core.groupby import DataFrameGroupBy

    import numpy as np
    from scipy.stats import norm

    # Test pandas
    if not pd:
        raise unittest.SkipTest("pandas not installed")
    df = DataFrame(np.random.normal(size=(100000, 3)))
    expected_df = DataFrame([
        Series([norm.pdf(val) for val in df[col]])
        for col in df], index=df.columns)


# Generated at 2022-06-24 09:45:22.127483
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib.concurrent import process_map
    from tqdm import tqdm

    df = pd.DataFrame({'a': range(100), 'b': range(100)})
    df2 = pd.DataFrame({'a': range(100), 'b': range(100)})

    def func(x):
        return x

    df_groupby = df.groupby(df.index // 10)
    df2_groupby = df2.groupby(df2.index // 10)

    # test tqdm.pandas(**tqdm_kwargs)
    df_groupby.progress_apply(func)  # normal
    tqdm.pandas(**tqdm_kwargs)
    df_

# Generated at 2022-06-24 09:45:27.654628
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    assert tqdm != tqdm_pandas  # for coverage
    assert tqdm_pandas.__name__.startswith('tqdm_')

    tqdm_pandas(tqdm, ascii=True, file=sys.stderr)
    #  tqdm_pandas(tqdm_gui, ascii=True, file=sys.stderr)  # Fails



# Generated at 2022-06-24 09:45:32.419589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'a': np.random.randn(10000)})
    tqdm_pandas(tqdm(total=len(df)), file=sys.stdout).apply(lambda x: x)
    tqdm_pandas(tqdm(total=len(df), file=sys.stdout)).apply(lambda x: x)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:45:42.339146
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import trange, tqdm
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({'a': range(100), 'b': range(100, 200)})
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(trange)
    w = []
    tqdm_pandas(tqdm(df.groupby('a'),
                     desc='Progress',
                     leave=True,
                     miniters=0))
    try:
        tqdm_pandas(tqdm(total=10))
    except TqdmDeprecationWarning as e:
        w.append(str(e))
    assert len(w)