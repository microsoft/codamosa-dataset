

# Generated at 2022-06-24 09:35:56.431170
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas

    # Create sample DataFrame
    from pandas import DataFrame
    from numpy import random
    import string
    df = DataFrame([{"a": i,
                     "b": i * 2,
                     "c": i * 3} for i in
                    tqdm_pandas(range(10000),
                                desc='df creation')])
    df['d'] = [
        ''.join(random.choice(string.ascii_uppercase + string.digits, 20))
        for _ in tqdm_pandas(range(10000),
                             desc='df creation')
    ]

    # Apply function on all columns
    def mysum(x):
        return x.sum()

    print(df.progress_apply(mysum))

    # Apply function

# Generated at 2022-06-24 09:36:07.845611
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from pandas import DataFrame
    import pandas as pd

    def pro(x):
        return x

    df = DataFrame({'a': list(range(20))})
    t1 = tqdm_pandas(tqdm(total=10), desc='1')
    t2 = tqdm_pandas(tqdm(total=10))
    try:
        # delayed adapter case
        t1(t2)
    except AttributeError as e:
        assert str(e) == "'tqdm' object has no attribute 'pandas'"
    else:
        raise RuntimeError()
    tqdm_pandas(tqdm(t1(desc='2')))

# Generated at 2022-06-24 09:36:17.746553
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame
    import pandas as pd
    import numpy as np
    import io

    # check that class method is assigned correctly
    assert hasattr(tqdm, 'pandas')
    assert type(tqdm('test')).pandas is not None
    assert type(tqdm('test')).pandas.__module__ == 'tqdm.pandas'

    # check that tqdm_pandas works
    tqdm_pandas(tqdm.tqdm)

    # check that class method can be assigned to a custom tqdm class
    class CustomTqdm:
        @staticmethod
        def pandas(*args, **kwargs):
            pass


# Generated at 2022-06-24 09:36:26.904744
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    def func(df):
        return df['a'].sum()

    df = pd.DataFrame({'a': [1, 2, 3] * 100, 'b': [1, 1, 1] * 100})
    out = df.groupby('b').progress_apply(func)
    assert out.sum() == 900, out
    print("Test 1 succeeded")
    out = df.groupby('b', progress_apply=tqdm.tqdm).apply(func)
    assert out.sum() == 900, out
    print("Test 2 succeeded")
    out = df.groupby('b', progress_apply=tqdm.tqdm_notebook).apply(func)
    assert out.sum() == 900, out
    print("Test 3 succeeded")
   

# Generated at 2022-06-24 09:36:35.596588
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm

    df = pd.DataFrame({"a": np.arange(10), "b": [1, 2, 3, np.nan] * 3})
    res = df.groupby("a").progress_apply(
        lambda x: np.sum(x))  # Test with tqdm_pandas
    assert res.sum() == sum(df.groupby("a").apply(lambda x: np.sum(x)).values.flatten())

    res = tqdm_pandas(tclass=tqdm, unit="it", total=1)(df.groupby("a")).progress_apply(
        lambda x: np.sum(x))  # Test with tqdm_pandas

# Generated at 2022-06-24 09:36:44.890102
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm as tqdm
    import time
    import os

    def test_func(df):
        time.sleep(0.1)
        return df

    pd.core.groupby.GroupBy.progress_apply = lambda self, func, *args, **kwargs: func(self, *args, **kwargs)
    tqdm_pandas(tqdm)

    N = 10000
    df = pd.DataFrame(np.random.randint(0, 100, (N, 6)), columns=list('ABCDEF'))
    for _ in df.groupby('A').progress_apply(test_func):
        pass

    print("Done! No error raised")
    os._exit(0)



# Generated at 2022-06-24 09:36:49.852867
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        tqdm_pandas(tqdm, leave=False)
        assert len(w) >= 1
        assert any(['tqdm_pandas' in str(wi.message) for wi in w])
        # reset warnings filter
        warnings.simplefilter('default')
    assert hasattr(pd.core.groupby.DataFrameGroupBy, 'progress_apply')

# Generated at 2022-06-24 09:36:57.867050
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm as tqdm
    tqdm.tqdm_pandas(tqdm)
    tqdm.tqdm_pandas(tqdm.tqdm)
    tqdm.tqdm_pandas(tqdm.tqdm_notebook)
    tqdm.tqdm_pandas(tqdm.tqdm_gui)
    tqdm.tqdm_pandas(tqdm.trange)
    tqdm.tqdm_pandas(tqdm.tqdm_pandas)  # TODO: add test for this one
    tqdm.tqdm_pandas(tqdm.tqdm_pandas, total=100)  # TODO: add

# Generated at 2022-06-24 09:37:09.213911
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmDeprecationWarning

    with tqdm(0) as t:
        tqdm_pandas(t)

    assert TqdmDeprecationWarning
    assert t.pandas.__self__ is t


# https://bugs.python.org/issue2361
# https://github.com/pandas-dev/pandas/pull/3252

# Generated at 2022-06-24 09:37:11.861901
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm_pandas)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:12.794474
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:37:19.653446
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os, sys
    import pandas as pd
    from tqdm import tqdm


# Generated at 2022-06-24 09:37:29.294659
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd

    try:
        tqdm_pandas(tclass=tqdm)
        tqdm_pandas(tclass=tqdm(), file=sys.stdout)
        tqdm_pandas(tclass=tqdm())
    except NotImplementedError:
        pass

    df = pd.DataFrame(
        {'a': [4, 3, 5, 7], 'b': [0, 4, 11, 22], 'c': [0, 0, 0, 0]})
    df.groupby('a').progress_apply(lambda r: r)
    df.groupby('a', as_index=False).progress_apply(lambda r: r)


# Generated at 2022-06-24 09:37:39.790807
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return  # skipped
    tqdm_pandas(tqdm(total=1000), file=sys.stdout).sum(level=0)
    tqdm_pandas(tqdm(total=1000), file=sys.stdout).aggregate(level=0)
    tqdm_pandas(tqdm(total=1000), file=sys.stdout).apply(level=0)
    tqdm_pandas(tqdm(total=1000), file=sys.stdout).filter(level=0)
    tqdm_pandas(tqdm(total=1000), file=sys.stdout).transform(level=0)

# Generated at 2022-06-24 09:37:49.835823
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with catch_warnings(record=True) as w:
        tqdm_pandas(tqdm)
        assert tqdm.pandas._instances == {}

        tqdm_pandas(tqdm())
        assert (len(tqdm.pandas._instances) ==
                1 and isinstance(list(tqdm.pandas._instances.values())[0], tqdm))

    # check that warnings were raised
    assert len(w) > 0
    assert any(['Please use `tqdm.pandas(...)`' in str(ww.message) for ww in w])

    # explicit unit test
    tqdm_pandas(tclass=tqdm)



# Generated at 2022-06-24 09:37:59.600769
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        tqdm_pandas(0)  # TypeError
    except Exception as e:
        if type(e).__name__ != 'TypeError':
            raise
    try:
        tqdm_pandas(float, 0)
    except Exception as e:
        if type(e).__name__ != 'TypeError':
            raise
    try:
        tqdm_pandas(type, 0)
    except Exception as e:
        if type(e).__name__ != 'TypeError':
            raise
    a = tqdm_pandas(tqdm_notebook)
    b = tqdm_pandas(tqdm)
    assert a == b
    del a, b



# Generated at 2022-06-24 09:38:07.876257
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame

    try:
        from tqdm import tqdm_notebook as tqdm
    except Exception:
        from tqdm import tqdm

    import numpy as np
    from time import sleep

    df = DataFrame(np.random.uniform(size=(1000000, 3)), columns=list("abc"))

    for i in tqdm(df.groupby("a").progress_apply(lambda x: x)):
        sleep(0.001)  # some computations


# if __name__ == '__main__':
#     test_tqdm_pandas()

# Generated at 2022-06-24 09:38:10.024954
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm(total=10, position=0))  # tqdm(..., position=x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:17.719308
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        from tqdm import *
        df = pd.DataFrame({'x': range(10),
                           'y': range(10)})

        def tqdm_pandas_test_func(df):
            return df

        # Test with both tqdm args and kwargs (and delayed adapter)
        with tqdm(total=10) as t:
            t = df.groupby(tqdm_pandas(t, leave=None), as_index=False).progress_apply(tqdm_pandas_test_func)
        assert t is not None
    except Exception as e:
        print("Exception: " + str(e))
        raise e


if __name__ == '__main__':
    test_tqdm_pandas

# Generated at 2022-06-24 09:38:27.380079
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    df = pd.DataFrame([1, 2, 3, 4, 5])
    tqdm_pandas(tqdm(), unit='bla')  # Output: Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.
    tqdm_pandas(tqdm(unit='bla'))  # Output: Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm(...))`.
    df.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-24 09:38:35.747438
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from numpy.random import randint

    def func():
        return DataFrame(randint(10, size=(1000, 1000)))

    with tqdm(total=1000, tqdm_kwargs={"ncols": 100}) as pbar:
        func().progress_apply(lambda x: None, axis=0)
        pbar.update(1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:46.218772
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from tqdm.auto import tqdm

    try:
        import pandas
    except ImportError:
        warnings.warn("pandas not found. unit test for tqdm_pandas skipped.")
    else:
        pd = pandas.DataFrame({'a': range(3)})
        with tqdm(total=3) as t:

            def f(x):
                t.update()
                return x + 1

            p = pd.progress_apply(f, axis=1, result_type='broadcast')
            assert pd.equals(p, pandas.DataFrame({'a': range(1, 4)}))


test_tqdm_pandas.test_tqdm_pandas_deprecation = True

# Generated at 2022-06-24 09:38:48.796460
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm
    tqdm.pandas()
    pandas.read_csv('__test_pandas__').progress_apply(lambda x: x + 1)

# Generated at 2022-06-24 09:38:59.451335
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    df = pandas.DataFrame(data={'x': range(1000)})
    with tqdm_pandas(total=len(df), ascii=True) as pbar:
        df.progress_apply(lambda x: x**2)
    assert len(pbar) == len(df)
    assert pbar.n == len(df)
    assert pbar.total == len(df)
    assert pbar.smoothing == 1
    assert pbar.dynamic_ncols
    assert not pbar.leave
    assert not pbar.ascii
    assert not pbar.disable

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:05.904603
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    import pandas as pd
    import numpy as np

# Generated at 2022-06-24 09:39:13.614856
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def f(x):
        time.sleep(0.01)
        return x

    try:
        import pandas as pd
        df = pd.DataFrame(np.random.random((100, 100)))
        with tqdm(total=100, ascii=True, mininterval=1.0) as t:
            df.apply(f, axis=1, result_type='reduce',
                     min_count=1,
                     post_apply=lambda x: t.update())
        assert t.n == t.total == 100
    except ImportError:
        pass

# Generated at 2022-06-24 09:39:24.065168
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Installing tqdm
    try:
        import pandas
        assert pandas
    except ImportError:
        raise SkipTest

    def func_test_tqdm_pandas():
        import pandas as pd
        import numpy as np
        df = pd.DataFrame({'user_id': ['U%d' % i for i in range(1000)]})
        # test the default tqdm_notebook
        with tqdm_pandas():
            _ = df.groupby('user_id').progress_apply(lambda _: np.random.rand())
        # test passing tqdm

# Generated at 2022-06-24 09:39:34.999428
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import trange

    def func(x):
        return x**2
    # Finds func within globals()
    assert 'func' in DataFrameGroupBy.progress_apply.__globals__
    # Create a DataFrame with random values
    df = DataFrame(pd.util.testing.makeDataFrame())
    # Apply func to the first column of df
    df_out = df.iloc[:, 0].progress_apply(func, display=False)
    # Reshape df and apply tqdm_pandas
    for i in trange(5):
        tqdm_pandas(trange(5), desc='tqdm_pandas')
        df

# Generated at 2022-06-24 09:39:44.983030
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    from pandas import DataFrame
    from tqdm import tqdm_pandas
    from tqdm._tqdm import tqdm

    def tqdm_wrapper(*args, **kwargs):
        return tqdm(*args, **kwargs)

    df = DataFrame(np.random.rand(10000, 5))

    with tqdm_wrapper(total=len(df), file=sys.stderr) as t:
        tqdm_pandas(t)
        df.progress_apply(lambda x: x ** 2)

    df.progress_apply(lambda x: x ** 2)

    with tqdm_pandas(total=len(df), file=sys.stderr) as t:
        df.progress_apply(lambda x: x ** 2)



# Generated at 2022-06-24 09:39:50.625477
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    from pandas.util.testing import makeTimeDataFrame, assert_frame_equal

    df = makeTimeDataFrame()
    df['B'] = df['A']
    tqdm.pandas(tqdm.trange)
    result = df.progress_apply(lambda x: x)
    assert_frame_equal(result, df)


del sys

if __name__ == '__main__':
    tqdm_pandas(tqdm)
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:00.914092
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from random import randint
    from tqdm import tqdm, tqdm_notebook, trange

    # Create DataFrame
    df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 4)), columns=list('ABCD'))

    # Test the different functions
    for tclass in [tqdm, tqdm_notebook, trange]:
        tqdm_pandas(tclass, desc=('desc'))
        df.groupby('A').progress_apply(lambda x: x + x.mean())
        tqdm_pandas(tclass)
        df.groupby('A').progress_apply(lambda x: x + x.mean())


# Generated at 2022-06-24 09:40:11.715205
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        tqdm_pandas(tqdm(total=3), a=1)
    except TqdmDeprecationWarning:
        pass
    else:
        raise RuntimeError('tqdm_pandas should raise a DeprecationWarning')

    try:
        tqdm_pandas(tqdm, total=3, a=1)
    except TqdmDeprecationWarning:
        pass
    else:
        raise RuntimeError('tqdm_pandas should raise a DeprecationWarning')

    try:
        tqdm_pandas(tqdm)
    except TqdmDeprecationWarning:
        pass
    else:
        raise RuntimeError('tqdm_pandas should raise a DeprecationWarning')


# Generated at 2022-06-24 09:40:17.006953
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class MockTqdm:
        attr = None

        @staticmethod
        def pandas(*args, **kwargs):
            MockTqdm.attr = ('pandas', args, kwargs)

    class MockTqdmFunc:
        attr = None
        fp = None

        def __init__(self, *args, **kwargs):
            MockTqdmFunc.attr = ('tqdm', args, kwargs)

        @staticmethod
        def pandas(*args, **kwargs):
            MockTqdmFunc.attr = ('pandas', args, kwargs)

    from tqdm.autonotebook import tqdm

    assert MockTqdm.attr is None
    tqdm_pandas(MockTqdm)

# Generated at 2022-06-24 09:40:26.126121
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm(total=10, desc='pbar', file=None) as pbar:
        tqdm_pandas(pbar, file=None)
        pbar.pandas(file=None)
    import pandas as pd
    with tqdm(total=10, desc='pbar', file=None) as pbar:
        tqdm_pandas(pbar, file=None)
        df = pd.DataFrame({'a': list(range(10))})
        df.groupby(['a']).progress_apply(lambda x: 1 + 1)
    import numpy as np
    with tqdm(total=10, desc='pbar', file=None) as pbar:
        tqdm_pandas(pbar, file=None)

# Generated at 2022-06-24 09:40:35.453093
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for the entire module"""
    try:
        import pandas as pd
    except ImportError:
        return  # Only run tests if pandas is installed
    from tqdm import tqdm

    df = pd.DataFrame(
        {'a': [1, 2, 3, 4, 5],
         'b': [6, 7, 8, 9, 0],
         'c': [1, 2, 3, 4, 5],
         'd': [6, 7, 8, 9, 0]})

    def dummy_fun(x):
        return x.iloc[-1]


# Generated at 2022-06-24 09:40:42.457136
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm as tqdm_pandas

    for i in tqdm_pandas(range(100)):  # instant adapter case
        assert (i >= 0)


if hasattr(tqdm, "pandas"):
    tqdm_pandas = tqdm.pandas  # noqa
elif hasattr(tqdm, "tqdm_pandas"):
    tqdm_pandas = tqdm.tqdm_pandas  # noqa
else:
    tqdm_pandas = tqdm_pandas  # noqa

# Generated at 2022-06-24 09:40:49.863493
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    from tqdm import tqdm_pandas

    df = pandas.DataFrame({'float': numpy.random.random(100),
                           'int': list(range(100)),
                           'str': ['foo'] * 100})

    tqdm_pandas(tqdm=tqdm)
    pandas.core.groupby.DataFrameGroupBy.progress_apply = tqdm(
        pandas.core.groupby.DataFrameGroupBy.progress_apply,
        **{'bar_format': '{n_fmt}/{total_fmt} [{elapsed}>{remaining} {rate_fmt}]'})
    df.groupby('str').progress_apply(lambda x: x['float'].sum())



# Generated at 2022-06-24 09:40:57.304395
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm_pandas
    tqdm_pandas(0)
    tqdm_pandas(tqdm=[0])
    tqdm = tqdm_pandas([0])
    with tqdm:
        assert tqdm.get_lock().is_being_managed()
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm.get_lock()
    pd.DataFrame(np.random.randn(1000, 1000)).groupby(0).progress_apply(lambda x: x ** 2)

# Generated at 2022-06-24 09:41:04.299074
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    try:
        from tqdm import tnrange, tqdm_pandas  # from tqdm master
    except ImportError:
        from tqdm import trange as tnrange, tqdm_gui as tqdm_pandas

    tqdm_pandas(tqdm, leave=False)  # tqdm.pandas(leave=False)

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x ** 2)
    tnrange(10)  # check nested tnrange

# Generated at 2022-06-24 09:41:14.047019
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    pd.Series(range(5)).progress_apply(lambda x: x)
    pd.DataFrame({'a': range(5), 'b': range(5)}).groupby('a').progress_apply(lambda x: x)
    pd.DataFrame({'a': range(5), 'b': range(5)}).groupby('b').progress_apply(lambda x: x)
    pd.DataFrame({'a': range(5), 'b': range(5)}).groupby(['a', 'b']).progress_apply(lambda x: x)
    pd.DataFrame({'a': range(5), 'b': range(5)}).groupby(['b', 'a']).progress_apply(lambda x: x)



# Generated at 2022-06-24 09:41:22.767708
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Function for testing:
    def test_func(values, tqdm_pandas_):
        for _ in tqdm_pandas_(range(values)):
            time.sleep(1.e-3)
        return values

    # Check no explicit bar integration:
    with _range(1, desc='One'):
        import pandas
        df = pandas.DataFrame()
        df['value'] = pandas.Series([100, 200, 300])
        df.groupby(['value']).progress_apply(test_func)  # no explicit bar:

    # Check explicit bar integration:
    with _range(1, desc='One'):
        import pandas
        df = pandas.DataFrame()
        df['value'] = pandas.Series([100, 200, 300])

# Generated at 2022-06-24 09:41:31.809137
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame
    from tqdm import tqdm

    df = DataFrame([[1, 1], [2, 2], [3, 3], [4, 4], [5, 5]], columns=['A', 'B'])
    with tqdm(total=len(df)) as pbar:
        for i in tqdm_pandas(df.groupby('A'), file=pbar):
            # print(i)
            pass
    assert True


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:39.180721
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Unit test for method tqdm_pandas
    '''
    import tqdm.auto as tqdm
    if tqdm is None:
        return
    with tqdm.tqdm_pandas(range(3)) as t:
        pass

# Generated at 2022-06-24 09:41:43.457921
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas_tqdm import tqdm
    tqdm_pandas(tqdm, smooth=1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:50.767543
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib.tests import tnrange
    from tqdm.auto import trange

    tqdm_pandas(tnrange, ascii=True)
    tqdm_pandas(tnrange, ascii=True, miniters=1)
    tqdm_pandas(tnrange, ascii=True, total=100, miniters=1)
    tqdm_pandas(trange, ascii=True)
    tqdm_pandas(trange, ascii=True, total=100)
    try:
        tqdm_pandas(trange, total=0)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-24 09:41:57.817504
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    nrows = 100
    ncols = 3
    df = pd.DataFrame(np.random.randint(10, size=(nrows, ncols)),
                      columns=[str(i) for i in range(ncols)])
    summation = df.groupby(0).progress_apply(np.sum)
    assert summation.shape == (len(df.groupby(0)), ncols)

# Generated at 2022-06-24 09:41:58.653913
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas()"""

# Generated at 2022-06-24 09:42:04.741317
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # create progress bar
    tqdm.pandas()

    # test on group by data frame
    df = pd.DataFrame({'x': np.random.random(100), 'y': np.random.random(100)})
    df.groupby('x').progress_apply(lambda g: np.sum(g))

    # test on apply data frame
    df.progress_apply(lambda x: np.sum(x))

# Generated at 2022-06-24 09:42:13.059380
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    from random import randint
    from time import sleep
    from tqdm import tqdm_notebook

    n, p = 1000, 0.001
    df = pandas.DataFrame({'a': [randint(0, 2) for _ in range(n)],
                           'b': [randint(0, 2) for _ in range(n)]})
    gr = df.groupby(['a', 'b'])

    # Test legacy
    assert tqdm_pandas(tqdm_notebook) == None
    # Test with pandas
    assert tqdm_pandas(tqdm_notebook, desc='Testing...') == None

    # Test no-deprecation warnings

# Generated at 2022-06-24 09:42:19.835052
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test fp_write
    tqdm_pandas(tqdm_gui, fp_write=lambda x: None)
    tqdm_pandas(tqdm_gui())
    # Test mutable kwargs
    tqdm_pandas(tqdm_gui, display=False, file=sys.stdout)
    tqdm_pandas(tqdm_gui, file=sys.stdout, display=False)
    # Test class and instance
    tqdm_pandas(tqdm_gui)
    tqdm_pandas(tqdm_gui())
    tqdm_pandas(tqdm_gui, display=True)
    tqdm_pandas(tqdm_gui, file=sys.stdout)
    tqdm

# Generated at 2022-06-24 09:42:29.788583
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm); tqdm_pandas(tqdm(range(10)))


__all__.append('test_tqdm_pandas')
del sys, test_tqdm_pandas, TqdmDeprecationWarning


# Compatibility with older versions of pandas
try:
    import pandas as pd
    Series = pd.Series
    DataFrame = pd.DataFrame
    Series.progress_apply = tqdm_pandas(Series.progress_apply)
    DataFrame.progress_apply = tqdm_pandas(DataFrame.progress_apply)

    def tqdm_pandas():
        raise TypeError("Please use `tqdm.pandas()`.")
except ImportError:
    pass

# Generated at 2022-06-24 09:42:34.640380
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .std import tqdm_pandas as t2p
    from .std import tqdm
    from .std import pandas
    from .std import np
    from .std import time
    from .std import pd

    with tqdm(total=10, ascii=True, desc=True) as t:
        t2p(t, leave=True)
        df = pd.DataFrame(np.random.randn(100000, 2))
        time.sleep(.05)
        t.close()
        df.progress_apply(t.update, axis=1)

# Generated at 2022-06-24 09:42:43.126113
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    tqdm_pandas() test for Travis CI and PyPi.
    """
    try:
        import pandas as pd
        from tqdm import tqdm
        from tqdm import trange
    except Exception:
        return

    # Test tqdm_pandas(tqdm_func)
    tqdm_pandas(tqdm)

    # Test tqdm_pandas(tqdm_obj)
    tqdm_pandas(tqdm(0))

    # Test tqdm_pandas(tqdm_cls)
    tqdm_pandas(tqdm.__class__)

    # Test tqdm_pandas(tqdm_cls)

# Generated at 2022-06-24 09:42:52.102659
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas

    def get_sample_df():
        return pd.DataFrame([
            {'id': 1, 'name': 'A'},
            {'id': 2, 'name': 'B'},
            {'id': 3, 'name': 'C'},
            {'id': 4, 'name': 'D'},
            {'id': 5, 'name': 'E'},
            {'id': 6, 'name': 'F'},
        ])

    df = get_sample_df()
    assert 'sum' not in df


# Generated at 2022-06-24 09:43:00.090003
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    df = pandas.DataFrame(range(10))
    with tqdm(total=len(df)) as pbar:
        def slow_sum(x):
            sleep(0.1)
            return sum(x)
        df.progress_apply(slow_sum, axis=1, meta=('sum', int))
    assert pbar.n == pbar.total == len(df)
    assert pbar.last_print_n == 1


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:06.466642
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.contrib import pandas
    from pandas import DataFrame

    DataFrame.progress_apply = pandas.progress_apply
    df = DataFrame(index=range(1000))

    for i in range(100):
        tqdm_pandas(tqdm(desc='test_tqdm_pandas'), leave=False, file=sys.stdout)(
            df.progress_apply)(lambda x: x)

# Generated at 2022-06-24 09:43:17.018932
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    # Example 1
    df = pd.DataFrame({"a": np.random.randint(1, 100, 100),
                       "b": [i for i in range(100)],
                       "c": [str(i) for i in range(100)]})
    with tqdm_pandas(total=len(df)) as pbar:
        def display(x):
            pbar.update()
            if x.a < 10:
                return True
            else:
                return False
        df.progress_apply(display, axis=1)

    # Example 2
    with tqdm_pandas(df) as pbar:
        df.groupby("c").progress_apply(len)

    # Example 3
    # expects failure

# Generated at 2022-06-24 09:43:24.283723
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(
        np.random.random((100000, 4)), columns=list('ABCD'))

    def sqr(x):
        return x ** 2

    assert (tqdm_pandas(tqdm, desc='Sqr')
            .groupby('A')['B', 'C']
            .progress_apply(sqr)
            .reset_index()
            .equals(df.groupby('A')['B', 'C'].apply(sqr).reset_index()))


if __name__ == '__main__':
    import pandas as pd
    from tqdm import tqdm


# Generated at 2022-06-24 09:43:34.567444
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm = tqdm_pandas
    import pandas as pd
    df = pd.DataFrame({'A': [1, 2, 3], 'B': [2, 3, 4]})
    assert df.groupby('A').progress_apply(lambda x: x.sum()).equals(df)
    assert df.groupby('A').progress_apply(lambda x: x.sum()).equals(df)
    with tqdm(total=1, leave=False) as t:
        assert df.groupby('A').progress_apply(lambda x: x.sum()).equals(df)
    with tqdm(total=1, leave=False) as t:
        assert df.groupby('A').progress_apply(lambda x: x.sum()).equals(df)



# Generated at 2022-06-24 09:43:37.958172
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    data = np.random.normal(0, 1, size=(100, 2))
    df = pd.DataFrame(data, columns=['v1', 'v2'])
    res = df.groupby('v1').progress_apply(np.mean)
    assert res.shape == (100, 1)

# Generated at 2022-06-24 09:43:48.468823
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    # Test automatic tqdm conversion
    df = DataFrame([dict(a=1, b=2), dict(a=3, b=4)])
    assert df.groupby('b', as_index=True).progress_apply(len) == [2, 2]

    # Test manual tqdm conversion
    tqdm_pandas(tqdm())
    assert df.groupby('b', as_index=True).progress_apply(len) == [2, 2]

    # Test delayed tqdm conversion
    tqdm_pandas(tqdm)
    assert df.groupby('b', as_index=True).progress_apply(len) == [2, 2]

    # Test delayed tqdm subclass conversion

# Generated at 2022-06-24 09:43:49.896860
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)



# Generated at 2022-06-24 09:44:00.907927
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas function"""
    import inspect
    try:
        exec('from tqdm import tqdm_pandas')
    except ImportError:
        return
    wrapped_tqdm_pandas = tqdm_pandas
    from tqdm import tqdm, tqdm_pandas
    assert inspect.getsource(tqdm_pandas) == inspect.getsource(wrapped_tqdm_pandas)
    for tcls in [tqdm, tqdm_pandas]:
        tcls.pandas = lambda **kw: 1
        tqdm_pandas(tcls)
        assert tcls.pandas() == 1

# Generated at 2022-06-24 09:44:11.118486
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib.tests import pretest_posttest
    import pandas as pd
    import numpy as np
    import functools

    def test(tqdm_pandas):
        T = functools.partial(tqdm_pandas, mininterval=0.01)
        df = pd.DataFrame(np.random.rand(1000, 10), columns=list('ABCDEFGHIJ'))

        @T
        def a(df):
            return df.mean()

        @T
        def b(df):
            return df.groupby('A').sum()

        assert (a(df) == df.mean()).all()
        assert (b(df) == df.groupby('A').sum()).size


# Generated at 2022-06-24 09:44:16.914061
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import trange
    tqdm_pandas(trange(1), pandas=True)
    tqdm_pandas(trange(1), pandas=False)
    tqdm_pandas(trange(1), pandas=None)
    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(trange(1), pandas=None)
        assert len(w) == 2  # 2 warnings: pandas on & off
        assert w[0].category == DeprecationWarning
        assert str(w[0].message) == 'Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.'

# Generated at 2022-06-24 09:44:24.925950
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def progressable_apply(df, *args, **kwargs):
        apply_fn = kwargs.pop('_apply_fn', None)
        progress_bar = kwargs.pop('progress_bar', None)
        if progress_bar:
            return progress_bar([apply_fn(g) for _, g in df.groupby(*args, **kwargs)])
        else:
            return df.groupby(*args, **kwargs).apply(apply_fn)

    def progress_apply(df, *args, **kwargs):
        from tqdm.std import tqdm
        if isinstance(kwargs.get('progress_bar', None), type):
            tqdm_type = kwargs.pop('progress_bar')

# Generated at 2022-06-24 09:44:35.268331
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    # Prepare data
    df = pd.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    df = pd.concat([df, df], axis=1)
    df['C'] = df.apply(lambda x: x.sum(), axis=1)

    # Simple aggregate
    for cls in [tqdm, tqdm_notebook]:
        cls.pandas(desc="test")
        assert df.groupby('B').progress_apply(len)['A'] == 3
        cls.pandas(desc="test", unit="len(group)")
        assert df.groupby('B').progress_apply(len)['A'] == 3

# Generated at 2022-06-24 09:44:39.058856
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tnrange

    df = DataFrame({"a": [1, 2, 3]})
    for i in tnrange(2):
        df = df.progress_apply(lambda x: x.sum())
        assert (df.sum() == 6).all(), df

    for i in tnrange(2):
        df = tnrange(2).progress_apply(lambda x: x)
        assert (df.sum() == 3).all(), df

    df = tnrange(2).progress_apply(lambda x: x)
    assert (df.sum() == 3).all(), df


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:46.490615
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    # Create the DataFrame
    df = pd.DataFrame({"x": np.random.rand(100)})

    # Register the `tqdm` instance already
    # set on `tqdm.pandas`
    tqdm_pandas(tqdm(**tqdm.get_default_kwargs()), desc='test tqdm')

    # Apply a function through the `progress_apply` interface
    df.groupby("C").progress_apply(lambda x: x * 2)



# Generated at 2022-06-24 09:44:51.871877
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test for function tqdm_pandas
    """
    try:
        from tqdm.autonotebook import tqdm as _tqdm

        tqdm = _tqdm
    except ModuleNotFoundError:
        tqdm = tqdm_pandas

    tqdm(tqdm_pandas=tqdm_pandas)

# Generated at 2022-06-24 09:44:57.601527
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    from tqdm import tqdm
    tqdm_pandas(tqdm(total=100))
    tqdm_pandas(tqdm)
    tqdm.pandas(total=100)
    tqdm.pandas()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:00.759433
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    tqdm_pandas(tqdm)
    assert tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:45:02.564042
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    x = tqdm_pandas(tqdm(total=1000), desc='x')
    assert isinstance(x, type(tqdm()))

# Generated at 2022-06-24 09:45:11.373934
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    "Tests function tqdm_pandas for basic behaviour"
    import sys
    try:
        sys.modules['pandas']
    except KeyError:
        print("SKIP: 'pandas' module not found; skipping test_tqdm_pandas()")
        return

    import pandas as pd
    from pandas import DataFrame

    # Setup
    DataFrame.progress_apply = None  # Force using tqdm.pandas()
    l = [i % 5 + 1 for i in range(20)]
    df = DataFrame(l, columns=['val'])

    # Test tqdm_pandas()
    tqdm = tqdm_pandas(total=len(df), desc='testing...')

# Generated at 2022-06-24 09:45:21.648436
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame as pd
    from numpy import arange
    from tqdm import tqdm, trange
    from time import sleep
    x = pd(arange(100000))
    y = pd(arange(100000))
    for i in trange(3):
        for j in trange(3):
            sleep(0.01)
    for i in tqdm(range(3)):
        for j in tqdm(range(3)):
            sleep(0.01)
    with trange(3) as T:
        for i in T:
            for j in tqdm(range(3)):
                sleep(0.01)
            T.set_description('i = {}'.format(i))

# Generated at 2022-06-24 09:45:25.753960
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({'a': [1,2,3]})
    tqdm_pandas(df.progress_apply(lambda x: x))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:32.419736
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Check the tqdm_pandas adapter
    import pandas as pd
    import numpy as np
    import tqdm

    t = tqdm.tqdm()
    t._instances = set()  # avoid dummy instance creation
    tqdm_pandas(t)
    assert 'pandas' in t.__dict__
    assert t.pandas
    df = pd.DataFrame(dict(a=[1, 2, 3, 4], b=[1, 1, 2, 2], c=np.random.rand(4)))
    df.groupby("b").progress_apply(lambda x: x)



# Generated at 2022-06-24 09:45:42.339847
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test to check if registered tqdm is correctly being called.
    """

    import pandas
    from tqdm import TqdmDeprecationWarning

    def bar(x):
        return x

    # test registration
    TqdmDeprecationWarning.ignore = True
    tqdm_pandas(tclass=tqdm)
    with warnings.catch_warnings(record=True) as w:
        df = pandas.DataFrame([1, 2, 3])
        df.groupby(by=[0]).progress_apply(bar)
        assert len(w) == 0
    TqdmDeprecationWarning.ignore = False

    # test if correctly called
    TqdmDeprecationWarning.ignore = True
    tqdm_pandas(tqdm(total=3))

# Generated at 2022-06-24 09:45:51.647253
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    if 'pandas' in sys.modules:
        try:
            # test both tqdm_pandas(tqdm) and tqdm_pandas(tqdm(...)) use cases
            for tclass in (tqdm, tqdm()):
                tqdm_pandas(tclass)
                pandas.Series(range(5)).groupby(
                    lambda x: (x + 1) % 3).progress_apply(lambda x: x.sum())
                assert pandas.__version__ < '0.17.0' or tclass.get_instances()
        finally:
            super(_tqdm_pandas, tqdm).clear_instances()