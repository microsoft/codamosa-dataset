

# Generated at 2022-06-24 09:35:37.579684
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:35:44.011981
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randn(1000, 4), columns=list('ABCD'))
    df_group = df.groupby(lambda x: x % 10)

    # Example-1
    with tqdm(total=df_group.ngroups) as pbar:
        df_group.progress_apply(lambda x: x ** 2).reset_index()
        pbar.update()

    # Example-2
    tqdm_pandas(tqdm())
    with tqdm(total=df_group.ngroups) as pbar:
        df_group.progress_apply(lambda x: x ** 2).reset_index()
        pbar.update()


test_tqdm_pandas()

# Generated at 2022-06-24 09:35:55.292119
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange
    import pandas as pd
    from numpy.random import randn
    from pandas import DataFrame
    from pandas import concat
    from pandas.core.groupby import DataFrameGroupBy

    # test automatic adapter
    with tqdm(total=100, smoothing=0, ascii=True) as t:
        tqdm_pandas(t)
        assert hasattr(DataFrameGroupBy, 'progress_apply')
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
            # tqdm_pandas(t)
        try:
            raise IndexError()
        except Exception:
            t.close()

    # test manual adapter

# Generated at 2022-06-24 09:36:00.595457
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from ._tqdm_pandas import tqdm_pandas
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    for tclass in [tqdm, tqdm(leave=True)]:
        tqdm_pandas(tclass)
        import time
        from tqdm import trange
        time.sleep(1)

        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

        # Progress bar
        res = df.progress_apply(lambda x: x**2)
        # Basic speed test
        res = df.progress_apply(lambda x: x**2, axis=1)
        # Basic speed test

# Generated at 2022-06-24 09:36:09.870082
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        tqdm = tqdm_pandas(tqdm)

        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
        df['y'] = df.progress_apply(lambda x: x[0] + x[1] + x[2] + x[3] + x[4] + x[5], axis=1)
        result = list(df['y'].values)
    except (ModuleNotFoundError, ImportError):
        return

    from io import StringIO
    buf = StringIO()
    old = sys.stderr
    try:
        sys.stderr = buf
        tqdm_pandas(tqdm)
    finally:
        sys.st

# Generated at 2022-06-24 09:36:19.426084
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    import numpy as np

    tqdm_pandas(tqdm(_range(100), desc='bar'))
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_rows', None)
    pd.set_option('max_colwidth', None)
    np.random.seed(4)
    n = 100
    df = pd.DataFrame(np.random.randint(0, n, size=(n // 10, n // 20)))
    df.groupby(0).progress_apply(lambda x: x)
    df.groupby(0).progress_apply(np.sqrt)

# Generated at 2022-06-24 09:36:28.618367
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    try:  # pandas < 0.18
        from pandas.tools.tile import _tile_slices
    except ImportError:
        from pandas.core.reshape.tile import _tile_slices

    def test_tiled(rows, chunksize):
        a = np.arange(rows)
        b = np.arange(rows) * 2
        df = pd.DataFrame(dict(a=a, b=b))
        for _ in _tile_slices(df.index, chunksize):
            pass
        return df


# Generated at 2022-06-24 09:36:30.457026
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm.pandas(desc="")


# Main

# Generated at 2022-06-24 09:36:37.604051
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests the `tqdm_pandas` function:
    """
    from pandas import DataFrame
    tqdm = tqdm_notebook
    tqdm.pandas()
    try:
        # TODO: use `assert_series_equal`/`assert_frame_equal` as soon as they
        #  become available in pandas
        assert_frame_equal(DataFrame(range(1, 11)).groupby(1).progress_apply(lambda x: x),
                           DataFrame(range(1, 11)))
    finally:
        tqdm.pandas(False)



# Generated at 2022-06-24 09:36:46.663109
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({'c': ['a', 'b'],
                       'd': ['c', 'd'],
                       'e': ['f', 'g']})
    df.groupby(['c', 'd']).progress_apply(lambda x: x['e'])
    df.groupby(['c', 'd']).progress_apply(lambda x: x)

    with tqdm(pandas=True) as t:
        df.groupby(['c', 'd']).progress_apply(lambda x: x)
        assert t.n == 2

    for tclass in [tqdm, tqdm.tqdm]:
        tqdm_pandas(tclass)

# Generated at 2022-06-24 09:36:52.665525
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm, pandas

    df = pandas.DataFrame([list(range(10)), list(range(10))])
    with tqdm.tqdm_pandas(df.groupby(df.columns.tolist()).progress_apply, ncols=2000) as pbar:
        pbar.set_description("Unit test tqdm_pandas")
        pbar.set_postfix(order=1)
        pbar.reset(mininterval=0.001)
        pbar.close()
        pbar.close(True)
        pbar.miniters = 0
        pbar.desc = "Unit test tqdm_pandas"
        pbar.dynamic_ncols = True


# Generated at 2022-06-24 09:36:55.119791
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm())

        tqdm_pandas(tqdm_notebook)
        tqdm_pandas(tqdm_notebook())
    except ImportError:
        pass



# Generated at 2022-06-24 09:37:06.697562
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm as tqdm_lib
    from pandas import DataFrame as pd_DataFrame
    from numpy import random as np_random
    from pandas import Series as pd_Series
    from pandas import concat as pd_concat

    # tqdm_pandas(tqdm_lib(range(100)), leave=False)
    tqdm_pandas(tqdm_lib, leave=False)(range(100))

    def test_progress_apply(df, func, **kwargs):
        """
        Loop over DataFrame rows and execute `func(progress_apply=i)`
        """
        progress_apply = kwargs.pop('progress_apply', None)
        if progress_apply:
            progress = tqdm_kwargs.get('progress', True)

# Generated at 2022-06-24 09:37:15.907424
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas
    dt = pandas.DataFrame({
        'a': [1, 2, 3, 4, 5, 6, 7, 8, 9],
        'b': [3, 4, 5, 6, 7, 5, 6, 7, 8],
        'c': [5, 6, 7, 8, 9, 5, 6, 7, 8]
    })

    # tqdm_pandas(tqdm.tqdm, total=len(dt.index))
    # tqdm_pandas(tqdm.tqdm(total=len(dt.index)))

    for x in tqdm.pandas(total=len(dt.index), desc="Test test_tqdm_pandas()"):
        print(x)



# Generated at 2022-06-24 09:37:23.835048
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.util.testing import makeCustomDataframe as mkdf
    df = mkdf(10, 3)
    dfg = df.groupby(['A', 'B'], as_index=False)
    tqdm_pandas(tqdm, desc='test')
    new_df = dfg.progress_apply(lambda x: x * 2 * x.sum())

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:31.307636
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # This is a test case for tqdm_pandas
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    returned_list = []
    tqdm_pandas(tqdm)
    dataframe = pd.DataFrame({'x': np.arange(0, 10)})
    dataframe.groupby('x').progress_apply(lambda x: returned_list.append(x))

# Generated at 2022-06-24 09:37:37.895326
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.autonotebook import tqdm
    t = tqdm(total=4)
    for i in range(4):
        t.update()
    assert t.n == 4
    t.close()
    tqdm_pandas(tqdm)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:42.043898
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import arange
    from numpy.random import choice
    from tqdm import tqdm_pandas as tpdm

    data = DataFrame()
    data['col'] = choice(arange(500), 100, replace=True)
    data['col'].groupby(data['col']).progress_apply(lambda x: None)
    tpdm(tpdm(tpdm).DeprecatedTqdmFile(None))


# Remove after checking deprecated warning
del test_tqdm_pandas

# Generated at 2022-06-24 09:37:52.832407
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for tqdm_pandas."""
    from tqdm.autonotebook import tqdm, tqdm_pandas

    df = pd.DataFrame({
        'data': range(100),
        'group': list(np.random.randint(0, 5, 100))})
    tqdm_pandas(tqdm)
    for i in tqdm(range(10)):
        df.groupby('group').progress_apply(lambda x: x.sum())
    tqdm_pandas(tqdm(total=7))
    for i in tqdm(range(10)):
        df.groupby('group').progress_apply(lambda x: x.sum())
    tqdm_pandas(tqdm(max=10))

# Generated at 2022-06-24 09:38:01.407385
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    pd.DataFrame(range(100)).progress_apply(lambda x: x*2,
                tqdm_kwargs={'desc': 'foo'})

    # delayed adapter case
    with tqdm(range(1)) as t:
        def tqdm(tclass):
            return tclass
        tqdm_pandas(tqdm, desc='bar')

    # delayed tclass case
    with tqdm(range(1)) as t:
        tqdm_pandas(t.__class__, desc='baz')

# Generated at 2022-06-24 09:38:11.457406
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import tqdm_gui

# Generated at 2022-06-24 09:38:18.481281
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange
    import pandas as pd
    from numpy.random import random
    from time import sleep

    df = pd.DataFrame({'a': random(1000), 'b': random(1000), 'c': random(1000)})

    with tqdm(total=len(df)) as pbar:
        def progress(x):
            pbar.update()
            return x

        print(df.progress_apply(progress))

    with trange(len(df)) as pbar:
        @tqdm_pandas(pbar)
        def progress(x):
            sleep(0.001)
            return x

        print(df.progress_apply(progress))


# Generated at 2022-06-24 09:38:27.727205
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    import numpy as np
    n = 100
    data = DataFrame(np.random.randn(n, n))
    data.progress_apply(lambda x: [x] * 100)
    tqdm_pandas(tqdm())
    data.progress_apply(lambda x: [x] * 100)
    tqdm_pandas(tqdm(leave=False))
    data.progress_apply(lambda x: [x] * 100)
    tqdm_pandas(tqdm(leave=False))
    data.progress_apply(lambda x: [x] * 100)
    tqdm_pandas(tqdm(leave=False))

# Generated at 2022-06-24 09:38:31.094512
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange

    list(tqdm_pandas(trange(10), desc='test'))
    return True

if __name__ == '__main__':
    assert test_tqdm_pandas()

# Generated at 2022-06-24 09:38:42.575466
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    df = pd.DataFrame([dict(x=int(i ** 2)) for i in range(20)])
    try:
        del os.environ['COLUMNS']
    except KeyError:
        pass

    def progress_apply(df):
        kwargs = dict(leave=False, smoothing=1,
                      total=len(df))
        for _ in tqdm_pandas(df.progress_apply, **kwargs):
            pass

    progress_apply(df)
    progress_apply(df)

    with tqdm_pandas(total=len(df)) as t:
        for _ in df.progress_apply(func=lambda x: x, t=t):
            pass

    t = t

# Generated at 2022-06-24 09:38:48.536156
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm.pandas()
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(unit='t'))
    tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm.tqdm(unit='x'))
    import pandas as pd
    pd.DataFrame([1, 2, 3]).progress_apply(lambda x: x * 2)

# Generated at 2022-06-24 09:38:59.748621
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange, tqdm_pandas
    from pandas import DataFrame, Series
    import numpy as np
    from time import sleep

    print('Testing tqdm_pandas()...', end='')

    with trange(10) as pbar:
        pbar.reset()
        pbar.total = 100
        pbar.update(0)
        tqdm_pandas(pbar)
        # Using deprecated pandas.tools.plotting.progress_apply
        pbar.update(0)
        DataFrame([np.arange(100)]).progress_apply(lambda x: sleep(0.01))
        # Using modern pandas.core.groupby.DataFrameGroupBy.progress_apply
        pbar.update(0)

# Generated at 2022-06-24 09:39:04.873356
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    tqdm_pandas(tqdm)

    df = pd.DataFrame(np.random.randn(100, 2))
    df.groupby([1, 2, 3]).progress_apply(lambda x: x * x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:12.507051
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import tqdm_notebook as tqdm

    tqdm.pandas()
    tqdm_pandas(tqdm_notebook)  # deprecated

    def test_func(df):
        for x in df:
            pass

    df = DataFrame({'a': list(range(1000)), 'b': list(range(1000))})
    assert isinstance(df.groupby('a').progress_apply(test_func), DataFrameGroupBy)

# Generated at 2022-06-24 09:39:16.133844
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.contrib.tests import pandas

    tqdm_pandas(tqdm)
    # for some reason fails on travis
    # pandas.test_tqdm_apply()

# Generated at 2022-06-24 09:39:25.865273
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm

    pandas.DataFrame({'a': [1, 2, 3]}).groupby('a').progress_apply(lambda x: x)
    pandas.DataFrame({'a': [1, 2, 3]}).groupby('a').progress_apply(lambda x: x)
    tqdm.pandas()
    pandas.DataFrame({'a': [1, 2, 3]}).groupby('a').progress_apply(lambda x: x)
    pandas.DataFrame({'a': [1, 2, 3]}).groupby('a').progress_apply(lambda x: x)
    tqdm_pandas(tqdm())

# Generated at 2022-06-24 09:39:35.786594
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import trange
    from tqdm import tqdm

    df = pd.DataFrame(dict(a=range(10), b=range(10)))

    def noop(x):
        pass

    # Test without progressbar
    df.groupby('a').progress_apply(noop)
    df.groupby('a').progress_apply(noop, axis=1)

    # Test with progressbar
    with trange(10) as t:
        df.groupby('a').progress_apply(noop, t=t)
        df.groupby('a').progress_apply(noop, axis=1, t=t)

    # Test deprecated tqdm_pandas()
    pandas_tqdm = tqdm_pandas

# Generated at 2022-06-24 09:39:42.374434
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    a = pd.DataFrame({'a': [1, 2, 4, 7, 11, 24, 98]})
    tqdm_pandas(tclass=tqdm, desc='test tqdm_pandas')
    b = a.progress_apply(lambda r: r.a)
    assert(a['a'].equals(b))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:50.431364
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    try:
        import pandas
    except ImportError:  # pragma: no cover
        print('Skipping pandas tests (pandas not found)')
        return
    import warnings
    from tqdm import tqdm
    from tqdm import TqdmDeprecationWarning

    # Tests normal operation
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        tqdm_pandas(tqdm(**tqdm_test_kwargs(leave=True)))
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
    with warnings.catch_warnings(record=True) as w:
        warnings.simple

# Generated at 2022-06-24 09:40:00.802110
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._tqdm_pandas_impl import TqdmPandasProgressBar
    from pandas import DataFrame, Series
    import pandas as pd
    import numpy as np
    from numpy.random import randint, seed

    def _test(df, func, *args, **kwargs):
        df_bar = func(df, *args, **kwargs)
        df_no_bar = func(df, *args, show_progressbar=False, **kwargs)
        assert (df_bar == df_no_bar).all().all()

    # Test Series
    seed(123)
    a = Series(randint(0, 100, 10))
    _test(a, Series.map)
    _test(a, Series.apply)

# Generated at 2022-06-24 09:40:11.284058
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 3)), columns=['A', 'B', 'C'])
    tqdm = tqdm_pandas(tqdm, leave=True, total=len(df))
    df.groupby(by=['A', 'B']).progress_apply(lambda x: x.mean())
    tqdm.close()


try:
    from IPython.core import magic_arguments
    from IPython.core.magic import line_magic, Magics, magics_class, cell_magic
except ImportError:
    raise RuntimeError('IPython is required for tqdm_notebook!')



# Generated at 2022-06-24 09:40:17.228551
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    num_rows = 1000
    num_cols = 10
    # test dataframe
    df = pd.DataFrame(
        np.random.randint(0, 100, size=(num_rows, num_cols)),
        columns=list('ABCDEFGHIJ'))
    # test function
    def increment(x):
        return x + 1
    # result you should get
    result = df.apply(increment)
    import tqdm
    tqdm.pandas()
    # test if tqdm works for pandas
    for _ in range(10):
        assert (df.progress_apply(increment) == result).all().all()



# Generated at 2022-06-24 09:40:26.302050
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy import arange
    from time import sleep

    df = DataFrame({'a': arange(20), 'b': arange(20)})

    def mysum(a, b):
        sleep(.05)
        return a.sum() + b.sum()

    # With return
    assert df.progress_apply(mysum, axis=1, result_type='reduce').sum() == sum(
        row.a+row.b for row in df.itertuples()) == 1780

    # No return
    tqdm_pandas(tqdm)
    df.progress_apply(mysum, axis=1, result_type=None)


if __name__ == '__main__':
    test_tqdm_

# Generated at 2022-06-24 09:40:33.622066
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    tqdm_pandas(pd.DataFrame([1, 2, 3]).groupby(0).progress_apply(lambda x: x))
    tqdm_pandas(pd.DataFrame([1, 2, 3]).groupby(0).apply(lambda x: x))



# Generated at 2022-06-24 09:40:42.118138
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(dict(a=np.random.random(10000)))
    tqdm_pandas(tqdm, leave=False)
    df.groupby('a').progress_apply(lambda x: x)


if __name__ == '__main__':
    from tqdm.autonotebook import tqdm
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(dict(a=np.random.random(10000)))
    tqdm_pandas(tqdm, leave=False)
    df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:40:48.934365
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import numpy as np
        import pandas as pd
        from tqdm import tqdm
        pd.DataFrame(1, columns=['a']).groupby(
            'a').progress_apply(lambda x: np.random.normal(size=len(x)))
    except (ImportError, AttributeError):
        pass
    else:
        raise RuntimeError("Test failed")
    tqdm_pandas('tqdm')
    pd.DataFrame(1, columns=['a']).groupby(
        'a').progress_apply(lambda x: np.random.normal(size=len(x)))

# Generated at 2022-06-24 09:40:55.606300
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import warnings

    with warnings.catch_warnings(record=True):
        warnings.simplefilter("always")
        tqdm_pandas(tqdm, desc="pandas bar")
        pd.DataFrame({'x': np.arange(10000)}).groupby('x').progress_apply(
            lambda x: 1)
        pd.DataFrame({'x': np.arange(10000)}).groupby('x').progress_apply(
            lambda x: 1, desc="test")



# Generated at 2022-06-24 09:41:03.849497
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy.random import uniform
    from pandas import DataFrame
    from pandas import concat

    tqdm_pandas(tqdm)

    df = DataFrame({'a': uniform(size=100)})

    def f(x):
        return DataFrame({'a': x['a'] + uniform()})

    # Delayed adapter
    df = df.groupby(0).progress_apply(f)
    tqdm_pandas(tqdm, desc='Custom desc').pandas(desc='Custom desc')
    df = df.groupby(0).progress_apply(f)

    # With `desc`
    df = df.groupby(0).progress_apply(f)

# Generated at 2022-06-24 09:41:13.653821
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return None
    from tqdm import tqdm
    # dummy groupby object
    df = pd.DataFrame({'a': list(range(10)),
                       'b': list(range(10))})
    mygroupby = df.groupby(['a'])

    # test adapter
    tqdm.pandas(**{'desc': "mygroupby"})
    assert mygroupby.progress_apply.__dict__['desc'] == "mygroupby"
    assert mygroupby.progress_apply.__dict__['total'] == \
        mygroupby.apply.__dict__['total']
    mygroupby.progress_apply.__dict__['total'] = 10

    # test adapter

# Generated at 2022-06-24 09:41:22.563231
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np

    unique_values = [None, False, 11, 5.5, 'abc', [0], (2, 3), {'a': 1, 'b': 2}]
    combos = itertools.product(unique_values, [None, False], [None, False])

    for use_tqdm in (True, False):
        for (a, b, c) in tqdm(combos, desc="tqdm_pandas"):
            from pandas import DataFrame

            df = DataFrame([(a, b, c)], columns=('a', 'b', 'c'))
            if use_tqdm:
                tclass = tqdm
            else:
                class tclass(tqdm):
                    pass
            tqdm_pandas(tclass)

# Generated at 2022-06-24 09:41:34.215809
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    from tqdm import tqdm, trange, tnrange
    from tqdm._utils import _term_move_up

    # Setup DataFrame
    N = 100000
    df = pd.DataFrame(np.random.randint(0, 100, size=(N, 4)),
                      columns=list('ABCD'), dtype='int64')

    def test_tqdm_pandas_type(tqdm_class):
        tqdm_pandas(tqdm_class)

# Generated at 2022-06-24 09:41:38.826214
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm

    df = pd.DataFrame(np.random.rand(100000, 14))

    # test 1: create instance and register
    t = tqdm()
    tqdm_pandas(t)
    df.progress_apply(lambda x: x.square()).sum()

    for _ in range(3):
        df.progress_apply(lambda x: x.square()).sum()

    # test 2: register with tqdm()
    tqdm_pandas(tqdm())
    df.progress_apply(lambda x: x.square()).sum()

    for _ in range(3):
        df.progress_apply(lambda x: x.square()).sum()



# Generated at 2022-06-24 09:41:44.541377
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    # Test tqdm_pandas
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm_gui)

test_tqdm_pandas()

# Generated at 2022-06-24 09:41:51.365711
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    # only run this test if pandas and tqdm are installed
    if tqdm.tqdm is not None and pd.DataFrame is not None:
        from multiprocessing import Process, Manager
        from tqdm import format_interval

        for tclass in [tqdm.tqdm, tqdm.tqdm_notebook]:
            # test with tqdm.tqdm
            df = pd.DataFrame(
                {'value': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                 'label': ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']})
            result = df.groupby('label').progress_apply

# Generated at 2022-06-24 09:42:01.718794
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        raise unittest.SkipTest()

    t = tqdm_pandas(tqdm())
    t.pandas()

    df = pd.DataFrame(np.random.rand(1000, 1000))
    res = df.progress_apply(lambda x: x.sum())
    res = df.progress_aggregate(res, lambda x: x.sum())

    # test miniters
    with tqdm(total=1000, miniters=10, unit='B', unit_scale=False,
              dynamic_ncols=True) as t:
        t.update(5)
        assert t.n == 5
        t.update(5)
        assert t.n == 10

    # test nested

# Generated at 2022-06-24 09:42:11.571258
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    try:
        import tqdm
    except ImportError:
        raise unittest.SkipTest('tqdm not installed')
    df = pd.DataFrame({'a': np.random.randn(1000)})

    def slow_function(x):
        time.sleep(0.005)
        return x

    tqdm.tqdm_pandas(tqdm.tqdm())
    df['b'] = df['a'].progress_apply(slow_function)
    tqdm.tqdm_pandas(tqdm.tqdm())
    df['c'] = df['b'].progress_apply(slow_function)

# Generated at 2022-06-24 09:42:19.449471
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas  # NOQA
    try:
        import pandas as pd
    except ImportError:
        return  # make sure to run "pip install tqdm[pandas]" first
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    total = df[0].count()

    # Register `pandas.progress_apply` and `pandas.Series.map_apply` with `tqdm`
    tqdm.pandas(desc="my bar!")

    # Now you can use `progress_apply` instead of `apply`
    # and `progress_map` instead of `map`
    # and `progress_apply` will automatically display a progress bar,
    # and use `

# Generated at 2022-06-24 09:42:29.594491
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        from tqdm.contrib.test import NEW_PYPY, TOLERANCE
        from tqdm.auto import tqdm
    except ImportError:
        return
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        np.random.seed(1)
        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
        total = len(df)

        # Register `tqdm` instance with `pandas`
        tqdm_pandas(tqdm, unit="pandas")

        # Now you can use `progress_apply` instead of `apply`
        df.groupby(0).progress_apply(lambda x: x)

        #

# Generated at 2022-06-24 09:42:34.864648
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random

    tqdm_pandas(
        DataFrame(
            random.rand(100, 100)).groupby(0).progress_apply(
            lambda x: x * 2))

######################################################################
# tqdm_pandas
# ^^^^^^^^^^^
# Decorator to add `tqdm` support to `DataFrameGroupBy.progress_apply`.
#
# Usage::
#
#   >>> @tqdm_pandas
#   ... def group_apply(df):
#   ...     return df.groupby(0).progress_apply(lambda x: x * 2)
#

# Generated at 2022-06-24 09:42:39.793415
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # tqdm_pandas('')
    tqdm_pandas(1)
    tqdm_pandas(tqdm(total=5))


if __name__ == '__main__':
    test_tqdm_pandas()

# If you want to enable pandas integration in your code, you can use the following code:
tqdm.pandas()

# Generated at 2022-06-24 09:42:49.849000
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        from tqdm import tqdm
        assert tqdm(['a', 'b'], desc='test1', leave=False).n == 2
        with tqdm(['c', 'd'], desc='test2', leave=False) as t:
            assert t.n == 2
            assert 'test2' in repr(t)
    except ImportError:
        pass
    try:
        from tqdm import trange
        assert trange(3, desc='test3', leave=False).n == 3
        with trange(4, desc='test4', leave=False) as t:
            assert t.n == 4
            assert 'test4' in repr(t)
    except ImportError:
        pass
    # Test tqdm_pandas

# Generated at 2022-06-24 09:42:54.037438
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    with tqdm.tqdm_pandas(total=10000) as t:
        pd.Series(np.arange(10000)).groupby(np.arange(10000) % 100).progress_apply(
            lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:00.796980
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    tqdm_pandas(tqdm())
    tqdm_pandas(tclass=tqdm())

    # Test for delayed tqdm_pandas adapter (tqdm_pandas(tqdm))
    with warnings.catch_warnings():  # tqdm deprecation
        warnings.simplefilter('ignore')
        tqdm_pandas(tqdm)

    try:
        import pandas
        has_pandas = True
    except ImportError:
        has_pandas = False

# Generated at 2022-06-24 09:43:10.825581
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, pandas
    from pandas import Series, DataFrame

    tclass = tqdm(total=10)
    tqdm_pandas(tclass)
    for i in range(10):
        tclass.update()

    series = Series(range(10))
    tqdm.pandas(**{'tclass': tclass})
    series.progress_apply(lambda x: x * 2)

    test_df = DataFrame({'a': [1, 2], 'b': [3, 4]})
    tqdm.pandas(**{'tclass': tclass})
    test_df.groupby('a').progress_apply(lambda x: x * 2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:20.840209
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import tqdm
    from tqdm import TqdmExperimentalWarning, TqdmDeprecationWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        tqdm_pandas(tqdm)

        df = pandas.DataFrame({'a': [1, 2, 3, 4]})
        assert list(df.groupby('a').progress_apply(lambda k: k)) == [df, df, df, df]
    with warnings.catch_warnings():
        warnings.simplefilter("error", category=TqdmExperimentalWarning)
        with pytest.raises(TqdmExperimentalWarning):
            test_tqdm_p

# Generated at 2022-06-24 09:43:29.760163
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import warnings
    import pandas as pd
    import numpy as np
    list_df = []
    for i in range(10000):
        df = pd.DataFrame(np.random.random(size=(1000, 3)), columns=["a", "b", "c"])
        list_df.append(df)
    df = pd.concat(list_df)
    with warnings.catch_warnings(record=True) as warn:
        tqdm_pandas(tqdm(), file=open("tmp.txt", "a"))
        df.groupby("a").progress_apply(np.mean)

    assert len(warn) == 1

# Generated at 2022-06-24 09:43:38.090879
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    np.random.seed(1337)
    df = pd.DataFrame(data={
        'A': np.random.randint(0, 10, size=10),
        'B': np.random.randint(0, 100, size=10),
        'C': np.random.randint(0, 1000, size=10),
        'D': np.random.randint(0, 10000, size=10)},
        index=pd.date_range("2000-01-01", "2000-01-10"))

    # Unit test for tqdm_pandas using deprecated function call
    tqdm_pandas(tqdm, leave=False)
    res = df.groupby('A').progress_apply(lambda x: x.sum())
    assert isinstance(res, pd.DataFrame)  #

# Generated at 2022-06-24 09:43:48.622653
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(
        {'x': np.random.normal(0, 1, (100000, 1)),
         'y': np.random.normal(0, 1, (100000, 1))})
    df['z'] = df.apply(lambda row: row['x'] ** 2 + row['y'] ** 2, axis=1)
    tqdm(df, total=len(df), leave=False,
         desc='tqdm_pandas(tqdm, total=len(df))', mininterval=0.1,
         file=sys.stdout)

# Generated at 2022-06-24 09:43:59.588104
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .tests import tqdm, pandas, TestCase

    class TestTqdmPandas(TestCase):
        def test_tqdm_pandas(self):
            try:
                import pandas as _  # NOQA
            except ImportError:
                self.skipTest("requires pandas")

            from tqdm import tqdm
            with tqdm(total=10, leave=False) as t:
                t.pandas(desc="BAR")
                self.assertTrue(hasattr(pandas, 'core'))
                self.assertTrue(hasattr(pandas.core, 'groupby'))
                self.assertTrue(hasattr(pandas.core.groupby, 'DataFrameGroupBy'))

# Generated at 2022-06-24 09:44:07.982060
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import pandas
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=list('ABCDEF'))

    # We must use `progress_apply` instead of `apply`
    # in order to use `max_rows`
    tqdm_result = df.groupby('A').B.progress_apply(
        lambda x: x ** 2).sum()
    # To use `tqdm_pandas` instead of `progress_apply`,
    # we can do:
    df.groupby('A').B.apply(lambda x: x ** 2).sum()  # NOQA
    tqdm.pandas

# Generated at 2022-06-24 09:44:14.954468
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_notebook

    # Create a pandas dataframe
    df = pd.DataFrame(dict(a=[1, 2, 3], b=[1, 2, 3]))

    # Initialise a tqdm instance
    t = tqdm(total=df.shape[0])

    # Register tqdm instance with `pandas.core.groupby.DataFrameGroupBy.progress_apply`
    tqdm_pandas(t)

    # Apply a function to every row
    def double_row(row, t=t):
        t.update()
        return 2 * row

    df.progress_apply(double_row, axis=1)

    # Initialise a tqdm_notebook instance
    t = tqdm_

# Generated at 2022-06-24 09:44:23.592207
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm
    test_df = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=list('ABCDEF'))
    # We run the function
    tqdm_pandas(tqdm(desc='pandas test'))
    # We make a GroupBy
    ttest = test_df.groupby('A').progress_apply(lambda x: x**2)
    assert ttest is not None

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:33.905046
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import pandas as pd
    import tqdm

    df = pd.DataFrame(dict(a=range(10000, -1, -1), b=range(10000, -1, -1)))

    def add(x, y):
        return x + y

    out = df.groupby(['a', 'b']).progress_apply(add)
    assert out.equals(df.groupby(['a', 'b']).apply(add))

    with tqdm.tqdm() as t:
        tqdm_pandas(t)
        out = df.groupby(['a', 'b']).progress_apply(add)
    assert out.equals(df.groupby(['a', 'b']).apply(add))


# Generated at 2022-06-24 09:44:39.856512
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    from tqdm import tqdm as _tqdm

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        tqdm_pandas(_tqdm)

    assert len(w) == 1
    assert issubclass(w[-1].category, TqdmDeprecationWarning)



# Generated at 2022-06-24 09:44:48.761715
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm.pandas import tqdm_pandas
    from tqdm import tnrange
    import numpy as np

    df = DataFrame({'A': [1] * 5, 'B': [2] * 5})
    M = 100
    df = DataFrame({k: Series(np.random.randint(M, size=M))
                    for k in map(chr, range(ord('a'), ord('z')))})
    assert df.shape == (100, 26)
    # Basic test
    before = list(df.columns)
    tqdm_pandas(df.groupby('a'))
    after = list(df.columns)
    assert before == after


# Generated at 2022-06-24 09:44:57.853966
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    pd.DataFrame(list(range(10))).progress_apply(lambda x: x**2)

    try:
        pd.DataFrame(list(range(10))).progress_apply(lambda x: x**2,
                                                     tclass=tqdm)
    except TqdmDeprecationWarning:
        pass
    else:
        raise AssertionError()

    pd.DataFrame(list(range(10))).progress_apply(lambda x: x**2,
                                                 tqdm_kwargs={'bar_format': '{n}'})


# Generated at 2022-06-24 09:45:07.927456
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd

    def deprecated_tqdm_pandas_test(bar_format, prog_percent, total, **tqdm_kwargs):
        # set default values for testing
        tqdm_kwargs.setdefault('disable', True)
        tqdm_kwargs.setdefault('smoothing', 1)
        tqdm_kwargs.setdefault('mininterval', 0.1)
        tqdm_kwargs.setdefault('unit', 'it')
        tqdm_kwargs.setdefault('unit_scale', False)
        tqdm_kwargs.setdefault('unit_divisor', 1000)

        with tqdm(**tqdm_kwargs) as t:
            tqdm_pandas(t)
           

# Generated at 2022-06-24 09:45:16.096570
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import hashlib
    import pandas as pd
    import time
    time.sleep(0.01)
    from tqdm import tqdm as tqdm_super
    from tqdm.pandas import tqdm as tqdm_pandas_super


# Generated at 2022-06-24 09:45:26.148498
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from math import nan
    from random import randint
    from time import sleep

    # Testing plain tqdm
    df = DataFrame([[randint(0, 100) for i in range(50)]
                    for i in range(20000)])
    print('Test tqdm_pandas with plain tqdm...')
    with tqdm(df.groupby(df.columns.tolist()).progress_apply(min),
              desc='Test tqdm', unit='cols') as t:
        for v, c in zip(t, df.columns.tolist()):
            t.set_postfix(postfix=c)
            sleep(0.02)
    t.close()


# Generated at 2022-06-24 09:45:30.066272
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame([x for x in range(10)])
    df.progress_apply(lambda x: x, 1)
    df.progress_apply(lambda x: x, 1, tclass=tqdm)



# Generated at 2022-06-24 09:45:41.234379
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm import trange
    from tqdm.contrib import DummyTqdmFile

    df = pd.DataFrame(
        np.random.randn(10, 4), columns=['A', 'B', 'C', 'D'])
    with tqdm(total=len(df)) as progress_bar:
        df.progress_apply(lambda x: np.dot(x, x), axis=1,
                          progress_kwargs={'file': DummyTqdmFile(
                              progress_bar=progress_bar)})
