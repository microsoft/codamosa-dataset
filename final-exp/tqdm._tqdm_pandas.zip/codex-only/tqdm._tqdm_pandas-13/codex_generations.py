

# Generated at 2022-06-24 09:35:51.058301
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    df = pd.DataFrame({'A': np.random.randn(10000)})
    with tqdm(total=len(df), file=sys.stderr) as pbar:
        a = df.groupby('A').progress_apply(lambda x: x)
        assert len(a) == 10000

# Generated at 2022-06-24 09:35:53.723400
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm)


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 09:35:57.994862
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from ._tqdm_gui import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm)  # test pandas integration
    df = DataFrame(
        {'city': list('AAABBBCCC'), 'number': [4, 5, 4, 1, 2, 1, 4, 3, 5]})
    df.groupby('city').progress_apply(lambda x: x.sort_values().sum())

# Generated at 2022-06-24 09:36:06.548723
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Will raise an error if pandas is not installed.
    """
    import pandas as pd

    df = pd.DataFrame({'a': [1, 2, 3]})
    tqdm_pandas(df.groupby('a').progress_apply)
    tqdm_pandas(df.groupby('a').progress_apply, leave=True)
    tqdm_pandas(df.groupby('a').progress_apply, ascii=True)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:10.962967
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test function of tqdm_pandas."""
    # test delayed display
    tqdm_pandas(None)
    # test for error message
    try:
        tqdm_pandas('tqdm')
        raise RuntimeError("ExpectedError not raised")
    except TqdmDeprecationWarning:
        pass

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:20.040658
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_notebook as _tqdm_notebook
    from tqdm.contrib.tests import dummy_tqdm
    from tqdm.contrib.tests.pandas import pandas_bar

    tqdm = dummy_tqdm()
    # Dummy pandas
    pd_bar = pd.DataFrame.progress_apply = pandas_bar(tqdm)

    # Test: wrap _tqdm_notebook
    tqdm_notebook = _tqdm_notebook
    try:
        tqdm_pandas(tqdm_notebook, desc='test')
        assert "test" == pd_bar.desc
    finally:
        del tqdm_notebook.pandas
        tqdm

# Generated at 2022-06-24 09:36:25.280933
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame(np.random.random((100, 3)), columns=['A', 'B', 'C'])
    for i in tqdm_pandas(range(10)):
        _ = df.groupby('A').progress_apply(lambda x: x + 1)


if __name__ == '__main__':
    test_tqdm_pandas()
    print("Success")

# Generated at 2022-06-24 09:36:31.898246
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange, tqdm_gui, tqdm_notebook

    if sys.version_info[:2] >= (3, 6):
        tclasses = [tqdm, trange, tqdm_gui, tqdm_notebook]
    else:
        tclasses = [tqdm, trange, tqdm_gui, tqdm_notebook]

    for tclass in tclasses:
        try:
            tqdm_pandas(tclass)
        except Exception:
            pass

# Generated at 2022-06-24 09:36:41.425895
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    # Random dataframe
    df = pd.DataFrame(np.random.randint(0, 1000, size=(10000, 4)), columns=list('ABCD'))

    # Mean of each column
    print('Mean of each column:')
    print(df.progress_apply(np.mean))

    # Cumulative sum of each column
    print('Cumulative sum of each column:')
    print(df.progress_apply(np.cumsum))

if __name__ == '__main__':
    from tqdm.auto import tqdm
    tqdm_pandas(tqdm)
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:49.041112
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    N = 10000
    df = pd.DataFrame({'a': np.random.randint(9999, size=N),
                       'b': np.random.randint(9999, size=N),
                       'c': np.random.randint(9999, size=N)})
    with tqdm(total=N) as t:
        t.pandas(desc='test')
        df.groupby('a').progress_apply(lambda x: x**2)

if __name__ == '__main__':
    from tqdm import _tqdm_pandas
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:53.237674
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    df = pd.DataFrame(np.random.random((100,100)))
    print(df.progress_apply(lambda x:x.mean()).head())


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:58.439532
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Test functionality of tqdm_pandas
    '''
    # This test is somewhat superfluous, as the user would never
    # manually run tqdm_pandas themselves, but just in case...
    import numpy as np
    import pandas as pd
    from tqdm.contrib.concurrent import process_map
    from tqdm import tqdm

    global_counter = 0
    def multi_progress_func_0(x):
        global global_counter
        global_counter = (x + 1) % 3
        return x ** 2

    def multi_progress_func_1(x):
        global global_counter
        global_counter = (x + 2) % 3
        return x ** 2

    def multi_progress_func_2(x):
        global global_counter

# Generated at 2022-06-24 09:37:07.820877
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return  # Not available

    tqdm_pandas(tqdm(total=42))
    tqdm_pandas(tqdm(total=42), smoothing=1)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, smoothing=1)
    tqdm_pandas(tqdm(), smoothing=1)

    df = pd.DataFrame([dict(a=0, b=1)])
    df.groupby('a').progress_apply(lambda _: _)

# Generated at 2022-06-24 09:37:16.808372
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import np

    from tqdm import __main__ as cli
    from tqdm.auto import tqdm

    CLASSES = (tqdm, cli.TqdmTypeWarning)
    try:
        from tqdm import tqdm  # type: ignore
        from tqdm import tqdm_gui  # type: ignore
        from tqdm import tnrange  # type: ignore
        from tqdm import trange  # type: ignore
        CLASSES += (tqdm, tqdm_gui, tnrange, trange,
                    tqdm.tqdm, tqdm_gui.tqdm, tnrange.tqdm, trange.tqdm)
    except (AttributeError, ImportError):
        pass


# Generated at 2022-06-24 09:37:24.980306
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    try:
        import pandas as pd
        import numpy as np
        tqdm_pandas(tqdm, miniters=1)
        df = pd.DataFrame(np.random.randint(0, 100, (1000, 26)),
                          columns=list('ABCDEFGHIJKLMNOPQRSTUVWXYZ'))
        df.groupby(0).progress_apply(lambda x: x**2)
    except Exception:
        pass

# Generated at 2022-06-24 09:37:34.681649
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm_pandas as deprecated_tqdm_pandas
    from tqdm import tqdm

    df = DataFrame({'A': [1, 2, 3], 'B': [2, 3, 4]})

    def wait_apply(x):
        import time
        time.sleep(.01)
        return x

    # deprecated usage
    with tqdm(total=2, desc="deprecated", file=sys.stderr) as deprecated_t:
        assert deprecated_tqdm_pandas(deprecated_t, desc='deprecated', leave=False).apply(wait_apply)
    # normal usage
    with tqdm(total=2, desc="direct", file=sys.stderr) as t:
        df.progress_

# Generated at 2022-06-24 09:37:41.159015
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Python 3.7+
    import pandas as pd
    import numpy as np
    global tqdm

    # create a dataframe
    df = pd.DataFrame({"Col1": np.random.randint(0, 1000, 10), "Col2": np.random.randint(0, 1000, 10)})
    # select rows that is 1000 times greater than Col1 - Col2
    n = 1000

    # tqdm_pandas(list(df.progress_apply(lambda row: row["Col1"] - row["Col2"] < 0, axis=1)))
    tqdm_pandas(tqdm, desc="tqdm_pandas_test")(list(df.progress_apply(lambda row: row["Col1"] - row["Col2"] < 0, axis=1)))




# Generated at 2022-06-24 09:37:48.449672
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'a': range(100)})

    with tqdm.tqdm_pandas(total=len(df), desc='Description test') as t:
        df.groupby(by=(df['a'] / 10).round()).progress_apply(lambda x: x)


# From pandas v0.24.2

# Generated at 2022-06-24 09:37:55.077043
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:37:57.236168
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import  pandas

    tqdm_pandas(
        pandas.core.groupby.DataFrameGroupBy.progress_apply)
    pass

# Generated at 2022-06-24 09:38:08.485785
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    # pylint: disable=redefined-outer-name,invalid-name,unused-variable,expression-not-assigned
    import pandas as pd
    from pandas.core.groupby import DataFrameGroupBy
    try:
        import pandas_profiling
        has_pandas_profiling = True
    except ImportError:
        has_pandas_profiling = False
    try:
        import sklearn_pandas
        has_sklearn_pandas = True
    except ImportError:
        has_sklearn_pandas = False
    from . import tqdm, TqdmDeprecationWarning


# Generated at 2022-06-24 09:38:12.934356
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    df = pd.DataFrame(np.random.random((100, 3)), columns=list('abc'))
    tqdm_pandas(df.groupby('a').progress_apply(lambda x: x ** 2))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:23.433380
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import tnrange
    from tqdm import trange
    from tqdm.contrib import DummyTqdmFile

    # Test lazy case
    tqdm_pandas(tqdm)
    # Test eager case
    with tqdm(total=100, ascii=True, file=DummyTqdmFile()) as t:
        tqdm_pandas(t)
    # Test delayed lazy case
    tqdm_pandas(tnrange, total=100)
    # Test delayed eager case
    with trange(100) as t:
        tqdm_pandas(t)


# Generated at 2022-06-24 09:38:30.173536
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    import pandas as pd
    tqdm_pandas(tqdm)
    df = pd.DataFrame(
        {'something': [1, 2, 3], 'something_else': [2, 3, 4]},
        index=[2, 3, 4])
    df.groupby(['something']).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:41.910289
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class tqdm:
        @classmethod
        def pandas(cls, *args, **kwargs):
            return ("tqdm.pandas(*args=%r, **kwargs=%r)" % (args, kwargs))
    # Deprecated use-cases
    assert tqdm_pandas(tqdm) == "tqdm.pandas(*args=(), **kwargs={})"
    assert tqdm_pandas(tqdm, desc="desc") == "tqdm.pandas(*args=(), **kwargs={'desc': 'desc'})"
    assert tqdm_pandas(tqdm(), desc="desc") == "tqdm.pandas(*args=(), **kwargs={'desc': 'desc'})"
    # Normal use-cases

# Generated at 2022-06-24 09:38:50.686101
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm_pandas`"""
    import pandas as pd
    from tqdm import tqdm


# Generated at 2022-06-24 09:38:53.983795
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=FutureWarning)
        df = pd.DataFrame(dict(a=range(9), b=range(9)))
        assert tqdm_pandas(range(9)) == range(9)
        assert tqdm_pandas(pd.Series(range(9))) == pd.Series(range(9))
        assert tqdm_pandas(df.apply(lambda x: x)) == df
        assert tqdm_pandas(df.groupby(['a']).apply(lambda x: x)) == df.groupby(
            ['a']).apply(lambda x: x)

# Generated at 2022-06-24 09:39:02.742052
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    df = pd.DataFrame({'a': [1, 2, 3, 4, 5, 6, 7, 8, 9],
                       'b': [4, 5, 6, 3, 2, 1, 0, 0, 0]}, index=list(range(9)))
    x = df.groupby('a').progress_apply(lambda x: x**2)
    assert pd.Series((x['b'] - df['b'].values)**2).mean() == 0
    df = pd.DataFrame({'a': [1, 2, 3, 4, 5, 6, 7, 8, 9],
                       'b': [4, 5, 6, 3, 2, 1, 0, 0, 0]}, index=list(range(9)))
    x = df.progress

# Generated at 2022-06-24 09:39:11.721521
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm as tqdm_

    t = pd.DataFrame({'A': ['a'] * 1e6, 'B': ['b'] * 1e6})
    t.progress_apply(lambda x: x)
    tqdm_pandas(tqdm_, unit='rows')
    t.progress_apply(lambda x: x)
    tqdm_pandas(tqdm, unit='rows')
    t.progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:22.813129
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        has_pandas = True
    except ImportError:
        has_pandas = False

    if has_pandas:
        from tqdm.contrib import pandas as pandas_tqdm

        pandas_tqdm.tqdm_pandas(pandas_tqdm, file=sys.stderr)

        def test_func(grp):
            return grp['num'] * 2

        tqdm_pandas(pandas_tqdm, file=sys.stderr)
        df = pandas.DataFrame(
            {'year': [2015, 2016] * 2,
             'num': [1, 2, 3, 4],
             'val': ['a', 'b', 'c', 'd']})

# Generated at 2022-06-24 09:39:34.511712
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return None

    # tqdm as simple function
    from tqdm import trange
    t = trange(2, ascii=True)
    tqdm_pandas(t, ascii=True)
    pd.Series(range(10)).groupby(lambda x: x % 3).progress_apply(lambda x: x.sum())
    tqdm_pandas(t, ascii=False)
    pd.Series(range(10)).groupby(lambda x: x % 3).progress_apply(lambda x: x.sum())

    # tqdm as class
    from tqdm import tqdm
    t = tqdm(total=2)
    tqdm_pandas(t)
    p

# Generated at 2022-06-24 09:39:43.882615
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    from pandas import DataFrame
    from numpy import arange
    from random import shuffle

    test = DataFrame({
        'a': arange(10000),
        'b': map(lambda _: [shuffle(arange(1000)) for _ in range(100)], arange(10000))
    })

    # Test deprecated code
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        tqdm_pandas(tqdm)
        test.groupby('a').progress_apply(lambda a: a)

    # Test correct code
    tqdm.pandas()
    test.groupby('a').progress_apply(lambda a: a)

# Generated at 2022-06-24 09:39:51.460666
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import itertools
    import pandas as pd
    import numpy as np

    pd.DataFrame(dict(a=range(100))).groupby('a').progress_apply(lambda x: x)

    try:
        import sklearn
        assert hasattr(sklearn.base, 'BaseEstimator')
    except Exception:
        pass
    else:
        class Estimator(sklearn.base.BaseEstimator):
            def fit(self, X, Y):
                from tqdm import trange
                for _ in trange(10):
                    pass
                return self

            def predict(self, X):
                from tqdm import trange
                for _ in trange(10):
                    pass
                return np.zeros(X.shape)


# Generated at 2022-06-24 09:40:01.564720
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import TqdmDeprecationWarning

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", TqdmDeprecationWarning)
        tqdm_pandas(tqdm, ascii=True)
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(range(3)))
        tqdm_pandas(tqdm(range(3), ascii=True))
    assert len(w) == 4
    assert all(issubclass(w_.category, TqdmDeprecationWarning)
               for w_ in w)

# Generated at 2022-06-24 09:40:12.336438
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    "Unit test for function `tqdm_pandas`."
    from tqdm import trange
    from tqdm._version import _has_deprecated
    from pandas import DataFrame
    from pandas.util.testing import assert_frame_equal

    # Test `tqdm_pandas` version
    assert getattr(tqdm_pandas, '__version__', None)

    # Test deprecated `tqdm_pandas`
    assert _has_deprecated(tqdm_pandas)

    # Test `tqdm_pandas`
    try:
        from numpy.random import rand
        from pandas import DataFrame
    except ImportError:
        return None  # skip on readthedocs
    n = 100

# Generated at 2022-06-24 09:40:17.613130
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test 1
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame({'a': np.random.randn(1000000)})
    tqdm_pandas(tqdm, fp_write=sys.stderr.write)
    df.groupby(lambda x: x // 1E5).progress_apply(lambda _: [1 for _ in range(100000)])

    # Test 2
    @tqdm_pandas
    def func(df, **kwargs):
        return df.groupby(lambda x: x // 1E5).progress_apply(lambda _: [1 for _ in range(100000)])

    func(df)
    tqdm_pandas(tqdm)



# Generated at 2022-06-24 09:40:27.460297
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from pandas.core.groupby import DataFrameGroupBy, SeriesGroupBy
    from pandas.api.types import is_series
    from tqdm.auto import tqdm
    from tqdm._tqdm_pandas_test_sample import tqdm_pandas_test_sample
    import numpy as np
    from numpy.testing import assert_array_equal

    def _test_tqdm_pandas(t, maxiter):
        if is_series(t):
            tgroupby = SeriesGroupBy(t, t.index)
        else:
            tgroupby = DataFrameGroupBy(t, t.index)

        def _test_tqdm_tgroupby(tgroupby, tqdm):
            tgroupby_obj = t

# Generated at 2022-06-24 09:40:34.522880
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert sys.version_info >= (3, 3)
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm, trange
    tqdm_pandas(tqdm)

    df = pd.DataFrame(np.random.random((100, 1)))
    for _ in trange(10, leave=False):
        df_sum = df.groupby(0).progress_apply(sum)
        assert df_sum

    print('tqdm_pandas: OK')

test_tqdm_pandas()

# Generated at 2022-06-24 09:40:42.922886
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
        from pandas import Series
        from pandas.core.groupby import DataFrameGroupBy

        DataFrameGroupBy.progress_apply = tqdm_pandas
        assert hasattr(DataFrameGroupBy, 'progress_apply')
        df = DataFrame({'a': ['a', 'a', 'a', 'a'], 'b': Series([1, 2, 3, 4]).repeat(100)})
        assert df.groupby('a').progress_apply(sum).values[0, 0] == 100
        del DataFrameGroupBy.progress_apply
        assert not hasattr(DataFrameGroupBy, 'progress_apply')
    except:
        pass


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:49.880987
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test imports
    import pandas as pd
    from tqdm import tqdm_pandas

    # Test type registered with tqdm_pandas
    df = pd.DataFrame({'a':list(range(20))})
    result = df.groupby('a').progress_apply(lambda x: int(x))
    assert result is not None
    # Test instance registered with tqdm_pandas
    df = pd.DataFrame({'a':list(range(20))})
    result = df.groupby('a').progress_apply(lambda x: int(x))
    assert result is not None
    # Test tqdm_gui
    result = df.groupby('a').progress_apply(lambda x: int(x))
    assert result is not None
    # Test tqdm_note

# Generated at 2022-06-24 09:40:53.122059
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    try:
        import pandas  # NOQA
        from tqdm import tqdm
    except ImportError:
        return
    tqdm_pandas(tqdm(total=10))



# Generated at 2022-06-24 09:41:00.349578
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import math
    import pandas as pd
    import numpy as np
    import tqdm
    import tqdm.pandas
    arr = np.random.randn(100, 100)
    df = pd.DataFrame(arr)
    tqdm_pandas(tqdm.tqdm, desc='desc')
    df.progress_apply(lambda x: math.sqrt(x))
    tqdm.pandas(desc='desc')
    df.progress_apply(lambda x: math.sqrt(x))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:07.379415
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    This is a Unit test function for function tqdm_pandas.
    '''
    try:
        tqdm_pandas(tqdm_pandas)
    except Exception:
        import sys
        print("test_tqdm_pandas failed", file=sys.stderr)
        raise
    else:
        print("test_tqdm_pandas succeeded", file=sys.stderr)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:17.649031
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _supports_unicode
    from .std import tqdm

    from pandas import DataFrame, Series
    from pandas.core.groupby import DataFrameGroupBy

    df = DataFrame({'x': [1, 2, 0, 1], 'y': [1, 0, 1, 1]})
    df = df.groupby('x').y
    assert isinstance(df, DataFrameGroupBy)

    tqdm(disable=True)
    tqdm_pandas(tqdm)
    try:
        df = df.progress_apply(lambda x: x)
        # assert isinstance(df, Series)
    except AttributeError:
        pass
    df = df.progress_apply(lambda x: x)
    assert isinstance(df, Series)


# Generated at 2022-06-24 09:41:24.337935
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Some tests to ensure that tqdm_pandas properly works.
    class local_tqdm:

        def __init__(self, **kwargs):
            if 'deprecated_t' in kwargs:
                self.deprecated_t = True
            elif 'tclass' in kwargs:
                self.tclass = True

        def pandas(self, **kwargs):
            if hasattr(self, 'deprecated_t'):
                self.deprecated_t = kwargs.get('deprecated_t', None)
            elif hasattr(self, 'tclass'):
                self.tclass = kwargs.get('tclass', None)

    # Case 1: calling tqdm_pandas with tclass and **tqdm_kwargs
    local_tqdm_instance

# Generated at 2022-06-24 09:41:26.433752
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(), total=None)



# Generated at 2022-06-24 09:41:33.374160
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas.util.testing import (test_parallel, test_parallel_function,
                                     RNGContext, assert_series_equal)
    from tqdm._utils import _supports_unicode
    from tqdm.gui import tqdm
    if not _supports_unicode:
        return

    def get_df(n, n_groups=10, n_group_rows=10):
        # type: (int, int, int) -> pd.DataFrame
        with RNGContext(42):
            randint = np.random.randint
            data = [(randint(n_groups), randint(n_group_rows))
                    for _ in range(n)]
            return pd.DataFrame(data, columns=['group', 'value'])


# Generated at 2022-06-24 09:41:46.913105
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange, tqdm
    from tqdm.contrib import pandas
    from pandas import DataFrame, Series

    def rand(m):
        return DataFrame(Series([random() for _ in range(m)]),
                         columns=['a'])

    for i in tnrange(10, unit='test'):
        with pandas.tqdm_pandas(tqdm(desc='Test tqdm', leave=True)) as pbar:
            _ = pbar.progress_apply(rand, axis=0, m=100)
    print('tqdm_pandas() unit test passed.')


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:55.099561
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm.notebook import trange
    from tqdm import tqdm_notebook
    from tqdm.contrib.concurrent import process_map

    try:
        import DummyTqdmType
    except ImportError:
        pass
    else:
        tqdm_pandas(DummyTqdmType)
        DummyTqdmType.pandas.test_pandas()

    df = pd.DataFrame(np.random.rand(100, 100))
    tqdm_pandas(tqdm)
    res = df.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-24 09:42:04.978112
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test function tqdm_pandas
    """
    import pandas as pd
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=100))

    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm, ascii=True)

    assert len(w) == 1
    assert issubclass(w[-1].category, TqdmDeprecationWarning)
    assert 'tqdm.pandas(...)' in str(w[-1].message)
    assert 'tqdm_pandas(tqdm, ...)' in str(w[-1].message)

    with warnings.catch_warnings(record=True) as w:
        tqdm_

# Generated at 2022-06-24 09:42:10.619736
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import trange

    dummy_df = pd.DataFrame(
        {'label': [1, 3, 5, 7, 9], 'value': [9, 7, 5, 3, 1]})
    dummy_df.groupby('label').progress_apply(lambda x: [x['value']] * 10)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:18.465986
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    def test_apply(self, func, *args, **kwargs):
        is_lambda = func.__code__.co_code.__sizeof__() == 0
        if not (is_lambda or self._apply_type == 'expanding'):
            name = '{0}_apply_func'.format(self._groupby_type)

            desc = getattr(func, '__name__', '{0}_apply_func'.format(
                self._groupby_type))
            self._tqdm_pandas_total = self.size
            self._tqdm_pandas_desc = desc
            self._tqdm_pandas_unit = self.name

# Generated at 2022-06-24 09:42:28.778295
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas_
    from tqdm import tqdm
    from tqdm.tests._utils import _range
    # range is a builtin wrapper in python 2.x
    # just to be sure, check python 3.x
    assert list(_range(1)) == [0]
    assert list(tqdm(_range(1))) == [0]
    assert list(tqdm_pandas_(_range(1))) == [0]
    assert list(tqdm_pandas(tqdm)) == [0]
    assert list(tqdm_pandas(tqdm_pandas_)) == [0]

if __name__ == '__main__':
    from sys import version_info

# Generated at 2022-06-24 09:42:32.566571
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({"A": [0] * 10000, "B": [1] * 10000})
    _ = df.groupby("A").progress_apply(getattr, name="B")


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:40.147530
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # test case 1: string
    s = '''
    tqdm_pandas(...) -> <lambda>
    Registers the given tqdm instance with pandas.core.groupby.DataFrameGroupBy.progress_apply.
    '''
    res = tqdm_pandas.__doc__
    assert res == s

    # test case 2: string
    s = '''
    test_tqdm_pandas() -> None
    Unit test for function tqdm_pandas
    '''
    res = test_tqdm_pandas.__doc__
    assert res == s

# Generated at 2022-06-24 09:42:47.711690
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame(
        {'a': [4, 5, 6, 7],
         'b': [10, 20, 30, 40]})

    # Use tqdm_pandas to apply a function to a pandas dataframe
    def myfunction(x):
        return x + 1

    new_df = df.groupby('a').progress_apply(myfunction)
    assert set(new_df.b) == {11, 21, 31, 41}


__all__ += ['tqdm_notebook']



# Generated at 2022-06-24 09:42:58.968906
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    # pylint: disable=import-outside-toplevel
    from tqdm import tqdm_pandas as tqdm_pandas_

    tqdm_kwargs = {}
    if hasattr(tqdm, '_instances'):
        tqdm._instances.clear()  # needed for Python 2
    tqdm_pandas_(tqdm, **tqdm_kwargs)
    tqdm_pandas_(tqdm_kwargs)

    df = pd.DataFrame({"a": list(range(1000000)), "b": list(range(1000000))})
    tqdm.pandas(**tqdm_kwargs)
    df.groupby(["a", "b"]).progress_

# Generated at 2022-06-24 09:43:03.595602
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    tqdm_pandas(tqdm(leave=False))  # delayed adapter case
    tqdm_pandas(tqdm(leave=False, dynamic_ncols=True))  # delayed adapter case

# Generated at 2022-06-24 09:43:14.098130
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from numpy import random
    from itertools import repeat

    tqdm.pandas()

    data = DataFrame()
    for i in repeat(None, 2):
        data[i] = Series(random.randint(1, 100, 100))

    # applymap:
    try:
        with tqdm(total=len(data)) as pbar:
            def inner(x):
                pbar.update(1)
                return x ** 2

            data.applymap(inner)
    except:
        raise Exception('applymap: FAIL')
    else:
        print('applymap: PASS')

    # apply:

# Generated at 2022-06-24 09:43:17.302748
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm)
    try:
        tqdm_pandas(tqdm())
    except TypeError:
        pass
    else:
        raise ValueError()

# Generated at 2022-06-24 09:43:21.771992
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    dummy = pd.Series(['apple', 'orange', 'banana', 'pears'])
    assert hasattr(dummy.progress_apply, '__call__')


if __name__ == '__main__':
    """Unit test"""
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:32.525954
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        import numpy as np
        import pandas as pd
        import pandas.util.testing as tm
    except ImportError:
        raise unittest.SkipTest('numpy or pandas not installed')

    class TestTqdmPandas(tm.TestCase):
        def test_tqdm_pandas(self):
            tqdm_pandas(tqdm)
            index = pd.date_range('1/1/2000', periods=8)
            df = pd.DataFrame(
                np.random.randn(8, 3), index=index, columns=['A', 'B', 'C'])

            def f(x):
                return x * 2


# Generated at 2022-06-24 09:43:39.981132
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    from tqdm import tqdm, tqdm_gui  # noqa

    print('Case 1')
    with tqdm(total=10) as t:
        tqdm_pandas(t)
        pandas.DataFrame([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]).groupby(
            0).progress_apply(lambda x: x)
        t.close()

    print('Case 2')
    tqdm_pandas(tqdm)
    with tqdm(total=10) as t:
        pandas.DataFrame([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]).groupby(
            0).progress_apply(lambda x: x)

# Generated at 2022-06-24 09:43:45.534759
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test that Foo.pandas(t=T) is equivalent to tqdm.pandas(Foo)"""
    T = tqdm_pandas(tqdm(range(1000)))
    result = Foo.pandas(t=T)
    assert result.__name__ == tqdm_pandas(Foo).__name__



# Generated at 2022-06-24 09:43:53.339749
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test function of tqdm_pandas"""
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({
        "a": np.random.randint(0, 100, 1000),
        "b": np.random.randint(0, 100, 1000)
    })

    def foo(x):
        """Dummy function to apply on the DataFrameGroupBy"""
        return x.max()

    class DummyTQDM(tqdm):
        """Dummy TQDM for testing"""

        def __call__(self, *args, **kwargs):
            """Dummy TQDM for testing"""
            return self


# Generated at 2022-06-24 09:44:03.639053
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    # Testing pandas >= 0.17
    try:
        if float(pd.__version__[:3]) >= 0.18:
            from pandas.core.groupby import SeriesGroupBy, DataFrameGroupBy
            SeriesGroupBy.progress_apply = SeriesGroupBy.apply
            DataFrameGroupBy.progress_apply = DataFrameGroupBy.apply

    except ImportError:
        pass

    # Testing pandas < 0.17
    test = pd.DataFrame({'x':[1,2,3,4], 'y':[3,4,5,6]})
    test_series = pd.Series([1,2,3])

# Generated at 2022-06-24 09:44:12.519093
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Should pass
    import pandas as pd

    try:
        tqdm_pandas(tqdm)
    except:
        raise Exception

    try:
        tqdm_pandas(tqdm())
    except:
        raise Exception

    data = {'col_1': [3, 2, 1, 0], 'col_2': ['a', 'b', 'c', 'd']}
    df = pd.DataFrame.from_dict(data)
    for _ in range(2):
        try:
            for _ in tqdm(df.pandas.progress_apply(lambda x: x)):
                pass
        except:
            pass

    df.pandas.progress_apply(lambda x: x, show_percent=False)
    df.pandas.progress_apply

# Generated at 2022-06-24 09:44:18.204082
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm import tqdm_notebook
    from tqdm._tqdm_pandas import tqdm_pandas

    assert not hasattr(tqdm, 'pandas')
    assert not hasattr(tqdm_notebook, 'pandas')
    with warnings.catch_warnings(record=True) as ws:
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm_notebook)
        assert len(ws) == 2
    assert hasattr(tqdm, 'pandas')
    assert hasattr(tqdm_notebook, 'pandas')

    def f(param):
        return param.sum()

# Generated at 2022-06-24 09:44:25.432184
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        try:
            import pandas
        except ImportError:
            return
    tqdm_pandas(tqdm, ascii=True)
    tqdm_pandas(tqdm.tqdm, ascii=True)
    tqdm_pandas(tqdm.tqdm_notebook, ascii=True)
    tqdm_pandas(tqdm.tqdm_gui, ascii=True)
    tqdm_pandas(tqdm.trange, ascii=True)
    tqdm_pandas(tqdm.tgrange, ascii=True)

# Generated at 2022-06-24 09:44:33.838906
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        # Pandas support
        import pandas as pd
        tqdm_pandas(tqdm())  # Pandas support only available in tqdm v4.22+
        # Create the DataFrame to act on
        dummy_df = pd.DataFrame({'a': range(1000), 'b': range(1000)})
        # Use progress_apply instead of regular apply
        res = dummy_df.groupby('a').progress_apply(lambda x: x ** 2)
        assert int(res.a.sum()) == 333833500
    except (AttributeError, ImportError):
        pass
    except Exception as e:
        raise e

# Generated at 2022-06-24 09:44:43.763183
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import concat
    from pandas.api.types import is_categorical_dtype
    import tqdm

    d = [
        DataFrame(range(i, i + 5))
        for i in range(0, 100, 5)
    ]
    # Make sure it's groupable
    df = concat(d, keys=range(0, 100, 5))
    assert len(df.groupby(df.index // 5)) == 20

    # Make sure there is a categorical_dtype
    df2 = concat(d, keys=['a', 'b', 'c', 'd', 'e'])
    assert is_categorical_dtype(df2.index.dtype)

    # Make sure it works on dataframes

# Generated at 2022-06-24 09:44:51.428688
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import pandas
    import numpy
    try:
        xmlrpc = __import__("xmlrpc")
    except Exception:
        pass
    else:
        if xmlrpc.client.ServerProxy("http://pypi.python.org/pypi").package_releases("pandas"):  # pragma: no cover
            # we are not compatible in 0.18, so skip test
            return

# Generated at 2022-06-24 09:45:00.013095
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    import random

    with tqdm(range(10)) as t:
        assert tqdm_pandas(t) is None

    with tqdm(range(10), file=open(os.devnull, 'w')) as t:
        assert tqdm_pandas(t) is None

    with tqdm(total=100, file=open(os.devnull, 'w')) as t:
        assert tqdm_pandas(t) is None

    assert tqdm_pandas(type(tqdm)) is None

    global SLOW_MODE
    global DEBUG_MODE
    tqdm_pandas.SLOW_MODE = False


# Generated at 2022-06-24 09:45:09.126183
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    try:
        import numpy as np
    except ImportError:
        return

    if not pd:
        from tqdm import TqdmSkipped
        raise TqdmSkipped("pandas not found")

    # Test basic functionality
    for N in [0, 1, 100, 1000, 10000]:
        assert np.all(pd.DataFrame(np.random.random((N, N))).progress_apply(
            lambda x: x) == pd.DataFrame(np.random.random((N, N))))

    # Test tqdm(...)

# Generated at 2022-06-24 09:45:19.050867
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`."""
    from tqdm import tqdm
    import pandas

    pbar = tqdm(total=10)
    tqdm_pandas(pbar)
    df = pandas.DataFrame(dict(x=list(range(10)), y=list(range(10))))
    df.groupby('x').progress_apply(lambda x: x)

    pbar = tqdm(total=10)
    tqdm_pandas(pbar, postfix='loading')
    df = pandas.DataFrame(dict(x=list(range(10)), y=list(range(10))))
    df.groupby('x').progress_apply(lambda x: x)

    pbar = tqdm(total=10)

# Generated at 2022-06-24 09:45:27.886191
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    from tqdm import tqdm, TqdmDeprecationWarning

    # Test 1
    with captured_output() as (out, err):
        tqdm_pandas(tqdm)
    cp = out.getvalue().strip()
    assert (cp == '''
Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.
'''.strip())

    # Test 2
    with captured_output() as (out, err):
        tqdm_pandas(tqdm())
    cp = out.getvalue().strip()

# Generated at 2022-06-24 09:45:34.158919
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    import numpy as np
    from tqdm import tqdm_pandas

    tqdm_pandas(tqdm)  # Registers in pandas
    # Tests it
    df = pandas.DataFrame({'a': np.arange(10000)})
    prev_len = len(df)
    df = df.groupby('a').progress_apply(lambda x: x)
    assert len(df) == prev_len
    # Tests same thing but with delayed tqdm
    df = pandas.DataFrame({'a': np.arange(10000)})
    prev_len = len(df)
    df = df.groupby('a').progress_apply(lambda x: x)  # noqa: F841
   

# Generated at 2022-06-24 09:45:43.330679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Simple unit test for function tqdm_pandas."""
    # dummy (pandas) dataframe
    df = pd.DataFrame(
        np.random.rand(5, 3),
        columns=['col1', 'col2', 'col3'],
    )

    # test the deprecated behaviour
    try:
        tqdm_pandas(tqdm, desc='Progress', unit='iter', total=len(df))
    except TqdmDeprecationWarning:
        pass
    else:
        raise AssertionError()
    try:
        tqdm_pandas(tqdm(desc='Progress', unit='iter', total=len(df)))
    except TqdmDeprecationWarning:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-24 09:45:52.457234
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    groups = {'A': [1, 2], 'B': [3, 4]}
    data = pd.DataFrame({'A': [1, 2, 3, 4, 5], 'B': [3, 4, 1, 2, 3]})

    def inner_fn(x):
        return x

    def outer_fn(g):
        return g.progress_apply(inner_fn)

    # noinspection PyUnresolvedReferences,PyProtectedMember
    with tqdm(total=len(groups)) as t:
        # noinspection PyUnresolvedReferences,PyProtectedMember
        data.groupby('B').progress_apply(inner_fn).sum()
        # noinspection PyUnresolvedReferences,PyProtectedMember