

# Generated at 2022-06-24 09:35:43.365718
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas
    import pandas as pd
    import numpy as np
    import time

    with pandas(total=5) as pbar:
        for i in range(5):
            time.sleep(0.1)
            pbar.update()

    with pandas(total=5) as pbar:
        for i in range(5):
            time.sleep(0.1)
            pbar.update(1)

    df = pd.DataFrame(np.random.randint(0, 1000, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x**2)

    tqdm_pandas(pd.core.groupby.DataFrameGroupBy, leave=True)

# Generated at 2022-06-24 09:35:54.759824
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm, tqdm_pandas
    df = pd.DataFrame({'a': [1, 2, 3, 4], 'b': [1, 2, 3, 4]})
    with tqdm(total=len(df)) as pbar:
        def progress(x):
            pbar.update()
            return x
        df.apply(progress, axis=1)

    with tqdm(total=len(df)) as pbar:
        def progress(x):
            pbar.update()
            return x
        df.progress_apply(progress, axis=1)

    with tqdm(total=len(df)) as pbar:
        def progress(x):
            pbar.update()
            return x
        t

# Generated at 2022-06-24 09:36:00.441631
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange
    assert tqdm_pandas(tqdm) == tqdm.pandas()
    assert tqdm_pandas(trange) == trange.pandas()
    assert tqdm_pandas(tqdm, leave=True) == tqdm.pandas(leave=True)
    assert tqdm_pandas(trange, leave=True) == trange.pandas(leave=True)
    assert tqdm_pandas(tqdm(leave=True)) == tqdm(leave=True).pandas()
    assert tqdm_pandas(trange(leave=True)) == trange(leave=True).pandas()
    assert tqdm_pand

# Generated at 2022-06-24 09:36:09.785815
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'a': range(5), 'b': range(5, 10)})
    df.groupby(['a']).progress_apply(len)  # deprecated, but still works
    with tqdm.tqdm_pandas(total=len(df)) as t:
        df.groupby(['a']).progress_apply(len)  # deprecated, but still works
    # short names:
    with tqdm.tqdm_pandas(total=len(df)) as t:
        df.groupby(['a']).progress_apply(len)  # deprecated, but still works
    # full names:
    with tqdm.tqdm_pandas(total=len(df)) as t:
        df

# Generated at 2022-06-24 09:36:19.355341
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    class t:
        """Fake tqdm"""
        def pandas(self, **x):
            self.x = x

    class t2:
        """Fake tqdm class"""
        @classmethod
        def pandas(self, **x):
            self.x = x

    # tqdm instance
    tqdm_pandas(t())
    assert hasattr(t, 'x')
    # raw tqdm class
    tqdm_pandas(t, ascii=True)
    assert hasattr(t, 'x')
    # fake tqdm
    tqdm_pandas(t2)
    assert hasattr(t2, 'x')
    # fake tqdm class
    t

# Generated at 2022-06-24 09:36:28.527447
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pytest
    try:
        import pandas
    except ImportError:
        pytest.exit("pandas not found")
    old_stdout = sys.stdout
    sys.stdout = tempfile.TemporaryFile()
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    with tqdm() as t:
        tqdm_pandas(t)
    with tqdm(ncols=10) as t:
        tqdm_pandas(t)
    t = tqdm()
    tqdm_pandas(t)
    assert t.ncols == 0
    DataFrame = pandas.DataFrame
    df = DataFrame({"A": [1, 2, 3, 4]})

# Generated at 2022-06-24 09:36:33.950049
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm = tqdm_pandas(tqdm)
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    # We must use a multi-index to trigger progress_apply
    df = df.set_index([*['A', 'B', 'C']*2, [1, 2]])
    tqdm_pandas(df.groupby(level=0).progress_apply(lambda x: x))

# Generated at 2022-06-24 09:36:43.544589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Create a dummy function
    def my_func(df):
        return df

    # Create a dummy pandas data frame
    import numpy as np
    import pandas as pd
    n = 100000
    df = pd.DataFrame(np.random.randint(0, 10, size=(n, 4)), columns=list('ABCD'))

    # Test tqdm.pandas
    tqdm.pandas(desc='Test 1')
    df.groupby('A').progress_apply(my_func)

    with tqdm.pandas(desc='Test 2') as t2:
        df.groupby('A').progress_apply(my_func)
    assert t2.total == n

    # Test tqdm_pandas()

# Generated at 2022-06-24 09:36:48.933591
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    # Unit test
    import tqdm
    pd.set_option('display.max_columns', None)
    df = pd.DataFrame(np.random.randn(40000, 4), columns=list('ABCD'))

    with tqdm.tqdm(total=df.shape[0], desc='Pandas loop') as pbar:
        def myfunc(x, pbar=pbar):
            pbar.update()
            return (x ** 2)

        df = df.progress_apply(myfunc, axis=1)

# Generated at 2022-06-24 09:36:56.512439
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Test for tqdm_pandas.
    """
    from tqdm.auto import tqdm
    from pandas.core.groupby import GroupBy
    from pandas.core.groupby import DataFrameGroupBy
    from pandas.core.series import Series
    import pandas as pd

# Generated at 2022-06-24 09:36:59.665136
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tt = tqdm([1, 2, 3, 4, 5])
    tt.pandas()

# Generated at 2022-06-24 09:37:10.143885
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:37:15.595081
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        import numpy
    except ImportError:
        return

    numpy.random.seed(4)
    df = pandas.DataFrame(numpy.random.randint(0, 100, (100000, 4)),
                          columns=list('ABCD'))
    v = df.A.groupby(df.B).progress_apply(sum)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:17.910598
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm_pandas(tqdm(range(3))) as t:
        # Use t directly as a context manager
        # This could be a foundamental change
        assert t.__class__.__name__ == 'tqdm'
        for _ in range(4):
            t.update()
    assert t.n == 3


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:28.708857
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test for function tqdm_pandas
    """
    from pandas import DataFrame
    from tqdm.auto import tqdm
    from random import randint
    from time import sleep

    # Test pandas progress bar on DataFrameGroupBy object
    df = DataFrame(
        [[randint(1, 10) for _ in range(randint(10, 20))] for _ in range(randint(5, 10))],
        columns=['col' + str(i) for i in range(randint(10, 20))])

    def mean_dummy(x):
        sleep(0.1)
        return x.mean()

    with tqdm(ncols=150) as bar:
        df.groupby('col1').progress_apply(mean_dummy, meta=bar)
        bar

# Generated at 2022-06-24 09:37:30.007685
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(None)

# Generated at 2022-06-24 09:37:40.214686
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import pandas as pd
    from tqdm.auto import tqdm

    tqdm.pandas()  # register the `pandas.progress_apply` and `pandas.Series.progress_map` with `tqdm`
    tqdm(total=100, desc="Pandas (total)").close()
    tqdm(total=100, desc="Pandas (chunks)").close()
    for i in tqdm(range(1000), desc="Pandas (itertools)"):
        pass

    df = pd.DataFrame({'x': range(500), 'y': range(500)})
    df.progress_apply(lambda x: x ** 2)  # `progress_apply` will automatically display a `tqdm`
    # progress bar when you apply a `Pandas` function
   

# Generated at 2022-06-24 09:37:46.066197
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    from pandas import DataFrame

    # Simulates a pandas DataFrame
    df = DataFrame({'x': [1, 2, 3, 4, 5]})
    tqdm_pandas(tqdm())

    df.groupby('x').progress_apply(lambda x: x + 1)
    tqdm_pandas(tqdm(leave=False))

    df.groupby('x').progress_apply(lambda x: x + 1)
    tqdm_pandas(tqdm(desc='Testing desc'))

    df.groupby('x').progress_apply(lambda x: x + 1)
    tqdm_pandas(tqdm(desc='Testing %s' % 'desc'))

test_t

# Generated at 2022-06-24 09:37:54.166966
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    numpy.random.seed(42)
    from tqdm import tqdm
    from tqdm import tqdm_gui
    from tqdm import trange
    from tqdm import tnrange
    x = numpy.random.choice(range(10), size=1000, replace=True)
    y = numpy.random.choice(range(10), size=1000, replace=True)
    df = pandas.DataFrame({'categorical': x, 'numerical': y})
    for t in [tqdm, tqdm_gui, trange, tnrange]:
        t(total=100).pandas(df.progress_apply, lambda x: x)

if __name__ == '__main__':
    test_tqdm_pand

# Generated at 2022-06-24 09:38:05.050713
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    try:
        import pandas.core.groupby as groupby
    except ImportError:
        print('pandas not installed: tqdm_pandas unit test skipped')
        return

    try:
        import pytest
    except ImportError:
        print('pytest not installed: tqdm_pandas unit test skipped')
        return

    DTYPES = [
        'float32', 'float64', 'int8', 'int16', 'int32', 'int64',
        'bool', 'object', 'category']
    DATA = np.random.random((100, 100))
    DATA = pd.DataFrame(DATA, columns=DTYPES)
    DATA['category'] = DATA['category'].astype('category')

    # Wrap the

# Generated at 2022-06-24 09:38:12.229498
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        pd = None
    if pd is not None:
        from tqdm import tqdm
        tqdm_pandas(tqdm, leave=True)
        data = {'a': list(range(10)), 'b': list(reversed(range(10)))}
        df = pd.DataFrame(data)
        df.groupby('a').progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:15.475566
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    df = DataFrame({'A': list("abcdefg")})
    try:
        tqdm_pandas(tqdm(desc=''), desc='')
    except:
        return
    assert False

# Generated at 2022-06-24 09:38:18.253566
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    t = tqdm_pandas(tqdm)
    assert hasattr(t, 'pandas')



# Generated at 2022-06-24 09:38:27.555606
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        pass  # pandas is not installed (tqdm is required though)

    # tqdm is required
    from tqdm import tqdm

    N = 100
    df = pd.DataFrame(dict(A=np.random.choice([4] * N, N, p=[.9, .05, .03, .02]),
                           B=np.random.randn(N),
                           C=np.random.choice([0] * 10 + [10] * 10, N, p=[.1] * 10 + [.9] * 10)))

    with tqdm(total=1) as t:
        t.set_description("Testing tqdm_pandas")
        tqdm_pandas

# Generated at 2022-06-24 09:38:38.376160
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    from tqdm import tqdm

    tqdm_pandas(tqdm)

    from pandas import DataFrame
    df = DataFrame({'a': [1, 2, 3, 4, 5], 'b': [6, 7, 8, 9, 10]})

    def add_one(x):
        return x + 1

    for i in tqdm(range(4)):
        ret = df.groupby('a').progress_apply(add_one, i)

    with tqdm(range(4)) as t:
        t.pandas(desc='ABC', miniters=1)
        ret = df.groupby('a').progress_apply(add_one, t)

# Generated at 2022-06-24 09:38:48.687815
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm, tqdm_pandas
    from tqdm import TqdmDeprecationWarning
    from tqdm.contrib._fake_itertools import U

    # Adapted from pandas/core/groupby/tests/test_base.py
    for i in tqdm(range(1, 10)):
        if i == 5:
            raise RuntimeError("TEST")
    l = list(range(10))

# Generated at 2022-06-24 09:38:58.405694
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm.pandas
    type(tqdm.pandas.tqdm).pandas = tqdm_pandas
    tqdm.pandas.tqdm.disable = True

    df = pd.DataFrame({'a': [1], 'b': [0.1]})
    df['c'] = df.progress_apply(lambda x: x.a + x.b, axis=1)
    return str(df['c'].iloc[0]) == '1.1'

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:08.425822
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm_notebook
    from tqdm.contrib import pandas
    tmp_file = 'tmp.txt'
    with open(tmp_file, 'w') as fo:
        fo.write('100\n')
        fo.write('100\n')
    df = pd.read_csv(tmp_file, header=None)
    df.columns = ['a']
    # this works
    print(df.progress_apply(lambda x: x * np.random.random(), axis=1))
    # these should not break
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(pandas)  # delayed adapter case
    # should work with new function call
    print

# Generated at 2022-06-24 09:39:16.666910
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(None, unit='a', leave=False)  # deprecated
    with tqdm(unit='a', leave=False) as t:
        tqdm_pandas(t, unit='a', leave=False)  # deprecated
        tqdm_pandas(t, unit='a', leave=False)  # deprecated
        t.pandas(unit='a', leave=False)
        t.pandas(unit='a', leave=False)
        t.pandas(unit='a', leave=False)
        t.pandas(unit='a', leave=False)



# Generated at 2022-06-24 09:39:26.176872
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # check standard use case with pandas loaded
    # inversion of control?
    import pandas as pd
    import tqdm
    tqdm_pandas(tqdm)
    assert ('pandas' in tqdm.tqdm_gui.TqdmTypeError.__repr__.__code__.co_names)
    # check without pandas
    # with patch.dict('sys.modules', pandas=None):
    #     # tqdm.tqdm_gui.TqdmTypeError.__repr__ = lambda _: "pandas not loaded"
    #     tqdm_pandas(tqdm)
    #     assert ('pandas' not in tqdm.tqdm_gui.TqdmTypeError.__repr__.__code__.co_

# Generated at 2022-06-24 09:39:34.096605
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    tqdm_pandas(tqdm())  # tqdm_pandas(tqdm, ...)
    tqdm_pandas(0)
    tqdm_pandas(tqdm(0))  # tqdm_pandas(tqdm(...))
    pd.DataFrame().groupby(0).progress_apply(lambda x: 0)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:44.248914
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame(
        {'A': [0, 0, 0, 1, 1, 2, 2, 2, 2, 2],
         'B': [1, 1, 2, 0, 2, 3, 3, 3, 2, 2]})
    if 'tqdm.auto.tqdm' in sys.modules:
        from tqdm import tqdm
        from tqdm._tqdm_pandas import tqdm as tqdm_pandas
    else:
        from tqdm import tqdm, tqdm_pandas
        tqdm_pandas = tqdm

    testvec = []

# Generated at 2022-06-24 09:39:51.692503
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from pandas import DataFrame
    from pandas.util import testing as pdt
    from tqdm import tqdm

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch # Python 2

    # Assert that ignoring the warning returns no errors
    old_stderr, sys.stderr = sys.stderr, io.StringIO()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        tqdm_pandas(tqdm)
    assert not sys.stderr.getvalue()

    # Assert that ignoring the warning returns no errors
    sys.stderr = io.StringIO()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        tqdm_pand

# Generated at 2022-06-24 09:40:01.739014
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({"a": range(100)})

    # Without `tqdm_pandas`
    df.groupby("a").progress_apply(lambda x: x)

    # With `tqdm_pandas`
    with tqdm(total=len(df)) as pbar:
        tqdm_pandas(pbar)
        df.groupby("a").progress_apply(lambda x: x)

    # With `tqdm.pandas`
    with tqdm(total=len(df)) as pbar:
        tqdm.pandas(pbar)
        df.groupby("a").progress_apply(lambda x: x)

    # With `tqdm_pand

# Generated at 2022-06-24 09:40:11.903386
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    tclass = tqdm(np.random.randint(0, 100, (1000,)),
                  desc='test',
                  ncols=20,
                  total=1000,
                  ascii=True)
    tqdm_pandas(tclass)

    a = np.arange(0, 100)
    b = np.arange(0, 100)

    df = pd.DataFrame({'a': a, 'b': b})

    df.groupby('a').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:17.218365
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import pandas.core.groupby as gp
    from .std import tqdm
    from .std import tqdm_pandas

    def test_pandas_apply(df):
        """ Pandas .apply() test """
        tqdm.pandas(desc="apply")
        return df['a'].apply(lambda x: x + 1)

    def test_groupby_progress_apply(df):
        """ Pandas .groupby().progress_apply() test """
        tqdm_pandas(tqdm)
        return df.groupby(['b']).progress_apply(lambda g: g['a'].sum())

    def test_groupby_apply(df):
        """ Pandas .groupby().apply() test """

# Generated at 2022-06-24 09:40:24.476424
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # TODO
    # problem with travis ci, class undefined
    # works on local env
    tp = tqdm_pandas
    import pandas as pd
    df = pd.DataFrame({'a': [1, 2, 3] * 1000, 'b': [8, 10, 12] * 1000})
    for _ in tp(range(100)):
        df.groupby('a').progress_apply(lambda x: x.a + x.b)
    df.groupby('a').progress_apply(lambda x: x.a + x.b)

# Generated at 2022-06-24 09:40:35.820416
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise SkipTest("Skipping test_tqdm_pandas (pandas not installed)")

    import os
    from random import randint
    from itertools import count
    from pandas import DataFrame
    from pandas.util.testing import rands

    from .tests_tqdm import pretest_posttest, with_setup

    n = 100

    # ----------
    def df_test(t):
        df = DataFrame({'A': [randint(0, 100) for _ in range(n)]})

        @t.wrap()
        def progress_apply():
            return df.groupby('A').progress_apply(lambda x: x)


# Generated at 2022-06-24 09:40:44.662523
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy import random as np_random
    from pandas import Series
    from numpy import arange

    # tqdm_pandas(tqdm)
    tqdm_pandas(tqdm)

    df = DataFrame({'A': Series(np_random.uniform(size=10000)),
                    'B': arange(10000)})
    for _ in tqdm(df.groupby('A').progress_apply(tuple)):
        pass
    df = DataFrame({'A': Series(np_random.uniform(size=10000)),
                    'B': arange(10000)})
    for _ in tqdm(df.groupby('A').progress_apply(tuple), disable=True):
        pass




# Generated at 2022-06-24 09:40:52.499110
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return None
    g = pd.DataFrame([{'a': i} for i in range(1000000)])
    with tqdm(total=len(g), leave=False) as pbar:
        def func(df):
            pbar.update()
            return df
        g.groupby('a').progress_apply(func)
    with tqdm(total=len(g), leave=False) as pbar:
        def func(df):
            pbar.update()
            return df
        g.groupby('a').progress_apply(func, tqdm_cls=type(pbar))

# Generated at 2022-06-24 09:41:01.329289
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import tqdm

    # non-regression test
    tqdm_pandas(tqdm)

    # unit test
    def dummy_apply(self):
        pass

    assert 'apply' not in DataFrameGroupBy.__dict__
    tqdm_pandas(tqdm)
    assert 'apply' in DataFrameGroupBy.__dict__

    DataFrameGroupBy.progress_apply = dummy_apply
    tqdm_pandas(tqdm)
    assert DataFrameGroupBy.progress_apply == dummy_apply
    del DataFrameGroupBy.progress_apply

    pd.DataFrame.progress_apply = dummy_apply
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:41:11.533062
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        from tqdm.auto import tqdm
    except:
        return
    df = pd.DataFrame({'a': np.random.rand(int(1e5)),
                       'b': np.random.rand(int(1e5)),
                       'c': np.random.rand(int(1e5)),
                       'd': np.random.rand(int(1e5))})
    # pandas does not have tqdm as a dependency, so we must import it manually
    f_tqdm = tqdm(total=len(df))
    # register the tqdm instance with the `progress_apply` method
    tqdm_pandas(f_tqdm)
    f = lambda df: df['a'] + df

# Generated at 2022-06-24 09:41:21.346107
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange

    tqdm_pandas(tclass=tqdm, desc='Test')

    n = 100
    df = pd.DataFrame({
        'A': np.random.randn(n),
        'B': np.random.randn(n),
        'C': np.random.randn(n),
        'D': np.random.randn(n)})
    df = df.groupby(['A', 'B']).progress_apply(lambda x: x**2 + 0.1)
    assert df.progress_apply(lambda x: x).equals(df)

    with tqdm(total=10) as pbar:
        for _ in trange(10):
            pbar

# Generated at 2022-06-24 09:41:30.089736
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    def progress_apply(df):
        tqdm.pandas(desc='apply')
        return df

    data = pd.DataFrame({'a':[1,2,3], 'b':[4,5,6]})
    data.groupby('a').progress_apply(progress_apply)

    tqdm.tqdm_pandas(tqdm.tqdm())
    data.groupby('a').progress_apply(progress_apply)



if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:42.605653
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Imports
    from tqdm import tqdm
    from pandas import DataFrame, Series, cut
    from random import randint

    # Test initialisation
    try:
        from pandas import __version__ as pandas_version  # NOQA
        tqdm_pandas(tqdm, unit="s", total=400)
        DataFrame([randint(0, 99) for _ in range(400)]).progress_apply(
            lambda x: (x // 10 + 1) * 10)
    except ImportError:
        pass
    else:
        # Test compatibility with custom progress_apply
        def progress_apply(self, func, *args, **kwargs):
            return tqdm.pandas(self.apply(func, *args, **kwargs), unit="s")

        DataFrame.progress_

# Generated at 2022-06-24 09:41:46.566200
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        tqdm_pandas(tqdm.tqdm)
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
        tqdm_pandas(tqdm.tqdm(total=10))
        assert len(w) == 2
        assert issubclass(w[-1].category, TqdmDeprecationWarning)


# =============================================================================
# Main
# =============================================================================

if __name__ == '__main__':
    from .gui import tqdm_gui

# Generated at 2022-06-24 09:41:55.099618
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    for tclass in [tqdm, tqdm(leave=False),
                   tqdm.tqdm_notebook, tqdm.tqdm_notebook(leave=False),
                   tqdm.tqdm_pandas(ascii=True),
                   tqdm.tqdm_pandas(ncols=200),
                   tqdm.tqdm_gui, tqdm.tqdm_gui(leave=False),
                   ]:
        # Test on Series
        s = pd.Series(range(10))

# Generated at 2022-06-24 09:41:57.174433
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tclass = tqdm(range(10))
    tqdm_pandas(tclass)

# Generated at 2022-06-24 09:42:01.798724
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm.auto

    pd.options.mode.chained_assignment = None  # default='warn'

    df = pd.DataFrame(np.random.random((100000, 5)))
    tqdm_pandas(tqdm.auto.tqdm(leave=False))
    df.progress_apply(lambda x: x)

# Generated at 2022-06-24 09:42:06.057435
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tclass=tqdm, desc='', unit_scale=False,
                miniters=1, leave=True)

# Unit test: pandas
if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:14.222202
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm, trange
    from time import sleep
    # Register tqdm
    tqdm.pandas()

    n = 10000
    x = pd.Series(np.random.randint(0, n, n))
    df = pd.DataFrame()
    df["x"] = x
    df["y"] = x.progress_apply(lambda x: sleep(0.1) or 1)
    with trange(10) as t:
        for i in t:
            df["y"] = df["x"].progress_apply(lambda x: sleep(0.1) or 1)
    assert np.all(np.asarray(x) == np.asarray(df["x"]))
    assert np.all

# Generated at 2022-06-24 09:42:18.945549
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas()."""
    import numpy as np, pandas as pd
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    sum_df = df[0].groupby(df[1]).progress_apply(sum)
    mean_df = df[2].groupby(df[3]).progress_apply(np.mean)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:29.109710
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    from tqdm import tqdm
    try:
        import pandas as pd
    except ImportError:
        print('pandas not found')
        return
    try:
        pd.DataFrame([1, 2]).groupby(0).progress_apply(lambda x: x)
    except AttributeError:
        print('pandas is too old')
        return
    tqdm_pandas(tqdm(total=1))
    tqdm_pandas(tqdm(total=1), file=sys.stdout)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, file=sys.stdout)

# Generated at 2022-06-24 09:42:38.751374
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, TqdmDeprecationWarning
    import warnings

    array = np.random.randint(0, 100, size=[1000, 1000])
    df = pd.DataFrame(array)

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmDeprecationWarning)
        # create a registered progress bar with pandas. This progress bar
        # will be updated while applying a function to a group of data.
        tqdm_pandas(tqdm())

    def foo(x):
        # Apply this function followed by a sleep to each group.
        # The progress bar should be updated while the function
        # is running.
        time.sleep(1e-4)
        return x



# Generated at 2022-06-24 09:42:48.784584
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        import pandas as pd
    except ImportError:
        return
    pd.DataFrame({'x': [1, 2, 3]}).groupby('x').progress_apply(lambda x: x)
    pd.DataFrame({'x': [1, 2, 3]}).groupby('x').progress_apply(lambda x: x, meta=str)
    pd.DataFrame({'x': [1, 2, 3]}).groupby('x').progress_apply(lambda x: x, meta={'x': 1})
    # Dict returned instead of Series
    pd.DataFrame({'x': [1, 2, 3]}).groupby('x').progress_apply(lambda x: {'x': x})
    # pandas >= 0.

# Generated at 2022-06-24 09:42:52.166716
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm as tqdm_auto

    with tqdm_auto.disable:  # noqa
        tqdm_auto.tqdm_pandas()  # noqa

# Generated at 2022-06-24 09:43:01.756070
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series, concat
    from numpy import random as rnd
    from time import sleep
    from tqdm.autonotebook import tqdm
    from tqdm.contrib.tests import pretest_posttest

    df = DataFrame(
        {"A": Series(
            rnd.randn(10000) * 10 + 100).apply(
            lambda x: int(x))})
    ans = df.groupby("A").agg("count")
    ans["B"] = df.groupby("A").progress_apply(
        lambda x: x["A"].sum()).to_frame("B")


# Generated at 2022-06-24 09:43:12.290353
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    try:
        from tqdm import tqdm, TqdmTypeError
    except ImportError:
        return

    df = pd.DataFrame({'A': [10, 20, 30]})
    tqdm_pandas(tqdm, unit='B', unit_scale=True, miniters=1,
                desc="testing tqdm_pandas")
    for _ in tqdm(df.groupby('A').progress_apply(lambda x: x), total=3,
                  desc="testing 1"):
        pass
    for _ in tqdm(df.groupby('A').progress_apply(lambda x: x)):
        pass

# Generated at 2022-06-24 09:43:14.494941
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm, desc="test pandas")

# Generated at 2022-06-24 09:43:19.013890
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame([[1] * 100] * 200)
    for _ in tqdm(df.groupby(0)):
        pass

    for _ in tqdm_pandas(tqdm(), total=len(df)):   # `tqdm` instance
        pass

# Generated at 2022-06-24 09:43:25.575118
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.api.types import is_integer_dtype
    import pandas as pd
    import numpy as np

    # Test that value_counts are preserved
    df = DataFrame({
        'a': np.random.randint(0, 100, size=1000),
        'b': np.random.randint(0, 5, size=1000)
    })

    tqdm_pandas(tqdm)
    with tqdm(total=df.shape[0]) as pbar:
        df_res = df.groupby('b').progress_apply(lambda x: x['a'].value_counts())

        assert pbar.n == df.shape[0], "Progress bar value was not properly updated"


# Generated at 2022-06-24 09:43:34.128263
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    pd.DataFrame({'x': np.random.randint(100, size=100)}) \
        .groupby('x') \
        .progress_apply(lambda x: x)
    tclass = tqdm(total=10)
    tqdm_pandas(tclass)
    tqdm_pandas(tclass, total=10)
    tqdm_pandas(tclass, total=10, dynamic_ncols=True)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:36.106997
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'a': [1, 2, 3]})
    tqdm.pandas(desc='foo')
    df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:43:42.280547
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    from tqdm import tqdm
    from pandas import DataFrame
    from time import sleep

    df = DataFrame(np.random.random((10, 2)))

    # tqdm case
    tqdm_pandas(tqdm(mininterval=0,
                     disable=False,
                     smooth=0,
                     gui=False,
                     leave=True,
                     file=sys.stderr))

    def test_func(x):
        sleep(0.01)
        return x

    df.progress_apply(test_func, axis=1)

    # tqdm_notebook case
    from tqdm.notebook import tqdm_notebook


# Generated at 2022-06-24 09:43:51.303516
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    from tqdm.contrib import pandas
    import pandas as pd
    import numpy as np
    old_pandas_backend = getattr(pd, '_config', {}).get('assign_options_to_attributes')
    pd.reset_option('assign_options_to_attributes')

# Generated at 2022-06-24 09:43:57.805863
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import tqdm
    tqdm.tqdm = tqdm.tqdm_notebook

    a = pandas.DataFrame({"A": ["a" * 10, "a" * 10, "a" * 10, "a" * 10, "a" * 10]})
    b = a.groupby([0] * 10).progress_apply(len)

# Generated at 2022-06-24 09:44:05.899060
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        print('Unable to import pandas; skipping test')
        return
    try:
        from tqdm.auto import tqdm
    except ImportError:
        print('Unable to import tqdm; skipping test')
        return

    df = pd.DataFrame({"A": [1, 2, 3, 4], "B": [1, 1, 2, 2]})
    data = df.groupby('B').progress_apply(lambda x: x)
    assert data.equals(df)
    data = df.groupby('B').progress_apply(lambda x: x)
    assert data.equals(df)



# Generated at 2022-06-24 09:44:12.845348
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    try:
        import pandas as pd
    except ImportError:
        print("pandas not installed")
        return
    tqdm_pandas(
        # tqdm(total=100, desc="Progress: ", leave=False),
        tqdm,
        total=100,
        desc="Progress: ",
        leave=False,
    )
    pd.DataFrame([1, 2, 3]).progress_apply(lambda x: x + 1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:22.868316
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    from tqdm.autonotebook import tnrange
    from tqdm.autonotebook import tqdm
    from tqdm.autonotebook import tqdm_notebook
    from tqdm.autonotebook import trange

    def randn(*args):
        return numpy.random.randn(*args)

    numpy.random.seed(10)
    df = pandas.DataFrame(randn(100000, 4), columns=list('ABCD'))
    # ---
    for t in (trange, tnrange, tqdm, tqdm_notebook):
        with t(total=100) as pbar:
            pbar.set_description('new desc')

# Generated at 2022-06-24 09:44:30.769578
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    # Test for bug #117
    df = pd.DataFrame([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    df.groupby(df[0].apply(lambda x: x)).progress_apply(lambda x: x ** 2)
    type(tqdm_pandas(tqdm(pandas=True))).pandas(tqdm_pandas(tqdm(pandas=True)))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:40.284368
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from time import sleep
    df = pandas.DataFrame({"A": [], "B": []})
    # print(df.groupby("A").progress_apply(lambda x: sleep(1)))
    # Doesn't work without tqdm_pandas
    tqdm_pandas(tqdm_kwargs={"desc": "test"})
    print(df.groupby("A").progress_apply(lambda x: sleep(1)))
    # print(df.groupby("A").progress_apply(lambda x: sleep(1), file=sys.stdout))
    # print(df.groupby("A").progress_apply(lambda x, file=sys.stdout: sleep(1)))
    # print(df.groupby("A").progress_apply(lambda x: tqdm(sleep(1

# Generated at 2022-06-24 09:44:49.093690
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    frame = pandas.DataFrame({'a': range(1000), 'b': range(1000)})

    def square(row):
        return row['a'] ** 2

    frame.groupby('b').progress_apply(square)
    assert True


try:
    import pandas
except ImportError:
    pass
else:
    import tqdm

    _tqdm = tqdm.tqdm
    PANDAS_INSTALLED = True
    try:
        from pandas.core.groupby import DataFrameGroupBy, SeriesGroupBy
    except ImportError:
        # For old pandas (v0.18)
        from pandas.core.groupby import DataFrameGroupBy, SeriesGroupBy
        PANDAS_INSTALLED = False


# Generated at 2022-06-24 09:44:58.161144
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import pandas as pd
    import numpy as np
    df = pd.DataFrame([[i, i + 3] for i in range(10)], columns=["A", "B"])
    series = df.groupby('A').progress_apply(lambda x: sum(x))  # noqa
    if not isinstance(series, pd.core.series.Series):
        raise Exception("pandas is not patched")
    try:
        series.sum()
    except AttributeError:
        raise Exception("pandas is not patched")
    tqdm_kwargs = dict(miniters=1, mininterval=0, total=len(df))

# Generated at 2022-06-24 09:45:01.505352
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm_pandas(total=10) as t:
        for i in range(10):
            t.update()

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:04.254504
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    pd.DataFrame([1, 2, 3]).groupby(lambda x: x).progress_apply(lambda x: x)


# Module level imports
from .std import tqdm as _tqdm

# Register `tqdm_pandas` with `tqdm`, for convenience
_tqdm.pandas = tqdm_pandas


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:11.242384
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        import pandas as pd
    except ImportError:
        return

    try:
        import numpy as np
    except ImportError:
        return

    df = pd.DataFrame(
        np.random.randn(10, 2), columns=['col1', 'col2'])
    with closing(StringIO()) as s:
        try:
            df.progress_apply(lambda x: x * x, axis=1, file=s)
        except TypeError:
            pass
    return


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:21.569216
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import unittest
    from unittest import TestCase
    from tqdm.utils import _supports_unicode


    class PandasTest(TestCase):
        def setUp(self):
            from pandas import DataFrame
            from numpy import arange

            self.df = DataFrame(arange(10))

        @unittest.skipUnless(_supports_unicode() and (
                hasattr(tqdm, '_version') or hasattr(tqdm, '__version__')),
                             "requires unicode support")
        def test_register_pandas(self):
            """Test tqdm_pandas (pandas.DataFrame.progress_apply)"""
            from pandas.core.groupby import DataFrameGroupBy


# Generated at 2022-06-24 09:45:27.484807
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'a': [0, 1, 2], 'b': [3, 4, 5]})
    df = tqdm.tqdm_pandas(tqdm.tqdm(), df)
    df = df.groupby('a').progress_apply(lambda x: x)
    # Should not raise any error

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:33.614894
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit testing function tqdm_pandas
    """
    import tqdm
    import pandas as pd
    df = pd.DataFrame({'a': [1, 2, 3, 4]})
    with tqdm.tqdm(total=len(df)) as t:
        df.apply(lambda x: t.update())
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas(pd.core.groupby.DataFrameGroupBy.progress_apply)  # noqa
    with tqdm.tqdm(total=len(df) * 2) as t:
        df.groupby(df.a // 2).progress_apply(lambda x: t.update())

# Generated at 2022-06-24 09:45:35.336515
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas([1, 2, 3])

# Generated at 2022-06-24 09:45:43.921039
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm, tqdm_pandas
    from tqdm import trange

    df = DataFrame([range(20)])

    print(df.groupby(0).progress_apply(lambda x: x))
    with trange(1) as t:
        print(df.groupby(0).progress_apply(lambda x: x, t=t))

    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(total=1))
    tqdm_pandas(tqdm_pandas())  # no-op

    with trange(1) as t:
        df = DataFrame([range(20)])
        tqdm_pandas(t)