

# Generated at 2022-06-24 09:35:45.851579
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.util.testing import assert_frame_equal

    from tqdm.pandas import tqdm_pandas
    from tqdm import tqdm
    tqdm_pandas(tqdm)

    # if we apply a function, then it should be the same as without tqdm_pandas
    df = DataFrame({'a': [1, 2, 3]})
    df1 = df.progress_apply(lambda x: x)
    df2 = df.apply(lambda x: x)
    assert_frame_equal(df1, df2)

# Generated at 2022-06-24 09:35:56.753993
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import pandas as pd
    import numpy as np
    import math
    import sys
    import warnings
    old_pandas_apply = pd.core.groupby.DataFrameGroupBy.progress_apply

    def test_func(tqdm_kwargs, tclass):
        from tqdm import tqdm

        tqdm_pandas(tclass, **tqdm_kwargs)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # Smoke test
            gb = pd.DataFrame(dict(A=[], B=[])).groupby('A')
            gb.progress_apply(lambda x: x.sum())
            # Numeric smoke test

# Generated at 2022-06-24 09:36:08.114814
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`."""
    from pandas import DataFrame, Series
    import numpy as np
    import pandas as pd
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import tqdm

    tqdm_pandas(tqdm)

    assert hasattr(DataFrameGroupBy, "progress_apply")

    # Example
    df = DataFrame({"date": pd.date_range('20000101', periods=100),
                    "data1": np.random.randn(100).cumsum(),
                    "data2": np.random.randn(100)})
    df_ = df.groupby(Series(np.arange(len(df)) // 20))  # equivalent to .groupby(df.index//20)

# Generated at 2022-06-24 09:36:17.705260
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    from tqdm import tqdm
    from pandas import DataFrame

    # Test: without tqdm_pandas
    df = DataFrame({'A': [1, 2, 3]})
    df.groupby('A').progress_apply(lambda x: x)

    # Test: with tqdm_pandas
    df = DataFrame({'A': [1, 2, 3]})
    tqdm_pandas(tqdm)
    df.groupby('A').progress_apply(lambda x: x)


if __name__ == "__main__":
    """
    Load function test
    """
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:23.242589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm import tnrange
    tqdm(total=7, file=sys.stderr)
    tqdm.pandas()
    df = pd.DataFrame({'x': np.random.randint(100, size=100)})
    df.groupby(by=0).progress_apply(lambda x: x**2)
    for _ in tnrange(6):
        tqdm.write('hello world')
    for _ in tqdm(range(6)):
        tqdm.write('hello world')
    tqdm.close()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:26.708786
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    return tqdm_pandas(tqdm)  # NOQA, should not fail

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:31.078763
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm
        failed = False
    except (ImportError, KeyboardInterrupt):
        raise
    except:
        failed = True
    if not failed:
        tqdm_pandas(tqdm, desc='Testing')

# Unit tests for function tqdm_pandas in delayed adapter mode

# Generated at 2022-06-24 09:36:41.607881
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    tdf = pd.util.testing.makeDataFrame()
    for tclass in [tqdm, tqdm_notebook]:
        try:
            tclass.pandas(tdf.groupby(['A', 'B']).progress_apply(lambda x: x))
        except (ImportError, AttributeError):
            pass
        try:
            tqdm_pandas(tclass, _wcols=['A', 'B'])
            tclass.pandas(tdf.groupby(['A', 'B']).progress_apply(lambda x: x))
        except (ImportError, AttributeError):
            pass

# Generated at 2022-06-24 09:36:46.847897
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib import test_tqdm_pandas  # "test" module

    # Regression test for #562 (GitHub)
    df = pd.DataFrame([[1, 2], [3, 4], [5, 6]], columns=list("AB"))
    tqdm_pandas(df.groupby("A").progress_apply(lambda x: x["B"]))

# Generated at 2022-06-24 09:36:55.186998
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    import time

    df = pd.DataFrame({'x': np.random.randint(0, 100, (1000000,)),
                       'y': np.random.normal(size=(1000000,))})

    def progress_apply(df, func):
        with tqdm_pandas(total=df.shape[0]) as pbar:
            def wrapper(*args, **kwargs):
                pbar.update()
                return func(*args, **kwargs)
            return df.progress_apply(wrapper, axis=1)

    def slow_function(x, y, i):
        time.sleep(1e-6 * x * y)
        return x + y + i

    # check pandas functionality

# Generated at 2022-06-24 09:37:05.215480
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    try:
        # py3
        from unittest import mock
    except ImportError:
        # py2
        import mock
    with mock.patch('sys.stderr', new=io.BytesIO()) as mock_stderr:
        # Deprecated
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm())
        assert "Please use `tqdm.pandas(...)` instead" in mock_stderr.getvalue()

        # Correct
        tqdm(pandas=True)
        tqdm().pandas()

# Generated at 2022-06-24 09:37:14.759906
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # This function is executed automatically when pytest is run.

    # Silence all tqdm messages.
    tqdm_kwargs = {'disable': True}

    # Import pandas and test if it's installed.
    try:
        import pandas as pd
    except ImportError as e:
        pytest.skip("Could not import pandas: {}.".format(e))

    # Set up a DataFrameGroupBy with a custom aggregation function and test that the
    # aggregation function is called for each iteration.
    def aggfunc(group):
        # The following test fails if the aggregation function is not called.
        assert group.name == "AAA" or group.name == "BBB"


# Generated at 2022-06-24 09:37:24.689203
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    try:
        tqdm.pandas()
    except TypeError:
        pass  # maybe pandas is not installed

    try:
        tqdm_pandas(tqdm())
    except AttributeError:
        pass  # maybe pandas is not installed

    a = pd.DataFrame(
        {'A': np.random.choice(range(100), (1000, 1)),
         'B': np.random.choice(range(100), (1000, 1))})
    # test if pandas is installed
    try:
        _ = a.groupby('A').progress_apply(lambda x: x)
    except AttributeError:
        return


# Generated at 2022-06-24 09:37:31.570125
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    from tqdm import tqdm
    from pandas import DataFrame, Series
    df = DataFrame(np.arange(12).reshape((4, 3)), columns=list('abc'))
    df = df.apply(tqdm, axis=1, miniters=1)
    s = Series(np.arange(6), name='x')
    s = s.map(tqdm, na_action=None)
    list(map(tqdm, [1, 2, 3], miniters=1))
    list(map(tqdm, [1, 2, 3], miniters=3))
# end_unit_test

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:41.522316
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm
    from tqdm import tqdm_pandas
    from random import random
    from time import sleep
    df = 100000 * pd.DataFrame({'A': [random() for _ in range(1000)]})
    with tqdm(total=len(df), unit='rows', smoothing=0) as pbar:
        df.groupby(df.A // 0.1).progress_apply(lambda x: sleep(0.01) or x,
                                               meta={'A': float, 'B': int}).head(5)
        pbar.update(len(df))

# Generated at 2022-06-24 09:37:52.711269
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import numpy as np
    import pandas as pd
    from pandas import DataFrame
    from tqdm import tqdm, pandas
    from tqdm._tqdm import TqdmDeprecationWarning
    from tqdm.contrib.concurrent import process_map, thread_map

    try:
        assert issubclass(TqdmDeprecationWarning, DeprecationWarning)
    except AssertionError:
        print("SKIP: TqdmDeprecationWarning not available")
        return

    df = DataFrame(np.random.randint(0, 100, (100000, 6)), columns=list('ABCDEF'))
    original_stdout = sys.stdout

    # Test: tqdm_pandas(tqdm

# Generated at 2022-06-24 09:38:02.079559
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import shutil
    import tempfile

    try:
        tmpdir = tempfile.mkdtemp()
        out = os.path.join(tmpdir, 'out')
        with open(out, 'w') as fp:
            fp.write('\n'.join(tqdm_pandas(tqdm(range(200)))))
        with open(out, encoding='utf-8') as fp:
            assert fp.read() == '\n'.join(str(s) for s in tqdm(range(200)))
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-24 09:38:12.064827
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange
    df = pd.DataFrame()
    df['data'] = list(range(1, 100000))
    df.groupby(['data']).count()
    tqdm(pandas=True)
    df.groupby(['data']).count()
    tqdm_pandas(tqdm(pandas=True))
    df.groupby(['data']).count()
    tqdm_pandas(tqdm())
    df.groupby(['data']).count()
    tqdm_pandas(tqdm(tclass=tqdm))
    df.groupby(['data']).count()

# Generated at 2022-06-24 09:38:22.553336
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    # Check that `progress_apply` is called
    with tqdm.pandas() as t:
        df = pd.DataFrame({'a': range(10), 'b': range(10)})
        t.fp.write('called!')
        assert df.progress_apply(len) is not None, "progress_apply is not used"
        assert not t.n, "n has not been reset"
    # Check that `progress_apply` is called when `tqdm` is passed as a parameter
    with tqdm(total=10) as t:
        df = pd.DataFrame({'a': range(10), 'b': range(10)})
        tqdm_pandas(t)
        assert df.progress_apply

# Generated at 2022-06-24 09:38:26.971754
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame, Series
    except ImportError:
        return
    from tqdm import tqdm_gui
    df = DataFrame({'A': Series([1, 2, 3]),
                    'B': Series([1, 2, 3]),
                    'C': Series([1, 2, 3])})
    try:
        df.groupby('B').progress_apply(lambda x: x)
    except AttributeError:
        return
    tqdm_pandas(tqdm_gui())
    try:
        df.groupby('B').progress_apply(lambda x: x)
    except Exception:
        raise AssertionError(
            "`tqdm.pandas(tqdm_gui)` does not work (progress bar does not show)")
    tqdm_p

# Generated at 2022-06-24 09:38:38.539712
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        return
    import pandas as pd
    import numpy as np
    np.random.seed(42)
    tqdm_kwargs = dict(
        disable=False,
        mininterval=0.1, miniters=1, glob_tqdm=False, leave=True,
        total=None, unit_scale=False)
    try:
        from tqdm import tqdm, trange
        tqdm_kwargs['miniters'] = 10
        tqdm_kwargs['total'] = 10
    except ImportError:
        tqdm = lambda x: x
        trange = range

    # 1. Test pandas functionality
    ####################################################################

# Generated at 2022-06-24 09:38:48.858842
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm.pandas`, all functions in `tqdm.pandas`"""
    from pandas.core.groupby import DataFrameGroupBy
    from pandas.core.groupby import SeriesGroupBy
    from tqdm import tqdm
    from pandas import DataFrame, Series

    # noinspection PyUnresolvedReferences
    class PandasTqdm(tqdm):
        """
        dummy class to test the calling of `tqdm.pandas(...)`
        """

        # noinspection PyShadowingBuiltins
        def pandas(self, t=None, total=None, desc=None, leave=None,
                   **tqdm_kwargs):
            """
            dummy `tqdm.pandas` which only prints the given arguments
            """

# Generated at 2022-06-24 09:38:59.790056
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import trange
    from tqdm.tests import MockTqdmType

    pd.DataFrame([1, 2, 3]).\
        progress_apply(lambda x: x + 1,
                       progress_args=(trange, {'desc': '0'}),
                       args=(),
                       kwargs={})
    pd.DataFrame([1, 2, 3]).\
        progress_apply(lambda x: x + 1,
                       progress_args=(tqdm, {'desc': '1', 'dynamic_ncols': True}),
                       args=(),
                       kwargs={})

# Generated at 2022-06-24 09:39:06.611265
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    from tqdm.contrib.tests import dummy_iter

    for iterable in [(), [], dict(), set(), frozenset(), object()]:
        tqdm_pandas(tqdm(iterable))

    for N in [1, 2]:
        for iterable in dummy_iter.values():
            tqdm_pandas(tqdm(iterable(N)))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:08.344845
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:39:19.057880
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas()`."""
    import pandas
    from pandas import DataFrame

    def _test_single_tqdm_pandas(tqdm_cli, new_tqdm, **kwargs):
        def _test_func(df):
            tqdm_cli.update()
            return df

        N = 1e6
        F = 10000
        df = DataFrame().reindex(range(int(N)))
        df = df.dropna()
        for x in new_tqdm(range(int(F)), **kwargs):
            func = df.groupby(1).progress_apply(_test_func, axis=1)
            _ = func.head()  # noqa
        tqdm_cli.close()


# Generated at 2022-06-24 09:39:24.246315
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import warnings
    warnings.simplefilter("error")
    import pandas as pd
    from tqdm import tqdm

    with tqdm(total=2) as t:  # total=2 because decorator creates a new instance
        df = pd.DataFrame({'x': [1, 2]})
        df.groupby('x').progress_apply(lambda s: time.sleep(0.1))

# Generated at 2022-06-24 09:39:29.825379
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm
        tqdm.tqdm_pandas()
    except Exception:
        pass


tqdm_pandas.__test__ = False  # for NoseTests


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:33.781338
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm.tqdm_pandas(tclass=tqdm)
    tqdm.tqdm_pandas(tqdm, desc='test')

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:39:44.086839
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import time

    # setup the test
    df = pd.DataFrame({'f1': np.random.randint(low=0, high=100, size=1000),
                       'f2': np.random.uniform(size=1000)},
                      columns=['f1', 'f2'])
    df.f1 = df.f1.astype('category')
    df.f2 = df.f2.astype('float32')

    # test with pandas default agg method
    start = time.time()
    df.groupby(['f1']).progress_apply(lambda x: x.sum())
    elapsed_time = time.time() - start
    assert elapsed_time > 0.1, elapsed_time

    # test with numpy ufunc

# Generated at 2022-06-24 09:39:50.427211
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # test case 1
    try:
        c = '\x1b[?1034h'
        tqdm_pandas(c)
    except AttributeError as e:
        assert True, "Test case 1 success"
    except Exception as e:
        assert False, "Test case 1 failed"

    # test case 2
    try:
        tqdm_pandas()
    except DeprecationWarning as e:
        assert True, "Test case 2 success"
    except Exception as e:
        assert False, "Test case 2 failed"


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:00.802413
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:  # pragma: no cover
        import pandas  # NOQA
        import numpy  # NOQA
    except ImportError:  # pragma: no cover
        return
    import tqdm

    df = pandas.DataFrame({'a': numpy.random.randint(0, 100, 100)})
    tqdm_pandas(tqdm)  # check delayed adapter (deprecated)
    tqdm_pandas(tqdm.tqdm)  # check delayed adapter
    with tqdm.tqdm(total=len(df)) as t:  # check "forced" instance
        assert isinstance(df.progress_apply(lambda x: t.update()), pandas.Series)

# Generated at 2022-06-24 09:40:07.585565
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    orig_stdout = sys.stdout
    try:
        from io import StringIO
        import pandas as pd
        out = StringIO()
        sys.stdout = out
        tqdm_pandas(tclass=tqdm, file=out)
        orig_stdout.write(out.getvalue())
    finally:
        sys.stdout = orig_stdout


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:15.542691
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas
    """
    # Setup
    import pandas as pd
    import pandas.core.groupby
    import random
    import re
    import tqdm
    tqdm.monitor_interval = 0
    df = pd.DataFrame({'numbers': range(5),
                       'squares': [x ** 2 for x in range(5)],
                       'letters': ['a', 'b', 'c', 'd', 'e']})
    # Test
    with closing(StringIO()) as our_file, redirect_stdout(our_file):
        tqdm_pandas(tqdm)
        df.groupby('numbers').progress_apply(lambda x: None)
    output = our_file.getvalue()
    # Assert
   

# Generated at 2022-06-24 09:40:24.892199
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame as df
    from tqdm import tqdm
    from pprint import pprint

    progress = tqdm_pandas(tqdm())
    data = 0
    for i in progress((df(dict(a=range(100), b=range(100)))
                       .groupby('a').progress_apply(lambda x: x))):
        data += i['b'].sum()
    assert data == 328350

    data = (pd.DataFrame(dict(a=range(100), b=range(100)))
            .groupby('a').progress_apply(lambda x: x))
    pprint(data)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:35.845126
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    class tqdm_tqdm_tqdm(tqdm):
        def __init__(self, *args, **kwargs):
            self.total_max = 0
            self.total = 0
            super(tqdm_tqdm_tqdm, self).__init__(*args, **kwargs)

        def update(self, n=1):
            self.total += n
            self.total_max += self.total
            super(tqdm_tqdm_tqdm, self).update(n)

    def plus_one(x):
        for _ in trange(x + 1):  # Use trange instead of range for Py3.4 compat
            pass
        return x + 1


# Generated at 2022-06-24 09:40:44.133535
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    """Tests tqdm_pandas() for sanity"""
    from tqdm import tqdm, tqdm_pandas, TqdmDeprecationWarning
    import warnings

    tqdm_pandas(tqdm(desc='test'))

    # TqdmDeprecationWarning is raised when `python -Wd` is used
    # For example: python3.6 -Wd -m pytest tests/test_pandas.py
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmDeprecationWarning)
        tqdm_pandas(tqdm(desc='test'), file=open('/dev/null', 'w'))

# Generated at 2022-06-24 09:40:52.057403
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import unittest
    from pandas.util.testing import assert_frame_equal

    class Test(unittest.TestCase):
        def test(self):
            df = pd.DataFrame(
                [[1, 2], [3, 4], [5, 6], [7, 8]],
                columns=['a', 'b'])
            dg = df.copy()
            dg.a = dg.a.progress_apply(lambda x: x ** 2)
            assert_frame_equal(df ** 2, dg)


# Generated at 2022-06-24 09:40:57.593076
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm, tnrange
    __author__ = "github.com/casperdcl"
    # Make sure tqdm.pandas is registered with tqdm_gui()
    import pandas as pd
    df = pd.DataFrame({"a": [1, 2, 3, 4], "b": [2, 3, 4, 5]})
    with tqdm(total=df.progress_apply.__code__.co_argcount) as pbar:
        # Make sure tqdm_pandas is registered with tqdm_gui(...)
        with tnrange(4) as pbar:
            pbar.set_description("i")

# Generated at 2022-06-24 09:41:04.910545
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({'a': [1, 2, 3],
                       'b': [4, 5, 6]})

    # tqdm_pandas(tclass=tqdm(), apply=lambda x: x)
    tqdm(ncols=150).pandas(apply=lambda x: x)

    df.groupby('a').progress_apply(lambda x: x)
    df.groupby('a').progress_apply(lambda x: x)

    tqdm().pandas(apply=lambda x: x)
    tqdm().pandas(apply=lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:14.792995
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from unittest import TestCase, main
    from numpy.random import randn
    from pandas import DataFrame, Series, concat
    from tqdm import tqdm

    class TestTqdmPandas(TestCase):
        def test_initialization(self):
            def check(series):
                self.assertTrue(
                    series.equals(tqdm_pandas(tqdm(series), desc="foo")),
                    "Series are not equal!")
                self.assertTrue(
                    (series ** 2).equals(
                        tqdm_pandas(tqdm(series), desc="foo") ** 2),
                    "Series are not equal!")


# Generated at 2022-06-24 09:41:20.619360
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.rand(100, 2))
    with tqdm.pandas(desc='my bar!') as t:
        res = df.groupby(0).progress_apply(lambda x: x**2)
        assert (res.index == df.index).all()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:27.408293
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        from pandas.core.groupby import DataFrameGroupBy
    except:
        print("pandas not found, skipping test_tqdm_pandas()")
        return
    pd.DataFrame({'g': [0, 0, 1, 1],
                  'v': [0, 1, 0, 1]}).groupby('g').progress_apply(len)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:32.002640
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    # deprecated
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm())  # repeated call does nothing
    tqdm_pandas(tqdm)  # tqdm class explicit

    # recommended/supported
    tqdm.pandas()
    tqdm.pandas()  # repeated call does nothing


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:42.633961
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    from tqdm import tqdm, tqdm_gui
    from pandas import DataFrame
    from numpy.random import rand

    # Dummy DataFrame
    df = DataFrame({'x': rand(100), 'y': rand(100)})
    # Execute tqdm_pandas
    tqdm_pandas(tqdm, bar_format='{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]')
    df.groupby(['x']).progress_apply(lambda x: x.sum())
    tqdm_pandas(tqdm_gui)
    df.groupby(['x']).progress_apply(lambda x: x.sum())

# Generated at 2022-06-24 09:41:50.362024
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm.auto import tqdm
    from tqdm.notebook import tqdm as tqdm_notebook

    df = pd.DataFrame({
        'A': [1, 2, 3, 4, 5, 6, 7, 8, 9],
        'B': [10, 11, 12, 13, 14, 15, 16, 17, 18]
    })

    df_expected = pd.DataFrame({
        'A': [1, 2, 3, 4, 5, 6, 7, 8, 9],
        'B': [20, 22, 24, 26, 28, 30, 32, 34, 36]
    })


# Generated at 2022-06-24 09:41:57.174749
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas default use case"""
    from tqdm import tqdm_pandas as tqdm
    tqdm(pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]}), **{'leave': False}).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:03.259145
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        has_pandas = True
    except ImportError:
        has_pandas = False

    if has_pandas:
        from .tqdm import tqdm
        from pandas import DataFrame

        with tqdm.pandas(ncols=77) as t:
            DataFrame(range(1000)).progress_apply(t)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:12.341668
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from numpy import random, int32, arange
    from itertools import count
    from operator import mul
    from functools import reduce

    a = arange(100, dtype=int32)
    random.shuffle(a)

    df = DataFrame()
    df['a'] = a
    df['b'] = Series(a).apply(lambda x: x % 2 == 0)
    # FIXME: add more test cases
    # using ProgressBar
    ret = []
    for _ in tqdm(df.groupby('b').progress_apply(lambda x: mul(*x)),
                  desc='pandas test', leave=False):
        ret.append(_)

# Generated at 2022-06-24 09:42:16.250984
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np

        def test_transform(x):
            return [i ** 2 for i in x]

        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
        df.groupby(0).progress_apply(test_transform)
    except ImportError:
        return

# Generated at 2022-06-24 09:42:25.758407
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    data = pd.DataFrame(
        {'x': [1, 2, 3, 4, 5],
         'y': [0.001, 0.01, 0.1, 0.2, 0.3]})

    # explicit tqdm instance
    with tqdm.tqdm(total=len(data)) as pbar:
        def progress_apply(data, tqdm_wargs=None):
            return data.apply(lambda x: x, axis=1)

        progress = data.progress_apply(progress_apply)
        pbar.update(len(progress))

    # tqdm instance passed as an argument
    tqdm_instance = tqdm.tqdm(total=len(data), leave=False)
    progress = data.progress

# Generated at 2022-06-24 09:42:33.326137
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import tests
    import pandas as pd
    import random

    # Enable the function for tests
    tqdm_pandas(tests.tqdm)

    # allow one level of index
    df = pd.DataFrame(
        [[random.random() for _ in range(10)]
         for _ in range(10)],
        index=[random.randrange(10) for _ in range(10)])

    # .progress_apply()
    df.progress_apply(lambda x: sum(x), axis=1)

    # .progress_apply() with argument `desc`
    df.progress_apply(lambda x: sum(x), axis=1, desc='index')

    # .progress_apply() with argument `desc`

# Generated at 2022-06-24 09:42:34.213816
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(None)

# Generated at 2022-06-24 09:42:42.840936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_gui
    from .gui import tqdm_gui
    from .std import tqdm as tqdm_std
    # Test delayed adapter case
    tqdm_pandas(tqdm, ncols=50)
    tqdm_pandas(tqdm_gui, nrows=25)
    tqdm_pandas(tqdm_std, ncols=100)
    # Test tclass case
    tqdm_pandas(tqdm(ncols=123))
    tqdm_pandas(tqdm_gui(nrows=321))
    tqdm_pandas(tqdm_std(ncols=666))

# Generated at 2022-06-24 09:42:51.305294
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    # The tqdm_pandas function should be considered deprecated,
    # therefore we test that it still works as expected

    # Check that deprecated tqdm_pandas() is still working as expected
    tqdm_pandas(tqdm.tqdm)
    pd.DataFrame([1, 2]).progress_apply(lambda x: x + 1)

    # Check that delayed adapter case is still working as expected
    tqdm_pandas(tqdm.tqdm)
    pd.DataFrame([1, 2]).progress_apply(lambda x: x + 1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:01.621810
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame([
        {'col1': i}
        for i in tqdm.tqdm([1, 9, 10, 3], desc='df')
    ])

    def func(x):
        for _ in tqdm.tqdm([1, 9, 10, 3], desc='func', leave=False):
            pass
        return x['col1'] * 2

    assert df.progress_apply(func, axis=1)[0] == 2
    assert df.progress_apply(func, axis=1)[1] == 18
    assert df.progress_apply(func, axis=1)[2] == 20
    assert df.progress_apply(func, axis=1)[3] == 6


# Generated at 2022-06-24 09:43:12.105402
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    N = 100
    df = pd.DataFrame(np.random.rand(N, N))

    # Test without updating
    with tqdm_pandas():
        df.groupby(lambda x: x % 10).progress_apply(
            lambda x: x ** 2, meta=['cols', 'applying'])
        df.groupby(lambda x: x % 10).progress_apply(
            lambda x: x ** 2, meta=['cols', 'applying'], file=sys.stderr)

    # Test with updating

# Generated at 2022-06-24 09:43:19.321605
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        tqdm_pandas(tqdm)
        assert len(w) >= 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
        assert "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`." \
               in str(w[-1].message)


# for backwards compatibility

# Generated at 2022-06-24 09:43:23.847998
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pds

    with tqdm_pandas(total=42) as pbar:
        assert isinstance(pbar, tqdm)
        pbar.update(10)
        d = pds.DataFrame({"a": [1, 2, 3, 4], "b": [1, 2, 3, 4]})
        assert d.groupby("a").progress_apply(lambda x: x ** 2).sum().sum() == 72
        pbar.update(32)

# Generated at 2022-06-24 09:43:34.332734
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy import random
    from time import sleep

    df = DataFrame({'a': random.randn(100000), 'b': random.randn(100000)})

    # Test tqdm_pandas
    tqdm_pandas(tqdm)
    iterdf = df.groupby('a')
    list(enumerate(iterdf.progress_apply(lambda x: x)))
    assert iterdf.progress_apply(lambda x: x).equals(df)

    # Test tqdm_pandas2
    tqdm_pandas(tqdm(ascii=True, mininterval=0.1, miniters=1000))

# Generated at 2022-06-24 09:43:41.061754
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame

    # reset tqdm_gui's internal state
    from ._tqdm_gui import main as tqdm_gui_main
    tqdm_gui_main()

    # test both with and without custom gui
    for gui in ["nogui", "tqdm_gui"]:
        # test deprecation
        tqdm_pandas(tqdm, gui=gui)

        # test with `tqdm.pandas()`
        with tqdm.pandas(gui=gui) as t:
            # test progress_apply with `desc`
            tqdm.pandas(desc='hello world', gui=gui)
            DataFrame({"a": range(10)}).groupby("a").progress_apply(lambda x: x)

            # test progress_apply without

# Generated at 2022-06-24 09:43:50.661515
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        import pandas as pd
        import numpy as np
        tqdm_pandas(tqdm)
        arr = np.arange(10000).reshape((5000, 2))
        df = pd.DataFrame(arr)
        df.groupby(0, sort=False).progress_apply(lambda x: 1)
        tqdm_pandas(tqdm(desc='progress_bar'))
        df.groupby(0, sort=False).progress_apply(lambda x: 1)
    except ImportError:
        return
    except KeyError:  # Python 2
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:01.551702
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
    except ImportError:
        return
    tclass = tqdm_pandas
    tqdm_pandas(tclass, **{})
    tqdm_pandas(tclass)
    tqdm_pandas(tclass(total=5), desc="test")
    tqdm_pandas(tclass(), ascii=True)
    assert len(DataFrame([1, 2]).groupby(
        by=1).progress_apply.cache) == 1
    tqdm_pandas(tclass(total=0), desc="test")

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:11.268705
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:44:22.171690
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    from tqdm import tqdm
    from tqdm._tqdm_pandas import tqdm_pandas

    class apply_tester:
        n = 0

        def apply(self, function, axis=0):
            return function(self.n)

    # Test 1: with class
    class TestTQDM:
        pandas = tqdm_pandas
        fp = sys.stderr

    TestTQDM().pandas()
    assert apply_tester().apply(tqdm(ncols=100).__call__, axis=0) == 0

    # Test 2: with instance
    tt2 = TestTQDM()
    tt2.pandas()

# Generated at 2022-06-24 09:44:28.530247
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange

    for t in (tqdm, trange, lambda _: tqdm(total=_, desc='foo')):
        tqdm_pandas(t)
        assert hasattr(pd.core.groupby.DataFrameGroupBy, 'progress_apply'), \
            "`pd.core.groupby.DataFrameGroupBy` lacks `progress_apply`"

# Generated at 2022-06-24 09:44:36.755901
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm

    def foo(df):
        return df

    df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})

    df.groupby("A").progress_apply(foo)

    tqdm_pandas(tqdm(), total=len(df), leave=False)
    df.groupby("A").progress_apply(foo)
    tqdm_pandas(tqdm(total=len(df), leave=False))
    df.groupby("A").progress_apply(foo)
    tqdm_pandas(tqdm(total=len(df), leave=True))
    df.groupby("A").progress_apply(foo)

    tqdm_pandas(False)
   

# Generated at 2022-06-24 09:44:46.493047
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm
    from numpy.random import randint
    from numpy import concatenate, zeros
    from tqdm.autonotebook import tqdm as ntqdm
    from tqdm.contrib import pnds

    df = pandas.DataFrame(randint(0, 10, (100000, 10)), columns=list('abcdefghij'))

    df.rolling(20, center=False).sum()
    df.groupby('a').progress_apply(lambda x: x.sum())
    try:
        df.groupby('a').progress_apply(lambda x: x.sum(min_count=1))
    except NotImplementedError:
        pass


# Generated at 2022-06-24 09:44:57.078470
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with pytest.raises(ImportError):
        tqdm_pandas(None)

    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm(range(1000)))

    import pandas as pd
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(pd.DataFrame(range(1000)))

    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm(range(1000)), desc='pandas!')

    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(pd.DataFrame(range(1000)), desc='pandas!')


# Generated at 2022-06-24 09:45:00.317010
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test the deprecated function `tqdm_pandas(tqdm)`
    """
    from tqdm import tqdm, TqdmTypeError
    tqdm_pandas(tqdm)
    try:
        tqdm_pandas(tqdm.pandas)
    except TqdmTypeError:
        pass
    else:
        raise RuntimeError('tqdm_pandas(tqdm.pandas) failed!')

# Generated at 2022-06-24 09:45:07.966542
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import pandas as pd
    from tqdm import tqdm

    with tqdm(total=100, mininterval=0, miniters=10) as t:
        _ = pd.DataFrame(dict(a=range(100), b=range(100))) \
            .groupby('a') \
            .progress_apply(lambda df: df.a.sum())

    assert 'miniters' in t.miniters
    assert 'mininterval' in t.mininterval
    assert t.n == 100


if __name__ == '__main__':
    sys.exit(test_tqdm_pandas())

# Generated at 2022-06-24 09:45:12.647279
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({"col1": ["row" + str(i) for i in range(10)]})
    tqdm_pandas(tqdm, total=len(df), miniters=1)
    #tqdm_pandas(tqdm(), total=len(df), miniters=1)
    def apply_func(x):
        return x
    df.groupby(["col1"]).progress_apply(apply_func)



# Generated at 2022-06-24 09:45:22.580100
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def test(df):
        import time
        time.sleep(0.001)
        return df[:-1]

    df = pd.DataFrame({"a": [1, 2, 3, 4, 5, 6, 7],
                       "b": [1, 0, 3, 0, 5, 6, 0]})

    tqdm_pandas(type(tqdm_pandas))
    assert test(df).equals(test(df).progress_apply(test))

    tqdm_pandas(tqdm)
    assert test(df).equals(test(df).progress_apply(test))

    tqdm_pandas(tqdm(total=100))
    assert test(df).equals(test(df).progress_apply(test))

   

# Generated at 2022-06-24 09:45:30.748017
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm, TqdmDeprecationWarning
    mock_warn = [False]
    from unittest.mock import patch

    with patch('warnings.warn') as mock_warn_method:
        mock_warn_method.side_effect = lambda *args, **kwargs: mock_warn.__setitem__(0, True)
        tqdm_pandas(TqdmDeprecationWarning)
        assert mock_warn[0]

    with patch('warnings.warn') as mock_warn_method:
        mock_warn_method.side_effect = lambda *args, **kwargs: mock_warn.__setitem__(0, True)
        tqdm_pandas(tqdm)
        assert mock_warn[0]


# Generated at 2022-06-24 09:45:41.824331
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm._tqdm import tqdm
    from tqdm import trange

    # Init some dataframes
    df = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=list('ABCDEF'))
    df1 = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=list('ABCDEF'))
    df2 = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=list('ABCDEF'))

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(ncols=150))

   