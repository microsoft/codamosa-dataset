

# Generated at 2022-06-24 09:35:50.001531
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange, trange, tqdm, tqdm_notebook
    from random import random
    tqdm_pandas(tqdm)
    try:
        import pandas as pd
        # TODO: pandas >= 0.25 or dask >= 2.9 required
        try:
            pd.DataFrame([random() for _ in tqdm_notebook(range(10000))])
        except ImportError:
            pass
    except ImportError:
        pass

# Generated at 2022-06-24 09:35:57.239899
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy

    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(range(8)))
    tqdm_pandas(tqdm_notebook(range(8)))

    def square(x):
        import time
        time.sleep(0.05)
        return x * x

    df = pandas.DataFrame({'a': numpy.random.randint(0, 50, 100)})
    df.progress_apply(square).head()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:07.030630
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    with tqdm_pandas(total=None) as pbar:
        assert pbar.last_print_n == 0
        total = 100000
        df = pandas.DataFrame(dict(idx=range(total),
                                   text=['a'] * total))
        for _ in df.groupby("idx").progress_apply(lambda x: None):
            pass
    assert pbar.last_print_n >= total
    assert pbar.n >= total
    return

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:17.252706
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import random
    from tqdm import tqdm

    tqdm_pandas(tqdm)

    def tqdm_test():
        return pd.DataFrame([random.random() for _ in range(100000)])

    pd.DataFrame([random.random() for _ in range(100000)])\
        .progress_apply(lambda x: x)\
        .progress_apply(lambda x: x, axis=0)\
        .progress_apply(lambda x: x, axis=1)\
        .progress_apply(lambda x: x, axis=1)\
        .progress_apply(lambda x: x, axis=0)\
        .progress_apply(lambda x: x)


# Generated at 2022-06-24 09:36:20.306184
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test
    try:
        tqdm_pandas(tqdm_gui)
        tqdm_pandas(tqdm_gui(total=100))
    except Exception as e:
        from tqdm import TqdmDeprecationWarning
        assert isinstance(e, TqdmDeprecationWarning)
        assert 'Please use `tqdm.pandas(...)` instead of ' in e.args[0]
    else:
        raise ValueError("Should have failed with deprecation warning")

# Generated at 2022-06-24 09:36:25.977660
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return  # no pandas: skip the test

    # 1. test register to pandas.core.groupby.DataFrameGroupBy.progress_apply
    pbar = tqdm_pandas(tqdm, leave=False)
    assert pandas.core.groupby.DataFrameGroupBy.progress_apply \
           == tqdm_pandas._register_to_pandas_progress_apply
    assert pandas.core.groupby.DataFrameGroupBy.progress_apply.tqdm \
           == pbar  # necessary to avoid tqdm_pandas(tqdm())
    assert pandas.core.groupby.DataFrameGroupBy.progress_apply.tqdm_kwargs \
           == {'leave': False}
    tq

# Generated at 2022-06-24 09:36:34.791024
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Skeleton for tqdm_pandas unit tests."""
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy.random import randint
    from numpy import arange
    from itertools import repeat
    try:
        from pandas import Series
    except ImportError:
        return

    # DataFrameGroupBy.apply
    df = DataFrame(randint(0, 10, (10000, 3)),
                   columns=['a', 'b', 'c'])
    dfgb = df.groupby('a')
    assert (dfgb.progress_apply(len) ==
            dfgb.apply(tqdm(len, leave=False)))

    # DataFrameGroupBy.aggregate

# Generated at 2022-06-24 09:36:44.303175
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function `tqdm_pandas()` """
    import pandas as pd
    from tqdm import tqdm as tqdm_
    from tqdm import tnrange, TqdmDeprecationWarning
    with TqdmDeprecationWarning(fp_write=sys.stderr.write):
        tqdm_pandas(tnrange(0))
        tqdm_pandas(tqdm_(0, file=sys.stderr))
        pd_df = pd.DataFrame(dict(zip(range(1, 4), [
                                  [0, 1, 2], [0, 1, 2], [0, 1, 2]])))

# Generated at 2022-06-24 09:36:45.466278
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm_pandas(tqdm)



# Generated at 2022-06-24 09:36:52.643756
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    df = pd.DataFrame({'a': np.random.rand(100)})
    with tqdm.tqdm(total=len(df)) as pbar:
        df.progress_apply(lambda x: pbar.update())
    assert pbar.n == len(df)

# NOTE: this function has been taken from the pandas project
# https://github.com/pandas-dev/pandas/blob/v0.22.0/pandas/core/apply.py#L554-L568

# Generated at 2022-06-24 09:36:55.891288
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm_pandas`"""
    from tqdm import tqdm
    from tqdm import tqdm_pandas

    tqdm_pandas(tqdm)

    for tcls in [tqdm, tqdm()]:
        tqdm_pandas(tcls)

    tqdm()

# Generated at 2022-06-24 09:37:04.281953
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    df = pd.DataFrame({'i': range(10 ** 4), 'j': range(10 ** 4)})
    df.groupby('i').progress_apply(lambda x: x)
    with tqdm(total=1) as t:
        tqdm_pandas(t)
        tqdm_pandas(tqdm)
        df.groupby('i').progress_apply(lambda sub_df: sub_df)
    assert len(tbar_instances()) == 0



# Generated at 2022-06-24 09:37:14.161815
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'a': [1, 4, 2, 3, 2, 5], 'b': [1, 2, 4, 3, 2, 5]})
    # Test if pandas's default progress bar is shown
    tqdm_pandas(tqdm.tqdm, tqdm.tqdm_pandas)
    df.groupby('a').progress_apply(lambda x: x)
    # Test if the one from tqdm is shown
    tqdm_pandas(tqdm.tqdm, tqdm.tqdm_pandas)
    df.groupby('a').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_p

# Generated at 2022-06-24 09:37:17.972574
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import trange
    from tqdm.contrib import pandas
    from tqdm.contrib.test_tqdm_pandas import test_tqdm_pandas_
    tqdm_pandas(tclass=pandas)
    test_tqdm_pandas_()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:26.969551
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    import pandas as pd
    import numpy as np
    if pd.__version__ >= '0.18':
        df = pd.DataFrame({'x': np.random.normal(size=100)})
        df.groupby("x").progress_apply(lambda x:x)
        df.apply(lambda x:x).progress_apply(lambda x:x)
    tqdm_pandas(tqdm(desc="foo"))
    tqdm_pandas(tqdm(desc="foo"), leave=False)

# Generated at 2022-06-24 09:37:38.513300
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.core.groupby.groupby import DataFrameGroupBy

    @tqdm_pandas
    def apply(df):
        return df.groupby(['name', 'gender']).sum()

    assert isinstance(apply(DataFrame({'name': [1, 2, 3],
                                       'gender': ['a', 'a', 'b'],
                                       'count': [1, 2, 3]})), DataFrameGroupBy)


# Generated at 2022-06-24 09:37:43.786130
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Test the deprecated tqdm_pandas function.
    Verify that it raises TqdmDeprecationWarning and invokes progress_apply
    method.
    '''
    # Install deprecation handler for testing purposes
    def handler(msg, *args, **kwargs):
        raise Exception('test_tqdm_pandas')
    warnings.simplefilter('always', TqdmDeprecationWarning)
    warnings.simplefilter('always', TqdmExperimentalWarning)
    with pytest.raises(Exception, match='test_tqdm_pandas'):
        with warnings.catch_warnings(record=True) as w:
            warnings.showwarning = handler
            tqdm_pandas(tqdm, total=10)
            warnings.showwarning = handler
            tqdm_p

# Generated at 2022-06-24 09:37:53.313604
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from tqdm.contrib.tests import TqdmTestCase

    class TestTqdmPandas(TqdmTestCase):
        def test_tqdm_pandas(self):
            tqdm_pandas(tqdm())
            df = DataFrame({'a': [1, 2, 3], 'b': [1, 2, 3], 'c': [1, 2, 3]})
            r = df.groupby('a').progress_apply(
                lambda x: x['b'] + x['c']).to_dict()
            with self.assertWritesToTqdmWrite():
                r = df.groupby('a').progress_aggregate(
                    lambda x: x['b'] + x['c']).to_dict

# Generated at 2022-06-24 09:38:04.285814
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit tests for `tqdm_pandas`

    """
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas

    N = 100
    df = pd.DataFrame({'x': np.random.random(size=N)})
    tqdm_pandas(df.groupby('x').progress_apply(lambda x: x**2))

    df = pd.DataFrame({'x': np.random.random(size=N)})
    tqdm_pandas(tqdm(df.groupby('x')).progress_apply(lambda x: x**2))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:13.906767
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm_gui, trange

    df = DataFrame({'x': Series([1, 2, 3])})

    # Test with tqdm
    tqdm_pandas(tqdm(leave=False, total=len(df)))
    df['x'].progress_apply(lambda x: x ** 2)

    # Test with tqdm_gui
    tqdm_pandas(tqdm_gui(leave=False, total=len(df)))
    df['x'].progress_apply(lambda x: x ** 2)

    # Test with trange
    tqdm_pandas(trange(leave=False, total=len(df)))
    df['x'].progress_apply(lambda x: x ** 2)
    # Test

# Generated at 2022-06-24 09:38:24.092977
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from pandas import DataFrame

    df = DataFrame({'x': [1, 2, 3]})
    for i in trange(1, leave=False):
        with tqdm_pandas(total=df.shape[0]) as pbar:
            df.x.progress_apply(lambda x: x + i)
            pbar.update(df.shape[0])
    for i in trange(1, leave=False):
        with tqdm_pandas(total=df.shape[0]) as pbar:
            df.x.progress_apply(lambda x: x + i)
            pbar.update()

# Generated at 2022-06-24 09:38:35.024653
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from colorama import Fore, Style

    try:
        import pandas as pd
    except ImportError:
        return

    progress_bar = tqdm_pandas(tqdm_notebook, unit='B', unit_scale=True, leave=True)
    df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 2, 8], "C": [10, 20, 30]})

    data_size = math.fsum(sys.getsizeof(i) for i in df.itertuples())

# Generated at 2022-06-24 09:38:45.789528
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        # For Python3.3 we need mock
        from unittest import mock
    except ImportError:
        try:
            # For Python3.2 we need mock
            import mock
        except ImportError:
            # For Python2 we need mock
            from unittest import mock

    with mock.patch('tqdm.std.sys.stderr', new_callable=mock.PropertyMock) as mock_stderr:
        from tqdm import TqdmTypeError, TqdmDeprecationWarning
        from tqdm.std import tqdm  # , tqdm_gui

        # Test case 1: Pandas API.

# Generated at 2022-06-24 09:38:53.028418
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from numpy.random import random
    import pandas

    # Test all variants of tqdm_pandas
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm().__class__)
    try:
        tqdm_pandas(tqdm().__class__())
    except TypeError:
        pass  # expected
    tqdm_pandas(tqdm().__class__, total=10)
    tqdm_pandas(tqdm, total=10)

    # Test by hand
    if 'pandas' in sys.modules:
        from pandas.core.groupby import DataFrameGroupBy

# Generated at 2022-06-24 09:38:58.717295
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from unittest import TestCase

    tqdm.pandas()
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm)
    TestCase().assertRaises(TypeError, tqdm_pandas)
    TestCase().assertRaises(TypeError, tqdm_pandas, tqdm, monkey=True)

# Generated at 2022-06-24 09:39:08.482055
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame({'time': [i for i in range(10**5)]})
    df.groupby('time').progress_apply(lambda x: x)

    tqdm_pandas(tqdm)
    df = pd.DataFrame({'time': [i for i in range(10**5)]})
    df.groupby('time').progress_apply(lambda x: x)

    tqdm_pandas(tqdm(total=10**5))
    df.groupby('time').progress_apply(lambda x: x)

    tqdm_pandas(tqdm(ascii=True))
    df.groupby('time').progress_apply(lambda x: x)

    tqdm_

# Generated at 2022-06-24 09:39:19.238455
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Monkey patch
    class tqdm(object):
        @classmethod
        def pandas(cls, deprecated_t=None):
            return deprecated_t.close() if deprecated_t else None

    tqdm.pandas = staticmethod(tqdm.pandas)

    class tqdm_class(object):
        fp = 0

        @classmethod
        def pandas(cls, **kwargs):
            return cls.__name__

        def __init__(self, *args, **kwargs):
            self.__name__ = 'tqdm_class'

    tqdm_class.__name__ = 'tqdm_class'

    class tqdm_class_new(object):
        fp = 0


# Generated at 2022-06-24 09:39:27.440781
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from tqdm.auto import tqdm, trange
    from pandas import DataFrame, concat
    from numpy.random import randint

    try:
        import pandas
    except ImportError:
        try:
            import pandas as pd
        except ImportError:
            return

    # test 1
    tqdm_pandas(tqdm)
    tqdm.pandas(tqdm)

    # test 2
    tqdm_pandas(tqdm())
    tqdm(tqdm()).pandas()

    # test 3
    tqdm_pandas(trange)
    trange.pandas(trange)
    for _ in trange(1):
        pass

    #

# Generated at 2022-06-24 09:39:36.572005
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm.auto import trange
    from tqdm.contrib.concurrent import process_map

    df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 4)),
                      columns=list('ABCD'))

    def prog_apply(df):
        def _sum(data):
            return pd.Series(data[0] + data[1] + data[2])

        return df.groupby('A').progress_apply(_sum)

    df = prog_apply(df)


# Generated at 2022-06-24 09:39:42.956671
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Delayed case
    tqdm_pandas(tqdm)
    # Active case
    tqdm_pandas(tqdm(0))
    # Deprecated
    try:
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            # Delayed case
            tqdm_pandas(tqdm, file=sys.stdout)
            assert len(w) == 1
            assert issubclass(w[-1].category, TqdmDeprecationWarning)
        # Active case
        tqdm_pandas(tqdm(0, file=sys.stdout))
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
    finally:
        pass

# Generated at 2022-06-24 09:39:50.845280
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas
    """
    from tqdm import tqdm, TqdmDeprecationWarning
    from pandas import DataFrame
    from pandas import read_csv

    pandas_version = [int(x) for x in re.findall(r"[\d']+", pd.__version__)]
    if pandas_version >= [0, 21, 0]:
        test_df = DataFrame(range(100))
        test_csv = os.path.join(os.path.dirname(__file__), 'test.csv')
        with tqdm(total=3) as t:
            test_df.progress_apply(lambda x: t.update())

# Generated at 2022-06-24 09:39:55.634779
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, desc='testing tqdm_pandas')
    tqdm_pandas(tqdm, desc='testing tqdm_pandas', total=1)



# Generated at 2022-06-24 09:40:04.092526
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randn(1000, 10))
    with tqdm_pandas(total=len(df), unit='it') as t:
        df.progress_apply(lambda x: np.sum(x), axis=1)
    assert t.total == len(df)

    with tqdm_pandas(total=len(df), unit='it') as t:
        df.progress_apply(lambda x: np.sum(x), axis=1)
    assert t.total == len(df)

    t = tqdm_pandas()
    df = pd.DataFrame(np.random.randn(1000, 10))
    t.pandas(total=len(df), unit='it')


# Generated at 2022-06-24 09:40:13.789130
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Unit tests for deprecated tqdm_pandas() function.
    '''
    from tqdm import tqdm
    from tqdm._utils import _deprecated_alias  # avoid pyflakes
    from tests_tqdm import with_setup

    @_deprecated_alias(tclass=tqdm)
    def tqdm_pandas(tclass, **tqdm_kwargs):
        return tqdm(**tqdm_kwargs)

    # Test the deprecated tqdm_pandas()
    @with_setup(setup=tqdm_pandas)
    @with_setup(teardown=lambda: tqdm.pandas(False))
    def inner_test_tqdm_pandas():
        import pandas
        tqdm.p

# Generated at 2022-06-24 09:40:16.765175
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame

    def slow_function(x):
        import time
        time.sleep(1.0)
        return x

    df = DataFrame(dict([(k, [k] * 1000) for k in range(10)]))

    tqdm_pandas(df.groupby(0).progress_apply(slow_function))

# Generated at 2022-06-24 09:40:22.075148
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Registers the given `tqdm` instance with
    `pandas.core.groupby.DataFrameGroupBy.progress_apply`.
    """
    from tqdm import tqdm
    tqdm.pandas()


###############################################################################
#                                 Backported                                  #
###############################################################################


# Generated at 2022-06-24 09:40:34.335507
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # type: () -> None
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas

    df = pd.DataFrame(dict(a=np.random.randn(1e6), b=np.random.randn(1e6)))

    (df.groupby(['a'])
     .progress_apply(lambda x: x ** 2)  # type: ignore
     .head(100))

    (df.groupby(['a'])
     .progress_apply(lambda x: x ** 2)  # type: ignore
     .head(100))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:42.053053
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        df = pd.DataFrame({'a': [1, 2, 3, 4], 'b': [2, 3, 4, 5]})

        tqdm_pandas(tqdm, total=len(df))
        df.progress_apply(lambda x: x, axis=1)
        df.progress_apply(lambda x: x, axis=1)

        tqdm_pandas(tqdm(total=len(df)))
        df.progress_apply(lambda x: x, axis=1)
        df.progress_apply(lambda x: x, axis=1)

# Generated at 2022-06-24 09:40:49.822145
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmTypeError
    import numpy as np
    import pandas as pd
    from pandas import DataFrame
    import pandas.core.groupby
    from pandas.core.groupby import DataFrameGroupBy

    pandas.core.groupby.DataFrameGroupBy.progress_apply = None

    # Test 0
    try:
        tqdm_pandas(1)
    except TqdmTypeError:
        pass
    else:
        raise AssertionError()

    # Test 1: following error must be raised
    # TypeError: decorator() takes exactly 1 argument (2 given)

# Generated at 2022-06-24 09:40:55.971026
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from datetime import datetime, timedelta
    from tqdm import tqdm
    from tqdm.contrib import pandas
    # basic test
    for _ in tqdm(pd.date_range(datetime.today(),
                                datetime.today() + timedelta(days=1),
                                freq='H')):
        pass
    # function test
    df = pd.DataFrame([i for i in range(10000)])
    df.groupby(0).progress_apply(lambda x: x + 1)


if __name__ == '__main__':
    _LIGHT_BLUE = '\033[94m'
    _BOLD_BLUE = '\033[1m\033[94m'

# Generated at 2022-06-24 09:41:02.744779
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas.core.groupby import DataFrameGroupBy

    dfgb = DataFrameGroupBy(object(), object())
    assert hasattr(dfgb, 'progress_apply')
    tcls = tqdm(range(2))
    tqdm_pandas(tcls)
    assert hasattr(tcls, 'pandas')
    try:
        tqdm_pandas(object())
    except TypeError:
        pass
    else:
        raise AssertionError('tqdm_pandas(object()) should fail!')


__all__.append('test_tqdm_pandas')

# Generated at 2022-06-24 09:41:12.021255
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    @tqdm_pandas
    def test_func(a, b=0):
        return a + b

    df = pd.DataFrame()
    result = test_func(df)
    assert df.equals(result), "tqdm_pandas-decorated apply is broken"

    tqdm.tqdm.pandas()
    result = test_func(df)
    assert df.equals(result), "tqdm.pandas() is broken"

    # Test that we can handle a tqdm-class adapter (tqdm_gui, etc)
    tqdm.tqdm_pandas(tqdm.tqdm_gui)  # noqa E999
    result = test_func(df)


# Generated at 2022-06-24 09:41:21.671666
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    np.random.seed(0)
    df = pd.DataFrame(np.random.randn(1000, 1000))
    df_out = df.progress_apply(lambda x: x + 1, axis=1)
    assert (df_out == df.apply(lambda x: x + 1, axis=1)).all().all()
    assert (df_out == tqdm(df, leave=False).apply(lambda x: x + 1, axis=1)).all().all()
    assert (df_out == tqdm_pandas(tqdm(df, leave=False), leave=False).apply(lambda x: x + 1, axis=1)).all().all()

# Generated at 2022-06-24 09:41:33.381662
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd
    import numpy as np
    # Get a progress bar
    pg = tqdm(total=100)
    assert isinstance(pg, tqdm)
    assert pg.n == 0

    # Add ten
    for i in range(10):
        pg.update()
    assert pg.n == 10

    # Create a DataFrame
    df = pd.DataFrame({
        'a': np.random.uniform(0, 100, (100000,)),
        'b': np.random.uniform(0, 100, (100000,))
    })

    # Test the progress_apply function
    def progress_func(x):
        return x**2


# Generated at 2022-06-24 09:41:42.016990
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        pytest.skip("tqdm.pandas requires pandas to be installed")
    from tqdm.auto import tqdm, trange

    pd.DataFrame(range(1000)).groupby(0).progress_apply(lambda x: x)
    pd.DataFrame(range(1000)).groupby(0).progress_apply(lambda x: x,
                                                        desc='test')

    tqdm_pandas(tqdm(desc='test', total=1000))
    tqdm_pandas(trange(1000), desc='test')
    # tqdm_pandas(tqdm(total=1000))  # for delayed-/subclass-adapter support
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:41:49.025501
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from numpy.random import default_rng
    from tqdm import tqdm_notebook as tqdm

    rng = default_rng()
    df = pd.DataFrame(rng.standard_normal(size=(1_000_000, 3)))
    df.apply(lambda x: x + 1, axis=1)
    # Register the tqdm instance with pandas
    tqdm_pandas(tqdm())
    # Now you can use ``progress_apply`` instead of ``apply``
    df.progress_apply(lambda x: x + 1, axis=1)

# Generated at 2022-06-24 09:42:00.089553
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import random
    # register `tqdm` with `pandas` if in notebook.

    try:
        import ipywidgets
        get_ipython
        tqdm.pandas()  # can use `tqdm_gui`, `tqdm_notebook`, `tqdm_pandas`, see `tqdm.pandas()` docstring.

        df = pd.DataFrame({"A": [random.randint(0, 1000) for _ in range(10000)]})
        # df.groupby("A").progress_apply(lambda x: x)
        df.groupby("A").apply(lambda x: x)
    except (NameError, ModuleNotFoundError):
        print("No ipywidgets")

# Generated at 2022-06-24 09:42:10.397690
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import numpy as np
    import pandas as pd
    import re
    import os

    def get_stdout():
        import sys
        return sys.stdout.getvalue().strip()

    def get_stdout_handle(handle):
        import sys
        return sys.bytes_stdout.getvalue().strip()

    # Setup
    df = pd.DataFrame({
        'name': ['Alice', 'Bob', 'Alice', 'Bob'],
        'datum': ['1', '2', '3', '4'],
    })
    # Test cases for v4

# Generated at 2022-06-24 09:42:18.208429
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({'x': [1, 2, 3, 4, 6, 7, 8, 9, 10]})

    def double(x):
        return x * 2

    df.groupby('x').progress_apply(double)

    # Double progress bar
    df.groupby('x').progress_apply(double)

    # Remove pandas progress bar
    df.groupby('x').progress_apply(double)
    tqdm.pandas(tqdm(), leave=False)
    df.groupby('x').progress_apply(double)
    tqdm.pandas(tqdm(), leave=True)
    df.groupby('x').progress_apply(double)

    # Test deprecated method
    tqdm

# Generated at 2022-06-24 09:42:28.474839
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm.pandas(desc='Testing tqdm_pandas')
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(desc='Testing tqdm_pandas'))
    import pandas as pd
    # Test for decorator: @tqdm_pandas
    df = pd.DataFrame(dict(a=[1] * 10, b=range(10)))
    df.groupby('a').progress_apply(tqdm_pandas)
    # Test for validator: tqdm.pandas
    tqdm.pandas()  # tqdm(tqdm_class=tqdm.tqdm_notebook)
    # Test for auto-discovery
   

# Generated at 2022-06-24 09:42:37.800977
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from distutils.util import strtobool
    from pandas import DataFrame
    from numpy.random import rand
    from numpy import nan

    def slow_identity(df):
        for col in df.columns:
            for _ in range(int(1e1)):
                _ = df[col]

        return df.copy()

    def slow_sqr(df):
        for col in df.columns:
            for _ in range(int(1e1)):
                _ = df[col] ** 2

        return df.copy()

    def slow_triple(df):
        for col in df.columns:
            for _ in range(int(1e1)):
                _ = df[col] * 3

        return df.copy()


# Generated at 2022-06-24 09:42:47.931551
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    from ._utils import format_sizeof, format_interval
    from .tqdm_gui import tqdm_gui
    from .std import tqdm

    # tqdm_pandas(tqdm, desc='Pandas')
    tqdm.pandas(desc='Pandas')

    df = pd.DataFrame(
        {'group': [1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3],
         'value': [1, 1, 2, 3, 4, 4, 5, 6, 7, 8, 8, 10, 11, 11, 12]})
    df_result = df.groupby('group').progress_apply(
        lambda x: x['value'].nunique())
    assert df

# Generated at 2022-06-24 09:42:58.099280
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib import pandas

    # Define pandas DataFrame
    df = pd.DataFrame({'col': [1, 2, 3]})

    # Set up tqdm class
    t = tqdm(range(10), desc='Loop_1')

    # Decorator
    @pandas(desc='Loop_2', unit='loop')
    def g(p):
        for i in t.__iter__():  # Trick to avoid KeyboardInterrupt
            # Do something with p
            p
    # Apply decorator
    df.progress_apply(lambda x: g(x['col']), axis=1)

# Generated at 2022-06-24 09:43:05.633385
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm

    df = pd.DataFrame(np.random.randint(0, 1000, (100000, 6)))
    tclass = tqdm.tqdm(total=len(df))
    tqdm_pandas(tclass=tclass, total=len(df))
    df.groupby(0).progress_apply(lambda x: x ** 2)

# if __name__ == "__main__":
#     test_tqdm_pandas()

# Generated at 2022-06-24 09:43:16.003019
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm, trange

    n = 10


# Generated at 2022-06-24 09:43:19.670428
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # With tqdm instance
    from tqdm.auto import tqdm
    t = tqdm(total=2, desc='Testing tqdm_pandas')
    tqdm_pandas(t)
    # With tqdm class
    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:43:28.473286
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    import pandas as pd

    df = pd.DataFrame({'A': [0, 1, 0, 1] * 8,
                       'B': [0, 0, 1, 1] * 8,
                       'C': (v % 3 for v in range(32))})
    g = df.groupby(['A', 'B'])
    # g.progress_apply(lambda x: x)  # library not loaded yet
    with tqdm(total=len(df), file=sys.stdout) as t:
        tqdm_pandas(t)
        g.progress_apply(lambda x: x)

# Generated at 2022-06-24 09:43:33.163835
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame({'col1': range(0, 100),
                       'col2': range(0, 100, 2)})
    res = df.groupby('col2').progress_apply(lambda x: sum(x))
    assert (res == df['col2'] * 100).all()



# Generated at 2022-06-24 09:43:37.996991
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm

    try:
        import pandas as pd  # pandas >= 0.19
    except ImportError:
        pass

    def foo(*args, **kwargs):
        return 42

    def test_adapter(tclass, **tqdm_kwargs):
        try:
            tclass.pandas(**tqdm_kwargs)
        except:
            return False
        else:
            return True

    assert test_adapter(tqdm(), total=10)
    assert test_adapter(tqdm.tqdm(total=10))

    try:
        import pandas as pd  # pandas >= 0.19
    except ImportError:
        pass

# Generated at 2022-06-24 09:43:48.506630
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm.auto import tqdm
    from io import StringIO

    def apply_to_mock():
        """Mock for apply method"""
        return

    class DataFrameMock(DataFrame):
        """Mock for DataFrame"""
        # pylint: disable=abstract-method
        def apply(self, func, *_, **__):
            """Mock for DataFrame.apply"""
            apply_to_mock()

    class DataFrameGroupByMock(DataFrameMock.groupby):
        """Mock for DataFrameGroupBy"""
        def progress_apply(self, func, *_, **__):
            """Mock for DataFrameGroupBy.progress_apply"""
            return apply_to_mock()


# Generated at 2022-06-24 09:43:54.447168
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tclass = mock.Mock()
    tqdm_pandas(tclass, desc="test", **{'file': sys.stderr})
    tclass.pandas.assert_called_with(desc="test", **{'file': sys.stderr})
    tclass.pandas.reset_mock()

    tclass = mock.Mock()
    tqdm_pandas(tclass)
    tclass.pandas.assert_called_with()

    # delayed adapter case
    tclass = type('tqdm', (), {'pandas': mock.Mock()})
    tqdm_pandas(tclass)
    tclass.pandas.assert_called_with()

    tclass = mock.MagicMock(__name__='tqdm_notebook')

# Generated at 2022-06-24 09:43:56.275781
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    tqdm_pandas(tqdm)



# Generated at 2022-06-24 09:44:05.349386
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm
        import pandas as pd
        import random
        import numpy as np
        tqdm_pandas(tqdm)
        n = 100
        indices = 10000
        data_frame = pd.DataFrame(np.random.randn(indices, n))
        minimum = lambda x: x.min()
        maximum = lambda x: x.max()
        data_frame.groupby(
            np.random.randint(0, 10, indices)).progress_apply(minimum)
        data_frame.groupby(
            np.random.randint(0, 10, indices)).progress_apply(maximum)
        print('\r', end='', flush=True)

    except ImportError:
        pass

# Generated at 2022-06-24 09:44:13.440634
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import functools
    import pandas as pd
    df = pd.DataFrame({'first': range(2), 'second': range(2)})

    def f(x):
        return x

    fclass = functools.partial(f, 1)
    tqdm_pandas(fclass)
    if (
        fclass(df['second']).sum() != 2 or
        fclass(df.groupby('first')['second']).sum().sum() != 2 or
        fclass(df.groupby('first')['second']).sum().sum() != 2
    ):
        raise Exception("Test failed")


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:18.141532
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_notebook
    tqdm_pandas(tqdm_notebook)
    assert isinstance(tqdm_pandas, types.FunctionType)


################################################################################
# Set-up for pandas
################################################################################


# Generated at 2022-06-24 09:44:22.699415
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib.test import get_dataframe

    tqdm_pandas(get_dataframe(0).groupby(0).progress_apply,
                desc=str("test"))
    tqdm_pandas(get_dataframe(0).progress_apply,
                desc=str("test"))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:31.433191
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import trange
    df = pd.DataFrame(columns=['input', 'output'])
    df['input'] = trange(10000)
    df['output'] = df['input']
    assert df['output'].apply(lambda x: x+1).sum() == sum(df['input'] + 1)
    assert df.groupby('input').progress_apply(lambda x: x+1) is not None
    assert df.groupby('input').progress_apply(
        lambda x: x+1).progress_apply(lambda x: x+1) is not None


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:40.973729
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({
        'x': list(range(10)),
        'y': [i * 1.2 for i in range(10)],
        'z': [i % 4 for i in range(10)],
    })

    def process_row(row):
        return row['x'] * row['y'] * row['z']

    # should work with standard tqdm instance
    df.groupby('z').progress_apply(process_row, tqdm=tqdm)

    # should work with nested tqdm instance

# Generated at 2022-06-24 09:44:49.622273
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:44:58.627275
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas()
    """
    try:
        import pandas as pd
    except:
        return None

    if int(pd.__version__.split('.')[0]) >= 1:
        import numpy as np
        df = pd.DataFrame({'a': ['a', 'b', 'c', 'a', 'b', 'c'], 'b': [1, 2, 3, 1, 2, 3]})
        tqdm_pandas(pd.core.groupby.DataFrameGroupBy.progress_apply)
        res = df.groupby('a').progress_apply(lambda x: x['b'].mean())
        exp = pd.Series([1.5, 2.5, 3.5], index=['a', 'b', 'c'])

   

# Generated at 2022-06-24 09:45:03.695538
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    t = tqdm_pandas(tqdm())
    t.register_hooks()
    try:
        df = pd.DataFrame({'a': [1, 2, 3], 'b': [1, 2, 3]})
        df.groupby('a').progress_apply(lambda x: x)
    except Exception:
        pass
    finally:
        t.unregister_hooks()

# Generated at 2022-06-24 09:45:09.652210
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    pandas = None
    try:
        import pandas
    except ImportError:
        pass
    if pandas:
        try:
            # Test with DataFrameGroupBy.progress_apply method
            pandas.DataFrame({"a": [1, 2, 3, 4]}).groupby("a").progress_apply(lambda x: x)
        except AttributeError:
            print("AttributeError probably is due to lack of pandas upgrade")


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:45:19.864006
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for tqdm_pandas function."""
    from tqdm import tqdm, tqdm_gui
    from random import shuffle

    # Dummy class
    class Dummy:
        def __init__(self, name=''):
            self.name = name

        def __getattr__(self, attr):
            if attr == '__name__':
                return self.name
            raise AttributeError()

    # tqdm instance
    t = tqdm(total=2, desc="foo")

    # tqdm delayed instance
    t_delayed = tqdm_gui()

    # tqdm getattr
    t_getattr = Dummy(name='tqdm_getattr')
    t_getattr.__name__ = 'tqdm_getattr'

    # D

# Generated at 2022-06-24 09:45:29.062048
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if os.environ.get('TEST_ADAPTER') not in ('tqdm_pandas', 'all'):
        return
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.api.types import is_numeric_dtype

    df = DataFrame({
        'x': list('abcdefghi') * 1e1,
        'y': list(reversed(list('abcdefghi'))) * 1e1,
        'z': list(reversed(list('abcdefghi'))) * 1e1,
        'foo': [1, 2, 3, 4] * 1e2,
        'bar': [1, 2, 3, 4] * 1e2,
    })

    tqdm_pandas(tqdm)

# Generated at 2022-06-24 09:45:39.909586
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return None
    tqdm_kwargs = {'total': 1000}
    old_tqdm_pandas = tqdm.pandas

    try:
        import tqdm.pandas  # minimal recursion call

        tqdm.pandas = lambda: None
        tqdm_pandas(tqdm, **tqdm_kwargs)
        assert tqdm.pandas is not None

        tqdm.pandas = old_tqdm_pandas  # delayed adapter
        tqdm_pandas(tqdm, **tqdm_kwargs)
    finally:
        tqdm.pandas = old_tqdm_pandas

# Generated at 2022-06-24 09:45:45.799696
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import pandas as pd

    def to_pandas():
        data = (os.urandom(8192) for _ in range(100000))  # 8 KiB of random data
        df = pd.DataFrame(
            [pandas_hash_bytes(pandas_buffer_bytes(x)) for x in data],
            columns=['hash'])
        df = df.groupby(['hash']).progress_apply(
            lambda x: pandas_hash_bytes(x.values)
        )
        return df

    from tqdm import tqdm
    from tqdm.autonotebook import tqdm as tqdm_notebook

    def to_pandas_tqdm():
        data = (os.urandom(8192) for _ in range(100000))

# Generated at 2022-06-24 09:45:50.748527
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    from tqdm import tqdm
    tqdm_pandas(tqdm, unit='s')
    tqdm.pandas(unit='s')
    tqdm_pandas(tqdm(unit='s'))