

# Generated at 2022-06-24 09:35:56.465948
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from pandas import DataFrame
    except ImportError:
        return
    tqdm = tqdm_pandas(tqdm)
    df = DataFrame({'col': [1, 2, 3, 4]})
    for i in df.groupby('col').progress_apply(lambda x: x):
        assert i is not None
    tqdm = tqdm_pandas(tqdm)
    # Test asynchronous updates
    df = pd.DataFrame({'col': [1, 2, 3, 4]})
    for i in df.groupby('col').progress_apply(lambda x: x, use_threads=True):
        assert i is not None

    # Test unlabelled

# Generated at 2022-06-24 09:36:02.429754
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    from pandas import DataFrame

    def f(df):
        import time
        time.sleep(0.01)

    tqdm_pandas(tqdm).progress_apply(DataFrame([1, 2, 3]), f, axis=0)



# Generated at 2022-06-24 09:36:07.382418
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    from tqdm import tqdm

    for i in tqdm([0, 1, 2], desc='test'):
        pass

    for i in tqdm(range(3), desc='test2'):
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:15.530410
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    from pandas import DataFrame
    from tqdm import tqdm

    def my_func(x):
        """Function that returns the row number"""
        from time import sleep
        from random import random
        sleep(random() / 10)
        return x

    df = DataFrame({'a': range(10), 'b': range(10)})
    tqdm_pandas(tqdm, miniters=1)(my_func)(df.a)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:19.564159
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import numpy as np
    d = pd.DataFrame(np.random.randn(100,5),
        columns=list('abcde'))
    tqdm_pandas(tqdm.tqdm())
    res = d.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-24 09:36:25.541892
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from .tests_tqdm import trange
    tqdm_pandas(tqdm(total=len(range(10))))
    tqdm_pandas(tqdm)
    tqdm_pandas(trange=trange, total=len(range(10)))

    df = DataFrame(range(10))
    df.groupby(0).progress_apply(sum, axis=0)  # noqa: E712

    def map_func(*args, **kwargs):
        return sum(*args, **kwargs)

    df.groupby(0).progress_apply(map_func, axis=0)

    from .tests_tqdm import tqdm_pandas as _tqdm_pandas
   

# Generated at 2022-06-24 09:36:34.563315
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy.random import randint
    from tqdm import tqdm

    def do_apply(df):
        return df.apply(lambda x: (x * 2).sum())

    N_ROWS = 50

# Generated at 2022-06-24 09:36:41.876635
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib.test_tqdm_pandas import test_tqdm_pandas

    df = pd.DataFrame({'col1': np.random.randint(0, 100, size=100)})
    progress_apply = test_tqdm_pandas(tqdm_pandas)
    assert len(list(progress_apply(df, lambda x: x))) > 0


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:36:51.066114
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    tqdm_kwargs = dict(name='test', total=100)
    res = tqdm_pandas(tclass=pd.DataFrame, **tqdm_kwargs)
    assert res is None  # check that the decorator wasn't used

    try:
        import pandas as pd
        from .tqdm import trange
    except ImportError:
        return

    df = pd.DataFrame({
        'A': [1, 2, 3],
        'B': [2, 3, 4],
    })

    # no progress_apply
    res = df.groupby('A').apply(lambda x: x['B'].sum())
    assert res.values.tolist() == [2, 7]



# Generated at 2022-06-24 09:36:57.130158
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randn(10000, 2))
    from tqdm.autonotebook import tqdm
    with tqdm(total=10000, mininterval=0) as pbar:
        for _ in df.groupby(df.columns[0]):
            pbar.update(1)

    print("\n")

    with tqdm(total=10000, mininterval=0) as pbar:
        for (i, j) in df.progress_apply(lambda x: (x[0], x[1]), axis=1):
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:08.582986
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randn(100000, 1000))
    tqdm_pandas(df.groupby(0).progress_apply(lambda x: x**2))

    # tqdm.pandas(**tqdm_kwargs)
    tqdm_pandas(df.groupby(0).progress_apply(lambda x: x**2), leave=True)

    # tqdm.pandas(deprecated_t=tclass)
    # tqdm_pandas(tqdm(df.groupby(0).progress_apply(lambda x: x**2)))

# Generated at 2022-06-24 09:37:15.305179
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests that the wrapper works.
    """
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'val': [0, 2, 4, 8, 16, 32, 64, 128, 256]})
    df.groupby('val').progress_apply(len)

    tqdm.pandas(tqdm.tqdm)
    df.groupby('val').progress_apply(len)

    tqdm.pandas()
    df.groupby('val').progress_apply(len)



# Generated at 2022-06-24 09:37:25.678826
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        import numpy as np
    except ImportError:
        raise unittest.SkipTest("pandas not found")

    import pandas as pd
    df = pd.DataFrame({
        'x': [1, 2, 3, 4, 5],
        'y': [6, 7, 8, 9, 10],
    })
    res = df.groupby('x').progress_apply(len)
    assert res.x.max() == 5

    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas(pd.core.groupby.DataFrameGroupBy.progress_apply)
    res = df.groupby('x').progress_apply(len)
    assert res.x.max() == 5


# Generated at 2022-06-24 09:37:31.142932
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        print('Skipping pandas tests due to missing pandas dependency')
        return

    tqdm_pandas(tqdm(total=100))

    tqdm_pandas(tqdm(total=100), leave=False)

    df = pd.DataFrame(dict(a=range(10000), b=range(10000)))

    _ = df.groupby('a').progress_apply(lambda x: x)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:41.152673
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame
    from tqdm import tqdm

    for t in [tqdm, tqdm.tqdm, tqdm.tqdm_notebook]:
        t(range(10), desc='tqdm_test').pandas(desc='tqdm_pandas')
        tqdm_pandas(t, desc='tqdm_pandas')
        t(range(10), desc='tqdm_test').pandas(desc='tqdm_pandas')
        tqdm_pandas(t, desc='tqdm_pandas')

    df_range = DataFrame(range(100))
    df_range.groupby(0).progress_apply(lambda x: x)
    df_range.groupby

# Generated at 2022-06-24 09:37:48.072891
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.contrib import tqdm_pandas

    df = pd.DataFrame(dict(a=range(1000), b=range(1000)))
    df.groupby('a').progress_apply(str)
    assert True


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:37:52.232283
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame([0, 1])
    t = tqdm_pandas(pd.DataFrame(df).groupby(df[0]).progress_apply(len))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:38:03.323294
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except (ModuleNotFoundError, ImportError):
        return
    from tqdm.auto import tqdm
    from tqdm.pandas import tqdm_pandas

    tqdm_pandas(tqdm)

    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_pandas)
    tqdm_pandas(tqdm_pandas())
    tqdm_pandas(tqdm_pandas, file=sys.stderr)
    tqdm_pandas(tqdm_pandas())
    tqdm_pandas(tqdm_pandas(), file=sys.stderr)


# Generated at 2022-06-24 09:38:09.154852
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    for _ in trange(3):
        # test `tqdm.pandas(...)`
        import pandas as pd
        df = pd.DataFrame({'test': [1] * 10})
        tqdm_kwargs = {'desc': 'test_tqdm_pandas'}
        df.groupby('test').progress_apply(lambda x: x, **tqdm_kwargs)

        # test `tqdm.pandas(...)`
        tqdm = trange(3, desc='test_tqdm_pandas')
        tqdm.pandas(**tqdm_kwargs)
        for _ in df.groupby('test').progress_apply(lambda x: x):
            pass

        # test `tqdm

# Generated at 2022-06-24 09:38:17.176027
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from pandas.testing import assert_frame_equal
    from tqdm.contrib.test import new_tqdm_instance
    from pandas.core.groupby import DataFrameGroupBy

    def test_fn(dfg):
        'dfg returns dfg'
        return dfg

    n = 100
    df = pd.DataFrame({'a': np.random.rand(n),
                       'b': np.random.rand(n)})

    df_grouped = df.groupby(['a'])

    t = tqdm_pandas(new_tqdm_instance(leave=True))
    df_test = df_grouped.progress_apply(test_fn)
    t.close()


# Generated at 2022-06-24 09:38:27.023677
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`"""
    from tqdm import tqdm
    from pandas import DataFrame

    tclass = tqdm(total=10)
    tqdm_pandas(tclass)
    df = DataFrame({'a': [1, 2], 'b': ['e', 'f']})
    df.groupby('b', as_index=False).progress_apply(lambda x: None)

    try:
        import pandas as pd
        pd.read_table('non-existing-file.tsv')
    except (ImportError, FileNotFoundError):
        pass
    else:
        assert False, "Must fail on missing file error"

    tclass = tqdm(total=10)

# Generated at 2022-06-24 09:38:34.834097
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    def test_f(x):
        """Add 5 to every element"""
        return x + 5

    pdg = pd.DataFrame(np.random.randint(10, size=(100, 10)))
    result = pd.DataFrame({c: pdg[c].progress_apply(test_f) for c in pdg})
    assert (result == pdg + 5).all().all()

# Generated at 2022-06-24 09:38:45.672738
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from pandas import DataFrame, Series
    tqdm_pandas(trange(10))
    tqdm_pandas(trange(10), leave=False)
    tqdm_pandas(trange(1))
    tqdm_pandas(trange(0))
    df = DataFrame({"x": [1, 2, 3, 4],
                    "y": [5, 6, 7, 8]})
    tqdm_pandas(df.groupby("x").progress_apply(lambda x: x + 1))
    tqdm_pandas(df.groupby("x").progress_apply(lambda x: x + 1), leave=False)

    # unit test for series.apply()

# Generated at 2022-06-24 09:38:49.044889
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # TODO: write a unit test
    pass


if __name__ == "__main__":
    try:  # pragma: no cover
        import pandas  # NOQA

        test_tqdm_pandas()
    except ImportError:
        pass

# Generated at 2022-06-24 09:38:59.789379
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test data
    import pandas
    import numpy
    array1 = numpy.random.rand(1000)
    array2 = numpy.random.rand(1000)
    dataframe = pandas.DataFrame({'a': array1, 'b': array2})

    # Test function
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    dataframe.groupby('a').progress_apply(lambda x:x)
    tqdm_pandas(tqdm(loc=0))
    dataframe.groupby('a').progress_apply(lambda x:x)

if __name__ == '__main__':
    test_tqdm_pandas()


# Generated at 2022-06-24 09:39:09.603983
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas()"""
    a = list(range(100))
    import pandas as pd
    df = pd.DataFrame(a)

    try:
        # Test basic case
        with tqdm_pandas(df.groupby(0)) as v:
            assert hasattr(v, 'progress_apply')
    except Exception:
        return False

    try:
        # Test delayed adapter case
        with tqdm_pandas(tqdm, df.groupby(0)) as v:
            assert hasattr(v, 'progress_apply')
    except Exception:
        return False


# Generated at 2022-06-24 09:39:12.176623
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas
    from tqdm import tqdm

    tqdm_pandas(tqdm())


# Generated at 2022-06-24 09:39:17.016949
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [10, 20, 30]})

    with tqdm.tqdm_pandas() as t:
        df.progress_apply(t.update)
        t.close()

# Generated at 2022-06-24 09:39:20.849199
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm(leave=False) as t:
        tqdm_pandas(t)
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm, foo='bar')



# Generated at 2022-06-24 09:39:28.280354
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._tqdm import tqdm
    from pandas import DataFrame
    from random import choice

    from .tests_tqdm import closing, in_current_process


# Generated at 2022-06-24 09:39:35.841775
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy
    numpy.random.seed(42)

    import pandas
    df = pandas.DataFrame({'a': numpy.random.rand(100000),
                           'b': numpy.random.rand(100000),
                           'c': numpy.random.randint(-100, 100, (100000,)),
                           'd': numpy.random.choice(['a', 'b', 'c'], (100000,))})
    tqdm_pandas(tqdm(ncols=80))
    df.groupby('d').progress_apply(lambda g: g['a'].sum())



# Generated at 2022-06-24 09:39:42.116388
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'A': np.random.randint(1, 1000, 10000),
                       'B': np.random.randint(1, 1000, 10000),
                       'C': np.random.randint(1, 1000, 10000),
                       'D': np.random.randint(1, 1000, 10000)})
    dg = df.groupby('A')
    tqdm_pandas(tqdm)

    assert dg.progress_apply(lambda x: x['B'].sum())
    assert dg.progress_apply(lambda x: x['B'].sum(), axis=1)
    assert dg.progress_agg({'B': lambda x: x.sum()})
    assert dg.progress

# Generated at 2022-06-24 09:39:47.555717
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # Test alias case
    try:
        from tqdm import tqdm
        tqdm_pandas(tqdm)
    except:
        pass

    # Test class on-the-fly case
    try:
        tqdm_pandas(tqdm, total=5)
    except:
        pass

    # Test class case
    try:
        tqdm_pandas(tqdm.tqdm)
    except:
        pass

# Generated at 2022-06-24 09:39:57.714135
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for :func:`tqdm.std.tqdm_pandas`."""
    from tqdm.autonotebook import tqdm

    def func(df):
        """Dummy function."""
        return df

    for t in [tqdm, tqdm.pandas, tqdm_pandas]:
        with captured_output() as (out, _):
            try:
                t(range(10))
            except AttributeError:  # Python < 3.3
                assert sys.version_info[:2] < (3, 3)
                assert "object has no attribute 'tqdm_gui'" in out.getvalue()
            else:
                assert sys.version_info[:2] >= (3, 3)
                assert out.getvalue() == ''

# Generated at 2022-06-24 09:40:02.882340
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    df = pd.DataFrame({'a': [1, 2] * 9})
    for tclass in [tqdm, tqdm_notebook, tqdm_gui, tqdm_pandas]:
        t = tclass(total=len(df))
        try:
            assert t == df.groupby('a').progress_apply(lambda x: x)
        except TypeError:  # pandas not installed
            return  # skip test


# Generated at 2022-06-24 09:40:13.266962
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        # For pandas < 0.23
        from pandas.core.groupby import DataFrameGroupBy
    tqdm_pandas(tqdm)
    df = pd.DataFrame([{'label': i} for i in range(10)])
    assert df.groupby('label').progress_apply(lambda x: x['label'].sum()) == 45

    # Old API:
    tqdm_pandas(tqdm.tqdm)
    df = pd.DataFrame([{'label': i} for i in range(10)])
    assert df.groupby('label').progress_apply(lambda x: x['label'].sum())

# Generated at 2022-06-24 09:40:19.435994
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:  # pragma: no cover
        raise unittest.SkipTest("Missing pandas")
    from tqdm import tqdm

    df = pd.DataFrame({
        'x': list(range(10)),
        'y': list(range(10, 20)),
    })
    df.groupby(df.x % 2).progress_apply(lambda x: x)
    with tqdm(total=10) as t:
        df.groupby(df.x % 2).progress_apply(t.update)


if __name__ == '__main__':
    from tqdm import tqdm
    from tqdm.contrib.test_utils import closable_named_file

# Generated at 2022-06-24 09:40:30.108339
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # https://stackoverflow.com/a/48311072/353337
    import pandas as pd
    from tqdm import tqdm_notebook as tqdm

    df = pd.DataFrame({
        'col1': [1, 2],
        'col2': [3, 4]
    })

    def slow_square(x):
        import time
        time.sleep(.5)
        return x ** 2

    # tqdm_pandas(tqdm)  # register `pandas.progress_apply` with `tqdm`
    df['col1_squared'] = df['col1'].progress_apply(slow_square)
    df['col2_squared'] = df['col2'].progress_apply(slow_square)


# Generated at 2022-06-24 09:40:36.153930
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        import pandas
        has_pandas = True
    except ImportError:
        has_pandas = False
    if has_pandas:
        t_pandas = tqdm(
            desc='test_tqdm_pandas',
            ncols=100,
            miniters=1,
            mininterval=0.1,
            maxinterval=0.1,
            disable=False)
        try:
            tqdm_pandas(t_pandas)
        except Exception as e:
            raise e
        try:
            tqdm_pandas(tqdm, t_pandas=t_pandas)
        except Exception as e:
            raise e

# Generated at 2022-06-24 09:40:41.501629
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas  # noqa
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'a': np.random.randn(100)})
    with tqdm(total=len(df)) as pbar:
        # Apply a trivial transformation to each row
        df.progress_apply(lambda x: pbar.update(), axis=1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:40:49.561363
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import pandas as pd
    if not pd:
        return

    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock  # noqa

    from tqdm._utils import _deprecated

    tclass = MagicMock()
    tclass_name = tclass.__name__ = 'tqdm'

    tqdm_pandas(tclass)
    assert tclass.pandas.call_args[1] == {}

    tqdm_kwargs = {'a': 'b'}
    tqdm_pandas(tclass, **tqdm_kwargs)
    assert tclass.pandas.call_args[1] == tq

# Generated at 2022-06-24 09:40:54.534409
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    import pandas as pd
    with tqdm.pandas() as t:
        _ = DataFrame(dict(a=pd.Series([1, 2, 3]), b=pd.Series([1, 2, 3]))).progress_apply(
            lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:41:02.945751
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    
    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        tqdm_pandas()
        df = pd.DataFrame({'animal': 'cat dog cat fish dog cat cat'.split(),
                           'size': list('SSMMMLL'),
                           'weight': [8, 10, 11, 1, 20, 12, 12],
                           'adult': [False] * 5 + [True] * 2})
        df.groupby("animal").progress_apply(lambda subf:
                                            subf["weight"].mean())
        TqdmTypeError("tqdm_pandas(tqdm) or tqdm_pandas(tqdm(...)) takes no arguments.")

# Generated at 2022-06-24 09:41:07.076622
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import random

    df = pd.DataFrame(list(range(100)), columns=['col1'])
    tqdm_pandas(tqdm(total=df.shape[0]))
    df['col1'] = df['col1'].progress_apply(lambda x: x*random.random())

# Generated at 2022-06-24 09:41:17.334005
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    a = pd.DataFrame({'a': range(100), 'b': range(100)})
    tqdm_pandas(a.groupby('a').progress_apply(lambda x: x))
    tqdm_pandas(a.groupby('a').progress_apply(np.mean))
    tqdm_pandas(a.groupby('a').progress_apply(lambda x: x))
    tqdm_pandas(a.groupby('a').progress_apply(np.mean))
    tqdm_pandas(a.progress_apply(lambda x: x))
    tqdm_pandas(a.progress_apply(np.mean))

if __name__ == '__main__':
    test_t

# Generated at 2022-06-24 09:41:24.192635
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    x = pd.DataFrame({'a': range(300)})
    y = x.progress_apply(lambda x: x)
    for _ in range(2): # repeat to test reuse
        for _ in y:
            pass

if __name__ == '__main__':
    ipython_mode = False
    if not ipython_mode:
        from pandas import DataFrame, Series
        from numpy.random import randn
        import pandas.util.testing as tm
        tm.N, tm.K = 100, 10
        tm.makeCustomDataframe
        tm.makeTimeDataFrame
        tm.makeMixedDataFrame
        tm.makeMissingDataframe
        tm.makeCategoricalDataframe
        tm.makeObjectSeries
        tm.makeStringSeries
        t

# Generated at 2022-06-24 09:41:34.977897
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.testing import assert_frame_equal
    from numpy.testing import assert_equal

    df = DataFrame({'color': ['blue', 'green', 'red'] * 100,
                    'height': [160, 180, 170] * 100,
                    'weight': [60, 70, 50] * 100})

    tqdm.pandas(tqdm())
    assert_frame_equal(
        df.groupby('color').progress_apply(lambda x: x.mean()),
        df.groupby('color').apply(lambda x: x.mean()))
    tqdm.pandas(tqdm(leave=False))

# Generated at 2022-06-24 09:41:42.784712
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:41:49.997046
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_gui
    import pandas as pd
    from itertools import product

    for tclass in [tqdm, tqdm_gui]:
        with tclass(desc="TEST", total=10) as t:
            tqdm_pandas(t)
            progress_bar = pd.DataFrame([
                [i, j] for i, j in product(range(10), range(10))]).groupby(
                    0).progress_apply(lambda _: t.update())
        assert t.n == 10
        assert t.total == 10


if __name__ == '__main__':
    # Unit test
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:00.351370
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    df = DataFrame({"a": range(100), "b": range(100), "c": range(100)})
    it = df.groupby("a")
    try:
        it.progress_apply(lambda x: x)
        assert True
    except AttributeError:
        assert True
    try:
        tqdm_pandas(tqdm())
        assert True
    except AttributeError:
        assert True
    tqdm_pandas(tqdm)
    _ = it.progress_apply(lambda x: x)
    try:
        tqdm_pandas(tqdm())
        assert True
    except AttributeError:
        assert True

# Generated at 2022-06-24 09:42:10.656018
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import trange, tqdm_notebook, tqdm
    N = 100000
    df = pd.DataFrame({'a': np.arange(N),
                       'b': np.random.randn(N)})
    t = trange(4, leave=False)
    for i in t:
        t.set_description("progress: %d%%" % (100 * i // t.total))
        df.progress_apply(lambda x: x**2)
    if hasattr(tqdm_notebook, '_instances'):
        tqdm_notebook._instances.clear()
    if hasattr(tqdm, '_instances'):
        tqdm._instances.clear()

    t = t

# Generated at 2022-06-24 09:42:18.538542
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    tqdm_pandas(tclass=tqdm)
    # Create dataframe
    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    df = df.groupby(df.columns.tolist()).sum()  # add some column indexes
    # Create tqdm instance
    with tqdm.tqdm(total=len(df),
                   file=sys.stdout,
                   ncols=70,
                   miniters=1,
                   mininterval=0,
                   ascii=True) as t:
        # Call pandas.core.groupby.DataFrameGroupBy.progress_apply
        df.progress_apply(t.update)



# Generated at 2022-06-24 09:42:28.893107
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import unittest

    class TqdmPandasTest(unittest.TestCase):
        def setUp(self):
            self.df = pd.DataFrame({'a': [2] * 100, 'b': [3] * 100})

        def test_progress_apply(self):
            tqdm.pandas(ncols=50)
            self.assertEqual(self.df.progress_apply(lambda x: x).equals(self.df), True)

        def test_progress_agg(self):
            tqdm.pandas(ncols=50)
            self.assertEqual(self.df.groupby(['a']).progress_agg(lambda x: x).equals(self.df), True)


# Generated at 2022-06-24 09:42:37.837744
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        from tqdm import tqdm
        tqdm.pandas(desc='test2')
        with tqdm(total=1, unit='step') as t:
            df = pd.DataFrame({'int': np.random.randint(1, 5, 10),
                               'int_sq': np.random.randint(10, 20, 10)})
            df.progress_apply(lambda x: pd.Series(x), axis=1)
            t.update()
    except (ImportError, ModuleNotFoundError):
        pass

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-24 09:42:43.679595
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame()
    df['0'] = np.arange(1, 301)

    @tqdm_pandas
    def tqdm_apply(x):
        import time
        time.sleep(0.1)
        return x

    df.progress_apply(tqdm_apply)

# Generated at 2022-06-24 09:42:49.062266
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas.tests.test_groupby import TestGroupBy
    import numpy as np
    from tqdm import tqdm

    class TestPandas_tqdm(TestGroupBy):
        def test_progress_apply(self):
            iterables = [
                [pd.Timestamp('2011-01-01'), pd.Timestamp('2011-01-02'),
                 pd.Timestamp('2011-01-03')],
                ['x', 'y', 'z'], [1, 2, 3]]

# Generated at 2022-06-24 09:43:00.088927
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from pandas import Series, DataFrame
    import pandas as pd
    import numpy as np

    np.random.seed(10)
    df = DataFrame(np.random.randint(0, 100, (100000, 6)))
    print(df.head())
    print(df.apply(tqdm_pandas(sum, total=df.shape[0])))
    print(df.apply(tqdm_pandas(len, total=df.shape[0])))
    print(df.apply(tqdm_pandas(np.sum)))
    print(df.progress_apply(sum, axis=1))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:06.147128
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm)
    for i in range(2):
        DataFrame([[1, 2, 3], [4, 5, 6]]).groupby(lambda x: x // 2
                                                  ).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:15.798013
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    from tqdm import tqdm
    from tqdm import tqdm_notebook
    from tqdm import trange
    try:
        tqdm_pandas(tqdm, unit="B")
    except Exception as e:
        print(str(e))
    try:
        tqdm_pandas(tqdm_notebook, unit="B")
    except Exception as e:
        print(str(e))
    try:
        tqdm_pandas(trange, unit="B")
    except Exception as e:
        print(str(e))


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:20.399800
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    tqdm_pandas(tqdm)
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    for i in tqdm(df.groupby(0), desc='tqdm_pandas test'):
        pass

# Generated at 2022-06-24 09:43:30.009391
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    series = pd.Series(range(10000))

    def f(x):
        return x ** 2

    with tqdm(total=len(series)) as t:
        t.pandas(desc="Test tqdm_pandas")
        print(series.progress_apply(f).sum())
        t.close()

    with tqdm(total=len(series)) as t:
        tqdm_pandas(t, desc="Test tqdm_pandas deprecated")
        print(series.progress_apply(f).sum())
        t.close()

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:38.289130
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm_pandas()`."""
    import numpy as np
    import pandas as pd
    import pytest
    from numpy.testing import assert_array_equal
    from pandas import DataFrame, Series

    try:
        from pandas import SeriesGroupBy
    except ImportError:
        # pandas version < 0.25.0
        from pandas.core.groupby import SeriesGroupBy
    from tqdm.pandas import tqdm_pandas
    from tqdm.tqdm import TqdmDeprecationWarning

    with pytest.deprecated_call(match=r"Please use `tqdm.pandas\(\)`"):
        tqdm_pandas(ncols=100)

# Generated at 2022-06-24 09:43:45.332192
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    with tqdm_pandas(total=1) as pbar:
        try:
            pd.DataFrame({'a': np.random.rand(1000)}).groupby('a').progress_apply(
                lambda x: x)
        except TypeError:
            tqdm_pandas(tqdm())
        finally:
            pbar.close()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:50.696829
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange
    from time import sleep

    for _ in tnrange(2, desc='1st loop'):
        for _ in tnrange(5, desc='2nd loop', leave=True):
            for _ in tnrange(3, desc='3nd loop'):
                sleep(0.01)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:43:59.336037
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    def test_func(dataframe):
        # dummy function
        return dataframe

    df = pd.DataFrame({'a': [1, 2, 3, 4], 'b': [5, 6, 7, 8]})
    gb = df.groupby('a')
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas(tqdm)
    gb.progress_apply(test_func)

# Generated at 2022-06-24 09:44:07.836806
# Unit test for function tqdm_pandas

# Generated at 2022-06-24 09:44:14.815446
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test coverage for tqdm_pandas()."""
    from tqdm import tqdm, TqdmDeprecationWarning

    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm())

    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm_gui())

    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm_notebook())


# Generated at 2022-06-24 09:44:23.558793
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    ds = pd.DataFrame({'a': [1, 2, 3, 4], 'b': [1, 3, 3, 1]})
    ds.groupby(['b']).progress_apply(lambda t: t.a.sum())
    with tqdm_notebook(total=0) as t:
        tqdm_pandas(t)
        ds.groupby(['b']).progress_apply(lambda t: t.a.sum())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:33.904084
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm import trange
    from tqdm import tnrange

    for T in [tqdm, trange, tnrange]:
        df = pd.DataFrame(np.random.random((10000, 100)))
        with T(ncols=80) as pbar:
            pbar.pandas(
                desc='my bar',
                total=len(df),
                position=1,
                leave=False,
                mininterval=0.2,
                smoothing=0.1)
            df.progress_apply(lambda x: x ** 2, axis=1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:40.842675
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    import numpy as np
    
    def square(x):
        return x ** 2

    for progress in [True, False]:
        x = 1 - np.random.rand(100)
        
        with tqdm_pandas(tqdm(total=100, desc="test", disable=not progress)) as t:
            DataFrame({
                "a": Series(x),
                "b": Series(x).progress_apply(square),
            })

# Generated at 2022-06-24 09:44:45.049532
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        with tqdm(total=5) as t:
            _ = pd.DataFrame(range(5)).groupby(0).progress_apply(lambda x: x)
    except:
        pass

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-24 09:44:52.281049
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    dummy = (pd.DataFrame({'a': np.arange(100),
                           'b': np.arange(100)})
             .groupby('a')
             .progress_apply(lambda x: sum(x)))

    with tqdm(total=dummy.shape[0]) as t:
        t.pandas(desc="pandas test")

    summary = type(t).dynamic_miniters.get('pandas')
    assert summary, "Dynamic miniters not working"
    assert 1.0 <= summary.smoothed_f() <= 100.0, "Dynamic miniters broken"
    assert summary.smoothed_f() < 15.0, "Progress bar should have been closed"
    assert summary.last_print_n

# Generated at 2022-06-24 09:45:00.588769
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Old function usage
    tqdm_pandas(tqdm, desc="groupby progress")
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm_notebook())
    tqdm_pandas(tqdm_gui)
    tqdm_pandas(tqdm_gui())
    tqdm_pandas(tqdm_pandas)
    tqdm_pandas(tqdm_pandas())

    # Current function usage
    tqdm.pandas()
    tqdm.pandas(desc="groupby progress")
    tqdm_notebook.pandas()

# Generated at 2022-06-24 09:45:04.276956
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm(total=100))

    # tqdm_pandas(tqdm)  # deprecated alias
    # tqdm_pandas(tqdm())  # deprecated alias

# Generated at 2022-06-24 09:45:12.202622
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from random import randint
    from tqdm import tqdm, trange
    from time import sleep

    # Test basic loop over pandas dataframe
    df = pd.DataFrame(np.random.randn(10, 1))
    tqdm_pandas(tqdm())
    for i in df.progress_apply(lambda x: sleep(0.1) or x, axis=1):
        pass
    tqdm.options.display.close()

    # Test basic loop and display
    df = pd.DataFrame(np.random.randn(10, 1))
    tqdm_pandas(tqdm(leave=True, position=0), total=len(df))

# Generated at 2022-06-24 09:45:22.163322
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import random
    import string
    import tqdm
    import os

    def _gen_data(size=10000000):
        # random strings
        l = int(size / 10)
        random_strings = '\n'.join([''.join(
            [random.choice(string.ascii_lowercase) for _ in range(l)]) for _ in range(
                l)])
        # random ints
        random_ints = list(np.random.randint(-2**32, 2**32, l))
        data = '\n'.join([random_strings, str(random_ints)])
        return data

    # data to test tqdm_pandas
    data = _gen_data()

# Generated at 2022-06-24 09:45:29.841806
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def func(x):
        time.sleep(0.01)
        return np.sin(x)

    df = pd.DataFrame(np.random.random((10000, 10)))
    with tqdm(total=len(df), ascii=True, leave=False) as pbar:
        new_df = df.groupby(lambda x: x // 100).progress_apply(func)
    assert not pbar.n
    assert not pbar.total

# Check if tqdm_pandas(...) works without raising a DeprecationWarning
test_tqdm_pandas()

# Generated at 2022-06-24 09:45:39.325399
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        for tclass in [tqdm, tnrange]:
            try:
                with tclass(10, desc='test_tqdm_pandas') as iterable:
                    for _ in iterable:
                        _ = np.random.randint(2)
                pd.DataFrame(np.random.randint(10, size=(100, 6))). \
                    groupby(0, sort=False).progress_apply(lambda x: x)
            except ValueError:
                pass
    except ImportError:
        pass

# Generated at 2022-06-24 09:45:45.529593
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    # tests for delayed adapter
    assert tqdm_pandas(tqdm) is not None
    assert tqdm_pandas(tqdm) is not None
    assert tqdm_pandas(tqdm, total=100, file=sys.stdout).__class__.__name__ == 'tqdm'
    # tests for immediate adapter
    t = tqdm(total=100, file=sys.stdout)
    assert tqdm_pandas(t) is not None
    assert tqdm_pandas(t).__class__.__name__ == 'tqdm'
    assert tqdm_pandas(t).__class__.__name__ == 'tqdm'
    # test duplicated options
    assert tqdm_