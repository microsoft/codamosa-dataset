

# Generated at 2022-06-12 14:16:33.966662
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import math
    import random, string
    import tqdm
    import tqdm._tqdm as _tqdm
    from pandas import compat
    # init pandas df
    N = 50000
    df = pd.DataFrame(np.random.randint(0, 100, size=(N, 4)),
                      columns=list('ABCD'))

    def progress_bar_incompatible_function(df):
        # test for function which returns a list, for compatibility
        return [x + 1 for x in df['A']]

    def progress_bar_compatible_function(df):
        # test for function which returns a pd.Series, for performance
        return df['A'] + 1


# Generated at 2022-06-12 14:16:36.487612
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # test if we can call it with a class
    from tqdm import tqdm
    tqdm_pandas(tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:16:46.330061
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    asd
    """
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_notebook
    df = pd.DataFrame({'a': np.arange(1000)})
    df['b'] = np.random.rand(1000)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    # test deprecated function
    tqdm_pandas(tqdm, ascii=True)
    # test deprecated class
    tqdm_pandas(type(tqdm_notebook), ascii=True)
    df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-12 14:16:54.476148
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm.auto import tqdm
    tqdm_pandas(tqdm)
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x ** 2)


if __name__ == '__main__':
    from tqdm.auto import tqdm
    test_tqdm_pandas()
    tqdm_pandas(tqdm)
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x ** 2)

# Generated at 2022-06-12 14:17:00.587471
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    tqdm_pandas(tqdm.tqdm)
    fake_dict = {
        'x': [1, 2, 3, 4, 5, 6, 7, 8, 9],
        'y': [1, 2, 3, 4, 5, 6, 7, 8, 9],
        'z': [1, 2, 3, 4, 5, 6, 7, 8, 9]
    }
    df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 3)), columns=list('xyz'))
    # df = pd.DataFrame.from_dict(fake_dict)
    df['group'] = df['x']+df['y']


# Generated at 2022-06-12 14:17:05.237506
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    return tqdm_pandas(tqdm(bar_format='{l_bar}{bar}|  {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'))


# Unit test
if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:11.231627
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests that tqdm_pandas function works
    """
    import pandas as pd
    import numpy as np
    import tqdm


# Generated at 2022-06-12 14:17:19.484025
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    with tqdm(
            total=100,
            unit_scale=1,
            desc='Test',
            unit='',
            mininterval=0.5) as progress:
        progress.update(10)
    with tqdm(unit_scale=1, unit='', mininterval=0.5) as progress:
        progress.total = 100
        progress.update(10)
        progress.set_description('Test')
    with tqdm(unit_scale=1, unit='', mininterval=0) as progress:
        progress.total = 100
        progress.update(10)
        progress.set_description('Test')

# Generated at 2022-06-12 14:17:27.333968
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmTypeError
    import pandas as pd

    assert_raises(TqdmTypeError, tqdm_pandas, 5)
    assert_raises(TqdmTypeError, tqdm_pandas, None)
    assert_raises(TqdmTypeError, tqdm_pandas, "tqdm_pandas")

    # Test function-like case
    T = tqdm_pandas(tqdm, "test")
    assert getattr(pd.core.groupby.DataFrameGroupBy, "progress_apply_original", None)
    T.reset()
    assert not getattr(pd.core.groupby.DataFrameGroupBy, "progress_apply_original", None)

    # Test class-like case

# Generated at 2022-06-12 14:17:33.470620
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from random import randint
    import pandas as pd
    from tqdm import tqdm

    array = [randint(0, 10000) for _ in range(100)]
    df = pd.DataFrame({"a": array})

    # Using tqdm_pandas
    tqdm_pandas(tqdm())
    df2 = df.groupby("a").progress_apply(
        lambda x: x.tolist()[0])  # noqa: E127
    assert all(df.a == df2.a)

    # Using tqdm().pandas()
    tqdm().pandas()
    df2 = df.groupby("a").progress_apply(
        lambda x: x.tolist()[0])  # noqa: E127

# Generated at 2022-06-12 14:17:43.727082
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm, trange

    # Unit test for function tqdm_pandas
    df = pd.DataFrame(np.random.randint(0, 10, (100000, 6)))
    with trange(10) as t:
        for i in t:
            # Register `tqdm` to `pandas`
            tqdm_pandas(t, desc='Loop desc')
            # Now you can use `progress_apply` instead of `apply`
            df.groupby(0).progress_apply(lambda x: x ** 2)


if __name__ == '__tqdm__':
    # Test & benchmarking
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:49.639568
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'text': ['sample'] * 1000})
    result = df.groupby('text').progress_apply(lambda x: x)
    assert len(result) == 1
    assert result['text'].values[0] == 'sample'
    assert result['text'].values[0] == df['text'].values[0]

# Generated at 2022-06-12 14:17:52.015748
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    tqdm_pandas(tqdm)

    df = pd.DataFrame([1, 2, 3, 4])
    df.groupby(df[0]).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:00.014648
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import random

        df = pd.DataFrame({'x': [random.uniform(0, 2) for _ in range(100000)]})
        df = df.groupby(['x']).sum()

        def func(x):
            return x*2
        df.progress_apply(func).to_csv('test.csv')
    except:
        if PY3:
            from traceback import print_exc as exc
        else:
            from traceback import print_exc
        if os.path.exists('test.csv'):
            os.unlink('test.csv')
        print("ERROR: tqdm_pandas does not work (traceback below)\n")
        exc()

# Generated at 2022-06-12 14:18:04.776940
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        df = pd.DataFrame({'a': ['a', 'b', 'c', 'd']})
        tqdm_pandas(tqdm, total=len(df['a']))
        df.groupby('a').progress_apply(lambda x: 1)
    except Exception:
        pass

# Generated at 2022-06-12 14:18:10.104270
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    import sys

    try:
        # Python 3
        from StringIO import StringIO
    except ImportError:
        # Python 2
        from io import StringIO

    with tqdm(total=1, file=StringIO()) as t:
        tqdm_pandas(t, desc='Test')
        pd.DataFrame([1, 2, 3]).progress_apply(
            lambda x: (t.update(), x ** 2), axis=1)
        t.close()

# Unit test inside IPython

# Generated at 2022-06-12 14:18:21.915293
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame, Series

    # Test: deprecated function
    t1 = tqdm(**{'total': 2, 'desc': 'TQDM'})
    t2 = tqdm(**{'total': 2, 'desc': 'TQDM Clone'})
    tqdm_pandas(t1)
    tqdm_pandas(t2)
    try:
        tqdm_pandas(tclass=t1)
    except Exception:
        pass
    try:
        tqdm_pandas(tclass=t2)
    except Exception:
        pass

    # Test: progress_apply
    cls_test = DataFrame({'a': [1, 2, 3]})
    tqdm_pandas

# Generated at 2022-06-12 14:18:24.172077
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    t = tqdm.tqdm()
    tqdm_pandas(t)
    tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:18:35.160557
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    import numpy as np
    from pandas import DataFrame

    tqdm_pandas(tqdm())

    # Test basic usage
    df = DataFrame(np.random.randn(100, 100))
    df.progress_apply(lambda x: x ** 2)

    # Test tqdm_pandas(tqdm(...))
    tqdm_pandas(
        tqdm(total=10, bar_format='{desc}: {percentage:3.0f}%'))
    df = DataFrame(np.random.randn(100, 100))
    df.progress_apply(lambda x: x ** 2)

    # Test tqdm_pandas(tqdm(...)) changing `desc`
   

# Generated at 2022-06-12 14:18:42.835679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook, tqdm_gui

    # Deprecated case
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm(total=1))
        tqdm_pandas(tqdm, total=1)
        tqdm_pandas(tqdm_notebook, total=1)
        tqdm_pandas(tqdm_gui, total=1)

    # New case
    tqdm_pandas(total=1)
    tqdm_notebook(total=1).pandas()
    tqdm_gui(total=1).pandas()

    # Unit test for custom class
    class tqdm_foo(tqdm):
        pass



# Generated at 2022-06-12 14:18:57.672305
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    # Create test dataframe
    n = 1000
    df = pd.DataFrame()
    df["x"] = np.random.randint(0, 100, size=n)
    df["y"] = np.random.randint(0, 100, size=n)

    # Manual test case
    def square(x):
        return x**2

    def square_output(x):
        return x**2

    df["x_squared"] = df["x"].progress_apply(square)
    assert df["x_squared"].equals(df["x"].apply(square_output))

    # Test case for tqdm_pandas
    tqdm_pandas(tqdm)
   

# Generated at 2022-06-12 14:19:07.485433
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import re
    from tqdm import TqdmDeprecationWarning

    # Mock the deprecation warning
    def test_function(x):
        test_function._called_with = x

    test_function._called_with = None
    TqdmDeprecationWarning = test_function


# Generated at 2022-06-12 14:19:16.188679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    tqdm_pandas(tqdm)

    df = DataFrame({'a': [1, 2, 3], 'b': [2, 3, 4]})

    assert (df.groupby('a').progress_apply(lambda x: x['a'] * 2)) == df['a'] * 2
    assert (df.groupby('a').progress_apply(lambda x: x['a'] * 2, meta='b')) == \
        df['b'].map(str)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:26.953186
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    from tqdm import tqdm

    def example_function(df):
        s = 0
        for c in df.columns:
            s += df[c].sum()
        return s

    df = [{'a': i, 'b': i * i} for i in range(100)]
    df = pandas.DataFrame(df)

    assert numpy.allclose(df.progress_apply(example_function),
                          df.apply(example_function))
    assert numpy.allclose(tqdm_pandas(tqdm(leave=False)).progress_apply(
        df, example_function), df.apply(example_function))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:33.958416
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange  # NOQA, for testing
    from pandas import DataFrame
    df = DataFrame([1, 2, 3])
    assert df.progress_apply(lambda x: x * 2).equals(
        df.progress_apply(lambda x: x * 2))


if __name__ == '__main__':  # pragma: no cover
    from tqdm import tqdm  # NOQA, for testing
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:43.911705
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    from tqdm.contrib.concrete_tqdm import tqdm as tqdm_pandas
    try:
        import pandas as pd
        df = pd.DataFrame(dict(a=range(100), b=range(100, 200)))
    except Exception:
        print("WARNING: pandas is not installed, skipping tqdm_pandas test.")
        return
    import numpy as np
    try:
        import cytoolz as tlz
    except ImportError:
        try:
            import toolz as tlz
        except ImportError:
            print(
                "WARNING: cytoolz or toolz is not installed, "
                "skipping tqdm_pandas test.")
            return
    res = tl

# Generated at 2022-06-12 14:19:56.477927
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy

    # Removes tqdm_pandas() function warning
    import warnings
    with warnings.catch_warnings(): warnings.simplefilter('ignore')

    # Initialisation
    tqdm_pandas()

    # Tests
    if pandas.__version__ >= '0.18':
        df = pandas.DataFrame(numpy.random.rand(10000, 1))

        def f(x): return x % 2

        df = df.progress_apply(f)

    else:  # pragma: no cover
        from tqdm import trange
        from tqdm import TqdmDeprecationWarning

        with warnings.catch_warnings(record=True):
            warnings.simplefilter('ignore', TqdmDeprecationWarning)

# Generated at 2022-06-12 14:20:04.703315
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        tqdm = tqdm_pandas(pandas=True)  # pandas isn't installed
        a = pd.DataFrame([1, 2, 3])
        a.groupby(a[0]).progress_apply(lambda x: x**2)
    except Exception as e:  # pragma: no cover
        raise RuntimeError(
            "tqdm_pandas unit test failed\n{e}".format(e=e)) from None


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:14.118516
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest("Skipping pandas test (pandas not installed)")

    import sys
    import mock

    df = pd.DataFrame({'x1': ['a', 'b', 'c', 'd'] * 100,
                       'x2': np.random.rand(400)})
    from tqdm import tqdm, trange
    from tqdm.pandas import tqdm_pandas
    for t in trange, tqdm:
        tqdm_pandas(t)
        for tcls in tqdm, trange:
            dfi = df.copy()

            # Test __get_kwargs

# Generated at 2022-06-12 14:20:19.154934
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame(np.random.rand(10,1))
    for _ in tqdm_pandas(tqdm.tqdm(total=len(df), unit_scale=True, leave=False)):
        df.progress_apply(lambda x: x**2)

# Generated at 2022-06-12 14:20:29.232551
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)


if __name__ == '__main__':
    from tqdm import main
    main()

# Generated at 2022-06-12 14:20:32.018390
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm_pandas(tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:36.903407
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    from numpy import arange

    tqdm_pandas(tqdm)

    df = DataFrame(arange(1e4), columns=['val'])
    res = df.groupby('val').progress_apply(lambda x: x)
    assert len(res) == 1

# Generated at 2022-06-12 14:20:47.900844
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    from tqdm.contrib import pd_deprecation_decorator

    @pd_deprecation_decorator
    def tqdm_map(self, func):
        return self.progress_apply(func)

    @pd_deprecation_decorator
    def tqdm_reduce(self, func):
        return self._reduce(func)

    @pd_deprecation_decorator
    def tqdm_iter(self):
        return self.iteritems()


# Generated at 2022-06-12 14:20:58.526636
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return  # SKIP
    else:
        from tqdm._utils import _term_move_up
        from tqdm.std import tqdm
        from tqdm.autonotebook import tqdm as tqdm_notebook
        from tqdm import TqdmTypeError, TqdmKeyError, TqdmWarning

        def _select_tqdm(tqdm_cls, mininterval):
            is_notebook = get_ipython() is not None
            if is_notebook:
                return tqdm_notebook(tqdm_cls, mininterval=mininterval)
            else:
                return tqdm_cls(mininterval=mininterval)


# Generated at 2022-06-12 14:21:10.002883
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test"""
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas
    from .tqdm import tqdm

    # Generate a DataFrame of 10000000 rows and progress bar with `tqdm_pandas()`
    df = pd.DataFrame(np.random.randn(10000000,2))
    assert "Progress of `mean`" in str(tqdm_pandas(tqdm(ncols=100)))
    assert "Progress of `mean`" in str(df.groupby(0).progress_apply(np.mean))

    # Deprecated behaviour

# Generated at 2022-06-12 14:21:21.812763
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import Series, DataFrame
    from tqdm.pandas import trange
    from numpy.random import randn

    try:
        import pandas_datareader  # pip install pandas_datareader
    except ImportError:
        return
    try:
        import requests
        requests.get('http://google.com')
    except Exception:
        return

    # tqdm.pandas()
    df = DataFrame(randn(100, 3))
    df.progress_apply(lambda x: x**2)

    # tqdm_pandas()
    df = DataFrame(randn(100, 3))
    tqdm_pandas(trange, desc='tqdm_pandas()')
    df.progress_apply(lambda x: x**2)

    #

# Generated at 2022-06-12 14:21:24.933967
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tclass = type('TestTqdm', (_tqdm,), {'pandas': lambda _: 42})
    assert tqdm_pandas(tclass) == 42



# Generated at 2022-06-12 14:21:29.866241
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np

        df = pd.DataFrame(np.random.randint(100, size=(100000, 2)), columns=list('AB'))
        t = tqdm(total=len(df.index))

        def f(x):
            t.update(1)
            return x ** 2

        tqdm_pandas(t, df.progress_apply(f, axis=1))
    except ImportError:
        pass



# Generated at 2022-06-12 14:21:40.309073
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas
    # Create pandas DataFrame
    df = pd.DataFrame({'a': [[1, 2], [3, 4]], 'b': [1, 2]})
    df['c'] = df.progress_apply(lambda row: row['a'] + row['b'], axis=1)
    assert df['c'].to_list() == [[1, 2, 1, 2], [3, 4, 1, 2]]
    # Test tqdm_pandas via decorator
    tqdm_pandas()
    # Test tqdm_pandas via function
    tqdm_pandas(tqdm)
    # Test tq

# Generated at 2022-06-12 14:21:56.894165
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    tqdm_pandas(tqdm)
    assert ('apply' in dir(pd.core.groupby.DataFrameGroupBy))
    assert ('apply' in dir(pd.core.groupby.SeriesGroupBy))
    assert ('progress_apply' in dir(pd.core.groupby.DataFrameGroupBy))
    assert ('progress_apply' in dir(pd.core.groupby.SeriesGroupBy))
    assert ('progress_map' in dir(pd.core.groupby.SeriesGroupBy))

    df = pd.DataFrame({'col': np.arange(1000)})
    df.groupby('col').progress_apply(lambda x: x**2)


# Generated at 2022-06-12 14:22:05.038318
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook
    import pandas as pd
    import numpy as np
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    df = pd.DataFrame(
        {'a': np.random.choice(range(1000), size=1000),
         'b': np.random.choice(range(1000), size=1000)})
    # tqdm_pandas(tqdm)  # dummy to test deprecation warning
    # tqdm_pandas(tqdm())  # dummy to test deprecation warning

# Generated at 2022-06-12 14:22:14.454076
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame

    def prog2(x):
        assert isinstance(x, pd.DataFrame)
        return x + 1

    # No printing
    df = DataFrame(np.random.random((10, 2)), columns=['a', 'b'])
    assert (df.groupby('a').progress_apply(prog2) ==
            df.groupby('a').apply(prog2)).all().all()
    assert (df.groupby('a', as_index=False).progress_apply(prog2) ==
            df.groupby('a', as_index=False).apply(prog2)).all().all()

    # Printing
    df = DataFrame(np.random.random((10, 2)), columns=['a', 'b'])

# Generated at 2022-06-12 14:22:25.964284
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas()
    """
    # For unit test only, otherwise monkey-patch
    import tqdm._tqdm
    if '_tqdm' not in sys.modules:
        tqdm._tqdm.__dict__.update(sys.modules['tqdm'].__dict__)
        sys.modules['_tqdm'] = sys.modules['tqdm']
        tqdm._tqdm_orig = tqdm._tqdm
    import unittest

    class TestTqdmPandas(unittest.TestCase):
        def test_tqdm_pandas_simple(self):
            from tqdm import tqdm
            tqdm_pandas(tqdm())


# Generated at 2022-06-12 14:22:28.078858
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm(total=4, file=sys.stdout))



# Generated at 2022-06-12 14:22:36.187063
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm import tqdm
    from tqdm.contrib.tests.pandas_dataframe import df

    # Enable with tqdm instance
    tqdm_pandas(tqdm(), total=df.size)
    # Enable with tqdm class
    tqdm_pandas(tqdm, total=df.size)
    # Enable with tqdm_notebook instance
    tqdm_pandas(tqdm.tqdm_notebook, total=df.size)
    # Enable with tqdm_notebook class
    tqdm_pandas(tqdm.tqdm_notebook.tqdm_notebook, total=df.size)


# Generated at 2022-06-12 14:22:46.192388
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=list('ABCDEF'))

    # `progress_apply` available since 0.18.0
    if LooseVersion(pd.__version__) >= '0.18.0':
        # `progress_apply` default
        result = df.groupby('A').progress_apply(lambda x: x.sum())

        # `apply` (regular iterator)
        result = df.groupby('A').apply(lambda x: x.sum())

        # `progress_apply` (TQDM notebook)

# Generated at 2022-06-12 14:22:55.206722
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    pd = TqdmExperimentalWarning(
        "`tqdm.pandas(tqdm)` is deprecated, use `tqdm.pandas()` instead.")
    with capture_stderr() as s:
        tqdm_pandas(tqdm())
    assert pd.message in s.getvalue()
    s.truncate(0)
    with capture_stderr() as s:
        tqdm_pandas(tqdm, miniters=1)
    assert pd.message in s.getvalue()

# Generated at 2022-06-12 14:23:03.429513
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import re
    import sys

    def test_tqdm_pandas_regression():
        pbar = tqdm_pandas(tqdm())
        df = pd.DataFrame(dict(
            A=np.arange(1000),
            B=np.arange(1000),
        ))
        df.groupby('A')['B'].progress_apply(lambda x: x + 1)

        # Collect printed output and make sure there are no exceptions.
        # In particular, this tests for the regression in #301.
        printed = sys.stdout.getvalue().strip()
        assert not re.search(r'Exception', printed), printed
        assert re.search(r'tqdm_pandas/1000it', printed), printed


# Generated at 2022-06-12 14:23:10.056766
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    import numpy as np

    df = pd.DataFrame({'a': np.random.randn(1_000_000),
                       'b': np.random.randn(1_000_000)})
    with tqdm(total=len(df.index)) as t:
        _ = df.groupby('a').progress_apply(lambda x: x + 1, t=t)

# Generated at 2022-06-12 14:23:27.052091
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    #import pandas as pd
    #from tqdm import trange
    #df = pd.DataFrame({'x': range(1000)})
    #progress_tqdm = tqdm_pandas(tqdm())
    #df.groupby(0).progress_apply(lambda x: sum(x))
    pass


if __name__ == '__main__':
    #pass
    test_tqdm_pandas()
    #import pandas as pd
    #from tqdm import trange
    #df = pd.DataFrame({'x': range(1000)})
    #progress_tqdm = tqdm_pandas(tqdm())
    #df.groupby(0).progress_apply(lambda x: sum(x))

# Generated at 2022-06-12 14:23:31.262416
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def pow2(x):
        return x**2

    tqdm_pandas(tqdm(total=pd.DataFrame().pow(2).progress_apply(pow2)._estimate_length(),
                     ascii=True,
                     miniters=1))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:37.317648
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame(data={'a': [1, 2, 3, 4], 'b': [5, 6, 7, 8]})
    from tqdm import tqdm
    with tqdm(total=len(df)) as pbar:
        df.groupby('a').progress_apply(lambda x: x+1, pbar=pbar)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:44.430184
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas """
    import pandas as pd

    data = pd.DataFrame({
        'x': [0, 0, 1, 1],
        'y': [0, 1, 0, 1],
        'z': list('abcd')
    })

    # Should work with iterables
    t = tqdm_pandas(data)
    assert isinstance(t, pd.core.groupby.DataFrameGroupBy)
    with suppress(Exception):
        t.apply(len)

    # Should work with options
    t = tqdm_pandas(data, total=len(data))
    assert isinstance(t, pd.core.groupby.DataFrameGroupBy)
    with suppress(Exception):
        t.apply(len)

    # Should work

# Generated at 2022-06-12 14:23:55.350546
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    pd.DataFrame([1, 2, 3]).progress_apply(lambda x: x + 1)
    pd.DataFrame([1, 2, 3]).groupby(0).progress_apply(lambda x: sum(x))
    df = pd.DataFrame(
        [
            [pd.Timestamp('20180101 00:00:00'), 4, 0.1],
            [pd.Timestamp('20180101 00:00:00'), 4, 0.2],
            [pd.Timestamp('20180101 00:00:00'), 4, 0.3]
        ],
        columns=['date', 'symbol', 'val'])

# Generated at 2022-06-12 14:23:58.124586
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    t = tqdm(total=100)
    try:
        assert (isinstance(t, type(t.pandas())))
    finally:
        t.close()

# Generated at 2022-06-12 14:24:05.683252
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame({'a': list(range(1000))})
    try:
        tqdm_pandas(tqdm)
        pbar = tqdm_pandas(df.groupby('a').progress_apply)
        assert type(pbar) is type(df.groupby('a'))
        assert hasattr(pbar, 'pbar_')
        assert pbar.pbar_.fp == sys.stderr
        assert not pbar.pbar_.disable
        assert not pbar.pbar_.unit_scale

    finally:
        from tqdm import tqdm_gui, tqdm_notebook
        for tclass in [tqdm_gui, tqdm_notebook]:
            tqdm_pandas(tclass)


# Generated at 2022-06-12 14:24:09.519479
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    d = pd.DataFrame({'low': [1, 2, 3], 'high': [4, 5, 6]})

    # TODO: write unit tests
    pass

if __name__ == '__main__':
    test_tqdm_pandas()
    sys.exit(0)

# Generated at 2022-06-12 14:24:14.237743
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    # Testing with tqdm module
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    # Testing with tqdm instance
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_notebook())
# tqdm_pandas.tests = {"1": test_tqdm_pandas}


# legacy
tqdm_gui = _deprecate_alias(
    "tqdm.gui",
    "Please use `tqdm_notebook` instead of `tqdm.gui`.",
    "tqdm_notebook",
)
# tqdm_gui.__all__ = []  # hide from help


# Generated at 2022-06-12 14:24:25.422260
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # create a dummy tqdm instance for testing purposes
    class dummy_tqdm:
        def __init__(self, **kwargs):
            pass

        def pandas(self, deprecated_t=None):
            pass

    # test the deprecated case
    test_tqdm = dummy_tqdm()
    try:
        tqdm_pandas(test_tqdm)
        assert False, "No warning was raised"
    except Exception as e:
        assert type(e) == TqdmDeprecationWarning
    tqdm_pandas(dummy_tqdm, file=dummy_tqdm())
    tqdm_pandas(dummy_tqdm(name="test"))
    tqdm_pandas(test_tqdm)

    # test the currently supported case

# Generated at 2022-06-12 14:24:35.852831
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        tqdm_pandas(tqdm(), ncols=100)
        tqdm_pandas(tqdm(total=100))
        df = pandas.DataFrame([[1, 2, 3], [4, 5, 6]])
        df.groupby(1).progress_apply(lambda x: x)
    except Exception as e:
        raise e


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:44.307576
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import _test_deprecation

    class TqdmCls(object):
        def __init__(self, *args, **kwargs):
            self.total = 100
            self.n = 0

        def __iter__(self):
            return self

        def __next__(self):
            self.n += 1
            if self.n > self.total:
                raise StopIteration()
            return self.n

        def update(self, n):
            self.n = n

    class DeprecatedTqdmCls(object):
        def __init__(self, *args, **kwargs):
            self.total = 100
            self.n = 0

        def __iter__(self):
            return self

        def __next__(self):
            self.n += 1

# Generated at 2022-06-12 14:24:49.408741
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        from random import random

        def test_pandas():
            pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm(
                pd.core.groupby.DataFrameGroupBy.progress_apply, total=100, mininterval=0)
            df = pd.DataFrame({'test': [random() for _ in range(100)]})
            df = df.groupby(['test']).sum()

        test_pandas()
    except Exception as e:
        print(e)

# Generated at 2022-06-12 14:24:58.602969
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        tqdm_pandas(tqdm)
        assert len(w) == 1


# Extend pandas.DataFrame.progress_apply()
if not hasattr(pd.DataFrame, '_progress_apply'):
    pd.DataFrame._progress_apply = pd.DataFrame.progress_apply

    def progress_map(self, *args, **kwargs):
        """ Calls `tqdm.pandas(...)` on `DataFrame.progress_map(...)`.

        Note: `tqdm.pandas(...)` does not support keyword arguments.
        """
        return tqdm_pandas(pd.DataFrame.progress_map, self, *args, **kwargs)

    p

# Generated at 2022-06-12 14:25:06.580281
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas
    """
    try:
        import pandas
        import numpy

        def apply_func(x):
            return x + x

        def test(df):
            return df.groupby('A').progress_apply(apply_func)

        tqdm_pandas(tqdm)
        df = pandas.DataFrame({'A': numpy.arange(10000)})
        test(df)
    except ImportError:
        warn("pandas is not installed")


if __name__ == "__main__":
    from tqdm import tqdm
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:16.148584
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import numpy as np
    import pandas as pd

    def mul(x):
        return x * np.random.rand()

    df = pd.DataFrame(np.random.rand(100, 1))
    try:
        from tqdm.auto import tqdm
    except ImportError:
        from tqdm import tqdm

    # Test `tqdm` as a function
    with tqdm(desc="tqdm_pandas test") as t:
        tqdm_pandas(t)
        df.progress_apply(mul)

    # Test `tqdm` as a class

# Generated at 2022-06-12 14:25:20.250034
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({'a': range(20)}, dtype='float64')
    df = df.groupby('a').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:28.582198
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame, Series
    except ImportError:
        return  # Testing without pandas

    # Create a DataFrame (df) and a Series (s)
    df = DataFrame(
        {
            'Col1':
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            'Col2':
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            'Col3':
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        },
        columns=['Col1', 'Col2', 'Col3'])
    s = Series(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'])



# Generated at 2022-06-12 14:25:31.554877
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    proc = pd.DataFrame({"a": [t for t in range(1000)]})
    with tqdm(total=len(proc)) as pbar:
        proc.progress_apply(lambda r: pbar.update())

# Generated at 2022-06-12 14:25:41.210600
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    def _func(df):
        return df.sum()

    N = 1000
    test_df = pd.DataFrame(np.random.random((N, 5)))
    with tqdm.tqdm_pandas(total=test_df.groupby(0).ngroups) as pbar:
        test_df.groupby(0).progress_apply(_func)

    def _func(df):
        raise Exception('test_tqdm_pandas')

    with pytest.raises(Exception):
        with tqdm.tqdm_pandas(total=test_df.groupby(0).ngroups) as pbar:
            test_df.groupby(0).progress_apply(_func)

# Generated at 2022-06-12 14:26:05.349765
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    n_rows = 10000

    # allow users to override default max_rows setting
    max_rows = getattr(tqdm.tqdm, "pandas_max_rows_setting", 100)

    print(max_rows)

    df = pd.DataFrame(
        {'A': [1, 2, 3] * n_rows,
         'B': [4, 5, 6] * n_rows,
         'C': [7, 8, 9] * n_rows})

    with tqdm.tqdm_pandas(total=df.shape[0]) as pbar:
        res = df.groupby('A').progress_apply(
            lambda x: x['B'].sum() + x['C'].sum())


# Generated at 2022-06-12 14:26:14.561340
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_gui)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_gui)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_gui())
    tqdm_pandas(tqdm_notebook())
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_gui())

# Generated at 2022-06-12 14:26:19.281285
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import pandas
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({'x': np.random.randn(1000)})
    with pandas.tqdm_pandas(total=len(df)) as prog_bar:
        df.apply(lambda x: x, axis=1)
        assert prog_bar.n == 1000

# Generated at 2022-06-12 14:26:26.780506
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    from tqdm import tqdm, tqdm_notebook
    from tqdm.tests import setup_tests, pretest_posttest

    # Very 'manual' test: only test if function call succeeds,
    # and use assertion only to check that `pandas` is available
    # (so code coverage is not affected if it is not installed)
    with pretest_posttest() as (p, _):
        for t in (tqdm, tqdm_notebook):
            tqdm_pandas(t)
        assert not p.disabled
        assert p.trange(3).__enter__().__next__() == 0
        assert p.clear(1)
        assert p.display(0)
        assert not p.disable