

# Generated at 2022-06-12 14:16:33.220936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_pandas

    def dummy_df_iter(df, chunksize=10):
        for i in range(0, len(df), chunksize):
            yield df.iloc[i:i + chunksize]

    from pandas import DataFrame
    df = DataFrame({'A' : [1, 2, 3, 4, 5],
                    'B' : [10, 20, 30, 40, 50],
                    'C' : [5, 4, 3, 2, 1],
                    'D' : [0.1, 0.2, 0.3, 0.4, 0.5]})

# Generated at 2022-06-12 14:16:40.122601
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # This module also serves as a unit test for function tqdm_pandas
    # to make sure that it does not break on any update to pandas
    import pandas
    from warnings import catch_warnings
    from tqdm import tqdm
    with catch_warnings(record=True) as w:
        tqdm_pandas(tqdm)
        assert (len(w) == 2)
        assert (issubclass(w[-1].category, DeprecationWarning))
    with catch_warnings(record=True) as w:
        tqdm_pandas(tqdm, desc='test')
        assert (len(w) == 1)
        assert (issubclass(w[-1].category, DeprecationWarning))


# Generated at 2022-06-12 14:16:49.302282
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    # Can't test "adapter case" with tclass = tqdm
    # since tqdm is not imported until function call

    # No data frame - will throw an error
    # tqdm_pandas(tqdm(10))

    # No progress - will throw an error
    # tqdm_pandas(tqdm())

    # The following does not work, maybe because it is not a data frame
    # d = [1, 2, 3, 4, 5]
    # tqdm_pandas(tqdm(d))

    # The following works
    tqdm_pandas(tqdm(None, total=10))
    tqdm_pandas(tqdm(total=10))



# Generated at 2022-06-12 14:16:58.439142
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import sys
    import pandas as pd

    def test_pbar(x):  # mock function that takes some time
        if x is None:
            return
        elif x % 2 == 0:
            return x
        sleep(0.1)  # sleep a while to slow down
        return x

    df = pd.DataFrame(np.random.randn(1000))
    tqdm_pandas(tqdm(file=sys.stdout))  # tqdm_pandas(tqdm_obj)
    df.progress_apply(test_pbar)

    tqdm_pandas(tqdm)  # tqdm_pandas(tqdm_class)
    df.progress_apply(test_pbar)

    with closing(StringIO()) as s:
        t

# Generated at 2022-06-12 14:17:00.621354
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    pass

# Backwards compatibility
if sys.version_info >= (3, 0):
    tqdm_pandas.register = tqdm_pandas

# Generated at 2022-06-12 14:17:05.580254
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    @tqdm_pandas
    def testme(x):
        from time import sleep
        sleep(0.01)
        return x

    df = pandas.DataFrame({'x': range(1000)})
    assert df.groupby('x').progress_apply(testme).equals(df)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:16.033764
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from numpy import random
    from time import sleep


    def fn(x):
        sleep(0.01)  # some heavy operation
        return x


    # -- Test 1: Test with `tqdm` instance
    t = tqdm(postfix="my postfix", unit_scale=True)
    tqdm_pandas(t, total=100)
    df = DataFrame(random.randn(100, 5))
    g = df.groupby(0)
    assert g.progress_apply(fn).equals(g.apply(fn))  # noqa


    # -- Test 2: Test with `tqdm` adapter
    df = DataFrame(random.randn(100, 5))

# Generated at 2022-06-12 14:17:23.108109
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib.tests import healthcare

    df = pd.DataFrame(healthcare.TYPICAL_PATIENTS)
    # Register tqdm instance with pandas
    with tqdm(total=len(df), file=sys.stderr) as t:
        df.groupby('gender').progress_apply(
            lambda x: x['weight'] / ((x['height'] / 100) ** 2),
            axis=1,
            reduce=True,
            iterable=True,
            t=t,
        )
    # Register tqdm class with pandas
    tqdm_pandas(tqdm, total=len(df), file=sys.stderr)
    df.groupby('gender').progress_

# Generated at 2022-06-12 14:17:31.065427
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from functools import wraps
    from tqdm import tqdm
    from tqdm._tqdm import TqdmDefaultWriteLock
    try:
        from pandas.core.groupby.generic import DataFrameGroupBy
    except ImportError:  # pragma: no cover
        return
    # Number of iterations
    N = 10
    # Generate a pandas dataframe
    df = pd.DataFrame({'A': list(range(N))})
    # Check that tqdm_pandas works identically
    # on progress_apply and progress_apply_simple (without grouper)

    def func(df):
        """Test function"""
        return df

    def func2(df):
        """Test function"""
        return df

    # Patch DataFrameGroupBy.progress_

# Generated at 2022-06-12 14:17:41.995872
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas as tqdm_pd
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'a': np.random.randint(1000, size=100),
                       'b': np.random.randint(1000, size=100)})

    df['c'] = df.progress_apply(lambda x: x['a'] + x['b'], axis=1)
    def func(df):
        return df['a'] + df['b']
    df['d'] = df.progress_apply(func, axis=1)
    df = pd.DataFrame({'a': np.random.randint(1000, size=10000),
                       'b': np.random.randint(1000, size=10000)})

# Generated at 2022-06-12 14:17:53.728698
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm._version import __version__
    from pandas import DataFrame, Series

    dts = Series([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    tqdm_pandas(tqdm, desc='tqdm_pandas_test')
    dts.groupby(lambda _: 'A').progress_apply(lambda g: g.sum()).head()
    df = DataFrame({'A': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                    'B': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]})

# Generated at 2022-06-12 14:18:03.278815
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import Series
    from tqdm import tqdm, trange
    from numpy.random import randint

    class dummy_class():
        def apply(self, func):
            for i in trange(10, desc="foo", leave=False):
                func(Series(randint(i, i + 10, size=10)))

    dummy_data = DataFrame([1, 2, 3])
    dummy_data.groupby(0).progress_apply(lambda x: x)
    dummy_data.groupby(0).apply(lambda x: x)
    tqdm_pandas(tqdm(), desc="foo")
    dummy_data.groupby(0).progress_apply(lambda x: x)
    dummy_data.groupby(0).apply(lambda x: x)

# Generated at 2022-06-12 14:18:09.948672
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    try:
        import pandas
    except ImportError:
        return
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, ncols=100, bar_format='{n_fmt}')
    tqdm_pandas(tqdm, file=sys.stdout)
    tqdm_pandas(tqdm, file=[sys.stdout, 42])
    tqdm_pandas(tqdm, file=[sys.stdout, sys.stderr])
    tqdm_pandas(tqdm, file=sys.stdout, dynamic_ncols=True)
    tqdm_pandas(tqdm, ascii=True)
    tqdm_p

# Generated at 2022-06-12 14:18:21.491368
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Simple unit tests for tqdm_pandas"""
    from tqdm import tqdm

    with tqdm() as t:
        tqdm_pandas(t)
    with tqdm() as t:
        tqdm.pandas(t)
    tqdm_pandas(tqdm)
    tqdm.pandas()


if __name__ == '__main__':
    from tqdm import tqdm, tqdm_gui
    if len(sys.argv) == 2 and sys.argv[1] in ['tqdm', 'tqdm_gui']:
        tqdm_pandas(eval(sys.argv[1]))
    else:
        test_tqdm_pandas()

# Generated at 2022-06-12 14:18:25.358134
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame
    tq = tqdm(total=1)
    assert tq._total == 1
    tqdm_pandas(tq)
    assert tq._total == "?"
    # test that it works
    DataFrame(range(4)).progress_apply(sum)

# Generated at 2022-06-12 14:18:32.269444
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with closing(StringIO()) as our_file:
        tqdm.pandas(tqdm_kwargs=dict(bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt}', file=our_file))
        assert pd.Series(range(1000)).progress_apply(lambda x: x**2).tail(5).tolist() == [984, 985, 986, 987, 988]



# Generated at 2022-06-12 14:18:39.746957
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    from pandas import DataFrame, Series
    from random import shuffle
    from tqdm import tqdm
    try:
        from numpy.random import randint
    except ImportError:
        from numpy.random import randint

    # Create a pandas dataframe with a column of integers
    df = DataFrame({'int': list(randint(0, 100, size=1000))})

    # Shuffle the rows
    df = df.sample(frac=1)

    # Apply tqdm_pandas to each column, using the same tqdm
    ncols = df.shape[1]
    with tqdm(total=ncols) as pbar:
        _ = df.progress_apply(lambda x: x, axis=0, t=tqdm(pbar=pbar)).head()

    # Apply

# Generated at 2022-06-12 14:18:45.168961
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange
    import pandas
    tqdm_pandas(tnrange)
    try:
        # This can take a while
        pandas.DataFrame([*range(1000000)]).groupby(0).progress_apply(lambda x: x)
    except Exception as e:
        assert str(e) == "No module named 'tqdm'"
        raise e

# Generated at 2022-06-12 14:18:50.400234
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        from tqdm.autonotebook import tqdm, trange
    except ImportError:
        from tqdm import tqdm, trange

    # Test success message
    tqdm_pandas(tqdm)

    # Test warning message
    tqdm_pandas(trange)


# Generated at 2022-06-12 14:18:55.741826
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.arange(100000))
    for i in tqdm_pandas(range(100000)):
        if i>50000:
            break
        df.progress_apply(lambda x: x+i)

# Generated at 2022-06-12 14:19:08.331057
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # function tqdm_pandas(tclass, **tqdm_kwargs)
    # tqdm_pandas(tqdm, **tqdm_kwargs) and tqdm_pandas(tqdm(...))
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm, total=len(df), smoothing=0.05)
    res = df.groupby(0).progress_apply(lambda x: x**2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:19.455272
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_notebook
    from tqdm.auto import trange

    # Test tqdm_pandas with bar tqdm, tqdm_notebook, tqdm
    test_list = [['Mercedes-Benz', '1,300,000'],
                 ['BMW', '845,186'], ['Audi', '589,480'],
                 ['Mercedes-Benz', '1,300,000'],
                 ['BMW', '845,186'], ['Audi', '589,480']]
    df = pd.DataFrame(test_list, columns=['Brand', 'Sales'])
    df['Sales'] = df['Sales'].astype(int)

    # test with tq

# Generated at 2022-06-12 14:19:24.430093
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm.pandas import tqdm_pandas
    from glob import glob
    from subprocess import PIPE
    from os.path import join

    files = glob(join(__file__.split('test_')[0], '*.py'))[:15]

    # Test 1
    df = pd.DataFrame(files, columns=['filepath'])
    df = df.progress_apply(lambda x: open(x).read().replace('\n', ''))

    # Test 2
    df = pd.DataFrame(files, columns=['filepath'])
    s = df.progress_apply(lambda x: open(x).read().replace('\n', ''))

    # Test 3

# Generated at 2022-06-12 14:19:32.652138
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from tqdm._tqdm import TqdmDeprecationWarning
    from pandas import DataFrame
    from numpy import random
    from pytest import raises
    from time import sleep

    from .tests_tqdm import closing, pretesting

    with closing(StringIO()) as our_file, pretesting(our_file):
        # Test for delayed adapter case
        with raises(TqdmDeprecationWarning):
            tqdm_pandas(tqdm, file=our_file)
        with raises(TqdmDeprecationWarning):
            tcls = tqdm(file=our_file)
            tqdm_pandas(tcls)

        # Test for regular case

# Generated at 2022-06-12 14:19:38.432610
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    df = DataFrame(data={'a':[1,2,3,4], 'b':[4,3,2,1]})
    df['c'] = df.progress_apply(lambda row: row.a + row.b, axis=1)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:46.162531
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:19:56.894719
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import tenumerate
    from tqdm.contrib._pandas import _progress_apply

    def assert_correct_type():
        assert _progress_apply.__name__ == '_progress_apply'
        assert _progress_apply.__module__ == 'tqdm.contrib._pandas'

    def test_tqdm_tclass():
        pd = pytest.importorskip('pandas')
        tqdm = pytest.importorskip('tqdm')

        tqdm_pandas(tqdm)
        tclass = tqdm(range(6))
        assert_correct_type()

        # Check apply
        pd.Series.progress_apply = _progress_apply
        pd.DataFrame.progress_apply = _progress_apply

# Generated at 2022-06-12 14:20:06.850781
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.utils import _supports_unicode, tqdm_deeply_nested
    from tqdm.auto import tqdm as tqdm_auto
    with tqdm() as t:
        assert isinstance(t, tqdm)
        assert isinstance(t, tqdm_auto)
        assert t.total == 0
        assert t.last_print_n == 0
        t.total = 1000
        assert t.total == 1000
        assert not t.last_print_n
        try:
            tqdm_pandas(t)
        except AttributeError:
            pass  # For tqdm_auto that does not support pandas
        else:
            assert "DataFrameGroupBy" in t.__

# Generated at 2022-06-12 14:20:17.798307
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except Exception:
        from pandas.core.groupby import DataFrameGroupBy

    if not hasattr(DataFrameGroupBy, 'progress_apply'):
        # If pandas is too old, skip this test
        return None

    df = DataFrame({'a': ['aaa', 'bbb'] * 50, 'b': list(range(100))})
    tqdm_pandas(tqdm)
    assert list(df.groupby('a').progress_apply(len)) == [50, 50]
    # Cleanup
    DataFrameGroupBy.progress_apply = DataFrameGroupBy.apply


test_tqdm_pandas()

# Generated at 2022-06-12 14:20:22.915483
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_pandas
    df = pd.DataFrame({"col1": [1, 2, 3, 4], "col2": [2, 3, 4, 5]})
    tqdm_pandas(df.progress_apply(lambda x: x))
    # df.progress_apply(lambda x: x)
    return


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:33.492203
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:42.352876
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    pd.DataFrame.progress_apply = tqdm_pandas(tqdm)

    # Test dataframe
    test_df = pd.DataFrame(np.random.randn(100, 3))

    # Test function
    def test_func(a):
        import time
        time.sleep(0.01)  # artificial time.sleep to simulate an actual function
        return a * 2

    # Apply test function to the dataframe
    test_df.progress_apply(func=test_func, axis=0)

# Generated at 2022-06-12 14:20:50.843750
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ModuleNotFoundError:
        from warnings import warn
        warn("Package pandas not found. This test won't run.")
        return
    from pandas import DataFrame
    df = DataFrame({'x': [1, 2, 3, 4, 5],
                    'y': [6, 7, 8, 9, 10]})
    res = df.groupby(['x'])
    res.progress_apply(lambda x: x)
    tqdm_pandas(res, desc="My loop")
    tqdm_pandas(res, desc="My loop", leave=False)
    res.progress_apply(lambda x: x)
    tqdm_pandas(res, leave=False)
    res.progress_apply(lambda x: x)
    tqdm_

# Generated at 2022-06-12 14:21:01.841032
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    df = pd.DataFrame([{'a': 1}, {'a': 2}])
    deprecated_t = tqdm(total=2, leave=False)
    tqdm_pandas(deprecated_t, file=deprecated_t.fp)
    df.groupby('a').progress_apply(lambda x: x)
    deprecated_t.close()
    with warnings.catch_warnings(record=True) as w:
        t = tqdm(total=2)
        tqdm_pandas(t)
        df.groupby('a').progress_apply(lambda x: x)
        t.close()
    assert issubclass(w[0].category, TqdmDeprecationWarning)
   

# Generated at 2022-06-12 14:21:12.670854
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({'A': np.arange(100),
                       'B': ['foo'] * 100,
                       'C': np.random.randint(100, size=100)})
    with tqdm(total=len(df.index)) as pbar:
        def apply_func(row):
            pbar.update()
            return row['A'] + row['C']

        df['D'] = df.progress_apply(apply_func, axis=1)
        assert len(df['D'].dropna()) == len(df.index)
        pbar.close()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:24.205068
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit tests for `tqdm.auto.tqdm_pandas`.
    """
    try:
        import pandas as pd
    except ImportError:
        return

    from pandas import DataFrame, Series
    from tqdm.auto import tqdm

    tqdm_pandas(tqdm)

    # Call with `df.progress_apply`
    df = DataFrame({'a': [0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]})
    df_out = df.progress_apply(lambda x: x)
    for i, e in enumerate(df_out.values.flatten()):
        assert i == e

    # Call with `df.groupby('a').progress_apply`

# Generated at 2022-06-12 14:21:32.658879
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    tpandas0 = tqdm_pandas(tqdm(file=StringIO()))
    tpandas1 = tqdm_pandas(tqdm(file=StringIO()), total=3)
    tpandas2 = tqdm_pandas(tqdm_notebook)
    tpandas3 = tqdm_pandas(tqdm(file=StringIO()), total=3)
    assert tpandas0.total == 100
    assert tpandas1.total == 3
    assert tpandas2.total == 100
    assert tpandas3.total == 3

# Generated at 2022-06-12 14:21:38.621288
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    df = pd.DataFrame(dict(a=range(10000), b=range(10000), c=range(10000)))
    tqdm_pandas(tqdm(total=df.shape[0] + 1),
                desc="Progress: ").progress_apply(
                    func=lambda x: x * 2, axis=1)

# Generated at 2022-06-12 14:21:41.729422
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas


if __name__ == '__main__':
    from .tqdm import _main
    _main(__doc__)

# Generated at 2022-06-12 14:21:47.797843
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def tqdm_pandas_test():
        pd = pytest.importorskip('pandas')
        tqdm = pytest.importorskip('tqdm')
        df = pd.DataFrame(np.random.randn(100, 2))

        @tqdm_pandas
        def foo(data):
            return data.foo

        df.groupby('bar').progress_apply(foo)
        df.groupby('bar').progress_apply(lambda x: x)

    tqdm_pandas_test()

# Generated at 2022-06-12 14:21:56.736287
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:22:04.893570
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
    except ImportError:
        print("Skipping pandas tests")
        return
    try:
        from pandas.core.groupby import DataFrameGroupBy
        DataFrameGroupBy.progress_apply = tqdm_pandas(
            DataFrameGroupBy.progress_apply)
    except:
        print("pandas is too old (<0.18) or missing!")
        return

    with tqdm_pandas(total=10) as pbar:
        df = DataFrame({'col_1': range(10), 'col_2': range(10, 20)})
        df.groupby('col_1').progress_apply(lambda x: x)  # noqa
    assert pbar.n == 10


# Generated at 2022-06-12 14:22:10.694414
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    import pandas as pd

    df = pd.DataFrame({'foo': range(100),  # bar is just ignored
                       'bar': ['apple'] * 100})
    with trange(100) as t:
        # should return a bar in each loop
        for i in tqdm_pandas(t, total=df.shape[0]):
            df.progress_apply(lambda x: i, axis=1)


# Register `tqdm_pandas` with `DataFrame.progress_apply`
import pandas as pd
pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas

# Generated at 2022-06-12 14:22:16.657987
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    df = pd.DataFrame(np.arange(100), columns=['a'])
    result = df.groupby('a').progress_apply(lambda x: x ** 2)
    assert np.all(result.values == df.values ** 2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:27.389939
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    import numpy as np
    import pandas as pd
    df = pd.DataFrame({'x': np.random.random(10000),
                       'y': ['a', 'b', 'c'] * 3300})

    with captured_output() as (out, _):
        tqdm_pandas(tqdm(leave=False, position=0))
        w = df.groupby('y').progress_apply(lambda x: x)
        assert '#' in out.getvalue()


if __name__ == '__main__':
    from .tests import common_main
    common_main(__file__, globals(), verbose=True, no_coverage=True)

# Generated at 2022-06-12 14:22:31.955869
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Test tqdm_pandas with deprecated input """
    import tqdm
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest("pandas is not available")
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm.tqdm)



# Generated at 2022-06-12 14:22:37.838211
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'Col1': [1, 2, 3],
                       'Col2': [4, 5, 6]})
    grp = df.groupby(['Col1'])
    tqdm_pandas(tqdm)
    with tqdm.tqdm() as t:
        for k, df in grp:
            df = df + 1  # Apply some operation
            t.update(len(df))


if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-12 14:22:46.711468
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    def my_func(x):
        return x * 2

    df = pd.DataFrame({'a': [1, 1, 2, 3, 4, 4, 4]})

    with closing(StringIO()) as our_file:
        with tqdm_pandas(our_file, leave=False,
                         total=len(df.groupby('a'))) as t:
            df.groupby('a').progress_apply(my_func, meta=('b', int),
                                           tqdm=t)

        our_file = our_file.getvalue()

    assert 'b' in our_file, "Column 'b' not found in progress bar string!"

# Generated at 2022-06-12 14:22:52.163851
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    a = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
    tqdm_pandas(tqdm.tqdm, a.groupby('a').progress_apply(sum))

# Generated at 2022-06-12 14:23:01.072148
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({'a': np.random.randint(0, 100, 1000000),
                       'b': np.random.randint(0, 100, 1000000)})

    # Registers `tqdm.DataFrameGroupBy` instead of `tqdm.tqdm`
    tqdm_pandas(tqdm())
    assert 'progress_apply' in dir(df.groupby('a'))

    # Registers `tqdm.pandas`
    tqdm_pandas(tqdm)
    assert 'progress_apply' in dir(df.groupby('a'))


if __name__ == '__main__':
    import pytest

# Generated at 2022-06-12 14:23:22.417322
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    tqdm_pandas(tqdm)
    n_rows = 10
    df = pd.DataFrame({
        'aa1': np.random.rand(n_rows),
        'ab1': np.random.rand(n_rows)
    })
    for _ in df.progress_apply(lambda x: x):
        pass

# Test whether tqdm.pandas works

# Generated at 2022-06-12 14:23:30.374899
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    from pandas import DataFrame
    from tqdm import tqdm_notebook
    import pandas
    import numpy

    df = pandas.DataFrame({'col': numpy.random.randn(10000)})

    with tqdm_notebook(total=df.shape[0]) as pbar:

        def f(x):
            pbar.update()
            return x**2

        df = df.groupby('col').apply(f)
        tqdm_pandas(tqdm_notebook)
        df = df.groupby('col').progress_apply(f)

        tqdm_pandas(tqdm_notebook(total=df.shape[0]))
        df = df.groupby('col').progress

# Generated at 2022-06-12 14:23:38.847055
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    from tqdm import tqdm
    from pandas import DataFrame
    try:
        df = DataFrame({
            'col': range(10),
        })
        gb = df.groupby('col')
        gb.progress_apply(lambda x: x)
    except AttributeError:
        # that's fine, just check that it works
        tqdm_pandas(tqdm())
        gb = df.groupby('col')
        gb.progress_apply(lambda x: x)
    print('> tqdm_pandas succeeded')

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:42.016160
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        pd.DataFrame([range(10)]).groupby(0).progress_apply(lambda x: x)
    except (ImportError, TypeError):
        print('SKIP: pandas not installed')


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:52.528148
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import pandas.core.groupby as pdg
    from tqdm._utils import _range

    def foo(a):
        return a

    pdg.DataFrameGroupBy.progress_apply = tqdm_pandas(tqdm.tqdm_notebook)
    pdg.DataFrameGroupBy.progress_apply(
        foo, pd.DataFrame([[1], [2], [3]]), _range(3))
    tqdm_pandas(tqdm.tqdm_notebook, file=sys.stderr)
    pdg.DataFrameGroupBy.progress_apply(
        foo, pd.DataFrame([[1], [2], [3]]), _range(3))
    tqdm_p

# Generated at 2022-06-12 14:24:00.207353
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    import pandas as pd
    import numpy as np
    tqdm_pandas(tqdm)
    assert pd.DataFrame(np.arange(10)).progress_apply(lambda x: x + 1).equals(
        pd.DataFrame(np.arange(10) + 1))
    tqdm_pandas(tqdm)
    assert pd.DataFrame(np.arange(10)).progress_apply(lambda x: x + 1).equals(
        pd.DataFrame(np.arange(10) + 1))


# Generated at 2022-06-12 14:24:06.377605
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tnrange
    df = pd.DataFrame({'x': (1, 2, 3, 4, 5)})
    df.groupby(lambda x: x).progress_apply(lambda _: _ + 1)
    with tnrange(1) as t:
        df.groupby(lambda x: x).progress_apply(lambda _: t.set_postfix(x=_))

# Generated at 2022-06-12 14:24:12.565980
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import time
    import pandas as pd
    import numpy as np

    # generate random dataframe
    tbl = pd.DataFrame({'product': np.random.choice(['a', 'b'], 100000),
                        'value': np.random.random(100000)})

    # classic way to compute
    tic = time.time()
    count = 0
    for product in tbl['product'].unique():
        count += tbl.loc[tbl['product'] == product, 'value'].sum()
    print(time.time() - tic)

    # use tqdm in pandas
    tic = time.time()
    count2 = tbl.groupby('product').progress_apply(
        lambda x: x['value'].sum())
    print(time.time() - tic)

# Generated at 2022-06-12 14:24:14.950062
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Dummy values
    total = 100
    tqdm_pandas(total)


# Generated at 2022-06-12 14:24:25.973044
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm

    try:
        import pandas  # noqa
    except ImportError:
        raise unittest.SkipTest("Skipping Pandas-specific tests")

    test_df = DataFrame({'A': Series([1, 2, 3, 4, 5]),
                         'B': Series([6, 7, 8, 9, 10]),
                         'C': Series([2, 4, 6, 8, 10])})

    # Check adaptor
    tqdm.pandas(unit_scale=True, total=test_df.shape[0], unit='row')
    assert (test_df.progress_apply(lambda x: x * x) == test_df ** 2).all().all()


# Generated at 2022-06-12 14:24:47.566657
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        import pandas
        frame = pandas.DataFrame({'a': list('abc' * 100), 'b': list('ab' * 300)})
        tqdm_pandas(tqdm(total=len(frame)))
        frame.groupby('a').progress_apply(len)
    except Exception as e:
        raise ValueError("tqdm_pandas() unit test failed\n{}".format(e))
    print("tqdm_pandas() unit test passed successfully")

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:53.203783
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas as tp
    from pandas import DataFrame

    df = DataFrame({'a': range(100)})
    for t in [tp, tqdm_pandas]:
        t("{desc}", total=len(df))
        df.progress_apply(lambda x: x, axis=1)
        assert df.groupby("a").progress_apply(lambda x: x, axis=1) is not None

# Generated at 2022-06-12 14:25:02.203736
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    df = pd.DataFrame(dict(a=np.random.randint(0, 100, 100),
                           b=np.random.randint(0, 100, 100)))

    # Sum of elements in each group
    df.groupby('a').progress_apply(lambda x: x.sum())

    # Multi-column grouping
    df.groupby(['a', 'b']).progress_apply(lambda x: x.sum())

    # Count number of elements in each group
    df.groupby('a').progress_apply(lambda x: len(x))

    # Call tqdm without arguments
    tqdm_pandas(tqdm())

    # Call tqdm with arguments

# Generated at 2022-06-12 14:25:06.998207
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.contrib.concurrent import process_map
    from tqdm import tqdm

    df = pd.DataFrame({"a": [1, 2, 3, 4]})
    tqdm_pandas(tqdm(), leave=True)(process_map)(lambda x: x**2, df["a"].values)

# Generated at 2022-06-12 14:25:11.650351
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    t = tqdm_pandas(tqdm, file=open(os.devnull, 'w'))
    assert (t._miniters == 1)
    t = tqdm_pandas(tqdm, file=open(os.devnull, 'w'), mininterval=0.5)
    assert (t._mininterval == 0.5)



# Generated at 2022-06-12 14:25:21.733097
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange
    from tqdm import tqdm_pandas
    from tqdm.contrib import DummyTqdmFile
    from tqdm.contrib import pandas
    from tqdm._tqdm import TqdmDeprecationWarning

    tclass1 = tqdm_pandas(tqdm(tclass=pandas))
    tclass2 = tqdm_pandas(tqdm(tclass=pandas))
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        assert len(w) == 2
        assert not any([bool(w1.filename) for w1 in w])

# Generated at 2022-06-12 14:25:29.159918
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    tqdm(pandas=True)
    tqdm(df.progress_apply, pandas='groupby')
    tqdm.pandas(df.progress_apply)
    tqdm(df.progress_apply)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(pandas=True))
    tqdm_pandas(tqdm(df.progress_apply, pandas='groupby'))
    tqdm_pandas(tqdm.pandas(df.progress_apply))
    tqdm_pandas(tqdm(df.progress_apply))

# Generated at 2022-06-12 14:25:38.219009
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    with tqdm(total=102, desc="Register") as t:
        t.update(1)
        try:
            tqdm_pandas(t)
        except (AttributeError, ImportError):
            msg = "pandas is required to register `tqdm` with `DataFrameGroupBy`."
            raise ImportError(msg)
    t.update(1)
    t.close()

    pd.DataFrame(
        {"i": [1] * 20 + [2] * 50 + [3] * 32}).groupby("i").progress_apply(lambda x: x)
    t.close()

    # Test ignoring non-TQDM classes
    class NotTQDMClass(object):
        pass
    NotTQDM

# Generated at 2022-06-12 14:25:44.102095
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .gui import tqdm

    try:
        import pandas
    except ImportError:
        from nose.plugins.skip import SkipTest
        raise SkipTest("pandas is not installed")

    df = pandas.DataFrame({"x": range(100)})

    with tqdm(total=len(df)) as t:
        df.groupby("x").progress_apply(lambda x: t.update())

# Generated at 2022-06-12 14:25:52.837169
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:  # pragma: no cover
        import pandas  # noqa: F401
    except ImportError:  # pragma: no cover
        return
    import numpy as np
    a = np.random.randint(0, 100, (10000,))
    a[0] = -1
    import pandas as pd
    df = pd.DataFrame(a, columns=['a'])
    df = df.groupby('a').progress_apply(lambda x: square(x).sum())
    assert isinstance(df, pd.DataFrame)


if __name__ == "__main__":
    test_tqdm_pandas()