

# Generated at 2022-06-12 14:16:31.296260
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    df = pandas.DataFrame({'x': range(1, 100), 'y': range(1, 100)})

    def func(x):
        return x

    # Check argument dependent case
    tqdm_pandas(tqdm.tqdm(**{}))
    tqdm_pandas(tqdm.tqdm(total=100))
    tqdm_pandas(tqdm.tqdm(total=100, unit="px"))

    # Check argument independent case
    tqdm_pandas(tclass=tqdm.tqdm)
    tqdm_pandas(tclass=tqdm.tqdm, total=100)

# Generated at 2022-06-12 14:16:38.658013
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        raise RuntimeError()
    except Exception:
        dummy_except = sys.exc_info()
    try:
        tqdm_pandas(tqdm)  # test deprecation warning
    except Exception as e:  # pragma: no cover
        print("deprecation warning test failed", file=sys.stderr)
        raise dummy_except
    try:
        tqdm_pandas(tqdm(**tqdm_kwargs))  # test deprecation warning
    except Exception as e:  # pragma: no cover
        print("deprecation warning test failed", file=sys.stderr)
        raise dummy_except

# Generated at 2022-06-12 14:16:40.225408
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm_pandas(pandas.util.testing.makeTimeDataFrame()) as progress_bar:
        progress_bar.progress_apply(lambda x: x*x)

# Generated at 2022-06-12 14:16:48.898149
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.auto import trange
    from tqdm.contrib import pandas
    import pandas as pd
    # test w/ single tqdm instance
    tqdm(total=10, file=sys.stderr)
    try:
        pd.DataFrame([1, 2, 3]).progress_apply(lambda i: i ** 2)
    except Exception as e:
        print(e)
        raise
    # test w/ simple class
    class T:
        @classmethod
        def pandas(cls, deprecated_t):
            assert isinstance(deprecated_t, tqdm)
            assert deprecated_t.disable
            assert deprecated_t.total == 10
            assert deprecated_t.fp is sys.stderr
            raise Exception


# Generated at 2022-06-12 14:16:56.601294
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import sys
    import tqdm
    with tqdm.tqdm(total=1000) as t:
        tclass = tqdm_pandas(t)
        assert getattr(tclass, '__name__', '').startswith('tqdm_')
        df = pandas.DataFrame({
            'a': [1, 2, 3, 4, 5, 6, 7, 8],
            'b': [4, 5, 6, 3, 2, 1, 0, 0]
        })
        df.groupby('a').progress_apply(lambda x: x**2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:04.317335
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    from tqdm import tqdm

    tqdm_pandas(tqdm(0))
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm_notebook())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:11.316515
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(ascii=True))
    tqdm_pandas(tqdm(file=BytesIO()))


# Registers our bar with pandas using register_tqdm()
import pandas as _pandas
_pandas.core.groupby.DataFrameGroupBy.progress_apply = getattr(
    tqdm, '__version__', '4.42.1')[:5] <= '4.42'  # Backward compatibility for pandas 0.25
register_tqdm(_pandas.core.groupby.DataFrameGroupBy)
__pandas_version__ = _pandas.__version__

# Generated at 2022-06-12 14:17:18.946040
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Uninitialized
    try:
        tqdm_pandas(None)
    except Exception as e:
        assert isinstance(e, TypeError)
        assert "tqdm_pandas() missing 1 required positional argument" in str(e)

    # Non-tqdm instance
    try:
        tqdm_pandas(range(10))
    except Exception as e:
        assert isinstance(e, TypeError)
        assert "tqdm_pandas(): tqdm (or tqdm-like) instance expected" in str(e)


if __name__ == '__main__':  # Test
    from .main import tqdm  # NOQA: F401
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:26.927190
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm
    except ImportError:
        return
    tqdm.pandas()
    tqdm.pandas(smoothing=0)
    tqdm.pandas(bar_format='{l_bar}{bar}{r_bar}')
    tqdm.pandas(total=1)
    tqdm.pandas(ascii=True)
    tqdm.pandas(unit='test')
    tqdm.pandas(leave=True)
    tqdm.pandas(desc='test')
    tqdm.pandas(dynamic_ncols=True)
    tqdm.pandas(miniters=1)
    tqdm.pandas(mininterval=0)

# Generated at 2022-06-12 14:17:31.092251
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # create tqdm instance
    import pandas as pd
    import numpy as np

    pd.DataFrame(np.random.rand(100, 100)).groupby(0).progress_apply(lambda x: x)
    pd.Series(np.random.rand(100)).progress_apply(lambda x: x)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:42.823222
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from tqdm.contrib import DummyTqdmFile

    # Test actual progress
    df = DataFrame({'x': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]})
    with tqdm(total=df.shape[0]) as t:
        tqdm_pandas(t, leave=False)
        df.groupby('x').progress_apply(lambda x: x)
        assert t.n == df.shape[0]

    # Test that progress_apply() still works with a progressbar
    # that doesn't actually output to the file descriptor
    df = DataFrame({'x': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]})

# Generated at 2022-06-12 14:17:53.204695
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    from tqdm.auto import trange, tqdm
    from pandas.testing import assert_frame_equal
    import numpy as np

    dummy_progress_apply = pd.DataFrame.progress_apply


# Generated at 2022-06-12 14:17:57.295774
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time

    # Add progress bar to the pandas df.progress_apply
    df = pd.DataFrame({'x': np.random.randint(0, 1000, 10000)})
    df.progress_apply(time.sleep)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:04.693438
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    import numpy as np
    from os import devnull
    with open(devnull, 'w') as fp:
        tqdm(fp=fp, desc='testing tqdm_pandas()').pandas(DataFrame(
            np.random.rand(100, 100)))

# pandas integration
try:
    from pandas import DataFrame
except ImportError:
    pass
else:
    DataFrame.progress_apply = tqdm_pandas(DataFrame.progress_apply)

# Generated at 2022-06-12 14:18:08.034826
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # cmd line testing
    if sys.argv[-1] == __file__:
        tqdm_pandas(tqdm())
        tqdm_pandas(tqdm(ncols=60))
        tqdm_pandas(tqdm(total=1729))

# Generated at 2022-06-12 14:18:18.876875
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    M, N = 1000, 100
    test_df = pd.DataFrame({
        'int': pd.Series(np.random.randint(0, 10, size=M)),
        'float': pd.Series(np.random.uniform(size=M)),
        'str': pd.Series([str(i) for i in range(M)]),
    })
    with tqdm.tqdm(total=N) as pbar:
        pbar.update(1)
        test_df.groupby('int').progress_apply(pbar.update, **{'n': 1})

# Generated at 2022-06-12 14:18:26.929364
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import arange
    from time import time

    tqdm_pandas(tqdm)

    test_df = DataFrame(arange(50000), columns=['test'])

    # Test that tqdm works with pandas.core.groupby.DataFrameGroupBy.progress_apply
    test_df.groupby(test_df['test']).progress_apply(lambda x: time())

    # Test that tqdm works with pandas.core.frame.DataFrame.progress_apply
    test_df.progress_apply(lambda x: time(), axis=1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:33.903329
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    try:
        df = pandas.DataFrame(dict(A=pandas.np.arange(1000)))
        t = tqdm(total=len(df))
        tqdm_pandas(t, desc='Pandas')
        assert hasattr(df.groupby('A'), 'progress_apply')
        assert df.groupby('A').progress_apply(lambda x: x) is None
    except:
        pass

# Generated at 2022-06-12 14:18:39.631977
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    import tqdm
    # tqdm_pandas should serve as a drop-in replacement for being imported as
    # tqdm_pandas (since v4.26.0):
    import tqdm_pandas
    from tqdm import TqdmDeprecationWarning
    df = pandas.DataFrame({
        'a': list(map(str, range(20))),                                 # category
        'b': numpy.random.randint(0, 20, size=20),                      # int
        'c': numpy.random.normal(size=20),                              # float
        'd': numpy.random.choice(list('abcdefghijklmnopqrstuvwxyz'), 20),  # object
    })

    # Test `'total'

# Generated at 2022-06-12 14:18:48.293368
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    tqdm_kwargs = {
        'leave': True,
        'mininterval': 0.01,
        'smoothing': 0.1,
    }

    df = pd.DataFrame({
        'A': np.random.randn(100),
        'B': np.random.randn(100),
        'C': np.random.randn(100),
    })

    tqdm_pandas(tclass=tqdm, **tqdm_kwargs)
    df.groupby('C').progress_apply(lambda x: np.sum(x))

# Generated at 2022-06-12 14:18:58.929724
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame(np.random.rand(1000, 1))
    df = tqdm.tqdm.pandas(df, total=len(df), miniters=len(df), unit_scale=True)
    assert 'tqdm' in repr(df.progress_apply)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:08.510762
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import numpy as np
    import pandas as pd
    from tqdm.auto import tqdm
    from tqdm import TqdmDeprecationWarning

    # Create a pandas dataframe
    df = pd.DataFrame({'x': np.random.random(10000)})
    df.to_parquet('test.parq')

    # Register the instance "t" with the pandas DataFrameGroupBy
    t = tqdm(total=1033)
    tqdm_pandas(t)

    # Test reading of file with parquet
    df = pd.read_parquet('test.parq')
    df.groupby('x').progress_apply(lambda x: x**2)

    # Test if no warning is thrown for "

# Generated at 2022-06-12 14:19:17.377498
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from .std import tqdm

    # Test case 1: test with the deprecated usage
    tclass = tqdm(range(100), ascii=True, miniters=1)
    try:
        tqdm_pandas(tclass)
    except tqdm.TqdmDeprecationWarning:
        pass
    # Test case 2: test using the new usage
    tqdm_pandas(tqdm)
    # Test case 3: test using the new delayed usage
    tqdm_pandas(type(tqdm))

    return

# Generated at 2022-06-12 14:19:25.045218
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)

        t = tqdm()
        tqdm_pandas(t)
        t.pandas()
        t = tqdm(total=10)
        tqdm_pandas(t)
        assert t.total == 10
        t = tqdm(total=10, file=open('_', 'wb'))
        tqdm_pandas(t)
        assert t.file.name == '_'

# Generated at 2022-06-12 14:19:32.053574
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    # Create the dataframe.
    df = pd.DataFrame(index=range(10), columns=['A', 'B'])

    df['A'] = np.random.rand(10)
    df['B'] = np.random.rand(10)

    # Test with tqdm.pandas.
    tqdm_pandas(tqdm)

    # Test with a normal `tqdm` instance
    for row in tqdm_pandas(df.progress_apply(lambda x: x)):
        pass


# Alias for backwards compatibility
tqdm_gui = tqdm

# Generated at 2022-06-12 14:19:42.625147
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import random
    import string

    # Example taken from pandas DataFrameGroupBy
    df = pd.DataFrame({'A': list('aabbcdcdddd'),
                       'B': [random.randint(1, 9) for _ in range(11)],
                       'C': [random.choice(string.ascii_letters) for _ in range(11)]})
    grp = df.groupby(['A'])['B']

    def f(group):
        # some heavy operation
        return group.sum()

    # before applying tqdm_pandas
    print("No tqdm_pandas:")

# Generated at 2022-06-12 14:19:54.546315
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame(data=[1, 2, 3], index=[1, 2, 3])

    def add_to_df(x):
        return x+100

    print(df.groupby(0).progress_apply(add_to_df))
    tqdm_pandas(tqdm, df.groupby(0).progress_apply(add_to_df))
    tqdm_pandas(tqdm(df.groupby(0).progress_apply(add_to_df)))
    tqdm_pandas(tqdm.pandas(df.groupby(0).progress_apply(add_to_df)))

# Generated at 2022-06-12 14:20:04.659139
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    n = 1e2
    tqdm_pandas(tqdm(total=n))  # test __name__
    tqdm_pandas(tqdm.tqdm(total=n))  # test __name__
    tqdm_pandas(tqdm(total=n))
    tqdm_pandas(tqdm.tqdm(total=n))
    tqdm_pandas(tqdm.tqdm(total=n), desc='test')
    tqdm_pandas(tqdm.tqdm(total=n), miniters=1)
    tqdm_pandas(tqdm.tqdm(total=n), mininterval=0)


# Generated at 2022-06-12 14:20:09.668606
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.rand(100000, 100))
    with tqdm(total=len(df)) as pbar:
        # Register `pbar` with `pandas`
        tqdm_pandas(pbar)
        # Now you can use `progress_apply` instead of `apply`
        # and `pbar` will get updated automatically.
        df.progress_apply(lambda x: x**2)

# Generated at 2022-06-12 14:20:20.132034
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    actual = DataFrame({'x': range(10), 'y': range(10)})
    expected = dict([(i, f'x{i}y{i}') for i in range(10)])

    def test_fn(x):
        return str(x.x) + 'x' + str(x.y)

    res = actual.groupby('x').progress_apply(test_fn)
    actual = dict(zip(res.index, res))
    # print(actual)
    assert actual == expected

    res = actual.groupby('x').progress_apply(test_fn, desc='silly')
    actual = dict(zip(res.index, res))
    assert actual == expected


# Generated at 2022-06-12 14:20:32.293752
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.rand(1000, 200))
    with tqdm(total=len(df)) as pbar:
        def f(x):
            pbar.update()
        df.progress_apply(f)

# Generated at 2022-06-12 14:20:41.323391
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import pandas as pd

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)),
                      columns=list('ABCDEF'))

    # Register `tqdm` to the `progress_apply` method of DataFrame
    tqdm_pandas(tqdm(ascii=True))

    # Now you can use `progress_apply` instead of `apply`
    df.groupby(0).progress_apply(lambda x: x**2)
    df.groupby(0).progress_apply(lambda x: x**2, axis=1)

# Generated at 2022-06-12 14:20:42.399675
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

# Generated at 2022-06-12 14:20:49.293459
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas()"""
    import pandas as pd
    from tqdm import tqdm, trange

    df = pd.DataFrame({'x': range(10)})
    df.groupby('x').progress_apply(lambda x: x)

    tqdm_pandas(trange(3), desc='desc', ncols=64)
    tqdm_pandas(tqdm(range(3), desc='desc', ncols=64))

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:00.006099
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas

    tqdm_pandas(tqdm)

    def test_fn(x):
        import time
        import numpy as np
        time.sleep(np.random.rand() / 100)
        return x * 2

    df = pd.DataFrame({'x': range(100)})
    df = df.groupby('x').progress_apply(test_fn)
    assert set(df.values.ravel()) == set(range(0, 200, 2))

    # test unit-test function
    import unittest

    class TestTqdmPandas(unittest.TestCase):
        def test(self):
            test_tqdm_pandas()

    unittest.main()




# Generated at 2022-06-12 14:21:07.116142
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.rand(100, 10), columns=list('ABCDEFGHIJ'))
    tqdm.pandas(desc='Pandas apply:')
    print(df.groupby('A').progress_apply(lambda x: np.random.randint(20)))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:13.814688
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas
    from tqdm import tqdm
    tqdm_pandas(tqdm())
    pandas.core.groupby.DataFrameGroupBy.progress_apply = \
        tqdm_pandas(tqdm()).progress_apply


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:20.382115
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # noinspection PyShadowingNames
    def f(x):
        return x

    # noinspection PyUnresolvedReferences
    import pandas as pd
    import tqdm

    # Initialise a Series with tqdm progress bar
    Series = pd.Series(range(100)).progress_apply(f)

    # Check that the `Series` returned is a `tqdm.tqdm` instance
    assert isinstance(Series, tqdm.tqdm)

# Generated at 2022-06-12 14:21:23.637675
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    df = pd.DataFrame(dict(zip(range(3), [range(x) for x in range(3, 6)])))
    assert df.groupby(0).progress_apply(sum) is True

# Generated at 2022-06-12 14:21:29.234969
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    df = pandas.DataFrame({'a': [1, 2, 3, 4, 5]})
    from tqdm import tqdm
    try:
        tqdm_pandas(tqdm)
        df.groupby('a').progress_apply(lambda x: None)
    except AttributeError as err:
        assert False, "Failed tqdm_pandas function test: {}".format(err)

# Generated at 2022-06-12 14:21:38.601995
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
    df.groupby(['a']).progress_apply(lambda x: x**2)


if __name__ == '__main__':
   test_tqdm_pandas()

# Generated at 2022-06-12 14:21:47.621672
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from tqdm.autonotebook import tqdm as tqdm_notebook

    with closing(StringIO()) as our_file:
        with closing(StringIO()) as their_file:
            for tclass in [tqdm_notebook, trange]:
                # dummy dataset
                df = pd.DataFrame(dict(A=tuple(range(100))))
                # test with instance and class
                for tqdm in [tclass, type(tclass)]:
                    # test with file, filepath and str
                    for fp in [our_file, their_file, our_file.name]:
                        tqdm_pandas(tqdm, file=fp)
                        pd.DataFrame().groupby([]).progress_apply(lambda x: None)

# Generated at 2022-06-12 14:21:56.932792
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""

    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm

    print("\nTesting tqdm_pandas .. ", end="")

    # Create a demo DataFrame with columns 'A' and 'B'
    df = pd.DataFrame({'A': np.ones((1024)), 'B': np.arange(1024)})

    # Perform a function on the column 'A' with tqdm
    df1 = df.groupby(['A']).progress_apply(lambda x: x + 1)

    # Check if the columns are equal
    assert np.array_equal(np.asarray(df1['A']), np.asarray(df['A'] + 1))

    # Perform a function on the column

# Generated at 2022-06-12 14:22:03.482686
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    $ python3 -m tqdm.tests.tqdm_pandas
    """
    from tqdm.autonotebook import tqdm
    t = tqdm(total=100)
    t.interact()  # start tqdm

    try:
        from pandas import DataFrame
    except ImportError:
        raise unittest.SkipTest("pandas not found")
    else:
        tqdm_pandas(t, ascii=True)

        # Simplest possible case
        try:
            t.pandas(metric='items')
        except:
            sys.stderr.write('Error: "Items" metric failed\n')

        # Numerical statistic case

# Generated at 2022-06-12 14:22:07.888436
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.random((1000, 3)), columns=['A', 'B', 'C'])

    with tqdm_pandas(total=len(df)) as pbar:
        def square(x):
            pbar.update()
            return x ** 2

        df = df.groupby(['A', 'B']).progress_apply(square)

# Generated at 2022-06-12 14:22:16.832166
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    from tqdm import tnrange
    import pandas as pd

    data = {'a': [1,2,3], 'b': [2,3,4], 'c': [3,4,5]}
    df = pd.DataFrame(data)
    grp = df.groupby('a')
    grp.progress_apply(lambda x: 1)

    df = pd.DataFrame(data)
    grp = df.groupby('a')
    tqdm_pandas(tqdm(grp))
    grp.progress_apply(lambda x: 1)

# Generated at 2022-06-12 14:22:28.218606
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    import time

    def f(x):
        time.sleep(0.1)
        return x + 1

    def f2(x):
        time.sleep(0.1)

    pd.set_option('mode.chained_assignment', None)
    d = pd.DataFrame({"a": np.arange(0, 5), "b": ["x"] * 5, "c": np.random.random(5)})

    # test for `.progress_apply`

# Generated at 2022-06-12 14:22:33.133435
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas

    df = pd.DataFrame(np.random.random((1000, 3)))
    tqdm_pandas(df)
    tqdm_pandas(df.groupby(df.sum()))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:44.636583
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    np.random.seed(0)  # ensure reproducibility
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    pd.options.display.width = 1000
    pd.options.display.precision = 5
    pd.options.display.max_rows = 10
    if __name__ == '__main__':
        from tqdm import tqdm, tqdm_notebook
        try:
            from IPython import get_ipython
            ipython = get_ipython()
        except ImportError:
            ipython = None
        if ipython and getattr(ipython, '__class__', None).__name__ == 'ZMQInteractiveShell':
            tqdm_pand

# Generated at 2022-06-12 14:22:54.164203
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm as tqdm_base
    from tqdm import tnrange as tqdm_range

    df = pd.DataFrame({'a': [3, 2, 1]})
    try:
        tclass = tqdm_range(5)
        tqdm_pandas(tclass)
        df.groupby('a').progress_apply(lambda x: len(x))
    except ImportError as e:
        print("\nFailure: {}".format(e))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:15.218726
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        pass
    else:
        from tqdm import tqdm

        df = pd.DataFrame(np.random.randn(10, 2))
        if hasattr(tqdm, 'pandas'):
            # Only test subsequent pandas calls
            tqdm_pandas(tqdm(total=10))

            df.groupby(df.columns.tolist(), as_index=False, sort=False).progress_apply(
                pd.Series.nunique)


# Generated at 2022-06-12 14:23:25.371253
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    from tqdm import tqdm_pandas

    with tqdm.tests.nested(
            tqdm([1, 2], desc='0%'), tqdm(1, desc='50%'), tqdm(0, desc='100%',
                                                              leave=False)) as (
            t1, t2, t3):
        # Type I: `tqdm_pandas(tqdm)`
        tqdm_pandas(tqdm)

        t1.display()
        assert pd.Series([1, 2]).progress_apply(tqdm.write, meta='1/2') == [1, 2]
        t2.display()

# Generated at 2022-06-12 14:23:30.465991
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        from pandas import DataFrame
        from pandas.util.testing import rands
    except ImportError:
        return
    from tqdm import tqdm

    tqdm.pandas(desc="test")
    df = DataFrame({'a': [rands(4) for _ in range(100)]})
    for char in df.groupby('a').progress_apply(len):
        pass


if __name__ == '__main__':  # run tests
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:35.920929
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm
    tqdm.pandas(smoothing=0.5)
    df = pandas.DataFrame([dict(a=[1, 2, 3], b=[4, 5, 6])])
    g = df.groupby('a').ProgressBar()
    g.apply(pandas.DataFrame.mean)
    tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:23:41.913819
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    df = pd.DataFrame({'X': [1, 2, 3, 4],
                       'Y': [5, 6, 7, 8],
                       'Z': [9, 10, 11, 12]})

    def func(df):
        return df.sum()

    # Be careful not to use tqdm.pandas(...) here due to lazy loading,
    # which should not be tested by function tqdm_pandas.
    tqdm_pandas(tqdm())
    assert (df.progress_apply(func) == df.apply(func)).all()

    # Test deprecated version
    from tqdm import TqdmDeprecationWarning
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm())



# Generated at 2022-06-12 14:23:52.427682
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:24:01.726886
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas.
    """
    import pandas as pd

    n = 100
    df = pd.DataFrame({'a': range(n), 'b': range(n)})

    # Test class instance
    with tqdm_pandas(total=df.groupby('a').ngroups) as t:
        df.groupby('a').progress_apply(lambda x: x)
    assert t.n == df.groupby('a').ngroups
    t.close()
    # Test class decorator
    @tqdm_pandas
    def pro(x):
        return x
    with pro(total=df.groupby('a').ngroups) as t:
        df.groupby('a').progress_apply(lambda x: x)
    assert t

# Generated at 2022-06-12 14:24:09.478780
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm_pandas(tqdm()) as t:
        assert t.__class__.__name__.startswith('tqdm_')

    with tqdm_pandas(tqdm()) as t:
        assert t.__class__.__name__.startswith('tqdm_')

    with tqdm_pandas(tqdm) as t:
        assert t.__class__.__name__.startswith('tqdm_')


if __name__ == "__main__":
    import pytest
    # pytest.main([__file__])
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:12.203502
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.contrib.tests import solitude, pandas_tests
    tqdm_pandas(tqdm)
    assert solitude(pandas_tests)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:24.032808
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # must not raise exception
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_notebook())
    # must not raise exception
    tqdm_pandas(tqdm(total=1))
    tqdm_pandas(tqdm_notebook(total=1))

    from tqdm import TqdmTypeError
    from tqdm import TqdmDeprecationWarning

    with pytest.raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm_gui())

    # must not raise exception
    with pytest.raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm_notebook(total=1))


# Generated at 2022-06-12 14:24:58.935486
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm

    df = DataFrame(Series(range(100)))
    tqdm_pandas(tqdm, leave=False)
    assert isinstance(df.groupby(df[0] % 5).progress_apply(lambda x: x).sum()[0], int)
    return


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:07.247537
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from glob import glob
    from pandas import DataFrame

    df = DataFrame([[i, i ** 2] for i in range(100)])
    list(df.groupby(1).progress_apply(lambda x: x))

    glob_l = glob(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'testtmp_*'))
    assert len(glob_l) > 0


if __name__ == '__main__':
    import os
    import shutil

    test_tqdm_pandas()
    for x in glob.glob('testtmp_*'):
        os.remove(x)

# Generated at 2022-06-12 14:25:15.018678
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    for _ in tqdm.tqdm_notebook(range(1000)):
        pass

    df = pd.DataFrame({
        'a': [1, 2, 3],
        'b': [1, 2, 3],
        'c': [1, 2, 3],
        'd': [1, 2, 3],
    })
    df.groupby(['d'])['b'].progress_apply(lambda x: sum(x))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:24.114289
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.auto import trange

    d = pd.DataFrame({'c1': [1, 2, 3, 4]})

    # Test kwargs using default tqdm
    with trange(100) as t:
        d.progress_apply(lambda x: x+1, axis=1, t=t)

    # Test adapter
    with tqdm(total=100, desc='tqdm_pandas') as t:
        tqdm_pandas(t, leave=False)
        d.progress_apply(lambda x: x+1, axis=1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:31.259102
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        import tqdm

        df = pd.DataFrame({'x': [1, 2, 3, 4],
                           'y': [5, 6, 7, 8]})
        df_tqdm = tqdm.tqdm(df)
        df_tqdm.progress_apply(lambda row: row['x'] + row['y'])
        tqdm.pandas(tqdm.tqdm)
    except ImportError:
        pass

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:40.919363
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas
    if 'IPython' in sys.modules:
        import pytest
        pytest.skip("skip testing tqdm_pandas if IPython is loaded")
    # Register `pandas.progress_apply` and `pandas.Series.map_apply` with `tqdm`
    tqdm.pandas()

    # Construct the data frame
    df = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=['a', 'b', 'c', 'd', 'e', 'f'])

# Generated at 2022-06-12 14:25:49.175884
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test of finding the max value in a number of groups
    """
    import pandas as pd
    import numpy as np
    import time
    import tqdm

    rand_func = lambda n: np.random.randn(n)
    df = pd.DataFrame({'group': np.random.choice(range(1000), 1000),
                       'data': [rand_func(1000) for _ in range(1000)]})
    progress = tqdm.tqdm_notebook(total=len(df.group.unique()))

    def _test(df, progress):

        def _test_inner(df, progress):
            df = df.copy()
    #         df = df.sample(frac=1).reset_index(drop=True)
            df['max_data'] = df['data'].progress

# Generated at 2022-06-12 14:25:56.220470
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'a': pd.Series(range(20)).apply(str)})
    with tqdm.tqdm(
            total=df.groupby('a').ngroups,
            desc='Progress',
            unit='group',
    ) as t:  # automatic unit and desc
        df.groupby('a').progress_apply(lambda g: t.update())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:26:05.809108
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm
    N = int(1e6)
    df = pd.DataFrame({'a': np.arange(N), 'b': np.random.randint(N, size=N),
                       'c': np.random.normal(size=N)})

    assert len(df) == N
    df_groupby_size = len(df.groupby('c'))
    assert max(df_groupby_size, N // df_groupby_size) < 1000

    # Test against tqdm
    tclass = tqdm(total=df_groupby_size)
    tqdm_pandas(tclass)

# Generated at 2022-06-12 14:26:14.776353
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm.pandas(desc="my bar!")
    df.groupby(0).progress_apply(lambda x: x ** 2)
    tqdm_pandas(tqdm, desc="hi!")
    df.groupby(0).progress_apply(lambda x: x ** 2)
    tqdm_pandas(tqdm(desc="hi!"))
    df.groupby(0).progress_apply(lambda x: x ** 2)


if __name__ == "__main__":
    test_tqdm_pandas()