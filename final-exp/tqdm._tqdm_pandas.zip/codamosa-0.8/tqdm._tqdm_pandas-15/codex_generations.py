

# Generated at 2022-06-12 14:16:32.483795
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    for fn in ['tqdm', 'trange', 'tqdm_notebook']:
        for x in [getattr(tqdm, fn)(), getattr(tqdm, fn)('hi', ascii=True,
                                                         miniters=2, mininterval=0)]:
            tqdm_pandas(x)
            x.set_description('hi')
            x.update(1)
            x.total = 5
            x.update(2)
            x.update()
            x.close()
            tqdm_pandas(type(x))
            x.set_description('hi')
            x.update(1)
            x.total = 5
            x.update(2)
            x.update()
            x.close()



# Generated at 2022-06-12 14:16:39.570622
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test the tqdm_pandas() function
    """
    from tqdm.auto import tqdm

    # Check fixing of deprecation
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, file=open('/dev/null', 'w'))
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm_notebook, file=open('/dev/null', 'w'))

    # Check no deprecation
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tqdm(total=10), file=open('/dev/null', 'w'))

# Generated at 2022-06-12 14:16:47.026694
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from tqdm.contrib import pandas
        pandas  # silence flake8
    except ImportError:
        try:
            from tqdm import pandas
            pandas  # silence flake8
        except ImportError:
            return

    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]], columns=list('ABC'))

    assert 'tqdm_pandas' not in df.groupby('A').apply.__name__

    tqdm_pandas(df.groupby('A').progress_apply)

    assert 'tqdm_pandas' in df.groupby('A').apply.__name__


# Generated at 2022-06-12 14:16:49.636397
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:16:54.884079
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib import pandas
    n = 100000
    df = pd.DataFrame(np.random.rand(n, n))
    tqdm_pandas(df.groupby('time').progress_apply(lambda x: x*x))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:03.917999
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from tqdm import tqdm

        for t in [tqdm, tqdm()]:
            with warnings.catch_warnings(record=True) as w:
                tqdm_pandas(t)
                assert isinstance(w[-1].message, TqdmDeprecationWarning)

    except ImportError:
        pass

    def tqdm_pandas_wrapper(tclass, **tqdm_kwargs):
        """
        Registers the given `tqdm` instance with
        `pandas.core.groupby.DataFrameGroupBy.progress_apply`.
        """
        type(tclass).pandas(deprecated_t=tclass)
    tqdm_pandas_wrapper(tqdm_pandas)



# Generated at 2022-06-12 14:17:09.346777
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import tqdm
    import pandas as pd

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
    df = df.groupby(['a', 'b']).progress_apply(lambda x: x)
    assert isinstance(df.progress_apply, type(tqdm.tqdm.pandas))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:18.000448
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas()"""
    try:  # python 3
        from unittest.mock import MagicMock
    except ImportError:
        from mock import Mock as MagicMock
    from pandas import DataFrame

    df = DataFrame({'a': [1, 2, 3], 'b': ['a', 'b', 'c']})
    mock_instance = MagicMock()
    mock_class = MagicMock()
    mock_class.return_value = mock_instance

    # check if lazy `tqdm.pandas()` is called as expected
    tqdm_pandas(mock_class)  # lazy initialization
    mock_class.assert_called_with()
    mock_instance.pandas.assert_called_with()
    mock_instance.reset_mock

# Generated at 2022-06-12 14:17:24.867694
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    df = pd.DataFrame(index=range(1024), columns=["dummy"])
    with tqdm(total=len(df), ascii=True) as pbar:
        for _ in df.progress_apply(lambda _: pbar.update()):
            pass
    with tqdm(total=len(df), ascii=True) as pbar:
        for _ in df.groupby(0).progress_apply(lambda _: pbar.update()):
            pass


if __name__ == '__main__':
    from tqdm import main
    main()

# Generated at 2022-06-12 14:17:31.023524
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame, Series

    df = DataFrame([[1, 2, 3], [4, 5, 6]], columns=['a', 'b', 'c'])
    tqdm.pandas()

    def f(x):
        return x + y

    y = 5
    # only works with progress_apply
    ret = df.groupby('a').progress_apply(f)
    assert (ret == df + y).all().all()

    # should work with any apply function
    def f(x):
        return 2 * x
    ret = df.progress_apply(f)
    assert (ret == df * 2).all().all()

    # also with series
    s = Series([1, 2, 3])

# Generated at 2022-06-12 14:17:42.695020
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from copy import deepcopy
    from pandas import DataFrame
    from pandas import read_csv
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    from tqdm._tqdm_pandas import _dataframe_apply
    from tqdm._tqdm_pandas import _series_apply
    from tqdm.auto import tqdm as tqdm_auto

    def func(x):
        return x + 1

    def func_raise(x):
        raise Exception

    def func_name(x):
        return x + type(x).__name__

    def func_deepcopy(x):
        return x + deepcopy(x)

    try:
        from pandas import read_csv_dask
    except ImportError:
        pass

# Generated at 2022-06-12 14:17:46.800447
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class tqdm_pandas_test():
        def pandas(self):
            pass

    tqdm_pandas(tqdm_pandas_test)
    try:
        tqdm_pandas(tqdm_pandas)
    except TypeError:
        pass

# Generated at 2022-06-12 14:17:54.193354
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with pytest.raises(tqdm.TqdmDeprecationWarning, match='Please use `tqdm.pandas'):
        # tqdm_pandas(tqdm)
        tqdm_pandas(tqdm.tqdm)
    with pytest.raises(tqdm.TqdmDeprecationWarning, match='Please use `tqdm.pandas'):
        # tqdm_pandas(tqdm())
        tqdm_pandas(tqdm.tqdm())



# Generated at 2022-06-12 14:18:04.014680
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    df=pd.DataFrame(np.random.randint(0,100,size=(100000, 1)))
    with tqdm(total=len(df)) as pbar:
        df.progress_apply(lambda x: pbar.update())
        assert pbar.n == len(df)
    with tqdm(total=len(df), file=sys.stdout) as pbar:
        df.progress_apply(lambda x: pbar.update())
        assert pbar.n == len(df)
    with tqdm(total=len(df), file=sys.stdout, disable=True) as pbar:
        df.progress_apply(lambda x: pbar.update())

# Generated at 2022-06-12 14:18:10.743010
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    from itertools import product as iprod

    def _prod(x):
        return np.prod(x)

    def _sum(x):
        return np.sum(x)

    tqdm_pandas(tqdm)

    for n in [1, 100]:
        for chunksize in [1, 9, 10, 11, 20, 100]:
            arbitrary_args = np.random.random(n)
            a_series = pd.Series(arbitrary_args)

            # Test a Series
            ans = a_series.progress_apply(_prod)
            assert ans == _prod(arbitrary_args)
            ans = a_series.progress_apply(_sum)

# Generated at 2022-06-12 14:18:18.527147
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd

        tqdm_pandas(tqdm, desc='Progress')

        # Test on a pandas DataFrame
        df = pd.DataFrame(columns=['a', 'b'])
        df['a'] = [1,2,3,4,5]
        df['b'] = [2,3,4,5,6]
        df.progress_apply(lambda x: x['a'] + x['b'])
    except ImportError:
        pass

# Generated at 2022-06-12 14:18:27.418169
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Make a test dataset
    import numpy as np
    from pandas import DataFrame

    def collection_function(data):
        np.random.shuffle(data)

    _data = np.zeros(100)
    df = DataFrame()
    df['A'] = np.random.randint(0, 100, size=100)
    df['B'] = np.random.randint(0, 100, size=100)

    # tqdm_pandas deprecated
    with warnings.catch_warnings(record=False) as w:
        warnings.simplefilter("always")
        tqdm_pandas(type('', (object,), {})())
    assert len(w) > 0

    # tqdm_pandas deprecated as a class

# Generated at 2022-06-12 14:18:31.858710
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm())


# Append the decorator
from tqdm._tqdm_pandas import tqdm_pandas as _tqdm_pandas

try:
    from pandas.core.groupby import DataFrameGroupBy
    DataFrameGroupBy.progress_apply = _tqdm_pandas
except ImportError:
    pass

# Generated at 2022-06-12 14:18:40.171294
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    from tqdm import tqdm_pandas
    from tqdm import tqdm
    from pandas import DataFrame

    df = DataFrame({'A': range(1000), 'B': range(1000)})
    for tcls in [tqdm_pandas, tqdm]:
        tcls(total=10).pandas()
        tcls().pandas()

    def apply_test(x):
        return 1.0

    with tqdm_pandas(total=len(df)) as pbar:
        df.progress_apply(apply_test, axis=1)
        pbar.update()

# Generated at 2022-06-12 14:18:48.291439
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def test_dfg_range(x):
        for _ in tqdm.pandas(range(x), desc='Inner loop'):
            pass
        return x

    df = pd.DataFrame({'col1': range(10), 'col2': range(10, 20)})

    try:
        df.groupby(['col1']).progress_apply(test_dfg_range)
    except AttributeError:
        pass
    except tqdm.TqdmKeyError:
        # pandas < 0.23
        pass



# Generated at 2022-06-12 14:19:01.086931
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm

    # TestPandasSeries
    test_pd_series = pd.Series(np.random.randint(low=0, high=10000000, size=10000000))
    tqdm_pandas(tqdm(total=len(test_pd_series), unit_scale=True, unit='rows'))
    test_pd_series.progress_apply(lambda x: x + 1)

    # TestPandasDataFrame
    test_pd_dataframe = pd.DataFrame(np.random.randint(low=0, high=10000000, size=(10000000, 1)))

# Generated at 2022-06-12 14:19:06.779574
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm)
        assert any("deprecated" in str(x.message) for x in w)
        tqdm_pandas(tqdm_notebook)
        assert any("deprecated" in str(x.message) for x in w)


# Tests
if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:08.465828
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm(total=10))

# Generated at 2022-06-12 14:19:16.484081
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_notebook
    try:
        from IPython.display import clear_output
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        return

    # Regression test for #xx
    df = pd.DataFrame({str(i): [str(i)] for i in range(3)})
    tqdm_pandas(tqdm_notebook(total=3))
    try:
        clear_output()
    except NameError:
        pass

# Generated at 2022-06-12 14:19:27.214391
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np
    import tqdm
    from tqdm.contrib import pandas as tqdm_pandas
    from tqdm._tqdm import tqdm_deprecate_attr

    try:  # older than pandas 0.18
        from pandas.compat import range
    except ImportError:  # pandas 0.18+
        from pandas.core.compat import range

    N = 100
    df = pandas.DataFrame(np.random.randint(0, 100, (N, 6)), columns=list('ABCDEF'))

    # try
    # >>> tqdm.pandas(desc="my bar!")
    # ... df.groupby(0).progress_apply(lambda x: x**2)
    # ...
    # my bar!:

# Generated at 2022-06-12 14:19:31.572268
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas, tqdm
    try:
        tqdm_pandas(tqdm(range(10)))
    except TypeError:
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:42.233836
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:19:53.772657
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        df = pd.DataFrame({'a': [1, 2, 4, 7, 11], 'b': [4, 5, 6, 9, 5]})
        def tqdm_pandas_test(a):
            return a+1
        target = {'a': [1, 2, 4, 7, 11], 'b': [5, 6, 7, 10, 6]}
        with tqdm_pandas(total=len(df)) as pbar:
            res = df.groupby('a').progress_apply(tqdm_pandas_test)
        assert res.equals(pd.DataFrame(target))
    except:
        pass

if __name__ == '__main__':
    multiprocessing.freeze_support()  # for

# Generated at 2022-06-12 14:20:00.546759
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.notebook import trange
    from pandas import DataFrame
    from random import uniform
    from time import sleep

    df = DataFrame(
        {
            'dummy_column1': [uniform(0, 1) for i in range(10)]
            , 'dummy_column2': [uniform(0, 1) for i in range(10)]
        })

    # Without the registration (default behaviour)
    progress_apply = df.progress_apply(lambda row: 2 * row['dummy_column1'] + row['dummy_column2'], axis=1)

    # With registration of trange as tqdm instance
    tqdm_pandas(trange)

# Generated at 2022-06-12 14:20:09.121205
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import pandas.core.groupby

    # Create a dummy pandas DataFrameGroupBy instance
    class DummyPandasDataFrameGroupBy(
            pandas.core.groupby.DataFrameGroupBy):
        pass

    DummyPandasDataFrameGroupBy.progress_apply = lambda self, func, *args, **kwargs: func(*args, **kwargs)

    dummy_data_frame = pandas.DataFrame(
        index=pandas.MultiIndex.from_product([list(range(2)), list(range(2))],
                                             names=('a', 'b')),
        data={'data': list(range(4))})
    dummy_data_frame_group_by = DummyPandasDataFrameGroupBy(
        dummy_data_frame, ['a'])

    # Test deprecated

# Generated at 2022-06-12 14:20:21.647589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import functools
    import pandas as pd
    from tqdm import tnrange

# Generated at 2022-06-12 14:20:29.642107
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm as tqdm_no_yield  # bypass yield from in case it's not supported

    for _tqdm in [tqdm, tqdm_no_yield]:
        tqdm_pandas(_tqdm)
        try:
            from pandas import DataFrame
        except ImportError:
            break
        df = DataFrame(list(range(100)))
        for _ in _tqdm(df.groupby(0).progress_apply(lambda x: x), total=101):
            pass


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:39.019796
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    randoms = np.random.random(5)
    df = pd.DataFrame(randoms, columns=['a'])
    df['b'] = df['a']
    df['c'] = df['a']
    df['d'] = df['a']
    df['e'] = df['a']
    with tqdm_pandas(total=df.shape[0]) as pbar:
        df.progress_apply(lambda x: x*x)
    pbar.close()
    assert isinstance(pbar, tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:42.835038
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm._tqdm import TqdmDeprecationWarning
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm(range(3)))

# Generated at 2022-06-12 14:20:51.140366
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:21:02.104360
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Tests that tqdm_pandas works with and without suppressed output.
    '''
    from tqdm import tqdm, tqdm_notebook, trange
    from pandas import DataFrame
    from math import sqrt
    import logging

    # Dummy function for testing
    def f(x):
        return x ** 2 + sqrt(x)

    # Suppress log (live notebook)
    with tqdm.hooks.wrap_logging_output():
        # Test all tqdm classes
        data = DataFrame({'x': range(100)})
        tqdm_pandas(tqdm, data=data)
        tqdm_pandas(tqdm_notebook, data=data)
        tqdm_pandas(trange, data=data)



# Generated at 2022-06-12 14:21:10.303187
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.random((100, 100)) - 0.5, columns=['x'] * 100)
    try:
        with tqdm_pandas(tqdm(leave=False)) as pbar:
            df.progress_apply(tqdm.tqdm.sleep, axis=1, args=(0.1,))
    except Exception:
        pass


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:22.004787
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    from pandas import compat
    from collections import defaultdict
    from random import randint, random as rndm

    rng = range(10000)
    tqdm_pandas(tqdm(rng, leave=False))
    s = pd.Series(rng).progress_apply(lambda _: None)

    # 1. Special case: `lambda _: _`
    (pd.DataFrame({'str': rng, 'int': rng, 'float': rng})
        .groupby('float')
        .progress_apply(lambda _: _))

    # 2. Groupby on several columns

# Generated at 2022-06-12 14:21:29.612629
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd

    tqdm_pandas(tqdm())

    df = pd.DataFrame({'val': [1, 2, 3, 4, 5, ] * 1000})
    df.groupby(df['val']).progress_apply(lambda x: x)

    df['cumsum'] = df.progress_apply(lambda x: x['val'].cumsum(0), axis=0)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:40.066333
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas as tpd

    df = pd.DataFrame({'x': list(range(10))})

    # By default, progress_apply will show progress bar
    tpd()
    df.groupby(['x']).progress_apply(lambda x: x)

    # But if verbose=False, the progress bar is hidden
    tpd(verbose=False)
    df.groupby(['x']).progress_apply(lambda x: x)

    # If multi_column=True, the index will be shown
    tpd(multi_column=True)
    df.groupby(['x']).progress_apply(lambda x: x)

    # Some other parameters are just like the main tqdm

# Generated at 2022-06-12 14:21:56.533885
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        from tqdm.contrib.tests import tqdm_pandas_obj
    except ImportError:
        return

    # First test: tqdm_pandas(stage.tqdm)
    tqdm_pandas_obj(tqdm_pandas)

    # Second test: tqdm_pandas(tqdm)
    # Create a dummy DataFrame
    df1 = pd.DataFrame({'a':[1,2,3], 'b':[4,5,6]})
    df2 = pd.DataFrame({'a':[1,2,3], 'b':[4,5,6]})
    # Use tqdm_pandas with tqdm

# Generated at 2022-06-12 14:22:04.705643
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm
    from tqdm import tnrange

    # Test tqdm_pandas(tqdm)
    tqdm_pandas(tqdm)
    assert tqdm.config_ctx()._instances[-1]._gui.get_term_width() > 10

    # Test tqdm_pandas(tqdm(...))
    tqdm_pandas(tqdm(total=10))
    assert tqdm.config_ctx()._instances[-1]._gui.get_term_width() > 10

    # Test tqdm_pandas(tqdm_...)
    tqdm_pandas(tnrange(10))
    assert tqdm.config_ctx()._instances

# Generated at 2022-06-12 14:22:14.064421
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas.
    """
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange

    tqdm_pandas(tqdm)
    df = pd.DataFrame({'x': np.random.random(10000)})
    print(df.head())
    for _ in tqdm(df.groupby('x')):
        pass

    tqdm_pandas(trange)
    df = pd.DataFrame({'x': np.random.random(10000)})
    print(df.head())
    for _ in tqdm(df.groupby('x')):
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:25.389962
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import tqdm
    import pandas as pd
    import pandas.util.testing as pdt
    import pandas.util._test_decorators as td

    # define test class and decorator
    @tqdm_pandas
    def do_apply(df):
        return df.apply(lambda x: np.mean(x) ** 2)

    df = pd.DataFrame(np.random.rand(1000, 3))
    expected = df.apply(lambda x: np.mean(x) ** 2)
    result = do_apply(df)
    pdt.assert_series_equal(result, expected)


# Generated at 2022-06-12 14:22:34.589495
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os

    try:
        import pandas as pd
    except ImportError:
        return

    if 'CI' in os.environ:
        return  # This test is slow, and doesn't work in CI anyway

    try:
        from numpy.random import randint
        from numpy import random
    except ImportError:
        random = random_
        randint = random_randint

    # Tests for delayed tqdm_pandas import
    from tqdm import tqdm_gui
    tqdm_pandas(tqdm_gui, leave=False, mininterval=0)
    tqdm_pandas(tqdm_gui, leave=False, mininterval=0,
                file=open(os.devnull, 'w'))

# Generated at 2022-06-12 14:22:37.740208
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    tqdm.pandas()



# Generated at 2022-06-12 14:22:46.869748
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)

        # Case 1
        t = TqdmDeprecationWarning
        tclass = type(t)
        tqdm_kwargs = dict(a=1, b=2)
        assert t.__name__ == 'TqdmDeprecationWarning'
        assert isinstance(tclass, type)
        assert not getattr(tclass, '__name__', '').startswith('tqdm_')
        assert tqdm_kwargs == dict(a=1, b=2)
        with mock.patch('tqdm.TqdmDeprecationWarning.pandas') as m_pandas:
            tqdm_pandas(tclass, **tqdm_kwargs)
            m

# Generated at 2022-06-12 14:22:52.770941
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # simple test that tqdm_notebook and tqdm_gui do not crash
    try:
        import pandas  # noqa

        with tqdm_pandas(total=1, unit_scale=True) as pbar:
            import time
            pbar.update(1)
    except Exception:
        # pandas not installed
        pass

# Generated at 2022-06-12 14:23:01.534350
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for deprecated function `tqdm_pandas`."""
    from tqdm import tqdm_pandas

    from tqdm.contrib import tqdm_pandas; tqdm_pandas()
    tqdm_pandas(tqdm_pandas)
    tqdm_pandas(tqdm_pandas(), tqdm_kwargs=dict())
    tqdm_pandas(tqdm_pandas, tqdm_kwargs=dict())
    tqdm_pandas(tqdm_pandas())
    tqdm_pandas.tqdm_pandas()
    tqdm_pandas.tqdm_pandas(tqdm_pandas)
    tqdm_pand

# Generated at 2022-06-12 14:23:11.858469
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from numpy import random
    from time import sleep
    from itertools import product

    tqdm_kwargs = dict(desc='tqdm_pandas', leave=False, total=10)

    # Test: delayed adapter case
    df = DataFrame(random.randn(10, 3))
    tqdm_kwargs['file'] = open(os.devnull, 'wb')
    tqdm_pandas(tqdm, **tqdm_kwargs)
    df.progress_apply(sleep, 1, axis=1)

    # Test: explicit tclass case
    tclass = tqdm(**tqdm_kwargs)
    tqdm_pandas(tclass)

# Generated at 2022-06-12 14:23:34.361456
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm.pandas()
    # initialize test dataframe
    df = pd.DataFrame(index=[1, 2, 3], columns=['a', 'b', 'c'])
    df.a = [0.4, 0.4, 0.4]
    df.b = [0.4, 0.4, 0.4]
    df.c = [0.4, 0.4, 0.4]
    # test tqdm_pandas
    df = df.groupby(['a', 'b', 'c']).progress_apply(lambda x: x)
    assert(True)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:42.487307
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange, TqdmSynchronisationWarning
    from tqdm._utils import _term_move_up
    try:
        from pandas.core import groupby
    except ImportError:
        return None

    df = pd.DataFrame({'a': list(map(str, np.random.rand(10000)))})
    t = tqdm(total=len(df))
    _term_move_up()
    with warnings.catch_warnings():
        if pd.__version__ >= '0.18':
            warnings.filterwarnings('ignore', category=TqdmSynchronisationWarning)
        df.groupby('a').progress_apply(lambda _: None, t=t)


# Generated at 2022-06-12 14:23:53.177591
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from random import randint, random
    from pandas import DataFrame, Series
    from tqdm import tqdm

    df = DataFrame({'col1': [randint(1, 100) for _ in range(1000)],
                    'col2': [random() for _ in range(1000)]})
    df1 = df.groupby('col1').progress_apply(
        lambda x: Series({'col3': sum(x['col2']), 'col4': len(x['col2'])}))
    df2 = df.groupby('col1').apply(
        lambda x: Series({'col3': sum(x['col2']), 'col4': len(x['col2'])}))
    assert df1.equals(df2)

#     a = tqdm

# Generated at 2022-06-12 14:24:02.324882
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    data = {'col1': np.random.randint(10, size=1000000),
            'col2': np.random.randint(10, size=1000000),
            'col3': np.random.randint(10, size=1000000)}
    df = pd.DataFrame(data=data)
    data_sum = df.groupby('col1').agg({'col2': np.sum, 'col3': np.count_nonzero})
    test_sum = data_sum.sum()
    tqdm_pandas(tqdm())
    tqdm_sum = df.progress_apply(sum)
    assert test_sum == tqdm_sum



# Generated at 2022-06-12 14:24:10.976573
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    try:
        tqdm_pandas(tqdm())
    except TqdmDeprecationWarning as e:
        assert "Please use `tqdm.pandas(...)`" in str(e)

    try:
        tqdm_pandas(tqdm)
    except TqdmDeprecationWarning as e:
        assert "Please use `tqdm.pandas(...)`" in str(e)

    try:
        tqdm.pandas()
    except TqdmDeprecationWarning as e:
        assert "Please set miniters" in str(e)

    tqdm_pandas(tqdm, mininterval=0)


# Generated at 2022-06-12 14:24:22.794378
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:24:29.744314
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, pandas
    from pandas import DataFrame
    from numpy.random import normal
    from os import remove
    from warnings import simplefilter
    simplefilter("ignore", TqdmDeprecationWarning)  # or: ignore all DeprecationWarnings

# Generated at 2022-06-12 14:24:40.212750
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas function."""
    import os
    from tqdm import tqdm
    from pandas import DataFrame
    from random import randint, choice
    from string import ascii_uppercase
    from shutil import rmtree


# Generated at 2022-06-12 14:24:48.300770
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Dummy tqdm call that does not create any bars
    def tqdm(*args, **kwargs):
        return type('tqdm', (object,), {'pandas': tqdm_pandas})()

    # Initialize tqdm and pandas without any bars created
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)
        import pandas
        tqdm_pandas(tqdm())
    # Same effect with tqdm as an argument
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)
        import pandas
        tqdm_pandas(tqdm())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:57.479679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm.auto import tqdm
    tqdm.pandas()
    df = pd.DataFrame({'a': np.random.randn(1000), 'b': np.random.randn(1000)})
    df.groupby(['a']).progress_apply(lambda x: x**2)
    df.groupby(['a']).progress_apply(lambda x: x**2)
# ncols = int(tqdm_test().n)
# fn = tqdm_test().write
# print(ncols, fn)
# tqdm_pandas(tqdm_test())
# from tqdm import trange
# from tqdm.auto import tqdm
# tqdm.pandas()

# Generated at 2022-06-12 14:25:21.896786
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm, pandas
    from .std import isatty
    from .std import PY3
    from .utils import GzipFile

    # pandas is not installed
    try:
        # noinspection PyUnresolvedReferences
        import pandas as pd
    except ImportError:
        return None

    if PY3:
        from io import StringIO
        # noinspection PyMissingOrEmptyDocstring,PyRedeclaration
        class BytesIO(StringIO):
            def write(self, s):
                super(BytesIO, self).write(s.decode())
    else:
        from StringIO import StringIO
        BytesIO = StringIO

    # test tqdm_pandas()

# Generated at 2022-06-12 14:25:29.718320
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    from tqdm import tqdm, TqdmTypeError

    try:
        tqdm_pandas(tqdm())
    except Exception as e:
        raise type(e)(
            "tqdm_pandas: tqdm(meth=False) case failed",
            type(e).__name__ + '.traceback',
            e.args,
            file=sys.stderr.buffer) from None


# Generated at 2022-06-12 14:25:38.850745
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import random
    from tqdm import tqdm, trange

    # Basic functionality
    tqdm_pandas(tqdm(), total=10)
    DataFrame(random.randn(20, 10)).progress_apply(lambda x: x)

    # Attribute access
    assert isinstance(tqdm_pandas(tqdm.pandas(total=10)).file, tqdm.std.filelike)
    assert isinstance(tqdm_pandas(tqdm.pandas(total=10)).desc, str)
    assert isinstance(tqdm_pandas(tqdm.pandas(total=10)).miniters, int)

# Generated at 2022-06-12 14:25:43.967040
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'a': range(10)})
    tqdm.pandas(tqdm.tqdm(), desc="test_tqdm_pandas")
    df.groupby('a').progress_apply(lambda x: x, axis=0)

# Generated at 2022-06-12 14:25:50.718780
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def assert_tqdm_pandas(t, **kwargs):
        assert hasattr(t, 'pandas')
        assert not hasattr(t, 'tqdm_pandas')
        assert not hasattr(t, 'tqdm_')

    from tqdm import tqdm
    assert_tqdm_pandas(tqdm)
    tqdm_pandas(tqdm)
    assert_tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:25:56.562673
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    T = pandas.util.testing
    df = T.makeTimeDataFrame()
    T.N = 100
    t = tqdm(total=T.N)
    t.update(1)
    tqdm_pandas(t)
    assert t is df.groupby('A').progress_apply(id)
    t = tqdm(total=T.N, miniters=1)
    t.update(1)
    tqdm_pandas(t, miniters=1)
    assert t is df.groupby('A').progress_apply(id)
    t = tqdm(total=T.N)
    t.update(1)
    tqdm_pandas(tqdm)
    assert t is df.groupby('A').progress_apply

# Generated at 2022-06-12 14:26:00.762387
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        assert hasattr(tqdm(unit='B', unit_scale=True, unit_divisor=1024), 'pandas')
    except (ModuleNotFoundError, AttributeError):
        pass


if __name__ == '__main__':
    from .main import _test
    _test()

# Generated at 2022-06-12 14:26:04.181919
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm_pandas(tqdm())
    pd.DataFrame({}).groupby('i').progress_apply(lambda x: x)

# Generated at 2022-06-12 14:26:09.204807
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        return
    tqdm_pandas(tqdm.tqdm)

    for f in [chr, None]:
        assert hasattr(DataFrameGroupBy, 'progress_apply')
        assert hasattr(DataFrameGroupBy, 'progress_map')

# Generated at 2022-06-12 14:26:18.299268
# Unit test for function tqdm_pandas
def test_tqdm_pandas(): # pragma: no cover
    from tqdm.pandas import tqdm_pandas
    from tqdm import tqdm
    import pandas as pd

    def test_func(df):
        return df.sum() + 1

    df = pd.DataFrame({'col1': [1, 2, 3], 'col2': [4, 5, 6]})

    # New API
    df.progress_apply(test_func)
    tqdm_pandas(tqdm()).pandas(df.progress_apply, test_func)
    tqdm_pandas(tqdm).pandas(df.progress_apply, test_func)
    tqdm_pandas(**tqdm().kwargs).pandas(df.progress_apply, test_func)

