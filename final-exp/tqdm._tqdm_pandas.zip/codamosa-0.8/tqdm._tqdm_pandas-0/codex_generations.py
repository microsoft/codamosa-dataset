

# Generated at 2022-06-12 14:16:26.716936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import tqdm

    tqdm.tqdm_pandas(tqdm.tqdm(), smoothing=0)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:16:35.639976
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """run unit tests"""
    from pandas import DataFrame
    from pandas import Series
    from pandas import concat

    tqdm_pandas(type(tqdm))

    # see: https://github.com/pandas-dev/pandas/commit/0f38d97c54d7b2dc2b0e66d065aebc7a4b4f4b6c
    # We can't use the simple `test(test_cases, columns)` function
    # from the above link because it uses the deprecated tqdm_pandas
    # import.

# Generated at 2022-06-12 14:16:44.294331
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    from tqdm._tqdm_pandas import trange

    # Deprecated, but still until release of tqdm v. 5.0
    tqdm_pandas(trange(0), desc='...')

    # This is the main functionality, which should be preserved
    tqdm_pandas(trange(0, desc='...'))

    assert list(pd.DataFrame({'a': range(10)}).progress_apply(lambda x: x)) == [
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9
    ]

# Generated at 2022-06-12 14:16:52.829950
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm._utils import _range, _unich, _term_move_up

    df = pd.DataFrame({'A': np.random.randint(0, 100, 10000),
                       'B': np.random.randint(0, 100, 10000)})
    res = []
    for _ in tqdm(range(1000)):
        res.append(df.groupby('A').progress_apply(
            lambda x: x['B'].sum()))
    res = pd.concat(res).groupby(level=0).sum()
    print(res.head())
    print(res.tail())

# Generated at 2022-06-12 14:16:59.382044
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def func(df):
        return pd.DataFrame([df.mean()] * 10)

    try:
        import pandas
        orig_df = pandas.DataFrame(np.random.randint(0, 100, (100000, 6)))
    except ImportError:
        orig_df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

    df = orig_df.copy()
    # Check that deprecated function tqdm_pandas works the same as tqdm.pandas
    print('\nDeprecated')
    tqdm_pandas(tqdm, unit='rows')
    df = orig_df.copy()

# Generated at 2022-06-12 14:17:06.880750
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    DataFrame.progress_apply = tqdm_pandas(
        DataFrameGroupBy.progress_apply)
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.random((1000, 1000)))
    with tqdm(total=len(df)) as pbar:
        df.progress_apply(lambda x: x.sum(), axis=1)
    assert len(pbar) == len(df)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:16.505237
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas import Series
    from numpy import random
    from numpy import array
    from numpy import concatenate
    from numpy import NaN

    # Preparation
    n_df = 20
    n_df_row = 10
    n_series = n_df * n_df_row
    n_array = n_df * n_df_row
    n_nested_df = 5
    n_nested_df_row = 4
    n_nested_series = n_nested_df * n_nested_df_row
    n_nested_array = n_nested_df * n_nested_df_row
    data = random.normal(size=n_series)

# Generated at 2022-06-12 14:17:23.045166
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm.test

    _test_tqdm_pandas = tqdm.test._test_tqdm_pandas
    try:
        tqdm.test._test_tqdm_pandas = lambda: None
        import pandas
        assert pandas is not None
        _test_tqdm_pandas()
        assert tqdm.pandas is not None
    finally:
        tqdm.test._test_tqdm_pandas = _test_tqdm_pandas

test_tqdm_pandas()

# Generated at 2022-06-12 14:17:31.035616
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for :py:func:`tqdm_pandas`"""
    from pandas import DataFrame
    df = DataFrame(columns=['a', 'b', 'c'], data=[[4, 5, 6], [7, 8, 9]])
    from tqdm import tnrange
    from tqdm import tqdm
    from tqdm import tqdm_notebook

    with tnrange(2) as t:
        df.groupby(['a']).progress_apply(lambda x: next(t))
    with tqdm_notebook(10, desc='test') as t:
        df.groupby(['a']).progress_apply(lambda x: next(t))

# Generated at 2022-06-12 14:17:39.173484
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests that tqdm_pandas works as expected
    """
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'A': range(100)})
    t = tqdm.tqdm(unit='', total=df.shape[0])
    assert df.groupby(df.A // 10) \
        .progress_apply(lambda x: x, tqdm_kwargs={'t': t}) \
        .shape == (100, 1)


# Generated at 2022-06-12 14:17:41.261890
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm())

# Generated at 2022-06-12 14:17:49.363002
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas.
    """
    from tqdm import tqdm
    try:
        import pandas as pd
    except ImportError:
        return  # skip
    assert tqdm_pandas(tqdm) == tqdm.pandas()


if __name__ == '__main__':
    r"""
    CommandLine:
        python -m tqdm.contrib.concurrent
        python -m tqdm.contrib.concurrent --allexamples
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:17:57.763529
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import trange
    from tqdm.autonotebook import tqdm

    # Compatible with pandas<0.23
    def progress_apply(self, func, *args, **kwargs):
        groups = self.groups
        progress = tqdm(groups)
        retval = []
        v = 0
        for i in progress:
            progress.set_description(str(i))
            progress.set_postfix(v=v)
            v += 1
        return retval


# Generated at 2022-06-12 14:18:07.229523
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Runs the unit tests for tqdm_pandas
    """
    from tqdm.auto import tqdm

    warnings.simplefilter("ignore")
    try:
        import pandas
    except ImportError:
        return
    try:
        df = pandas.DataFrame({'a': range(10), 'b': range(10), 'c': range(10)})
        df.groupby('a').progress_apply(lambda x: None)
        tqdm.pandas(desc='Testing `tqdm.pandas`')
        df.groupby('a').progress_apply(lambda x: None)
    finally:
        tqdm.pandas(desc=None)
        warnings.simplefilter("default")


if __name__ == "__main__":
    test_tqdm

# Generated at 2022-06-12 14:18:17.730046
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange
    from tqdm._utils import _range
    import pandas as pd

    for cls in [tqdm, trange]:
        with cls(total=10, file=sys.stderr) as pbar:
            assert pbar.total == 10
            for _ in _range(8):
                pbar.update()
            for _ in _range(2):
                pbar.update(2)
            assert pbar.n == pbar.total

        with cls(total=10, file=sys.stderr) as pbar:
            try:
                raise NotImplementedError
            except NotImplementedError:
                pbar.print_exc()

        pbar = cls(total=11, file=sys.stderr)

# Generated at 2022-06-12 14:18:26.476958
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test of tqdm_pandas() """
    pandas_import_error = None
    try:
        import pandas as pd
    except ImportError:
        pandas_import_error = ImportError

    if pandas_import_error:
        print('pandas not found: skipping ...')
    else:
        df = pd.DataFrame({'a': [1, 2, 3], 'b': [1, 2, 3]})
        df.groupby('a').progress_apply(lambda d: d)
        df.groupby('a').progress_apply(lambda d: d, show_percentage=False)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:35.247601
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from pandas import DataFrame
    from pandas import Series
    from tqdm import tqdm

    df = DataFrame({'numbers': [n for n in range(100)]})
    df = df.groupby(df.numbers % 4).progress_apply(lambda x: x)
    # df.apply(lambda x: x)

    # with tqdm(total=100) as pbar:
    #     df = df.groupby(df.numbers % 4).progress_apply(lambda x: x)
    #     pbar.update(50)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:41.598038
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas, tqdm_gui
    from pandas import DataFrame, Series

    # Testing deprecated argument `tqdm_class`
    tqdm_class = tqdm
    tqdm_pandas(tclass=tqdm_class)

    # Testing deprecated argument `tqdm_gui`
    tqdm_gui(tclass=tqdm_gui)

    # Testing deprecated argument `tqdm`
    tqdm_kwargs = {'total': 100000, 'position': 0}
    tqdm(disable=False, **tqdm_kwargs)

# Generated at 2022-06-12 14:18:53.418080
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import arange
    from time import sleep
    from tqdm import tqdm

    # Test cases
    for tclass in (tqdm, tqdm(leave=True)):
        # Test groupby
        for obj in [DataFrame({'A': arange(10), 'B': arange(10)}),
                    Series(arange(10))]:
            # Test normal
            assert obj.copy().groupby('A').progress_apply(
                lambda x: sleep(.1)).equals(obj)
            # Test desc
            assert obj.copy().groupby('A', group_keys=False).progress_apply(
                lambda x: sleep(.1), desc='TEST').equals(obj)
        # Test apply

# Generated at 2022-06-12 14:19:03.415023
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    a = DataFrame({'a': [1, 2, 3], 'b': [2, 3, 4]})

    # Test deprecated function
    with closing(StringIO()) as our_file:
        tqdm_pandas(tqdm(desc="Progress", file=our_file), total=3)
        a.progress_apply(lambda x: x['a'] + 2)

    # Test function
    with closing(StringIO()) as our_file:
        tqdm.pandas(file=our_file)
        a.progress_apply(lambda x: x['a'] + 2)


if __name__ == '__main__':
    from tqdm.auto import tqdm
    from io import StringIO

# Generated at 2022-06-12 14:19:11.101911
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm.contrib.concurrent import process_map

    def my_dataframe(x):
        import time
        time.sleep(0.01)
        return x

    df = DataFrame(list(range(100)))

    # Register a tqdm instance with pandas
    tqdm_pandas(tqdm())(process_map, my_dataframe, df[0])

# Generated at 2022-06-12 14:19:17.473337
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        tqdm_pandas(tqdm())
        tqdm_pandas(tqdm, total=100)
        tqdm_pandas(tqdm_gui)
        tqdm_pandas(tqdm_gui, total=100)
        tqdm_pandas(tqdm_notebook)
        tqdm_pandas(tqdm_notebook, total=100)
    except:
        raise

# Generated at 2022-06-12 14:19:21.800469
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    with tqdm(total=np.arange(1000).sum()) as pbar:
        pd.DataFrame({'a': np.arange(1000)}).groupby('a').progress_apply(
            lambda x: pbar.update())

    with tqdm(total=np.arange(5).sum()) as pbar:
        pd.DataFrame({'a': np.arange(5)}).groupby('a').progress_apply(
            lambda x: pbar.update())

if __name__ == __author__:
    print("Running unit test for `{0}`.".format(__file__))
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:25.818505
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm_notebook())



# Generated at 2022-06-12 14:19:37.056341
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import nan
    from .tqdm_pandas import tqdm_pandas
    # Non-deprecated syntax
    try:
        assert tqdm_pandas(tqdm_notebook)(range(2)) == list(range(2))
    except ImportError:
        pass
    assert tqdm_pandas(range(2)) == list(range(2))
    # Deprecated syntax
    assert tqdm_pandas(tqdm_notebook)(range(2)) == list(range(2))
    assert tqdm_pandas(range(2)) == list(range(2))
    # Checking correct progress-bar type is used
    tqdm_pandas(range(2))

# Generated at 2022-06-12 14:19:45.451155
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    # Fake a tqdm instance and test
    class tqdm(object):
        def __init__(self, iterable, **kwargs):
            pass
    tqdm.pandas = tqdm_pandas  # Enable function to just pass tqdm
    tqdm(None)  # Call tqdm(None)

    # Test DataFrameGroupBy.progress_apply
    from pandas import DataFrame
    from pandas import Series
    from pandas import concat
    from pandas import date_range
    import numpy as np
    df = DataFrame(np.random.rand(10000, 10000), columns=['a', 'b', 'c'])
    df['str'] = 'abc'
    df['ts']

# Generated at 2022-06-12 14:19:56.710887
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for `tqdm_pandas`.
    """

# Generated at 2022-06-12 14:20:06.632908
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from tqdm import tqdm
    except ImportError:
        raise SkipTest
    from numpy import random
    from pandas import DataFrame
    from pandas import Series

    try:
        import pandas
        from pandas import Index
    except ImportError:
        raise SkipTest

    tqdm_pandas(tqdm)

    df = DataFrame({'a': random.rand(100)})
    if Index is not None:
        idx = Index(['x'] * 10)
    else:
        idx = list('abcdefghij')
    s = Series(range(10), index=idx)

    # Check df.progress_apply
    df['b'] = df['a'].progress_apply(lambda x: x**2)

# Generated at 2022-06-12 14:20:12.503763
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:20:17.968216
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm
    df = pd.DataFrame(np.random.randn(1e4, 4), columns=list('abcd'))
    tqdm.pandas(tqdm.tqdm(ascii=True), leave=False, desc="progress_apply")
    df.groupby('a').progress_apply(lambda x: x ** 2).mean()

# Generated at 2022-06-12 14:20:31.804951
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm, tqdm_pandas
    import numpy as np
    import pandas as pd

    df = pd.DataFrame()
    df['x'] = [0, 1, 2, 3, 4]
    print(df)

    def func(x):
        return x * 2

    def func2(x):
        raise IOError('foo')

    df.progress_apply(func)
    df.progress_apply(func, axis=1)

    try:
        df.progress_apply(func2)
    except IOError as e:
        assert str(e) == 'foo'

    try:
        df.progress_apply(func2, axis=1)
    except IOError as e:
        assert str(e) == 'foo'

    # Use of t

# Generated at 2022-06-12 14:20:40.133067
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm

    df = pd.DataFrame({'x': np.arange(100)})

    tqdm_pandas(tqdm)
    expected = df.progress_apply(lambda x: x, axis=1)
    tqdm_pandas(tqdm())
    actual = df.progress_apply(lambda x: x, axis=1)
    assert actual.equals(expected)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:48.012989
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    df = pd.DataFrame({'a': [1, 2, 3, 4, 5], 'b': [1, 2, 3, 4, 5]})
    df = df.groupby('a').progress_apply(lambda x: x)

    with tqdm() as t:
        df = pd.DataFrame({'a': [1, 2, 3, 4, 5], 'b': [1, 2, 3, 4, 5]})
        df = df.groupby('a').progress_apply(lambda x: x, t=t)


# Generated at 2022-06-12 14:20:58.727218
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    import pandas as pd
    import tqdm
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO
    import numpy as np
    import random

    def slow_function(df):
        return DataFrame([[random.uniform(0, 0.5)] for i in range(16)],
                         index=df.index[:16], columns=df.columns[:16])

    # Apply slow function using tqdm_pandas
    pd.set_option("display.max_rows", None, "display.max_columns", None)

# Generated at 2022-06-12 14:21:06.992220
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange
    df = pd.DataFrame({'x': np.random.randn(5),
                       'y': np.random.randn(5)})
    tqdm_pandas(tqdm)
    tqdm_pandas(trange)
    list(df.groupby('x').progress_agg(
        lambda x: np.sum(x.y), pbar=True, desc='test'))



# Generated at 2022-06-12 14:21:18.438634
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd, numpy as np
    from tqdm import tqdm
    with tqdm(total=1) as t:
        pd.DataFrame(np.random.random((1000, 1000))) \
            .progress_apply(lambda x: x ** 2)
        assert hasattr(t, 'pandas'), 'Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.'
    with tqdm(total=1) as t:
        pd.DataFrame(np.random.random((1000, 1000))) \
            .progress_apply(lambda x: x ** 2)

# Generated at 2022-06-12 14:21:28.852940
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange
    from tqdm.pandas import tqdm_pandas

    def simple_apply(i, t, ts):
        return pd.Series(
            np.random.randn(len(i)), index=i, name=ts.name).sort_values()

    df = pd.DataFrame(np.random.randn(1000, 100), columns=tuple('ABCDEFGHIJKLMNOPQRSTUVWXYZ'))
    gb = df.groupby(lambda x: x % 20)
    # Auto-registers tqdm and `pandas.core.groupby.DataFrameGroupBy.progress_apply` with tqdm

# Generated at 2022-06-12 14:21:35.383741
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Callable example
    tqdm_pandas(tqdm, smoothing=0)

    # Non-callable example
    tqdm_pandas(tqdm(0, miniters=1, smoothing=0))

    # Verify deprecated alias works
    import warnings
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        tqdm_pandas(tqdm, smoothing=0)
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
        assert "tqdm_pandas(tqdm" in str(w[-1].message)
        tqdm_pandas(tqdm(0, miniters=1, smoothing=0))

# Generated at 2022-06-12 14:21:45.895750
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.utils import _term_move_up
    from tqdm.contrib import pandas
    from pandas import DataFrame
    from pandas import concat
    from pandas import date_range

    def progress_apply_test(desc=None, total=None, leave=False, **tqdm_kwargs):
        # dummy test
        # NB: will not be called if `tqdm_pandas(tqdm)`
        # is called prior to this function
        assert desc == "test"
        assert total == 10
        assert not leave
        assert tqdm_kwargs == dict()

    # Test 1 (ensure dummy function is properly called)
    DataFrame().progress_apply(
        lambda x: x)  # initialise test case
    DataFrame

# Generated at 2022-06-12 14:21:54.767232
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from tqdm import tqdm
    from tqdm._utils import _supports_unicode
    import pandas as pd
    import numpy as np
    import random

    with tqdm(total=100) as t:
        # Initialise array
        numElems = 100
        data = np.zeros(numElems)
        # Generate some random data
        for i in t:
            data[i] = random.random()
            t.set_postfix(i=i, data=data[i])

    # tqdm_pandas(tqdm, pandas=True)  # register `pandas.progress_apply`
    # df = pd.DataFrame({'x': data})
    # with tqdm(total

# Generated at 2022-06-12 14:22:11.611165
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import pandas as t_pd

    # Test error when executing *tqdm_pandas(tqdm(...))*
    with tqdm(['a', 'b', 'c'], desc='tqdm') as t:
        assert isinstance(t, tqdm.tqdm)
        with pytest.raises(TqdmDeprecationWarning):
            tqdm_pandas(t)
        # Test error when executing *tqdm_pandas(tqdm)*
        with pytest.raises(TqdmDeprecationWarning):
            tqdm_pandas(tqdm)

    if pandas_found:
        test_df = pd.DataFrame(np.random.randint(0, 500000, (1000000, 1)))


# Generated at 2022-06-12 14:22:22.845596
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame

    print("\nTesting tqdm_pandas with Series")
    s = pd.Series(np.arange(1000))
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmDeprecationWarning)
        for i in tqdm_pandas(s):
            pass

    print("\nTesting tqdm_pandas with DataFrame")
    df = DataFrame({'col1': s, 'col2': s})
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmDeprecationWarning)
        # iterrows
        for index, row in tqdm_pandas(df.iterrows(), total=len(df)):
            pass


# Generated at 2022-06-12 14:22:32.561944
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    # Does not support tqdm_pandas
    assert not hasattr(tqdm(total=0, desc='Test'), 'pandas')
    # Support tqdm_pandas
    tqdm_pandas(tqdm(total=0, desc='Test', file=StringIO()))
    assert hasattr(tqdm(total=0, desc='Test', file=StringIO()), 'pandas')
    df = pandas.DataFrame(numpy.random.randn(100, 100))
    tqdm_pandas(tqdm(total=1, desc='Test', file=StringIO()),
            leave=False,
            mininterval=0.1).progress_apply(lambda x: x ** 2, axis=1)
    tq

# Generated at 2022-06-12 14:22:42.680054
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame([1,2,3])
    tqdm_pandas(tqdm.tqdm, df.groupby(df[0]))
    tqdm_pandas(tqdm.tqdm_notebook, df.groupby(df[0]))
    tqdm_pandas(tqdm.tqdm_notebook, df.groupby(df[0])).progress_apply(lambda x: x)
    tqdm_pandas(tqdm.tqdm, df.groupby(df[0])).progress_apply(lambda x: x)

# Generated at 2022-06-12 14:22:53.675424
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        print('SKIP: module `pandas` not found')
        return

    tqdm_pandas(tqdm(["a", "b", "c", "d"]))

    try:
        tqdm_pandas(tqdm.tqdm(["a", "b", "c", "d"]))
    except TypeError:
        print('TypeError: tqdm_pandas(tqdm.tqdm(...))')
        pass
    else:
        raise AssertionError('Expected TypeError: tqdm_pandas(tqdm.tqdm(...))')

    tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:23:02.281343
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    $ python -m tqdm.tests.test_pandas
    """
    import pandas as pd
    try:
        df = pd.DataFrame(columns=['a', 'b', 'c'])
        df['a'] = [1,2,3,4,5]
        df['b'] = [0] * 5
        import tqdm
        try:
            tqdm.pandas(tqdm.tqdm())
        except:
            tqdm.pandas()
        df['b'] = df.progress_apply(lambda x: x['a']%2, axis=1)
        assert df['b'].sum() == 2
        tqdm.pandas(tqdm.tqdm())
    except ImportError:
        pass
    
#

# Generated at 2022-06-12 14:23:10.256171
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise SkipTest
    tqdm_pandas(tqdm(pandas=True))
    tqdm_pandas(tqdm(pandas=True), mininterval=0.01)
    tqdm_pandas(tqdm(pandas=True), smoothing=0.5)
    tqdm_pandas(tqdm(pandas=True), smoothing=0.1)

if __name__ == '__main__':
    from .main import _test
    _test()

# Generated at 2022-06-12 14:23:17.566225
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        if pandas.__version__ < '0.20':
            raise ImportError
        import tqdm
    except ImportError:
        print("Skipping tests for tqdm_pandas (pandas is not installed)!")
    else:
        from pandas import DataFrame
        tqdm_pandas(tqdm.tqdm())
        tqdm_pandas(tqdm.tqdm(total=10))
        tqdm_pandas(tqdm.tqdm(total=10, disable=None))
        tqdm_pandas(tqdm.tqdm(total=0))
        tqdm_pandas(tqdm.tqdm(total=0))

# Generated at 2022-06-12 14:23:27.279720
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    tqdm_pandas(tqdm)

    N = 10
    df = pd.DataFrame({'a': np.random.randn(N),
                       'b': np.random.randn(N)})

    r = pd.DataFrame(index=df.index)
    for i, group in enumerate(df.groupby('a')):
        r.loc[df.index[i]] = group[1].b.mean()
    assert (df.groupby('a').progress_apply(lambda x: x.b.mean()) == r).all()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:36.086098
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    def apply_df(df, f, **kwargs):
        return df.groupby(**kwargs).progress_apply(f)

    print('\nTest ProgressApply:')
    df = pd.DataFrame({'x': [1, 2, 3] * 100000, 'y': [4, 5, 6] * 100000})
    # Apply a simple function to apply example
    print(apply_df(df, lambda x: x, by='x'))
    with tqdm(position=0, leave=True, file=sys.stdout) as t:
        print(apply_df(df, lambda x: x, by='x', tqdm=t))

    # Apply a simple function to apply example

# Generated at 2022-06-12 14:23:56.784546
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    df = DataFrame(dict(col_1=[1, 2, 3], col_2=[4, 5, 6]))

    progress_bar = tqdm(range(10), desc='test_tqdm_pandas', ncols=100)
    tqdm_pandas(tclass=progress_bar)
    df.groupby(['col_1']).progress_apply(lambda x: x.sum())


# Generated at 2022-06-12 14:24:04.942619
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma:nocover
    def tqdm_pandas_check(**tqdm_kwargs):
        from collections import defaultdict
        from pandas import DataFrame
        from pandas.core.groupby import DataFrameGroupBy
        from numpy.random import randint

        # Assert that `tqdm_pandas` automatically install `tqdm.pandas` if not already installed
        from tqdm.pandas import tqdm_pandas
        assert not hasattr(DataFrameGroupBy, 'progress_apply')
        tqdm_pandas(**tqdm_kwargs)
        assert hasattr(DataFrameGroupBy, 'progress_apply')

        # Make sure progress_apply works correctly
        d = defaultdict(list)

# Generated at 2022-06-12 14:24:13.057174
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy  as np

    # http://xahlee.info/python/python_infinite_generator.html
    def natural_nums():
        n = 0
        while True:
            yield n
            n += 1

    # http://stackoverflow.com/a/1630350/353337
    def gen_df(n):
        for i in natural_nums():
            yield pd.DataFrame({'x': np.arange(n) + i,
                                'y': np.random.rand(n)})
            if i >= 100:
                break

    # http://stackoverflow.com/a/17387853/353337

# Generated at 2022-06-12 14:24:24.816351
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_notebook
    from tqdm import tqdm

    def _run_tests(tqdm_func):
        global __name__
        __name__ = 'tqdm_notebook'
        tqdm_pandas(tqdm_func(unit='it', smoothing=0), file=open(os.devnull, 'w'))
        __name__ = 'tqdm'
        tqdm_pandas(tqdm_func(unit='it', smoothing=0, file=open(os.devnull, 'w')))
        __name__ = ''

    _run_tests(tqdm_notebook)
    _run_tests(tqdm)


if __name__ == 'tqdm':
    from pandas import DataFrame
    DataFrame

# Generated at 2022-06-12 14:24:30.915832
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test if tqdm_pandas returns no exception
    def tqdm_test():
        tqdm_test = tqdm(total=7, unit='test')
        tqdm_test.update(7)
        return tqdm_test

    tqdm_pandas(tqdm_test())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:40.911081
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Download data
    from pandas_datareader import data as pdr
    from tqdm.auto import tqdm
    import pandas as pd
    import numpy as np
    # Import pandas_datareader.data as web
    # Import Panel
    download_data = False
    if download_data:
        data = pdr.get_data_yahoo("SPY", start="2017-01-01", end="2017-04-30")
    else:
        data = pd.read_csv("test_tqdm_pandas.csv")
    # Check data
    print("Data of 2017-01-01 to 2017-04-30")
    print(data)
    # Check pandas_datareader & tqdm

# Generated at 2022-06-12 14:24:45.947152
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from tqdm import trange
    from pandas import DataFrame
    from numpy import random

    df = DataFrame(random.randn(100,100)*10)
    tqdm_pandas(trange(5))(df.groupby(0).sum)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:51.850834
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    python3 -c "import sys; sys.path.append('.');import tqdm.pandas; tqdm.pandas.test.test_tqdm_pandas()"
    """
    from pandas import DataFrame
    from numpy import arange
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm.pandas import tqdm_pandas
    from tqdm import tqdm


# Generated at 2022-06-12 14:24:59.974775
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm_pandas

    try:
        tqdm_pandas(pd.DataFrame(np.random.random((1000, 1000)), columns=['A']).groupby('A').progress_apply(lambda x: x))
    except Exception as e:
        raise AssertionError(e)
    try:
        tqdm_pandas(pd.DataFrame(np.random.random((1000, 1000)), columns=['A']).groupby('A').progress_apply(lambda x: x.progress_apply(np.sum)))
    except Exception as e:
        raise AssertionError(e)

# Generated at 2022-06-12 14:25:09.048625
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas.
    """
    import pandas as pd
    from tqdm import tqdm

    # Test tqdm_pandas for tqdm class instance
    df = pd.DataFrame({"a": [i for i in range(10)]})
    tqdm_pandas(tqdm(ascii=True))
    df.groupby('a').progress_apply(lambda x: x['a'])

    # Test tqdm_pandas for tqdm class
    tqdm_pandas(tqdm, ascii=True)
    df.groupby('a').progress_apply(lambda x: x['a'])


# Generated at 2022-06-12 14:25:32.591843
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange, trange
    from pandas import DataFrame

    df = DataFrame([[1, 2, 3], [4, 5, 6]])

    for t in [tnrange, trange]:
        with tqdm_pandas(t):
            df.groupby(0).progress_apply(lambda x: x.sum())

    with tqdm_pandas(tclass=t):
        df.groupby(0).progress_apply(lambda x: x.sum())

    with tqdm_pandas(tclass=t, total=2):
        df.groupby(0).progress_apply(lambda x: x.sum())


# Generated at 2022-06-12 14:25:38.416236
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    # test with tqdm.pandas
    df = pd.DataFrame(np.random.random(size=(100, 100)))
    with tqdm.pandas(desc='my bar', mininterval=0) as t:
        # must use .progress_apply(func) instead of .apply(func)
        df.groupby(0).progress_apply(lambda x: x ** 2 if x.name == 0 else x ** 3)
        # test second use
        df.groupby(0).progress_apply(lambda x: x ** 2 if x.name == 0 else x ** 3)

    # test with tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:25:43.908337
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    with tqdm(total=df.shape[0]) as pbar:
        def wrapper(x):
            pbar.update()
            return x
        df.progress_apply(wrapper)


# Generated at 2022-06-12 14:25:50.234353
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        # Pandas >= 0.17
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        # Pandas < 0.17
        from pandas.core.groupby import GroupBy

    # Test 1: tqdm instance
    try:
        t = tqdm_pandas(tqdm(total=4, desc='t'))
        assert t.__name__ == 'tqdm_pandas'
        assert hasattr(t, 'pandas')
        t.close()
    except:
        pass
    else:
        assert False  # pragma: no cover

    # Test 2: delayed tqdm class

# Generated at 2022-06-12 14:25:55.143748
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        df = pandas.DataFrame({'a': list(range(100)), 'b': [1] * 100})
        df = df.groupby('a').progress_apply(lambda x: x)
        assert True
    except ImportError:
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:26:00.365062
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random
    from random import random
    from tqdm import tqdm_pandas, tqdm
    from tqdm.contrib.tests import is_in, is_not_in

    df = DataFrame({'a': random.randint(0, 100, 1000),
                    'b': [random() for i in range(1000)]})

    tqdm_pandas(tqdm())

    # Check that `tqdm` is registered with `progress_apply`
    with tqdm(total=100) as pbar:
        assert is_in(pbar,
                     df.groupby('a').progress_apply(lambda x: x + 1))

    # Check that `tqdm` is unregistered with `progress_apply`

# Generated at 2022-06-12 14:26:05.875057
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    >>> import pandas as pd
    >>> import tqdm
    >>> tqdm.pandas()
    >>> def test_func(df):
    ...     return df
    >>> df = pd.DataFrame([1, 2, 3])
    >>> df.groupby(0, group_keys=False).progress_apply(test_func)
    ...       0
    0  1
    1  2
    2  3
    """
    pass

# Generated at 2022-06-12 14:26:15.334097
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    # Create pandas data frame
    n = 10
    df = pd.DataFrame({
        'A': pd.Series(np.random.randn(n)),
        'B': pd.Series(np.random.randn(n)),
        'C': pd.Series(np.random.randn(n))
    })
    # Test with 'nested' tqdm instances
    tqdm_pandas(tqdm(total=len(df)))
    # Test with nested decorator
    @tqdm_pandas
    def _():
        return df.groupby('A').progress_aggregate(np.mean)
    _()
    # Test with nested decorator with tqdm instances as arguments

# Generated at 2022-06-12 14:26:22.275218
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        # Unit test
        import numpy as np
        df = pd.DataFrame(np.random.randint(0, 100, (100000, 4)),
                          columns=list('ABCD'))

        # Register `tqdm` with `pandas.progress_apply`
        tqdm_pandas(tqdm())

        # Now you can use `progress_apply` instead of `apply`
        df.groupby('A').progress_apply(lambda x: x**2)
    except:
        pass

test_tqdm_pandas()
del test_tqdm_pandas