

# Generated at 2022-06-12 14:16:32.446120
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if MULTI_PROCESSING_AVAILABLE:
        import pandas as pd
        from pandas import DataFrame
        from pandas.core.groupby import DataFrameGroupBy

        import tqdm

        n_rows, n_cols = 100, 10

        with tqdm.tqdm_pandas(leave=False) as t:
            df = DataFrame(
                {
                    'A': [1, 2, 3] * n_rows,
                    'B': [4, 5, 6] * n_rows
                })

            # `df.groupby('A')` is a `DataFrameGroupBy` instance
            # which is a `pandas.core.groupby.DataFrameGroupBy` subclass
            assert isinstance(df.groupby('A'), DataFrameGroupBy)

            #

# Generated at 2022-06-12 14:16:39.515371
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        print('\nPlease install `pandas` to test `tqdm_pandas`')
    else:
        import os
        import re
        import itertools
        import contextlib
        import tempfile

        # Fake data
        df = pandas.DataFrame([[1, 2, 3], [4, 5, 6]],
                              columns=['a', 'b', 'c'])

        # Regression test: assert that tqdm_pandas does not cause recursion
        tqdm_pandas(tqdm_pandas)

        @contextlib.contextmanager
        def capture_tqdm(tclass, **tqdm_kwargs):
            saved_stdout = tempfile.TemporaryFile()
            tqdm_

# Generated at 2022-06-12 14:16:46.957351
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    with tqdm_pandas() as t:
        pd.DataFrame({'a': [1, 2, 3], 'b': [10, 20, 30]}).progress_apply(lambda x: x**2)
        pd.DataFrame({'a': [1, 2, 3], 'b': [10, 20, 30]}).progress_apply(lambda x: x**2, axis=1)
        pd.DataFrame({'a': [1, 2, 3], 'b': [10, 20, 30]}).groupby('a').progress_apply(lambda x: x**2)

# Generated at 2022-06-12 14:16:53.154830
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm._tqdm import tqdm

    df = pd.DataFrame([x for x in range(1000)])
    tqdm_pandas(tqdm, total=df.shape[0])
    df.groupby(by=[0] * df.shape[0]).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:16:56.765638
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tclass=tqdm, total=10)
    # delayed
    tqdm_pandas(tclass=type(tqdm(total=10)))
    tqdm_pandas(tclass=type(tqdm(total=10)), total=10)

# Generated at 2022-06-12 14:17:06.365177
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tnrange
    from tqdm._utils import _decr_instances

    N = 1000000

    @tqdm_pandas
    def test_func(df):
        pd.DataFrame(np.random.random((df.shape[0], df.shape[1])))
        return df

    with tnrange(10, desc='tqdm_pandas') as t:
        for _ in t:
            df = pd.DataFrame(np.random.random((N, 3)))
            test_func(df).compute()
            t.update()

    # .progress_apply() method

# Generated at 2022-06-12 14:17:14.720663
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    for _ in tqdm_pandas(tqdm(), file=None) \
            (pd.Series(range(10000)).groupby(lambda x: x % 100)
             .progress_apply(lambda x: x.sum())):
        pass
    for _ in tqdm_pandas(tqdm, file=None) \
            (pd.Series(range(10000)).groupby(lambda x: x % 100)
             .progress_apply(lambda x: x.sum())):
        pass

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:22.965410
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    dataframe = pd.DataFrame({'col_1': [1, 2, 3], 'col_2': [2, 3, 4]})
    tqdm_pandas(tqdm())
    dataframe.groupby('col_1').progress_apply(lambda x: x)
    tqdm_pandas(tqdm(leave=False))
    dataframe.groupby('col_1').progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:28.814908
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    with tqdm(total=1) as t:
        df = DataFrame({'x': [1,2,3,4], 'y': [1,2,3,4]})
        tqdm_pandas(t)
        df.groupby('x').progress_apply(lambda x: x)
        df.progress_apply(lambda x: x)


if __name__ == "__main__":
    # Test
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:40.014732
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm as tq
    from tqdm.pandas import tqdm_pandas

    # Initial DataFrame
    df = pd.DataFrame({'a': [1] * 10, 'b': [2] * 10, 'c': [3] * 10})

    # Test with no tqdm instance
    res = df.groupby('a').progress_apply(int)
    assert isinstance(res, pd.DataFrame)

    # Test with tqdm instance
    with tqdm_pandas(tq) as tt:
        _ = df.groupby('a').progress_apply(int) == df.groupby('a').apply(int)

    # Test with tqdm instance (without getattr)

# Generated at 2022-06-12 14:17:50.942756
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    import pandas

    with tqdm_pandas(trange(10, desc='test', leave=True)) as t:
        for _ in t:
            pass

    def f(x):
        return x ** 2
    df = pandas.DataFrame(dict(a=range(10)))
    with tqdm_pandas(total=len(df), desc='foo') as t:
        res = df.groupby('a').progress_apply(f)
    assert isinstance(res, pandas.core.groupby.DataFrameGroupBy)

if __name__ == '__main__':
    test_tqdm_pandas()
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:17:56.641629
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    sys.modules['pandas'] = __import__('tqdm', fromlist=['tqdm'])
    from tqdm.auto import tqdm, trange
    from tqdm.contrib import DummyTqdmFile
    # import warnings
    # warnings.simplefilter('ignore', category=TqdmDeprecationWarning)

    try:
        tqdm_pandas(DummyTqdmFile())
    except TypeError:
        pass
    except TqdmDeprecationWarning:
        pass

    try:
        tqdm_pandas(tqdm(file=DummyTqdmFile()))
    except TypeError:
        pass
    except TqdmDeprecationWarning:
        pass


# Generated at 2022-06-12 14:18:05.489947
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # test for case `tqdm_pandas(tqdm, ...)`
    import tqdm
    tqdm.tqdm_pandas(tqdm, total=10)
    # test for case `tqdm_pandas(tqdm(...))`
    tqdm.tqdm_pandas(tqdm(total=10))


tqdm_pandas.__doc__ = """
Registers the given `tqdm` instance with
`pandas.core.groupby.DataFrameGroupBy.progress_apply`.

Deprecated (will be removed in v4.8.0)
""".format(
    file=__file__,
)



# Generated at 2022-06-12 14:18:11.988504
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame

    tpb = tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:18:23.328177
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import pandas.util.testing as pdt

    from tqdm import tqdm_notebook, tqdm_pandas

    # progress reporting via progress bar
    tqdm_pandas(tqdm_notebook)

    # Unit test
    def ptest(*args, **kwargs):
        return args, kwargs

    df = pdt.makeDataFrame()
    pd.core.groupby.DataFrameGroupBy.progress_apply = ptest


# Generated at 2022-06-12 14:18:34.803440
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    # Initialize test df
    numpy.random.seed(0)
    df = pandas.DataFrame({'a': numpy.random.randint(0, 100, size=1000),
                           'b': numpy.random.randint(0, 100, size=1000)})
    # Test tqdm_pandas
    try:
        import tqdm
    except (ImportError, OSError, IOError):
        pass
    else:
        # Assert that tqdm_pandas cannot be used without any arguments
        try:
            tqdm_pandas()
        except TypeError:
            pass
        else:
            raise Exception("The function 'tqdm_pandas' should raise an exception if called without arguments.")
        # Assert that

# Generated at 2022-06-12 14:18:40.806814
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm._utils import _range, _unich, _term_move_up
    from io import StringIO
    from tqdm.autonotebook import tqdm

    # --- Test functions ---
    def _map_apply(self, f, ufunc=False, **kwargs):
        def func(x):
            try:
                return f(x)
            except Exception:
                return f(pd.DataFrame(x))

        return self._groupby_apply(func, f, ufunc=ufunc, **kwargs)

    # emulates pandas.core.groupby.DataFrameGroupBy.progress_apply
    # https://github.com/pandas-dev/pandas/blob/fdc6a3d/p

# Generated at 2022-06-12 14:18:52.376787
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:19:02.702486
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import pandas.core.groupby
    import pandas.core.frame
    import numpy as np
    import pickle
    import time

    df = pd.DataFrame({'col_' + str(i): np.random.random(100)
                       for i in range(3)})

    def test_func(df):
        time.sleep(0.01)
        return df

    dfgp = df.groupby(df.index // 10, sort=False)

    with tqdm_pandas(dfgp, unit_scale=True, desc='Doing very important stuff',
                     mininterval=0.5) as t:
        newdf = dfgp.progress_apply(test_func)  # will automatically call tqdm.update()

    # test for DataFrameGroupBy

# Generated at 2022-06-12 14:19:13.135457
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas
    from numpy import random

    tqdm.pandas(tqdm)

    # Create sample data
    df = pandas.DataFrame(data=random.randint(1, 10, (100000, 3)),
                          columns=['A', 'B', 'C'])

    df.groupby('A').progress_apply(sum)
    df.progress_apply(sum, axis=1)
    df.progress_apply(sum, axis=0)

    tqdm.pandas(tqdm)
    df.groupby('A').progress_apply(sum)
    df.progress_apply(sum, axis=1)
    df.progress_apply(sum, axis=0)

    tqdm.pandas(tqdm.tqdm)
   

# Generated at 2022-06-12 14:19:25.591938
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    pd = pandas.DataFrame({'x': range(10000), 'y': range(10000)})
    tqdm_pandas(pd.groupby('x').progress_apply(sum))
    tqdm_pandas(pd.groupby('x').progress_apply(sum, meta=('result', int)))
    tqdm_pandas(pd.groupby('x').progress_apply(pd.DataFrame.sum))
    tqdm_pandas(pd.groupby('x').progress_apply(pd.DataFrame.sum,
                                               meta=('result', pandas.Series)))

# Generated at 2022-06-12 14:19:36.617537
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_tqdm_pandas.tqdm_pandas_test_ok = True
    test_tqdm_pandas.tqdm_pandas_test_data = pd.DataFrame({'x': [0] * 20, 'y': [1] * 2})

    def test_func(df):
        return df.x + df.y

    test_tqdm_pandas.tqdm_pandas_test_data.groupby(
        'x').progress_apply(test_func).sum()

# Test for `tqdm.pandas(...)`
# Test for `tqdm_pandas(tqdm(...))`
test_tqdm_pandas()


# Generated at 2022-06-12 14:19:41.216819
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    s = pd.Series(
        np.random.randn(1000))
    s.groupby(lambda _: np.random.randint(
        2)).progress_apply(lambda x: np.sqrt(x.sum())).sum()

# Test for #651

# Generated at 2022-06-12 14:19:45.987433
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    # Python 2
    import tqdm as tqdm
    tqdm_pandas(tqdm)
    if hasattr(tqdm, "tqdm"):
        tqdm_pandas(tqdm.tqdm)
    df = pd.DataFrame({
        'A': pd.Series(np.random.randn(1024)),
        'B': pd.Series(np.random.randn(1024)),
    })
    df.groupby(0).progress_apply(lambda x: x)

# Generated at 2022-06-12 14:19:54.311758
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if 'pandas' not in globals():
        return

    df = pandas.DataFrame(pandas.np.random.rand(1e4, 1e2))
    ncols = df.shape[1]

    # regression test: check that pandas' DataFrameGroupBy.progress_apply
    # correctly handles the kwargs we attempt to pass
    with tqdm(total=ncols) as t:
        df.groupby(level=0).progress_apply(
            lambda x: sum(x), meta=['sum']).apply(lambda x: t.update())

# Generated at 2022-06-12 14:20:04.434589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        np = pd.np
    except ImportError:
        return
    N = 1e2
    df = pd.DataFrame({
        'a': np.arange(N),
        'b': 1,
    }).set_index('a')
    total = N
    with closing(StringIO()) as our_file:
        with tqdm.__main__.Tqdm(total=total, file=our_file, disable=None) as t:
            prog = tqdm_pandas(t, smoothing=0)
            for _ in df.groupby('b').progress_apply(
                    lambda block: block.index.values.sum(),
                    group_keys=False,
                    progress_kwargs={'total': total}):
                t.update()

# Generated at 2022-06-12 14:20:11.327519
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:20:15.691596
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    # Initializing test Dataframe
    test_df = pd.DataFrame({'a': [5] * 100, 'b': [6] * 100, 'c': [7] * 100})

    # Creating a tqdm instance for testing
    test_tqdm = tqdm(total=len(test_df.index))

    # Calling tqdm_pandas function
    tqdm_pandas(test_tqdm)

    # Initializing progress_apply
    def test_sum(x, y):
        return x + y

    # Applying progress_apply to test_df
    test_df.progress_apply(lambda row: test_sum(row['a'], row['b']), axis=1)
    return None



# Generated at 2022-06-12 14:20:23.877342
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from numpy.random import random
    from random import choice
    from string import ascii_letters
    from time import sleep

    df = DataFrame(random((10000, 10000)))
    df['test'] = df.progress_apply(lambda _: 1, axis=1)
    df['test2'] = df.progress_apply(lambda _: 1, axis=1)
    df = df.progress_apply(lambda _: 1, axis=0)
    df.apply(lambda _: sleep(0.01), axis=1).progress_apply(lambda _: 1, axis=1)

# Generated at 2022-06-12 14:20:32.756081
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm

    def fun(df):
        """
        Function toy simulated
        """
        return pd.Series([1, 2], index=['one', 'two'])

    df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 4)),
                      columns=list('ABCD'))

    # Note that the `miniters` parameter
    # is crucial to improve performance.
    tqdm_pandas(tqdm)
    df.groupby('A').progress_apply(fun)

# Generated at 2022-06-12 14:20:46.709579
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_notebook, trange

    for i in trange(3):
        df = pd.DataFrame({'x': range(1000)})
        tqdm(df.groupby('x').progress_apply(lambda x: x))
        tqdm_notebook(df.groupby('x').progress_apply(lambda x: x))


if __name__ == '__main__':
    from tqdm import tqdm, TqdmExperimentalWarning
    with tqdm.external_write_mode():
        test_tqdm_pandas()
    with tqdm.external_write_mode():
        test_tqdm_pandas()

# Generated at 2022-06-12 14:20:57.073092
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        tqdm_pandas(5)
    except TypeError:
        pass
    else:
        raise Exception('tqdm_pandas(5) should raise TypeError')
    tqdm_pandas(tqdm, total=10)
    tqdm_pandas(tqdm(total=10), total=2)
    from tqdm import tqdm_pandas
    # Support delayed instantiation:
    tqdm_pandas.pandas(total=2)
    pd.DataFrame(range(1000)).groupby(0).progress_apply(lambda x: x)

# Generated at 2022-06-12 14:21:04.478934
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm, tqdm_pandas

    df = DataFrame({'a': range(10), 'b': range(10, 20)})
    tqdm_pandas(tqdm())  # enable progress bar on pandas
    df.groupby('a').progress_apply(lambda x: x['b'].sum())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:09.590443
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import argparse
    parser = argparse.ArgumentParser(description='test of tqdm_pandas')
    parser.add_argument('-p', '--pandas')
    args = parser.parse_args()

    # Dummy test for function tqdm_pandas

# Generated at 2022-06-12 14:21:15.985350
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.contrib import pandas

    def foo(df):
        return df

    df = pd.DataFrame({'num_legs': [2, 4], 'num_wings': [2, 0]}, index=['falcon', 'dog'])
    print(df.groupby('num_legs').progress_apply(foo))



# Generated at 2022-06-12 14:21:25.239826
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from random import random
    from time import sleep

    def random_gen():
        for i in range(100):
            sleep(0.01)
            yield random()

    t = pd.DataFrame(
        {'A': random_gen(),
         'B': random_gen()}
    )


    with tqdm(total=len(t)) as pbar:
        def my_apply(x):
            pbar.update()
            return x

        assert isinstance(
            t.progress_apply(my_apply, axis=1), type(t))

    tqdm.write("Success!")



# Generated at 2022-06-12 14:21:33.522082
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    import numpy as np

    df = DataFrame(np.random.randint(0, 100, (10000, 26)), columns=list(map(chr, range(65, 91))))

    def under_test(x):
        return x

    def test_df_progress_apply(df, func=under_test, **tqdm_kwargs):
        return df.progress_apply(func, axis=1, **tqdm_kwargs)

    # test 1: tqdm object
    tqdm_pandas(tqdm())
    assert test_df_progress_apply(df).equals(df)

    # test 2: tqdm class
    tqdm_pandas(tqdm)
    assert test_df_progress

# Generated at 2022-06-12 14:21:44.300694
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def test_tqdm_deprecated_warning():
        import tqdm
        import warnings
        with warnings.catch_warnings(record=True) as w:
            # Cause all warnings to always be triggered.
            warnings.simplefilter("always")
            # Trigger a warning.
            tqdm_pandas(tqdm.tqdm())
            # Verify some things
            assert len(w) == 1
            assert issubclass(w[-1].category, tqdm.TqdmDeprecationWarning)
            assert "Please use `tqdm.pandas(...)`" in str(w[-1].message)
    test_tqdm_deprecated_warning()
    try:
        from pandas import DataFrame
    except ImportError:
        from pandas import core

# Generated at 2022-06-12 14:21:53.105329
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import trange, tqdm

    def test_tqdm_pandas_t(t):
        # regression test for GH-1094
        df = pd.DataFrame({'x': np.random.randint(0, 1000, 10000)})
        df.groupby('x').progress_apply(lambda x: x)

    with trange(3, desc='Testing tqdm_pandas',
                miniters=0, mininterval=0, maxinterval=0, ascii=True) as t:
        test_tqdm_pandas_t(t)


# Generated at 2022-06-12 14:21:58.560982
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame
    from sys import stdout

    with tqdm(DataFrame(range(100))[0], file=stdout) as t:
        for x in t:
            num = x

    with tqdm(total=100) as t:
        for x in range(100):
            t.update()

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:06.920893
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)



# Generated at 2022-06-12 14:22:17.592943
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import Series, DataFrame
    from tqdm import tqdm as _tqdm

    with _tqdm(pandas=True) as pbar:
        for i in range(10):
            # pbar.update()
            assert hasattr(pbar, 'update')

    with _tqdm(pandas=True) as pbar:
        # pbar.update()
        assert hasattr(pbar, 'update')

    tqdm = _tqdm
    tqdm_pandas(tqdm)
    with tqdm(pandas=True) as pbar:
        for i in range(10):
            # pbar.update()
            assert hasattr(pbar, 'update')


# Generated at 2022-06-12 14:22:28.390628
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:22:33.173914
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame([[np.nan, 2, np.nan, 0],
                       [3, 4, np.nan, 1],
                       [np.nan, np.nan, np.nan, 5],
                       [np.nan, 3, np.nan, 4]],
                      columns=list('ABCD'))
    # register the instance `tqdm`
    tqdm_pandas(tqdm.tqdm)
    # test pandas.core.groupby.DataFrameGroupBy.progress_apply
    result = df.groupby('A').progress_apply(lambda x: x ** 2)
    # test pandas.core.groupby.DataFrameGroupBy.progress_agg

# Generated at 2022-06-12 14:22:40.588317
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    try:
        pd = pandas.DataFrame({"a": range(1000000)})
        pd.groupby("a").progress_apply(lambda x: x)
    except AttributeError:
        pass
    else:
        raise AssertionError("tqdm_pandas didn't remove the attribute, did"
                             " you forget to decorate?")


# Pip version checker

# Generated at 2022-06-12 14:22:48.216874
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    import tqdm
    import sys

    df = pd.DataFrame({
        'a': np.arange(10000),
        'b': np.arange(10000),
        'c': np.arange(10000),
    })

    # progress apply
    f = lambda x: time.sleep(0.001)
    # with tqdm_pandas():
    #    df.groupby(['a', 'b', 'c']).progress_apply(f)

    # direct apply

# Generated at 2022-06-12 14:22:58.695841
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange, trange
    from tqdm.contrib.concurrent import process_map

    for tt in [tnrange, trange]:
        for pd in [pd, pd]:
            try:
                import pandas as pd
                break
            except ImportError:
                pass
        else:
            raise ImportError('pandas not found')

        df = pd.DataFrame({'a': [1, 2, 3], 'b': [3, 4, 5], 'c': [7, 8, 9]})
        df = pd.concat([df] * 100000, ignore_index=True)  # ~100MB

        def square(df):
            return df ** 2

        # Processes=2, desc + optional unit (dummy)

# Generated at 2022-06-12 14:23:04.089301
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert tqdm_pandas

if __name__ == "__main__":
    r"""
    CommandLine:
        python -m tqdm.contrib.test_tqdm_pandas
        python -m tqdm.contrib.test_tqdm_pandas --allexamples
        python -m tqdm.contrib.test_tqdm_pandas --allexamples --noface --nosrc
    """
    import xdoctest
    xdoctest.doctest_module(__file__)

# Generated at 2022-06-12 14:23:14.411793
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    try:
        import cProfile as profile
    except:
        import profile
    try:
        import StringIO
    except:
        import io as StringIO

    data = pd.DataFrame({'col1': [1, 2],
                         'col2': ['a', 'b']})
    stream = StringIO.StringIO()

    # Test without profiling
    tqdm_pandas(data.groupby('col1').apply(len))
    tqdm_pandas(data.groupby('col1').apply(len), file=stream)
    tqdm_pandas(data.groupby('col1').apply(len), show_percent=True)

# Generated at 2022-06-12 14:23:24.620624
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        warnings.warn("pandas not installed, could not run test on function 'tqdm_pandas()'.")
        return
    try:
        tqdm_pandas
    except NameError:
        tqdm_pandas = sys.modules[__package__ + '.tqdm_pandas']
    import numpy
    import pandas

    # Don't display useless warnings
    old_stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')

    df = pandas.DataFrame(numpy.random.rand(10000, 1), columns=['x'])
    t0 = tqdm_pandas(total=len(df))

# Generated at 2022-06-12 14:23:47.573967
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({"a": list(range(100)), "b": list(range(100))})
    df[["a", "b"]] = df[["a", "b"]].progress_apply(
        lambda x: x ** 2, tclass=tqdm.tqdm)
    df[["a", "b"]] = tqdm.tqdm(df[["a", "b"]])
    df[["a", "b"]] = tqdm_pandas(tqdm.tqdm, df[["a", "b"]])


if __name__ == '__main__':
    from tqdm import trange
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:54.764445
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np
    import sys
    with tqdm_pandas(tqdm(total=100)) as tp:
        df = pd.DataFrame(np.random.randn(100, 1000))
        df.progress_apply(lambda x: x ** 2, axis=1)
        assert tp.total == 100


if __name__ == '__main__':
    from .tqdm import tqdm
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:02.256188
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_notebook as tqdm
    for _t in [tqdm, tqdm.tqdm]:
        # tqdm(desc="") is deprecated in tqdm v4.36.0
        _t().close()
        tqdm_pandas(_t)
        # Test:
        df = pd.DataFrame([[1, 2], [3, 4]])
        df[df.columns[:1]] = df.progress_apply(lambda x: x**2, axis=1)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:10.979204
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    import warnings

    # delayed tqdm_pandas
    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm)
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)

    # with tqdm
    with tqdm.tqdm(deprecated=False) as t:
        tqdm_pandas(t)
        assert len(t.dynamic_messages) == 1
        assert "deprecated" in t.dynamic_messages[-1]

    # with tqdm_notebook

# Generated at 2022-06-12 14:24:22.792785
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests `tqdm_pandas` function.
    """
    from tqdm import tqdm
    from ..tests._utils_tests import _try_interrupt_test

    for tclass in [tqdm,
                   tqdm(total=1, desc="test")]:
        try:
            tqdm_pandas(tclass)
        except Exception as e:
            raise (e)

    # Test deprecation warning
    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm)
        assert len(w) == 1
        assert w[0].category is TqdmDeprecationWarning

# Generated at 2022-06-12 14:24:29.766414
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    import numpy as np

    from tqdm import tqdm
    from tqdm._utils import _term_move_up

    tqdm_pandas(tqdm)

    try:
        from tqdm import tnrange
    except ImportError:
        pass
    else:
        tqdm_pandas(tnrange)

    def myrange(n):
        for i in range(n):
            yield i

    def myrange_fixed(n):
        return iter(range(n))

    def myrange_fixed_2(n):
        return range(n)

    df = pandas.DataFrame(dict(a=np.random.randint(0, 100, 100)))
    df.groupby("a").progress

# Generated at 2022-06-12 14:24:39.197408
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    from tqdm import tqdm

    def func(x):
        return x

    df = pd.DataFrame({'a': [1, 2, 3]})
    with tqdm(total=len(df)) as t:
        df.progress_apply(func, axis=1, args=(t,))
        assert t.n == t.total
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm)
    tqdm_pandas()

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:45.356356
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    df = pd.DataFrame({'x': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]})
    pbar = tqdm_pandas(tqdm)
    res = df.groupby('x').progress_apply(lambda x: x**2)  # doctest: +SKIP
    assert res.tolist() == [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
    pbar.close()

# Generated at 2022-06-12 14:24:51.483323
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    import time

    data = pd.DataFrame({'A': np.random.randn(100),
                         'B': np.random.randn(100)},
                        index=range(100))

    tqdm.tqdm_pandas(tqdm.tqdm(total=len(data)))
    progress = tqdm_pandas(tqdm.tqdm(total=len(data)))

    def func(x):
        time.sleep(0.01)
        return x

    # test SeriesGroupBy.progress_apply
    data.progress_apply(func, axis=0)
    data.progress_apply(func, axis=0)

    # test DataFrameGroupBy.progress_apply

# Generated at 2022-06-12 14:25:00.763763
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import *
    import numpy as np
    from tqdm._utils import _term_move_up

    n = 5
    rng = np.arange(n)
    test_series = Series(rng)
    test_groupby = test_series.groupby(test_series)
    assert [i for i in test_groupby] == [
        (0, Series([0], dtype=object)),
        (1, Series([1], dtype=object)),
        (2, Series([2], dtype=object)),
        (3, Series([3], dtype=object)),
        (4, Series([4], dtype=object)),
    ]

    progress = Series([0], dtype=object)

    def progress_apply_append(x, progress=progress):
        progress.iloc[0]

# Generated at 2022-06-12 14:25:38.364073
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange, tqdm
    try:
        from pandas import DataFrame
    except ImportError:
        # Skip tests if pandas is not available
        return
    tk = tnrange(10)
    tqdm_pandas(tk)

    df = DataFrame({'x': [1, 2]})
    list(df.groupby('x').progress_apply(len))

    tqdm_pandas(tclass=tk)

    tk = tqdm(total=10)
    tqdm_pandas(tk)
    tqdm_pandas(tclass=tk)

    tk = tqdm(total=10, bar_format='{l_bar}')
    tqdm_pandas(tk)
    tqdm_pand

# Generated at 2022-06-12 14:25:44.613836
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    assert tqdm_pandas(tqdm(42)) == tqdm(42).pandas()
    assert tqdm_pandas(tqdm) == tqdm.pandas()
    assert tqdm_pandas(tqdm) == tqdm.pandas()

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:47.181020
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        tqdm_pandas(pd.core.groupby.DataFrameGroupBy.progress_apply)
    except:
        pass

# Generated at 2022-06-12 14:25:54.096483
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    # Unit test for function tqdm_pandas
    l = list(range(10))
    df = pandas.DataFrame(l, columns=['a'])
    with closing(StringIO()) as our_file:
        with tqdm_pandas(our_file) as t:
            df.progress_apply(lambda x: x**2, axis=1)
            t.update()
    assert our_file.getvalue()

# Generated at 2022-06-12 14:26:04.064592
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    with warnings.catch_warnings(record=True) as warn_list:
        tqdm_pandas(tqdm(**tqdm_kwargs))
    assert len(warn_list) == 1
    assert issubclass(warn_list[-1].category, TqdmDeprecationWarning)
    assert re.search(r'\btype\(tclass\).pandas\(deprecated_t=tclass\)',
                     str(warn_list[-1].message))
    assert re.search(r'<tqdm .+?>', str(warn_list[-1].message))

    # delayed adapter case
    del warn_list[:]

# Generated at 2022-06-12 14:26:12.962976
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy.random import choice, random, randint
    from tqdm import tqdm
    from time import sleep

    def test_func(x):
        sleep(.5)
        return x.sum()

    df = DataFrame({'a': choice(100, 1000)})
    s = Series(random(1000))

    def run_tests(t):
        tclass = t()
        tclass.pandas(df)
        tclass.pandas(s, total=len(s))
        tclass.pandas(s, total=len(s), desc='series', leave=False)
        tqdm.pandas(df)
        tqdm.pandas(s, total=len(s))

# Generated at 2022-06-12 14:26:15.711813
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    tqdm.pandas()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:26:23.790548
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    assert not hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply')
    from tqdm import tqdm
    import tqdm.pandas
    assert not hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply')
    tqdm_pandas(tqdm.tqdm, leave=False)
    assert hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply')
    tqdm_pandas(tqdm, leave=False)
    assert hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply')
    tqdm(leave=False).pandas()