

# Generated at 2022-06-12 14:16:34.001968
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    import pytest
    from tqdm.pandas import tqdm_pandas

    df = pd.DataFrame(np.random.randn(1000, 4), columns=list('ABCD'))
    df.progress_apply(np.square)

    df = pd.DataFrame(np.random.randn(1000, 4), columns=list('ABCD'))
    with pytest.raises(AttributeError):
        tqdm_pandas(tqdm).progress_apply(np.square, df)
    with pytest.raises(TypeError):
        tqdm_pandas(tqdm, df=df).progress_apply(np.square)

# Generated at 2022-06-12 14:16:40.694698
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:16:49.637557
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas
    """

# Generated at 2022-06-12 14:16:58.826719
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame({'A': [1, 2, 3], 'B': [2, 3, 4], 'C': [3, 4, 5]})
    ### Test `for iter in pandas.core.groupby.DataFrameGroupBy.progress_iter` ###
    # This test also supports delayed adapter case
    # (such as `tqdm_pandas(tqdm)`).
    from tqdm.contrib import pandas as tqdm_pandas
    for _ in tqdm_pandas(df.groupby(['A'])):
        assert True
    for _ in tqdm_pandas(tqdm_pandas)(df.groupby(['A'])):
        assert True

# Generated at 2022-06-12 14:17:07.244728
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    with tqdm(total=4, ncols=100, mininterval=0.1, smoothing=0) as pbar:
        pd.DataFrame({'a': np.random.randint(0, 100, 50),
                      'b': np.random.randint(0, 100, 50)}).groupby('a').progress_apply(
            lambda x: sum(x), pbar=pbar)
    print('')


# Register the function tqdm_pandas with pandas.core.groupby.DataFrameGroupBy.progress_apply

# Generated at 2022-06-12 14:17:16.855400
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    from pandas import DataFrame
    from pandas import Series
    from pandas import concat

    df = DataFrame(np.random.randn(100, 4),
                   columns=list('ABCD'),
                   index=pd.date_range('20130101', periods=100, freq='min'))
    df = concat([df, df], keys=list('XY'), sort=False)
    df.sort_index(axis=1, inplace=True)
    X = df.iloc[[1, 3, 5, 7, 9], :]

    with tqdm(total=X.shape[0]) as t:  # initialise
        X.groupby(X.index.minute).progress_apply(lambda x: t.update())  # apply


# Generated at 2022-06-12 14:17:25.170646
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import Series
    from pandas import DataFrame
    import numpy as np
    from tqdm import tqdm

    def f(x):
        x.shape

    TEST_N = 10 ** 2 * int(tqdm._instances.get('total', 1))
    TEST_DF = DataFrame({'a': np.zeros(TEST_N)})
    TEST_S = Series(np.zeros(TEST_N))

    print('Test df:')
    print(TEST_DF.head())
    print('Test s:')
    print(TEST_S.head())

    test_df = TEST_DF.groupby(0).progress_apply(f)
    test_s = TEST_S.groupby(0).progress_apply(f)

   

# Generated at 2022-06-12 14:17:32.552906
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm
    from tqdm import trange
    from pandas import DataFrame

    def test_func(x):
        return np.sum(x)

    df = DataFrame(data=np.random.randint(0, 100, [3, 3]))
    pd_result = df.groupby(0).progress_apply(test_func)
    tqdm_pandas(tqdm)
    tq_result = df.groupby(0).progress_apply(test_func)
    assert (pd_result == tq_result).all()
    tqdm_pandas(trange)
    tq_result = df.groupby(0).progress_apply(test_func)

# Generated at 2022-06-12 14:17:42.792055
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas, tnrange, tqdm_notebook
    from pandas import DataFrame, Series
    import numpy as np
    import optparse

    parser = optparse.OptionParser(
        usage='Usage: python -m tqdm %s' % __file__)
    parser.add_option('--pandas', dest='pandas', default=True,
                      action='store_true', help='Pandas tests')
    parser.add_option('--nopandas', dest='pandas', action='store_false',
                      help='Pandas tests')

    (options, args) = parser.parse_args()

    if options.pandas:
        import pandas as pd

# Generated at 2022-06-12 14:17:48.408985
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Make sure it's not broken in case of reimport
    import pandas as pd
    tqdm_pandas(pd.DataFrame(range(10)).groupby(0).progress_apply(lambda x: x))
    tqdm_pandas(pd.DataFrame(range(10)).groupby(0))
    tqdm_pandas(pd.DataFrame)



# Generated at 2022-06-12 14:17:57.891791
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm
    from tqdm import trange
    from time import sleep

    def g(x):
        sleep(0.01)
        return x

    df = pd.DataFrame({'a': [1, 2],
                       'b': [10, 20]})
    # with tqdm_pandas(tqdm(ncols=100)) as t:  # can use `with` statement
    t = tqdm_pandas(tqdm(ncols=100))
    for i in trange(4, desc='bar', file=sys.stdout):
        df['c'] = df['a'].progress_apply(g)
    print(df)



# Generated at 2022-06-12 14:18:06.308009
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    num_rows = 1000000
    num_cols = 3
    tqdm_pandas(tqdm)
    df = pd.DataFrame(np.random.random((num_rows, num_cols)))

    result = df.groupby(0).progress_apply(lambda x: x ** 2)
    del result  # for coverage
    result = df.progress_apply(lambda x: x + 1)
    del result  # for coverage


if __name__ == "__main__":
    from tqdm import tqdm
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:17.080734
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def test_dfg(df):
        s = 0
        for i in range(1000000):
            s += i * i * (i % 10)
        return df * s

    df = pd.DataFrame(data=[1, 2, 3, 4])
    pd.DataFrame(data=[1, 2, 3, 4]).progress_apply(test_dfg)

    import tqdm
    tqdm.pandas()
    pd.DataFrame(data=[1, 2, 3, 4]).progress_apply(test_dfg)
    tqdm.pandas(desc="bar", leave=False)
    pd.DataFrame(data=[1, 2, 3, 4]).progress_apply(test_dfg)

    import warnings

# Generated at 2022-06-12 14:18:22.216053
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    with tqdm(total=100) as t:
        tqdm_pandas(t)
        df = pd.DataFrame(dict(a=range(100), b=range(100)))
        df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-12 14:18:34.640558
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    class TqdmTest(str):
        """
        Test class providing attributes of the `tqdm` class.
        """

        def __new__(cls, value):
            return str(value)

        def __init__(self, value):
            self.fp = sys.stderr
            self.is_notebook = False
            self.position = -1
            self.last_print_t = 0
            self.total = 42  # Test if attribute is transferred.
            self.reset()
            self.update_to(value + 1)

        def reset(self):
            self.n = 0
            self.dynamic_ncols = True
            self.smoothing = 0.1
            self.format_dict = {}


# Generated at 2022-06-12 14:18:40.700994
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame([[i] for i in range(100)])
    for cls in (tqdm_pandas, tqdm.tqdm):
        t = cls(total=len(df), desc='test')
        tqdm_pandas(t)

        def func(x):
            return x + 1
        g = df.groupby(0)
        l = g.progress_apply(func)
        assert (l == g.apply(func)).all()



# Generated at 2022-06-12 14:18:52.193731
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from distutils.version import StrictVersion
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'x': np.random.randint(0, 100, 100)})
    # work with tqdm v4/v5/v6
    tqdm_pandas(tqdm)
    ret = df.groupby(df.x).progress_apply(len)
    assert (ret == pd.Series(1, index=df.x)).all()
    # work with tqdm v3
    tqdm_pandas(lambda: tqdm(desc='Apply', leave=False))
    ret = df.groupby(df.x).progress_apply(len)

# Generated at 2022-06-12 14:19:02.577999
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from .tqdm_pandas import tqdm_pandas

    df = pd.DataFrame({'a': np.arange(10000),
                       'b': np.arange(10000)})
    tqdm_pandas(tqdm())
    df.groupby('a').progress_apply(lambda x: x**x)
    tqdm_pandas(tqdm(total=100))
    df.groupby('a').progress_apply(lambda x: x**x)
    tqdm_pandas(tqdm(total=100, desc='pandas loop'))
    df.groupby('a').progress

# Generated at 2022-06-12 14:19:12.977779
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm._tqdm import TqdmTypeError
    try:
        tqdm_pandas(tqdm)
    except TqdmTypeError:
        assert 1
    try:
        tqdm_pandas(tclass=tqdm)
    except TypeError:
        assert 1
    tqdm_pandas(tqdm(desc='Testing'))
    tqdm_pandas(tqdm(desc='Testing'),
                tclass=tqdm)
    # not random but using apply is fine
    df = pd.DataFrame(
        np.random.randint(0, 100, (1000, 26)),
        columns=list(string.ascii_lowercase))

# Generated at 2022-06-12 14:19:23.788938
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(dict(a=np.random.randint(10000, size=(10000, )),
                           b=np.random.choice(['a', 'b', 'c'], size=(10000, ))))
    s = df.groupby('b').progress_apply(lambda x: x.a.sum())
    assert s.a == df.a.sum()
    tqdm_pandas(tqdm, desc='test_tqdm_pandas')
    s = df.groupby('b').progress_apply(lambda x: x.a.sum())
    assert s.a == df.a.sum()


if __name__ == '__main__':
    test_tqdm

# Generated at 2022-06-12 14:19:35.799022
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm, tqdm_pandas
    tqdm_pandas(tqdm())  # Test deprecation message
    tqdm_pandas(tqdm).pandas(tqdm())  # Test chaining deprecation message
    tqdm_pandas(tqdm())  # Test delayed adapter
    tqdm_pandas(tqdm_pandas(tqdm))  # Test chaining
    tqdm.pandas()  # Test tqdm_pandas replacement
    tqdm_pandas(tqdm).pandas()  # Test chaining tqdm_pandas replacement
    with tqdm(total=5) as t:
        tqdm_pand

# Generated at 2022-06-12 14:19:43.705577
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm as autonb_tqdm
    from tqdm.contrib.concurrent import process
    from pandas import DataFrame, Series

    df = DataFrame({'x': list(range(10))})
    for tclass in [autonb_tqdm, process.tqdm]:
        tqdm_pandas(tclass)
        assert isinstance(df.groupby('x').progress_apply(Series.sum), tclass)

if __name__ == "__main__":
    from multiprocessing import freeze_support
    freeze_support()  # for Windows
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:56.354143
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    #data = np.random.randint(1e3, size=(1e3, 4))
    data = np.random.randint(1e4, size=(1e4, 4))
    data = pd.DataFrame(data, columns=["a", "b", "c", "d"])

    # Error handling for input args
    try:
        tqdm_pandas("this is not a tqdm instance")
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError not raised")

    # Unit test with tqdm_notebook
    tqdm_pandas(tqdm, leave=True)
    data.groupby("a").progress_apply

# Generated at 2022-06-12 14:20:06.313692
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    To run this unit test run `python -m tqdm.utils tqdm_pandas`
    (or `python setup.py test`)
    """
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map, thread_map

    with tqdm(total=DataFrameGroupBy.progress_apply.__code__.co_argcount,
              desc='Testing tqdm_pandas') as pbar:
        assert callable(tqdm_pandas)

        tqdm_pandas(tqdm)
        pbar.update()
        assert hasattr(DataFrameGroupBy, 'progress_apply')

        tqdm_p

# Generated at 2022-06-12 14:20:15.918721
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    from tqdm import tqdm  # this is not required, just for demo
    #import tqdm_pandas; tqdm_pandas.tqdm_pandas(tqdm)  # enable tqdm pandas integration

    # by default progress bar position is set to last column
    # use tqdm_kwargs={'position':0} to move it to the first column

    import pandas as pd
    df = pd.DataFrame({'x': range(10)}, dtype='float')

    def progress_func(i):
        import time
        time.sleep(0.1)
        return i

    res = df.groupby(0).progress_apply(progress_func)

# Generated at 2022-06-12 14:20:20.596223
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    from tqdm.autonotebook import tqdm, tnrange
    from numpy.random import randint
    pd.DataFrame({'a': randint(0, 100, 1000)}) \
        .groupby('a')['a'] \
        .progress_apply(lambda x: x**2)

# Generated at 2022-06-12 14:20:27.071550
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit tests for function `tqdm_pandas`.
    """
    from tqdm import tqdm

    # Test with tqdm
    tqdm_pandas(tqdm())

    # Test with tqdm.tqdm
    tqdm_pandas(tqdm)

    # Test with tqdm_gui
    try:
        from tqdm import tqdm_gui
    except ImportError:
        pass
    else:
        tqdm_pandas(tqdm_gui)

    # Test with tqdm_notebook
    try:
        from tqdm import tqdm_notebook
    except ImportError:
        pass
    else:
        tqdm_pandas(tqdm_notebook)

    return

# Generated at 2022-06-12 14:20:35.507548
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    result = df.groupby("a").progress_apply(lambda x: x["b"].sum())
    assert set(result.index) == set(df["a"])
    assert set(result) == {4, 5, 6}


if __name__ == '__main__':
    try:
        from tqdm import tqdm
        tqdm_pandas(tqdm)
        test_tqdm_pandas()
    except Exception as e:
        from sys import stderr
        stderr.write("SKIP")

# Generated at 2022-06-12 14:20:46.624477
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import pandas as pd
    import numpy as np
    import time
    print('Testing tqdm_pandas...', end='')

    def func_1(x):
        time.sleep(.001)
        return x + 1

    def func_2(group):
        time.sleep(.001)
        return pd.Series([group.min(), group.max()], index=['min', 'max'])

    try:
        import pandas.core.groupby
        pandas.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas
    except ImportError:
        print('pandas is not installed.')
        return

    # Test progress_apply()

# Generated at 2022-06-12 14:20:56.985425
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import sys
    import tqdm

    try:
        tqdm_pandas(tqdm.tqdm)
    except tqdm.TqdmDeprecationWarning as e:
        assert type(e.args[0]) is str
        assert 'Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`' in e.args[0]
        assert sys.stderr.write is e.fp_write
    try:
        tqdm_pandas(tqdm.tqdm())
    except tqdm.TqdmDeprecationWarning as e:
        assert type(e.args[0]) is str

# Generated at 2022-06-12 14:21:11.368382
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Import pandas
    import pandas as pd

    # Create DataFrame
    data = pd.DataFrame(np.random.randn(10000, 4), columns=list('ABCD'))

    # create random column
    data['E'] = data['A'].cumsum()

    # Test tqdm_pandas
    tqdm_pandas(tqdm())

    # Test groupby.progress_apply
    data.groupby([data.A > 0]).progress_apply(lambda x: x)

    # Test groupby.progress_aggregate
    data.groupby([data.A > 0]).progress_agg(np.mean)

    # Test groupby.progress_transform
    data.groupby([data.A > 0]).progress_transform(lambda x: x)

# Generated at 2022-06-12 14:21:22.947399
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randint(0, 10, (10000, 3)),
                      columns=list('abc'))

    # REGRESSION (GH#1073): `tqdm_pandas` needs to work with
    #   delayed instantiation of `tqdm`
    # tqdm_pandas(tqdm.tqdm, leave=True)
    # df.groupby('a').progress_apply(lambda x: x)
    # assert len(list(globals().keys())) == 2

    # Integration test
    tqdm_pandas(tqdm.tqdm, leave=True)
    df.groupby('a').progress_apply(lambda x: x)

    # Unit test

# Generated at 2022-06-12 14:21:28.723290
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    n = 100
    df = DataFrame(data={'y': np.random.rand(n,),
                         'z': 10 * np.random.rand(n,)})
    tqdm_pandas()
    df.groupby('y').progress_apply(lambda x: x)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:21:35.327092
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm.tests.numpy.open_zip(
            tqdm.tests.numpy.TEST_FILE, mode='rb') as zipfile:
        with zipfile.open('tqdm_pandas_test', mode='r') as f:
            import pandas as pd
            df = pd.read_csv(f, sep='\t', header=None, names=['a', 'b'])
            assert list(df.groupby('a').progress_apply(lambda x: x.sum())) == list(
                df.groupby('a').apply(lambda x: x.sum()))


if __name__ == "__main__":
    import pandas as pd

# Generated at 2022-06-12 14:21:42.861093
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy.random import randint

    with tqdm_pandas(unit='vals', smoothing=0) as t:
        for i in range(1000):
            DataFrame(randint(0, 100, (1000, 1000))).progress_apply(lambda x: x + i)
            assert t.n == i + 1
            assert t.last_print_n == i + 1


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:49.998489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for the DeprecationWarning due to the use of tqdm_pandas.

    Tested by passing TClass as the argument to tqdm_pandas, which
    should call the deprecated function.
    """
    import warnings

    tclass = tqdm(range(100), desc='1')

    with warnings.catch_warnings(record=True) as w:
        warnings.resetwarnings()
        warnings.simplefilter('always')
        tqdm_pandas(tclass)

        assert len(w) == 1
        assert issubclass(w[0].category, TqdmDeprecationWarning)
        assert "tqdm_pandas" in str(w[0].message)

    with warnings.catch_warnings(record=True) as w:
        warnings.resetwarnings()


# Generated at 2022-06-12 14:21:59.173058
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas

    df = pd.DataFrame(np.random.randn(10000, 1), columns=['col1'])
    with tqdm(total=len(df), leave=False, unit_scale=True) as t:
        df.progress_apply(t.update)
        assert t._n_iter == len(df) + 1
    tqdm_pandas(tqdm())
    with tqdm(total=len(df), leave=False, unit_scale=True) as t:
        df.progress_apply(t.update)
        assert t._n_iter == len(df) + 1
    tqdm_pandas(tqdm(), desc='foo')


# Generated at 2022-06-12 14:22:03.531015
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .tests._utils import _range
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy import random
    from random import randint

    for cls in [tqdm, tqdm._instances[0]]:
        pd_df = DataFrame.from_dict({"x": random.randint(1000, size=1000)})
        pd_df.progress_apply(lambda x: _range(randint(1, 10000)), axis=1)

# Generated at 2022-06-12 14:22:10.695398
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        pd = None
    if pd:
        # Test for delayed import
        from tqdm._tqdm_pandas import tqdm_pandas as tp
        from tqdm import tqdm
        tp(tqdm)
        df = pd.DataFrame({'A': [0] * 100, 'B': [0] * 100})
        tp(tqdm, desc='Test tqdm_pandas')
        df.groupby('A').progress_apply(lambda x: x)
        tp(tqdm)(df.groupby('A').progress_apply(lambda x: x))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:21.826892
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pytest
    import sys
    import pandas as pd
    from pandas.testing import assert_frame_equal

    sys.stderr.write("This stderr message should appear only once")
    a = tqdm_pandas(tqdm())
    b = tqdm_pandas(tqdm.tqdm)
    for i in [a, b]:
        assert isinstance(i, tqdm)
        assert i.fp is sys.stderr

    tqdm_pandas(tqdm(), file=sys.stdout)
    assert sys.stdout.getvalue().strip() == "This stdout message should appear only once"

    df = pd.DataFrame({'i': range(100), 'c': [i % 4 for i in range(100)]})

# Generated at 2022-06-12 14:22:35.634394
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    try:
        import pandas as pd
        tqdm_pandas(tqdm, desc='Test')
        with tqdm(desc='Test') as t:
            pd.DataFrame([1, 2, 3]).groupby(0).progress_apply(lambda x: x)
            assert t.n == 3
            assert t.total == 3
    finally:
        # restore default
        tqdm_pandas(tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:45.951542
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame([[1, 2]], columns=['a', 'b'])

    # tqdm_pandas(tclass)
    pbar = tqdm.tqdm(total=1, mininterval=1)
    tqdm_pandas(tclass=pbar)
    df.groupby('a').progress_apply(lambda x: x)
    pbar.close()

    # tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, total=1, mininterval=1)
    df.groupby('a').progress_apply(lambda x: x)

    # tqdm_pandas(tqdm())
    pbar = tqdm_pand

# Generated at 2022-06-12 14:22:57.176236
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
    except ImportError:
        return  # skip the test if pandas is not installed
    try:
        from tqdm import tqdm
    except ImportError:
        raise ImportError(
            "`tqdm_pandas()` requires `tqdm` to be installed.\n"
            "Please install `tqdm` in order to run this test case.")

    # Regression test: https://github.com/tqdm/tqdm/issues/527
    df = DataFrame({'a': range(100)})
    with tqdm(total=100, desc="Processing", file=sys.stdout) as pbar:
        df.groupby('a').progress_apply(lambda row: pbar.update())


# Generated at 2022-06-12 14:23:03.753743
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # Prepare data
    index = pd.date_range('1/1/2000', periods=10)
    df = pd.DataFrame(index=index, data={"a": range(10)})

    # Test function
    tclass = tqdm(total=len(df), desc="Test")
    tqdm_pandas(tclass)
    res = df.progress_apply(lambda x: x)

    if res is None:
        raise ValueError("Test failed.")

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:12.921125
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame(np.arange(100).reshape(5, 20))
    tqdm_pandas(tqdm.tqdm())
    tqdm_pandas(tqdm.tqdm(total=df.shape[0]))
    tqdm_pandas(tqdm.tqdm(df))
    tqdm_pandas(tqdm.tqdm(df), total=df.shape[0])


# tqdm for pandas

# Generated at 2022-06-12 14:23:16.532780
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    try:
        from pandas import DataFrame
    except ImportError:
        return  # pandas not available

    df = DataFrame(np.arange(100000))
    df.groupby(0).progress_apply(lambda x: x)


test_tqdm_pandas()

# Generated at 2022-06-12 14:23:26.652756
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Unit test for function tqdm_pandas
    import pandas as pd
    from tqdm import tqdm

    # The test is expected to throw a DeprecationWarning here
    tqdm_pandas(tqdm, leave=True)
    tqdm_pandas(tqdm(total=100), leave=True)

    # Test creates df with a random index, which will create a random sequence
    # so we always use the same random integers via `seek(0)`
    # (hardcoded seed to ensure test is deterministic)
    import numpy as np
    np.random.seed(0)
    df = pd.DataFrame(np.random.randint(0, 100, size=(100, 1)), columns=["a"])

# Generated at 2022-06-12 14:23:34.863019
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(np.random.rand(100, 3), columns=list('ABC'))
    tqdm.pandas(**{'tclass': tqdm, 'leave': False})

    return all(df.groupby('A').progress_apply(lambda x: x) ==
               df.groupby('A').apply(lambda x: x))

# Test if tqdm_pandas runs properly (could be redundant with tests in tqdm)
# try:
#     test_tqdm_pandas()
# except Exception as exp:
#     exit("Could not run tqdm_pandas unit test: {}".format(exp))

# Generated at 2022-06-12 14:23:42.759288
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        has_pandas = True
    except ImportError:
        has_pandas = False
    if has_pandas:
        import numpy as np
        from tqdm import tqdm
        df = pd.DataFrame(np.random.random(size=(1000, 3)))
        _ = df.groupby(0).progress_apply(lambda x: x)

        with tqdm(total=10) as t:
            i = 0
            # Delayed adapter case
            _ = df.groupby(0).progress_apply(lambda x: t.update())
            assert i == 10

            # Instantiation case
            t = tqdm(total=10)
            _ = df.groupby(0).progress_apply(lambda x: t.update())

# Generated at 2022-06-12 14:23:52.720721
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    import pandas
    #
    # Create a progress bar...
    with tqdm(total=100, desc='test', unit='test', ncols=80,
              miniters=1, mininterval=0.25) as t:
        # ...and display a pandas progress bar
        tqdm_pandas(t)
        data = pandas.DataFrame({'a': [0, 1, 2, 3, 4], 'b': [0, 1, 2, 3, 4]})
        # Apply a function with `progress_apply`
        data.groupby(['a']).progress_apply(lambda x: x)

# Generated at 2022-06-12 14:24:12.622729
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    a = np.random.randint(1, 1e6, size=(int(5e5)))
    df = pd.DataFrame(a, columns=['v'])
    with tqdm(unit_scale=1.0, leave=False, ncols=None,
              disable=None, ascii=None, desc=None, total=None,
              unit="it", initial=0, position=None) as t:
        df.groupby(['v']).progress_apply(lambda x: x)


if sys.version_info < (3, 0):
    tqdm_pandas = tqdm_pandas

# Generated at 2022-06-12 14:24:22.389833
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    df = pd.DataFrame({'a': [1, 2, 3, 4], 'b': [0, 0, 0, 1], 'c': [0.0, 0.0, -1.0, 1.0]})
    tqdm_pandas(tqdm(total=len(df)))
    df2 = df.groupby('a').progress_apply(lambda group: group.c.sum() * group.b.sum())
    assert df.a.sum() == df2.sum()



# Generated at 2022-06-12 14:24:29.571961
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    import numpy as np
    from .tqdm_gui import tqdm_gui

    pbar = tqdm_gui(total=100)
    assert isinstance(pbar.pos, int)
    assert isinstance(pbar.max_iter, float)
    assert isinstance(pbar.prev_total, int)
    assert pbar.miniters > 0
    assert pbar.mininterval > 0
    assert pbar.maxinterval > 0
    assert pbar.mininterval < pbar.maxinterval
    assert hasattr(pbar, 'dynamic_miniters')
    assert pbar.total == pbar.max_iter == 100
    assert pbar.miniters * pbar.mininterval <= 2

    pbar.total = 50
    assert p

# Generated at 2022-06-12 14:24:33.398037
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    pd.DataFrame({'a': [i for i in range(1000000)],
                  'b': [i for i in range(1000000)]})\
      .groupby(['a'])\
      .progress_apply(lambda x: x)

# Generated at 2022-06-12 14:24:40.871718
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    N = 10000
    try:
        tqdm_pandas(N, desc='mybar', leave=True)
    except:
        pass
    try:
        tqdm_pandas(pd.DataFrame({'a': np.random.randint(0, N, size=N)})[
                    'a'].groupby(np.random.randint(0, N // 4, size=N)).mean(),
                    desc='mybar', leave=True)
    except:
        pass

# Generated at 2022-06-12 14:24:43.160881
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    pass

if __name__ == "__main__":
    # unit test
    test_tqdm_pandas()
    print("all passed")

# Generated at 2022-06-12 14:24:50.074489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`"""
    import pandas as pd
    import numpy as np
    import tqdm

    T = tqdm.pandas(desc='test', ascii=True)

    df = pd.DataFrame({'A': np.random.randint(0, 100) for k in range(10)})
    df['B'] = df['A'].progress_apply(lambda x: np.random.normal(1, 1))
    df['C'] = df.progress_apply(lambda x: np.random.normal(x['A'], x['B']), axis=1)
    df = df.set_index('A').groupby(level=0).progress_apply(np.mean)
    assert isinstance(T, tqdm.tqdm)

# Generated at 2022-06-12 14:24:59.222762
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except:
        return
    # Test pandas integration
    from tqdm import tqdm
    from tqdm.utils import _term_move_up
    tqdm_pandas(tqdm)

    t = tqdm(pd.DataFrame(dict(A=range(1000))), leave=False)
    assert t.total == 1000

    df = pd.DataFrame(dict(A=range(1000)))
    t = tqdm(df, leave=False)
    assert t.total == 1000

    t = tqdm(df.groupby('A'), leave=False)
    assert t.total == 1000

    t = tqdm(df.groupby('A').A, leave=False)
    assert t.total == 1000

    t = t

# Generated at 2022-06-12 14:25:08.425342
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmDeprecationWarning
    with warnings.catch_warnings(record=True) as ws:
        tqdm_pandas(tqdm(total=10))
    assert ws[0].category == TqdmDeprecationWarning
    try:
        from pandas import DataFrame
    except ImportError:
        return

# Generated at 2022-06-12 14:25:19.056477
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.contrib import pandas

    import pandas as pd
    import numpy as np

    # Create a dataframe
    df = pd.DataFrame({'a': np.random.choice(2, 500),
                       'b': np.random.rand(500)})

    # Groupby operation
    for i, v in tqdm(df.groupby('a').progress_apply(lambda x: x.rolling(5).mean())):
        pass

    for i, v in tqdm(df.groupby('a').progress_apply(lambda x: x.rolling(5).mean()),
                     total=df['a'].nunique()):
        pass


# Generated at 2022-06-12 14:25:39.603276
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    try:
        import pandas as pd
    except ImportError:
        return
    tqdm_pandas(tqdm())
    assert hasattr(pd.DataFrame.progress_apply, 'deprecated_mininterval')
    assert hasattr(pd.DataFrame.progress_apply, 'deprecated_dynamic_ncols')


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:42.759744
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    x=pd.DataFrame({"a":[1,2,3,4]})
    x.groupby("a").progress_apply(lambda x: x)

# Generated at 2022-06-12 14:25:49.094169
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import tests
    from tqdm.std import tqdm

    tests.setup_environment()
    t = tqdm(total=10)
    with tqdm.tests.mock.patch('pandas.core.groupby.DataFrameGroupBy',
                               side_effect=test_tqdm_pandas):
        tqdm_pandas(t)

if __name__ == "__main__":
    test_tqdm_pandas()
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
    print("DocTest succeeded!")

# Generated at 2022-06-12 14:25:59.240528
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm
    from tqdm import TqdmDeprecationWarning
    from tqdm.contrib.concurrent import process_map
    from tqdm import trange

    assert hasattr(tqdm, 'pandas')
    assert hasattr(tqdm, 'status_printer')
    assert hasattr(tqdm, 'tqdm_pandas')
    assert not hasattr(tqdm, 'tqdm')

    with pytest.raises(TqdmDeprecationWarning):
        assert tqdm.tqdm_pandas(tqdm)
    assert tqdm.pandas(pandas=True)


# Generated at 2022-06-12 14:26:07.652937
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    from pandas import Series
    tqdm_pandas(tqdm(total=len(df)), smoothing=1)
    res = df.progress_apply(pd.Series.nunique, axis=0)
    assert all(res.values)


# Hack function into pandas module
try:
    import pandas
except ImportError:
    pass
else:
    pandas.tqdm = tqdm_pandas

# Generated at 2022-06-12 14:26:16.905953
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm._tqdm_pandas import patch_pandas
    from tqdm import tqdm_pandas
    from tqdm import tqdm
    from tqdm import trange

    patch_pandas()

    df = pandas.DataFrame([i for i in range(50)])

    tqdm_pandas(tqdm, desc='desc')
    df.progress_apply(lambda x: x)

    tqdm_pandas(tqdm)
    df.progress_apply(lambda x: x)

    tqdm_pandas(tqdm_pandas(tqdm))
    df.progress_apply(lambda x: x)

    tqdm_pandas(tqdm.tqdm)

# Generated at 2022-06-12 14:26:21.278670
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib import pandas

    df = pd.DataFrame(dict(a=list(range(100))))

    assert df.groupby('a').progress_apply(lambda x: x) is not None


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:26:28.337360
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
        len(DataFrame())
    except (ImportError, TypeError):
        return

    try:
        from tqdm import tnrange
    except ImportError:
        return

    # If we had to use tnrange, then the test is invalid.
    if hasattr(tnrange, '__base__'):
        return

    df = DataFrame(dict(
        a=list(range(100)),
        b=list(map(lambda x: x / 2, range(100))),
        c=list(map(lambda x: x / 3, range(100))),
        d=list(map(lambda x: x / 4, range(100))),
        e=list(map(lambda x: x / 5, range(100))),
    ))
