

# Generated at 2022-06-12 14:16:32.152506
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # make a short string to be multiplied many times
    data = pd.Series(["a"] * 100)
    # the function to apply
    func = lambda x: x + "b"
    # use the progress_apply method
    data = data.progress_apply(func)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:16:39.276942
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from numpy import random
    from time import sleep

    # Using tqdm_pandas as a closure
    def f(sleep_time):
        sleep(sleep_time)

    # Using tqdm_pandas as a function
    def g(sleep_time):
        sleep(sleep_time)

    df = DataFrame({'a': [10] * 100, 'b': [20] * 100})
    s = Series(random.random(100))
    print('DF:')
    tqdm_pandas(tqdm(total=len(df)), desc='1st loop')(f)(df['a'] / 1000)
    print('\nSer:')

# Generated at 2022-06-12 14:16:46.789369
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import sys
    from tqdm import tqdm, get_lock
    try:
        import pandas as pd
        import pandas.core.groupby
    except ImportError:
        tqdm_pandas(tqdm(fp=sys.stdout), file=sys.stdout)
        tqdm_pandas(tqdm)
        return

    with get_lock():
        tqdm_pandas(tqdm)
        tqdm_kwargs = dict(file=sys.stdout.buffer)
        tqdm_pandas(tqdm, **tqdm_kwargs)
        import tqdm.pandas

# Generated at 2022-06-12 14:16:51.610768
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    tqdm_pandas(pd.DataFrame({'a': [1, 2]}).groupby('a').progress_apply(len))
    tqdm_pandas(pd.DataFrame({'a': [1, 2]}).groupby('a').progress_apply(len).reset_index().groupby('a').progress_apply(len))

# Generated at 2022-06-12 14:17:00.544840
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from time import sleep
    if not _is_pandas_installed():
        return
    import pandas as pd

    tqdm_pandas(tqdm)
    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
    with closing(StringIO()) as our_file:
        tqdm.pandas(
            file=our_file, leave=False, dynamic_ncols=True,
            unit_scale=True, unit_divisor=1024, mininterval=0.5, miniters=1)
        # We must use `progress_apply` instead of `apply`
        # because `apply` by default is lazy, and `tqdm`
        # computes the total number of iterations in advance
        # (for more

# Generated at 2022-06-12 14:17:08.055066
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    try:
        import pandas  # noqa
    except:
        raise unittest.SkipTest("No pandas installed")
    try:
        import tqdm  # noqa
    except:
        raise unittest.SkipTest("No tqdm installed")
    with captured_stdout() as t:
        tqdm_pandas(tclass=tqdm, ascii=True)
    assert (t.getvalue() == "Pandas Apply: 100%|##########| 100/100 [00:01<00:00, 97.77it/s]\n")


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-12 14:17:17.268312
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas

    df = pd.DataFrame({'x': np.random.random(100000),
                       'y': np.random.random(100000),
                       'z': np.random.random(100000)})

    def simple_func(x):
        return np.sum(x * np.random.random(len(x)))

    tqdm_pandas(tqdm())  # tqdm(...)
    df.groupby('y').progress_apply(simple_func)  # tqdm(...)

    delayed = tqdm_pandas(tqdm, desc='delayed', leave=False)  # tqdm_pandas(tqdm, ...)

# Generated at 2022-06-12 14:17:25.351269
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm

    try:
        from pandas import DataFrame, Series
    except ImportError:
        return

    tqdm_pandas(tqdm)

    df = DataFrame({'a': list(range(200000)),
                    'b': list(range(200000)),
                    'c': list(range(200000))})

    # test without file descriptor
    s = df.groupby('a').progress_apply(lambda x: x)
    assert (s.shape == df.shape)

    # test with file descriptor
    s = df.groupby('a').progress_apply(lambda x: x)
    assert (s.shape == df.shape)

    # test with Series

# Generated at 2022-06-12 14:17:32.646936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    import random
    import sys
    import traceback

    def random_generator(n):
        for i in range(n):
            yield random.random()

    try:
        df = pd.DataFrame(random_generator(10), columns=['rand'])
        try:
            # Test tqdm_pandas
            tqdm_pandas(tqdm(total=10))
            df.groupby('rand').progress_apply(lambda x: sum(x))
        except Exception:
            traceback.print_exc()
            return False
        else:
            return True
    except ImportError:
        return False



# Generated at 2022-06-12 14:17:42.854116
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    try:
        pandas.core.groupby.DataFrameGroupBy.progress_apply
    except AttributeError:
        return
    try:
        tqdm_pandas(tqdm)
    except Exception as e:
        raise Exception("tqdm_pandas(tqdm) raised `%s`" % e)
    try:
        tqdm_pandas(tqdm.tqdm)
    except Exception as e:
        raise Exception("tqdm_pandas(tqdm.tqdm) raised `%s`" % e)

# Generated at 2022-06-12 14:17:54.384043
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # This is to register tqdm with pandas
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from functools import wraps
    from time import sleep

    # This is a decorator to add tqdm progress meter to pandas progress_apply

    def tqdm_progress_apply(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            progress_args = kwargs.pop('progress_args', {})
            progress_func = kwargs.pop('progress_func', DataFrame.progress_apply)
            df = args[0]
            apply_result = func(*args, **kwargs)
            if not len(df):
                return apply_result
            # from tqdm import tqdm
            # from tqdm import t

# Generated at 2022-06-12 14:18:00.836322
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_notebook, tqdm

    df = pd.DataFrame(np.ones((10,)))

    def f(x):
        return x * 2

    df.progress_apply(f, axis=0)

    tqdm_pandas(tqdm_notebook)
    df.progress_apply(f, axis=0)

    tqdm_pandas(tqdm)
    df.progress_apply(f, axis=0)

# Generated at 2022-06-12 14:18:08.553144
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm
    tqdm_pandas(tqdm)

    df = pd.DataFrame({'A': np.random.randn(10000),
                       'B': np.random.randn(10000)})
    df.groupby('B').progress_apply(lambda x: x)
    # or even
    df.groupby(pd.Grouper(freq='M')).progress_apply(lambda x: x)
    
    
if __name__ == "__main__":  
    test_tqdm_pandas()
    print("Success")

# Generated at 2022-06-12 14:18:14.844498
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def func(df):
        return df

    try:
        import tqdm
    except ImportError:
        return  # nosec

    from pandas import DataFrame
    from pandas import concat as pd_concat
    from pandas import read_csv as pd_read_csv

    df0 = pd_read_csv(__file__, nrows=111)
    df1 = pd_read_csv(__file__, nrows=222)
    df2 = pd_read_csv(__file__, nrows=333)
    df = pd_concat([df0, df1, df2])

    tqdm_pandas(tqdm.tqdm)  # register
    df.groupby('lineno').progress_apply(func)

    # should also work without explicit registration

# Generated at 2022-06-12 14:18:25.434941
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:18:32.317679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas
    tqdm_pandas(tqdm)
    df = pd.DataFrame()
    df['a'] = np.random.rand(1000000)
    df.groupby(['a']).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:39.797286
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest
    from .gui import tqdm
    from .gui import trange

    # Test existing DataFrameGroupBy.progress_apply behaviour
    df = pd.DataFrame({'x': [1, 2, 3, 4]})
    for _ in df.groupby('x').progress_apply(lambda x: x):
        pass

    # Test tqdm-based progress_apply
    df = pd.DataFrame({'x': [1, 2, 3, 4]})
    t = tqdm(total=len(df.groupby('x')))
    # Test tqdm_pandas(tclass) with tclass=type(t)
    tqdm_pandas(tclass=type(t))

# Generated at 2022-06-12 14:18:50.260878
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    df = pd.DataFrame({'x':[10, 20, 30]})
    with tqdm(total=len(df)) as t:
        def fn(x):
            t.update()
            return x - 1
        df['y'] = df.x.progress_apply(fn)
    print(df.x, df.y)
    df = pd.DataFrame({'x':[10, 20, 30]})
    with tqdm(total=len(df)) as t:
        df['y'] = df.x.progress_apply(lambda x: t.update() or x - 1)
    print(df.x, df.y)
    df = pd.DataFrame({'x':[10, 20, 30]})

# Generated at 2022-06-12 14:18:56.331321
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return tqdm_pandas
    pandas.DataFrame([1, 2]).groupby(0).progress_apply(lambda _: None)
    return tqdm_pandas


if __name__ == '__main__':
    test_tqdm_pandas()(tqdm)

# Generated at 2022-06-12 14:19:05.742585
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import linspace, sin
    from random import uniform
    from tqdm import tqdm
    df = DataFrame({'a': Series(linspace(0, 1, int(1e6)))})
    df['c'] = df['a'].progress_apply(lambda x: uniform(0, 1) * sin(x))
    print(df)
    df2 = DataFrame({'a': Series(linspace(0, 1, int(1e6)))})
    with tqdm() as t:
        df2['c'] = t.pandas(df2['a'].progress_apply, total=len(df2))(
            lambda x: uniform(0, 1) * sin(x))
    print(df2)

# Generated at 2022-06-12 14:19:17.966884
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function `tqdm.tqdm_pandas`
    """
    import pandas as pd
    from collections import defaultdict
    from tqdm.autonotebook import tqdm, trange
    import numpy as np

    # Check to see if an argument is passed in and has
    # the expected value.
    def check_arg(arg, val):
        assert arg == val, "Unexpected arg value"

    # Check to see if an argument is passed in and
    # has the expected type.
    def check_arg_type(arg, type):
        assert isinstance(arg, type)

    # Check to see if an argument is passed in and
    # is expected to not be None.
    def check_arg_not_none(arg):
        assert arg is not None

    # Check to

# Generated at 2022-06-12 14:19:22.458474
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd

    tqdm_pandas(tqdm)
    df = pd.DataFrame()
    df['a'] = [1.0] * 10000000

    df.groupby('a').progress_apply(lambda x: x[0])

# Generated at 2022-06-12 14:19:31.572460
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except:
        raise unittest.SkipTest("pandas not found")
    import numpy as np
    from tqdm import tqdm
    a = pd.DataFrame({'a': np.random.randint(0, 100, 100000)})
    tqdm_pandas(tqdm)
    assert "`tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`" in \
        str(tqdm_pandas)
    assert "`tqdm.pandas(...)` instead of `tqdm_pandas(tqdm(...))`" in \
        str(tqdm_pandas)

# Generated at 2022-06-12 14:19:38.533065
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        tqdm_pandas()
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        tqdm_pandas(tqdm_pandas)
    except TypeError:
        pass
    else:
        raise AssertionError

    t = tqdm_pandas(tqdm)
    assert (t.__name__ == 'tqdm_pandas')



# Generated at 2022-06-12 14:19:44.398367
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .tqdm import tqdm

    tqdm_pandas(tqdm, total=100, smoothing=0)
    tqdm_pandas(tqdm(total=100, smoothing=0))
    tqdm_pandas(tqdm, total=100)
    tqdm_pandas(tqdm(total=100))
    tqdm_pandas = tqdm.pandas


# -----------------------------------------------------------------------------
# Deprecated tqdm_gui
# -----------------------------------------------------------------------------

# Generated at 2022-06-12 14:19:56.528920
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        from tqdm import trange
    except ImportError as e:
        warnings.warn("Skipping tqdm.pandas unit tests (requires: pandas)")
        return None

    data = {'a': list(range(1, 101))}
    df = pd.DataFrame(data)

    with tqdm_pandas(total=100) as pbar:
        def func(x):
            pbar.update()
            return x * 2
        assert(df['a'].progress_apply(func).max() == 200)

    with tqdm_pandas(trange(10)) as pbar:
        def func(x):
            pbar.update()
            return x * 2

# Generated at 2022-06-12 14:20:06.476241
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for pandas tqdm"""
    try:
        import pandas
        import numpy
        from tqdm import tqdm
    except ImportError:
        return
    n = 100

    # Test pandas groupby progress_apply
    data = pandas.DataFrame(numpy.ones(n, dtype=int), columns=['a'])
    for i in range(2):
        tqdm_pandas(tqdm(desc='GroupBy'), leave=True)(data.groupby('a').progress_apply)(
            lambda x: x)

    # Test pandas apply
    for i in range(2):
        tqdm_pandas(tqdm(desc='Apply'), leave=True)(data.progress_apply)(
            lambda x: x)

    # Test pandas map

# Generated at 2022-06-12 14:20:17.311378
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    #from .tqdm_pandas import tqdm_pandas
    import pandas as pd

    try:
        import numpy as np
    except ImportError:
        np = None

    tqdm_pandas(tqdm)  # register tqdm instance with pandas

    # Testing tqdm.pandas() with apply()
    DF = pd.DataFrame({'val': [1, 2, 3, 4, 5, 6]})
    if sys.version_info[0] >= 3:
        assert_equal(DF.progress_apply(lambda x: x*x).sum().sum(), 91)

# Generated at 2022-06-12 14:20:19.110159
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from tqdm import tqdm as tqdm_regular

    tqdm_pandas(tqdm_regular(total=10))

# Generated at 2022-06-12 14:20:26.078928
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np
    from tqdm import tqdm


# Generated at 2022-06-12 14:20:34.116695
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        from tqdm.contrib import pandas
        import pandas as pd

        pd.DataFrame({"A": [1, 2], "B": [3, 4]}).groupby("A").progress_apply(
            lambda x: x["B"])
    except ImportError:
        pass

# Generated at 2022-06-12 14:20:45.097973
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        pass
    else:
        import pandas as pd
        import numpy as np

        df = pd.DataFrame(np.arange(2000000), columns=['a'])

        pd.options.display.max_rows = 10

        assert pd.DataFrame(np.arange(10), columns=['a']).progress_apply(
            lambda x: x).equals(pd.DataFrame(np.arange(10), columns=['a']))

        with tqdm(total=len(df), leave=False) as t:
            pd.options.display.max_rows = 10

# Generated at 2022-06-12 14:20:52.872680
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        import pandas
    except ImportError:
        import nose
        raise nose.SkipTest

    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tqdm)
    t = tqdm(total=10)
    tqdm_pandas(t)
    assert hasattr(t.__class__, 'pandas')
    # Test if nothing breaks when pandas is not installed
    import pandas  # NOQA
    import sys, re
    sys.modules['pandas'] = None
    tqdm_pandas(tqdm(total=10))
    sys.modules['pandas'] = re



# Generated at 2022-06-12 14:20:59.607156
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({'name': ['a', 'b', 'c', 'd', 'e']})

    def foo(df):
        for i in range(int(1e4)):
            for j in range(int(1e4)):
                i, j
        return df

    tqdm_pandas(tclass=tqdm, leave=True)(foo)(df)

# Generated at 2022-06-12 14:21:10.981235
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:21:22.579422
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    pd = pytest.importorskip('pandas')

    def slow_duplicate_rows(df):
        df = df.iloc[::2].copy()
        df["foo"] = df["bar"]**2
        return df

    df = pd.DataFrame({"bar": [1, 2, 3, 4]})

    # Register tqdm with the pandas groupby module
    tqdm_pandas(tqdm)

    # Run the dataframe operation with tqdm monitoring
    result = df.groupby("bar").progress_apply(slow_duplicate_rows)
    assert list(result["foo"]) == [1, 4, 9, 16]


if __name__ == '__main__':
    test_tqdm_pand

# Generated at 2022-06-12 14:21:31.875907
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Check that tqdm_pandas works on the fly"""
    import pandas as pd
    from tqdm import tqdm
    from tqdm._utils import _term_move_up

    from io import StringIO
    import sys
    import traceback

# Generated at 2022-06-12 14:21:42.537850
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except Exception:
        warnings.warn('pandas must be installed for tqdm_pandas()')
        return

    for cls in tqdm, trange, tgrange:
        prog_kwargs = dict(desc='progbar',
                           miniters=1,
                           unit='it',
                           total=100,
                           file=sys.stdout)

        with cls(**prog_kwargs) as t:
            result = tqdm_pandas(t, ascii=True, leave=False)
            assert (pd.DataFrame(dict(A=[1, 2, 3]))
                    .groupby('A').progress_apply(lambda x: x) is not None)

# Generated at 2022-06-12 14:21:46.387340
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm
    tqdm_pandas(tqdm)
    df = pd.DataFrame(dict(a=range(1000), b=range(1000)))
    df.groupby('a').progress_apply(lambda x: x+1)

# Generated at 2022-06-12 14:21:55.247878
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test the tqdm_pandas function
    """
    import numpy as np
    import pandas as pd
    from pandas import DataFrame
    try:
        from tqdm._utils import _term_move_up, _screen_shape_wrapper
    except:
        from tqdm._utils import _term_move_up as _term_move_up
        from tqdm._utils import _screen_shape_wrapper as _screen_shape_wrapper

    def test_case(t):
        from pandas import DataFrame
        df = DataFrame({"A": [1, 1], "B": [1, 1]})
        return t.pandas(df.groupby("A").progress_apply(lambda _df: True))

    t = tqdm(total=100)

# Generated at 2022-06-12 14:22:05.303146
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class tqdm:
        @staticmethod
        def pandas(**kwargs):
            return kwargs

    assert tqdm_pandas(tqdm)(a=1) == {'a': 1}

# Generated at 2022-06-12 14:22:10.433727
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    try:
        import pandas as pd
    except ImportError:
        return

    tqdm_pandas(tqdm())

    def f(x):
        return x

    DF = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]})
    g = DF.groupby('a')
    g.progress_apply(f)

# Generated at 2022-06-12 14:22:21.070634
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from random import random
    n = 1000
    tqdm_pandas(tqdm, desc="test_tqdm_pandas")
    lst = list(range(n))
    df = DataFrame({'A': lst, 'B': [random() for _ in lst]})
    res = df.groupby('A').progress_apply(lambda x: x.sum() + 1)
    assert (Series(lst).groupby(lst).apply(lambda x: x.sum() + 1) == res).all()
    print('Test passed!')


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:31.091478
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    df = DataFrame({"x": [1, 2, 3, 4]})
    tqdm_kwargs = {
        'total': df.shape[0],
        'initial': 1,
        'desc': 'testing',
        'leave': True,
    }
    t_instance = tqdm.pandas(**tqdm_kwargs)
    df.progress_apply(lambda x: x, axis=1)
    t_class = tqdm.pandas(**tqdm_kwargs)
    df.progress_apply(lambda x: x, axis=1)
    assert isinstance(t_instance, tqdm.tqdm)

# Generated at 2022-06-12 14:22:36.404663
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    try:
        import numpy
    except ImportError:
        return
    import tqdm
    from tqdm.auto import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(lambda: tqdm)
    for _ in tqdm_pandas(range(2)):
        _


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:46.285597
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame(np.random.normal(size=(1000, 1000)))
    tqdm.pandas(desc='test_1')
    # Should not raise
    df.progress_apply(lambda x: x**2)
    df.groupby(0).progress_apply(lambda x: x**2)
    # Should not raise
    tqdm_pandas(tqdm.tqdm)
    df.progress_apply(lambda x: x**2)
    df.groupby(0).progress_apply(lambda x: x**2)
    df_cum = pd.DataFrame(np.random.normal(size=(10000, 10000)))
    # Should not raise

# Generated at 2022-06-12 14:22:57.511252
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, pandas
    from pandas import DataFrame

    df = DataFrame([1, 2, 3])
    tqdm_pandas(tqdm(**{}))
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(**{}))
    tqdm_pandas(pandas)
    with tqdm(total=len(df), **{}) as t:
        df.progress_apply(lambda x: x, t=t)

# Generated at 2022-06-12 14:23:04.776952
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import random

    N = 1000
    df = pd.DataFrame({'id': [random.randint(0, N) for _ in range(N)]})
    g = df.groupby('id')
    if hasattr(g, 'progress_apply'):
        with tqdm_pandas(total=len(df)) as pbar:
            g.progress_apply(lambda x: len(x), meta=('len(x):', int))
    else:
        def _apply(df):
            return len(df)
        # with tqdm(total=len(df), desc='Testing tqdm_pandas') as pbar:

# Generated at 2022-06-12 14:23:09.481102
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        pass
    else:
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(total=1))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:13.556493
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm
        t = tqdm.tqdm(total=100)
        tqdm_pandas(t)
        # tqdm.pandas(t)  # more.py does not define this function
        assert True
    except:
        assert False

# Generated at 2022-06-12 14:23:33.730645
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas.
    """
    from tqdm import tqdm

    try:
        tqdm_pandas(tqdm())  # tqdm instance
    except Exception as e:
        raise e

    try:
        tqdm_pandas(tqdm)  # delayed adapter case
    except Exception as e:
        raise e


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:42.040512
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    with tqdm.tqdm_pandas(unit='B', unit_scale=True, miniters=1) as t:
        df = pd.DataFrame(np.random.random((100, 100)))
        _ = df.groupby(0).progress_apply(lambda x: x**2)
    assert len(t) == 100
    t.close()
    with tqdm.tqdm_pandas(unit='B', unit_scale=True, miniters=1) as t:
        _ = df.progress_apply(lambda x: x**2)
    assert len(t) == 10000
    t.close()


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-12 14:23:52.572946
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm

    try:
        import pandas as pd
    except ImportError:
        print("")
        print("Pandas not installed. Skipping tqdm_pandas unit tests.",
              file=sys.stderr)
    else:
        print("")
        print("Running tqdm_pandas unit tests...")
        print("")

        tqdm_pandas(tqdm, desc="this is a test")
        import numpy as np
        from tqdm.auto import trange, tqdm

        df = pd.DataFrame()
        df['a'] = np.random.randint(1, 10**6, 10**6)
        df['b'] = np.random.randint(1, 10**6, 10**6)
        df

# Generated at 2022-06-12 14:24:01.839386
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Tests the tqdm_pandas decorator"""
    # Test case - tqdm.pandas(...)
    tqdm_pandas(tqdm)

    # Test case - tqdm_notebook.pandas(...)
    tqdm_pandas(tqdm_notebook)

    # Test case - tqdm_pandas(tqdm_notebook, ...)
    tqdm_pandas(tqdm_notebook)

    # Test case - tqdm_pandas(tqdm, ...)
    tqdm_pandas(tqdm)

    # Test case - tqdm_pandas(tqdm(...), ...)
    tqdm_pandas(tqdm())

    # Test case - tqdm_

# Generated at 2022-06-12 14:24:03.712700
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm(total=10), desc='tqdm_pandas')



# Generated at 2022-06-12 14:24:07.481231
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from time import sleep
    x = pd.DataFrame(np.random.randn(10, 10))
    tqdm_pandas(x.groupby(0).progress_apply(lambda x: sleep(0.2)))

# Generated at 2022-06-12 14:24:14.583492
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        from pandas import DataFrame, Series
    except ImportError:
        return

    for prog in [
            'tqdm_notebook', 'tqdm_gui', 'tqdm', 'tqdm_pandas',
            'tqdm_pandas(tqdm)', 'tqdm_pandas(tqdm_notebook)',
            'tqdm_pandas(tqdm_notebook, leave=True)'
    ]:
        print("Testing", prog, "...")
        tqdm_pandas(eval(prog))
        # Test DataFrameGroupBy.progress_apply with tqdm_pandas

# Generated at 2022-06-12 14:24:25.704679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # unit test for tqdm_pandas()
    try:
        import pandas
    except ImportError:
        try:
            import pandas_test as pandas
        except ImportError:
            pandas = None
    if not pandas:
        return

    from tqdm import tqdm
    tqdm_pandas(tqdm)
    from random import random
    from time import sleep
    from pandas import DataFrame
    df = DataFrame([random() for _ in range(10 ** 3)])
    for value in df.groupby(0, sort=False).progress_apply(
            lambda x: sleep(1e-3 * len(x))).values:
        assert value[0] == 0


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:35.974370
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm, trange
    from pandas import DataFrame

    df = DataFrame({'x': [1, 2, 3, 4, 5, 6]})

    # register the tqdm instance and use progress_apply
    # tqdm_pandas(tqdm, unit='rows', leave=False)
    # df.groupby('x').progress_apply(lambda x: x - x.mean())
    tqdm_pandas(tqdm)
    df.groupby('x').apply(lambda x: x - x.mean())

    # or, use `tqdm.pandas` as a context manager
    with tqdm.pandas(desc='foo', unit='rows', leave=False) as t:
        df.groupby('x').progress_

# Generated at 2022-06-12 14:24:44.369160
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'a': list("abcd" * 500)})
    with tqdm.tqdm_pandas(total=len(df)) as t:
        df.groupby('a').progress_apply(t.update)

    df = pd.DataFrame({'a': list("abcd" * 500)})
    with tqdm.tqdm_pandas(total=len(df)) as t:
        df.apply(t.update)

    # Test when file is None (avoid AttributeError on file.write())
    with tqdm.tqdm_pandas(file=None) as t:
        t.pandas(total=1000, unit='B', desc='Downloading...')



# Generated at 2022-06-12 14:25:06.747809
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm_pandas(tqdm())  # can use instance or class
    # Now you can use `progress_apply` instead of `apply`
    df.groupby(0).progress_apply(lambda x: x ** 2)


if __name__ == '__main__':
    import pytest
    pytest.cmdline.main([__file__])

# Generated at 2022-06-12 14:25:11.745536
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    import numpy as np
    import tqdm
    tqdm.pandas(ncols=80)
    df = pd.DataFrame(np.random.randint(0, 2, (1000, 2)), columns=['A', 'B'])
    assert 'A' in df.progress_apply(lambda x: len(x) > 2)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:21.854167
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    x_float = pd.DataFrame(np.random.randn(100, 3))
    x_float.groupby(0).progress_apply(lambda x: x + 1)

    x_int = pd.DataFrame(np.random.randint(0, 10, size=(100, 3)))
    x_int.groupby(0).progress_apply(lambda x: x * 2)

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, total=100)

    tqdm_pandas(tqdm(), total=100)

    x_float.groupby(0).progress_apply(lambda x: x.dot(x.T))
    x

# Generated at 2022-06-12 14:25:27.854533
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time

    L = [np.arange(1000)]  # normal iterator
    df = pd.DataFrame({'a': np.arange(1000) + 5, 'b': list('a' * 1000)})

    tqdm_pandas(df.groupby('b').progress_apply(lambda x: x**2 + x + 1))

    def noop(x):
        time.sleep(0.01)

    tqdm_pandas(df.groupby('b').progress_apply(noop))

# Generated at 2022-06-12 14:25:36.677304
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm.auto import tqdm

    df = pandas.DataFrame([[i] for i in tqdm(range(10000))])
    assert df.groupby(0).progress_apply(lambda x: x**2)
    assert not tqdm._instances  # must be garbage collected
    assert df.groupby(0).progress_apply(lambda x: x**2)
    assert not tqdm._instances  # must be garbage collected

    df = pandas.DataFrame([[i] for i in tqdm(range(10000), position=0)])
    assert df.groupby(0).progress_apply(lambda x: x**2)
    assert not tqdm._tqdm._instances  # must be garbage collected

# Generated at 2022-06-12 14:25:40.300853
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from .std import time_range


# Generated at 2022-06-12 14:25:48.822403
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    df = DataFrame([[int(x), x] for x in range(1000)], columns=['a', 'b'])

    # Test with no tqdm function (to check compatibility)
    df.groupby('a').progress_apply(lambda x: x['b'])

    # Test with tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, desc='My GroupBy')
    df.groupby('a').progress_apply(lambda x: x['b'])

    # Test with tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(desc='My GroupBy'))

# Generated at 2022-06-12 14:25:58.997231
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    with tqdm(total=100, unit='samples') as t:
        t.pandas(desc='blah', unit='samples')
        pd.DataFrame({str(i): np.random.random((128, 128)) for i in range(100)})
        t.update()

    def f(x):
        import time
        time.sleep(0.01)
        return x * x * x

    # with tqdm(total=100) as t:
    #     a = pd.DataFrame({'a': list(range(100))})
    #     a.groupby('a').progress_apply(f)
    #     t.update()


# Generated at 2022-06-12 14:26:04.645508
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import numpy as np
        import pandas as pd
        from tqdm.autonotebook import tqdm
    except ImportError:
        pass
    else:
        dummy = pd.DataFrame(1 * np.ones((100, 100)))
        dummy = dummy.copy()

        tqdm_pandas(tqdm(dummy.groupby(0).progress_apply(lambda x: x)))

# Generated at 2022-06-12 14:26:13.856649
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np
    import tqdm
    import io

    # Check function tqdm_pandas
    # 1. Check deprecated
    tqdm.tqdm_pandas(tqdm.tqdm(ascii=True, total=10))
    tqdm.tqdm_pandas(tqdm.tqdm)
    # 2. Check working case
    output = io.StringIO()
    tqdm.tqdm_pandas(tqdm.tqdm(ascii=True, file=output, total=10))
    tqdm.tqdm_pandas(tqdm.tqdm(ascii=True, total=10))