

# Generated at 2022-06-12 14:16:31.220742
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import random
    from itertools import combinations
    import pandas as pd
    from tqdm import tqdm

    tqdm_pandas(tqdm)

    df = DataFrame(random.randn(1000, 10))

    for n in tqdm(range(10), mininterval=1):
        df.iloc[:, n].progress_apply(lambda x: x ** 2)

    for n in tqdm(range(10), mininterval=1):
        df.progress_apply(lambda x: x.iloc[n] ** 2)

    def square_series(s):
        return Series(s.iloc[:-1] ** 2)

    for n in tqdm(range(10), mininterval=1):
        df

# Generated at 2022-06-12 14:16:38.595937
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    import pandas as pd

    assert not hasattr(tqdm, 'pandas_deprecation_warning_issued')

    d = {'col1': [1, 2], 'col2': [3, 4]}
    df = pd.DataFrame(data=d)
    gb = df.groupby('col1')
    list(tqdm(gb))
    tqdm_pandas(tqdm)
    list(tqdm(gb))
    tqdm_pandas(tqdm(total=1))
    list(tqdm(gb))

    assert tqdm.pandas_deprecation_warning_issued


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:16:46.330733
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm

    a = pd.DataFrame({'a': range(10000), 'b': range(10000)})
    tqdm.pandas()
    a.groupby('a').progress_apply(lambda x: x+1)
    tqdm_pandas(tqdm)
    a.groupby('a').progress_apply(lambda x: x+1)
    tqdm_pandas(tqdm())
    a.groupby('a').progress_apply(lambda x: x+1)

# Generated at 2022-06-12 14:16:54.476662
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    for i in tqdm_pandas(range(1), total=3):
        pass
    for i in tqdm_pandas(range(1), total=3, file=sys.stderr):
        pass



# Generated at 2022-06-12 14:16:58.628589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _range
    from tqdm import tqdm

    tqdm_pandas(tqdm.pandas, total=100)
    tqdm_pandas(tqdm(total=100))
    tqdm_pandas(tclass=tqdm(total=100))

# Generated at 2022-06-12 14:17:05.274729
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    
    arr = np.random.rand(10)
    df = pd.DataFrame(arr)
    for i in (tqdm, tqdm_pandas):
        i(df).apply(lambda x: x+1)
    try:
        i(tqdm(df)).apply(lambda x: x+1)
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:15.994030
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    # Dummy setup
    t = tqdm(total=100)
    t.update(50)
    t.close()

    # Testing delayed
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm_gui)

    # Testing default
    pd.Series(range(100)).progress_apply(lambda i: i)
    pd.Series(range(100)).progress_apply(lambda i: i, leave=False)
    pd.Series(range(100)).progress_apply(lambda i: i, mininterval=0.001)

# Generated at 2022-06-12 14:17:24.571479
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas
    """
    try:
        import pandas
    except ImportError:
        return  # skip tests
    import numpy

# Generated at 2022-06-12 14:17:30.823397
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmDeprecationWarning
    assert_raises(TqdmDeprecationWarning,
                  tqdm_pandas, tqdm, file=open('/dev/null', 'w'))

    # N.B.: for some reason, sys.stderr is not imported in tests
    assert_raises(TqdmDeprecationWarning, tqdm_pandas, tqdm())

    with captured_output() as (out, err):
        assert_raises(TqdmDeprecationWarning, tqdm_pandas, tqdm())
        assert str(err)
    assert "please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`" \
           in str(err)



# Generated at 2022-06-12 14:17:40.111794
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Simple unit test for function `tqdm_pandas`.
    """
    import pandas
    tqdm_pandas(pandas.core.groupby.DataFrameGroupBy.progress_apply)
    assert pandas.core.groupby.DataFrameGroupBy.progress_apply.__doc__

    global bar  # for `del bar`
    bar = tqdm_pandas(tqdm(unit_scale=True))
    tqdm_pandas(bar)
    del bar
    assert 'progress_apply' not in pandas.core.groupby.DataFrameGroupBy.__dict__



# Generated at 2022-06-12 14:17:51.693605
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, trange

    # unit tests for tqdm_pandas module
    df = pd.DataFrame({'a': np.random.randint(0, 100, (100,)),
                       'b': ['bar'] * 50 + ['foo'] * 50,
                       'c': np.random.uniform(0, 10, (100,))})

    # test with tqdm_notebook
    # tqdm_notebook is only for jupyter notebook, so let's skip this test in Travis
    if os.environ.get('TRAVIS', None) != 'true':
        # should not produce any error
        tqdm_pandas(tqdm_notebook)

        # test functions, should not produce any

# Generated at 2022-06-12 14:17:59.244323
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    try:
        import tqdm
    except ImportError:
        raise ImportError('tqdm progress bar need to be installed first')

    t = tqdm.tqdm
    tqdm_pandas(t)

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    gpdf = df.groupby(0)
    try:
        gpdf.progress_apply(lambda x: x**2)
    except:
        tqdm_pandas.__init__(t)
        gpdf.progress_apply(lambda x: x**2)

    tqdm.tqdm_pandas().__init__(t)

# Generated at 2022-06-12 14:18:03.050546
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_pandas, tqdm
    for tclass in [pd, tqdm(pd), tqdm()]:
        tqdm_pandas(tclass)

# Generated at 2022-06-12 14:18:10.594232
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest("Skipping `pandas' tests (requires pandas)")

    class Dummysys(object):
        def __init__(self):
            self.argv = []

    class Dummytqdm(tqdm):
        def __init__(self):
            self.dummy = 1
            sys = Dummysys()

        @staticmethod
        def pandas(bar_format='{l_bar}'):
            assert bar_format == '{l_bar}'
            return Dummytqdm()

    tqdm_pandas(Dummytqdm())


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-12 14:18:22.416471
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    else:
        pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas(
            getattr(pd, 'core.groupby.DataFrameGroupBy.progress_apply'),
            desc='GroupBy')
        pd.core.groupby.GroupBy.progress_apply = tqdm_pandas(
            getattr(pd, 'core.groupby.GroupBy.progress_apply'),
            desc='GroupBy')
        from io import StringIO
        fobj = StringIO()
        tqdm_pandas(tqdm(
            file=fobj,
            total=1,
            miniters=1,
        ))  # Dummy iterator that does nothing
        tqdm_

# Generated at 2022-06-12 14:18:25.796168
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm())

# Generated at 2022-06-12 14:18:28.390646
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    t = tqdm(total=100)
    t.pandas(overwrite=True)

# Generated at 2022-06-12 14:18:33.354596
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ test tqdm.pandas"""
    try:
        import pandas
    except ImportError:
        return
    else:
        tqdm_pandas(None, total=100)
        # tqdm_pandas(None, total=100)  # noqa: F841
        tqdm_pandas(None, total=100)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:42.429655
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange, tqdm_pandas
    from pandas import DataFrame
    import pandas as pd
    from numpy import random
    import numpy as np
    from unittest import main

    class TestPandas(tnrange):
        """Testing pandas progress_apply"""
        def progress_apply(self, func, *args, **kwargs):
            t = tnrange(self._num_rows, disable=self.disable,
                        leave=self.leave, file=self.fp,
                        smoothing=self.smoothing, miniters=self.miniters)
            t.update()  # Initial draw
            results = super(TestPandas, self).progress_apply(func, *args,
                                                            **kwargs)
            t.close()
            return results



# Generated at 2022-06-12 14:18:54.357965
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    try:
        pd
    except NameError:
        raise SkipTest

    try:
        import numpy as np
    except ImportError:
        raise SkipTest

    T = tqdm.tqdm_pandas
    df = pd.DataFrame({'A': list('abcd') * 100,
                       'B': np.random.randn(400)})

    for unit in ['item', 'iter', 'group']:
        func = getattr(df.groupby('A'), 'progress_apply')
        func(lambda x: x + 1, unit=unit)
        func(lambda x: x + 1, unit=unit, miniters=200)
        func(lambda x: x + 1, unit=unit, leave=False)

# Generated at 2022-06-12 14:19:05.238067
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_notebook
    import pandas as pd
    import numpy as np

    n_rows = 100000
    df = pd.DataFrame({
        'col1': np.arange(n_rows),
        'col2': np.arange(n_rows),
    })

    def sum_cols(df):
        return df['col1'] + df['col2']

    res = df.groupby('col1').progress_apply(sum_cols)
    assert len(res) == df['col2'][-1] * 2

    tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:19:13.767100
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib import cProgressBar

    nrows = 50
    ncols = 50
    df = pd.DataFrame(np.random.randint(0, 100, size=(nrows, ncols)))
    N = 100

    # create tqdm instance
    t = cProgressBar(total=N)

    # register tqdm instance
    tqdm_pandas(t)

    # apply function on DataFrame
    df.progress_apply(lambda x: x + 1)
    assert t.n == N, "tqdm instance not registered"

# Generated at 2022-06-12 14:19:14.798510
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Placeholder for future unit tests
    pass

# Generated at 2022-06-12 14:19:25.728269
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm, trange
    from numpy import random
    import time

    with tqdm(range(100)) as t:
        for i in t:
            time.sleep(1e-3)
            t.set_description('Progress: %i' % i)
    with tqdm(range(100)) as t:
        for i in t:
            time.sleep(1e-3)
            t.set_description('Progress: %i' % i)

    tqdm_pandas(t)

    data = DataFrame([[random.random() for _ in range(1000)] for _ in range(1000)])
    data = data.progress_apply(lambda x: x + 1, axis=1)

# Generated at 2022-06-12 14:19:29.413060
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook

    for tc in [tqdm, tqdm_notebook]:
        tqdm_pandas(tc)
        tqdm_pandas(tqdm(0, "", file=sys.stdout))



# Generated at 2022-06-12 14:19:40.221137
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests that the tqdm_pandas() function works properly.

    Checks that warnings are raised and that the pandas method works properly
    """
    from pandas import DataFrame, Series
    from sklearn.datasets import load_iris
    from tqdm import tqdm_pandas
    from tqdm.contrib.tests import unittest

    class TestTqdmPandas(unittest.TestCase):
        def test_warning_type(self):
            """
            Tests that function tqdm_pandas() raises the proper
            TqdmDeprecationWarning
            """

# Generated at 2022-06-12 14:19:46.329963
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    N = 100
    test_df = pd.DataFrame(dict(
        A=np.random.randint(0, 10, N),
        B=np.random.rand(N),
        C=np.random.randint(0, 10, N)
    ))

    # Test with `tqdm` instance
    try:
        tqdm_pandas(tclass=tqdm_pandas, total=N)
    except Exception as e:
        print(e)
        assert isinstance(e, TypeError)

    # Test with `tqdm` class
    tqdm_pandas(tclass=tqdm)

    # Test with `tqdm(...)`
    t

# Generated at 2022-06-12 14:19:57.028795
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    from tqdm import tqdm

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(ascii=True), total=10, desc='desc')
    tqdm_pandas(tqdm(ascii=True), total=10, desc='desc2')
    tqdm_pandas(tqdm(ascii=True), total=10, desc='desc3')
    tqdm_pandas(tqdm(ascii=True), total=10, desc='desc4')
    tqdm_pandas(tqdm(ascii=True), total=10, desc='desc5')
    tqdm_pandas(tqdm(ascii=True), total=10, desc='desc6')
    t

# Generated at 2022-06-12 14:20:05.646761
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from pandas import Series, DataFrame
    import tqdm
    t = tqdm.pandas(leave=False)
    df = DataFrame({'col1': Series([0, 1, 2]), 'col2': Series([3, 4, 5])})
    df = df.groupby('col1').progress_apply(lambda x: x['col2'].sum())
    assert df.equals(DataFrame({'col1': Series([0, 1, 2]),
                                'col2': Series([3, 4, 5])}))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:15.869513
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    try:
        # Test with tqdm
        import tqdm as tqdm_bkp
        tqdm = tqdm_bkp

        assert tqdm.tqdm.__self__ is tqdm_bkp
        df = pd.DataFrame(np.random.random(size=(100, 3)))
        df.groupby(df.columns.tolist()).progress_apply(lambda x: x ** 2)
        tqdm.tqdm.__self__ = None

    except ImportError:
        # Test without tqdm
        import warnings
        tqdm = None


# Generated at 2022-06-12 14:20:25.791139
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib.tests import pandas_test_data
    from tqdm import tqdm_notebook as tqdm
    from tqdm.contrib import pandas
    df = pandas_test_data()

    tqdm()
    df.groupby('A').progress_apply(lambda x: [str(i) for i in x['B']])
    pandas(tqdm)
    df.groupby('A').progress_apply(lambda x: [str(i) for i in x['B']])
    df.groupby('A').progress_apply(lambda x: [str(i) for i in x['B']])
    tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:20:36.123228
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    try:
        import pandas as pd
    except ImportError:
        return

    df = pd.DataFrame({'col1': [1, 2, 3, 4, 5],
                       'col2': ['a', 'b', 'c', 'd', 'e'],
                       'col3': [3, 2, 1, 4, 5]})

    # Test that simple solutions work
    with tqdm.tqdm(total=10, ncols=0, dynamic_ncols=True) as t:
        tqdm.pandas(t)
        _ = df.groupby('col2').progress_apply(lambda x: x**2)
    assert t.n == 10
    assert t.last_print_n == t.n
    assert t.disable == 1

    #

# Generated at 2022-06-12 14:20:47.204986
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import numpy as np
    import pandas as pd

    def my_func(x):
        return x + 1

    n = 100

    # create a dataframe
    df = pd.DataFrame(np.random.rand(n, n))

    with tqdm(total=n, miniters=1, mininterval=0,
              bar_format="{l_bar}{bar} [ time left: {remaining} ]") as t:
        tqdm_pandas(t=t,
                    apply_func=my_func,
                    dataframe=df)


if __name__ == '__main__':
    test_tqdm_pandas()


# ======================================================================
# CHANGELOG (tqdm_pand

# Generated at 2022-06-12 14:20:57.701272
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:21:09.577794
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    try:
        pd.DataFrame({}).groupby(0).progress_apply(print)
    except AttributeError:
        tqdm_pandas(tqdm)
        # run this twice to cover code path where progress_apply already exists
        tqdm_pandas(tqdm)
        pd.DataFrame({}).groupby(0).progress_apply(print)
    else:
        raise Exception("progress_apply already exists?")

    try:
        pd.DataFrame({}).progress_apply(print)
    except AttributeError:
        tqdm_pandas(tqdm)
        # run this twice to cover code path where progress_apply already exists

# Generated at 2022-06-12 14:21:15.545849
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with pytest.raises(Exception):
        tqdm_pandas("")


# Alias for tqdm_pandas
tqdm_pandas_ = tqdm_pandas


######################################################################
# Use pandas.core.groupby.DataFrameGroupBy progress_apply method
# (with tqdm_gui)
######################################################################


# Generated at 2022-06-12 14:21:26.511719
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from time import sleep

    class test_tqdm_pandas_class:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.i = 0

        def get_kwargs(self):
            return self.kwargs

        def update(self):
            self.i += 1

        def __iter__(self):
            return self

        def __next__(self):
            self.kwargs['total'] = 10
            self.update()
            if self.i < 10:
                return self
            raise StopIteration

    df = pd.DataFrame(np.random.randint(0, 100, (15, 6)))

# Generated at 2022-06-12 14:21:34.991388
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import trange

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})

    for i in trange(2):
        df.groupby('a').progress_apply(lambda x: len(x))

    tqdm.pandas(tqdm(desc="whatever"))
    df.groupby('a').progress_apply(lambda x: len(x))

    with tqdm() as t:
        tqdm_pandas(t)
        df.groupby('a').progress_apply(lambda x: len(x))

    with tqdm(desc="whatever") as t:
        tqdm_pandas(t)
        df.groupby

# Generated at 2022-06-12 14:21:43.294181
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Initialize `tqdm.pandas` with warning
    assert tqdm_pandas(tqdm, desc='TEST') is None
    # Initialize `tqdm.pandas` with non-warning, non-tqdm-class
    assert tqdm_pandas(tqdm, desc='TEST', mininterval=0.2) is None
    # Initialize `tqdm.pandas` as a delayed adapter
    assert tqdm_pandas(tqdm_notebook, desc='TEST') is None

# Generated at 2022-06-12 14:21:47.135005
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    #tqdm_pandas(tqdm)
    #df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    #df.groupby(0).progress_apply(lambda x: x**2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:54.523540
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randn(10, 1))
    with tqdm(total=None) as pbar:
        df.progress_apply(lambda x: x + 2)
        pbar.update()
        assert pbar.n == 0
        assert pbar.total == 10
        assert pbar.desc == 'Pandas: Apply: lambda'


# Generated at 2022-06-12 14:22:03.048624
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import pandas as pd
    with pd.option_context('mode.chained_assignment', None):
        pd.core.common.is_list_like = pd.api.types.is_list_like
        from tqdm.test import TqdmExperimentalWarning
        import warnings
        warnings.simplefilter('ignore', TqdmExperimentalWarning)
        from tqdm.autonotebook import tqdm
        from tqdm.contrib import pandas
        from pandas.api.types import is_list_like

        df = pd.DataFrame({'a': [0, 1, 2, 3, 4], 'b': [0, 1, 2, 3, 4]})

# Generated at 2022-06-12 14:22:10.353764
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=3))
    tqdm_pandas(tqdm(total=3, postfix='foo', file=sys.stdout))
    tqdm_pandas(tclass=tqdm, postfix='foo', desc='foo', file=sys.stdout)

    tqdm_pandas(tclass=tqdm, postfix='foo',
                desc='foo', file=sys.stdout, nested=True)

    # https://github.com/tqdm/tqdm/issues/506
    try:
        import pandas as pd
    except ImportError:
        return
    pd

# Generated at 2022-06-12 14:22:21.698875
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm.utils import _term_move_up
    from tqdm.pandas import tqdm_pandas

    tqdm_pandas(tqdm)

    dfg = DataFrame(
        {'A': [1, 2, 3, 4, 5], 'B': [10, 20, 30, 40, 50]},
        columns=['A', 'B']).groupby(['A'])

    num_op = 1

    def fn(df):
        return len(df)


# Generated at 2022-06-12 14:22:31.711282
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    import pandas as pd
    import tqdm
    tqdm.tqdm_pandas(tqdm.tqdm())
    tqdm.tqdm_pandas(tqdm.tqdm_notebook())
    tqdm.tqdm_pandas(tqdm.tqdm_gui())
    tqdm.tqdm_pandas(tqdm.trange(5))
    df = pd.DataFrame({'a': [1, 2, 3],
                       'b': [1, 2, 3]})
    df.groupby('a', as_index=False).progress_apply(lambda x: x)


# Generated at 2022-06-12 14:22:43.205057
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    # tqdm.pandas() case
    tqdm.pandas()

    # deprecated cases
    import pandas as pd
    tpd = pd.DataFrame({'A': range(100000)})
    tpd.groupby(tpd.A // 10).progress_apply(lambda x: None)
    tpd.groupby(tpd.A // 10).progress_apply(lambda x: None, stream=tqdm())

    def test_fn_0(*args, **kwargs):
        pass

    def test_fn_1(*args, **kwargs):
        kwargs['stream'].write(" ")

    test_fn_0(stream=tqdm())
    test_fn_1(stream=tqdm())



# Generated at 2022-06-12 14:22:54.207034
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if sys.version_info[0] == 3 and sys.version_info[1] < 3:
        raise unittest.SkipTest("tqdm_pandas is not tested with Python < 3.3.")

    class tqdm(object):
        @staticmethod
        def pandas(**kwargs):
            return kwargs
    original = tqdm
    del tqdm


# Generated at 2022-06-12 14:23:02.702733
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas.core.indexes.category import CategoricalIndex
    from test_tqdm import pretest_posttest, with_setup
    from .std import tqdm, trange

    assert not hasattr(pd.Series, '_tqdm_hidden')
    assert not hasattr(pd.DataFrame, '_tqdm_hidden')

    assert not hasattr(pd.Series, 'progress_apply')
    assert not hasattr(pd.DataFrame, 'progress_apply')
    assert not hasattr(CategoricalIndex, 'progress_apply')


# Generated at 2022-06-12 14:23:11.865437
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return
    from time import sleep
    df = pd.DataFrame({'a': np.random.randint(0, 100, (10000,))})
    df.groupby('a').progress_apply(lambda x: sleep(0.01))  # should display a progressbar
    df.groupby('a').progress_apply(lambda x: sleep(0.01))  # should not display a progressbar
    # because a tqdm_pandas() has been registered
    df.groupby('a').progress_apply(lambda x: sleep(0.01))  # should display a progressbar

# Generated at 2022-06-12 14:23:17.997435
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:23:24.407968
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    df = pd.DataFrame({"A": [1] * 10000, "B": [1] * 10000})
    tqdm_pandas(tqdm)
    with tqdm() as f:
        df.groupby("A").progress_apply(lambda x: 1)

# Generated at 2022-06-12 14:23:31.635174
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm_pandas`"""
    from tqdm import tnrange

    # Test case 1: old argument style (deprecated)
    with warnings.catch_warnings(record=True) as caught_warnings:
        tqdm_pandas(tclass=tnrange(1), desc='foo')
        tqdm_pandas(tclass=tqdm_pandas, desc='foo')
        if len(caught_warnings) < 2:
            raise RuntimeError('test_tqdm_pandas: Test case 1 failed')
        else:
            for warning in caught_warnings:
                assert issubclass(warning.category, DeprecationWarning)

    # Test case 2: new argument style

# Generated at 2022-06-12 14:23:36.004261
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame({'x': np.random.randn(100000),
                       'y': np.random.randn(100000)})
    print(df.groupby('y').progress_apply(lambda x: x.x.sum()))

# Generated at 2022-06-12 14:23:39.197618
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm.auto import tqdm
    a = pandas.DataFrame({'a': [0, 1, 2, 3, 4]})
    with tqdm(total=5) as t:
        a.progress_apply(lambda x: t.update())

# Generated at 2022-06-12 14:23:47.772277
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm._utils import _term_move_up
    try:
        from pandas.api.types import is_bool_dtype
    except ImportError:
        from pandas.core.common import is_bool_dtype
    with closing(StringIO()) as our_file:
        tqdm_pandas(tqdm(file=our_file))
        for i in tqdm(range(100)):
            pd.DataFrame(list(range(100))).groupby(len).progress_apply(is_bool_dtype)
        our_file.seek(0)
        assert (our_file.read() == _term_move_up() * 101)


# Generated at 2022-06-12 14:23:58.307567
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas.core.groupby import DataFrameGroupBy
    from pandas import DataFrame

    try:
        from pandas.core.groupby import dummy
    except ImportError:  # Pandas < 0.23
        class dummy(object):
            pass

    # fake a DataFrame
    df = DataFrame({'key': ['a', 'b', 'c'] * 100, 'key2': ['a', 'b', 'c'] * 100,
                    'data1': range(300), 'data2': range(300)})

    # fake a groupby
    groupby = DataFrameGroupBy(df, [], [])

    # before
    assert not hasattr(DataFrameGroupBy, 'progress_apply')

    from tqdm import tqdm
    t = tqdm()
    # after
    tqdm_p

# Generated at 2022-06-12 14:24:05.595942
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import numpy
    import pandas
    import time

    tqdm_pandas()  # no error

    fake_df = pandas.DataFrame({'a': numpy.random.randint(10000, size=1000000)})

    # Unit test
    with tqdm.pandas(total=len(fake_df)) as progress:
        progress.update(1)
        def dummy():
            time.sleep(0.0001)

        fake_df.progress_apply(dummy)
        progress.update(1)


tqdm_pandas.__doc__ = __doc__



# Generated at 2022-06-12 14:24:09.438522
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest("pandas not found")
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(range(2)))


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-12 14:24:15.730365
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:24:26.548320
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test"""
    def get_df(N=10000, rows=100):
        """Generate random DataFrame."""
        from numpy import random, array
        from pandas import DataFrame
        from pandas.util.testing import makeCustomDataframe as mkdf
        return DataFrame(mkdf(N, nColumns=rows).get_values(),
                         columns=array([str(i) for i in range(rows)]))
    from tqdm import tqdm
    from tqdm.auto import tqdm as tqdm_auto
    try:
        from pandas import DataFrame
    except ImportError:
        return  # Skipping
    df = DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
    updated_df = df.groupby('x').progress_

# Generated at 2022-06-12 14:24:40.564461
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test to make sure tqdm_pandas() works as expected"""
    import pytest
    import numpy as np
    import pandas as pd
    from tqdm import tqdm_pandas

    assert tqdm_pandas is not None

    # test that tqdm_pandas works with tqdm objects
    # create a tqdm object
    t = tqdm_pandas(total=10)
    # test that it has an attribute of pandas
    assert hasattr(t, 'pandas')
    # check the status of the object after one iteration
    assert type(t.pandas()) is t.__class__
    # test that it has an attribute of pandas
    assert hasattr(t, 'pandas')

    # test that tqdm_pandas

# Generated at 2022-06-12 14:24:48.601675
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import random

    df = pd.DataFrame(
        [[random.randint(0, 100) for _ in range(10)]
         for _ in range(0, 1000)],
        columns=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
    )

    # tqdm_pandas(tqdm)
    tqdm_pandas(tqdm)
    df.groupby('a').progress_apply(lambda x: x ** 2)
    df.groupby('a').progress_apply(lambda x: x ** 2).progress_apply(lambda x: x ** 2)

# Generated at 2022-06-12 14:24:56.769887
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    with tqdm_pandas(total=100) as pbar:
        df = pd.DataFrame(
            {
                'A': np.random.randint(0, 5, size=100),
                'B': np.random.randint(0, 5, size=100)
            }
        )
        gb = df.groupby('A')
        result = gb.progress_apply(lambda x: x['B'].sum())
        pbar.update()

    assert isinstance(result, pd.core.series.Series)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:06.119741
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test the usage of function `tqdm_pandas`."""
    from tqdm import tqdm
    from pandas import DataFrame

    total = 10000

    def fib(n):
        return n if n < 2 else fib(n - 1) + fib(n - 2)

    df = DataFrame()
    # Register tqdm with `pandas.DataFrame`
    tqdm.pandas(**{'desc': 'fibonacci'})
    df['fib'] = [fib(i % 21) for i in range(total)] * 5

    # Apply tqdm to `pandas.DataFrame` (should use tqdm defaults)
    df.groupby('fib').progress_apply(lambda x: x)  # NOQA

    # Verify that tqdm is still registered

# Generated at 2022-06-12 14:25:10.837830
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm_pandas(tqdm, leave=True)
    assert "pandas" in tqdm.__module__
    df = pd.DataFrame({'a': [0, 1]})
    df.groupby('a').progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:20.961395
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test for tqdm_pandas
    """
    from tqdm import tqdm_pandas as tp
    from pandas import DataFrame
    from tqdm import tqdm

    data = [['01', 'a', '1'], ['02', 'b', '2'], ['02', 'c', '3'], ['03', 'a', '4'],
            ['03', 'b', '5'], ['04', 'c', '6']]

    df = DataFrame(data, columns=['No.', 'Name', 'Age'])
    df['Age'] = df.groupby(['No.', 'Name']).progress_apply(
        lambda x: tp(tqdm(x)).sum())

# Generated at 2022-06-12 14:25:29.128918
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    from tqdm import trange
    from tqdm._utils import _term_move_up
    from tqdm._tqdm import TMonitor
    from tqdm._utils import _supports_unicode
    from tqdm import TqdmTypeError

    df = pd.DataFrame(np.random.random((10000, 10000)))

    try:
        with tqdm(total=20) as pbar:
            if sys.version_info.major == 2:
                pbar.write("non-unicode")
        assert True
    except TypeError:
        assert False


# Generated at 2022-06-12 14:25:35.642857
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm_pandas(tqdm)
    # Test that it works
    df.groupby(0).progress_apply(lambda x: x**2)

    def f(x):
        return x**2

    df.groupby(0).progress_apply(f)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:46.047179
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import pandas as pd
    import numpy as np
    import tqdm

    N = 10000
    M = 10
    df = pd.DataFrame(np.random.random((N, M)))
    tqdm_pandas(tqdm)
    iter_length = len(df)
    pbar = tqdm.tqdm(total=iter_length)

    def _progress_apply(self, func, *args, **kwargs):
        """
        Registers the given `tqdm` instance with
        `pandas.core.groupby.DataFrameGroupBy.progress_apply`.
        """
        from tqdm import tqdm_notebook
        from tqdm.utils import _range


# Generated at 2022-06-12 14:25:56.135145
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series

    try:
        import pandas as pd  # noqa
    except ImportError:
        return
    from tqdm import tqdm
    import numpy as np

    df = DataFrame(np.random.randn(1, 3))
    srs = df[0]
    srs.name = 'foo'
    # Test df
    tqdm_kwargs = dict(total=df.shape[0])
    tqdm_pandas(tqdm, **tqdm_kwargs)
    srs = df.progress_apply(lambda x: x, axis=1)
    srs.name = 'foo'
    tqdm_pandas(tqdm(**tqdm_kwargs))

# Generated at 2022-06-12 14:26:09.196339
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, smoothing=0.01)
    tqdm_pandas(tqdm(), smoothing=0.01)
    tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm.tqdm, smoothing=0.01)


# Test for class `tqdm_notebook` and `tqdm_notebook()`

# Generated at 2022-06-12 14:26:13.005237
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    df = pd.DataFrame([[i] for i in range(1000)])
    tqdm_pandas(tqdm)
    df.groupby(0).progress_apply(lambda x: x)

# Generated at 2022-06-12 14:26:20.378833
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    try:
        import pandas
        tqdm_pandas(tqdm)
        raise Exception("Should have raised DeprecationWarning")
    except DeprecationWarning:
        pass
    try:
        import pandas
        tqdm_pandas(tqdm(total=10))
    except DeprecationWarning:
        raise Exception("Should not have raised DeprecationWarning")
    import pandas as pd
    pd.read_csv(os.path.join(os.path.dirname(__file__), 'README.md'),
                chunksize=10000).progress_apply(len)