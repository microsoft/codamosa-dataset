

# Generated at 2022-06-12 14:16:34.887602
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas as tqdm_pd
    from numpy.random import randint, random

    # =========================================================================
    # example 1: progress_apply
    # =========================================================================
    d = pd.DataFrame(randint(0, 10, (100000, 6)))
    d.groupby(0).progress_apply(lambda x: x**2)

    d.groupby(0).progress_apply(lambda x: x**2, tqdm=tqdm)

    # deprecated test
    tqdm_pd(tqdm)
    with tqdm(unit='myunit', unit_scale=True) as t:
        tqdm_pd(t)

# Generated at 2022-06-12 14:16:44.888174
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import Series
    import tqdm
    import random

    # initialize a series of length 10
    s = Series([random.randint(0, 10) for i in range(10)])

    # set up a tqdm instance
    with tqdm.tqdm(s) as pbar:
        res = s.progress_apply(lambda x: x)

    # set up a via tqdm_pandas
    with tqdm.tqdm(total=len(s)) as pbar:
        tqdm_pandas(pbar)
        res = s.progress_apply(lambda x: x)
        pbar.close()
        assert pbar._n == len(s)

    # test for dataframe
    # initialize a series of length 10
    df

# Generated at 2022-06-12 14:16:50.976498
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    # Dummy df
    df = DataFrame({'a': range(10), 'b': range(10, 20)})

    # Test with tqdm instance
    tqdm_pandas(tqdm())
    df.groupby(['a']).progress_apply(lambda x: x)

    # Test with tqdm class
    tqdm_pandas(tqdm)
    df.groupby(['a']).progress_apply(lambda x: x)

# Generated at 2022-06-12 14:16:54.997231
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
    except ImportError:
        return False
    assert DataFrame(dict(a=[1, 2, 3, 4], b=2)).groupby('b').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:04.035780
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for ``tqdm_pandas``
    """
    from .tqdm import tqdm
    from .pandas import trange

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, ascii=True)
    tqdm_pandas(trange)

    from .gui import tqdm
    from .pandas import trange

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, ascii=True)
    tqdm_pandas(trange)

    tqdm_pandas(tqdm(ascii=True))
    tqdm_pandas(trange(ascii=True))


# Generated at 2022-06-12 14:17:09.030810
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    from tqdm.auto import tqdm
    import numpy as np
    import pandas as pd
    n = 100
    df = pd.DataFrame( np.random.randn(n, 2), columns=list(range(2)) )
    tqdm_pandas( tqdm( desc='test_tqdm_pandas' ) )
    df.groupby( 0 ).progress_apply( lambda x: x**2 )

# Generated at 2022-06-12 14:17:12.839561
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd, tqdm
    df = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
    tqdm.tqdm_pandas(tqdm.tqdm())
    df.groupby('A').progress_apply(len)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:18.441560
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    # Make sure we don't print the "Please use `tqdm.pandas(...)` instead" warning
    import pandas.core.groupby  # noqa
    import pandas.core.apply  # noqa

    df = pd.DataFrame({'a': np.arange(1000), 'b': np.random.randn(1000)})
    # tqdm_pandas(tqdm)
    df.groupby('a').progress_apply(lambda x: x)
    # tqdm_pandas(tqdm())
    df.groupby('a').progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:26.486525
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:17:33.043441
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return

    from tqdm import tqdm
    tqdm.pandas(desc="test")
    assert hasattr(pd.core.groupby.DataFrameGroupBy, 'progress_apply')
    assert hasattr(pd.core.groupby.SeriesGroupBy, 'progress_apply')

    for obj in [pd.core.groupby.DataFrameGroupBy, pd.core.groupby.SeriesGroupBy]:
        obj.progress_apply = None
    assert not hasattr(pd.core.groupby.DataFrameGroupBy, 'progress_apply')
    assert not hasattr(pd.core.groupby.SeriesGroupBy, 'progress_apply')


# Generated at 2022-06-12 14:17:43.631572
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Check tqdm_pandas() is working"""
    import pandas as pd
    import numpy as np
    import tqdm

    # Create a test DataFrame
    try:
        import cStringIO as StringIO
    except ImportError:
        import StringIO
    with tqdm.tqdm() as t:
        test_csv = (
            "col1,col2\n"
            "abc,1\n"
            "def,1\n"
            "ghi,1\n"
        )
        df = pd.read_csv(StringIO.StringIO(test_csv))
        t.close()

    # Test DataFrameGroupBy.progress_apply()
    group = df.groupby('col2')
    df_group = group.progress_apply(len)
    df

# Generated at 2022-06-12 14:17:53.964703
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        raise unittest.SkipTest(
            "Test tqdm_pandas requires pandas package.")

    from tqdm import tqdm

    def test():
        """Simple function to test if progress tqdm is working"""
        for i in tqdm(range(4)):
            time.sleep(0.1)
        return

    # Call the test func to get the ProgressBar obj
    test()
    t = test()
    # t is a ProgressBar obj
    # use tqdm_pandas to register tqdm with pandas
    tqdm_pandas(t)
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)),
                      columns=list('ABCDEF'))
   

# Generated at 2022-06-12 14:17:55.007309
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)



# Generated at 2022-06-12 14:18:01.596105
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas."""
    try:
        import pandas
    except ImportError:
        pass
    else:

        def func(x):
            time.sleep(1)
            return x

        def test_args(**kwargs):
            tqdm_pandas(**kwargs)
            pandas.DataFrame({'a': [1, 2, 3]}).groupby('a').progress_apply(func)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
            yield test_args, {'tclass': tqdm}

# Generated at 2022-06-12 14:18:08.177727
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Example manual test for `tqdm_pandas`"""
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib.tests import skip_if_no_pandas

    skip_if_no_pandas()
    df = pd.DataFrame([i for i in range(10000)])
    with tqdm(total=len(df), mininterval=0.5) as prog_bar:
        df.progress_apply(lambda x: x)
    assert prog_bar.n == len(df)

# Generated at 2022-06-12 14:18:14.578812
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:18:19.488357
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Setup
    prog = tqdm(total=100, leave=False, ascii=True, unit='B',
                unit_scale=True, dynamic_ncols=True)
    # Unit test
    assert tqdm_pandas(prog) is None
    # Teardown
    prog.close()

# Generated at 2022-06-12 14:18:27.907857
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange
    import numpy as np
    import pandas as pd
    tqdm_pandas(tqdm)

    @pd.api.extensions.register_dataframe_accessor("tqdm")
    class MyProgressBar(object):
        def __init__(self, pandas_obj):
            self._obj = pandas_obj

        def progress_apply(self, func, **kwargs):
            import sys

            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except:
                    e = sys.exc_info()[0]
                    tqdm.write("error: {}".format(e))
                    raise


# Generated at 2022-06-12 14:18:32.643012
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from tqdm import tqdm

    tqdm(pandas=True)
    tqdm(pandas=True, file=sys.stderr)
    tqdm(pandas=True, file=tqdm.tqdm_gui.default_gui.fp)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:40.247072
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 1)))

    with tqdm(total=len(df.index), mininterval=0, miniters=1, unit='',
              bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}') as progress_bar:
        def progress(x):
            progress_bar.update()
            return x

        df = df.groupby(0, group_keys=False).progress_apply(progress)

# Generated at 2022-06-12 14:18:53.359245
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange
    from tqdm._utils import _term_move_up

    df = pd.DataFrame({
        'A': list(range(5)),
        'B': list(range(5, 10))
    })

    tqdm_pandas(tqdm(desc="testing", total=len(df), unit='row', leave=False))
    new_df = df.groupby(['A']).progress_apply(lambda x: x['B'] + 1)

    # Test cli output
    trange(3, file=tqdm.write)
    tqdm.write('')
    assert tqdm.write('foo') is None
    tqdm.write('\rbar')

# Generated at 2022-06-12 14:19:03.037425
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    def _slow_concat(df):
        try:
            return df.apply(lambda x: 1 + _slow_concat(x))
        except AttributeError:
            return df

    # Only to instantiate TqdmDeprecationWarning
    try:
        tqdm_pandas(tqdm)
    except DeprecationWarning:
        pass
    df = DataFrame([[1, 2], [3, 4]])
    assert all(x == 2 for x in tqdm(df.groupby(0, sort=False).progress_apply(_slow_concat)).flatten())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:13.516845
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    import pandas
    from tqdm import tqdm as tqdm_std
    from tqdm import tqdm_notebook
    from tqdm import trange
    from tqdm import format_size

    # Pandas version >= 0.18.0
    pandas_version = [int(x) for x in pandas.__version__.split('.')]
    if pandas_version >= [0, 18, 0]:
        from pandas.core.groupby import DataFrameGroupBy

        def progress_apply(self, func, *args, **kwargs):
            progress_kwargs = {'total': len(self)}

            if 'desc' in kwargs:
                progress_kwargs['desc'] = kwargs['desc']

# Generated at 2022-06-12 14:19:24.415663
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy
    import pandas
    import tqdm
    tqdm.pandas(tqdm.tqdm)
    tqdm.pandas(tqdm.tqdm(ascii=True))
    tqdm.pandas(tqdm.tqdm(ascii=True), unit_scale=True)
    tqdm.pandas(tqdm.tqdm(ascii=True), unit='cells')
    tqdm.pandas(tqdm.tqdm(ascii=True), unit_scale=True, unit='cells', miniters=1)
    numpy.random.seed(10)

# Generated at 2022-06-12 14:19:26.546094
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        tqdm_pandas(tqdm())
        return True
    except Exception:
        return False

# Generated at 2022-06-12 14:19:33.920191
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    tqdm.pandas(tqdm())

    df_m2 = pd.DataFrame(dict(
        A=pd.Series(np.random.randint(1, 50, 100)),
        B=pd.Series(np.random.randint(1, 50, 100)),
        C=pd.Series(np.random.randint(1, 50, 100)),
        D=pd.Series(np.random.randint(1, 50, 100)),
        E=pd.Series(np.random.randint(1, 50, 100))))

    def f(x):
        return x

    df_m2.groupby(['A']).progress_apply(f)

# Generated at 2022-06-12 14:19:42.109556
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for tqdm_pandas """
    from tqdm import tqdm
    from pandas import DataFrame
    import numpy as np

    data = np.random.rand(10000, 2)
    df = DataFrame(data)
    # creates a tqdm instance
    t = tqdm(ascii=True, desc='Loop 1')
    dfs = df.groupby(0)
    # register the instance with pandas
    tqdm_pandas(t)
    # apply a function to the groupby
    _ = dfs.progress_apply(lambda x: x)

# Generated at 2022-06-12 14:19:48.378387
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tclass = tqdm.pandas(leave=True)

    # The following code is only executed if tqdm_pandas is called directly
    # (which it should NOT be)
    def f(x):
        return x
    ret = tclass.progress_apply(f, axis=0)
    assert ret is None


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:56.672200
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame({'num_legs': [2, 4], 'num_wings': [2, 0]},
                      index=['falcon', 'dog'])

    tqdm_pandas(df.groupby(df.columns, axis=1).progress_apply(
        lambda x: x**2))  # returns DataFrame with column names 'num_legs' and 'num_wings'


if __name__ == "__main__":
    from tests_tqdm import utils

    utils.run_tests(globals())

# Generated at 2022-06-12 14:20:06.644636
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import sys
    from io import StringIO
    # numpy 1.17+ generates a FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated
    # we must be sure not to generate any warning
    tqdm_stdout = StringIO()
    tqdm_stderr = StringIO()

# Generated at 2022-06-12 14:20:19.029791
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    from tqdm import tqdm

    tqdm_pandas(tqdm, unit='it', unit_scale=True, unit_divisor=1024)
    try:
        import pandas

        df = pandas.DataFrame(dict(a=[4, 5, 6, 7, 8],
                                   b=[r'{0}\nand\n{1}'.format(i, i + 1)
                                      for i in range(5)]))
        progress_bar = tqdm(total=len(df))
        progress_bar.set_description('test')
        progress_bar.update(len(df.groupby('b').progress_apply(len)))
    finally:
        pandas.core.groupby.DataFrameGroupBy.progress_apply = (
            _orig_progress_apply)

# Generated at 2022-06-12 14:20:24.155171
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'y': np.random.randn(100)})
    gp = df.groupby('y')
    tqdm_pandas(lambda: gp.progress_apply(lambda x: x))
    tqdm_pandas(gp.progress_apply(lambda x: x))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:34.832185
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for `tqdm.pandas`
    """
    import json
    import pandas as pd
    import numpy as np
    from tqdm import trange
    from .std import TqdmTypeError, TqdmKeyError, TqdmWarning
    from .gui import tqdm
    from .auto import trange, tqdm
    from .tqdm_pandas import tqdm_pandas
    from .tqdm import TqdmExperimentalWarning

    try:
        from tqdm.contrib.concurrent import process_map
    except ImportError:
        process_map = None

    try:
        from pandarallel import pandarallel
    except ImportError:
        pandarallel = None


# Generated at 2022-06-12 14:20:45.888007
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:20:52.795387
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import arange
    l = arange(50)
    p = DataFrame({'a': Series(l), 'b': Series(l, index=[x for x in range(2, 52, 2)])})
    tqdm_pandas(p.groupby('a').progress_apply(lambda x: len(x)))
    tqdm_pandas(p.groupby('a').progress_apply(lambda x: len(x) + 1))
    tqdm_pandas(p.groupby('b').progress_apply(lambda x: len(x) + 1))
    tqdm_pandas(p.groupby('b').progress_apply(lambda x: len(x) + 1, meta=list('abc')))
    tqdm_pand

# Generated at 2022-06-12 14:21:04.192487
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    tqdm.tqdm_pandas(tqdm.tqdm())
    tqdm.tqdm_pandas(tqdm.tqdm_notebook())
    tqdm.tqdm_pandas(tqdm.tqdm_gui())
    tqdm.tqdm_pandas(tqdm.trange())
    pandas_mock = pd.DataFrame({'foo': [1, 2, 3]})
    tqdm.tqdm_pandas(tqdm.tqdm())
    tqdm.tqdm_pandas(tqdm.tqdm_notebook())

# Generated at 2022-06-12 14:21:12.276373
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas
    tqdm.pandas(tqdm)

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.progress_apply(lambda x: x**2)
    assert df.progress_apply(lambda x: x**2).equals(df.apply(lambda x: x**2))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:20.684822
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test for tqdm_pandas function
    """
    class tqdm(object):  # dummy tqdm for testing
        def pandas(self):
            pass
    tqdm_pandas(tqdm)

    class tqdm(object):
        @classmethod
        def pandas(self):
            pass
    tqdm_pandas(tqdm)

    class tqdm(object):
        @staticmethod
        def pandas():
            pass
    tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:21:27.914779
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    data = pd.DataFrame(pd.np.random.randint(0,100,size=(100000, 4)), columns=list('ABCD'))
    tqdm.pandas(desc="test_pandas")
    data['E'] = data[['A', 'B', 'C', 'D']].progress_apply(
        lambda x: x[0] + x[1] + x[2] + x[3], axis=1)
    #print(data.head())



# Generated at 2022-06-12 14:21:29.639119
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    return


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:34.580598
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.random((10000, 1)))
    tqdm_pandas(tqdm(total=len(df)))
    #tqdm_pandas(tqdm)

# Generated at 2022-06-12 14:21:44.011238
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        pd = None
        return None
    t = tqdm_pandas(tqdm(total=100), desc='Group A')
    df = pd.DataFrame(dict(A=[1, 2, 3], B=[3, 2, 1]))
    assert list(df.groupby('A').progress_apply(lambda x: x)) == df.groupby('A').apply(
        lambda x: x).tolist()
    t.close()
    assert t.n == 100

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:52.618550
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import itertools as it
    import random
    import sys

    df = pd.DataFrame(list(zip(
        *it.islice(it.cycle([xrange(10) for i in range(20)]), 100))))
    df = pd.concat([df] * 90, ignore_index=True)

    df.groupby(
        0,
        group_keys=False,
    ).progress_apply(
        lambda x: random.choice(x[1:].values)
    )
    try:
        tqdm_pandas(tqdm(total=1), desc='test')
    except TypeError:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-12 14:22:01.113974
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        try:
            import pandas
        except ImportError:
            return None
    else:
        tqdm_pandas(tqdm)
        df = pd.DataFrame({'key': [1] * 5, 'data': range(5)})
        type(tqdm).pandas(tqdm)  # No-op
        tclass = tqdm(df.groupby('key').progress_apply(lambda _: None))
        tqdm_pandas(tclass)
        tqdm_pandas(tclass, ncols=100)
        tqdm_pandas(tclass, mininterval=0.5)
        tqdm_pandas(tqdm(total=5))


# Generated at 2022-06-12 14:22:08.967460
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # Test a simple case
    df = pd.DataFrame({"x": [1, 2, 3]})
    assert list(df.groupby("x").progress_apply(lambda x: x)) == list(df.groupby("x").apply(lambda x: x))

    # Test a more complex case where apply method is not implemented
    class TestClass:
        def __init__(self, x):
            self.x = x

        def progress_apply(self, func, **kwargs):
            return func(self.x)

    df = pd.DataFrame({"x": [TestClass(1), TestClass(2), TestClass(3)]})

# Generated at 2022-06-12 14:22:19.267327
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test case 1 - normal function call
    try:
        tqdm_pandas('tqdm_notebook')
    except Exception as e:
        raise AssertionError(e)

    # Test case 2 - delayed adapter case
    try:
        tqdm_pandas(tqdm_notebook)
    except Exception as e:
        raise AssertionError(e)


# Test case 1 - normal function call
try:
    test_tqdm_pandas()
except Exception as e:
    print('[FAIL] test_tqdm_pandas: test case 1 failed')
    raise e
else:
    print('[PASS] test_tqdm_pandas: test case 1 passed')

# Generated at 2022-06-12 14:22:26.008295
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randn(5, 3), columns=['a', 'b', 'c'])
    df.progress_apply(lambda x: x * x)


if __name__ == "__main__":
    from tqdm.pandas import tqdm_pandas
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:34.992625
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from pandas.core.groupby import DataFrameGroupBy

    # Create a test DataFrame with 5 groups
    data = pd.DataFrame(dict(
        A=np.random.randint(0, 5, 20000),
        B=np.random.randint(0, 5, 20000),
        C=np.random.randint(0, 5, 20000),
        D=np.random.randint(0, 5, 20000),
        E=np.random.randint(0, 5, 20000)))

    # Decorate the pandas.core.groupby.DataFrameGroupBy.progress_apply method
    # with tqdm_pandas()

# Generated at 2022-06-12 14:22:45.508598
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # Test Series.apply
    x = pd.Series(range(10), name="foo")
    pd.Series.progress_apply = tqdm_pandas
    # -------------------------
    # Delayed adapter
    tqdm_pandas(tqdm, leave=False)
    tqdm_pandas(tqdm)
    # -------------------------
    # Direct
    x.progress_apply(lambda x: x)
    # -------------------------
    # With nested loop:
    for _ in tqdm(range(3), leave=False):
        x.progress_apply(lambda x: x)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:52.678018
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    # Create the dataframe
    df = pd.DataFrame({'a': np.random.rand(10000),
                       'b': np.random.rand(10000)})

    # Apply the function tqdm_pandas
    try:
        result = df.groupby('a').progress_apply(np.mean)
    except TypeError:
        pass

# Generated at 2022-06-12 14:22:59.262295
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class tqdm():
        def __init__(self, total):
            self.n = 0
            self.total = total
            self.fp = None

        def update(self, n):
            self.n = n

        def pandas(self, *args, **kwargs):
            return

    try:
        tqdm_pandas(tqdm)
    except Exception as e:
        raise e

# Generated at 2022-06-12 14:23:01.965459
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    dataframe = pandas.DataFrame({'foo': [1,2,3,4], 'bar': [0,0,1,1]})
    dataframe.groupby('bar').progress_apply(lambda x: x)

# Generated at 2022-06-12 14:23:09.061440
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame([(x, x) for x in range(10)], columns=["a", "b"])

    def func(x):
        x += 1
        return x

    with tqdm.tqdm() as pbar:
        pbar.total = len(df)
        tqdm.pandas(pbar)
        df.progress_apply(func)
    assert pbar.total == len(df)
    assert pbar.n == 10

# Generated at 2022-06-12 14:23:15.286627
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'x': list(range(10))})
    tqdm_pandas(tqdm, total=len(df))
    df.groupby('x').progress_apply(lambda g: pd.DataFrame({'y': list(range(len(g)))}))
    df.groupby('x').progress_apply(lambda g: pd.DataFrame({'y': list(range(len(g)))}), meta='group')

# Generated at 2022-06-12 14:23:17.916913
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.contrib.tests import T, tclass

    with T.assert_produces_warning():
        tqdm_pandas(tclass())

# Generated at 2022-06-12 14:23:20.008899
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    return tqdm_pandas(tqdm(range(10)))

# Generated at 2022-06-12 14:23:26.492725
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        # Deprecated way
        from tqdm import tqdm
        from tqdm import tqdm_notebook
    except ImportError:
        return
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)

    # Delayed adapter
    import pandas as pd
    pd.DataFrame().progress_apply(lambda x: x, desc="df tqdm")


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:31.875335
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import random

    # Create random DataFrame
    df = pd.DataFrame(
        {'a': [random.randint(0, 10) for _ in range(100)],
         'b': [random.randint(0, 10) for _ in range(100)]})

    # Measure progress_apply()
    tqdm_pandas(df.groupby('a').progress_apply(sum))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:40.741069
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .std import tqdm
    import pandas as pd

    df = pd.DataFrame(dict(a=range(1000)))
    tqdm.pandas(tqdm)
    # test auto `tqdm` naming
    assert hasattr(df.groupby('a'), 'tqdm_notebook')
    # test registered progress_apply
    assert df.groupby('a').progress_apply(len).equals(df.groupby('a').apply(len))
    assert not (df.groupby('a').progress_apply(len) - df.groupby('a').apply(len)).any()
    assert np.all(df.groupby('a').progress_apply(len) == df.groupby('a').apply(len))
    from .std import gc
    gc.collect()   #

# Generated at 2022-06-12 14:23:43.142234
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame(dict(a=range(100)))
    for i in tqdm_pandas(df.groupby('a')):
        pass

# Generated at 2022-06-12 14:23:55.941404
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""

    class TClass:
        @classmethod
        def pandas(cls, **kwargs):
            pandas(cls, **kwargs)

    class DeprecatedTClass:
        @classmethod
        def pandas(cls, deprecated_t):
            assert type(tclass).pandas == pandas
            assert deprecated_t is tclass

    global pandas
    for deprecated in [False, True]:
        tqdm_kwargs = {'mininterval': 1, 'miniters': 1}

        # tqdm_pandas(tclass, tqdm_kwargs)
        class_dict = {}

# Generated at 2022-06-12 14:24:04.278368
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.notebook import tqdm
    # Check that tqdm_pandas works
    tqdm_pandas(tqdm)
    # Create dataframe
    df = pd.DataFrame(np.random.rand(1000,4))
    sum_ = df.groupby(0).progress_apply(lambda x: x.sum())

test_tqdm_pandas()

# %%
#TQDM
#https://github.com/tqdm/tqdm
#Use tqdm.pandas()
#Use tqdm_notebook
#Use tqdm_gui()

#tqdm.pandas not working!
# %%
#https://medium.com/@jasonrig/speeding

# Generated at 2022-06-12 14:24:08.960914
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import pandas as pd
    from time import sleep
    from numpy.random import rand

    df = pd.DataFrame({'a': rand(1000), 'b': rand(1000), 'y': rand(1000)})

    # Test deprecated use case #1
    try:
        import tqdm
        tqdm.pandas(tqdm.tqdm(leave=False, file=sys.stderr))
    except Exception as e:
        sys.stderr.write("Unit test failed. Exception: {}\n".format(e))
        exit(1)

    # Test deprecated use case #2

# Generated at 2022-06-12 14:24:13.214804
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from tqdm import tqdm, trange
    except ImportError:
        return

    for t in [tqdm, trange]:
        assert (tqdm_pandas(t) is t)
        assert (tqdm_pandas(t(), leave=True, desc="Test") is t)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:24.816201
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm.utils.tqdm_pandas`"""
    import pandas
    from pandas import DataFrame
    from pandas import Series
    from numpy import random

    df = DataFrame(random.randint(1, 100, (100000, 4)), columns=list('abcd'))
    tqdm_pandas(tqdm).progress_apply(lambda x: x.sum(), axis=0)
    tqdm_pandas(tqdm).progress_apply(lambda x: x.sum(), axis=1)
    tqdm_pandas(tqdm).progress_aggregate(lambda x: x.sum(), axis=0)
    tqdm_pandas(tqdm).progress_aggregate(lambda x: x.sum(), axis=1)
    t

# Generated at 2022-06-12 14:24:35.082507
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy import random

    tqdm_pandas(tclass=tqdm, desc='foo', file=sys.stderr)

    def _(x):
        return x

    random.seed(0)
    df1 = DataFrame(random.randint(0, 100, (100000, 6)))
    df2 = df1.copy()

    df2.progress_apply(_, axis=1)

    tqdm_pandas(tclass=tqdm, desc='foo')
    df2.progress_apply(_, axis=1)
    assert df1.equals(df2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:41.806715
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import sys
    import pandas as pd
    from tqdm import tqdm
    from tqdm.pandas import tqdm_pandas

    if sys.version_info[0] == 3:
        # tqdm.pandas is an optional dependency in Python 3
        try:
            import tqdm.pandas
            assert tqdm_pandas is tqdm.pandas.tqdm_pandas
        except ImportError:
            pass


# Need to keep this class for backwards compatibility with previous versions.

# Generated at 2022-06-12 14:24:45.982340
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    df = DataFrame(index=range(4), columns=['a', 'b', 'c'])
    df['a'] = range(4)
    df['b'] = [0.3, 0.1, 0.5, 0]

    # reg

# Generated at 2022-06-12 14:24:50.922968
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        print('Skipping pandas tests...', file=sys.stderr, flush=True)
        return
    from tqdm import tqdm, tqdm_pandas  # NOQA

    N = 100
    # Create random dataframe
    df = pandas.DataFrame({'id': list(range(N)),
                           'val': np.random.randint(1, 10, size=N)})

    # Test with tqdm instance
    df.groupby('val').progress_apply(lambda x: x, tqdm_instance=tqdm(total=N, leave=False))

    # Test with tqdm class
    tqdm_pandas(tqdm, total=N, leave=False)
    df.groupby

# Generated at 2022-06-12 14:24:54.531011
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame(range(100))
    df.groupby(0).progress_apply(lambda x: x)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:00.978290
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    tqdm_pandas(tqdm(total=1, file=sys.stdout))
    tqdm_pandas(tqdm_notebook(total=1, file=sys.stdout))
    tqdm_pandas(tqdm(total=1))
    tqdm_pandas(tqdm_notebook(total=1))
    tqdm_pandas(tqdm(total=1, file=sys.stdout), ascii=True)
    tqdm_pandas(tqdm_notebook(total=1, file=sys.stdout), ascii=True)
    tqdm_pandas(tqdm(total=1), ascii=True)


# Generated at 2022-06-12 14:25:09.869746
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    df = DataFrame({'c': ['a', 'b', 'c'] * 100,
                    'd': [1, 2, 3] * 100})
    if not os.environ.get("TRAVIS", False):
        assert df.groupby('c', sort=False).progress_apply(len).sum().item() == 300
        with tqdm(leave=True, position=0) as t:
            assert df.groupby('c', sort=False).progress_apply(len, tqdm_kwargs={
                'leave': True, 'position': 0, 'tqdm': t}).sum().item() == 300

# Generated at 2022-06-12 14:25:19.925492
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for the function `tqdm_pandas`."""
    from tqdm.auto import tnrange, tqdm
    from pandas import DataFrame
    from numpy.random import random
    from time import sleep

    # # Test deprecated behaviours
    # with tqdm(total=1) as t:
    #     t.pandas("")
    # with tqdm(total=1) as t:
    #     tqdm_pandas(t)
    # import tqdm_pandas as tqdm
    # with tqdm(total=1) as tq:
    #     tq.pandas("")
    # with tqdm(total=1) as t:
    #     tqdm_pandas(tqdm(total=1))
   

# Generated at 2022-06-12 14:25:22.295313
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm_notebook)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:28.789611
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for tqdm_pandas()."""
    try:
        from pandas import DataFrame
    except ImportError:
        raise SkipTest
    from tqdm import tqdm

    def dumb_func(x):
        return x

    test_df = DataFrame({'x': list(range(10))})
    test_df.groupby('x').progress_apply(dumb_func)

    for tclass in [tqdm, tqdm(range(1))]:
        tclass.pandas = None
        tqdm_pandas(tclass, unit='rows')
        assert tclass.pandas is not None

# Generated at 2022-06-12 14:25:32.751273
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import CommonTestCases as tt
    from tqdm.tests.pandas_tests import CommonPandasTestCases as pt
    with pt.test_pandas(tqdm_pandas, tt.smoke_test_tqdm) as pbar:
        _ = pbar.apply(str)

# Generated at 2022-06-12 14:25:38.059503
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    import pandas as pd

    # Test old version
    try:
        tqdm_pandas(tclass=trange(10), desc='hi')
    except (RuntimeError, TypeError, DeprecationWarning):
        pass

    # Test new version
    tqdm_pandas(tclass=trange(10, desc='hi', unit='i'))

    # Test pre-installed version
    tqdm_pandas(tclass=trange(10))

    # Test range()
    assert pd.DataFrame({'a': list(range(6))}).groupby('a').progress_apply(lambda x: x * 2)['a'].tolist() == [0, 2, 4, 6, 8, 10]



# Generated at 2022-06-12 14:25:47.651585
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm import trange
    from tqdm._tqdm import TqdmTypeError

    with pytest.raises(TqdmTypeError):
        tqdm_pandas(range(1))

    with pytest.raises(TqdmTypeError):
        tqdm_pandas(42)

    pd.DataFrame([1, 2, 3]).groupby(1).progress_apply(lambda x: x ** 2)

    # Test multi-level index
    pd.DataFrame([1, 2, 3]).groupby([1, 2]).progress_apply(lambda x: x ** 2)

    # Test Pandas 0.25

# Generated at 2022-06-12 14:25:57.896815
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import trange
    from tqdm import tqdm

    # Static unit tests
    pbar = tqdm(**tqdm_kwargs)
    try:
        pbar.pandas(1.0 / 0.0)
    except:  # noqa
        pass
    assert pbar.total == 1

    pbar = tqdm(**tqdm_kwargs)
    pbar.pandas(range(10))
    assert pbar.total == 10
    assert pbar.n == 9

    pbar = tqdm(**tqdm_kwargs)
    pbar.pandas(range(10), total=20)
    assert pbar.total == 20
    assert pbar.n == 9


# Generated at 2022-06-12 14:26:03.538562
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)
    try:
        import pandas as pd
        try:
            pd.DataFrame([1, 2, 3]).progress_apply(lambda x: x * x)
        except AttributeError:
            pass  # newer pandas
    except ImportError:
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:26:16.364944
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    n = numpy.random.randint(0, 2, 10)
    x = numpy.random.normal(0, 1, 10)
    df = pandas.DataFrame({'n': n, 'x': x})
    import tqdm
    with tqdm.tqdm(total=3) as tbar:
        def f(df):
            with tqdm.tqdm(total=len(df),
                           leave=False,
                           unit='x',
                           position=2,
                           file=sys.stderr) as tdf:
                tdf.update(len(df)//2)
                return df.x.sum()
        df.progress_apply(f, axis=1, result_type='broadcast')
        tbar.update

# Generated at 2022-06-12 14:26:24.324825
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Usage:
    $ python3 -m tqdm.tests.test_tqdm_pandas
    """
    # from tqdm import TqdmDeprecationWarning
    from tqdm import tqdm
    from tqdm import trange
    from tqdm import tnrange
    import pandas as pd

    # Should pass without errors
    tqdm_pandas(tqdm)
    tqdm_pandas(trange)
    tqdm_pandas(tnrange)
    pd.DataFrame([1, 2, 3]).groupby(0).progress_apply(lambda x: x)

    # Should throw deprecated warning
    # TODO: check deprecated warning
    tqdm_pandas(tqdm, file=sys.stderr)



# Generated at 2022-06-12 14:26:27.904769
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd

    for t in [tqdm, tqdm(range(0))]:
        tqdm_pandas(t)
        assert hasattr(pd.DataFrame.progress_apply, '_tqdm_cls')


if __name__ == '__main__':
    test_tqdm_pandas()