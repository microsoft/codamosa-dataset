

# Generated at 2022-06-12 14:16:24.213227
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm_pandas(tqdm)
    try:
        import pandas
        assert 'pandas' in tqdm.__dict__
    except ImportError:
        pass

# Generated at 2022-06-12 14:16:30.604492
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class TqdmCls():
        def __init__(self):
            pass

        def pandas(self, **tqdm_kwargs):
            print("Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm(...))`.")

    tqdm_pandas(TqdmCls())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:16:38.110795
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    with tqdm(total=10) as t:
        pd.DataFrame(t.n).progress_apply(t.update)

    with tqdm(total=10) as t:
        tqdm_pandas(t)
        pd.DataFrame(t.n).progress_apply(t.update)

    with tqdm(total=10) as t:
        tqdm_pandas(tclass=t)
        pd.DataFrame(t.n).progress_apply(t.update)

    with tqdm(total=10) as t:
        tqdm_pandas(tclass=t, mininterval=0.01)
        pd.DataFrame(t.n).progress_

# Generated at 2022-06-12 14:16:47.255079
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        # with tqdm._utils.maybe_tqdm(lambda x: x, disable=True) as pbar:
        with tqdm.pandas(disable=True) as pbar:
            pbar.update(1)
    except TypeError:
        # disable=None (default)
        return False

    df = tqdm.pandas(
        pd.DataFrame({'dummy': [1] * 3})
    ).progress_apply(lambda x: x + 1)
    if len(df.index) != 3:
        return False
    return True


if __name__ == "__main__":
    assert test_tqdm_pandas(), "tqdm.pandas() failed"
    print("OK")

# Generated at 2022-06-12 14:16:54.027384
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas

    df = pd.DataFrame(np.arange(25).reshape(5, 5))
    df.groupby(0).progress_apply(lambda x: x**2)
    tqdm_pandas(df.groupby(0)).apply(lambda x: x**2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:03.058619
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm as tqdm_pandas
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'a': np.random.random(100),
                       'b': np.random.random(100)})
    df.groupby('a').progress_apply(lambda x: x ** 2)
    with tqdm_pandas(total=10, desc="Loading...") as t:
        for i in range(10):
            t.update()
    with tqdm_pandas(total=10, desc="Loading...", unit_scale=True) as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-12 14:17:06.070355
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        tqdm_pandas(tqdm)
        assert False
    except TqdmDeprecationWarning as e:
        assert "Please use `tqdm.pandas()`" in str(e)



# Generated at 2022-06-12 14:17:13.354554
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    # Unit test for class tqdm
    df = pd.DataFrame(np.random.randint(0, 10, (100000, 6)),
                      columns=list('ABCDEF'))
    with tqdm.pandas(total=5):  # 5 is just a progress bar length
        df.groupby('A').progress_apply(lambda x: x)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:23.233597
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import os
    import tempfile
    import tqdm

    # Run tqdm_pandas after completion
    tfile = tempfile.NamedTemporaryFile(mode='w+')
    data = {'a': np.random.randint(0, 10, size=20),\
            'b': np.random.randint(0, 10, size=20),\
            'c': np.random.randint(0, 10, size=20)}
    df = pd.DataFrame(data)

    def func(grp):
        return grp['a'] * grp['b'] * grp['c']

    res = df.groupby('b').progress_apply(func)
    print('\n' + str(res))
    tq

# Generated at 2022-06-12 14:17:30.944273
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame([1, 2, 3])
    tqdm_pandas(tqdm(total=len(df)))


if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
#    doctest.testmod(optionflags=doctest.REPORT_UDIFF)
#    doctest.testmod(optionflags=doctest.REPORT_CDIFF)
#    doctest.testmod(optionflags=doctest.REPORT_NDIFF)
#    doctest.testmod(optionflags=doctest.REPORT_ONLY_FIRST_FAILURE)

# Generated at 2022-06-12 14:17:42.697048
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm._tqdm import TqdmDefaultWarning
    from tqdm._tqdm_gui import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)

# Generated at 2022-06-12 14:17:49.689339
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        print("SKIP: pandas not installed")
        return True

    try:
        df = pandas.DataFrame(dict(a=[1, 2]))
        tqdm_pandas(df.groupby('a').sum().progress_apply(lambda x: x))
    except Exception:
        return False
    return True

if __name__ == '__main__':
    assert test_tqdm_pandas()

# Generated at 2022-06-12 14:17:54.516221
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randint(1, 4, (100, 100)))
    df.groupby(0).progress_apply(lambda x: x)
    tqdm_pandas(tqdm(), leave=True, smoothing=1)
    df.groupby(0).progress_apply(lambda x: x)
    # tqdm_pandas(tqdm(leave=True, smoothing=1))
    # df.groupby(0).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:04.437002
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm

    for t in [tqdm, tqdm_pandas]:
        df = pandas.DataFrame({'a': list(range(10))})

        # tqdm test
        with t(total=len(df)) as pbar:
            def f(df, pbar=pbar):
                for _, row in df.iterrows():
                    pbar.update()
            s = df.groupby(df.a // 2).progress_apply(f)

        # tqdm_notebook test
        try:
            from tqdm import tqdm_notebook
        except ImportError:
            pass

# Generated at 2022-06-12 14:18:08.448534
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # From tqdm/tests/test_pandas.py
    import pandas as pd
    import tqdm

    @tqdm.pandas()
    def transform(x):
        time.sleep(0.01)
        return x

    df = pd.DataFrame({'a': list(range(100))})
    df['b'] = transform(df.a)
    assert all(df.a == df.b)

# Generated at 2022-06-12 14:18:14.761598
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook
    from random import shuffle
    from pandas import DataFrame

    def random_df(n=100):
        """Sample function to create a (n, n) DataFrame"""
        df = DataFrame(dict(((chr(65+i),
                              [i]*(n//2) + [i**2]*(n-n//2)) for i in range(n))))
        shuffle(df.columns)
        shuffle(df.index)
        return df

    df = random_df()
    kwargs = dict()
    tqdm_pandas(tqdm, **kwargs)
    df_tqdm = df.progress_apply(lambda _: None)

# Generated at 2022-06-12 14:18:23.483709
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas
        df = pd.DataFrame(np.random.rand(100, 100))
        _ = df.groupby(lambda x: x % 20).progress_apply(lambda x: x ** 2)
    except Exception:
        raise ImportError("tqdm_pandas tests failed")
    else:
        del pd
        del np


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:34.805400
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random
    from tqdm.auto import trange
    import pandas as pd
    import numpy as np

    # Define helper functions
    def tqdm_pandas(tclass, **tqdm_kwargs):
        # Registers the given `tqdm` instance with
        # `pandas.core.groupby.DataFrameGroupBy.progress_apply`.
        from tqdm import TqdmDeprecationWarning


# Generated at 2022-06-12 14:18:40.155159
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np

        # Create test data
        df = pd.DataFrame(np.random.rand(1000, 5))

        # Define a progress bar
        from tqdm import tqdm
        pbar = tqdm(total=len(df))

        # Register the progress bar with the pandas progress_apply method
        tqdm_pandas(pbar)

        # Apply a function to the dataframe (this will automatically update
        # the progress bar).
        df.progress_apply(lambda x: x)
    except:
        return False
    return True

# Generated at 2022-06-12 14:18:51.024022
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from pandas import DataFrame

    for tqdm_cls in [tqdm, tqdm_notebook, tqdm_gui]:
        with tqdm_cls(total=10, desc='tqdm_pandas test') as pbar:
            df = DataFrame(np.random.randint(0, 100, (100000, 6)))
            tqdm_pandas(tqdm_cls, file=sys.stdout, mininterval=0.5)
            # Test on series
            df[0].progress_apply(lambda x: pbar.update())
            # Test on dataframe
            df.progress_apply(lambda x: pbar.update())

# Generated at 2022-06-12 14:18:59.555123
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    def progress_apply_test(df):
        """
        Simple function to test in DataFrameGroupBy.progress_apply
        """
        return numpy.mean(df)
    df = pandas.DataFrame(numpy.arange(1000).reshape(100, 10))
    df = tqdm_pandas(df.groupby(lambda x: x % 20).progress_apply(progress_apply_test))
    assert(df is not None)



# Generated at 2022-06-12 14:19:09.132940
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    from tqdm.autonotebook import tqdm
    import numpy as np
    data = {'name': ['Jason', 'Molly', 'Tina', 'Jake', 'Amy'],
                'year': [2012, 2012, 2013, 2014, 2014],
                'reports': [4, 24, 31, 2, 3]}
    df = pd.DataFrame(data)
    t = tqdm(total=len(df.groupby('year')['name']), leave=False)
    tqdm_pandas(t, desc='test_tqdm_pandas')
    t._instances = [t]
    df.groupby('year').progress_apply(lambda grp: grp['name'])


# Generated at 2022-06-12 14:19:20.354121
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm._utils import _term_move_up
    from tqdm.contrib.test_utils import unittest, PrintTestCase

    class TqdmDeprecationWarning(UserWarning):
        pass

    class dummy_tqdm():
        class _inst:
            def __init__(self, fp, leave=False, disable=False, dynamic_ncols=True):
                self.fp = fp
                self.disable = disable
                self.leave = leave
                self.dynamic_ncols = dynamic_ncols

        def __init__(self, fp, leave=False, disable=False, dynamic_ncols=True):
            self._inst = self._inst()


# Generated at 2022-06-12 14:19:28.260156
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 4)),
                      columns=list('ABCD'))
    t = tqdm(total=len(df))
    tqdm_pandas(t, total=len(df))
    result = df.progress_apply(lambda x: x, axis=1)
    assert len(result) == len(df)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:38.736948
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    tqdm_pandas(tqdm.tqdm(total=1, leave=False))

    df = pd.DataFrame(dict(n=range(10), m=range(20, 30)))
    # Split into two groups
    grp = df.groupby(df.n % 2)

    # Apply a lambda function to each group and tqdm each iteration
    for _, x in grp.progress_apply(lambda x, m: x[m].sum(),
                                   m=['m', 'n']):
        pass

    tqdm_pandas(tqdm.tqdm(total=1, leave=False))
    for _ in tqdm.tqdm(range(1), leave=False):
        pass
    tqdm

# Generated at 2022-06-12 14:19:44.566030
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange, tqdm_pandas
    from pandas import DataFrame
    import pandas as pd

    def tq(x):
        return trange(x, desc='in progress', leave=False)

    tqdm_pandas(tq)

    df = DataFrame()

    def g(x):
        return x

    df = pd.DataFrame({'A' : 'foo bar hoo haa'.split(' '),
                       'B' : [1,2,3,4],
                       'C' : 'a b c d'.split(' ')})
    print(df)
    print(df.groupby('A').progress_apply(g))

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:55.819697
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
        from tqdm import tqdm
    except ImportError:
        return
    df = DataFrame(dict(a=range(100), b=range(100)))
    with tqdm(total=len(df)) as pbar:
        df.progress_apply(lambda x: pbar.update(), axis=1)
        assert pbar.n == len(df)
    with tqdm(total=len(df)) as pbar:
        df.progress_apply(lambda x: pbar.update(), axis=0)
        assert pbar.n == len(df)


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:20:04.658686
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas as tqdm

    from pandas import DataFrame
    import pandas as pd


# Generated at 2022-06-12 14:20:10.379302
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    with tqdm(total=10, file=sys.stdout) as t:
        tqdm.pandas(deprecated_t=t, desc="tqdm_pandas")
        df = pd.DataFrame({'A' : np.random.randn(100)})
        df.progress_apply(lambda x: x.sum())

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:19.408222
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    try:
        tqdm_pandas()
        assert True, 'tqdm_pandas() must fail without param'
    except TypeError:
        pass

    tqdm_pandas(tqdm.tqdm)
    df = pd.DataFrame(np.random.random((10, 10)))
    tqdm.tqdm_pandas(tqdm.tqdm)
    df.groupby(0).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:33.617876
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import sys
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, TqdmDeprecationWarning

    assert hasattr(tqdm, 'pandas')

    def test_tqdm_pandas_tqdm(tclass):
        tqdm_pandas(tclass)

        df = pd.DataFrame({'A': [1, 3, 4, 3, 4],
                           'B': [2, 3, 1, 2, 3],
                           'C': [3, 5, 2, 4, 4]})

        for _ in tclass(df.groupby('A')):
            pass

        for _ in tclass(df.groupby('A').progress_apply(lambda x: x)):
            pass


# Generated at 2022-06-12 14:20:43.678449
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm)
    # with silence_stdout():
    #     tqdm_pandas(tqdm)

if __name__ == '__main__':
    from tqdm import tqdm, tqdm_gui

    test_tqdm_pandas()
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_gui)
    # with silence_stdout():
    #     test_tqdm_pandas()
    #     tqdm_pandas(tqdm)
    #     tqdm_pandas(tqdm_gui)

# Generated at 2022-06-12 14:20:48.777820
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randn(10, 10))
    tqdm_pandas(tqdm())
    # Reshaping to trigger on_first_chunk=True
    df.groupby(df.columns.tolist()).apply(lambda x: x.values.reshape(-1))



# Generated at 2022-06-12 14:20:57.449513
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    def myfunc(x):
        time.sleep(0.01)
        return x ** 2

    try:
        import numpy
        import pandas
    except ImportError:
        return  # numpy and pandas not installed: can't test

    with tqdm(total=100) as t:
        data = pandas.DataFrame(numpy.random.randint(0, 100, (100000, 6)),
                                columns=list('abcdef'))
        data.groupby('a').progress_apply(myfunc)

    # t.close()  # NOTE: not needed as automatic context manager cleanup

# Generated at 2022-06-12 14:21:06.451481
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def test_tqdm_pandas():
        import pandas as pd
        import numpy as np
        df = pd.DataFrame(np.random.rand(1000, 4),
                          columns=['a', 'b', 'c', 'd'])
        res = df.groupby('a').progress_apply(
            lambda x: x ** 2).sum().sum()
        assert res == df.apply(
            lambda x: x ** 2).groupby('a').sum().sum()[0]

# Generated at 2022-06-12 14:21:12.182259
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # This function unit tests function tqdm_pandas. In order to do this it is
    # necessary to test that the function creates a tqdm function that can be
    # called.
    # TODO: Find a better way to test this function.
    try:
        tqdm_pandas(tqdm(total=100))
    except:
        raise AssertionError
    return True


# Generated at 2022-06-12 14:21:23.638135
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from pandas.util.testing import assert_frame_equal

    # creating a test DataFrame
    df = pd.DataFrame(np.random.randn(100, 3))
    df.columns = ['col1', 'col2', 'col3']
    df['col4'] = 'ABC'
    df = pd.concat([df, df], axis=0)

    # testing basic use
    def test_func(x):
        return x * 2

    out = tqdm_pandas(df.groupby('col4').progress_apply(test_func))
    assert_frame_equal(out, df * 2)

    # testing output

# Generated at 2022-06-12 14:21:32.594781
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:21:43.360473
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange
    from .utils import format_size, BasicTest
    tqdm.pandas(desc="my bar!")
    d = {
        'col1': ['A', 'B', 'C', 'D', 'E', 'F'],
        'col2': [2, 1, 9, 8, 7, 4],
        'col3': [0, 1, 9, 4, 2, 3],
    }
    df = pd.DataFrame(data=d)
    gb = df.groupby(["col1"])

    # Test without tqdm
    BasicTest(gb.progress_apply(lambda x: x)).start()

    # Test with trange

# Generated at 2022-06-12 14:21:51.313654
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    N = 100

    # Test 1: with tqdm.pandas.
    df = pd.DataFrame({
        'x': np.random.normal(size=N),
        'y': np.random.normal(size=N),
    })
    # Create a new column `z` whose values are the sum of `x` and `y`
    with tqdm.pandas(desc='Test 1') as t:
        df['z'] = df.progress_apply(lambda row: row['x'] + row['y'], axis=1)
    assert (df['z'] == df['x'] + df['y']).all()  # Check that they are indeed equal
    df['z'] *= 0  #

# Generated at 2022-06-12 14:22:03.735109
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from tqdm import tqdm as tclass
    except:
        from tqdm import TqdmDeprecationWarning
        raise TqdmDeprecationWarning(
            "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.",
            fp_write=sys.stderr.write)

    if not hasattr(tclass, 'pandas'):
        raise ImportError("error importing pandas progress_apply")
    else:  # tclass.pandas is a classmethod
        tqdm_pandas(tclass)

# Generated at 2022-06-12 14:22:10.770768
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas  # noqa
    except ImportError:
        return
    import tqdm

    # Test pre-registration
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, mininterval=0.1)
    tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm.tqdm, mininterval=0.1)
    tqdm_pandas(tqdm.tqdm_gui)
    tqdm_pandas(tqdm.tqdm_gui, mininterval=0.1)

    # Test post-registration
    tqdm_pandas(tqdm.tqdm())

# Generated at 2022-06-12 14:22:14.452972
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib.tests import _test_tqdm_pandas
    _test_tqdm_pandas.test_tqdm_pandas()


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:15.568489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    tqdm_pandas(tqdm)
# export


# Generated at 2022-06-12 14:22:25.391199
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm_pandas as tp

    # Test data
    df = DataFrame(data={'col1': [4, 5, 6], 'col2': [1, 2, 3]})

    # Tests without tqdm_pandas
    assert round(df['col1'].mean(), 1) == 5.0
    assert round(df['col2'].mean(), 1) == 2.0

    # Test with tqdm_pandas
    with tp(total=len(df)):
        assert round(df['col1'].mean(), 1) == 5.0
        assert round(df['col2'].mean(), 1) == 2.0

# Generated at 2022-06-12 14:22:34.589204
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import trange

    from tqdm import TqdmDeprecationWarning

    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm)
        assert issubclass(w[-1].category, TqdmDeprecationWarning)

    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(trange)
        assert issubclass(w[-1].category, TqdmDeprecationWarning)

    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm())
        assert issubclass(w[-1].category, TqdmDeprecationWarning)



# Generated at 2022-06-12 14:22:45.736476
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm._tqdm_pandas import _deprecate_pandas

    def test_df(a):
        return pd.DataFrame(a, columns=list('abc'))
    df = test_df(10)
    # Make sure tqdm_pandas works in non-decorated form
    tqdm_pandas(tqdm(total=10))
    # Make sure tqdm_pandas works in decorated form
    @tqdm_pandas
    def test_df(a):
        return pd.DataFrame(a, columns=list('abc'))
    df = test_df(10)
    assert df.progress_apply(lambda x: x).equals(df)

# Generated at 2022-06-12 14:22:56.962526
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._tqdm import tqdm_pandas
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'x': [1, 2, 3, 4, 5, 6],
                       'y': [10, 20, 30, 40, 50, 60]})
    for i in range(2):
        with tqdm_pandas() as tq:
            if i == 0:
                df["x"] = df["x"].progress_apply(lambda x: x**2)
            else:
                df["x"] = df["x"].progress_apply(lambda x: x**2).values
            assert np.all(df['x'] == [1, 4, 9, 16, 25, 36])
            assert len(tq.bars) == len(df)

# Generated at 2022-06-12 14:23:02.597061
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        df = pd.DataFrame({'a': range(100)})
        t = tqdm_pandas(tqdm(total=df.a.sum(), unit_scale=True))
        df.a.progress_apply(lambda a: a*a)
    except Exception:
        pass
    finally:
        clear_tqdm_deprecation_warnings()
        clear_tqdm_pandas_deprecation_warnings()
    return True



# Generated at 2022-06-12 14:23:13.084078
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    try:
        from pandas import DataFrame
    except ImportError:
        pytest.skip("pandas not installed")


# Generated at 2022-06-12 14:23:29.075626
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        # Unit test with pandas
        import pandas as pd
        df = pd.DataFrame()
        df['a'] = range(10)
        df['b'] = range(10, 20)
        df.groupby('a').progress_apply(lambda x: x)
        df.groupby('a').progress_apply(lambda x: x ** 2)
        df.groupby('a').progress_apply(lambda x: x ** 3)
    except ImportError:
        # Unit test without pandas
        t = tqdm(range(10), desc='tqdm_pandas')
        t = tqdm_pandas(t)
        for i in t:
            pass
        t = tqdm(range(10), desc='tqdm_pandas')
        t = tq

# Generated at 2022-06-12 14:23:38.124561
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    df = pd.DataFrame(np.random.random((1000, 1000)))

    with tqdm_pandas(tqdm()) as t:  # can use `with`
        df.groupby(0).progress_apply(lambda x: x ** 2)

    with tqdm_pandas(tqdm(ascii=True, desc='1st loop')) as t:
        for i in t:
            df.groupby(0).progress_apply(lambda x: x ** 2)
        t.set_description('1st loop (done)')

    with tqdm_pandas(tqdm(desc='2nd loop', miniters=1)) as t:
        for i in t:
            df.groupby(0).progress_apply(lambda x: x ** 2)
        t.close

# Generated at 2022-06-12 14:23:43.941681
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame({"a":range(5), "b":range(5)})

    with TqdmDeprecationWarning_Binary.silence():
        tqdm_pandas(tqdm)
        assert df.groupby('a').progress_apply(lambda x: x) is not None
        tqdm_pandas(tqdm, leave=False)
        assert df.groupby('a').progress_apply(lambda x: x) is not None
        tqdm_pandas(tqdm, show_percent=True)
        assert df.groupby('a').progress_apply(lambda x: x) is not None

# Generated at 2022-06-12 14:23:55.057803
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    import numpy as np
    import pandas as pd
    from pandas import DataFrame
    from pandas.util.testing import assert_frame_equal
    from itertools import product
    from tqdm import tqdm
    from .std import tqdm_pandas

    tqdm.pandas = tqdm_pandas  # Monkey patch to not use original

    N = 20
    P = 4
    keys = np.random.choice(list(product(['key%d' % d for d in range(P)],
                                         'ABCD')), N)
    data = np.random.randint(0, 10, (N, 2))

# Generated at 2022-06-12 14:24:03.610143
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    import pandas as pd
    from tqdm.auto import tqdm
    from .std import tqdm

    try:
        from tqdm.notebook import trange
        trange(3, desc="Pandas (deprecated)").pandas(total=3)
    except:
        pass
    try:
        from tqdm.notebook import tnrange
        tnrange(3, desc="Pandas (deprecated)").pandas(total=3)
    except:
        pass
    try:
        from tqdm import tqdm_notebook as tqdm
        tqdm(range(3), desc="Pandas (deprecated)").pandas(total=3)
    except:
        pass
    assert t

# Generated at 2022-06-12 14:24:12.040941
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    def test_groupby(gb):
        return gb.progress_apply(lambda x: x + 1)

    df = pd.DataFrame({'a': pd.Categorical(['B', 'A', 'A', 'B', 'B', 'A'],
                                           categories=['A', 'B'])})
    assert (df.groupby('a').progress_apply(lambda x: x + 1)
            == df.groupby('a').apply(lambda x: x + 1)).all()
    tqdm_pandas(tqdm.tqdm)
    assert (test_groupby(df.groupby('a'))
            == df.groupby('a').apply(lambda x: x + 1)).all()
    tqdm_p

# Generated at 2022-06-12 14:24:18.273147
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm
    import numpy as np
    
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm_pandas(tqdm)
    df.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-12 14:24:27.990153
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas """
    pd = pytest.importorskip('pandas', minversion="1.0.0")

    N = 10
    df = pd.DataFrame({"A": [0, 1, 2, 3, 0, 1, 2, 3, 0, 1],
                       "B": [4, 5, 6, 7, 4, 5, 6, 7, 4, 5],
                       "C": [8, 9, 8, 9, 0, 1, 2, 3, 4, 5]})
    df_pgb = df.groupby("A")

    # check pandas >= 1.0.0
    assert pd.__version__ >= '1.0.0'

    # check that progress_apply is installed
    pd.core.groupby.DataFrameGroupBy

# Generated at 2022-06-12 14:24:38.820406
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pdf
    import numpy as np

    for ttype in ['tqdm', 'trange', 'tnotebook', 'tnrange']:
        tq = getattr(tqdm, ttype)(total=0, leave=False)
        assert not hasattr(tq, 'pandas')
        tqdm_pandas(tq)
        assert hasattr(tq, 'pandas')

        df = pd.DataFrame(np.random.randn(5, 3), columns=['A', 'B', 'C'])

        class MyProgressBar(tqdm):
            file = sys.stdout

            def update_to(self, b=1, bsize=1, tsize=None):
                self.total = tsize
               

# Generated at 2022-06-12 14:24:46.975082
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import pandas as pd
    import numpy as np
    import functools
    import warnings
    import sys

    df = pd.DataFrame({'i': np.random.randint(0, 100, 100), 'j': np.random.randint(0, 100, 100)})

    def tqdm_w_progress_hook(iterable, *args, **kwargs):
        # Need to override to avoid that the tuple is interpreted as one argument
        t = tqdm(iterable, *args, **kwargs)
        t.register_hook(lambda: t.update(0))
        return t

    # Code to override the default behavior of pandas
    # when a function is wrapped with that decorator

# Generated at 2022-06-12 14:25:06.330833
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm)
    df = DataFrame([1, 2])
    df = df.progress_apply(lambda x: x**2)
    assert len(df) == 2
    assert df[0][0] == 1
    assert df[0][1] == 4

# Generated at 2022-06-12 14:25:10.742318
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame(
        {'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]})
    with tqdm_pandas(total=len(df)) as pbar:  # can use tqdm_gui, optional kwargs, etc
        df.progress_apply(lambda x: x**2, axis=1)

# Generated at 2022-06-12 14:25:15.460599
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm, desc='test')
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tqdm(total=10), desc='test')
    tqdm_pandas(tqdm(total=10), desc='test', file=sys.stdout)

# Generated at 2022-06-12 14:25:24.485172
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    import numpy as np
    try:
        import tqdm
    except ImportError:
        try:
            import tqdm_pandas
            tqdm = tqdm_pandas
        except ImportError:
            warnings.warn('Unable to load package tqdm or tqdm_pandas')
            return
    df = pd.DataFrame({'a': np.random.randn(1000)})
    tqdm_pandas(tqdm)
    result = df.groupby(0).progress_apply(lambda x: x ** 2)
    assert isinstance(result.columns, pd.MultiIndex)



# Generated at 2022-06-12 14:25:33.372053
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    # make sure tqdm is imported and accessible
    from tqdm import tqdm, tqdm_pandas
    from tqdm import tqdm as tqdm_original
    from tqdm.pandas import tqdm as tqdm_pandas_new
    # make sure tqdm_pandas is accessible
    tqdm_pandas
    # make sure tqdm_pandas_new is accessible
    tqdm_pandas_new
    # make sure tqdm_original is accessible
    tqdm_original
    # make sure tqdm is accessible
    tqdm
    # create a dummy class
    class DummyClass(tqdm):
        pass
    # run the function tqdm

# Generated at 2022-06-12 14:25:38.817587
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm

    # Create a pandas dataframe
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

    # Progress bar with pandas
    df.groupby(0).progress_apply(lambda x: x**2)

    # Progress bar with `tqdm_pandas`
    tqdm.tqdm_pandas(tqdm.tqdm(total=100000))
    df.groupby(0).progress_apply(lambda x: x**2)

    # Custom progress bar
    # tqdm_custom = tqdm.tqdm(total=100000, miniters=1, mininterval=1, desc="custom",
    #                       dynamic_ncols

# Generated at 2022-06-12 14:25:46.492019
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 4)),
                      columns=list('ABCD'))
    tqdm_pandas(tqdm, unit_scale=True)
    # Iterate over the pandas dataframe and print out every row

    _ = df.progress_apply(lambda x: x, axis=1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:56.625785
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    pd.options.display.width = 0

    # Test a data frame
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

    # Case 1
    with tqdm(leave=False) as t:
        df.progress_apply(t.update)

    # Case 2
    tqdm_pandas(t)
    with tqdm(leave=False, desc="Test") as t:
        df.progress_apply(t.update)

    # Case 3
    with tqdm(total=len(df), leave=False, desc="Test") as t:
        df.progress_apply(t.update)

    # Case 4

# Generated at 2022-06-12 14:26:05.842078
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test 1
    try:
        from tqdm._tqdm import tqdm
    except ImportError:
        from tqdm import tqdm

    try:
        import pandas
    except ImportError:
        return

    # Test 1
    tqdm_pandas(tqdm, leave=False)
    assert pandas.core.groupby.DataFrameGroupBy.progress_apply.__doc__

    # Test 2
    try:
        tqdm_pandas(tqdm(total=1), leave=False)
        raise AssertionError("tqdm_pandas(tqdm(...)) should raise a"
                             " TqdmDeprecationWarning")
    except TqdmDeprecationWarning:
        pass

# Generated at 2022-06-12 14:26:15.291460
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import Series
    from numpy import random
    from numpy import array
    from numpy import concatenate
    from tqdm import tqdm
    from pandas import concat

    size = 10**3

    df = DataFrame(Series(random.random(size),
                        index=range(size)))

    def func(serie):
        return Series(random.random(serie.size))

    def func2(serie):
        return Series(random.random(serie.size),
                     index=serie.index)

    def func3(serie, param=None):
        return Series(random.random(serie.size),
                     index=serie.index)
