

# Generated at 2022-06-12 14:16:33.207749
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmTypeError, TqdmDeprecationWarning
    from pandas import DataFrame
    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm, ascii=True)
        tqdm_pandas(tqdm(ascii=True))
    assert len(w) == 2
    assert (w[1].category, w[1].message.args[0]
            ) == (TqdmDeprecationWarning, "Please use `tqdm.pandas(...)` instead "
                                         "of `tqdm_pandas(tqdm(...))`.")
    df = DataFrame([range(100)] * 1000)

# Generated at 2022-06-12 14:16:40.098011
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for `tqdm_pandas`"""

    from tqdm.auto import tqdm, trange


# Generated at 2022-06-12 14:16:46.465854
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd

    # Dataframe
    df = pd.DataFrame(range(100), columns=["A"])

    # Without tqdm
    def func(x):
        return x * 2

    df.groupby("A").progress_apply(func)

    # With tqdm
    tqdm = tqdm_pandas(tqdm=tqdm_notebook)
    df.groupby("A").progress_apply(func)

# Generated at 2022-06-12 14:16:51.090143
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame(list(range(3)))
    with tqdm_pandas(total=len(df)) as t:  # Register `tqdm` with `pandas`
        df.progress_apply(lambda x: x, axis=1)  # Now you can use `progress_apply`


test_tqdm_pandas()

# Generated at 2022-06-12 14:16:54.711621
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
        df.groupby(0).progress_apply(lambda x: x ** 2)
    except ImportError:
        pass

# Generated at 2022-06-12 14:17:03.754796
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    # Check on a DataFrameGroupBy object
    df = pd.DataFrame({'a': [1, 2, 3], 'b': [8, 9, 10]})
    tqdm_pandas(tqdm, df=df.groupby('a').count())

    # Check on a DataFrame object
    df = pd.DataFrame({'a': [1, 2, 3], 'b': [8, 9, 10]})
    tqdm_pandas(tqdm, df=df)
    tqdm_pandas(tqdm, df=df.groupby('a'))

    # Delayed adapter case
    tqdm_pandas(tqdm, total=10)

# Generated at 2022-06-12 14:17:05.640962
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm(range(10)))
    assert tqdm_pandas(tqdm, range(10))

# Generated at 2022-06-12 14:17:11.650277
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    try:
        from tqdm.test import test_tqdm_pandas
        test_tqdm_pandas()
    except ImportError:
        # tqdm is not installed
        assert True

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:16.544189
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return None
    size = (100, 100)
    df = pd.DataFrame(np.random.randint(
        0, 10, size=size), columns=['A', 'B'])
    df = df.groupby('A').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:23.403456
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy

    df = DataFrame({'col': [0] * 50 + [1] * 50})
    df_grouped = df.groupby('col')

    def test_apply(self, func, *args, **kwargs):
        return 42

    assert DataFrameGroupBy.progress_apply != test_apply
    DataFrameGroupBy.progress_apply = test_apply
    assert DataFrameGroupBy.progress_apply == test_apply
    tqdm_pandas(tqdm)
    assert DataFrameGroupBy.progress_apply != test_apply

    df_grouped.progress_apply(lambda x: x)
    DataFrameGroupBy.progress_apply = test_apply


# Generated at 2022-06-12 14:17:26.927190
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        assert(tqdm_pandas is pd.core.groupby.DataFrameGroupBy.progress_apply)
    except ImportError:
        pass

# Generated at 2022-06-12 14:17:32.370421
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas as tqdm
    import pandas as pd

    df = pd.DataFrame({
        'a': [2, 3, 4],
        'b': [5, 6, 5],
        'c': [4, 5, 4],
        'd': [4, 3, 6],
    })

    def add(a, b, c, d):
        return a + b + c + d

    df.groupby('a').progress_apply(add, 'b', 'c', 'd')

    # Should also works with tqdm_class=tqdm
    tqdm(tqdm_class=tqdm).pandas(df.groupby('a'))

# Generated at 2022-06-12 14:17:42.696237
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.autonotebook import tqdm_notebook
    import numpy as np

    pd.options.display.max_columns = 10

    # create a data frame
    df = pd.DataFrame(np.random.randn(1000, 4), columns=list('ABCD'))

    # create a `tqdm` instance to register
    tq = tqdm(total=100)

    # group by 'A' and sum 'B'
    df_res = df.groupby('A').progress_apply(lambda x: x.B.sum())

    # test if `tq` is registered by `tqdm_pandas()`
    assert tq.is_registered(), '`tq` is not registered'

# Generated at 2022-06-12 14:17:53.080655
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas function."""
    import pandas as pd
    import numpy as np
    import tqdm

    def f(x):
        return x

    for tclass in [tqdm.tqdm, tqdm.tqdm_notebook, tqdm.tqdm_pandas]:
        df = pd.DataFrame({'a': np.random.random(10000),
                           'b': np.random.random(10000)})

        if not isinstance(tclass, type):
            tclass = type(tclass)
        tclass.pandas(**{'desc': 'test', 'dynamic_ncols': True})

        df.groupby('a').progress_apply(f)
        tclass.clear_instance_cache()



# Generated at 2022-06-12 14:17:55.739472
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm())


# Make a patch for pandas.core.groupby.DataFrameGroupBy.progress_apply
# for automatic tqdm integration

# Generated at 2022-06-12 14:18:05.720152
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    from tqdm import trange

    # Initialise a big dummy DataFrame
    df = pd.DataFrame(
        {'a': list(range(100000)),
         'b': list(range(200000, 300000)),
         'c': list(range(300000, 400000))
         })

    def func(df):
        return (df['a'] + df['b']).sum()

    # Check tqdm forwards to pandas
    assert tqdm_pandas(tqdm) is None
    assert tqdm_pandas(tqdm, position=1) is None
    assert tqdm_pandas(tqdm, total=2) is None


# Generated at 2022-06-12 14:18:12.711271
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit tests for `tqdm_pandas`."""
    # Test the delayed adapter case
    tqdm = tqdm_pandas(type('tqdm'), total=2, file=sys.stderr)
    assert tqdm.filename == sys.stderr.fileno()

    class _tqdm:
        fp = sys.stderr
        __name__ = 'tqdm_old'

    # Test the deprecated t case
    tqdm = tqdm_pandas(_tqdm())
    assert tqdm.filename == sys.stderr.fileno()

# Generated at 2022-06-12 14:18:22.370196
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm_pandas()`."""
    import pandas as pd
    from tqdm.pandas import tqdm

    data = pd.DataFrame({'a': [1, 2, 3], 'b': [4]})
    with tqdm.tqdm_pandas(total=len(data)) as pbar:
        def func(row):
            pbar.update()
            return row['a'] + row['b']

        data.apply(func, axis=1) == [5, 6, 7]

    tqdm_pandas(tqdm)



# Generated at 2022-06-12 14:18:25.792231
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # import pandas
    tqdm_pandas(tqdm, total=100)

# Generated at 2022-06-12 14:18:35.981379
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randn(100_000, 2))
    with tqdm_pandas(total=len(df)) as pbar:
        df.progress_apply(np.square)
        assert pbar.n == len(df)


# Register with pandas
try:
    import pandas as pd
except ImportError:
    pass
else:
    pandas_index_class = type(pd.Index(['']))
    if pd.__version__ < '1.0.0':
        # For pandas < 1.0.0
        # Called for every column
        def tqdm_pandas_apply(x, func, num_rows):
            from tqdm import tqdm

# Generated at 2022-06-12 14:18:42.714687
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    import tqdm
    df = pd.DataFrame({'test': np.random.rand(100)})
    tclass = tqdm.tqdm(total=len(df))

    # Should succeed
    tqdm_pandas(tclass)
    # Should succeed
    with tqdm.tqdm() as tclass:
        tqdm_pandas(tclass)

    arr = []
    with tqdm.tqdm(total=10) as tclass:
        # Should succeed
        arr.extend(df.groupby('test').progress_apply(lambda x: [x for _ in range(1000000)]))
        # Should succeed

# Generated at 2022-06-12 14:18:54.869141
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test tqdm_pandas function."""
    # pylint: disable=import-outside-toplevel
    try:
        import pandas
    except ImportError:
        print('Skip pandas tests')
        return
    from tqdm import tqdm
    from tqdm.pandas import tqdm_pandas
    import pandas as pd

    n = 100
    df = pd.DataFrame(dict(a=range(n), b=range(n), c=range(n)))
    tqdm_pandas(tqdm)  # registers the tqdm instance with pandas
    rdf = df.groupby(['a', 'b']).progress_apply(lambda x: x)
    assert (rdf['a'] == rdf['b']).all()

# Generated at 2022-06-12 14:19:04.415881
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _term_move_up

    from tqdm import tqdm, trange
    from pandas import DataFrame, Series
    import random
    import string

    random.seed(777)

    t = tqdm(total=1, file=sys.stderr,
             dynamic_ncols=True, disable=True)
    t.pandas(desc="TEST")

    # Test DataFrame
    df = DataFrame({'int': [random.randint(-1000, 1000) for _ in range(100)],
                    'float': [random.uniform(-1e6, 1e6)
                              for _ in range(100)],
                    'str': [''.join(random.sample(
                        string.ascii_lowercase, 10)) for _ in range(100)]})


# Generated at 2022-06-12 14:19:10.861415
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import random
    import string
    df = pd.DataFrame({'a': [''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10)) for i in range(100)]})
    gb = df.groupby('a')
    with tqdm_pandas(gb) as t:
        for name, group in t:
            pass
    assert len(t) == len(gb)

# Generated at 2022-06-12 14:19:21.716828
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import tqdm
    try:
        pandas.set_option('compute.use_bottleneck', False)
    except:
        pass
    try:
        pandas.set_option('compute.use_numexpr', False)
    except:
        pass
    t = tqdm.tqdm
    tqdm.tqdm = type('', (), dict(get_lock=lambda _: None))
    tqdm.tqdm.pandas = lambda *_, **__: None
    try:
        tqdm_pandas()
    except (tqdm.TqdmDeprecationWarning, TypeError):
        pass
    else:
        raise AssertionError

# Generated at 2022-06-12 14:19:31.041791
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import sys

    def set_tqdm(df, **kwargs):
        tqdm_pandas(tqdm(**kwargs), leave=False)

    for kwargs in [{}, {'file':sys.stdout}, {'mininterval':0.01}]:
        df = pd.DataFrame(dict(a=[1], b=[('a', 'b')]))
        set_tqdm(df, **kwargs)
        pd.DataFrame(dict(a=[1], b=[('a', 'b')])).groupby('a').progress_apply(
            lambda x: x).groupby('a').progress_apply(lambda x: x)
        set_tqdm(df, **kwargs)
        p

# Generated at 2022-06-12 14:19:39.095404
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        from pandas import DataFrame
    except ImportError:
        return None
    df = DataFrame({'a': range(10000, 9000, -1), 'b': range(10)})
    with tqdm(total=len(df)) as pbar:
        def test_len(a, b):
            pbar.update()
            return len(str(a))
        df.progress_apply(test_len, axis=1)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:43.104258
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm_pandas(tqdm(df, desc="Progress "))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:19:55.459349
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function `tqdm_pandas` """
    from pandas import DataFrame
    from pandas import Series
    from numpy import random
    from tqdm import tqdm
    from tqdm import tqdm_notebook

    DATA_SIZE = 1000000
    data = DataFrame()
    data['A'] = Series(random.randn(DATA_SIZE))
    data['B'] = Series(random.randint(0, DATA_SIZE, DATA_SIZE))

    # Test that `tqdm_pandas` registers properly `tqdm` in `pandas.core.groupby.DataFrameGroupBy.progress_apply`

# Generated at 2022-06-12 14:20:05.307177
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests the function `tqdm` with `pandas` library
    """
    from pandas import DataFrame

    from .main import tqdm
    import numpy as np

    df = DataFrame({'a': np.random.randint(0, 100, (1000)),
                    'b': np.random.randint(0, 100, (1000)),
                    'c': np.random.randint(0, 100, (1000)),
                    'd': np.random.randint(0, 100, (1000))})

    def do_something(x):
        # do something with `x`
        return x

    df_out = df.groupby('a').progress_apply(do_something)


# Generated at 2022-06-12 14:20:19.690859
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Just check for register the tqdm instance with pandas
    import pandas as pd
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy

    import tqdm

    def test_apply(self, func, group_keys=True, **kwargs):
        if group_keys:
            self._selected_obj = self._obj_with_exclusions
        return self._python_apply_general(func, **kwargs)

    DataFrameGroupBy.apply = test_apply

    d = {'col1': [1, 2], 'col2': [3, 4]}
    df = DataFrame(data=d)
    df_gb = df.groupby("col1")

    with tqdm.pandas(desc="test") as pbar:
        df_gb.progress_

# Generated at 2022-06-12 14:20:29.320741
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange
    from tqdm import tqdm_notebook
    from pandas import DataFrame, Series
    from pandas.core.groupby import DataFrameGroupBy
    from numpy import nan

    df = DataFrame({'A': [nan, nan, nan, 1, 2, 3, 4, 5, nan],
                    'B': [1, 2, 3, 4, nan, nan, 1, 2, 3]})

    def test_pandas_tqdm(t):  # use tqdm instance
        t.pandas(desc=globals().get('__doc__'))
        progress = DataFrameGroupBy(df, "A").progress_apply(len)
        assert progress is not None

    test_pandas_tqdm(tnrange(100))
    test_

# Generated at 2022-06-12 14:20:40.245531
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    from tqdm._version import __version__

    assert __version__ >= '4.26.0', __version__

    tqdm_pandas(tqdm())
    with tqdm(total=0) as t:
        tqdm_pandas(t, desc='foobar')

    df = pd.DataFrame([[1, 1], [1, 2], [1, 3], [2, 1], [2, 2], [2, 3], [3, 1],
                       [3, 2], [3, 3]], columns=['A', 'B'])
    df.groupby('A').progress_apply(lambda x: None)


# Generated at 2022-06-12 14:20:49.534750
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    $ python -m tqdm.std.tqdm_pandas
    """
    import numpy as np
    import pandas as pd
    import tqdm as tqdm

    def test_groupby(t, **kwargs):
        df = pd.DataFrame({
            'A': np.array([1, 1, 2, 1, 2, 2]),
            'B': np.array([0.5, 0, 1, 0.5, 1, 0]),
        })
        return df.groupby('A').progress_apply(
            lambda g: g['B'].max(), **kwargs)


# Generated at 2022-06-12 14:21:00.316285
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from pandas import DataFrame
    from tqdm import tqdm

    # Test for deprecated
    try:
        tqdm_pandas(tqdm)
    except TqdmDeprecationWarning:
        pass

    # Test for new
    try:
        tqdm_pandas(tqdm.pandas)
    except TqdmDeprecationWarning:
        pass

    # Test apply
    df = DataFrame(dict(
        A=['foo', 'bar', 'baz', 'qux'],
        B=['one', 'one', 'two', 'one'],
        C=[1, 2, 3, 4]))
    df_grouped = df.groupby(['B'])


# Generated at 2022-06-12 14:21:07.758532
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_pandas
    import numpy as np
    df = pd.DataFrame({'a': np.random.randint(0, 100, size=1000)})
    def my_func(x):
        time.sleep(np.random.random())
        return x
    tdf = tqdm_pandas(df.groupby('a'))
    tdf['a'].progress_apply(my_func)

# Generated at 2022-06-12 14:21:19.197004
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # check if function throws exception
    try:
        tqdm_pandas(1)  # test with not-a-tqdm instance
    except Exception as e:
        # print('Passed test_tqdm_pandas type check')
        pass
    else:
        raise('Failed test_tqdm_pandas type check')
    # check if function throws exception
    try:
        tqdm_pandas(tqdm)  # test with tqdm class itself
    except Exception as e:
        # print('Passed test_tqdm_pandas tqdm class check')
        pass
    else:
        raise('Failed test_tqdm_pandas tqdm class check')
    # check if function throws exception

# Generated at 2022-06-12 14:21:21.581733
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm  # import tqdm

    tqdm_pandas(tqdm)  # register `tqdm` with `pandas`

# print("\nRegister tqdm_pandas")
# test_tqdm_pandas()

# Generated at 2022-06-12 14:21:24.722244
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm.pandas(leave=True)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:33.257599
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    import warnings
    warnings.simplefilter('ignore', TqdmDeprecationWarning)
    with tqdm_pandas(total=1) as pbar:
        df = pd.DataFrame({'A': np.random.randint(0, 10000, (100000,)),
                           'B': np.random.randint(0, 10000, (100000,)),
                           'C': np.random.randint(0, 10000, (100000,)),
                           'D': np.random.randint(0, 10000, (100000,))})

        # Register `pandas.progress_apply` and `pandas.Series.map_apply` with `tqdm`
        # (can use `tqdm_gui`, `

# Generated at 2022-06-12 14:21:48.739006
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    df = pandas.DataFrame({
        'country': ['FR', 'US', 'BR', 'FR', 'US', 'BR'],
        'year': [2005, 2006, 2007, 2005, 2006, 2007]
    })
    import tqdm
    tqdm.tqdm_pandas(tqdm.tqdm)
    # when ``name`` and ``desc`` are given, `tqdm.pandas` is used.
    df.groupby('country').progress_apply(lambda g: g['year'].sum(),
                                         name='mybar', desc='mydesc')
    # when ``ncols`` option is given, `tqdm_notebook.pandas`` is used.

# Generated at 2022-06-12 14:21:57.940889
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    test_df = pandas.DataFrame([
        [1, 2, 3, 4, 5],
        ["alpha", "beta", "gamma", "delta", "epsilon"],
        [1., 2., 3., 4., 5.]
    ])
    test_df = test_df.T
    test_df.columns = ['integer', 'string', 'float']

    # Test tqdm auto support
    test_df.groupby('integer').progress_apply(
        lambda x: x ** 2)

    # Test tqdm custom support
    import tqdm

# Generated at 2022-06-12 14:22:03.483195
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    N = 100
    df = pd.DataFrame({'a': np.random.randint(0, 100, size=N),
                       'b': np.random.randint(0, 100, size=N),
                       'c': np.random.randint(0, 100, size=N)})

    def square_a(x):
        return x ** 2

    tqdm_pandas(df.groupby(['a']).progress_apply(square_a))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:10.668005
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_gui
    from tqdm.auto import trange
    import numpy as np
    from tqdm.contrib.tests import pretest, posttest
    pretest()
    with tqdm(ascii=True) as t:
        tqdm_pandas(t)
        df = pd.DataFrame(np.arange(500, dtype=np.uint8))
        df.progress_apply(lambda x: x ** 2)
    with tqdm_gui() as t:
        tqdm_pandas(t)
        df = pd.DataFrame(np.arange(500, dtype=np.uint8))
        df.progress_apply(lambda x: x ** 2)

# Generated at 2022-06-12 14:22:21.826019
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas_deprecated
    from tqdm import tqdm
    from pandas import DataFrame

    tqdm_pandas_deprecated(tqdm)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm_kwargs={'ncols': 80})
    assert DataFrame().groupby(by=['a']).progress_apply(lambda x: x, meta=int)
    assert DataFrame({'a': range(100)}) \
        .groupby(by=['a']) \
        .progress_apply(lambda x: x + 1, axis=1)

if __name__ == "__main__":
    test_tq

# Generated at 2022-06-12 14:22:28.081173
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    tqdm_pandas(tqdm(total=10, unit='s', desc='testing'))
    pd.DataFrame({'a': [],
                  'b': []}).groupby('a').progress_apply(lambda x: 2*x)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:36.216786
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from pandas import DataFrame
    from pandas.util.testing import assert_frame_equal

    try:
        from tqdm import trange
    except ImportError:
        from tqdm import tnrange as trange

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        from pandas.core.groupby import DataFrameGroupBy as _DataFrameGroupBy

        class DataFrameGroupBy(_DataFrameGroupBy):
            def progress_apply(self, func, *args, **kwargs):
                import pandas.core.common as com
                from pandas.core.groupby import DataFrameGroupBy
                from pandas.core.base import DataError, SpecificationError


# Generated at 2022-06-12 14:22:46.203900
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    with tqdm(['a', 'b', 'c', 'd']) as t:
        assert t.__name__ == 'tqdm'
        tqdm_pandas(t)
        assert t.__name__ == 'tqdm_pandas'

    with tqdm(['a', 'b', 'c', 'd'], desc='desc_t') as t:
        assert t.__name__ == 'tqdm'
        tqdm_pandas(type(t))
        assert t.__name__ == 'tqdm_pandas'

    assert tqdm_pandas.__doc__


if __name__ == '__main__':
    from utils_test import run_tests

# Generated at 2022-06-12 14:22:54.541660
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import trange
    df = pd.DataFrame(np.random.randint(
        0, 100, (100000, 6)), columns=list('abcdef'))
    t = trange(1)
    tqdm_pandas(t, total=df.progress_apply(lambda x: x).count().sum())


if __name__ == '__main__':
    from .std import *
    test_tqdm_pandas()

# Generated at 2022-06-12 14:22:57.297486
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:07.376679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:13.636340
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        # Test pandas
        import pandas as pd
        pd.DataFrame([]).groupby(0).progress_apply(lambda x: x)

        # Test delayed
        tqdm_pandas(tqdm)
    except Exception as e:
        print(e)
        raise  # re-raise exception


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:21.093038
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from ._tqdm.gui import tnrange
    import pandas as pd

    df = pd.DataFrame({'a': list(range(10000)), 'b': list(range(10000))})

    tqdm_pandas(tnrange(3))

    def f(x, y):
        return x + y

    assert (df.progress_apply(f, axis=1, raw=True) ==
            pd.DataFrame({'a': list(range(10000)), 'b': list(range(10000))})
            .apply(f, axis=1, raw=True)).all().all()

# Generated at 2022-06-12 14:23:27.982875
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_notebook as tqdm

    def my_function(x):
        return round(x, 2)

    df = pd.DataFrame(np.random.rand(100, 4))
    tqdm_pandas(tqdm(), show_percent=True, file=sys.stdout)
    df.progress_apply(my_function, axis=1)
    sys.stdout.flush()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:36.866034
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange
    import pandas as pd

    def test_fn(x):
        return pd.DataFrame([x + i for i in range(10)])  # numpy.random.randn(10, 5)

    df = pd.DataFrame([(i, i*2) for i in range(1000)], columns=['int', 'int*2'])
    df = df.groupby('int').progress_apply(test_fn)

    given_ = 'tqdm_pandas(tqdm(...))'
    tqdm(total=1, desc=given_, bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt}')

    # tqdm_pandas(tqdm(...))
   

# Generated at 2022-06-12 14:23:44.129816
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm
    except ImportError:
        return
    from tqdm import tqdm
    from tqdm.std import tqdm

    import pandas as pd
    import numpy as np
    from pandas import DataFrame

    def test_adapter(t, status_format):
        for _ in t:
            # raise Exception
            pass

    # First test regular class
    tqdm_pandas(tqdm, status_format="{percentage:3.0f}%")

    df = DataFrame(np.random.randint(0, 100, (100000, 6)))
    sum = df.progress_apply(
        lambda x: x.sum(),
        axis=1,
        result_type='broadcast')  # NOQA


# Generated at 2022-06-12 14:23:55.205219
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm, trange

    N = 100
    tqdm.pandas()

    pd.DataFrame(dict(
        A=pd.Series(np.arange(N)),
        B=pd.Series(list(range(N))),
    )).groupby('A').progress_apply(lambda x: x)

    pd.DataFrame(dict(
        A=pd.Series(np.arange(N)),
        B=pd.Series(list(range(N))),
    )).progress_apply(lambda x: x)


# Generated at 2022-06-12 14:24:03.150629
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        import pandas
    except ImportError:
        return
    pd = pandas
    df = pd.DataFrame([range(10)])
    with tqdm(total=len(df), unit='columns') as t:
        for i, r in df.iterrows():
            tqdm_pandas(t)(pd.DataFrame.apply)(r, lambda x: x * 2, axis=0)
    with tqdm(total=len(df), unit='columns') as t:
        tqdm_pandas(t)(pd.DataFrame.apply)(df, lambda x: x * 2, axis=1)

# test_tqdm_pandas()

# Generated at 2022-06-12 14:24:11.636171
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm.auto import tqdm
    from tqdm import TqdmSynchronisationWarning
    import warnings

    # Suppress warnings
    warnings.filterwarnings("ignore", category=TqdmSynchronisationWarning)
    warnings.filterwarnings("ignore", category=RuntimeWarning)  # pandas
    sys.stdout = open(os.devnull, "w")  # disable all print messages
    df = pd.DataFrame({'x': np.random.randint(0, 10, size=10000),
                       'y': np.random.randint(0, 10, size=10000)})
    result = df.groupby('x').y.apply(tqdm_pandas, lambda x: x.mean())
    # check result

# Generated at 2022-06-12 14:24:23.650135
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({"a": np.arange(10) * np.random.randn(10)})

    # check return type
    assert(isinstance(tqdm(df.groupby("a").progress_apply(lambda x: None)), tqdm))

    # column read
    with tqdm(df.groupby("a").progress_apply(lambda x: None)) as pbar:
        assert(pbar.n == 10)
        assert(pbar.total == 10)

    # column write
    df = pd.DataFrame({"a": np.arange(10) * np.random.randn(10)})

# Generated at 2022-06-12 14:24:46.558246
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random
    from tqdm import tqdm_pandas
    from tqdm import tqdm

    def f(x):
        return x

    df = DataFrame(dict(a=random.randint(0, 100, size=1000),
                        b=random.randint(0, 100, size=1000)))

    try:
        df.groupby('a').progress_apply(f)
    except Exception as e:
        if str(e) == "progress_apply(): 'tqdm' not defined":
            tqdm_pandas(tqdm())
        else:
            raise e

    # Check that tqdm_pandas(tqdm()) works
    df.groupby('a').progress_apply(f)

    # Check that tq

# Generated at 2022-06-12 14:24:51.533937
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from numpy import random

    N = 1000
    D = 30
    Data = DataFrame(random.normal(size=(N, D)))
    Series(range(N)).progress_apply(lambda x: (x + 1) ** 2)
    Data.groupby(0).progress_apply(lambda x: x + 1)
    list(tqdm(range(1000), leave=False, ascii=True, disable=True))
    tqdm_pandas(tqdm(total=1000, leave=False, ascii=True, disable=True),
                desc='testing pandas', mininterval=0.1)

# Generated at 2022-06-12 14:25:00.843344
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import pandas.util.testing as pdt

    try:
        import pandas.core.reshape.concat as pd_concat
    except:
        import pandas.tools.merge as pd_concat

    assert hasattr(pd.core.groupby.DataFrameGroupBy, 'progress_apply')
    try:
        import pandas.core.reshape.concat as pd_concat
    except:
        import pandas.tools.merge as pd_concat
    assert hasattr(pd_concat.concat, 'progress_map')
    assert ('progress_apply' in dir(pd.core.groupby.DataFrameGroupBy))
    assert ('progress_map' in dir(pd_concat.concat))


# Generated at 2022-06-12 14:25:04.462154
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas
    from time import sleep

    test_series = pd.Series(np.arange(5))
    for i, x in tqdm_pandas(test_series.progress_apply(lambda x: sleep(1.0))):
        pass

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:10.154129
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange

    df = pd.DataFrame([[1,2,3],[4,5,6],[7,8,9]])
    df.groupby(0).progress_apply(lambda x: list(trange(x.shape[0])))
    with tqdm(total=100) as t:
        df.groupby(0).progress_apply(lambda x: t.update(x.shape[0]))

# Generated at 2022-06-12 14:25:20.249202
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        import numpy as np
        _numpy_installed = True
    except ImportError:
        _numpy_installed = False

    df = pd.DataFrame({'a': [1] * 3 + [2] * 3 + [3] * 4,
                       'b': [4, 5, 6, 1, 2, 3, 7, 8, 9, 10]})
    df.groupby('a').progress_apply(lambda x: x)
    df.groupby('a').progress_apply(lambda x: x, show_count=True)
    df.groupby('a').progress_apply(lambda x: x, show_percent=True)

    if _numpy_installed:
        df.groupby('a').progress_apply(lambda x: np.mean(x))
   

# Generated at 2022-06-12 14:25:28.582846
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas.core.indexes.base import Index
    # import tqdm
    import mock
    with mock.patch('tqdm.tqdm_pandas.tqdm', autospec=True) as mck_tbar:
        tqdm_pandas(mck_tbar)
        mck_tbar().pandas.assert_called_once_with()
    with mock.patch('tqdm.tqdm', autospec=True) as mck_tbar:
        tqdm_pandas(mck_tbar)
        mck_tbar().pandas.assert_called_once_with()
    with mock.patch('tqdm.tqdm_gui', autospec=True) as mck_tbar:
        tq

# Generated at 2022-06-12 14:25:37.551067
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from pandas import DataFrame
    from tqdm import tqdm
    # Test on DataFrameGroupBy
    tqdm(total=10).pandas(DataFrame({"a": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}).groupby(
        "a"))
    # Test on DataFrameGroupBy apply
    tqdm(total=10).pandas(DataFrame({"a": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}).groupby(
        "a").progress_apply)
    # Test on DataFrameGroupBy with deprecated tqdm

# Generated at 2022-06-12 14:25:45.502523
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    from pandas.util.testing import assert_frame_equal

    def test_func(df):
        return df

    df = pd.DataFrame(np.random.random((100, 2)))
    with tqdm.tqdm_pandas() as s:
        res = df.progress_apply(test_func, axis=1)
    ans = test_func(df)
    assert_frame_equal(ans, res)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:56.001350
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import random
    import pandas as pd

    s = Series(random.randn(1000), name="progress_apply")
    df = DataFrame(s)
    df.groupby(0).progress_apply(lambda x: x)

    # Test deprecation
    tqdm_pandas(tqdm(total=100))
    tqdm_pandas(tqdm, total=100)
    tqdm_pandas(tqdm_notebook(total=100))

    # Make sure the deprecation is raised
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm(total=100))


# Compatibility for tqdm_notebook and tqdm_gui
t