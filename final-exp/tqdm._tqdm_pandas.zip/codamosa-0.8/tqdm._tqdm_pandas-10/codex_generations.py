

# Generated at 2022-06-12 14:16:34.001861
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    progress_apply_original = DataFrame.progress_apply
    progress_apply_new = tqdm_pandas(tqdm)(progress_apply_original)
    assert progress_apply_new != progress_apply_original
    assert progress_apply_new.__doc__ == progress_apply_original.__doc__
    assert progress_apply_new.__module__ == progress_apply_original.__module__
    assert progress_apply_new.__dict__ == progress_apply_original.__dict__
    del tqdm_pandas, tqdm, DataFrame, progress_apply_original



# try:
#     from pandas import DataFrame
#     import pandas as pd
#     __all__ = ['tqdm_pandas

# Generated at 2022-06-12 14:16:36.118609
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm_pandas(tqdm.tqdm)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:16:43.542479
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    pd.DataFrame({'a': [1, 2, 3]}).groupby('a').progress_apply(print, 1)
    tqdm.pandas(desc='my bar')
    pd.DataFrame({'a': [1, 2, 3]}).groupby('a').progress_apply(print, 1)


# Monkey patch pandas.core.groupby.DataFrameGroupBy.progress_apply

# Generated at 2022-06-12 14:16:52.190426
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit tests for tqdm_pandas.
    """
    import pandas as pd
    pd.__version__ = '0.17.0'
    import tqdm
    tqdm.__version__ = '3.8.0'
    import unittest

    class TestPandas(unittest.TestCase):
        def setUp(self):
            self.df = pd.DataFrame({'A': [0, 1, 2, 3, 4],
                                    'B': [1, 0, 0, 1, 1],
                                    'C': [1, 1, 1, 0, 0]})

        def test_tapply(self):
            self.df.groupby('B').progress_apply(lambda x: x['C'].sum())

# Generated at 2022-06-12 14:16:58.847619
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    global tqdm_class
    try:
        from tqdm.autonotebook import tqdm
        tqdm_class = tqdm
    except ImportError:
        tqdm = None

    def func(df):
        return df.sum()

    with tqdm_class(total=None) as t:
        df = pd.DataFrame([[1, 2], [3, 4]], columns=['a', 'b'], index=['c', 'd'])
        res = df.groupby('b').progress_apply(func, t)
        assert res.equals(df.groupby('b').apply(func))

    if tqdm is None:
        return


# Generated at 2022-06-12 14:17:07.279453
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange

    def tqdm_test(x, *, pbar=None):
        for i in trange(10, position=pbar):
            x += i / 2.
        return x

    def named_tqdm_test(x, *, pbar=None, data='dummy'):
        for i in trange(10, position=pbar):
            x += i / 2.
            assert data == 'dummy'
        return x

    with tqdm(total=100) as pbar:
        assert tqdm_test(0.0, pbar=pbar) == 25.0
    assert pbar.n == 10


# Generated at 2022-06-12 14:17:13.575705
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(10))
    tqdm_pandas(tqdm(10), leave=True)
    tqdm_pandas(tqdm(10), total=10)
    tqdm_pandas(tqdm(total=10))


# Not to be used directly

# Generated at 2022-06-12 14:17:22.221960
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas
    from tqdm import tqdm_pandas

    # Depracated method
    tqdm_pandas(pandas.tqdm)

    # Adapter method
    pandas.tqdm = tqdm_pandas(pandas.tqdm)

    # With deprecated
    tqdm_pandas(pandas.tqdm, 'test')

    # With adapter
    pandas.tqdm = tqdm_pandas(pandas.tqdm, 'test')


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:17:29.754259
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def check(ret):
        assert isinstance(ret, tqdm.tqdm)

    # Ensure all 2.x/3.x compatible, despite __str__ vs __repr__ in py2/3
    check(tqdm_pandas(tqdm))
    check(tqdm_pandas(tqdm(1)))
    check(tqdm_pandas(tqdm(1), desc='foo'))
    check(tqdm_pandas(tqdm(1), mininterval=5))
    check(tqdm_pandas(tqdm(1), ascii=False))
    check(tqdm_pandas(tqdm(1), ncols=1))

# Generated at 2022-06-12 14:17:41.181366
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_pandas
    from time import sleep
    df = pd.DataFrame(dict(a=[1, 2, 3, 4, 5],
                           b=pd.Timestamp('2015-01-01', tz='UTC'),
                           c=range(5),
                           d=range(5, 10),
                           e=[0.0, 0.5, 0.25, 0.125, 0.0625],
                           f=[-1, -2, -3, -4, -5]))
    df_gb = df.groupby('a')

    # Test pandas.core.groupby.DataFrameGroupBy.progress_apply
    def test_func(x):
        sleep(0.01)
        return x

# Generated at 2022-06-12 14:17:48.937082
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    import pandas.core.groupby # NOQA
    import numpy as np
    N = 100
    M = 100
    df = DataFrame(np.random.randn(N, M))
    tqdm_pandas(tqdm())
    for i, row in enumerate(df.progress_apply(sum)):
        assert i == row


# Generated at 2022-06-12 14:17:56.045406
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from pandas import DataFrame
    from numpy import random

    df = DataFrame(random.poisson(lam=200, size=(100000, 100)))
    tqdm_pandas(tqdm)

    def func(x):
        return sum(x)

    df.progress_apply(func, axis=1)


if __name__ == '__main__':
    from .autonotebook import tqdm as tqdm_auto
    tqdm_pandas(tqdm_auto)
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:05.871143
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    import time

    # Test DeprecationWarning (1)
    tqdm.pandas(bar_format="{n_fmt}/{total_fmt} [{elapsed}<{remaining}]")
    with tqdm.utils.capture_output() as io:
        with tqdm.utils.disable_dashboard():
            inp = pd.DataFrame({
                'A': [1, 2, 3],
                'B': ['a', 'b', 'c']
            })
            inp.groupby('A').progress_apply(lambda x: x)
    assert 'DeprecationWarning' in io.err

    # Test DeprecationWarning (2)

# Generated at 2022-06-12 14:18:10.772601
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    prog_bar = tqdm_pandas(tqdm(total=10))
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'x': np.ones(10), 'y': np.ones(10)})
    df.groupby('x').progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:22.631705
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm
    from tqdm._utils import _range

    df = pd.DataFrame({'a': list(range(30)),
                       'b': list(range(30))})

    # tests
    def func(x):
        return x

    def func_with_kwargs(x, inplace=True):
        return x

    def func_raise(x):
        raise Exception()

    def func_tqdm(x):
        for _ in _range(10):
            yield _

    # test simple func
    assert(df.groupby('a').progress_apply(tqdm_pandas(tqdm)(func))['a'].sum() == 435)

    # test func with kwargs

# Generated at 2022-06-12 14:18:30.032461
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm
    import numpy as np
    from tqdm import tqdm_notebook

    df = pd.DataFrame(np.random.rand(100, 4), columns=list('ABCD'))
    tqdm.pandas()
    df.groupby('A').progress_apply(lambda x: x ** 2)

# Generated at 2022-06-12 14:18:38.468550
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        # non-vital dependency: skip its tests
        pass
    else:
        from random import shuffle
        from tqdm import tqdm
        from tqdm.contrib.tests._tqdm_test_cls import T
        from tqdm.contrib.tests._tqdm_test_cls import StringIO
        from tqdm.auto import trange

        # unit test
        _range = range(1000)
        # set fixed seed for determinism
        shuffle(_range)
        df = pd.DataFrame(_range)

        def tqdm_identity(tqdm_obj):
            def identity(x):
                tqdm_obj.update()  # increment progress bar manually
                return x
            return identity


# Generated at 2022-06-12 14:18:41.896301
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm

    df = pandas.DataFrame({"a": [1, 2, 3]})
    tqdm_pandas(tqdm, fp=open('/dev/null', 'w'))
    df.groupby('a').progress_apply(lambda x: x)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:45.786213
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    tqdm_pandas(tqdm, leave=True)(pandas.DataFrame().groupby('').progress_apply)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:18:56.713386
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from numpy import arange
    n = 10
    df = DataFrame({'x': arange(n),
                    'y': Series(arange(n)).apply(lambda x: 2 * int(x)),
                    'z': 4 * arange(n)})
    t = tqdm(total=len(df))
    def f(x):
        t.update()
        return x.sum()
    df2 = df.groupby('y').apply(f)
    assert len(df2) == n // 2
    assert df2['x'].sum() == (n - 1) * n // 2
    assert df2['z'].sum() == 4 * (n - 1) * n // 2

# Generated at 2022-06-12 14:19:03.456964
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy.random import randint

    tqdm.pandas(desc='testing')  # for unit test coverage
    df = DataFrame(randint(0, 10, (1000, 6)))
    for _ in df.groupby(0).progress_apply(lambda x: x + 1):
        pass



# Generated at 2022-06-12 14:19:13.964636
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    import tqdm

    # Create a fake dataset for testing
    df = pd.DataFrame({'A': np.random.randint(low=1, high=100, size=100),
                       'B': np.random.randint(low=1, high=100, size=100)})


    def foo_with_progress(df):
        time.sleep(0.01)
        return df


    def foo_without_progress(df):
        time.sleep(0.01)
        return df


    pbar = tqdm.tqdm(total=len(df.A), desc="Group A")
    a_with_progress = df.groupby('A').progress_apply(foo_with_progress)

# Generated at 2022-06-12 14:19:24.898803
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm_pandas import tqdm_pandas
    from pandas import DataFrame, Series
    import numpy as np
    from pandas.util.testing import assert_series_equal
    from tqdm import tqdm

    pd = DataFrame(dict(
        int_col=Series(np.random.randint(0, 4, size=1000)),
        float_col=Series(np.random.randn(1000))))
    tqdm_pandas(tqdm)  # attach
    # test will be performed after some usage

    # For example:
    pd.groupby('int_col').progress_apply(lambda x: x.sum())

    # De-attach
    tqdm_pandas.detach()

    # must now error

# Generated at 2022-06-12 14:19:32.963015
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas
    from tqdm.contrib.test_tqdm_pandas import DataFrameMock, df_groupby_mock
    try:
        from pandas import DataFrame
    except:
        from pandas.core.frame import DataFrame

    # Simple test of tqdm_pandas
    tqdm_pandas(tqdm.tqdm, total=100)
    tqdm_pandas(tqdm.tqdm(total=100))

    # Simple test of tqdm_pandas with Pandas
    df = DataFrame(DataFrameMock(range(100)))
    df.groupby(lambda x: x).progress_apply(lambda x: x)

    # Test that tqdm_p

# Generated at 2022-06-12 14:19:39.888861
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm, file=sys.stderr)
    import pandas as pd

    from tqdm import tqdm_notebook

    # Check that tqdm_notebook doesn't raise an exception
    df = pd.DataFrame({'A': [1, 2, 3, 4, 5], 'B': [1, 2, 3, 4, 5]})
    df.groupby('A').progress_apply(lambda x: x)



# Generated at 2022-06-12 14:19:46.015001
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest

    try:
        from unittest import mock
    except ImportError:
        import mock  # Python 2 and < 3.3
    from tqdm.contrib import pandas

    # stub
    def mock_groupby_progress_apply(x):
        return x

    # unit test for tqdm.pandas(tqdm=)
    t = tqdm.tqdm(range(10))
    with mock.patch.object(t.__class__, 'pandas', wraps=pd.core.groupby.DataFrameGroupBy.progress_apply) as mock_progress:
        tqdm_pandas(t)
        assert mock_progress.called

# Generated at 2022-06-12 14:19:47.914931
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm.tqdm_pandas(tqdm.tqdm())

# Generated at 2022-06-12 14:19:57.996377
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib.tests import dummy_tqdm

    # Dataframe
    df_shape = (100000, 100)
    df = pd.DataFrame(np.random.randint(0, 100, df_shape),
                      columns=["col_{}".format(x) for x in range(df_shape[1])])
    # tqdm
    t = dummy_tqdm()
    # test_tqdm
    tqdm_pandas(t)
    df.progress_apply(lambda x: None)

    # Df in Df

# Generated at 2022-06-12 14:20:07.619988
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm, tqdm_gui
    from numpy.random import randint
    from pandas import DataFrame as df
    from time import sleep

    assert tqdm_pandas(tqdm) is None
    assert tqdm_pandas(tqdm_gui) is None
    assert tqdm_pandas(tqdm(total=0)) is None

    data = df(randint(0, 100, (100000, 6)))
    # We MUST use a single core, otherwise
    # we will be mixing up the outputs.
    # The test suite is run on many cores.
    with tqdm(total=len(data)) as pbar:
        def nop(x):
            sleep(0.0001)
            pbar.update()
            return

# Generated at 2022-06-12 14:20:18.485851
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import random

    try:
        tqdm_pandas(tqdm, disable=True)
    except:
        print("tqdm_pandas(tqdm, ...) deprecated!")

    try:
        tqdm_pandas(tqdm())
    except:
        print("tqdm_pandas(tqdm(...)) deprecated!")

    global t
    t = tqdm(total=0, leave=True, desc='test', miniters=1, unit_scale=1,
             initial=0)

    def f(x):
        t.update(1)
        return random.random()

    df = pd.DataFrame(np.random.random((100, 30)))

# Generated at 2022-06-12 14:20:27.204318
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm

    df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    tqdm_pandas(tqdm(total=len(df), ascii=True))
    df.groupby("a").progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:20:36.682007
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        import numpy
    except ImportError:
        return None
    df = pandas.DataFrame({'a': numpy.random.randint(0, 100, size=100),
                           'b': numpy.random.randint(0, 100, size=100)})
    # Test pandas >=0.18
    if hasattr(pandas.core.groupby.GroupBy, 'progress_apply'):
        from tqdm import tqdm
        tqdm.pandas(tqdm())
    else:
        from tqdm.autonotebook import tqdm
        tqdm_pandas(tqdm())
    tqdm.pandas(desc='desc')(lambda x: x)

# Generated at 2022-06-12 14:20:42.053103
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.util.testing.makeDataFrame()
    tqdm_pandas(tqdm)
    res = df.groupby('C').progress_apply(len)
    assert res.sum() == len(df)

# Generated at 2022-06-12 14:20:50.659425
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random
    from tqdm import tqdm

    try:
        from datetime import timedelta
    except ImportError:
        from pandas._libs.tslib import timedelta  # pandas<0.19.0

    df = DataFrame({'A': ['a'] * 1000, 'B': [1.0] * 1000})
    # Register tqdm with pandas
    with tqdm(total=len(df)) as pbar:
        df.groupby('A').progress_apply(lambda x: x, pbar=pbar)

    # Test Series.apply
    for n in [1, 2, 3, 5, 8, 13]:
        s = df['A'].head(100).progress_apply(lambda x: random.randn())

# Generated at 2022-06-12 14:21:01.644938
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    import pandas as pd
    from tqdm.auto import tqdm
    from numpy import arange, sin, cos

    df = pd.DataFrame({'a': arange(10000), 'b': arange(10000)})

    # Test tqdm.pandas(...)
    with tqdm(total=len(df)) as pbar:
        res = df.groupby('a').progress_apply(lambda x: x['a'] * x['b'])
        pbar.update(len(res))

    # Test tqdm_pandas
    with tqdm(total=len(df)) as pbar:
        res = df.groupby('a').progress_apply(lambda x: x['a'] * x['b'])

# Generated at 2022-06-12 14:21:07.709885
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from collections import Counter
    L = [3, 1, 2, 3, 1, 3]
    C = Counter(L)
    assert C[3] == 3
    assert C[2] == 1
    C = Counter()
    for k in tqdm_pandas(L):
        C[k] += 1
    assert C[3] == 3
    assert C[2] == 1



# Generated at 2022-06-12 14:21:19.146906
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    t = tqdm(desc='testing tqdm_pandas')

# Generated at 2022-06-12 14:21:23.043709
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.plotting import scatter_matrix

    tqdm_pandas(tqdm)
    df = DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    scatter_matrix(df.progress_apply(lambda x: x/2, axis=1), diagonal='kde')


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:21:32.238848
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy

    df = pandas.DataFrame({'a': numpy.random.randint(0, 100, size=100),
                           'b': numpy.random.randint(0, 100, size=100)})

    def func(x):
        return x ** 2

    df_squared_progress = df.progress_apply(func, axis=1)
    rel_error = sum(df_squared_progress['a'] - df['a'] ** 2)
    assert rel_error < 1e-4, "the function does not return the correct value"
    assert df_squared_progress.equals(df.apply(func, axis=1)), "the function does not return the correct value"


if __name__ == '__main__':
    import tqdm

# Generated at 2022-06-12 14:21:42.946689
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Simple tests for `tqdm_pandas` and other features.
    """
    from pandas import DataFrame, Series
    from tqdm import tqdm
    from tqdm.contrib import DummyTqdmFile, DummyTqdmFileObject

    # cleanup
    try:
        DataFrame.progress_apply
        DataFrame.progress_map
        Series.progress_map
    except AttributeError:
        pass
    else:
        raise Exception(
            "`DataFrame.progress_apply` already exists: "
            "could not safely run test"
        )

    # test Pandas integration
    tqdm_pandas(tqdm)
    assert hasattr(DataFrame, 'progress_apply')
    assert hasattr(DataFrame, 'progress_map')

# Generated at 2022-06-12 14:21:47.825356
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    data = np.random.rand(int(1e6))
    series = pd.Series(data)
    tqdm_pandas(series.progress_apply, lambda x:x+1)

# Generated at 2022-06-12 14:21:57.130336
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    try:
        import pandas_profiling
    except ImportError:
        raise ImportError("Error in test_tqdm_pandas: pandas_profiling is not installed.")
    from tqdm import tqdm

    dummy_df = DataFrame([[i for i in range(1000)]])
    dummy_df_profiling = pandas_profiling.ProfileReport(dummy_df)

    t = tqdm(total=1000, leave=True, position=0)
    t.set_description('done %s/%s' % (0, 1000))
    tqdm_pandas(t=t, desc="")
    dummy_df_profiling.to_html()
    assert t.n == t.total



# Generated at 2022-06-12 14:22:00.078980
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    return isinstance(tqdm_pandas(tqdm)(pd.DataFrame()).groupby(1).progress_apply(lambda x: x),
                      pd.core.groupby.DataFrameGroupBy)

# Generated at 2022-06-12 14:22:05.462589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        tq = tqdm_pandas(tqdm())

        df = pd.DataFrame([[1, 2], [3, 4]], columns=list('AB'))
        g = df.groupby('A')
        res = g.progress_apply(lambda x: x['A'][0])

        assert res.tolist() == [1, 3]
        tq.close()
    except Exception:
        pass
test_tqdm_pandas.test = True

# Generated at 2022-06-12 14:22:09.900871
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from tqdm.contrib import DummyTqdmFile

    df = DataFrame(range(10))
    with DummyTqdmFile() as file_:
        res = df.progress_apply(lambda x: x, file=file_)
        assert res.equals(df)



# Generated at 2022-06-12 14:22:14.453544
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm

    a = pd.DataFrame(np.random.rand(1000, 1000))
    tqdm.pandas()
    a.progress_apply(lambda x: x * 1.0)  # noqa: F841

# Generated at 2022-06-12 14:22:25.475489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.testing import assert_frame_equal

    for i in tqdm(range(10)):
        pass
    tqdm_pandas(tqdm(range(10)))

    df = DataFrame(list(range(10)))
    dfgp = df.groupby(0)
    dfgp.progress_apply(lambda x: x+1)
    tqdm_pandas(tqdm(dfgp))
    assert_frame_equal(df, dfgp.apply(lambda x: x+1))
    tqdm_pandas(tqdm, dfgp)
    assert_frame_equal(df, dfgp.apply(lambda x: x+1))

# Generated at 2022-06-12 14:22:29.760176
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib.tests._tqdm_test_cases import tqdm_pandas_test_cases

    for tc in tqdm_pandas_test_cases:
        tqdm_pandas(*tc.get('args', ()), **tc.get('kwargs', {}))

# Generated at 2022-06-12 14:22:37.326266
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`."""
    from pandas import DataFrame
    from tqdm import tqdm

    df = DataFrame({'x': [1, 2, 3], 'y': [2, 3, 4]})
    df = df.groupby('x').progress_apply(lambda x: x**2)
    tqdm_pandas(tqdm())
    df = DataFrame({'x': [1, 2, 3], 'y': [2, 3, 4]})
    df = df.groupby('x').progress_apply(lambda x: x**2)
    assert df.equals(tqdm_pandas(tqdm()).data)
    tqdm_pandas(tqdm)(mininterval=1, maxinterval=1)


# Generated at 2022-06-12 14:22:46.676568
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy

    from tqdm import tqdm
    from tqdm.contrib.concurrent import thread_map

    try:
        from pandas import Series
    except ImportError:
        Series = type(None)

    assert hasattr(DataFrameGroupBy, 'progress_apply')
    df = DataFrame(data={'col1': [0, 1, 2, 3], 'col2': [0, 1, 2, 3]})
    df_g = df.groupby('col1')
    assert tqdm_pandas(tqdm) is None
    assert tqdm_pandas(tqdm(desc='test')) is None
    assert tqdm_pandas(tqdm(ascii=True))

# Generated at 2022-06-12 14:22:54.583655
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas


if __name__ == "__main__":
    from doit.tools import create_doit_task

    def task_self():
        return create_doit_task(globals(),
                                'tqdm_pandas',
                                (tqdm_pandas,))
    task_self()

# Generated at 2022-06-12 14:22:58.735742
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    test_df = pd.DataFrame({'col': ['a'] * 10000})

    with tqdm_pandas(test_df.groupby('col')) as test_gb:
        test_gb.progress_apply(lambda x: x)
        test_gb.progress_apply(lambda x: x)

# Generated at 2022-06-12 14:23:00.752908
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas
    from tqdm import tqdm

    tqdm_pandas(tqdm())

# Generated at 2022-06-12 14:23:10.347897
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import unittest
    import pandas as pd

    class TestTqdmPandas(unittest.TestCase):
        def setUp(self):
            self.df = pd.DataFrame(
                {'col1': [1, 2, 3, 4, 5],
                 'col2': [2, 3, 4, 5, 6],
                 })
            self.df2 = pd.DataFrame(
                {'col1': [6, 7, 8, 9, 10],
                 'col2': [7, 8, 9, 10, 11],
                 })

        def test_tqdm_pandas(self):
            from tqdm import tqdm
            import sys


# Generated at 2022-06-12 14:23:17.603549
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        try:
            # this test is not crucial so it can be skipped
            if not pd._version.get_versions()['version'] >= '0.25':
                return
        except AttributeError:
            if pd.__version__ < '0.25':
                return
        tqdm_pandas(lambda x: x, desc='mytest')
        assert all('mytest' in l for l in sys.stderr.getvalue().split('\n')[-3:])
    except ImportError:
        pass


# Use test_tqdm_pandas() as a dummy test
test_tqdm_pandas.__doc__ = test_tqdm_pandas.__name__

# Generated at 2022-06-12 14:23:27.010437
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(
        {
            'a': [1, 5, 2, 0, 4, 5],
            'b': [9, 4, 1, 4, 5, 9],
            'c': [4, 1, 5, 5, 1, 4],
        }
    )

    def fn(x):
        np.random.seed(42)
        return int(np.random.choice(x, 1) + np.random.randn())

    tqdm_pandas()
    assert df.groupby('a').progress_apply(fn) is not None


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-12 14:23:35.753490
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    def test_func(df):
        return sum(df.sum())

    try:
        tqdm_pandas(tqdm(desc="test_pandas"))
        assert False, "tqdm_pandas(tqdm(...)) did not raise"
    except TypeError:
        pass

    with tqdm_pandas(tqdm, desc="test_pandas") as t:
        df = pd.DataFrame(np.random.random((10000, 10)))
        assert t.miniters == 1
        assert len(
            str(t)) > 0, "string representation of tqdm must not be empty"
        assert test_func(df) == df.progress_apply(test_func, axis=0).sum()

# Generated at 2022-06-12 14:23:42.169423
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm

    df = DataFrame({'a': Series(range(10))})

    for desc in [None, '', 'custom desc']:
        for total in [None, 10]:
            tqdm_pandas(tqdm(desc=desc, total=total))
            df.groupby(df['a'] % 3).progress_apply(
                lambda _: _)  # Test with `progress_apply`
            df.groupby(df['a'] % 3).progress_apply(
                lambda _: _)  # Test with `progress_apply`

# Generated at 2022-06-12 14:23:52.774608
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from tqdm import tqdm, trange
    except ImportError:
        print('tqdm not found, skipping tests.')
        return

    def sqrt(x):
        from time import sleep
        sleep(0.01)
        return x ** .5

    for adaptive in [False, True]:
        for mininterval in [0.1, 0.01, 0.001]:
            for miniters in [1, 10, 100]:
                for multi in [False, True]:
                    # test tqdm function
                    pdf = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

# Generated at 2022-06-12 14:23:57.632254
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame(dict(a=range(5), b=range(5, 10)))
    tqdm_pandas(tqdm.tqdm, desc='test')

    def f(x):
        return x.a + x.b
    df.groupby('a').progress_apply(f)

# Generated at 2022-06-12 14:24:05.163112
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas
    import numpy
    data = numpy.random.random(100)
    with tqdm.tqdm_pandas(total=len(data)) as _tqdm:
        pandas.DataFrame(data).groupby(data).progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:13.216991
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas """
    from tqdm.auto import tqdm
    from pandas.core.groupby import DataFrameGroupBy
    import numpy as np
    df = pd.DataFrame({'x': np.random.randint(10, size=(10,))})
    # old_progress_apply = DataFrameGroupBy.progress_apply

    def test_unit(df):
        return df.groupby(df.x).progress_apply(lambda x: x.x.sum())

    # Test (deprecated old-style)
    tqdm_pandas(tqdm)
    test_unit(df)
    # Test (new-style, basic)

# Generated at 2022-06-12 14:24:24.815346
# Unit test for function tqdm_pandas

# Generated at 2022-06-12 14:24:33.355956
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test"""
    try:
        # pylint: disable=unused-variable
        import pandas as pd  # NOQA
        tqdm_pandas(tqdm(total=4), desc="test")
        tqdm_pandas(tqdm.tqdm(total=4), desc="test")
        tqdm_pandas(tqdm.tqdm(total=4), desc="test", mininterval=0.5)
    except ImportError:
        print("Skipping Pandas tests...")

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:24:42.901449
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests `tqdm.tqdm_pandas`.
    """
    from pandas import DataFrame
    from tqdm import tqdm, tqdm_gui, tqdm_notebook

    df = DataFrame({'a': range(10), 'b': range(5, 15)})
    out = [0, 0]

    class tqdm_cls(tqdm):
        def __init__(self, iterable, *args, **kwargs):
            super().__init__(iterable, *args, **kwargs)
            self.df = iterable

    tqdm_pandas(tqdm_cls, leave=False)  # instantiate
    out[0] = df.groupby('a').progress_apply(lambda x: x['b'].sum())

   

# Generated at 2022-06-12 14:24:49.995335
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange

    def neg(x):
        return -x

    pd.options.display.max_rows = None

    with trange(1) as t:
        df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
        t.set_postfix(group=df.groupby('a').progress_apply(neg).groupby(level=0).sum())

    with trange(1) as t:
        df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})

# Generated at 2022-06-12 14:24:59.143806
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm, tqdm_pandas, tnrange
    from numpy import random

    N = 10000
    df = DataFrame({'a': random.randint(0, N, (N,)),
                    'b': random.randint(0, N, (N,))},
                   index=random.randint(0, N, (N,)))

    def f_test(x):
        return x > N // 2

    # no progress bar
    df.groupby('a').b.progress_apply(f_test).sum()

    # tqdm_pandas instead of tqdm
    # tqdm_kwargs = dict(desc='test', total=len(df))
    # tqdm_pandas(tqdm, **

# Generated at 2022-06-12 14:25:07.124442
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    arr = np.asarray([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    df = pd.DataFrame(arr, columns=['arr'])

    def increment(x):
        return x + 1

    tqdm_pandas(tqdm(total=len(df), desc='Increment'))
    res = df.progress_apply(increment)
    assert (res == arr + 1).all()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-12 14:25:12.403011
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random
    from tqdm import tqdm

    def func(x):
        import time
        return time.sleep(random.rand())

    df = DataFrame(random.rand(100, 100))
    tqdm_pandas(tqdm, leave=True)
    df.progress_apply(func)

    tqdm_pandas(tqdm, leave=False)
    df.progress_apply(func)

# if __name__ == '__main__':
#     test_tqdm_pandas()

# Generated at 2022-06-12 14:25:22.431773
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import random
    import time
    from tqdm import tqdm
    tqdm.pandas(tqdm(total=20, desc='faking progress'))
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)), columns=list('ABCDEF'))
    df.groupby(0).progress_apply(lambda x: time.sleep(0.01) or x)
    tqdm.pandas(tqdm(total=20, desc='faking progress'))
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)), columns=list('ABCDEF'))

# Generated at 2022-06-12 14:25:34.751601
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import inspect
    import pandas as pd
    import numpy as np

    tqdmp_func = tqdm_pandas
    func_str = inspect.getsource(tqdmp_func)
    assert 'tqdm' in func_str
    assert 'pandas' in func_str
    assert 'DataFrameGroupBy' in func_str
    assert 'progress_apply' in func_str
    assert 'tqdm_kwargs' in func_str

    def f(x):
        """Test function"""
        return x

    df = pd.DataFrame(np.random.randn(1000, 1))
    res = pd.DataFrame(np.random.randn(1000, 1))
    assert len(f(df)) == 1000
    res = f(df)

# Generated at 2022-06-12 14:25:45.223100
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import io
    import sys

    def test_instantiation(tqdm_cls=tqdm):
        t = tqdm_cls()
        assert isinstance(t, tqdm_cls)
        assert not t.dynamic_miniters

        t = tqdm_cls(dynamic_miniters=True)
        assert t.dynamic_miniters

        # deprecated:
        t = tqdm_cls(dynamic_miniters=False)
        assert not t.dynamic_miniters

        # deprecated:
        t = tqdm_cls(miniters=False)
        assert not t.dynamic_miniters



# Generated at 2022-06-12 14:25:55.741972
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    df = DataFrame({'a': range(5), 'b': range(2, 5) + range(2, 7)})
    with tqdm(total=df.groupby('a').size().sum()) as pbar:
        def _test(df):
            for _, row in df.iterrows():
                pbar.update()
                if row.a == 3:
                    raise StopIteration
                return row.b

        try:
            df.groupby('a').apply(_test)
        except StopIteration:
            pass

# # Regression test for #511
# def test_tqdm_pandas_regression511():
#     from pandas import DataFrame
#     from tqdm import tqdm
#     from t

# Generated at 2022-06-12 14:26:05.429536
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm as tqdm_original
    from tqdm import tnrange as tnrange_original
    from tqdm.pandas import tqdm as tqdm_pandas
    import pandas as pd
    import numpy as np

    # To avoid using nested loops (or function calls)
    range_ = range if sys.version_info[0] < 3 else range

    # Easier conversion
    def range_i(j):
        return [(i, i + j) for i in range_(0, 10, j)]

    # Test tqdm DataFrame
    res = []
    for j in range_(2, 5):
        res.append([i for i in tqdm_pandas(range_i(j), leave=False, postfix="!")])

# Generated at 2022-06-12 14:26:14.702577
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm.auto import tqdm
    from tqdm.contrib import DummyTqdmFile

    df = DataFrame([[1, 1], [1, 2], [3, 4]], columns=['A', 'B'])
    with tqdm(unit='B', unit_scale=True, total=len(df.memory_usage()),
              file=DummyTqdmFile()) as t:
        tqdm_pandas(t)
        df.progress_apply(lambda x: x, axis=1)


# Monkey-patch pandas
if pd is not None:
    try:
        import pandas.core.groupby
        import pandas.core.frame
        import pandas.core.series
    except ImportError:
        pass
   

# Generated at 2022-06-12 14:26:23.093908
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import Series
    import pandas as pd
    from tqdm import tqdm

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        from pandas.core.groupby import GroupBy as DataFrameGroupBy

    for i in tqdm([1, 2, 3]):
        pass

    try:
        DataFrameGroupBy._old_progress_apply = DataFrameGroupBy.progress_apply
    except AttributeError:
        pass

    DataFrameGroupBy.progress_apply = lambda x, y: None

    s = Series(range(100))

    # test tqdm
    tqdm_pandas(tqdm(leave=False, total=len(s)))