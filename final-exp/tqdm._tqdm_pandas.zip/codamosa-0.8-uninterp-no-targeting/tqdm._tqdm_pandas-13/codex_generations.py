

# Generated at 2022-06-22 04:43:01.705952
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        def func(a):
            time.sleep(1)
            return a

        result = pd.DataFrame({'a': [1,2,3,4,5]}).groupby('a').progress_apply(func)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:10.201942
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(ascii=True))
    import pandas as pd

    df = pd.DataFrame({'A': [1, 2, 3, 4]})
    df.groupby(['A']).progress_apply(lambda x: x)
    list(df.groupby(['A']).progress_apply(lambda x: x))

# Generated at 2022-06-22 04:43:16.471064
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    total = len(df)

    with tqdm_pandas(total=total) as t:  # Register instance
        def fn(x):
            return x
        df.groupby(0).progress_apply(fn)

# Generated at 2022-06-22 04:43:25.339346
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm

    df = pd.DataFrame(np.random.random((100, 10)))
    tqdm_pandas(tqdm, tclass=type(tqdm.tqdm()))
    # Test with a new tqdm instance
    with tqdm.tqdm() as t:
        df.progress_apply(lambda x: x / 1., axis=1,
                          prog_bar=t,
                          post_apply=lambda x: t.update())

# Generated at 2022-06-22 04:43:33.874879
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test warning:
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)

    # Test no-op:
    with pytest.warns(None) as record:
        tqdm_pandas(tqdm.tqdm)
    assert len(record) == 0

    @tqdm_pandas(tqdm)
    def dummy_pandas_instance():
        pass

    with pytest.warns(None) as record:
        dummy_pandas_instance()
    assert len(record) == 0

# Generated at 2022-06-22 04:43:42.995601
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    @tqdm_pandas
    def groupby_apply_test(df):
        """
        https://github.com/pandas-dev/pandas/blob/master/pandas/core/groupby/groupby.py#L4248
        """
        return df.groupby('a').progress_apply(lambda x: x * 2)

    def groupby_apply_test_orig(df):
        """
        https://github.com/pandas-dev/pandas/blob/master/pandas/core/groupby/groupby.py#L4248
        """
        return df.groupby('a').apply(lambda x: x * 2)


# Generated at 2022-06-22 04:43:52.978620
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange, pandas

    for tqdm_func in [tqdm, trange]:
        # Basic
        with tqdm_func(7) as t:
            pandas(t)

        # Basic with bar_format
        with tqdm_func(7, bar_format='{desc}') as t:
            pandas(t)

        # Basic with fraction
        with tqdm_func(7, total=100, desc='test', position=1,
                       dynamic_ncols=True) as t:
            pandas(t)

        # Basic with `file`
        with tqdm_func(7, file=sys.stdout) as t:
            pandas(t)

        # Basic with `disable`

# Generated at 2022-06-22 04:43:54.528922
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm.auto as t
    t.pandas()



# Generated at 2022-06-22 04:44:05.694530
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    from tqdm import pandas as tqdm_pandas

    df = pd.DataFrame({'x':np.random.randn(100000),
                       'y':np.random.randn(100000)})
    df = df[np.random.rand(len(df)) > 0.95]
    df = df.groupby('x').progress_apply(lambda x: x.mean())
    df = df.groupby('y').apply(lambda x: x.mean())

    # If a progressbar shows up and completes, it's working.

# Generated at 2022-06-22 04:44:15.944183
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    import numpy as np
    import pandas as pd
    import tqdm.TestHandler
    import tqdm
    pd.DataFrame({'a': np.arange(1e5)}) \
        .groupby('a') \
        .progress_apply(lambda x: sum(x))
    assert tqdm.TestHandler.EXCEPTIONS == ['BadZipfile', 'chunked']

    # Regression test for
    # https://github.com/tqdm/tqdm/issues/743
    pd.DataFrame({'a': range(100)}).groupby('a').progress_apply(min)

    # Regression test for updating :total_attr_sum
    # https://github.com/tqdm/tqdm

# Generated at 2022-06-22 04:44:26.370072
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    import tqdm_pandas

    def sum_ints(ints):
        return sum(ints)

    data = pd.DataFrame(np.random.randint(0,100,size=(100000, 4)), columns=list('ABCD'))
    assert data.groupby('A').progress_apply(sum_ints).sum().sum() == data.sum().sum()
    assert data.groupby('A').progress_apply(sum_ints).sum().sum() == data.sum().sum()

# Generated at 2022-06-22 04:44:30.562018
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    df = pd.DataFrame({'x': [1, 2, 3], 'y': [1.0, 2.0, 3.0]})
    tqdm.pandas(tqdm.tqdm)
    df.groupby('x').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:44:35.074301
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    pd.DataFrame({'x': range(3)}).groupby(0).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:46.528307
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    ra = np.array
    dt = np.dtype
    x = ra([(1, 3.), (3, 2.), (5, 1.)], dtype=dt([('a', np.int), ('b', np.float)]))
    y = x.copy()
    y.dtype.names = ('aa', 'bb')

    import pandas as pd
    dfx = pd.DataFrame(x)
    dfy = pd.DataFrame(y)
    tqdm_pandas(tqdm(total=len(dfx) + len(dfy)),
                desc="pd.DataFrame.progress_apply()")

# Generated at 2022-06-22 04:44:56.710886
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class Tqdm(object):
        """
        Mock class
        """
        class TqdmDeprecationWarning(object):
            """
            Mock class
            """
            def __init__(self, text, fp_write=None):
                pass

        def pandas(self, deprecated_t=None):
            pass

    assert (tqdm_pandas(Tqdm))
    assert (tqdm_pandas(Tqdm, position=1))
    assert (tqdm_pandas(Tqdm.TqdmDeprecationWarning))
    assert (tqdm_pandas(Tqdm.TqdmDeprecationWarning, position=1))



# Generated at 2022-06-22 04:45:05.531529
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd


# Generated at 2022-06-22 04:45:15.587323
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd

        from tqdm import tqdm_pandas, tqdm
    except ImportError:
        return
    tqdm_pandas()

    df = pd.DataFrame({"val": [i for i in range(10)]})
    df_grouped = df.groupby(df["val"] % 2)

    # Test deprecated tqdm_pandas
    def tqdm_pandas_deprecated(tclass, **tqdm_kwargs):
        return tqdm_pandas(tclass, **tqdm_kwargs)

    # Test deprecated tqdm_pandas
    tqdm_pandas_deprecated(tqdm(pandas=True))

# Generated at 2022-06-22 04:45:25.777422
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import random
    random.seed(0)

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    mask = df.sum(axis=1) > 300
    res = df[mask]
    try:
        with tqdm_pandas(total=len(df)) as pbar:
            res = df.groupby(mask).progress_apply(lambda x: x * 2)
    except Exception:  # pragma: no cover
        subprocess_run(['git', 'bisect', 'bad', 'HEAD'])
        raise

    assert len(res) == 18241


# Generated at 2022-06-22 04:45:36.670825
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from _tqdm import tqdm, TqdmSynchronisationWarning
    from tqdm import tqdm_notebook  # for do nothing in unit tests
    from tqdm import tnrange, tqdm_pandas  # for do nothing in unit tests
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmSynchronisationWarning)
        with tqdm(leave=False) as gobar:
            tqdm_pandas(gobar)
            # NB: DataFrameGroupBy.progress_apply(func, *args, **kwargs)
            func = lambda series: series
            args = (1, 2, 3)
            kwargs = {'a': 1}
            gobar.pandas(func, *args, **kwargs)

# DE

# Generated at 2022-06-22 04:45:43.947062
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    # example progress function
    def progress_fct(x):
        x.loc[0] /= 2
        return x

    df = pd.DataFrame({
        0: pd.Series(range(1000)),
        1: pd.Series(range(1000))
    })
    # NOTE: normalise=True is incompatible with pandas up to 0.20.0
    df.groupby(0).progress_apply(progress_fct, normalise=True)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm())  # verify no exception

# Generated at 2022-06-22 04:45:51.393796
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        df = pd.DataFrame({'x': range(100)})
        df.groupby(0).progress_apply(lambda x: x)
        from tqdm import tqdm
        tqdm_pandas(tqdm)
        df.groupby(0).progress_apply(lambda x: x)
    except Exception as e:  # pragma: no cover
        print("TqdmDeprecationWarning: " + str(e))
        raise e

# Generated at 2022-06-22 04:46:02.647272
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from tqdm.utils import _term_move_up
    from tqdm._tqdm import FormatCustomText
    from pandas import DataFrame, Series
    from pandas.core.groupby import DataFrameGroupBy
    from numpy.core.defchararray import upper

    # Make a sample dataset
    df = DataFrame({"val": Series(["a", "b", "c", "d", "e", "f", "g", "h"])})
    # Enable tqdm_pandas
    tqdm_pandas(trange)
    # Try to run a progress_apply
    it = df.groupby("val").progress_apply(lambda x: upper(x))
    # Result should have all tqdm attributes and a proper iterator

# Generated at 2022-06-22 04:46:09.493008
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    from tqdm import trange


# Generated at 2022-06-22 04:46:17.625491
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    import tqdm.contrib.pandas

    def my_function(x):
        return x ** 2

    tqdm.contrib.pandas.tqdm_pandas(tqdm.tqdm_notebook)
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.progress_apply(my_function)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:21.996215
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from pandas.testing import assert_frame_equal

    df = pd.DataFrame({'A':[1,2,3], 'B':[4,5,6]})
    from tqdm import tqdm
    result = df.groupby('A').progress_apply(lambda x: x)
    assert_frame_equal(result, df.groupby('A').apply(lambda x: x))

    try:
        from tqdm.pandas import tqdm_pandas
    except:
        pass
    else:
        result = df.groupby('A').progress_apply(lambda x: x)
        assert_frame_equal(result, df.groupby('A').apply(lambda x: x))


# Generated at 2022-06-22 04:46:33.104676
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm._tqdm_pandas import tqdm_pandas
    from pandas.util.testing import assert_frame_equal

    # Create pandas dataframe
    df = pd.DataFrame(np.random.randn(10, 2))

    # Define function for pandas apply
    def func(df):
        return pd.DataFrame({
            'col1': df.max(axis=1),
            'col2': df.min(axis=1),
        })

    # Apply tqdm_pandas to pandas apply
    tqdm_pandas(func(df))

    # Compare result with default pandas apply
    assert_frame_equal(func(df), df.progress_apply(func))


# Generated at 2022-06-22 04:46:43.061600
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    
    df = pd.DataFrame(data={'col1': [1, 2, 3], 'col2': [4, 5, 6]})
    tclass = tqdm_pandas(df.groupby('col1'))
    tclass.progress_apply(lambda x: x)
    
    
if __name__ == '__main__':
    test_tqdm_pandas()
 
#%% [markdown]
# #### [tqdm](https://github.com/tqdm/tqdm)

#%%
from tqdm import tqdm, trange, tqdm_notebook, tnrange
from time import sleep
from random import randint

lst = [randint(1, 500) for i in range(1000)]



# Generated at 2022-06-22 04:46:47.885632
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from tqdm.tests.test_tqdm import FakePandasDF

    df = FakePandasDF([2, 3, 4])
    tqdm_pandas(tqdm, desc='Pandas', leave=False)(
        df.groupby('c').progress_apply(lambda x: x.c.sum())).sum()

# Generated at 2022-06-22 04:46:54.138622
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_notebook, tqdm_gui, tqdm
    from tqdm.autonotebook import tqdm as atqdm
    from tqdm import trange

    rows = 100
    cols = 5

    # Register all possible implementations of tqdm with pandas
    for tclass in [tqdm, tqdm_notebook, tqdm_gui, atqdm, trange]:
        for t in [tclass, tclass()]:
            try:
                tqdm_pandas(t)
            except TqdmDeprecationWarning:
                pass
            else:
                test_df = pd.DataFrame({i: np.random.randn(rows) for i in range(cols)})
                # Check is progress bar overrides pandas groupby apply

# Generated at 2022-06-22 04:47:00.419986
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    t = trange(4, desc='test')
    t.pandas(t, total=4)
    t.pandas(total=4)
    t.pandas(t, total=4)
    t.pandas(total=4)
    tqdm_pandas(t, total=4)
    tqdm_pandas(trange, total=4)

# Generated at 2022-06-22 04:47:13.360323
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas, sys

    tclass = type('tqdm', (object,), {'__name__': 'tqdm'})(
    )  # test class as adapter
    tqdm_pandas(tclass)
    assert (
        tqdm_pandas == type(tclass).pandas.__func__
    ), "tqdm_pandas did not initialize the adapter"

    tclass = type('tqdm', (object,), {'__name__': 'tqdm_notebook'})(
    )  # test class as adapter
    tqdm_pandas(tclass)
    assert (
        tqdm_pandas == type(tclass).pandas.__func__
    ), "tqdm_pandas did not initialize the adapter"

    tclass

# Generated at 2022-06-22 04:47:15.060070
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
        import pandas as pd
        import tqdm

        tqdm.tqdm_notebook().pandas()

# Generated at 2022-06-22 04:47:26.863337
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm  # ...

    # Test initialisation
    df = pd.DataFrame([[0, 1, 2, 3], [0, 1, 2, 3]])
    with tqdm.pandas() as t:
        t.get_lock()
        # Test lock
        assert t.get_lock() is t.get_lock()

        df = df.groupby(0).progress_apply(lambda df: df)
        # Test GroupByRegister
        assert hasattr(df.groupby(0), 'progress_apply')
        df = df.groupby(0).progress_apply(lambda df: df)
        # Test GroupByRegister
        assert hasattr(df.groupby(0), 'progress_apply')

# Generated at 2022-06-22 04:47:31.630854
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    testdf = pd.DataFrame(np.random.random((500, 500)))
    import tqdm
    tqdm_pandas(tqdm.tqdm_notebook)
    testdf.groupby(testdf.index // 10).progress_apply(lambda x: x)
    
# Execute function tqdm_pandas
test_tqdm_pandas()
 
# Create class

# Generated at 2022-06-22 04:47:43.435525
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame, Series
    from tqdm import tqdm, tqdm_pandas

    assert_err = 'tqdm_pandas()'
    try:
        tqdm_pandas(tqdm)
    except TypeError as e:
        if str(e).startswith(assert_err):
            pass
        else:
            raise

    def func(x, c=3):
        return x + c

    df = DataFrame(dict(a=Series([1, 2, 3])))
    res_df = df.progress_apply(func)
    assert df.equals(res_df)
    # Test again, for StdErr handling
    res_df = df.progress_apply(func)

# Generated at 2022-06-22 04:47:52.694831
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    import numpy as np
    from tqdm import tnrange
    from pandas.util.testing import assert_frame_equal

    tqdm_pandas(tqdm, leave=True)
    n = 100
    df = pd.DataFrame(np.random.random(size=n))
    df2 = pd.DataFrame(np.random.randint(0, 100, size=n))

    res = df.groupby(df2).progress_apply(lambda x: x.sum())
    assert_frame_equal(res, df.groupby(df2).apply(lambda x: x.sum()),
                       check_dtype=False)

# Generated at 2022-06-22 04:48:03.529703
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_notebook
    from pandas import DataFrame

    df = DataFrame(data={'a': [1, 2, 3],
                         'b': ['a', 'b', 'c'],
                         }, )
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    assert df.groupby('b').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:48:11.764103
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from .autonotebook import tnrange, tqdm
    from tqdm import TqdmKeyError
    from tqdm._utils import _term_move_up

    tqdm_pandas(tqdm)

    # Unpatch
    if hasattr(_tqdm_pandas, 'patched_apply'):
        import pandas as pd
        pd.core.groupby.DataFrameGroupBy.progress_apply = _tqdm_pandas.patched_apply
        del _tqdm_pandas.patched_apply
    # Sanity
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmKeyError)

# Generated at 2022-06-22 04:48:20.068349
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        # `tqdm_pandas` is a bridge between `tqdm` and `pandas`
        # Ensure that it works with both, even in case of delayed import
        # tqdm is an optional dependency of pandas
        import tqdm.pandas
        df = pd.DataFrame({'x': range(100000), 'y': range(100000, 200000)})
        tqdm_pandas(tqdm.pandas.tqdm)
        df.groupby('x')
        df.groupby('x')
    except ImportError:
        # Skip test if pandas is not installed
        pass

# Generated at 2022-06-22 04:48:30.701218
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from unittest import TestCase
    from tqdm import tqdm, trange
    from tqdm.auto import tqdm_pandas
    from pandas import DataFrame, Series
    import numpy as np
    import warnings

    class TestDataFrame(DataFrame):
        def progress_apply(self, func, *args, **kwargs):
            super(TestDataFrame, self).apply(func, *args, **kwargs)

    class TestSeries(Series):
        def progress_apply(self, func, *args, **kwargs):
            super(TestSeries, self).apply(func, *args, **kwargs)

    class TestTqdm(tqdm):
        @staticmethod
        def pandas(**kwargs):
            raise Exception("tqdm.pandas(...) should not be called")

# Generated at 2022-06-22 04:48:38.807605
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test function tqdm_pandas.
    """
    from pandas import DataFrame, Series

    a = DataFrame({"target": Series([1] * 10), "values": [1] * 10})
    a = a.groupby("target").progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:50.258121
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    tqdm.pandas()
    tqdm_pandas(tqdm, file=sys.stdout)  # should not raise warnings

    # Test all methods returning iterators
    df = DataFrame([1, 2, 3, 4])
    assert tqdm(df.values).__class__ == tqdm(df.values)
    assert tqdm(df.itertuples()).__class__ == tqdm(df.itertuples())
    assert tqdm(df.iterrows()).__class__ == tqdm(df.iterrows())
    assert tqdm(df.iteritems()).__class__ == tqdm(df.iteritems())

# Generated at 2022-06-22 04:49:00.553250
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    from pandas.core.groupby import DataFrameGroupBy
    from numpy.testing import assert_equal

    # collect original progress_apply
    wrapped_progress_apply = DataFrameGroupBy._progress_apply

    # prepare a mock `tqdm.auto`
    tclass = type('tqdm_' + __name__ + '_test', (object,), {})
    tclass.auto = lambda *args, **kwargs: tclass()
    tclass._instances = []

    # execute tqdm_pandas function
    tqdm_pandas(tclass, leave=False)

    # test if mocked `tqdm.auto` is called
    assert tclass._instances == []
    assert wrapped_progress_apply == DataFrameGroupBy._progress

# Generated at 2022-06-22 04:49:06.860662
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    df = pd.DataFrame(np.random.randn(10000, 2), columns=list('AB'))
    # apply a custom function to each column
    # this should work despite the custom function
    # applied to the columns using standard apply
    # having no `.transform` method
    df.groupby('A').progress_apply(sum)

# Generated at 2022-06-22 04:49:16.636372
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return  # skip if not installed
    from tqdm import tqdm, tqdm_notebook, tqdm_pandas

    # class-based registration (`tqdm.pandas`)
    tqdm_pandas(tclass=tqdm)

    # function-based registration (`tqdm.pandas`)
    tqdm_pandas(tclass=tqdm_notebook)

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [2, 3, 4]})

    if hasattr(tqdm, "_instances"):
        _tqdm_instances = tqdm._instances.copy()
        tqdm._instances.clear

# Generated at 2022-06-22 04:49:21.599530
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas

    def f(x):
        return x * .1

    N = int(1e6)
    tqdm_pandas(tqdm())
    df = pd.DataFrame(np.random.randint(0, N, (N, 2)))
    ans = df.groupby(0).progress_apply(f)

    assert (ans == df.groupby(0).apply(f)).all()

    # Make sure that multi-index works
    df = pd.DataFrame(np.arange(N * 4).reshape(N, 4),
                      columns=['A', 'B', 'C', 'D']).set_index(['A', 'B'])
    ans = df.group

# Generated at 2022-06-22 04:49:25.884481
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def f(x):
        # print(x)
        import time
        time.sleep(0.01)

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]})
    try:
        df.groupby('a').progress_apply(f)
        assert False, "tqdm_pandas() is not registered in pandas.core.groupby"
    except AttributeError:
        pass
    tqdm_pandas()
    df.groupby('a').progress_apply(f)

# Generated at 2022-06-22 04:49:32.372424
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        print("pandas not installed, skipping tqdm_pandas test")
        return
    import pandas as pd
    pd.DataFrame({'a': [1] * 1000000, 'b': [2] * 1000000}).groupby('b').apply(
        lambda x: x['a'].sum())
    print("\nNot throwing an error is enough to pass tqdm_pandas test")

test_tqdm_pandas()

# Generated at 2022-06-22 04:49:44.422891
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    import tqdm

    df = pd.DataFrame(np.array(np.random.randn(100, 4), dtype='f4'),
                      columns=['a', 'b', 'c', 'd'])
    gb = df.groupby(df.a // 0.2, sort=False)
    tqdm.pandas()
    t = time.time()
    lst = []
    for i, dfg in enumerate(gb):
        lst.append(dfg[1]['b'].progress_apply(
            lambda x: time.sleep(0.01) or x))
        if i > 3:
            break
    assert time.time() - t < 1



# Generated at 2022-06-22 04:49:51.287805
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randn(5, 2))
    tqdm_pandas(tqdm, total=len(df))
    result = df.groupby(df.index // 2, sort=False).progress_apply(lambda x: (x ** 2).sum())
    return result


if __name__ == '__main__':
    from tqdm import tqdm
    test_tqdm_pandas()
    print('Test passed')

# Generated at 2022-06-22 04:50:06.876250
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    df = pd.DataFrame(np.random.randint(0, 100, (1000, 6)))
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(leave=False))
    tqdm_pandas(tqdm(desc="Pandas"))
    tqdm_pandas(tqdm(desc="Pandas", file=sys.stdout))
    tqdm_pandas(tqdm(desc="Pandas", file=sys.stderr, leave=False))
    df.groupby(0).progress_apply(lambda x: x**2)



# Generated at 2022-06-22 04:50:11.478131
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import test_pandas
    import tqdm as tm
    func = tm.tqdm
    tm.tqdm = lambda x: x
    try:
        tqdm = tqdm_pandas(func, desc='test')
        test_pandas(tqdm_pandas=tqdm)
    finally:
        tm.tqdm = func

# Generated at 2022-06-22 04:50:21.764951
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    try:
        import numpy as np
    except ImportError:
        return
    irange = range
    from tqdm import tqdm
    for n in irange(5, 20, 5):
        tqdm.pandas(desc='test_tqdm_pandas')
        io = StringIO()
        df = pandas.DataFrame(np.random.random((n, n)))
        for _ in df.groupby(0).progress_apply(lambda x: x):
            pass
        tqdm.pandas(desc='test_tqdm_pandas', file=io)
        for _ in df.groupby(0).progress_apply(lambda x: x):
            pass

# Generated at 2022-06-22 04:50:31.360118
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    try:
        from tests_tqdm import pandas
    except ImportError:
        return

    with pandas.option_context("mode.chained_assignment", None):
        frame = pd.DataFrame({'a': range(2000)})
        frame.groupby('a').progress_apply(lambda x: x)

        tqdm_bar = tqdm(range(10))
        tqdm_pandas(tqdm_bar)
        frame.groupby('a').progress_aggregate(lambda x: x)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:41.731946
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm
    from tqdm.contrib.tests._utils import TestCaseMixin

    class T(TestCaseMixin):

        def test_tqdm_pandas(self):
            """Test tqdm"""
            import pandas
            from tqdm import tqdm

            df = pandas.DataFrame(
                {'a': range(100), 'b': range(100)})

            # should raise TypeError if not called on a pd.DataFrame
            with self.assertRaises(TypeError):
                tqdm(df.columns.tolist()).apply(len)

            # no tqdm bar displayed yet

# Generated at 2022-06-22 04:50:51.150651
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    n_rows = 10000
    df = pd.DataFrame(np.random.rand(n_rows), columns=['random'])

    df.groupby(0).progress_apply(lambda x: x)

    for i in range(5):
        tqdm.tqdm.pandas(desc="Pandas loop with `tqdm.tqdm.pandas()`")
        df.groupby(0).progress_apply(lambda x: x)

    tqdm.tqdm_pandas(tqdm.tqdm(), desc="Pandas loop with `tqdm.tqdm_pandas()`")
    df.groupby(0).progress_apply(lambda x: x)

    tqdm

# Generated at 2022-06-22 04:51:02.188921
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test without any parameter (no tqdm)
    try:
        tqdm_pandas()
    except TypeError:
        pass
    except Exception as e:
        raise e

    # Test with tqdm, before and after registration (required in some cases)
    from tqdm import tqdm
    from pandas import DataFrame, Series, concat

    df = DataFrame({'x': Series([1, 2, 3])})

    tqdm_pandas(tqdm)
    try:
        df.groupby(df.columns[0]).progress_apply(lambda x: x)
    except AttributeError:
        pass

    # Test without any parameter (tqdm already registered)
    tqdm_pandas()

# Generated at 2022-06-22 04:51:10.503771
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    df = pd.DataFrame({'col': range(10000)})
    tqdm_pandas(tqdm)
    df.groupby('col').progress_apply(lambda x: x)
    tqdm_pandas(tqdm, disable=True)
    df.groupby('col').progress_apply(lambda x: x)

    # tqdm.notebook
    tqdm_pandas(tqdm.notebook)
    df.groupby('col').progress_apply(lambda x: x)
    tqdm_pandas(tqdm.notebook, disable=True)
    df.groupby('col').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:51:22.073983
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests `tqdm_pandas(tqdm)` and `tqdm_pandas.pandas(tqdm)`:
        >>> test_tqdm_pandas()
    """
    from unittest import TestCase
    from collections import namedtuple
    import pandas as pd
    from .tqdm import tqdm

    # Test class
    TqdmTest = namedtuple("TqdmTest", ["t", "tqdm_kwargs", "entries"])
    tests = []  # Test collection

    # Test 1
    tests.append(TqdmTest(
        t=tqdm, tqdm_kwargs={},
        entries=pd.DataFrame([1, 2, 3, 4, 5]).groupby(0).progress_apply(sum)))

# Generated at 2022-06-22 04:51:30.036954
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    tqdm.pandas(tqdm)

    def tqdm_sample():
        """
        Used to apply to pandas' DataFrame.
        """
        import time
        time.sleep(0.1)

    # Test pandas without tqdm
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    print(df.groupby(0).progress_apply(tqdm_sample))

    # Test pandas with tqdm
    # pd.set_option('display.max_columns', None)
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

# Generated at 2022-06-22 04:51:53.857443
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    tqdm.pandas(desc='test_pandas')
    pd.DataFrame.test = lambda x: x
    assert tqdm.get_instances() > 0, 'tqdm_pandas() failed'


if __name__ == '__main__':
    from os import sys, path
    sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
    from tests_tqdm import _test_argparse, PytestTqdm, test_tqdm
    from pandas import DataFrame
    from pandas import Series  # noqa
    from numpy import arange  # noqa
    from tqdm import tqdm
    from time import sleep

    test_tqdm

# Generated at 2022-06-22 04:52:03.614735
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm
    from tqdm._tqdm_pandas import tqdm as tqdm_pandas

    for tclass in [tqdm_pandas, tqdm]:
        # Setup
        series = Series(range(100))
        dataframe = DataFrame({"a": series, "b": series})

        # Just tqdm
        tqdm(total=len(dataframe), disable=None, file=sys.stdout)

        # Tqdm with sum
        tqdm(total=len(dataframe), disable=None, file=sys.stdout).sum()

        # Tqdm with apply
        tqdm(total=len(series), disable=None, file=sys.stdout).apply(lambda x: x)

# Generated at 2022-06-22 04:52:13.400525
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    tqdm_pandas(tqdm)
    try:
        pd.DataFrame([1, 2]).groupby(0).progress_apply(lambda x: x)
    except AttributeError:
        raise AssertionError("tqdm_pandas doesn't register properly")
    finally:
        try:
            pd.DataFrameGroupBy.progress_apply.unregister(tqdm)
        except TypeError:  # pragma: no cover
            pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:23.689302
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import TqdmDeprecationWarning
    import pandas as pd

    with tqdm(total=2) as t:
        with pytest.warns(TqdmDeprecationWarning,
                          match=r'Please use `tqdm.pandas(...)` instead of `tqdm_pandas\(tqdm, ...\)`\.') as recwarn:
            tqdm_pandas(t)


# Generated at 2022-06-22 04:52:33.568215
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    for i in range(4):
        tqdm_pandas(tqdm(total=4, position=i), file=open(os.devnull, 'w'))

    df = pd.DataFrame({'x': range(100), 'y': np.random.randn(100)})
    tqdm_pandas(tqdm(total=100, unit='rows'), file=open(os.devnull, 'w')).progress_apply(
        lambda x: x, axis=1)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:42.327875
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'A': [1, 2, 3, 4]})
    result = df.groupby('A').progress_apply(lambda x: x.sum())
    assert result.equals(df)
    result = df.groupby('A').progress_apply(lambda x: x.sum(),
                                            tqdm_kwargs=dict(total=len(df), desc='mygroupby'))
    assert result.equals(df)
    # Check returned object is valid
    result = df.groupby('A').progress_apply(lambda x: x.sum(), tqdm_kwargs={
        'total': len(df), 'desc': 'mygroupby'})
   

# Generated at 2022-06-22 04:52:54.109497
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas
    from pandas import DataFrame
    from numpy import random
    from sys import stderr

    df = DataFrame(dict(a=random.randint(0, 4, 100),
                        b=random.randint(0, 4, 100)))
    pandas(unit='rows', desc='foo', file=stderr)(df.groupby('a').progress_apply)(
        lambda x: x + 1)
    pandas(unit='rows', desc='foo', file=stderr)(df.groupby('a').progress_apply)(
        lambda x: x + 1)


if __name__ == '__main__':
    from os import system
    from sys import version_info

    if version_info.major == 2:
        from tqdm import tqdm_gui as tqdm

# Generated at 2022-06-22 04:53:03.092652
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.pandas import tqdm_pandas
    import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

    # `tqdm_pandas` should work with `tqdm.tqdm`
    with tqdm.tqdm(desc="test") as t:
        tqdm_pandas(t)
        df.groupby(0).progress_apply(lambda x: x**2)

    # `tqdm_pandas` should work with `tqdm.tqdm` and `tqdm.pandas`
    with tqdm.tqdm(desc="test") as t:
        tqdm_pand