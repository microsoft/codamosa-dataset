

# Generated at 2022-06-22 04:43:03.861552
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm, trange

    for k in ('ncols', 'miniters', 'mininterval'):
        for v in (1, 0.5, 1e-3):
            tqdm_pandas(tqdm(**{k: v}))
            tqdm_pandas(tqdm())
            tqdm_pandas(trange())
            tqdm_pandas(trange(0, 5, 0.5), desc='trange', unit='s', mininterval=v, miniters=v,
                        ncols=v)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:15.065776
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return
    indices = np.arange(5)
    df = pd.DataFrame(data={'col1': ['a', 'b', 'c', 'd', 'e'],
                            'col2': np.arange(5, dtype=np.int64),
                            'col3': indices})
    df_gp = df.groupby(by='col1')
    # should not raise
    tqdm_pandas(tqdm_kwargs={'disable': True})(df_gp)
    # test with default tqdm
    tqdm_pandas()(df_gp)
    # test with delayed adapter

# Generated at 2022-06-22 04:43:25.079024
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    from tqdm._tqdm import tqdm
    df = pandas.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
    df.groupby('y').progress_apply(lambda x: numpy.sum(x))
    df.groupby('y').progress_apply(lambda x: numpy.sum(x),
                                   tqdm_kwargs={'leave': False, 'total': 10})
    tqdm_pandas(tqdm)
    df.groupby('y').progress_apply(lambda x: numpy.sum(x))

# Generated at 2022-06-22 04:43:27.040891
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({'a': np.linspace(1, 10, 10**6)})
    df.groupby('a').progress_apply(lambda x: x.sum())

# Generated at 2022-06-22 04:43:38.995197
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas() function.
    """
    try:
        from tqdm import tqdm_pandas
    except ImportError:
        return 0
    else:
        try:
            import pandas as pd
        except ImportError:
            return 0
        else:
            tqdm_pandas(tqdm)
            df = pd.DataFrame({"A": [1, 2, 4, 8, 16]})
            tqdm.pandas(desc="test")
            res = df.groupby(df.A // 4).progress_apply(lambda x: x.sum())
            if res is None:  # pragma: no cover
                raise ValueError("df.groupby(...).progress_apply(...) failed")
            return 0

# Generated at 2022-06-22 04:43:51.224557
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from distutils.version import LooseVersion
    from pandas import DataFrame, Series
    from . import tqdm
    from .utils import _version

    # 'progress_apply' is not available in older pandas versions
    if _version.parse(LooseVersion(pandas.__version__)) < _version.parse(
            LooseVersion('0.16.2')):
        try:
            DataFrame.progress_apply
        except AttributeError:
            return
        else:
            raise Exception("Failed asserting that pandas < 0.16.2 doesn't have 'progress_apply'")

    tqdm.pandas(tqdm.tqdm, leave=False)
    assert 'progress_apply' in DataFrame.__dict__
    assert 'progress_apply' in Series.__dict__

# Generated at 2022-06-22 04:43:55.835761
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame({'x': np.random.randint(0, 100, 100000)})
    df.groupby('x').progress_apply(lambda x: x)  # test-passed

# Generated at 2022-06-22 04:44:06.395591
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmDeprecationWarning

    # Ensures that the chain "tqdm_pandas(tqdm)" throws a warning
    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm())
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)

    # Ensures that the chain "tqdm_pandas(tqdm, ...)" throws a warning
    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm, leave=True)
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)

    # Ens

# Generated at 2022-06-22 04:44:12.792776
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    with tqdm_pandas(total=len(pd.DataFrame(np.random.randint(2, size=(100000, 20))))) as t:
        _ = pd.DataFrame(np.random.randint(2, size=(100000, 20))).progress_apply(lambda x: x**0)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:18.702617
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd

    def test_func(a, b):
        from time import sleep
        sleep(0.5)
        return a + b

    df = pd.DataFrame([(1, 2), (4, 5), (6, 7), (8, 9)],
                      columns=['first', 'second'])
    tqdm_pandas(tqdm())
    assert (df.groupby('first').progress_apply(test_func, b=3)
            == df.groupby('first').apply(test_func, b=3)).all()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:31.866588
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    from tqdm import tqdm_pandas
    from pandas import DataFrame, Series
    from numpy import random
    df = DataFrame(random.randint(0, 1000, (100000, 6)))
    # We MUST avoid `progress_apply` here or else it will
    # be infinitely recursive
    df.groupby(0).progress_apply(lambda x: x**2)
    with tqdm.external_write_mode():
        tqdm_pandas(tqdm.tqdm)
        df.groupby(0).progress_apply(lambda x: x**2)
        with tqdm.tqdm(total=10) as t:
            tqdm_pandas(t)

# Generated at 2022-06-22 04:44:42.034813
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_gui

    class User(object):
        def __init__(self, name, age):
            self.name = name
            self.age = age

    users = [User(name=chr(x), age=x % 17) for x in range(65, 94)]
    df = pd.DataFrame([x.__dict__ for x in users])
    df.groupby('age').progress_apply(lambda x: x.name)

    tqdm_pandas(tqdm_gui, total=len(df))
    df.groupby('age').progress_apply(lambda x: x.name)

# Generated at 2022-06-22 04:44:53.063318
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, TqdmTypeError, TqdmDeprecationWarning

    from tqdm._utils import _range
    from ._tqdm import trange
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std
    from .notebook import tqdm as tqdm_notebook

    for tclass in (
            trange, tqdm, tqdm_gui, tqdm_std, tqdm_notebook,
            pd.core.groupby.DataFrameGroupBy):
        tqdm_pandas(tclass)


# Generated at 2022-06-22 04:45:03.455173
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    # Create an example testing DataFrame
    np.random.seed(1234)
    df = pd.DataFrame({'a': np.random.randn(100), 'b': np.random.randn(100),
                       'c': np.arange(100), 'd': np.random.randn(100),
                       'e': np.random.randn(100)})

    tqdm_pandas(tqdm(ascii=True, smoothing=0), group_by_level=False,
                leave=True, unit="step", file=sys.stdout)

    # Test all DataFrame methods that use `progress_apply`
    df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:45:11.433783
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import trange
    global df
    # create a small data frame
    df = pd.DataFrame(
        np.random.randn(100, 2), columns=['a', 'b'])
    for __ in trange(1, 0, 100):
        df.groupby(['a', 'b']).progress_apply(
            lambda x: x**2,
            tqdm_kwargs=dict(unit='total', total=0))
    return df

# Generated at 2022-06-22 04:45:19.767487
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if '-t' in sys.argv:
        from tqdm.auto import tqdm
        from pandas import DataFrame

        # auto
        df = DataFrame({'A': [1, 2, 3], 'B': ['a', 'b', 'c']})
        dfg = df.groupby('A')

        def func(df):
            """
            :param df: groupby df
            :return: dummy output
            """
            assert isinstance(df, DataFrame), df
            return df.sum()

        tclass = tqdm(leave=False)
        tqdm_pandas(tclass)
        dfg.progress_apply(func)
        tqdm_pandas(tqdm)
        dfg.progress_apply(func)

        # manual
        tclass = tq

# Generated at 2022-06-22 04:45:31.064692
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import sys
    import pickle
    import tqdm

    def _tqdm_pandas_show_progress(bar_func, *args, **kwargs):
        """Catch unregistered bars"""
        raise RuntimeError("Please register `tqdm.pandas()` or `tqdm_pandas.tqdm_pandas()`"
                           " with `tqdm_pandas.register_tqdm_pandas()` first!")

    with tqdm.testing.disable_progress_bar():
        tqdm.pandas(postfix=False, unit_scale=True)
        tqdm.pandas()  # automatically detect
        tqdm.pandas(postfix=False)  # don't show postfix

# Generated at 2022-06-22 04:45:41.772241
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import pandas as tqpd
    from tqdm.contrib._test_pandas import test_tqdm_pandas as test_tqpd
    from tqdm.contrib._test_pandas import test_tqpd_tclass
    import pandas as pd

    test_tqpd()
    test_tqpd_tclass()

    if 'tqdm_notebook' in sys.modules:
        test_tqpd_tclass(tqpd.tqdm_notebook)

    try:
        import pandas.core.groupby.GroupBy
    except ImportError:
        pass
    else:
        assert hasattr(pandas.core.groupby.GroupBy, 'progress_apply')

# Generated at 2022-06-22 04:45:52.200565
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    test = pd.DataFrame({'a': [1], 'b': [pd.Timestamp('2012-01-01')]})
    def test_eq(*args, **kwargs):
        return test
    test.groupby = test_eq
    test.groupby.progress_apply = test_eq
    # tqdm(test.groupby.progress_apply(lambda x: x))
    test_eq(tqdm(test.groupby.progress_apply(lambda x: x)))
    tqdm_pandas(tqdm(test.groupby.progress_apply(lambda x: x)))


if __name__ == "__main__":
    from tqdm import tqdm
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:58.405262
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import pandas as pd
    import numpy as np

    try:
        import tqdm

        df = pd.DataFrame(np.random.rand(100000, 20))
        df.progress_apply(lambda x: x + 1)
        df.progress_apply(lambda x: x + 1, axis=1)
    except (ImportError, ModuleNotFoundError):
        pass

# Generated at 2022-06-22 04:46:08.684161
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    import tqdm
    # Use all default values of tqdm
    tqdm.pandas()
    # Generate a simple dataframe
    df = pd.DataFrame({'x': np.random.randint(5, size=100), 'y': np.random.randint(5, size=100)})
    # Do a simple operation
    df['z'] = df['x'] + df['y']
    # Check the progress bar on the screen
    for i in range(10):
        time.sleep(1)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:15.673774
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        assert pandas
    except ImportError:
        # unit-test for function tqdm_pandas only
        return
    from tqdm.contrib.test_tqdm.tqdm_pandas import test_pandas
    test_pandas()


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:26.922003
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, leave=True)
    tqdm_pandas(tqdm, smoothing=0.3)
    tqdm_pandas(tqdm, miniters=200)
    tqdm_pandas(tqdm, file=open('t.log', 'w'))

    # mongodb upgrade pymongo
    #try:
    #    import pymongo
    #except:
    #    pass
    #else:
    #    df = pd.DataFrame(
    #        {'a': [20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 50, 50

# Generated at 2022-06-22 04:46:34.569951
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_pandas

    class tqdm_fake(tqdm):
        class pandas:
            class work:
                class func:
                    def __init__(self, func):
                        func.pandas = True

    # Call the function directly
    tqdm_pandas(tqdm_fake(total=1000))
    assert tqdm_fake.pandas.work.func.pandas

    # Call the function with an instance as first argument
    tqdm_pandas(tqdm_fake(total=1000))
    assert tqdm_fake.pandas.work.func.pandas

    # Call the function with a deprecated adapter

# Generated at 2022-06-22 04:46:45.253661
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        from nose.plugins.skip import SkipTest
        raise SkipTest()

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except:
        from nose.plugins.skip import SkipTest
        raise SkipTest()

    from tqdm import tqdm
    from tqdm.pandas import tqdm_pandas

    tqdm_pandas(tqdm)

    assert hasattr(tqdm, '__enter__')
    assert hasattr(tqdm, '__exit__')
    assert hasattr(tqdm, 'write')
    assert hasattr(tqdm, 'isatty')

    assert hasattr(DataFrameGroupBy, 'progress_apply')  # original func
    pf = DataFrameGroup

# Generated at 2022-06-22 04:46:53.214486
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import time as time
    import pandas as pd
    import numpy as np
    import tqdm

    objs = [tqdm.tqdm, tqdm.tqdm_notebook, tqdm.tqdm_gui]
    kwargs_list = [{}, {'leave': True}, {'mininterval': 0.1}]
    shapes = [(100, 100), (100,), (100,), (100, 100)]
    df_list = [pd.DataFrame(np.random.random(s)) for s in shapes]

    for obj in objs:
        for kwargs_current in kwargs_list:
            time.sleep(1)
            obj(**kwargs_current).pandas(desc="Progress: ")

# Generated at 2022-06-22 04:46:59.510949
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm(total=3))

    df = DataFrame({"A": [0, 1, 2], "B": [1, 2, 3]})
    df.groupby("A").progress_apply(lambda x: x + 1)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:12.863252
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Tests tqdm_pandas function."""
    # Create a dummy DataFrame
    try:
        import pandas
    except:
        return  # pandas not installed
    df = pandas.DataFrame({'a': [1, 2, 3]})
    # Unit testing
    try:
        from io import BytesIO as StringIO
    except ImportError:
        from io import StringIO
    from tqdm.auto import tqdm  # import here for backwards compatibility
    for tclass in (tqdm, tqdm()):
        with StringIO() as buf:
            tqdm_pandas(tclass, file=buf)
            df.groupby('a').progress_apply(lambda x: x)
            assert (len(buf.getvalue()) > 0)


# =====================================================================
# Main

# Generated at 2022-06-22 04:47:17.230693
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    import numpy as np

    df = DataFrame(np.random.rand(100000, 1000))
    df.progress_apply(lambda x: x ** 2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:24.110391
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    s = pd.Series(['apple', 'orange', 'pear', 'banana'])
    s = s.groupby(s.str.get_dummies().cumsum()).progress_apply(lambda x: len(x))
    assert s.equals(pd.Series([1, 1, 1, 1]))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:32.093217
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas, tqdm
    from pandas import DataFrame


    df = DataFrame({
        'id': [1, 2, 3],
        'alpha': ['a', 'b', 'c'],
        'num': [1, 2, 3]
    })

    # Test tqdm
    tqdm_pandas(tqdm)
    df.groupby('alpha').progress_apply(lambda x: x.id.sum())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:39.722091
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        a = tqdm_pandas(tqdm(desc='tqdm_pandas test', unit_scale=True))
        pd.DataFrame({'a': range(3), 'b': range(3)}).groupby('a').progress_apply(
            lambda x: x,
            meta=['c' for i in range(4)])
    except Exception as e:
        print(str(e))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:47.312009
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    df = pandas.DataFrame(
        {'a': [1, 2, 3, 4, 5], 'b': [6, 7, 8, 9, 10],
         'c': [1, 1, 2, 2, 2], 'd': [1, 1, 1, 2, 2]})
    df.groupby(['c', 'd']).progress_apply(lambda x: len(x))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:58.510025
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas  # NOQA
        import numpy as np  # NOQA
        from tqdm.autonotebook import tqdm  # NOQA

        if hasattr(tqdm, "_version"):
            assert LooseVersion("4.35.0") <= LooseVersion(tqdm._version.get_versions()['version']) <= LooseVersion("4.40.1")

        from tqdm import tqdm_gui  # NOQA
        from tqdm import tnrange  # NOQA
        from tqdm import tqdm_notebook  # NOQA
    except ImportError:
        return

    df = pandas.DataFrame({'c1': np.random.randint(0, 100, 1000)})

# Generated at 2022-06-22 04:48:09.635666
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm
    a = pd.DataFrame(np.random.randint(0, 100, (10000, 14)))
    tqdm.pandas(tqdm.tqdm())
    a = a.groupby(0).progress_apply(lambda x: x**2)
    with tqdm.tqdm() as t:
        a = a.groupby(0).progress_apply(lambda x: x**2, desc='Custom tqdm')
    tqdm.pandas()
    with tqdm.tqdm() as t:
        a = a.groupby(0).progress_apply(lambda x: x**2, desc='Custom tqdm')

# Generated at 2022-06-22 04:48:19.902752
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    from tqdm import tqdm

    df = pd.DataFrame({'a': [1, 1, 2, 3]})

    def g(df):
        for i in range(1, 19):
            df.loc[:, 'b'] = df.loc[:, 'a'] + i

    # normal pandas apply
    g(df)

    # applying with tqdm
    tqdm_pandas(tqdm, file=sys.stderr)
    g(df)
    # Test that tqdm_wrapper can be used to create a new instance
    type(tqdm_pandas)(tqdm_pandas.tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:30.659894
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange, tqdm
    from pandas import DataFrame, Series
    from numpy.random import randint, seed

    seed(1)
    df = DataFrame(data=randint(100, size=(100000, 4)), columns=list('ABCD'))
    pd_df = DataFrame(data=randint(100, size=(100000, 4)), columns=list('ABCD'))
    s = Series(data=randint(100, size=(100000,)), name='A')
    pd_s = Series(data=randint(100, size=(100000,)), name='A')

    for _ in trange(3):
        # Test on default pandas DataFrame
        for i in tqdm(df.groupby('A')['B']):
            pass


# Generated at 2022-06-22 04:48:37.549429
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame(data=[[1, 2], [3, 4]])
    tqdm_pandas(pd.core.groupby.DataFrameGroupBy, total=len(df))
    for _ in df.groupby(0).progress_apply(len):
        assert True
    with pytest.raises(SystemExit):
        tqdm_pandas(pd.core.groupby.DataFrameGroupBy)

# Generated at 2022-06-22 04:48:40.947442
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas
    """
    import pandas
    import numpy
    df = pandas.DataFrame(numpy.random.randint(1, 1000, (1000, 2)))
    tqdm = tqdm_pandas(tqdm)
    df.groupby(0).progress_apply(lambda x: x)

# Generated at 2022-06-22 04:48:48.320724
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random
    # We do not import tqdm because we want to test the deprecated version

    for _ in tqdm_pandas(range(2)):
        DataFrame(random.rand(1000, 1000)).groupby(0).progress_apply(lambda x: x)

    with tqdm_pandas(dynamic_ncols=True) as t:
        DataFrame(random.rand(1000, 1000)).groupby(0).progress_apply(lambda x: x)


# Generated at 2022-06-22 04:49:04.692967
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import tqdm
    from ._version import __version__

    df = DataFrame({'a': [1,2,3], 'b': [1,2,3], 'c': [1,2,3], 'd': [1,2,3]})
    df.groupby(['a', 'b']).progress_apply(lambda x: x * x.c)
    df.groupby(['a', 'b']).progress_apply(lambda x: x * x.c)
    assert not hasattr(df.groupby(['a'])['b'], '_tqdm')
    assert df.groupby(['a', 'b'])._tqdm._version == __version__
    assert isinstance

# Generated at 2022-06-22 04:49:10.456936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    df = pandas.DataFrame([numpy.random.randn(100).cumsum() for i in range(100)])

    result = df.progress_apply(lambda x: x)
    assert True  # should not raise errors, for now


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:21.192574
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from contextlib import closing
    import pandas as pd
    import numpy as np
    from tqdm import TqdmDeprecationWarning, tqdm

    # Initialize fake DataFrame
    n_rows = 5
    n_cols = 5
    data = np.random.randn(n_rows, n_cols)
    df = pd.DataFrame(data)
    df.columns = ['c%d' % i for i in range(n_cols)]
    df.index = list('abcd%d' % i for i in range(n_rows))

    # Test tqdm_pandas
    with closing(StringIO()) as our_file, \
            redirect_stdout(our_file):
        with warnings.catch_warnings(record=True) as ign:
            tq

# Generated at 2022-06-22 04:49:31.437364
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    # tqdm_pandas(tqdm())

    # Expected result
    def my_apply(df):
        return 1

    try:
        pd.DataFrame([1, 2]).groupby(0).progress_apply(my_apply)
    except AttributeError:
        pass
    else:
        raise RuntimeError("tqdm_pandas failed to register `tqdm` instance with "
                           "progress_apply!")
    try:
        pd.DataFrame([1, 2]).groupby(0).progress_apply(my_apply)
    except AttributeError:
        pass

# Generated at 2022-06-22 04:49:35.143111
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    seq = list(range(100))
    seq_tqdm = tqdm(seq, bar_format="{l_bar}{bar}{r_bar}")
    seq_tqdm.pandas()



# Generated at 2022-06-22 04:49:46.898255
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest('pandas not installed.')
    try:
        assert not pd.__version__.startswith('0.')
    except AttributeError:
        raise unittest.SkipTest('no pandas <1.')
    import warnings
    import sys

    class _Capturing(list):
        """A class used to capture stdout/stderr"""

        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio  # free up some memory
            sys.std

# Generated at 2022-06-22 04:49:53.876483
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:50:05.067129
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Ensure that the tqdm_pandas function is properly overwritten.

    Issue: #801.
    """
    # Need to import pandas here (for testing only)
    from pandas import DataFrame
    from pandas import date_range

    from tqdm import tqdm_pandas_init, tqdm_pandas_deprecated
    from tqdm._tqdm import TqdmDeprecationWarning

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        tqdm_pandas(tqdm_kwargs={'total': 10}, tclass=None)
    assert len(w) == 1
    assert issubclass(w[-1].category, TqdmDeprecationWarning)


# Generated at 2022-06-22 04:50:13.017257
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .gui import tgrange
    import pandas as pd
    import numpy as np
    from time import sleep

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)), columns=list('ABCDEF'))
    t = tgrange(10)
    df.groupby('A').progress_apply(lambda x: x ** 2)
    sleep(0.01)
    assert t.n == 10
    assert not t.disable


tqdm_pandas.__doc__ = __doc__.split('---')[1].strip()
# Hack to avoid importing tqdm to register it
# But this works much better than using entry points!
tqdm_pandas(object)

# Generated at 2022-06-22 04:50:16.058523
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    test_data = pd.DataFrame(np.random.randn(5, 2))
    with tqdm(total=test_data.shape[0]) as pbar:
        test_data.progress_apply(lambda x: np.sin(x), axis=1,
                                 progress_args=(pbar,))

# Generated at 2022-06-22 04:50:24.345727
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(None)

# Generated at 2022-06-22 04:50:27.293231
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import tests
    assert tests.test_tqdm_pandas(tqdm_pandas)

# Generated at 2022-06-22 04:50:35.790761
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm)

    import pandas as pd
    df = pd.DataFrame(
        {'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9], 'd': [10, 11, 12]},
        index=['first', 'second', 'third'])

    def add_one(x):
        return x + 1

    tqdm.pandas(desc='add_one')
    df.progress_apply(add_one)

    tqdm.pandas(desc='multiply',
                leave=True,
                unit='cells')

# Generated at 2022-06-22 04:50:38.895752
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    assert tqdm_pandas

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:45.943106
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm.auto import tqdm
    with tqdm.pandas(total=1, leave=False, mininterval=0.1) as t:
        pd.DataFrame([1]).reindex(t.n)


if __name__ == '__main__':
    from .auto import main as _main
    _main(__file__)

# Generated at 2022-06-22 04:50:54.852923
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    from pandas import DataFrame
    from pandas.util.testing import makeCustomDataframe as mkdf

    tqdm.pandas()
    # tqdm_pandas(tqdm.tqdm())

    df = DataFrame(dict(a=range(20), b=range(20)))
    for desc, f in [(None, sum), ('hello', sum), ('', sum), ('world', sum)]:
        assert str(df.groupby('a').progress_apply(f, desc=desc)) == \
            str(df.groupby('a').apply(f))

    if hasattr(df, 'multi_iter'):
        df = df.multi_iter()

# Generated at 2022-06-22 04:51:06.061676
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import trange
    pd_series = pd.Series(range(100))

    @tqdm_pandas(trange)
    def progress_len(s):
        return len(s)

    assert progress_len(pd_series) == 100

    with pytest.raises(TypeError, match='Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`'):
        @tqdm_pandas
        def progress_len(s):
            return len(s)


# Generated at 2022-06-22 04:51:14.240920
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas.
    """
    try:
        from pandas import DataFrame
        from numpy.random import randint
    except ImportError:
        return
    from .gui import tqdm
    from time import sleep
    from .utils import format_sizeof

    def compute(x):
        sleep(0.001)
        return x

    # Test basic use with progress_apply
    df = DataFrame(randint(0, 10000, size=(100000, 6)))
    tqdm.pandas(desc="Computing:")
    df.progress_apply(compute)
    # Test basic use with progress_map
    df = DataFrame(randint(0, 10000, size=(100000, 6)))
    tqdm.pandas(desc="Computing:")

# Generated at 2022-06-22 04:51:23.114214
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Simple unit test for `tqdm_pandas`"""
    import numpy as np
    import pandas as pd
    import tqdm
    import warnings

    try:
        pd.Series([1, 2]).progress_apply(lambda x: x)
    except AttributeError:
        warnings.warn(RuntimeWarning(
            "`tqdm_pandas` needs pandas >= 0.16.2 to run tests. Skipping..."))
        return
    tqdm_pandas(tqdm)
    net_speed = pd.Series(np.random.rand(2000)).progress_apply(lambda x: x)
    assert isinstance(net_speed, pd.Series)
    tqdm_pandas(tqdm_pandas)



# Generated at 2022-06-22 04:51:29.846180
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    def my_func(a):
        return a * 2

    df = pd.DataFrame([1, 2, 3, 4], columns=['a'])
    tqdm_pandas(tqdm(total=len(df)))
    out = df.groupby('a').progress_apply(my_func)


# Generated at 2022-06-22 04:51:46.373490
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    from tqdm import tqdm as deprecated_tqdm

    pds = pd.Series(np.arange(5))
    tqdm.pandas(pds.progress_apply)

    dfs1 = pd.DataFrame({'colA': np.arange(10), 'colB': np.arange(10)})
    tqdm.pandas(dfs1.groupby('colB').progress_apply)

    dfs2 = pd.DataFrame({'colA': np.arange(10), 'colB': np.arange(10)})
    tqdm_pandas(tqdm.tqdm, dfs2.groupby('colB').progress_apply)

    d

# Generated at 2022-06-22 04:51:55.200422
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    # Tests:
    import numpy as np
    df = pandas.DataFrame(np.random.randint(0, 100, (100000, 6)))
    # 1. using instance method
    with tqdm_pandas(total=len(df)) as pbar:
        def fn(x):
            return x
        df.groupby(0).progress_apply(fn)
    assert len(pbar) == len(df)
    # 2. using class method
    with tqdm_pandas(total=len(df)) as pbar:
        df.groupby(0).progress_apply(lambda x: x)
    assert len(pbar) == len(df)
    # 3. using delayed adapter
    pbar = tq

# Generated at 2022-06-22 04:52:03.785700
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    from tqdm import tqdm_pandas

    df = pd.DataFrame({'x': range(100000)})
    test_progress = tqdm_pandas(tqdm(total=len(df)))
    test_progress.progress_apply(lambda x: x)
    test_progress.set_description("test_pandas")
    test_progress.close()

    # Make sure that pandas is not loaded on import
    # (or else this test will fail)
    import sys
    assert 'pandas' not in sys.modules

# Generated at 2022-06-22 04:52:14.832997
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:52:17.954868
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm.tqdm_pandas()


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:25.626718
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    try:
        import pandas
    except ImportError:
        return
    def f(x):
        import time
        time.sleep(0.01)
    with tqdm(total=1) as t1:
        tqdm_pandas(t1)
        pandas.DataFrame({'col1': [1, 2, 3, 4], 'col2':[5, 6, 7, 8]}).groupby('col1').progress_apply(f)
    assert t1.n == 1


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:35.669698
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    tqdm_pandas(tqdm.tqdm, unit='bytes')
    tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm, unit='bytes')
    # Testitng all deprecated cases
    tqdm_pandas(tqdm, unit='bytes')
    res = (pd.DataFrame({'foo': [6, 5, 4]})
           .groupby('foo')
           .progress_apply(lambda x: x))
    assert all(res == pd.DataFrame({'foo': [6, 5, 4]}))



# Generated at 2022-06-22 04:52:43.205631
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd

    df = pd.DataFrame({'label': ['a', 'b', 'c'],
                       'value': [1, 2, 3]})

    with tqdm(total=len(df), desc='Pandas progress') as t:
        df.groupby('label').progress_apply(lambda x: x)
        t.update()

    # This also works
    tqdm_pandas(tqdm(), desc='Pandas progress')
    df.groupby('label').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:52:54.315970
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random

    # from tqdm import TqdmExperimentalWarning, TqdmSynchronisationWarning
    # TqdmExperimentalWarning.ignore = True
    # TqdmSynchronisationWarning.ignore = True

    # data
    df = DataFrame(
               data=random.randint(0, 1001, (1000, 6)),
               index=random.randint(0, 2**10 + 1, 1000),
               columns=list('ABCDEF'))

    # test with apply()
    def f(x):
        return x.sum()

    with tqdm() as t:
        df.progress_apply(f, axis=1)
        t.update()

    # test with apply()
    def f(x):
        return x.sum()
