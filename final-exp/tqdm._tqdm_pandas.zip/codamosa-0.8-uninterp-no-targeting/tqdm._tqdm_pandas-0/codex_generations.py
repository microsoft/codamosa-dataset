

# Generated at 2022-06-22 04:42:59.994632
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    with tqdm(total=100) as bar:
        tqdm_pandas(tqdm, total=100)
        assert bar.total == 100, "Total does not match"

# Generated at 2022-06-22 04:43:01.670024
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:11.068495
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, pandas
    from pandas import DataFrame

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(), total=55)
    tqdm_pandas(pandas(total=55))
    DataFrame([1, 2, 3]).progress_apply(lambda i: i)
    DataFrame([1, 2, 3]).progress_apply(lambda i: i)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:22.680505
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas, tqdm
    tqdm_pandas(tqdm_pandas)
    tqdm_pandas(tqdm)
    import pandas
    tqdm_pandas(pandas)
    pd = pandas

    # Successful cases
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, total=100)

    # DeprecationWarnings
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter("always")
        tqdm_pandas(tqdm_pandas)
        tqdm_pandas(tqdm)
        tqdm_pandas(pandas)
    assert len

# Generated at 2022-06-22 04:43:34.430979
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas.
    This function assumes that function `reset_tqdm` works ok.
    """
    try:
        import pandas as pd
    except ImportError:
        return

    def sum_dummy_mul(x, c=2):
        return x.sum() * c

    N = 50000
    df = pd.DataFrame({'a': np.random.randint(100, size=N),
                       'b': np.random.randint(100, size=N),
                       'c': np.random.randint(100, size=N),
                       'd': np.random.randint(100, size=N),
                       'e': np.random.randint(100, size=N)})


# Generated at 2022-06-22 04:43:43.247225
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    # First, just test that pandas bar is shown and works
    df = pd.DataFrame(np.random.randn(100, 100))
    with tqdm.pandas(desc='Desc', leave=False) as t:
        _ = df.progress_apply(lambda x: x.sum())
    assert t.n == df.shape[0]

    # Then check that tqdm arguments are passed correctly
    with tqdm.pandas(desc='Desc', total=df.shape[0], leave=False) as t:
        t.pandas(desc='Desc2', total=df.shape[0], leave=False)
        _ = df.progress_apply(lambda x: x.sum())
    assert t.n == df.shape[0]

# Generated at 2022-06-22 04:43:48.983453
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        pandas
    except (AttributeError, NameError):
        return
    else:
        with tqdm_pandas(total=1) as pbar:
            pandas.Series([1, 2, 3]).progress_apply(lambda _: pbar.update())


# Monkey patching is deprecated
if pandas is not None:
    pandas.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas

# Generated at 2022-06-22 04:44:01.083560
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return
    try:
        import pandas.core.groupby.DataFrameGroupBy
        import pandas.core.frame.DataFrame
    except (ImportError, AttributeError):
        return
    # This program is supposed to return no error.
    # It should be used in the form
    # ```python -c "from tqdm import *; test_tqdm_pandas()"```
    # In Python>=3.1, it should also be possible to use
    # ```python -m tqdm.test_tqdm_pandas```
    # But not in Python<3.1
    import sys
    import warnings

# Generated at 2022-06-22 04:44:09.869207
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas

    def slow_iter():
        import time
        import math
        for _ in range(100):
            yield math.sin(time.time())

    def testfunc(x):
        import math
        return math.cos(x)

    tqdm_pandas(tqdm.tqdm())
    tqdm_pandas(tqdm.tqdm, desc='0')
    tqdm_pandas(tqdm.tqdm, desc='0', leave=False, ascii=False)
    tqdm_pandas(tqdm.tqdm(desc='0', leave=False, ascii=False))


# Generated at 2022-06-22 04:44:17.945221
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Mock tqdm
    class tqdm_mock(object):
        @staticmethod
        def pandas(*args, **kwargs): pass
    # Mock pandas
    from pandas import Series
    class pandas_mock(object):
        @staticmethod
        def Series(data, **kwargs):
            # Check that the given `data` length is the one passing through
            return Series(data)
    # Mock tqdm kwargs
    tqdm_kwargs = {'total': 3, 'desc': 'Test'}
    # Check that tqdm is called with the correct arguments

# Generated at 2022-06-22 04:44:27.608069
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_notebook

    tqdm_pandas(tqdm_notebook())
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x ** 2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:38.316443
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, trange

    def test_tqdm():
        x = range(0, 1000)

        for _ in tqdm(x, total=len(x)):
            y = np.random.rand(100, 100)

    test_tqdm()
    test_tqdm_pandas(tqdm)

    def test_trange():
        x = range(0, 1000)

        for _ in trange(len(x), total=len(x)):
            y = np.random.rand(100, 100)

    test_trange()
    test_tqdm_pandas(trange)


# Generated at 2022-06-22 04:44:48.674373
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import dummy_pandas, tqdm_pandas_0, tqdm_pandas_1, tqdm

    for i in range(2):
        pd = dummy_pandas()

# Generated at 2022-06-22 04:45:00.053825
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import trange
    from time import sleep

    pd.options.mode.chained_assignment = None  # default='warn'

    df = pd.DataFrame(
        data=[["a", 10, 0.1], ["b", 20, 0.2], ["c", 30, 0.3],
              ["d", 40, 0.4], ["e", 30, 0.3], ["f", 20, 0.2],
              ["g", 10, 0.1]],
        columns=["name", "x", "y"])


# Generated at 2022-06-22 04:45:07.216022
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    a = pd.DataFrame([[1, 2], [3, 4]])

    if sys.version_info[0] >= 3:  # py3
        assert tqdm_pandas(lambda i: i, a) == a
        assert tqdm_pandas(tqdm(), a) == a
        assert tqdm_pandas(tqdm(a)) == a
    else:
        assert tqdm_pandas(lambda i: i, a) == a
        assert tqdm_pandas(tqdm(a)) == a
        assert tqdm_pandas(tqdm.tqdm(a)) == a

# Generated at 2022-06-22 04:45:16.373450
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.tests import TqdmDeprecationWarning
    from tqdm._tqdm import TqdmKeyError

    with pytest.raises(TqdmKeyError):
        tqdm_pandas("wrong_tclass")
    with pytest.raises(TqdmKeyError):
        tqdm_pandas(tqdm("wrong_tclass"))

    # Temporary compatibility guard
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(tqdm))


# Generated at 2022-06-22 04:45:23.680143
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm.tqdm_pandas(tqdm.tqdm)
    tqdm.tqdm_pandas(tqdm.tqdm, leave=False)
    tqdm.tqdm_pandas(tqdm.tqdm(leave=False))
    tqdm.tqdm_pandas(tqdm, leave=False)
    tqdm.tqdm_pandas(tqdm_leave=False)


# Decorator for methods of pandas (DataFrame/Series)

# Generated at 2022-06-22 04:45:32.967474
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm
    import time

    @tqdm_pandas(tclass=tqdm)
    def dummy(df):
        time.sleep(0.1)
        return df * 2

    df = pd.DataFrame(np.random.randint(0, 100, (1000000, 2)),
                      columns=['A', 'B'])
    df = dummy(df)
    assert (df > 200).sum().sum() == 0
    assert (df > 0).sum().sum() > 0
    assert (df < 200).sum().sum() > 0

# Generated at 2022-06-22 04:45:41.504131
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        df = pd.DataFrame(dict(a=list(range(10)), b=list(range(10, 20))))
        t = tqdm_pandas(tqdm())
        df = df.groupby("a").progress_apply(lambda x: x)
    except Exception as e:
        raise Exception("The function tqdm_pandas is not working properly:\n{}".format(e))


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:52.166973
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    # Create several DataFrameGroupBy objects
    df = pd.DataFrame({'A': [1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 2, 2],
                       'B': ['a', 'a', 'b', 'b', 'b', 'b', 'a', 'a',
                             'b', 'b', 'a', 'a'],
                       'C': [1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2]})
    groupby_objects = [df.groupby(['A']),
                       df.groupby(['B']),
                       df.groupby(['C']),
                       df.groupby(['A', 'B', 'C'])]

    # Test the

# Generated at 2022-06-22 04:46:05.068371
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    from tqdm import tqdm

    # Convenience function
    def progress_apply(df, *args, **kwargs):
        tqdm_pandas(tqdm(*args, **kwargs))
        return df.progress_apply(*args, **kwargs)

    # Some random data
    df = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=list('ABCDEF'))

    # We run several `progress_apply` calls
    # with different arguments
    df.progress_apply(lambda x: x ** 2)
    df.progress_apply(lambda x: x ** 2, axis=1)
    progress_apply(df, lambda x: x ** 2)
    progress_apply

# Generated at 2022-06-22 04:46:10.358266
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise ImportError(
            "tqdm_pandas requires pandas package to be installed!")
    import tqdm
    import random
    import pandas as pd


    def rand_data(rows, columns):
        return [random.randint(0, 99) for _ in range(rows * columns)]


    def f(x):
        return x * x


    d = pd.DataFrame(rand_data(100, 3), columns=["x", "y", "z"])
    d.groupby('y').progress_apply(f)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:20.021959
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame([1, 2, 3])
    print(df.groupby(['A']).progress_apply(lambda x: x**2))

    with tqdm(total=1,
              postfix=None,
              desc='progress_apply') as t:
        print(df.groupby(['A']).progress_apply(lambda x: x**2,
                                               tqdm=t))

        tqdm_pandas(tqdm,
                    total=1,
                    postfix=None,
                    desc='progress_apply')
        print(df.groupby(['A']).progress_apply(lambda x: x**2))


if __name__ == '__main__':
    test_tqdm_

# Generated at 2022-06-22 04:46:27.252862
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    data = pd.DataFrame({'col': np.random.random(1000)})
    tqdm_pandas(tqdm(), desc='foo')
    assert data.groupby(data.col > .5).progress_apply(len).sum() == 500

# Generated at 2022-06-22 04:46:34.846789
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas."""
    try:
        import pandas
        if pandas.__version__.split('.') < ['0', '25', '0']:
            raise ModuleNotFoundError(
                "tqdm_pandas requires pandas >= 0.25.0. Please update and retry.")
    except ModuleNotFoundError:
        print("pandas not found, skipping test_tqdm_pandas()...")
        return
    from tqdm.auto import tqdm, trange

    test_array = [1, 2, 3, 4, 5, 6]

    def identity(df, **kwargs):  # pragma: no cover
        return df

    # test with decorator

# Generated at 2022-06-22 04:46:43.849681
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    # test wrapped tqdm case
    tqdm.pandas(tclass=tqdm)
    # test progress_apply
    _ = Series(range(10**2)).progress_apply(lambda x: x)
    _ = DataFrame(range(10**2)).progress_apply(lambda x: x)


# Register the default tqdm instance with pandas
tqdm_pandas(tqdm)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:52.257640
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        from tqdm import tqdm, trange
        from functools import partial

        class Tqdm_pandas:
            def __init__(self, tqdm_cls, **tqdm_kwargs):
                self.tqdm_cls = tqdm_cls
                self.tqdm_kwargs = tqdm_kwargs

            def __enter__(self):
                return self

            def __exit__(self, *args):
                pass

            @staticmethod
            def progress_apply(df, *args, **kwargs):
                """
                Override pandas.core.groupby.DataFrameGroupBy.progress_apply to
                add a progress bar.
                """
               

# Generated at 2022-06-22 04:47:01.872942
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm_pandas(tqdm)

    test_df = pd.DataFrame([
        (1, 2),
        (2, 4),
        (3, 6)
    ], columns=['foo', 'bar'])

    def test_func(df):
        return df.foo + df.bar

    res_vanilla = test_df.groupby(by='foo').progress_apply(test_func)
    res_decorated = test_df.groupby(by='foo').progress_apply(test_func)

    assert res_vanilla.equals(res_decorated)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:13.360299
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'col1': np.random.randn(100), 'col2': np.random.randn(100)})
    tqdm.pandas(desc="my bar!")
    df.progress_apply(lambda x: x)
    tqdm.pandas(desc="my bar!", leave=False)
    df.progress_apply(lambda x: x)
    tqdm.pandas(desc="my bar!", leave=False, position=1)
    df.progress_apply(lambda x: x)
    tqdm.pandas(desc="my bar!", leave=True)
    df.progress_apply(lambda x: x)
    tq

# Generated at 2022-06-22 04:47:21.180913
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas

        pandas.DataFrame(range(100), dtype=float).groupby(
            lambda x: x % 10).progress_apply(
            lambda x: x - 0.5)
        print("\nPassed `test_tqdm_pandas` test (pandas not installed)")
    except ImportError:
        print("\nPassed `test_tqdm_pandas` test (pandas not installed)")


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:27.743501
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm_pandas(total=100) as pbar:
        pbar.update(5)
        assert pbar.n == 5

# Generated at 2022-06-22 04:47:38.351842
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    >>> from pandas import DataFrame
    >>> from pandas import Series
    >>> from pandas import concat
    >>> import numpy as np

    >>> test_df = DataFrame(dict(A=Series(np.random.rand(100), name='A'),
    ...             B=Series(np.random.rand(100), name='B')))
    >>> def test(s):
    ...     return [e * 2 for e in s]
    >>> test_df.groupby('A').progress_apply(test)
    >>> test_df.groupby('B').progress_apply(test)
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
    doctest.master.sum

# Generated at 2022-06-22 04:47:48.338559
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    def dummy_func(df):
        """
        Function to apply to pandas' DataFrame
        """
        return df['a'] + df['b']

    t = tqdm(total=1, leave=False)
    df = DataFrame({"a": [1, 2, 3, 4], "b": [2, 3, 4, 5]})
    tqdm_pandas(t)
    res = df.groupby('a').progress_apply(dummy_func)
    assert res.sum() == 27
    t.close()


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-22 04:47:54.293188
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def test_func(x):
        return x

    df = pd.DataFrame({
        'A': np.random.randint(0, 1000, (1000,)),
        'B': np.random.randint(0, 1000, (1000,)),
        'C': np.random.randint(0, 1000, (1000,))
    })

    with tqdm(total=len(df.index) * len(df.columns)) as t:
        # Test method chaining
        df.progress_apply(test_func).agg(sum, axis=0).progress_apply(test_func)
        df.groupby('C').progress_apply(test_func).agg(sum, axis=0).progress_apply(
            test_func)


# Generated at 2022-06-22 04:48:05.771517
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    import pandas as pd
    from tqdm import tqdm_notebook as tqdm

    # Test case - 1
    with warnings.catch_warnings(record=True) as w:
        tqdm_pandas(tqdm)  # init=10)
        # assert len(w) == 1
        # assert issubclass(w[0].category, TqdmDeprecationWarning)
        # assert "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`." in str(w[0].message)

    # Test case - 2
    with warnings.catch_warnings(record=True) as w:
        df = pd.Data

# Generated at 2022-06-22 04:48:17.364369
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        return  # Not running in pandas

    # Test for delayed adapter case
    test_df = DataFrame({'a': [23, 23, 34], 'b': [1, 2, 3]})
    tqdm_pandas(tqdm, desc='test tqdm_pandas')
    res1 = test_df.groupby('a').progress_apply(lambda x: x.sum())
    assert isinstance(res1, DataFrame), "Expected DataFrame, got %s" % (type(res1))

# Generated at 2022-06-22 04:48:24.023527
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas """
    try:
        import pandas as pd
        b = pd.DataFrame({'a': [1, 2, 3, 4, 5], 'b': [5, 4, 3, 2, 1]})
        b.groupby('a').progress_apply(lambda x: x.b.sum())
    except:
        print("requires pandas")
        return
    tqdm_pandas(tqdm(ascii=True, desc='testing function tqdm_pandas'))
    tqdm_pandas(tqdm.tqdm_notebook, ascii=True, desc='testing function tqdm_pandas')

# Generated at 2022-06-22 04:48:31.762167
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    ''' Unit test for function tqdm_pandas '''
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, trange

    df = pd.DataFrame({'x': np.random.randint(0, 5, 10000)})
    count = df.progress_apply(len)
    assert count.equals(df.x.count())

    # Register directly with tqdm
    tqdm_pandas(tqdm)
    count = df.progress_apply(len)
    assert count.equals(df.x.count())

    # Register with a subclassed tqdm instance
    tqdm_pandas(trange)
    count = df.progress_apply(len)
    assert count.equals(df.x.count())

   

# Generated at 2022-06-22 04:48:40.649236
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from numpy.random import RandomState

    from tqdm.auto import tqdm

    from pandas.util.testing import assert_frame_equal

    # Create data
    tqdm_pandas(tqdm)  # deprecated but still works

    prng = RandomState(0)
    df = pd.DataFrame({"col1": prng.randint(0, 10, size=50),
                       "col2": prng.randint(0, 10, size=50),
                       "col3": prng.randint(0, 10, size=50)})

    df_grouped = df.groupby("col1")
    df_grouped_sum = df_grouped.progress_apply(lambda x: x.sum())

    df_

# Generated at 2022-06-22 04:48:43.696637
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test = tqdm_pandas(tqdm(total=1))
    assert test.total == 1

# Generated at 2022-06-22 04:48:51.149281
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    # Test pandas
    pd = tqdm.pandas(desc='foo')
    import pandas as pd

    df = pd.DataFrame(np.random.randn(5, 3), columns=list('abc'))
    df.progress_apply(np.mean)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:59.985234
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    def f(x):
        import time
        time.sleep(0.01)
        return x


# Generated at 2022-06-22 04:49:11.259182
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def func(df):
        import time
        time.sleep(0.001)
        return df

    df = pd.DataFrame({'A': [1, 2, 3, 4, 5],
                       'B': [5, 4, 3, 2, 1]})

    res = df.groupby('A').progress_apply(func)

try:
    from pandas import DataFrame, Series  # noqa
    from pandas.core.groupby import DataFrameGroupBy, SeriesGroupBy  # noqa

    from tqdm._tqdm_pandas import tqdm_pandas, TqdmProgressBar
    from tqdm._tqdm_pandas import tqdm as tqdm_pandas_sub  # noqa
except ImportError:
    pass

# Generated at 2022-06-22 04:49:13.859741
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=100))



# Generated at 2022-06-22 04:49:24.584348
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import tests  # avoid circular imports
    from pandas import DataFrame, Series
    from numpy.random import rand

    def assert_apply_result_equal(df0, df1, group_by, value_func=None,
                                  **apply_kwargs):
        """Evaluates value_func if provided and compares the apply on
        `group_by` to the value_func on df0"""
        if value_func is not None:
            val0 = value_func(df0, **apply_kwargs)
            val1 = df1[group_by].progress_apply(value_func, **apply_kwargs)
            assert_apply_result_equal(df0, df1, group_by, value_func=None)
            tests.assert_equal(val0, val1)

# Generated at 2022-06-22 04:49:34.394179
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas."""
    import numpy as np
    import pandas as pd
    df = pd.DataFrame(np.random.randn(5, 3), columns=list('ABC'))
    tqdm_pandas(tqdm_notebook(), leave=True)
    res = df.groupby('A').progress_apply(lambda x: x ** 2)
    assert res.shape == (5, 3)
    res = df.groupby('A').progress_apply(lambda x: x ** 2, meta=str)
    assert res.shape == (5, 3)
    res = df.groupby('A').progress_apply(lambda x: x ** 2, meta=('col1', 'col2'))
    assert res.shape == (5, 2)

# Generated at 2022-06-22 04:49:45.224941
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm._tqdm_pandas import trange
    from tqdm import tqdm
    from random import random

    df = pd.DataFrame(np.random.rand(100, 100))
    df.progress_apply(lambda x: x.sum())
    tqdm_pandas(tqdm)
    tqdm_pandas(type(tqdm))
    with tqdm(total=0, leave=False) as t:
        df.progress_apply(lambda x: x.sum(), tqdm_kwargs=t)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:49.336607
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return  # not installed: no test to be done
    df = pandas.DataFrame([[1, 2], [3, 4]], columns=['A', 'B'])
    assert df.progress_apply(lambda x: x) is not None

# Generated at 2022-06-22 04:49:53.128060
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm_pandas(tqdm)


# Test module
if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:57.256529
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    assert tqdm == tqdm_pandas(tqdm)



# Generated at 2022-06-22 04:50:12.048688
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import warnings, sys
    from tqdm.auto import tqdm

    try:
        import pandas
    except ImportError:
        warnings.warn("pandas not installed, function tqdm_pandas not tested")
        return

    # First test: `tqdm(n).pandas(...)`
    with warnings.catch_warnings(record=True) as ws:
        tqdm_pandas(tqdm(), total=100)

        assert len(ws) == 1
        assert issubclass(ws[-1].category, TqdmDeprecationWarning)

    # Second test: `tqdm.pandas(...)'

# Generated at 2022-06-22 04:50:19.919933
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    from random import random
    from pandas import DataFrame, concat

    df = concat([DataFrame({'c': [random() for _ in range(10)]}) for _ in range(100)])  # NOQA
    df_tqdm = tqdm_pandas(tqdm)
    df_tqdm.head(10)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:31.782172
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # Assume pandas > 0.24
    # https://pandas.pydata.org/pandas-docs/stable/user_guide/categorical.html#series-and-dataframes-with-categorical-data
    df = pd.DataFrame({
        'id': [1.0, 2.0, 3.0, 4.0],
        'categories': pd.Categorical(list('aabd'), categories=list('abcd')),
    })

    # Test with pandas > 0.24

# Generated at 2022-06-22 04:50:41.798991
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")

        # Trigger a warning.
        tqdm_pandas(tqdm, desc='left', foo='bar', bar='baz')

        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
        assert "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`" in str(w[-1].message)

        # Trigger a warning.
        tqdm_pandas(tqdm(desc='left', foo='bar', bar='baz'))

        assert len(w) == 2

# Generated at 2022-06-22 04:50:51.212897
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    _ = np.random.RandomState(42).uniform(0, 100, 1 << 18)
    df = pd.DataFrame(data=_.reshape(-1, 2)).drop_duplicates()

    def f(df):
        return df.apply(sum,
                        axis=1)  # this should use tqdm_pandas, since it's a call to progress_apply

    assert not hasattr(df.groupby(0).progress_apply(sum), 'pandas')
    tqdm_pandas(tqdm())
    assert hasattr(df.groupby(0).progress_apply(sum), 'pandas')

    # NB: `tqdm.pandas(...)` is equivalent to `@tqdm_pandas

# Generated at 2022-06-22 04:51:02.274995
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm, tqdm_pandas
    max_count = 100
    df = DataFrame({'a': Series([1] * max_count), 'b': Series([2] * max_count)})

    def square(x):
        return x * x

    # check that no error will be raised in case of no file parameter
    tqdm_pandas(tclass=tqdm, total=max_count)
    c = df.progress_apply(square).sum()

    with open('test.txt', 'w+') as f:
        # check that no error will be raised in case of with file parameter
        tqdm_pandas(tclass=tqdm, total=max_count, file=f)
        c = df.progress_

# Generated at 2022-06-22 04:51:11.461422
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test for the `tqdm_pandas` function.
    """
    import numpy as np
    import pandas as pd
    df = pd.DataFrame({'a': [0, 0, 1, 1], 'b': np.random.randint(0, 10, 4)})
    group_by_a = df.groupby('a')
    n_groups = len(df['a'].unique())

    # case 1: tqdm_pandas(tqdm_class, ...)
    def tqdm_class(**tqdm_args):
        """
        Mocked class used for testing.
        """
        nonlocal n_groups
        class TqdmCls(object):
            def __init__(self, total, **tqdm_args):
                nonlocal n

# Generated at 2022-06-22 04:51:22.155356
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import trange, tqdm_gui
    from tqdm._tqdm_gui import tqdm_gui_new_handle
    from tqdm.contrib import DummyTqdmFile

    # test DummyTqdmFile
    with DummyTqdmFile() as outfile:
        for _ in trange(10, desc="testing", file=outfile):
            pass

    # test with pandas
    assert 'pandas' not in tqdm_gui.__dict__
    tqdm_pandas(tqdm_gui, desc="testing pandas")

    assert 'pandas' in tqdm_gui.__dict__
    assert 'pandas' in tqdm_gui_new_handle

# Generated at 2022-06-22 04:51:28.356052
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import Series, DataFrame
        import numpy as np

        df = DataFrame({'col1': Series(np.random.randn(1000)),
                        'col2': Series(np.random.randn(1000))})

        result = df.progress_apply(lambda x: x**2)

        assert result is not None
        assert len(result) == len(df)
    except:
        pass  # dependency not installed


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:38.153141
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import tqdm
    except ImportError:
        pass
    else:
        data = pd.DataFrame({'a': [1, 2, 3, 4],
                             'b': [4, 5, 6, 7],
                             'c': [7, 8, 9, 10]})
        results = data.groupby('a').progress_apply(lambda x: x.sum())
        assert isinstance(results, pd.DataFrame)
        assert (results.columns == ['b', 'c']).all()
        assert (results.index == [1, 2, 3, 4]).all()
        assert (results.a == [4, 14, 24, 34]).all()

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:53.064756
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm(total=100))
    with pytest.raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm, total=100)
    tqdm_pandas(type(tqdm(total=100)))
    tqdm_pandas(type('tqdm_foo', (tqdm, ), {'__doc__': 'fake'}), total=100)
    from tqdm._tqdm import tqdm
    tqdm_pandas(tqdm, total=100)

# Generated at 2022-06-22 04:52:00.440057
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.auto import tnrange, trange, tqdm
    from tqdm.contrib import DummyTqdmFile, DummyTqdmFileObj

    total = 10
    tt = pd.DataFrame(np.ones(total), columns=['num'])
    tqdm.pandas()
    tt['num'] = tt['num'].progress_apply(lambda x: x + 1)
    assert tt['num'].sum() == 2 * total

    tqdm.pandas(tqdm_class=tqdm, desc='pandas')
    tt = pd.DataFrame(np.ones(total), columns=['num'])

# Generated at 2022-06-22 04:52:11.587808
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm
    from tqdm._utils import _term_move_up


# Generated at 2022-06-22 04:52:17.446421
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        df = pd.DataFrame({"x": [1,2,3,4]})
        tqdm_pandas(tqdm(total=df.shape[0]), file=sys.stdout)
        df.groupby("x").progress_apply(lambda x : x)
    except Exception:
        return False
    return True


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:21.741170
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    df = pandas.DataFrame(dict(a=range(10000)))
    df.groupby('a').progress_apply(lambda x: x)


if __name__ == '__main__':
    from tqdm import main
    main()

# Generated at 2022-06-22 04:52:28.123017
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    with tqdm(total=10) as pbar:
        df = pd.DataFrame({'A': [x for x in range(10)]})
        df.groupby(1).parallel_apply(tqdm_pandas(pbar))
        assert (pbar.n == 10)

    with tqdm.__main__.tqdm(total=10) as pbar:
        tqdm_pandas(pbar)
        assert (pbar.n == 10)

    with tqdm(total=10) as pbar:
        df = pd.DataFrame({'A': [x for x in range(10)]})

# Generated at 2022-06-22 04:52:34.115925
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm as tqdm
        import pandas as pd

        tqdm_pandas(tqdm)
        x = pd.DataFrame({'X': [1, 2, 3],
                          'Y': [4, 5, 6],
                          'Z': [7, 8, 9]})
        for _ in x.groupby('X').progress_apply(lambda x: x):
            pass
    except (ImportError, AttributeError):
        pass

# Generated at 2022-06-22 04:52:42.909275
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import sys

    with closing(StringIO()) as our_file:
        tqdm_pandas(tqdm(file=our_file, total=5, leave=False))
        df0 = pd.DataFrame(np.random.randn(5,5))
        df1 = df0.groupby(0).progress_apply(lambda x:x)

    assert not our_file.getvalue()  # no output have been made

    with closing(StringIO()) as our_file:
        tqdm_pandas(tqdm_gui(file=our_file, total=5, leave=False))
        df0 = pd.DataFrame(np.random.randn(5,5))

# Generated at 2022-06-22 04:52:46.231147
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm_notebook(total=100))

# Generated at 2022-06-22 04:52:55.959623
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import time
    import pandas as pd

    df = pd.DataFrame({'a':[1,2,3,4], 'b':[5,6,7,8]})
    tqdm_pandas(df.groupby('a').progress_apply(lambda x: time.sleep(0.01)))
    tqdm_pandas(pd.DataFrame().groupby('').progress_apply(0))
    tqdm_pandas(pd.DataFrame().groupby('').progress_transform(0))
    tqdm_pandas(pd.DataFrame().groupby('').progress_agg(0))
    from tqdm import tqdm as tqdm_type
    tqdm_pandas(tqdm_type)
    TqdmType = tqdm_