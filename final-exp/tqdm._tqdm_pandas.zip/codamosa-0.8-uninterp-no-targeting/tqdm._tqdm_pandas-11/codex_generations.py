

# Generated at 2022-06-22 04:43:14.981289
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from .pandas import trange
    from .pandas import tqdm_pandas

    t = trange(10)
    t.close()
    t = tqdm(range(10))
    t.close()

    df = pd.DataFrame()
    df['a'] = list(range(100))
    df['b'] = list(range(100))
    df['c'] = list(range(100))

    def sum_two_cols(a, b):
        return a + b


# Generated at 2022-06-22 04:43:18.801104
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    return
    tqdm_pandas(pd.core.groupby.DataFrameGroupBy.progress_apply)

# Generated at 2022-06-22 04:43:29.997096
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:43:38.358937
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    def fn(x):
        from time import sleep
        sleep(0.01)
        return x

    a = DataFrame(list(range(100)))
    b = tqdm_pandas(tqdm())
    result = a.groupby(0).progress_apply(fn)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:45.814719
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    tqdm.pandas(desc="my bar!")
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-22 04:43:56.101377
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm._utils import _range
    from tqdm import tqdm
    from tqdm import trange, tnrange

    tqdm.pandas()
    tnrange(1)
    # Initialise a pandas dataframe
    df = pd.DataFrame({'a': _range(10),
                       'b': _range(10, 0, -1)})

    # Register the tqdm instance with pandas
    tqdm_pandas(tqdm(total=len(df), leave=False))

    # Apply a function to dataframe
    df['c'] = df[['a', 'b']].progress_apply(sum, axis=1)

    # Verify that progress_apply was registered

# Generated at 2022-06-22 04:44:02.506448
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.arange(10), columns=['A'])
    tqdm_pandas(tqdm(), desc='')(df.groupby('A')['A'].apply)(lambda x: x)

# Generated at 2022-06-22 04:44:07.347244
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for `tqdm.tqdm_pandas`.
    """
    from tqdm.pandas import tqdm_pandas
    import pandas as pd
    import numpy as np

    df = pd.DataFrame([1, 2, 3, 4, 5])
    results = df.groupby(df[0] % 2).progress_apply(
        lambda x: tqdm_pandas(x))
    np.testing.assert_array_equal(results, df)


# Generated at 2022-06-22 04:44:16.849695
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    pd.DataFrame.from_dict({'A': [1, 2, 3], 'B': [4, 5, 6]}).groupby('A').progress_apply(
        lambda x: x ** 2)
    pd.DataFrame.from_dict({'A': [1, 2, 3], 'B': [4, 5, 6]}).groupby('A').progress_apply(
        lambda x: x ** 2, tqdm_kwargs={})
    pd.DataFrame.from_dict({'A': [1, 2, 3], 'B': [4, 5, 6]}).groupby('A').progress_apply(
        lambda x: x ** 2, tqdm_kwargs={'total': 100, 'desc': 'Pow'})


# Generated at 2022-06-22 04:44:28.964335
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm.auto import tqdm
    from tqdm._tqdm import TqdmTypeError
    from ._tqdm_pandas import TqdmExperimentalWarning

    try:
        with tqdm(range(1), leave=True, ascii=True) as t:
            pass  # just for py3.6 compatibility (not necessary for 3.7+)
    except TqdmTypeError:
        pass
    else:
        raise ValueError('cannot continue w/o proper tqdm error handling')

    assert DataFrame({'A': range(1000)}).groupby('A').progress_apply(lambda x: x) is None
    tqdm_pandas(tqdm(ascii=True, leave=True))

# Generated at 2022-06-22 04:44:42.710617
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame
    from tqdm.pandas import tqdm_notebook
    df = DataFrame({'A': [0, 1, 2, 3, 4],
                    'B': [5, 6, 7, 8, 9],
                    'C': ['a', 'b', 'c--', 'd', 'e']})
    assert type(
        df.groupby('A').progress_apply(len)
    ).__name__ == type(
        df.groupby('A').apply(len)
    ).__name__ == "DataFrameGroupBy"

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:54.143464
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    "this is to test the tqdm_pandas function"
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm.pandas(desc="my bar!")
    # Register `pandas.progress_apply` and `pandas.Series.map_apply` with `tqdm`
    # (can use `tqdm_gui`, `tqdm_notebook`, optional kwargs, etc.)
    res = df.progress_apply(lambda x: x**2)

    # Test without `tqdm` (normal `apply`):
    res_without_tqdm = df.apply(lambda x: x**2)
   

# Generated at 2022-06-22 04:45:04.108803
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        import pandas
        import numpy
    except ImportError:
        print("\n pandas/numpy not installed.  Skipping test_tqdm_pandas.\n")
        return

    # Dummy pandas progress_apply function
    def progress_apply(self, func, *args, **kwargs):
        for _ in range(self.n):
            func(*args, **kwargs)

    # Dummy pandas DataFrameGroupBy class
    class DataFrameGroupBy(object):
        def __init__(self, n):
            self.n = n
            self.progress_apply = progress_apply

    # Dummy tqdm class

# Generated at 2022-06-22 04:45:12.153183
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        tclass = tqdm_pandas(tqdm, total=100)
        n = len(pd.DataFrame({'x': range(100)}).groupby('x').last())
        pd.DataFrame({'x': range(n)}).groupby('x').progress_apply(lambda x: None)
    except ImportError:
        pass


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:16.063267
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from tqdm.autonotebook import tqdm
    except ImportError:
        return

    df = pd.DataFrame({'x': [1, 2, 3]})
    df.progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:20.438711
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from time import sleep
    from pandas import DataFrame
    from numpy.random import randint

    df = DataFrame(randint(5, size=(5, 3)), columns='A B C'.split())

    def fun(x):
        sleep(1)
        return x * 2

    tqdm_pandas(df.groupby('A').progress_apply(fun))

# Generated at 2022-06-22 04:45:31.711625
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib.concurrent import process_map
    from tqdm import tqdm as tqdm_module

    # -- test multiprocessing
    def inc(x):
        return x + 1

    def tqdm_mp_wrap(tqdm_cls, *tqdm_args, **tqdm_kwargs):
        return tqdm_cls(*tqdm_args, **tqdm_kwargs, file=sys.stdout)

    df = pd.DataFrame(np.random.randn(10, 5))
    df1 = df.progress_apply(inc, axis=1, progress_kwargs=dict(tqdm_class=tqdm_mp_wrap))

    # -- test single process


# Generated at 2022-06-22 04:45:42.280554
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm import tqdm, tqdm_notebook, tnrange
    from numpy.random import randint
    from time import sleep

    df = pd.DataFrame(randint(1, 100, (100000, 6)), columns=list('ABCDEF'))

    tqdm_pandas(tqdm, desc="my bar!")
    res = df.groupby('A').progress_apply(lambda x: x**2)

    tqdm_pandas(tnrange, unit="blah", desc="my bar!")
    res = df.groupby('A').progress_apply(lambda x: x**2)


# Generated at 2022-06-22 04:45:51.674486
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import random
    from tqdm import tqdm
    tqdm = tqdm_pandas(tqdm)

    try:
        DataFrame(random.random((100, 100))).progress_apply(
            lambda x: x + 1, axis=0)
    except Exception:  # pragma: no cover
        print('tqdm.pandas(tqdm) not working')
        raise
    try:
        DataFrame(random.random((100, 100))).progress_apply(
            lambda x: x + 1, axis=0)
    except Exception:  # pragma: no cover
        print('tqdm_pandas(tqdm) not working')
        raise

# Generated at 2022-06-22 04:46:02.914984
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from unittest import TestCase

    from tqdm import TqdmDeprecationWarning

    try:
        from collections.abc import Callable
    except ImportError:
        from collections import Callable

    class StubTqdm(object):
        fp = object()
        __name__ = 'StubTqdm'

        @staticmethod
        def pandas(*args, **kwargs):
            pass

    class DeprecatedT(object):
        @staticmethod
        def pandas(*args, **kwargs):
            pass
        fp = object()
        __name__ = 'tqdm_notebook'

    class TestTqdmPandas(TestCase):
        def test_tqdm_class(self):
            with self.assertWarns(TqdmDeprecationWarning):
                tqdm_p

# Generated at 2022-06-22 04:46:17.790586
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Requires pandas
    try:
        import pandas as pd
    except ImportError:
        warnings.warn("Test skipped: pandas not found")
        return

    # For testing, we need to be able to construct class instances without
    # actually registering them with TqdmTypeError. We use a helper function
    # that allows to set up a class while also using it as a decorator:
    # https://stackoverflow.com/questions/308999/what-does-functools-wraps-do#309003
    class Register(object):
        def __init__(self, cls):
            self._class = cls

        def __call__(self, *args, **kwargs):
            return self._class

        def __getattr__(self, item):
            return getattr(self._class, item)



# Generated at 2022-06-22 04:46:28.316674
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from tqdm import tqdm_pandas

    x = tqdm(total=10)
    tqdm_pandas(x)

    df = DataFrame({'a': [1, 2, 3] * 1000, 'b': [10, 20] * 1000})

    print(df.groupby('a').progress_apply(lambda x: x.sum()))
    df.groupby('a').progress_apply(lambda x: x.sum())

    tqdm_pandas(tqdm())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:39.127668
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import Series
    from pandas import concat
    from pandas import date_range
    from pandas.util.testing import rands
    from pandas.util.testing import assert_series_equal
    from pandas_tqdm.tqdm_pandas import tqdm
    from datetime import timedelta

    def random_dates(start, delta):
        end = start + delta
        dt = start + delta * np.random.rand(100)
        return Series(dt)

    def random_strings(length):
        return Series([rands(np.random.randint(1, length + 1))
                       for _ in range(100)])

    def assert_df(a, b):
        assert_series_equal(a.dtypes, b.dtypes)


# Generated at 2022-06-22 04:46:49.889107
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmTypeError
    from pandas import DataFrame
    from numpy import nan, random

    # Test pandas groups
    df = DataFrame({'a': [1, 2, 3, nan, nan], 'b': random.random(5)})
    for cls in [tqdm, tqdm()]:
        for func in [sum, df.groupby('a').progress_apply]:
            func(cls=cls, leave=False)
            func(cls=cls, leave=True)
            func(cls=cls, total=42, leave=False)
            func(cls=cls, total=42, leave=True)

# Generated at 2022-06-22 04:47:01.437714
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, bar_format='{n}/{total}', ncols=80)

    class my_tqdm:
        @staticmethod
        def pandas(*args, **kwargs):
            print('my_tqdm.pandas', args, kwargs)

    class my_tqdm2:
        def __init__(self, *args, **kwargs):
            print('my_tqdm2.__init__', args, kwargs)

    tqdm_pandas(my_tqdm)
    tqdm_pandas(my_tqdm, total=100)

# Generated at 2022-06-22 04:47:13.241949
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    from tqdm import tqdm
    from tqdm._utils import _term_move_up
    from .gui import tqdm_gui
    from .std import tqdm
    from .std import TqdmTypeError, TqdmKeyError, TqdmDeprecationWarning
    from ._utils import _range

    try:
        pd.core.groupby.DataFrameGroupBy.progress_apply
    except AttributeError:
        return

    tqdm_pandas(tqdm_gui)
    assert pd.core.groupby.DataFrameGroupBy.progress_apply.im_self is tqdm_gui

    # Test with tqdm instance

# Generated at 2022-06-22 04:47:23.955729
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    data = np.random.uniform(0, 1, (10 ** 6, 10))
    data = pd.DataFrame(data)
    assert not hasattr(data, 'progress_apply')

    try:
        import tqdm
        tqdm.tqdm_pandas(data)
        assert hasattr(data, 'progress_apply')
    finally:
        del sys.modules['tqdm']

    try:
        from tqdm.contrib import pandas
        pandas.tqdm_pandas(tqdm, data)
        assert hasattr(data, 'progress_apply')
    finally:
        del sys.modules['tqdm']


del tqdm_pandas

# Generated at 2022-06-22 04:47:35.316651
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm.autonotebook import tqdm

    # test `tqdm.pandas(...)`
    pbar = tqdm.pandas(custom_len=lambda _: 10)
    pbar(range(10))
    assert (pbar.n == 10)  # regression test
    pbar.close()
    assert (pbar.n == 10)  # regression test

    # test `tqdm(...).pandas(...)`
    pbar = tqdm(custom_len=lambda _: 10)
    pbar.pandas(range(10))
    assert (pbar.n == 10)  # regression test
    pbar.close()
    assert (pbar.n == 10)

# Generated at 2022-06-22 04:47:41.165169
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm_pandas, tqdm
    from numpy import random

    df = DataFrame(random.rand(1000000, 6))
    with tqdm(total=len(df)) as pbar:
        df.progress_apply(lambda x: x, axis=1).sum()
        pbar.update()
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm)

# Generated at 2022-06-22 04:47:49.583393
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({'A': range(10), 'B': range(10)})
    df.groupby('A').progress_apply(lambda x: x.sum())
    tqdm.pandas()
    df.groupby('A').progress_apply(lambda x: x.sum())
    tqdm_pandas(tqdm)
    df.groupby('A').progress_apply(lambda x: x.sum())

# Generated at 2022-06-22 04:48:04.648670
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    frame = pd.DataFrame({'name': ['jack', 'james', 'james', 'james', 'jack', 'james',
                                   'james'],
                          'age': [29, 28, 28, 28, 30, 29, 30],
                          'net': [123.5, 120.7, 114.5, 120., 140.5, 150.4, 165.4]})
    import pandas as pd
    from tqdm import tqdm

    def sum_age(g):
        return g['age'].sum()

    # A
    result = frame.groupby(['name']).progress_apply(sum_age)

# Generated at 2022-06-22 04:48:08.561922
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from random import random
    df = DataFrame({"a": [random() for _ in range(10000)]})
    df.groupby("a").filter(lambda g: g["a"].sum() > 0).progress_apply(lambda f: f)

# Generated at 2022-06-22 04:48:17.236091
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        import tqdm
    except ImportError:
        raise SkipTest
    df = pd.DataFrame({'a': list(range(100)), 'b': list(range(100))})

    def f(x):
        return x
    res = tqdm.pandas(tqdm.tqdm_gui(desc=None))(f)(df)

    # Results of progress operations should be the same
    # as not using progress
    assert res.equals(df)

# Generated at 2022-06-22 04:48:19.854610
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas
    tclass = tqdm()
    tqdm_pandas(tclass)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:23.450975
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm.pandas()

# Generated at 2022-06-22 04:48:31.504576
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tnrange
    from pandas.core.groupby import DataFrameGroupBy
    df = pd.DataFrame({'c': [1, 1, 1, 1, 2, 1, 3, 4, 5, 6],
                       'd': [0, 1, 2, 3, 4, 1, 6, 7, 8, 9]})

    for t in [tqdm, tnrange]:
        tqdm_pandas(t)
        with pytest.warns(TqdmDeprecationWarning):
            assert DataFrameGroupBy.progress_apply is t.pandas.__wrapped__

        tqdm_pandas(t())
        assert DataFrameGroupBy.progress_apply is t.__wrapped__


# Generated at 2022-06-22 04:48:40.139566
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd

    df = pd.DataFrame({'a': ['a', 'a', 'a', 'b', 'b', 'b'], 'b': [1, 2, 3] * 2})
    with tqdm(total=len(df), disable=True, position=0) as t:
        # noinspection PyUnusedLocal
        def test_dataframe_groupby_progress_apply(df=df):
            # noinspection PyUnresolvedReferences
            df.groupby('a').progress_apply(lambda x: x)

        tqdm_pandas(t, test_dataframe_groupby_progress_apply)

# Generated at 2022-06-22 04:48:50.360667
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    def test_df(df):
        return df

    class TestTqdm:
        def __init__(self, total=None, **_):
            self.total = total
            self.n = 0

        def update(self, n=1):
            self.n += n

        def __iter__(self):
            return self

        def __next__(self):
            if self.n > self.total:
                raise StopIteration
            self.update()
            return self.n

        def close(self):
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass


# Generated at 2022-06-22 04:49:00.647362
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import numpy as np
    import pandas as pd

    def f(df):
        # simple function to test
        return df.assign(c=df.a * df.b)

    # make a test dataframe
    a = np.random.rand(1000)
    b = np.random.rand(1000)
    df = pd.DataFrame(dict(a=a, b=b))
    df.progress_apply(f)
    tqdm_pandas(tqdm())
    df.progress_apply(f)
    tqdm_pandas(tqdm(unit="lines", leave=True))
    df.progress_apply(f)
    tqdm_pandas(tqdm(desc="test progress_apply"))

# Generated at 2022-06-22 04:49:06.689643
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from tqdm.contrib.concurrent import process_map
    except ImportError:
        process_map = None

    if 'tqdm_gui' in sys.modules:
        sys.modules['tqdm'] = sys.modules['tqdm_gui']

    def f(df):
        import time
        time.sleep(0.1)
        return df.sum()

    df = pd.DataFrame(np.random.random((100, 100)))
    # test basic pandas Bar
    df.progress_apply(f, axis=0)
    # test basic pandas pandas
    df.progress_apply(f, axis=1)
    # test that pandas respects mininterval

# Generated at 2022-06-22 04:49:14.717803
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import tqdm_gui

    @tqdm_pandas
    def test_tqdm_gui_groupby_df_a(g):
        return g.apply(lambda x: x * 3)

    idx = pd.date_range('2016-01-01', '2016-01-05', freq='D')
    df = pd.DataFrame({'x': [1, 2, 3, 4, 5]}, index=idx)
    df_a = test_tqdm_gui_groupby_df_a(df.groupby(pd.Grouper(freq='W')))

# Generated at 2022-06-22 04:49:25.533191
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from random import randint
    import numpy as np
    from tqdm import tqdm
    import time
    import inspect

    df = DataFrame([randint(0, 100) for x in range(10000)],
                   columns=["randint"])

    # Old style
    tqdm_pandas(tqdm, desc="counter")
    df.groupby("randint").progress_apply(lambda x: x)

    # New style
    tqdm_pandas(tqdm(desc="counter", unit="units", total=10000))
    df.groupby("randint").progress_apply(lambda x: x)

    # testing the decorator

# Generated at 2022-06-22 04:49:28.114739
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import trange
    trange(3)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:39.746012
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas import Series

    try:
        from tqdm import tqdm as tqdm_base
    except ImportError:
        return
    tqdm_base.pandas = tqdm_pandas

    with tqdm_base(total=1) as t:
        DataFrame([Series(np.random.random(10)), Series(np.random.random(10))]).groupby(
            0).progress_apply(lambda x: x)
        DataFrame(np.random.random((10, 10)))
        DataFrame(np.random.random((10, 10)))

        prog = tqdm_base("test", total=1)
        prog.pandas()
        DataFrame(np.random.random((10, 10)))
        prog.update()


# Generated at 2022-06-22 04:49:49.415804
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import itertools
    import time
    import sys
    import unittest

    class TqdmDeprecationWarningTests(unittest.TestCase):
        """
        Tests for tqdm.TqdmDeprecationWarning class
        """
        def test_basic(self):
            """
            Basic test
            """
            # from tqdm import TqdmDeprecationWarning
            # message = "test"
            # with self.assertRaises(TqdmDeprecationWarning) as cm:
            #     raise TqdmDeprecationWarning(message)
            #
            # self.assertEqual(str(cm.exception), message)
            assert True


# Generated at 2022-06-22 04:49:55.144912
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm import tqdm
    d = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
    d.groupby('a').progress_apply(lambda x: x)
    print('\nSucceeded initializing pandas progress bar.')
    try:
        tqdm_pandas(tqdm(total=10))
    except Exception:
        tqdm_pandas(tqdm(total=10), file=sys.stdout)
    print('\nSucceeded re-initializing pandas progress bar.')


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_pandas

# Generated at 2022-06-22 04:50:04.679515
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook, trange
    from tqdm import tqdm_gui, tqdm_pandas
    import random
    random.seed(42)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(trange)
    tqdm_pandas(tqdm_gui)
    assert trange is not tqdm_pandas
    assert tqdm_notebook is not tqdm_pandas
    assert tqdm is not tqdm_pandas
    assert tqdm_gui is not tqdm_pandas

# Generated at 2022-06-22 04:50:13.251448
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    df = pd.DataFrame({'test': [1, 2, 3], 'test2': [3, 4, 5]})
    def square(x):
        return x**2
    res = df.groupby('test').progress_apply(square)

    tqdm.tqdm.pandas(desc='my bar!')
    assert tqdm.tqdm.deprecated_default_mininterval == 1
    res2 = df.groupby('test').progress_apply(square)

    tqdm.tqdm.pandas(desc='my bar!', miniters=0)
    assert tqdm.tqdm.deprecated_default_mininterval == 0
    res3 = df.groupby('test').progress_apply(square)

# Generated at 2022-06-22 04:50:22.682560
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:  # pragma: no cover
        return None
    from tqdm import trange

    trange(10).pandas(desc='trange(10)')
    trange(10).pandas(desc='trange(10)')  # no double-registration warning
    trange(10, desc='trange(10)')
    trange(10, desc='trange(10)')
    df = pd.DataFrame({'a': range(1000), 'b': range(1000, 2000)})
    df.groupby('a').progress_apply(len)
    df.groupby('a').progress_apply(len)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:31.968964
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas  # NOQA
    except ImportError:
        from tqdm import TqdmDeprecationWarning
        TqdmDeprecationWarning(
            "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.",
            fp_write=sys.stderr.write)
    else:
        df = pandas.DataFrame([[1, 2, 3, 4],
                               [10, 20, 30, 40]])

        with tqdm(total=1) as progress:
            result = df.groupby(lambda x: x).progress_apply(lambda x: x)

        assert result.equals(df)

# Generated at 2022-06-22 04:50:46.704370
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    # Generate DataFrame
    data = np.random.rand(200, 200)
    df = pd.DataFrame(data)

    # Use tqdm with `progress_apply`
    tqdm_pandas(tqdm)
    df.groupby(np.cumsum(np.random.random(200)) > 0.5).progress_apply(lambda x: x)

# Generated at 2022-06-22 04:50:55.005538
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    test_tqdm = tqdm(range(100))
    test_tqdm_pandas(test_tqdm)

    df = pd.DataFrame([[1, 2], [3, 4], [5, 6]])
    df = df.groupby(0).progress_apply(lambda x: x)
    assert df.to_numpy().sum() == 21

    test_t = tqdm_pandas(tqdm(range(100)))
    test_t.pandas(ncols=80)

    test_t = tqdm_pandas(tqdm(range(100)))
    test_t.pandas(ncols=80)

    df = p

# Generated at 2022-06-22 04:51:05.554991
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_notebook
    with tqdm_notebook() as t:
        t.pandas(total=10)
        df = pd.DataFrame({'A': np.random.randn(10)})
        df = df.groupby(0).progress_apply(lambda x: x)
    with tqdm() as t:
        t.pandas(total=10)
        df = pd.DataFrame({'A': np.random.randn(10)})
        df = df.groupby(0).progress_apply(lambda x: x)


# Use run_before_pandas_apply decorator

# Generated at 2022-06-22 04:51:09.656444
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    with tqdm.tqdm(total=10) as progress_bar:
        progress_bar.pandas(df=pd.DataFrame({"A": [2]*10}), func=lambda i: i+1)

# Generated at 2022-06-22 04:51:21.905878
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm
    tqdm().pandas()

    # Create a DataFrame
    df = pd.DataFrame({
        'Name': ['Braund', 'Cummings', 'Heikkinen', 'Allen'],
        'Age': [22, 38, 26, 35],
        'Fare': [7.25, 71.83, 7.85, 8.05],
        'Survived?': [False, True, True, False]
    })
    assert df.progress_apply(lambda x: x).equals(df)
    assert df.progress_apply(lambda x: x, axis=1).equals(df)


if __name__ == '__main__':
    test_tqdm_pandas()

# import

# Generated at 2022-06-22 04:51:29.937837
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.contrib import pandas
    from tqdm.contrib import rnumba
    from tqdm.contrib.test_tqdm_pandas import core, groupby, rnumba_test_func
    from tqdm import trange

    # Test pandas
    # =====================================================================

    class test_tqdm():
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.n = kwargs['total']
            self.last_print_n = 0
            self.fp = open('test_tqdm.log', 'w')
            self.fp.write('initing...')

        def update(self, n):
            self.last_print_n = n


# Generated at 2022-06-22 04:51:38.577454
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    df = tqdm.tqdm(pd.DataFrame({'foo': range(100), 'bar': range(100)}),
                   total=100, file=sys.stdout, mininterval=0.01)
    print(df)

    df = tqdm.tqdm(pd.DataFrame({'foo': range(100), 'bar': range(100)}),
                   total=100, file=sys.stdout, mininterval=0.01)
    print(df.bar)

    df = tqdm.tqdm(pd.DataFrame({'foo': range(100), 'bar': range(100)}),
                   total=100, file=sys.stdout, mininterval=0.01)
    print(df.bar.values)


# Generated at 2022-06-22 04:51:46.591274
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas as pd
    import numpy as np
    import pandas.core.groupby
    import sys

    with tqdm(total=3, file=sys.stdout) as t:
        tqdm_pandas(t)
        df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 4)),
                          columns=list('ABCD'))
        df.groupby('A').progress_apply(lambda x: x)
        t.update()
        df.groupby(['A', 'B']).progress_apply(lambda x: x)
        t.update()
        df.progress_apply(lambda x: x)
        t.update()
    assert t.n == 3
    assert t

# Generated at 2022-06-22 04:51:53.714554
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmTypeError
    import pandas as pd
    try:
        tqdm_pandas(tqdm(total=100))
    except TqdmTypeError:
        pass
    # Test Pandas DataFrameGroupBy
    df = pd.DataFrame({'a': [1, 2, 3], 'b': [2, 3, 4]})
    with tqdm(total=len(df)) as t:
        def pause_pandas(_df):
            t.update()
            return True
        df.progress_apply(pause_pandas)

# Generated at 2022-06-22 04:52:03.470372
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas, tqdm, trange


# Generated at 2022-06-22 04:52:21.152047
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests that the decorator colors in the terminal and that the `progress_apply`
    method is called
    """
    import pandas as pd
    import tqdm
    from tqdm import trange
    from sys import stdout

    # Make a fake pandas dataframe
    class PandasFake(object):
        def __init__(self):
            self.i = pd.DataFrame([1, 2, 3])
            self.i.index.name = 'index'

        def __getattr__(self, name):
            if name == 'progress_apply':
                # Fake `progress_apply` function
                def f(self, func):
                    for i in trange(5):
                        pass
                return f
            else:
                raise AttributeError()


# Generated at 2022-06-22 04:52:29.419598
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    bar = tqdm(total=100)
    # "old" syntax
    tqdm_pandas(bar)
    # "new" syntax
    tqdm.pandas(bar)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:37.364459
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import fail_on_exception
    fail_on_exception.enable()

    from pandas import DataFrame
    from pandas import Series
    import numpy as np
    grouped = DataFrame(np.random.randn(100, 100)).groupby(np.random.randint(10, size=100))
    grouped.progress_apply(lambda x: x * x)
    grouped.progress_apply(lambda x: x + x)

    grouped = DataFrame(np.random.randint(100, size=(100, 100))).groupby(np.random.randint(10, size=100))
    grouped.progress_apply(lambda x: x * x)
    grouped.progress_apply(lambda x: x + x)

    grouped = DataFrame({'a': np.random.randint(100, size=100)}).group

# Generated at 2022-06-22 04:52:45.873788
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas as tqdm
    import pandas as pd
    import numpy as np
    from pandas import DataFrame, Series
    from numpy.random import rand
    from os.path import join

    try:
        from pandas import read_csv
    except ImportError:
        return

    # unit tests adapted and modified from the pandas project
    # (https://github.com/pandas-dev/pandas)
    # and modified for tqdm
    try:
        from pandas.tools.merge import concat
    except ImportError:
        from pandas import concat
    try:
        from pandas.tools.tile import cut
    except ImportError:
        from pandas import cut


# Generated at 2022-06-22 04:52:55.710687
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas
    import tqdm

    def assert_equal(a, b):
        assert a == b, '%r != %r' % (a, b)

    t = tqdm.tqdm(pandas.DataFrame({'a': ['test'] * 5}))
    assert_equal(t.__class__.__name__, 'tqdm_pandas')
    # t.__class__ => <class 'tqdm.tqdm_pandas'>
    t = tqdm.tqdm(pandas.DataFrame({'a': ['test'] * 5}),
                  total=len(pandas.DataFrame({'a': ['test'] * 5})))

# Generated at 2022-06-22 04:53:03.377963
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm_pandas
    tqdm_pandas(lambda x: x + 1)
    assert pd.Series(list(range(5))).progress_apply(lambda x: x + 1).sum() == 25

# if __name__ == '__main__':
#     from pandas import DataFrame
#     from numpy import random
#     from tqdm import trange

#     for n in trange(5):
#         n_lines = 10**6
#         n_fields = 40

#         df = DataFrame(random.random((n_lines, n_fields)))
#         df.progress_apply(lambda x: x + 1)
#         df.progress_apply(lambda x: x + 1, axis=1)
#         df