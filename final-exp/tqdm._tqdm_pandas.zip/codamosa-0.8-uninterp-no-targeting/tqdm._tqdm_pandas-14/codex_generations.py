

# Generated at 2022-06-22 04:43:05.838363
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:14.533336
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange
    from tqdm.contrib import pandas
    for _ in tnrange(1000):
        try:
            tqdm_pandas(tnrange(1000),
                        ascii=True,
                        file=sys.stdout,
                        desc="Msg")
            tqdm_pandas(pandas)
            tqdm_pandas(pandas, ascii=True)
            tqdm_pandas(pandas, ascii=True, desc="Msg")
        except BaseException:
            pass

# Generated at 2022-06-22 04:43:26.604730
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    df = pd.DataFrame({'col': [1, 2, 3]})

    # Function application
    res = df.groupby('col').progress_apply(lambda x: x * 2)
    assert df.equals(res)

    # Aggregate
    res = df.groupby('col').progress_agg(pd.Series.nunique)
    assert df.equals(res)

    # Transform
    res = df.groupby('col').progress_transform(lambda x: x * 2)
    assert df.equals(res)

    # Sorting
    res = df.groupby('col', sort=False).progress_apply(lambda x: x * 2)
    assert df.equals(res)

    # Sorting

# Generated at 2022-06-22 04:43:38.628798
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import pandas as pd
    from tqdm import tqdm

    if os.name == 'nt':
        from ctypes import windll, create_unicode_buffer
        buf = create_unicode_buffer(512)
        cch = windll.kernel32.GetConsoleTitleW(buf, len(buf))
    else:
        cch = None

    def get_title():
        if cch is None:
            return None
        if os.name == 'nt':
            return buf.value
        return None

    def set_title(title):
        if cch is None:
            return
        if os.name == 'nt':
            windll.kernel32.SetConsoleTitleW(title)
        else:
            return

# Generated at 2022-06-22 04:43:50.960283
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests for tqdm_pandas
    """
    import pandas
    from pandas.core.groupby import DataFrameGroupBy

    test_str = "test"

    # Test function `groupby.progress_apply` exists
    assert DataFrameGroupBy.progress_apply is not None

    # Test deprecation warning
    prev_stderr = sys.stderr
    sys.stderr = None
    try:
        tqdm_pandas(test_str)
    finally:
        sys.stderr = prev_stderr
    assert sys.stderr.getvalue() == test_str + '\n'

    # Test function `tqdm.pandas`
    import tqdm


# Generated at 2022-06-22 04:44:03.222981
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm_pandas
    from tqdm.tests import tests
    from pandas import read_csv

    tests.reset_counters()

    # For coverage
    tqdm_pandas(tqdm_pandas)

    assert tests.counters['proxy'] == 1
    with tests.mock_std_out() as (_, err):
        with tests.trap_std_err():
            tqdm_pandas(enumerate(
                ['A', 'b', 'c', 'd']), unit='bytes', total=10, miniters=1)
    assert err.getvalue().count("DeprecationWarning") == 1

    assert len(tests.flags['leave']) == 1
    assert tests.flags['leave'][0] is True

   

# Generated at 2022-06-22 04:44:08.197426
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        tqdm_pandas(tqdm)
        # can't test tqdm_notebook (due to IPython dependency)
    except ImportError:
        warnings.warn("pandas not found", ImportWarning)

# Generated at 2022-06-22 04:44:17.170403
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Example: `tqdm.pandas(tqdm(total=df.groupby('B').size().sum()))`
    """
    import pandas
    from tqdm import tqdm

    df = pandas.DataFrame(
        [(a, b, a * b) for a in range(1, 11) for b in range(1, 11)],
        columns=['A', 'B', 'C'])

    def mapper(x):
        return x + x

    df['x'] = df.groupby('B')['A']\
        .progress_apply(mapper)
    tqdm_pandas(tqdm(total=df.groupby('B').size().sum()))

# Generated at 2022-06-22 04:44:26.721140
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        import pandas as pd
        import numpy as np
        import tqdm
    except ImportError:
        return
    df = pd.DataFrame(np.random.random((100, 3)))

    with tqdm.tqdm(desc="test") as t:
        def test(x):
            t.update()

        tqdm.pandas(t, desc="test")
        df.progress_apply(test)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:31.230111
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import random

    # Create a pandas dataframe
    df = pd.DataFrame({'a': range(10),'b': range(10),'c': range(10),'d': range(10)})

    # Pass the dataframe to the funtion to be used
    df.groupby('a').progress_apply(lambda x: sum(x))

# Generated at 2022-06-22 04:44:40.817811
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    cols = [
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
    ]
    df = DataFrame({col: [1, 2] for col in cols})
    tqdm_pandas(tqdm(total=len(df)*5), desc='test')(
        lambda x: x**2).progress_apply(df)

# Generated at 2022-06-22 04:44:50.369452
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:44:55.863142
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    t = tqdm_pandas(tqdm(total=100))
    t.register_instance()
    try:
        for i in range(100):
            randint(0, 100)
    except Exception as e:
        raise e
    finally:
        t.close()

# Generated at 2022-06-22 04:45:03.490153
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    df = pd.DataFrame({'a': np.random.randint(0, 100, size=(100,))})
    tqdm_pandas(tqdm, leave=True)
    for _, group in tqdm(df.groupby('a')):
        for _ in group.a:
            pass


if __name__ == '__main__':
    from tqdm import tqdm
    tqdm_pandas(tqdm, leave=True)

# Generated at 2022-06-22 04:45:12.077750
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
    except ImportError:
        return
    try:
        from tqdm.auto import tqdm
    except ImportError:
        return
    from .tqdm_pandas import tqdm_pandas
    tqdm_pandas(tqdm)
    data = DataFrame([1, 2, 3], columns=['test'])
    # note: `on=None` is not allowed in python-tqdm
    data.groupby(data.test).progress_apply(lambda x: x * 2)

# Generated at 2022-06-22 04:45:20.521229
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd

    df = pd.DataFrame(['a', 'b', 'c', 'd', 'e', 'f'], columns=['letters'])

    def square(x):
        import time
        time.sleep(.2)
        return x ** 2

    tqdm.pandas(tqdm)
    df['letter_squared'] = df['letters'].progress_apply(square)

    tqdm_pandas(tqdm)
    df['letter_squared'] = df['letters'].progress_apply(square)

    tqdm_pandas(tqdm(leave=False))
    df['letter_squared'] = df['letters'].progress_apply(square)


# Generated at 2022-06-22 04:45:30.806439
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, TqdmDeprecationWarning

    with tqdm(total=10, leave=False) as t:
        # Register tqdm into pandas
        tqdm_pandas(t)

        # Test
        df = pd.DataFrame(range(99), columns=['x'])
        df = df.groupby(df['x'] % 10)['x'].progress_apply(lambda x: x ** 2)

        assert t.total == 10
        assert isinstance(type(t), TqdmDeprecationWarning)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:41.572713
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return  # pandas not installed

    # Instantiation test
    try:
        tqdm_pandas(tqdm)
    except Exception as e:
        tqdm_pandas(tqdm)  # delayed adapter case
        tqdm_pandas(tqdm())

    # Pandas test
    try:
        pd.options.display.max_rows = 1000
        from numpy.random import randint

        df = pd.DataFrame(randint(0, 100, (100000, 6)))
        df.progress_apply(lambda x: x**2)
    except Exception as e:
        raise e
    finally:
        pd.options.display.max_rows = 60

# Generated at 2022-06-22 04:45:52.167290
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    # Make up some test data for pandas
    data = {'a': (2, 3, 1, 1, 2),
            'b': ('B', 'B', 'A', 'C', 'B')}
    df = pd.DataFrame(data)
    # Apply function to each group of data in the DataFrame
    # with tqdm printing out the progress
    for _ in tqdm_pandas(tqdm(range(1000)), desc="testing tqdm_pandas"):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # Shuffle the dataframe each loop
            df = df.sample(frac=1)
            df.groupby('b').progress_apply(lambda x: x.a.sum())



# Generated at 2022-06-22 04:46:00.629314
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # DataFrame
    df = pd.DataFrame({'vals': range(100)})
    assert len([i for i in tqdm_pandas(df.groupby('vals').progress_apply(lambda x: x))]) == 100

    # SeriesGroupBy
    df = pd.DataFrame({'vals': range(100)})
    assert len([i for i in tqdm_pandas(df.groupby('vals').progress_apply(lambda x: x))]) == 100

# Generated at 2022-06-22 04:46:09.776483
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm.pandas(desc='test')
    tqdm_pandas(tqdm, desc='test')

    import pandas as pd
    iris = pd.read_csv('https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv')
    print(iris.groupby('species').progress_apply(lambda x: x.describe()))
    print(iris.groupby('species').progress_apply(lambda x: x.describe()))


# Generated at 2022-06-22 04:46:19.559408
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    #    tqdm._main(['__main__', '--unit_test'])  # for `pip install`
    #    tqdm.main(['__main__', '--unit_test'])  # for `python setup.py test`
    #    tqdm.main(['__main__', '--unit_test', '--verbose'])

    # test tqdm_pandas()
    tqdm_pandas(tqdm, desc='Test0')
    tqdm_pandas(tqdm(desc='Test1'))
    tqdm_pandas(tqdm.tqdm, desc='Test2')
    tqdm_pandas(tqdm.tqdm(desc='Test3'))
    t

# Generated at 2022-06-22 04:46:29.056338
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    pandas = __import__('pandas')
    if not hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply'):
        return  # Old version of pandas

    tqdm_pandas(tqdm)

    pandas.DataFrame([[1, 1], [2, 2], [3, 3]]).groupby(1).progress_apply(
        lambda x: x)


if __name__ == '__main__':
    from tqdm import tqdm
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:37.703940
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import pandas.core.groupby
    import tqdm


# Generated at 2022-06-22 04:46:42.092585
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    hist = pd.DataFrame()
    tqdm_pandas(tqdm)
    hist = hist.groupby('date').progress_apply(lambda x: np.random.randint(10))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:48.249462
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        df = pd.DataFrame({'a': [1, 2, 3, 4, 5], 'b': [1, 1, 1, 1, 1],
                           'c': 'hello'})
        g = df.groupby('b')
        tqdm_pandas(g.progress_apply, lambda x: x)
    except ImportError:
        return


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:51.764847
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm

    with tqdm(total=None) as pbar:
        tqdm_pandas(pbar)
        DataFrame({'col1': [1, 2, 3]}).groupby('col1').progress_apply(lambda x: x * 2)
        assert pbar.n == 3

# Generated at 2022-06-22 04:47:02.095251
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas.
    """
    import pandas as pd
    import numpy as np

    from tqdm.auto import trange
    from tqdm.contrib import tenumerate

    n = 1000000
    for tclass in [trange, tenumerate]:
        for pandas_func in ['progress_map', 'progress_apply']:
            for progress in [True, False]:
                for i in tclass(range(20)):
                    f = pd.DataFrame({'x': np.random.random(n)})
                    if progress:
                        f.groupby('x').progress_apply(lambda x: x)
                        tqdm_pandas(tclass)
                        f.groupby('x').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:47:12.730885
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def func(x):
        a = np.empty(100)
        a.fill(x)
        return a

    df = pd.DataFrame({'col_1': np.arange(100), 'col_2': np.arange(100)})
    with tqdm_module.tqdm_pandas(leave=False) as t:
        a = df.groupby(['col_1']).progress_apply(func)
        for _ in t(range(10)):
            pass

if __name__ == '__main__':
    from tqdm import tqdm as tqdm_module
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:22.403174
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm.std import tqdm
    import pandas as pd

    df = pd.read_csv('../example.csv')
    df_test = DataFrame.copy(df)

    # if not registed:
    _apply = DataFrameGroupBy.progress_apply
    df_test.groupby('id_1').progress_apply(lambda x: x ** 2)
    assert (_apply != DataFrameGroupBy.progress_apply)

    # call tqdm_pandas with delayed adapter
    tqdm.pandas(**{'miniters': 1})



# Generated at 2022-06-22 04:47:36.675281
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    for t in tqdm, trange, tgrange:
        tqdm_pandas(t)
        assert _deprecated_pandas == t.pandas
        assert _deprecated_pandas_groupby == pandas.core.groupby.DataFrameGroupBy.progress_apply
        _deprecated_pandas = _deprecated_pandas_groupby = None

    # Test adapter conversion
    tqdm_pandas(tqdm, **{'ncols': 80})
    assert tqdm.__dict__["ncols"] == 80
    tqdm.__dict__.pop("ncols")
    assert "ncols" not in tqdm.__dict__


if __name__ == '__main__':
    test_tqdm_

# Generated at 2022-06-22 04:47:47.689571
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from time import sleep
    from tqdm import tqdm, TqdmTypeError

    pbar = tqdm()
    tqdm_pandas(pbar)
    df = pandas.DataFrame()
    df['a'] = list(range(100))
    assert isinstance(df.groupby('a').a.progress_apply(sleep), pandas.core.groupby.SeriesGroupBy)
    pbar.close()

    try:
        tqdm_pandas()
    except TypeError:
        pass
    else:
        raise Exception('Failed TypeError check')

    try:
        tqdm_pandas("tqdm")
    except TypeError:
        pass
    else:
        raise Exception('Failed TypeError check')

# Generated at 2022-06-22 04:47:58.900392
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import os
    import sys
    import warnings
    import pandas
    from tqdm import tqdm as tqdm_base
    import pandas

    # Regression test for issue #86
    # Check that isinstance(tqdm, type) is True in the current context
    assert isinstance(tqdm_base, type)
    try:
        from tqdm.pandas import tqdm as tqdm_pandas_orig
        from tqdm.contrib.pandas import tqdm as tqdm_pandas_backcompat
    except ImportError:  # pragma: no cover
        return

    def _check_tqdm(tqdm):
        assert hasattr(pandas.core.groupby.DataFrameGroupBy, 'progress_apply')

# Generated at 2022-06-22 04:48:09.943408
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange
    try:
        import cStringIO as StringIO
    except ImportError:
        from io import StringIO

    data = [['x'], ['a'], ['b'], ['c'], ['a'], ['b'], ['c'], ['a'], ['b'], ['c']]
    f = StringIO()
    df = pd.DataFrame(data, columns=['letters'])
    letters = df.groupby(['letters'])
    t = tqdm(letters, file=f, leave=False)
    result = letters.progress_apply(lambda x: len(x))
    t.close()
    assert str(result) in f.getvalue()

    f = StringIO()
    df = pd.DataFrame

# Generated at 2022-06-22 04:48:17.434610
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    tqdm.pandas()
    df = pd.DataFrame({'A': ['a', 'b', 'c', 'd', 'e'] * 20,
                       'B': [1.0, 2.3, 3.0] * 30})
    df.groupby('A').progress_apply(lambda x: x ** 3)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:28.554112
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame({"a": range(1000), "b": range(1000), "c": range(1000)})

    def f(x):
        return x["a"] + x["b"] + x["c"]

    def g(x):
        return x["a"] + x["b"] - x["c"]

    # Test `tqdm_pandas`
    result_t_pandas = df.groupby("a").progress_apply(f)
    result_no_t_pandas = df.groupby("a").progress_apply(g)
    assert result_t_pandas is not None and result_no_t_pandas is not None

# Generated at 2022-06-22 04:48:39.738512
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import io

    def func(x):
        return x
    df = pd.DataFrame({'x': [1, 2, 3, 4, 5, 6]})

    tqdm_pandas(tqdm, total=len(df))
    res = df.groupby('x').progress_apply(func)
    assert(res.equals(df))

    tqdm_pandas(tqdm, total=len(df))
    res = df.groupby('x').progress_apply(func)
    assert(res.equals(df))

    tqdm_pandas(tqdm())
    res = df.groupby('x').progress_apply(func)
    assert(res.equals(df))

    tqdm_

# Generated at 2022-06-22 04:48:43.364602
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm.pandas()



# Generated at 2022-06-22 04:48:50.224028
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    tqdm.pandas()
    print("Generating pandas DataFrame...")
    df = pd.DataFrame({'col': ('Go', 'Python', 'JavaScript', 'Java', 'C++'),
                       'val': (1, 2, 10, 20, 23)})
    print("Done!")
    print("Applying method groupby...")
    df.groupby('col').progress_apply(lambda x: x + 1)
    print("Done!")

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:58.772150
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy import mean

    tclass = tqdm(total=100)
    assert tclass.total == 100

    tqdm_pandas(tclass)
    assert tclass.total == 100

    df = DataFrame({'a': range(100)})
    df = df.groupby('a').progress_apply(mean)
    assert df.sum().sum() == 99

if __name__ == '__main__':
    try:
        test_tqdm_pandas()
    except ImportError:
        pass

# Generated at 2022-06-22 04:49:16.037833
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas."""
    try:
        import pandas
    except ImportError:
        return
    import numpy as np
    import pandas as pd
    from tqdm import tqdm_pandas, tqdm

    df = pd.DataFrame(np.arange(10), columns=list('A'))
    with tqdm(total=len(df)) as t:
        df.groupby(df.A % 2).progress_apply(
            lambda x: x**2.2,
            meta=('A', lambda x: t.update()))

# Generated at 2022-06-22 04:49:22.330820
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .gui import tqdm  # NOQA
    from pandas import DataFrame
    df = DataFrame({'a': [1, 2, 3], 'b': ['xg', 'yh', 'zi']})
    df = tqdm_pandas(tqdm(total=len(df)), df)
    assert isinstance(df, DataFrame)


# Generated at 2022-06-22 04:49:31.848720
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:49:43.857597
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`"""
    # pylint: disable=no-member,import-outside-toplevel
    import pandas as pd
    import tqdm
    try:
        pd.core.groupby.DataFrameGroupBy.progress_apply
    except AttributeError:
        try:
            pd.core.groupby.GroupBy.progress_apply
        except AttributeError:
            raise unittest.SkipTest('pandas < 0.25')
        else:
            pd.core.groupby.DataFrameGroupBy.progress_apply = \
                pd.core.groupby.GroupBy.progress_apply
    from pandas.core.groupby import DataFrameGroupBy
    pd.core.groupby.DataFrameGroupBy.progress_apply = None

# Generated at 2022-06-22 04:49:53.122792
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    try:
        import pandas as pd
    except ImportError:
        return
    from random import random
    from time import sleep
    from tqdm import trange

    sleep_bar = trange(100, desc="Unit test", leave=False, ncols=110)
    tqdm_pandas(sleep_bar)

    # Create test DataFrame
    df = pd.DataFrame({"a": [random() for _ in range(1000)],
                       "b": [random() for _ in range(1000)]})

    # Test Pandas GroupBy
    df.groupby('a').progress_apply(lambda x: x**2)

    # Test Pandas DataFrame.applymap()
    df.progress_applymap(lambda x: x**2)

# Generated at 2022-06-22 04:50:03.884464
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({"a": [1, 2, 3], "b": [1, 2, 3]})
    assert df.groupby("a").progress_apply(sum).equals(df.groupby("a").apply(sum))

    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(), mininterval=0.01)
    assert df.groupby("a").progress_apply(sum).equals(df.groupby("a").apply(sum))


if __name__ == '__main__':
    from multiprocessing import Pool
    Pool(1).map(test_tqdm_pandas, [None])

# Generated at 2022-06-22 04:50:12.988387
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib import pandas
    import tqdm

    def test_fn(g, **kwargs):
        ret = pd.Series([1, 1], index=g.index, name='tqdm')
        return ret

    def test_fn2(g, **kwargs):
        ret = pd.Series([1, 1], index=g.index, name='tqdm')
        return ret

    def test_fn_slow(g, **kwargs):
        from time import sleep
        sleep(2)
        ret = pd.Series([1, 1], index=g.index, name='tqdm')
        return ret


# Generated at 2022-06-22 04:50:22.655287
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import random
    import pandas as pd
    n = 1000
    df = pd.DataFrame({'x': [random.random() for _ in range(n)],
                       'y': [random.random() for _ in range(n)]})
    _ = df.groupby('x').progress_apply(lambda x: x)
    _ = df.groupby('x').progress_apply(lambda x: x, desc='test')
    _ = df.groupby('x').progress_apply(lambda x: x, leave=True, desc='test')

    _ = df.progress_apply(lambda x: x, axis=1)
    _ = df.progress_apply(lambda x: x, axis=1, desc='test')

# Generated at 2022-06-22 04:50:34.412405
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    from tqdm import tqdm
    from tqdm import tqdm_pandas

    df = pd.DataFrame(np.random.randint(1, size=(1000, 3)), columns=list('ABC'))

    def s(x):
        time.sleep(0.01)

    df['C'] = df['C'].progress_apply(s)
    df['C'] = df['C'].progress_apply(s)

    tqdm_pandas(tqdm)
    df['C'] = df['C'].progress_apply(s)
    df['C'] = df['C'].progress_apply(s)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:43.636123
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas import Series

    # case 1
    with tqdm(total=3) as t:
        t.pandas()
        # dummy function
        DataFrame([Series([1,2,3]), Series([4,5,6]), Series([7,8,9])]).apply(lambda s: s)
    assert t.n == 3

    # case 2
    with tqdm(total=3) as t:
        tqdm_pandas(t)
        # dummy function
        DataFrame([Series([1,2,3]), Series([4,5,6]), Series([7,8,9])]).apply(lambda s: s)
    assert t.n == 3

    # case 3

# Generated at 2022-06-22 04:51:06.137489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Create a training dataset and a validation dataset
    df_train, df_valid = create_dataset()

# Generated at 2022-06-22 04:51:11.903709
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    t = tqdm.tqdm(total=100)
    df = pd.DataFrame({'a': [1, 2, 3, 4], 'b': [5, 6, 7, 8]})
    tqdm_pandas(t, df.groupby('a').progress_apply(lambda x: x))
    assert t.n == 100
    assert t.total == 100



# Generated at 2022-06-22 04:51:22.155545
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame, Series
    from tqdm import tqdm_pandas as tqdm

    # test DataFrame
    def f1(x):
        return 1
    df = DataFrame({'a': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]})
    expected = df.groupby(df.a // 2).progress_apply(f1)
    actual = df.groupby(df.a // 2).progress_apply(f1, tqdm_kwargs={'desc': 'test'})
    assert expected.equals(actual)

    # test Series
    def f2(x):
        return x

# Generated at 2022-06-22 04:51:30.108245
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    try:
        import pandas as pd
        import numpy as np
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        raise unittest.SkipTest("No pandas module")

    with tqdm(range(10), desc="progress", unit="it") as t:
        pbar = tqdm_pandas(t)
        DataFrameGroupBy(pd.DataFrame([[1, 2], [1, 3]]), [0]).progress_apply(
            lambda x: pbar.update(), meta=[0])

    with tqdm(range(10), desc="progress", unit="it") as t:
        def f(x):
            t.update()
            return x
        tqdm_pandas(t)
        Data

# Generated at 2022-06-22 04:51:35.294367
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except:
        return
    try:
        tqdm_pandas(tqdm())
    except:
        assert False, 'tqdm_pandas(tqdm()) not working'
    try:
        tqdm_pandas(tqdm(total=1))
    except:
        assert False, 'tqdm_pandas(tqdm(total=1)) not working'

# Generated at 2022-06-22 04:51:38.611501
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    df = pd.DataFrame([[1, 2, 3], [1, 2, 3], [1, 2, 3]],
                      columns=['a', 'b', 'c'])
    df.groupby('a').progress_apply(lambda x: None)

# Generated at 2022-06-22 04:51:49.319184
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    tqdm_pandas(tqdm(desc="Test tqdm_pandas"))
    df = pd.DataFrame(np.random.random_sample((1000, 3)))
    df.groupby(0).progress_apply(lambda x: x)
    tqdm_pandas(tqdm(desc="Test tqdm_pandas"), leave=False)
    df = pd.DataFrame(np.random.random_sample((1000, 3)))
    df.groupby(0).progress_apply(lambda x: x)


# Generated at 2022-06-22 04:51:57.131087
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    import numpy as np
    from numpy.testing import assert_array_equal

    def g(x):
        return x + 1

    df = DataFrame(np.arange(20).reshape(2, 10))
    res = tqdm_pandas(df.groupby(0).progress_apply(g)).values
    assert_array_equal(np.arange(1, 21).reshape(2, 10), res)

    res = tqdm_pandas(tqdm(df.groupby(0))).progress_apply(g).values
    assert_array_equal(np.arange(1, 21).reshape(2, 10), res)


# Generated at 2022-06-22 04:52:06.931563
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas
    pd.Series([1, 2, 3]).progress_apply(lambda x: x ** 2)
    tqdm_pandas(tqdm(total=100))
    # pd.Series(range(1000)).progress_apply(lambda x: x ** 2)
    df = pd.DataFrame(np.random.randn(1000, 4).cumsum(),
                      columns=['A', 'B', 'C', 'D'])
    df = pd.DataFrame(np.random.randn(1000, 4))

# Generated at 2022-06-22 04:52:14.184810
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class tqdm:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def __iter__(self):
            yield 0

        def __len__(self):
            return 100

        def __repr__(self):
            return "tqdm(0/100)"

        def display(self):
            pass

    tqdm_pandas(tqdm)



# Generated at 2022-06-22 04:52:31.798817
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import TqdmDeprecationWarning

    with pytest.raises(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)



# Generated at 2022-06-22 04:52:36.721305
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.rand(1000000, 10))
    df.groupby(df.columns.tolist()).progress_apply(lambda x: 1)

    tqdm_pandas(tqdm)
    df.groupby(df.columns.tolist()).progress_apply(lambda x: 1)

# Generated at 2022-06-22 04:52:45.447887
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function `tqdm_pandas`."""
    from tqdm import TqdmTypeError
    from tqdm import tqdm

    # Expected type errors
    try:
        tqdm_pandas(None)
    except TqdmTypeError:
        pass
    try:
        tqdm_pandas(123)
    except TqdmTypeError:
        pass

    # Basic tests
    try:
        tqdm_pandas(tqdm)
    except TqdmDeprecationWarning:
        pass
    try:
        tqdm_pandas(tqdm.tqdm)
    except TqdmDeprecationWarning:
        pass

    # Test with `tqdm` instance

# Generated at 2022-06-22 04:52:55.348139
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    import random
    import re

    for tclass in (tqdm, tqdm.tqdm):
        with tclass(total=100, file=tqdm.tqdm.write) as t:
            for _ in range(100):
                t.update(1)
                tqdm_pandas(t)
                tqdm_pandas(tclass)
                df = DataFrame(
                    {
                        'col_%d' % i: [random.randint(0, 1) for _ in range(100)]
                        for i in range(10)})
                for _ in tqdm_pandas(tclass)(df.groupby(['col_0'])):
                    pass
        # this is broken due to pand

# Generated at 2022-06-22 04:53:03.377137
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import tqdm

    pandas.DataFrame([[1, 2], [3, 4]]).groupby(1).progress_apply(
        lambda x: list(tqdm.tqdm(x, leave=False)))
    pandas.DataFrame([[1, 2], [3, 4]]).groupby(1).progress_apply(
        lambda x: list(tqdm_pandas(x, leave=False)))
    tqdm_pandas(tqdm, leave=False).pandas(
        lambda x: list(x), data=pandas.DataFrame([[1, 2], [3, 4]]).groupby(1))
