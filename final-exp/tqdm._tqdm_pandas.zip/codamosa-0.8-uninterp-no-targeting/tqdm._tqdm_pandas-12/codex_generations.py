

# Generated at 2022-06-22 04:43:15.152196
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test """
    try:
        pd = __import__('pandas')
    except ImportError:
        pd = None

    if pd is None:
        print("Warning: pandas not found")
        return

    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas

    # Creating DataFrame
    df = pd.DataFrame(np.random.randint(0, 100, size=(100000, 4)), columns=list('ABCD'))

    # Register `pandas.progress_apply` and `pandas.Series.map_apply` with `tqdm`
    # (can use tqdm_gui, optional kwargs, etc.)
    tqdm_pandas(tqdm())

    # Now you can use `

# Generated at 2022-06-22 04:43:27.252204
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    tqdm.monitor_interval = 0  # Suppress tqdm's internal deprecation warnings

    # test automatic `tqdm` instanciation in simple case
    tqdm_pandas()
    t = pd.Series(range(100))
    assert all(t.progress_apply(lambda _: _) == t)

    # test automatic `tqdm` instanciation in complex case
    tqdm_pandas()
    t = pd.DataFrame(np.random.randint(0, 100, (100, 6)))
    assert all(t.groupby(0).progress_apply(lambda _: _) ==
                   t.groupby(0).apply(lambda _: _))

   

# Generated at 2022-06-22 04:43:39.144570
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import datetime
    from tqdm.auto import tqdm, trange
    import os
    import multiprocessing

    print('Test unit tqdm_pandas.py')
    print('=========================')

    print('\nTest: tqdm_pandas(tqdm)')
    print('-----------------------')
    tqdm_pandas(tqdm)
    pd.DataFrame(np.random.randint(0, 100, (100000, 6))).groupby(0).progress_apply(lambda x: x)

    print('\nTest: tqdm_pandas(trange)')
    print('-------------------------')
    tqdm_pandas(trange)

# Generated at 2022-06-22 04:43:51.354601
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    try:
        from pandas import Series
    except:  # pragma: no cover
        from pandas.core.series import Series
    try:
        from pandas import DataFrame
    except:  # pragma: no cover
        from pandas.core.frame import DataFrame

    s = Series(range(10))
    try:
        from IPython.display import display
        display(tqdm(s))  # display should trigger progress_apply
    except ImportError:  # pragma: no cover
        pass
    assert tqdm(s).values.all()


# Generated at 2022-06-22 04:44:03.594595
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from time import sleep
    from pandas import DataFrame
    from pandas import concat
    from pandas import Series
    from tqdm import tqdm

    batches = DataFrame({
        'field1': list('abcd') * 50,
        'field2': list('wxyz') * 50,
    })
    batches = concat([batches for _ in range(10)], ignore_index=True)

    results = []
    for batch in tqdm(batches.groupby('field1')):
        sleep(0.01)
        if batch[0] == 'a':
            results.append(Series([0] * len(batch[1]), index=batch[1].index))
        else:
            results.append(Series([1] * len(batch[1]), index=batch[1].index))

   

# Generated at 2022-06-22 04:44:14.928460
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .notebook import tnrange
    from .contrib.test_tqdm import with_test_modules, pretest_posttest

    @with_test_modules
    def test():
        from pandas import DataFrame
        import pandas.core.groupby  # import DataFrameGroupBy

        @pretest_posttest
        def _test():
            assert 'progress_apply' in dir(
                pandas.core.groupby.DataFrameGroupBy)

            # tqdm register with progress apply
            tqdm_pandas(tnrange)
            df = DataFrame(range(100), columns=['a'])
            df.groupby('a', as_index=False).progress_apply(lambda x: None)

            # tqdm register without progress apply

# Generated at 2022-06-22 04:44:23.779742
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    df = pandas.DataFrame([pandas.Series(range(10)), pandas.Series(range(10))])
    with tqdm_pandas(total=df.shape[0]) as t_bar:
        df.progress_apply(lambda x: x ** 2, axis=1, result_type="expand")
    assert t_bar.n == df.shape[0]
    assert t_bar.total == df.shape[0]


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:34.247990
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    try:
        import tqdm
    except ImportError:
        return
    df = pd.DataFrame({'col1': [1, 2, 3, 4], 'col2': [10, 11, 12, 13]})
    for _ in tqdm.tqdm_pandas(df.groupby('col1')):
        pass
    tqdm.tqdm_pandas(tqdm.tqdm())
    type(tqdm.tqdm()).pandas(tqdm.tqdm())
    tqdm.pandas(tqdm.tqdm())
    assert tqdm.tqdm_pandas is tqdm.pandas


if __name__ == '__main__':
    test_tqdm_

# Generated at 2022-06-22 04:44:45.921052
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    DataFrameGroupBy.progress_apply = lambda self, *args, **kwargs: self.apply(*args, **kwargs)
    from tqdm.pandas import tqdm_pandas
    import pandas as pd
    import tqdm

    # Unit testing tqdm_pandas with pandas.DataFrame.progress_apply
    with tqdm.tqdm_pandas(desc='this is tqdm_pandas') as t:
        df = pd.DataFrame([1, 2, 3])
        output = df.progress_apply(lambda x: x**2)
        assert output.equals(df.apply(lambda x: x**2))

# Generated at 2022-06-22 04:44:57.118786
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    from tqdm import tqdm, trange
    from tqdm.utils import _supports_unicode, _environ_cols_wrapper

    import pandas as pd
    import numpy as np
    import sys

    # Using a pandas dataframe
    N = 50000
    df = pd.DataFrame({
        'A': pd.Series(np.random.randn(N)),
        'B': pd.Series(['foo'] * N),
    })

    tqdm_pandas(tqdm)
    # Apply progress to 'A's
    res = df.groupby('B')['A'].progress_apply(lambda x: x * 2)
    assert (len(res) == N)

    # Check that

# Generated at 2022-06-22 04:45:06.768847
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.rand(1_000, 1_000))

    tqdm_pandas(tqdm, file=sys.stdout)
    df.groupby(0).progress_apply(lambda x: x * 2)
    tqdm_pandas(tqdm(file=sys.stdout), unit='B')
    df.groupby(0).progress_apply(lambda x: x * 2)


if __name__ == '__main__':
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.rand(1_000, 1_000))

    tq

# Generated at 2022-06-22 04:45:14.022922
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import time
    import numpy as np
    try:
        tqdm.pandas(desc='test_pandas')
    except TypeError:
        tqdm.pandas(desc='test_pandas', ncols=40)

    size = 100000
    df = pd.DataFrame(dict(a=np.arange(size), b=np.random.randn(size)))
    time.sleep(0.01)
    df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:45:23.485671
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook, trange
    from pandas import DataFrame

    for T in tqdm, tqdm_notebook, trange:
        for i in T(range(1)):
            with warnings.catch_warnings(record=True) as w:
                tqdm_pandas(T, ascii=True, unit_scale=True)
                assert len(w) == 1
                assert issubclass(w[0].category, TqdmDeprecationWarning)
                assert type(T(range(10))) == T

                # DataFrameGroupBy.progress_apply()
                sample_df = DataFrame(
                    {'a': ['foo'] * 10, 'b': ['two'] * 10, 'c': [1] * 10})
                sample_groupby

# Generated at 2022-06-22 04:45:28.789975
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy import arange

    tqdm_pandas(tqdm)
    df = DataFrame([arange(100000)], columns=['a'])
    for i, j in df.progress_apply(lambda x: x + 1, axis=0, result_type='expand').iterrows():
        pass

# Generated at 2022-06-22 04:45:39.859588
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit tests."""
    from pandas import Series, DataFrame
    from pandas import Series, DataFrame
    from tqdm.autonotebook import tqdm_pandas
    from numpy import arange

    s = Series(arange(10))
    df = DataFrame({'A': arange(10), 'B': arange(10)})

    def f(x):
        return x

    def g(x):
        return x

    # Series
    s.progress_apply(f)
    s.progress_apply(f, tclass=tqdm_pandas)
    s.progress_apply(f, tclass=lambda **t: tqdm_pandas(**t))

# Generated at 2022-06-22 04:45:45.901721
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas  # NOQA
    except ImportError:
        return

    if not hasattr(pandas, 'core'):
        return
    if not hasattr(pandas.core, 'groupby'):
        return
    if not hasattr(pandas.core.groupby, 'DataFrameGroupBy'):
        return

    import pandas as pd
    from tqdm import tqdm

    d = pd.DataFrame({1: [1, 2, 3], 2: [4, 5, 6]})
    dg = d.groupby(1)
    tqdm_pandas(tqdm)
    list(dg.progress_apply(lambda x: x))

if __name__ == '__main__':
    test_tqdm_pandas

# Generated at 2022-06-22 04:45:56.853329
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except Exception:
        return

    with tqdm_pandas(tqdm()) as pbar:
        df = pd.DataFrame({'a': [1, 2, 3, 4]})
        df.groupby('a').progress_apply(lambda x: x)
        pbar.close()

    tqdm_obj = tqdm()
    with tqdm_pandas(tqdm_obj):
        df = pd.DataFrame({'a': [1, 2, 3, 4]})
        df.groupby('a').progress_apply(lambda x: x)

    assert tqdm_obj._instances == []


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:05.908050
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    try:
        import pandas
    except ImportError:
        raise ImportError("`test_tqdm_pandas` requires pandas")

    for i in tqdm(range(999999), total=999999):
        pass
    df = pandas.DataFrame()
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        tqdm_pandas(tqdm, smoothing=0.5)
        # Verify some things
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
        assert "Please use `tqdm.pandas(...)`" in str

# Generated at 2022-06-22 04:46:17.780532
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for function `tqdm_pandas(tclass, **tqdm_kwargs)`."""
    from tqdm import tqdm_pandas, tqdm
    import pandas as pd

    df = pd.DataFrame(range(20), columns=['foo'])
    df.groupby('foo').progress_apply(lambda x: int(x.mean()))

    type(tqdm_pandas(tqdm)).pandas(deprecated_t=tqdm_pandas(tqdm))

    type(tqdm(bar_format='{l_bar}')).pandas(deprecated_t=tqdm(bar_format='{l_bar}'))


if __name__ == '__main__':
    test_tqdm_pand

# Generated at 2022-06-22 04:46:19.905478
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit testing function before deprecation.
    """
    tqdm_pandas(tqdm, desc='test tqdm_pandas')



# Generated at 2022-06-22 04:46:33.226148
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        from tqdm import tqdm

# Generated at 2022-06-22 04:46:39.824505
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    tqdm.tqdm_pandas(tqdm.tqdm(mininterval=0))
    tqdm.tqdm_pandas()
    pd.DataFrame([0]).groupby(0).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:50.373287
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    import pandas as pd

    df = pd.DataFrame({'A': [0, 1, 2, 3, 4], 'B': [0, 1, 2, 4, 5]})
    gdf = df.groupby('A')

    try:
        # register a tqdm instance with pandas
        tqdm_pandas(tqdm())
        assert gdf.progress_apply(lambda x: x).drop('A', axis=1).equals(df.drop('A', axis=1))

        # make sure that it's working
        assert gdf.progress_apply(lambda x: x).drop('A', axis=1).equals(df.drop('A', axis=1))
    finally:
        # unregister the tqdm instance
        tqdm_

# Generated at 2022-06-22 04:47:01.919963
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import pandas as pd
    import numpy as np
    import random

    # test tqdm_pandas
    df = pd.DataFrame({'animals': ['dog', 'cat', 'bird', 'panda', 'snake'] * 100,
                       'age': np.random.randint(1, 100, 500),
                       'weight': np.random.randint(1, 100, 500),
                       'priority': np.random.randint(0, 2, 500)},
                      columns=['animals', 'age', 'weight', 'priority'])
    df_grouped = df.groupby(by='animals')
    ret_val = df_grouped.progress_apply(lambda x: x)
    assert ret_val.equals(df_grouped.apply(lambda x: x))

    # test

# Generated at 2022-06-22 04:47:13.361806
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tnrange, trange

    df = pd.DataFrame(np.random.randint(0, 10, (100000, 6)),
                      columns=list('ABCDEF'))
    df.groupby(df[list('ABC')].applymap(str)).progress_apply(
        lambda x: x.shape, **{'t': tnrange, 'total': df.shape[0]})
    df.groupby(df[list('ABC')].applymap(str)).apply(
        lambda x: x.shape, **{'t': trange, 'total': df.shape[0]})

    tqdm_pandas(tnrange)

# Generated at 2022-06-22 04:47:24.266503
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:47:35.669243
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # test for the old syntax with tqdm(...)
    class DummyTqdm(object):

        class __metaclass__(type):
            def __init__(self, *args, **kwargs):
                self.pandas_called = 0

            def __call__(self, *args, **kwargs):
                self.tqdm_inst = object()
                return self.tqdm_inst

            def pandas(self, deprecated_t):
                self.pandas_called += 1
                assert deprecated_t is self.tqdm_inst
                self.pandas_args = args
                self.pandas_kwargs = kwargs

    dummy_tqdm = DummyTqdm()
    tqdm_pandas(dummy_tqdm)
    assert dummy_t

# Generated at 2022-06-22 04:47:46.602624
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm(total=100))
    with tqdm(total=100) as t:
        tqdm_pandas(t)
    tqdm_pandas(tqdm(total=100), smoothing=0)
    tqdm_pandas(tqdm(total=100), mininterval=0)
    tqdm_pandas(tqdm(total=100), miniters=0)



# Generated at 2022-06-22 04:47:57.412294
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from pandas.core.groupby import DataFrameGroupBy

    t = tqdm(total=2)
    t.pandas()

    df = pd.DataFrame(dict(a=[1, 2, 3], b=[4, 5, 6]))
    assert isinstance(df.groupby('a').progress_apply(len), tqdm)

    df.groupby('a', group_keys=False).progress_apply(len)
    df.groupby('a', as_index=False).progress_apply(len)

    t.close()

    df.groupby('a', as_index=False).progress_apply(lambda _: 1 / 0)

    t = tqdm(total=0)

# Generated at 2022-06-22 04:48:08.198459
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test function tqdm_pandas
    """
    import os
    import sys
    import tempfile
    import nose
    import nose.tools as nt
    from tqdm import tqdm, tqdm_pandas, TqdmExperimentalWarning, \
        TqdmDeprecationWarning
    from pandas import DataFrame, Series
    from numpy import random
    from pandas.core.groupby import DataFrameGroupBy
    from pandas.core.frame import DataFrame

    # Global options
    nt.assert_raises(TqdmExperimentalWarning, tqdm_pandas, tqdm)

    # Testing writing method

# Generated at 2022-06-22 04:48:20.882250
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    tqdm.monitor_interval = 0  # workaround for https://github.com/tqdm/tqdm/issues/481

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 5)), columns=list('ABCDE'))

    g = df.groupby('A')
    g_correct = dict([(name, g.get_group(name)) for name in g.groups])

    with tqdm(desc='Progress', ascii=True, leave=True) as t:
        g_test = dict(g.progress_apply(tqdm.tqdm_pandas, **t.kwargs))

# Generated at 2022-06-22 04:48:28.849866
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from inspect import isfunction
    assert isfunction(tqdm_pandas)
    try:
        import pandas
        with warnings.catch_warnings(record=True) as w:
            tqdm_pandas(pandas.DataFrame)
            tqdm_pandas(tqdm(pandas.DataFrame))
        assert all('deprecate' in str(ww.message) for ww in w)
    except ImportError:
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:39.738766
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import pandas as pd
    import numpy as np
    n, k = 20, 5
    df1 = pd.DataFrame(np.random.randint(0, k, size=(n, 2)), columns=list('AB'))
    df2 = df1.groupby('A').progress_apply(lambda x: x)
    assert len(df2) == len(df1)


if __name__ == '__main__':
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    n, k = 20, 5
    df1 = pd.DataFrame(np.random.randint(0, k, size=(n, 2)), columns=list('AB'))

# Generated at 2022-06-22 04:48:50.328439
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Disabled in Travis
    if os.environ.get('TRAVIS') == 'true':
        raise unittest.SkipTest

    import tqdm._tqdm_pandas
    assert tqdm._tqdm_pandas.tqdm_pandas is tqdm_pandas

    from pandas import DataFrame, Series
    from random import randint, random
    from tqdm.autonotebook import tqdm
    from time import sleep

    df = DataFrame({'a': [random() for _ in range(1000)],
                    'b': [randint(0, 100) for _ in range(1000)]})
    tqdm_pandas(tqdm)

# Generated at 2022-06-22 04:48:57.980366
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    d = {'col1': [1, 2], 'col2': [3, 4]}
    df = pd.DataFrame(data=d)

    tqdm_pandas(tqdm(total=len(df.index)))

    df.groupby('col1').progress_apply(lambda x: x + 1)
    tqdm_pandas(tqdm(total=len(df.index)))  # Test again to catch delayed adapter case



# Generated at 2022-06-22 04:49:03.391405
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm as tqdm
    global tqdm

    df = pd.DataFrame(range(10**6))
    _ = df.groupby(0).apply(lambda x: 1)
    with tqdm.tqdm(total=len(df)) as pbar:
        _ = df.groupby(0).progress_apply(lambda x: 1, pbar=pbar)

# Generated at 2022-06-22 04:49:11.950027
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np
    # Create test dataset
    df = pandas.DataFrame({'A' : np.random.rand(1000),
                           'B' : np.random.rand(1000)})
    # Create function to be applied with progress bar
    def sum_of_square(x):
        return (x['A'] ** 2 + x['B'] ** 2).sum()
    # Apply function with tqdm_pandas
    df.groupby(0).progress_apply(sum_of_square)
    # The function should not raise an error
    pass

# Generated at 2022-06-22 04:49:14.784932
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .std import tqdm
    t_instance = tqdm(range(100))
    tqdm_pandas(t_instance)

    t_class = tqdm
    tqdm_pandas(t_class)



# Generated at 2022-06-22 04:49:25.574835
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    from time import sleep
    import numpy as np

    if not isinstance(tqdm, type):
        from tqdm import TqdmDeprecationWarning
        import warnings
        warnings.simplefilter("error", TqdmDeprecationWarning)
        try:
            tqdm = tqdm(leave=True)
        except TqdmDeprecationWarning:
            return
        else:
            raise ValueError("Expected TqdmDeprecationWarning")


# Generated at 2022-06-22 04:49:35.261042
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        pass
    else:
        df = pandas.DataFrame(columns=list("ABCD"))
        df = df.reindex(range(10000))
        df2 = df.copy()

        # test 1:
        with tqdm_pandas(ascii=True) as t:
            df.groupby("A").progress_apply(lambda x: x)

        # test 2:
        for _ in tqdm_pandas(range(10), ascii=True):
            df.groupby("A").progress_apply(lambda x: x)

        # test 3:

# Generated at 2022-06-22 04:49:53.037703
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    # Import pandas and register the adapter
    import pandas
    tqdm_pandas(pandas)

    # Prepare a simple DataFrame
    N = 5
    X = pandas.DataFrame({'a': [1]*N, 'b': [2]*N, 'c': [3]*N})

    # Perform a trivial groupby operation
    groupby_generator = X.groupby('a').progress_apply(lambda x: x)

    # Check output
    for _ in groupby_generator:
        pass

    # Test that on a non DataFrame
    Xs = X['a']
    assert "DataFrameGroupBy" not in str(type(Xs.groupby([1, 2, 3, 4, 5])))
   

# Generated at 2022-06-22 04:50:03.283388
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test unit for function tqdm_pandas

    >>> import pandas as pd
    >>> df = pd.DataFrame()
    >>> df['a'] = [1,1,1,1,1,]
    >>> df.groupby('a').progress_apply(lambda x: x**2)
    100%|██████████| 1/1 [00:00<00:00, 55.19it/s]
    a
    1    1
    1    1
    1    1
    1    1
    1    1
    """
    pass


if __name__ == "__main__":
    from doctest import testmod
    testmod(name="tqdm_pandas")

# Generated at 2022-06-22 04:50:12.922583
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas
    from pandas.core.groupby import DataFrameGroupBy, SeriesGroupBy
    import tqdm

    class Tqdm(tqdm.tqdm):
        def __init__(self, *args, **kwargs):
            super(Tqdm, self).__init__(*args, **kwargs)
            self.pandas_enabled = False

        def register_instance(self, *args, **kwargs):
            self.pandas_enabled = True

    # Test Pandas
    res = pandas.DataFrame(np.random.rand(1000, 10)).groupby(10).progress_apply(
        lambda x: x ** 2)
    assert isinstance(res, DataFrameGroupBy)


# Generated at 2022-06-22 04:50:22.656588
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    "Testcase for tqdm_pandas function."
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(np.random.rand(1000, 1000))
    result = pd.DataFrame(index=df.index)

    with tqdm(ascii=True) as t:
        result['mean'] = df.progress_apply(lambda x: np.mean(x), axis=1,
                                           desc='Mean',
                                           dynamic_ncols=True,
                                           bar_format='{l_bar}{bar}{r_bar}',
                                           leave=False,
                                           file=t.fp,
                                           miniters=1,
                                           mininterval=0)

# Generated at 2022-06-22 04:50:32.313899
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if sys.version_info < (3, 3):
        return
    else:
        import pandas as pd
        import numpy as np
        import tqdm
        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)), columns=list('ABCDEF'))
        with tqdm.tqdm(total=len(df)) as pbar:
            df.groupby('A').progress_apply(lambda x: pbar.update())
            pbar.close()

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:42.149614
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from tqdm import tqdm
        from pandas import DataFrame, Series

        tqdm.pandas(desc='test')
        d = {'A': Series([1, 2, 3, 4, 5]), 'B': Series([1.1, 2.2, 3.3, 4.4, 5.5])}

        for n in [1, 2, 4, 8]:
            df = DataFrame(d)
            p = df.groupby('B').progress_apply(lambda x: x+n)
            assert p.iloc[0, 0] == d['A'].iloc[0]+n
            assert p.iloc[0, 1] == d['B'].iloc[0]
    except:
        pass

# Run unit test
test_tqdm_pandas()

# Generated at 2022-06-22 04:50:46.843754
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test with tqdm
    tqdm_pandas(tqdm)
    # Test with manual tqdm instance
    with tqdm(total=10) as progress_bar:
        tqdm_pandas(progress_bar)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:55.071095
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    with tqdm(total=10) as t:
        def my_func(x):
            t.update()
            return 2 * x

        df = pd.DataFrame({'a': range(10)})
        df.groupby('a').progress_apply(my_func)

    with tqdm(total=10) as t:
        tqdm_pandas(t)

        def my_func(x):
            t.update()
            return 2 * x

        df = pd.DataFrame({'a': range(10)})
        df.groupby('a').progress_apply(my_func)

    with tqdm(total=10) as t:
        tqdm_pandas(tqdm)
       

# Generated at 2022-06-22 04:51:06.309577
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'a': np.array(np.random.randn(10000), dtype=np.float64),
                       'b': np.array(np.random.randn(10000), dtype=np.float32),
                       'c': np.array(np.random.randn(10000), dtype=np.int8),
                       'd': range(10000),
                       'e': list("b" * 10000),
                       'f': list("a" * 10000)})

# Generated at 2022-06-22 04:51:11.209785
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    df = pd.DataFrame({'x': [1, 2, 3], 'y': [2, 3, 4]})
    df.groupby('x').progress_apply(lambda g: g['y'].sum()).tolist()



# Generated at 2022-06-22 04:51:37.306853
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import trange
    from tqdm.pandas import tqdm_pandas
    N = 100
    df = pd.DataFrame({'x': np.random.rand(N)})

    def tqdm_apply(df, fn, **kwargs):
        print(kwargs)
        progress_kwargs = {}
        progress_kwargs.update(tqdm_kwargs)
        t = trange(len(df), **progress_kwargs)
        for (i, record) in enumerate(t):
            df.iloc[i] = fn(record)
            t.update()


# Generated at 2022-06-22 04:51:46.406979
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit tests for `tqdm_pandas` function.
    """
    from tqdm import tqdm
    from tqdm import trange
    from pandas import DataFrame
    from pandas import Series

    for k in ('df', 'ser'):
        locals()[k] = DataFrame({'a': [0, 1, 2], 'b': [3, 4, 5]})
        locals()[k].loc[2, 'a'] = 2  # force NaN
        locals()[k].loc[:, 'c'] = Series([6, 7, 8], index=[1, 2, 3])

    # Test normal behaviour
    assert tqdm_pandas(tqdm) is None
    assert tqdm_pandas(tqdm(total=len(df))) is None

# Generated at 2022-06-22 04:51:47.579251
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFram

# Generated at 2022-06-22 04:51:56.142304
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return  # No pandas, no test
    pd.options.mode.chained_assignment = None  # Ignore setting with copy
    from tqdm.auto import trange
    from tqdm import tqdm, TqdmDeprecationWarning
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmDeprecationWarning)
        tqdm_pandas(tqdm)
    list(map(str, pd.Series(['a'] * 5).progress_apply(len)))
    list(map(str, pd.DataFrame({'a': ['a'] * 5,
                                'b': ['b'] * 5}).progress_apply(str, axis=1)))

# Generated at 2022-06-22 04:52:06.187828
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        print('\n\n' + "-" * 32 + '\nMissing dependencies for testing pandas '
              'integration.  Skipping.' + '\n' + "-" * 32 + '\n\n')
        return
    from tqdm import trange
    from tqdm._utils import _supports_unicode
    from tqdm import tqdm
    import sys

    with tqdm(range(10)) as t:
        assert hasattr(t, 'pandas')
        sys.stderr.flush()
        tqdm_pandas(t)


# Generated at 2022-06-22 04:52:16.800338
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Pre-create the two dummy pandas DataFrame
    from pandas import DataFrame
    df = DataFrame({'A': [1] * 1000, 'B': [2] * 1000})
    df_grp = df.groupby(['A'])
    # import tqdm
    # tqdm_pandas(tqdm)
    # print(df_grp.progress_agg(['mean']))  # <-- should show the progress bar
    # df_grp.progress_apply(lambda x: x)  # <-- should show the progress bar
    # print(df_grp.progress_agg(['mean']))  # <-- should show the progress bar


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:25.764944
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib import DummyTqdmFile, DummyTqdmFileEx
    from tqdm.auto import tqdm as auto_tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.tqdm import tgrange
    from tqdm.std import trange

    chunk_size = 10
    nrows = 50
    ncols = 2
    pd.set_option('chained_assignment', None)
    # DataFrame

# Generated at 2022-06-22 04:52:31.639956
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    try:
        from datetime import datetime
    except ImportError:
        from pandas._libs.tslibs import parsing

        try:
            from python3_utils import datetime
        except ImportError:
            datetime = parsing._datetime_from_string

    # Setup dataframe
    df = pd.DataFrame({'A': np.random.choice(range(100), size=100),
                       'B': list(range(100)),
                       'C': np.random.choice(
                           list(range(100)) + [None], size=100)})

    # Test tqdm_pandas function with deprecated parameter
    with tqdm(total=len(df)) as t:
        df.groupby

# Generated at 2022-06-22 04:52:38.472656
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm

    # Try case of not-delayed adapter
    try:
        tqdm_pandas(tqdm())
    except Exception:
        pass
    else:
        raise Exception('Not-delayed adapter case failed')

    for adapter in [tqdm, tqdm.write, tqdm.monitor, tqdm.notebook]:
        # Try case of delayed adapter
        try:
            tqdm_pandas(adapter)
        except Exception:
            raise Exception('Delayed adapter case failed')

        # Try case of already-created instance
        obj = adapter()
        try:
            tqdm_pandas(obj)
        except Exception:
            raise Exception('Already-created instance case failed')

    # None case
    assert tqdm_

# Generated at 2022-06-22 04:52:46.142782
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    def check_tqdm_pandas(tclass, **tqdm_kwargs):
        import pandas as pd
        df = pd.DataFrame({'a': list('abcdef'), 'b': [1, 2, 1, 2, 1, 2]})
        try:
            tqdm_pandas(tclass, **tqdm_kwargs)
            assert df.groupby('b').progress_apply(lambda x: x)
        except Exception as e:
            print(repr(e))
            raise

    check_tqdm_pandas(tqdm)
    check_tqdm_pandas(tclass=tqdm)

# Generated at 2022-06-22 04:53:08.243794
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    tqdm_pandas(tqdm)
    df = DataFrame()
    df.groupby(df.columns.tolist()).progress_apply(lambda x: x)