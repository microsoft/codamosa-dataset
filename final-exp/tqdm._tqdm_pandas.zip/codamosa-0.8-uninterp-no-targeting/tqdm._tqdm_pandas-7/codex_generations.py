

# Generated at 2022-06-22 04:43:10.726418
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    try:
        from pandas import DataFrame
    except ImportError:
        return
    try:
        df = DataFrame([[1, 2], [3, 4]], columns=list('AB'))
        tqdm_pandas(tqdm(), desc='A')
        assert df.progress_apply(lambda x: x, axis=1).index[0] == 0
    except Exception:
        return

# Generated at 2022-06-22 04:43:16.903257
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    with tqdm.tqdm_pandas() as t:
        df = pd.DataFrame({
            "A": [1, 2, 3, 4],
            "B": [22, 33, 44, 55]
        })
        df.groupby("A").progress_apply(lambda x: t.update())



# Generated at 2022-06-22 04:43:24.982118
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        df = pd.DataFrame({'a': [
            1, 2, 3
        ], 'b': [
            'x', 'y', 'z'
        ], 'c': [
            'a', 'b', 'c'
        ]})
        df.groupby(['a', 'b']).progress_apply(len)
    except ImportError:
        pass
    else:
        del pd


# Shortcut for function tqdm_pandas

# Generated at 2022-06-22 04:43:28.489783
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise SkipTest

    data = list(range(1000))
    d = pd.DataFrame(data, columns=['data'])

    tqdm_pandas(tqdm())
    for i in d.groupby(d.index // 100).progress_apply(lambda x: x):
        pass


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-22 04:43:40.146792
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from pandas.testing import assert_series_equal
    from tqdm import tqdm, trange

    pd = tqdm_pandas(tqdm)
    # Instantiate the tqdm object
    T = trange(3)
    data = {'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9]}
    df = DataFrame(data, columns=['A', 'B', 'C'])
    output = df.groupby('A').progress_apply(lambda x: x ** 2)
    rv = output.reset_index(level=0, drop=True).values
    expected = df.groupby('A').apply(lambda x: x ** 2).values

# Generated at 2022-06-22 04:43:52.056683
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_notebook as tqdm
    from pandas import DataFrame

    try:
        from IPython.display import display
    except ImportError:
        display = lambda d: d  # NOQA

    try:
        from sklearn.utils import shuffle
    except ImportError:
        from sklearn.cross_validation import shuffle

    df = DataFrame(shuffle(range(1000)))
    display(df.groupby(0).progress_apply(sum))

    def tqdm_pandas(t):
        assert t.__name__.startswith('tqdm_')
        return t

    tqdm_pandas(tqdm)('notebook')
    display(df.groupby(0).progress_apply(tqdm_pandas))



# Generated at 2022-06-22 04:44:04.196608
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    tqdm_pandas(tqdm)

    def f(x):
        return x * 2

    # Test DataFrameGroupBy.progress_apply

# Generated at 2022-06-22 04:44:14.276328
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas

    def func(x, y, *args, **kwargs):
        return x + y

    args = [{'x': 0, 'y': 1}, {'x': 0, 'y': 2}, {'x': 0, 'y': 3},
            {'x': 0, 'y': 4}, {'x': 0, 'y': 5},
            {'x': 0, 'y': 6}, {'x': 0, 'y': 7}, {'x': 0, 'y': 8}]

    pd_func = tqdm_pandas(lambda x: func(**x))

    for res in pd_func(args):
        assert res == 1

# Generated at 2022-06-22 04:44:27.069404
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    try:
        import numpy as np
    except ImportError:
        np = None

    def tqdm_func(x, y):
        return x + y

    range_len = get_tqdm()._instances.maxsize * 2 // 3
    df = pd.DataFrame({'a': np.random.randint(0, 100, range_len),
                       'b': np.random.randint(0, 100, range_len)})

    with tqdm(total=range_len) as t:
        df.progress_apply(tqdm_func, axis=1, args=(3,),
                          post_apply=lambda _: t.update())
    # print(df)

    from tqdm import tnrange

# Generated at 2022-06-22 04:44:34.773927
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    try:
        from tqdm import tqdm_notebook as tqdm
    except:
        from tqdm import tqdm
        tqdm = tqdm

    tqdm_pandas(tqdm, total=1000)

    df = pd.DataFrame(np.random.randint(0, 100000, (100000, 6)),
                      columns=['a', 'b', 'c', 'd', 'e', 'f'])
    df.groupby('a').progress_apply(lambda x: x**2)



# Generated at 2022-06-22 04:44:48.516635
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas.
    """
    try:
        from tqdm import tqdm_pandas
    except ImportError:
        return
    from random import random
    from pandas import DataFrame
    from time import sleep

    # Create mock DataFrame
    df = DataFrame({'dummy': [random() for _ in range(1000)]})

    # Decorate pandas.core.groupby.DataFrameGroupBy.progress_apply
    with tqdm_pandas(total=len(df)) as t:
        # Register `t` with `tqdm`
        def wrapper(*args, **kwargs):
            sleep(random() / 20)
            return t.update()
        df.groupby(0).progress_apply = wrapper

        # Test
        assert df.group

# Generated at 2022-06-22 04:44:55.291825
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests tqdm_pandas standalone function
    (as opposed to the method in tqdm).
    """
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy import random
    from pandas import np
    df = DataFrame(np.random.random((1000, 3)))
    tqdm.pandas(**vars(tqdm(df.progress_apply(max))))

# Generated at 2022-06-22 04:45:05.002958
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Must be compatible with pandas 0.22.x
    from pandas import DataFrame
    import pandas as pd

    with tqdm_pandas(total=None) as pbar:
        DataFrame([(1, 2)], columns=['A', 'B']).groupby(['A']).progress_apply(
            lambda x: tqdm(total=None).update(1))
    pbar.n = pbar.last_print_n = pbar.n = pbar.total = None
    with tqdm_pandas(total=None) as pbar:
        DataFrame([(1, 2)], columns=['A', 'B']).groupby(['A']).progress_apply(
            lambda x: tqdm(total=None).update(1))
    assert pbar.n == p

# Generated at 2022-06-22 04:45:15.357619
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook, trange
    from pandas import DataFrame, Series

    def _check(cls):
        with cls(leave=False) as pbar:
            for i in pbar([1, 2, 3]):
                pass
        pbar = cls(total=100, leave=False)
        pbar.update(42)
        pbar.close()

        tqdm_pandas(cls, total=10)
        assert isinstance(Series.progress_apply, Callable)
        assert isinstance(DataFrame.progress_apply, Callable)
        s = Series(["a", "b", "c"])
        assert s.progress_apply(lambda x: x.upper())[:0]._tqdm.total == 3
        x = Data

# Generated at 2022-06-22 04:45:19.346012
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    with tqdm_pandas(total=None) as pbar:
        pbar.update()

    tqdm_pandas(tqdm(total=None))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:29.849878
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test tqdm_pandas function"""
    import pandas as pd

    # With pandas version < 1
    def pandas_progress_apply(df):
        return df.groupby('A').progress_apply(lambda x: x['B'].sum())

    tqdm_pandas(pandas_progress_apply(pd.DataFrame({'A': [0, 0, 1, 1], 'B': [1, 1, 1, 1]})))

    # With pandas version >= 1
    tqdm_pandas(pd.DataFrame({'A': [0, 0, 1, 1], 'B': [1, 1, 1, 1]}).groupby('A').apply(lambda x: x['B'].sum()))

# Generated at 2022-06-22 04:45:39.930788
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit Test"""
    d = {'col1': [1, 2], 'col2': [3, 4]}
    try:
        import tqdm  # NOQA
        tqdm = tqdm.tqdm
        raise NotImplementedError
    except ImportError:
        import tqdm  # NOQA
        from tqdm.contrib import tqdm
    except NotImplementedError:
        # ignore test for contrib
        return
    import pandas as pd
    # tqdm.tqdm = tqdm  # for delayed adapter case
    df = pd.DataFrame(data=d)
    assert df.groupby('col1').progress_apply(lambda x: x).equals(df)

# Generated at 2022-06-22 04:45:45.946475
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import numpy as np
    import pandas as pd
    import os
    import tempfile
    try:
        from pandas import Series
    except ImportError:
        return
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    def myfunc(x):
        return x

    df = DataFrame(np.random.randint(1, 100, (300, 3)), columns=list('abc'))
    # tqdm function

# Generated at 2022-06-22 04:45:53.994695
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    def _test_tqdm_pandas(t):
        # tqdm_pandas(tqdm)
        tqdm_pandas(tqdm)
        # tqdm_pandas(tqdm())
        tqdm_pandas(t())

    _test_tqdm_pandas(tqdm)
    _test_tqdm_pandas(tqdm.tqdm)
    _test_tqdm_pandas(tqdm.tqdm_notebook)



# Generated at 2022-06-22 04:46:03.568798
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    pass
    # import tqdm as tqdm
    # import pandas as pd
    #
    # columns = ['col1', 'col2']
    # df = pd.DataFrame({
    #     'col1': [1, 2, 3, 4],
    #     'col2': ['a', 'b', 'c', 'd']}, columns=columns)
    # tqdm_pandas(tqdm)
    # df.groupby('col1').progress_apply(lambda x: x['col2'].mean())
    # df.groupby('col1', as_index=True).progress_apply(lambda x: x['col2'].mean())

# Generated at 2022-06-22 04:46:16.612189
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd

    rows = 1000
    t = tqdm(total=rows)
    with t:
        df = pd.DataFrame(
            [['a', 'angus'], ['b', 'bev'], ['c', 'clive']],
            columns=['letter', 'name'])
        df2 = df.groupby('letter').progress_apply(
            lambda x: x.shape[0] if x.name == 'c' else None)
        assert df2.shape[0] == rows


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:19.632826
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with tqdm(total=5) as t:
        for i in range(5):
            t.update()
    tqdm_pandas(t, file=None)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:30.882929
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    class tqdm_cls(object):
        """ Fake tqdm class """
        file = False
        write = False

    tqdm_inst = tqdm_cls()
    tqdm_inst.__name__ = 'tqdm_inst_name'

    tqdm_cls.pandas = lambda self, **kwargs: (
        self.file.write('tqdm_cls_pandas\n'))
    tqdm_inst.pandas = lambda self, **kwargs: (
        self.file.write('tqdm_inst_pandas\n'))

    tqdm_pandas(tqdm_cls, file=sys.stderr)

# Generated at 2022-06-22 04:46:39.587208
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    from tqdm import tqdm
    from pandas import DataFrame

    # Setup
    from numpy import random
    from six.moves import range

    df = DataFrame(random.randint(0, 100, (100000, 6)))
    total = len(df)

    # Test instance method
    with tqdm(total=total) as t:
        def nop(x):
            t.update()
            return x
        df.progress_apply(nop, axis=1)

    # Test class method
    with tqdm.__class__(total=total) as T:
        def nop(x):
            T.update()
            return x
        df.progress_apply(nop, axis=1)

# Get original `DataFrameGroupBy.progress_apply`

# Generated at 2022-06-22 04:46:50.320700
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .main import tqdm
    from .gui import tqdm_gui
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    import pandas
    assert DataFrameGroupBy.progress_apply != tqdm_pandas
    df = DataFrame([1, 2, 3, 4, 5], columns=['a'])
    tqdm_pandas(tqdm_gui)
    df.groupby('a').progress_apply(lambda x: x + 1)
    tqdm_pandas(tqdm)
    df.groupby('a').progress_apply(lambda x: x + 1, total=1e6)
    tqdm_pandas(tqdm_gui)
    with tqdm.external_write_mode():
        df.group

# Generated at 2022-06-22 04:47:01.873920
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for `tqdm_pandas`"""
    from .main import tqdm
    from .std import TqdmExperimentalWarning
    from tqdm import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter('ignore', TqdmDeprecationWarning)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', TqdmExperimentalWarning)
            # Test case 0
            # Un-adapter case
            tqdm_pandas(tqdm())
            # Test case 1
            # Un-adapter case
            tqdm_pandas(tqdm(ascii=True))
            # Test case 2
            # Delayed adapter case
            tqdm_pandas(tqdm, ascii=True)



# Generated at 2022-06-22 04:47:10.457571
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    from tqdm.contrib.pandas import tqdm_pandas

    df = pd.DataFrame({'col': [1, 2, 3]})
    with tqdm_pandas() as t:
        # Register `tqdm` to `DataFrameGroupBy.progress_apply`
        df.groupby('col', sort=False).progress_apply(t=t)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:16.354335
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    class TqdmClass:
        @staticmethod
        def pandas(**kwargs):
            pass

        @staticmethod
        def pandas(deprecated_t, **kwargs):
            pass

    tqdm_pandas(TqdmClass)
    tqdm_pandas(tqdm)
    # Now we test that it works by calling it on a large frame and checking
    # that it's called.
    from pandas.core.groupby import _GroupBy

    class GroupByTest(_GroupBy):
        def progress_apply(self, func, *args, **kwargs):
            assert "total" in kwargs, "Must have 'total'"

# Generated at 2022-06-22 04:47:21.180589
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    df = pd.DataFrame({'a': list(range(1000000))})
    for _ in tqdm.pandas(df.a):
        pass


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:28.773281
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    df = pd.DataFrame(
        [
            range(100),
            range(100),
        ],
        index=[
            'a',
            'b',
        ]
    )
    for _ in tqdm.tqdm_pandas(df.groupby(by=[1])):
        pass
    df.groupby(by=[1]).progress_apply(lambda x: tqdm.tqdm_pandas(x), axis=1)

# Generated at 2022-06-22 04:47:47.023149
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.random((100, 100)))

    def foo(x):
        return np.sum(x)

    # Apply tqdm to progress_apply
    tqdm_pandas(tqdm)
    df.groupby(0).progress_apply(foo)
    # Apply tqdm with lambda
    tqdm_pandas(lambda *a, **kw: tqdm(*a, **kw, dynamic_ncols=True))
    df.groupby(0).progress_apply(foo)
    # Apply tqdm with closure
    tqdm_pandas(tqdm(dynamic_ncols=True))

# Generated at 2022-06-22 04:47:58.242151
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Simple unit tests for tqdm_pandas.

    Note that this unit test will fail if pandas is not installed.
    """
    try:
        import pandas as pd
    except ImportError:
        return None
    # Try with positional arguments
    tqdm_pandas(tclass=tqdm, pandas=True)
    # Try with keyword arguments
    tqdm_pandas(tclass=tqdm, pandas=True)
    # Try with incorrect arguments
    with pytest.raises(TypeError):
        tqdm_pandas(tclass=tqdm)
    with pytest.raises(TypeError):
        tqdm_pandas(tclass=tqdm, pandas=True, __force_monitor='2')
    # Try with a t

# Generated at 2022-06-22 04:47:59.979530
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    return tqdm_pandas  # for coverage purposes

# Generated at 2022-06-22 04:48:06.946943
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for tqdm_pandas """
    import pandas as pd
    import numpy as np
    s = range(10)
    df = pd.DataFrame({'s': s,
                       'a': np.random.rand(10),
                       'b': np.random.rand(10)})
    print(df)
    with tqdm(total=10) as t:
        df.progress_apply(tqdm_pandas(t.update))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:18.362310
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    import pandas

    df = DataFrame(dict(A=[0, 1, 2], B=[2, 3, 4]))
    test = df.groupby('A').progress_apply(lambda x: 2*x).B.sum()
    assert test == 16, test

    # tqdm_pandas()
    tqdm_pandas(tqdm())
    with tqdm(disable=True) as tq:
        tqdm_pandas(tq)
    with tqdm(disable=True, dynamic_ncols=True) as tq:
        tqdm_pandas(tq)

# Generated at 2022-06-22 04:48:29.966707
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    tqdm_pandas(tqdm.tqdm(ascii=True))
    assert hasattr(tqdm.tqdm, 'pandas')
    assert 'pandas' in tqdm.tqdm().__repr__()
    tqdm_pandas(tqdm.tqdm_notebook)
    assert hasattr(tqdm.tqdm_notebook, 'pandas')
    assert 'pandas' in tqdm.tqdm_notebook().__repr__()
    tqdm_pandas(tqdm.tqdm_gui)
    assert hasattr(tqdm.tqdm_gui, 'pandas')
    assert 'pandas' in tqdm.tqdm_gui().__

# Generated at 2022-06-22 04:48:38.769472
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.autonotebook import tqdm as tqdm_notebook

    for tqdm_class in [tqdm, tqdm_notebook]:
        try:
            tqdm_pandas(tqdm_class)
            tqdm_pandas(tqdm_class, leave=False)
        except:
            import traceback
            traceback.print_exc()
            raise AssertionError("Failed with tqdm_class={}"
                                 .format(tqdm_class))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:48.471712
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Monkey-patching magic to redirect `pandas.core.groupby.DataFrameGroupBy.progress_apply` to use `tqdm` instead of `tqdm_notebook` when available.
    from tqdm.contrib.concurrent import thread_map
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.rand(100))
    df.groupby(0).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:59.702746
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np

    df = pd.DataFrame(np.random.randn(1000, 1), columns=['a'])
    if 'tqdm_notebook' in sys.modules:
        import tqdm_notebook
        tqdm_notebook.tqdm.pandas()
    else:
        tqdm.tqdm.pandas()
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm.tqdm.pandas()
    result = df.groupby(0).progress_apply(lambda x: x ** 2)
    assert (result.values >= 0).all()

    df = pd.DataFrame(np.random.randn(1000, 1), columns=['a'])

# Generated at 2022-06-22 04:49:06.585080
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    for tclass in [tqdm, tqdm_notebook, tqdm_gui, tqdm_pandas]:
        tbar = tclass(pandas=True)
        grp = pd.DataFrame(np.random.randn(100000, 4)).groupby(0)
        assert grp.progress_apply(lambda x: x).equals(grp.apply(lambda x: x))

# Generated at 2022-06-22 04:49:26.986912
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas
    pd = pandas.DataFrame({
        'col': [1, 2, 3, 4]
    })
    with tqdm.tqdm_pandas(leave=True) as t:
        pd.progress_apply(t.update)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:38.509569
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    try:
        import pandas as pd
        from numpy.random import randint
    except:
        return
    df = pd.DataFrame(randint(0, 100, size=(100000, 4)), columns=list('ABCD'))
    tqdm_pandas(tqdm)
    df.groupby('A').progress_apply(lambda x: x)
    tqdm_pandas(tqdm, leave=False)
    with tqdm(total=len(df)) as pbar:
        df.groupby('A').progress_apply(lambda x: x, pbar=pbar)
    tqdm_pandas(tqdm)
    g = df.groupby('A')

# Generated at 2022-06-22 04:49:48.179955
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    tqdm.pandas()  # register the `pandas.progress_apply` and `pandas.Series.map_apply` with `tqdm`
    df = pd.DataFrame({'A': [1, 2, 3, 4, 5, 6], 'B': [2, 3, 4, 5, 6, 7], 'C': [3, 4, 5, 6, 7, 8]})
    # example of `pandas.DataFrame.progress_apply` with `tqdm`
    df.progress_apply(lambda x: x**2, axis=1)
    # example of `pandas.Series.map_apply` with `tqdm`

# Generated at 2022-06-22 04:49:54.602785
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from random import shuffle
    from .tqdm import trange
    from .pandas import tqdm_pandas

    def slow_squared(x):
        from time import sleep
        sleep(0.001)
        return x ** 2

    tqdm_pandas(trange)
    df = pd.DataFrame({'x': [1, 2, 3, 4, 5]})
    # Test on pandas DataFrame
    # Before
    shuffle(df.x)
    df['x2'] = df['x'].progress_apply(slow_squared)
    # After
    shuffle(df.x)
    df['x2'] = df['x'].progress_apply(slow_squared)

# Generated at 2022-06-22 04:50:05.496569
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    try:
        import tqdm
        tqdm_pandas(tqdm)
    except ImportError:
        pass

    try:
        import tqdm.autonotebook
        tqdm_pandas(tqdm.autonotebook)
    except ImportError:
        pass

    try:
        import tqdm.notebook
        tqdm_pandas(tqdm.notebook)
    except ImportError:
        pass

    try:
        import tqdm_gui
        tqdm_pandas(tqdm_gui)
    except ImportError:
        pass


# Generated at 2022-06-22 04:50:13.986976
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    from tqdm import tqdm

    df = pd.DataFrame({"A": [1, 2, 3], "B": [1., 2., 2.]})
    result = df.groupby("B").progress_apply(len, 1)
    assert (result == df.groupby("B").apply(len, 1)).all().all()

    with tqdm(total=1) as t:
        result = df.groupby("B").progress_apply(len, 1, t)
        assert (result == df.groupby("B").apply(len, 1)).all().all()

    with tqdm(total=1) as t:
        result = df.groupby("B").progress_apply(lambda x: len(x), 1, t)

# Generated at 2022-06-22 04:50:24.569336
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test of the tqdm_pandas() function."""
    import pandas as pd
    pd.core.groupby.DataFrameGroupBy.progress_apply = lambda self, func, *args, **kwargs: func(*args, **kwargs)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(position=1))
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tqdm_notebook())
    tqdm_pandas(tqdm_notebook(position=1))
    tqdm_pandas(tqdm_notebook(total=10))
    tqdm_pandas(tqdm(position=1, total=10))
    tqdm

# Generated at 2022-06-22 04:50:29.653012
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    data = pandas.DataFrame(numpy.random.random((100, 100)))
    data = data.apply(tqdm_pandas(lambda x: x))
    assert data is not None

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:39.407834
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    tqdm_pandas(tqdm.tqdm())

    # Test whether pandas progress_apply function is overridden
    df = pd.DataFrame({'x': [1, 2, 3]})
    old_pgb = pd.core.groupby.DataFrameGroupBy.progress_apply
    tqdm_pandas(tqdm.tqdm())
    assert pd.core.groupby.DataFrameGroupBy.progress_apply != old_pgb


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:48.271305
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    assert callable(tqdm_pandas), "tqdm_pandas is not callable"
    assert tqdm_pandas(tqdm.tqdm) is None
    assert isinstance(tqdm_pandas(tqdm.tqdm)(pd.DataFrame([1, 2])), pd.DataFrame)
    assert isinstance(tqdm_pandas(tqdm.tqdm)(pd.Series([1, 2])), pd.Series)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:23.610716
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm
    import math
    df = pd.DataFrame({'x': [1, 2, 3],
                       'y': ['a', 'b', 'c']})
    assert df.groupby('y').progress_apply(lambda x: math.log(x, 2))[0].sum() == 2.584962500721156


if __name__ == '__main__':
    from tqdm import tqdm
    test_tqdm_pandas()
    print("All tests passed")

# Generated at 2022-06-22 04:51:29.671778
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm_pandas(tqdm, leave=False)
    df.groupby(0).progress_apply(lambda x: x**2)
    tqdm_pandas(tqdm(leave=False))
    df.groupby(0).progress_apply(lambda x: x**2)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:38.330412
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return

    df = pandas.DataFrame({'a': [1, 2, 3], 'b': [3, 4, 5]})

    # test register/unregister
    tqdm_pandas(pandas)
    df.groupby('a').progress_apply(lambda x: x)
    tqdm_pandas.unregister()
    df.groupby('a').progress_apply(lambda x: x)

    # test register/unregister delayed adapter
    with closing(StringIO()) as our_file:
        tqdm_pandas(file=our_file)
        df.groupby('a').progress_apply(lambda x: x)
        tqdm_pandas.unregister()
        df.groupby('a').progress

# Generated at 2022-06-22 04:51:48.415057
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test which re-tests the examples.
    """
    import pandas as pd

    def slow_mean(df):
        import time
        time.sleep(0.06)
        return df.mean()

    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]],
                      index=['cobra', 'viper', 'sidewinder'],
                      columns=['max_speed', 'shield', 'missiles'])

    import tqdm
    tqdm.tqdm_pandas(tqdm.tqdm(), 'mean')
    assert df.groupby(['max_speed']).progress_apply(slow_mean)



# Generated at 2022-06-22 04:51:52.401587
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # delay import of pandas
    import pandas as pd
    df = pd.DataFrame({'x': range(5)})
    with tqdm_pandas(leave=True) as t:
        df.groupby('x').progress_apply(lambda x: x.sum())

# Generated at 2022-06-22 04:51:57.509697
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        df = pd.DataFrame(np.arange(1e6).reshape(1e6//8, 8))
        from tqdm import tqdm
        tqdm_pandas(tqdm, file=open('/dev/null', 'w'))
        assert hasattr(df.groupby(0).progress_apply, '__wrapped__')
    except (ImportError, AssertionError):
        pass
test_tqdm_pandas.test_tqdm_pandas = True



# Generated at 2022-06-22 04:52:06.380631
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    tqdm_pandas(tqdm.tqdm())
    a = pd.DataFrame(np.random.randint(1, 100, (10000, 10000)))
    b = a.groupby(np.random.randint(2, 10, 10000))
    r = b.apply(lambda x: x.agg(np.sum))
    tqdm.pandas(desc="test_tqdm_pandas: ")
    r = b.progress_apply(lambda x: x.agg(np.sum))
    return


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:15.413178
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import random

    rand_list = random.sample(list(range(0, 100)), 10)
    rand_list = [random.sample(list(range(0, 100)), 10)
                 for _ in range(0, 100)]
    df = pd.DataFrame(rand_list)


    def square(x):
        return x**2


    # case 1
    tqdm_pandas(df.groupby(0))
    # case 2
    tqdm_pandas(tqdm(), df.groupby(0))


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:25.424165
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return  # Skip test if pandas is not installed
    try:
        import requests
    except ImportError:
        return  # Skip test if requests is not installed

    url = 'https://raw.githubusercontent.com/pandas-dev/pandas/master/pandas/tests/data/test1.json'
    # tqdm.pandas not available in this version
    if not hasattr(sys.modules[__name__], 'tqdm_pandas'):
        return
    with tqdm(total=10, desc='Downloading test data') as pbar:
        def report(*args, **kwargs):
            pbar.update()
        req = requests.get(url, hooks={'response': report})

# Generated at 2022-06-22 04:52:27.745073
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tclass=tqdm, desc='test')

