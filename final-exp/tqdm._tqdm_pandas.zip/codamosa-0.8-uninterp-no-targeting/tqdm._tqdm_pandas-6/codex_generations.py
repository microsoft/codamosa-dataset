

# Generated at 2022-06-22 04:43:14.939367
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test tqdm_pandas function with random generated DataFrame."""
    import random
    import pandas as pd

    n_row = 100
    n_col = 10
    data = pd.DataFrame({x: [random.random() for y in range(n_row)] for x in range(n_col)})
    init = data.progress_apply.__doc__

    tqdm_pandas(tqdm)
    assert data.progress_apply.__doc__ != init, "Links not registered"

    # Test function
    def f(x):
        x = 0
        for _ in range(int(random.random() * 100)):
            x += random.random()
        return x

    t = data.progress_apply(f)

# Generated at 2022-06-22 04:43:27.128472
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    import numpy as np
    import pandas as pd
    from tqdm import tqdm
    from .gui import tqdm_notebook
    from .std import tqdm_gui

    # Test case 1: function tqdm_pandas
    # init_notebook_mode() (execute only once)
    for _ in tqdm(range(2), ascii=True):
        pass
    for _ in tqdm_notebook(range(2), ascii=True):
        pass
    for _ in tqdm_gui(range(2), ascii=True):
        pass
    # Real world test
    import tqdm_pandas


# Generated at 2022-06-22 04:43:30.489931
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    with tqdm.tqdm(total=100, smoothing=0) as t:
        pd.DataFrame().groupby([0, 1]).progress_apply(lambda x: t.update())

# Generated at 2022-06-22 04:43:34.138542
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    t = tqdm.tqdm(total=1)
    with tqdm.testing.disable_warnings():
        tqdm_pandas(t)

# Generated at 2022-06-22 04:43:43.107936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm

    assert (tqdm is not None)
    try:
        import pandas as pd
    except ImportError:
        return
    with tqdm.pandas(total=10) as t:
        pd.DataFrame(range(10)).groupby(
            0).progress_apply(lambda x: x)
        assert (t.last_print_n == 1)



# Generated at 2022-06-22 04:43:50.075571
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    def inc(x):
        return x + 1

    tqdm_pandas(tqdm, desc='Test')
    df = pd.DataFrame({'a': [1, 2, 3]})
    assert df.groupby('a').progress_apply(inc).equals(df + 1)


# =============================================================================
# Test script
# =============================================================================

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:54.345914
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({'x': range(100)})
    df['y'] = df['x'].progress_apply(lambda x: x*2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:57.933899
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return
    df = pd.DataFrame(np.random.randint(0, 1000, (100000, 6)), columns=[
                      'a', 'b', 'c', 'd', 'e', 'f'])
    # We need `close` set to `False` or `None` for `progress_apply` to
    # work with `tqdm_pandas`, but since it's deprecated, `tqdm_pandas`
    # will set it to `True` for us.
    tqdm_pandas(lambda x: x, total=len(df), leave=False)
    assert (df.progress_apply(lambda x: x) == df).all().all()
    tqdm_pandas

# Generated at 2022-06-22 04:44:06.716037
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    from tqdm import tqdm  # from __future__ import absolute_import
    from pandas.core.groupby import GroupByError

    # test with progress_apply
    data = pandas.DataFrame(numpy.random.randint(0, int(1e9),
                                                (int(1e6), 5)))
    try:
        # test no file nocache
        pandas.DataFrame(data.groupby('A').progress_apply(lambda x: x))
    except GroupByError:
        assert True
    try:
        # test no file cache
        pandas.DataFrame(data.groupby('A').progress_apply(lambda x: x))
    except GroupByError:
        assert True
    assert True



# Generated at 2022-06-22 04:44:16.453671
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time

    class DummyTqdmFile(object):
        """Dummy file-like that will write to tqdm"""
        file = None

        def __init__(self, file):
            self.file = file

        def write(self, x):
            # Avoid print() second call (useless \n)
            if len(x.rstrip()) > 0:
                tqdm.write(x, file=self.file)

    df = pd.DataFrame(np.random.random((5000, 3)), columns=list('ABC'))

# Generated at 2022-06-22 04:44:24.157128
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Import pandas and numpy
    import pandas as pd
    import numpy as np
    # Define a toy data frame
    df = pd.DataFrame({"a": np.arange(1000), "b": np.random.randn(1000)})
    # Apply function over data frame with progress
    df.groupby("a").progress_apply(lambda x: x)


# Generated at 2022-06-22 04:44:34.946143
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, trange
    from pandas import DataFrame

    t = trange(10, desc='Progress Bar', file=sys.stdout)
    tqdm_pandas(t)

    t = trange(10, desc='Progress Bar', file=sys.stdout)
    tqdm_pandas(tqdm)

    # test python function
    def fn(*args):
        for i in args:
            yield i

    df = DataFrame({'A': [0, 0, 0, 0, 0],
                    'B': [1, 1, 1, 1, 1],
                    'C': [2, 2, 2, 2, 2],
                    'D': [3, 3, 3, 3, 3]})
    df.groupby(['A', 'B']).progress_apply

# Generated at 2022-06-22 04:44:46.399063
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas.core.groupby import DataFrameGroupBy

    @tqdm_pandas
    def dummy(df):
        time.sleep(0.01)
        return df

    class DummyClass():
        pass

    class DummyTqdm():
        def __init__(self):
            self.total = 1000
            self.n = 0
            self.last_print_n = 0

        def update(self, n=1):
            self.n += n

        def close(self):
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

    DataFrameGroupBy._progress_apply = dummy

# Generated at 2022-06-22 04:44:57.553709
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'a': np.random.uniform(size=10000),
                       'b': list('abcdefghijklmnopqrstuvwxyz' * 400),
                       'c': np.random.random_integers(low=100, high=900,
                                                      size=10000)})

    # tqdm_pandas can be called in several ways
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=1000))
    tqdm_pandas(tqdm(total=1000), total=1000)

# Generated at 2022-06-22 04:45:00.844886
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    # Test with actual TqdmInvoker with expected output
    try:
        from tqdm import tqdm
    except ImportError:
        raise SkipTest("Please install `tqdm` to enable this test!")

    tqdm(pandas=True)

    # Test with tqdm() (invoker)
    tqdm_pandas(tqdm())

    # Test with delayed adapter
    from tqdm import trange
    tqdm_pandas(trange)

# Generated at 2022-06-22 04:45:04.189949
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # https://stackoverflow.com/questions/32007085/how-to-unit-test-a-python-function
    from pandas import DataFrame
    from tqdm import tqdm
    from tqdm import trange

    for t in [tqdm, trange]:
        tqdm_pandas(t)
        df = DataFrame(data={'a': [1, 2, 3], 'b': [4, 5, 6]},
                    index=[1.0, 2.0, 3.0])
        df_mean = df.groupby(by=['a']).progress_apply(np.mean)
        assert 'b' in df_mean.columns
        assert len(df_mean) == 3
        assert df_mean.index[0] == 1

# Generated at 2022-06-22 04:45:15.001961
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings(record=True) as w:
        try:
            from pandas import Series, DataFrame
        except ImportError:
            raise unittest.SkipTest("pandas is not installed")
        else:
            from tqdm.autonotebook import tqdm

            # Test tqdm_pandas with `tqdm` (default)
            tqdm_pandas(tqdm)
            tqdm_pandas(tqdm())
            assert len(w) == 2

            # Test tqdm_pandas with `tqdm` (new)
            tqdm_pandas(tqdm, total=len(Series(range(10))))
            tqdm_pandas(tqdm, total=len(DataFrame(range(10))))


# Generated at 2022-06-22 04:45:22.820815
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for function `tqdm_pandas`."""
    from tqdm import tqdm
    from tqdm.contrib import pandas

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(leave=True))
    assert tqdm_pandas(tqdm, total=123) == pandas.tqdm(total=123)
    assert tqdm_pandas(tqdm, total=123, file=sys.stderr) == \
        pandas.tqdm(total=123, file=sys.stderr)

# Generated at 2022-06-22 04:45:28.885447
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    x = tqdm_pandas(tqdm(total=10), mininterval=0.01, leave=False)
    x.pandas(mininterval=0.01, leave=False)
    tqdm_pandas(tqdm, mininterval=0.01, leave=False).pandas(
        mininterval=0.01, leave=False)



# Generated at 2022-06-22 04:45:35.978479
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas.
    """
    try:
        import pandas as pd;
        tqdm_test = tqdm_pandas(tqdm)
        df = pd.DataFrame([[i] for i in range(100)]);
        df.groupby(0).progress_apply(lambda x: x**2)
    except Exception as e:
        raise e

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:39.523620
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tclass=tqdm)



# Generated at 2022-06-22 04:45:43.213793
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm(ascii=True))
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, ascii=True)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:52.967925
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`
    """
    import pandas as pd
    from pandas import DataFrame, Series
    from numpy.random import randint, rand

    # Initialize dataframe
    df = DataFrame({
        'A': randint(1, 10, 10),
        'B': randint(1, 10, 10),
        'C': [1, 2, 3, 4, 4, 5, 6, 7, 7, 8],
        'D': [1, 2, 2, 4, 5, 6, 7, 7, 8, 9]
    })
    df['E'] = ['A', 'B', 'A', 'C', 'A', 'B', 'B', 'A', 'A', 'B']

# Generated at 2022-06-22 04:45:57.387740
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    import tqdm

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:06.357643
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm.autonotebook import tqdm

    try:
        # Evaluating tqdm_pandas with a type
        tqdm_pandas(tqdm)

        # Evaluating tqdm_pandas with an instance
        tqdm_pandas(tqdm())

        # Evaluating tqdm_pandas with a delayed adapter
        tqdm_pandas(tqdm_notebook)

        # Evaluating pandas with a tqdm instance
        pd = DataFrame({"A": [1, 2]}).groupby(['A']).progress_apply(lambda x: x)
        # df.groupby(['A']).progress_apply(lambda x: x)
    except Exception:
        return False

# Generated at 2022-06-22 04:46:17.781256
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    # First make sure we can progress on the barebone dataframe
    try:
        pd.DataFrame([1, 2, 3]).progress_apply(lambda x: x)
    except AttributeError:
        raise AttributeError("Please use pandas >= 0.18.0 to run this test")

    # Then make sure we allocate tqdm correctly
    with tqdm.std.redirect_stdout(None):
        progress = tqdm_pandas(tqdm.tqdm, desc='foo')
    assert hasattr(progress, 'tqdm')
    assert hasattr(progress.tqdm, '__get__')
    assert getattr(progress.tqdm, '__name__') == 'tqdm'

    # Then make sure we can t

# Generated at 2022-06-22 04:46:29.204216
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        raise unittest.SkipTest("pandas is not installed")
    import numpy as np
    from tqdm import tqdm

    with tqdm(total=100, desc='test', ascii=True) as pbar:
        pandas.DataFrame([np.arange(1000) for i in range(3)]).progress_apply(
            lambda x: pbar.update())

    try:
        tqdm_pandas(tqdm, ascii=True)
    except TypeError:
        pass
    else:
        raise ValueError("accepting `tqdm` instance should fail with TypeError")

    tqdm_pandas(tqdm_pandas, ascii=True)  # delayed adapter case


# Generated at 2022-06-22 04:46:37.811030
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def return_true(_):
        return True

    def return_false(_):
        return False

    df = pd.DataFrame(dict(a=[return_true] * 3 + [return_false] * 5))
    try:
        with tqdm_pandas(total=len(df)) as t:
            # NOTE: We force progress_apply to use chunks of size 1
            #       as otherwise pandas would raise a NotImplementedError
            df.groupby('a').progress_apply(lambda x: x,
                                           group_keys=False,
                                           chunk_size=1,
                                           tqdm=t)
    except NotImplementedError:  # pragma: no cover
        assert True
    else:  # pragma: no cover
        assert False

# Generated at 2022-06-22 04:46:47.123202
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame

    from tqdm import tqdm_notebook
    from tqdm import tqdm_gui
    from tqdm import tqdm_pandas

    s = DataFrame({'a': [1, 2], 'b': [3, 4]})
    s.groupby(['a']).progress_apply(lambda x: x)
    tqdm_pandas(tqdm_notebook)
    s.groupby(['a']).progress_apply(lambda x: x)
    tqdm_pandas(tqdm_gui)
    s.groupby(['a']).progress_apply(lambda x: x)

# Generated at 2022-06-22 04:46:52.651819
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    tqdm_pandas()
    df = pd.DataFrame({'a': range(100000), 'b': range(100000), 'c': range(100000), 'd': range(100000)})
    df.groupby('a').progress_apply(lambda x: x)
    df.groupby('a').progress_apply(lambda x: x)
    df.groupby('a').progress_apply(lambda x: x)
    df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:47:02.174843
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas
    from time import sleep
    from numpy.random import randint

    def f(x):
        sleep(randint(10) / 1000)
        return x ** 2

    df = pd.DataFrame({'x': range(1000)})
    tqdm_pandas(tqdm())
    df['y'] = df['x'].progress_apply(f)
    tqdm.pandas(desc='Test')
    df['y'] = df['x'].progress_apply(f)
    return True

# Generated at 2022-06-22 04:47:13.394715
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
    except ImportError:
        return None

    df = pd.DataFrame({'x': np.random.randn(int(1e4)),
                       'y': np.random.randn(int(1e4))})
    # Test default case
    tqdm_pandas(tqdm())
    # Test delayed adapter case
    tqdm_pandas(tqdm_gui, leave=False)
    # Test multiple applications
    tqdm_pandas(tqdm(), smoothing=0.1)
    tqdm_pandas(tqdm_gui(), leave=False)
    # Test lazy case
    tqdm_pandas(tqdm(df))
    # Test nested lazy case
    t

# Generated at 2022-06-22 04:47:24.265411
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas()."""
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas

    def f(x):
        time.sleep(0.1)
        return x

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)),
                      columns=list('ABCDEF'))
    # We MUST use `list(df)` instead of `df.columns`
    # as the latter doesn't always work
    for c in tqdm_pandas(list(df)):
        df[c] = df[c].apply(f)
    for c in tqdm_pandas(list(df), desc="Pandas 'apply' progress:"):
        df

# Generated at 2022-06-22 04:47:27.502307
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        try:
            import pandas
        except ImportError:
            return
    tqdm_pandas(tqdm())

# Generated at 2022-06-22 04:47:29.244286
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    t = tqdm(total=1)
    tqdm_pandas(t)

# Generated at 2022-06-22 04:47:39.722150
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    try:
        from pandas import Series
    except ImportError:
        return
    df = pd.DataFrame({'x': pd.Series(range(50))})
    df.groupby('x').progress_apply(lambda x: x ** 2)

    try:
        with tqdm(total=0) as t:
            tqdm_pandas([1, 2, 3], t=t)
    except TypeError:
        return
    raise AssertionError("tqdm_pandas([1,2,3], t=t) should have failed")


# Run tests
if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:51.073405
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series
    from pandas.util.testing import assert_series_equal
    from numpy.testing import assert_equal

    df = DataFrame({'A': [1, 2, 3, 4, 5], 'B': [6, 5, 4, 3, 2], 'C': [3, 4, 5, 6, 7]})
    df2 = DataFrame({'A': [0, 1, 2, 3], 'B': [4, 3, 2, 1]})

    assert_series_equal(df.apply(Series.sum).sort_index(),
                        df.progress_apply(Series.sum, tqdm_kwargs={'leave': False}).sort_index(),
                        check_dtype=False)


# Generated at 2022-06-22 04:47:55.192927
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange

    # Check noop
    t = trange(0)
    tqdm_pandas(t)

    # Check pandas
    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        df = pd.DataFrame(range(10000))
        tqdm_pandas(df.groupby(0).apply(lambda x: x))

# Generated at 2022-06-22 04:48:00.164005
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    n = 500
    pd.DataFrame(range(n)).groupby(0).progress_apply(
        lambda p: p,
        tqdm_kwargs=dict(tclass=tqdm))

# Generated at 2022-06-22 04:48:07.652403
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    import time
    df = pd.DataFrame({'a': [10, 20, 30, 40, 50],
                       'b': [20, 30, 10, 40, 50],
                       'c': [32, 234, 23, 23, 42523]})

    def my_test(x):
        time.sleep(0.1)
        return x

    tqdm.pandas(tqdm.tqdm(total=len(df)))
    df.progress_apply(my_test)
    assert True

# Generated at 2022-06-22 04:48:11.460938
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)



# Generated at 2022-06-22 04:48:17.435145
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        from nose import SkipTest
        raise SkipTest("pandas not installed")
    with tqdm(total=100) as t:
        tqdm_pandas(t, desc="Pandas")
        pandas.DataFrame(numpy.arange(1e5).reshape(1e4, 100)).progress_apply(
            lambda x: x)
        t.close()

# Generated at 2022-06-22 04:48:24.538932
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    # catch warnings
    with warnings.catch_warnings(record=True) as w:
        # cause all warnings to always be triggered
        warnings.simplefilter("always")
        # trigger a deprecation warning
        tqdm_pandas(tqdm)
        # test warnings
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
        assert "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`." in str(w[-1].message)
        # trigger a deprecation warning
        tqdm_pandas(tqdm(unit='t'))
        # test warnings
        assert len(w) == 2
        assert issubclass

# Generated at 2022-06-22 04:48:32.031705
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm._tqdm_pandas import tqdm_pandas_deprecated as tqdm_pandas
    from tqdm.contrib import DummyTqdmFile

    # Test 1
    df = pd.DataFrame(
        {'x': np.random.permutation(20000),
         'y': np.random.permutation(20000)})
    with DummyTqdmFile(sys.stderr) as f:
        for _ in tqdm_pandas(range(10)):
            df.groupby('x').progress_apply(lambda df2: df2.y.sum(), f=f)

# Generated at 2022-06-22 04:48:40.741806
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest("pandas is not available")
    from tqdm import tqdm, tqdm_pandas
    from tqdm._tqdm_gui import tqdm as tqdmg  # type: ignore

    # tqdm_pandas(tqdm, ...)
    df = pd.DataFrame(
        {'A': [4, 4, 2, 1, 2],
         'B': [1, 2, 2, 4, 2],
         'C': [1, 2, 1, 1, 2]},
        index=['r1', 'r2', 'r3', 'r4', 'r5'])
    with captured_output() as (_, _):
        tqdm_p

# Generated at 2022-06-22 04:48:50.512604
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    try:
        from pandas import DataFrame
    except ImportError:
        return

    __first_iter__ = False
    tqdm._instances.clear()

    def test(tclass):
        def dumb_apply(self, func, *args, **kwds):
            return self

        with suppress(ImportError):
            from pandas.core.groupby import DataFrameGroupBy
            DataFrameGroupBy._apply = dumb_apply
        tqdm_pandas(tclass)
        df = DataFrame({'a': [1, 2, 3]})
        df.groupby('a').progress_apply(lambda x: x)

    test(tqdm())
    test(tqdm)



# Generated at 2022-06-22 04:48:57.867216
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm

    def dummy():
        return pandas.DataFrame(range(10))

    x = tqdm(dummy())
    tqdm_pandas(x)

    df = pandas.DataFrame(range(10000))
    df.groupby(df[0]).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:08.084905
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    tqdm.tqdm_pandas_deprecated()
    try:
        from tqdm import tqdm_notebook as tqdm
    except:
        print("tqdm_notebook not installed, using tqdm instead")
    else:
        try:
            from tqdm.contrib import tqdm_notebook
        except ImportError:
            pass
        else:
            try:
                from tqdm.contrib.notebook import tqdm_notebook
            except ImportError:
                pass
            else:
                tqdm = tqdm_notebook

    df = pd.DataFrame(np.random.randn(1000, 2), columns=['a', 'b'])
    t

# Generated at 2022-06-22 04:49:17.326668
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    if sys.version_info < (3, 0):
        import StringIO
        io = StringIO.StringIO()
    else:
        import io
        io = io.StringIO()

    with warnings.catch_warnings(record=True) as ws:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        tqdm_pandas(tqdm, file=io)
        # Verify some things
        assert len(ws) == 1
        assert issubclass(ws[-1].category, TqdmDeprecationWarning)

    with warnings.catch_warnings(record=True) as ws:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        tqdm_pandas

# Generated at 2022-06-22 04:49:27.252512
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm
    n = 10
    A = pd.DataFrame({'a': np.arange(n), 'b': np.arange(n)[::-1]})
    tqdm_pandas(tqdm(A.groupby('a').apply(lambda x: x)), ncols=80)
    #tqdm_pandas(tqdm(A.groupby('a')), ncols=80)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:40.369643
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import __version__
    from pandas import DataFrame

    df = DataFrame({'a': [12, 3, 1, 1, 4, 6, 9, 5, 8, 3]})
    group = df.groupby('a')

    arr = group.progress_apply(lambda x: x.mean())
    assert arr.loc[1] == 2.0
    assert arr.loc[3] == 3.0
    assert arr.loc[9] == 9.0
    pd_tqdm_version = getattr(group.progress_apply, 'tqdm_version', '')
    assert pd_tqdm_version == __version__


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:51.722809
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    def dummy_progress(self, *args, **kwargs):
        """Overrides pandas progress bar"""
        import tqdm
        tqdm.tqdm.__init__(self, *args, **kwargs)

    try:
        import pandas as pd
    except ImportError:
        return

    # Run to see if it makes any errors or exceptions
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, total=10)
    tqdm_pandas(tqdm, pandas_total=10)
    tqdm_pandas(tqdm().__class__)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(total=10))


# Generated at 2022-06-22 04:50:03.919296
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    ## Test setting an attribute
    tqdm.pandas(leave=True)
    assert tqdm.get_lock().leave
    ## Test automatic attribute reset
    tqdm.pandas()
    assert not tqdm.get_lock().leave
    ## Test illegal attributes
    with pytest.raises(ValueError):
        tqdm.pandas(leave=True, mininterval=0)
    ## Test old style
    with pytest.raises(DeprecationWarning):
        tqdm_pandas(tqdm.tqdm)
    ## Shortcut to tqdm_pandas
    tqdm_pandas(tqdm, leave=True)
    assert tqdm.get_lock().leave
    ## Shortcut to tqdm.tqdm_pandas


# Generated at 2022-06-22 04:50:06.023816
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    __test_tqdm_pandas()
    __test_tqdm_pandas(version=4)



# Generated at 2022-06-22 04:50:12.014614
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit tests of :func:`tqdm_pandas`."""
    try:
        import pandas as pd
        import numpy as np
        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
        df.groupby(0).progress_apply(lambda x: x**2)
    except ImportError:
        pass
    from tqdm.auto import trange

    trange(10).pandas()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:18.868947
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas()"""
    d = {'a': [1, 2, 3], 'b': [5, 6, 7]}
    df = pandas.DataFrame(d)

    # Insert a tqdm instance
    sys.modules['tqdm'] = tqdm
    tqdm_pandas(tqdm(total=len(df['a'])), df=df)



# Generated at 2022-06-22 04:50:28.263698
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """tqdm_pandas unit testing"""
    _ = tqdm_pandas
    from pandas import DataFrame
    from tqdm import tqdm
    # tqdm.pandas(tqdm_class=tqdm)  # deprecated
    # tqdm_pandas(tqdm)  # deprecated
    # tqdm_pandas(tqdm_class=tqdm)  # deprecated

    df = DataFrame((d for d in [{'a': 1, 'b': 2}]))
    df.groupby('b').progress_apply(lambda x: x)
    with tqdm(total=1) as t:
        df.groupby('b').progress_apply(lambda x: x, t=t)



# Generated at 2022-06-22 04:50:36.332747
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series

    # TODO: add assertion here when we find out how to test pandas progress_apply
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm, leave=False)
    tqdm_pandas(tqdm(), leave=False)
    tqdm_pandas(tqdm(total=10))
    tqdm_pandas(tqdm(), total=10)
    tqdm_pandas(tqdm, total=10)
    tqdm_pandas(tqdm(total=10), leave=False)

# Generated at 2022-06-22 04:50:38.571570
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    t = tqdm(total=100)
    tqdm_pandas(t)

# Generated at 2022-06-22 04:50:49.489285
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib import pandas
    from tqdm import tqdm_gui
    from tqdm import tnrange, tqdm
    try:
        from tqdm._tqdm_gui import TMonitor
    except ImportError:
        TMonitor = None

    if TMonitor is None:
        return

    def nop(x):
        pass

    def square(x):
        return x**2

    df = pd.DataFrame(np.random.randint(0, 10, size=(100000, 4)), columns=list('ABCD'))
    # Test in-form setup
    assert 'desc' not in tqdm_gui.__dict__
    tqdm_pandas(tqdm_gui)

# Generated at 2022-06-22 04:51:02.388974
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm import tqdm_pandas
    tqdm_pandas(t=True)

    def test_func(x):
        return x * 10

    df = DataFrame({'a': [1, 2, 3]})
    s = df.progress_apply(test_func)
    assert (s == df['a'] * 10).all()

    s = df.progress_apply(test_func, axis=1)
    assert (s == df['a'] * 10).all()

    s = df.progress_apply(test_func, axis=1, result_type='reduce')
    assert (s == df['a'].sum() * 10)

    s = df.progress_apply(test_func, axis=1, raw=True)

# Generated at 2022-06-22 04:51:11.568115
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    # DataFrame
    df = pd.DataFrame(np.random.randn(10000, 2))
    df.progress_apply(lambda x: x)
    df.progress_apply(lambda x: np.nanmedian(x))
    # Series
    s = pd.Series(np.random.randn(10000))
    s.progress_apply(lambda x: x)
    s.progress_apply(lambda x: np.nanmedian(x))
    # GroupBy
    df.groupby(0).progress_apply(lambda x: x)
    df.groupby(0).progress_apply(lambda x: np.nanmedian(x))
    # GroupBy on Series

# Generated at 2022-06-22 04:51:22.156543
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from random import randrange
    from tqdm import tqdm

    tqdm_pandas(tqdm, desc='grpby', leave=False, file=sys.stdout)

    df = pd.DataFrame({
        'x': [randrange(10) for _ in range(10000)],
    })
    for k, g in df.groupby('x'):
        for i in range(10):
            time.sleep(0.01)
            g.progress_apply(lambda x: x + i, axis=1)

    tqdm.pandas(tqdm, desc='grpby', leave=False, file=sys.stdout)

# Generated at 2022-06-22 04:51:30.107784
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test with no arguments
    tqdm_pandas(tqdm)
    # Test with keyword arguments
    tqdm_pandas(tqdm, total=10, desc='Testing for tqdm_pandas function')
    # Test with delayed arguments
    tqdm_pandas(tqdm_gui)
    # Test with delayed and keyword arguments
    tqdm_pandas(tqdm_gui, total=10, desc='Testing for tqdm_pandas function')
    # Delayed adapter case
    class tqdm_gui(tqdm):
        @classmethod
        def pandas(cls, *args, **kwargs):
            tqdm.pandas(*args, **kwargs)

# Generated at 2022-06-22 04:51:38.712668
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    def func_raise(x):
        raise RuntimeError("Oups")

    def func_sleep(x):
        from time import sleep
        sleep(0.01)
        return x

    def func_return(x):
        return x

    df = DataFrame({'a': range(10), 'b': range(10)})

    t = tqdm(total=10)
    tqdm_pandas(t)
    assert df.groupby('a').progress_apply(func_return) is not None
    t.close()

    t = tqdm(total=10)
    tqdm_pandas(t)
    assert df.groupby('a').progress_apply(func_sleep) is not None
    t.close()

# Generated at 2022-06-22 04:51:46.680466
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_notebook as tqdm

    try:
        from pandas import DataFrame, Series
    except ImportError:
        return

    df = DataFrame({'Integers': [1, 2, 3],
                    'Floats': [0.0, 0.1, 0.2]})
    # Test first with default init args
    tqdm_pandas(tqdm)
    ret = df.groupby('Integers').progress_apply(lambda _: 1)
    assert ret.equals(df)
    # Test with custom init args
    tqdm_pandas(tqdm, smoothing=1)
    ret = df.groupby('Integers').progress_apply(lambda _: 1)
    assert ret.equals(df)
    # Test incompatibility

# Generated at 2022-06-22 04:51:55.426699
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas

    for _ in tqdm_pandas(tqdm.trange(2), ascii=True, desc='foo'):
        pass
    for _ in tqdm_pandas(tqdm.trange(2), ascii=True):
        pass
    for _ in tqdm_pandas(tqdm.trange(2), ascii=True, total=4):
        pass

    for _ in tqdm_pandas(tqdm.tqdm, ascii=True, desc='foo'):
        pass
    for _ in tqdm_pandas(tqdm.tqdm, ascii=True):
        pass

# Generated at 2022-06-22 04:52:01.419189
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def square(x):
        from time import sleep
        sleep(0.01)
        return x**2

    df = pd.DataFrame({'x': range(10)})
    I = df.groupby(df['x'] % 2).progress_apply(square)
    assert all(I == df.groupby(df['x'] % 2).apply(square))

# Generated at 2022-06-22 04:52:07.546649
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test tqdm_pandas"""
    # Unicode
    try:
        tqdm_pandas(tqdm(total=1, desc=u'Ё'))
    except Exception:
        raise Exception("Failed to encode unicode correctly")
    # tqdm type
    try:
        tqdm_pandas(tqdm)
    except Exception:
        pass
    else:
        raise Exception("Unicode test failed")



# Generated at 2022-06-22 04:52:13.138007
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    data = pd.DataFrame({'a': range(0, 1000), 'b': range(0, 1000)})
    tqdm_pandas(tqdm, unit='rows', leave=False)
    data.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:52:25.072058
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from itertools import repeat
    from tqdm import tqdm_pandas, tqdm
    from pandas.util.testing import assert_frame_equal

    df = pd.DataFrame({'x': [1, 2, 3, 4, 5]})

    # single process
    tqdm_pandas(tqdm())  # register `pandas.progress_apply`
    tdf = df.progress_apply(lambda x: x)
    assert_frame_equal(df, tdf)

    # parallel
    tqdm_pandas(tqdm())
    tdf = df.progress_apply(lambda x: x, axis=1, num_workers=2)
    assert_frame_equal(df, tdf)

    # multiprocess
    t

# Generated at 2022-06-22 04:52:35.226912
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    # basic
    df = pd.DataFrame({'A': [0, 1, 2, 3], 'B': [2, 1, 2, 3], 'C': [0, 1, 2, 3]})

    for i in tqdm(df.groupby('A'), total=len(df.groupby('A'))):
        for j in tqdm(df.groupby('B'), total=len(df.groupby('B'))):
            for k in tqdm(df.groupby('C'), total=len(df.groupby('C'))):
                pass

    # creation of tqdm and tqdm_pandas

# Generated at 2022-06-22 04:52:43.912081
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    from pandas import DataFrame
    from pandas import Series

    with tqdm(total=None) as t:
        df = DataFrame({'x': [1, 2, 3, 4, 5],
                        'y': [4, 3, 4, 3, 5]})
        tqdm_pandas(t)
        df.groupby('y').progress_apply(lambda x: x)
        t.update(1)

    with tqdm(total=None) as t:
        df = DataFrame({'x': [1, 2, 3, 4, 5],
                        'y': [4, 3, 4, 3, 5]})
        tqdm_pandas(t, desc='gd')
        df

# Generated at 2022-06-22 04:52:54.770448
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _deprecated_alias
    from tqdm import trange

    # Test deprecated alias
    assert tqdm_pandas(tclass=trange, desc="test_tqdm_pandas") == \
        _deprecated_alias(tqdm_pandas, 'tqdm_pandas')

    # Test with deprecated argument `tqdm`
    t = trange(10)
    assert tqdm_pandas(t, desc="test_tqdm_pandas") == \
        t.pandas(desc="test_tqdm_pandas")

    # Test normal use case `tqdm.pandas(...)`
    t = trange(10)

# Generated at 2022-06-22 04:53:01.626254
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    @tqdm_pandas
    def parallel_apply(df, func, n_cores=8):
        df_split = np.array_split(df, n_cores)
        pool = Pool(n_cores)
        df = pd.concat(pool.map(func, df_split))
        pool.close()
        pool.join()
        return df

    df = pd.DataFrame({"A": [1, 2] * 100000})
    parallel_apply(df, lambda x: x)

# Generated at 2022-06-22 04:53:07.801646
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm(total=10), desc='tqdm_pandas function')

if __name__ == '__main__':
    test_tqdm_pandas()