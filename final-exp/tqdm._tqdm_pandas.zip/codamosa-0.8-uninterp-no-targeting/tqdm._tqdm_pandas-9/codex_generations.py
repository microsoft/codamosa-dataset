

# Generated at 2022-06-22 04:43:04.111125
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from time import sleep

    for pbar in [tqdm_pandas,
                 lambda tclass, **tqdm_kwargs: tqdm_pandas(tqdm(**tqdm_kwargs))]:
        pbar(tqdm)
        try:
            for df in pandas.read_csv('requirements.txt',
                                      chunksize=10,
                                      delimiter=' ',
                                      error_bad_lines=False):
                df.groupby('#').progress_apply(sleep, 5)
                pd.util.testing.assert_frame_equal(df, df)
        except Exception as e:
            if not isinstance(e, KeyboardInterrupt):
                raise

# Generated at 2022-06-22 04:43:09.868341
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    df = pd.DataFrame({'a': np.random.randn(100)})
    if hasattr(tqdm, 'pandas'):
        tqdm.pandas(tqdm.tqdm)
    else:
        import warnings
        warnings.warn("tqdm.pandas not found. Calling `tqdm_pandas(tqdm)`.")
        tqdm_pandas(tqdm)

    # Define a function to test for progress_apply:
    def param_squared(param):
        return param[0] * param[0]

    df.progress_apply(param_squared, axis=1)

if __name__ == "__main__":
    test

# Generated at 2022-06-22 04:43:21.376135
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_pandas
    from tqdm.contrib import DummyTqdmFile

    tqdm_pandas(tqdm)  # delayed adapter case
    tqdm_kwargs = dict(mininterval=0.1, smoothing=0.1, ascii=True, file=DummyTqdmFile())
    tqdm_pandas(tqdm, **tqdm_kwargs)  # delayed adapter case

    # Tests
    df = pd.DataFrame(dict(a=range(10), b=range(10)))
    import multiprocessing as mp
    assert df.a.progress_apply(lambda x: x * 2, **tqdm_kwargs).sum() == 90
    assert df

# Generated at 2022-06-22 04:43:32.676700
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas, trange
    from tqdm.autonotebook import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

    # `ProgressBar` does *not* automatically apply to `DataFrameGroupBy`
    df.groupby(0).progress_apply(lambda x: x**2)

    # Applies `tqdm_pandas` to `DataFrameGroupBy` and `ProgressBar` classes
    tqdm_pandas(tqdm)

    # Show progress bar while `progress_apply` processes `df`

# Generated at 2022-06-22 04:43:37.681266
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_notebook
    tqdm_notebook().pandas()


# Decorator for methods of pandas.core.groupby.DataFrameGroupBy

# Generated at 2022-06-22 04:43:50.487056
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm as tqdm_mod
    assert hasattr(tqdm_mod, 'pandas')

    try:
        from pandas import DataFrame
    except Exception as e:
        return

    ################
    #### tqdm.pandas
    ################

    with tqdm_mod.tqdm(total=1) as t:
        tqdm_mod.pandas(t)
        DataFrame().groupby("A").apply(lambda x: x)
        t.close()

    with tqdm_mod.tqdm(total=1) as t:
        tqdm_mod.pandas(t, leave=False)
        DataFrame().groupby("A").apply(lambda x: x)
        t.close()

# Generated at 2022-06-22 04:43:54.779271
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, tqdm_pandas
    tqdm_pandas(pd.DataFrame(np.random.random((10000, 3))).groupby(0).progress_apply(lambda x: x))

# Generated at 2022-06-22 04:44:05.859577
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Regression test for tqdm.pandas()."""
    import pandas as pd
    from tqdm.autonotebook import tqdm

    df = pd.DataFrame()
    pd.util.testing.assert_frame_equal(
        df.groupby(
            df.iloc[:, 0]).progress_apply(
            lambda x: True), df.groupby(
                df.iloc[:, 0]).apply(
            lambda x: True))
    pd.util.testing.assert_frame_equal(
        df.groupby(
            df.iloc[:, 0]).progress_apply(
            lambda x: True), df.groupby(
                df.iloc[:, 0]).apply(
            lambda x: True))

# Generated at 2022-06-22 04:44:16.048690
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    import pandas as pd
    df = pd.DataFrame({'a': [1, 2, 3], 'b': [1, 1, 1]})
    groups = df.groupby('b')

    def test_func(df):
        return df

    # test pandas v0.24.0
    with tqdm(total=len(groups)) as pbar:
        def progress(df):
            pbar.update(1)
            return test_func(df)

        result = groups.progress_apply(progress)
        assert (result == df).all().all()
    with tqdm(total=len(groups)) as pbar:
        def progress(_, df):
            pbar.update(1)
            return test_func(df)



# Generated at 2022-06-22 04:44:28.235119
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame(list(range(500)))
    with tqdm(df.groupby(0), desc="testing", file=sys.stdout, leave=False) as t:
        # Test internal `tqdm.pandas`
        pd.options.display.max_rows = 10
        assert str(df.groupby(0).progress_apply(lambda x: x)) == ""
        # Test `tqdm_pandas`
        pd.options.display.max_rows = None
        with tqdm_pandas(t) as T:
            assert str(df.groupby(0).progress_apply(lambda x: x)) == ""



# Generated at 2022-06-22 04:44:39.509813
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''
    Test whether tqdm_pandas detects
    '''
    with suppress(DeprecationWarning):
        tqdm_pandas(tqdm.tqdm)
        tqdm_pandas(tqdm.tqdm_notebook)
        tqdm_pandas(tqdm.trange)
        tqdm_pandas(tclass=tqdm.tqdm_notebook, bar_format='deprecated')
        tqdm_pandas(tqdm.tqdm)
    assert tqdm.tqdm.pandas.__module__ == "tqdm.pandas"

# Generated at 2022-06-22 04:44:49.108889
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    __all__ = ["test_tqdm_pandas"]

    from tqdm import tqdm, trange
    from tqdm.tests import tests as tqdmtests, _range, closing, tqdm_deprecation

    with closing(StringIO()) as our_file:
        with tqdm_deprecation():
            tqdm_pandas(_range(10), file=our_file)
            tqdm_pandas(tqdm(_range(10), file=our_file))
            tqdm_pandas(trange(10), file=our_file)
            tqdm_pandas(tqdm(file=our_file))
            # Non-matching fp
            tqdm_pandas(tqdm(file=StringIO()))

        #

# Generated at 2022-06-22 04:44:59.510905
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import TqdmDeprecationWarning, tqdm

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        tqdm_pandas(tqdm(disable=True))
        # Verify some things
        warning = w[-1]  # last item
        assert issubclass(warning.category, TqdmDeprecationWarning)
        assert "Please use `tqdm.pandas(...)`" in str(warning.message)
    return True


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:07.291670
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import warnings

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            tqdm_pandas(tqdm(leave=False,
                             disable=False))
            assert False  # pragma: no cover
    except TqdmDeprecationWarning:
        assert True  # pragma: no cover
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            tqdm_pandas(tqdm(leave=False,
                             disable=False,
                             total=1),
                        total=1)
            assert False  # pragma: no cover
    except TqdmDeprecationWarning:
        assert True  # pragma: no cover

# Generated at 2022-06-22 04:45:16.372849
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm_pandas, tqdm
    from tqdm import trange
    from pandas import DataFrame
    from random import randint
    from datetime import timedelta
    from time import sleep

    # Regression for #377
    df = DataFrame(np.random.randn(10, 3))
    for i in trange(4):
        df.rolling(window=3).sum()

    # Regression for #550
    df = DataFrame(np.random.randn(10, 3))
    for i in trange(4):
        # noinspection PyStatementEffect
        df.groupby(df.index // 3).agg(['sum', 'mean', 'max'])[0]

    # Regression for #720

# Generated at 2022-06-22 04:45:26.601611
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        import numpy
        from tqdm._tqdm import tqdm
    except ImportError:
        return

    a = [1, 2]
    tqdm_pandas(tqdm(a))
    tqdm_pandas(tqdm(a, total=2))
    # pass pandas groupby as iterator
    df = pandas.DataFrame({'a': [1, 2], 'b': ['a', 'b']})
    tqdm_pandas(tqdm(df.groupby('b')))
    tqdm_pandas(tqdm(df.groupby('b').progress_apply))
    # pass numpy array as iterator
    tqdm_pandas(tqdm(numpy.array([1, 2])))

# Generated at 2022-06-22 04:45:38.223932
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)),
                      columns=list('ABCDEF'))

    # We MUST use a nested function as the decorator
    # as the tqdm instance must be initiated within the
    # runtime of the decorated function.
    # This is because we want the kwargs for tqdm to be
    # dynamically generated at runtime.
    @tqdm_pandas
    def process_with_tqdm(df):
        tqdm.tqdm.pandas()
        df.groupby('A').progress_apply(lambda x: x**2)
        return df

    # assert that the try_tqdm functionality works

# Generated at 2022-06-22 04:45:49.643356
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    try:
        import pandas as pd
    except ImportError:
        return
    from tqdm.auto import tqdm

    d = {'col1': [1, 2, 3], 'col2': [4, 5, 6]}
    df = pd.DataFrame.from_dict(d)

    # First call should not raise warning
    tqdm_pandas(tqdm)
    # Second call should raise a warning
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)
    # Third call should not raise another warning
    tqdm_pandas(tqdm)

    # First call should not raise warning

# Generated at 2022-06-22 04:45:58.012553
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest

    def dummy_func(x):
        import time
        time.sleep(0.01)
        return x

    df = pd.DataFrame({'x': range(100)})

    # test 1: non-delayed tqdm
    with closing(StringIO()) as our_file:
        with tqdm.tqdm(total=len(df), file=our_file) as t:
            result = df.progress_apply(tclass=t, func=dummy_func)
        output = our_file.getvalue()
        assert "100/100" in output

    # test 2: delayed tqdm
    with closing(StringIO()) as our_file:
        t = tqdm.tq

# Generated at 2022-06-22 04:46:06.929798
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd
    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        from pandas.core.groupby import DataFrameGroupBy
    df = pd.DataFrame({'A': [1, 1, 1, 2, 2, 2],
                       'B': [1, 2, 3, 1, 2, 3]})
    # Unit test for tqdm_pandas(tqdm, **tqdm_kwargs)
    tqdm_pandas(tqdm, total=len(df))
    # Unit test for tqdm_pandas(type)
    tqdm_pandas(DataFrameGroupBy)


if __name__ == '__main__':
    test_tqdm_

# Generated at 2022-06-22 04:46:19.215316
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    df = pd.DataFrame(data=[1, 2, 3, 4, 5])
    for t in [tqdm.tqdm, tqdm.tqdm_notebook, tqdm.tqdm_gui]:
        try:
            tqdm_pandas(t, file=sys.stdout, ncols=80)
            tqdm_pandas(type(tclass), tqdm_kwargs={'file': sys.stdout})
            df.groupby(df.index).progress_apply(lambda x: x**2)
        except Exception as e:
            raise e

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:30.536519
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Tests the tqdm_pandas() function. """

    try:
        import pandas as pd
    except ImportError:
        return
    try:
        from tqdm import tqdm_pandas
    except ImportError:
        from tqdm.contrib import tqdm_pandas

    # tqdm_pandas(tqdm(...))
    for _ in tqdm_pandas(range(1000)):
        pass

    # tqdm_pandas(tqdm)
    for _ in tqdm_pandas.tqdm(range(1000)):
        pass

    # tqdm_pandas(...)
    tqdm_pandas()
    tqdm_pandas(desc='testing tqdm_pandas')



# Generated at 2022-06-22 04:46:40.492737
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test function `tqdm_pandas`"""
    import pandas as pd, numpy as np

    # Test Pandas Series
    pd.Series(np.random.randn(1000)).progress_apply(lambda x: x)
    pd.Series(np.random.randn(1000)).progress_apply(lambda x: x, axis=1)

    # Test Pandas DataFrame
    pd.DataFrame(np.random.randn(1000, 4)).progress_apply(
        lambda x: x, axis=1)

    # Test Pandas GroupBy
    pd.DataFrame(np.random.randn(1000, 4)).groupby(
        0).progress_apply(lambda x: x)

# Generated at 2022-06-22 04:46:50.423974
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .tqdm import tqdm
    from datetime import datetime as dt
    import pandas as pd
    import numpy as np

    def dummy_to_tqdm(x):
        pd.DataFrame({'A': [1], 'B': [2], 'C': [3]}).apply(
            lambda row: tqdm(row.iteritems(), total=len(row), leave=False),
            axis=1)

    def _test_tqdm_pandas(progress_bar_type):
        t_start = dt.now()
        # Test Multi-index
        df = pd.DataFrame({'A': [1, 1, 2, 2], 'B': [1, 2, 3, 4], 'C': np.random.randn(4)})
        df2 = df

# Generated at 2022-06-22 04:47:01.943963
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    if sys.version_info[:2] >= (3, 0):
        from pandas import Series, DataFrame
        import numpy as np
        series1 = Series([1, 2, 3, 4, 5, 6],
                         index=['a', 'b', 'c', 'd', 'e', 'f'])
        series2 = Series([5, 6, 7, 8, 9, 10],
                         index=['a', 'b', 'c', 'd', 'e', 'f'])
        s = DataFrame({'series1': series1, 'series2': series2})

        def func(s):
            return s + 2

        def func_mp(s):
            import time
            import numpy as np

# Generated at 2022-06-22 04:47:13.361190
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:47:20.866361
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def test_func(df):
        return df.groupby('A').apply(lambda x: np.sum(x.B))

    df = pd.DataFrame({'A': [1, 1, 2, 2, 2], 'B': np.random.rand(5)})
    result = df.groupby('A').progress_apply(test_func)
    assert result.equals(df.groupby('A').apply(lambda x: np.sum(x.B)))



# Generated at 2022-06-22 04:47:27.888537
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas
    pandas.DataFrame(dict(x=range(100))).groupby(['x']).progress_apply(lambda x: x)
    tqdm.pandas(desc='dummy')
    pandas.DataFrame(dict(x=range(100))).groupby(['x']).progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:38.600019
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # Generate random input DataFrame
    df = pd.DataFrame({'a': list(range(1000)), 'b': list(range(1000))})
    iteration_length = len(df.groupby('a'))

    # Test deprecated tqdm_pandas
    foo = tqdm_pandas(tqdm(total=iteration_length, disable=True), desc='desc')
    foo = tqdm_pandas(tqdm(total=iteration_length, disable=True), desc='desc')
    foo = tqdm_pandas(tqdm(total=iteration_length, disable=False), desc='desc')

# Generated at 2022-06-22 04:47:49.993244
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        a = pd.DataFrame({'x': [1, 1, 1, 1, 1],
                          'y': [1, 2, 3, 4, 5],
                          'z': [6, 5, 4, 3, 2]})
        bar = a.groupby('x').progress_apply(lambda x: np.array([np.sum(x['y'])]))
        pd.testing.assert_frame_equal(bar, pd.DataFrame({'x': [1, 1, 1, 1, 1],
                                                         'y': [1, 2, 3, 4, 5],
                                                         'z': [6, 5, 4, 3, 2]}))
    except ImportError:  # pragma: no cover
        pass

# Generated at 2022-06-22 04:48:00.215948
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.contrib import pandas
    df = pd.DataFrame(dict(a=[1, 2, 3], b=[4, 5, 6]))
    df.groupby('a').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:10.476280
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from tqdm.auto import tqdm, trange
    # tqdm + pandas
    with tqdm(total=0, leave=False) as t:
        try:
            assert not t.disable
            df = DataFrame({'a': range(5), 'b': range(5)})
            df.groupby('a').progress_apply(lambda x: x)
        except:
            raise
        finally:
            t.close()
            assert t.disable
    # trange + pandas

# Generated at 2022-06-22 04:48:20.479635
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    try:
        import pandas_datareader
    except ImportError:
        import io
        import requests

        r = requests.get('https://archive.ics.uci.edu/ml/machine-learning-databases/'
                         'heart-disease/processed.switzerland.data')
        r.raise_for_status()
        r.encoding = 'utf-8'
        df = pd.read_csv(io.StringIO(r.text), header=None)
        df.columns = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
                      'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'num']
        df['thal']

# Generated at 2022-06-22 04:48:27.616185
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import pandas
    from tqdm.contrib.pandas import tqdm_pandas
    df = pandas.DataFrame({'x': list(range(50))})

    # Check that the deprecated tqdm_pandas function still works
    tqdm_pandas(pandas.tqdm, pandas.DataFrameGroupBy.progress_apply, df.groupby('x'))

# Generated at 2022-06-22 04:48:38.081872
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd 
    from tqdm import tqdm
    # Disable pandas progress bar for demo purpose
    pd.core.groupby.DataFrameGroupBy.progress_apply = lambda *x: x[-1]
    tqdm_pandas(tqdm(total=3))
    result = pd.core.groupby.DataFrameGroupBy.progress_apply(None, lambda x: None)
    assert result is None
    tqdm_pandas(tqdm)
    result = pd.core.groupby.DataFrameGroupBy.progress_apply(None, lambda x: None)
    assert result is None

# Generated at 2022-06-22 04:48:50.133679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd, numpy as np
    from tqdm import tqdm
    from tqdm.pandas import tqdm as tqdm_pandas

    # unregister `tqdm_pandas` for unit-testing
    tqdm_pandas.unregister()

    # create a huge random pandas dataframe
    df = pd.DataFrame(np.random.rand(100, 10000))

    # apply a function (that just double the values) using tqdm_pandas
    df.progress_apply(lambda x: x * 2)

    # apply a function (that just double the values) using tqdm_pandas
    # and change the tqdm default arguments
    with tqdm(total=df.shape[1], leave=False) as t:
        t

# Generated at 2022-06-22 04:49:00.419033
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import random
    N = 5
    M = 10
    try:
        import numpy as np
        if int(np.__version__.split(".")[1]) < 16:
            print("Numpy >= 1.16 required for `tqdm.pandas`")
    except ImportError:
        print("Numpy required for `tqdm.pandas`")
        return
    try:
        colorama
    except NameError:
        colorama = None

    with tqdm_pandas(total=N * M) as pbar:
        df = pd.DataFrame(
            {'a': [random.randint(0, M) for _ in range(N)
                   ], 'b': [random.randint(0, M) for _ in range(N)]})

# Generated at 2022-06-22 04:49:07.053957
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    try:
        import sklearn
    except:
        pass
    try:
        import scikit_learn
    except:
        pass
    data = pd.DataFrame(np.random.random((100, 100)))
    data.groupby(0).progress_apply(lambda x: x**2)
    data.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-22 04:49:16.813823
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.contrib.test import _test_tqdm_pandas
    import tqdm.contrib.test as tct

    # Test regular case
    _test_tqdm_pandas(tqdm_pandas)

    # Test `.progress_apply` case
    _test_tqdm_pandas(tqdm_pandas,
                      use_progress_apply=True)
    # Test `.progress_apply` case with tqdm parameter
    _test_tqdm_pandas(tqdm_pandas,
                      use_progress_apply=True,
                      tqdm=tct.tqdm)

    # Test delayed adapter

# Generated at 2022-06-22 04:49:21.595489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm._tqdm_pandas import tqdm as tqdm_pandas
    from tqdm import tqdm_gui

    # Test with DataFrameGroupBy.progress_apply
    def test_dfgb_apply(dfgb):
        def inner(df):
            # Some example from the doc
            return pd.Series({'x': df['x'].sum()})
        return dfgb.progress_apply(inner)

    dfgb = pd.DataFrame({'x': np.random.randint(0, 1000, 1000)}).groupby(['x'])
    with tqdm_pandas(total=len(dfgb)):
        test_dfgb_apply(dfgb)

    # Test with DataFrame.progress

# Generated at 2022-06-22 04:49:32.333183
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    pd.set_option("display.max_rows", 500)
    pd.set_option('display.width', 320)


# Generated at 2022-06-22 04:49:44.380835
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    try:
        from numpy.random import normal
    except ImportError:
        def normal(*args, **kwargs):
            from random import normalvariate
            return normalvariate(*args, **kwargs)

    N = 1000
    df = DataFrame({'a': normal(size=N), 'b': normal(size=N), 'c': normal(size=N)})

    def my_transform(x):
        return x

    # test with tqdm_notebook

# Generated at 2022-06-22 04:49:53.150196
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Import pandas only if needed to save time
    from pandas import DataFrame, Series
    from numpy.random import randn
    from numpy import arange
    df = DataFrame(randn(10, 2), columns=['A', 'B'])
    df.groupby('A').progress_apply(lambda x: x)
    df = DataFrame(arange(15), columns=['A'])
    df.groupby('A').progress_apply(lambda x: x)
    df = DataFrame(arange(15), columns=['A'])
    df.progress_apply(lambda x: x)
    s = Series(arange(15))
    s.progress_apply(lambda x: x)
    s.progress_apply(lambda x: x, axis=1)


# Generated at 2022-06-22 04:49:57.716919
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(None, total=1)
    import tqdm
    tqdm_pandas(tqdm.tqdm, total=1)



# Generated at 2022-06-22 04:50:01.829309
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    df = pd.DataFrame(list(zip(list(range(10)), list(range(10, 20)))),
                      columns=['a', 'b'])
    result = df.groupby('a').progress_apply(lambda x: x)

    assert len(result) == 10



# Generated at 2022-06-22 04:50:12.824600
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame(['a', 'b', 'c'], columns=['col_1'])

    def add_SOS(x):
        return 'SOS' + x # random function

    # Check with correct usage
    tqdm_pandas(tqdm)
    df.progress_apply(add_SOS) # should be fine

    # Check with deprecated usage
    tqdm_pandas(tqdm(leave=False)) # should be fine

    tqdm_pandas(tqdm)
    # Check with wrong usage
    tqdm_pandas(tqdm(leave=False)) # raises a warning

if __name__ == '__main__':
    test_tqdm_pand

# Generated at 2022-06-22 04:50:21.031263
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tnrange
    from pandas import Series

    for tclass in (tnrange,):
        tqdm_pandas(tclass)
        with tclass(10) as t:
            Series(range(10)).progress_apply(lambda x: x**2,
                                             meta={'total': 10})
            assert t.total == 10
            assert t.n == 10
            # TODO: Test pandas.core.groupby.DataFrameGroupBy.progress_apply


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:32.034366
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas
    """
    import pandas as pd
    import numpy as np
    import tqdm.auto as tqdm

    try:
        # Python 3
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    try:
        # In Python 3 we can use a context manager
        from contextlib import ExitStack
    except ImportError:
        # But in Python 2, we emulate one
        class ExitStack(object):
            def __init__(self):
                self._exit_stack = []

            def __enter__(self):
                return self

            def __exit__(self, *args):
                exception = args[0] is not None

# Generated at 2022-06-22 04:50:41.995629
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise
    import numpy as np
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    df = pd.DataFrame({'a': np.random.randint(0, 10, 100),
                       'b': np.random.randint(0, 10, 100),
                       'c': np.random.randint(0, 10, 100)})
    # test `progress_apply`
    with tqdm(total=len(df)) as t:
        df.progress_apply(lambda x: len(x), axis=1, result_type='reduce')
        t.close()

    # test `progress_agg`
    with tqdm(total=len(df)) as t:
        df

# Generated at 2022-06-22 04:50:51.213068
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    # Test with DataFrameGroupBy.progress_apply
    df = pd.DataFrame({'id_1': [1, 1, 1, 2, 2, 2, 3, 3, 3],
                       'id_2': [1, 2, 3, 1, 2, 3, 1, 2, 3],
                       'value': range(9)})
    df2 = df.groupby(['id_1', 'id_2']).progress_apply(sum)

    # Test with DataFrame.progress_apply

# Generated at 2022-06-22 04:51:08.986303
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import trange
    for n in trange(2):
        pd.DataFrame([1, 2, 3]).groupby(0).progress_apply(lambda x: x)

# Generated at 2022-06-22 04:51:13.800935
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import tqdm
    print("pandas: {}".format(pd.__version__))
    try:
        pd.DataFrame({'a': [1] * 1000}).groupby('a').progress_apply(lambda x: x)
    except Exception:
        tqdm_pandas(tqdm())
        pd.DataFrame({'a': [1] * 1000}).groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:51:22.767852
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    TqdmDeprecationWarning("").write = str
    try:
        from tqdm import trange
    except:
        trange = range
    try:
        import pandas
    except:
        pandas = None
        return
    assert not hasattr(pandas.core.groupby.DataFrameGroupBy, '_tqdm_writer')

    # test delayed tqdm adapter case
    tqdm_pandas(range, **{'total': 100})

    assert hasattr(pandas.core.groupby.DataFrameGroupBy, '_tqdm_writer')
    cnt = 0
    file = io.StringIO()

    def on_apply(x):
        nonlocal cnt
        cnt += 1
        if cnt == 50:
            raise ValueError("TEST")

   

# Generated at 2022-06-22 04:51:30.434893
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import pandas.util.testing as tm
    from tqdm import tqdm, trange, tqdm_notebook

    # Check options
    opts = tqdm_pandas.__defaults__

    df = pd.DataFrame(data={"A": [1,2,3,4], "B": [5,6,7,8]})
    df.groupby(["A"]).progress_apply(lambda x: x)
    for t in [tqdm, trange, tqdm_notebook]:
        tqdm_pandas(t, **opts)
        df.groupby(["A"]).progress_apply(lambda x: x)
        tqdm_pandas.reset()

# Generated at 2022-06-22 04:51:38.970951
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import io

    class DummyTqdmFile(io.StringIO):
        """
        Dummy file-like that will write to tqdm's file.
        """
        def __init__(self, file):
            self.file = file
            super(DummyTqdmFile, self).__init__()

        def write(self, x):
            # Avoid print() second call (useless \n)
            if len(x.rstrip()) > 0:
                tqdm.write(x, file=self.file)

    def monkeypatch_pandas():
        """
        Monkepatch pandas.core.groupby.DataFrameGroupBy
        and replace `progress_apply` with `tqdm_pandas(tqdm(...))`.
        """

# Generated at 2022-06-22 04:51:49.743992
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas.
    """
    import tqdm
    import numpy as np
    import pandas as pd
    from pandas import DataFrame

    df = DataFrame({"a": np.random.randn(100), "b": np.random.randn(100), "c": np.random.randn(100)})

    # Test error case (integer)
    try:
        tqdm_pandas(df.groupby("a").progress_apply(len))
    except Exception:
        pass

    # Test error case (type)
    try:
        tqdm_pandas(type(None))
    except Exception:
        pass

    # Test tqdm_pandas with tclass

# Generated at 2022-06-22 04:51:59.879917
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm, tqdm_pandas

    try:
        import numpy
    except ImportError:
        return

    pdf = pandas.DataFrame(numpy.random.rand(1000, 2))
    for cls in [tqdm, tqdm_pandas]:
        tqdm_pandas(cls)
        pdf.progress_apply(lambda x: numpy.sum(x))


if __name__ == '__main__':
    import nose
    nose.runmodule(argv=[__file__, '-vvs', '-x', '--pdb', '--pdb-failure'],
                   exit=False)

# Generated at 2022-06-22 04:52:10.058652
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas as tqdm_pandas
    import pandas as pd
    global tqdm
    tqdm = tqdm_pandas

    df = pd.DataFrame(dict(
        a=[1, 2, 3] * 1000 + [1, 3, 2],
        b=list(range(100)) * 10,
        c=[1] * 100000))
    assert (df.groupby(
        'c').progress_apply(lambda x: x.a.sum()).cumsum() ==
            pd.Series(range(1, 100001))).all()
    assert (df.groupby(
        'a').progress_apply(lambda x: x.b.sum()).cumsum() ==
            pd.Series(range(100000))).all()

# Generated at 2022-06-22 04:52:20.978774
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import pandas
    for pd in [0, 1]:
        if pd:
            from pandas import DataFrame
            from pandas import Series
            from tqdm import tqdm
            from tqdm import tqdm_gui
        else:
            from pandas import *
            from tqdm import *
            # from tqdm import tqdm_notebook  # not available on pypi
        df = DataFrame(dict(a=Series(range(1000)), b=Series(range(1000))))
        tqdm_pandas(tqdm)
        tqdm.pandas()
        df.groupby('a').progress_apply(lambda x: x)
        tqdm_pandas(tqdm_gui)
       

# Generated at 2022-06-22 04:52:27.697681
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for tqdm_pandas()"""
    class dummy:
        def __init__(self, *args, **kwargs):
            self.name = 'dummy'
            self.args = args
            self.kwargs = kwargs

        @classmethod
        def pandas(cls, *args, deprecated_t=None, **kwargs):
            name = deprecated_t.name if deprecated_t else cls.__name__
            args = deprecated_t.args if deprecated_t else args
            kwargs = deprecated_t.kwargs if deprecated_t else kwargs
            return name, args, kwargs

    # direct case

# Generated at 2022-06-22 04:52:54.067578
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmDeprecationWarning
    from pandas import DataFrame

    try:
        tqdm_pandas(tqdm)
    except TqdmDeprecationWarning:
        tqdm_pandas(tqdm, unit='iter')
    else:
        raise AssertionError('tqdm_pandas(tqdm) should fail!')

    try:
        tqdm_pandas(tqdm, unit='iter')
    except TqdmDeprecationWarning:
        pass
    else:
        raise AssertionError('tqdm_pandas(tqdm, unit=\'iter\') should fail!')

    # Test if the function works
    df = DataFrame({'x': [1, 2, 3, 4]})


# Generated at 2022-06-22 04:53:00.336436
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import numpy as np
    import pandas as pd

    n = 1000
    df = pd.DataFrame({"a": np.arange(n),
                       "b": np.random.randn(n),
                       "c": np.random.normal(size=n)})

    # Use tqdm_pandas with a tqdm class
    tqdm_pandas(tqdm)

    # Use tqdm_pandas with an instantiated object
    tqdm_pandas(tqdm(total=n))

    with tqdm(total=n) as t:
        df.groupby("b").progress_apply(t.update)
