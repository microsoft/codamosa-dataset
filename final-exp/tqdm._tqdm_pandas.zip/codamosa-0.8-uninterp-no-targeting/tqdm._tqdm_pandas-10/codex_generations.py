

# Generated at 2022-06-22 04:43:14.718510
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm

    # Make a test data frame
    n = 10000
    index = pd.date_range('1/1/2000', periods=n)
    ts = pd.Series(np.random.randn(n), index=index)

    # Apply to pandas grouped data
    for i in tqdm(range(n), desc='t1'):
        ts.groupby(pd.Grouper(freq='A')).mean()

    # Apply to pandas series
    for i in tqdm(range(n), desc='t2'):
        ts.apply(lambda x: x ** 2)

    # Apply to pandas data frame

# Generated at 2022-06-22 04:43:18.119071
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        tqdm_pandas(tqdm(total=15, desc='test'))
        assert False
    except TqdmDeprecationWarning:
        assert True

# Generated at 2022-06-22 04:43:29.425132
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .std import tqdm_pandas
    from pandas import DataFrame
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(), total=100)
    try:
        tqdm_pandas(tqdm(), total=0)
    except ValueError:
        pass
    else:
        raise ValueError

    try:
        tqdm_pandas(tqdm())
    except ValueError:
        pass
    else:
        raise ValueError

    test_apply_df = DataFrame({'a': [1, 2, 3], 'b': [1, 2, 3]})
    test_apply_df.groupby('a').progress_apply(lambda x: x)
    test_apply_df

# Generated at 2022-06-22 04:43:35.217031
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({'a': np.arange(10000),
                       'b': np.random.randint(0, 10000, 10000)})
    try:
        import IPython
        ip_shell = True
    except ImportError:
        ip_shell = False
    if not ip_shell:
        return  # exit
    from tqdm import tqdm, tqdm_gui
    # tqdm_gui(leave=True)
    # tqdm_gui(leave=True, position=1)

    # Register instance
    # tqdm_pandas(tclass=tqdm_gui)

    # Register class
    tclass_gui = tqdm_gui.__class__

# Generated at 2022-06-22 04:43:43.271079
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmTypeError

    tqdm_pandas(tqdm(leave=False, desc='x', total=0))
    try:
        tqdm_pandas(tqdm(total=0, desc='x'))
        assert False
    except TqdmTypeError:
        pass

    try:
        tqdm_pandas(tqdm(leave=False, desc='x'))
        assert False
    except TqdmTypeError:
        pass

    try:
        tqdm_pandas(tqdm(total=0))
        assert False
    except TqdmTypeError:
        pass


# Generated at 2022-06-22 04:43:53.264401
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # Dummy dataframe
    df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6], "C": [7, 8, 9]})

    # Test the function will raise warning
    with tqdm.external_write_mode():
        tqdm_pandas(tqdm)

    # Test delay adapter
    with tqdm.external_write_mode():
        tqdm_pandas(tclass=tqdm.tqdm)

    # Test the function will not raise warning
    with tqdm.external_write_mode():
        tqdm_pandas(tqdm(df))


# Register the adapter

# Generated at 2022-06-22 04:44:04.122640
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas.core.groupby as gb
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm_pandas)
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm)
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(type(tqdm()))
    assert 'progress_apply' in dir(gb.DataFrameGroupBy)
    assert 'pandas' in type(tqdm()).__dict__
    assert tqdm_pandas.__doc__ is not None


del sys, pytest

# Generated at 2022-06-22 04:44:14.635555
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm_kwargs = dict(total=len(df), miniters=1, smoothing=0.1,
                       leave=False, dynamic_ncols=True,
                       desc="tqdm_pandas")
    import tqdm
    tqdm_pandas(tqdm.tqdm, **tqdm_kwargs)
    mean_length = df.progress_apply(len).mean()
    assert np.allclose(mean_length, 6)

# Function tqdm_pandas should be deprecated
test_tqdm_pandas()

# Generated at 2022-06-22 04:44:26.028048
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return None

    @tqdm_pandas(tclass=tqdm)
    def square(df):
        return pd.DataFrame({c: df[c] ** 2 for c in df})

    df = pd.DataFrame({'a': range(10), 'b': range(10)})

    # test tqdm instance is registered
    square(df)

    # unregister tqdm
    type(tqdm).pandas(unregister_tclass=tqdm)

    # test tqdm instance is unregistered
    with pytest.raises(AttributeError):
        square(df)

# Generated at 2022-06-22 04:44:36.331236
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    progress = tqdm(total=5, desc='progress')
    df = pd.DataFrame({
        'a': [1, 2, 3, 4, 5],
        'b': [5, 4, 3, 2, 1],
    })
    df['sum'] = df.progress_apply(lambda row: row.a + row.b, axis=1,
                                  progress_kwargs={'t': progress})
    progress.close()

    progress = tqdm(total=5, desc='progress')
    df = pd.DataFrame({
        'a': [1, 2, 3, 4, 5],
        'b': [5, 4, 3, 2, 1],
    })

# Generated at 2022-06-22 04:44:48.033265
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:44:59.431430
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Tests that the above function registers the pandas.core.groupby.DataFrameGroupBy.progress_apply hook
    # with any tqdm instance, whether created with `tqdm(...)` directly, or with `tqdm.tqdm(...)`,
    # or with `tqdm.tqdm_notebook(...)`

    import math
    from tqdm import tqdm, trange, tqdm_notebook
    from tqdm.pandas import tqdm_pandas
    import pandas as pd

    # Create a tqdm instance
    # t = tqdm(total=100, dynamic_ncols=True)
    # t = trange(100, dynamic_ncols=True)
    # t = tqdm_notebook(total=100, dynamic_ncols

# Generated at 2022-06-22 04:45:07.242344
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    #from tqdm import tqdm

    n = 100000
    df = pd.DataFrame(
        {'x': np.random.uniform(0, 1, size=(n, )),
         'y': np.random.uniform(0, 1, size=(n, ))}
    )

    #print(df.groupby(pd.cut(df.x, np.linspace(0, 1, 11))).progress_apply(lambda x: x.y.sum()))
    #tqdm_pandas(tqdm(leave=False, dynamic_ncols=True))
    #print(df.groupby(pd.cut(df.x, np.linspace(0, 1, 11))).progress_apply(lambda x: x.

# Generated at 2022-06-22 04:45:12.972330
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import numpy as np

    data = pd.DataFrame({'x': np.random.rand(100),
                         'y': np.random.rand(100)})
    data_group = data.groupby('x')
    data_group.progress_apply(lambda x: x)

    # no infinite loop with deprecated function
    tqdm_pandas(tqdm.tqdm)

# Generated at 2022-06-22 04:45:21.377050
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy import random
    from pandas import date_range
    try:
        # unit test for pandas.core.groupby.DataFrameGroupBy.progress_apply
        df = DataFrame({'A': random.randint(0, 10, 10),
                        'B': [date_range(2008, periods=10)]})
        with tqdm_pandas(total=len(df)) as t:
            df.groupby('A').progress_apply(lambda x: x)
    except Exception:
        pass

# Generated at 2022-06-22 04:45:31.397288
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    import tqdm

    # Enables the 'tqdm_pandas' wrapper
    tqdm.pandas()

    # Convert the "Iris" data set to a DataFrame object
    iris_data = pandas.read_csv("../examples/iris.csv")

    # Enables the 'tqdm_pandas' wrapper
    tqdm.pandas()

    # Converts the data to a string
    iris_data['species'] = iris_data['species'].apply(str)

    # Converts the data to a string

# Generated at 2022-06-22 04:45:42.031364
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_notebook

    tqdm.pandas()
    tqdm_notebook().pandas()
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)

    # Test Pandas DataFrameGroupBy progress bar
    df = pd.DataFrame()
    df['x'] = [i for i in range(5)]
    df['y'] = [i for i in range(5, 10)]
    tqdm.pandas(desc='test')
    df.groupby('x').progress_apply(lambda x: x)

    # Test Pandas SeriesGroupBy progress bar
    df = pd.DataFrame()

# Generated at 2022-06-22 04:45:48.072796
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    tqdm.tqdm = tqdm_pandas(tqdm.tqdm)
    df = pd.DataFrame((np.random.rand(1000, 1000)), columns=list('abcdefghij'))
    df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:45:58.492780
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test `tqdm_pandas(tclass, *tqdm_args, **tqdm_kwargs)` function.
    """
    from .main import tqdm
    import pandas as pd

    # Test for vanilla `tclass`
    t = tqdm(total=10)
    with t:
        tqdm_pandas(t)
    with pytest.raises(AttributeError):
        t.close()  # we just closed the `tqdm.tqdm` instance

    # Test for `tqdm(tclass, ...)` adapter
    t = tqdm(total=10)
    with t:
        tqdm_pandas(tqdm(t))  # note the wrapping

# Generated at 2022-06-22 04:46:04.040520
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    lag = 10**9
    df = pd.DataFrame(np.random.rand(lag, 2))
    with tqdm_pandas(total=len(df)) as t:
        _ = df.progress_apply(lambda x: x + 1)
        t.update()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:10.792343
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm as tqdm_class
    import pandas as pd

    def test_mean():
        """
        Unit test for pandas.core.groupby.DataFrameGroupBy.progress_apply.
        """
        from collections import OrderedDict
        from pandas import DataFrame

        df = DataFrame(
            OrderedDict([(a, range(100)) for a in map(chr, range(65, 91))])
        )
        df_grouped = df.groupby('A')

# Generated at 2022-06-22 04:46:17.236644
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm, pandas=True)
    tqdm_pandas(tqdm, pandas=False)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(pandas=True))
    tqdm_pandas(tqdm(pandas=False))
    tqdm_pandas(tqdm())

# Generated at 2022-06-22 04:46:25.820241
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def test_apply(df):
        return df.progress_apply(lambda x: 1, axis=1)
        # return df['value'].progress_apply(lambda x: 1)

    df = pd.DataFrame({'value': np.random.randn(100)})
    df.groupby(df.value > 0).progress_apply(test_apply)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:31.177374
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        tqdm_pandas(TqdmTypeError)  # should raise TqdmTypeError
    except:
        pass
    try:
        tqdm_pandas(tqdm(TqdmTypeError))  # should raise TqdmTypeError
    except:
        pass
    try:
        tqdm_pandas(tqdm_gui(TqdmTypeError))  # should raise TqdmTypeError
    except:
        pass

# Generated at 2022-06-22 04:46:37.287273
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import numpy as np
    from pandas import DataFrame
    from tqdm.contrib.pandas import tqdm_pandas

    df = DataFrame(np.random.rand(1000000, 4))
    with tqdm_pandas() as progress:
        df.progress_apply(lambda x: x**2)

# Generated at 2022-06-22 04:46:44.382578
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm.auto import trange

    pd_dfg = DataFrame({'x': range(10)}).groupby('x')

    try:
        # Check that tqdm_pandas registers tqdm object
        with trange(3) as t1:
            tqdm_pandas(t1)
            pd_dfg.progress_apply(lambda x: x)  # no exception
    finally:
        del pd_dfg.progress_apply


# Generated at 2022-06-22 04:46:52.663825
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_notebook
    from .tqdm import tqdm

    A_ = np.random.randint(5, size=1000)
    B_ = np.random.randint(5, size=1000)
    df = pd.DataFrame({'A': A_, 'B': B_})
    groups = df.groupby('A')

    def add(df):
        return df.sum()

    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, bar_format='{l_bar}')
    tqdm_pandas(tqdm, total=len(groups))
    tqdm_pandas(tqdm, unit_scale=True)

# Generated at 2022-06-22 04:46:58.974055
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas """
    import tqdm
    tqdm_pandas(tqdm.tqdm)
    if not hasattr(tqdm.tqdm, "pandas"):
        raise Exception("tqdm.tqdm has no attribute 'pandas'")


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:02.955343
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    df = pd.DataFrame({'x': np.linspace(0, 10, 10000000)})
    tqdm_pandas(tqdm(total=len(df)))
    df.groupby(0).progress_apply(lambda x: x**2)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:13.572564
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import unittest
    import pandas as pd

    class TqdmPandasTest(unittest.TestCase):
        def test_basic(self):

            def tqdm_func(pdf):
                return pdf.sum()

            # Test with DataFrameGroupBy.progress_apply
            def tqdm_apply(df):
                pgb = df.groupby('x')
                return pgb.progress_apply(tqdm_func)

            tqdm_kwargs = {'miniters': 1, 'desc': 'tqdm_apply'}

            # Test without TqdmTypeError
            df = pd.DataFrame({'x': [1, 2, 2, 3], 'y': [4, 5, 6, 7]})

# Generated at 2022-06-22 04:47:27.997615
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    tclass = tqdm_pandas()

# Generated at 2022-06-22 04:47:33.011679
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pytest
    import numpy as np
    import pandas as pd

    df = pd.DataFrame(np.random.random((10, 10)))
    # test tqdm_pandas(DeprecatedPandas(...))
    try:
        tqdm_pandas(tqdm_pandas(tqdm()))
    except Exception as e:
        pytest.fail("Exception: {}".format(e))
    # test tqdm_pandas(DeprecatedPandas)
    try:
        tqdm_pandas(tqdm_pandas)
    except Exception as e:
        pytest.fail("Exception: {}".format(e))
    # test for delayed adapter case

# Generated at 2022-06-22 04:47:44.432266
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from itertools import count
    from tqdm import tqdm
    from pandas import DataFrame
    from numpy.random import randint

    tqdm.pandas(desc="idx")

    for _ in tqdm(range(5)):
        DataFrame({'a': randint(0, 100, 100), 'b': randint(0, 100, 100)}).groupby('a').progress_apply(lambda _: _ + 1)

    tqdm.pandas(desc="total")

    for _ in tqdm(range(5)):
        DataFrame({'a': randint(0, 100, 100), 'b': randint(0, 100, 100)}).groupby('a').progress_apply(lambda _: _ + 1)

    tqdm.pandas(desc="none")



# Generated at 2022-06-22 04:47:54.845015
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm

    a = tqdm.tqdm_pandas(tqdm.tqdm())
    if a is None:
        raise RuntimeError(
            "tqdm_pandas(tqdm(...)) didn't register with pandas.groupby")
    if not a.is_notified:
        raise RuntimeError(
            "tqdm_pandas(tqdm(...)) didn't warn about deprecation")

    a = tqdm.tqdm_pandas(tqdm.tqdm)
    if a is None:
        raise RuntimeError(
            "tqdm_pandas(tqdm_notebook) didn't register with pandas.groupby")

# Generated at 2022-06-22 04:48:05.845053
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import random
    import pandas as pd
    from tqdm import tnrange, tqdm
    from contextlib import closing
    import pandas.util.testing as pdt
    N = 1000
    pdt.N = N

    def test_pandas_progressapply_df(desc, df, func, *args, **kwargs):
        result = df.progress_apply(func, *args, **kwargs)
        tqdm_pandas(tqdm(desc=desc + ' (pandas.progress_apply)    '))
        result2 = df.progress_apply(func, *args, **kwargs)
        assert result.equals(result2)


# Generated at 2022-06-22 04:48:15.634948
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    # set tqdm_pandas as default for test (this is recommended)
    tqdm_pandas(tqdm)

    try:
        import pandas as pd
    except ImportError:
        print("Skipping pandas tests...")
    else:
        import numpy as np

        data = np.random.choice(10, (10, 100))
        data = pd.DataFrame(data)
        data = data.groupby(data.index)
        data.progress_apply(lambda x: x)
        data.progress_apply(lambda x: x, axis=1)

# Generated at 2022-06-22 04:48:23.669163
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, TqdmDeprecationWarning, tqdm_pandas
    import pandas as pd
    import numpy as np

    data = pd.DataFrame(np.random.random(10))
    data['key'] = 'a'

    with tqdm(total=len(data) + 1, disable=False) as pbar:

        @tqdm_pandas(tclass=pbar)
        def func(x):
            return x

        def func_no_pbar(x):
            return x

        result = data.groupby('key').progress_apply(func)
        assert result is not None

        with pytest.warns(TqdmDeprecationWarning):
            tqdm_pandas(pbar)


# Generated at 2022-06-22 04:48:29.273897
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return None
    t = tqdm_pandas()
    assert 'ProgressBar' in str(t)
    # Test if deprecated API still works
    tqdm_pandas(tqdm(total=1, file=StringIO()))
    tqdm_pandas(tqdm, total=1, file=StringIO())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:39.802193
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import trange
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from random import random, seed
    from sys import version_info
    seed(42)
    df = DataFrame({'x': [random() for _ in range(100)]})

    def f(gdf):
        return gdf['x'].sum()

    for t in [trange, tqdm, tqdm_gui, tqdm_notebook]:
        tqdm_pandas(t)

# Generated at 2022-06-22 04:48:44.487796
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import pandas
    try:
        pandas.tqdm.pandas(tqdm_pandas)
    except (AttributeError, ImportError):
        pass
    else:
        raise Exception

# Generated at 2022-06-22 04:48:53.569437
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np

    print("Testing tqdm_pandas...")

    from tqdm import tqdm

    df = pandas.DataFrame(np.random.randn(1000000, 1))
    res = df.groupby(0).progress_apply(lambda x: x * 2)
    assert len(res) == len(df)

    res = df.progress_apply(lambda x: x * 2)
    assert len(res) == len(df)

    res = df.progress_apply(lambda x: x * 2)
    assert len(res) == len(df)

    with tqdm(total=2) as pbar:
        res = df.progress_apply(lambda x: x * 2)
        assert len(res) == len(df)
        pbar.update

# Generated at 2022-06-22 04:49:03.182461
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.autonotebook import trange, tqdm
    import numpy as np
    from time import sleep

    # All the code that needs tqdm progress bars

# Generated at 2022-06-22 04:49:14.078042
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy
    import shutil
    from io import StringIO
    with StringIO() as buf, redirect_stdout(buf), redirect_stderr(buf), \
        tqdm_pandas(unit='B'):
        pandas.DataFrame({'a': numpy.random.randint(0, 100, size=100000)}).groupby('a', sort=False).progress_apply(
            lambda x: x ** 2) == 0
    assert len(buf.getvalue()) > 0

    with StringIO() as buf, redirect_stdout(buf), redirect_stderr(buf):
        tqdm_pandas(tqdm=tqdm, unit='B')

# Generated at 2022-06-22 04:49:24.890865
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:49:34.671884
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        import numpy
    except ImportError:
        pass
    else:
        from tqdm.auto import tqdm
        t = tqdm_pandas(tqdm)
        df = pandas.DataFrame(
            [[2, 3, 4], [1, 4, 2], [1, 4, 2], [0, 2, 3]],
            columns=list("ABC"),
            index=list("ijkl"))
        with t:
            assert (df.groupby("A").progress_apply(len) ==
                    df.groupby("A").apply(len)).all()

# Generated at 2022-06-22 04:49:42.084268
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    tqdm.pandas(tqdm())
    pd.DataFrame(index=range(1000000)).groupby(level=0).progress_apply(lambda x: x)
    # check deprecated API
    tqdm_pandas(tqdm())

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:52.858495
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def f(df):
        import time
        time.sleep(0.01)
        return len(df)


# Generated at 2022-06-22 04:50:03.810702
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd

    df = pd.DataFrame(np.random.rand(100, 4),
                      columns=list('ABCD'))

    def f(x):
        return x  # Identity

    # First method
    import tqdm
    for i in tqdm.tqdm_pandas(df.progress_apply, **tqdm.__dict__):
        f(i)

    # Second method
    with tqdm.tqdm_pandas(tqdm.tqdm(**tqdm.__dict__)) as t:
        df.progress_apply(f, axis=1, args=[t])

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:12.960383
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    import io

    # Sample pandas function
    def add(df):
        import time
        time.sleep(0.01)
        return df["A"] + df["B"]

    # Test decorator
    @tqdm_pandas(tclass=tqdm.tqdm)
    def add_decorated(df):
        import time
        time.sleep(0.01)
        return df["A"] + df["B"]

    # Test args
    def add_args(df, val):
        import time
        time.sleep(0.01)
        return df["A"] + df["B"] + val

    # Test kwargs
    def add_kwargs(df, val=1):
        import time


# Generated at 2022-06-22 04:50:22.655890
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    # Create a dataframe
    df1 = pd.DataFrame(data=range(1, 5), index=list(range(10, 40, 10)), columns=['a'])
    with tqdm(total=len(df1)) as progressbar:
        progressbar.set_description('DataFrame')
        df2 = df1.progress_apply(lambda x: x)
    assert df1.equals(df2)


# If a Pandas deprecation warning is raised, ignore it (for v0.9.x)
import warnings
warnings.filterwarnings('ignore', category=DeprecationWarning)

# Generated at 2022-06-22 04:50:30.644824
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm, desc='')
    tqdm_pandas(tqdm)
    tqdm.pandas(tqdm)
    tqdm.pandas()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:37.303357
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm

    tqdm.tqdm = tqdm_pandas
    # Iterate over pandas dataframe
    pd.DataFrame({'A': [1, 2, 3], 'B': [2, 3, 4]}).groupby('A').progress_apply(lambda x: x)



# Generated at 2022-06-22 04:50:48.382157
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import trange
    import pandas as pd

    df = pd.DataFrame(dict(a=range(100), b=range(100, 200)))

    # Test 1
    tqdm_pandas(trange, desc="test1")
    df.groupby('a').progress_apply(lambda x: sum(x) + 1)

    # Test 2
    tqdm_pandas(trange, 'test2')
    df.groupby('a').progress_apply(lambda x: sum(x) + 1)

    # Test 3
    tqdm_pandas(trange(total=df.shape[0]))
    df.groupby('a').progress_apply(lambda x: sum(x) + 1)

# Generated at 2022-06-22 04:50:54.827448
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas
    from tqdm import tqdm
    from tqdm import TqdmDeprecationWarning
    import warnings

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        tqdm_pandas(tqdm)
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmDeprecationWarning)
        assert "Please use `tqdm.pandas(...)` instead" in str(w[-1].message)

# Generated at 2022-06-22 04:51:05.680811
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    N = 100
    df = pd.DataFrame([np.random.randint(0, 100, N) for _ in range(N)])
    tqdm_pandas(tqdm)
    # This shouldn't raise any exception
    df.groupby(0).progress_apply(lambda x: x)
    # This neither
    tqdm_pandas(tqdm_pandas)
    tqdm_pandas(tqdm_pandas(tqdm))
    tqdm_pandas(tqdm_pandas(tqdm_pandas))


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 04:51:13.998157
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        import tqdm
    except ImportError:
        raise unittest.SkipTest("pandas and/or tqdm not installed.")
    with closing(StringIO()) as our_file:
        with tqdm.tqdm(total=10, file=our_file) as t:
            tqdm_pandas(t)
            pandas.np.random.randn(10, 10).progress_apply(
                lambda x: x + 1)
        assert os.fstat(our_file.fileno()).st_size > 0
    with closing(StringIO()) as our_file:
        with tqdm.tqdm(total=10) as t:
            tqdm_pandas(t, file=our_file)

# Generated at 2022-06-22 04:51:20.015695
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from tqdm import tqdm
    try:
        from pandas import DataFrame
    except ImportError:
        return
    df = DataFrame([{"a": 1}, {"a": 2}])

    for t in [tqdm, tqdm_pandas]:
        t(df.groupby('a').progress_apply(lambda x: 7)).close()


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:28.326556
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm.autonotebook import tqdm

    # test normal case
    a = pd.DataFrame(np.random.rand(1000000, 1))
    b = pd.Series(np.random.rand(1000000))

    with tqdm(total=10000, unit='it') as pbar:
        a.progress_apply(lambda x: x**2, axis=1, meta={'total': 10000})
        pbar.update()
        b.progress_apply(lambda x: x**2, meta={'total': 10000})
        pbar.update()

    # test delayed case

# Generated at 2022-06-22 04:51:36.634926
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # pd.options.mode.chained_assignment = 'raise'  # NOQA

    @tqdm_pandas(tclass=tqdm)
    def func(df):
        df.x = df.x * df.x + df.y
        return df

    # test on a big dataframe
    df = pd.DataFrame({'x': range(10000), 'y': range(10000)}, dtype='float32')
    func(df)
    assert round(df.x.sum(), -3) == round(25006666.0, -3)

# Generated at 2022-06-22 04:51:46.339181
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:  # pragma: no cover
        return

    with warnings.catch_warnings():
        warnings.simplefilter('ignore', TqdmDeprecationWarning)
        old_tqdm = tqdm(pandas=True)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', TqdmDeprecationWarning)
        new_tqdm = tqdm.pandas()

    assert old_tqdm.pandas.__self__ is new_tqdm

    with warnings.catch_warnings():
        warnings.simplefilter('ignore', TqdmDeprecationWarning)
        assert old_tqdm.pandas

    # Registering mutliple times should not have any effect either

# Generated at 2022-06-22 04:52:01.380183
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # Setup progress bar
    tqdm.pandas(desc='test', leave=False, unit='test')

    # Iterator method
    df = pd.DataFrame(['test'] * 10000)
    it = df.progress_apply(lambda x: x.lower())
    for x in it:
        pass

    # Static method
    df.progress_apply(lambda x: x.lower())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:12.289993
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(1, index=range(10), columns=list('ab'))
    try:
        tqdm_pandas(tqdm())
    except TypeError:
        pass
    tqdm_pandas(tqdm(), total=10)
    tqdm_pandas(tqdm_notebook(), total=10)
    pd.DataFrame([df.progress_apply(lambda x: x),
                  df.progress_apply(lambda x: x, axis=1)])
    try:
        pd.DataFrame([df.progress_apply(lambda x: x, axis=3)])
    except ValueError:
        pass

# Generated at 2022-06-22 04:52:20.152929
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm
    from numpy.random import rand
    import os

    DATA = pd.DataFrame(rand(10000, 10000))
    for i in [tqdm, tqdm_pandas]:
        with i(disable=False, leave=True) as T:
            sum_ = DATA.progress_apply(T=T, func=sum)

    assert abs(sum_.sum() - DATA.sum().sum()) < 1e-5


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:27.405498
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function tqdm_pandas()
    """
    # Unit test for the decorator
    try:
        from tqdm.contrib import pandas
        from tqdm import tqdm
    except ImportError:
        return
    from pandas import DataFrame, Series

    # Data
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    df = DataFrame({'A': data})

    # Test 1: `dtype` is `int`
    res = set()
    for _, row in pandas.tqdm(df.iterrows(), total=len(df)):
        res.add(row['A'])
    assert res == set(data)

    # Test 2: `dtype` is `object`
    res = set

# Generated at 2022-06-22 04:52:33.777387
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    tqdm_pandas(tqdm)
    df = pd.DataFrame(np.random.randn(100, 4), columns=list('ABCD'))
    result = df.groupby('A').progress_apply(lambda g: g['B'].sum())
    assert result.sum() >= 0.0, "tqdm_pandas() failed, result.sum() == {}".format(
        result.sum())

# Generated at 2022-06-22 04:52:42.562368
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm)



# Generated at 2022-06-22 04:52:54.110717
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, trange
    # Test tqdm
    tdata = pd.DataFrame({"x": np.random.normal(size=100)})
    tdata.groupby(
        "x"
    ).progress_apply(
        lambda x: x.sum()  # pylint: disable=g-long-lambda
    )
    tdata.groupby(
        "x"
    ).progress_apply(
        lambda x: x.sum(),  # pylint: disable=g-long-lambda
        desc="test(tqdm)"
    )
    # Test tqdm.pandas
    tdata = pd.DataFrame({"x": np.random.normal(size=100)})
    tdata

# Generated at 2022-06-22 04:53:00.357785
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib.tests import pandas as tqdm_pandas_mod
    import pandas as pd

    test_series = pd.Series([1, 2, 3, 4])
    assert list(test_series.progress_apply(lambda x: x)) \
        == [1, 2, 3, 4]
    assert list(test_series.progress_apply(lambda x: x, tqdm_kwargs=dict(desc='Test'))) \
        == [1, 2, 3, 4]

    test_df = pd.DataFrame({'C1': [1, 2, 3, 4],
                            'C2': [11, 22, 33, 44]})