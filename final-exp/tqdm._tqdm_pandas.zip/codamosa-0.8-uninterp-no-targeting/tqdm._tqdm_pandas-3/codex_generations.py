

# Generated at 2022-06-22 04:43:00.560444
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    raise NotImplementedError


try:
    import pandas
    import pandas.core.groupby  # noqa: F401

    # register with pandas
    pandas.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas
except ImportError:
    pass

# Generated at 2022-06-22 04:43:04.725354
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    tqdm = tqdm_pandas(tqdm)  # noqa
    x = pd.DataFrame({'a': range(0, 20000), 'b': range(0, 20000)})
    x.groupby('a').progress_apply(lambda a: a * 2)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:16.025316
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd, numpy as np
    from tqdm import tqdm, tqdm_pandas, trange

    try:
        from tqdm.contrib import DummyTqdmFile
    except ImportError:  # pragma: no cover
        def DummyTqdmFile(*args, **kwargs):
            if args:
                raise NotImplementedError
            return args[0]

    with DummyTqdmFile() as R:
        with tqdm(ascii=True, file=R, disable=False) as t:
            t.set_description("testing")
            pd.DataFrame(np.random.randn(100, 100)).progress_apply(
                lambda x: x + 1, axis=0)

# Generated at 2022-06-22 04:43:27.946574
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:43:39.728309
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy
    import pandas
    from time import sleep
    from tqdm.tests._tqdm_test_examples import (
        nested_nested_range, nested_range, numpy_test, pandas_test)

    try:
        import pandas as pd
    except ImportError:
        pd = None

    # Unit tests
    print('Testing tqdm_pandas', file=sys.stderr)

    with tqdm(nested_range(1, 5), miniters=1, mininterval=0,
              smoothing=0) as t:
        for _ in tqdm_pandas(t, nested_range(1, 3)):
            sleep(0.01)


# Generated at 2022-06-22 04:43:51.483813
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
  import numpy as np
  import pandas as pd
  from tqdm import tqdm_notebook, tqdm_pandas
  from time import sleep

  tqdm_pandas()
  df = pd.DataFrame([{"a": 1, "b": 1},
                     {"a": 2, "b": 2, "c": 3},
                     {"a": 3, "b": 4, "d": 5}])
  results = df.groupby("a").progress_apply(lambda x: x)
  assert results.shape == (3, 3)
  tqdm_notebook().pandas();
  results = df.groupby("a").progress_apply(lambda x: x)
  assert results.shape == (3, 3)

# Generated at 2022-06-22 04:44:03.715317
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        print("skip\n")
        return

    import pandas as pd
    import numpy as np

    # https://stackoverflow.com/questions/36383821/apply-a-function-to-two-columns-of-pandas-dataframe/36383893#36383893
    def f(x):
        return pd.Series(dict(mean_x=x['x'].mean(),
                              mean_y=x['y'].mean()))

    from tqdm import tqdm_pandas

    big = pd.concat([pd.DataFrame(np.random.randint(100, size=(100000, 2)), columns=['x', 'y'])] * 20)
    res = big.groupby

# Generated at 2022-06-22 04:44:14.932158
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    # import pandas as pd

    df = DataFrame(dict(zip(range(3), (list(range(i, 5 + i)) for i in range(3)))))  # create 3x5 df
    # df = DataFrame(np.random.randint(1, 6, size=(3, 5)), columns=list('ABCDE'))  # create 3x5 df
    # df = pd.read_csv(DATA_FILE)
    # df = pd.DataFrame(x for x in [np.random.random(int(10e5)) for _ in range(10)])
    # df = pd.DataFrame(x for x in [np.random.random(int(10e3)) for _ in range(100)])
    # for

# Generated at 2022-06-22 04:44:23.415326
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    from tqdm import tqdm_pandas
    from tqdm._tqdm_pandas import tqdm_pandas

    tqdm_pandas(tqdm_pandas)
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(range(10)))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:33.520246
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    def test_group_progress(df, prog_bar=None, **kwargs):
        if prog_bar is None:
            return df
        prog_bar.update(1)
        return df

    def test_group_progress_wrapper(df, prog_bar=None, **kwargs):
        return df.groupby('user').progress_apply(test_group_progress,
                                                 prog_bar=prog_bar, **kwargs)

    try:
        import pandas
    except ImportError:
        return

    df = pandas.DataFrame([{'user': 'A'}, {'user': 'B'}, {'user': 'C'}])


# Generated at 2022-06-22 04:44:46.313954
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, TqdmTypeError, tqdm_pandas, trange

    try:
        progress_bar = trange(10, desc='foo', bar_format="{postfix}")
        tqdm_pandas(progress_bar)
    except TqdmTypeError:
        pass
    else:
        raise RuntimeError("expected TqdmTypeError")

    try:
        tqdm_pandas(tqdm(desc='foo', bar_format="{postfix}"))
    except TqdmTypeError:
        pass
    else:
        raise RuntimeError("expected TqdmTypeError")

    # reg_tqdm = tqdm(desc='foo', bar_format="{postfix}")
    # tqdm_p

# Generated at 2022-06-22 04:44:57.475252
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    import pandas as pd
    import numpy as np

    if sys.version_info < (3,):
        from future_builtins import map

    for pandas_like_tuples_type in (pd.DataFrame, pd.Series):

        class pandas:
            pass

        pandas.core = pandas.core if hasattr(pandas, 'core') else pandas
        pandas.core.groupby = pandas.core.groupby if hasattr(pandas.core, 'groupby') else pandas.core
        pandas.core.groupby.DataFrameGroupBy = pandas_like_tuples_type

        tqdm_pandas(tqdm)


# Generated at 2022-06-22 04:45:01.701168
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Simple test to make sure it is executed at least once.
    """
    from tqdm import tqdm
    tqdm_pandas(tqdm(...))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:13.200697
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy
    from tqdm import tqdm

    tqdm_pandas(tqdm)
    assert 'progress_apply' in dir(DataFrameGroupBy)
    # try to use multiple times (and make sure not to break things)
    if 'progress_apply' in dir(DataFrameGroupBy):
        tqdm_pandas(tqdm)
    assert 'progress_apply' in dir(DataFrameGroupBy)
    # try to use multiple times, in case *something* broke things
    if 'progress_apply' in dir(DataFrameGroupBy):
        tqdm_pandas(tqdm)

    # Allocate a dummy pandas dataframe, and
    # use dummy function to

# Generated at 2022-06-22 04:45:15.548557
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with suppress(DeprecationWarning):
        try:
            tqdm_pandas(tqdm.tqdm)
        except AttributeError:
            # tqdm.tqdm not available
            pass

# Generated at 2022-06-22 04:45:20.561755
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import numpy as np
        import pandas as pd

        def tqdm_pandas_test(**kwargs):
            pd.DataFrame(np.random.random(size=(100, 100))).groupby(
                0).progress_apply(lambda x: x)

        tqdm_pandas(tqdm_pandas_test, unit='test')
    except ImportError:
        pass

# Generated at 2022-06-22 04:45:31.829057
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    # To test `tqdm.pandas(...)`
    tqdm.pandas(desc='progress-bar')
    # To test `type(tqdm.tqdm_notebook).pandas(t=tqdm.tqdm_notebook(...))`
    type(tqdm.tqdm_notebook).pandas(deprecated_t=tqdm.tqdm_notebook())
    # To test `tqdm_pandas(tqdm.tqdm_notebook, ...)`
    tqdm_pandas(tclass=tqdm.tqdm_notebook())
    # To test `tqdm_pandas(tqdm_notebook,

# Generated at 2022-06-22 04:45:40.227680
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm.pandas

    df = pd.DataFrame({'x': np.random.normal(size=100)})

    # Test deprecation warning
    with pytest.warns(TqdmDeprecationWarning):
        tqdm_pandas(tqdm.pandas)

    # Test if progress bar works
    try:
        with tqdm.pandas():
            df['x'].progress_apply(lambda x: x**2)
    except Exception as e:
        pytest.fail("progress_apply did not work. See error:\n%s" % (e,))

    # Test if progress bar works with `desc`

# Generated at 2022-06-22 04:45:43.919433
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    To be changed to pytest equivalent.
    """
    try:
        import pandas
        t = tqdm(range(10), desc="tqdm_pandas test")
        for _ in pandas.Series(range(10)).progress_apply(t.update):
            pass
    except ImportError:
        ...


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:53.234819
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_gui
    from numpy.random import randint

    for t in (tqdm, tqdm_gui):
        df = pd.DataFrame(1 + randint(-5, 6, (100, 100)), dtype=float)

        result = df.groupby(randint(0, 10, 100)).progress_apply(lambda x: x)
        if result.shape != (100, 100):
            raise AssertionError("Incorrect result shape")

        result = df.progress_apply(lambda x: x)
        if result.shape != (100, 100):
            raise AssertionError("Incorrect result shape")

        result = df.progress_apply(lambda x: x, axis=0)

# Generated at 2022-06-22 04:46:00.366781
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit-test for function tqdm_pandas
    """
    import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm.tqdm)


test_tqdm_pandas()



# Generated at 2022-06-22 04:46:08.470988
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import tqdm
        import numpy as np
    except ImportError:
        return
    try:
        pd.DataFrame([1]).progress_apply  # pandas >= 0.18
    except AttributeError:
        raise unittest.SkipTest

    def test_df(df, **kwargs):
        assert isinstance(df, pd.DataFrame)
        assert np.all(df >= 0)

    def test_cdf(df, **kwargs):
        assert isinstance(df, pd.DataFrame)
        assert np.all(df >= 0)
        return np.sum(df)

    tqdm.tqdm_pandas(tqdm.tqdm)

# Generated at 2022-06-22 04:46:19.292511
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas."""
    tqdm = tqdm_pandas
    try:
        import pandas as pd
    except ImportError as e:
        # verify that if pandas is missing, it does not raise
        # an ImportError
        assert re.match(r'No module named .*pandas', str(e))
        return
    pd.DataFrame(tqdm(pd.DataFrame([list(range(10))]))).to_csv()
    try:
        pd.DataFrame(tqdm(pd.DataFrame([list(range(10))]))).to_csv('/foo/bar')
    except TypeError:
        pass

# Generated at 2022-06-22 04:46:30.584141
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    # Test with datagframe
    df = pd.DataFrame({
        'a': [4, 3, 5, 2, 1, 7, 7, 5],
        'b': [0, 4, 3, 6, 7, 10, 11, 9],
        'c': ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'],
    }, index=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
    df_groupby = df.groupby('a')

    # Test with Series
    series = pd.Series([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    series_groupby = series

# Generated at 2022-06-22 04:46:41.811162
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def test_adapter(tclass):
        tqdm_pandas(tclass, desc='my_desc')


    def test_adapter_kwargs(tclass):
        tqdm_pandas(tclass, desc='my_desc', bar_format='custom: bar_format')


    class DummyTqdmCls:
        def __init__(self, desc=None, file=None, bar_format=None, leave=True):
            self.desc = desc
            self.file = file
            self.bar_format = bar_format
            self.leave = leave

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass


# Generated at 2022-06-22 04:46:50.670221
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    try:
        from numpy import random as nprand
    except ImportError:
        from random import random as nprand
    from tqdm.auto import tqdm
    import pandas as pd

    def test_fn(x):
        """Dummy function to test `progress_apply`"""
        sleep(x / 100)
        return x

    N = 10000
    tqdm_pandas(tqdm, smoothing=1)
    nprand.seed(0)
    # Test DataFrame
    df = DataFrame({"A": nprand.randn(N), "B": nprand.randn(N)})
    # need to disable disable=W0511 for test in case
    # nbformat<4.2.0.dev==dev,

# Generated at 2022-06-22 04:47:02.006105
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Tests `tqdm.pandas` for a DataFrameGroupBy.
    """
    from pandas import DataFrame, Series
    from tqdm import tqdm

    df = DataFrame({'a': Series(range(10000)).astype('float16')})
    is_ca = df.a.map_partitions(
        lambda s: pd.Series(s.map(lambda x: x < max(s) * 0.8).all()))
    assert is_ca.sum() == 0
    is_ca = df.a.progress_apply(lambda x: x < max(df.a) * 0.8).all()
    assert is_ca

# Generated at 2022-06-22 04:47:13.394623
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'a': [1, 2, 3, 4]})
    list(tqdm.tqdm_pandas(df.groupby('a'), desc='1st loop'))
    df.groupby('a').progress_apply(lambda x: None)
    with tqdm.tqdm_pandas(desc='1st loop') as t:
        list(df.groupby('a').progress_apply(lambda x: None, t=t))

    try:
        df.groupby('a').progress_apply(lambda x: None, total=10)
    except TypeError:
        pass
    else:
        raise ValueError('Total must be an integer or None')



# Generated at 2022-06-22 04:47:21.181476
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        print("Could not import pandas. Cannot run test for tqdm_pandas.")
    else:
        df = pd.DataFrame(dict(id=range(int(1e6)),
                               b=np.arange(int(1e6)),
                               c=np.arange(int(1e6))))
        df = df.groupby('id').progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:25.776562
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    pd.DataFrame({'a': range(100)}).groupby('a').progress_apply(lambda x: x)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:40.142149
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib import pandas as tpdp
    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
    pb = tqdm(total=len(df))
    df.progress_apply(lambda x: x + 1, axis=1)
    assert pb.n == len(df)
    pb = tqdm(total=len(df))
    df.apply(lambda x: x + 1, axis=1)
    assert pb.n == len(df)

    assert len(df.progress_apply(lambda x: x + 1)) == len(df)
    assert len(df.progress_apply(lambda x: x + 1, axis=1))

# Generated at 2022-06-22 04:47:51.616140
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    from tqdm import tqdm, TqdmDeprecationWarning
    from .tests import tqdm_tests as td
    from pandas import DataFrame

    # test with provided TqdmType
    tqdm_pandas(tqdm)

    # test with explicit tqdm type
    tqdm_pandas(td.TqdmType)

    # test with tqdm instance
    tqdm_pandas(tqdm())

    # test with deprecated tqdm instance
    with td.AssertPrints("Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm(...))`."):
        tqdm_pandas(tqdm(deprecated=True))

# Generated at 2022-06-22 04:48:03.114450
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    A = pd.DataFrame([np.arange(10000), np.arange(10000)])
    B = A.groupby(0).progress_apply(lambda x: x.sum())
    B - pd.DataFrame([np.arange(10000) * 9999])
    try:
        from pandas.core.groupby import GenericGroupBy
        GenericGroupBy.progress_apply = None
    except:
        pass  # old pandas

    A = pd.DataFrame([np.arange(10000), np.arange(10000)])
    B = A.groupby(0).progress_apply(lambda x: x.sum())
    B - pd.DataFrame([np.arange(10000) * 9999])

   

# Generated at 2022-06-22 04:48:14.091980
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    def generate_df():
        df = pd.DataFrame({'num_legs': [8, 4], 'num_wings': [0, 2]},
                          index=['spider', 'bird'])
        df.index.name = 'animal'
        return df

    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(desc='my_desc'))
    tqdm_pandas(tqdm(desc='my_desc', leave=True, position=0))
    tqdm_pandas(tqdm(desc='my_desc', leave=True, position=1))

# Generated at 2022-06-22 04:48:19.639425
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # test with tqdm_notebook
    try:
        try:
            import tqdm_notebook as tqdm
        except ImportError:
            from tqdm import tqdm_notebook as tqdm
    except ImportError:
        return  # skip tqdm_notebook test
    tqdm_pandas(tqdm)

    # test with tqdm
    tqdm_pandas(tqdm)

# Generated at 2022-06-22 04:48:30.660124
# Unit test for function tqdm_pandas

# Generated at 2022-06-22 04:48:40.500530
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas import Series

    import numpy as np

    ITERABLES = [
        DataFrame({'a': range(1000), 'b': range(1000)}).groupby('b'),
        Series(range(1000)).groupby(lambda x: x // 10),
        DataFrame(np.random.randint(0, 10, size=(100, 4)),
                  columns=list('ABCD')).groupby('A'),
        DataFrame({'a': range(1000), 'b': range(1000)}).groupby(
            'b').progress_apply(len),
    ]
    for obj in ITERABLES:
        t = tqdm()
        with t:
            obj.progress_apply(t.update)
        t.close()

   

# Generated at 2022-06-22 04:48:48.059565
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import tqdm
        from pandas import DataFrame
    except ImportError:
        return
    tqdm.tqdm_pandas(tqdm.tqdm())
    with tqdm.tqdm_pandas(tqdm.tqdm()) as t:
        DataFrame([[1, 2, 3], [4, 5, 6]]).progress_apply(lambda x: x)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:50.566870
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np

        pd.DataFrame(np.random.randn(1000, 100)).groupby(0).progress_apply(lambda x: x**2)
    except ImportError:
        pass

# Generated at 2022-06-22 04:49:01.247941
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm

    def tqdm_pandas_factory(t, **tqdm_kwargs):
        return tqdm_pandas(t, **tqdm_kwargs)

    df = pd.DataFrame({'A': list(range(0, 10)),
                       'B': list(range(0, 10))})

    # tqdm.pandas deprecated
    # test progress_apply and progress_map
    tqdm_pandas_factory(
        tqdm, desc='test_progress_apply_1').progress_apply(df,
                                                           lambda x: x,
                                                           axis=1)
    # test for map
    tqdm_pandas_f

# Generated at 2022-06-22 04:49:12.958398
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm, desc='Test')
    df = DataFrame(dict(a=list(range(100))))
    df['a_new'] = df.groupby('a').progress_apply(lambda x: x)

# Generated at 2022-06-22 04:49:22.751212
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm._tqdm_pandas import tqdm_pandas
    tqdm_pandas(tqdm(total=5))
    pd.DataFrame({'a': [1, 3, 4]}).groupby(['a']).progress_apply(len, axis='index')
    pd.Series([1, 3, 4]).progress_apply(len)
    tqdm_pandas(tqdm(total=5))
    pd.DataFrame({'a': [1, 3, 4]}).groupby(['a']).progress_apply(len, axis='index')
    pd.Series([1, 3, 4]).progress_apply(len)

# Generated at 2022-06-22 04:49:32.130260
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `pandas`.
    """
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from tqdm import trange
    n = 1000
    df = pd.DataFrame(data={"a": np.random.rand(n),
                            "b": np.random.rand(n),
                            "c": np.random.rand(n),
                            })

    # test trange
    tqdm_pandas(trange(ncalls=4))

    # test tqdm
    tqdm_pandas(tqdm())

    # test tqdm.pandas
    tqdm.pandas()
    df.groupby("a").progress_apply(lambda x: x)

    # test t

# Generated at 2022-06-22 04:49:38.664504
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import trange
    from sklearn.datasets import load_digits
    digits = load_digits()
    df_digits = pd.DataFrame(digits.data)
    df_digits.apply(lambda row: trange(10).sum(), axis=1)

# Generated at 2022-06-22 04:49:48.331703
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import tqdm
    # Case 1
    tclass = tqdm.tqdm
    with tqdm.tqdm(total=10) as pbar:
        assert len(pbar) == 10
    tqdm_pandas(pbar, total=20)
    assert len(pbar) == 20
    # Case 2
    tclass = tqdm.tqdm
    with tqdm.tqdm(total=10) as pbar:
        assert len(pbar) == 10
    tqdm_pandas(tclass, total=20)
    assert len(pbar) == 20
    # Case 3
    tclass = tqdm.tqdm

# Generated at 2022-06-22 04:49:58.606435
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def tqdm_pandas(tqdm_kwargs):
        return tqdm_pandas(tqdm_kwargs=tqdm_kwargs)

    # Test whether tqdm_pandas(tqdm(...)) works
    tqdm_pandas(tqdm(range(100)))

    # Test whether tqdm_pandas(tqdm.pandas(...)) works
    tqdm_pandas(tqdm.pandas(range(100)))

    # Test whether tqdm_pandas(tqdm(...)) works for DataFrames
    df = pd.DataFrame({'a': [1, 2, 3, 4], 'b': [4, 3, 2, 1]})

# Generated at 2022-06-22 04:50:07.813012
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test case for :py:func:`tqdm.contrib.concurrent.tqdm_pandas`,
    """
    try:
        import pandas
    except ImportError:
        return
    from tqdm import tqdm, tqdm_pandas

    # deprecated form
    tqdm_pandas(tqdm, total=10, leave=False)

    # new form
    tqdm_pandas(total=10, leave=False)

    # nested deprecated form
    tqdm_pandas(tqdm_pandas(tqdm, total=10, leave=False), total=10, leave=False)

    # nested new form
    tqdm_pandas(total=10, leave=False)

# Generated at 2022-06-22 04:50:20.191389
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Testcase"""
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame([[1, 3], [2, 4], [5, 6], [1, 8], [4, 4], [5, 4]],
                      columns=['A', 'B'])

    # Test tqdm_pandas

# Generated at 2022-06-22 04:50:31.782481
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    import pandas as pd
    import pandas.core.groupby as grp
    # test `tqdm_pandas(tqdm, ...)`
    orig_dfgb = grp.DataFrameGroupBy.progress_apply
    tqdm_pandas(tqdm, total=5)
    assert grp.DataFrameGroupBy.progress_apply == orig_dfgb
    tqdm_pandas(tqdm, total=5)
    assert grp.DataFrameGroupBy.progress_apply == orig_dfgb
    # test `tqdm_pandas(tqdm(...))`
    orig_dfgb = grp.DataFrameGroupBy.progress_apply
    tqdm_pandas(tqdm(total=5))


# Generated at 2022-06-22 04:50:41.228878
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tqdm_pandas(tqdm(total=len(df), unit='cell', smoothing=0))
    df.progress_apply(lambda x: x)
    df.progress_apply(lambda x: x, axis=1)
    df.progress_apply(lambda x: x[1], axis=1)


if __name__ == '__main__':
    from multiprocessing import Pool
    p = Pool(2)
    _ = p.map(test_tqdm_pandas, [None] * 2)

# Generated at 2022-06-22 04:51:06.350727
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame, Series
    except ImportError:
        return
    from numpy.random import randint

    try:
        from pandas import Series
        s = Series(randint(0, 10, size=100000))
        assert tqdm_pandas(s).sum() == s.sum()
        assert tqdm_pandas(s, desc='custom').sum() == s.sum()
    except ImportError:
        pass

    try:
        from pandas import DataFrame
        df = DataFrame(randint(0, 10, size=(100000, 3)), columns=list('abc'))
        assert (tqdm_pandas(df).sum() == df.sum()).all()
    except ImportError:
        pass

# Generated at 2022-06-22 04:51:13.026188
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({'a': [1, 2, 3, 4, 5, 6],
                       'b': [11, 22, 33, 44, 55, 66],
                       'c': [11, 22, 33, 44, 55, 66],
                       'd': [11, 22, 33, 44, 55, 66],
                       'e': [11, 22, 33, 44, 55, 66],
                       'f': [11, 22, 33, 44, 55, 66]})


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:19.625013
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    from tqdm import tqdm
    tbar = tqdm()
    tqdm_pandas(tbar)
    tqdm_pandas(tqdm)
    try:
        tqdm_pandas(1)
    except TypeError:
        pass


# Add a Pandas-specific unit test to the default tqdm unit test suite
from tqdm import __main__
__main__.TEST_MODULES += ['tests_pandas']

# Generated at 2022-06-22 04:51:28.105600
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm.pandas
    tqdm.pandas.register()
    import pandas as pd

    df = pd.DataFrame(range(10))
    df.groupby(2).progress_apply(lambda x: x**2)

    with tqdm.pandas(total=50) as t:  # can use `miniters=1` instead of `total`
        df.groupby(2).progress_apply(lambda x: x**2)
        t.update()  # update tqdm manually after consuming some iters

    # also works with `pandas.core.groupby.GroupBy.progress_agg`, as well as
    # `pandas.core.groupby.GroupBy.progress_transform`
    # and `pandas.core.groupby.GroupBy.progress

# Generated at 2022-06-22 04:51:38.153336
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from distutils.version import StrictVersion
    import pandas
    from tqdm import tqdm

    # Check pandas version
    if StrictVersion(pandas.__version__) < StrictVersion('0.18.0'):
        return None

    # Initialize a pandas DataFrame
    df = pandas.DataFrame({'a': [1, 2, 3], 'b': [10, 20, 30]})

    # Apply a function to the DataFrame
    def function(x):
        return x['a'] + x['b']

    # Perform the function without the adapter
    df_result = df.progress_apply(function, axis=1)
    assert ((df_result == df['a'] + df['b']).all())

    # Perform the function with the adapter

# Generated at 2022-06-22 04:51:45.322298
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import tqdm_pandas_with_deprecation
    try:
        import pandas as pd
        import numpy as np
        df = pd.DataFrame({'A': np.arange(100), 'B': np.arange(100, 0, -1)})
        df.groupby('A').progress_apply(lambda x: x)
    except Exception:
        tqdm_pandas_with_deprecation()
        df.groupby('A').progress_apply(lambda x: x)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:53.714363
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        df = pd.DataFrame(
            {'x': [1, 2, 3, 4], 'y': [5, 6, 7, 8]}, index=[3, 4, 5, 6])
        assert df.groupby('x').progress_apply(lambda x: x).equals(
            df.groupby('x').apply(lambda x: x))
        assert df.progress_apply(lambda x: x).equals(df.apply(lambda x: x))
    except ImportError:
        pass
    else:
        print("passed tqdm_pandas unit test")


# Register tqdm instance method
tqdm.pandas = tqdm_pandas


# Generated at 2022-06-22 04:52:01.942934
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)),
                      columns=list('ABCDEF'))

    # `progress_map` available since v0.18.0
    df.groupby('A').progress_apply(lambda x: x**2)

    # `progress_apply` available since v0.19.0
    df.groupby('A').progress_apply(lambda x: x**2)


# Initialise in case imported directly and not via tqdm
tqdm_pandas(tqdm)

# Generated at 2022-06-22 04:52:12.908972
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import unittest
    try:
        import pandas as pd
    except ImportError:
        raise unittest.SkipTest("pandas is not installed")

    from tqdm.cli import tqdm
    from .tests_tqdm import pretest_posttest_tqdm

    class TqdmTest(unittest.TestCase):
        def test_tqdm_pandas_tqdm(self):
            def f(df):
                return df
            df = pd.DataFrame(dict(a=[1, 2, 3], b=[4, 5, 6]))
            assert f(df).equals(tqdm(f)(df))

# Generated at 2022-06-22 04:52:21.597766
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_cases = [
        [tqdm, {}],
        [tqdm.tqdm, {'desc': 'testing'}],
        [tqdm.tqdm_notebook, {'desc': 'testing', 'ascii': True}],
        [tqdm.tqdm_gui, {'desc': 'testing'}],
        [tqdm.tqdm_pandas, {'desc': 'testing'}],
    ]
    for tc in test_cases:
        tqdm_pandas(*tc)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:56.513505
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Test how tqdm_pandas works.
    """
    import tqdm
    import pandas as pd
    import numpy as np
    df = pd.DataFrame()
    df['a'] = np.random.randint(100, size=100)
    tqdm_pandas(tqdm)
    df.groupby(['a']).progress_apply(lambda x: x + 1)

if __name__ == '__main__':
    test_tqdm_pandas()