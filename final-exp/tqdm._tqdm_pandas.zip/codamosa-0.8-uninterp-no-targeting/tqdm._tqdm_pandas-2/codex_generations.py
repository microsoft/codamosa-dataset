

# Generated at 2022-06-22 04:43:10.304427
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
    tqdm_pandas(tqdm, total=len(df))
    assert df.groupby('A').progress_apply(lambda x: x)
    return


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:22.005509
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    # initialise df
    df = pd.DataFrame(
        {'a': [0, 1, 2],
         'b': [3, 4, 5]})
    # check default behaviour (without tqdm)
    assert df.progress_apply(pd.Series.sum).equals(pd.Series([3, 5, 7]))
    # check `tqdm_pandas` behaviour
    assert df.progress_apply(lambda x: pd.Series.sum(x)).equals(pd.Series([3, 5, 7]))
    # check `tqdm_pandas` with instantiated tqdm

# Generated at 2022-06-22 04:43:33.528546
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame as dataframe
    from tqdm import tqdm
    from tqdm.auto import tqdm as tqdm_auto

    df = dataframe({"x": [1, 2, 3],
                    "y": [4, 5, 6],
                    "z": [7, 8, 9]})

    # no tqdm
    assert list(df.groupby("x").progress_apply(lambda x: x)) == [
        dataframe({"y": [4], "z": [7]}),
        dataframe({"y": [5], "z": [8]}),
        dataframe({"y": [6], "z": [9]})]

    # tqdm

# Generated at 2022-06-22 04:43:42.900863
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test"""
    # Imports
    import pandas as pd
    import numpy as np
    import os
    import sys

    if sys.version_info[:2] < (3, 6):  # pandas needs py>=3.6
        return

    # Configuration
    saved_env = {}
    for key in list(os.environ.keys()):
        if key.startswith("TQDM"):
            saved_env[key] = os.environ[key]
            del os.environ[key]

    tqdm_pandas(tqdm)
    df = pd.DataFrame(np.random.rand(100000, 56))

    # Start test
    with tqdm(total=100) as pbar:
        def progress_func(x):
            pbar

# Generated at 2022-06-22 04:43:52.931421
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm(total=100), total=200)
    tqdm_pandas(tqdm(total=100), total=200, mininterval=0.1)
    tqdm_pandas(tqdm(), total=200)
    tqdm_pandas(tqdm(), total=200, mininterval=0.1)
    tqdm_pandas(tqdm(total=100), mininterval=0.1)
    tqdm_pandas(tqdm(total=100), file=sys.stderr)

# Generated at 2022-06-22 04:43:55.926092
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm.pandas()

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:06.454071
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange
    from tqdm.autonotebook import tqdm

    pd.DataFrame({'a': np.random.randint(0, 10, size=1000)}).groupby(
        'a').progress_apply(lambda d: [d.values])
    # should be a no-op
    tqdm.pandas()
    pd.DataFrame({'a': np.random.randint(0, 10, size=1000)}).groupby(
        'a').progress_apply(lambda d: [d.values])
    # should be a no-op
    tqdm.pandas(tqdm)

# Generated at 2022-06-22 04:44:16.290238
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame({'a': [1, 2, 3], 'b': [10, 20, 30]})

    # test function given a class
    @tqdm_pandas(tclass=tqdm)
    def func_class(df):
        return df.sum(axis=1)

    func_class(df)

    # test function given an instance
    @tqdm_pandas(tclass=tqdm(total=1))
    def func_instance(df):
        return df.sum(axis=1)

    func_instance(df)

    class TmpClass:
        @classmethod
        def pandas(cls, **kwargs):
            pass

    # test with the deprecated decorator
   

# Generated at 2022-06-22 04:44:23.064631
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    for dtype in [pd.DataFrame, pd.Series]:
        df = dtype(dict(a=list(range(100))))
        assert df.groupby("a").progress_apply(lambda x: x, tqdm_kwargs=dict(total=len(df))).sum().values[0] == 4950

# Generated at 2022-06-22 04:44:33.092357
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series
    from numpy.random import randint

    df = DataFrame({'a': Series(randint(0, 1000, 1000)),
                    'b': Series(randint(0, 1000, 1000)),
                    'c': Series(randint(0, 1000, 1000)),})

    def f(x):
        return x.mean()

    def f2(x):
        return x.sum()

    for progress in [False, True]:
        for nice in [False, True]:
            with tqdm_pandas(total=len(df.columns) - 1, unit='column') as t:
                df.progress_apply(f, axis=0, progress_apply=progress,
                                  nice=nice, use_tqdm=True, tqdm_kwargs=t)

# Generated at 2022-06-22 04:44:44.056660
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    with tqdm_pandas(total=5) as pbar:  # use `tqdm_pandas` defined here
        DataFrame().groupby(level=0).progress_apply(lambda _: "data")  # to see the bar
    assert not pbar.disable


if __name__ == "__main__":
    # import os
    # os.chdir(os.path.dirname(__file__) or os.curdir)
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:47.977510
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        t = tqdm_pandas(tqdm())
        t.register()
        df = pd.DataFrame([1, 2, 3])
        df.groupby(0).progress_apply(lambda x: 1)
    finally:
        t.unregister()

# Generated at 2022-06-22 04:44:52.346531
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    pandas_df = pd.DataFrame({
        'true': np.random.normal(size=100),
        'false': -np.random.normal(size=100),
        'null': np.nan
    })

    with tqdm.tqdm_pandas(unit='rows') as t:
        pandas_df.progress_apply(lambda _: np.random.normal(), axis=1)
        assert getattr(t.deprecated_t, 'n', None) == pandas_df.shape[0]


# Generated at 2022-06-22 04:45:03.022497
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        print('Testing pandas integration: ', end='')
        tqdm = tqdm_pandas
        df = pd.DataFrame(np.random.randn(10, 2))
        it = df.groupby(0).progress_apply(lambda x: x)
        # Nested tqdm inside pandas
        it = df.groupby(0).progress_apply(
            lambda x: tqdm(x).progress_apply(lambda x: x))
        for _ in it:
            pass
        print('successfully passed')
    except:
        print('failed to test')
        raise


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:10.660359
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for tqdm_pandas
    """
    # Unit test for following case:
    # tqdm_pandas(tqdm(total=None))
    import tqdm

    t = tqdm.tqdm(total=None)
    tqdm_pandas(t)

    # Unit test for following case:
    # tqdm_pandas(tqdm)
    tqdm_pandas(tqdm)

# Generated at 2022-06-22 04:45:19.030145
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd
    import numpy as np
    from random import randint
    import os

    # generate some random dataframe
    df = pd.DataFrame({'key': [randint(0,1) for _ in range(randint(10,50))],
                       'value': [randint(0,100) for _ in range(randint(10,50))]})
    df1 = df.groupby('key').progress_apply(lambda x: x**2)
    tqdm_pandas(tqdm())
    df2 = df.groupby('key').progress_apply(lambda x: x**2)
    assert (df1.values == df2.values).all()


# Generated at 2022-06-22 04:45:30.246377
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    import pandas as pd
    import numpy as np
    from tqdm import trange
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", default=10, type=int)
    args = parser.parse_args()
    limit = args.limit
    N = 20
    df = DataFrame(np.random.randint(0, N, (N // 2, 2)), columns=list('AB'))
    df2 = df.groupby('A').progress_apply(lambda x: x ** 2)
    assert df.equals(df2)
    # Test trange compatibility

# Generated at 2022-06-22 04:45:34.047958
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    tqdm_pandas(tqdm())  # no exception
    tqdm_pandas(type(tqdm()))  # no exception


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:43.710001
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for class tqdm_pandas"""
    import pandas as pd
    from tqdm import tqdm

    data = pd.DataFrame({'a': list(range(10))})

    # Test real time adapter
    tqdm_pandas(tqdm)
    assert tqdm.pandas.__name__ == 'tqdm_pandas'
    assert tqdm.pandas.__doc__ == """

    Registers the given `tqdm` instance with
    `pandas.core.groupby.DataFrameGroupBy.progress_apply`.
    """
    # Test delayed adapter
    tqdm_pandas(type(tqdm))
    assert tqdm.pandas.__name__ == 'tqdm_pandas'

# Generated at 2022-06-22 04:45:53.108720
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        import pandas
    except ImportError:
        print('\033[1m\033[93m`pandas` not installed, skipping test.\033[0m')
        return
    try:
        import numpy
    except ImportError:
        print('\033[1m\033[93m`numpy` not installed, skipping test.\033[0m')
        return
    try:
        # Do the import here to check that `tqdm_notebook` works
        from tqdm.notebook import tqdm as tqdm_notebook
    except ImportError:
        print('\033[1m\033[93m`tqdm.notebook` not installed, skipping test.\033[0m')
        return

   

# Generated at 2022-06-22 04:45:58.482887
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        tqdm_pandas(tqdm(pandas.Series(range(500))))
    except ImportError:
        pass

# Generated at 2022-06-22 04:46:01.598318
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:05.862402
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import tqdm
    T = tqdm.tqdm(total=10)
    tqdm_pandas(T)
    tqdm_pandas(tqdm)


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-22 04:46:17.782110
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test function tqdm_pandas"""

    def test_function(x):
        return x

    try:
        import pandas as pd
    except ImportError:
        return

    df = pd.DataFrame({"test": [1, 1, 1, 1, 1]}, index=[0, 0, 0, 0, 0])

    with tqdm_pandas(total=df.shape[0] // 2) as t:
        # In case where you want to apply a function to each row
        # and show progress bar for each two rows.
        result = df.groupby(df.index).progress_apply(test_function,
                                                     meta={"total": df.shape[0],
                                                           "description": "test_description",
                                                           "unit": "unit_test"})


# Generated at 2022-06-22 04:46:27.548220
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_notebook
    try:
        from pandas import DataFrame
    except ImportError:
        return
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm_notebook)
    tqdm_pandas(tqdm(total=100))
    tqdm_pandas(tqdm_notebook(total=100))
    assert hasattr(DataFrame.progress_apply, 'tqdm_gui')


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:32.857881
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    # tqdm_pandas(tqdm.tqdm())
    tqdm_pandas(tqdm)
    tqdm_pandas(pd.DataFrame({'a': [1, 2, 3]}))
    tqdm_pandas(pd.DataFrame({'a': [1, 2, 3]}).groupby('a'))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:39.201627
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    try:
        import test_tqdm_pandas
        print('Test for tqdm_pandas passed successfully!')
    except ImportError:
        raise ImportError('Please run "pip3 install tqdm" first.')

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:49.925416
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        raise SkipTest

    class T(tqdm):
        """
        Class to test tqdm_pandas on old and new tqdm versions.
        """
        def pandas(deprecated_t=None, **tqdm_kwargs):
            """
            Old-style delayed adapter, can be called with either `tqdm.pandas(...)`
            or `tqdm_pandas(tqdm, ...)`.

            New-style function, should be called with
            `tqdm_pandas(tqdm(...))` or deprecated `tqdm_pandas(tqdm)`.
            """
            from tqdm import TqdmDeprecationWarning
            # test argument passing

# Generated at 2022-06-22 04:47:01.534020
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function tqdm_pandas() """
    from tqdm import tqdm, tqdm_pandas
    import numpy as np
    import pandas as pd

    # Test for `tqdm_pandas`
    df = pd.DataFrame(np.arange(10000).reshape(1000, 10))
    with tqdm(total=len(df)) as pbar:
        df.progress_apply(lambda x: x**2)
    pbar.close()

    # Test for `tqdm.pandas`
    with tqdm(total=len(df)) as pbar:
        df.progress_apply(lambda x: x**2)
    pbar.close()

    # Test for `tqdm_pandas` and `tqdm.p

# Generated at 2022-06-22 04:47:12.905217
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from pandas import DataFrame
    except ImportError:
        # for pandas 0.10
        from pandas.core.frame import DataFrame

    df = DataFrame({'foo': range(10), 'bar': range(10, 20)})
    try:
        # pandas >= 0.13
        with tqdm_pandas(total=None) as t:
            df.groupby('foo').progress_apply(lambda x: x.sum())
    except:
        # pandas < 0.13
        with tqdm_pandas():
            df.groupby('foo').apply(lambda x: x.sum())

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:28.146944
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import pandas as pd

    t = tqdm(total=10)
    t.update(1)
    tqdm_pandas(t)
    t.update(1)
    t.close()

    t = tqdm(total=10)
    t.update(1)
    tqdm_pandas(tqdm)
    t.update(1)
    t.close()

    t = tqdm(total=10)
    t.update(1)
    tqdm_pandas(tqdm())
    t.update(1)
    t.close()

    t = tqdm(total=10)
    t.update(1)
    tqdm_pandas(tqdm(total=10))
   

# Generated at 2022-06-22 04:47:38.890033
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # When tqdm is imported first time, `default_miniters` isn't defined yet
    # (See https://github.com/tqdm/tqdm/issues/312)
    from tqdm import tqdm
    tqdm.pandas()
    _, t = tqdm(enumerate([0, 1, 2]))
    t.restart()


from ._version import get_versions
__version__ = get_versions()['version']
del get_versions

from tqdm import tqdm as _tqdm
from tqdm import trange as _trange
from tqdm import TqdmDeprecationWarning
from tqdm import TqdmExperimentalWarning
from tqdm import TqdmKeyError
from tqdm import TqdmTypeError

# Generated at 2022-06-22 04:47:50.229104
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm.contrib import pandas
    from pandas.core.groupby import DataFrameGroupBy

    # Tests that a tqdm(...) is registered for the DataFrameGroupBy class
    assert 'progress_apply' in dir(tqdm(DataFrameGroupBy, leave=False))

    # Tests that a tqdm(...) is registered for the DataFrameGroupBy class
    # when the first input to tqdm_pandas is an instance of tqdm
    assert 'progress_apply' in dir(tqdm_pandas(tqdm(DataFrameGroupBy, leave=False)))

    # Tests that a tqdm(...) is registered for the DataFrameGroupBy class
    # when the first input to tqdm_pandas is a class object

# Generated at 2022-06-22 04:48:01.942933
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    import warnings

    # Test error
    with pytest.raises(ValueError) as e:
        tqdm_pandas("")
    assert str(e.value) == ("`tqdm_pandas(tqdm)` is "
                            "deprecated, use `tqdm.pandas()` instead!")

    # Test deprecated
    with warnings.catch_warnings(record=True) as _:
        warnings.simplefilter("always")
        tqdm_pandas(tqdm.tqdm)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

# Generated at 2022-06-22 04:48:06.066609
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    tqdm.pandas()
    tmp = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    tmp['y'] = 1
    tmp.groupby(0).progress_apply(lambda x: x**2)

# Generated at 2022-06-22 04:48:17.551597
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from pandas import DataFrame
    except ImportError:
        return
    tqdm_pandas(tqdm.tqdm(total=1))
    assert not tqdm.class_has_own_tqdm(DataFrame.progress_apply)
    _orig_range = DataFrame.progress_apply.__code__.co_varnames
    df = DataFrame()
    with tqdm.tqdm(total=1) as t:
        df.progress_apply(lambda: t.update())
    assert tqdm.class_has_own_tqdm(DataFrame.progress_apply)
    assert tqdm.class_has_own_tqdm(DataFrame.progress_apply.__wrapped__)

# Generated at 2022-06-22 04:48:18.534280
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tqdm_pandas(tqdm)



# Generated at 2022-06-22 04:48:24.482983
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        assert 'pandas' in sys.modules
    except ImportError:
        raise unittest.SkipTest("pandas not found")
    assert hasattr(pandas.core.groupby.GroupBy, 'progress_apply')

    tqdm_pandas(tqdm)

    try:
        import numpy
        assert 'numpy' in sys.modules
        assert hasattr(numpy.core.ufunc, '__tqdm_version__')
    except (ImportError, AttributeError):
        raise unittest.SkipTest("numpy not found")

    tqdm_pandas(tqdm)

# Generated at 2022-06-22 04:48:32.006474
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange
    from tqdm.auto import tqdm

    for t in [pd, pd.Series]:
        for tclass in [tqdm, trange]:
            tqdm_pandas(t, tclass)
            assert np.all(t.DataFrame.progress_apply.func_globals.get(
                'tqdm') == tclass)

    tqdm_pandas(tqdm)
    assert np.all(pandas.DataFrame.progress_apply.func_globals.get(
        'tqdm') == tqdm)

    tqdm_pandas(trange)

# Generated at 2022-06-22 04:48:40.741802
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.autonotebook import tqdm
    from tqdm._tqdm_pandas import pandas

    from tqdm import trange
    from pandas import DataFrame, Series

    def func(x):
        return x**2
    df = DataFrame({'a': range(1000), 'b': range(1000)})
    # regular test
    res = df.groupby('a').progress_apply(func)
    pandas(tqdm=tqdm)
    res = df.groupby('a').progress_apply(func)
    # delayed adapter test
    res = df.groupby('a').progress_apply(func)
    pandas(tqdm=tqdm, total=1000)
    res = df.groupby('a').progress_apply(func)
    s = Series

# Generated at 2022-06-22 04:48:53.569443
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    import time
    import random

    test_df = pd.DataFrame({"id": range(5), "value": range(-2, 3)})
    test_dict = {"id": [0, 1, 2], "value": [3, 4, 5]}
    test_series = test_df["id"]
    test_list = list(range(10))

    for use_tqdm_pandas in [True, False]:
        test_df.groupby("id").progress_apply(lambda group: group)
        if use_tqdm_pandas:
            from tqdm import trange
            tqdm.pandas(tqdm_class=trange)

# Generated at 2022-06-22 04:48:58.240361
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.contrib.tests import tclass
    tqdm_pandas(tclass(**{'desc': 'test_tqdm_pandas'}),
                total=100, group_by=10)
    pd.Series(range(100)).progress_apply(lambda x: x + 1)



# Generated at 2022-06-22 04:49:08.823245
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        import tqdm

        df = pd.DataFrame({'a': np.arange(10000)})

        def nullfunc(x):
            return x

        tqdm_pandas(tqdm.tqdm)
        assert hasattr(df.groupby('a'), 'progress_apply')

        # Iterator version
        res = df.groupby('a').progress_apply(nullfunc)
        assert (res == df.groupby('a')).all()

        # Apply version (new in pandas 0.25.0)
        res = df.progress_apply(nullfunc)
        assert (res == df).all()

    finally:
        # Unregister tqdm for pandas
        tqdm_pandas(None)

# Generated at 2022-06-22 04:49:16.388297
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series

    df = DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]}, index=['a', 'b', 'c'])
    s = Series(['a', 'b', 'c'], name='idx')

    def f(x):
        return x

    with tqdm(total=len(df)) as pbar:
        df.progress_apply(f, axis=0, args=(pbar,))
        df.progress_apply(f, axis=1, args=(pbar,))
        s.progress_apply(f, args=(pbar,))

# Generated at 2022-06-22 04:49:27.778815
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    import pandas as pd
    import numpy as np
    from tqdm._tqdm import TqdmKeyError
    from tqdm._tqdm import TqdmTypeError

    # Test tclass is not a tqdm class
    with pytest.raises(TqdmTypeError):
        tqdm_pandas(tclass=range(3), total=3)

    # Test tclass is not a tqdm class
    with pytest.raises(TqdmTypeError):
        tqdm_pandas(tclass=tuple('abc'), total=3)

    # Test tclass is not a tqdm class
    with pytest.raises(TqdmTypeError):
        tqdm_pand

# Generated at 2022-06-22 04:49:39.339274
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    from tqdm.contrib.concurrent import process_map

    from pandas.util.testing import assert_series_equal
    from numpy.testing import assert_array_equal

    n = 1e4
    df = pd.DataFrame({"a": range(n), "b": range(n), "c": range(n), "d": range(n)})


# Generated at 2022-06-22 04:49:49.075381
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import trange
    from tqdm._utils import _term_move_up
    from tqdm.std import tqdm
    from tqdm.tests.utils import _range

    tqdm.pandas()

    df = pd.DataFrame({'a': np.random.randint(0, 5, 100),
                       'b': np.random.randint(0, 5, 100)})

    pd.DataFrame().groupby('.').progress_apply(lambda x: x)

    assert df.groupby('a').progress_apply(lambda x: x + 1).equals(
        df.groupby('a').apply(lambda x: x + 1))


# Generated at 2022-06-22 04:49:51.287706
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        # (Just to make sure it doesn't fail if pandas is not installed)
        import pandas
        tqdm_pandas(tqdm)
    except ImportError:
        pass

# Generated at 2022-06-22 04:50:03.519292
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    # Create a pandas DataFrame
    example = pd.DataFrame({'1': [1] * 5, '2': [2] * 5})
    # Unit test for the deprecated case
    from tqdm import tqdm
    t = tqdm()
    tqdm_pandas(t, example)
    from tqdm import TqdmTypeError
    assert isinstance(t.deprecated_t, TqdmTypeError)
    # Unit test for the new case
    tqdm_pandas(tqdm, example)
    assert isinstance(t, pd.core.groupby.DataFrameGroupBy)
    # Unit test for staticmethod case
    tqdm_pandas(tqdm.pandas, example)

# Generated at 2022-06-22 04:50:12.958658
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm
    N = 1000
    X = np.random.randn(N)
    df = pd.DataFrame(X, columns=['a'])
    Y = pd.Series(X)
    tqdm.pandas(tqdm)
    df.groupby(df.a // 1).progress_apply(lambda dfx: dfx)  # test progress_apply

    tqdm.pandas(tqdm)  # test repeated registration
    tqdm.pandas(tqdm)

    for i in tqdm.trange(N):
        df.a.progress_apply(lambda x: x)  # test apply
    Y.progress_apply(lambda x: x)  # test apply
    # test over

# Generated at 2022-06-22 04:50:39.228121
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    frame = pd.DataFrame({'col': np.random.uniform(0, 1,
                         (1000000,))}).groupby('col').sum()

    # Test function tqdm_pandas which should not be called
    try:
        from tqdm import tqdm_pandas as tp
        raise AssertionError("Please use tqdm.pandas(...) instead of tqdm_pandas(...)")
    except ImportError:
        pass

    # Test tqdm.pandas
    try:
        from tqdm.auto import tqdm
    except ImportError:
        return

    tqdm.pandas(desc="test")
    assert str(frame.progress_apply(lambda x: x)).start

# Generated at 2022-06-22 04:50:43.846522
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    x = [1, 2]
    x = pd.DataFrame({'a': x})
    tqdm_pandas(tqdm(x))


# Generated at 2022-06-22 04:50:51.861457
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    >>> import pandas as pd
    >>> from tqdm import tqdm_pandas
    >>> pd.DataFrame([[1, 2], [3, 4]]).groupby(0).sum().progress_apply(lambda x: x, meta=int)
    ... # doctest: +NORMALIZE_WHITESPACE
    0  1    2
    1  3    4
    2  4    6
    3  6    8
    """
    pass

# Generated at 2022-06-22 04:51:02.958974
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for tqdm_pandas."""
    from pandas import DataFrame
    from numpy.random import randint
    tqdm_pandas(type(TqdmType()))

    def iteration_factory(n):
        def iteration(x):
            for _ in range(n):
                x += 1
            return x
        return iteration

    df = DataFrame({"A": [], "B": []})
    # test for DataFrame
    for _ in range(5):
        df = df.append({"A": randint(0, 4), "B": randint(0, 10)}, ignore_index=True)
    df.groupby("A").progress_apply(iteration_factory(randint(1, 9)))

# Generated at 2022-06-22 04:51:12.065867
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas
    from pandas import DataFrame

    # Test without any dependency
    tqdm_pandas(tclass=None)

    # Test with dependencies
    tqdm_pandas(tclass=tqdm_pandas)

    # Test with tqdm
    tqdm_pandas(tclass=tqdm)

    # Test with tqdm(..., unit='cols')
    tqdm_pandas(tclass=tqdm(unit='cols'))

    # Test with tqdm(...)
    tqdm_pandas(tclass=tqdm())

    # Test with tqdm(..., leave=True)
    tqdm_pandas(tclass=tqdm(leave=True))

   

# Generated at 2022-06-22 04:51:22.193470
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_notebook
    N = 100000
    df = pd.DataFrame()
    df['value'] = list(range(N))
    # tqdm_notebook
    tqdm_pandas(tqdm_notebook, smoothing=0)
    res = df.groupby(['value']).progress_apply(lambda x: x)
    # tqdm
    tqdm_pandas(tqdm)
    res = df.groupby(['value']).progress_apply(lambda x: x)
    # tqdm
    tqdm_pandas(tqdm(smoothing=0))
    res = df.groupby(['value']).progress_apply(lambda x: x)
    #

# Generated at 2022-06-22 04:51:27.090595
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tclass = tqdm_pandas
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)
        tqdm_pandas(tclass)  # delayed adapter case
        tqdm_pandas(tclass)  # normal case
        tqdm_pandas(tqdm)  # normal case

# Generated at 2022-06-22 04:51:37.420859
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time
    from tqdm.pandas import tqdm_pandas
    bins = np.arange(0.0, 1.0, 0.1)
    df = pd.DataFrame(
        dict(floats=np.random.random_sample(1000), ints=np.random.randint(1, 10, size=1000)))
    grouped = df.groupby('ints')

    tqdm_pandas(t_class=tqdm_notebook, smoothing=0)

    out = grouped.progress_apply(lambda x: x["floats"].sum())
    print(out)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:46.407655
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # Create a sample dataset to mimic real cases
    n_rows = 100
    pd_df = pd.DataFrame()
    col_names = ['Age', 'Sex']
    col_range = [[i for i in range(n_rows)],
                 ['M' for i in range(n_rows // 2)] + ['F' for i in range(n_rows // 2)]]
    for i in range(len(col_names)):
        pd_df[col_names[i]] = col_range[i]
    pd_df = pd_df.sample(frac=1)

    # Show the result of groupby
    groupby_result = pd_df.groupby('Sex').progress_apply(lambda x: x)
   

# Generated at 2022-06-22 04:51:53.245329
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return
    try:
        tqdm.pandas()
        import pandas.core.groupby
        assert 'progress_apply' in dir(pandas.core.groupby.DataFrameGroupBy)
        tqdm.pandas(leave=True)
        assert 'progress_apply' not in dir(pandas.core.groupby.DataFrameGroupBy)
    except AssertionError:
        print(pandas.core.groupby.DataFrameGroupBy.__dict__)
        raise



# Generated at 2022-06-22 04:52:34.485394
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import re
    import pandas as pd
    import numpy as np
    from io import StringIO
    from tqdm import tqdm, TqdmDeprecationWarning

    df = pd.DataFrame(np.arange(1e5))
    with tqdm(total=len(df)) as pbar, StringIO() as buf:
        tqdm_pandas(pbar, file=buf)
        df.progress_apply(lambda x: x)

# Generated at 2022-06-22 04:52:43.265988
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    try:
        # noinspection PyUnresolvedReferences
        import pandas.util.testing as pdt
        # noinspection PyUnresolvedReferences
        from pandas.core.groupby import GroupByError
        test_pandas = True
    except ImportError:
        test_pandas = False

    if not test_pandas:
        return

    df = pd.DataFrame(dict(col1=np.arange(100), col2=1))
    dfgb = df.groupby('col2')

    # Test for https://github.com/tqdm/tqdm/issues/564
    # Test for https://github.com/tqdm/tqdm/issues/625


# Generated at 2022-06-22 04:52:53.637192
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Tests for :func:`tqdm_pandas`."""
    from tqdm.auto import trange
    from pandas import DataFrame

    # Current function
    tqdm_pandas(trange(5))

    # Delayed function
    tqdm_pandas(trange)
    trange().pandas()

    # pandas
    df = DataFrame(dict(x=[1, 2, 3], y=[4, 5, 6]))
    df.groupby("y").pandas(trange)()


# Run the unit tests when this file is the main file (not imported from elsewhere)
if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:53:00.057975
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy
    import pandas
    from pandas import DataFrame
    from pandas import Series
    from tqdm import tqdm_pandas

    df = DataFrame({'a': numpy.random.rand(int(1e3)),
                    'b': ['foo'] * int(1e3)})
    s = Series(numpy.random.rand(int(1e3)))

    tqdm_pandas(tqdm_kwargs={'desc': 'L1'})
    df.groupby('b').a.progress_apply(lambda x: x * 3)
    tqdm_pandas(tqdm_kwargs={'desc': 'L2'})
    s.progress_apply(lambda x: x * 3)

# Generated at 2022-06-22 04:53:03.883272
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    df = pd.DataFrame({'A': [1, 2, 3]}, index=['x', 'y', 'z'])
    try:
        from tqdm.auto import tqdm
        import tqdm
        tqdm_pandas(tqdm, leave=True)
        result = df.groupby('A').progress_apply(lambda x: x)
        assert isinstance(result, pd.core.groupby.generic.DataFrameGroupBy)
    finally:
        tqdm.pandas(False)