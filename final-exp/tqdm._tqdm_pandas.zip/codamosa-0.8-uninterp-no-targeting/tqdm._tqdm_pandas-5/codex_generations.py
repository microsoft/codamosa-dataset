

# Generated at 2022-06-22 04:43:14.894977
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Simple unit test for tqdm_pandas"""
    from tqdm.autonotebook import tqdm

    @tqdm_pandas
    def dummy_pandas_evaluate(df):
        return df['col'].apply(lambda x: x)

    @tqdm_pandas
    def dummy_pandas_aggregate(df):
        return df.groupby('col').progress_apply(lambda x: x)

    @tqdm_pandas
    def dummy_pandas_transform(df):
        return df.groupby('col').progress_apply(lambda x: x)

    try:
        import pandas as pd  # break up try/except to avoid circular imports
    except ImportError:
        pass

# Generated at 2022-06-22 04:43:19.940229
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test"""
    # (1) Start progress bar
    tqdm_pandas(tqdm(total=10))
    # (1) Close progress bar
    gc.collect()


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:43:25.836724
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm as t
    # Base case
    tqdm_pandas(t)
    # Delayed adapter
    tqdm_pandas(t, desc='desc')
    # Pandas case
    from pandas import DataFrame
    tqdm_pandas(t(DataFrame()), desc='desc')

# Generated at 2022-06-22 04:43:38.156113
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except BaseException:
        return
    from tqdm.auto import tqdm

    try:
        with tqdm(total=1) as t:
            tqdm_pandas(t)
            pd.Series(range(10)).progress_apply(lambda x: x + 1)
            t.close()
    except BaseException:
        pass
    try:
        with tqdm(total=1) as t:
            tqdm_pandas(t)
            pd.Series(range(10)).progress_map(lambda x: x + 1)
            t.close()
    except BaseException:
        pass

# Generated at 2022-06-22 04:43:46.544080
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        from tqdm import tqdm
        tqdm_pandas(tqdm)
        # tqdm_pandas(tqdm(total=123))
    except Exception as e:
        warnings.warn(
            'tqdm pandas dependency not found, test_tqdm_pandas() '
            'returned error: {0}'.format(e),
            RuntimeWarning)

# Generated at 2022-06-22 04:43:58.491321
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    import numpy as np
    from tqdm import tqdm
    tqdm_pandas(tqdm, desc='test')
    # Test speedup
    df = pd.DataFrame({'a': np.arange(1000)})
    assert (df.groupby('a').progress_apply(lambda x: x).equals(df))
    # Test updated description
    df = pd.DataFrame({'a': np.arange(10000)})
    tqdm.pandas(desc='test2')
    assert (df.groupby('a').progress_apply(lambda x: x).equals(df))
    # Test special pandas error
    from tqdm.contrib.tests import logging_error_re

# Generated at 2022-06-22 04:44:07.002699
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        from tqdm import tqdm
        from tqdm import trange
    except:
        return
    df = pd.DataFrame({"x": list(range(5))})
    for t in [trange, tqdm]:
        for n in [None, 10]:
            for min_ in [0, 1]:
                # Register `tqdm` to `progress_apply`
                tqdm_pandas(t)
                # Register `tqdm(...)` to `progress_apply`
                tqdm_pandas(t(n, mininterval=min_))
                # Register `tqdm(...)` to `progress_apply`

# Generated at 2022-06-22 04:44:15.839496
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    pd.core.groupby.DataFrameGroupBy.progress_apply = tqdm_pandas(
        tqdm, dynamic_ncols=True)
    df = pd.DataFrame([[1, 1, 1], [1, 1, 1], [1, 1, 1]])
    df.groupby(0).progress_apply(lambda x: list(x)).compute()
    df.groupby(0).progress_apply(lambda x: list(x)).compute(scheduler='processes')

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:28.017501
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    # Test with class
    try:
        with tqdm_pandas(tqdm):
            assert False  # pragma: no cover
    except TqdmDeprecationWarning:
        pass

    # Test with instance
    t = tqdm()
    try:
        with tqdm_pandas(t):
            assert False  # pragma: no cover
    except TqdmDeprecationWarning:
        pass

    # Test with deprecated name
    try:
        with tqdm_pandas(tqdm_notebook):
            assert False  # pragma: no cover
    except TqdmDeprecationWarning:
        pass

    # Test that it actually works
    test_data = pd.DataFrame([1, 2, 3])

# Generated at 2022-06-22 04:44:28.931261
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    pass


# Generated at 2022-06-22 04:44:35.393561
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm_pandas

    # Test whether the progress bar is called
    df = pd.DataFrame([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], columns=['a'])
    df = df.groupby('a')
    tqdm_pandas(df)
    df.progress_apply(lambda x: int(np.sum(x)))
    print("test_tqdm_pandas: PASS")


test_tqdm_pandas.unit_test = True


# Generated at 2022-06-22 04:44:46.741947
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(total=1))

# Enable tests with `python -m tqdm.tests.test_pandas`
if __name__ == "__main__":
    from .tests import TestCase
    from .utils import closing, FreezableIter
    from tqdm._tqdm_gui import tqdm_gui

    class TestPandas(TestCase):
        def test_pandas(self):
            with closing(StringIO()) as our_file:
                test_data = pd.DataFrame([[1, 2], [4, 5], [7, 8]],
                                         columns=['A', 'B'])
                our_tqdm = tqdm(file=our_file, leave=False)


# Generated at 2022-06-22 04:44:57.872676
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        assert pandas.__version__ >= '0.17'
    except ImportError:
        warnings.warn("`pandas` not installed, cannot test `tqdm_pandas`")
    else:
        import numpy as np
        from tqdm.autonotebook import tqdm
        from tqdm.utils import _supports_unicode

        # with tqdm(total=10) as pbar:
        #     for _ in range(10):
        #         pbar.update()

        total = 100
        df = pandas.DataFrame({
            'x': np.random.randint(0, total, total),
            'y': np.random.rand(total),
            'z': np.random.randint(0, 1000, total)
        })

# Generated at 2022-06-22 04:45:06.400926
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    def verify_pandas_usage():
        import numpy as np
        np.random.seed(0xB00B1E5)

        N, M = 1_000_000, 100
        df = pd.DataFrame({
            'key': np.random.randint(0, N, size=M),
            'value': np.random.choice(list('abcdefghijklmnopqrstuvwxyz'),
                                      size=M)})
        df2 = df.groupby('key').value.agg(lambda s: ''.join(sorted(s)))
        df3 = df2.progress_apply(lambda s: np.sum(list(map(ord, s))))

        return df2, df3

   

# Generated at 2022-06-22 04:45:15.830544
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    def func(df, factor=1):
        return df * factor

    df = pd.DataFrame(np.random.randint(1, 10, (100000, 4)), columns=list('ABCD'))

    with tqdm_pandas(tclass=tqdm, unit='rows') as sort_bar:
        res = df.groupby(by='A').progress_apply(func, factor=2)

    with tqdm_pandas(tclass=tqdm, unit='rows') as sort_bar:
        res = df.groupby(by='A').progress_apply(func, factor=2, args=())

    with tqdm_pandas(tclass=tqdm, unit='rows') as sort_bar:
        res

# Generated at 2022-06-22 04:45:24.395292
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({'a': np.random.rand(1000),
                       'b': np.random.rand(1000)})

    try:
        import tqdm
    except ImportError:
        try:
            import tqdm_pandas
        except ImportError:  # pragma: no cover
            raise
        return tqdm_pandas.tqdm_pandas(df.groupby(0).progress_apply(lambda x: x))
    else:
        return tqdm.pandas(df.groupby(0).progress_apply(lambda x: x))



# Generated at 2022-06-22 04:45:34.625234
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    # Using `wraps` for preserving the `__dict__` of the given iterable
    from tqdm.contrib.concurrent import process_map
    from multiprocessing import cpu_count
    with tqdm(total=len(df)) as pbar:
        result = process_map(
            lambda x: x,
            df.groupby(0).progress_apply(lambda x: x),
            max_workers=cpu_count(),
            pbar=pbar)
        assert len(result) == len(df)
    # Test tqdm_pandas(tqdm_notebook, ...)

# Generated at 2022-06-22 04:45:39.523757
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    tqdm_pandas(tqdm())

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:45.742102
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    from pandas import DataFrame
    from tqdm._tqdm_gui import tqdm

    df = DataFrame(np.random.rand(10000, 1000), columns=np.arange(1000))
    diff = df.progress_apply(lambda x: x.sum()) - df.apply(lambda x: x.sum())
    assert not diff.any().any()

    df = DataFrame(np.random.rand(10000, 1000), columns=np.arange(1000))
    diff = df.progress_apply(lambda x: x.sum()) - df.apply(lambda x: x.sum())
    assert not diff.any().any()

    df = DataFrame(np.random.rand(10000, 1000), columns=np.arange(1000))

# Generated at 2022-06-22 04:45:56.851939
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    import numpy as np

    for _ in tqdm_pandas(range(10)):
        pandas.DataFrame(np.random.rand(100, 100)).progress_apply(
            lambda x: x.sum(),
            axis=1)


if __name__ == '__main__':
    """
    Unit test for pandas interface
    """
    import pandas as pd
    import numpy as np

    # Setup pandas
    df = pd.DataFrame(np.random.randn(1000000, 8), columns=list('abcdefgh'))

    print("Testing on pandas version: " + pd.__version__)

    # Case 1: No `tqdm` instance in scope.

# Generated at 2022-06-22 04:46:08.509320
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    try:
        from tqdm.autonotebook import tqdm
    except:
        from tqdm import tqdm
    from tqdm.contrib.tests import dummy_dfg_apply, dummy_df_apply
    from tqdm.contrib import pandas


    pandas.tqdm_pandas()
    for i in range(1):
        for j in [tqdm, tqdm.pandas]:
            t = j(total=1000)
            for k in tqdm(range(5), leave=False, ascii=True,
                          dynamic_ncols=True):
                dummy_dfg_apply(i, t.update)
                dummy_df_apply(i, t.update)
                t.n = 3 * k

# Generated at 2022-06-22 04:46:19.330518
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.contrib.tests import TqdmTestCase, pretest_posttest_run

    class TestPandas(TqdmTestCase):
        def test_tqdm_pandas(self):
            """Test `tqdm_pandas()`"""
            df = pd.DataFrame({'x': [1, 2, 3, 4, 5]})
            for index, row in tqdm(df.iterrows(),
                                   desc='Iterating rows'):
                self.assertEqual(row['x'] - 1, index)

# Generated at 2022-06-22 04:46:30.641902
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        tclass = tqdm(range(100))
        tqdm_pandas(tclass)
        df = pd.DataFrame(np.random.rand(1000000, 4), columns=list('ABCD'))
        df.groupby('A').progress_apply(lambda x: x)
    except ImportError:
        pass  # pandas not installed
    else:
        TqdmDeprecationWarning.warn = mock.Mock()
        with warnings.catch_warnings():
            warnings.filterwarnings('error')
            try:
                tqdm_pandas(tqdm, bar_format='{l_bar}')
                assert False
            except TqdmDeprecationWarning:
                assert True

# Generated at 2022-06-22 04:46:41.557363
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    """Unit test for `tqdm.tqdm_pandas`."""
    from pandas import DataFrame
    from tqdm.auto import tqdm
    try:
        import pandas as pd
        pd.core.groupby.DataFrameGroupBy.progress_apply  # avoid erroring out if pandas not installed
    except (ModuleNotFoundError, AttributeError):
        return
    df = DataFrame(dtype=float, data={'foo': [0, 1, 2, 3, 4],
                                      'bar': [0, 1, 2, 3, 4]})
    tqdm_pandas(tqdm)
    df.groupby('foo', as_index=False).progress_apply(lambda x: x.sum())

# Generated at 2022-06-22 04:46:50.486599
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm_pandas as old_tqdm_pandas
    from pandas import DataFrame
    from numpy import random
    from time import sleep

    def func(dfgrp, tqdm=True):
        if tqdm:
            old_tqdm_pandas(tclass=tqdm)

        for sleep_time in dfgrp:
            sleep(sleep_time)

        return dfgrp.mean()

    class_dict = {'experiment': ['A', 'A', 'A', 'A', 'A', 'B', 'B', 'B', 'B', 'B'],
                  'readings': random.randint(1, 10, 10)}
    df = DataFrame(class_dict)
    grp = df.groupby('experiment')
    df

# Generated at 2022-06-22 04:47:02.006168
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import trange
    import pandas as pd
    import numpy as np
    import time
    import warnings

    # -- tqdm pandas
    n = 10000
    df = pd.DataFrame({'x': np.random.randint(0, n, size=n)})

    # -- print progress
    # `df.groupby(...).progress_apply` is recommended if the apply function is slow
    with trange(100) as t:
        for i in t:  # print progress bar for every iteration
            df.groupby('x').progress_apply(lambda x: time.sleep(0.001))
            t.set_description(f"Iteration {i}")

    # `df.progress_apply` works even when there is no groupby

# Generated at 2022-06-22 04:47:10.512471
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        tqdm_pandas(tqdm())
        tqdm_pandas(tqdm(total=100))
        tqdm_pandas(tqdm(total=100, postfix='abc'))
        tqdm_pandas(tqdm(total=100, postfix='abc', desc='xyz'))
    except ImportError:
        pass
    except:
        print('ERROR: tqdm_pandas() unit test failed')
        raise

# Generated at 2022-06-22 04:47:14.789371
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    from tqdm import tqdm, trange

    df = pd.DataFrame(np.random.rand(1000, 1000))

    for t in [df.progress_apply, df.groupby(0).progress_apply,
              trange, tqdm.tqdm_notebook, tqdm]:
        tqdm_pandas(t)

# Generated at 2022-06-22 04:47:26.392995
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    '''Unit test for function tqdm_pandas'''
    import pandas as pd
    from tqdm import tqdm
    from tqdm.autonotebook import tqdm as tqdm_notebook
    try:
        from tqdm.terminal import tqdm as tqdm_terminal
    except ImportError:
        tqdm_terminal = lambda x: x

    def mock_progress_apply(df, *l, **k):
        """Mock `pandas.DataFrame.progress_apply`"""
        return df
    pd.DataFrame.progress_apply = mock_progress_apply

    def check(t):
        """Check that `tqdm_pandas` registers callback with pandas"""
        df = pd.DataFrame([])

# Generated at 2022-06-22 04:47:36.913644
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas"""
    from tqdm import tqdm
    import pandas as pd
    import numpy as np

    class dummy(tqdm):

        def __init__(self):
            self.tp = 123
            self.total = 123
            self.n = 123

    tqdm_pandas(dummy)
    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    # tqdm_pandas(tqdm)
    df.groupby(0).progress_apply(lambda x: x ** 2)
    # tqdm_pandas(tqdm(total=100))
    df.groupby(0).progress_apply(lambda x: x ** 2)



# Generated at 2022-06-22 04:47:45.744872
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
        tqdm_pandas(tqdm())
    except ImportError:
        pass
    else:
        assert True


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:47:52.613574
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
    df.groupby('x').progress_apply(lambda x: int(x))
    # Give some time for threads to start
    import time; time.sleep(1e-7)
    assert(len(tqdm._instances) > 0)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:04.072594
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import TqdmTypeError, TqdmDeprecationWarning
    import io
    try:
        tqdm_pandas(1)
    except TqdmTypeError as e:
        assert str(e) == 'Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.'
    try:
        tqdm_pandas(tqdm_pandas)
    except TqdmDeprecationWarning as e:
        assert str(e) == 'Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.'

# Generated at 2022-06-22 04:48:08.431851
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np, pandas as pd
    from tqdm.auto import tqdm
    df = pd.DataFrame({'A': np.random.randn(10),
                       'B': np.random.randn(10),
                       'C': np.random.randn(10)})
    with tqdm(total=df.groupby('C').size().sum()) as pbar:
        df.groupby('C').progress_apply(lambda x: (pbar.update(), x))

# Generated at 2022-06-22 04:48:19.530386
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib import pandas

    tclass = pandas.tqdm
    tqdm_kwargs = {}

    from tqdm.tests import FakePandasModule

    # TODO: make this test more robust
    sys.modules['pandas'] = FakePandasModule

    del pandas.tqdm_pandas

    try:
        tqdm_pandas(tclass, **tqdm_kwargs)
    except TypeError:
        pass  # no need to handle

    del pandas.tqdm_pandas


if __name__ == '__main__':
    try:
        test_tqdm_pandas()
    except Exception as e:
        print('\nError in tqdm.contrib.pandas:\n{}'.format(e))

# Generated at 2022-06-22 04:48:25.490107
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for function 'tqdm_pandas' """
    import tqdm.pandas
    tqdm_pandas(tqdm.pandas, smoothing=1, mininterval=5)



# Generated at 2022-06-22 04:48:27.732505
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for the function tqdm_pandas"""
    # This will be tested in `tqdm/tests/test_pandas.py`
    assert True

# Generated at 2022-06-22 04:48:39.709040
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        return None

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')

        tqdm_pandas(tqdm())
        tqdm_pandas(tqdm(total=100, file=io.StringIO()))
        tqdm_pandas(tqdm(total=100, file=io.StringIO()),
                    desc='Custom desc')
        tqdm_pandas(tqdm(total=100, file=io.StringIO()),
                    leave=False)
        tqdm_pandas(tqdm(total=100, file=io.StringIO()),
                    dynamic_ncols=True)

        assert len(w) == 5

# Generated at 2022-06-22 04:48:47.339308
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm(file=2))
    tqdm_pandas(tqdm.tqdm_gui)
    tqdm_pandas(tqdm.tqdm_notebook)
    tqdm_pandas(tqdm.trange)


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:49.047788
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:02.379530
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm, tqdm_pandas
    import pandas as pd
    import numpy as np
    l = list(range(1, 999))
    df = pd.DataFrame(np.random.random(size=(999, 999)))

    # Test tqdm object
    with tqdm(total=len(l), miniters=len(l) // 10, maxiters=0, unit="it") as pbar:
        df.progress_apply(lambda x: pbar.update(1))

    # Test tqdm_pandas decorator
    @tqdm_pandas
    def df_func(df):
        return df
    df_func(df)


# tqdm_pandas = tqdm.tqdm_pandas



# Generated at 2022-06-22 04:49:11.948658
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test (doctest) for tqdm_pandas function."""
    try:
        import pandas as pd
        df = pd.DataFrame({'A': [1, 2, 3]})
        t = tqdm_pandas(tqdm(total=df.shape[0]), desc="test")
        assert tqdm_pandas.__doc__ in repr(tqdm_pandas)
        assert tqdm_pandas.__doc__ == tqdm_pandas.__doc__
    except Exception:
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:22.381960
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    from tqdm.std import DataFrameGroupBy

    # Create pandas DataFrame
    df = pd.DataFrame(np.arange(20).reshape(4, 5), columns=list('abcde'))
    # Create test cases

# Generated at 2022-06-22 04:49:25.491468
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm(ncols=80, desc='Testing tqdm_pandas()'))

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:49:35.222054
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    t = tqdm(total=100, initial=50)
    assert t.n == 50
    tqdm_pandas(t)
    t.start_t = "unit test"
    assert isinstance(t.bar_format, str)
    tqdm_pandas(t, bar_format="test")
    assert t.bar_format == "test"
    assert tqdm_pandas.__doc__
    assert tqdm_pandas.__all__ == ['tqdm_pandas']
    assert tqdm_pandas.__author__ == "github.com/casperdcl"
    assert inspect.isfunction(tqdm_pandas)




#################################################################
#                                                               #
#   TQDM

# Generated at 2022-06-22 04:49:46.980096
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    df = pd.DataFrame(dict(l=[2, 3, 4]))
    with tqdm(total=len(df), unit='row') as t:
        tqdm.pandas(t)
        df['new'] = df['l'].progress_apply(lambda x: x**2)
        assert(df['new'].equals(pd.Series([4, 9, 16])))
        t.close()

    with tqdm() as t:
        tqdm_pandas(t)
        df['new'] = df['l'].progress_apply(lambda x: x**2)
        assert(df['new'].equals(pd.Series([4, 9, 16])))
        t.close()


# Generated at 2022-06-22 04:49:53.905862
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.auto import tqdm
    try_dep = [None, True, False]
    try:
        # pandas doesn't exist
        import pandas
        del pandas
        raise ImportError
    except ImportError:
        try_dep.extend([None, True, False])
    for dep in try_dep:
        tqdm_pandas(tqdm, pandas_dep=dep)
        df = pd.DataFrame([[np.nan, 2, np.nan, 0], [3, 4, np.nan, 1],
                           [np.nan, np.nan, np.nan, 5]],
                          columns=list('ABCD'))

# Generated at 2022-06-22 04:50:01.533313
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # tqdm_pandas(tqdm)
    import tqdm
    import pandas

    df = pandas.DataFrame({'c1': [1, 2, 3, 4], 'c2': ['a', 'b', 'c', 'd']})
    for _ in df.groupby('c1').progress_apply(lambda x: x):
        pass


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:11.908432
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test"""
    from tqdm import tqdm as tclass, tqdm_pandas as tqdm_pandas_

    # deprecated style
    tqdm_pandas_(tclass)
    tqdm_pandas_(tqdm)
    tqdm_pandas_(tqdm_pandas_)

    # proper style
    tclass.pandas()
    tqdm.pandas()
    tqdm_pandas_.pandas()
    try:
        tclass.pandas(leave=True)
        assert False
    except TypeError:
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:22.166876
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd

    def _test_tqdm_pandas(tclass):
        raw_list = list(range(20)) * 2
        raw_list = pd.DataFrame({'col': raw_list})
        raw_list = raw_list.groupby('col')

        res_list = list(raw_list.progress_apply(lambda x: x))
        assert res_list == [raw_list.get_group(i) for i in range(20)]

        fail = False
        try:
            raw_list.progress_apply(lambda x: False)
        except AssertionError:
            fail = True
        assert fail

    def _test_tqdm_pandas_depr(tclass):
        tqdm_pandas(tclass)


# Generated at 2022-06-22 04:50:29.148174
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        tqdm_pandas(tqdm(total=100))
        tqdm_pandas(tqdm)
        return True
    except Exception:
        return False


# Generated at 2022-06-22 04:50:37.678123
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm

    df = pd.DataFrame(np.arange(100000), columns=['A'])
    # Delayed adapter case
    tqdm_pandas(tqdm, total=len(df))
    # Manual adapter case
    tqdm_pandas(tqdm(total=len(df)))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:44.445726
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame({'a': range(5)})
    tqdm_pandas(tqdm.tqdm(total=len(df)))


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-22 04:50:52.934908
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np

    tqdm_pandas(tqdm())
    # check if register
    assert hasattr(pd.core.groupby.DataFrameGroupBy, 'progress_apply')
    # test progress_apply
    df = pd.DataFrame(np.random.randint(0,100,size=(100000, 4)))
    tqdm_pandas(tqdm())
    res = df.groupby(0).progress_apply(lambda x: x**2)  # noqa


# Generated at 2022-06-22 04:51:02.367096
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    import numpy as np
    import pandas as pd

    tqdm_kwargs = {"mininterval": 0.01}
    progress = tqdm_pandas(tqdm, **tqdm_kwargs)

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
    df.groupby(0).progress_apply(lambda x: x ** 2)


if __name__ == '__main__':
    from tqdm import main
    main()

# Generated at 2022-06-22 04:51:10.988842
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange

    # Test tqdm
    tqdm_pandas(tqdm)
    dl = [-1, 1]
    df = pd.DataFrame({'a': dl})
    G = df.groupby('a', as_index=False)
    assert G.progress_apply(int).values == [1, -1]

    # Test tqdm_gui
    try:
        from tqdm import tqdm_gui
    except ImportError:
        pass
    else:
        tqdm_pandas(tqdm_gui)
        assert G.progress_apply(int).values == [1, -1]



# Generated at 2022-06-22 04:51:22.115145
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm.pandas import tqdm_pandas
    try:
        tqdm_pandas()
    except TypeError:
        pass
    else:
        assert False

    try:
        tqdm_pandas("tqdm")
    except TypeError:
        pass
    else:
        assert False

    try:
        tqdm_pandas(tqdm)
    except TypeError:
        pass
    else:
        assert False

    # tqdm_pandas(tqdm())
    # pandas.core.groupby.DataFrameGroupBy.progress_apply
    p = pd.DataFrame({'foo': [1, 2]})
    # assert not hasattr(p.

# Generated at 2022-06-22 04:51:30.091122
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas"""
    import tqdm
    tqdm_pandas(tqdm.tqdm)


if __name__ == '__main__':
    import pandas as pd
    df = pd.DataFrame(dict([(x, [x]) for x in range(1000)]))
    try:
        from tqdm.auto import tqdm
        tqdm_pandas(tqdm)
    except ImportError:
        tqdm_pandas(tqdm.tqdm)
    tqdm_pandas(tqdm.tqdm)

    def test_func(x):
        return x * 2
    tqdm.pandas(desc='my bar!')

# Generated at 2022-06-22 04:51:34.970254
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm._utils import _range
    import pandas as pd

    for cls in [tqdm, tqdm_notebook, tnrange]:
        with cls(10) as pbar:
            pd.Series(_range(10)).progress_apply(lambda _: pbar.update())


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:45.180738
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return

    from tqdm import tqdm
    from tqdm._utils import _range

    tqdm_pandas(tqdm)
    len_df = 8
    df = pd.DataFrame({'x': range(len_df)})
    desc = 'tqdm_pandas unit-test'
    try:
        for i in [None, 10, 100, 1000]:
            a = df.groupby('x').progress_apply(lambda x: x)
            if i is not None:
                a = df.groupby('x').progress_apply(lambda x: x, min_rows=i)
    except (TypeError, AttributeError) as e:
        raise e  # pragma: no cover
    assert len

# Generated at 2022-06-22 04:51:56.856985
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    # test delayed adapter
    import pandas as pd
    from tqdm import tqdm
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm, mininterval=1, miniters=1)

    # test class
    tqdm_pandas(tqdm(1))
    tqdm_pandas(tqdm(1), mininterval=1, miniters=1)

    # test decorator
    @tqdm_pandas(mininterval=1, miniters=1)
    def dummy(df):
        return df
    try:
        dummy(pd.DataFrame())
    except AttributeError:
        pass



# Generated at 2022-06-22 04:52:04.625153
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        tqdm_pandas(tqdm())
        tqdm_pandas(tqdm)
        tqdm_pandas(tqdm(total=2))
        df = pd.DataFrame({
            'A': [1, 2, 3],
            'B': [4, 5, 6],
            'C': [7, 8, 9]
        })
        tqdm_pandas(tqdm(total=df.shape[0]))
        df.groupby('A').progress_apply(lambda x: x.sum())
    except Exception:
        pass  # Unit tests can fail on Py2.7

# Generated at 2022-06-22 04:52:15.452584
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from pandas import DataFrame
    from pandas.core.groupby import DataFrameGroupBy

    df = pd.DataFrame(data=np.zeros((100, 100)))
    dfg = df.groupby('foo')

    @tqdm_pandas(tqdm(total=dfg.ngroups))
    def example_fun(df):
        return df.sum()

    print(dfg.progress_apply(example_fun) is None)

    # For some reason, this line causes
    # `pandas.core.groupby.DataFrameGroupBy.progress_apply` to be
    # unregistered (losing all progress bars)

# Generated at 2022-06-22 04:52:25.423870
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm.pandas

    tqdm.pandas(desc='Progress: ')

    df = pd.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
        columns=['a', 'b', 'c', 'd', 'e', 'f'])

    # Register `pandas.progress_apply` and `pandas.Series.map_apply` with `tqdm`
    # (can use `tqdm_gui`, `tqdm_notebook`, optional kwargs, etc.)

    # Now you can use `progress_apply` instead of `apply`
    # and `progress_map` instead of `map`
    # and tqdm will display a smart progress bar.

    df

# Generated at 2022-06-22 04:52:35.533523
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def _tqdm_pandas(tclass):
        import pandas as pd
        import numpy as np
        df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
        # We use a slightly different process.progress_apply for pandas 0.18.0
        # See https://github.com/tqdm/tqdm/issues/447
        pd.core.groupby.GroupBy.progress_apply = getattr(
            pd.core.groupby.GroupBy, 'progress_apply', None) or pd.core.groupby.GroupBy.apply
        # We must use a separate tqdm instance for each `progress_apply` call
        # (otherwise leave=False would leave progress bars orphaned)
        # Simple example
        tclass.pand

# Generated at 2022-06-22 04:52:44.180469
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from .main import tqdm

    data_frame = pandas.DataFrame({'i': list(range(100))})
    tqdm_pandas(tclass=tqdm, total=data_frame.i.size)
    assert isinstance(data_frame.groupby('i').progress_apply(lambda x: x),
                      pandas.core.groupby.DataFrameGroupBy)
    tqdm_pandas(tclass=tqdm(total=data_frame.i.size))
    assert isinstance(data_frame.groupby('i').progress_apply(lambda x: x),
                      pandas.core.groupby.DataFrameGroupBy)
    tqdm_pandas()

# Generated at 2022-06-22 04:52:49.521009
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import tqdm
    except ImportError:
        return None
    df = pd.DataFrame()
    df['a'] = [1, 2, 3, 4]
    df['b'] = [2, 3, 4, 5]
    df['c'] = [3, 4, 5, 6]

    def add_a_plus_b(a, b):
        return a + b

    def add_b_plus_c(b, c):
        return b + c

    tqdm.pandas()
    df.progress_apply(add_a_plus_b, axis=1)
    df.groupby('a').progress_apply(add_a_plus_b)
    df.groupby('a').progress_apply(add_b_plus_c)

# Generated at 2022-06-22 04:52:55.142116
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm import tqdm
    from ._utils import format_sizeof
    df = DataFrame({'x': range(1000), 'y': range(1000)})

    tqdm_pandas(tqdm())
    df.groupby('x').progress_apply(lambda x: x.y.sum())


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:53:00.126422
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import time

    def f(x):
        time.sleep(0.01)
        return x

    r = pd.DataFrame({'pid': list(range(100))})
    tqdm_pandas(r.progress_apply(f))

# Generated at 2022-06-22 04:53:04.778062
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from random import Random
    from itertools import product
    import time
    import sys
    from tqdm import tqdm

    # Test parameters
    cycles = 3
    n_cols = 3
    n_rows = 5
    dataset_name = 'test_dataset'

    # Test dataset
    test_dataset = pd.DataFrame(np.random.random((n_rows, n_cols)))
    test_dataset.columns = ['col_{i}'.format(i=i) for i in range(n_cols)]

    # Test in-place operation
    for repeat in range(cycles):
        Random(repeat).shuffle(test_dataset.index)  # reshuffle dataset