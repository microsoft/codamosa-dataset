

# Generated at 2022-06-22 04:43:04.586685
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    No doctest (to be refactored)
    """
    import numpy as np
    try:
        import pandas
        import pandas as pd  # isort:skip
    except ImportError:
        return
    try:
        from collections import OrderedDict
    except ImportError:
        from pandas.compat import OrderedDict

    try:
        from tqdm.contrib import pandas as tqdm_pandas_local
    except ImportError:
        from .contrib import pandas as tqdm_pandas_local

    x = OrderedDict()
    for i in range(100):
        x[i] = [np.random.randint(100) for _ in range(np.random.randint(100))]


# Generated at 2022-06-22 04:43:11.652412
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import datetime
    import random
    import pandas

    def foo(x):
        time.sleep(random.random() / 20.0)
        return 2 * x

    df_tq = pandas.DataFrame({'x': [1, 2, 3] * 100})
    df_tq['y'] = tqdm_pandas(df_tq['x'].progress_apply, foo)
    assert df_tq['y'].sum() == (df_tq['x'] * 2).sum()

# Generated at 2022-06-22 04:43:19.658587
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # function call
    tqdm_pandas(tqdm, total=1000)
    pandas.DataFrame({}).progress_apply(lambda x: x, axis=0)  # no error thrown
    # function call
    tqdm_pandas(tqdm())
    pandas.DataFrame({}).progress_apply(lambda x: x, axis=0)  # no error thrown


# if __name__ == "__main__":
    # test_tqdm_pandas()

# Generated at 2022-06-22 04:43:25.979942
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm

    with tqdm(total=1) as t:
        t.pandas()

    # Old non-transparent:
    with tqdm(total=1) as t:
        tqdm_pandas(t)

    # New transparent:
    tqdm_pandas(tqdm)

    tqdm_pandas(tqdm())

# Generated at 2022-06-22 04:43:38.362197
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test function `tqdm.pandas()`."""
    import pandas as pd
    from tqdm import tqdm
    # test `tqdm.pandas(tqdm_obj, ...)`
    tqdm_pandas(tqdm)
    # test `tqdm.pandas(...)`
    with tqdm(total=1) as t:
        t.pandas()
        try:
            from pandas import read_csv
            read_csv(__file__)
        except Exception as e:  # pragma: no cover
            t.write("GOT: " + str(e))
            raise
#     # test `tqdm.pandas(...)`
    tqdm_pandas()

# Generated at 2022-06-22 04:43:50.791580
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd
    import numpy as np
    def __test_progbar():
        try:
            import progressbar as pb
        except ImportError:
            return
        pb.streams.wrap_stderr()
        return pb

    _pb = __test_progbar()

    df = pd.DataFrame({'a': np.random.rand(100)})
    for t in [tqdm, tqdm.tqdm, tqdm.tqdm_notebook, tqdm.tqdm_gui, tqdm.tqdm_pandas]:
        tclass = t(total=len(df))
        tqdm_pandas(tclass)
        _pb_cls = _pb.ProgressBar if _pb else None

# Generated at 2022-06-22 04:44:02.191295
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas
    except ImportError:
        try:
            from unittest import SkipTest
        except ImportError:
            # For Pythons w/o unittest (i.e. Python < 2.7)
            import unittest.case
            raise unittest.case.SkipTest('Skipping pandas tests')
        else:
            raise SkipTest('Skipping pandas tests')

    df = pandas.DataFrame(
        {'col1': list(range(300)), 'col2': list(range(300))})
    result = df.progress_apply(lambda row: row['col1'] * row['col2'], axis=1)
    assert result.isnull().sum() == 0

# Generated at 2022-06-22 04:44:10.501454
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas.util.testing import assert_frame_equal
    import numpy as np
    import sys
    import io
    old_stdout = sys.stdout
    sys.stdout = mystdout = io.StringIO()  # redirect standard output to a string
    # --------------------------------------------------------------------------
    # Test basic functionality
    tqdm_pandas(tqdm())  # Test delayed adapter
    df = pd.DataFrame({'a': np.arange(100), 'b': np.arange(100)})
    df = df.groupby(['a % 2'])

    def func(df, x):
        return df.groupby(['b % ' + str(x)])

    packed = df.progress_apply(func, axis=0, args=(2,))

# Generated at 2022-06-22 04:44:17.091281
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return
    df = pd.DataFrame({"A": [1, 2, 3], "B": [10, 20, 30]})
    with tqdm(total=len(df)) as t:
        tqdm_pandas(t)

        def myapply(x):
            time.sleep(0.01)
            return x * x
        df.groupby("A").progress_apply(myapply)
        t.update()


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:27.981995
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    df = pd.DataFrame({
        '_id': np.arange(10),
        'data': np.random.randint(1, 100, 10)
    })
    grp = df.groupby('_id')
    assert not grp.progress_apply.registered
    tqdm_pandas(tqdm)
    assert grp.progress_apply.registered

    @tqdm_pandas
    def f():
        pass
    assert grp.progress_apply.registered

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:44:35.023982
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    from tqdm.auto import tqdm

    df = pd.DataFrame(
        {'col1': list(range(1, 10001)),
         'col2': list(reversed(range(10001)))})

    for (dfg, name) in zip([df.groupby(['col1']),
                            df.groupby(['col1', 'col2'])],
                           ['col1', 'col1, col2']):
        tqdm.pandas(desc=f'by {name}: total=')
        assert dfg.progress_apply(lambda x: x).equals(df)


# Generated at 2022-06-22 04:44:46.485747
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from tqdm.auto import tqdm
    from tqdm import trange
    from warnings import catch_warnings
    from io import StringIO
    with catch_warnings(record=True) as w:
        tqdm_pandas(tqdm(file=StringIO()))
        assert len(w) == 1
        assert str(w[0].message) == 'Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm(...))`.'
        tqdm_pandas(trange, file=StringIO())
        assert len(w) == 2

# Generated at 2022-06-22 04:44:57.628315
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for tqdm_pandas()"""
    from pandas import DataFrame
    from random import randint
    from collections import defaultdict
    from tqdm import tqdm, trange

    # Create a pandas dataframe
    df = DataFrame(data={
        'first': [randint(1, 100) for i in range(1000)],
        'second': [randint(1, 100) for i in range(1000)]
    })

    # Register tqdm instance
    #   1) from tqdm
    tqdm_pandas(tqdm(total=len(df)))
    #   2) from tqdm_notebook
    from tqdm import tqdm_notebook
    tqdm_pandas(tqdm_notebook(total=len(df)))


# Generated at 2022-06-22 04:45:06.229320
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, trange, TqdmDeprecationWarning

    def deprecation_stderr_patched_write(msg):
        from tqdm.std import _patched_stderr_write
        if isinstance(msg, TqdmDeprecationWarning):
            _patched_stderr_write("Deprecated: " + str(msg) + "\n")
        else:
            _patched_stderr_write(msg)

    trange.fp = type("", (object,), {"write": deprecation_stderr_patched_write})
    tqdm.fp = type("", (object,), {"write": deprecation_stderr_patched_write})

# Generated at 2022-06-22 04:45:15.662992
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm_pandas, trange
    from tqdm._utils import _term_move_up

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))

    # Register instance
    t = trange(3)
    tqdm_pandas(t)

    # Test on DataFrame
    assert len(t) == 3
    with t:
        df.groupby(0).progress_apply(lambda x: x**2)
    assert t.n == 3

    # Test on Series
    assert len(t) == 3
    with t:
        df[1].progress_apply(lambda x: x**2)
    assert t.n == 3

    # Test on Series

# Generated at 2022-06-22 04:45:25.867163
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import unittest
    import numpy as np
    import pandas as pd

    class TestCase(unittest.TestCase):
        def test_tqdm_pandas(self):
            # TODO: fix test (by mocking DataFrameGroupBy.progress_apply)
            # with self.assertRaises(tqdm.TqdmDeprecationWarning):
            #     tqdm_pandas(tqdm)
            # df = pd.DataFrame(np.random.randn(20000, 2))
            # with self.assertRaises(tqdm.TqdmDeprecationWarning):
            #     tqdm_pandas(tqdm(total=len(df)))
            # df.groupby(0).progress_apply(np.mean)

            tqdm_pand

# Generated at 2022-06-22 04:45:36.750167
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.pandas import tqdm_pandas
    from time import sleep
    from numpy.random import randint

    df = pd.DataFrame({
        'col1': randint(0, 10, size=40),
        'col2': randint(0, 10, size=40)
    })
    df_grouped = df.groupby(['col1'])

    def avg(x):
        sleep(0.05)
        return x.sum() / len(x)

    with tqdm_pandas(desc='avg') as t:
        df_grouped.progress_apply(avg)  # tqdm-version of apply
        df_grouped.progress_apply(avg)  # normal apply

# Generated at 2022-06-22 04:45:44.000936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from .gui import tqdm
    from pandas import DataFrame

    with tqdm(total=10, file=sys.stdout) as t:  # Register instance `t`
        for _ in range(10):
            t.update(1)
    T = tqdm(total=0)
    T.pandas(total=10)
    _ = T + t  # Register class `tqdm`
    _ = DataFrame([1, 2]).groupby(0).progress_apply(id)  # Check if it works


if __name__ == '__main__':
    test_tqdm_pandas()
    test_tqdm_pandas()

# Generated at 2022-06-22 04:45:53.234392
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.contrib.tests import remaining_warnings

    with remaining_warnings():
        for deprecation_warnings in [True, False]:
            print("""# Unit test for tqdm_pandas""")
            print("""def test_tqdm_pandas():""")
            print("""    from tqdm.contrib.tests import remaining_warnings""")
            print("""    with remaining_warnings():""")
            print("""        for deprecation_warnings in [True, False]:""")
            print("""            print("# Unit test for function tqdm_pandas")""")
            print("""            print("    case 1: call deprecated `tqdm_pandas(tqdm)`")""")

# Generated at 2022-06-22 04:46:04.600249
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit tests for `tqdm.pandas`.
    """
    from tqdm import tqdm_notebook, tqdm
    from tqdm.tests import TqdmTestCase, pretest_posttest, skip_if_no_pandas

    def test_with_tqdm():
        df = pd.DataFrame({'a': [0, 1, 2]})
        for tclass in [tqdm, tqdm_notebook]:
            with pretest_posttest() as (pd_, _):
                tqdm_pandas(tclass)
                list(df.groupby('a').progress_apply(lambda x: None))
            TqdmTestCase().assertTrue(pd_)


# Generated at 2022-06-22 04:46:10.947084
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm

    A = pd.DataFrame({'A': np.random.randn(10000)})
    tqdm_pandas(tqdm)
    _ = A.groupby('A').progress_apply(lambda x: x.sum())


if __name__ == '__main__':
    from tqdm import tqdm, trange
    from tqdm.contrib import DummyTqdmFile
    import pandas as pd
    import numpy as np

    try:
        from pandas.core.groupby import DataFrameGroupBy
    except ImportError:
        # pandas < 0.17 fallback
        from pandas.core.groupby import GroupBy


# Generated at 2022-06-22 04:46:20.547356
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame, Series

    df = DataFrame(dict(a=Series(range(10)), b=Series(range(10, 20))))
    total = len(df)
    assert total == 10
    tqdm_pandas(type(tqdm))
    df_sum = df.groupby('a').progress_apply(lambda x: x.sum())
    # df_sum.iloc[0] should == sum(range(0, 10))
    assert df_sum.iloc[0] == 45
    # df_sum.iloc[9] should == sum(range(9, 19))
    assert df_sum.iloc[9] == 155


if __name__ == '__main__':
    from tqdm import tqdm

# Generated at 2022-06-22 04:46:31.737489
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    import pandas as pd
    from tqdm import tqdm, tqdm_pandas

    # for data frame apply (can specify axis, but not binary)
    df = pd.DataFrame({'int': list(range(5)),
                       'float': list(np.arange(5))})
    tqdm_pandas(tqdm, desc="data frame apply")
    df = df.apply(lambda x: x, axis=1)

    # for data frame apply (can specify axis, but not binary)
    tqdm_pandas(tqdm, desc="data frame applymap")
    df = df.applymap(lambda x: x)

    # for data frame apply (can specify axis, but not binary)

# Generated at 2022-06-22 04:46:35.913763
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.pandas import _progress_apply as progress_apply

    assert progress_apply is not None


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:40.692521
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(None)
    tqdm_pandas(3)
    tqdm_pandas(int)
    try:
        tqdm_pandas(
            type('', (), {}),
            total=10,
            unit='frames',
        )
    except Exception:
        pass


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:46:50.424409
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """
    Unit test for function `tqdm_pandas`.
    """
    from os import remove as rm
    from time import sleep
    from numpy import nan, random
    from pandas import DataFrame
    from tqdm import trange
    from tqdm.contrib import pandas

    # test file cleanup
    for _fname in ['test.csv', 'test.xls', 'test.xlsx', 'test.feather',
                   'test_list.pkl', 'test_dict.pkl']:
        try:
            rm(_fname)
        except:
            pass

    df = pandas.utils.testing.makeTimeDataFrame()
    # df.to_csv('test.csv')
    # df.to_excel('test.xls')
    # df.to_excel

# Generated at 2022-06-22 04:47:01.945206
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        print("Please install pandas to test tqdm_pandas(). Skipping test.")
        return
    from tqdm import tqdm_pandas
    from tqdm._tqdm_pandas import TqdmUpTo

    # Test pandas 0.20 or lower
    pd.__version__ = '0.20.2'
    tqdm_pandas(tqdm_kwargs=dict(total=5))
    pd.__version__ = '0.20.1'
    tqdm_pandas(tqdm_kwargs=dict(total=5))
    pd.__version__ = '0.21.0'

# Generated at 2022-06-22 04:47:13.364720
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    df = pd.DataFrame(data=[[1, 1], [1, 1]], index=['a', 'b'])
    func = lambda x: sum(x)
    tqdm_pandas(tqdm, desc='test')
    tqdm_pandas(tqdm.tqdm, desc='test')
    # test pandas progress_bar
    from pandas.core.arrays.numpy_.numpy_ import PandasArray
    istype = lambda x: isinstance(x, pd.DataFrame) or isinstance(x, PandasArray)
    tqdm_pandas(tqdm.tqdm, desc='test', leave=False, position=1, is_type=istype)
    # deprecated
    deprecated

# Generated at 2022-06-22 04:47:16.875580
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    tclass = tqdm(total=1)
    tqdm_pandas(tclass)
    tqdm_pandas(tqdm)

# Function for adding tqdm.pandas to progress_apply monkey patch

# Generated at 2022-06-22 04:47:28.479850
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas
    from tqdm import tqdm_pandas
    import numpy as np

    df_small = pandas.DataFrame(
        np.random.randint(0, 100, (100000, 6)),
    )
    df_med = pandas.DataFrame(
        np.random.randint(0, 100, (200000, 6)),
    )
    df_large = pandas.DataFrame(
        np.random.randint(0, 100, (500000, 6)),
    )

    with tqdm_pandas(total=df_small.shape[0]) as t:
        _ = df_small.progress_apply(
            lambda x: x**2,
            axis=1,
            result_type='expand',
            raw=False,
        )
    assert t

# Generated at 2022-06-22 04:47:40.627899
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import numpy as np
    import pandas as pd
    import pandas.util.testing as pdt

    try:
        from pandas.core.groupby import DataFrameGroupBy
        from pandas.core.series import Series
    except ImportError:
        # pandas < 0.21.0
        from pandas.core.groupby import DataFrameGroupBy
        from pandas.core.series import Series

    # random testing data
    df_in = pdt.DataFrame(np.random.randn(100, 10))
    aggr_expected = df_in.sum(axis=1)

    with tqdm(total=df_in.shape[0]) as t:
        tqdm_pandas(t)

# Generated at 2022-06-22 04:47:52.230878
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for ``tqdm_pandas``."""
    import pandas as pd
    from tqdm.autonotebook import tnrange

    try:
        import pandas as pd
    except ImportError:
        return

    x = pd.DataFrame({'a': [0, 1, 2, 0, 1, 2],
                      'b': [1, 2, 3, 4, 5, 6]})

    for tclass in [tnrange, tnrange.duplicate]:
        with tclass(4) as t:
            t.__total__ = 4
            assert t.__total__ == 4
            t.pandas(x.groupby('a').apply(lambda x: x.b.sum())).reset_index()
        # check compatibility with pandas.core.groupby.Data

# Generated at 2022-06-22 04:48:03.683985
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas.util.testing import assert_frame_equal
    from tqdm import tqdm
    import numpy as np
    from tqdm.auto import trange
    from tqdm.contrib.concurrent import thread_map

    def func(df):
        x = 0.
        for i in range(1000000):
            x += np.sqrt(i)
        return df

    df = pd.DataFrame({'col1': list(range(5)),
                       'col2': list(range(5))})

    # Function case
    # with tqdm_pandas() as pbar:
    #     df_test = df.groupby(['col1']).progress_apply(func)
    #
    # df_test_ = df.groupby(['

# Generated at 2022-06-22 04:48:12.985308
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
        import numpy as np
        n = 10000
        df = pd.DataFrame(np.random.randn(n, n))
        tqdm_pandas(df.groupby(0).progress_apply(lambda x: x + 1))
        tqdm_pandas(df.groupby(0).progress_apply(lambda x: x + 1))
    except ImportError as e:
        print(e)
        return
    else:
        print('Test passed')


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-22 04:48:22.320451
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame, Series

    from pandas.core.groupby import DataFrameGroupBy, SeriesGroupBy
    from pandas.api.types import CategoricalDtype
    from tqdm import tqdm

    # DataFrame
    df = DataFrame(Series(range(100), range(100)))
    df.groupby(df.index // 10).progress_apply(lambda x: sum(x))

    # Series
    sr = Series(range(100))
    sr.groupby(sr.index // 10).progress_apply(lambda x: sum(x))

    # DataFrameGroupBy
    df = DataFrame(Series(range(100), range(100)))
    dfg = df.groupby(df.index // 10)
    dfg.apply(lambda x: len(x))
    dfg.progress_apply

# Generated at 2022-06-22 04:48:30.996002
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tqdm
    import pandas as pd

    pd.DataFrame([1, 2, 3]).groupby(0).progress_apply(lambda x: x + 1)
    pd.DataFrame([1, 2, 3]).groupby(0).progress_apply(lambda x: x + 1, **tqdm.tqdm_kwargs())

    tqdm_pandas(tqdm.tqdm, total=10)
    tqdm.tqdm_pandas(total=10)


# rst-class::
#    :hidden:

# rst-class::
#    :hidden:

# try uninstalling tqdm and pandas
# try:
#     import pandas
#     has_pandas = True
# except ImportError:
#     has_pand

# Generated at 2022-06-22 04:48:40.577324
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm

    # Delayed adapter case
    tqdm_pandas(tqdm)

    df = pd.DataFrame({
        'A': [1, 2, 3, 4, 5],
        'B': [5, 4, 3, 2, 1],
    })

    def slow_f(x):
        import time
        time.sleep(0.01)
        return x

    # Instance case
    tqdm_pandas(tqdm())

    # Parallel case
    tqdm_pandas(tqdm(), desc='Processing')
    df.groupby('A').progress_apply(slow_f)

    # Check if progress bar is always printed
    print()

# Generated at 2022-06-22 04:48:50.449937
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Unit test for function tqdm_pandas."""
    try:
        import pandas as pd
    except ImportError:
        return

    tqdm_pandas(tqdmlib.tqdm_notebook)
    pd.DataFrame([x for x in range(10)]).groupby(0).progress_apply(lambda x: x)

    tqdm_pandas(tqdmlib.tqdm)
    pd.DataFrame([x for x in range(10)]).groupby(0).progress_apply(lambda x: x)

    tq = tqdmlib.tqdm(total=100)
    tqdm_pandas(tq)

# Generated at 2022-06-22 04:48:57.830412
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas

        # regress test for https://github.com/tqdm/tqdm/issues/357
        tqdm_pandas(tqdm_gui)
        tqdm_pandas(tqdm_notebook)
        tqdm_pandas(tqdm)
        tqdm_pandas(pandas.core.groupby.DataFrameGroupBy).progress_apply
    except ImportError:
        pass

# Generated at 2022-06-22 04:49:07.677469
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        from tqdm import tqdm
    except ImportError:
        return None
    from pandas.core.groupby import DataFrameGroupBy
    from pandas import DataFrame
    from numpy import random

    def test_apply():
        return sum([i for i in range(100)])

    tqdm_kwargs = {'ascii': True, 'file': sys.stdout}

    tqdm.pandas(**tqdm_kwargs)
    df = DataFrame(random.randn(10, 10))
    assert isinstance(df.groupby(0).progress_apply(test_apply), DataFrame)

    tqdm_kwargs = {'ascii': True, 'file': sys.stderr}


# Generated at 2022-06-22 04:49:21.197131
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tqdm

    a = [1, 2, 3, 4]
    df = pd.DataFrame(a)
    # testing with tqdm class
    with tqdm.tqdm_pandas(tqdm) as progress:
        # test progress_apply
        data = {'a': range(0, 100),
                'b': range(0, 100)}
        i = 0
        df = pd.DataFrame(data)
        for i in df.progress_apply(lambda x: x['a'] + x['b'], axis=1):
            assert i == 2 * (i // 2)
            i += 1
        # test progress_apply
        i = 0

# Generated at 2022-06-22 04:49:31.437005
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    from tqdm import trange
    from pandas.util.testing import assert_frame_equal
    from tqdm.pandas import TqdmTypeError, TqdmDeprecationWarning

    import warnings
    warnings.simplefilter('error')
    for warnings_class in (TqdmTypeError, TqdmDeprecationWarning):
        try:
            from tqdm import tqdm_pandas
        except warnings_class:
            pass
        else:
            raise ValueError('Exception expected!')
    warnings.resetwarnings()

    df = pd.DataFrame({'a': [1, 2], 'b': [3, 4]})

# Generated at 2022-06-22 04:49:40.865717
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm
    pd.DataFrame([1]).groupby(0).progress_apply(lambda x: 1)
    pd.DataFrame([1]).progress_apply(lambda x: 2)
    # should work
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    # shouldn't work
    try:
        tqdm_pandas()
    except RuntimeError:
        pass
    try:
        tqdm_pandas(1)
    except RuntimeError:
        pass

# Generated at 2022-06-22 04:49:52.117261
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm, trange

    df = pd.DataFrame(np.random.random((1000, 3)), columns=list('ABC'))
    with tqdm(total=len(df), leave=False, desc='tqdm_pandas', unit='') as progressbar:
        def progress_apply(df, func, *args, **kwargs):
            assert func is None or args is None or kwargs is None
            if func is not None:
                kwargs['progressbar'] = progressbar
            ret = df.progress_apply(func, *args, **kwargs)
            progressbar.update()
            return ret

# Generated at 2022-06-22 04:50:03.956110
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas

    def test_df(interval, t=None, **tqdm_kwargs):
        global df
        df = pandas.DataFrame(dict(
            (k, pandas.util.testing.rands(n=(interval // 2)))
            for k in ['A', 'B', 'C', 'D', 'E']))
        # Progress bar
        if t is None:
            t = pandas.core.groupby.DataFrameGroupBy(df).progress_apply
        else:
            pandas.core.groupby.DataFrameGroupBy(df).progress_apply = t
        # Test
        r = df.groupby('A').progress_apply(
            lambda x: x['B'].sum() + len(x))

# Generated at 2022-06-22 04:50:15.852484
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        import pandas as pd
    except ImportError:
        return  # Test skipped

    tqdm_pandas(tqdm(total=100), miniters=20)
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    tqdm_pandas(tqdm(total=100, file=StringIO()), miniters=20)
    tqdm_pandas(tqdm(total=100), miniters=20, n_samples=5)
    tqdm_pandas(tqdm, total=100, miniters=20)
    tqdm_pandas(tqdm, total=100, miniters=20, n_samples=5)

# Generated at 2022-06-22 04:50:25.282552
# Unit test for function tqdm_pandas
def test_tqdm_pandas():  # pragma: no cover
    """Test function tqdm_pandas"""
    import tqdm
    tqdm.tqdm = tqdm_pandas(tqdm.tqdm)
    try:
        import pandas as pd
        import numpy as np
        df = pd.DataFrame(np.random.randn(3, 4))
        g = df.groupby(0).progress_apply(lambda x: x)
        assert str(g) == str(df)
        g = df.groupby(0).progress_apply(lambda x: x, foo='bar')
        assert str(g) == str(df)
    finally:
        del tqdm.tqdm

# Generated at 2022-06-22 04:50:33.403248
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Test for tqdm_pandas to validate pandas is installed and tqdm pandas adapter is working"""
    try:
        import pandas  # This will fail if pandas is not installed
    except ImportError:
        raise ImportError("make sure pandas is installed")
    try:
        tqdm_pandas(tqdm(total=100))
    except Exception:
        raise Exception("tqdm pandas adapter failed")
    # print('tqdm pandas adapter passed the test')


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:50:44.647767
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm import tqdm
    from time import sleep

    df = pd.DataFrame({'a': [1, 2, 3, 4, 5], 'b': np.random.randn(5)})
    r = df.groupby('a').apply(lambda x: sleep(1 / x['b'].sum()))
    assert r == df
    r = df.groupby('a').progress_apply(lambda x: sleep(1 / x['b'].sum()))
    assert r == df
    tqdm_pandas(tqdm())
    r = df.groupby('a').progress_apply(lambda x: sleep(1 / x['b'].sum()))
    assert r == df

# Generated at 2022-06-22 04:50:52.830912
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from tqdm import tqdm_pandas
    import pandas as pd

    df = pd.DataFrame(dict(a=list(range(10)),
                           b=list(reversed(range(10)))))
    df.groupby('a').progress_apply(lambda x: x)
    df.groupby('b').progress_apply(lambda x: x)

    tqdm_pandas(tqdm())
    df.groupby('a').progress_apply(lambda x: x)
    df.groupby('b').progress_apply(lambda x: x)

    tqdm_pandas(tqdm(leave=True))
    df.groupby('a').progress_apply(lambda x: x)
    df.groupby('b').progress

# Generated at 2022-06-22 04:51:10.314796
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            import pandas as pd
        except ImportError:
            sys.stderr.write('pandas is not installed, skipping test')
            return

        # Check progress_apply works with tqdm
        df = pd.DataFrame(
            {'a': pd.Series(100, dtype=int), 'b': pd.Series(100, dtype=int)})

        tqdm_kwargs = {}
        if numpy is not None:
            # to ensure below code works even when numpy is not installed
            df['c'] = numpy.random.rand(len(df))
            tqdm_kwargs = {'total': len(df)}


# Generated at 2022-06-22 04:51:22.072441
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import tqdm
    import numpy as np
    try:
        from pandas.api.types import is_list_like
        # this version of pandas is buggy with dataframe.progress_apply
        # https://github.com/tqdm/tqdm/issues/521
        def _is_list_like(x):
            return isinstance(x, (pd.Series, np.ndarray, pd.Index))
    except:
        _is_list_like = is_list_like

    df = pd.DataFrame(np.random.randint(0, 100, (100000, 4)), columns=list('ABCD'))
    tqdm.tqdm.pandas(desc="my bar!")

    # https://github.com/tqdm/t

# Generated at 2022-06-22 04:51:29.644578
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import tempfile
    import sys
    from tqdm import tqdm
    from pandas import DataFrame, Series, concat
    f = tempfile.TemporaryFile('w+')
    sys.stdout = f
    sys.stderr = f
    df = DataFrame({"A": concat([Series(range(10))] * 100)})
    df.groupby("A").progress_apply(len)
    tqdm(pandas=True)
    df.groupby("A").progress_apply(len)
    c = tqdm()
    c.pandas()
    df.groupby("A").progress_apply(len)
    f.seek(0)
    assert f.read().count("groupby") == 2

# Generated at 2022-06-22 04:51:37.110609
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    import tempfile
    with tempfile.NamedTemporaryFile('w') as f:
        with tqdm.wrapattr(f, 'write') as fw:
            tqdm_pandas(type(tqdm.tqdm(ncols=80)), fw=fw)
            df = pd.DataFrame(np.random.randint(0, 100, (100000, 6)))
            gb = df.groupby(0)
            list(gb.progress_apply(lambda x: x ** 2))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:46.374737
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """Tests the `tqdm.pandas` decorator on dummy `pd.DataFrame`."""
    from pandas import DataFrame
    from pandas.api.types import is_list_like
    from tqdm import tqdm

    def decorator(fn, *args, **kwargs):
        """Decorator for applying `tqdm.pandas`."""
        return fn(*args, **kwargs)
    try:
        from pandas import Series
        from pandas.core.groupby import DataFrameGroupBy, SeriesGroupBy
    except ImportError:
        return None  # skip test
    global tqdm_pandas  # pylint: disable=invalid-name
    tqdm_pandas = decorator  # pylint: disable=invalid-name
    # generate fake

# Generated at 2022-06-22 04:51:51.680472
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    df = pd.DataFrame(np.random.randn(100, 100))
    result = df.apply(lambda c: c.sum(), axis=0)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    from tqdm import tqdm; tqdm.pandas()
    test_tqdm_pandas()

# Generated at 2022-06-22 04:51:59.347609
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm import tqdm, tqdm_notebook
    try:
        import ipywidgets
    except ImportError:
        ipywidgets = None

    def f(x):
        time.sleep(1e-3)
        return x

    df1 = pd.DataFrame({'x': range(100)})
    df2 = pd.DataFrame({'x': range(100)})

    with tqdm(df1['x']) as t:
        df1['x'].progress_apply(f)
        assert '100/100' in t.last_print_n
        assert '100/100' in t.last_print_str

    with tqdm() as t:
        df2['x'].progress_apply(f)

# Generated at 2022-06-22 04:52:09.635839
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from tqdm.auto import tqdm

    class CustomTqdm(tqdm):
        def update_to(self, **kwargs):
            self.n = kwargs['n']
            self.refresh()
            self.n = None

    df = pd.DataFrame({'x': range(1000)})
    df.groupby('x').progress_apply(
        lambda x: x.x + 1,
        tqdm_kwargs={'tclass': CustomTqdm, 'unit_scale': False},
        tqdm_deprecated=True,  # ensure that pandas works
    )
    df.groupby('x').progress_apply(lambda x: x.x + 1)

# Generated at 2022-06-22 04:52:20.401936
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.auto import tqdm
    from numpy.random import randint
    from numpy.testing import assert_equal
    from pandas import DataFrame

    df = DataFrame(randint(0, 10, (10, 5)))

    def sum_(x):
        return x.sum()

    # Delayed adapter case
    assert_equal(df.progress_apply(sum_), df.apply(sum_),
                 err_msg="tqdm_pandas doesn't work with delayed adapter")

    # Immediate adapter case
    assert_equal(tqdm(df).progress_apply(sum_), df.apply(sum_),
                 err_msg="tqdm_pandas doesn't work with immediate adapter")


if __name__ == '__main__':
    from pytest import main

# Generated at 2022-06-22 04:52:25.656121
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import tqdm
    from pandas import DataFrame

    tqdm_pandas(tqdm)
    df = DataFrame({'a': [1, 2, 3], 'b': [3, 2, 1]})
    result = df.groupby('a').progress_apply(lambda x: x['b'].sum())
    assert result == [1, 3, 4]


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-22 04:52:41.918341
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas import DataFrame
    from numpy.random import random
    from tqdm.auto import tqdm, trange

    array_size = 100000
    df = DataFrame(data={"val": random(size=array_size)})

    def f(x):
        if x < 0.5:
            return 0
        else:
            return 1

    t = trange(10, desc="Progress")
    p = tqdm(total=1, file=t.file)
    df.groupby("val").progress_apply(f,
                                     tqdm_kwargs={"total": array_size,
                                                  "desc": "Grouped tqdm",
                                                  "leave": True,
                                                  "file": p.fp})
    t.close()


# Generated at 2022-06-22 04:52:54.069630
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    def tqdm_pandas(tclass, **tqdm_kwargs):
        """
        Registers the given `tqdm` instance with
        `pandas.core.groupby.DataFrameGroupBy.progress_apply`.
        """
        from tqdm import TqdmDeprecationWarning

        if isinstance(tclass, type) or (getattr(tclass, '__name__', '').startswith(
                'tqdm_')):  # delayed adapter case
            TqdmDeprecationWarning(
                "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.",
                fp_write=getattr(tqdm_kwargs.get('file', None), 'write', sys.stderr.write))


# Generated at 2022-06-22 04:53:02.981240
# Unit test for function tqdm_pandas
def test_tqdm_pandas(): # pragma: no cover
    """Test the most common TqdmDeprecationWarning paths and message format."""
    try:
        # pd.core.groupby.DataFrameGroupBy.progress_apply
        import pandas as pd
        tqdm_pandas(pd.DataFrame.groupby)

        # tqdm_pandas(tqdm)
        from tqdm import tqdm
        tqdm_pandas(tqdm)

        # tqdm_pandas(tqdm(...))
        from tqdm import tqdm
        tqdm_pandas(tqdm(desc='test'))
    except TqdmDeprecationWarning as e:
        assert "Please use" in str(e) and "instead of" in str(e)
        return
   