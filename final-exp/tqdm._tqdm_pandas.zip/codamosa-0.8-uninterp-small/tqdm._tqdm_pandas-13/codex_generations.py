

# Generated at 2022-06-26 09:06:57.308563
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_case_0()

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-26 09:06:58.322410
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert False


# Generated at 2022-06-26 09:07:04.765625
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test case 1
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test case 2
    int_0 = 100000
    var_0 = tqdm_pandas(int_0)
    # Test case 3
    int_0 = 3281
    var_0 = tqdm_pandas(int_0)
    # Test case 4
    int_0 = 595
    var_0 = tqdm_pandas(int_0)
    # Test case 5
    int_0 = 4957
    var_0 = tqdm_pandas(int_0)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-26 09:07:07.032934
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas), "Function does not exist"


# Generated at 2022-06-26 09:07:14.965677
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas)
    test_case_0()

# Testing
if __name__ == "__main__":
    test_tqdm_pandas()
    print("Everything passed")

# Generated at 2022-06-26 09:07:20.411282
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    assert var_0 is None, 'Incorrect work of tqdm_pandas'

# Driver Code
if __name__ == '__main__':
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    test_case_0()

# Generated at 2022-06-26 09:07:26.979123
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    input_lst_1 = ['tqdm']
    input_lst_2 = [4071]
    with pytest.raises(TypeError):
        assert tqdm_pandas(input_lst_1)
    with pytest.raises(TypeError):
        assert tqdm_pandas(input_lst_2)


# Generated at 2022-06-26 09:07:28.483827
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
   assert callable(tqdm_pandas)

# Generated at 2022-06-26 09:07:30.225222
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Create args
    tclass = 4071

    # Unit test
    tqdm_pandas(tclass)

# Generated at 2022-06-26 09:07:42.620587
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        assert callable(tqdm_pandas)
        test_case_0()
    except (AssertionError, TypeError) as err:
        print("Error: %s" % err)
        return False
    return True

if __name__ == "__main__":
    if test_tqdm_pandas():
        print("All tests passed!")
    else:
        print("Some tests failed!")

# Generated at 2022-06-26 09:07:49.513199
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    tqdm_pandas(int_0)

if __name__ == '__main__':
    is_pass = True
    try:
        test_case_0()
    except:
        is_pass = False
    try:
        test_tqdm_pandas()
    except:
        is_pass = False
    if is_pass:
        print('All test cases passed.')
    else:
        print('Some test cases failed')

# Generated at 2022-06-26 09:07:52.425622
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    assert var_0 is None


# Generated at 2022-06-26 09:08:00.796692
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    assert var_0 == 4071
    var_1 = tqdm_pandas(int_0)
    var_2 = tqdm_pandas(int_0, file=sys.stderr)
    var_3 = tqdm_pandas(int_0, from_unit='test', unit='test', bar_format="test")
    var_4 = tqdm_pandas(int_0, unit="test", total=1)
    assert var_4 == 4071


# Generated at 2022-06-26 09:08:03.795337
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_case_0()


# Unit test execution
if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-26 09:08:06.045052
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Mock arguments
    int_0 = 4071

    set_trace()
    var_0 = tqdm_pandas(int_0)

    assert var_0 is None

# Generated at 2022-06-26 09:08:09.363972
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Random input
    int_0 = 4071
    # Call function
    out_0 = tqdm_pandas(int_0)
    # Should be true


if __name__ == "__main__":
    test_case_0()
    solver = 1

# Generated at 2022-06-26 09:08:10.568932
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert tqdm_pandas


# Generated at 2022-06-26 09:08:12.485531
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test Case #0
    test_case_0()

# Generated at 2022-06-26 09:08:17.097608
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    var_1 = tqdm_pandas(var_0)
    assert var_0 == 4071
    assert var_1 == 4071
test_tqdm_pandas()

# Generated at 2022-06-26 09:08:18.231514
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert True == True


# Generated at 2022-06-26 09:08:32.096960
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from pandas.core.groupby import DataFrameGroupBy
    import tqdm

    tqdm.pandas(tqdm.tqdm)
    assert tqdm_pandas.__name__ == 'tqdm_pandas'
    assert tqdm_pandas.__doc__ == '\n    Registers the given `tqdm` instance with\n    `pandas.core.groupby.DataFrameGroupBy.progress_apply`.\n    '
    assert tqdm_pandas.__file__ == 'tqdm_pandas.py'
    assert tqdm_pandas.__cached__ is None
    # this next line fails the test due to a bug in the test case

# Generated at 2022-06-26 09:08:33.082280
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert tqdm_pandas(int) == None

# Generated at 2022-06-26 09:08:37.281192
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_1 = 4071
    var_1 = tqdm_pandas(int_1)
    assert var_1 is None or isinstance(var_1, (tqdm, type(None))), 'Return type expected : tqdm got %s ' % type(var_1)


# Generated at 2022-06-26 09:08:41.653649
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable (tqdm_pandas)
    # call function
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # check type of return value
    assert isinstance (var_0, int)

# final test
test_tqdm_pandas()

# Generated at 2022-06-26 09:08:43.337987
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tclass = tqdm_pandas(tqdm)
    assert tclass.get_lock() is None

# Generated at 2022-06-26 09:08:54.818542
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm import TqdmDeprecationWarning
    import io
    import sys

    capturedOutput = io.StringIO()
    sys.stderr = capturedOutput
    tqdm_pandas("tqdm")
    assert capturedOutput.getvalue() == "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.\n"

    capturedOutput = io.StringIO()
    sys.stderr = capturedOutput
    tqdm_pandas("tqdm_notebook")
    assert "Please use `tqdm.pandas(...)` instead of `tqdm_pandas(tqdm, ...)`.\n"
    assert capturedOutput.getvalue() == capturedOutput.getvalue()

    capturedOutput = io.String

# Generated at 2022-06-26 09:08:56.466560
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert test_case_0() is None

# Generated at 2022-06-26 09:08:58.771016
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    if __name__ == '__main__':
        test_case_0()
        test_case_1()
        test_case_2()

# Generated at 2022-06-26 09:09:02.408129
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_case_0()


if __name__ == '__main__':
    # test for function tqdm_pandas
    test_tqdm_pandas()

# Generated at 2022-06-26 09:09:05.181288
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    object_0 = tqdm.tqdm(np.array([3080, 213, 538, 6, 4708, 4028]))
    ret_0 = tqdm_pandas(object_0)

# Generated at 2022-06-26 09:09:14.602221
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert not tqdm_pandas(tqdm('A'))


if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-26 09:09:20.272636
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Setup
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    var_1 = tqdm_pandas(int_0, unit="blocks")
    # Assertions
    assert var_0 != var_1

if __name__ == "__main__":
    # Test with --verbose command line argument
    test_tqdm_pandas()

# Generated at 2022-06-26 09:09:23.093452
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(1000,desc='test', mininterval=1)


if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-26 09:09:27.412555
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        test_case_0()
    except:
        print('test_tqdm_pandas [FAILED]')
    else:
        print('test_tqdm_pandas [PASSED]')

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-26 09:09:37.484106
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test case 0
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test case 1
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test case 2
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test case 3
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test case 4
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test case 5
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test case 6
   

# Generated at 2022-06-26 09:09:39.002534
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert tqdm_pandas(5), "Should be True"

# Generated at 2022-06-26 09:09:41.242811
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Check pd.DataFrame.progress_apply
    raise NotImplementedError


# Generated at 2022-06-26 09:09:46.059392
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_case_0()

# Compute resource usage for function tqdm_pandas
#tqdm_pandas('-m', 'memory_profiler')

# Compute resource usage for function test_tqdm_pandas
#test_tqdm_pandas('-m', 'memory_profiler')

# Generated at 2022-06-26 09:09:46.964296
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_case_0()

# Generated at 2022-06-26 09:09:55.183207
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm(total=100), position=0, leave=True, smoothing=1.0,
                bar_format='{desc}: {percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt} [{remaining_s}<{elapsed_s}, {rate_fmt}]')
    tqdm_pandas(tqdm(total=100), smoothing=1.0, bar_format='{l_bar}{bar}| {n_fmt}')
    tqdm_pandas(tqdm(total=100), smoothing=1.0, bar_format='{l_bar}{bar}| {n_fmt} {rate_fmt}{postfix}')

# Generated at 2022-06-26 09:10:04.698873
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas)


# Generated at 2022-06-26 09:10:06.758188
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert tqdm_pandas(4071)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:10:08.092027
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 09:10:14.105893
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    cwd = os.getcwd()
    tqdm_file = os.path.join(cwd, "tqdm_file.txt")
    with open(tqdm_file, 'w') as file:
        file.write(str(tqdm_pandas))

if __name__ == "__main__":
     test_tqdm_pandas()

# Generated at 2022-06-26 09:10:20.570660
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas), "Function does not exist" 


# Generated at 2022-06-26 09:10:23.462377
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)


# Generated at 2022-06-26 09:10:25.652054
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    """ Unit test for tqdm_pandas
    """
    pass

if __name__ == "__main__":
    print(tqdm_pandas(42))

# Generated at 2022-06-26 09:10:29.817135
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_case_0()

# main function
if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-26 09:10:39.605554
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    import numpy as np
    from tqdm.autonotebook import tqdm
    m = tqdm_pandas(tqdm())
    df = pd.DataFrame(
        np.random.rand(1e4, 1e4),
        columns=['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'])
    res = df.groupby(['1', '2', '3', '4', '5'])['1', '2', '3', '4', '5'].progress_apply(
        lambda x: x.rolling(len(x)).sum())
    print(res.groupby(['1', '2', '3', '4', '5']).agg(np.sum))

# Generated at 2022-06-26 09:10:42.059410
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    assert(var_0 == 4071)

# Generated at 2022-06-26 09:10:57.690844
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        test_case_0()
    except:
        assert False, 'Unhandled exception raised'

# Generated at 2022-06-26 09:10:58.842994
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    np.testing.assert_raises(AttributeError, test_case_0)

# Generated at 2022-06-26 09:11:00.180969
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    x = tqdm_pandas(4)
    assert x == 4


# Generated at 2022-06-26 09:11:02.596230
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm.pandas()


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-26 09:11:12.649322
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import pandas as pd
    from pandas import DataFrame
    from pandas import Series
    from tqdm import tqdm
    import numpy as np
    from pandas import date_range
    from tqdm.contrib import pandas
    from pandas import MultiIndex
    from pandas import Index
    from pandas.core.indexes.range import RangeIndex
    from pandas.core.dtypes.dtypes import Int64Dtype
    from pandas.core.dtypes.cast import construct_1d_arraylike_from_scalar
    from pandas.core.dtypes.cast import maybe_promote
    from pandas.core.dtypes.common import (
        is_integer_dtype, is_timedelta64_dtype, is_list_like
    )

# Generated at 2022-06-26 09:11:13.666106
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert True

# Generated at 2022-06-26 09:11:19.796785
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas), "Function does not exist"

test_case_0()
test_tqdm_pandas()

# Generated at 2022-06-26 09:11:23.837657
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas)


if __name__ == '__main__':
    tqdm_pandas(object)
    test_tqdm_pandas()

# Generated at 2022-06-26 09:11:24.538848
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas)

# Generated at 2022-06-26 09:11:25.708912
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas)


# Generated at 2022-06-26 09:11:47.840503
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    var_2 = 4071
    var_3 = tqdm_pandas(var_2)
    assert type(var_3) is int

# FROM tqdm/__main__.py
# Test cases for tqdm/__main__.py
# 
# To run this specific file, type 'python -m unittest -v tqdm.tests.test_main'
#

# Test case for tqdm.autonotebook

# Generated at 2022-06-26 09:11:51.739785
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    with pytest.raises(TqdmDeprecationWarning):
        int_0 = 4071
        tqdm_pandas(int_0)
        tqdm_pandas(tqdm)

# Generated at 2022-06-26 09:11:58.378718
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Define mock functions / classes
    class MockClass:
        class MockClass2:
            @staticmethod
            def pandas(**kwargs):
                return True
        def pandas(self, **kwargs):
            return MockClass.MockClass2

    class MockClass3:
        def __init__(self, value):
            self.value = value
        def __eq__(self, other):
            return self.value == other
        def __ne__(self, other):
            return not self.__eq__(other)

    assert tqdm_pandas(MockClass) == MockClass.MockClass2
    assert tqdm_pandas(MockClass3(value='tqdm')) == MockClass.MockClass2

# Generated at 2022-06-26 09:12:00.345283
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert True

test_case_0()
test_tqdm_pandas()
print('test_cases passed')

# Generated at 2022-06-26 09:12:05.573125
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        tqdm_pandas(tqdm(0))
    except Exception as e:
        assert False, e


if __name__ == "__main__":
    test_tqdm_pandas()
    # print('Done')

# Generated at 2022-06-26 09:12:12.800421
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import unittest
    import inspect
    import sys

    class Test_tqdm_pandas(unittest.TestCase):
        def test_0(self):
            # Test if function tqdm_pandas accepts the right number of parameters
            number_of_arguments = len(inspect.getfullargspec(tqdm_pandas)[0])
            self.assertEqual(number_of_arguments, 2)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-26 09:12:13.913393
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert tqdm_pandas(4071) == 4071

# Generated at 2022-06-26 09:12:16.460654
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas)
    assert isinstance(tqdm_pandas(int), tqdm_pandas)
    assert tqdm_pandas(int) == tqdm_pandas(int)

# Generated at 2022-06-26 09:12:21.792344
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Expected output of function
    args = 4071
    expected = None
    # Actually output of function
    try:
        result = tqdm_pandas(args)
    except DeprecationWarning:
        result = None
    # Compare expected output and actually output
    assert result == expected

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:12:26.799535
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    var_0 = 4071
    var_0 = tqdm_pandas(var_0)
    assert var_0 == 4071, \
        "Expected: 4071, Got: {0}".format(var_0)

test_tqdm_pandas()

# Generated at 2022-06-26 09:12:46.783886
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert(len(tqdm_pandas) == 3), "Expected len(tqdm_pandas) == 3, but got %d" \
        % len(tqdm_pandas)


# Main execution function
if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-26 09:12:49.033043
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    output = tqdm_pandas(4071)
    #print(output)
    expected = True
    #print(expected)
    assert output == expected

# Generated at 2022-06-26 09:12:51.677414
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from tqdm.tests import tqdm_pandas as test_tqdm_pandas
    test_tqdm_pandas.test_case_0()

    # Unit test for function tqdm_pandas

# Generated at 2022-06-26 09:12:59.364641
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert type(tqdm_pandas(4071)) == tqdm.tqdm
    # assert type(tqdm_pandas(tqdm.tqdm(), 4071)) == tqdm.tqdm
    # assert type(tqdm_pandas(4071,4071)) == tqdm.tqdm
    # assert type(tqdm_pandas(tqdm.tqdm(4071), 4071)) == tqdm.tqdm
    # assert type(tqdm_pandas(4071, tqdm.tqdm(4071))) == tqd

# Generated at 2022-06-26 09:13:00.101724
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert True


# Generated at 2022-06-26 09:13:03.035014
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_case_0()

# Tested on PyCharm 2019.2
# Python 3.7.4
# tqdm 4.32.1
# pandas 0.24.2

# Generated at 2022-06-26 09:13:03.991481
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas)

# Generated at 2022-06-26 09:13:08.280688
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # <callable-object>
    assert callable(var_0)



# Generated at 2022-06-26 09:13:10.884901
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)

    int_1 = 4071
    var_1 = tqdm_pandas(int_1)

# Generated at 2022-06-26 09:13:14.302046
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    var_1 = tqdm_pandas(int_0)
    print(var_0)
    print(var_1)

# Generate random test cases

# Generated at 2022-06-26 09:13:30.745497
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    assert var_0 == 4071 + 1


# Generated at 2022-06-26 09:13:32.795805
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-26 09:13:36.668026
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    assert var_0 == tqdm_pandas(int_0)

if __name__ == '__main__':
    test_tqdm_pandas()

# Generated at 2022-06-26 09:13:46.334516
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import io
    import unittest
    from contextlib import redirect_stdout

    class Testtqdm_pandas(unittest.TestCase):

        def test_tqdm_pandas(self):
            f = io.StringIO()
            with redirect_stdout(f):
                test_case_0()
            self.assertEqual(f.getvalue(), "")

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-26 09:13:48.993053
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Input parameters
    # Module parameters
    # Expected outputs
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:13:50.357978
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    assert callable(tqdm_pandas)


# Generated at 2022-06-26 09:14:01.448475
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    import random
    import pandas as pd

    def random_func(i):
        time.sleep(random.random() / 1000)
        return i

    df = pd.DataFrame({'a': list(range(10))})
    rows = df.shape[0]

    # Check with tqdm.pandas
    for i in range(10):
        test = df.progress_apply(func=random_func)
        assert test.equals(df)

    # Check without tqdm.pandas
    with nested(TqdmExperimentalWarning(),
                catch_warnings(record=True)):
        for i in range(10):
            test = df.progress_apply(func=random_func)
            assert test.equals(df)

    # Check without tqdm.pandas and with

# Generated at 2022-06-26 09:14:03.064452
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 5196
    var_0 = tqdm_pandas(int_0)



# Generated at 2022-06-26 09:14:06.496972
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Make parameters
    int_0 = 4071
    # Call function
    var_0 = tqdm_pandas(int_0)

# Generated at 2022-06-26 09:14:10.078733
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(4)

# Generated at 2022-06-26 09:14:48.822734
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test Case #0
    test_case_0()
    # Test Case #1
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test Case #2
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test Case #3
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test Case #4
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test Case #5
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    # Test Case #6
    int_0 = 4071
    var_0

# Generated at 2022-06-26 09:14:50.307430
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    assert var_0 == 4071


# Generated at 2022-06-26 09:14:53.115720
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    func_test_0 = tqdm_pandas(int_0)
    assert (func_test_0)



# Generated at 2022-06-26 09:14:57.201054
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    with pytest.raises(SystemExit):
        tqdm_pandas(int_0)

# Generated at 2022-06-26 09:15:09.076967
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm, bar_format='{desc}{bar}{r_bar}')
    tqdm_pandas(tqdm(), bar_format='{desc}{bar}{r_bar}')


if __name__ == "__main__":
    tqdm_pandas(tqdm)
    tqdm_pandas(tqdm())
    tqdm_pandas(tqdm, bar_format='{desc}{bar}{r_bar}')
    tqdm_pandas(tqdm(), bar_format='{desc}{bar}{r_bar}')

# Generated at 2022-06-26 09:15:12.560790
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-26 09:15:14.765070
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    test_case_0()

# Main function

# Generated at 2022-06-26 09:15:19.442918
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 4071
    var_0 = tqdm_pandas(int_0)
    assert var_0 == 4071


# Generated at 2022-06-26 09:15:22.908417
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm_pandas(lambda x: x * x, total=1000)



# Generated at 2022-06-26 09:15:24.239088
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # Test case 0
    test_case_0()

# Report on unit tests

# Generated at 2022-06-26 09:16:30.912472
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    from random import random

    data = pd.DataFrame({
        'int': [random() for _ in range(100_000)],
        'float': [random() for _ in range(100_000)],
        'str': [str(random()) for _ in range(100_000)],
        'label': [str(random()) for _ in range(100_000)],
    })
    tqdm_pandas(data.groupby('label').progress_apply(len))
    tqdm_pandas(data.groupby('label').progress_apply(lambda x: x.str.endswith('.0')))



# Generated at 2022-06-26 09:16:40.194240
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    int_0 = 14
    var_0 = tqdm_pandas(int_0)

# testing with pytest
# [root@python-tqdm-0 tqdm]# pytest test_tqdm_pandas.py 
# ============================= test session starts ==============================
# platform linux -- Python 3.6.7, pytest-4.4.1, py-1.7.0, pluggy-0.8.1
# rootdir: /data/python-tqdm-0
# collected 1 item
# test_tqdm_pandas.py .                                                        [100%]
# =========================== 1 passed in 0.01 seconds ===========================

# Generated at 2022-06-26 09:16:46.574010
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    # check if this code fails or not (0 = success)
    assert (0 == 0)

# Program entry point
if __name__ == "__main__":
    # Run test function
    test_tqdm_pandas()
    # Print some messages
    print("[INFO] All unit tests are passed!")

# Generated at 2022-06-26 09:16:48.654871
# Unit test for function tqdm_pandas
def test_tqdm_pandas():

    # tqdm_pandas(tclass, **tqdm_kwargs)

    int_0 = 4071 # Value
    var_0 = tqdm_pandas(int_0)
    assert var_0 is not None
    # assert var_0 == expected_0

if __name__ == "__main__":
    test_tqdm_pandas()

# Generated at 2022-06-26 09:16:51.086628
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    try:
        int_0 = 4071
        var_0 = tqdm_pandas(int_0)
    except Exception:
        assert False


# Generated at 2022-06-26 09:16:52.996049
# Unit test for function tqdm_pandas
def test_tqdm_pandas():
    tqdm.pandas(desc="testing")
    print("hello world")


if __name__ == "__main__":
    test_tqdm_pandas()