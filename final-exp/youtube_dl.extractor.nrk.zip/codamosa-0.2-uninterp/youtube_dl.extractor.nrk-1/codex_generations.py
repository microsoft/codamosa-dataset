

# Generated at 2022-06-18 14:25:40.073909
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', 'nrk.no')
    assert ie.IE_NAME == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.SUCCESS_REGEX == r'(?:^|[\s\n]+)ok(?:[\s\n]+|$)'
    assert ie.FAIL_REGEX == r'(?:^|[\s\n]+)fail(?:[\s\n]+|$)'
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:25:49.200663
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podkast') == 'podcast'
    assert ie._catalog_name('series') == 'series'
    assert ie._catalog_name('something') == 'series'
    assert ie._extract_assets_key({}) is None
    assert ie._extract_assets_key({'episodes': {}}) == 'episodes'
    assert ie._extract_assets_key({'instalments': {}}) == 'instalments'
    assert ie._extract_assets_key({'episodes': {}, 'instalments': {}}) == 'episodes'
    assert ie._

# Generated at 2022-06-18 14:25:55.522989
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert NRKPlaylistIE.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449/')

# Generated at 2022-06-18 14:25:55.991238
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()

# Generated at 2022-06-18 14:26:01.058397
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.IE_NAME == 'nrk:episode'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:26:05.442688
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220" /></head></html>'

# Generated at 2022-06-18 14:26:14.527678
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie.IE_DESC == 'NRK Radio Podkast'
    assert ie.IE_NAME == 'nrk:radiopodkast'
    assert ie.ie_key() == 'NRKRadioPodkast'
    assert ie.SUITABLE_GENERIC == False
    assert ie.SUITABLE_BROWSER == False

# Generated at 2022-06-18 14:26:21.423981
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """
    Unit test for constructor of class NRKTVDirekteIE
    """
    nrktvdirekte_ie = NRKTVDirekteIE()
    assert nrktvdirekte_ie.ie_key() == 'NRKTVDirekte'
    assert nrktvdirekte_ie.ie_desc() == 'NRK TV Direkte and NRK Radio Direkte'
    assert nrktvdirekte_ie.ie_name() == 'NRKTVDirekte'
    assert nrktvdirekte_ie.ie_version() == '0.1'
    assert nrktvdirekte_ie.extractor_key() == 'NRKTVDirekte'
    assert nrktvdirekte_ie

# Generated at 2022-06-18 14:26:29.456626
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    assert nrk_radio_podkast_ie._match_id(url) == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

# Generated at 2022-06-18 14:26:39.348488
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._EPISODE_RE == '(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'

# Generated at 2022-06-18 14:27:34.324157
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()

# Generated at 2022-06-18 14:27:44.791318
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    test_url = 'https://tv.nrk.no/direkte/nrk1'
    ie = NRKTVDirekteIE(NRKTVDirekteIE.ie_key())
    assert ie.suitable(test_url)
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.IE_VERSION == '1.0'
    assert ie.VALID_URL == 'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://nrk.no/serum/objects/%s.json'


# Generated at 2022-06-18 14:27:52.980675
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1'
    playlist_id = 'dagsrevyen/1'
    playlist_title = 'Dagsrevyen'
    playlist_description = 'md5:63692ceb96813d9a207e9910483d948b'

# Generated at 2022-06-18 14:27:55.021634
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE(NRKSkoleIE.ie_key())._VALID_URL == NRKSkoleIE._VALID_URL

# Generated at 2022-06-18 14:28:02.985043
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/serie/(?P<id>[^/?#&]+)'
    assert ie._ITEM_RE == r'nrk:([\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-18 14:28:12.433798
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')

# Generated at 2022-06-18 14:28:22.260101
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test constructor of class NRKTVEpisodesIE
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie

# Generated at 2022-06-18 14:28:26.865583
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201507/NPUB21019315')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#')

# Generated at 2022-06-18 14:28:27.524161
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-18 14:28:31.842033
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie.suitable(url)
    assert nrk_skole_ie._match_id(url) == '14099'


# Generated at 2022-06-18 14:29:31.112580
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:29:39.292887
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:29:48.691736
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:29:58.661360
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.__class__.__name__ == 'NRKTVEpisodesIE'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-18 14:30:00.257078
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE(NRKPlaylistBaseIE.ie_key())



# Generated at 2022-06-18 14:30:05.107837
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:30:15.264728
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/programmer/kategori/dokumentar/dokumentar/'
    playlist_id = 'dokumentar'
    webpage = '<html><body><div class="nrk-playlist-item" data-nrk-asset-id="MUHH48000314AA"></div></body></html>'
    entries = [
        'nrk:MUHH48000314AA'
    ]
    playlist_title = 'Dokumentar'
    playlist_description = None

    nrk_playlist_base_ie = NRKPlaylistBaseIE()
    nrk_playlist_base_ie.url = url
    nrk_playlist_base_ie.playlist_id = playlist_id
    nrk_playlist_base_ie.web

# Generated at 2022-06-18 14:30:17.318711
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE(NRKTVIE())._ITEM_RE == NRKTVIE._EPISODE_RE

# Generated at 2022-06-18 14:30:29.418118
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]



# Generated at 2022-06-18 14:30:33.874327
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:32:52.592158
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert ie._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-18 14:33:01.010252
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220" /></head></html>'

# Generated at 2022-06-18 14:33:04.069023
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:33:09.639515
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:33:15.021826
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:33:24.484885
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK Playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-18 14:33:28.910064
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie.IE_DESC == 'NRK Radio Podkast'
    assert ie.ie_key() == 'NRKRadioPodkast'
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:33:36.693857
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')

# Generated at 2022-06-18 14:33:42.872895
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\n        (?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n        )/'


# Generated at 2022-06-18 14:33:52.864108
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/klipp/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763/video/PS*12270763')