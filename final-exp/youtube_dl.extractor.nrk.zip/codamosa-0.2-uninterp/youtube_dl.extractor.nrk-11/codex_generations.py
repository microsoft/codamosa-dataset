

# Generated at 2022-06-18 14:25:48.637605
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'nrk:radio_podkast'
    assert ie.IE_DESC == 'NRK Radio Podkast'

# Generated at 2022-06-18 14:25:54.834859
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == None
    assert ie._ITEM_RE == None
    assert ie._TESTS == []
    assert ie.IE_NAME == None
    assert ie.IE_DESC == None
    assert ie.ie_key() == None
    assert ie.suitable(None) == False
    assert ie.working == False
    assert ie._downloader == None
    assert ie._download_webpage(None, None) == None
    assert ie._match_id(None) == None
    assert ie._real_extract(None) == None
    assert ie._extract_description(None) == None
    assert ie._extract_title(None) == None
    assert ie.playlist_result(None, None, None, None) == None

# Generated at 2022-06-18 14:26:00.219788
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == NRKTVIE._VALID_URL
    assert ie._TESTS == NRKTVIE._TESTS
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie.ie_key() == 'NRKTV'
    assert ie.ie_key() == 'NRKRadio'


# Generated at 2022-06-18 14:26:10.926732
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller/')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller/1')
   

# Generated at 2022-06-18 14:26:14.975232
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'



# Generated at 2022-06-18 14:26:23.914600
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller/1')

# Generated at 2022-06-18 14:26:30.843244
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:26:35.448300
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'


# Generated at 2022-06-18 14:26:36.145781
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-18 14:26:45.075178
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:27:54.193337
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/2016')
    assert ie.suitable('https://tv.nrk.no/serie/blank/2016/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/2016/episode/1/avspiller')

# Generated at 2022-06-18 14:28:02.508406
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.__name__ == 'NRKPlaylistBaseIE'
    assert NRKPlaylistBaseIE.__doc__ == 'Base class for NRK playlists'
    assert NRKPlaylistBaseIE.IE_DESC == 'NRK Playlists'
    assert NRKPlaylistBaseIE._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/(?:[^/]+/)+(?P<id>[^/?#&]+)'
    assert NRKPlaylistBaseIE._ITEM_RE == r'nrk:([^"]+)'
    assert NRKPlaylistBaseIE._TESTS == []
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/dagsrevyen-21-05-2019')

# Generated at 2022-06-18 14:28:12.085254
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-18 14:28:16.475543
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == NRKTVIE._VALID_URL
    assert ie._TESTS == NRKTVIE._TESTS
    assert ie.IE_DESC == NRKTVIE.IE_DESC
    assert ie.ie_key() == 'NRKTV'


# Generated at 2022-06-18 14:28:21.519696
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_key() == NRKTVDirekteIE.ie_key()
    assert ie.IE_NAME == 'NRKTVDirekte'
    assert ie.IE_NAME == NRKTVDirekteIE.IE_NAME
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.IE_DESC == NRKTVDirekteIE.IE_DESC
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._VALID_URL == NRKTVD

# Generated at 2022-06-18 14:28:24.744806
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    assert nrk.IE_NAME == 'nrk'
    assert nrk.IE_DESC == 'NRK'
    assert nrk.VALID_URL == NRKIE._VALID_URL
    assert nrk.GEO_COUNTRIES == ['NO']
    assert nrk.CDN_REPL_REGEX == NRKIE._CDN_REPL_REGEX


# Generated at 2022-06-18 14:28:34.462993
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._ITEM_RE == r'nrk:([\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie._TITLE_RE == r'<title>(.+?)</title>'
    assert ie._DESCRIPTION_RE == r'<meta name="description" content="(.+?)">'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/(?:[^/]+/)+(?P<id>[^/?#&]+)'
    assert ie._TESTS == []
    assert ie.IE_DESC == 'NRK Playlist'
    assert ie.ie_key

# Generated at 2022-06-18 14:28:43.972589
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK Playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'


# Generated at 2022-06-18 14:28:53.451780
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    webpage = '''
        <div class="rich" data-video-id="MUHH48000314AA">
        <div class="rich" data-video-id="MUHH48000314BB">
    '''
    entries = [
        'nrk:MUHH48000314AA',
        'nrk:MUHH48000314BB',
    ]
    playlist_title = 'Gjenopplev den historiske solformørkelsen'

# Generated at 2022-06-18 14:28:58.003827
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE


# Generated at 2022-06-18 14:30:05.066092
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    assert nrk_radio_podkast_ie._match_id(url) == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

# Generated at 2022-06-18 14:30:06.549403
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE('NRKTVEpisodesIE', 'NRK TV Episodes')


# Generated at 2022-06-18 14:30:11.001484
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1')
    assert NRKTVDirekteIE.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/dagsrevyen')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1/sesong/1/episode/1')
    assert not NRKTVDire

# Generated at 2022-06-18 14:30:15.604607
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_desc() == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.suitable('https://tv.nrk.no/direkte/nrk1')
    assert ie.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not ie.suitable('https://tv.nrk.no/serie/dagsrevyen')
    assert not ie.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')

# Generated at 2022-06-18 14:30:27.007068
# Unit test for constructor of class NRKRadioPodkastIE

# Generated at 2022-06-18 14:30:33.878517
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    ie = NRKPlaylistIE(NRKPlaylistIE.suitable(url), url)
    assert ie.playlist_id == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    assert ie.url == url
    assert ie.playlist_title == 'Gjenopplev den historiske solformørkelsen'
    assert ie.playlist_description == 'md5:c2df8ea3bac5654a26fc2834a542feed'
    assert ie.playlist_count == 2


# Generated at 2022-06-18 14:30:39.019786
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')
    assert not NRKTVSeason

# Generated at 2022-06-18 14:30:49.700521
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:30:57.351980
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1'
    playlist_id = 'dagsrevyen/1'
    webpage = '<html><body><div>test</div></body></html>'
    playlist_title = 'test'
    playlist_description = 'test'
    entries = [
        'nrk:%s' % video_id
        for video_id in re.findall(NRKTVSeasonIE._ITEM_RE, webpage)
    ]
    playlist_result = {
        '_type': 'playlist',
        'id': playlist_id,
        'title': playlist_title,
        'description': playlist_description,
        'entries': entries,
    }

# Generated at 2022-06-18 14:31:07.981723
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/lindmo/2016')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/spangas/sesong/1')

# Generated at 2022-06-18 14:32:40.904677
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie.IE_DESC == 'NRK Radio Podkast'
    assert ie.ie_key() == 'nrk:radiopodkast'
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
   

# Generated at 2022-06-18 14:32:47.334712
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'nrk:radio_podkast'
    assert ie.IE_DESC == 'NRK Radio Podkast'

# Generated at 2022-06-18 14:32:51.759056
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1/')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1/avspiller')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1/avspiller/')

# Generated at 2022-06-18 14:32:59.150644
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:33:03.525679
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/program/MDDP12000117'
    assert ie._TESTS[0]['md5'] == 'c4a5960f1b00b40d47db65c1064e0ab1'
    assert ie._T

# Generated at 2022-06-18 14:33:10.527881
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')

# Generated at 2022-06-18 14:33:19.554125
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert ie.suitable('https://radio.nrk.no/serie/dickie-dick-dickens')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/nrkno-poddkast-26588-134079-05042018030000')


# Generated at 2022-06-18 14:33:23.957655
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:33:32.570605
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL is None
    assert ie._ITEM_RE is None
    assert ie._TESTS is None
    assert ie.IE_NAME is None
    assert ie.IE_DESC is None
    assert ie.ie_key() is None
    assert ie.webpage_url_basename() is None
    assert ie.suitable(None) is False
    assert ie.working is False
    assert ie.extract_id(None) is None
    assert ie._real_extract(None) is None
    assert ie._download_webpage(None, None) is None
    assert ie._extract_title(None) is None
    assert ie._extract_description(None) is None
    assert ie.playlist_result(None, None, None, None)

# Generated at 2022-06-18 14:33:37.282499
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'