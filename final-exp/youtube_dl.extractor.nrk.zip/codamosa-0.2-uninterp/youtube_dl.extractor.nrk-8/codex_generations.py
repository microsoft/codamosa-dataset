

# Generated at 2022-06-18 14:25:40.665148
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    NRKRadioPodkastIE(NRKRadioPodkastIE._create_ie(), url)

# Generated at 2022-06-18 14:25:49.503382
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:25:55.854992
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie.VALID_URL == NRKIE._VALID_URL
    assert ie.GEO_COUNTRIES == NRKBaseIE._GEO_COUNTRIES
    assert ie.CDN_REPL_REGEX == NRKBaseIE._CDN_REPL_REGEX
    assert ie.TESTS == NRKIE._TESTS


# Generated at 2022-06-18 14:26:07.221198
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:26:19.458541
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie.IE_DESC == 'NRK Playlist'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/serie/(?P<id>[^/?#&]+)'

# Generated at 2022-06-18 14:26:20.403939
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-18 14:26:26.187057
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('https://tv.nrk.no/serie/backstage/sesong/1')
    assert ie.domain == 'tv'
    assert ie.serie_kind == 'serie'
    assert ie.serie == 'backstage'
    assert ie.season_id == '1'
    assert ie.display_id == 'backstage/1'



# Generated at 2022-06-18 14:26:36.981051
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:26:38.726297
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test that the constructor of NRKTVDirekteIE is able to create an instance
    # of NRKTVDirekteIE
    NRKTVDirekteIE()

# Generated at 2022-06-18 14:26:48.997692
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    ie = NRKTVSeasonIE(url)
    assert ie.suitable(url)
    assert ie.__class__.__name__ == 'NRKTVSeasonIE'
    assert ie.__class__.__bases__[0].__name__ == 'NRKTVSerieBaseIE'
    assert ie.__class__.__bases__[0].__bases__[0].__name__ == 'NRKBaseIE'
    assert ie.__class__.__bases__[0].__bases__[0].__bases__[0].__name__ == 'InfoExtractor'


# Generated at 2022-06-18 14:27:47.624471
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:27:59.431135
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == None
    assert ie._ITEM_RE == None
    assert ie._TITLE_RE == None
    assert ie._TESTS == []
    assert ie.IE_DESC == 'NRK Playlist Base'
    assert ie.ie_key() == 'NRKPlaylistBase'
    assert ie.SUCCESS_CODES == [0]
    assert ie.extract_flat == False
    assert ie.http_headers == {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20150101 Firefox/47.0 (Chrome)',
    }
    assert ie.query == {}
    assert ie.note == None

# Generated at 2022-06-18 14:28:00.736219
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE(NRKPlaylistBaseIE.ie_key())



# Generated at 2022-06-18 14:28:11.242756
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    nrktvseasonie = NRKTVSeasonIE(url)
    assert nrktvseasonie.suitable(url)
    assert nrktvseasonie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''

# Generated at 2022-06-18 14:28:15.829723
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_desc() == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.suitable('https://tv.nrk.no/direkte/nrk1')
    assert ie.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not ie.suitable('https://tv.nrk.no/serie/dagsrevyen')
    assert not ie.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')

# Generated at 2022-06-18 14:28:20.782968
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:28:30.974536
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    webpage = '''
    <div class="rich" data-video-id="MUHH48000314AA"></div>
    <div class="rich" data-video-id="MUHH48000314AB"></div>
    '''
    entries = [
        'nrk:MUHH48000314AA',
        'nrk:MUHH48000314AB',
    ]
    playlist_title = 'Gjenopplev den historiske solformørkelsen'

# Generated at 2022-06-18 14:28:31.546266
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-18 14:28:32.518092
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-18 14:28:39.280916
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:30:33.471730
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/1')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/1/')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/1/1')
    assert not ie

# Generated at 2022-06-18 14:30:34.023821
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()


# Generated at 2022-06-18 14:30:40.414894
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == NRKTVIE._VALID_URL
    assert ie._EPISODE_RE == NRKTVIE._EPISODE_RE
    assert ie._TESTS == NRKTVIE._TESTS
    assert ie.IE_DESC == NRKTVIE.IE_DESC
    assert ie.ie_key() == 'NRKTV'
    assert ie.ie_key() == NRKTVIE.ie_key()
    assert ie._real_extract == NRKTVIE._real_extract


# Generated at 2022-06-18 14:30:43.250624
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE('NRKPlaylistBaseIE')


# Generated at 2022-06-18 14:30:52.452779
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_NAME == 'nrk:tv'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-18 14:30:53.597250
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()


# Generated at 2022-06-18 14:31:00.492800
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/1')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/1/')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/1/1')
    assert not ie

# Generated at 2022-06-18 14:31:06.084820
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:31:13.821837
# Unit test for constructor of class NRKPlaylistIE

# Generated at 2022-06-18 14:31:22.994355
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')