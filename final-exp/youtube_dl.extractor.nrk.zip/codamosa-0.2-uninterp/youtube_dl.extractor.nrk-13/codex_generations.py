

# Generated at 2022-06-18 14:25:42.438228
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test for NRKPlaylistIE
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/klipp/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763/PS*12270763')

# Generated at 2022-06-18 14:25:43.760822
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test that the constructor of NRKTVSeriesIE does not raise an exception
    NRKTVSeriesIE()


# Generated at 2022-06-18 14:25:51.474515
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == 'NRK'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\n        (?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n        )/'


# Generated at 2022-06-18 14:25:57.686875
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._ITEM_RE == r'nrk:([\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/(?:[^/]+/)+(?P<id>[^/?#&]+)'
    assert ie.IE_DESC == 'NRK TV and NRK Radio playlists'
    assert ie.ie_key() == 'NRKPlaylistBase'

# Generated at 2022-06-18 14:26:04.488823
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-18 14:26:09.164697
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1#')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1?foo=bar')

# Generated at 2022-06-18 14:26:20.440522
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_desc() == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.suitable('https://tv.nrk.no/direkte/nrk1')
    assert ie.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not ie.suitable('https://tv.nrk.no/serie/blank')
    assert not ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert not ie.suitable('https://tv.nrk.no/serie/blank/sesong/1')

# Generated at 2022-06-18 14:26:27.087688
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:26:37.133370
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie.IE_DESC == 'NRK Playlist'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/serie/(?P<id>[^/?#&]+)'
    assert ie._ITEM_RE == r'nrk:([\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-18 14:26:39.186744
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'


# Generated at 2022-06-18 14:27:51.291434
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/lindmo')
    assert ie.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert ie.suitable('https://tv.nrk.no/serie/backstage')
    assert ie.suitable('https://tv.nrk.no/serie/spangas')
    assert ie.suitable('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    assert ie.suitable('https://tv.nrk.no/serie/saving-the-human-race')

# Generated at 2022-06-18 14:27:59.360614
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:28:09.900089
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Test for NRKTVSeasonIE
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8/avspiller')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8/avspiller')
    assert not NRKTVSeasonIE.su

# Generated at 2022-06-18 14:28:19.152399
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._ITEM_RE == None
    assert ie._VALID_URL == None
    assert ie._TESTS == []
    assert ie.IE_NAME == None
    assert ie.IE_DESC == None
    assert ie.ie_key() == None
    assert ie.suitable(None) == False
    assert ie.working == False
    assert ie.extract_id(None) == None
    assert ie._real_extract(None) == None
    assert ie._extract_title(None) == None
    assert ie._extract_description(None) == None
    assert ie.playlist_result(None, None, None, None) == None
    assert ie.url_result(None, None, None) == None


# Generated at 2022-06-18 14:28:22.711797
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test that the constructor of NRKPlaylistIE is working
    NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')


# Generated at 2022-06-18 14:28:28.279620
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:28:36.324132
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    mobj = re.match(NRKTVSeasonIE._VALID_URL, url)
    domain = mobj.group('domain')
    serie_kind = mobj.group('serie_kind')
    serie = mobj.group('serie')
    season_id = mobj.group('id') or mobj.group('id_2')
    display_id = '%s/%s' % (serie, season_id)

# Generated at 2022-06-18 14:28:41.485657
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test that the constructor of NRKTVDirekteIE is working
    # This is not a real test, but it is better than nothing
    NRKTVDirekteIE('NRKTVDirekte', 'NRK TV Direkte')



# Generated at 2022-06-18 14:28:42.588744
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()



# Generated at 2022-06-18 14:28:49.932552
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:31:03.192818
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:31:12.207174
# Unit test for constructor of class NRKRadioPodkastIE

# Generated at 2022-06-18 14:31:16.170033
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-18 14:31:23.871968
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert NRKTVEpisodeIE._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert NRKTVEpisodeIE._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert NRKTVEpisodeIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-18 14:31:34.253209
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % ie._EPISODE_RE

# Generated at 2022-06-18 14:31:39.648530
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE')
    assert ie.IE_NAME == 'NRKBaseIE'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:31:50.587141
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:31:58.711658
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    assert not NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355&test=test')
    assert not NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355&test=test')
    assert not NRK

# Generated at 2022-06-18 14:32:06.756746
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/klipp/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763/klipp/PS*12270763')

# Generated at 2022-06-18 14:32:10.484822
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Test constructor of class NRKSkoleIE
    # Test that the constructor of class NRKSkoleIE is working
    # properly.
    #
    # Input:
    #     None
    #
    # Expected output:
    #     An instance of class NRKSkoleIE

    ie = NRKSkoleIE()
    assert isinstance(ie, NRKSkoleIE)
