

# Generated at 2022-06-18 14:25:48.793526
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:25:55.046873
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:26:00.220629
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('https://tv.nrk.no/serie/backstage/sesong/1')
    assert ie._VALID_URL == 'https?://(?P<domain>tv|radio)\.nrk\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<serie>[^/]+)/(?:(?:sesong/)?(?P<id>\\d+)|sesong/(?P<id_2>[^/?#&]+))'

# Generated at 2022-06-18 14:26:07.651292
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/klipp/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763/video/PS*12270763')

# Generated at 2022-06-18 14:26:14.154418
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_name() == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-18 14:26:20.963154
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:26:27.356000
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''


# Generated at 2022-06-18 14:26:32.189081
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:26:37.937971
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:26:48.914313
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:27:53.814752
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-18 14:28:03.506932
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-18 14:28:12.782615
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert ie._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-18 14:28:22.659314
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-12')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-12')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-12')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-12')

# Generated at 2022-06-18 14:28:29.427617
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:28:35.173922
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:28:46.534791
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:28:47.444766
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-18 14:28:56.504019
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    assert nrk_radio_podkast_ie.suitable(url)
    assert nrk_radio_podkast_ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-18 14:29:07.784231
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    webpage = '<div class="rich" data-video-id="MUHH48000314AA"></div>'
    entries = [
        'nrk:MUHH48000314AA'
    ]
    playlist_title = 'Gjenopplev den historiske solformørkelsen'
    playlist_description = 'md5:c2df8ea3bac5654a26fc2834a542feed'
    playlist_count = 2

    # Test constructor of class NRKPlaylistIE
    NRKPlaylistIE_

# Generated at 2022-06-18 14:30:59.400763
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """Unit test for constructor of class NRKTVIE"""
    # Test for NRKTVIE
    NRKTVIE()


# Generated at 2022-06-18 14:31:00.094676
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-18 14:31:03.220687
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test constructor of class NRKTVEpisodesIE
    # Test if the constructor of class NRKTVEpisodesIE is working correctly
    # Input:
    #    - None
    # Expected output:
    #    - Instance of class NRKTVEpisodesIE
    assert isinstance(NRKTVEpisodesIE(), NRKTVEpisodesIE)



# Generated at 2022-06-18 14:31:04.509395
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE('NRKTVSeriesIE', 'https://tv.nrk.no/serie/groenn-glede')


# Generated at 2022-06-18 14:31:09.740892
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/program/MDDP12000117'
    assert ie._TESTS[0]['md5'] == 'c4a5960f1b00b40d47db65c1064e0ab1'
    assert ie._TESTS[0]['info_dict']['id'] == 'MDDP12000117'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._T

# Generated at 2022-06-18 14:31:17.092710
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
   

# Generated at 2022-06-18 14:31:18.212638
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()



# Generated at 2022-06-18 14:31:25.057419
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:31:35.079095
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie.IE_DESC == 'NRK Skole'

# Generated at 2022-06-18 14:31:38.911820
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
