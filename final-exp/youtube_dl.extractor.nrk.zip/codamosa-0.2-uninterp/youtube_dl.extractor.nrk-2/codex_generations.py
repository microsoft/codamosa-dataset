

# Generated at 2022-06-18 14:25:42.312956
# Unit test for constructor of class NRKPlaylistIE

# Generated at 2022-06-18 14:25:50.371117
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert ie._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-18 14:25:55.770880
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL is None
    assert ie._ITEM_RE is None
    assert ie._TESTS is None
    assert ie.IE_NAME is None
    assert ie.IE_DESC is None
    assert ie.ie_key() is None
    assert ie.webpage_url_basename() is None
    assert ie.suitable(None) is False
    assert ie._real_extract(None) is None
    assert ie._extract_description(None) is None
    assert ie._extract_title(None) is None
    assert ie._match_id(None) is None


# Generated at 2022-06-18 14:26:01.580413
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert NRKPlaylistIE.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/')

# Generated at 2022-06-18 14:26:12.421234
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:26:14.528572
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE._VALID_URL == NRKIE.VALID_URL
    assert NRKIE._TESTS == NRKIE.TESTS


# Generated at 2022-06-18 14:26:21.449658
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test for constructor of class NRKPlaylistIE
    # Create an instance of class NRKPlaylistIE
    nrk_playlist_ie = NRKPlaylistIE()
    # Test for _VALID_URL
    assert nrk_playlist_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    # Test for _ITEM_RE
    assert nrk_playlist_ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    # Test for _TESTS

# Generated at 2022-06-18 14:26:28.484192
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Test the constructor of class NRKRadioPodkastIE
    ie = NRKRadioPodkastIE()
    assert ie.IE_NAME == 'nrk:radiopodkast'
    assert ie.IE_DESC == 'NRK Radio Podkast'
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-18 14:26:33.948435
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201507/NPUB21019315')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#')

# Generated at 2022-06-18 14:26:41.538480
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')

# Generated at 2022-06-18 14:27:37.269181
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie.IE_DESC == 'NRK Playlist'



# Generated at 2022-06-18 14:27:46.734664
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test constructor of class NRKPlaylistIE
    # Test with valid url
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    nrk_playlist_ie = NRKPlaylistIE(url)
    assert nrk_playlist_ie._match_id(url) == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'

    # Test with invalid url
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763/'
    nrk_playlist_ie = NRKPlaylistIE(url)
    assert nrk_

# Generated at 2022-06-18 14:27:57.830900
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    assert ie._TESTS[0]['md5'] == '18c12c3d071953c3bf8d54ef6b2587b7'
    assert ie._TESTS[0]['info_dict']['id'] == '6021'

# Generated at 2022-06-18 14:28:02.903493
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:28:12.401605
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'nrk:episodes'
    assert ie.IE_DESC == 'NRK TV episodes'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-18 14:28:18.001816
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/69031')

# Generated at 2022-06-18 14:28:27.680189
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:28:36.041030
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_NAME == 'nrk:tv'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-18 14:28:41.999606
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    NRKRadioPodkastIE(NRKRadioPodkastIE.suitable(url), url)



# Generated at 2022-06-18 14:28:47.146184
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable(None) == False
    assert NRKPlaylistBaseIE.suitable('') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/') == False

# Generated at 2022-06-18 14:30:47.341913
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:30:53.613440
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:30:59.141895
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podkast') == 'podcast'
    assert ie._catalog_name('series') == 'series'
    assert ie._catalog_name('serie') == 'series'
    assert ie._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:31:04.420386
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    NRKRadioPodkastIE(NRKRadioPodkastIE._create_ie(), url)

# Generated at 2022-06-18 14:31:11.214616
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', 'nrk.no')
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\s*nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:31:18.108066
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller/')

# Generated at 2022-06-18 14:31:19.249103
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('NRKPlaylistIE', 'nrk.no')


# Generated at 2022-06-18 14:31:23.164482
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:31:25.923251
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')


# Generated at 2022-06-18 14:31:27.362482
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE('NRKRadioPodkastIE', 'NRK Radio Podkast')
