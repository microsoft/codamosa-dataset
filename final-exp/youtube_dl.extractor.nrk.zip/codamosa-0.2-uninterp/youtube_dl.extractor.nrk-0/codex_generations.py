

# Generated at 2022-06-18 14:25:45.162414
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie.IE_NAME == 'nrk:radiopodkast'
    assert ie.IE_DESC == 'NRK Radio Podkast'
    assert ie.ie_key() == 'NRKRadioPodkast'
    assert ie.SUITABLE_GENERIC == False
    assert ie.SUITABLE_BROWSER == False

# Generated at 2022-06-18 14:25:49.827377
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert NRKPlaylistIE.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/')

# Generated at 2022-06-18 14:25:54.740827
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    assert NRKTVSeasonIE._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''
    assert NRKTVSeasonIE.suitable(url)
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
   

# Generated at 2022-06-18 14:26:06.843251
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.GEO_COUNTRIES == ['NO']
    assert ie.CDN_REPL_REGEX == r'(?x)://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'

# Generated at 2022-06-18 14:26:11.487505
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201507/NPUB21019315')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#')


# Generated at 2022-06-18 14:26:21.099912
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert ie.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert not ie.suitable('http://www.nrk.no/video/')
    assert not ie.suitable('http://www.nrk.no/skole/')
    assert not ie.suitable('http://www.nrk.no/video/')
    assert not ie.suitable('http://www.nrk.no/skole/')

# Generated at 2022-06-18 14:26:27.608848
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/programoversikt/')
    assert NRKPlaylistBaseIE.suitable('https://radio.nrk.no/programoversikt/')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/programoversikt/')
    assert not NRKPlaylistBaseIE.suitable('https://radio.nrk.no/programoversikt/')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/programoversikt/')
    assert not NRKPlaylistBaseIE.suitable('https://radio.nrk.no/programoversikt/')

# Generated at 2022-06-18 14:26:37.566205
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/programoversikt/dag/20170301')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/programoversikt/dag/20170301/1')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/programoversikt/dag/20170301/2')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/programoversikt/dag/20170301/3')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/programoversikt/dag/20170301/4')

# Generated at 2022-06-18 14:26:47.150466
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podcast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:26:58.324722
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert not NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    assert not NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    assert not NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')

# Generated at 2022-06-18 14:28:01.250761
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name('series') == 'series'
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podkast') == 'podcast'
    assert ie._catalog_name('other') == 'series'
    assert ie._extract_entries(None) == []
    assert ie._extract_entries([]) == []
    assert ie._extract_entries([{'prfId': '123'}]) == [{
        '_type': 'url',
        'id': '123',
        'url': 'nrk:123',
        'ie_key': 'NRK',
    }]
    assert ie

# Generated at 2022-06-18 14:28:11.711661
# Unit test for constructor of class NRKTVSeasonIE

# Generated at 2022-06-18 14:28:20.464962
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebaseie = NRKTVSerieBaseIE()
    assert nrktvseriebaseie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert nrktvseriebaseie._catalog_name('podcast') == 'podcast'
    assert nrktvseriebaseie._catalog_name('podkast') == 'podcast'
    assert nrktvseriebaseie._catalog_name('series') == 'series'
    assert nrktvseriebaseie._catalog_name('serie') == 'series'
    assert nrktvseriebaseie._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:28:21.893611
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('NRKPlaylistIE', 'nrk.no')


# Generated at 2022-06-18 14:28:27.314660
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:28:33.787442
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL is None
    assert ie._ITEM_RE is None
    assert ie._TESTS is None
    assert ie.IE_NAME is None
    assert ie.IE_DESC is None
    assert ie.ie_key() is None
    assert ie.webpage_url_basename() is None
    assert ie.suitable(None) is False
    assert ie._real_extract(None) is None
    assert ie._extract_description(None) is None


# Generated at 2022-06-18 14:28:37.491723
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-18 14:28:46.074126
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:28:50.878545
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:28:58.566055
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    ie = NRKTVSeriesIE()
    assert ie.suitable(url)
    assert ie.ie_key() == 'NRKTVSeries'
    assert ie.ie_key() in NRKTVSeriesIE.ie_key()
    assert ie.ie_key() in globals()
    assert ie.ie_key() in sys.modules[__name__].__dict__
    assert ie.ie_key() in sys.modules[__name__].__dict__['NRKTVSeriesIE'].__dict__
    assert ie.ie_key() in sys.modules[__name__].__dict__['NRKTVSeriesIE'].__dict__['test_NRKTVSeriesIE'].__globals__
    assert ie.ie_

# Generated at 2022-06-18 14:30:07.547673
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE()

# Generated at 2022-06-18 14:30:14.017184
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podkast') == 'podcast'
    assert ie._catalog_name('series') == 'series'
    assert ie._catalog_name('serie') == 'series'
    assert ie._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:30:21.574132
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert NRKPlaylistIE._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-18 14:30:23.930604
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Test for constructor of class NRKRadioPodkastIE
    # Create an instance of class NRKRadioPodkastIE
    NRKRadioPodkastIE()

# Generated at 2022-06-18 14:30:29.676082
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-18 14:30:34.131268
# Unit test for constructor of class NRKTVDirekteIE

# Generated at 2022-06-18 14:30:43.133231
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test that the constructor of class NRKTVEpisodesIE is working
    # correctly.
    #
    # This test is not part of the unit test suite, but can be run
    # manually.
    #
    # Run this test by executing the following command:
    #
    #     $ python -m youtube_dl.extractor.nrktv
    #
    # The output should be:
    #
    #     NRKTVEpisodesIE: constructor: OK
    #
    # If the output is not as expected, please file a bug report at
    # https://github.com/rg3/youtube-dl/issues

    print('NRKTVEpisodesIE: constructor: OK')


# Generated at 2022-06-18 14:30:52.291974
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-38897')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-38897')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-38897')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-38897')

# Generated at 2022-06-18 14:31:02.819780
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.suitable(url)
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:31:11.931023
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    ie = NRKTVDirekteIE(url)
    assert ie.url == url
    assert ie.video_id == 'nrk1'
    assert ie.channel_id == 'nrk1'
    assert ie.channel_name == 'NRK1'
    assert ie.channel_type == 'tv'
    assert ie.channel_url == 'https://tv.nrk.no/direkte/nrk1'
    assert ie.channel_logo == 'https://nrk.no/nrk_radio/img/logo/nrk1.png'
    assert ie.channel_description == 'Se NRK1 direkte og on demand'

# Generated at 2022-06-18 14:34:05.795870
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:34:15.423290
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/20/episode/5-5-2020/avspiller')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/20/episode/5-5-2020/avspiller')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/20/episode/5-5-2020/avspiller')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/20/episode/5-5-2020/avspiller')
    assert not NR

# Generated at 2022-06-18 14:34:21.557544
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:34:25.946504
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-18 14:34:35.837121
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test that the constructor of class NRKPlaylistIE is working
    # correctly.
    ie = NRKPlaylistIE()
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK Playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'