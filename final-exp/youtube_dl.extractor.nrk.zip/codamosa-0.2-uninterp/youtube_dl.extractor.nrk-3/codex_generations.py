

# Generated at 2022-06-18 14:25:39.916656
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE('nrk:MDDP12000117')


# Generated at 2022-06-18 14:25:47.049048
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:25:52.685486
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:26:00.905143
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:26:11.673275
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/backstage')
    assert ie.suitable('https://tv.nrk.no/serie/lindmo')
    assert ie.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert ie.suitable('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    assert ie.suitable('https://tv.nrk.no/serie/saving-the-human-race')
    assert ie.suitable('https://tv.nrk.no/serie/postmann-pat')
    assert ie.suitable

# Generated at 2022-06-18 14:26:15.606176
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('others') == 'series'



# Generated at 2022-06-18 14:26:24.179064
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:26:35.632533
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/skam/sesong/4/episode/4'
    ie = NRKPlaylistBaseIE(NRKPlaylistBaseIE._create_ie(url))
    assert ie.suitable(url)
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK Playlist'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/serie/(?P<id>[^/?#&]+)'
    assert ie._ITEM_RE == r'nrk:([\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
   

# Generated at 2022-06-18 14:26:41.014008
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekte = NRKTVDirekteIE()
    assert nrktvdirekte.IE_NAME == 'nrk:direkte'
    assert nrktvdirekte.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert nrktvdirekte._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'


# Generated at 2022-06-18 14:26:45.561141
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-18 14:27:54.027629
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert ie.suitable('https://radio.nrk.no/serie/dickie-dick-dickens')
    assert ie.suitable('https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers')

# Generated at 2022-06-18 14:27:59.997223
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == None
    assert ie._ITEM_RE == None
    assert ie._TESTS == []
    assert ie.IE_NAME == None
    assert ie.IE_DESC == None
    assert ie.ie_key() == None
    assert ie.suitable(None) == False
    assert ie.working() == False
    assert ie._real_extract(None) == None


# Generated at 2022-06-18 14:28:10.227909
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:28:13.203051
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE().IE_NAME == 'nrk'
    assert NRKIE()._VALID_URL == NRKBaseIE._VALID_URL
    assert NRKIE()._GEO_COUNTRIES == NRKBaseIE._GEO_COUNTRIES
    assert NRKIE()._CDN_REPL_REGEX == NRKBaseIE._CDN_REPL_REGEX
    assert NRKIE()._TESTS == NRKBaseIE._TESTS


# Generated at 2022-06-18 14:28:23.163936
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert NRKTVEpisodesIE._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert NRKTVEpisodesIE._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:28:33.084749
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_NAME == 'nrk:tv'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-18 14:28:45.704881
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
   

# Generated at 2022-06-18 14:28:55.043784
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie.IE_NAME == 'nrk:radiopodkast'
    assert ie.IE_DESC == 'NRK Radio Podkast'
    assert ie.ie_key() == 'NRKRadioPodkast'

# Generated at 2022-06-18 14:29:00.946925
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-18 14:29:06.031308
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:30:12.853230
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable(NRKTVSeasonIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVEpisodeIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKRadioPodkastIE._VALID_URL)



# Generated at 2022-06-18 14:30:23.499268
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:30:28.312433
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:30:36.347348
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1') == False
    assert NRKPlaylistBase

# Generated at 2022-06-18 14:30:41.126576
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:30:42.197487
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE('NRKTVSeasonIE', 'https://tv.nrk.no/serie/backstage/sesong/1')


# Generated at 2022-06-18 14:30:48.096380
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert NRKPlaylistIE._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-18 14:30:56.070572
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-18 14:31:02.756631
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == NRKTVEpisodesIE.ie_key()
    assert ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/1')
    assert not ie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/1/1')
    assert not ie

# Generated at 2022-06-18 14:31:08.153598
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/(?:[^/]+/)+(?P<id>[^/?#&]+)'
    assert ie._ITEM_RE == r'<a href="/video/[^"]+/[^"]+/([^"]+)">'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/serie/dagsrevyen/20-05-2014/MUHH48000314/avspiller',
        'only_matching': True,
    }]
    assert ie.suitable('https://tv.nrk.no/serie/dagsrevyen/20-05-2014/MUHH48000314/avspiller')
   

# Generated at 2022-06-18 14:33:59.138702
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podcast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:34:00.040272
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE(NRKPlaylistBaseIE.ie_key()) is not None


# Generated at 2022-06-18 14:34:08.845276
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1#')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')

# Generated at 2022-06-18 14:34:10.831292
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test that the constructor of NRKTVDirekteIE does not raise an exception
    NRKTVDirekteIE()


# Generated at 2022-06-18 14:34:15.152558
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:34:23.510629
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-18 14:34:29.682665
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1#')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1?foo=bar')

# Generated at 2022-06-18 14:34:34.188844
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'nrk:episodes'
    assert ie.IE_DESC == 'NRK TV episodes'
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == 'data-episode=["\']%s' % NRKTVIE._EPISODE_RE