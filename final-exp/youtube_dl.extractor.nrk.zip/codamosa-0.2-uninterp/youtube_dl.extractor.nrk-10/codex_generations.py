

# Generated at 2022-06-18 14:25:42.478926
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:25:48.157460
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\n        (?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n        )/'


# Generated at 2022-06-18 14:25:54.035815
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:25:59.169898
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220"></head></html>'

# Generated at 2022-06-18 14:26:10.110519
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    assert nrk_radio_podkast_ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert nrk_radio_podkast_ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:26:17.896460
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:26:18.448621
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-18 14:26:27.390218
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:26:28.594617
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test that constructor of NRKTVDirekteIE does not raise exception
    NRKTVDirekteIE()

# Generated at 2022-06-18 14:26:31.364444
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE()
    except Exception as e:
        assert False, 'NRKPlaylistBaseIE constructor raised exception: ' + str(e)


# Generated at 2022-06-18 14:28:19.230567
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL is None
    assert ie._ITEM_RE is None
    assert ie._TESTS is None
    assert ie.IE_NAME is None
    assert ie.IE_DESC is None
    assert ie.ie_key() is None
    assert ie.webpage_url_basename() is None
    assert ie.suitable(None) is False
    assert ie._real_extract(None) is None
    assert ie._extract_description(None) is None
    assert ie._extract_title(None) is None
    assert ie._match_id(None) is None
    assert ie.playlist_result(None, None, None, None) is None
    assert ie.url_result(None, None, None) is None
    assert ie.ext

# Generated at 2022-06-18 14:28:24.113789
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:28:25.231920
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE()._VALID_URL == NRKIE._VALID_URL


# Generated at 2022-06-18 14:28:34.495382
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', 'nrk.no')
    assert ie.IE_NAME == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'

# Generated at 2022-06-18 14:28:36.495415
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-18 14:28:42.823190
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:28:52.481460
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % ie._EPISODE_RE

# Generated at 2022-06-18 14:28:59.363272
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert not ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8/')

# Generated at 2022-06-18 14:29:01.268148
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE(NRKPlaylistBaseIE.ie_key(), NRKPlaylistBaseIE._VALID_URL)



# Generated at 2022-06-18 14:29:07.712425
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'



# Generated at 2022-06-18 14:33:33.497694
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert ie._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-18 14:33:38.182733
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:33:44.932379
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/sesong/1')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt/sesong/1')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt/sesong/1/episode/1')

# Generated at 2022-06-18 14:33:55.764264
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test for NRKTVSeriesIE with url https://tv.nrk.no/serie/groenn-glede
    url = 'https://tv.nrk.no/serie/groenn-glede'
    ie = NRKTVSeriesIE(url)
    assert ie.url == url
    assert ie.site == 'tv.nrk.no'
    assert ie.serie_kind == 'serie'
    assert ie.series_id == 'groenn-glede'
    assert ie.is_radio == False
    assert ie.domain == 'tv'
    assert ie.size_prefix == 'embeddedInstalmentsP'

# Generated at 2022-06-18 14:33:58.024245
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE(NRKPlaylistIE.ie_key())._VALID_URL == NRKPlaylistIE._VALID_URL


# Generated at 2022-06-18 14:34:05.500658
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:34:15.349101
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.IE_KEY == 'NRKTVDirekte'
    assert ie.IE_URL == 'https://tv.nrk.no/direkte/nrk1'
    assert ie.IE_VERSION == '1.0'
    assert ie.IE_DESC_BASE == 'NRK TV Direkte'
    assert ie.IE_DESC_EXTRA == 'NRK Radio Direkte'
    assert ie.IE_DESC_RADIO == 'NRK Radio Direkte'
    assert ie.IE_DESC_TV == 'NRK TV Direkte'

# Generated at 2022-06-18 14:34:19.751029
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie.IE_DESC == 'NRK TV and NRK Radio'
    assert nrktvie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert nrktvie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % nrktvie._EPISODE_RE

# Generated at 2022-06-18 14:34:27.131866
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:34:31.133204
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
