

# Generated at 2022-06-18 14:25:45.949972
# Unit test for constructor of class NRKTVIE

# Generated at 2022-06-18 14:25:52.108451
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1#del=2')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1#del=2/episode/8')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')

# Generated at 2022-06-18 14:26:00.793767
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_NAME == 'nrk:tv'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-18 14:26:06.501975
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:26:13.384836
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:26:19.939586
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert ie._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-18 14:26:25.939407
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._ITEM_RE == None
    assert ie._VALID_URL == None
    assert ie.IE_NAME == None
    assert ie.IE_DESC == None
    assert ie._TESTS == []
    assert ie.BRIGHTCOVE_URL_TEMPLATE == None
    assert ie._downloader == None
    assert ie._download_webpage == None
    assert ie._match_id == None
    assert ie._extract_title == None
    assert ie._extract_description == None
    assert ie._real_extract == None
    assert ie.playlist_result == None
    assert ie.url_result == None


# Generated at 2022-06-18 14:26:32.113514
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test that NRKTVDirekteIE is a subclass of NRKTVIE
    assert issubclass(NRKTVDirekteIE, NRKTVIE)
    # Test that NRKTVDirekteIE is a subclass of InfoExtractor
    assert issubclass(NRKTVDirekteIE, InfoExtractor)
    # Test that NRKTVDirekteIE is a subclass of NRKBaseIE
    assert issubclass(NRKTVDirekteIE, NRKBaseIE)
    # Test that NRKTVDirekteIE is a subclass of YoutubeIE
    assert issubclass(NRKTVDirekteIE, YoutubeIE)
    # Test that NRKTVDirekteIE is a subclass of YoutubePlaylistIE

# Generated at 2022-06-18 14:26:40.678358
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'nrk:episodes'
    assert ie.IE_DESC == 'NRK TV episodes'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-18 14:26:49.703436
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == 'nrk'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:27:46.668264
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == ''
    assert ie._ITEM_RE == ''
    assert ie._TESTS == []
    assert ie.IE_NAME == ''
    assert ie.IE_DESC == ''
    assert ie.ie_key() == ''
    assert ie.suitable('') == False
    assert ie._real_extract('') == None
    assert ie._extract_description('') == None


# Generated at 2022-06-18 14:27:57.830253
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:28:08.150713
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.ie_key() == 'NRKTVEpisode'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILED == 'FAILED'
    assert ie.IE_NAME == 'NRKTVEpisode'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie.VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie.BRAND == 'NRK'
    assert ie.BRAND_ID == 'nrk'
    assert ie.API_BASE == 'https://psapi.nrk.no'


# Generated at 2022-06-18 14:28:12.941658
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'


# Generated at 2022-06-18 14:28:14.906671
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test that the constructor of NRKPlaylistIE works
    NRKPlaylistIE('NRKPlaylist', True)


# Generated at 2022-06-18 14:28:16.349421
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()


# Generated at 2022-06-18 14:28:21.387171
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509/episode/1')

# Generated at 2022-06-18 14:28:31.506332
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:28:39.990625
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:28:50.555749
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    assert nrk._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-18 14:30:51.270207
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == ''
    assert ie._ITEM_RE == ''
    assert ie._TESTS == []
    assert ie.IE_NAME == ''
    assert ie.IE_DESC == ''
    assert ie.ie_key() == ''
    assert ie.webpage_url_basename() == ''
    assert ie.suitable('') == False
    assert ie._real_extract('') == []


# Generated at 2022-06-18 14:31:01.545914
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    assert nrk._GEO_COUNTRIES == ['NO']
    assert nrk._CDN_REPL_REGEX == r'(?x)://\n            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|\n            nrk-od-no\.telenorcdn\.net|\n            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n        /'

# Generated at 2022-06-18 14:31:08.964367
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'



# Generated at 2022-06-18 14:31:14.189358
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    ie = NRKTVSeasonIE(url)
    assert ie.url == url
    assert ie.display_id == 'backstage/1'
    assert ie.season_id == '1'
    assert ie.serie == 'backstage'
    assert ie.domain == 'tv'
    assert ie.serie_kind == 'serie'
    assert ie.catalog_name == 'series'
    assert ie.season_id == '1'



# Generated at 2022-06-18 14:31:19.146006
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:31:25.502800
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    nrktvseasonie = NRKTVSeasonIE()
    assert nrktvseasonie.suitable(url)
    assert nrktvseasonie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''


# Generated at 2022-06-18 14:31:35.506757
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert ie.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert ie.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')
    assert not ie.suitable('https://tv.nrk.no/serie/lindmo/2018/MUHU11006318/avspiller')
    assert not ie.suitable('https://tv.nrk.no/serie/lindmo/2018/MUHU11006318/avspiller')

# Generated at 2022-06-18 14:31:41.940988
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1#del=2')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1#del=2/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')
    assert not NRKTVSeasonIE.suitable

# Generated at 2022-06-18 14:31:46.783504
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    ie = NRKTVSeriesIE(url)
    assert ie.suitable(url)
    assert ie.__class__.__name__ == 'NRKTVSeriesIE'
    assert ie.__class__.__bases__[0].__name__ == 'NRKTVSerieBaseIE'
    assert ie.__class__.__bases__[0].__bases__[0].__name__ == 'NRKBaseIE'
    assert ie.__class__.__bases__[0].__bases__[0].__bases__[0].__name__ == 'InfoExtractor'
    assert ie.__class__.__bases__[0].__bases__[0].__bases__[0].__bases

# Generated at 2022-06-18 14:31:55.750781
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1')
    assert NRKTVDirekteIE.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/dagsrevyen')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1')