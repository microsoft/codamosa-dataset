

# Generated at 2022-06-18 14:25:36.943209
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test that the constructor of NRKTVDirekteIE is working
    ie = NRKTVDirekteIE()
    # Test that the constructor of NRKTVIE is working
    ie = NRKTVIE()


# Generated at 2022-06-18 14:25:46.222910
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_NAME == 'nrk:tv'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-18 14:25:52.629159
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie.VALID_URL == NRKIE._VALID_URL
    assert ie.GEO_COUNTRIES == NRKBaseIE._GEO_COUNTRIES
    assert ie.CDN_REPL_REGEX == NRKBaseIE._CDN_REPL_REGEX
    assert ie.TESTS == NRKIE._TESTS


# Generated at 2022-06-18 14:25:55.899402
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == NRKTVIE._VALID_URL
    assert ie._EPISODE_RE == NRKTVIE._EPISODE_RE
    assert ie._TESTS == NRKTVIE._TESTS


# Generated at 2022-06-18 14:26:01.750181
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/kveldsnytt/sesong/1/episode/1'
    playlist_id = 'kveldsnytt/1'
    webpage = '<html></html>'
    entries = [
        'nrk:%s' % video_id
        for video_id in re.findall(NRKTVSeasonIE._ITEM_RE, webpage)
    ]
    playlist_title = 'Sesong 1'
    playlist_description = 'md5:63692ceb96813d9a207e9910483d948b'

# Generated at 2022-06-18 14:26:13.063157
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:26:20.379632
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/sesong/201209')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt/sesong/201209')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt')
   

# Generated at 2022-06-18 14:26:25.899081
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:26:32.322130
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller')
    assert ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller/')

# Generated at 2022-06-18 14:26:32.878742
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-18 14:28:18.276829
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/klipp/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763/video/PS*12270763')

# Generated at 2022-06-18 14:28:23.295818
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:28:29.020069
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:28:36.670808
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() in NRKTVEpisodesIE.ie_key()
    assert ie.ie_key() in NRKTVEpisodesIE.ie_key()
    assert ie.ie_key() in NRKTVEpisodesIE.ie_key()
    assert ie.ie_key() in NRKTVEpisodesIE.ie_key()
    assert ie.ie_key() in NRKTVEpisodesIE.ie_key()
    assert ie.ie_key() in NRKTVEpisodesIE.ie_key()
    assert ie.ie_key() in NRKTVEpisodesIE.ie_key()
    assert ie.ie_key() in NRKTVEpisodesIE.ie_key()
    assert ie

# Generated at 2022-06-18 14:28:47.483114
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_desc() == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.suitable('https://tv.nrk.no/direkte/nrk1')
    assert ie.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not ie.suitable('https://tv.nrk.no/serie/blank')
    assert not ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert not ie.suitable('https://tv.nrk.no/serie/blank/sesong/1')

# Generated at 2022-06-18 14:28:51.381279
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    NRKPlaylistIE(NRKPlaylistIE.suitable(url), url)



# Generated at 2022-06-18 14:28:58.893315
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_NAME == 'nrk:tv'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-18 14:29:01.075564
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test that the constructor of class NRKPlaylistIE works
    # This is a very basic test, but it is better than nothing
    NRKPlaylistIE()


# Generated at 2022-06-18 14:29:06.212236
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509/episode/1')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/201509')

# Generated at 2022-06-18 14:29:06.748580
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()


# Generated at 2022-06-18 14:31:12.136386
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220"/></head></html>'
    info = {'@id': 'MUHH36005220'}
    nrk_id = 'MUHH36005220'

    def _download_webpage(url, display_id):
        return webpage

    def _search_json_ld(webpage, display_id, default=_NO_DEFAULT):
        return info


# Generated at 2022-06-18 14:31:15.766644
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'



# Generated at 2022-06-18 14:31:21.195217
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('serie') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'



# Generated at 2022-06-18 14:31:26.954449
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta property="nrk:program-id" content="MUHH36005220"/></head></html>'

# Generated at 2022-06-18 14:31:32.725423
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:31:40.160587
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#del=2')

# Generated at 2022-06-18 14:31:51.164002
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:31:51.825282
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-18 14:31:56.459740
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\s*nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:32:05.380612
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220"></head></html>'
    info = {
        '@id': 'MUHH36005220',
        '_type': 'url',
        'id': 'MUHH36005220',
        'url': 'nrk:MUHH36005220',
        'ie_key': 'NRK',
        'season_number': 1,
        'episode_number': 2,
    }
    ie = NR