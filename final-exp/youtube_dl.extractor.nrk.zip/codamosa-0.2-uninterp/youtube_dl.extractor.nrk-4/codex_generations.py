

# Generated at 2022-06-18 14:25:45.912202
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % ie._EPISODE_RE

# Generated at 2022-06-18 14:25:51.584654
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.ie_key() == 'NRKTV'
    assert ie.ie_key() == NRKTVIE.ie_key()
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILURE == 'FAILURE'
    assert ie._VALID_URL == NRKTVIE._VALID_URL
    assert ie._EPISODE_RE == NRKTVIE._EPISODE_RE
    assert ie._TESTS == NRKTVIE._TESTS


# Generated at 2022-06-18 14:25:57.793323
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._ITEM_RE == r'nrk:([\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie._TITLE_RE == r'<title>([^<]+)</title>'
    assert ie._DESCRIPTION_RE == r'<meta name="description" content="([^"]+)"'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/serie/(?P<id>[^/?#&]+)'

# Generated at 2022-06-18 14:25:58.838006
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()

# Generated at 2022-06-18 14:26:05.357031
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-18 14:26:17.347534
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert ie.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert not ie.suitable('http://www.nrk.no/video/')
    assert not ie.suitable('http://www.nrk.no/skole/')
    assert not ie.suitable('http://www.nrk.no/video/')
    assert not ie.suitable('http://www.nrk.no/skole/')

# Generated at 2022-06-18 14:26:26.393456
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank'
    ie = NRKTVSeriesIE()
    assert ie.suitable(url)
    assert ie.ie_key() == 'NRKTVSeries'
    assert ie.ie_key() in NRKTVSeriesIE.ie_key()
    assert ie.ie_key() in globals()
    assert ie.ie_key() in sys.modules[__name__].__dict__
    assert ie.ie_key() in sys.modules[__name__].__dict__['NRKTVSeriesIE'].__dict__
    assert ie.ie_key() in sys.modules[__name__].__dict__['NRKTVSeriesIE'].__dict__['test_NRKTVSeriesIE'].__globals__

# Generated at 2022-06-18 14:26:32.604099
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta property="nrk:program-id" content="MUHH36005220" /></head></html>'

# Generated at 2022-06-18 14:26:34.529750
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')


# Generated at 2022-06-18 14:26:40.120371
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:27:36.906898
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:27:46.021582
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert ie.suitable('https://tv.nrk.no/serie/lindmo')
    assert ie.suitable('https://tv.nrk.no/serie/backstage')
    assert ie.suitable('https://tv.nrksuper.no/serie/labyrint')
    assert ie.suitable('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    assert ie.suitable('https://tv.nrk.no/serie/saving-the-human-race')
    assert ie.suitable

# Generated at 2022-06-18 14:27:57.753218
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220"></head></html>'

# Generated at 2022-06-18 14:28:07.965049
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:28:08.956751
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-18 14:28:18.794787
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt/sesong/201210')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt/sesong/201210/episode/1')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/episode/1')

# Generated at 2022-06-18 14:28:23.795372
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:28:29.445474
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:28:39.327086
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220" /></head></html>'

# Generated at 2022-06-18 14:28:50.020214
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:29:56.471767
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1#del=2')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1#del=2')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1#del=2')

# Generated at 2022-06-18 14:30:06.399350
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', 'nrk.no')
    assert ie.IE_NAME == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ie_key() == 'NRKBaseIE'

# Generated at 2022-06-18 14:30:07.579109
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """
    Test if NRKTVDirekteIE can be constructed.
    """
    NRKTVDirekteIE()

# Generated at 2022-06-18 14:30:12.238238
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:30:18.606650
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'


# Generated at 2022-06-18 14:30:29.577924
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert ie._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-18 14:30:35.618716
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:30:40.382924
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    ie = NRKTVSeasonIE(url)
    assert ie.suitable(url)
    assert ie.domain == 'tv'
    assert ie.serie_kind == 'serie'
    assert ie.serie == 'backstage'
    assert ie.season_id == '1'
    assert ie.display_id == 'backstage/1'
    assert ie.catalog_name == 'series'
    assert ie.api_url == 'https://tv.nrk.no/catalog/series/backstage/seasons/1'
    assert ie.api_query == {'pageSize': 50}
    assert ie.api_key == 'season'
    assert ie.api_note == 'Downloading season JSON'
   

# Generated at 2022-06-18 14:30:51.200896
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/avspiller/')

# Generated at 2022-06-18 14:31:01.444407
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:33:44.654509
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/stream/FLV_HIGH_QUALITY/play')

# Generated at 2022-06-18 14:33:55.467814
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_key() == NRKTVDirekteIE.ie_key()
    assert ie.IE_NAME == 'NRKTVDirekte'
    assert ie.IE_NAME == NRKTVDirekteIE.IE_NAME
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.IE_DESC == NRKTVDirekteIE.IE_DESC
    assert ie.VALID_URL == 'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie.VALID_URL == NRKTVDire

# Generated at 2022-06-18 14:34:01.662912
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == 'nrk'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:34:08.688573
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    ie = NRKTVDirekteIE(url)
    assert ie.url == url
    assert ie.display_id == 'nrk1'
    assert ie.program_id == 'nrk1'
    assert ie.channel_id == 'nrk1'
    assert ie.is_live == True
    assert ie.is_radio == False
    assert ie.is_ondemand == False
    assert ie.is_direkte == True
    assert ie.is_live_direkte == True
    assert ie.is_live_ondemand == False
    assert ie.is_live_radio == False
    assert ie.is_live_tv == True
    assert ie.is_live_tv_direk

# Generated at 2022-06-18 14:34:15.153569
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    webpage = '''
    <div class="rich" data-video-id="MUHH48000314AA"></div>
    <div class="rich" data-video-id="MUHH48000314AB"></div>
    '''
    playlist_title = 'Gjenopplev den historiske solformørkelsen'
    playlist_description = 'md5:c2df8ea3bac5654a26fc2834a542feed'

# Generated at 2022-06-18 14:34:21.420659
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:34:25.407035
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable(NRKTVSeasonIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVEpisodeIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKRadioPodkastIE._VALID_URL)


# Generated at 2022-06-18 14:34:31.633223
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'nrk:radio:podkast'
    assert ie.IE_DESC == 'NRK Radio Podkast'

# Generated at 2022-06-18 14:34:32.597361
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()


# Generated at 2022-06-18 14:34:40.529690
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert ie.IE_NAME == 'nrkskole'
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'