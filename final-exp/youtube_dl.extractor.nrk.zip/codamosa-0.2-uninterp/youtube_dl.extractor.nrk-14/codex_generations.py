

# Generated at 2022-06-18 14:25:43.388148
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    ie = NRKPlaylistIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK Playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-18 14:25:49.700515
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-18 14:25:56.010715
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_NAME == 'nrk:skole'
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:26:03.768004
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'nrk:radio_podkast'
    assert ie.IE_DESC == 'NRK Radio Podkast'

# Generated at 2022-06-18 14:26:15.797309
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1')
    assert NRKTVDirekteIE.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/dagsrevyen')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1')

# Generated at 2022-06-18 14:26:16.668809
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()

# Generated at 2022-06-18 14:26:17.444941
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-18 14:26:23.638034
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    nrktvseasonie = NRKTVSeasonIE()
    assert nrktvseasonie.suitable(url)
    assert nrktvseasonie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''

# Generated at 2022-06-18 14:26:26.835081
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'


# Generated at 2022-06-18 14:26:28.873042
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE._VALID_URL == NRKIE.VALID_URL
    assert NRKIE._TESTS == NRKIE.TESTS


# Generated at 2022-06-18 14:27:37.545774
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', 'nrk.no')
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\n            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|\n            nrk-od-no\.telenorcdn\.net|\n            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n        /'

# Generated at 2022-06-18 14:27:46.915325
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-18 14:27:58.267042
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')
    assert not NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/1')

# Generated at 2022-06-18 14:28:00.425790
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    NRKSkoleIE(url)


# Generated at 2022-06-18 14:28:08.822531
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:28:15.892081
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:28:20.930007
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-18 14:28:31.101693
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == None
    assert ie._ITEM_RE == None
    assert ie._TESTS == []
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK Playlists'
    assert ie.webpage_url == 'https://tv.nrk.no/program/'
    assert ie.playlist_id == 'nrk:playlist'
    assert ie.playlist_title == 'NRK Playlists'
    assert ie.playlist_description == None
    assert ie.playlist_result == None
    assert ie.url_result == None
    assert ie._extract_description == None
    assert ie._real_extract == None
    assert ie._download_webpage == None
    assert ie

# Generated at 2022-06-18 14:28:37.586056
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == None
    assert ie._ITEM_RE == None
    assert ie._TESTS == []
    assert ie.IE_NAME == None
    assert ie.IE_DESC == None
    assert ie.ie_key() == None
    assert ie.suitable(None) == False
    assert ie.working == False
    assert ie.extract_urls(None) == []
    assert ie._extract_description(None) == None
    assert ie._real_extract(None) == None
    assert ie._real_initialize() == None
    assert ie._download_webpage(None, None) == None
    assert ie._match_id(None) == None
    assert ie._extract_title(None) == None
    assert ie._extract

# Generated at 2022-06-18 14:28:48.276467
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert NRKTVEpisodesIE._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert NRKTVEpisodesIE._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:30:47.835279
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    nrktvseasonie = NRKTVSeasonIE()
    assert nrktvseasonie.suitable(url)
    assert nrktvseasonie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''

# Generated at 2022-06-18 14:30:48.399301
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()



# Generated at 2022-06-18 14:30:53.105203
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert ie._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-18 14:31:03.231658
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:31:12.208394
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220"></head></html>'
    info = {'@id': 'MUHH36005220'}
    nrk_id = 'MUHH36005220'

    def _download_webpage(url, display_id):
        return webpage

    def _search_json_ld(webpage, display_id, default=_NO_DEFAULT):
        return info


# Generated at 2022-06-18 14:31:21.265668
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-18 14:31:27.045373
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.IE_NAME == 'nrk:episode'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-18 14:31:36.942592
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-18 14:31:43.064329
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'nrk:episodes'
    assert ie.IE_DESC == 'NRK TV and NRK Radio episodes'
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == 'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-18 14:31:54.249012
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''