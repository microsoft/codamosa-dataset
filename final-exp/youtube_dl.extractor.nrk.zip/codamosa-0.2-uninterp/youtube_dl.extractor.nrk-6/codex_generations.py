

# Generated at 2022-06-18 14:25:37.795503
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')


# Generated at 2022-06-18 14:25:48.804089
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    ie = NRKTVSeriesIE(url)
    assert ie.suitable(url)
    assert ie.ie_key() == 'NRKTVSeries'
    assert ie.ie_key() in NRKTVSeriesIE.ie_key()
    assert ie.ie_key() in ie.ie_key()
    assert ie.ie_key() in ie.__class__.ie_key()
    assert ie.ie_key() in ie.__class__.__name__
    assert ie.ie_key() in ie.__class__.__name__.lower()
    assert ie.ie_key() in ie.__class__.__name__.lower()
    assert ie.ie_key() in ie.__class__.__name__

# Generated at 2022-06-18 14:25:52.528405
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    NRKRadioPodkastIE(NRKRadioPodkastIE._create_ie(), url)


# Generated at 2022-06-18 14:26:03.332376
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-18 14:26:15.472598
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-379909')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-379909')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-379909')
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/21/episode/1-1-379909')

# Generated at 2022-06-18 14:26:21.528555
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.ie_key() == 'NRKTVEpisode'
    assert ie.ie_key() in NRKTVEpisodeIE.ie_key()
    assert ie.name == 'NRKTVEpisode'
    assert ie.name in NRKTVEpisodeIE.name
    assert ie.description == 'NRK TV and NRK Radio'
    assert ie.description in NRKTVEpisodeIE.description
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._VALID_URL in NRKTVEpisodeIE._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-18 14:26:27.973568
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/klipp/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/PS*12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/PS*12270763')

# Generated at 2022-06-18 14:26:30.866711
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'



# Generated at 2022-06-18 14:26:35.858141
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    webpage = '<html><head><meta property="nrk:program-id" content="MUHH36005220" /></head></html>'
    nrk_id = 'MUHH36005220'

# Generated at 2022-06-18 14:26:39.631442
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable(NRKTVSeasonIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVEpisodeIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKRadioPodkastIE._VALID_URL)



# Generated at 2022-06-18 14:27:45.925743
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:27:57.673714
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/lindmo/2016')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/spangas/sesong/1')

# Generated at 2022-06-18 14:28:07.874160
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.ie_key() == 'NRKTV'
    assert ie.suitable('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8/avspiller')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8#')

# Generated at 2022-06-18 14:28:15.356532
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-18 14:28:25.774581
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test that the constructor of class NRKPlaylistIE works as expected
    # Create an instance of class NRKPlaylistIE
    nrk_playlist_ie = NRKPlaylistIE()
    # Test that the instance is an instance of class NRKPlaylistIE
    assert isinstance(nrk_playlist_ie, NRKPlaylistIE)
    # Test that the instance is an instance of class InfoExtractor
    assert isinstance(nrk_playlist_ie, InfoExtractor)
    # Test that the instance is an instance of class YoutubeBaseInfoExtractor
    assert isinstance(nrk_playlist_ie, YoutubeBaseInfoExtractor)
    # Test that the instance is an instance of class YoutubeBaseIE
    assert isinstance(nrk_playlist_ie, YoutubeBaseIE)
    # Test that the instance is an instance of class Search

# Generated at 2022-06-18 14:28:34.732543
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK Playlists'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/serie/(?P<id>[^/?#&]+)'
    assert ie._ITEM_RE == r'<a href="(?:https?://(?:tv|radio)\.nrk\.no/)?(?:serie|program)/[^/]+/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-18 14:28:46.495510
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:28:53.848333
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-18 14:29:00.225862
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'nrk:episodes'
    assert ie.IE_DESC == 'NRK TV and NRK Radio episodes'
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == 'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-18 14:29:11.920290
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() == 'NRKTVEpisodes'
   

# Generated at 2022-06-18 14:31:16.971666
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }]


# Generated at 2022-06-18 14:31:18.663762
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._extract_description(None) is None
    assert ie._real_extract(None) is None



# Generated at 2022-06-18 14:31:22.700080
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable(NRKTVSeasonIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVEpisodeIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKRadioPodkastIE._VALID_URL)



# Generated at 2022-06-18 14:31:33.785119
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-18 14:31:37.921247
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE()._VALID_URL == NRKBaseIE._VALID_URL
    assert NRKIE().IE_NAME == 'nrk'
    assert NRKIE()._GEO_COUNTRIES == NRKBaseIE._GEO_COUNTRIES
    assert NRKIE()._CDN_REPL_REGEX == NRKBaseIE._CDN_REPL_REGEX


# Generated at 2022-06-18 14:31:43.743981
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    ie = NRKTVDirekteIE(NRKTVDirekteIE.ie_key())
    assert ie.suitable(url)
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'

# Generated at 2022-06-18 14:31:54.523486
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('https://tv.nrk.no/serie/backstage/sesong/1')
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''

# Generated at 2022-06-18 14:32:01.980475
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Test for valid URL
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    # Test for invalid URL
    assert NRKTVEpisodeIE._VALID_URL != r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-18 14:32:03.356366
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE(NRKSkoleIE.ie_key()) == NRKSkoleIE

# Generated at 2022-06-18 14:32:05.152843
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('NRKTVDirekte', 'NRK TV Direkte and NRK Radio Direkte')

