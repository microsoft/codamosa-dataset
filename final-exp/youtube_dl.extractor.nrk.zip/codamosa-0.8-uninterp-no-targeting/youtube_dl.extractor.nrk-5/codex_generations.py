

# Generated at 2022-06-22 08:09:10.766548
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == "NRK Skole"
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-22 08:09:21.711103
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()

# Generated at 2022-06-22 08:09:23.703029
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'

# Generated at 2022-06-22 08:09:25.107353
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-22 08:09:26.439933
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert isinstance(NRKPlaylistBaseIE(), NRKPlaylistBaseIE)

# Generated at 2022-06-22 08:09:28.099289
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE().IE_NAME == 'nrk'


# Generated at 2022-06-22 08:09:36.778591
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    site, serie_kind, series_id = re.match(
        NRKTVSeriesIE._VALID_URL,
        'https://tv.nrk.no/serie/spangas/sesong/1/episode/8').groups()
    is_radio = site == 'radio.nrk'
    domain = 'radio' if is_radio else 'tv'
    size_prefix = 'p' if is_radio else 'embeddedInstalmentsP'
    query = {size_prefix + 'ageSize': 50}
    NRKTVSeriesIE._call_api(
        '%s/catalog/%s/%s'
        % (domain, NRKTVSeriesIE._catalog_name(serie_kind), series_id),
        series_id, 'serie', query)

# Generated at 2022-06-22 08:09:39.612122
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        NRKBaseIE("")
    except:
        assert False, "NRKBaseIE class and constructor need to work properly"



# Generated at 2022-06-22 08:09:44.556617
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebase = NRKTVSerieBaseIE()
    assert_equal(nrktvseriebase._CATALOGS, ['series', 'podcasts'])
    assert_equal(nrktvseriebase._ASSETS_KEYS, ('episodes', 'instalments',))



# Generated at 2022-06-22 08:09:44.986118
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-22 08:10:43.830726
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert isinstance(NRKTVSeasonIE(None)._extract_entries(None), list)



# Generated at 2022-06-22 08:10:51.305987
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    from re import compile
    from unittest.mock import Mock, patch
    from ..utils import extract_attributes, parse_iso8601

    def _make_response(url, content):
        import json
        from requests import Response

        return Response()

    def _extract_json(url):
        import json
        from requests import Response


# Generated at 2022-06-22 08:11:02.671533
# Unit test for constructor of class NRKTVSeasonIE

# Generated at 2022-06-22 08:11:06.829555
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-22 08:11:19.167313
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_ie = NRKTVEpisodesIE()
    assert nrktv_episodes_ie.ie_key() == 'NRKTVEpisodes'
    assert NRKTVEpisodesIE.ie_key() == 'NRKTVEpisodes'
    assert nrktv_episodes_ie.SUITABLE == NRKTVIE.SUITABLE
    assert NRKTVEpisodesIE.SUITABLE == NRKTVIE.SUITABLE

# Generated at 2022-06-22 08:11:27.036049
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    from .nrktv import NRKTVSerieBaseIE

# Generated at 2022-06-22 08:11:30.065717
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == NRKTVIE._VALID_URL
    assert ie.IE_NAME == 'nrk'



# Generated at 2022-06-22 08:11:32.272650
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('NRK TV Direkte')

# Generated at 2022-06-22 08:11:43.051001
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    import unittest
    import sys
    import os

    path_to_test_file = os.path.dirname(os.path.realpath(__file__)) + "/"
    path_to_log_file = path_to_test_file + "test.log"
    if os.path.exists(path_to_log_file):
        os.remove(path_to_log_file)

    test_loader = unittest.TestLoader()
    test_suite = test_loader.loadTestsFromTestCase(TestNRKTVEpisodesIE)
    test_runner = unittest.TextTestRunner(verbosity=2, stream=sys.stderr)
    test_runner.run(test_suite)

# Generated at 2022-06-22 08:11:46.661919
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()

# Generated at 2022-06-22 08:13:05.528618
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    info_extractor = NRKTVSerieBaseIE()
    assert info_extractor.DEFAULT_THUMBNAIL_URL == 'https://gfx.nrk.no/{id}_512.png'

# Generated at 2022-06-22 08:13:07.448414
# Unit test for constructor of class NRKIE
def test_NRKIE():
    pass

# Generated at 2022-06-22 08:13:10.805317
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('NRKPlaylistBaseIE', 'NRK Playlist Base IE')
    # id is empty
    assert ie.suitable('') is False


# Generated at 2022-06-22 08:13:16.570194
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    video_id = ie._match_id(url)
    assert video_id == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

# Generated at 2022-06-22 08:13:26.359940
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    args = {
        'url': 'https://tv.nrk.no/direkte/nrk1',
    }
    nrktvdirekte_ie = NRKTVDirekteIE(args)
    nrktvdirekte_ie.extract()
    # no content
    assert nrktvdirekte_ie.query_path == 'https://v8.psapi.nrk.no/mediaelement/%s' % args['url']
    assert nrktvdirekte_ie.headers == {'Referer': '', 'Sec-Fetch-Site': 'cross-site'}
    assert nrktvdirekte_ie.is_live == True
    assert nrktvdirekte_ie.parent_nrk_id == None
   

# Generated at 2022-06-22 08:13:27.759106
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    from .nrk import NRKPlaylistBaseIE
    assert NRKPlaylistBaseIE(NRKPlaylistBaseIE())._VALID_URL is NRKPlaylistBaseIE(
    )._VALID_URL



# Generated at 2022-06-22 08:13:33.081017
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/programoversikt/kategori/drama'
    ie = NRKPlaylistBaseIE()
    assert ie._match_id(url) == 'kategori/drama'



# Generated at 2022-06-22 08:13:37.601752
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """Test NRKIE constructor"""
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.GEO_COUNTRIES == ['NO']
    assert ie.CDN_REPL_REGEX == (
        '://(?:'
        'nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|'
        'nrk-od-no\\.telenorcdn\\.net|'
        'minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no'
        ')/')
    assert ie._VALID_URL == (
        '(?x)')

# Generated at 2022-06-22 08:13:40.853512
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    data = {
        '_embedded': {'episodes': {'_embedded': {'episodes': ['a', 'b', 'c']}}},
    }
    entries = list(NRKTVSeasonIE()._entries(data, 'x'))
    assert entries == ['a', 'b', 'c']



# Generated at 2022-06-22 08:13:49.112670
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert issubclass(NRKTVSerieBaseIE, NRKBaseIE)
    assert NRKTVSerieBaseIE._ASSETS_KEYS == ('episodes', 'instalments',)
    assert NRKTVSerieBaseIE._catalog_name('show') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('other') == 'series'
    assert NRKTVSerieBaseIE._extract_entries(None) == []
    assert list(NRKTVSerieBaseIE._entries(None, None)) == []



# Generated at 2022-06-22 08:16:09.674752
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Instance with unittest.
    _NRKPlaylistBaseIE = NRKPlaylistBaseIE()

    # Initialize the property.
    _NRKPlaylistBaseIE._ITEM_RE = 'dummy_id'

    # Unit test for function _extract_entries in class NRKPlaylistBaseIE.
    def test_NRKPlaylistBaseIE__extract_entries():
        # Unit test for function _extract_entries in class NRKPlaylistBaseIE.
        def test_NRKPlaylistBaseIE__extract_entries():
            page = 'dummy_page'
            playlist = 'dummy_playlist'

            # If the webpage does not contains video id, an exception will be raised.

# Generated at 2022-06-22 08:16:10.828052
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.__class__.__name__ == 'NRKTVEpisodesIE'

# Generated at 2022-06-22 08:16:19.990978
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    tvidie = NRKTVIE()
    assert tvidie.IE_DESC == 'NRK TV and NRK Radio'
    assert tvidie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' %  tvidie._EPISODE_RE
    assert tvidie._TESTS[0]['url'] == 'https://tv.nrk.no/program/MDDP12000117'
    assert tvidie._TESTS[0]['md5'] == 'c4a5960f1b00b40d47db65c1064e0ab1'

# Generated at 2022-06-22 08:16:21.572241
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', 'The NRK Base Internet Extractor')

# Generated at 2022-06-22 08:16:32.879423
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Testing if the NRKTVEpisodesIE is instantiated with a valid url
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    nrk = NRKTVEpisodesIE(NRKBaseIE())
    nrk._download_webpage = lambda _, __: ''
    nrk._call_api = lambda _, __, ___: {}
    nrk._real_extract(url)
    nrk._extract_title('<h1>Nytt på nytt, sesong: 201210</h1>')
    nrk._extract_description('')
    nrk._ITEM_RE = r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
   

# Generated at 2022-06-22 08:16:37.285654
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    
    # Test broken valid URL
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    if (url != None):
        if (not ie._VALID_URL.match(url)):
            raise Exception('URL does not match regex')
        # NRKRadioPodkastIE._real_extract(url)
        # Unit test for private method
        # NRKRadioPodkastIE._real_extract(url)
        
    # Test broken valid URL

# Generated at 2022-06-22 08:16:38.705891
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE('NRK', 'NRKTVIE')


# Generated at 2022-06-22 08:16:41.910489
# Unit test for constructor of class NRKIE
def test_NRKIE():
    for url, test in NRKIE._TESTS:
        nrk = NRKIE(url=url)
        assert nrk._match_id(url) == test['only_matching']

# Generated at 2022-06-22 08:16:46.141013
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie_test = NRKTVSeriesIE(NRKTVSeriesIE._create_ie_instance({}))
    assert ie_test._VALID_URL == NRKTVSeriesIE._VALID_URL


# Generated at 2022-06-22 08:16:55.580869
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # For the sake of testing, we create an instance of the subclass
    ie = NRKTVEpisodesIE()
    # _VALID_URL is a class attribute, so it is shared by all instances
    # so we need to make a copy of the attribute before modifying it
    # ie._VALID_URL = r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    ie._VALID_URL = r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    ie.init()
    print(ie._VALID_URL)
    # Make sure it complied the regular expression