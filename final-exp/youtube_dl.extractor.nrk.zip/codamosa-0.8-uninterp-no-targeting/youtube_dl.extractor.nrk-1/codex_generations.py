

# Generated at 2022-06-22 08:09:03.118476
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    for arg in ['https://tv.nrk.no/serie/backstage', 'https://tv.nrk.no/program/backstage']:
        assert (repr(NRKTVSerieBaseIE(NRKIE(), arg))
                == "NRKTVSerieBaseIE(NRKIE(info_dict={'_type': 'url', 'url': 'nrk:backstage', 'id': 'backstage', 'ie_key': 'NRK'}), 'https://tv.nrk.no/program/backstage')")


# Generated at 2022-06-22 08:09:13.576487
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    def test_NRKTVEpisodeIE_embedded_page(page_name):
        url = 'https://tv.nrk.no/serie/%s/sesong/1/episode/2' % page_name
        ie = NRKTVEpisodeIE()
        # raise error if the constructor is not able to return an instance of NRKTVEpisodeIE
        assert isinstance(ie, NRKTVEpisodeIE), "%s does not return an instance of type NRKTVEpisodeIE!" % url
    test_NRKTVEpisodeIE_embedded_page('dagsrevyen')
    test_NRKTVEpisodeIE_embedded_page('sporten')
    test_NRKTVEpisodeIE_embedded_page('20-spoersmaal')


# Generated at 2022-06-22 08:09:24.988404
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    from .nrktv import NRKTVIE
    from .nrktv import NRKTVSeasonIE
    from .nrktv import NRKTVEpisodeIE
    from .nrktv import NRKTVSeriesIE
    from .nrktv import NRKTVDirekteIE
    from .nrktv import NRKRadioPodkastIE
    url = "https://www.nrk.no/nordland/nordland-fylkeskommune-vil-holde-grensen-stengt-for-a-unnga-mistanke-om-smittespredning-1.15127916"
    ie = NRKTVIE()
    assert ie.suitable(url) is True
    nrktv_season_ie = NRKTVSeasonIE()
    assert nrktv_season_ie

# Generated at 2022-06-22 08:09:29.235877
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE.suitable(
        'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')


# Generated at 2022-06-22 08:09:31.042423
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrk_episodes_ie = NRKTVEpisodesIE()
    assert nrk_episodes_ie is not None


# Generated at 2022-06-22 08:09:34.932953
# Unit test for constructor of class NRKIE
def test_NRKIE():
    result = NRKIE()._constructor(NRKIE('test'))
    assert(result.name, 'test') == 'test'
    assert(result, result.IE_NAME) == 'nrk'

# Generated at 2022-06-22 08:09:42.324702
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'http://www.nrk.no/nett-tv/populært/klipp/1.16264528'
    video_id = 'nrk:16264528'
    obj = NRKPlaylistBaseIE()
    assert obj._match_id(url) == video_id
    assert obj.url_result(url, NRKIE.ie_key()) == obj.url_result(video_id, NRKIE.ie_key())
    assert obj._ITEM_RE

# Generated at 2022-06-22 08:09:47.486774
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'http://my.nrk.no/profile/playlists/playlist/12345678901234567890/'
    ie = NRKPlaylistBaseIE()
    expected_playlist_id = '12345678901234567890'
    playlist_id = ie._match_id(url)
    assert playlist_id == expected_playlist_id


# Generated at 2022-06-22 08:09:49.189813
# Unit test for constructor of class NRKIE
def test_NRKIE():
    for t in NRKIE._TESTS:
        yield t['url']


# Generated at 2022-06-22 08:10:01.366840
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'

# Generated at 2022-06-22 08:11:07.389307
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    print(NRKTVDirekteIE(NRKTVDirekteIE.suitable(url), url))

# Generated at 2022-06-22 08:11:10.400489
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    actual_value = NRKTVDirekteIE.ie_key()
    expected_value = 'nrktvdirekte'
    assert actual_value == expected_value


# Generated at 2022-06-22 08:11:13.729429
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE(_TEST_GEO_COUNTRIES=['NO', 'SE'])
    assert ie._GEO_COUNTRIES == ['NO', 'SE']


# Generated at 2022-06-22 08:11:25.626209
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Unit test for constructor of class NRKIE
    assert NRKIE.IE_NAME == 'nrk'
    assert NRKIE._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert len(NRKBaseIE._GEO_COUNTRIES) == 1
    assert NRKBaseIE._GEO_COUNTRIES[0] == 'NO'
    assert NRKBaseIE._CDN_REPL_REG

# Generated at 2022-06-22 08:11:27.222626
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(None, None, None)


# Generated at 2022-06-22 08:11:30.882570
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert(NRKRadioPodkastIE('NRKRadioPodkastIE', 'NRKRadioPodkastIE', 'NRKRadioPodkastIE') != None)

# Generated at 2022-06-22 08:11:34.280732
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert __name__ == ie.__module__
    assert 'nrk' == ie.IE_NAME
    assert 'NRK' == ie.ie_key()



# Generated at 2022-06-22 08:11:45.049472
# Unit test for constructor of class NRKSkoleIE

# Generated at 2022-06-22 08:11:49.718434
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test_url = "https://v8-psapi.nrk.no/mediaelement/ecc1b952-96dc-4a98-81b9-5296dc7a98d9"
    ie = NRKIE()
    assert ie._match_id(test_url) == "ecc1b952-96dc-4a98-81b9-5296dc7a98d9"



# Generated at 2022-06-22 08:11:59.961409
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE('NRKTV', True, 'http://example.com')
    assert ie.domain == 'radio'
    assert ie.catalog_name == 'podcast'
    assert ie.series_id == 'NRKTV'
    assert ie.series_url == 'http://example.com'

    ie = NRKTVSeriesIE('NRKTV', False, None)
    assert ie.domain == 'tv'
    assert ie.catalog_name == 'series'
    assert ie.series_id == 'NRKTV'
    assert ie.series_url is None

    ie = NRKTVSeriesIE('NRKTV', True)
    assert ie.domain == 'radio'
    assert ie.catalog_name == 'podcast'
    assert ie.series_id == 'NRKTV'
    assert ie.series

# Generated at 2022-06-22 08:14:27.097422
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()

# Generated at 2022-06-22 08:14:29.185200
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/baat-til-afrika/MUHH38000181/sesong-6#tab-avspillingsliste-797889'
    nrkplaylistbaseie = NRKPlaylistBaseIE()
    assert nrkplaylistbaseie.suitable(url)


# Generated at 2022-06-22 08:14:30.515117
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Testing has been moved to NRKIE
    assert NRKSkoleIE(NRKIE())._VALID_URL == NRKSkoleIE._VALID_URL

# Generated at 2022-06-22 08:14:31.646634
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    e = NRKTVEpisodeIE()
    assert isinstance(e.url_result('foo'), NRKTVEpisodeIE.url_result)

# Generated at 2022-06-22 08:14:35.808575
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert hasattr(NRKTVDirekteIE, 'IE_NAME')
    assert hasattr(NRKTVDirekteIE, '_VALID_URL')
    assert hasattr(NRKTVDirekteIE, '_TESTS')
    assert hasattr(NRKTVDirekteIE, '_real_extract')
    assert hasattr(NRKTVDirekteIE, 'suitable')

# Generated at 2022-06-22 08:14:36.804741
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('NRK')


# Generated at 2022-06-22 08:14:41.869883
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert NRKTVEpisodesIE._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert NRKTVEpisodesIE._TESTS[0] == {
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }


# Generated at 2022-06-22 08:14:43.807632
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    my_nrktvepisodesie = NRKTVEpisodesIE()
    my_nrktvepisodesie.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    my_nrktvepisodesie.extract()

# Generated at 2022-06-22 08:14:44.500319
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test constructor.
    assert NRKTVEpisodesIE()

# Generated at 2022-06-22 08:14:51.576663
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    video_id = ie._match_id("https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8")
    assert video_id == "l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"

