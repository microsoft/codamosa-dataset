

# Generated at 2022-06-22 08:09:11.457247
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    instance = NRKSkoleIE()
    assert instance.IE_NAME == 'nrk:skole'
    assert instance.IE_DESC == 'NRK Skole'
    assert instance._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert len(instance._TESTS) == 2
    assert instance.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099') is True
    assert instance.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355') is True

# Generated at 2022-06-22 08:09:14.188126
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('http://some_url.com')
    assert ie.IE_NAME == 'NRKTVDirekteIE'


# Generated at 2022-06-22 08:09:20.695698
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id, season_number, episode_number = re.match(NRKTVEpisodeIE._VALID_URL, url).groups()
    assert display_id == 'hellums-kro'
    assert season_number == '1'
    assert episode_number == '2'

# Generated at 2022-06-22 08:09:22.866666
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """
    Test for constructor of class NRKIE.
    """
    NRKIE()


# Generated at 2022-06-22 08:09:24.882911
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKPlaylistBaseIE.test_constructor(NRKTVDirekteIE)

# Generated at 2022-06-22 08:09:36.396426
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie_ses = NRKTVSeasonIE()
    assert ie_ses.suitable("https://tv.nrk.no/serie/lindmo/2016") == True
    assert ie_ses.suitable("https://tv.nrk.no/serie/spangas/sesong/1") == True
    assert ie_ses.suitable("https://radio.nrk.no/serie/dagsnytt/sesong/201509") == True
    assert ie_ses.suitable("https://tv.nrk.no/serie/lindmo/2016") == True
    assert ie_ses.suitable("https://tv.nrk.no/serie/lindmo/2016/avspiller") == False
    #assert ie_ses.suitable("https://tv.nrk.no/serie/lindmo

# Generated at 2022-06-22 08:09:43.696105
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    for season in seasons_data:
        season_extractor = NRKTVSeasonIE('nrk', season[0])
        assert season_extractor.is_suitable(season[0])
        assert season[1] == season_extractor.get_id(season[0])
        assert season[2] == season_extractor.get_title(season[0])
        assert season[3] == season_extractor.get_series_name(season[0])
        assert season[4] == season_extractor.get_season_number(season[0])
        assert season[5] == season_extractor.get_episode_number(season[0])


# Generated at 2022-06-22 08:09:45.990501
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # A URL to test
    url = u"https://tv.nrk.no/program/MDDP12000117"
    # make sure it is valid
    NRKTVIE._VALID_URL = r'.*'
    # Run the constructor
    NRKTVIE(NRKTVIE._downloader)._real_initialize(url)

# Generated at 2022-06-22 08:09:58.538105
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_page_url = "https://nrkno-skole-prod.kube.nrk.no/skole/api/media/17160"

# Generated at 2022-06-22 08:09:59.588033
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE()

# Generated at 2022-06-22 08:11:10.900746
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Init
    def build_url(name):
        return 'https://tv.nrk.no/direkte/%s' % name
    name = 'nrk1'
    url = build_url(name)

    # Test
    test = NRKTVDirekteIE.suitable(url)
    assert test == True

    # Init
    def build_url(name):
        return 'https://radio.nrk.no/direkte/%s' % name
    name = 'p1_oslo_akershus'
    url = build_url(name)

    # Test
    test = NRKTVDirekteIE.suitable(url)
    assert test == True



# Generated at 2022-06-22 08:11:15.770072
# Unit test for constructor of class NRKIE
def test_NRKIE():
    url = 'http://www.nrk.no/video/PS*150533'
    match = NRKIE._VALID_URL.match(url)
    assert(match is not None)
    video_id = match.group('id')
    print(video_id)
    nrk = NRKIE()
    nrk._match_id(url)
    nrk._real_extract(url)
    nrk.IE_NAME
    nrk.geo_countries
    nrk._GEO_COUNTRIES
    nrk._CDN_REPL_REGEX
    nrk._extract_nrk_formats(url, video_id)
    playlist_id = '63425'
    nrk.playlist_from_id(playlist_id)


# Generated at 2022-06-22 08:11:17.520216
# Unit test for constructor of class NRKIE
def test_NRKIE():
    url = 'nrk:clip/150533'
    nrk = NRKIE().get_info('', url)
    assert nrk.get('id') == '150533'
    age_limit = nrk.get('age_limit')
    assert age_limit == None

# Generated at 2022-06-22 08:11:18.722522
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    pass


# Generated at 2022-06-22 08:11:25.075974
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    data = {
        'url': 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015',
        'info_dict': {
            'id': 'MSPO40010515',
            'ext': 'mp4',
            'title': 'Sprint fri teknikk, kvinner og menn 06.01.2015',
            'description': 'md5:c03aba1e917561eface5214020551b7a',
            'age_limit': 0,
        },
        'params': {
            'skip_download': True,
        },
        'expected_warnings': ['Failed to download m3u8 information'],
        'skip': 'Ikke tilgjengelig utenfor Norge',
    }

# Generated at 2022-06-22 08:11:27.440123
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    instance = NRKTVSeriesIE()
    ie_key = NRKTVSeriesIE.ie_key()
    assert ie_key in NRKBaseIE._ies



# Generated at 2022-06-22 08:11:40.280977
# Unit test for constructor of class NRKIE
def test_NRKIE():
    info_dict = {
        'id': '150533',
        'ext': 'mp4',
        'title': 'Dompap og andre fugler i Piip-Show',
        'description': 'md5:d9261ba34c43b61c812cb6b0269a5c8f',
        'duration': 262,
    }

    nrk_ie = NRKIE()

# Generated at 2022-06-22 08:11:45.419221
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    _ = NRKTVSerieBaseIE.ie_key()
    _ = NRKTVSerieBaseIE._call_api('test/test')
    _ = NRKTVSerieBaseIE._extract_entries([])
    _ = NRKTVSerieBaseIE._extract_assets_key({'_embedded': {}})
    _ = NRKTVSerieBaseIE._catalog_name('serie')
    _ = NRKTVSerieBaseIE._entries({'_embedded': {'test': {}}}, 'test')



# Generated at 2022-06-22 08:11:47.395123
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        assert issubclass(NRKPlaylistBaseIE, InfoExtractor)
    except AssertionError as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-22 08:11:48.699471
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert(NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/fasit/sesong/1') == False)


# Generated at 2022-06-22 08:13:07.269476
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """ Test case for NRKPlaylistBaseIE constructor """
    NRKPlaylistBaseIE('NRKPlaylistBaseIE', True, 'NRK')


# Generated at 2022-06-22 08:13:16.993628
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert nrktvie._TESTS[0]['url'] == 'https://tv.nrk.no/program/MDDP12000117'
    assert nrktvie._TESTS[0]['md5'] == 'c4a5960f1b00b40d47db65c1064e0ab1'
    assert nrktvie._TESTS[0]['info_dict']['id'] == 'MDDP12000117'
    assert nrktvie._TES

# Generated at 2022-06-22 08:13:27.977670
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Exercise basic functionality of constructor of class NRKBaseIE
    ie = NRKBaseIE()
    ie._valid_url('http://tv.nrk.no/program/bla1234', 'NrkTv')
    ie._valid_url('http://radio.nrk.no/serie/bla1234', 'NrkRadio')
    ie._valid_url('http://radio.nrk.no/bla1234', 'NrkRadio')
    # Test extraction of URL with '?_=_' in path.
    # The path is not really used in NRKBaseIE so
    # we check only that the URL is handled properly.
    ie._valid_url('http://radio.nrk.no/serie/dokumentar/bla?_=_', 'NrkRadio')
    ie._

# Generated at 2022-06-22 08:13:35.396770
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    class TestInfoExtractor(NRKBaseIE):
        _VALID_URL = r'https?://nrk\.no/id/'

        IE_NAME = 'NRKBaseIE'
        IE_DESC = 'NRKBaseIE'

        _TESTS = [{
            'url': 'https://nrk.no/id/',
            'ok': True,
        }]
    return TestInfoExtractor

# Generated at 2022-06-22 08:13:45.043372
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    class TestIE(NRKBaseIE):
        IE_NAME = 'test'

    t = TestIE()
    assert t._GEO_COUNTRIES[0] == 'NO'
    assert t._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
    # _extract_nrk_formats

# Generated at 2022-06-22 08:13:48.715936
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert isinstance(ie, NRKTVIE)

# Generated at 2022-06-22 08:13:52.797442
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        NRKTVSeasonIE('test', '1', 1)
    except Exception as e:
        assert False, 'NRKTVSeasonIE constructor should not throw any exceptions'



# Generated at 2022-06-22 08:13:53.443405
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()

# Generated at 2022-06-22 08:13:58.622148
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    class_ = type(
        'test_NRKTVSeriesIE', (NRKTVSeriesIE,),
        {'_VALID_URL': r'(?P<url>(?P<domain>%s)://(?P<serie_kind>%s)\.nrk\.no/(?P<id>[^/]+)' % (
            '|'.join((NRKTVSeriesIE._DOMAINS)), '|'.join(('serie', 'pod[ck]ast')))})
    test_url = 'https://tv.nrk.no/serie/backstage'
    result = class_._match_id(test_url)
    ie = class_._extract(test_url)

# Generated at 2022-06-22 08:14:05.836882
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    from .nrktv import NRKPlaylistIE
    playlist = NRKPlaylistIE()
    assert playlist._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert playlist._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-22 08:16:43.881572
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert isinstance(NRKPlaylistBaseIE(), InfoExtractor)


# Generated at 2022-06-22 08:16:54.536798
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # A test to check that the NRKIE function is
    # able to access the NRK server and extract video information.
    nrk_ie = NRKIE()
    assert nrk_ie._call_api('mediaelement/ecc1b952-96dc-4a98-81b9-5296dc7a98d9', 'ecc1b952-96dc-4a98-81b9-5296dc7a98d9', 'playback/manifest').get('playability') == "playable"
    # This test is not stable as the info may change

# Generated at 2022-06-22 08:16:59.840163
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.suitable('') == False
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1') == True
    assert NRKTVDirekteIE.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus') == True
    assert NRKTVDirekteIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers') == False


# Generated at 2022-06-22 08:17:01.927458
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Test NRKPlaylistBaseIE._extract_description
    assert NRKPlaylistBaseIE._extract_description("test_test") == None


# Generated at 2022-06-22 08:17:03.622694
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie


# Generated at 2022-06-22 08:17:13.141363
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert (NRKTVSeriesIE(NRKTVSeriesIE.ie_key(), {'serie_kind': 'serie', 'id': 'test_id'}).
            _call_api('tv/catalog/series/test_id', 'test_id', 'serie', query={'pageSize': 50})
            == 'tv/catalog/series/test_id?pageSize=50')
    assert (NRKTVSeriesIE(NRKTVSeriesIE.ie_key(), {'serie_kind': 'podkast', 'id': 'test_id'}).
            _call_api('tv/catalog/podcast/test_id', 'test_id', 'serie', query={'pageSize': 50})
            == 'tv/catalog/podcast/test_id?pageSize=50')

# Generated at 2022-06-22 08:17:14.580571
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()

# Generated at 2022-06-22 08:17:16.852840
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert(NRKTVEpisodesIE("NRKTVEpisodesIE", "tv.nrk.no", "69031") is not None)


# Generated at 2022-06-22 08:17:18.846756
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_desc()

# Generated at 2022-06-22 08:17:22.950013
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # i.e. NRKTVIE() is an instance of InfoExtractor object
    assert isinstance(NRKTVIE(), InfoExtractor)