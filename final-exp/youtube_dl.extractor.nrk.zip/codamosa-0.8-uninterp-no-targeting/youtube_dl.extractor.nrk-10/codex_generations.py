

# Generated at 2022-06-22 08:08:59.705472
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE(None, None)



# Generated at 2022-06-22 08:09:10.717876
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-22 08:09:14.776524
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie._VALID_URL == NRKIE._VALID_URL
    assert ie.IE_DESC == 'nrk.no, NRK TV, NRK Radio, and NRK Super'
    assert ie._GEO_COUNTRIES == NRKIE._GEO_COUNTRIES
    assert ie._CDN_REPL_REGEX == NRKIE._CDN_REPL_REGEX



# Generated at 2022-06-22 08:09:17.295507
# Unit test for constructor of class NRKIE
def test_NRKIE():
    obj = NRKIE()
    assert obj.IE_NAME == "nrk"


# Generated at 2022-06-22 08:09:23.266288
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    result = ie._real_extract(url='http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449', video_id='rivertonprisen-til-karin-fossum-1.12266449')
    assert result['id'] == 'rivertonprisen-til-karin-fossum-1.12266449'
    assert result['title'] == 'Rivertonprisen til Karin Fossum'
    assert result['description'] == 'Første kvinne på 15 år til å vinne krimlitteraturprisen.'
    assert len(result['entries']) == 2


# Generated at 2022-06-22 08:09:27.803469
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    m = NRKTVSerieBaseIE()
    assert m._extract_entries([{}, {'prfId': 'prfid'}]) == [
        {'_type': 'url',
         'id': 'prfid',
         'ie_key': 'NRK',
         'url': 'nrk:prfid',
         'video_id': 'prfid'}]

# Generated at 2022-06-22 08:09:32.010970
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    extractor = NRKTVSeasonIE()
    extractor.suitable(url)
    extractor.extract(url)


# Generated at 2022-06-22 08:09:36.666515
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-22 08:09:38.682078
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert len(NRKTVSeriesIE._TESTS) == 13


# Generated at 2022-06-22 08:09:46.405424
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE(): # pylint: disable=unused-variable
    # Test an empty playlist item
    playlist_item = {}
    assert NRKPlaylistBaseIE._extract_playlist_item(playlist_item) == {}

    # Test a non-empty playlist item
    from .nrktv import NRKTVIE
    from .nrktv import NRKTVSerieBaseIE

# Generated at 2022-06-22 08:10:50.871781
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert_raises(TypeError, NRKTVSerieBaseIE)



# Generated at 2022-06-22 08:11:01.062635
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    x = NRKTVSeriesIE(NRKTVSeriesIE.suitable('http://tv.nrk.no/serie/blank'), {})
    assert x is not None
    assert getattr(x, '_VALID_URL') == r'https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)'

# Generated at 2022-06-22 08:11:11.576119
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    webpage = "http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763"
    playlist_id = "gjenopplev-den-historiske-solformorkelsen-1.12270763"
    object1 = NRKPlaylistIE(NRKPlaylistIE._VALID_URL, NRKPlaylistIE._ITEM_RE, NRKPlaylistIE,None)
    playlist_title = 'Gjenopplev den historiske solformørkelsen'
    playlist_description = 'md5:c2df8ea3bac5654a26fc2834a542feed'

# Generated at 2022-06-22 08:11:12.847491
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ex1 = NRKTVDirekteIE()
    assert ex1.ie_key() == 'NRKTVDirekte'



# Generated at 2022-06-22 08:11:17.082028
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    skip_if_no_network()
    url = 'https://tv.nrk.no/direkte/nrk1'
    NRKTVDirekteIE(url)


# Generated at 2022-06-22 08:11:24.227168
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    """
    Unit test for constructor of class NRKRadioPodkastIE
    """
    my_ie = NRKRadioPodkastIE(NRKRadioPodkastIE.ie_key())
    assert my_ie

    my_ie = NRKRadioPodkastIE(NRKRadioPodkastIE.ie_key(), age_limit=18)
    assert my_ie


# Generated at 2022-06-22 08:11:27.986540
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekte_ie = NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')
    assert nrktvdirekte_ie.media_type == 'live'
    assert nrktvdirekte_ie.player_key == 'nrk:live:1'

# Generated at 2022-06-22 08:11:39.086571
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert isinstance(NRKPlaylistBaseIE, type)
    ie = NRKPlaylistBaseIE()
    # Test for properties of the object NRKPlaylistBaseIE
    assert ie.ie_key() == 'NRKPlaylistBase'
    assert ie.ie_desc() == 'NRK Playlist Base'
    assert ie.search_title == None
    assert ie.search_description == None
    assert ie.search_keywords == None
    assert ie.search_thumbnail == None
    assert ie.search_uploader == None
    assert ie.search_license == None

# Test for properties of the object NRKPlaylistBaseIE

# Generated at 2022-06-22 08:11:46.602871
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    url = 'https://nrk.no/'
    playlist_id = 'MIPL'
    display_id = 'NRK-TV_Sjakk_VM_2018'
    playlist_title = 'Sjakk VM 2018'

    serie_kind = 'podcast'
    playlist_url = 'https://tv.nrk.no/serie/sjakk-vm-2018/'
    info = NRKTVSerieBaseIE._build_nested_url(
        playlist_id, display_id, playlist_title, serie_kind)
    assert info.get('url') == 'https://api.nrk.no/v2/catalogs/podcast/series/%s?limit=0' % playlist_id
    assert info.get('display_id') == display_id

# Generated at 2022-06-22 08:11:50.843954
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('test_url')
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == '://((?:nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|nrk-od-no\\.telenorcdn\\.net|minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no)/)'
    assert ie._extract_m3u8_formats is not None

# Generated at 2022-06-22 08:13:56.163329
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    tester = NRKTVSeasonIE()
    tester.suitable(NRKTVSeasonIE._TESTS[0]['url']) == False

# Generated at 2022-06-22 08:14:00.796001
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE("")
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''

# Generated at 2022-06-22 08:14:04.859609
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    for url, expected_ie in [('https://tv.nrk.no/serie/naturligvis', NRKTVSerieIE),
                             ('https://tv.nrk.no/serie/julekalendere', NRKTVPlaylistIE),
                             ('https://tv.nrk.no/program/', None),
                             ('https://tv.nrk.no/', None),
                             ('https://tv.nrk.no/', NRKIE)]:
        ie = NRKTVSerieBaseIE._get_nrktv_ie(url)
        assert isinstance(ie, expected_ie), (ie, expected_ie)



# Generated at 2022-06-22 08:14:07.977595
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('www.nrk.no')
    assert ie.getName() == 'nrk.no'
    assert ie.getId() == 'nrk.no'


# Generated at 2022-06-22 08:14:17.214670
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://nrk.no/tv') == False
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/program/nh00b00490100059') == False
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank') == True
    assert NRKTVSeriesIE.suitable('https://nrksuper.no/program/nh00b00490100059') == False
    assert NRKTVSeriesIE.suitable('https://tv.nrksuper.no/serie/trollz') == True
    assert NRKTVSeriesIE.suitable('https://radio.nrk.no/program/nh00b00490100059') == False

# Generated at 2022-06-22 08:14:21.425955
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    # Valid URL
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % ie._EPISODE_RE
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/program/MDDP12000117'
    # Invalid URL
    assert ie._VALID_URL != r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % "MDDP12000118"
    assert ie._TESTS[0]['url'] != 'https://tv.nrk.no/program/MDDP12000118'

# Generated at 2022-06-22 08:14:23.369672
# Unit test for constructor of class NRKIE
def test_NRKIE():
    info_extractor = NRKIE()
    info = info_extractor._real_extract(
        "nrk:nrk1")
    assert info['id'] == 'nrk1'
    assert info['title'] == 'NRK 1 Direkte'
    assert info['formats'] == []

# Generated at 2022-06-22 08:14:32.917326
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk_base = NRKBaseIE()
    assert nrk_base is not None
    assert nrk_base._GEO_COUNTRIES == ['NO']
    assert nrk_base._CDN_REPL_REGEX == r'://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'


# Generated at 2022-06-22 08:14:37.340599
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    test_NRKRadioPodkastIE = NRKRadioPodkastIE()
    assert test_NRKRadioPodkastIE._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    test_NRKRadioPodkastIE.IE_DESC = 'NRK Radio Podkast'


# Generated at 2022-06-22 08:14:39.405006
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE(NRKIE._create_geturl())
    assert ie.IE_NAME == 'nrk.no'
    assert ie.IE_DESC == 'NRK'
    assert ie._VALID_URL == NRKIE._VALID_URL
