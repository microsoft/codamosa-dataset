

# Generated at 2022-06-22 08:09:13.758648
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://radio.nrk.no/serie/dagsnytt/sesong/201509'
    # NRKTVSeasonIE is not suitable for NRKTVIE, NRKTVEpisodeIE and NRKRadioPodkastIE
    assert not NRKTVSeasonIE.suitable(NRKTVIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKTVEpisodeIE._VALID_URL)
    assert not NRKTVSeasonIE.suitable(NRKRadioPodkastIE._VALID_URL)
    # NRKTVSeasonIE should be suitable for URL 'https://radio.nrk.no/serie/dagsnytt/sesong/201509'
    assert NRKTVSeasonIE.suitable(url)
    # Test constructor

# Generated at 2022-06-22 08:09:25.780281
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    inst = NRKTVDirekteIE()
    assert inst.IE_NAME == 'nrk'
    assert inst.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert inst._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert inst._TESTS[0]['url'] == 'https://tv.nrk.no/direkte/nrk1'
    assert inst._TESTS[0]['only_matching'] == True
    assert inst._TESTS[1]['url'] == 'https://radio.nrk.no/direkte/p1_oslo_akershus'

# Generated at 2022-06-22 08:09:26.693503
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()



# Generated at 2022-06-22 08:09:27.483339
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE(None, None)


# Generated at 2022-06-22 08:09:33.397437
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://radio.nrk.no/serie/dagsnytt/sesong/201507'
    instance = NRKTVSeasonIE(url)
    assert instance.url == url
    assert instance.display_id == 'dagsnytt/201507'
    assert instance.ie_key == 'NRKTVSeason'



# Generated at 2022-06-22 08:09:37.846199
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    i = NRKPlaylistIE()
    i.urls = [test_url]
    i.init()
    assert i.extract() is not None


# Generated at 2022-06-22 08:09:45.319333
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE(None, url)
    assert ie._match_id(url) == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'



# Generated at 2022-06-22 08:09:47.252945
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    obj = NRKTVSerieBaseIE()
    assert obj._ASSETS_KEYS == ('episodes', 'instalments',)


# Generated at 2022-06-22 08:09:49.343146
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    try:
        class_object=NRKRadioPodkastIE()
        return True
    except:
        return False


# Generated at 2022-06-22 08:10:00.255716
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    BaseIE = type('BaseIE', (NRKBaseIE,), {})
    assert BaseIE._GEO_COUNTRIES == ['NO']
    assert BaseIE._CDN_REPL_REGEX == (r'(?x)://'
        r'(?:'
            r'nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|'
            r'nrk-od-no\.telenorcdn\.net|'
            r'minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no'
        r')/')



# Generated at 2022-06-22 08:11:06.596514
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    """Test creation of class instance."""
    info_extractor = NRKBaseIE(None)



# Generated at 2022-06-22 08:11:17.600792
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-22 08:11:22.383278
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Constructor of class NRKPlaylistBaseIE should raise an
    # AttributeError because the _ITEM_RE class variable is not defined.
    # Saving the original value of the variable
    item_re = NRKPlaylistBaseIE._ITEM_RE

    # Undefining the variable
    del NRKPlaylistBaseIE._ITEM_RE

    # Testing constructor
    with pytest.raises(AttributeError, match=r'Missing class variable \'_ITEM_RE\''):
        NRKPlaylistBaseIE()

    # Restoring the variable
    NRKPlaylistBaseIE._ITEM_RE = item_re



# Generated at 2022-06-22 08:11:28.280688
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    def _call_create_ie(url):
        return NRKPlaylistIE.create_ie(url)
    assert hasattr(_call_create_ie, 'used_for')
    assert type(_call_create_ie.used_for) == list
    assert urlparse(_call_create_ie.used_for[0]).netloc == 'nrk.no'


# Generated at 2022-06-22 08:11:40.357412
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('test_nrk_base')
    assert ie.IE_NAME == 'test_nrk_base'
    assert ie._GEO_COUNTRIES == ['NO']
    assert 'nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0' in ie._CDN_REPL_REGEX
    assert 'nrk-od-no\.telenorcdn\.net' in ie._CDN_REPL_REGEX
    assert 'minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no' in ie._CDN_REPL_REGEX


# Generated at 2022-06-22 08:11:41.438469
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE in globals().values()

# Generated at 2022-06-22 08:11:42.546916
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE('NRK', 'ie key')



# Generated at 2022-06-22 08:11:47.365500
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """Test whether running constructor raises exception.

    It should not raise an exception. To test it, a dummy url is
    provided.
    """
    url_for_testing = 'https://tv.nrk.no/serie/backstage/sesong/1'
    np = NRKTVSeasonIE(NRKTVSeasonIE.suitable, url_for_testing)
    assert np.url == url_for_testing

    # This method is a no-op and just returns the instance.
    np.initialize()
    assert np.url == url_for_testing



# Generated at 2022-06-22 08:11:48.384503
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Create object for class NRKSkoleIE
    nrk = NRKSkoleIE();


# Generated at 2022-06-22 08:11:52.168044
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE('NRK.no', None, {})


# Generated at 2022-06-22 08:13:09.378195
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """
    Constructing the class should not raise any exceptions.
    """
    NRKTVSeriesIE()


# Generated at 2022-06-22 08:13:19.383186
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .nrktv import (
        NRKTVDirekteIE,
        NRKTVIE,
        NRKTVEpisodeIE,
        NRKTVSeriesIE,
        NRKTVSeasonIE,
        NRKRadioPodkastIE,
        NRKIE,
    )
    ie = NRKTVDirekteIE()

    assert ie.suitable('https://tv.nrk.no/direkte/nrk1')
    assert ie.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not ie.suitable('https://tv.nrk.no/serie/blah')
    assert not ie.suitable('https://tv.nrk.no/serie/blah/sesong/1/episode/1')
   

# Generated at 2022-06-22 08:13:23.092808
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrkradiopodkastIE = NRKRadioPodkastIE()
    assert isinstance(nrkradiopodkastIE, NRKBaseIE), "unit test error"



# Generated at 2022-06-22 08:13:34.383582
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktv_serie_base_ie = NRKTVSerieBaseIE()
    assert nrktv_serie_base_ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert nrktv_serie_base_ie._catalog_name('podcast') == 'podcast'
    assert nrktv_serie_base_ie._catalog_name('podkast') == 'podcast'
    assert nrktv_serie_base_ie._catalog_name('series') == 'series'
    assert nrktv_serie_base_ie._catalog_name('serie') == 'series'
    assert nrktv_serie_base_ie._catalog_name('audio') == 'series'
    assert nrktv_serie_base_ie

# Generated at 2022-06-22 08:13:44.191339
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrkbaseIE = NRKBaseIE()
    # Format of NRK m3u8 urls
    assert re.match(nrkbaseIE._CDN_REPL_REGEX, "//nrkod01-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/")
    assert re.match(nrkbaseIE._CDN_REPL_REGEX, "//nrk-od-no.telenorcdn.net/")
    assert re.match(nrkbaseIE._CDN_REPL_REGEX, "//minicdn-od.nrk.no/od/nrkhd-osl-rr.netwerk.no/no/")

# Generated at 2022-06-22 08:13:51.870685
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    if not hasattr(NRKPlaylistBaseIE, 'suitable'):
        return
    if not hasattr(NRKPlaylistBaseIE, '_extract_description'):
        return
    if not hasattr(NRKPlaylistBaseIE, '_real_extract'):
        return
    if not hasattr(NRKPlaylistBaseIE, '_ITEM_RE'):
        return
    try: NRKPlaylistBaseIE()
    except Exception: pass



# Generated at 2022-06-22 08:13:56.763085
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    """Unit test for constructor of class NRKPlaylistIE"""
    ie = NRKPlaylistIE()

    url = "http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763"

    # Check if extracting playlist_id from the url works
    expected_playlist_id = "gjenopplev-den-historiske-solformorkelsen-1.12270763"
    assert ie._match_id(url) == expected_playlist_id

    # Check if object is correct instanciated
    assert isinstance(ie, NRKPlaylistIE) is True
    assert isinstance(ie, InfoExtractor) is True


# Generated at 2022-06-22 08:14:01.533416
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    serie_kind = 'serie'
    season_id = '1'
    domain = 'https://tv.nrk.no'
    display_id = 'hele_historien/diagnose-kverulant'
    url = 'https://radio.nrk.no/serie/hele_historien/sesong/diagnose-kverulant'

# Generated at 2022-06-22 08:14:03.080266
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    unit_test_run(NRKTVDirekteIE)


# Generated at 2022-06-22 08:14:05.920957
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Using https://www.nrk.no/skole/?page=search&q=&mediaId=14099 in assert_raises
    with pytest.raises(ValueError, match=r"Cannot determine the NRK ID.*"):
        NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
# End of unit test for constructor of class NRKSkoleIE

# Generated at 2022-06-22 08:16:13.135478
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk_tv_direkte_ie = NRKTVDirekteIE()
    assert nrk_tv_direkte_ie.IE_NAME == 'NRKTVDirekteIE'



# Generated at 2022-06-22 08:16:17.721997
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from six import assertRaisesRegex
    from .nrktvie import NRKTVIE
    from .nrktvepisodeie import NRKTVEpisodeIE
    from .nrkradiopodkastie import NRKRadioPodkastIE
    ne = NRKTVSeasonIE()


# Generated at 2022-06-22 08:16:26.150973
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    class MockInfoExtractor(NRKBaseIE):
        IE_NAME = 'nrk'
    test_extractor = MockInfoExtractor()
    assert test_extractor._GEO_COUNTRIES == ['NO']
    assert test_extractor._CDN_REPL_REGEX == r'(?x)://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'


# Generated at 2022-06-22 08:16:32.306209
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    info = {}
    ie = NRKTVDirekteIE()
    assert ie.suitable(url)
    info = ie.extract(url)
    assert info is not None and '_type' in info and info['_type'] == 'url' and 'url' in info and info['url'] == 'nrk:nrk1'



# Generated at 2022-06-22 08:16:37.687673
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from inspect import getsource

    source = getsource(NRKTVIE).strip()
    assert source.startswith('class NRKTVIE')
    assert source.endswith("('NRK TV and NRK Radio', {})")

# Generated at 2022-06-22 08:16:40.766091
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''


# Generated at 2022-06-22 08:16:43.794815
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
        """
        Unit test to check construction of NRKTVEpisodesIE.
        """
        url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
        NRKTVEpisodesIE(NRKTVEpisodesIE.suitable(url))


# Generated at 2022-06-22 08:16:46.496537
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE == NRKPlaylistBaseIE.suitable_for_url('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')

# Generated at 2022-06-22 08:16:47.425930
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    event = NRKRadioPodkastIE()

    assert event is not None


# Generated at 2022-06-22 08:16:51.723383
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(FakeYDL(), {'serie_id': 'bob', 'serie_kind': 'tv'})
    assert (type(ie) is NRKTVSerieBaseIE)
    for serie_kind in ('tv', 'radio',):
        ie = NRKTVSerieBaseIE(FakeYDL(), {'serie_id': 'bob', 'serie_kind': serie_kind})
        assert ie._catalog_name(serie_kind) == 'series'

    for serie_kind in ('podcast', 'podkast',):
        ie = NRKTVSerieBaseIE(FakeYDL(), {'serie_id': 'bob', 'serie_kind': serie_kind})
        assert ie._catalog_name(serie_kind) == 'podcast'