

# Generated at 2022-06-22 08:08:59.482754
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE()


# Generated at 2022-06-22 08:09:07.660607
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = NRKPlaylistBaseIE._VALID_URL % 'ulrikkes_univers_sesong2'
    info = NRKPlaylistBaseIE()._real_extract(url)
    assert info['_type'] == 'playlist'
    assert info['id'] == 'ulrikkes_univers_sesong2'
    assert info['title'] == 'Ulrikkes univers'

# Generated at 2022-06-22 08:09:17.918504
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert issubclass(NRKTVSerieBaseIE, NRKBaseIE)
    assert not issubclass(NRKTVSerieBaseIE, InfoExtractor)
    assert NRKTVSerieBaseIE._catalog_name('radio') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    return



# Generated at 2022-06-22 08:09:25.468407
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    nrkbase_ie_attributes = [
        ("_GEO_COUNTRIES", ['NO']),
        ("_CDN_REPL_REGEX", r'(?:bw_(?:low|high)=\d+|no_audio_only)&?'),
    ]
    for key, value in nrkbase_ie_attributes:
        assert getattr(ie, key) == value



# Generated at 2022-06-22 08:09:27.003964
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'    


# Generated at 2022-06-22 08:09:35.546916
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE(None)._GEO_COUNTRIES == ['NO']
    assert NRKBaseIE(None)._CDN_REPL_REGEX == '://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-22 08:09:41.924190
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    inst = NRKBaseIE()
    assert inst._GEO_COUNTRIES == ['NO']
    assert inst._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-22 08:09:49.608001
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .utils import _fake_decrypt
    from .nrk import _decrypt_url

    # Test code from NRKTVIE
    def _download_json(self, url_or_request, tv_id, *args, **kwargs):
        def _upin_downin(query):
            upin = query.get('up')
            downin = query.get('down')
            if upin:
                query['up'] = 'in'
            if downin:
                query['down'] = 'in'
            return query
        return self._download_webpage(
            fix_url(url_or_request, _upin_downin),
            tv_id, *args, **kwargs)

    # Test code from NRKTVEpisodeIE

# Generated at 2022-06-22 08:09:52.362750
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    item = NRKPlaylistBaseIE()
    assert "NRKPlaylistBaseIE" == item.IE_NAME

# Generated at 2022-06-22 08:09:58.590848
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    t = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert t.url == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert t.id == '69031'
    assert t.ie_key() == 'NRKTVEpisodesIE'

# Generated at 2022-06-22 08:11:10.189776
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    obj = NRKPlaylistIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert obj._ITEM_RE == 'class="[^"]*\\brich\\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-22 08:11:15.555543
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Tests error messages when mediaIds are not passed
    doc = lxml.html.document_fromstring('<html><head><title>NRK Skole</title></head><body></body></html>')
    assert NRKSkoleIE._extract_urls(doc) == []



# Generated at 2022-06-22 08:11:16.847422
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()


# Generated at 2022-06-22 08:11:22.560246
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-22 08:11:33.248991
# Unit test for constructor of class NRKTVIE

# Generated at 2022-06-22 08:11:40.013839
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    catalog_url = 'http://www.nrk.no/video/api/catalog/%s'
    for serie_kind in ('show', 'tv-series', 'podcast', 'podkast'):
        catalog_name = NRKTVSerieBaseIE._catalog_name(serie_kind)
        assert catalog_url % catalog_name == NRKTVSerieBaseIE._CATALOG_URL % serie_kind



# Generated at 2022-06-22 08:11:46.303844
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    """
    Unit test for constructor of class NRKSkoleIE
    """
    nrkskoler = NRKSkoleIE()
    nrkskoler.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    nrkskoler._real_extract('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')


# Generated at 2022-06-22 08:11:51.487763
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    assert NRKTVSeasonIE.suitable(url)
    season = NRKTVSeasonIE(
        'https://tv.nrk.no/serie/backstage/sesong/1')
    assert season._VALID_URL == 'https?://(?P<domain>tv|radio)\\.nrk\\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<serie>[^/]+)/(?:(?:sesong/)?(?P<id>\\d+)|sesong/(?P<id_2>[^/?#&]+))'

# Generated at 2022-06-22 08:11:53.309098
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE().suitable('foo') == False

# Generated at 2022-06-22 08:12:01.335234
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    for test in NRKTVEpisodeIE._TESTS:
        url = test['url']
        ep = NRKTVEpisodeIE(url)
        assert ep.VALID_URL == url

# Generated at 2022-06-22 08:14:22.665073
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    instance = NRKTVSeasonIE('https://tv.nrk.no/serie/backstage/sesong/1')
    assert instance.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert instance.suitable('https://tv.nrk.no/serie/lindmo/2016')
    assert instance.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')
    assert not instance.suitable('https://tv.nrk.no/program/mdap01000816')
    assert not instance.suitable('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#')

# Generated at 2022-06-22 08:14:24.098980
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrk_episodesIE = NRKTVEpisodesIE()
    assert nrk_episodesIE.ie_key() == 'NRKTVEpisodes'


# Generated at 2022-06-22 08:14:27.477564
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(None, None)
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)



# Generated at 2022-06-22 08:14:34.275835
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    from .nrk import NRKPlaylistBaseIE
    nrk = NRKPlaylistBaseIE(NRKPlaylistBaseIE.ie_key(), '--1xx1--')
    assert nrk.IE_KEY == 'NRKPlaylistBase'
    assert nrk.ENTRY_URL_TEMPLATE == 'nrk:%s'
    assert nrk._ITEM_RE == ''
    assert nrk.ie_key() == 'NRKPlaylistBase'


# Generated at 2022-06-22 08:14:43.468736
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert_equal(ie.IE_NAME, 'nrk:playlist')
    assert_equal(ie.IE_DESC, 'NRK Playlists')
    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)')
    assert_equal(ie._ITEM_RE, r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"')
    assert_equal(ie.ie_key(), 'NrkPlaylist')

# Generated at 2022-06-22 08:14:44.503160
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()



# Generated at 2022-06-22 08:14:45.603706
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-22 08:14:49.675467
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        NRKTVSeriesIE('NRKTVSeriesIE', 'NRKTVSeriesIE')
        assert False
    except AssertionError:
        assert True



# Generated at 2022-06-22 08:15:02.525822
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-22 08:15:03.912037
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie is not None
