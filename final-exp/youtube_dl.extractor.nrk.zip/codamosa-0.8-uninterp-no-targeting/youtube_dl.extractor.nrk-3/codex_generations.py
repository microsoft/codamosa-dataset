

# Generated at 2022-06-22 08:08:58.948757
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    x = NRKTVDirekteIE()
    x.real_initialize()
    assert x.api_calls == {}



# Generated at 2022-06-22 08:09:09.872279
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    import os
    import yaml
    with open(os.path.join(os.path.dirname(__file__), 'fixtures', 'episodes.yml'), 'r') as episodes_file:
        episodes = yaml.load(episodes_file)
        for episode in episodes:
            ie = NRKTVEpisodesIE(episode['url'])
            webpage = ie._download_webpage(episode['url'], episode['id'])
            entries = ie._extract_entries(webpage)
            assert len(entries) == len(episode['entries'])
            for entry, expected_entry in zip(entries, episode['entries']):
                assert entry['id'] == expected_entry['id']

# Generated at 2022-06-22 08:09:12.480709
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE(None)

# Unit tests for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-22 08:09:15.257107
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from .nrktv import NRKTVSeasonIE
    assert NRKTVSeasonIE.__doc__
    instance = NRKTVSeasonIE(NRKTVSeasonIE.ie_key())
    assert isinstance(instance, InfoExtractor)



# Generated at 2022-06-22 08:09:17.402777
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE._TESTS[0]['info_dict']

# Generated at 2022-06-22 08:09:21.576779
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    nrk_skole_ie._real_extract('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')

# Generated at 2022-06-22 08:09:31.584378
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from youtube_dl.compat import compat_SIMPLEJSON as json
    # We only test the constructor of this class

# Generated at 2022-06-22 08:09:34.417751
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    skoleIE = NRKSkoleIE()
    assert skoleIE.IE_DESC == 'NRK Skole'


# Generated at 2022-06-22 08:09:36.465937
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE(None)._VALID_URL == NRKSkoleIE._VALID_URL

# Generated at 2022-06-22 08:09:47.584720
# Unit test for constructor of class NRKTVEpisodesIE

# Generated at 2022-06-22 08:10:47.391378
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ifr = NRKIE()
    return ifr

# Generated at 2022-06-22 08:10:50.860974
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktvepisodesie = NRKTVEpisodesIE()

# Generated at 2022-06-22 08:10:53.753245
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    """Unit test for constructor of class NRKTVSereBaseIE"""
    ie = NRKTVSerieBaseIE(object(), 'NRK TV Series Base')
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name('series') == 'series'
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podkast') == 'podcast'



# Generated at 2022-06-22 08:10:55.302539
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # If NRKTVEpisodeIE is changed, this test might need to be changed as well
    assert NRKTVEpisodeIE._TESTS[0]['info_dict']['id'] == 'MUHH36005220'



# Generated at 2022-06-22 08:11:01.300988
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'tv.nrk.no'
    path = 'program/MDDP12000117'
    episode_id = 'MDDP12000117'
    s = NRKTVIE(url, path, episode_id)
    assert s.url == 'https://tv.nrk.no/program/MDDP12000117'
    assert s.path == 'program/MDDP12000117'
    assert s.episode_id == 'MDDP12000117'


# Generated at 2022-06-22 08:11:09.141166
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from unittest import TestCase
    class TestNRKTVIE(TestCase):
        # This test case is for testing constructor, cannot be run by itself.
        def runTest(self):
            self.assertEqual(NRKTVIE._VALID_URL, r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})')

    return TestNRKTVIE()


# Generated at 2022-06-22 08:11:20.429391
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    video_id = 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

# Generated at 2022-06-22 08:11:31.076052
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie.IE_DESC == 'NRK Skole'


try:
    from .common import InfoExtractor
    from .nrk import NRKIE
    from .compat import compat_str
    from .utils import (
        get_element_by_attribute,
        try_get,
        urljoin,
        int_or_none,
    )
    from .aes import (
        aes_cbc_decrypt,
    )
except ImportError:
    from common import InfoExtractor
    from compat import compat_str
    from nrk import NRKIE

# Generated at 2022-06-22 08:11:33.602988
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    return NRKPlaylistIE('NRKPlaylistIE', {'id': 'test_id'}, 'test_inst')

# Generated at 2022-06-22 08:11:34.695685
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE()

# Generated at 2022-06-22 08:13:49.172957
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # This test is required to avoid unittest warning
    NRKSkoleIE(NRKSkoleIE.ie_key(), NRKSkoleIE._VALID_URL)



# Generated at 2022-06-22 08:14:00.720988
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    test_obj = NRKTVIE('NRKTVIE', 'nrk:serie/lindmo/2018/MUHU11006318/avspiller')
    assert test_obj._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert test_obj._EPISODE_RE == test_obj._VALID_URL.split('https?://')[1]
    assert test_obj._match_id('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#') == 'NPUB21019315'



# Generated at 2022-06-22 08:14:05.486019
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    for data in ({},):
        for page_num in (1,2):
            # Extract entries
            embedded = data.get('_embedded') or data
            if not isinstance(embedded, dict):
                break
            assets_key = NRKTVSerieBaseIE._extract_assets_key(embedded)
            if not assets_key:
                break
            entries = try_get(
                embedded,
                (lambda x: x[assets_key]['_embedded'][assets_key],
                 lambda x: x[assets_key]),
                list)
            for e in NRKTVSerieBaseIE._extract_entries(entries):
                yield e
            # Find next URL

# Generated at 2022-06-22 08:14:07.754194
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE('NRKTVIE')
    assert ie.ie_key() == 'nrk:nrktvie'



# Generated at 2022-06-22 08:14:16.846904
# Unit test for constructor of class NRKIE
def test_NRKIE():
    import unittest
    class NRKIETest(unittest.TestCase):
        def setUp(self):
            self.NRKIE = NRKIE()

        def test_NRKIE(self):
            self.assertTrue(self.NRKIE.IE_NAME == 'nrk')
            self.assertTrue(self.NRKIE.IE_DESC == 'NRK')
            self.assertTrue(self.NRKIE._VALID_URL == 'nrk:.*')
            self.assertTrue(self.NRKIE._GEO_COUNTRIES == ['NO'])
            self.assertTrue(self.NRKIE._NETRC_MACHINE == 'nrk')
    unittest.main(verbosity=2)


# Generated at 2022-06-22 08:14:27.160271
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/backstage')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/postmann-pat')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/saving-the-human-race')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    assert NRKTVSeriesIE.suitable('https://tv.nrksuper.no/serie/labyrint')
    assert NRKTVSeriesIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers')

# Generated at 2022-06-22 08:14:32.355751
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.__name__ is 'NRKTVSeriesIE'

    assert hasattr(NRKTVSeriesIE, '_VALID_URL')
    assert NRKTVSeriesIE._VALID_URL is not None

    assert hasattr(NRKTVSeriesIE, '_TESTS')
    assert NRKTVSeriesIE._TESTS is not None

    assert hasattr(NRKTVSeriesIE, 'suitable')
    assert callable(NRKTVSeriesIE.suitable)

    assert hasattr(NRKTVSeriesIE, '_real_extract')
    assert callable(NRKTVSeriesIE._real_extract)


# Generated at 2022-06-22 08:14:38.083125
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE('https://tv.nrk.no/serie/groenn-glede')
    assert(ie.domain == 'tv.nrk.no')
    assert(ie.serie_kind == 'serie')
    assert(ie.series_id == 'groenn-glede')
    assert(ie.display_id == 'groenn-glede')

    ie = NRKTVSeriesIE('https://nrksuper.no/serie/labyrint')
    assert(ie.domain == 'tv.nrksuper.no')
    assert(ie.serie_kind == 'serie')
    assert(ie.series_id == 'labyrint')
    assert(ie.display_id == 'labyrint')


# Generated at 2022-06-22 08:14:42.514587
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Test that we raise a RegexNotFoundError when we don't find matches.
    with pytest.raises(RegexNotFoundError):
        NRKSkoleIE._match_id("")
    # Test that we raise a RegexNotFoundError when we don't find matches.
    with pytest.raises(RegexNotFoundError):
        NRKSkoleIE._match_id("https://www.nrk.no/skole/?page=search&q=&mediaId=a")

    # Test that we return the correct matches.
    assert NRKSkoleIE._match_id("https://www.nrk.no/skole/?page=search&q=&mediaId=14099") == '14099'

# Generated at 2022-06-22 08:14:45.527068
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_obj = NRKBaseIE('test_NRKBaseIE')
    assert(isinstance(test_obj, NRKBaseIE))
    assert(isinstance(test_obj, InfoExtractor))
