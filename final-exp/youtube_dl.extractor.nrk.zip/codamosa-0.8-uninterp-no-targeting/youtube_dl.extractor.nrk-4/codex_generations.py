

# Generated at 2022-06-22 08:09:05.071351
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk_direkte_ie = NRKTVDirekteIE()
    assert nrk_direkte_ie.ie_key() == 'nrktvdirekte'
    assert nrk_direkte_ie.ie_desc == NRKTVDirekteIE.IE_DESC
    assert nrk_direkte_ie._VALID_URL == NRKTVDirekteIE._VALID_URL

# Generated at 2022-06-22 08:09:08.688064
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdir = NRKTVDirekteIE({})
    assert nrktvdir.ie_key() == 'NRKTVDirekte'


# Generated at 2022-06-22 08:09:18.303638
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-22 08:09:23.169370
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/spangas/sesong/1'
    obj = NRKTVSeasonIE().suitable(url)
    assert obj



# Generated at 2022-06-22 08:09:25.356257
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    IE = NRKTVEpisodesIE()
    # Confirm that the NRKTVEpisodesIE() constructor has properly set its
    # _VALID_URL attribute
    assert re.match(IE._VALID_URL, 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')


# Generated at 2022-06-22 08:09:29.182288
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    info_extractor = NRKPlaylistIE()
    assert isinstance(info_extractor, NRKPlaylistIE)
    assert isinstance(info_extractor, InfoExtractor)
    assert isinstance(info_extractor, NRKPlaylistBaseIE)



# Generated at 2022-06-22 08:09:36.063876
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie_NRKTVEpisodesIE = NRKTVEpisodesIE()
    assert ie_NRKTVEpisodesIE._TESTS[0] == {
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }



# Generated at 2022-06-22 08:09:38.667876
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()


# Generated at 2022-06-22 08:09:44.346006
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert(NRKTVSeasonIE.suitable(NRKTVSeasonIE._TESTS[0]['url']))
    assert(not NRKTVSeasonIE.suitable(NRKTVIE._TESTS[0]['url']))
    assert(not NRKTVSeasonIE.suitable(NRKTVEpisodeIE._TESTS[0]['url']))
    assert(not NRKTVSeasonIE.suitable(NRKRadioPodkastIE._TESTS[0]['url']))



# Generated at 2022-06-22 08:09:44.926175
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie

# Generated at 2022-06-22 08:10:38.634651
# Unit test for constructor of class NRKIE
def test_NRKIE():
    try:
        # Can we instantiate it?
        nrk = NRKIE()
    except Exception as e:
        assert False, 'Cannot instantiate, error: {}'.format(e)



# Generated at 2022-06-22 08:10:40.190199
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
  instanciated = NRKSkoleIE()


# Generated at 2022-06-22 08:10:52.054668
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-22 08:10:55.267200
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    instance = NRKTVDirekteIE()


# Generated at 2022-06-22 08:10:58.950815
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    NRKTVDirekteIE(NRKTVDirekteIE.suitable(url), url)


# Generated at 2022-06-22 08:11:00.471847
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == NRKIE._VALID_URL

# Generated at 2022-06-22 08:11:11.550661
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrk_series_ie = NRKTVSeriesIE()
    nrk_tv_ie = NRKTVIE()
    nrk_tv_episode_ie = NRKTVEpisodeIE()
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    nrk_tv_season_ie = NRKTVSeasonIE()


# Generated at 2022-06-22 08:11:22.856151
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # test an audio podcast episode
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/nrkno-poddkast-26588-134079-05042018030000'
    ie = NRKRadioPodkastIE(url)
    assert ie.video_id == 'NRKNO-PODDKAST-26588-134079'
    assert ie._MEDIA_TYPE == 'audio'
    assert ie.extractor_key == 'nrk:NRKNO-PODDKAST-26588-134079'

    # test a video podcast episode
    url = 'https://tv.nrk.no/serie/lindmo/sesong/2016/episode/8'
    ie = NRKRadioPodkastIE(url)

# Generated at 2022-06-22 08:11:23.846314
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrk = NRKTVIE()


# Generated at 2022-06-22 08:11:27.110588
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-22 08:12:37.793715
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    embedded = {
        'episodes': [
            {'prfId':'MUHH36000117'},
            {'prfId':'MUHH36000118'},
        ],
    }

    nrktv_serie_base = NRKTVSerieBaseIE()
    nrktv_serie_base._extract_assets_key(embedded)


# Generated at 2022-06-22 08:12:38.486626
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    constructor_test(NRKTVIE, 'NRKTVIE')


# Generated at 2022-06-22 08:12:42.887553
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test live stream URL
    url = "http://nrkno.brightspace.com/d2l/le/content/6539/viewContent/208412/View"
    play_list =  NRKPlaylistIE(NRKPlaylistIE()).url_result(url, 'nrk')
    assert play_list is not None

    url = "http://nrkno.brightspace.com/d2l/le/content/6539/viewContent/224552/View"
    play_list =  NRKPlaylistIE(NRKPlaylistIE()).url_result(url, 'nrk')
    assert play_list is not None

    # Test live stream URLs

# Generated at 2022-06-22 08:12:46.590181
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Unit test for constructor of class NRKIE
    try:
        ie = NRKIE() # Test the constructor
    except Exception as e:
        print(e)
        assert False
    assert True



# Generated at 2022-06-22 08:12:49.315100
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """Just a constructor test."""
    assert NRKPlaylistBaseIE(
        downloader=FakeYDL(),
        ie_key='NRKPlaylistBaseIE',
        ie_urls=['fake'])


# Generated at 2022-06-22 08:12:52.385390
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE.__init__(NRKTVSerieBaseIE, 'NRKTVSerieBaseIE')


# Generated at 2022-06-22 08:13:02.522589
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    info_extractor = NRKPlaylistBaseIE()
    assert info_extractor.suitable('http://tv.nrk.no/serie/a-want-to-be-a-millionaire') is False
    assert info_extractor.suitable('https://tv.nrk.no/serie/a-want-to-be-a-millionaire') is False
    assert info_extractor.suitable('http://tv.nrk.no/serie/a-want-to-be-a-millionaire/2016') is False
    assert info_extractor.suitable('http://www.nrk.no/nett-tv/kategori/dokumentar') is False



# Generated at 2022-06-22 08:13:06.096242
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    info_extractor = NRKBaseIE()
    assert NRKBaseIE.IE_NAME == 'NRK'
    assert info_extractor.IE_NAME == 'NRK'



# Generated at 2022-06-22 08:13:09.466883
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    test = NRKTVDirekteIE.Testcase()
    test.run_unittest()

# Generated at 2022-06-22 08:13:12.611286
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('nrk')
    assert ie._ENTRIES_PER_PAGE == 200
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podkast') == 'podcast'
    assert ie._catalog_name('not_podcast') == 'series'


# Generated at 2022-06-22 08:15:34.029808
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE("http://www.nrk.no/program/episodes/nytt-paa-nytt/69031")
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-22 08:15:35.609394
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():

    # test for constructor of class NRKTVDirekteIE
    assert NRKTVDirekteIE(NRKTVDirekteIE.ie_key())


NRKTVDirekteIE.ie_key()



# Generated at 2022-06-22 08:15:46.154018
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    def _test_NRKTVSeasonIE(url, serie, season_id):
        NRKTVSeasonIE._download_webpage(
            NRKTVSeasonIE(), url, display_id='%s/%s' % (serie, season_id))
    # Season with /sesong/ in path
    _test_NRKTVSeasonIE(
        'https://tv.nrk.no/serie/spangas/sesong/1',
        'spangas', '1')
    # Season without /sesong/ in path
    _test_NRKTVSeasonIE(
        'https://tv.nrk.no/serie/lindmo/2016',
        'lindmo', '2016')
    # Season with text in path

# Generated at 2022-06-22 08:15:54.389590
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    h = NRKTVSeasonIE()
    h.suitable('https://tv.nrk.no/serie/dicte/sesong/1/season')
    h.suitable('https://tv.nrk.no/serie/dicte/sesong/1')
    # NRKTVEpisodeIE is a subclass of NRKTVSeasonIE
    h.suitable('https://tv.nrk.no/serie/dicte/sesong/1/episode/1')



# Generated at 2022-06-22 08:15:58.592707
# Unit test for constructor of class NRKIE
def test_NRKIE():
    return NRKIE()._VALID_URL

# Generated at 2022-06-22 08:16:02.133005
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        NRKTVSeasonIE()
    except RuntimeError as e:
        assert e.args[0] == 'NRKTVSeasonIE needs subclassing for ' + \
            'NRKBaseIE._CATALOG_NAME_MAP to work'



# Generated at 2022-06-22 08:16:05.666173
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('nrk')
    assert ie._VALID_URL is None
    assert ie._downloader is None
    assert ie.ie_key() == 'NRKTVSerieBase'
    assert ie.server_url == NRKTVSerieBaseIE.server_url
    assert ie.base_url is None
    assert ie.http_headers == NRKTVSerieBaseIE.http_headers
    assert ie.api_key == NRKTVSerieBaseIE.api_key


# Generated at 2022-06-22 08:16:06.414425
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE('NRKTVEpisodes', 'tv.nrk.no')

# Generated at 2022-06-22 08:16:11.247696
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    def test_NRKTVSerieBaseIE_extract_assets_key_both(self):
        self.assertEquals(
            'episodes', self._extract_assets_key({'episodes': 'value1', 'instalments': 'value2'}))
    def test_NRKTVSerieBaseIE_extract_assets_key_episodes(self):
        self.assertEquals(
            'episodes', self._extract_assets_key({'episodes': 'value1'}))
    def test_NRKTVSerieBaseIE_extract_assets_key_instalments(self):
        self.assertEquals(
            'instalments', self._extract_assets_key({'instalments': 'value2'}))

# Generated at 2022-06-22 08:16:14.648980
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    obj = NRKPlaylistBaseIE()

# Test cases for NRKPlaylistBaseIE