

# Generated at 2022-06-22 08:09:05.352815
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert [ie.ie_key()
            for ie in gen_extractors()
            if isinstance(ie, NRKTVDirekteIE)] == [NRKTVDirekteIE.ie_key()]

    # Test constructor of class NRKTVDirekteIE
    test_object = NRKTVDirekteIE()
    assert test_object.ie_key() == NRKTVDirekteIE.ie_key()

# Test if extractor is added to the list of extractors

# Generated at 2022-06-22 08:09:09.535033
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE('url')
    assert ie.ie_key() == 'NrkTv'
    assert ie.ie_key() == 'NrkTv'


# Generated at 2022-06-22 08:09:19.846230
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_object = NRKPlaylistIE()
    assert 'http://www.nrk.no' in test_object._VALID_URL
    assert test_object._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763' in test_object._TESTS[0]['url']
    assert test_object._TESTS[0]['info_dict']['id'] == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'



# Generated at 2022-06-22 08:09:25.688421
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE("Test", "Test")
    ie.suitable("https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8")
test_NRKRadioPodkastIE()

# Generated at 2022-06-22 08:09:37.060594
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk_base_ie = NRKBaseIE('NRK')
    assert nrk_base_ie.IE_NAME == 'NRK'
    assert nrk_base_ie._GEO_COUNTRIES == ['NO']
    expected_cdn_regex = r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
    assert nrk_base_ie._CDN_REPL_REGEX == expected_cdn_re

# Generated at 2022-06-22 08:09:41.158227
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Test if showing error occures.
    # If error occures, it is expected to be shown in the message parameter
    # of API call.
    (NRKBaseIE._call_api)('', '', None, 'msg', True, None)

# Generated at 2022-06-22 08:09:45.998510
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie_ = NRKTVSeriesIE(NRKTVSeriesIE.ie_key())
    assert isinstance(ie_, NRKTVSeriesIE)
    ie_.suitable('https://tv.nrk.no/serie/backstage')
    ie_.suitable('https://radio.nrk.no/podkast/lørdagsrådet')

# Generated at 2022-06-22 08:09:49.358654
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8') == True


# Generated at 2022-06-22 08:09:56.982494
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    """
    Unit test for constructor of class NRKSkoleIE
    """
    skole_ie = NRKSkoleIE('http://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    assert isinstance(skole_ie, NRKSkoleIE), "Type of skole_ie is not class NRKSkoleIE"
    return skole_ie

# Generated at 2022-06-22 08:10:01.343530
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-22 08:11:09.017131
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # pylint: disable=W0212
    assert NRKBaseIE._extract_nrk_formats('', 'Test') is None

# Generated at 2022-06-22 08:11:12.332831
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE("NRKTVSerieBaseIE")
    except:
        print("Error: constructor of class NRKTVSerieBaseIE failed")


# Generated at 2022-06-22 08:11:23.208291
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    ie = NRKRadioPodkastIE(url)
    assert ie._VALID_URL == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}'

# Generated at 2022-06-22 08:11:29.262227
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie._extract_entries, functools.partial)
    assert isinstance(ie._extract_assets_key, functools.partial)
    assert isinstance(ie._catalog_name, functools.partial)
    assert isinstance(ie._entries, functools.partial)



# Generated at 2022-06-22 08:11:41.823563
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('NRKTVSeasonIE', 'https://tv.nrk.no/serie/backstage/sesong/1')
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?P<domain>tv|radio)\.nrk\.no/
                                    (?P<serie_kind>serie|pod[ck]ast)/
                                    (?P<serie>[^/]+)/
                                    (?:
                                        (?:sesong/)?(?P<id>\d+)|
                                        sesong/(?P<id_2>[^/?#&]+)
                                    )
                                '''
    assert ie.SUITABLE == False

# Generated at 2022-06-22 08:11:46.716557
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE(None)
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == '://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|://nrk-od-no\.telenorcdn\.net|://minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'

# Tests for _call_api

# Generated at 2022-06-22 08:11:48.457012
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    obj = NRKBaseIE()
    assert isinstance(obj, NRKBaseIE)


# Generated at 2022-06-22 08:11:58.843319
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert nrktvie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % nrktvie._EPISODE_RE
    assert nrktvie.IE_DESC == 'NRK TV and NRK Radio'



# Generated at 2022-06-22 08:12:02.195800
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NR = NRKIE()
    print('test_NRKIE OK!')

# Generated at 2022-06-22 08:12:10.491967
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL is None
    assert NRKTVSeasonIE.suitable is None
    assert NRKTVSeasonIE._extract_entries is None
    assert NRKTVSeasonIE._extract_assets_key is None
    assert NRKTVSeasonIE._catalog_name is None
    assert NRKTVSeasonIE._entries is None
    assert NRKTVSeasonIE._real_extract is None
    assert NRKTVSeasonIE.suitable is None
    assert NRKTVSeasonIE.IE_NAME is None
    assert NRKTVSeasonIE.IE_DESC is None
    assert NRKTVSeasonIE.valid_url(None, None) is None
    assert NRKTVSeasonIE.extract_id(None, None) is None
    assert NRKTVSeasonIE.IE_NAME is None



# Generated at 2022-06-22 08:14:20.422981
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('http://tv.nrk.no/direkte/nrk1')
test_NRKTVDirekteIE.unit_test = True



# Generated at 2022-06-22 08:14:28.436945
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    content = '<html><body><iframe src="http://radio.nrk.no/podkast/hele_historien/sesong/sirkus-sirkus/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c"></iframe></body></html>'


# Generated at 2022-06-22 08:14:31.632499
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    instance = NRKBaseIE("NRKBaseIE")
    expected = 'NRKBase'
    assert instance.IE_NAME == expected, 'Instance IE_NAME property does not match expected value'


# Generated at 2022-06-22 08:14:33.483516
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE('NRKTVSerieBaseIE', 'NRK TV')


# Generated at 2022-06-22 08:14:37.039920
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('program') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'



# Generated at 2022-06-22 08:14:39.268607
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    x = NRKSkoleIE(url)
    assert_equal(x._match_id(url), '19355')

# Generated at 2022-06-22 08:14:39.977045
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()


# Generated at 2022-06-22 08:14:45.174167
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/spangas/sesong/1'
    obj = NRKTVSeasonIE(NRKTVSeasonIE.suitable)
    assert obj.suitable(url) == True, 'Unexpected value for suitable method'


# Generated at 2022-06-22 08:14:54.258120
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''


# Generated at 2022-06-22 08:15:05.399800
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = "https://tv.nrk.no/serie/backstage/sesong/1/episode/8"
    display_id = "backstage/sesong/1/episode/8"
    season_number = 1
    episode_number = 8
    webpage = "I am a webpage."
    nrk_id = "blahblah"
    info = {
        "@type": "TVEpisode",
        "datePublished": "some date",
        "duration": "some duration",
        "headline": "some headline",
        "nrk:seriesId": "some series id",
        "image": {
            "image": "some image",
            "width": "some width",
            "height": "some height"
        }
    }
    class_object = NRKTVEpisodeIE()

# Generated at 2022-06-22 08:17:47.590880
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Create a new instance of your class
    test_nrk_podkast = NRKRadioPodkastIE()
    # For example call the function on the URL you want to test
    test_nrk_podkast._real_extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    # You have the assert function available
    # assert(your_expression, "Error message")
    assert(test_nrk_podkast.__module__ == 'nrk')

# Generated at 2022-06-22 08:17:52.320950
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE('NRKTVSerieBaseIE', 'NRKTV', 'NRK', 'nrk.no')
    NRKTVSerieBaseIE('NRKTVSerieBaseIE', 'NRK', 'NRK', 'nrk.no')



# Generated at 2022-06-22 08:17:53.764962
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    return NRKTVEpisodeIE()

# Generated at 2022-06-22 08:17:56.402015
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteie = NRKTVDirekteIE()
    assert nrktvdirekteie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-22 08:17:57.478470
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # This should fail without raising an exception
    a = NRKPlaylistIE()
    # We should be able to construct an object at all
    assert(a)

# Generated at 2022-06-22 08:18:04.068504
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE(NRKIE())._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'