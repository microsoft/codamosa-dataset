

# Generated at 2022-06-22 08:09:05.480226
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE("https://foo.bar.com/")
    assert ie.suitable("https://foo.bar.com/") == False


# Generated at 2022-06-22 08:09:09.262352
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    info_extractor = NRKRadioPodkastIE(NRKRadioPodkastIE._VALID_URL)
    info_extractor.suitable()

# Generated at 2022-06-22 08:09:11.498166
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('NRKBaseIE', {}, 'https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533')


# Generated at 2022-06-22 08:09:16.331353
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    from . import make_extractors_list
    extractors = make_extractors_list()
    assert NRKTVEpisodeIE in extractors
    for e in extractors:
        if e.IE_NAME == 'nrktv:episode':
            assert e is NRKTVEpisodeIE



# Generated at 2022-06-22 08:09:18.268638
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # see if the contructor is able to create a instance without errors
    # this is a cheap test to see if it crashes.
    ie = NRKPlaylistIE()


# Generated at 2022-06-22 08:09:27.965256
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/20-spoersmaal-tv/MUHH48000314/23-05-2014'
    ie = NRKTVIE()
    assert ie._match_id(url) == 'MUHH48000314'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._TESTS[0]['url'] == url


# Generated at 2022-06-22 08:09:28.617336
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE



# Generated at 2022-06-22 08:09:35.039845
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    flags = set()
    NRKTVSeriesIE.dont_use_this_class_on_url('fake_url')
    if 'fake_url' in flags:
        raise AssertionError('The flag of "fake_url" was not removed')

    # Add 'fake_url' to flags
    NRKTVSeriesIE.dont_use_this_class_on_url('fake_url')
    if 'fake_url' not in flags:
        raise AssertionError('The flag of "fake_url" was not added')



# Generated at 2022-06-22 08:09:39.293125
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-22 08:09:41.316876
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE(None, None)



# Generated at 2022-06-22 08:10:45.418958
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'

# Generated at 2022-06-22 08:10:46.519265
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-22 08:10:55.502318
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE('NRKTV').ie_key() == 'nrk'
    assert NRKTVSeriesIE('NRKTV').SUFFIX == '/'
    assert NRKTVSeriesIE('NRKTV')._format_id('1') == '1'

    assert NRKTVSeriesIE('NRKSuper').ie_key() == 'nrk:super'
    assert NRKTVSeriesIE('NRKSuper').SUFFIX == 'super/'
    assert NRKTVSeriesIE('NRKSuper')._format_id('1') == '1'



# Generated at 2022-06-22 08:10:58.111582
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    func_NRKSkoleIE = globals()['NRKSkoleIE']
    assert func_NRKSkoleIE.__name__ == 'NRKSkoleIE'



# Generated at 2022-06-22 08:10:59.404747
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrk_playlist_base_ie = NRKPlaylistBaseIE()



# Generated at 2022-06-22 08:11:11.431516
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    m3u8_url = 'https://lyd.nrk.no/nrk_radio_p1_ostlandssendingen_aac_h'
    url = 'https://radio.nrk.no/direkte/p1_oslo_akershus'
    ie = NRKTVDirekteIE()
    result = ie.url_result(url)
    if not result.get('_type') == 'url':
        raise Exception('Should be subclass of NRKTVIE')
    if not result.get('url') == m3u8_url:
        raise Exception('Url: %s should be %s' % (result.get('url'), m3u8_url))

# Generated at 2022-06-22 08:11:22.813948
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Test constructor of NRKTVSerieBaseIE.
    # First part, valid arguments
    test_nrktv_serie_base_ie_1 = NRKTVSerieBaseIE(NRKTVSerieBaseIE._VALID_URL)
    assert test_nrktv_serie_base_ie_1._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-22 08:11:28.054094
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert ie._match_id('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')



# Generated at 2022-06-22 08:11:40.839295
# Unit test for constructor of class NRKIE
def test_NRKIE():
    url = "https://tv.nrk.no/program/MUHH48004317"
    # url = "https://www.nrk.no/video/PS*154915"
    # url = "https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533"
    # url = "https://www.nrk.no/video/nrk_super_nyheter_19045"
    # url = "https://www.nrk.no/video/PS*154915"
    # url = "nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9"
    # url = "nrk:clip/7707d5a3-ebe7-434a-87d5-

# Generated at 2022-06-22 08:11:44.433291
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://www.nrk.no/program/episodes/hammerfest-i-krise/10857'
    episodes = NRKTVEpisodesIE(NRKPlaylistBaseIE())
    episodes.extract(url)



# Generated at 2022-06-22 08:14:11.960982
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE('tv', 'serie', 'backstage', '1')
    assert NRKTVSeasonIE('radio', 'podkast', 'dagsnytt', '201509')



# Generated at 2022-06-22 08:14:17.042733
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    info = NRKTVSeriesIE()._call_api('/foo', 'bar', 'baz', {'durum': 'äöü'})
    validate_info(info, False)
    # NRKTVEpisodeIE inherit NRKTVSeriesIE and implemented the validate_info method
    info = NRKTVSeriesIE()._call_api('/foo', 'bar', 'baz', {'durum': 'äöü'})
    validate_info(info, True)


# Generated at 2022-06-22 08:14:17.820329
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test = NRKTVEpisodeIE()



# Generated at 2022-06-22 08:14:18.977014
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()



# Generated at 2022-06-22 08:14:25.404137
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_ITEM_RE')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_extract_title')
    assert hasattr(ie, '_extract_description')



# Generated at 2022-06-22 08:14:29.590870
# Unit test for constructor of class NRKIE
def test_NRKIE():
    import sys
    import os
    import json
    
    # Setup input data and expected result
    url = 'http://www.nrk.no/video/PS*150533'
    test_data = {
        'md5': 'f46be075326e23ad0e524edfcb06aeb6',
        'info_dict': {
            'id': '150533',
            'ext': 'mp4',
            'title': 'Dompap og andre fugler i Piip-Show',
            'description': 'md5:d9261ba34c43b61c812cb6b0269a5c8f',
            'duration': 262,
        }
    }

    # Import the class and create an instance

# Generated at 2022-06-22 08:14:30.664859
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE(None)
    assert ie.PLAYLIST_TITLE(None) is None


# Generated at 2022-06-22 08:14:31.100897
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    pass

# Generated at 2022-06-22 08:14:32.654842
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE.ie_key() == 'nrk'


# Generated at 2022-06-22 08:14:35.755099
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    ie = NRKSkoleIE(url)
    assert ie.IE_DESC == 'NRK Skole'
    assert ie.valid_url == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie.video_id == '19355'

