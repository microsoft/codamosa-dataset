

# Generated at 2022-06-22 08:09:10.551673
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktvepisodesie = NRKTVEpisodesIE()
    assert nrktvepisodesie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert nrktvepisodesie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert nrktvepisodesie._TESTS[0]['url'] == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert nrktvepisodesie._TESTS[0]['info_dict']['id'] == '69031'
    assert nrktvepisodesie._TESTS

# Generated at 2022-06-22 08:09:12.894188
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    ie = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')



# Generated at 2022-06-22 08:09:19.488778
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE(NRKPlaylistIE.ie_key()).suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') == True
    assert NRKPlaylistIE(NRKPlaylistIE.ie_key()).suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449') == True



# Generated at 2022-06-22 08:09:21.795741
# Unit test for constructor of class NRKIE
def test_NRKIE():
    video = NRKIE(None)
    video._call_api("","","")


# Generated at 2022-06-22 08:09:25.292792
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.IE_DESC == 'NRK TV episodes'
    assert ie.ie_key() == 'NRKTVEpisode'

# Generated at 2022-06-22 08:09:26.452581
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlist_base_ie = NRKPlaylistBaseIE()
    assert "NRKPlaylistBaseIE" == playlist_base_ie.IE_NAME


# Generated at 2022-06-22 08:09:30.985864
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvseasonie = NRKTVSeasonIE(None)
    # Check that the base class is correctly assigned
    assert nrktvseasonie.__class__.__bases__[0].__name__ == 'NRKTVSeasonIE'


# Generated at 2022-06-22 08:09:32.379444
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert('NRKTVEpisodeIE')



# Generated at 2022-06-22 08:09:35.983422
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """Unit test for constructor of class NRKTVDirekteIE"""
    NRKTVDirekteIE.__init__(None, 'NRKTVDirekteIE')



# Generated at 2022-06-22 08:09:41.321782
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    """
    This test verifies that the NRKTVEpisodesIE constructor does not fail.
    """
    try:
        ie = NRKTVEpisodesIE()
    except Exception as ex:
        print('test_NRKTVEpisodesIE: Caught Exception %s' % ex)
        assert False
    assert True


# Generated at 2022-06-22 08:10:42.735368
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    try:
        NRKTVIE()
        print("NRKTVIE() constructor test is success")
    except:
        print("NRKTVIE() constructor test is failed")


# Generated at 2022-06-22 08:10:43.809202
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    class_ = NRKTVSeasonIE
    instance = class_(dict())
    assert isinstance(instance, NRKTVSeasonIE)



# Generated at 2022-06-22 08:10:45.772560
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE(None)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 08:10:57.490095
# Unit test for constructor of class NRKIE
def test_NRKIE():
    mp4_url = 'http://nrkwind-vh.akamaihd.net/i/nrkwind_0@132834/master.m3u8'
    m3u8_url = 'http://nrkwind-vh.akamaihd.net/i/nrkwind_0@132831/index_3_a-p.m3u8'
    info = {
        'id': 132831,
        'ext': 'mp4',
        'title': 'Dompap og andre fugler i Piip-Show',
        'description': 'md5:d9261ba34c43b61c812cb6b0269a5c8f',
        'duration': 262
    }
    test = NRKBaseIE()
    assert test._extract_akamai_

# Generated at 2022-06-22 08:10:59.076946
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-22 08:11:08.596625
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert not NRKTVSeriesIE.suitable(NRKTVIE.ie_key())
    assert not NRKTVSeriesIE.suitable(NRKTVEpisodeIE.ie_key())
    assert not NRKTVSeriesIE.suitable(NRKRadioPodkastIE.ie_key())
    assert not NRKTVSeriesIE.suitable(NRKTVSeasonIE.ie_key())
    assert NRKTVSeriesIE.suitable('nrktvseries')

# Generated at 2022-06-22 08:11:14.456465
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()

    assert nrktvie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert nrktvie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % nrktvie._EPISODE_RE

    assert nrktvie.IE_DESC == 'NRK TV and NRK Radio'


# Generated at 2022-06-22 08:11:16.560347
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    obj = NRKPlaylistIE()
    assert obj.IE_NAME == 'nrk:playlist'
    assert obj.IE_DESC == 'NRK Playlist'



# Generated at 2022-06-22 08:11:22.228055
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    pattern = re.compile(NRKTVEpisodeIE._VALID_URL)
    test_urls = [
        'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2',
        'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    ]
    for url in test_urls:
        display_id, season_number, episode_number = pattern.match(url).groups()
        nrk_episode_ie = NRKTVEpisodeIE(NRKTVEpisodeIE._downloader)
        info = nrk_episode_ie._real_extract(url)
        assert display_id == info.get('display_id')
        assert season_number == str(info.get('season_number'))

# Generated at 2022-06-22 08:11:24.623380
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    try:
        NRKSkoleIE()
    except:
        assert False, 'constructor of class NRKSkoleIE should not fail'


# Generated at 2022-06-22 08:13:31.518632
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE('NRKTV', True)

# Generated at 2022-06-22 08:13:35.501573
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # NRKTVDirekteIE cannot work without arguments
    assert_raises(TypeError, NRKTVDirekteIE)
    # It should have minimum of one argument
    assert_raises(TypeError, NRKTVDirekteIE, 1)
    # It should have maximum of two arguments
    assert_raises(TypeError, NRKTVDirekteIE, 1, 2, 3)



# Generated at 2022-06-22 08:13:41.670733
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('http://tv.nrk.no/direkte/nrk1#3637409')
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrk\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0/'
# end of Unit test for constructor of class NRKBaseIE


# Generated at 2022-06-22 08:13:45.401304
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = "https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c"
    ie = NRKRadioPodkastIE(url)
    assert ie.suitable(url)


# Generated at 2022-06-22 08:13:50.555678
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk = NRKBaseIE()
    assert nrk._GEO_COUNTRIES == ['NO']
    assert nrk._CDN_REPL_REGEX == r'(?x)://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'
    assert isinstance(nrk, InfoExtractor)



# Generated at 2022-06-22 08:13:52.897972
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    parser = NRKTVIE()

# Generated at 2022-06-22 08:13:58.379149
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    """NRKPlaylistIE test."""
    test_url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    ie = NRKPlaylistIE(NRKPlaylistIE._create_ie(NRKPlaylistIE.ie_key()))
    ie.extract(test_url)



# Generated at 2022-06-22 08:14:09.324366
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist_object = NRKPlaylistIE("http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763")
    assert playlist_object.IE_NAME == "NRKPlaylistIE"
    assert playlist_object._VALID_URL == "https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)"
    assert playlist_object._TESTS[0]["url"] == "http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763"

# Generated at 2022-06-22 08:14:11.703800
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    tv_serie_base = NRKTVSerieBaseIE()
    assert tv_serie_base.tv_serie_page_info(
        {'_links': {'next': {'href': 'something'}}}, 'some ID') == {
            '_type': 'url',
            'url': 'nrk:something',
            'ie_key': 'NRK',
        }



# Generated at 2022-06-22 08:14:14.350764
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
