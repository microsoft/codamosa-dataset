

# Generated at 2022-06-22 08:09:01.873552
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    """
    This is test for class NRKPlaylistIE and its constructor.
    """
    nrkie_instance = NRKPlaylistIE()
    assert nrkie_instance.ie_key() == 'NRKPlaylist'



# Generated at 2022-06-22 08:09:10.717860
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert(NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'))
    assert(not NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/'))
    assert(not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt/69031'))
    assert(not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt/'))

# Generated at 2022-06-22 08:09:20.346304
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Make sure it can handle a single video
    playlist = NRKPlaylistIE('nrk', 'gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert playlist.playlist_count == 1
    assert playlist._playlist_title is None
    assert playlist._playlist_desc is None
    assert playlist._entries == ['nrk:YT14557837']

    # Make sure it can handle a playlist
    playlist = NRKPlaylistIE('nrk', 'rivertonprisen-til-karin-fossum-1.12266449')
    assert playlist._playlist_title == 'Rivertonprisen til Karin Fossum'

# Generated at 2022-06-22 08:09:24.870119
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    class_to_test = NRKTVEpisodesIE
    nrk_tv_episodes_ie = class_to_test
    # Get a list of the methods of class_to_test
    methods_of_class_to_test = [method_name for method_name in dir(
        nrk_tv_episodes_ie) if callable(getattr(nrk_tv_episodes_ie, method_name))]
    print("Methods of class NRKTVEpisodesIE:")
    print(methods_of_class_to_test)

#
# This is a test of NRKTVEpisodesIE methods
#
    nrk_tv_episodes_ie = class_to_test('NRKTVEpisodesIE', {})
    # Get a list of the methods of class_to_test
    methods

# Generated at 2022-06-22 08:09:26.054205
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.ie_key() == 'NRKSkole:nrk'


# Generated at 2022-06-22 08:09:32.144352
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_ie = NRKTVEpisodesIE()
    assert nrktv_episodes_ie.ie_key() == 'NRKTVEpisodes'
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert nrktv_episodes_ie._match_id(url) == '69031'
    assert nrktv_episodes_ie._match_id('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/7050') is None
    assert nrktv_episodes_ie._match_id('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/7050.html') is None

# Generated at 2022-06-22 08:09:36.374998
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE._TESTS.append({
        'url': 'https://tv.nrk.no/serie/dagsnytt/sesong/12/episode/6',
        'only_matching': True,
    })
    for test in NRKTVSerieBaseIE._TESTS:
        result = NRKTVSerieBaseIE()._real_extract(test['url'])
        assert isinstance(result, list)



# Generated at 2022-06-22 08:09:39.929127
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-22 08:09:46.787833
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Required for build_opener.  See
    # https://docs.python.org/2/library/urllib2.html#urllib2.build_opener
    class NullHandler(AbstractHTTPHandler):
        def default_open(self, req):
            return NullHandler()

    opener = build_opener(NullHandler)
    opener.addheaders = [('User-Agent', 'Mozilla/5.0')]
    install_opener(opener)

    for test in NRKTVEpisodeIE._TESTS:
        print(test['url'])
        info = NRKTVEpisodeIE()._real_extract(test['url'])
        if 'skip' in test:
            continue
        # Check that the media URL is not actually downloaded.  The
        # `extract` method downloads the media

# Generated at 2022-06-22 08:09:47.376812
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    pass # TODO

# Generated at 2022-06-22 08:10:47.753304
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_len = len(NRKBaseIE._GEO_COUNTRIES)
    assert test_len == 1, 'Expected 1, got %s' % test_len


# Generated at 2022-06-22 08:10:48.821691
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE(NRKTVSeasonIE.suitable)._VALID_URL == NRKTVSeasonIE._VALID_URL


# Generated at 2022-06-22 08:10:50.489545
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()


# Generated at 2022-06-22 08:10:59.489440
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE("https://tv.nrk.no/serie/backstage")
    expected = [
        ("https://tv.nrk.no/serie/backstage", NRKTVSeriesIE),
        ("https://tv.nrk.no/serie/backstage/sesong/1", NRKTVSeasonIE),
        ("https://tv.nrk.no/serie/backstage/sesong/1/episode/1", NRKTVEpisodeIE),
        ]
    for url, expected_class in expected:
        assert ie.suitable(url)
        assert issubclass(ie.extract_info(url)['_type'], expected_class)

# Generated at 2022-06-22 08:11:11.531711
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    serie_base = NRKTVSerieBaseIE()
    embeddeds = {
        'episodes': {
            '_embedded': {
                'episodes': [
                    {'prfId': 'KMTE50100114'},
                    {'prfId': 'KMTE50100115'},
                ]
            }
        },
        'instalments': {
            '_embedded': {
                'instalments': [
                    {'episodeId': 'KMTE50100114'},
                    {'episodeId': 'KMTE50100115'},
                ]
            }
        },
    }
    serie_base._ASSETS_KEYS = ('episodes', 'instalments',)

# Generated at 2022-06-22 08:11:16.177393
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # The API of NRKSkoleIE has a different behavior.
    # When the API returns less episodes than the value set in `query` (query['pageSize']),
    # it means the episode list is complete and the API will not return any more episodes.
    # When the API returns the same number of episodes as the value set in `query`,
    # it means there might be more episodes and the API will return those additional episodes
    # when the `query` argument is increased.
    # But, the API will not return any more episodes when the episode list is complete.
    # So, set `query` argument to an integer that is larger than the number of episodes.
    # When the API returns all episodes, `self._call_api` will automatically reduce the value of `query` argument.

    # Create an instance of class NRKIE
    nrk = NRKTV

# Generated at 2022-06-22 08:11:20.215076
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers'
    serie_base_ie = NRKTVSeriesIE.suitable(url)
    assert serie_base_ie is False


# Generated at 2022-06-22 08:11:24.655825
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')

# Generated at 2022-06-22 08:11:30.650439
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    try:
        NRKSkoleIE("https://www.nrk.no/skole/?page=search&q=&mediaId=14099")
        NRKSkoleIE("https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355")
    except:
        raise AssertionError("Error in NRKSkoleIE")


# Generated at 2022-06-22 08:11:41.823437
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    from . import NRKTVEpisodeIE
    if sys.version_info < (3, 6):
        pytest.skip("Python version < 3.6 doesn't support named groups in regex")
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    # Data extracted from the URL
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'
    # Data extracted from the webpage
    webpage = '<meta data-program-id="MUHH36005220" />'
    nrk_id = 'MUHH36005220'
    # Create a NRKTVEpisodeIE object with default parameters
    episode = NRKTVEpisodeIE()
   

# Generated at 2022-06-22 08:14:02.265883
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']

    # Unit test for _extract_nrk_formats using asset_url as input
    asset_url = "https://nrkod-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/nrkhd-osl-rr.netwerk.no/no/nrk/md/2015-12-17/SOTS201512170115_1-a.mkv/master.m3u8"
    video_id = "SOTS201512170115_1-a"
    formats = ie._extract_nrk_formats(asset_url, video_id)

# Generated at 2022-06-22 08:14:03.010135
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE is not None


# Generated at 2022-06-22 08:14:13.284065
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    display_id = 'test-serie/3'
    query = {'pageSize': 50}
    url = 'https://tv.nrk.no/serie/test-serie/sesong/3'
    season_id = '3'
    serie = 'test-serie'

    # Create a mock episode_data object
    episode_data = mock.Mock()
    episode_data.get.return_value = {
        '_embedded': {
            'episodes': [{'previousEpisodeId': 'episode-id-1'}, {'previousEpisodeId': 'episode-id-2'}]
        }
    }

# Generated at 2022-06-22 08:14:24.754343
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Check whether method _extract_entries() is implemented correctly
    episode = {'episodeId': '0'}
    display_id = '0'
    wrong_episode = {'episodeId': True}
    wrong_display_id = 0
    entries = NRKTVSerieBaseIE._extract_entries([episode])
    wrong_entries = NRKTVSerieBaseIE._extract_entries([wrong_episode])
    assert entries != wrong_entries
    assert entries == NRKTVSerieBaseIE._extract_entries([])
    assert entries[0].url == 'nrk:%s' % display_id
    assert entries[0].video_id == display_id
    assert entries[0].ie_key == 'NRK'
    # Check whether method _extract_assets_key() is implemented correctly

# Generated at 2022-06-22 08:14:30.242732
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1')
    NRKTVDirekteIE.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert isinstance(NRKTVDirekteIE, type(NRKTVIE))


# Generated at 2022-06-22 08:14:39.884353
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrk_season_ie = NRKTVSeasonIE('http://www.nrk.no')
    assert nrk_season_ie.NAME == 'nrktv:season'
    assert nrk_season_ie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''

# Generated at 2022-06-22 08:14:41.427330
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE()


# Generated at 2022-06-22 08:14:51.839068
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """Unit test for constructor of class NRKTVSeriesIE.
    """
    from tests.test_nrk import test_NRKTVIE, test_NRKTVEpisodeIE, test_NRKRadioPodkastIE, test_NRKTVSeasonIE
    NRKTVSeriesIE.suitable(test_NRKTVIE._TESTS[0]['url'])
    NRKTVSeriesIE.suitable(test_NRKTVEpisodeIE._TESTS[0]['url'])
    NRKTVSeriesIE.suitable(test_NRKRadioPodkastIE._TESTS[0]['url'])
    NRKTVSeriesIE.suitable(test_NRKTVSeasonIE._TESTS[0]['url'])



# Generated at 2022-06-22 08:14:57.579963
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Arrange
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE(NRKIE(), url)

    # Act
    video_id = ie._video_id
    re_id = ie._match_id(url)

    # Assert
    assert video_id is not None
    assert re_id is not None
    assert video_id == re_id



# Generated at 2022-06-22 08:14:59.860672
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Test URL of NRKTVSeasonIE
    url = 'https://tv.nrk.no/serie/spangas/sesong/1'
    # Test constructor
    nrktvseason_object = NRKTVSeasonIE(NRKIE(), url)
    # Test suitable method
    assert not nrktvseason_object.suitable(url)
