

# Generated at 2022-06-22 08:09:04.990125
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    test_obj = NRKTVSerieBaseIE()
    assert not test_obj._search_regex(None, None, '1')
    assert not test_obj._search_regex(None, '0', '1')
    assert test_obj._search_regex('abc1abc', '1', 'test regex', default=None) == 'abc1abc'
    assert test_obj._search_regex('abc1abc', '2', 'test regex', default=None) == None
    assert test_obj._search_regex(
        'abc1abc', None, 'test regex', default=None) == None
    assert test_obj._search_regex('abc1abc', '1', 'test regex', default='DEFAULT') == 'abc1abc'

# Generated at 2022-06-22 08:09:07.314626
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # instantiate
    ie = NRKPlaylistBaseIE('some_url')
    # is_live (base class)
    assert not ie.is_live()


# Generated at 2022-06-22 08:09:19.608664
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == 'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-22 08:09:21.920602
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE(NRKIE()).ie_key() == 'NRKPlaylist'

# Generated at 2022-06-22 08:09:24.307611
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'



# Generated at 2022-06-22 08:09:33.709548
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('www.nrk.no', {}, None)
    assert ie.get_geo_countries() == ['NO']
    assert ie.get_geo_countries(False) == ['NO']
    assert ie.get_geo_countries('www.nrk.no') == ['NO']
    assert ie.get_geo_countries('www.nrk.no', False) == ['NO']

# Generated at 2022-06-22 08:09:37.947295
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert repr(NRKIE('nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9')) == repr('NRKIE "nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9"')


# Generated at 2022-06-22 08:09:39.460842
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE('nrk:6021', 'nrk:14099')

# Generated at 2022-06-22 08:09:41.074229
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE

# Generated at 2022-06-22 08:09:48.940740
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    class DummyClass(NRKBaseIE):
        _VALID_URL = r'...'

        def _real_extract(self, url):
            pass
    c = DummyClass()
    c._downloader = '...'
    c._make_request = lambda *args: '...'
    c._download_webpage = lambda *args: '...'
    c._download_json = lambda *args: '...'
    c._download_xml = lambda *args: '...'
    c.raise_login_required = lambda *args: None



# Generated at 2022-06-22 08:10:53.225420
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    stream = io.BytesIO(compat_urllib_request.urlopen(
        'https://tv.nrk.no/programserie/hellums-kro/kro-krig-og-kjaerlighet').read())
    url = 'https://tv.nrk.no/programserie/hellums-kro/kro-krig-og-kjaerlighet'
    nrk = NRKTVSerieBaseIE(NRKTVIE())
    nrk._download_webpage = lambda url, display_id: stream.read()
    nrk._search_regex = lambda regex, string1, string2, string3: None
    nrk._search_json_ld = lambda webpage, display_id, default: None

# Generated at 2022-06-22 08:10:55.812706
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test that new NRKPlaylistIE constructed with URL as input
    # has the same value in the _VALID_URL member variable
    # as the URL string used in the constructor as input
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    NRKPlaylistIE(url)._VALID_URL == url


# Generated at 2022-06-22 08:11:00.618522
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    base_ie = NRKBaseIE("nrk", 0, "fake_name")
    expected_attrs = ["name", "ie_key", "ie_name"]
    for attr in expected_attrs:
        assert getattr(base_ie,attr)

# Unit tests for _extract_nrk_formats()

# Generated at 2022-06-22 08:11:11.828136
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE._VALID_URL = r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    result = re.match(NRKTVEpisodeIE._VALID_URL, url)
    assert (result.groups()[0] == 'backstage/sesong/1/episode/8')
    assert (result.groups()[1] == '1')
    assert (result.groups()[2] == '8')


# Generated at 2022-06-22 08:11:15.940019
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Create an instance of class NRKPlaylistBaseIE
    instance = NRKPlaylistBaseIE()
    # Test if the instance is correctly created
    assert isinstance(instance,NRKPlaylistBaseIE)



# Generated at 2022-06-22 08:11:25.865734
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    with pytest.raises(AssertionError):
        NRKTVSeriesIE.suitable(NRKTVIE._VALID_URL)
    with pytest.raises(AssertionError):
        NRKTVSeriesIE.suitable(NRKTVEpisodeIE._VALID_URL)
    with pytest.raises(AssertionError):
        NRKTVSeriesIE.suitable(NRKRadioPodkastIE._VALID_URL)
    with pytest.raises(AssertionError):
        NRKTVSeriesIE.suitable(NRKTVSeasonIE._VALID_URL)
    assert NRKTVSeriesIE.suitable(NRKTVSeriesIE._VALID_URL)

# Generated at 2022-06-22 08:11:28.748283
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')


# Generated at 2022-06-22 08:11:41.572433
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL == 'https?://(?P<domain>tv|radio)\.nrk\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<serie>[^/]+)/(?:(?:sesong/)?(?P<id>\\d+)|sesong/(?P<id_2>[^/?#&]+))'
    assert NRKTVSeasonIE.uri_name == 'nrktvseason'
    assert NRKTVSeasonIE.name == 'NRKTV:Season'
    assert NRKTVSeasonIE.domain_id == 'nrktv'
    assert NRKTVSeasonIE.ie_key() == 'NRKTV:Season'

# Generated at 2022-06-22 08:11:43.003560
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    s = NRKTVDirekteIE()
    raise Exception("NRKTVIE don't have valid constructor")

# Generated at 2022-06-22 08:11:52.870362
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    vidie = NRKTVEpisodeIE()
    assert (vidie.__class__.__name__ == "NRKTVEpisodeIE") # test for the name of the class
    assert (vidie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))') # test for the url
    assert (vidie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2') # test for the first url in _TESTS
    assert (vidie._TESTS[0]['info_dict']['id'] == 'MUHH36005220')

# Generated at 2022-06-22 08:14:00.452717
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    r = NRKSkoleIE('nrk:6021')
    assert r._url == 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    assert r._id == '6021'
    assert r._type == 'nrk:6021'
    assert r.ie_key() == 'NRKSkole'
    assert r.suitable('nrk:6021')
    assert not r.suitable('nrk:')

# Generated at 2022-06-22 08:14:01.106190
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE

# Generated at 2022-06-22 08:14:03.873804
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://www.nrk.no/sport/tour-de-ski/spilleliste-tour-de-ski-med-kommentator-1.13903872'
    playlist = NRKPlaylistBaseIE._make_instance()
    playlist.extract(url)

# Generated at 2022-06-22 08:14:13.818462
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable(url='https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable(url='https://tv.nrk.no/serie/backstage/sesong')
    assert not NRKTVSeasonIE.suitable(url='https://tv.nrk.no/serie/backstage/1')
    assert not NRKTVSeasonIE.suitable(url='https://tv.nrk.no/serie/backstage')
    assert not NRKTVSeasonIE.suitable(url='https://tv.nrk.no/serie')
    assert not NRKTVSeasonIE.suitable(url='https://tv.nrk.no/')

# Generated at 2022-06-22 08:14:18.784753
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """Unit test for NRKIE.__init__"""
    NRKIE("nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9")



# Generated at 2022-06-22 08:14:27.435114
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    i = NRKTVSeriesIE()
    link1 = 'https://tv.nrk.no/serie/groenn-glede'
    link2 = 'https://tv.nrk.no/serie/lindmo'
    link3 = 'https://tv.nrk.no/serie/blank'
    link4 = 'https://tv.nrk.no/serie/backstage'
    link5 = 'https://tv.nrksuper.no/serie/labyrint'
    link6 = 'https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene'
    link7 = 'https://tv.nrk.no/serie/saving-the-human-race'

# Generated at 2022-06-22 08:14:32.259378
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvs = (NRKTVIE(), NRKTVIE(NRKTVIE.ie_key()))
    for nrktv in nrktvs:
        assert nrktv.ie_key() == 'NRK'
        assert nrktv.ie_key() in nrktv.SUITABLE_HOSTS


# Generated at 2022-06-22 08:14:40.688482
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    info_extractor = NRKPlaylistBaseIE('NRKPlaylistBaseIE')
    assert info_extractor._VALID_URL.__class__.__name__ == 'compiled_regex_type'
    assert info_extractor._TESTS.__class__.__name__ == 'list'
    assert info_extractor.IE_NAME.__class__.__name__ == 'str'
    assert info_extractor.IE_DESC.__class__.__name__ == 'str'
    assert info_extractor.IE_DESC_BASE.__class__.__name__ == 'str'
    assert info_extractor.version.__class__.__name__ == 'str'


# Generated at 2022-06-22 08:14:41.553915
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # class should be instantiated
    NRKTVSerieBaseIE()



# Generated at 2022-06-22 08:14:43.136058
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert(NRKTVSeriesIE)



# Generated at 2022-06-22 08:17:22.808162
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL == NRKTVEpisodeIE()._VALID_URL


# Generated at 2022-06-22 08:17:28.516422
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE(None, None)
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'


# Generated at 2022-06-22 08:17:30.807335
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    global _NRKBaseIE
    _NRKBaseIE = NRKBaseIE()

test_NRKBaseIE() # Run test


# Generated at 2022-06-22 08:17:35.180561
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Assert that the constructor of class NRKRadioPodkastIE does not raise an exception
    NRKRadioPodkastIE()


# Generated at 2022-06-22 08:17:38.673610
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE.suitable(None)



# Generated at 2022-06-22 08:17:39.397679
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-22 08:17:42.073135
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Test if it fails with the intention of finding invalid urls
    # Big thanks to @itsfoss and @bootsy on github for the idea
    with pytest.raises(RegexNotFoundError):
        NRKRadioPodkastIE()._real_extract('http://radio.nrk.no/podkast/ulrikkes_univers/l_something_else')

# Generated at 2022-06-22 08:17:44.904465
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_class = NRKBaseIE()
    assert test_class.IE_NAME == 'nrk'



# Generated at 2022-06-22 08:17:45.815925
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    instance = NRKTVEpisodesIE(None)
    assert isinstance(instance, NRKTVEpisodesIE)

# Generated at 2022-06-22 08:17:46.587167
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie is not None