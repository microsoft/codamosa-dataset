

# Generated at 2022-06-22 08:09:07.284260
# Unit test for constructor of class NRKIE
def test_NRKIE():
    video = NRKIE()
    assert isinstance(video, NRKIE)

# Unit test function for function '_extract_nrk_formats'

# Generated at 2022-06-22 08:09:09.689073
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    inst = NRKTVSeasonIE('NRKTVSeasonIE')
    inst.suitable('https://tv.nrk.no/serie/backstage/sesong/1')


# Generated at 2022-06-22 08:09:18.862262
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRK', 'NO')
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-22 08:09:23.268731
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    """Unit test for constructor of class NRKRadioPodkastIE."""
    nrkradio_podkast_ie = NRKRadioPodkastIE()
    assert nrkradio_podkast_ie != None

# Generated at 2022-06-22 08:09:32.910356
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from ..utils import parse_countries
    assert parse_countries(NRKBaseIE._GEO_COUNTRIES) == {'NO'}
    assert re.match(NRKBaseIE._CDN_REPL_REGEX, '//nrkod12-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/')
    assert re.match(NRKBaseIE._CDN_REPL_REGEX, '//nrk-od-no.telenorcdn.net/')
    assert re.match(NRKBaseIE._CDN_REPL_REGEX, '//minicdn-od.nrk.no/od/nrkhd-osl-rr.netwerk.no/no')

# Generated at 2022-06-22 08:09:36.010710
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE._ITEM_RE is None, 'The value of _ITEM_RE should be None'



# Generated at 2022-06-22 08:09:38.667228
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()

# Generated at 2022-06-22 08:09:50.212164
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    parser = NRKBaseIE()
    assert parser.IE_NAME == 'nrk'
    assert parser.GEO_COUNTRIES == ['NO']
    assert re.match(parser._CDN_REPL_REGEX, '://nrkod13-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/')
    assert re.match(parser._CDN_REPL_REGEX, '://nrkod133-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/')
    assert re.match(parser._CDN_REPL_REGEX, '://nrk-od-no.telenorcdn.net/')

# Generated at 2022-06-22 08:09:56.384080
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    class Test(NRKTVSerieBaseIE):
        @classmethod
        def _catalog_name(cls):
            return 'series'

        def _real_extract(self, url):
            return self.url_result(url, 'NRKIE')
    t = Test()
    assert t._extract_entries(None) == []
    assert t._extract_entries([]) == []
    assert t._extract_entries([{'episodeId': '1'}]) == [{'_type': 'url', 'url': 'nrk:1', 'ie_key': 'NRKTV', 'id': '1'}]

# Generated at 2022-06-22 08:10:01.946484
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from . import NRKTVDirekteIE
    assert NRKTVDirekteIE.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert NRKTVDirekteIE._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 08:11:09.086247
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE()



# Generated at 2022-06-22 08:11:11.492241
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE('nrk:MUHH48000314') == 'nrk:MUHH48000314'
    assert NRKTVIE('nrk:MUHH48000314').ie_key == 'nrk'



# Generated at 2022-06-22 08:11:12.206909
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    pass



# Generated at 2022-06-22 08:11:14.818412
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    serie_kind = 'serie'
    serie = 'backstage'
    season_id = '1'
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    expected = 'https://tv.nrk.no/api/catalog/series/backstage/seasons/1'
    assert NRKTVSeasonIE._call_api(url) == expected



# Generated at 2022-06-22 08:11:19.296666
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    """Unit tests for_init__ of class NRKTVEpisodesIE"""
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    _ = NRKTVEpisodesIE(url)



# Generated at 2022-06-22 08:11:25.820913
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    unit_test = NRKTVIE()
    assert unit_test.IE_NAME == 'nrk'
    assert unit_test.IE_DESC == 'NRK TV and NRK Radio'
    assert unit_test._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert unit_test._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % unit_test._EPISODE_RE

# Generated at 2022-06-22 08:11:28.509073
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        NRKBaseIE._GEO_COUNTRIES
    except AttributeError as e:
        print('No GEO countries.')
        return False
    return True



# Generated at 2022-06-22 08:11:30.005198
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
	NRKTVSerieBaseIE()

# Generated at 2022-06-22 08:11:32.924129
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert issubclass(NRKPlaylistBaseIE, InfoExtractor)



# Generated at 2022-06-22 08:11:39.186077
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    match = NRKTVEpisodeIE._VALID_URL.match('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert match.group('id') == 'hellums-kro/sesong/1/episode/2'
    assert int(match.group('season_number')) == 1
    assert int(match.group('episode_number')) == 2


# Generated at 2022-06-22 08:13:48.989414
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE')
    assert ie.IE_NAME == 'NRKBaseIE'
    assert ie._GEO_COUNTRIES == ['NO']

# Unit tests for helper functions in NRKBaseIE

# Generated at 2022-06-22 08:14:00.676347
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    tvid = 'nrk1'
    webtv_direkte_page = 'https://tv.nrk.no/direkte/%s' % tvid
    radio_direkte_page = 'https://radio.nrk.no/direkte/%s' % tvid
    webpage = fake_webpage({'webpage_or_url': webtv_direkte_page})
    url_result = NRKTVDirekteIE()._real_extract(webpage.url)
    assert url_result['id'] == tvid
    webpage = fake_webpage({'webpage_or_url': radio_direkte_page})
    url_result = NRKTVDirekteIE()._real_extract(webpage.url)

# Generated at 2022-06-22 08:14:05.331230
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE('https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13')
    NRKTVIE('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015')
    NRKTVIE('https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13')
    NRKTVIE('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015')


# Generated at 2022-06-22 08:14:07.977441
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_NRKBaseIE = NRKBaseIE()
    assert test_NRKBaseIE

# Test for raise_error method of class NRKBaseIE

# Generated at 2022-06-22 08:14:11.496791
# Unit test for constructor of class NRKIE
def test_NRKIE():
    url = 'http://www.nrk.no/video/PS*150533'
    ie = NRKIE()
    ie._match_id(url)
    ie.extract(url)



# Generated at 2022-06-22 08:14:15.967549
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE = NRKRadioPodkastIE()
    assert NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')



# Generated at 2022-06-22 08:14:16.669755
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    raise NotImplementedError

# Generated at 2022-06-22 08:14:25.467759
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank'
    website = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant'
    ie = NRKTVSeriesIE(NRKTVSeriesIE.create_ie())
    assert ie.suitable(url) is True
    assert ie.suitable(website) is False
    # site should be a string
    website_object = url_or_none(website)
    assert ie.suitable(website_object) is False


# Generated at 2022-06-22 08:14:33.825901
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    inst = NRKBaseIE('test', 'test')
    assert inst.IE_NAME == 'NRK'
    assert inst.GEO_COUNTRIES == ['NO']
    assert inst.CDN_REPL_REGEX == r'(?x)://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'


# Generated at 2022-06-22 08:14:35.851291
# Unit test for constructor of class NRKIE
def test_NRKIE():
    selector = NRKIE('NRKIE', 'NRKBaseIE')
    print(selector.__dict__)
