

# Generated at 2022-06-22 08:09:07.660606
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test that regular expression for episodes works for all possible
    # length of episode id (1-4 digits)
    regex = NRKTVEpisodesIE._ITEM_RE % '\d{1,4}'
    episodes = ['1234', '1', '12', '123']
    result = all(re.search(regex, episode) is not None for episode in episodes)
    assert result



# Generated at 2022-06-22 08:09:12.985744
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """Test KRKTVSeasonIE constructor"""
    class NRKTVSeasonIE(NRKTVSeasonIE):
        def __init__(self, *args, **kwargs):
            self._ASSETS_KEYS = NRKTVSeasonIE._ASSETS_KEYS
            self._TESTS = NRKTVSeasonIE._TESTS
            super(NRKTVSeasonIE, self).__init__(*args, **kwargs)

    return NRKTVSeasonIE


# Generated at 2022-06-22 08:09:17.655942
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    import unittest
    class test_NRKTVSeriesIE(unittest.TestCase):
        def setUp(self):
            self.tmpfile = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)

# Generated at 2022-06-22 08:09:19.582753
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/program/URBA17000620'
    ie = NRKPlaylistBaseIE()
    assert ie._match_id(url) == 'URBA17000620'
    assert ie.ie_key() == 'nrk:playlist'



# Generated at 2022-06-22 08:09:20.266727
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlistBase = NRKPlaylistBaseIE()
    print(playlistBase)


# Generated at 2022-06-22 08:09:21.111251
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE()



# Generated at 2022-06-22 08:09:31.235025
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE(None)
    assert ie._GEO_COUNTRIES == ['NO']
    assert re.match(ie._CDN_REPL_REGEX, 'http://nrk-od-no.telenorcdn.net/no/' )
    assert ie._extract_nrk_formats('http://nrk-od-no.telenorcdn.net/no/', '9/9/9') is None
    assert ie._extract_nrk_formats('https://nrk-od-no.telenorcdn.net/no/', '9/9/9') is None
    assert ie._extract_nrk_formats('http://nrk-od-no.telenorcdn.net/no/', '9/9/9') is None



# Generated at 2022-06-22 08:09:33.553888
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE(), 'Unit test for constructor of class NRKTVSeasonIE'



# Generated at 2022-06-22 08:09:36.027598
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    i = NRKRadioPodkastIE('MUHH48000314AA')
    assert i.video_id == 'MUHH48000314AA'

# Generated at 2022-06-22 08:09:42.013844
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    instance = NRKPlaylistIE(NRKPlaylistIE.ie_key())
    assert instance._match_id(url) == url

# Generated at 2022-06-22 08:10:51.085882
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Test ID
    URL = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    RESULT = NRKRadioPodkastIE._extract_url_result(URL)
    assert RESULT['url'] == 'nrk:l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert RESULT['ie'] == NRKIE.ie_key()
    assert RESULT['video_id'] == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'



# Generated at 2022-06-22 08:10:59.526521
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
        print('\nRunning test for NRKSkoleIE')
        url = 'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/14099'
        try:
            print('Trying to open url and get json data')
            data = self._download_json(url)
        except Exception as e:
            print('Exception raised trying to get json data ', e)
        print('Test finished')

# Generated at 2022-06-22 08:11:06.766074
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie is not None

NRKNoBaseIE = partial(NRKBaseIE, ie_key='NRK')
NRKNoIE = partial(NRKIE, ie_key='NRK')

# Generated at 2022-06-22 08:11:12.290596
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    NRKPlaylistIE().suitable(url)
    assert True

# Generated at 2022-06-22 08:11:17.992052
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE(NRKSkoleIE.IE_DESC,NRKSkoleIE._VALID_URL,NRKSkoleIE._TESTS)
    assert ie._downloader is not None
    assert ie._real_download is True
    assert ie._type is None
    assert ie._WORKING is True

# Generated at 2022-06-22 08:11:19.573054
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test_object = NRKPlaylistBaseIE()


# Generated at 2022-06-22 08:11:21.084425
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """Unit test to check that NRKTVSeasonIE has the class constructor defined properly"""
    nrktv_season_ie = NRKTVSeasonIE()
    assert nrktv_season_ie



# Generated at 2022-06-22 08:11:24.260138
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n = NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert n.video_id == '6021'

# Generated at 2022-06-22 08:11:27.367968
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE(
            'NRKPlaylistBase',
            'NRKPlaylistBaseIE_PREFIX',
            'NRKPlaylistBaseIE_TEST_URL')
        assert True
    except Exception:
        assert False



# Generated at 2022-06-22 08:11:33.066226
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE(NRKTVIE.ie_key())._VALID_URL == NRKTVIE._VALID_URL
    assert NRKTVIE(NRKTVIE.ie_key())._EPISODE_RE == NRKTVIE._EPISODE_RE

# Generated at 2022-06-22 08:13:57.799083
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_object = NRKBaseIE()
    assert test_object._GEO_COUNTRIES == ['NO']
    assert test_object._CDN_REPL_REGEX == r'\/\/(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net\/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no\/od\/nrkhd-osl-rr\.netwerk\.no\/no)\/'


# Generated at 2022-06-22 08:13:58.879273
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(None)



# Generated at 2022-06-22 08:14:05.092410
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = "https://tv.nrk.no/direkte/nrk1"
    ie = NRKTVIE(NRKTVIE._create_ie(NRKTVDirekteIE.ie_key()))
    ie_info = ie.extract(url)
    assert ie_info['id'] == 'MSM-MX-A-A2-1-h'


# Generated at 2022-06-22 08:14:15.043140
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk = NRKBaseIE()
    assert nrk.IE_NAME == 'nrk'
    assert nrk._GEO_COUNTRIES == ['NO']
    assert nrk._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|
            nrk-od-no\\.telenorcdn\\.net|
            minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no
        )/'''


# Generated at 2022-06-22 08:14:27.677179
# Unit test for constructor of class NRKIE
def test_NRKIE():
    video_id = '150533'
    _valid_url = r'nrk:150533'
    _VALID_URL = r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-22 08:14:29.130795
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Constructor test
    NRKTVSerieBaseIE()

# Generated at 2022-06-22 08:14:34.980886
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    NRKBaseIE._extract_nrk_formats('https://psapi-ne.nrk.no/mediaelement/41619317', 'abc')
    try:
        NRKBaseIE._call_api('', 'abc', 'ghi', 'jkl', True, {})
    except ExtractorError:
        pass
    NRKBaseIE._raise_error({'endUserMessage': 'End user message'})


# Generated at 2022-06-22 08:14:37.506499
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert_true(NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/hellums-kro/sesong/1'))



# Generated at 2022-06-22 08:14:39.204235
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('nrk:nrk1', None).suitable('nrk:nrk1')

# Generated at 2022-06-22 08:14:45.384348
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk_direkte_ie = NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')
    assert nrk_direkte_ie.IE_NAME == 'nrk:direkte'
    assert nrk_direkte_ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'

