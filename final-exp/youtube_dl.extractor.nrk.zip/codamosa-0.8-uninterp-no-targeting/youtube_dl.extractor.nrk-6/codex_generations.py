

# Generated at 2022-06-22 08:09:04.317266
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    p = NRKRadioPodkastIE('https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c')
    assert p._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'


# Generated at 2022-06-22 08:09:09.661688
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert issubclass(NRKTVSerieIE, NRKTVSerieBaseIE)
    assert issubclass(NRKTVPlaylistIE, NRKTVSerieBaseIE)
    assert issubclass(NRKTVEpisodeIE, InfoExtractor)
    assert not issubclass(NRKTVEpisodeIE, NRKTVSerieBaseIE)


# Generated at 2022-06-22 08:09:15.579506
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    """ Unit tests for NRKTVEpisodesIE class"""
    # Test 'id' value for NRKTVEpisodesIE
    episodesIE = NRKTVEpisodesIE("https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031")
    assert episodesIE._VALID_URL == "https://tv\.nrk\.no/program/episodes/[^/]+/\d+"
    assert episodesIE._ITEM_RE == r'data-episode=["\']\d{8}'

# Generated at 2022-06-22 08:09:27.431124
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Test multi page response with no inline embedded
    data = {
        '_links': {
            'next': {
                'href': '/api/v2/catalog/series/aaa/episodes?page=1&pageSize=50&orderBy=broadcastDate&order=desc&and=and'
            }
        },
        '_embedded': {
            'episodes': {
                '_links': {
                    'next': {
                        'href': '/api/v2/catalog/series/aaa/episodes?page=2&pageSize=50&orderBy=broadcastDate&order=desc&and=and'
                    }
                }
            }
        }
    }
    # This should extract next url from _links.next.href

# Generated at 2022-06-22 08:09:38.498923
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    nrkPlaylistIE = NRKPlaylistIE()
    nrkPlaylistIE._download_webpage = mock_download_page
    nrkPlaylistIE.url_result = mock_url_result
    nrkPlaylistIE.playlist_result = mock_playlist_result
    nrkPlaylistIE.extract(url)
    assert(mock_playlist_result.call_args[0][0][0]['url'] == 'nrk:MUHH48000314AA')

# Generated at 2022-06-22 08:09:44.425582
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert (NRKTVSeasonIE._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    ''')



# Generated at 2022-06-22 08:09:46.921608
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('https://www.nrk.no/')
    assert u'NRK' in ie.IE_NAME
    assert ie.IE_DESC == u'NRK'
    assert ie._VALID_URL == None
    assert ie._TESTS == []


# Generated at 2022-06-22 08:09:50.327827
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-22 08:09:54.818795
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """
    Just check that subclassing NRKPlaylistBaseIE works
    """
    class MyNRKPlaylistBaseIE(NRKPlaylistBaseIE):
        def __init__(self):
            NRKPlaylistBaseIE.__init__(self, 'foo')
    MyNRKPlaylistBaseIE()



# Generated at 2022-06-22 08:10:05.892752
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    klass = NRKRadioPodkastIE(url) # return NRKRadioPodkastIE object
    if not isinstance(klass, NRKRadioPodkastIE):
        raise AssertionError('create NRKRadioPodkastIE object error for url: %s' % url)
    url = 'https://radio.nrk.no/podcast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    klass = NRKRadioPodkastIE(url) # return NR

# Generated at 2022-06-22 08:11:16.511226
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Test init
    with pytest.raises(TypeError):
        NRKPlaylistBaseIE("")

    assert NRKPlaylistBaseIE("")._VALID_URL == r""

    NRKPlaylistBaseIE("something")._VALID_URL == r"something"

    nrk = NRKPlaylistBaseIE("test")
    assert nrk._real_extract("test")['_type'] == 'playlist'


# Generated at 2022-06-22 08:11:22.587339
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    obj = NRKTVDirekteIE()
    assert obj.IE_NAME == "nrk:direkte"
    assert obj.IE_DESC == "NRK TV Direkte and NRK Radio Direkte"
    assert obj._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 08:11:23.286376
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()

# Generated at 2022-06-22 08:11:24.773246
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE(None, None)


# Generated at 2022-06-22 08:11:32.876887
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')
    assert ie.IE_NAME == 'NRKTVDirekteIE'
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-22 08:11:42.900448
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Check that all the children classes of the NRKTVSeriesIE are in the urls_info
    # dictionary of the NRKTVSeriesIE class
    series_ie = NRKTVSeriesIE()
    children_ie = series_ie.ie_key_map.keys()

    urls_info = list(series_ie._TESTS)
    for url in urls_info:
        url = url.get('url')
        found = False
        for ie in children_ie:
            instance = ie()
            if instance.suitable(url) and url == instance._real_extract(url):
                found = True
        if not found:
            print("The url {} has no matching suitable children class".format(url))


# Generated at 2022-06-22 08:11:52.810416
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # This is a unit test to make sure all fetching of series is tested
    new_urls = []
    old_urls = []
    def resolve_url(url):
        slash = url.find('/', 8)
        return url[:slash] + '.' + url[slash:]

    for item in NRKTVSeriesIE._TESTS:
        if 'only_matching' in item:
            continue
        url = item['url']
        if url.find('nrksuper.no/') != -1:
            old_urls.append(item['url'])
            old_urls.append(url.replace('.nrksuper.no/', '.no/'))
            old_urls.append(url.replace('.nrksuper.no/', 'tv.nrk.no/'))

# Generated at 2022-06-22 08:12:02.581812
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    import json
    import re
    input_url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id, season_number, episode_number = re.match(NRKTVEpisodeIE._VALID_URL, input_url).groups()

    webpage = NRKTVPlaylistBaseIE()._download_webpage(input_url, display_id)

    info = NRKTVEpisodeIE._search_json_ld(webpage, display_id, default={})

# Generated at 2022-06-22 08:12:05.181581
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE();
    assert ie.ie_key() == 'NRKTVEpisodes';
    

# Generated at 2022-06-22 08:12:06.372008
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('nrk', 'nrk.no')


# Generated at 2022-06-22 08:14:14.558066
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie.extract("http://www.nrk.no/video/PS*150533")
    ie.extract("nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9")

# Generated at 2022-06-22 08:14:18.636907
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """Check that calling constructor of class NRKPlaylistBaseIE don't fail."""
    NRKPlaylistBaseIE('NRKPlaylistBaseIE')


# Generated at 2022-06-22 08:14:21.765124
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    def test_fail_on_nonexistent_arg(arg):
        args = {'thevideo_url': 'https://thevideo.me/embed-test-video-id',
                'title': 'test_title'}
        args[arg] = None
        with pytest.raises(TypeError):
            NRKTVEpisodesIE(args)

    test_fail_on_nonexistent_arg('title')
    test_fail_on_nonexistent_arg('thevideo_url')

# Generated at 2022-06-22 08:14:28.987617
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        NRKTVSeasonIE(None, 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')
    except TypeError:
        assert False, "Unexpected exception"
    try:
        NRKTVSeasonIE(None, 'https://tv.nrk.no/serie/spangas/sesong/1')
    except TypeError:
        assert False, "Unexpected exception"



# Generated at 2022-06-22 08:14:30.623816
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test_inst = NRKTVEpisodesIE()
    assert(test_inst._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)')

# Generated at 2022-06-22 08:14:35.345108
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvserieBaseIE = NRKTVSerieBaseIE();
    assert nrktvserieBaseIE._ASSETS_KEYS == ('episodes', 'instalments',)
    assert nrktvserieBaseIE._catalog_name('podcast') == 'podcast'
    assert nrktvserieBaseIE._catalog_name('serie') == 'series'
    assert nrktvserieBaseIE._catalog_name('podkast') == 'podcast'
    assert nrktvserieBaseIE._catalog_name('radio') == 'series'
    assert nrktvserieBaseIE._catalog_name('drama') == 'series'


# Generated at 2022-06-22 08:14:40.308491
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    kube = 'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/%s'
    query = '?page=search&q=&mediaId=%s'
    testurls = [
        (kube   % '14099', '6021'),
        (kube   % '19355', '8140'),
        (kube   % '12509', '6177'),
        ('https://www.nrk.no/skole/' + query % '14099', '6021'),
        ('https://www.nrk.no/skole/' + query % '19355', '8140'),
        ('https://www.nrk.no/skole/' + query % '12509', '6177'),
        ]

# Generated at 2022-06-22 08:14:46.067747
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie = NRKIE(NRKBaseIE())
    assert ie.IE_NAME == ie.__class__.IE_NAME
    assert ie.ie_key() == ie.__class__.ie_key()
    assert ie._VALID_URL == ie.__class__._VALID_URL


# Generated at 2022-06-22 08:14:46.990497
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist = NRKPlaylistIE()


# Generated at 2022-06-22 08:14:55.989712
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    """
    This function is used to test the constructor of class NRKTVSerieBaseIE
    """