

# Generated at 2022-06-24 12:58:03.280580
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    TEST_URL = 'https://tv.nrk.no/serie/groenn-glede'
    expected_playlist_mincount = 90
    _NRKTVSeriesIE = NRKTVSeriesIE.suitable(TEST_URL)
    if not _NRKTVSeriesIE:
        expected_playlist_mincount = 0
        raise "Invalid test setup, is it really a new format page?"

    pl_count = 0
    for _, __, entries in _NRKTVSeriesIE()._real_extract(TEST_URL):
        pl_count = pl_count + len(entries)
    assert pl_count == expected_playlist_mincount

# Generated at 2022-06-24 12:58:09.309871
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from .nrk import NRKTVSeriesIE
    import unittest
    # First make sure one of the URLs in _TESTS is actually working.
    assert NRKTVSeriesIE._extract_entries(
        NRKTVSeriesIE._call_api(
            'tv/catalog/series/groenn-glede',
            'groenn-glede', 'serie',
            query={'embeddedInstalmentsPageSize': 50}))

    suite = unittest.TestLoader().loadTestsFromTestCase(NRKTVSeriesIE)
    unittest.TextTestRunner(verbosity=2).run(suite)
    return suite



# Generated at 2022-06-24 12:58:16.025065
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    """
    Basic test: Instantiation of NRKTVEpisodesIE
    """
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == "NRKTVEpisodes"
    assert ie.IE_NAME == "NRKTVEpisodes"
    assert ie.IE_DESC == "NRKTVEpisodes"
    assert ie.valid_url(
        'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031') == True

# Generated at 2022-06-24 12:58:21.292480
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk_direkte_IE = NRKTVDirekteIE()
    assert nrk_direkte_IE.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert nrk_direkte_IE.INFO_URL == 'https://nrk.no/serum/gateway/streams/%s'
    assert nrk_direkte_IE.LIVE_URL == 'https://v8.psapi.nrk.no/channels/%s/streams/hls-live'
    assert nrk_direkte_IE.AGE_LIMIT == 6

# Generated at 2022-06-24 12:58:21.735078
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    pass



# Generated at 2022-06-24 12:58:28.018709
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_NAME == 'nrkskole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie.IE_DESC == 'NRK Skole'

# Generated at 2022-06-24 12:58:37.424935
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.nrk import NRKTVEpisodeIE
    from youtube_dl.utils import *
    from json import load
    from os.path import join

    # Create the test YoutubeDL object

# Generated at 2022-06-24 12:58:43.907715
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """
    Basic test case for NRKPlaylistBaseIE.
    """
    pb_ie = NRKPlaylistBaseIE()
    pb_ie._ITEM_RE = r'Rutetabellen er vedlikeholdt av Norgesbuss. For\s*spørsmål\s*kontakt\s*Norgesbuss.[\s\S]*?</html>'
    pb_ie._real_extract('http://tv.nrk.no/serie/rutetabellen')


# Generated at 2022-06-24 12:58:44.799029
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()

# Generated at 2022-06-24 12:58:52.989454
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    song_id = "123"
    url = 'https://someNRKPlaylistBaseIE'
    playlist_id = '456'
    playlist_title = "some playlist_title"
    playlist_description = "some playlist_description"

    class fake_nrk(NRKPlaylistBaseIE):
        _VALID_URL = r'(?P<id>.*)'
        _ITEM_RE = r'.*'
        IE_NAME = 'nrk'

        def _real_extract(self, url):
            return self.playlist_result(
                [self.url_result(song_id)], playlist_id, playlist_title,
                playlist_description)

    my_playlist = fake_nrk()
    my_playlist._downloader = FakeYDL()
    playlist = my_playlist._real_

# Generated at 2022-06-24 12:58:53.789813
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE(None, None)


# Generated at 2022-06-24 12:58:59.370123
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    class _Test_NRKTVDirekteIE(NRKTVDirekteIE):
        def _real_extract(self, url):
            raise NotImplementedError

    ie = _Test_NRKTVDirekteIE()
    assert ie.IE_NAME == 'NRKTV'



# Generated at 2022-06-24 12:59:04.448607
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    site, serie_kind, series_id = re.match(NRKTVSeriesIE._VALID_URL, 'http://nrksuper.no/serie/labyrint').groups()
    assert site == 'nrksuper.no'
    assert serie_kind == 'serie'
    assert series_id == 'labyrint'

# Generated at 2022-06-24 12:59:11.958576
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    __import__('sys').modules['nrktvie'] = __import__('nrktv')
    __import__('sys').modules['nrktvepisodeie'] = __import__('nrktv')
    __import__('sys').modules['nrktvseasonie'] = __import__('nrktv')
    __import__('sys').modules['nrktvliveie'] = __import__('nrktv')
    __import__('sys').modules['nrktvsearchie'] = __import__('nrktv')
    __import__('sys').modules['nrktvplaylistie'] = __import__('nrktv')
    __import__('sys').modules['nrkradiopodkastie'] = __import__('nrktv')
    for _ in NRKTVSeriesIE._TESTS:
        assert NRKTV

# Generated at 2022-06-24 12:59:21.386825
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE({})
    for asset_key in NRKTVSerieBaseIE._ASSETS_KEYS:
        test_data = {
            '_embedded': {
                asset_key: {
                    '_links': {
                        'next': {
                            'href': '/test_url',
                        }
                    }
                }
            },
            '_links': {
                'next': {
                    'href': '/test_url',
                }
            },
            'test_key': 'test_value'
        }
        assert ie._entries(test_data, 'test_display_id') is not None

# Generated at 2022-06-24 12:59:22.816388
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert issubclass(NRKPlaylistBaseIE, InfoExtractor)



# Generated at 2022-06-24 12:59:34.335899
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    from .nrktv import NRKTVIE
    from .nrksport import NRKSportIE
    from .nrkno import NRKNoIE
    from .nrkbeta import NRKEpisodeIE
    from .nrkbeta import NRKChapterIE
    from .nrkbeta import NRKPlaylisterIE
    from .nrk import NRKPlaylistBaseIE
    from .nrktvepisodes import NRKTVEpisodesIE
    from .nrktvseason import NRKTVSeasonIE

    def test_class_method_suitable_with_instance_of_NRKTVIE(nrk_skole_ie):
        assert not nrk_skole_ie.suitable(NRKTVIE())


# Generated at 2022-06-24 12:59:38.200376
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from ytdl.nrk import NRKTVIE
    assert NRKTVIE.IE_NAME == 'nrktv'
    ie = NRKTVIE()
    assert ie._VALID_URL == NRKTVIE._VALID_URL
    assert ie.IE_NAME == NRKTVIE.IE_NAME
    assert ie.IE_DESC == NRKTVIE.IE_DESC
    assert ie.ie_key() == NRKTVIE.ie_key()
    assert ie.ie_key() == 'nrktv'


# Generated at 2022-06-24 12:59:39.265222
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == 'NRK'

# Generated at 2022-06-24 12:59:40.247525
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('NRK', {})


# Generated at 2022-06-24 12:59:46.718731
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from xml.dom.minidom import parseString
    from io import BytesIO
    from json import loads
    from pycaption import CaptionConverter

    def parse_ttml(text):
        return CaptionConverter().read(BytesIO(parseString(text).toxml('utf-8')), format='ttml')

    playlist_item_json = loads(test_NRKTVIE_playlist_xml.content)
    playlist_item_captions = parse_ttml(playlist_item_json['content'][0]['playlistItem']['captions'])
    playlist_item_playlist = parse_ttml(playlist_item_json['content'][0]['playlistItem']['playlist'])

# Generated at 2022-06-24 12:59:47.782573
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie._match_id('nrk:clip/150533')



# Generated at 2022-06-24 12:59:56.832982
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    class DummyIE(NRKTVSeriesIE):
        class _API(object):
            @staticmethod
            def _parse_json(data):
                return json.loads(data)
            @staticmethod
            def extract_subtitles(subtitle_url, video_id):
                return 'subtitles'
            @staticmethod
            def get_subtitles(subtitle_url, video_id, lang, auto_subtitles=False):
                return [{'ext': 'ttml', 'data': 'subtitles'}]
            @staticmethod
            def _build_subtitle(subtitle):
                return 'subtitles'

    NRKTVSeriesIE._API = DummyIE._API

# Generated at 2022-06-24 13:00:06.166960
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    url = 'https://tv.nrk.no/serie/anno/KMTE38000115'
    test_obj = NRKTVSerieBaseIE(NRKTVSerieBaseIE._create_get_urls_regex(url))
    assert test_obj._VALID_URL == 'https?://tv\\.nrk\\.no/serie/anno/KMTE38000115'


# Generated at 2022-06-24 13:00:10.643904
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE('NRKTVEpisodes', 'NRK')
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 13:00:17.013005
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    m_init = mock.Mock()
    m_init.return_value = None
    m_subsubcls = mock.Mock()
    m_subsubcls.init = m_init
    m_subsubcls.return_value = m_subsubcls
    m_subcls = mock.Mock()
    m_subcls.return_value = m_subsubcls
    m_cls = mock.Mock()
    m_cls.sub = m_subcls
    m_cls.sub.sub = m_subsubcls
    m_cls.sub.sub.sub = m_subsubcls
    m_cls.sub.sub.sub.sub = m_subsubcls

# Generated at 2022-06-24 13:00:19.381433
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE.ie_key()
    inst = ie(NRKTVIE.ie_key(), NRKTVIE)
    assert inst.get_info('https://tv.nrk.no/serie/lindmo/2018/MUHU11006318/avspiller')

# Generated at 2022-06-24 13:00:28.900837
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():

    # Construe NRKTVSeriesIE
    result_nrktvseries_ie = NRKTVSeriesIE(NRKTVSeriesIE.ie_key())
    assert type(result_nrktvseries_ie) is NRKTVSeriesIE
    assert result_nrktvseries_ie._VALID_URL == r'https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)'



# Generated at 2022-06-24 13:00:32.075241
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test for empty id
    test_url='https://tv.nrk.no/program/episodes/nytt-paa-nytt/'
    assert 'Empty id:' in str(NRKTVEpisodesIE(NRKTVEpisodesIE.suitable, test_url))
    # Test for valid id
    test_url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert len(test_url) > 0



# Generated at 2022-06-24 13:00:37.763810
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    """Test constructor of class NRKBaseIE."""
    ie = NRKBaseIE()
    # in the following call, I don't think _extract_nrk_formats will be called
    # because _download_json does not raise an error
    result = ie._call_api('psapi/', 'someid')
    assert result['title'] == 'NRK API'



# Generated at 2022-06-24 13:00:40.475301
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    site = NRKTVIE()
    assert site.IE_NAME == 'NRKTVIE'
    assert site.IE_DESC == 'NRK TV and NRK Radio'

# Test cases for method NRKTVIE.suitable()
# Note that these cases are also listed in the file test_suitable.py,
# but the test method here does not need to be identical to the one in the parent class.

# Generated at 2022-06-24 13:00:42.101770
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert(NRKPlaylistBaseIE(None) is not None)


# Generated at 2022-06-24 13:00:44.987404
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(None)
    assert ie.is_NRKTVSerieBase(None) is False
    assert ie.is_NRKTVSerieBase('https://tv.nrk.no/serie/') is True
    assert ie.is_NRKTVSerieBase('https://tv.nrk.no/podkast/') is True
    assert ie.is_NRKTVSerieBase('https://tv.nrk.no/program/') is False


# Generated at 2022-06-24 13:00:57.685030
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    print(NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099'))
    print(NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'))
    print(NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=subjects'))
    print(NRKSkoleIE.suitable('https://www.nrk.no/skole/'))
    print(NRKSkoleIE.suitable('https://www.nrk.no/skole/illustrasjoner'))

# Generated at 2022-06-24 13:01:01.626135
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    Globals._initialize_cookies()
    Globals.user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0'
    Globals.storage_dir = '.'
    ie = NRKTVIE(NRKTVIE.create_ie())
    return ie

# Generated at 2022-06-24 13:01:03.901902
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE('NRKTVSerieBaseIE', 'NRK TV')


# Generated at 2022-06-24 13:01:10.242568
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # pylint: disable=redefined-outer-name
    from .nrktv import NRKTVSeasonIE

    assert_raises(TypeError, NRKTVSeasonIE)
    assert_raises(ValueError, NRKTVSeasonIE, 'foo')

    NRKTVSeasonIE('http://tv.nrk.no/serie/spangas/sesong/1/episode/2',
                  lambda x: None)

# Generated at 2022-06-24 13:01:12.710347
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    try:
        unit_test = NRKPlaylistIE()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-24 13:01:16.584176
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    """Test: valid url produces InfoExtractor object"""
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    ie_object = NRKRadioPodkastIE(url)
    assert isinstance(ie_object, InfoExtractor)

# Generated at 2022-06-24 13:01:21.053501
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    url = 'https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#'
    assert ie._match_id(url) == 'NPUB21019315'



# Generated at 2022-06-24 13:01:23.142721
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert ie._ITEM_RE == r'data-episode=["\']1126460'

# Generated at 2022-06-24 13:01:31.155425
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://radio.nrk.no/serie/dickie-dick-dickens')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/backstage')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/lindmo')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/det-beste-av-radio-norge')

# Generated at 2022-06-24 13:01:44.080971
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    from datetime import datetime
    from .nrk import NRKPlaylistBaseIE
    url = 'https://tv.nrk.no/serie/%c3%85pen+post'
    ie_nrkplaylistbase = NRKPlaylistBaseIE(url, datetime.now())
    assert str(ie_nrkplaylistbase)  == 'NRKPlaylistBaseIE(url=https://tv.nrk.no/serie/%c3%85pen+post,time=2020-04-07 11:11:23.562953)'
    assert str(repr(ie_nrkplaylistbase))  == 'NRKPlaylistBaseIE(url=https://tv.nrk.no/serie/%c3%85pen+post,time=2020-04-07 11:11:23.562953)'

# Generated at 2022-06-24 13:01:45.319356
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktvepisodesie = NRKTVEpisodesIE()
    assert nrktvepisodesie.get_class() == 'NRKTVEpisodesIE'

# Generated at 2022-06-24 13:01:45.985917
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(NRKTVIE)

# Generated at 2022-06-24 13:01:54.543485
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Create an instance of NRKBaseIE
    NRKBaseIE_object = NRKBaseIE()
    # Check its attributes
    msg = 'Object wrong attributes'
    assert (NRKBaseIE_object._GEO_COUNTRIES == ['NO']), msg
    assert (NRKBaseIE_object._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''), msg
    # Run _extract_

# Generated at 2022-06-24 13:02:01.271412
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://www.nrk.no/nett-tv/toppsaker/1.7856134'
    ie = NRKTVPlaylistIE()
    # Test invalid URL
    with pytest.raises(ExtractorError):
        ie.suitable(url)
    # Test valid URL
    assert ie.suitable(url) is True


# Generated at 2022-06-24 13:02:03.424098
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    try:
        NRKTVEpisodeIE()
    except Exception:
        raise("Failed NRKTVEpisodeIE test")


# Generated at 2022-06-24 13:02:05.114798
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Will raise exception if the object cannot be constructed from the inherited constructor of class NRKRadioPodkastIE
    NRKRadioPodkastIE()

# Unit tests for _extract_entries function of class NRKTVSeasonIE

# Generated at 2022-06-24 13:02:05.905289
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()



# Generated at 2022-06-24 13:02:07.334423
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Testing class constructor
    assert isinstance(NRKPlaylistBaseIE(), InfoExtractor)



# Generated at 2022-06-24 13:02:10.169366
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE()._match_id('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449') == 'rivertonprisen-til-karin-fossum-1.12266449'


# Generated at 2022-06-24 13:02:11.920259
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    """ If constructor works then this test will pass """
    ie = NRKBaseIE()
    assert ie != None



# Generated at 2022-06-24 13:02:13.505651
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test that the constructor exists
    NRKTVDirekteIE()

# Generated at 2022-06-24 13:02:15.962222
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from . import NRKIE
    NRKTVIE_init = NRKTVIE(NRKIE)
    assert NRKTVIE_init.ie == NRKIE


# Generated at 2022-06-24 13:02:29.132272
# Unit test for constructor of class NRKTVEpisodeIE

# Generated at 2022-06-24 13:02:29.701651
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    _NRKSkoleIE()



# Generated at 2022-06-24 13:02:38.293544
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """This unit test uses the data from the first test
    in the _TESTS list.
    """
    nrk_episode_info = NRKTVEpisodeIE._real_extract(NRKTVEpisodeIE(), NRKTVEpisodeIE._TESTS[0]['url'])
    # The data is supposed to match the data in _TESTS.
    assert nrk_episode_info == NRKTVEpisodeIE._TESTS[0]['info_dict']

# Generated at 2022-06-24 13:02:40.845863
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """
    Constructor test.
    """
    loader = NRKTVEpisodeIE
    ie = loader(loader)



# Generated at 2022-06-24 13:02:45.947018
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    instance = NRKTVEpisodeIE('nrk:%s' % 'KMTE50001317')
    result = instance.result('nrk:%s' % 'KMTE50001317')
    assert result['id'] == 'KMTE50001317'
    assert result['url'] == 'nrk:%s' % 'KMTE50001317'
    assert result['_type'] == 'url'

# Generated at 2022-06-24 13:02:52.790048
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    from .nrk import NRKTVSerieIE
    from .nrk import NRKRadioSerieIE
    if NRKTVSerieIE.__module__ == 'youtube_dl.extractor.nrk':
        return
    # NRKTVSerieIE, NRKRadioSerieIE are still not subclass of NRKTVSerieBaseIE
    # so we need to fix that before testing it
    NRKTVSerieIE.__bases__ = (NRKTVSerieBaseIE,)
    NRKRadioSerieIE.__bases__ = (NRKTVSerieBaseIE,)
    # Testing NRKTVSerieBaseIE
    ie = NRKTVSerieBaseIE('nrk:a')
    # extract_assets_key
    assert ie._extract_assets_key(None) is None
    assert ie._extract_

# Generated at 2022-06-24 13:02:55.154173
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # constructor of class NRKTVSeriesIE should work
    nrksuper_series_ie = NRKTVSeriesIE("NRKTVSeriesIE", {})



# Generated at 2022-06-24 13:02:56.455917
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    instance = NRKTVEpisodesIE()
    assert instance


# Generated at 2022-06-24 13:03:08.139775
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    import sys
    # If a parameter other than 'list' is specified,
    # it is assumed that a url is specified.
    url = 'list'
    if len(sys.argv) > 1:
        url = sys.argv[1]

    # Create an instance of class NRKTVSeriesIE.
    # This class inherits from YoutubePlaylistIE, and
    # therefore must provide the ie_key and ie
    # (Information Extractor) attribute,
    # so that YoutubePlaylistIE can identify it.
    class MyNRKTVSeriesIE(NRKTVSeriesIE):
        _VALID_URL = r'(.*)'

# Generated at 2022-06-24 13:03:21.548461
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk_ie = NRKBaseIE('http://tv.nrk.no/serie/alkohol/sesong/1/episode/2/avspiller')
    assert nrk_ie.IE_NAME == 'NRK'
    assert nrk_ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.(?:no|no2)/(?:[^?]+?/\d+/\d+|serie/\w+/sesong/(\d+)/episode/(\d+))'
    assert nrk_ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-24 13:03:24.067329
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Constructor()
    ie = NRKTVIE()
    assert ie.ie_key() == 'NRKTV'


# Generated at 2022-06-24 13:03:27.748865
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
	test_STR = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
	temp_ie = NRKTVEpisodesIE('test', test_STR)
	assert temp_ie.ie_key() == 'NRKTVEpisodes'
	assert temp_ie._VALID_URL == NRKTVEpisodesIE._VALID_URL
	assert temp_ie._ITEM_RE == NRKTVEpisodesIE._ITEM_RE

# Generated at 2022-06-24 13:03:30.637685
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrkSkole = NRKSkoleIE()
    assert isinstance(nrkSkole, NRKSkoleIE)
    assert nrkSkole.ie_key() == 'NRKSkole'


# Generated at 2022-06-24 13:03:37.177062
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE()
    ie.url = url
    assert ie.domain == 'radio.nrk.no'
    assert ie.ie_key() == 'NRKRadioPodkast'
    assert ie.suitable(url), ie.suitable(url) == True
    assert ie.video_id == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

# Generated at 2022-06-24 13:03:43.638729
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    nrktvseriesie = NRKTVSeriesIE()
    assert nrktvseriesie._VALID_URL == (
        r'https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)')
    assert nrktvseriesie.suitable(url)
    assert not nrktvseriesie.IE_NAME == 'NRKTV:series'
    assert nrktvseriesie.IE_NAME == 'NRKTV'
    assert nrktvseriesie.ie_key() == 'NRKTV'
    assert not nr

# Generated at 2022-06-24 13:03:46.784355
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    NRKRadioPodkastIE()._real_extract(url)

# Generated at 2022-06-24 13:03:52.999334
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert(NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/41'))
    assert(not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/dagsrevyen/sesong/1/episode/41/15'))
    assert(not NRKTVSeriesIE.suitable('https://tv.nrk.no/dagsrevyen/sesong/1/episode/41/15'))



# Generated at 2022-06-24 13:03:58.633386
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # pylint:disable=protected-access
    nrk = NRKBaseIE('nrk')
    nrk_no = NRKBaseIE('nrk:no')
    nrk_nom = NRKBaseIE('nrk:nom')
    assert nrk._GEO_COUNTRIES == nrk_no._GEO_COUNTRIES == nrk_nom._GEO_COUNTRIES == ['NO']
    # pylint:enable=protected-access



# Generated at 2022-06-24 13:04:00.235345
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test the constructor
    # Test if it raises on an empty url
    with pytest.raises(TypeError):
        ie = NRKTVEpisodesIE('')



# Generated at 2022-06-24 13:04:02.226930
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    input_url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    obj = NRKTVSeasonIE()
    assert obj.suitable(input_url) == True


# Generated at 2022-06-24 13:04:03.985509
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRK', None, None)
    assert ie.IE_NAME == 'NRK'

# Generated at 2022-06-24 13:04:04.992024
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    instance = NRKRadioPodkastIE()
    assert instance is not None


# Generated at 2022-06-24 13:04:06.860248
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE()._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'


# Generated at 2022-06-24 13:04:14.182826
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    ie = NRKTVEpisodeIE()
    webpage = ie._download_webpage(url, 'MUHH36005220')
    info = ie._search_json_ld(webpage, 'MUHH36005220', default={})
    nrk_id = info.get('@id') or ie._html_search_meta(
            'nrk:program-id', webpage, default=None) or ie._search_regex(
            r'data-program-id=["\'](%s)' % NRKTVIE._EPISODE_RE, webpage,
            'nrk id')

# Generated at 2022-06-24 13:04:14.619843
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    pass



# Generated at 2022-06-24 13:04:16.506596
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    [NRKTVSerieBaseIE(NRKTVIE())._extract_entries([])]

# Generated at 2022-06-24 13:04:28.975355
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    test_url = 'https://nrksuper.no/serie/labyrint'
    # Test if constructor of NRKTVSeriesIE raises exception when non existing URL
    # is passed as parameter
    try:
        NRKTVSeriesIE(NRKTVSeriesIE.ie_key(), test_url)
        pytest.fail()
    except ExtractorError:
        pass
    NRKTVSeriesIE(NRKTVSeriesIE.ie_key(), urlsplit(test_url).path)
    # Test if constructor of NRKTVSeriesIE raises exception when other IEs URL
    # is passed as parameter
    try:
        NRKTVSeriesIE(NRKTVIE.ie_key(), test_url)
        pytest.fail()
    except ExtractorError:
        pass

# Generated at 2022-06-24 13:04:31.220420
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE(NRKRadioPodkastIE._create_get_video_id_object('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'))


# Generated at 2022-06-24 13:04:41.080035
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE.suitable(NRKTVEpisodesIE._VALID_URL) == True
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/mesternes-mester-junior/69407') == True
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/mesternes-mester-junior/sesong/1') == False
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/mesternes-mester-junior/sesong/1/episode/2/avspiller') == False

# Generated at 2022-06-24 13:04:53.770015
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    input_url = "https://tv.nrk.no/serie/backstage/sesong/1"
    input_id = "backstage/1"
    input_playlist_mincount = 30
    input_title = "Sesong 1"
    obj = NRKTVSeasonIE()
    assert obj._VALID_URL == input_url
    assert obj._TESTS.get('url') == input_url
    assert obj._TESTS[0].get('url') == input_url
    assert obj._TESTS[0].get('info_dict').get('id') == input_id
    assert obj._TESTS[0].get('playlist_mincount') == input_playlist_mincount
    assert obj._TESTS[0].get('info_dict').get('title') == input_title



# Generated at 2022-06-24 13:04:59.987617
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r"""(?:nrk:|https?://(?:(?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|v8[-.]psapi\.nrk\.no/mediaelement/))(?P<id>[^?#&]+)"""

# Generated at 2022-06-24 13:05:03.631404
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE(NRKTVDirekteIE._VALID_URL, NRKTVDirekteIE.IE_NAME)
    assert ie.name == 'NRKTVDirekteIE'
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_key(ie) == 'NRKTVDirekte'

# Generated at 2022-06-24 13:05:11.504723
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    def get_url_from_regex(url):
        return re.match(NRKTVEpisodeIE._VALID_URL, url).groups()

    assert get_url_from_regex('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')  == ('hellums-kro/sesong/1/episode/2', '1', '2')
    assert get_url_from_regex('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')  == ('backstage/sesong/1/episode/8', '1', '8')


# Generated at 2022-06-24 13:05:19.921466
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()

    kwargs = {
        'url': 'https://tv.nrk.no/serie/anno/kmte50001317/sesong-3/episode-13',
        'info_dict': {
            'id': 'KMTE50001317',
            'ext': 'mp4',
            'title': 'Anno - 13. episode',
            'description': 'md5:11d9613661a8dbe6f9bef54e3a4cbbfa',
            'duration': 2340,
            'series': 'Anno',
            'episode': '13. episode',
            'season_number': 3,
            'episode_number': 13,
            'age_limit': 0
        },
    }

    assert ie.suitable(kwargs['url'])

# Generated at 2022-06-24 13:05:30.701033
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test if direct stream url is constructed properly
    assert_equal(
        NRKTVDirekteIE._get_direct_stream_url('NRK1', 'http://test.test/test.m3u8'),
        'http://test.test/test.m3u8'
    )

    assert_equal(
        NRKTVDirekteIE._get_direct_stream_url('NRK1', 'http://test.test/test.smil'),
        'http://test.test/test.smil/playlist.m3u8'
    )

    # Test if url is not changed if url does not end with '.smil'

# Generated at 2022-06-24 13:05:33.333326
# Unit test for constructor of class NRKIE
def test_NRKIE():
    try:
        # pass
        NRKIE.suitable (object())
    except:
        print ("\n Okay I am in trouble !\n")


# Generated at 2022-06-24 13:05:38.205367
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist = NRKPlaylistIE()
    assert playlist.suitable(url)

# Generated at 2022-06-24 13:05:43.547620
# Unit test for constructor of class NRKIE
def test_NRKIE():
    try:
        NRKIE()
    except Exception as e:
        try:
            assert not 'NRKBaseIE' in str(e)
        except AssertionError as ae:
            print("\nException from NRKIE constructor:\n\n%s" % ae)
        raise


# Generated at 2022-06-24 13:05:48.091007
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.tv_id is None
    assert ie.url is None
    assert ie.playlist_id is None
    assert ie.playlist_title is None
    assert ie.playlist_description is None
    assert ie.playlist_is_daily is False
    assert ie.added_by is None
    ents = ie.entries
    assert len(ents) == 0
    assert isinstance(ents, list)

# Generated at 2022-06-24 13:05:49.541114
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE()

# Generated at 2022-06-24 13:06:02.882666
# Unit test for constructor of class NRKIE

# Generated at 2022-06-24 13:06:04.666851
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE()
    except Exception:
        assert False
    assert True



# Generated at 2022-06-24 13:06:08.283395
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    ie.search_ie_key = lambda x : None
    ie.json_data = lambda x : None
    assert ie.search_ie_key is None
    assert ie.json_data is None
    assert isinstance(ie, InfoExtractor)
    return

# Generated at 2022-06-24 13:06:10.397203
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    for constructor in [NRKTVSeriesIE, NRKTVSeasonIE]:
        assert constructor.ie_key() == NRKTVIE.ie_key()

# Generated at 2022-06-24 13:06:12.559943
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE(NRKTVSeriesIE.ie_key(), NRKTVSeriesIE._VALID_URL)



# Generated at 2022-06-24 13:06:15.145719
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    return NRKPlaylistBaseIE()



# Generated at 2022-06-24 13:06:16.228759
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE



# Generated at 2022-06-24 13:06:18.731915
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrktvseriesie = NRKTVSeriesIE()
    assert isinstance(nrktvseriesie, NRKTVSeriesIE)


# Generated at 2022-06-24 13:06:20.671727
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    obj = NRKTVSeasonIE('NRKTVSeasonIE', None, None, None)
    assert obj._ASSETS_KEYS == ('episodes', 'instalments',)

# Generated at 2022-06-24 13:06:26.873778
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert re.match(NRKTVSeasonIE._VALID_URL, 'https://tv.nrk.no/serie/backstage/sesong/1').groups() == ('tv', 'serie', 'backstage', '1', None)
    assert re.match(NRKTVSeasonIE._VALID_URL, 'https://radio.nrk.no/serie/dagsnytt/sesong/201509').groups() == ('radio', 'serie', 'dagsnytt', '201509', None)

# Generated at 2022-06-24 13:06:28.404790
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('nrk', 'nrk.no', 'https://www.nrk.no/video/')


# Generated at 2022-06-24 13:06:33.463390
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    from youtube_dl.extractor import YoutubeDL
    from youtube_dl.extractor import gen_extractors
    extractors = gen_extractors()
    for i in extractors:
        extractor = i()
        if extractor.IE_NAME == 'nrksupertv':
            break
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    with ydl:
        for x in ydl.extract_info('https://tv.nrk.no/serie/backstage/sesong/1/episode/8', download=False):
            pass
        #print(x)
        assert x['id'] == 'MSUI14000816'

# Generated at 2022-06-24 13:06:46.359328
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Setup
    url = 'https://tv.nrk.no/direkte/nrk1'
    nrktvdirekte_IE = NRKTVDirekteIE(url)
    expected_name = "NRK TV Direkte and NRK Radio Direkte"
    expected_description = "Live and on demand radio and TV from Norway's public broadcaster."
    expected_suitable = False
    expected_ie_key = "NRKTVDirekte"
    expected_webpage_url = "https://tv.nrk.no/direkte/nrk1"
    expected_extractor_key = "nrktvdirekte"

    # Test
    assert nrktvdirekte_IE.name == expected_name

# Generated at 2022-06-24 13:06:49.956961
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Test instantiation of class NRKIE
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'


# Generated at 2022-06-24 13:06:51.734386
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    unit = NRKTVEpisodesIE()
    assert unit.__class__.__name__ == 'NRKTVEpisodesIE'

# Generated at 2022-06-24 13:06:57.633696
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE(None)

    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-24 13:06:58.206328
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    pass

# Generated at 2022-06-24 13:06:59.908038
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    with pytest.raises(TypeError):
        NRKTVSeriesIE()

# Generated at 2022-06-24 13:07:03.818910
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'nrk:14099'
    try:
        NRKSkoleIE(url)

    except:
        print("The constructor of class NRKSkoleIE is wrong!")
        assert False



# Generated at 2022-06-24 13:07:09.194756
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    test_obj = NRKTVIE('NRKTVIE', 'nrk', 'NRK TV and NRK Radio')
    assert test_obj._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % test_obj._EPISODE_RE

# Generated at 2022-06-24 13:07:16.651675
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    obj = NRKTVSerieBaseIE()
    assert obj._ASSETS_KEYS == ('episodes', 'instalments',)
    assert obj._catalog_name('podcast') == 'podcast'
    assert obj._catalog_name('serie') == 'series'
    assert isinstance(obj._extract_assets_key({'episodes': 'episodes'}), compat_str)
    assert obj._extract_assets_key({'instalments': 'instalments'}) == 'instalments'


# Generated at 2022-06-24 13:07:21.690104
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Test for private method _extract_description().
    for url, expected in [
        ('https://tv.nrk.no/programoversikt/N/Norge_rundt/Norge_rundt/NYTT/12_november',
            'Norge rundt'),
        ('https://radio.nrk.no/serie/distriktsprogram-troms', 'Distriktsprogram Troms'),
    ]:
        playlist_ie = NRKPlaylistBaseIE(
            downloader=FakeYoutubeDL(),
            params={'url': url,}
        )
        assert playlist_ie._extract_description(playlist_ie._download_webpage(url, None)) == expected, expected


# Generated at 2022-06-24 13:07:31.275080
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.GEO_COUNTRIES == ['NO']
    assert ie.CDN_REPL_REGEX == r'(?x)://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'


# Generated at 2022-06-24 13:07:33.507282
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteIE = NRKTVDirekteIE(NRKTVDirekteIE.ie_key())



# Generated at 2022-06-24 13:07:36.906664
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    tmpdir = mkdtemp()
    input_dir = os.path.dirname(os.path.abspath(__file__))
    input_file = os.path.join(input_dir, 'nrk_direkte.html')
    with open(input_file) as f:
        _NRKTVDirekteIE_extract_video_url(f.read(), 'nrk1')
    rmtree(tmpdir)

# Extract video_url from html for class NRKTVDirekteIE

# Generated at 2022-06-24 13:07:40.766837
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank'
    assert isinstance(NRKTVSeriesIE.test(), list)
    assert len(NRKTVSeriesIE.test_urls(url)) > 0
    assert NRKTVSeriesIE.ie_key() == 'nrk:tv:series'
    assert NRKTVSeriesIE.suitable(url)

# Generated at 2022-06-24 13:07:47.813130
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-24 13:07:53.557889
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'https://www.nrk.no/ostlandssendingen/ei-jente-for-daglig-1.12351261'
    item_re = NRKPlaylistIE._ITEM_RE
    result = re.findall(item_re, url)
    assert result == ['MJOH51900013K']
    test_ie = NRKPlaylistIE(url)
    assert test_ie._match_id(url) == 'ei-jente-for-daglig-1.12351261'
    webpage = test_ie._download_webpage(url, test_ie._match_id(url))
    assert test_ie._extract_title(webpage) == 'Ei jente for daglig'