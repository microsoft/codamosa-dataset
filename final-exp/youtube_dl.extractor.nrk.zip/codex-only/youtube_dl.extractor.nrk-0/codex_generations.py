

# Generated at 2022-06-24 12:57:59.598110
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    obj = NRKTVDirekteIE()
    assert obj.IE_NAME == 'nrk:tv:direkte'

# Generated at 2022-06-24 12:58:00.612930
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie != None

# Generated at 2022-06-24 12:58:05.297373
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Test creating an instance of NRKBaseIE
    test_obj = NRKBaseIE()._make_valid_url('https://tv.nrk.no/serie/bla/1234')
    assert test_obj.startswith('https://psapi.nrk.no/mediaelement')


# Generated at 2022-06-24 12:58:09.812321
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    """Constructor of class NRKPlaylistIE should return an object with expected fields."""
    NRKPlaylistIE_ = NRKPlaylistIE()
    assert_equal(NRKPlaylistIE_.ie_key(), 'NRKPlaylist')
    assert_equal(NRKPlaylistIE_.host, 'nrk.no')



# Generated at 2022-06-24 12:58:15.203015
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_ie = NRKPlaylistIE()
    input_url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    result = nrk_playlist_ie.suitable(input_url)
    assert result is True, 'NRKPlaylistIE test for constructor failed'



# Generated at 2022-06-24 12:58:19.798248
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from .nrktv import NRKTVIE

    test_video = 'https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13'
    video_id = 'KMTE50001317'
    info = {
            'id': 'KMTE50001317',
            'ext': 'mp4',
            'title': 'Anno - 13. episode',
            'description': 'md5:11d9613661a8dbe6f9bef54e3a4cbbfa',
            'duration': 2340,
            'series': 'Anno',
            'episode': '13. episode',
            'season_number': 3,
            'episode_number': 13,
            'age_limit': 0,
        }

# Generated at 2022-06-24 12:58:22.768065
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-24 12:58:24.271958
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert isinstance(ie, NRKTVIE)
    assert ie.IE_NAME == 'NRK TV and NRK Radio'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'

# Generated at 2022-06-24 12:58:24.928959
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()


# Generated at 2022-06-24 12:58:25.892462
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.ie_key() == 'NRKTV:Direkte'


# Generated at 2022-06-24 12:58:29.098712
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    obj_NRKTVEpisodesIE = NRKTVEpisodesIE()
    assert obj_NRKTVEpisodesIE.IE_NAME == 'nrktv:episodes'

# Generated at 2022-06-24 12:58:33.107527
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE('https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13')
    NRKTVIE('https://tv.nrk.no/program/MDDP12000117')



# Generated at 2022-06-24 12:58:34.855712
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test_object = NRKIE()
    assert test_object.IE_NAME == 'nrk'

# Generated at 2022-06-24 12:58:42.433175
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    info = NRKTVEpisode.create(url='https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert info.age_limit == 6
    assert info.display_id == 'Hellums kro - 2. Kro, krig og kjærlighet'
    assert info.episode == '2. Kro, krig og kjærlighet'
    assert info.episode_number == 2
    assert info.id == 'MUHH36005220'
    assert info.series == 'Hellums kro'
    assert info.season_number == 1



# Generated at 2022-06-24 12:58:51.294044
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """Unit test for constructor of class NRKTVEpisodeIE"""
    # Given a url for NRKTVEpisodeIE

    url = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    id = "MUHH36005220"
    season_number = "1"
    episode_number = "2"
    display_id = "hellums-kro/sesong/1/episode/2"

    # When creating NRKTVEpisodeIE
    NRKTVEpisodeIE(NRKTVEpisodeIE._VALID_URL, "NRKTVEpisodeIE", display_id)
    # Then the correct values are retrieved
    assert display_id == display_id
    assert id == id
    assert season_number == season_number
    assert episode_number == episode

# Generated at 2022-06-24 12:58:55.600808
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name('series') == 'series'
    assert ie._catalog_name('podkast') == 'podcast'


# Generated at 2022-06-24 12:59:04.300519
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test constructor class-method of NRKTVDirekteIE
    url = 'https://tv.nrk.no/direkte/nrk1'
    dir_live = NRKTVDirekteIE(url)
    # Test for variables set in NRKTVDirekteIE
    assert dir_live.domain == 'tv'
    assert dir_live.live_title == 'NRK1'
    assert dir_live.live_id == 'nrk1'
    assert dir_live.nrk_id is None


# Generated at 2022-06-24 12:59:10.135100
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

    ie = NRKRadioPodkastIE()
    ie._real_initialize()

    # Ensure that the class constructor is working properly
    assert ie._match_id(url) == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

# Generated at 2022-06-24 12:59:13.020158
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE(NRKTVDirekteIE.ie_key())

# Generated at 2022-06-24 12:59:17.875327
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant'
    nrktv_season_ie = NRKTVSeasonIE().suitable(url)
    assert nrktv_season_ie == True



# Generated at 2022-06-24 12:59:28.011763
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    class_ = globals()['NRKTVSeriesIE']
    assert class_.__name__ == 'NRKTVSeriesIE'
    assert class_.__doc__ == 'NRKTV and NRKSUPER series and seasons'
    assert hasattr(class_, '_VALID_URL')
    assert class_._VALID_URL == r'https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)'
    assert hasattr(class_, '_TESTS')
    assert isinstance(class_._TESTS, list)
    assert len(class_._TESTS) == 12

# Generated at 2022-06-24 12:59:33.107123
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    r = NRKRadioPodkastIE('https://radio.nrk.no/podkast/hele_historien/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c')
    assert r.__class__.__name__ == 'NRKRadioPodkastIE'

# Generated at 2022-06-24 12:59:35.288410
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    instance = NRKTVEpisodeIE()
    assert isinstance(instance, NRKTVEpisodeIE)


# Generated at 2022-06-24 12:59:37.868184
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE()
    except TypeError:
        pass
    else:
        raise Exception('An exception should be raised here')



# Generated at 2022-06-24 12:59:40.346121
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE()
    except:
        print('Error: constructor of class NRKPlaylistBaseIE does not work')


# Generated at 2022-06-24 12:59:46.803331
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    assert nrk._GEO_COUNTRIES == ['NO']
    assert nrk._CDN_REPL_REGEX == r'(?x)://\s*(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)\s*/'

# Generated at 2022-06-24 12:59:52.031554
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    ie = NRKTVDirekteIE(url)
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-24 12:59:58.224488
# Unit test for constructor of class NRKTVDirekteIE

# Generated at 2022-06-24 13:00:00.414351
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()

# Generated at 2022-06-24 13:00:10.279545
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    t = NRKTVIE('https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2')
    assert isinstance(t, NRKTVIE)
    t = NRKTVIE('https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015')
    assert isinstance(t, NRKTVIE)
    t = NRKTVIE('https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13')
    assert isinstance(t, NRKTVIE)

# Generated at 2022-06-24 13:00:13.165286
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015'
    # Correct constructor should be called if the url is NRK TV
    assert NRKTVIE._VALID_URL == NRKTVIE.VALID_URL

# Generated at 2022-06-24 13:00:15.410269
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    infoExtractor = NRKPlaylistIE()
    assert infoExtractor is not None
    assert isinstance(infoExtractor, NRKPlaylistBaseIE)
    assert isinstance(infoExtractor, InfoExtractor)

# Generated at 2022-06-24 13:00:16.988356
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie != None, ie
# END OF Unit test for constructor of class NRKRadioPodkastIE


# Generated at 2022-06-24 13:00:22.515769
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    def _test_result(parser, url, args, expected):
        # Constructor of NRKRadioPodkastIE returns only the expected result
        result = parser(args, url)
        if len(result) != 1:
            print("Result:", result)
            raise ValueError("Result should be a list with only one value")
        r = result[0]
        if r != expected:
            print("Result:", r)
            print("Expected:", expected)
            raise ValueError("Unexpected result")
    p = NRKRadioPodkastIE._VALID_URL
    _test_result(NRKRadioPodkastIE._match_id, "", p, "") # No URL

# Generated at 2022-06-24 13:00:26.534850
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE(None)._VALID_URL == NRKBaseIE._VALID_URL
    assert NRKIE(None)._TESTS == NRKBaseIE._TESTS



# Generated at 2022-06-24 13:00:30.103977
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE')
    assert ie.IE_NAME == 'NRKBaseIE'
    assert ie._GEO_COUNTRIES == ['NO']



# Generated at 2022-06-24 13:00:32.441295
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

    ie = NRKRadioPodkastIE()
    ie._real_extract(url)

# Generated at 2022-06-24 13:00:38.210150
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    class_nrktvseriebaseie = NRKTVSerieBaseIE()
    assert class_nrktvseriebaseie._extract_entries("") == []
    assert class_nrktvseriebaseie._extract_entries([]) == []
    assert len(class_nrktvseriebaseie._extract_entries([1, 2, 3])) == 0
    assert len(class_nrktvseriebaseie._extract_entries(
        [{'a': 1, 'prfId': '2'}, {'b': 2, 'episodeId': '3'}])) == 2
    assert class_nrktvseriebaseie._extract_assets_key({}) == None

# Generated at 2022-06-24 13:00:39.357064
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE(None).IE_NAME == 'nrk'

# Generated at 2022-06-24 13:00:42.810555
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        assert NRKTVSeasonIE.__name__ == 'NRKTVSeasonIE'
        assert issubclass(NRKTVSeasonIE, InfoExtractor)
    except:
        pass



# Generated at 2022-06-24 13:00:48.331863
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    import datetime
    t = datetime.datetime.utcnow()
    test = NRKTVEpisodeIE()

    test._downloader = None
    assert test._get_login_info() == (False, False, False)
    test._downloader = FakeDownloader()

    test._downloader.set_fake_cookie('nrk_portal_access_token', 'some_token')
    assert test._get_login_info() == (False, False, False)
    test._downloader.reset_fake_cookie('nrk_portal_access_token')

    test._downloader.set_fake_cookie('nrk_portal_access_token', 'some_token')
    test._downloader.set_fake_cookie('nrk_user_rights_token', 'some_token')
    assert test._get_

# Generated at 2022-06-24 13:00:52.556932
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrk = NRKPlaylistBaseIE('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert nrk is not None


# Generated at 2022-06-24 13:00:54.934187
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE(NRKBaseIE())

# Unit tests for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-24 13:01:07.986835
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRK')
    assert ie._GEO_COUNTRIES == ['NO']
    assert re.match(ie._CDN_REPL_REGEX, '://nrkod02-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0')
    assert re.match(ie._CDN_REPL_REGEX, '://nrk-od-no.telenorcdn.net')
    assert re.match(ie._CDN_REPL_REGEX, '://minicdn-od.nrk.no/od/nrkhd-osl-rr.netwerk.no/no')

# Generated at 2022-06-24 13:01:20.204449
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    from unittest import TestCase
    from youtube_dl import YoutubeDL

    test = TestCase()

    ydl = YoutubeDL({'quiet': True})
    ie = ydl.get_info_extractor('NRKPlaylistBase')
    test.assertEqual(ie._downloader.params,
                     {'quiet': True, 'usenetrc': False, 'forceurl': False,
                      'forcethumbnail': False, 'simulate': False, 'format': None,
                      'ignoreerrors': False, 'forcetitle': False,
                      'forcetitle': False, 'forceid': False, 'forcedescription': False,
                      'forceduration': False, 'forcefilename': False, 'forcejson': False,
                      'cookie': u'null', 'outtmpl': u'%(id)s'})


# Generated at 2022-06-24 13:01:22.185499
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    obj = NRKPlaylistBaseIE(None)
    assert obj._downloader is None



# Generated at 2022-06-24 13:01:29.880173
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    import unittest
    class NRKTVSerieBaseIETest(unittest.TestCase):
        def test_constructor(self):
            yt = NRKTVSerieBaseIE()
            self.assertEqual(yt._VALID_URL, None)
            self.assertEqual(yt._TESTS, [])
            self.assertEqual(yt._downloader, None)
            self.assertEqual(yt.IE_NAME, None)
            self.assertEqual(yt.ie, None)
            self.assertEqual(yt.ie_key(), None)
            self.assertEqual(yt.extractor, None)
            self.assertFalse(hasattr(yt, '_WORKING'))

# Generated at 2022-06-24 13:01:33.400517
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    import inspect
    # Test constructor of the NRKSkoleIE class
    NRKSkoleIE_object = NRKSkoleIE()
    # Test if constructor receives any parameters
    assert not inspect.getargspec(NRKSkoleIE_object.__init__).args


# Generated at 2022-06-24 13:01:46.442576
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Extract info from URL
    episodeIE = NRKTVEpisodeIE()
    info = episodeIE._real_extract(
        'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')

    # Check that nrk_id is set
    if not (re.match(NRKTVIE._EPISODE_RE, info['id'])):
        raise Exception("Incorrect nrk_id was extracted")

    # Check that season_number is set
    if not (info['season_number'] == 1):
        raise Exception("Incorrect season_number was extracted")

    # Check that episode_number is set
    if not (info['episode_number'] == 2):
        raise Exception("Incorrect episode_number was extracted")

# Generated at 2022-06-24 13:01:47.509646
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    a = NRKRadioPodkastIE(None)

# Generated at 2022-06-24 13:01:51.064224
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():

    # Objects are instances of the correct class
    assert isinstance(NRKPlaylistBaseIE(), NRKPlaylistBaseIE)



# Generated at 2022-06-24 13:02:02.803215
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # tests for NRKIE
    # this following call should return duration in seconds
    parse_duration('PT1H10M30S')
    parse_duration('P1DT26M5S')
    parse_duration('P2DT4H49M5S')
    parse_duration('PT59M')
    parse_duration('PT1H')
    parse_duration('PT')
    parse_duration('P')
    parse_duration('PT0H')
    parse_duration('PT0M0S')
    parse_duration('P0DT0H0M0S')
    parse_duration('PT0H0M')
    parse_duration('PT0M3S')
    parse_duration('PT0H1M')
    parse_duration('PT0H1M2S')
    parse_duration('PT1M2S')


# Generated at 2022-06-24 13:02:09.648524
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    obj = NRKTVSeriesIE()
    assert obj.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert obj.suitable('https://tv.nrk.no/serie/lindmo')
    assert obj.suitable('https://tv.nrk.no/serie/blank')
    assert obj.suitable('https://tv.nrk.no/serie/backstage')
    assert obj.suitable('https://tv.nrksuper.no/serie/labyrint')
    assert not obj.suitable('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    assert not obj.suitable('https://tv.nrk.no/serie/saving-the-human-race')
    assert not obj

# Generated at 2022-06-24 13:02:12.655940
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    IE_DESC = 'NRK TV Direkte and NRK Radio Direkte'
    nrktvdirekteie = NRKTVDirekteIE()
    assert nrktvdirekteie.IE_DESC == IE_DESC



# Generated at 2022-06-24 13:02:13.938306
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE('NRKTVSeason')


# Generated at 2022-06-24 13:02:14.578348
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-24 13:02:27.147274
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrktv_series_url = "https://tv.nrk.no/serie/debatten/sesong/1"
    nrk_tv_series = NRKTVSeriesIE._get_nrk_series_instance(nrktv_series_url)
    assert(nrk_tv_series.__class__.__name__ == "NRKTVSeriesIE")

    nrktv_season_url = "https://tv.nrk.no/serie/debatten"
    nrk_tv_season = NRKTVSeriesIE._get_nrk_series_instance(nrktv_season_url)
    assert(nrk_tv_season.__class__.__name__ == "NRKTVSeasonIE")


# Generated at 2022-06-24 13:02:37.086080
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'



# Generated at 2022-06-24 13:02:43.037416
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # NRKTVIE() can open sample URLs without error.
    for _ in NRKTVIE._TESTS:
        try:
            NRKTVIE()._real_extract(
                _['url'],
            )
        except ExtractorError as e:
            pass
        else:
            raise AssertionError('NRKTVIE() could open URL %s' % _['url'])

# Generated at 2022-06-24 13:02:49.043685
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE
    cases = [
        (('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'),
         {'id': '69031', 'title': 'Nytt på nytt, sesong: 201210'}),
    ]
    for url, expected in cases:
        info_dict = ie._real_extract(url)
        if not expected is None:
            assert info_dict == expected



# Generated at 2022-06-24 13:02:52.715500
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE("NRKTVIE._EPISODE_RE")

# Generated at 2022-06-24 13:03:03.976297
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    """Test when the class NRKTVSerieBaseIE is constructed."""
    ie = NRKTVSerieBaseIE('NRKTVSerie', 'nrk')
    # Extract entries
    def extract_entries(entry_list):
        return extract_entries(entry_list)
    ie._extract_entries = extract_entries
    # Extract assents key
    def extract_assets_key(embedded):
        return extract_assets_key(embedded)
    ie._extract_assets_key = extract_assets_key
    # Extract entries
    def entries(data, display_id):
        return entries(data, display_id)
    ie._entries = entries
    # Catalog name
    def catalog_name(serie_kind):
        return catalog_name(serie_kind)
    ie._catalog

# Generated at 2022-06-24 13:03:07.654018
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert isinstance(ie, NRKSkoleIE)
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-24 13:03:09.548248
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE.ie_key() == NRKTVIE.ie_key()

# Generated at 2022-06-24 13:03:22.804638
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    instance = NRKSkoleIE(url)

    assert instance.url == url
    assert instance.valid_url == url
    assert instance.valid_url == url
    assert instance._match_id == '14099'
    assert instance.IE_DESC == 'NRK Skole'
    assert instance.info_dict['id'] == '6021'
    assert instance.info_dict['ext'] == 'mp4'
    assert instance.info_dict['title'] == 'Genetikk og eneggede tvillinger'
    assert instance.info_dict['description'] == 'md5:3aca25dcf38ec30f0363428d2b265f8d'
    assert instance.info_

# Generated at 2022-06-24 13:03:27.019377
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    my_ie = NRKTVEpisodeIE()
    my_re = NRKTVEpisodeIE._VALID_URL
    assert re.match(my_re, 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')


# Generated at 2022-06-24 13:03:38.262783
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktovie = NRKTVIE(None)
    # Test explicit

# Generated at 2022-06-24 13:03:47.301879
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE("https://tv.nrk.no/serie/backstage/sesong/1")
    assert ie._VALID_URL == NRKTVSeasonIE._VALID_URL
    assert ie.suitable("https://tv.nrk.no/serie/backstage/sesong/1")
    assert not ie.suitable("https://tv.nrk.no/serie/spangas/sesong/1")
    assert not ie.suitable("https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant")


# Generated at 2022-06-24 13:03:48.110236
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    return NRKTVSerieBaseIE



# Generated at 2022-06-24 13:03:53.205805
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE("https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031")
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']\d+'


# Generated at 2022-06-24 13:03:57.657599
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert re.search(r'^%s\.\d{2,}\.\d{2,}\.\d{2,}\.\d{2,}\.\d{2,}\.\d{2,}\.\d{2,}$' % (NRKBaseIE.IE_NAME), ie.ie_key())


# Generated at 2022-06-24 13:04:00.092961
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from .nrk import NRKBaseIE
    ner=NRKBaseIE()



# Generated at 2022-06-24 13:04:01.515862
# Unit test for constructor of class NRKIE
def test_NRKIE():
    elem = NRKIE(None)
    assert elem

# Generated at 2022-06-24 13:04:08.670751
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    """Test method _extract_entries() objects of class NRKTVSerieBaseIE."""
    entries = []
    # entry_list has type "list"

# Generated at 2022-06-24 13:04:14.611771
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    instance = NRKTVEpisodesIE()
    assert instance.ie_key() == 'NRKTVEpisodes'
    assert instance.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031') == True
    assert instance.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/foobar') == True
    assert instance.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/foobar') == False
    assert instance.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt') == False

# Generated at 2022-06-24 13:04:20.946920
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/programmer/stemmer-fra-arkivet'
    playlist_id = 'stemmer-fra-arkivet'
    webpage = 'webpage'
    vid_list = []
    title = 'Stemmer fra arkivet'
    desc = 'Lorem Ipsum'

    nrk_plb_ie = NRKPlaylistBaseIE()
    nrk_plb_ie.playlist_result = lambda x, y, z, w: (x, y, z, w)
    nrk_plb_ie.url_result = lambda x, y: x
    nrk_plb_ie._download_webpage = lambda x, y: webpage
    nrk_plb_ie._match_id = lambda x: playlist_id

# Generated at 2022-06-24 13:04:23.628070
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE(NRKTVSeasonIE._downloader)._SEASON_RE == NRKTVIE._SEASON_RE



# Generated at 2022-06-24 13:04:36.078878
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    info_dict = {'id': '6021',
 'ext': 'mp4',
 'title': 'Genetikk og eneggede tvillinger',
 'description': 'md5:3aca25dcf38ec30f0363428d2b265f8d',
 'duration': 399}
    video_url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    obj = NRKSkoleIE()
    check_video_url(obj, video_url, '6021', info_dict)
    assert obj.IE_DESC == 'NRK Skole'
    assert obj._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-24 13:04:39.257414
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from .common import ExtractorError
    ie = NRKBaseIE()
    ie._raise_error({'messageType': 'ProgramIsGeoBlocked'})
    assert('NRK has not rights to show this' in ie.IE_NAME)

# Generated at 2022-06-24 13:04:43.502967
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    ie = NRKTVEpisodeIE()
    assert ie._real_extract(url)
    

# Generated at 2022-06-24 13:04:46.686850
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert isinstance(ie, NRKTVIE)
    assert ie.IE_NAME == ie.ie_key()



# Generated at 2022-06-24 13:04:55.538457
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    obj = NRKTVSeriesIE()
    assert obj.suitable('https://tv.nrk.no/serie/blank')
    assert obj.suitable('https://tv.nrk.no/serie/bla')
    assert not obj.suitable('https://tv.nrk.no/serie/bla/sesong/bla/episode/bla')
    assert not obj.suitable('https://tv.nrk.no/program/bla')
    assert not obj.suitable('https://tv.nrksuper.no/program/bla')

# Generated at 2022-06-24 13:04:57.772850
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    try:
        NRKTVIE()
    except:
        raise AssertionError("failed to construct instance of class NRKTVIE")


# Generated at 2022-06-24 13:04:59.018980
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('NRK:id')
    assert not ie.mgid_prefix



# Generated at 2022-06-24 13:05:03.237102
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test all but the last constructor of the class NRKTVEpisodesIE
    NRKTVEpisodesIE_check = NRKTVEpisodesIE(NRKTVIE(), 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    # Test the last constructor of the class NRKTVEpisodesIE
    NRKTVEpisodesIE_check.NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    return


# Generated at 2022-06-24 13:05:08.052387
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    import re
    display_id, season_number, episode_number = re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2').groups()
    assert display_id == 'hellums-kro'
    assert season_number == '1'
    assert episode_number == '2'

# Generated at 2022-06-24 13:05:14.649360
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    passage = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    a = NRKRadioPodkastIE()
    b = re.search(u'\"(http.*?)\"', passage).group()
    assert a._VALID_URL == b



# Generated at 2022-06-24 13:05:17.463597
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Given
    url = "https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031"

    # When
    NRKTVEpisodesIE(NRKPlaylistBaseIE)

    # Then
    assert NRKTVEpisodesIE._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'


# Generated at 2022-06-24 13:05:21.695385
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Unit test for constructor of class NRKTVSeasonIE
    try:
        NRKTVSeasonIE()
    except:
        print("Can not create object of class NRKTVSeasonIE")


# Generated at 2022-06-24 13:05:31.746380
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-24 13:05:38.581128
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    video_id = 'NRKTVIE_test'
    url = 'https://tv.nrk.no/program/%s' % video_id
    nrktvie._match_id(url) == video_id
    nrktvie.url_result(url, 'NRKIE', video_id)

# Generated at 2022-06-24 13:05:42.201703
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """
    Constructor test

    Should return an instance of class NRKTVSeasonIE
    """
    obj = NRKTVSeasonIE()
    assert isinstance(obj, NRKTVSeasonIE)



# Generated at 2022-06-24 13:05:50.442676
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Test if object is instanced correctly
    ie = NRKIE()
    # Test instance attributes
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._VALID_URL == 'http://[^/]+\\.nrk\\.no/video/PS\\*([^?\#&]+)'
    # call_playback_api()
    assert ie._call_api('playback/%s/150533', '150533', 'manifest', 'Downloading manifest JSON')

    # raise_error()
    assert ie._raise_error({'messageType': 'NoProgramRights', 'endUserMessage': 'foo'}) == 'ExtractorError: NRK said: foo'

# Generated at 2022-06-24 13:05:54.135362
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    import pytest
    with pytest.raises(NotImplementedError):
        NRKPlaylistBaseIE()._real_extract('http://test.test')


# Generated at 2022-06-24 13:06:06.031055
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from . import NRKTVIE

# Generated at 2022-06-24 13:06:17.643455
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert re.match(ie._VALID_URL, 'https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    assert re.match(ie._VALID_URL, 'https://tv.nrk.no/serie/saving-the-human-race')
    assert re.match(ie._VALID_URL, 'https://tv.nrk.no/serie/postmann-pat')
    assert re.match(ie._VALID_URL, 'https://tv.nrksuper.no/serie/labyrint')
    assert re.match(ie._VALID_URL, 'https://radio.nrk.no/podkast/ulrikkes_univers')

# Generated at 2022-06-24 13:06:19.473349
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-24 13:06:30.805781
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/abc')
    assert ie.suitable('https://tv.nrk.no/serie/backstage')
    assert ie.suitable('https://tv.nrk.no/serie/trollhunters')
    assert ie.suitable('https://tv.nrk.no/serie/heartland/sesong/12/episode/22')
    assert ie.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert ie.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509/episode/11')

# Generated at 2022-06-24 13:06:37.466390
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('http://tv.nrk.no/direkte/nrk1')
    assert ie is not None

    # Unit test for constructor of class NRKBaseIE
    def test_NRKBaseIE():
        ie = NRKBaseIE('http://tv.nrk.no/direkte/nrk1')
        assert ie is not None



# Generated at 2022-06-24 13:06:47.959669
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ins = NRKBaseIE(None, False)
    for iT in ins.__dict__.items():
        if iT[0] == '_GEO_COUNTRIES':
            assert iT[1] == ['NO'], 'Wrong value for _GEO_COUNTRIES'

# Generated at 2022-06-24 13:06:58.486123
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()._valid_url('http://www.nrk.no/video/PS*150533')
    NRKIE()._valid_url('https://v8-psapi.nrk.no/mediaelement/ecc1b952-96dc-4a98-81b9-5296dc7a98d9')
    NRKIE()._valid_url('https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533')
    NRKIE()._valid_url('nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9')

# Generated at 2022-06-24 13:07:10.409773
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ins = NRKTVIE('nrk')
    assert ins.ie_key() == 'NRKTV'
    assert ins.ie_key() == 'NRK'
    assert ins.is_nrk_url('nrk:dummy')
    assert ins.is_nrk_url('nrk:channel/nrk1')
    assert not ins.is_nrk_url('nrk:l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ins._match_id('https://tv.nrk.no/program/MDDP12000117') == 'MDDP12000117'

# Generated at 2022-06-24 13:07:21.111453
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Create new object for class NRKIE
    nrk = NRKIE()
    # Test public variables
    assert nrk.IE_NAME == 'nrk'
    assert nrk._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    # Test private functions
    assert nrk._real_extract('nrk:MDDP12000117') == 'MDDP12000117'
    assert nrk._

# Generated at 2022-06-24 13:07:29.467256
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE(
        NRKRadioPodkastIE._create_ie(), 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    )._VALID_URL == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-24 13:07:38.699289
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert ie.suitable('https://tv.nrk.no/serie/dicte/sesong/0')
    assert ie.suitable('https://tv.nrk.no/serie/en-liten-julsaga')
    assert ie.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert ie.suitable('https://tv.nrk.no/serie/en-liten-julsaga/sesong/0/episode/1')
    assert ie.suitable('https://tv.nrk.no/serie/dicte/sesong/5')
    assert not ie.suitable('https://tv.nrk.no/serie/en-liten-julsaga/0/1')

# Generated at 2022-06-24 13:07:39.900141
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie_nrk = NRKTVIE()
    ie_nrk.ie_key()

# Generated at 2022-06-24 13:07:41.414282
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    try:
        NRKPlaylistIE()
    except Exception:
        assert False, 'constructor did not take any param'



# Generated at 2022-06-24 13:07:48.346975
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """
    Unit test for NRKTVDirekteIE class
    """
    # Create directly instance of NRKTVDirekteIE
    test_instance = NRKTVDirekteIE('', {})
    # Assert that NRKTVDirekteIE is a subclass of NRKTVIE
    assert issubclass(NRKTVDirekteIE, NRKTVIE)
    # Assert that NRKTVDirekteIE is a subclass of NRKBaseIE
    assert issubclass(NRKTVDirekteIE, NRKBaseIE)



# Generated at 2022-06-24 13:07:59.393796
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    class TemplateIE(NRKTVSeriesIE):
        _VALID_URL = NRKTVSeriesIE._VALID_URL
        _TEMPLATE_URL = 'http://nrk.no/serie/%s/'
        _VIDEO_RE = r'(?:[^/]+/){4}(?P<id>[^/?#&]+)'
        _TESTS = [{
            'url': 'http://nrk.no/serie/blank',
            'info_dict': {
                'id': 'blank',
                'title': 'Blank',
            },
            'playlist_count': 3,
        }]
        def _real_extract(self, url):
            mobj = re.match(self._VALID_URL, url)
            series_id = mobj.group('id')