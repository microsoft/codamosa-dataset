

# Generated at 2022-06-24 12:58:09.742226
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    x = NRKTVEpisodeIE()
    test_url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    test_ep_id = 'MUHH36005220'
    test_season_number = '1'
    test_episode_number = '2'

    assert x._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert x._match_id(test_url) == test_ep_id
    assert x._match_season_number(test_season_number) == int(test_season_number)
    assert x._match_episode_number

# Generated at 2022-06-24 12:58:12.788662
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._build_static_url(
        'http://tv.nrk.no/serie/urania/sesong/1/episode/1') == 'nrk:MUUR01000710'

# Generated at 2022-06-24 12:58:16.633662
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Checks that an instance of NRKPlaylistIE can be created
    instance = NRKPlaylistIE('http://www.nrk.no/some-url/')
    assert isinstance(instance, NRKPlaylistIE)



# Generated at 2022-06-24 12:58:20.808537
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    @patch("urllib.request.urlopen")
    def mock_urlopen(url, data):
        class MockResponse:
            def __init__(self, data, status_code=200, headers={}):
                self.content = data
                self.status_code = status_code
                self.headers = headers
            def json(self):
                return json.loads(self.content)

        return MockResponse(json.dumps(data))

    data = {"test":42}

    mock_urlopen("http://nrk.no", data)
    assert NRKTVIE(None, "nrk:test/test")._call_api("test", video_id="test", item="test") == data

# Generated at 2022-06-24 12:58:26.139429
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # if __name__ == '__main__':
    #     test_NRKPlaylistIE()

    url = 'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'

# Generated at 2022-06-24 12:58:30.626296
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Test that we DO NOT crash on construction
    # because we are given an empty string as argument
    NRKSkoleIE("")
    # Test that we DO NOT crash on construction
    # because we are given a parameter with a value of
    # None type
    NRKSkoleIE(None)

# Generated at 2022-06-24 12:58:32.233555
# Unit test for constructor of class NRKIE
def test_NRKIE():
    obj = NRKIE()


# Generated at 2022-06-24 12:58:36.334441
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-24 12:58:39.152700
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Testing downloading a season of a series
    url = "https://tv.nrk.no/serie/backstage/sesong/1"
    expected = NRKTVSeasonIE(NRKTVSeasonIE.suitable(url), url)._VALID_URL == url
    assert expected


# Generated at 2022-06-24 12:58:47.263183
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # pylint: disable=attribute-defined-outside-init
    class FooNRKTVDirekteIE(NRKTVDirekteIE):
        @classmethod
        def suitable(cls, url):
            return False
    # Calling test constructor of class NRKTVDirekteIE
    unit_test_NRKTVDirekteIE = FooNRKTVDirekteIE(NRKTVDirekteIE.ie_key())
    assert unit_test_NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1') is False
    assert unit_test_NRKTVDirekteIE.suitable('direkte') is True

# Generated at 2022-06-24 12:58:52.987327
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    test_obj = NRKTVDirekteIE(None, None)
    assert test_obj.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert test_obj._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:59:05.371848
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-24 12:59:10.032513
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    e = NRKTVEpisodeIE('NRKTVEpisodeIE', 'undefined');
    assert(e._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))')


# Generated at 2022-06-24 12:59:17.928808
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    ie = NRKTVEpisodeIE()
    assert ie._download_webpage
    assert ie._match_id
    assert ie._html_search_meta
    assert ie._search_regex
    assert ie._search_json_ld
    assert ie._real_extract
    assert ie.IE_DESC



# Generated at 2022-06-24 12:59:24.581531
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie.IE_NAME == 'nrk:radiopodkast'
    assert ie.IE_DESC == 'NRK Radio Podkast'

# Generated at 2022-06-24 12:59:29.349108
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        assert(NRKTVSerieBaseIE._catalog_name('series') == 'series')
        assert(NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast')
    except AssertionError as e:
        print(e)


# Generated at 2022-06-24 12:59:30.123258
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE.IE_DESC

# Generated at 2022-06-24 12:59:35.155689
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    nrk_radio_podkast_ie._real_extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-24 12:59:37.342549
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE('https://tv.nrk.no/serie/spangas/sesong/1')


# Generated at 2022-06-24 12:59:43.504209
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    nrktv_ep_ie = NRKTVEpisodeIE()
    info = nrktv_ep_ie._real_extract(url)
    assert(info['id'] == 'MSUI14000816')
    assert(info['season_number'] == 1)
    assert(info['episode_number'] == 8)
    assert(info['url'] == 'nrk:MSUI14000816')
    assert(info['ie_key'] == 'NRK')


# Generated at 2022-06-24 12:59:45.091367
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrkbaseie = NRKBaseIE()
    print(nrkbaseie)


# Generated at 2022-06-24 12:59:50.382235
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = "https://tv.nrk.no/serie/backstage/sesong/1"
    nrktvsinie = NRKTVSeasonIE()
    assert nrktvsinie.suitable(url)


# Generated at 2022-06-24 12:59:53.129119
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktv_ie = NRKTVIE()
    nrktv_ie._real_extract('https://tv.nrk.no/program/MDDP12000117')



# Generated at 2022-06-24 12:59:55.826950
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    base_ie = NRKBaseIE()
    # Make sure _GEO_COUNTRIES is set to ['NO']
    assert base_ie._GEO_COUNTRIES == ['NO']
    # Make sure the constructor does not raise an error
    assert base_ie is not None


# Generated at 2022-06-24 13:00:03.189265
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE(None)

    # assert that the constructor raises an exception on invalid URLs
    assert ie.suitable('hello') == False
    # assert that the constructor does not raise an exception on valid URLs
    assert ie.suitable(ie._VALID_URL) == True



# Generated at 2022-06-24 13:00:06.605951
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.VALID_URL == NRKTVEpisodeIE._VALID_URL
    assert ie.TESTS == NRKTVEpisodeIE._TESTS



# Generated at 2022-06-24 13:00:07.625692
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE()



# Generated at 2022-06-24 13:00:10.965946
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE()._call_api('foo', 'bar', 'api_name') == {
        'type': 'api_name',
        'query': {
            'bar': 'p',  # p = page
        },
    }

# Generated at 2022-06-24 13:00:12.588390
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    obj = NRKPlaylistBaseIE()
    assert obj.IE_DESC == 'NRK Playlist'



# Generated at 2022-06-24 13:00:13.913990
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert(NRKTVSeriesIE.__name__ == 'NRKTVSeriesIE')

# Generated at 2022-06-24 13:00:20.667341
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert NRKTVSeriesIE.suitable(ie.url) is False
    assert NRKTVSeasonIE.suitable(ie.url) is False
    assert NRKTVEpisodeIE.suitable(ie.url) is False
    assert NRKTVIE.suitable(ie.url) is False
    assert NRKRadioPodkastIE.suitable(ie.url) is False
    assert NRKTVSeriesIE.suitable(ie.url) is True


# Generated at 2022-06-24 13:00:23.302961
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_ie = NRKPlaylistIE("https://www.nrk.no/urix/test_test_test-1.test")
    assert nrk_playlist_ie.url == 'https://www.nrk.no/urix/test_test_test-1.test'
    assert nrk_playlist_ie.playlist_id == 'test_test_test-1.test'


# Generated at 2022-06-24 13:00:28.394128
# Unit test for constructor of class NRKTVIE

# Generated at 2022-06-24 13:00:39.332055
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test extraction of explicit NRK_TV series
    explicit_series = 'https://tv.nrk.no/serie/groenn-glede'
    expected_video_id = 'groenn-glede'
    series = NRKTVSeriesIE(NRKTVSeriesIE.ie_key(), explicit_series)
    assert series._VALID_URL == series._VALID_URL
    video_id = series._match_id(explicit_series)
    assert video_id == expected_video_id
    # Test extraction of NRK_TV series with www in the url
    explicit_series_with_www = 'https://www.tv.nrk.no/serie/groenn-glede'

# Generated at 2022-06-24 13:00:42.467324
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._match_id('https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'


# Generated at 2022-06-24 13:00:51.048915
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Check if channel exists
    channel = 'NRK1'
    direkte_ie = NRKTVDirekteIE({'channel': channel})
    result1 = direkte_ie.params['channel']
    assert result1 == channel

    # Check if channel does not exist
    channel = 'NRK9'
    direkte_ie = NRKTVDirekteIE({'channel': channel})
    result2 = direkte_ie.params['channel']
    assert result2 != channel


# Generated at 2022-06-24 13:00:56.100436
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist = NRKPlaylistIE.url_result(url)
    assert playlist.pat.match(url)
    assert playlist.constructor(url) is not None

# Generated at 2022-06-24 13:01:04.198148
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # We do not have a valid url for this, but we generate one to test for constructor
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    try:
        NRKRadioPodkastIE(url)
    except:
        assert False, 'Constructor is broken'


# Generated at 2022-06-24 13:01:07.674219
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from . import NRKTVDirekteIE
    loader = NRKTVDirekteIE.NRKTVDirekteIE()
    assert loader is not None


# Generated at 2022-06-24 13:01:08.927854
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()


# Generated at 2022-06-24 13:01:13.294872
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    dummy_url = "https://radio.nrk.no/podkast/hele_historien/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c"
    try:
        NRKRadioPodkastIE(NRKRadioPodkastIE.create_ie(dummy_url))
    except AttributeError:
        assert False

# Generated at 2022-06-24 13:01:16.939344
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    result = NRKTVSeriesIE()
    assert isinstance(result, NRKBaseIE)
    assert isinstance(result, InfoExtractor)
    assert hasattr(result, '_call_api')


# Generated at 2022-06-24 13:01:23.823483
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._TESTS[0]["info_dict"] == {
        'id': '150533',
        'ext': 'mp4',
        'title': 'Dompap og andre fugler i Piip-Show',
        'description': 'md5:d9261ba34c43b61c812cb6b0269a5c8f',
        'duration': 262,
    }


# Generated at 2022-06-24 13:01:24.367399
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    NRKBaseIE()

# Generated at 2022-06-24 13:01:28.468655
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():

    with pytest.raises(AssertionError):
        url = ('https://radio.nrk.no/serie/dagsnytt/sesong/201509'
               '?pageSize=500&page=2')
        NRKTVSeasonIE(url, '')._call_api(url, '', '', {})



# Generated at 2022-06-24 13:01:33.861118
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    for url in ('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'):
        ie = NRKTVEpisodesIE(NRKIE(), url)
        assert ie.name == 'NRKTVEpisodesIE'
        assert ie.url == url



# Generated at 2022-06-24 13:01:38.108642
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-24 13:01:46.197706
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1', {
        'headLine': 'NRK1 direkte',
        'subLine': 'Se rene streaming av NRK1 med artikler om de forskjellige programmene, lenker til direkteoverføringer, bildegallerier og lydklipp.'
    })


# Generated at 2022-06-24 13:01:52.532097
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    meta = '_embedded.instalments._embedded.episodes._embedded.episodes'
    expected_json_meta = '_embedded.episodes._embedded.episodes'
    unit_test_class_constructor(
        NRKTVSeasonIE,
        expected_meta_resource=meta,
        expected_json_meta=expected_json_meta,
        expected_meta_type=list,
        url=url)



# Generated at 2022-06-24 13:01:57.688955
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test that the constructor is matching the url.
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    match = NRKTVEpisodesIE._VALID_URL.match(url)
    assert match
    assert match.groupdict()['id'] == '69031'


# Generated at 2022-06-24 13:02:00.642591
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    v = NRKTVSeriesIE()
    assert v.suitable(url)



# Generated at 2022-06-24 13:02:07.476129
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_NRKBaseIE = NRKBaseIE(1, 2)
    assert test_NRKBaseIE._GEO_COUNTRIES == ['NO'] \
        and test_NRKBaseIE._CDN_REPL_REGEX == r'(?x):://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-24 13:02:15.293049
# Unit test for constructor of class NRKIE
def test_NRKIE():
    obj = NRKIE('http://www.nrk.no/video/PS*154915')
    assert obj._VALID_URL == 'http://www.nrk.no/video/PS*154915'

# Generated at 2022-06-24 13:02:21.559921
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE(NRKBaseIE()._downloader, 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    # test variables
    assert ie.name == 'NRKTV:Epsiodes'
    assert ie.mandatory_ie == 'NRKTV'


# Generated at 2022-06-24 13:02:26.912171
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    class TestNRKBaseIE(NRKBaseIE):
        pass
    ie = TestNRKBaseIE('NRKBaseIE', 'nrk.no')
    assert ie.ie_key() == 'NRKBaseIE'
    assert ie.ieName() == 'nrk.no'


# Generated at 2022-06-24 13:02:29.440143
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    ie._extract_entries(None)

# Generated at 2022-06-24 13:02:36.324791
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    obj = NRKTVSeriesIE()
    assert obj._VALID_URL == 'https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)'


# Generated at 2022-06-24 13:02:38.343511
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL is not None
    NRKTVSeasonIE()



# Generated at 2022-06-24 13:02:48.481489
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-24 13:02:55.540164
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    serie_base_ie = NRKTVSerieBaseIE()
    assert serie_base_ie._catalog_name(serie_base_ie._ASSETS_KEYS[0]) == 'series'
    assert serie_base_ie._catalog_name(serie_base_ie._ASSETS_KEYS[1]) == 'series'



# Generated at 2022-06-24 13:03:07.205710
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert isinstance(NRKTVSeasonIE._call_api('https://tv-api.nrk.no/catalog/search?query=lindmo&pageSize=10'), dict)
    assert NRKTVSeasonIE._call_api('https://tv-api.nrk.no/catalog/search?query=lindmo&pageSize=10', fatal=False)
    assert isinstance(NRKTVSeasonIE._call_api('https://tv-api.nrk.no/catalog/search?query=lindmo&pageSize=10', fatal=False), dict)
    assert not NRKTVSeasonIE._call_api('https://tv-api.nrk.no/catalog/search_not_exist?query=lindmo&pageSize=10', fatal=False)

# Generated at 2022-06-24 13:03:20.453587
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    try:
        ie.IE_NAME 
    except:
        assert False
    assert ie.IE_NAME == "nrk:base"
    assert ie._VALID_URL == ""
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''

# Generated at 2022-06-24 13:03:26.650407
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    ie = NRKTVDirekteIE()
    assert ie != None
    assert ie.suitable(url) == True
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    ie_match = ie._VALID_URL_RE.search(url)
    assert ie_match != None
    assert ie_match.group('id') == 'nrk1'



# Generated at 2022-06-24 13:03:32.075135
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    ie = NRKTVSeasonIE()
    assert ie.suitable(url)
    test_result = NRKTVSeasonIE._tests

    # Case 1
    assert isinstance(test_result[0], dict)
    assert test_result[0]['url'] == 'https://tv.nrk.no/serie/backstage/sesong/1'
    assert len(test_result[0]['info_dict']) == 2
    assert test_result[0]['info_dict']['id'] == 'backstage/1'
    assert test_result[0]['info_dict']['title'] == 'Sesong 1'
    assert test_result[0]['playlist_mincount'] == 30

   

# Generated at 2022-06-24 13:03:38.455727
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    test = NRKRadioPodkastIE()
    valid_URL = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    m = test._VALID_URL.match(valid_URL)
    assert m.group('id') == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8', 'The unit test for _VALID_URL failed.'

# Generated at 2022-06-24 13:03:43.146542
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE();
    test_id = "MDDP12000117"
    test_video_url = ie._real_extract(ie._VALID_URL % test_id)["url"]
    assert(test_video_url == "nrk:%s" % test_id)

# Generated at 2022-06-24 13:03:45.842846
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE()
    except TypeError as e:
        msg = str(e)
        assert msg == 'Can\'t instantiate abstract class NRKTVSerieBaseIE with abstract methods _extract_assets_key, _extract_entries'


# Generated at 2022-06-24 13:03:54.496762
# Unit test for constructor of class NRKTVIE

# Generated at 2022-06-24 13:03:56.435096
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')



# Generated at 2022-06-24 13:04:02.360503
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test_url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    nrktv_episodes_ie = NRKTVEpisodesIE(NRKIE._build_test_config())
    test_data = nrktv_episodes_ie._extract_playlist(test_url)

    assert test_data.entries
    assert test_data.entries[0] == 'nrk:MUHH47000114AA'
    assert test_data.entries[1] == 'nrk:MUHH47000115AA'
    assert test_data.entries[2] == 'nrk:MUHH47000116AA'
    assert test_data.entries[3] == 'nrk:MUHH47000117AA'


# Generated at 2022-06-24 13:04:05.102191
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert isinstance(ie, NRKTVSeasonIE)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:04:07.167471
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Create a NRKSkoleIE object
    nrkSkoleIE = NRKSkoleIE()

    # Check the NRKSkoleIE.IE_DESC attribute
    assert nrkSkoleIE.IE_DESC == 'NRK Skole'


# Generated at 2022-06-24 13:04:11.396476
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # test that it is an InfoExtractor
    ie = NRKTVSerieBaseIE("http://tv.nrk.no/program/MSSU60000613")
    assert isinstance(ie, InfoExtractor)
    # test that the first element of _ASSETS_KEYS (which are used in
    # _extract_assets_key) is 'episodes'
    assert ie._ASSETS_KEYS[0] == 'episodes'


# Generated at 2022-06-24 13:04:18.104497
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # The constructor of class InfoExtractor is tested in common.test
    assert InfoExtractor.suitable(NRKPlaylistBaseIE.ie_key())
    ie = NRKPlaylistBaseIE('dummy_url', 'dummy_info_dict')
    assert ie.ie_key() == 'NRKPlaylistBase'
    assert ie._VALID_URL == ''
    assert ie._VALID_URL_TEMPL == ''
    assert ie._ITEM_RE == ''
    assert ie._TESTS == []
    assert ie.BRIGHTCOVE_URL_TEMPL == 'http://players.brightcove.net/%s/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:04:28.271039
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    result = NRKTVDirekteIE({
        '_links': {
            'stream': {
                'href': 'https://nrk-pd-v-hls-fra-a-nrk-no.akamaized.net/hls/index.m3u8'
            }
        },
        'title': 'NRK 1 live TV-kanal',
        'type': 'channel',
        'prfId': 'nrk2',
        'typeShort': 'tv-channel'
    })
    url = result.get_url()
    assert url == 'nrk:nrk2'

# Generated at 2022-06-24 13:04:39.461165
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    test_case = [{
        'url': 'https://tv.nrk.no/serie/groenn-glede',
        'info_dict': {
            'id': 'groenn-glede',
            'title': 'Grønn glede',
            'description': 'md5:7576e92ae7f65da6993cf90ee29e4608',
        },
        'playlist_mincount': 90,
    }]
    for test_case in test_case:
        test_url = test_case['url']
        test_playlist_mincount = test_case['playlist_mincount']
        test_result_title = test_case['info_dict']['title']
        test_result_id = test_case['info_dict']['id']
        test_

# Generated at 2022-06-24 13:04:49.399741
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBase')
    assert ie.GEO_COUNTRIES == 'NO'
    assert ie.IE_NAME == 'NRKBase'
    assert ie._CDN_REPL_REGEX == '://(?:nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|nrk-od-no\\.telenorcdn\\.net|minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no)/'


# Generated at 2022-06-24 13:04:51.303903
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE(NRKTVSeriesIE.ie_key())


# Generated at 2022-06-24 13:05:02.220028
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]["url"] == "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    assert ie._TESTS[0]["info_dict"]["id"] == "MUHH36005220"
    assert ie._TESTS[0]["info_dict"]["ext"] == "mp4"

# Generated at 2022-06-24 13:05:09.155285
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test is unit test running in the system
    if not is_unit_test():
        return

    # Test constructor of class NRKPlaylistIE
    test_url = 'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'
    try:
        nrk_playlist_ie = NRKPlaylistIE(test_url)
    except:
        print('Test of NRKPlaylistIE constructor failed')
        print(traceback.format_exc())
        return

    # Test constructor of class NRKPlaylistIE
    print('Test of NRKPlaylistIE constructor success')
    return


# Generated at 2022-06-24 13:05:10.999631
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvseasonIE = NRKTVSeasonIE('nrktv')

# Generated at 2022-06-24 13:05:19.660760
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    test_entry_list = [{'prfId':'1'}, {'prfId':'2'}, {'episodeId':'3'}]
    assert NRKTVSerieBaseIE._extract_entries(test_entry_list) == [
        {'_type': 'url', 'ie_key': 'NRKTV', 'id': '1', 'url': 'nrk:1'},
        {'_type': 'url', 'ie_key': 'NRKTV', 'id': '2', 'url': 'nrk:2'},
        {'_type': 'url', 'ie_key': 'NRKTV', 'id': '3', 'url': 'nrk:3'}]
    assert NRKTVSerieBaseIE._extract_entries({'error': True}) == []

# Generated at 2022-06-24 13:05:21.002953
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()



# Generated at 2022-06-24 13:05:22.696008
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    try:
        nrkskole = NRKSkoleIE()
    except:
        assert False, "NRKSkoleIE constructor throws exception"
    assert True


# Generated at 2022-06-24 13:05:24.621454
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    import re
    import doctest
    doctest.testmod(extraglobs={'NRKSkoleIE': NRKSkoleIE(NRKBaseInfoExtractor())})


# Generated at 2022-06-24 13:05:27.796831
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """
    Test case for constructor of class NRKTVSeasonIE
    """
    nrktvseason_ie = NRKTVSeasonIE()
    assert nrktvseason_ie is not None


# Generated at 2022-06-24 13:05:31.470058
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    ie = NRKPlaylistIE(url)
    assert 'video_id' in ie.video_info



# Generated at 2022-06-24 13:05:44.568622
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    webpage = '<a class="rich" data-video-id="mvla23500050aa">'
    playlist_title = 'Gjenopplev den historiske solformørkelsen'
    playlist_description = 'md5:c2df8ea3bac5654a26fc2834a542feed'

# Generated at 2022-06-24 13:05:56.705519
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Success test
    NRKRadioPodkastIE('http://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    # Failure tests
    with pytest.raises(RegexNotFoundError):
        NRKRadioPodkastIE('http://radio.nrk.no/podkast/ulrikkes_univers')
    with pytest.raises(RegexNotFoundError):
        NRKRadioPodkastIE('http://nrk.no/podkast/ulrikkes_univers')

# Generated at 2022-06-24 13:06:07.611767
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    func = NRKTVSeasonIE._extract_assets_key
    assert func({'episodes':True}) == 'episodes'
    assert func({'instalments':True}) == 'instalments'
    assert func({'episodes':True, 'instalments':True}) == 'episodes'
    assert func({'instalments':True, 'episodes':True}) == 'instalments'
    assert func({'episodes':True, 'instalments':True, 'episodes':False, 'instalments':False}) == 'episodes'
    assert func({'instalments':True, 'episodes':True, 'episodes':False, 'instalments':False}) == 'instalments'
    assert func({'episodes':False, 'instalments':False}) == None

# Generated at 2022-06-24 13:06:08.951372
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Assert that the NRKTVIE constructor does not break
    ie = NRKTVIE(GoogletvIE())

# Generated at 2022-06-24 13:06:11.278077
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Arrange
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    expected = '69031'

    # Act
    test = NRKTVEpisodesIE(NRKTVIE())
    # Assert
    assert test._match_id(url) == expected


# Generated at 2022-06-24 13:06:17.059913
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    try:
        data = get_testdata_as_dict()
        regex = NRKTVEpisodeIE._VALID_URL
        match = re.match(regex, data['url'])
        assert match.groups() == ('hellums-kro/sesong/1/episode/2', '1', '2')
        assert match.group(0) == data['url']
        assert match.group(1) == 'hellums-kro/sesong/1/episode/2'
        assert match.group(2) == '1'
        assert match.group(3) == '2'
        assert match.groupdict() == {'id': 'hellums-kro/sesong/1/episode/2', 'season_number': '1', 'episode_number': '2'}
    except Exception as e:
        raise

# Generated at 2022-06-24 13:06:21.818201
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert(NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'))
    assert(NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/2') == False)
    assert(NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/episodes') == False)

    NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')



# Generated at 2022-06-24 13:06:23.267441
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Construct an instance of class NRKPlaylistIE
    # and test if it passes construction
    NRKPlaylistIE().suitable('url')

# Generated at 2022-06-24 13:06:25.549815
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    video_id = '14099'
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=' + video_id
    ie = NRKSkoleIE()
    result = ie._real_extract(url)
    assert result['id'] == '6021'


# Generated at 2022-06-24 13:06:35.241596
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from . import _tests_util
    utils = _tests_util()
    def _extract_series(url, ie=NRKTVSeriesIE, video_id=None):
        return utils.get_extractor(ie, video_id)._extract_series(url)
    # Invalid URLs
    assert _extract_series(
        'https://tv.nrk.no/serie/backstage/sesong/1/episode/1',
        ie=NRKTVSeasonIE) == 'backstage/1'
    assert _extract_series(
        'https://tv.nrk.no/serie/backstage/sesong/1',
        ie=NRKTVSeasonIE) == 'backstage/1'

# Generated at 2022-06-24 13:06:38.148077
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()


# Generated at 2022-06-24 13:06:41.096413
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    # Check if the regex has been changed in any level
    assert(ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})')
    assert(ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % ie._EPISODE_RE)


# Generated at 2022-06-24 13:06:43.360475
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    inst = NRKTVDirekteIE()
    assert isinstance(inst.ie, (NRKTVIE, NRKTVDirekteIE))

# Generated at 2022-06-24 13:06:49.804868
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrkIE = NRKIE(None)
    assert nrkIE._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''



# Generated at 2022-06-24 13:06:56.109343
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert(NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099'))
    assert(NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'))
    assert(not NRKSkoleIE.suitable('https://www.nrk.no/malvik/hjemmebrent-i-leira-1.12121527'))
    assert(not NRKSkoleIE.suitable('https://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'))

# Generated at 2022-06-24 13:06:57.633270
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    with pytest.raises(AttributeError):
        NRKSkoleIE()

# Generated at 2022-06-24 13:06:58.474993
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()



# Generated at 2022-06-24 13:06:59.777354
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('nrk', {}, {}, {}, {})


# Generated at 2022-06-24 13:07:11.916252
# Unit test for constructor of class NRKTVIE

# Generated at 2022-06-24 13:07:14.476511
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie.is_valid_url


# Generated at 2022-06-24 13:07:16.204460
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    _NRKPlaylistBaseIE = NRKPlaylistBaseIE()
    assert _NRKPlaylistBaseIE._VALID_URL is None
    assert _NRKPlaylistBaseIE._ALLOW_AUDIO_STREAMS is False


# Generated at 2022-06-24 13:07:20.189921
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktv_ie = NRKTVIE()
    assert repr(nrktv_ie).startswith(NRKTVIE.IE_NAME)
    assert repr(nrktv_ie.extractor) == repr(NRKIE())


# Generated at 2022-06-24 13:07:25.468923
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    class_ = getattr(sys.modules[__name__], 'NRKTVEpisodesIE')
    instance = class_()
    assert instance.IE_DESC == 'NRK TV episodes'
    assert instance._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'


# Generated at 2022-06-24 13:07:32.172695
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    nrk_radio_podkast_ie.extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-24 13:07:33.351438
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    NRKTVSeasonIE()


# Generated at 2022-06-24 13:07:38.027193
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    obj = NRKTVSerieBaseIE()
    obj.url_result('nrk:MDDP12000117', ie='nrk', video_id='MDDP12000117')
    obj.url_result('nrktvseriebaseie', ie='nrk', video_id='md5:233712c5e5d5d5e5')



# Generated at 2022-06-24 13:07:38.704752
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    pass


# Generated at 2022-06-24 13:07:43.916839
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    yt = NRKBaseIE()
    assert yt.IE_DESC == "NRK"
    assert yt.ie_key() == "NRK"
    assert 'nrk' in yt.ie_key()
    assert yt.GEO_COUNTRIES == ['NO']
    assert 'https://psapi.nrk.no/' in yt._call_api("", "test")[0]

if __name__ == '__main__':
    test_NRKBaseIE()

# Generated at 2022-06-24 13:07:56.278609
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    import urllib.request, urllib.error, urllib.parse
    # Constructor test
    with pytest.raises(RegexNotFoundError):
        ie = NRKTVDirekteIE('http://www.tv.nrk.no/direkte/<objects>')
    with pytest.raises(RegexNotFoundError):
        ie = NRKTVDirekteIE('http://tv.nrk.no/direkte/')
    with pytest.raises(RegexNotFoundError):
        ie = NRKTVDirekteIE('http://www.tv.nrk.no/direkte/')
    ie = NRKTVDirekteIE('http://tv.nrk.no/direkte/nrk1')
    assert ie
    ie

# Generated at 2022-06-24 13:07:59.913884
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    ie = NRKTVEpisodeIE()
    assert re.match(ie._VALID_URL, test_url)
