

# Generated at 2022-06-24 12:57:58.557650
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE("NRKTVEpisodeIE", url="")
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 12:58:09.844865
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert_equal(ie._extract_assets_key({
        'instalments': {},
    }), 'instalments')
    assert_equal(ie._extract_assets_key({
        'episodes': {},
    }), 'episodes')
    assert_equal(ie._extract_assets_key({
        'episodes': {
            '_embedded': {
                'episodes': {},
            },
        },
    }), 'episodes')
    assert_equal(ie._extract_assets_key({
        '_embedded': {
            'episodes': {},
        },
    }), 'episodes')

# Generated at 2022-06-24 12:58:13.175553
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # test without JSON
    try:
        NRKSkoleIE._download_json(
            'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/0',
            '0')
        assert False
    except ExtractorError:
        pass



# Generated at 2022-06-24 12:58:14.476944
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert issubclass(NRKTVSeasonIE, InfoExtractor)

# Generated at 2022-06-24 12:58:15.478187
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Test whether constructor succeeds.
    ie = NRKIE()



# Generated at 2022-06-24 12:58:17.222011
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    from .nrktv import NRKTVEpisodesIE
    NRKTVEpisodesIE('episodes')


# Generated at 2022-06-24 12:58:23.140899
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    tv_series_ie = NRKTVSeriesIE(None, None)
    sites, serie_kind, series_id = tv_series_ie._VALID_URL.match(url).groups()
    assert sites == 'tv.nrk'
    assert serie_kind == 'serie'
    assert series_id == 'groenn-glede'

# Generated at 2022-06-24 12:58:26.202064
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie is not None


# Generated at 2022-06-24 12:58:27.810927
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE()



# Generated at 2022-06-24 12:58:30.626046
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE('NRKTVSeries')
    assert ie.get_url_re() is not None

test_NRKTVSeriesIE()



# Generated at 2022-06-24 12:58:41.022076
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """Unit test for constructor of class NRKPlaylistBaseIE."""
    from .nrktvie import NRKTVIE
    from .nrktvplaylistie import NRKTVPlaylistIE
    from .nrktvseasonie import NRKTVSeasonIE
    from .nrktvseriesie import NRKTVSeriesIE
    from .nrktvdirekteie import NRKTVDirekteIE
    from .nrkradiopodkastie import NRKRadioPodkastIE
    from .nrktvseriebaseie import NRKTVSerieBaseIE


# Generated at 2022-06-24 12:58:44.286605
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
  test_inputs = ['http://www.nrk.no/sport/fotball/the-knockout-cup-1.1234']
  for test_input in test_inputs:
    test_obj = NRKPlaylistIE(urls=[test_input])
    assert(test_obj != None)



# Generated at 2022-06-24 12:58:55.335794
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist_attributes = ['_VALID_URL', '_ITEM_RE', '_TESTS']
    for attribute in playlist_attributes:
        assert hasattr(NRKPlaylistIE, attribute)
# Test to make sure the playlist_attributes are not none
    for attribute in playlist_attributes:
        assert getattr(NRKPlaylistIE, attribute) is not None
# Test to make sure it is the right type
    for attribute in playlist_attributes:
        assert isinstance(getattr(NRKPlaylistIE, attribute), object)
# Test to make sure the playlists are not empty
    for attribute in playlist_attributes:
        assert getattr(NRKPlaylistIE, attribute) != []


# Generated at 2022-06-24 12:59:06.838146
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    test = [
        ['https://tv.nrk.no/serie/tour-de-ski', False],
        ['https://tv.nrk.no/serie/tour-de-ski/sesong/1', False],
        ['https://tv.nrk.no/serie/tour-de-ski/sesong/1/episode/1', True],
        ['https://tv.nrk.no/serie/tour-de-ski/sesong/1/utfordring/1', True],
    ]
    for url, is_series in test:
        assert ie._is_series(url) == is_series

# Generated at 2022-06-24 12:59:09.009414
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie.IE_DESC is None
    assert ie._VALID_URL is None
    assert ie._ITEM_RE is None


# Generated at 2022-06-24 12:59:13.140552
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Test for successful instantiation
    try:
        NRKTVSeasonIE()
    except:
        raise AssertionError("NRKTVSeasonIE failed initialization")
test_NRKTVSeasonIE()



# Generated at 2022-06-24 12:59:24.748632
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Test KGrid embed
    webpage = '''
<body>
  <script type="text/javascript" src="//static.vrt.be/player/wrapper.js"></script>
  <script type="text/javascript">
      var kgrid = kgrid || [];
      kgrid.push({
          "id": "https://kgrid-objects.vrt.be/ebook/f1/2c/f1e5-5e5d-4b68-aef8-697daf1d2c9a/",
          "selector": "#kgrid-wrapper"
      });
  </script>
</body>
    '''
    base_ie = NRKTVSerieBaseIE(webpage, {}, NRKTVIE())

# Generated at 2022-06-24 12:59:25.825211
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()



# Generated at 2022-06-24 12:59:29.812611
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE()
    except Exception as e:
        assert False, "NRKTVSerieBaseIE constructor throws exception " + str(e)


# Generated at 2022-06-24 12:59:34.571823
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # test_NRKTVPlaylistIE
    nrk_playlist_base_ie = NRKPlaylistBaseIE()
    nrk_tv_playlist_ie = NRKTVPlaylistIE()
    nrk_radio_playlist_ie = NRKRadioPlaylistIE()

    url = 'https://nrk.no/programoversikt/'
    assert nrk_playlist_base_ie._match_id(url) == nrk_tv_playlist_ie._match_id(url)

    url = 'https://radio.nrk.no/programoversikt/'
    assert nrk_playlist_base_ie._match_id(url) == nrk_radio_playlist_ie._match_id(url)



# Generated at 2022-06-24 12:59:42.512780
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():

    # TODO:
    # Båtliv. Her er festen med «Kaptein Sabeltann»
    # https://tv.nrk.no/serie/batliv/MSB50013018/sesong-1/episode-72
    # https://www.nrk.no/sport/xl/omtankelig-takling-tok-gronn-av-ryktene-1.14423538
    # https://tv.nrk.no/serie/supernytt/MOLB66040118/sesong-1/episode-1
    # https://www.nrk.no/sport/fotball/mye-fotball_-men-ingen-nordmenn-i-champions-league-finalen-1.14470447
    pass



# Generated at 2022-06-24 12:59:46.688321
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert not ie.suitable('http://tv.nrk.no/serie/blank')
    assert not ie.suitable('https://radio.nrk.no/direkte/nrk-p1-oslo-akershus')

# Generated at 2022-06-24 12:59:48.088359
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE(None)
    assert isinstance(ie, NRKTVDirekteIE)


# Generated at 2022-06-24 12:59:53.216169
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie.IE_DESC == 'NRK Skole'


# Generated at 2022-06-24 12:59:59.467339
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk_direkte_url = 'https://tv.nrk.no/direkte/nrk1'
    nrk_direkte_info = {
        'id': 'nrk1',
        'title': 'NRK1 (Direkte)',
    }
    nrk_direkte_info_entries = {
        'id': 'nrk1',
        'title': 'NRK1 (Direkte)',
    }
    nrk_direkte_obj = NRKTVDirekteIE()
    nrk_direkte_obj._real_extract = lambda x,y: y
    nrk_direkte_obj._download_json = lambda x, y, z: y
    assert nrk_d

# Generated at 2022-06-24 13:00:11.438329
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    a = NRKTVEpisodeIE("https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2")
    assert a._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-24 13:00:12.170658
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-24 13:00:12.877267
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    pass



# Generated at 2022-06-24 13:00:15.732347
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Constructor of class NRKTVEpisodeIE
    # without passing any parameter
    assert_raises(
        TypeError, NRKTVEpisodeIE
    )


# Generated at 2022-06-24 13:00:19.692303
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    NRKSkoleIE(NRKSkoleIE._downloader, url)
    url = 'http://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    NRKSkoleIE(NRKSkoleIE._downloader, url)

# Generated at 2022-06-24 13:00:20.191930
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-24 13:00:23.929547
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert hasattr(NRKPlaylistBaseIE, '_extract_description')
    assert hasattr(NRKPlaylistBaseIE, '_download_webpage')
    assert hasattr(NRKPlaylistBaseIE, '_real_extract')


# Generated at 2022-06-24 13:00:30.689926
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    _NRKPlaylistBaseIE = NRKPlaylistBaseIE(NRKBaseIE())
    assert(_NRKPlaylistBaseIE._ITEM_RE == r'nrk:([\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})')



# Generated at 2022-06-24 13:00:34.545521
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from youtube_dl.utils import bug_reports_message
    from youtube_dl.downloader import YoutubeDL
    from .nrk import testcases

    for case in testcases.NRKBaseIETestCases:
        try:
            # Note: YoutubeDL._match_id is called in extract_info, so we mock it here.
            case.test_constructor(YoutubeDL, IE_NAME=case.ie_key, bug_reports_message=bug_reports_message)
        except Exception:
            # Print some info to figure out which unit test failed.
            print('test_constructor failed in test case: %r' % case)
            raise



# Generated at 2022-06-24 13:00:36.088459
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE.__new__(NRKTVSerieBaseIE)
    ie._initialize_extractor()
    pass


# Generated at 2022-06-24 13:00:42.055116
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test constructor of NRKPlaylistIE
    playlist_ie = NRKPlaylistIE()
    assert playlist_ie.IE_NAME == "nrk:playlist"
    assert playlist_ie.IE_DESC == "NRK: Playlists"
    assert playlist_ie.BRIGHTCOVE_URL_TEMPLATE == "http://nrk.scene7.com/is/image/nrk/%s"
    assert playlist_ie.BRIGHTCOVE_ID_TEMPLATE == "ID%s"



# Generated at 2022-06-24 13:00:45.829409
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    ie.suitable()
    ie.extract()

# Generated at 2022-06-24 13:00:52.837359
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert (NRKTVSerieBaseIE._catalog_name('serie') == 'series'
        and NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
        and NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
        and NRKTVSerieBaseIE._catalog_name('non-existed') == 'series')


# Generated at 2022-06-24 13:01:06.032820
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE('https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c')
    assert ie.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c') == True

# Generated at 2022-06-24 13:01:12.760752
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'NRK'
    assert ie.IE_DESC == 'NRK and NRK Super'
    assert ie.GEO_COUNTRIES == ['NO']
    assert ie.VALID_URL
    assert ie.CDN_REPL_REGEX == ''
    assert ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 13:01:15.572273
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    NRKPlaylistIE(NRKPlaylistIE, test_url)



# Generated at 2022-06-24 13:01:20.149551
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """
    Check that NRKTVDirekteIE doesn't crash in __init__ by using NRKTVIE constructor.
    """
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        obj = NRKTVDirekteIE()
        assert isinstance(obj, NRKTVIE)
        assert len(w) == 1
        assert w[0].category == DeprecationWarning
        assert str(w[0].message) == 'Please use the NRKTVIE class instead of NRKTVDirekteIE.'



# Generated at 2022-06-24 13:01:28.318172
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRK')
    assert ie.IE_NAME == 'NRK'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''

# Generated at 2022-06-24 13:01:36.301083
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE._GEO_COUNTRIES == ['NO']
    assert NRKBaseIE._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 13:01:38.237008
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    ie = NRKTVEpisodesIE()
    assert ie._match_id(url) == '69031'
    assert ie._match_id(url) != '7412'

# Generated at 2022-06-24 13:01:44.302116
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('NRKBaseIE', 'NRKBaseIE.ie_key()', 'NRKBaseIE.ie')
    assert repr(ie) == 'NRKTVSerieBaseIE(NRKBaseIE, NRKBaseIE.ie_key(), NRKBaseIE.ie)'



# Generated at 2022-06-24 13:01:50.317985
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/lindmo'
    ie = NRKTVSeriesIE(url)
    hashes = {}
    hashes[ie.inspect_url(url)] = [
        l.regex for l in ie.__class__._TESTS]
    assert hashes == {
        'https://tv.nrk.no/serie/lindmo': ["(?x)"]
    }

# Generated at 2022-06-24 13:01:53.547023
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """Simple test of a NRKTVDirekteIE constructor."""
    result = NRKTVDirekteIE(NRKTVDirekteIE._VALID_URL)
    if result.IE_NAME == NRKTVDirekteIE.IE_NAME:
        return True
    else:
        return False

# Generated at 2022-06-24 13:01:55.317602
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert_raises(NotImplementedError, NRKPlaylistBaseIE)



# Generated at 2022-06-24 13:01:58.834977
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Build the test case
    info_extractor = NRKTVEpisodesIE()

    # Execute constructor
    info_extractor = NRKPlaylistBaseIE()

    # Assert object was created correctly
    assert info_extractor

# Generated at 2022-06-24 13:02:07.795221
# Unit test for constructor of class NRKIE
def test_NRKIE():

    # Testing input of single-episode episode
    ep_url = 'https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533'
    info = NRKIE()._real_extract(ep_url)
    assert info['title'] == 'Dompap og andre fugler i Piip-Show'
    assert info['season_number'] is None
    assert info['episode_number'] is None

    # Testing input of multi-episode
    ep_url = 'https://www.nrk.no/video/kommentatorboksen-reiser-til-sjos_d1fda11f-a4ad-437a-a374-0398bc84e999'
    info = NRKIE()._real_extract(ep_url)

# Generated at 2022-06-24 13:02:08.959464
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert issubclass(NRKTVSerieBaseIE, NRKBaseIE)



# Generated at 2022-06-24 13:02:09.936693
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert issubclass(NRKPlaylistBaseIE, InfoExtractor)



# Generated at 2022-06-24 13:02:19.847052
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrkskole = NRKSkoleIE()
    assert (nrkskole.IE_DESC == 'NRK Skole')
    assert (nrkskole._VALID_URL ==
            r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)')

# Generated at 2022-06-24 13:02:20.744913
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    instance = NRKPlaylistBaseIE('NRKPlaylistBaseIE', 'NRKPlaylistBaseIE')
    assert instance

# Generated at 2022-06-24 13:02:34.907775
# Unit test for constructor of class NRKIE

# Generated at 2022-06-24 13:02:45.969521
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'
    playlist_id = 'rivertonprisen-til-karin-fossum-1.12266449'
    playlist_title = 'Rivertonprisen til Karin Fossum'
    playlist_description = 'Første kvinne på 15 år til å vinne krimlitteraturprisen.'

    instance = NRKPlaylistIE(NRKPlaylistIE.ie_key())

    assert_equal(repr(instance), ('NRKPlaylistIE('
                                  '%r, %r, %r)' %
                                  (url, playlist_id, playlist_title)))

# Generated at 2022-06-24 13:02:56.588598
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Test if NRKTVSerieBaseIE._extract_entries function works
    episode_list = [{'prfId': 'test1'}, {'episodeId': 'test2'}, {'invalid': 'test3'}, {}]
    expected = [
        'nrk:test1',
        'nrk:test2',
    ]
    assert NRKTVSerieBaseIE._extract_entries(episode_list) == expected
    # Test if NRKTVSerieBaseIE._ASSETS_KEYS constants works properly
    assert NRKTVSerieBaseIE._ASSETS_KEYS == ('episodes', 'instalments',)
    # Test if NRKTVSerieBaseIE._extract_assets_key function works

# Generated at 2022-06-24 13:03:08.272223
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    series_base = NRKTVSerieBaseIE()
    # Test entries with valid data, expect to get valid entries
    assert series_base._extract_entries([{'prfId': 'id1'}, {'prfId': 'id2'}]) == [
        {
            '_type': 'url',
            'ie_key': 'NRK',
            'id': 'id1',
            'url': 'nrk:id1',
        },
        {
            '_type': 'url',
            'ie_key': 'NRK',
            'id': 'id2',
            'url': 'nrk:id2',
        }
    ]
    # Test entries with invalid data, expect to get empty list

# Generated at 2022-06-24 13:03:21.593684
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie._match_id('nrk:150533')
    ie._match_id('nrk:clip/150533')
    ie._match_id('nrk:MDDP12000117')
    ie._match_id('nrk:program/ENRK10100318')
    ie._match_id('nrk:nrk1')
    ie._match_id('nrk:channel/nrk1')
    ie._match_id('nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9')
    ie._match_id('nrk:clip/ecc1b952-96dc-4a98-81b9-5296dc7a98d9')

# Generated at 2022-06-24 13:03:22.368765
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE()



# Generated at 2022-06-24 13:03:31.454551
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    def check_url(url, res):
        assert NRKTVSeriesIE.suitable(url) == res
    check_url('https://tv.nrk.no/serie/backstage', True)
    check_url('https://tv.nrk.no/serie/backstage/sesong/8', False)
    check_url('https://tv.nrk.no/serie/backstage/sesong/8/episode/8', False)
    check_url('https://tv.nrk.no/serie/groenn-glede', True)
    check_url('https://tv.nrk.no/serie/groenn-glede/sesong/2/episode/11', False)

# Generated at 2022-06-24 13:03:37.878514
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c')
    # Test for an URL with an ID that cannot be matched by the regular expression

# Generated at 2022-06-24 13:03:40.828924
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie
    assert isinstance(ie, NRKBaseIE)
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 13:03:47.633504
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        # make a valid URL for NRKTVIE
        url = 'https://tv.nrk.no/serie/hoyt-lavt/sesong/1/episode/1'
        # parse it with NRKTVSerieBaseIE
        NRKTVSerieBaseIE._extract_entries(id_or_url=url)
        # get the extracted video_id
        video_id = NRKTVSerieBaseIE.suitable(url)
        # create an instance of NRKTVIE
        nrk_tvie = NRKTVIE.suitable(video_id)
        # make sure the instance was correctly created
        assert nrk_tvie

    except Exception as e:
        # this should not happen when the unit test is run
        raise



# Generated at 2022-06-24 13:03:49.698493
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    infoExtractorNRKSkole = NRKSkoleIE()
    assert infoExtractorNRKSkole != None


# Generated at 2022-06-24 13:03:53.959182
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    extractor = NRKBaseIE(None)
    assert isinstance(extractor, InfoExtractor)
    assert extractor.IE_NAME == 'NRK'
    assert extractor._GEO_COUNTRIES == ['NO']
    assert 'nrk-od' in extractor._CDN_REPL_REGEX


# Generated at 2022-06-24 13:03:56.757081
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    IE = NRKTVEpisodeIE()
    assert IE._VALID_URL.match("https://www.nrk.no/smellkyss/sesong/1/episode/1")


# Generated at 2022-06-24 13:04:08.469776
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrkie = NRKIE()
    assert nrkie._GEO_COUNTRIES == ['NO']
    assert nrkie._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''

# Generated at 2022-06-24 13:04:10.108774
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrkradio_podkast_ie = NRKRadioPodkastIE()
    assert nrkradio_podkast_ie is not None

# Generated at 2022-06-24 13:04:17.085497
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # NRKTVSeriesIE.suitable() is False for URLs that are handled by NRKTVIE
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/dagsrevyen/')
    # NRKTVSeriesIE.suitable() is False for URLs that are handled by NRKTVEpisodeIE
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/dagsrevyen/2018/01/30/')
    # NRKTVSeriesIE.suitable() is False for URLs that are handled by NRKRadioPodkastIE
    assert not NRKTVSeriesIE.suitable('https://radio.nrk.no/podkast/dagsnytt/')
    # NRKTVSeriesIE.suitable() is False for URLs that are handled by NR

# Generated at 2022-06-24 13:04:22.887338
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """Test constructor of class NRKPlaylistBaseIE."""
    # Test with None URL
    ie = NRKPlaylistBaseIE(None)
    assert ie._VALID_URL == None
    assert ie.ie_key() == None
    assert ie.video_id == None
    assert ie.url == None

    # Test with empty URL
    ie = NRKPlaylistBaseIE("")
    assert ie._VALID_URL == ""
    assert ie.ie_key() == ""
    assert ie.video_id == ""
    assert ie.url == ""

    # Test with valid URL
    ie = NRKPlaylistBaseIE("https://tv.nrk.no/serie/groenn-glede")

# Generated at 2022-06-24 13:04:33.871749
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert isinstance(NRKTVSeasonIE(NRKTVSeasonIE._DOWNLOADER).suitable,
                      collections.Callable)
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/program/backstage')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')



# Generated at 2022-06-24 13:04:36.482635
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    global NRKTVIE
    NRKTVIE = NRKTVIE("NRKTVIE", [], {})


# Generated at 2022-06-24 13:04:44.277361
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    from .nrk import NRKTVEpisodeIE
    ie = NRKTVEpisodeIE()
    #a valid URL
    urltest = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    match = ie._VALID_URL
    id = ie._match_id(urltest)[0]
    assert re.match(match, urltest), 'Expected valid URL'
    assert id, 'Expected valid display_id'

# Generated at 2022-06-24 13:04:46.471192
# Unit test for constructor of class NRKRadioPodkastIE

# Generated at 2022-06-24 13:04:58.109438
# Unit test for constructor of class NRKBaseIE

# Generated at 2022-06-24 13:05:06.494238
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKRadioPlaylistIE('NRKRadioPlaylistIE')
    assert ie.ITEM_RE == 'data-media-id="(.+?)"'
    assert ie._TITLE_RE() == r'<title>(.+?)(?: - NRK[\s\-]+Radio)?</title>'
    assert ie._DESCRIPTION_RE() == r'(?s)<div>\s*<p>(.*?)</p>'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/programmer/(?:[^/]+/)+(?P<id>sport_lister/.+?)\.html'


# Generated at 2022-06-24 13:05:12.528186
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/Jul-i-skomakergata/461953')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/Ulrikkes Univers/461953')


# Generated at 2022-06-24 13:05:16.157764
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """Test constructor of class NRKTVIE"""
    with pytest.raises(ValueError, match='The NRK TV and NRK Radio extractor is deprecated. '
        'Please use the NRK base extractor instead.'):
        NRKTVIE('NRKTVIE')


# Generated at 2022-06-24 13:05:18.627603
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE.__name__ == 'NRKTVIE'
    # Assert that class NRKTVIE is a subclass of InfoExtractor
    assert issubclass(NRKTVIE, InfoExtractor)



# Generated at 2022-06-24 13:05:22.952859
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'
    assert ie.ie_key() != 'nrk_tv_episodes'



# Generated at 2022-06-24 13:05:25.405383
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert isinstance(ie, (NRKTVSerieBaseIE,))


# Generated at 2022-06-24 13:05:32.095014
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    actual = NRKRadioPodkastIE(NRKRadioPodkastIE.suitable(url))
    b = NRKRadioPodkastIE.suitable(url)
    expected = NRKRadioPodkastIE
    assert actual.__class__ == expected

# Test for _get_subtitles method of class NRKRadioPodkastIE

# Generated at 2022-06-24 13:05:32.844959
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()



# Generated at 2022-06-24 13:05:46.010935
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # pylint: disable=line-too-long
    URL = "https://tv.nrk.no/program/episodes/arilas-bedrift/" + \
          "avspiller/EP00008194/sesong/EP00008194/episode/EP000081940331"

    # Get a video extractor instance
    video_extractor = NRKTVEpisodesIE.new_from_url(URL)

    # Assert that the video extractor is an instance of class NRKTVEpisodesIE
    assert isinstance(video_extractor, NRKTVEpisodesIE)

    # Assert that the video extractor's regex for URL matches the given URL
    assert video_extractor._VALID_URL.search(URL) is not None

    # Assert that the video extractor's regex for the id from URL matches the
   

# Generated at 2022-06-24 13:05:59.362573
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    url = 'https://tv.nrk.no/serie/p3morgen/sesong/4/episode/4/playlist/4'
    webpage = ie._download_webpage(url, '4')
    entries = ie._extract_entries(webpage, '4')

# Generated at 2022-06-24 13:06:02.539797
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    assert NRKTVSeasonIE.suitable(url) == True



# Generated at 2022-06-24 13:06:04.257972
# Unit test for constructor of class NRKIE
def test_NRKIE():
    return NRKIE('NRK')


# Generated at 2022-06-24 13:06:16.045701
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert 'NRKTVSeasonIE' in globals()
    assert 'NRKTVSerieBaseIE' in globals()
    assert 'NRKTVSeriesIE' in globals()
    assert NRKTVSeriesIE.suitable('https://radio.nrk.no/serie/stroem/sesong/1')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/dagsrevyen') == False
    assert NRKTVSeriesIE.suitable('https://nrksuper.no/serie/labyrint')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1') == False

# Generated at 2022-06-24 13:06:24.725463
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IE = NRKBaseIE()
    assert IE._GEO_COUNTRIES == ['NO']
    assert IE._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''



# Generated at 2022-06-24 13:06:27.160078
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVIE._EPISODE_RE = r"Nytt på nytt, sesong: (201705)"
    assert NRKTVIE._EPISODE_RE == r"Nytt på nytt, sesong: (201705)"

# Generated at 2022-06-24 13:06:32.856690
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Check if NRKTVSeasonIE is removed from ie list
    NRKTVSeriesIE_class = NRKTVSeriesIE.__new__(NRKTVSeriesIE) # Doesn't call __init__()
    assert len(NRKTVSeriesIE_class._ies) == 1
    assert NRKTVSeasonIE not in NRKTVSeriesIE_class._ies
    assert NRKTVIE in NRKTVSeriesIE_class._ies



# Generated at 2022-06-24 13:06:33.802117
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    r = NRKTVEpisodeIE()
    assert r._VALID_URL

# Generated at 2022-06-24 13:06:37.622307
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    result = NRKTVEpisodesIE()
    assert isinstance(result, NRKTVBaseIE)


# Generated at 2022-06-24 13:06:42.328784
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    inst = NRKTVIE()
    assert inst.IE_DESC == 'NRK TV and NRK Radio'
    assert isinstance(inst._EPISODE_RE, str)
    assert isinstance(inst._VALID_URL, str)
    assert isinstance(inst._TESTS, list)

# Generated at 2022-06-24 13:06:51.465372
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    info_extractor = NRKTVEpisodeIE()
    assert info_extractor._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-24 13:06:53.731266
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE('nrk:program/FJAF42000816')
    assert ie.video_id == 'FJAF42000816'



# Generated at 2022-06-24 13:06:55.858244
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE()
    except NameError as e:
        raise AssertionError(e)
    except AttributeError as e:
        raise AssertionError(e)



# Generated at 2022-06-24 13:06:57.515791
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert isinstance(NRKTVSerieBaseIE(), InfoExtractor)



# Generated at 2022-06-24 13:06:58.098910
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    pass



# Generated at 2022-06-24 13:07:09.668818
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    video_id = 14099
    nrk_id = 6021
    nrk_id_json = '{"psId": "6021","mediaType": "VIDEO"}'
    nrk_id_json_bytes = nrk_id_json.encode('utf-8')

    @mock.patch('urllib.request.urlopen')
    def test_NRKSkoleIE(urlopen):
        urlopen.return_value.read.return_value = nrk_id_json_bytes

        assert NRKSkoleIE._real_extract('https://www.nrk.no/skole/?page=search&q=&mediaId=%s' % video_id) == \
        NRKIE._real_extract('nrk:%s' % nrk_id)

    test_

# Generated at 2022-06-24 13:07:13.016271
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    instance = NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')
    assert instance.get_formats(instance)



# Generated at 2022-06-24 13:07:16.118743
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # test checked 5.9.2015
    result = NRKPlaylistBaseIE.suitable(NRKPlaylistBaseIE._VALID_URL)
    assert(result)



# Generated at 2022-06-24 13:07:22.117605
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    assert NRKSkoleIE.suitable(url)
    ie = NRKSkoleIE(url)
    url_result = ie._real_extract(url)
    assert url_result['id'] == '6021'
    assert url_result['url'] == 'nrk:6021'

# Generated at 2022-06-24 13:07:25.670883
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()

    # test NRKPlaylistIE __init__ function
    assert ie.ie_key() == 'NRKPlaylist'
    assert ie.ie_key() != 'NRKPlaylistBase'



# Generated at 2022-06-24 13:07:26.487439
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE(NRKTVSeriesIE.ie_key()) is not None

# Generated at 2022-06-24 13:07:28.784645
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Must not raise any exception
    NRKTVSeriesIE()



# Generated at 2022-06-24 13:07:31.824700
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    constructor = NRKSkoleIE().__class__
    assert constructor.__name__ == 'NRKSkoleIE'
    assert constructor.__module__ == 'nrk_extractor'


# Generated at 2022-06-24 13:07:36.697928
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url='https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2'
    retval = parse_qs(urlparse(url).query)
    assert retval['del'] == ['2']
    assert retval['del'][0] == '2'


# Generated at 2022-06-24 13:07:40.872566
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    NRKSkoleIE(NRKBaseIE())._real_initialize()
    NRKSkoleIE(NRKBaseIE())._real_extract(url)


# Generated at 2022-06-24 13:07:48.014357
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    podkast = NRKRadioPodkastIE()
    assert podkast.ie_key() == 'NRKRadioPodkast'
    assert podkast._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert podkast.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-24 13:07:50.918923
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('http://tv.nrk.no/serie/folkeopplysningen')
    assert ie.INVALID_URL == 'Invalid URL'
    ie = NRKBaseIE('http://tv.nrk.no/serie/folkeopplysningen', '-N')
    assert ie.get_geo_restricted() == False


# Generated at 2022-06-24 13:07:55.928051
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Test simpleinput.txt containing one line.
    def test_input(filename, string):
        with open(filename, 'w') as f:
            f.write(string)
        with open(filename, 'r') as f:
            for line in f:
                assert line == string
        os.remove(filename)
    test_input('simpleinput.txt', 'https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13')

    # Make an instance of class NRKTVIE
    ie = NRKTVIE()

    # Assert data is not None
    assert ie != None

    # Assert episode number is 13.
    assert ie.episode_number == 13

    episode_number = None
    # Assert episode number is 13.
    assert ie.episode