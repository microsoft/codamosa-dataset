

# Generated at 2022-06-24 12:58:07.359606
# Unit test for constructor of class NRKRadioPodkastIE

# Generated at 2022-06-24 12:58:17.188459
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Create instance
    inst = NRKTVSerieBaseIE()
    # Check attributes
    assert inst._VALID_URL == None
    assert inst._TESTS == []
    assert inst._TEST
    assert inst.IE_NAME == 'nrktv'
    assert inst.IE_DESC == 'NRK TV and NRK Radio'
    assert inst._API_BASE == 'https://tv-api.nrk.no'
    assert inst._API_REQUEST_HEADERS
    assert inst._API_CACHE_NAMESPACE == 'nrktv'
    assert inst._TOKEN_SECRET == 'a1b2c3d4e5f6123456'
    assert inst._TOKEN_TTL == 14400
    assert inst._TIMESTAMP_GRACE == 300
    assert inst._DRM

# Generated at 2022-06-24 12:58:20.068226
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert re.search(r'nrk-od-\d{2}\.akamaized\.net', NRKBaseIE()._CDN_REPL_REGEX)


# Generated at 2022-06-24 12:58:21.847116
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nor.NRKTVEpisodeIE(extractor=None, downloader=None, download_mode=None, age_limit=None, params=None, _cache_root=None)

# Generated at 2022-06-24 12:58:27.281333
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrkie = NRKIE()
    assert nrkie._GEO_COUNTRIES == ['NO']
    assert nrkie._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 12:58:29.319756
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlistname = 'TestName'
    url = 'https://www1.nrk.no/kringkaster/test'
    item = NRKPlaylistBaseIE(playlistname, url)
    assert isinstance(item, NRKPlaylistBaseIE)
    assert item.playlistname == playlistname
    assert item.url == url


# Generated at 2022-06-24 12:58:30.831355
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE(None) # should not fail


# Generated at 2022-06-24 12:58:32.827531
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE()._EPISODE_RE == NRKTVIE._EPISODE_RE


# Generated at 2022-06-24 12:58:40.342094
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    display_id, season_number, episode_number = re.match(NRKTVEpisodeIE.__module__.split('.')[-1].upper()._VALID_URL, url).groups()
    webpage = NRKTVEpisodeIE.__module__.split('.')[-1]._download_webpage(url, display_id)

    info = NRKTVEpisodeIE.__module__.split('.')[-1]._search_json_ld(webpage, display_id, default={})

# Generated at 2022-06-24 12:58:43.070448
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    import sys
    sys.path[0:0] = ['.', '..']
    from tests import get_testcases
    for t in get_testcases(globals().get('__name__'), globals()):
        yield t



# Generated at 2022-06-24 12:58:53.473090
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS == [{'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031', 'info_dict': {'id': '69031', 'title': 'Nytt på nytt, sesong: 201210'}, 'playlist_count': 4}]


# Generated at 2022-06-24 12:59:02.861712
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = (NRKTVDirekteIE, NRKTVIE)
    # I think it is not possible to check constructors using pytest.
    # https://docs.pytest.org/en/latest/example/parametrize.html#a-quick-port-of-testscenarios
    for clazz in ie:
        clazz(None, 'nrk:direkte/nrk1')._call_api('direkte/nrk1', 'nrk1', 'direkte', note='Downloading direkte JSON')


# Generated at 2022-06-24 12:59:09.257030
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    ie.IE_NAME = 'NRK'
    ie.IE_DESC = 'NRK'
    ie.tests[0].update({ 
        'url': 'https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c',
        'only_matching': True,
    })

# Generated at 2022-06-24 12:59:11.908797
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .nrktv import NRKTVDirekteIE
    NRKTVDirekteIE()


# Generated at 2022-06-24 12:59:12.717140
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE
    assert(ie != None)

# Generated at 2022-06-24 12:59:16.672822
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    nrktvie = NRKTVEpisodeIE()
    nrktvie.suitable(url)

# Generated at 2022-06-24 12:59:20.032421
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE()._VALID_URL == NRKSkoleIE._VALID_URL
    assert NRKSkoleIE().IE_DESC == NRKSkoleIE.IE_DESC
    assert NRKSkoleIE()._TESTS == NRKSkoleIE._TESTS

# Generated at 2022-06-24 12:59:26.247422
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    with pytest.raises(TypeError):
        NRKTVSeasonIE('serie', '1')
    with pytest.raises(TypeError):
        NRKTVSeasonIE('serie', '1', '1')
    assert NRKTVSeasonIE('serie', '1', '12345678910', '1')
    assert NRKTVSeasonIE('serie', '1', '1', '1')


# Generated at 2022-06-24 12:59:29.401954
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk_live_test = NRKTVDirekteIE()
    assert nrk_live_test is not None


# Generated at 2022-06-24 12:59:39.421191
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    test_urls = [
        'https://tv.nrk.no/serie/backstage/sesong/1',
        'https://tv.nrk.no/serie/lindmo/2016',
        'https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1',
        'https://radio.nrk.no/serie/dagsnytt/sesong/201509',
        'https://tv.nrk.no/serie/spangas/sesong/1',
        'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant',
        'https://radio.nrk.no/podkast/loerdagsraadet/sesong/202101',
    ]

# Generated at 2022-06-24 12:59:48.210408
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE._match_url('http://www.nrk.no/video/PS*154915')
    assert NRKIE._match_id('http://www.nrk.no/video/PS*154915')
    assert NRKIE._match_id('nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9')
    assert NRKIE._match_id('nrk:clip/7707d5a3-ebe7-434a-87d5-a3ebe7a34a70')
    assert NRKIE._match_id('https://v8-psapi.nrk.no/mediaelement/ecc1b952-96dc-4a98-81b9-5296dc7a98d9')
    assert NRKIE._

# Generated at 2022-06-24 12:59:49.130536
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert 'NRKTVEpisodeIE' in globals()


# Generated at 2022-06-24 13:00:01.806206
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE(): #
    from ytdl.extractor.common import InfoExtractor

    YoutubeIE = type('YoutubeIE', (NRKPlaylistBaseIE,), {
        '_VALID_URL': '^https?://(?:www\.)?youtube\.com',
        '_ITEM_RE': '[-\w]+',
        '_extract_title': lambda x: 'title',
        '_extract_description': lambda x: 'description',
    })

    # Make sure class is an InfoExtractor object
    assert isinstance(YoutubeIE(), InfoExtractor)

    # Make sure class has a valid _VALID_URL
    assert re.match(NRKPlaylistBaseIE._VALID_URL, 'https://www.youtube.com')

    # Make sure class has a valid _ITEM_RE

# Generated at 2022-06-24 13:00:06.166846
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Issue #15340
    url = 'https://tv.nrk.no/serie/groenn-glede?q'
    nrktvsie = NRKTVSeriesIE(None)
    assert nrktvsie.suitable(url)


# Generated at 2022-06-24 13:00:09.179663
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE.suitable('https://www.nrk.no/slik-hjelper-du-barnet-ditt-med-regning-1.14495073')



# Generated at 2022-06-24 13:00:13.289822
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE(_downloader=None, url='https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031', video_id='69031')
    assert ie.url == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert ie.video_id == '69031'

NRKTVEpisodeIE = NRKTVEpisodesIE



# Generated at 2022-06-24 13:00:24.174318
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from .common import InfoExtractor
    from .nrk import NRKPlaylistIE
    from .nrktv import NRKTVIE
    from .nrksupert import NRKSupertIE
    
    # Test the handling of Error
    nrk = NRKBaseIE()
    nrk._raise_error({'error': 'ProgramRightsAreNotReady'})
    

# Generated at 2022-06-24 13:00:30.528251
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    try:
        # Check that NRKSkoleIE.__doc__ is updated after modifying the class
        assert NRKSkoleIE.__doc__ == NRKSkoleIE.IE_DESC
    except AssertionError:
        # If the unit test failed, it could be that the class has been renamed
        # or removed
        pass

# Generated at 2022-06-24 13:00:38.574219
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """
    Constructor of class NRKTVEpisodeIE should return a NRKTVEpisodeIE object.
    The test also cover the code coverage of constructor's initial part.
    """
    extractor_class = NRKTVEpisodeIE
    assert isinstance(
        extractor_class,
        type), 'The constructor of class NRKTVEpisodeIE should be type.'
    # Invoke the constructor
    extractor = extractor_class()
    assert isinstance(extractor,
                      NRKTVEpisodeIE), 'The constructor should return a NRKTVEpisodeIE object.'


# Generated at 2022-06-24 13:00:40.463218
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk = NRKRadioPodkastIE()
# The constructor doesn't return anything
    assert(nrk is not None)


# Generated at 2022-06-24 13:00:43.311258
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Testing for a class constructor with one argument
    class_name = NRKPlaylistIE()
    assert(class_name)



# Generated at 2022-06-24 13:00:55.810719
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from .nrkplaylist import NRKPlaylistIE
    from .nrktv import NRKTVIE
    from .nrktv_episode import NRKTVEpisodeIE
    from .nrktv_season import NRKTVSeasonIE

    # Test with NRKPlaylistIE
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/lindmo')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/program/BOKU20002162/bokkilden-julekalenderen')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/lindmo/sesong/1')

# Generated at 2022-06-24 13:00:59.539286
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE('NRKPlaylistBaseIE')
    except Exception as e:
        assert False, e
        return False


# Generated at 2022-06-24 13:01:04.650694
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('broadcast') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'



# Generated at 2022-06-24 13:01:17.592478
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Assert that the channel name of a channel extracted by the NRKTVIE can be
    # found in the channel list of the NRKTVIE.
    assert("nrk_super" in NRKTVIE.CHANNELS.keys())
    # Assert that the channel name of a channel extracted by the NRKTVIE can be
    # found in the channel list of the NRKTVIE.
    assert("nrk_mp3" not in NRKTVIE.CHANNELS.keys())

    # Assert that the constructor raises an error if an invalid url is
    # given. The url of NRK is not a valid url for NRKTVIE, so this makes sure
    # that the constructor complains.

# Generated at 2022-06-24 13:01:23.680633
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    (NRKTVSeasonIE().
        _extract_entries(
            # A real example episode list of a podcast season
            [{
                'prfId': 'NPUB21024115',
            }, {
                'prfId': 'NPUB21024214',
            }, {
                'prfId': 'NPUB21024314',
            }]
        ))


# Generated at 2022-06-24 13:01:26.105567
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    with pytest.raises(TypeError, message='NRKTVSerieBaseIE cannot be instantiated'):
        ie.__init__()



# Generated at 2022-06-24 13:01:28.434371
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    i = InfoExtractor(NRKPlaylistIE)
    assert str(i.__class__) == "NRKPlaylistIE"
    assert i.ie_key() == 'NRKPlaylist'


# Generated at 2022-06-24 13:01:39.577626
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE(None)
    assert ie._ITEM_RE == r'nrksuper:media\.([\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie.__name__ == 'NRKPlaylistBase'
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK Playlists'
    assert ie.IE_VERSION == '1.0'
    assert ie.VALID_URL == r'https?://(?:www\.)?nrk\.no/(?:super/)?video/[^/]+/playlists/(?!_artikkel)[^/?#&]+\.html'


# Generated at 2022-06-24 13:01:45.312677
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    b = NRKTVIE()
    # test __init__
    def test_init():
        assert b.extractor_key == 'NRKTV'
    # test _VALID_URL
    def test_valid_url():
        assert b._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    # test _EPISODE_RE
    def test_episode_re():
        assert b._EPISODE_RE == '(?P<id>[a-zA-Z]{4}\d{8})'
    # test _download_json
    def test_download_json():
        pass
    # test _extract_nrk_formats
   

# Generated at 2022-06-24 13:01:46.832021
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie is not None



# Generated at 2022-06-24 13:01:47.849251
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE();



# Generated at 2022-06-24 13:01:49.917430
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-24 13:01:51.935534
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE(None)
    assert isinstance(ie, NRKBaseIE)



# Generated at 2022-06-24 13:01:52.508746
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert True

# Generated at 2022-06-24 13:01:54.113775
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')

# Generated at 2022-06-24 13:01:57.493101
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # NRKTVEpisodesIE should use NRKTVIE as it's default downloader.
    assert NRKTVEpisodesIE.ie_key() == NRKTVIE.ie_key()

# Generated at 2022-06-24 13:02:05.079790
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.IE_DESC == 'NRK Radio Podkast and NRK TV Podkast'
    assert ie._VALID_URL == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie._TESTS[0]['url'] == 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert ie._TESTS

# Generated at 2022-06-24 13:02:08.062573
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    nrk_skole_ie = NRKSkoleIE(url)
    assert nrk_skole_ie._match_id(url) == '14099'


# Generated at 2022-06-24 13:02:09.859758
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert issubclass(NRKTVSerieBaseIE, NRKBaseIE)
    assert issubclass(NRKTVSerieBaseIE, InfoExtractor)


# Generated at 2022-06-24 13:02:11.526444
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert isinstance (
        NRKTVEpisodeIE(),
        NRKTVEpisodeIE
    )

# Generated at 2022-06-24 13:02:16.100903
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE("NRKRadioPodkastIE")
    assert(re.match(NRKRadioPodkastIE._VALID_URL,
                    "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8") != None)
    assert(re.match(NRKRadioPodkastIE._VALID_URL,
                    "https://radio.nrk.no/podcast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8") != None)

# Generated at 2022-06-24 13:02:29.237830
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_url = 'http://www.nrk.no/'
    test_obj = NRKBaseIE()
    assert test_obj._GEO_COUNTRIES == ['NO']
    assert test_obj._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
    assert test_obj._extract_nrk_formats(test_url, 'test_video') == None
    assert test

# Generated at 2022-06-24 13:02:30.774219
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IE = NRKBaseIE()
    assert (IE is not None)


# Generated at 2022-06-24 13:02:35.095855
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    x = NRKRadioPodkastIE()
    if (x.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')):
        assert x._real_extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-24 13:02:46.098931
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031');
    check_assertion(ie.REAL_URL == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031', 'REAL_URL was not set correctly');
    check_assertion(ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)', '_VALID_URL was not set correctly');
    check_assertion(ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE, '_ITEM_RE was not set correctly');
    check

# Generated at 2022-06-24 13:02:47.400390
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE('NRKTVIE', 'nrk')

# Generated at 2022-06-24 13:02:49.980938
# Unit test for constructor of class NRKTVEpisodesIE

# Generated at 2022-06-24 13:02:54.479803
# Unit test for constructor of class NRKIE
def test_NRKIE():
    url= "http://www.nrk.no/video/PS*154915"
    ie= NRKIE()
    ie._match_id(url)
    ie._real_extract(url)


# Generated at 2022-06-24 13:03:00.988549
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    url = 'https://www.nrk.no/kultur/toppsaker/'
    playlist_id = 'toppsaker'

# Generated at 2022-06-24 13:03:06.243247
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """
    Test if NRKTVIE has been initialized with a valid URL.
    :return:
    """
    ie_instance = NRKTVIE(NRKTVIE._VALID_URL)
    assert ie_instance is not None, 'NRKTVIE not initialized with a valid URL'



# Generated at 2022-06-24 13:03:09.756669
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://nrk.no/x/podkast/laering-gjennom-barnas-oiner-1.12308922'
    instance = NRKPlaylistIE(url)
    assert instance._match_id(url) == 'laering-gjennom-barnas-oiner-1.12308922'
    assert instance._extract_description(url) is None
    assert type(instance._extract_title(url)) is NoneType
    assert instance._real_extract(url) is not None



# Generated at 2022-06-24 13:03:12.259628
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert isinstance(NRKSkoleIE(None, {}), NRKSkoleIE)

# Generated at 2022-06-24 13:03:14.584309
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    instance = NRKTVIE(FakeYDL())
    assert isinstance(instance, NRKTVIE)

# Generated at 2022-06-24 13:03:18.915624
# Unit test for constructor of class NRKIE
def test_NRKIE():
    url = 'http://www.nrk.no/video/PS*150533'
    nrk = NRKIE()
    nrk._match_id(url)
    nrk._real_extract(url)


# Generated at 2022-06-24 13:03:27.909309
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """
    This is not a real unit test, but it does confirm that
    the subclasses of NRKPlaylistBaseIE, namely NRKTVPlaylistsIE and
    NRKTVToplistIE, have been created, which is the only way to check that
    the base class has been properly instantiated.
    The subclasses have no test cases of their own because they do not parse
    their argument.
    """
    tv_playlists_ie = NRKTVPlaylistsIE.suitable('')
    tv_toplist_ie = NRKTVToplistIE.suitable('')

    assert tv_playlists_ie
    assert tv_toplist_ie

# Generated at 2022-06-24 13:03:37.284173
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_cases = [
        'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763',
        'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449',
    ]

    for test_case in test_cases:
        playlist_ie = NRKPlaylistIE(downloader=None).url_result(test_case)
        assert playlist_ie is not None

# Minimal unit test for constructor of class NRKPlaylistBaseIE

# Generated at 2022-06-24 13:03:41.797348
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # test a correct url
    correct_url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert re.match(NRKTVEpisodeIE._VALID_URL, correct_url)
    # test an invalid url
    invalid_url = 'https://tv.nrk.no/serie/aasdf/sesong/1/episode/2'
    assert not re.match(NRKTVEpisodeIE._VALID_URL, invalid_url)



# Generated at 2022-06-24 13:03:45.647953
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # create an instance of the class
    class_instance = NRKTVSerieBaseIE()
    assert class_instance._ASSETS_KEYS == ('episodes', 'instalments',)
    assert class_instance._catalog_name('podcast') == 'podcast'
    assert class_instance._catalog_name('podkast') == 'podcast'
    assert class_instance._catalog_name('series') == 'series'



# Generated at 2022-06-24 13:03:50.969207
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.name == 'nrk:l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert ie.ie_key() == 'NRKRadioPodkast'
    assert ie.ie_key() == 'NRKRadioPodkast'
    assert ie.thumbnail == 're:https?://.*\.jpg'



# Generated at 2022-06-24 13:03:52.575081
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    nrk._match_id("nrk:channel/nrk1")

# Generated at 2022-06-24 13:03:55.137082
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    from .nrktv import NRKTVSerieIE

    assert NRKTVSerieIE.__bases__ == (NRKTVSerieBaseIE,)



# Generated at 2022-06-24 13:04:06.851170
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    obj = NRKBaseIE(None)
    assert obj.IE_NAME == "NRKBaseIE"
    assert obj.ie_key() == "NRKBaseIE"
    assert obj.IE_DESC == "NRKBaseIE"
    assert obj._GEO_COUNTRIES == ["NO"]
    assert obj._CDN_REPL_REGEX == "(?x)://\nnrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|\nnrk-od-no\\.telenorcdn\\.net|\nminicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no\n/"
    assert obj._extract_

# Generated at 2022-06-24 13:04:12.687803
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrkTVDirekteIE = NRKTVDirekteIE()
    assert nrkTVDirekteIE.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert nrkTVDirekteIE._VALID_URL  == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 13:04:16.559274
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        from nose.tools import assert_true # pylint: disable=unused-import
        # Calling the constructor directly will result in a TypeError exception
        # unit_test_NRKTVSeriesIE() will not be called if this test is executed
        assert_true(False)
    except TypeError:
        pass


# Generated at 2022-06-24 13:04:28.096553
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    nrktv_episode_ie = NRKTVEpisodeIE(NRKTVEpisodeIE._build_url_result(url));

    assert nrktv_episode_ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert nrktv_episode_ie._downloader.yp_extractor.ie_key() == NRKIE.ie_key()



# Generated at 2022-06-24 13:04:32.154029
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    episode = NRKTVEpisodeIE()
    episode._real_extract(url)

# Generated at 2022-06-24 13:04:41.571616
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE('nrk', 'nrk:MDDP12000117')
    assert nrktvie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % nrktvie._EPISODE_RE
    assert nrktvie._TESTS

# Generated at 2022-06-24 13:04:43.998336
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie._EPISODE_RE

# Generated at 2022-06-24 13:04:47.209179
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    testee = NRKBaseIE()
    result = testee._GEO_COUNTRIES
    expected = ['NO']
    assert result == expected


# Generated at 2022-06-24 13:04:52.257933
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    inst = NRKRadioPodkastIE()
    inst.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')



# Generated at 2022-06-24 13:04:59.635420
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE.IE_NAME != ''
    assert NRKBaseIE.IE_DESC != ''
    assert len(NRKBaseIE._GEO_COUNTRIES) > 0
    assert NRKBaseIE._CDN_REPL_REGEX != ''
    assert NRKBaseIE.test_NRKBaseIE.__name__ != ''
    assert NRKBaseIE.test_NRKBaseIE.__doc__ != ''
    assert isinstance(NRKBaseIE._GEO_COUNTRIES, list)



# Generated at 2022-06-24 13:05:02.035522
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE("https://tv.nrk.no/serie/backstage/sesong/1", {}, {}, True)



# Generated at 2022-06-24 13:05:03.346825
# Unit test for constructor of class NRKIE
def test_NRKIE():
    instance = NRKIE()
    assert instance is not None



# Generated at 2022-06-24 13:05:04.151703
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()



# Generated at 2022-06-24 13:05:11.464489
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # pylint: disable=protected-access
    NRKTVDirekteIE._download_webpage = lambda *args, **kwargs: '{}'
    NRKTVDirekteIE._real_extract = lambda *args, **kwargs: {'id': 'NRKTVDirekteIE'}
    ie = NRKTVDirekteIE('http://tv.nrk.no/direkte/nrk1')('http://tv.nrk.no/direkte/nrk1')
    assert ie.ie_key() == 'NRKTVDirekte'

# Generated at 2022-06-24 13:05:13.791784
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    return NRKPlaylistBaseIE('NRKPlaylistBaseIE', 'nrk.no')


# Generated at 2022-06-24 13:05:19.432636
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/innafor')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/innafor')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/innafor/sesong/1/episode/1')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/podcast/')

# Generated at 2022-06-24 13:05:22.156595
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test_input = ('150533')
    ie = NRKIE()
    ie.constructor_test(test_input)



# Generated at 2022-06-24 13:05:26.631571
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from exports.extractors import nrktv
    ie = nrktv.NRKTVIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.__name__ == 'NRKBaseIE'
    assert repr(nrktv.NRKTVIE()) == repr(nrktv.NRKTVIE)
    ie2 = nrktv.NRKTVIE()
    assert ie == ie2
    assert ie != nrktv.NRKPlaylistIE()
    assert ie != nrktv.NRKTVIE(url='http://www.nrk.no')


# Generated at 2022-06-24 13:05:29.258687
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    nrktvepisodeie = NRKTVEpisodeIE()
    assert nrktvepisodeie.suitable(url)



# Generated at 2022-06-24 13:05:30.278052
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie



# Generated at 2022-06-24 13:05:31.153051
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-24 13:05:44.261297
# Unit test for constructor of class NRKTVSeasonIE

# Generated at 2022-06-24 13:05:45.129390
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert isinstance(NRKPlaylistBaseIE(), InfoExtractor)


# Generated at 2022-06-24 13:05:49.714530
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.IE_NAME == 'NRK:Direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-24 13:05:57.393684
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE(NRKIE())
    if not ie.suitable(url):
        raise Exception('Invalid url: %s' % url)


# Generated at 2022-06-24 13:06:06.788398
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert not ie._extract_assets_key({})
    assert 'episodes' == ie._extract_assets_key({'episodes': {}})
    assert 'instalments' == ie._extract_assets_key({'instalments': {}})
    assert not ie._extract_assets_key({'episodes': {}}, False)
    assert 'episodes' == ie._extract_assets_key({'episodes': {}})
    assert 'instalments' == ie._extract_assets_key({'instalments': {}}, False)



# Generated at 2022-06-24 13:06:12.925502
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert(
        NRKRadioPodkastIE(
            NRKRadioPodkastIE._downloader,
            'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')._VALID_URL
        == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    )



# Generated at 2022-06-24 13:06:18.162415
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    serie_json = {
        '_embedded': {
            'instalments': [
                {
                    'prfId': 'SID-001',
                    'episodeId': 'SID-000'
                },
                {
                    'prfId': 'SID-002',
                    'episodeId': 'SID-001'
                }
            ],
            'episodes': [
                {
                    'prfId': 'SEID-001',
                    'episodeId': 'SEID-000'
                },
                {
                    'episodeId': 'SEID-001',
                    'prfId': 'SEID-002'
                }
            ]
        }
    }
    serie_base = NRKTVSerieBaseIE()

# Generated at 2022-06-24 13:06:24.460180
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE("https://radio.nrk.no/serie/dagsnytt/sesong/201507")
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''
    assert ie.suitable("https://radio.nrk.no/serie/dagsnytt/sesong/201507")

# Generated at 2022-06-24 13:06:28.149765
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.IE_NAME == 'NRKPlaylist'
    assert ie._VALID_URL == NRKPlaylistIE._VALID_URL
    assert ie._TITLE_RE == NRKPlaylistIE._TITLE_RE
    assert ie._ITEM_RE == NRKPlaylistIE._ITEM_RE
    assert ie._TESTS == NRKPlaylistIE._TESTS


# Generated at 2022-06-24 13:06:33.884983
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie.IE_NAME == 'nrktv'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'

# Generated at 2022-06-24 13:06:36.114662
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    obj = NRKTVIE()

# Generated at 2022-06-24 13:06:42.040393
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert ie.ie_key() == 'NRKSkole'
    assert ie.info_extractors[0].ie_key() == 'NRKIE'


# Generated at 2022-06-24 13:06:46.312652
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-24 13:06:48.002178
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert "NRKTVIE" in globals()
    NRKTVIE()

# Generated at 2022-06-24 13:06:54.946065
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    from youtube_dl.extractor.nrk import NRKSkoleIE

    url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    ie = NRKSkoleIE(None)
    assert(ie.suitable(url))
    assert(ie.ie_key() == 'NRKSkole')
    assert(ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)')

# Generated at 2022-06-24 13:06:56.915240
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie_result = NRKPlaylistIE._build_url_result
    assert ie_result is not None



# Generated at 2022-06-24 13:07:05.055266
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrk_tv_ie = NRKTVIE()
    assert nrk_tv_ie.IE_DESC == 'NRK TV and NRK Radio'
    assert nrk_tv_ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert nrk_tv_ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % nrk_tv_ie._EPISODE_RE


# Generated at 2022-06-24 13:07:07.937947
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrk_playlist_base_ie = NRKPlaylistBaseIE("NRKPlaylistBaseIE")

    assert nrk_playlist_base_ie._VALID_URL == r'https?://tv\.nrk\.no/(serie/[^/]+/)(sesong/[^/?#&]+|)(\?.*)?$'


# Generated at 2022-06-24 13:07:11.080680
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = get_info_extractor(NRKTVSeriesIE.ie_key())
    ie.suitable(NRKTVSeriesIE._VALID_URL)


# Generated at 2022-06-24 13:07:12.223491
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE is not None



# Generated at 2022-06-24 13:07:14.431701
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    with pytest.raises(TypeError):
        NRKTVSerieBaseIE()



# Generated at 2022-06-24 13:07:24.829794
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    for ie_class in (NRKTVSeriesIE, NRKTVSeasonIE):
        for entry in test_NRKTVSeriesIE.__dict__:
            if (entry.startswith('_TESTS') and isinstance(test_NRKTVSeriesIE.__dict__[entry], list)
                and ie_class._TESTS != test_NRKTVSeriesIE.__dict__[entry]):
                ie_class._TESTS = test_NRKTVSeriesIE.__dict__[entry]
                break
    to_screen(ie_class.__name__)
    new_instance = ie_class(url='https://tv.nrk.no/serie/groenn-glede')
    assert isinstance(new_instance, NRKTVSeriesIE)

# Generated at 2022-06-24 13:07:27.972716
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert(ie)


# Generated at 2022-06-24 13:07:37.696223
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/kroppen/sesong/1/episode/1'
    # Create new NRKTVEpisodeIE object
    episode_obj = NRKTVEpisodeIE()
    obj = NRKPlaylistBaseIE()
    print("\nUnit test for _extract_title() for NRKTVEpisodeIE object:")
    assert obj._extract_title(episode_obj._download_webpage(url, 'kroppen/1/1')) == 'Kroppens mysterier – Sesong 1'
    print("passed\n")
    print("\nUnit test for _extract_description() for NRKTVEpisodeIE object:")

# Generated at 2022-06-24 13:07:39.418024
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """
    Unit test for constructor of class NRKIE
    """
    NRKIE()



# Generated at 2022-06-24 13:07:46.820375
# Unit test for constructor of class NRKIE
def test_NRKIE():
    import unittest.mock
    # Add the function _download_json to the class NRKBaseIE

# Generated at 2022-06-24 13:07:48.205943
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._ITEM_RE == None
    assert ie._VALID_URL == None


# Generated at 2022-06-24 13:07:51.886233
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Create instance of class NRKRadioPodkastIE
    NRKRadioPodkastIE1 = NRKRadioPodkastIE()
    # Test _VALID_URL
    assert NRKRadioPodkastIE1._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-24 13:07:55.921645
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    '''
    The name of the current class
    '''
    name = 'NRKTVDirekteIE'
    # The unit test
    assert NRKTVDirekteIE.suitable(name)

# Generated at 2022-06-24 13:08:02.188054
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/20-spoersmaal-tv/MUHH48000314/23-05-2014'
    instance = NRKTVEpisodeIE(NRKIE())
    # nrk_id is name of the variable after the instance of NRKTVEpisodeIE()
    nrk_id = instance._match_id(url)
    info = instance._real_extract(url)
    # nrk_id and info.id are both the same
    assert nrk_id == info['id']
