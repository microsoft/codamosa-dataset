

# Generated at 2022-06-24 12:58:03.634630
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    nrk_radio_podkast_ie._VALID_URL = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrk_radio_podkast_ie._real_extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')


# Generated at 2022-06-24 12:58:07.096688
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    d = NRKTVDirekteIE()
    if d.IE_NAME != 'nrk:direkte':
        raise Exception("IE_NAME")
    if d.IE_DESC != 'NRK TV Direkte and NRK Radio Direkte':
        raise Exception("IE_DESC")
    if d._VALID_URL != r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)':
        raise Exception("_VALID_URL")



# Generated at 2022-06-24 12:58:15.323118
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from .nrktv import NRKTVSeasonIE
    from .common import InfoExtractor, expected_warnings
    nrktv_seasonIE = NRKTVSeasonIE()
    nrktv_seasonIE.initialize()
    assert nrktv_seasonIE.suitable(
        'https://tv.nrk.no/serie/backstage/sesong/1') == True
    assert isinstance(nrktv_seasonIE, InfoExtractor) == True
    assert len(expected_warnings) == 0


# Generated at 2022-06-24 12:58:21.682773
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    a = NRKTVSeriesIE("NRKTVSeriesIE", 1, -1, -1)
    assert a._VALID_URL == "https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)"
    assert a.ie_key() == "NRKTVSeriesIE"



# Generated at 2022-06-24 12:58:32.216444
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test = {
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            #'id': '69031',
            'title': 'Nytt pa nytt, sesong: 201210',
            'description': 'Nytt pa nytt med Harald Eia og Bjoern',
        },
        'playlist_count': 4,
    }
    ie = NRKTVEpisodesIE(test)
    assert ie.suitable(test['url'])
    # ie._extract_description()
    # ie.extract_data()

# Generated at 2022-06-24 12:58:33.197779
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('NRK')


# Generated at 2022-06-24 12:58:35.303904
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    # Check that the constructor is working
    assert ie.IE_NAME is not None and ie.IE_NAME


# Generated at 2022-06-24 12:58:38.059664
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    obj = NRKPlaylistIE('test_id', 'test_title', 'test_description')
    assert obj.playlist_id == 'test_id'
    assert obj.playlist_title == 'test_title'
    assert obj.playlist_description == 'test_description'



# Generated at 2022-06-24 12:58:39.836396
# Unit test for constructor of class NRKIE
def test_NRKIE():
    try:
        NRKIE('NRK', '1', '2')
    except:
        raise AssertionError('Failed initializing class NRKIE')



# Generated at 2022-06-24 12:58:44.196799
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test = NRKPlaylistBaseIE()
    assert(test._extract_description("<div class=\"playlist-description\">Et syngende saueflokk kan selvsagt neppe måle seg med hundrevis av korister som sammen med en superb orkester fremfører Mozarts Requiem.</div>") == 'Et syngende saueflokk kan selvsagt neppe måle seg med hundrevis av korister som sammen med en superb orkester fremfører Mozarts Requiem.')

# Generated at 2022-06-24 12:58:49.066919
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE()
    # In the test, NRKPlaylistBaseIE is instantiated without having a url to
    # provide to its parent class InfoExtractor, which leads to an exception
    # NotImplementedError to be raised when InfoExtractor's constructor tries
    # to call cls._match_id().
    except NotImplementedError:
        pass


# Generated at 2022-06-24 12:58:50.622635
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE(
        NRKBaseIE(
            ie_key='NRKTVEpisodeIE',
            info_dict={},
            ie=NRKIE()
        )
    )

# Generated at 2022-06-24 12:58:52.246981
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    a = NRKBaseIE('test')
    assert a.IE_NAME == 'test'
    assert a._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-24 12:58:53.931138
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    _NRKRadioPodkastIE = NRKRadioPodkastIE()


# Generated at 2022-06-24 12:58:54.920854
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    try:
        NRKTVEpisodeIE()
    except TypeError:
        pass



# Generated at 2022-06-24 12:58:58.686100
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert isinstance(NRKPlaylistIE('NRKPlaylistIE'), NRKPlaylistIE)
    assert isinstance(NRKPlaylistIE('NRKPlaylistBaseIE'), NRKPlaylistBaseIE)


# Generated at 2022-06-24 12:59:09.324243
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url='https://radio.nrk.no/podkast/p1_arkivet/sesong/1/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    video_id='l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    page_iframe='<iframe src="https://www.nrk.no/urort/embed/p1arkivet/a/54ad45dff8eda44b9a9d2064/" width="100%" height="600" frameborder="0" allowfullscreen></iframe>'
    webpage=page_iframe
    nrk_playlist_base_ie=NRKPlaylistBaseIE()
    nrk_playlist

# Generated at 2022-06-24 12:59:10.394830
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE()

# Generated at 2022-06-24 12:59:23.084521
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    from .nrkie import NRKIE
    from .nrktvedioie import NRKTVEpisodeIE
    i = NRKTVSerieBaseIE(NRKIE(), 'catalog', 'series', 'a/series')
    assert i.catalog_name() == 'series'
    assert i.catalog == 'series'
    assert i.serie_kind == 'series'
    assert i.serie_path == 'a/series'
    assert i._VALID_URL == NRKTVIE._VALID_URL + '$'
    assert i.IE_NAME == 'nrk:series'
    assert i.ie_key() == 'NRKTVSerieBase'
    assert i.ie._downloader.params['noplaylist'] is False

# Generated at 2022-06-24 12:59:25.649556
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    extractor = NRKBaseIE('http://www.nrk.no')
    assert extractor.IE_NAME == 'nrk'


# Generated at 2022-06-24 12:59:36.765507
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/program/PSBPO01001116/torsdag-kveld-fra-nydalen'

# Generated at 2022-06-24 12:59:38.556553
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # NRKTVSeasonIE.__init__() works fine
    x = NRKTVSeasonIE()


# Generated at 2022-06-24 12:59:44.484709
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # This tests that the class NRKRadioPodkastIE are instantiated correctly
    # in the constructor of InfoExtractor.
    ie = InfoExtractor('nrkradio:l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    if not isinstance(ie, NRKRadioPodkastIE):
        raise AssertionError('ie should be an instance of NRKRadioPodkastIE')



# Generated at 2022-06-24 12:59:48.907447
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == 'nrk'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'



# Generated at 2022-06-24 12:59:53.735545
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvsie = NRKTVSeasonIE()
    data = nrktvsie._call_api('https://tv.nrk.no/catalog/series/backstage/seasons/1', 'backstage/1', 'season', query={'pageSize': 50})
    assert len(nrktvsie._entries(data, 'backstage/1')) == 30


# Generated at 2022-06-24 12:59:54.313214
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE



# Generated at 2022-06-24 12:59:55.497564
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE(None)
    assert ie.IE_NAME == 'nrk:direkte'


# Generated at 2022-06-24 13:00:01.013095
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'NRKTV:episodes'
    assert ie.IE_DESC == 'NRK TV episodes'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 13:00:11.761302
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    url_radio = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert NRKRadioPodkastIE().suitable(url) == True
    assert NRKRadioPodkastIE().suitable(url_radio) == True

# Generated at 2022-06-24 13:00:17.591869
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    expected_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    expected_title = 'Gjenopplev den historiske solformørkelsen'
    expected_description = 'md5:c2df8ea3bac5654a26fc2834a542feed'
    
    playlist = NRKPlaylistIE(test_url)

    assert playlist.id == expected_id
    assert playlist.url == test_url
    assert playlist.title == expected_title
    assert playlist.description == expected_description


# Generated at 2022-06-24 13:00:27.650017
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Construct an instance of class NRKBaseIE
    ie_raw = NRKBaseIE(InfoExtractor())

    # Check the instance is properly constructed
    assert ie_raw._GEO_COUNTRIES == ['NO']
    assert ie_raw._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-24 13:00:38.737642
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert re.match(NRKTVIE._VALID_URL, 'https://tv.nrk.no/serie/mord-uten-grenser/sesong/2/episode/2')
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/mord-uten-grenser/sesong/2/episode/2')
    assert not re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/mord-uten-grenser/sesong/2/episode')
    assert not re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/mord-uten-grenser/sesong/2')

# Generated at 2022-06-24 13:00:51.103753
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    video_id = "l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"

    match = re.search(NRKRadioPodkastIE._VALID_URL, url)
    assert match, 'Should match URL: {}'.format(url)
    assert match.group('id') == video_id


# Generated at 2022-06-24 13:00:52.744056
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteie = NRKTVDirekteIE()

# Generated at 2022-06-24 13:00:57.617795
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']\d+'

# Generated at 2022-06-24 13:01:01.313290
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('direkte/nrk1', 'nrk.no')
    ie.search_key('nrk1')
    ie.format()

# Generated at 2022-06-24 13:01:02.513862
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE()



# Generated at 2022-06-24 13:01:03.691928
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE() is not None



# Generated at 2022-06-24 13:01:06.880686
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie_obj = NRKPlaylistIE()
    ie_obj2 = NRKPlaylistIE()
    assert ie_obj == ie_obj2



# Generated at 2022-06-24 13:01:18.899091
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == "nrk"
    assert ie.IE_DESC == "NRK TV and NRK Radio"
    assert ie.VALID_URL == r"""(?:nrk:(?P<id>[a-z]+:?[a-zA-Z0-9_-]+)|https?://(?:tv\.)?nrk\.no/serie/(?P<path_id>#?[^/]+)/(?P<display_id>[^/]+))"""
    assert ie._GEO_COUNTRIES == ['NO']
    assert re.search(ie._CDN_REPL_REGEX, 'http://nrk-od-no.telenorcdn.net/no/data/123')

# Generated at 2022-06-24 13:01:20.256087
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert True == False, "Test not implemented."


# Generated at 2022-06-24 13:01:29.469289
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_video_id = '14099'
    nrk_skole_url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=%s' % nrk_skole_video_id
    nrk_skole_data = {
        'id': '6021',
        'ext': 'mp4',
        'title': 'Genetikk og eneggede tvillinger',
        'description': 'md5:3aca25dcf38ec30f0363428d2b265f8d',
        'duration': 399,
    }

    # response of the site
    mock_response = '{"psId":"6021"}'

    ie = NRKSkoleIE()

# Generated at 2022-06-24 13:01:41.623310
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    test_cases = [
        [
            'https://radio.nrk.no/podkast/hele_historien/nrkno-poddkast-26588-134079-05042018030000',
            'NRKTVSeriesIE',
            'hele_historien'
        ],
        [
            'https://radio.nrk.no/podkast/hele_historien/nrkno-poddkast-26588-134079-05042018030000',
            'NRKRadioPodkastIE',
            '26588-134079-05042018030000'
        ]
    ]
    for test_case in test_cases:
        test_case[1] = globals()[test_case[1]]

# Generated at 2022-06-24 13:01:51.631582
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    def _test_url(url, info_dict, playlist_mincount):
        ie = NRKTVSeasonIE(NRKTVSeasonIE.suitable)
        ie.download = lambda *a, **kw: kw['return_data']
        result = ie.extract(url)
        actual_count = sum(1 for _ in result['entries'])
        assert result['id'] == info_dict['id']
        assert result['title'] == info_dict['title']
        assert playlist_mincount <= actual_count
    for test_case in NRKTVSeasonIE._TESTS:
        yield _test_url, test_case['url'], test_case['info_dict'], test_case['playlist_mincount']


# Generated at 2022-06-24 13:01:53.048259
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    _ = NRKPlaylistBaseIE('url', 'playlist_id')


# Generated at 2022-06-24 13:01:57.051611
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-24 13:02:03.894663
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/play/')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/')
    assert not NRKPlaylistIE.suitable('')



# Generated at 2022-06-24 13:02:07.691108
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert isinstance(nrk_skole_ie, InfoExtractor)


# Generated at 2022-06-24 13:02:09.695814
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE('NRKTVEpisodesIE', 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')


# Generated at 2022-06-24 13:02:10.516253
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE('NRKPlaylistIE')

# Generated at 2022-06-24 13:02:12.693351
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.ie_key() == 'NRKTV'
    assert ie.ie_key() == NRKTVIE.ie_key()

# Generated at 2022-06-24 13:02:16.203790
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)')


# Generated at 2022-06-24 13:02:21.743470
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE(NRKSkoleIE.ie_key()).IE_NAME == 'nrk:skole'
    assert NRKSkoleIE(NRKSkoleIE.ie_key())._VALID_URL == NRKSkoleIE._VALID_URL


# Generated at 2022-06-24 13:02:36.010041
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    #assert ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\\d+)/episode/(?P<episode_number>\\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'

# Generated at 2022-06-24 13:02:38.444584
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie is not None


# Generated at 2022-06-24 13:02:48.563082
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    try:
        from urllib.parse import urlparse
    except ImportError:
        from urlparse import urlparse
    valid_urls = [
        'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763',
        'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'
    ]

    nrk_playlist_ie = NRKPlaylistIE()
    assert nrk_playlist_ie._ITEM_RE

    for test_url in valid_urls:
        valid_id = urlparse(test_url).path.split('/')[-1]

# Generated at 2022-06-24 13:02:54.883895
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie_main = NRKTVDirekteIE()
    assert ie_main.NRKTVIE._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/(?:(?:tv|radio)/)?(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 13:02:59.338542
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .nrktv import NRKTVDirekteIE
    url  = 'https://tv.nrk.no/direkte/nrk1'
    assert NRKTVDirekteIE.suitable(url)
    with pytest.raises(Exception):
        NRKTVDirekteIE.suitable(None)

# Generated at 2022-06-24 13:03:07.474066
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    args = [NRKPlaylistIE]
    kargs = {'_VALID_URL': r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)', '_ITEM_RE': r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'}
    NRKPlaylistIE(args, kargs)



# Generated at 2022-06-24 13:03:11.845311
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # I am just testing constructor:
    ie = NRKBaseIE('nrk.no')
    assert ie.IE_NAME == 'nrk.no'
    assert ie._GEO_COUNTRIES == ['NO']
# Test end


# Generated at 2022-06-24 13:03:12.608787
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()

# Generated at 2022-06-24 13:03:25.230112
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    combis = [
        ('serie', 'groenn-glede', NRKTVSeriesIE._VALID_URL),
        ('podkast', 'ulrikkes_univers', NRKTVSeriesIE._VALID_URL),
        ('serie', 'backstage', NRKTVSeriesIE._VALID_URL),
        ('podkast', 'dickie-dick-dickens', NRKTVSeriesIE._VALID_URL),
        ('serie', 'labyrint', NRKTVSeriesIE._VALID_URL),
    ]

    for serie_kind, series_id, regex in combis:
        url = 'https://tv.nrk.no/{}/{}'.format(serie_kind, series_id)
        match = re.match(regex, url)

# Generated at 2022-06-24 13:03:27.669387
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    result = NRKTVSeriesIE()._real_extract('https://tv.nrk.no/serie/groenn-glede')
    print(result)

# Generated at 2022-06-24 13:03:30.943006
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie_direkte = NRKTVDirekteIE()
    assert ie_direkte.IE_NAME == 'nrk:direkte'


# Generated at 2022-06-24 13:03:35.068066
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    obj = NRKTVSerieBaseIE()
    assert obj._ASSETS_KEYS == ('episodes', 'instalments', )
    assert obj._catalog_name('podcast') == 'podcast'
    assert obj._catalog_name('podkast') == 'podcast'
    assert obj._catalog_name('series') == 'series'
    assert obj._catalog_name('radio') == 'series'
    assert obj._catalog_name('abc') == 'series'



# Generated at 2022-06-24 13:03:46.162070
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    instance = NRKTVSeasonIE('name', 'id', {}, 'md5')
    assert instance.name == 'name'
    assert instance.ie_key() == 'id'
    assert instance.ie_key() == 'id'
    assert instance._downloader is None
    assert instance._downloader_contexts == {}
    assert instance._downloader_parameters == {}
    assert instance._downloader_context == {}
    assert instance.params == {'noplaylist': True}
    assert instance.add_default_values() == {}
    assert instance._type == 'url'
    assert instance.result_type == 'url'
    assert instance.expected_warnings == []
    assert instance.add_headers({}) == {}
    assert instance.DEFAULT_HEADERS == {'User-Agent': 'test'}
    assert instance

# Generated at 2022-06-24 13:03:54.668661
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert 'NRKTVEpisodesIE' in globals()
    assert 'NRKPlaylistBaseIE' in globals()
    assert NRKTVEpisodesIE == NRKTVEpisodesIE
    assert NRKTVEpisodesIE(_VALID_URL=r'(?:foo|bar)') != NRKPlaylistBaseIE(_VALID_URL=r'(?:foo|bar)')
    assert (NRKTVEpisodesIE
            == NRKTVEpisodesIE(NRKTVIE._VALID_URL)
            == NRKTVEpisodesIE(_VALID_URL=NRKTVEpisodesIE._VALID_URL))

# Generated at 2022-06-24 13:03:55.638049
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie != None


# Generated at 2022-06-24 13:04:01.649746
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Typical use case
    # https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant
    url = 'https://radio.nrk.no/serie/dagsnytt/sesong/201509'

    # Short use case
    # https://tv.nrk.no/serie/lindmo/2016
    url = 'https://tv.nrk.no/serie/lindmo/2016'

    # Long use case
    # https://radio.nrk.no/serie/dagsnytt/sesong/201509
    url = 'https://radio.nrk.no/serie/dagsnytt/sesong/201509'

    # This one is not reacheable in 2020/09
    # https://radio.nrk.no

# Generated at 2022-06-24 13:04:03.138832
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('http://programmer.nrk.no/2014/09/29/radio_p1_p1_pluss_pluss.html')

# Generated at 2022-06-24 13:04:07.642967
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # pylint: disable=W0612
    test_class = NRKTVSerieBaseIE(
        downloader=downloader.Downloader(),
        compat_str=compat_str,
        compat_urllib_request=compat_urllib_request,
        compat_urllib_parse=compat_urllib_parse)
    assert test_class._catalog_name('series') == 'series'
    assert test_class._catalog_name('podcast') == 'podcast'
    assert test_class._catalog_name('podkast') == 'podcast'
    assert test_class._catalog_name('program') == 'series'
    # pylint: enable=W0612


# Generated at 2022-06-24 13:04:11.652904
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from .nrktv import NRKTVIE
    test_videourl = 'https://tv.nrk.no/serie/dagsnytt/MUHH48000317/17-09-2018#tab=test'
    assert 'test' == NRKTVIE._match_id(test_videourl)

# Generated at 2022-06-24 13:04:13.289942
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE()._VALID_URL == NRKTVIE._VALID_URL



# Generated at 2022-06-24 13:04:14.177375
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()


# Generated at 2022-06-24 13:04:15.131058
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = "test"
    NRKRadioPodkastIE.suitable(url)


# Generated at 2022-06-24 13:04:17.416450
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE("https://tv.nrk.no/serie/lindmo")


# Generated at 2022-06-24 13:04:30.400009
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('NRKTVSeasonIE', 'url', 'display_id')
    ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    ie.suitable('https://tv.nrk.no/serie/backstage/1')
    ie.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')
    ie.suitable('https://tv.nrk.no/serie/spangas/sesong/1')
    ie.suitable('https://radio.nrk.no/podkast/loerdagsraadet/sesong/202101')
    ie.suitable('https://tv.nrk.no/serie/spangas')
   

# Generated at 2022-06-24 13:04:30.857363
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    pass



# Generated at 2022-06-24 13:04:40.870610
# Unit test for constructor of class NRKTVIE

# Generated at 2022-06-24 13:04:48.609933
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # NRKTVIE is an alias for NRKIE
    assert NRKTVIE.__module__ == 'youtube_dl.extractor.nrk'
    assert NRKTVIE.__name__ == 'NRKTVIE'
    assert hasattr(NRKTVIE, '_VALID_URL')
    # NRKTVIE should be an instance of InfoExtractor
    NRKTVIE_instance = NRKTVIE()
    assert isinstance(NRKTVIE_instance, InfoExtractor)

# Generated at 2022-06-24 13:04:52.223497
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test what happens when subclassing constructor is called with 'url' parameter
    try:
        # Constructor of NRKTVSeriesIE should raise an exception if called with 'url' parameter
        NRKTVSeriesIE('url')
    except TypeError:
        # TypeError is expected when url parameter is passed to constructor of NRKTVSeriesIE
        pass
    else:
        # Unexpected: no exception was raised when url parameter was passed to constructor of NRKTVSeriesIE
        assert False, 'NRKTVSeriesIE constructor unexpectedly did not raise TypeError when called with \'url\' parameter'


# Generated at 2022-06-24 13:04:52.837166
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE(None)



# Generated at 2022-06-24 13:04:56.252207
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """
    Constructor of class NRKTVSeasonIE should return an initialized object
    """
    # Check constructor call with the required parameters
    NRKTVSeasonIE('', {}, lambda x: x)

# Generated at 2022-06-24 13:04:59.235635
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """
    Unit test for constructor of class NRKIE

    This test will only check if the constructor of the class
    is not breaking anything.
    """
    ie = NRKIE()



# Generated at 2022-06-24 13:05:03.171199
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/urort/artister/kjetil-moester-1.12262737'
    NRKPlaylistIE(NRKPlaylistIE, url, {'expected_title': 'Kjetil Møster'})



# Generated at 2022-06-24 13:05:05.814811
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    print('Testing NRKTVEpisodesIE constructor')
    print('Test passed')

if __name__ == '__main__':
    test_NRKTVDirekteIE()
    test_NRKTVEpisodesIE()

# Generated at 2022-06-24 13:05:14.696266
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        from .test_constants import YOUTUBE_API_KEY
        api_key = YOUTUBE_API_KEY
    except ImportError:
        api_key = None
    ie = NRKTVSeasonIE(URLResolverMock(), params={'youtube_api_key': api_key})
    assert ie.right_domain_url('https://tv.nrk.no/serie/spangas/sesong/1')
    assert ie.right_domain_url('https://radio.nrk.no/serie/dagsnytt/sesong/201507')
    assert ie.right_domain_url('https://tv.nrk.no/serie/lindmo/2016')

# Generated at 2022-06-24 13:05:16.509844
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE in globals().values()


# Generated at 2022-06-24 13:05:18.235923
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    info_extractor = NRKPlaylistBaseIE
    assert info_extractor

# Generated at 2022-06-24 13:05:25.202245
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'http://www.nrk.no/playlister/barnas-favoritter-1.11167680'
    ie = NRKPlaylistBaseIE()
    assert ie.suitable(url)
    assert ie._match_id(url) == 'barnas-favoritter-1.11167680'
    assert ie._extract_description(None) is None


# Generated at 2022-06-24 13:05:33.654376
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    # Just to test if the regex is correct
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    # And that it is not suitable for other urls
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not ie.suitable('https://radio.nrk.no/serie/norske-eventyr/sesong/1')
    assert not ie.suitable('https://tv.nrk.no/serie/blank')

# Generated at 2022-06-24 13:05:37.507456
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE()
        assert False, 'NRKPlaylistBaseIE constructor does not throw exception'
    except TypeError:
        pass


# Generated at 2022-06-24 13:05:39.872682
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrkRadioPodkastIE = NRKRadioPodkastIE(None, None)
    if nrkRadioPodkastIE == None:
        print("NRKRadioPodkastIE object not created")
    else:
        print("NRKRadioPodkastIE object created")


# Generated at 2022-06-24 13:05:41.551122
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Constructor of class NRKIE
    NRKIE()


# Generated at 2022-06-24 13:05:47.899057
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk_base_ie = NRKBaseIE()
    input_url = 'https://tv.nrk.no/program/MDDP02000716/helge-midthjell-mener-1'
    expected_id = 'MDDP02000716'
    actual_id = nrk_base_ie._match_id(input_url)
    assert expected_id == actual_id
    nrk_base_ie.extract(input_url)



# Generated at 2022-06-24 13:06:01.564689
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from datetime import datetime
    from .test_imports import make_mock_extractor
    import pytest

    @make_mock_extractor('NRKBaseIE')
    class MockNRKBaseIE(NRKBaseIE):
        pass

    make_mock_extractor('NRKBaseIE')
    assert MockNRKBaseIE('NRKBaseIE').IE_NAME == 'NRK'
    assert MockNRKBaseIE('NRKBaseIE')._VALID_URL == MockNRKBaseIE.VALID_URL
    assert MockNRKBaseIE('NRKBaseIE').IE_DESC == MockNRKBaseIE.IE_DESC
    assert MockNRKBaseIE('NRKBaseIE')._GEO_COUNTRIES == MockNRKBaseIE.GEO_COUNTRIES
    assert MockNRK

# Generated at 2022-06-24 13:06:14.565206
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # URL of the series consists of ONLY 'http' (without 's')
    url = 'http://tv.nrk.no/serie/groenn-glede'
    parsed_url = compat_urllib_parse_urlparse(url)

    # Extracted value 'tv_nrk_no' for 'hostname'
    assert 'tv_nrk_no' in NRKTVSeriesIE._VALID_URL
    # Extracted value 'tv' for 'domain'
    assert 'tv' in NRKTVSeriesIE._VALID_URL
    # Extracted value 'serie' for 'serie_kind'
    assert 'serie' in NRKTVSeriesIE._VALID_URL
    # Extracted value 'groenn-glede' for 'id'
    assert 'groenn-glede' in NRKTV

# Generated at 2022-06-24 13:06:17.810360
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Arrange
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'

    # Act
    nrkTVEpisodesIE = NRKTVEpisodesIE()

    # Assert
    assert nrkTVEpisodesIE._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'

# Generated at 2022-06-24 13:06:29.368731
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    a = NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede')
    b = NRKTVSeriesIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers')
    c = NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    d = NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/lindmo')
    e = NRKTVSeriesIE.suitable('https://tv.nrksuper.no/serie/labyrint')
    f = NRKTVSeriesIE.suitable('https://nrksuper.no/serie/labyrint')

# Generated at 2022-06-24 13:06:31.018197
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._TESTS[0]['info_dict']['title'] == 'Gjenopplev den historiske solformørkelsen'

# Generated at 2022-06-24 13:06:43.067253
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    direkteUrl = 'https://tv.nrk.no/direkte/nrk1'
    direkteID = 'nrk1'
    direkteInstance = NRKTVDirekteIE(direkteUrl, direkteID)
    # test method _extract_media_url
    media_url = direkteInstance._extract_media_url(direkteUrl, direkteID)
    # test method _extract_media_url
    media_json = direkteInstance._extract_media_json(media_url)
    # test method _extract_media_url
    media_url_2 = direkteInstance._extract_media_url_from_json(media_json)
    assert media_url == media_url_2


# Generated at 2022-06-24 13:06:52.006826
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.__class__.__name__ == "NRKTVDirekteIE"
    ie2 = NRKTVDirekteIE()
    assert ie == ie2
    reprStr = repr(ie)
    assert reprStr == "<NRKTVDirekteIE(url=('https://(?:tv|radio)\\.nrk\\.no/direkte/(?P<id>[^/?#&]+))',)>"
    ie3 = NRKTVDirekteIE.from_url("https://tv.nrk.no/direkte/nrk1")
    assert ie3.__class__.__name__ == "NRKTVDirekteIE"

# Generated at 2022-06-24 13:06:53.646734
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    obj = NRKPlaylistIE()
    assert obj.IE_NAME == 'nrk:playlist'

# Generated at 2022-06-24 13:06:58.214523
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    for test in NRKTVSeriesIE._TESTS:
        try:
            NRKTVSeriesIE(test['url'])
        except Exception as e:
            dump_version()
            print('Exception on ' + test['url'])
            print(e)
            print('=================')
            continue

test_NRKTVSeriesIE()


# Generated at 2022-06-24 13:06:59.466971
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie is not None


# Generated at 2022-06-24 13:07:07.218265
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE("https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031")
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE


# Generated at 2022-06-24 13:07:13.230133
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    class_name = 'NRKRadioPodkastIE'
    constructor = globals()[class_name]
    NRKRadioPodkastIE.suitable("https://radio.nrk.no/podkast/ulrikkes_univers") in [True, None]
    NRKRadioPodkastIE.suitable("https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8") in [True, None]

# Generated at 2022-06-24 13:07:16.705207
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    URL = 'https://tv.nrk.no/direkte/nrk1'
    d = NRKTVDirekteIE(URL)
    assert isinstance(d, NRKTVIE)
    d.download(URL)



# Generated at 2022-06-24 13:07:18.302819
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()

# Generated at 2022-06-24 13:07:24.382053
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    result = nrk_radio_podkast_ie.suitable(url)
    assert(result is True)



# Generated at 2022-06-24 13:07:36.172208
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._NETRC_MACHINE == 'nrk'
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-24 13:07:36.991143
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE()

# Generated at 2022-06-24 13:07:38.091322
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    IE = NRKTVDirekteIE()


# Generated at 2022-06-24 13:07:41.519804
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    ie.age_limit = 0
    ie.http_headers = {'User-Agent': 'QuickTime/7.6.6'}
    # Test NRKTVSerieBaseIE.constructor with args
    assert isinstance(ie, NRKTVSerieBaseIE)
    # Test NRKTVSerieBaseIE.constructor with kwargs
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 13:07:45.372736
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .test_utils import vcr, FakeHeadRequest
    from .test_nrk import _test_nrk_legacy_api
    with vcr.use_cassette(os.path.join('nrk', 'NRKTVDirekteIE_test.yaml')):
        _test_nrk_legacy_api(NRKTVDirekteIE, 'p1_oslo_akershus', vcr)



# Generated at 2022-06-24 13:07:51.379787
# Unit test for constructor of class NRKPlaylistBaseIE

# Generated at 2022-06-24 13:07:56.229983
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE("http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763")
    assert ie._TESTS[0]["url"] == ie._VALID_URL
