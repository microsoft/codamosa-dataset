

# Generated at 2022-06-24 12:58:02.069425
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_class = NRKBaseIE()
    assert hasattr(test_class, '_GEO_COUNTRIES')
    assert hasattr(test_class, '_CDN_REPL_REGEX')
    assert hasattr(test_class, '_extract_nrk_formats')
    assert hasattr(test_class, '_raise_error')
    assert hasattr(test_class, '_call_api')



# Generated at 2022-06-24 12:58:03.935478
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    obj = NRKTVSeriesIE(1, 2, 3)
    assert isinstance(obj, NRKTVSeriesIE)
    assert obj.nrk_id == 1
    assert obj.url == 2
    assert obj.video_id == 3

# Generated at 2022-06-24 12:58:12.424946
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    test_object = NRKTVSerieBaseIE()
    # Check that the constructor of class NRKTVSerieBaseIE works correctly
    assert test_object._ASSETS_KEYS == ('episodes', 'instalments',)

    assert test_object._catalog_name('series') == 'series'
    assert test_object._catalog_name('podcast') == 'podcast'
    assert test_object._catalog_name('podkast') == 'podcast'
    assert test_object._catalog_name('something') == 'series' #default case
    assert test_object._catalog_name(None) == 'series' #default case

    # Check that the constructor of class NRKTVSerieBaseIE works correctly
    embedded = {'foobar': 1}

# Generated at 2022-06-24 12:58:16.161477
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        NRKBaseIE('NRK', 'http://tv.nrk.no/serie/hurra-for-deg')
        NRKBaseIE('NRK', 'http://nrk.no/')
        NRKBaseIE('NRK', 'http://www.nrk.no/')
    except:
        return False
    return True


# Generated at 2022-06-24 12:58:21.046626
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # test with a non-existing series name
    # this should raise an exception (TypeError)
    with pytest.raises(TypeError):
        url = "https://tv.nrk.no/serie/non_existing_series"
        NRKTVSeriesIE(NRKTVSeriesIE.suitable(url))


# Generated at 2022-06-24 12:58:21.744714
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE('nrk:MDDP12000117')


# Generated at 2022-06-24 12:58:23.477342
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    instance = NRKTVSeasonIE()
    assert isinstance(instance, NRKTVSeasonIE)
    instance.suitable('https://tv.nrk.no/serie/spangas/sesong/1')



# Generated at 2022-06-24 12:58:26.743097
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE(
    )._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'



# Generated at 2022-06-24 12:58:36.972689
# Unit test for constructor of class NRKIE
def test_NRKIE():
    myTest = NRKIE()
    assert myTest._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''

# Generated at 2022-06-24 12:58:46.418594
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    ie = NRKSkoleIE()
    assert(ie.suitable(url))
    assert(ie.ie_key() == 'NRKSkole')
    assert(ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)')
    assert(ie.IE_DESC == 'NRK Skole')

# Generated at 2022-06-24 12:58:49.479006
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    instance = NRKTVSerieBaseIE()
    assert instance._ASSETS_KEYS == ('episodes', 'instalments')


# Generated at 2022-06-24 12:58:51.623462
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    instance = NRKSkoleIE()
    ie_desc = instance.IE_DESC
    ie_key = instance.ie_key()
    assert_equal(ie_desc, 'NRK Skole')
    assert_equal(ie_key, 'NRKSkole')

# Generated at 2022-06-24 12:58:53.665154
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrktvseries = NRKTVSeriesIE()
    assert nrktvseries



# Generated at 2022-06-24 12:59:05.936950
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    class Test(NRKPlaylistIE):
        pass

    # Default validation regex
    x = Test()
    assert hasattr(x, '_VALID_URL')
    assert x._VALID_URL == 'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'

    # Test non-default validation regex
    Test._VALID_URL = 'https?://(?:www\.)?mrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    x = Test()
    assert x._VALID_URL == 'https?://(?:www\.)?mrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'



# Generated at 2022-06-24 12:59:17.982860
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie_nrk_tv = NRKTVIE()

    assert ie_nrk_tv.IE_NAME == 'nrk'
    assert ie_nrk_tv.IE_DESC == 'NRK TV and NRK Radio'
    assert ie_nrk_tv._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

    assert 'MDDP12000117' == ie_nrk_tv._match_id(r'https://tv.nrk.no/program/MDDP12000117')

# Generated at 2022-06-24 12:59:19.762301
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE({}) is None


# Generated at 2022-06-24 12:59:20.786122
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE(bool, "TEST")

# Generated at 2022-06-24 12:59:25.889933
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    a = NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    b = NRKSkoleIE('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')



# Generated at 2022-06-24 12:59:29.021122
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test_obj = NRKTVEpisodesIE()
    assert type(test_obj) == NRKTVEpisodesIE



# Generated at 2022-06-24 12:59:38.738021
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist_test = NRKPlaylistIE('test', 'test')
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/')
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/_test_/')
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/test/test/')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/video/')
    assert not NRKPlaylistIE.suitable('http://www.nrk.no/skole/')
    assert playlist_test._match_id('http://www.nrk.no/troms/test/test/') == 'test/test'


# Generated at 2022-06-24 12:59:42.565707
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """
    Constructor test
    """
    url = 'https://radio.nrk.no/direkte/program/psykologi'
    playlist_base_ie = NRKPlaylistBaseIE()
    playlist_base_ie._real_extract(url)



# Generated at 2022-06-24 12:59:47.942652
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE(None)
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.n' \
                                 r'o/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl' \
                                 r'-rr\.netwerk\.no/no/'


# Generated at 2022-06-24 12:59:58.870732
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """
    Make sure NRKTVSeriesIE doesn't crash if the api json object is missing
    seriesType.
    """
    # Add the number of parameters to NRKTVSeriesIE.__init__ required for
    # this test. The number of arguments are indicated in the code by
    # underscores.
    # NB: The unit test also catches cases where new parameters are added to
    # NRKTVSeriesIE.__init__
    x = NRKTVSeriesIE(_____)
    assert isinstance(x, NRKTVSeriesIE)
    # Add number of parameters above to NRKTVSeriesIE.__init__
    x = NRKTVSeriesIE(_____, {}, {})
    assert isinstance(x, NRKTVSeriesIE)


# Generated at 2022-06-24 13:00:02.712189
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE(None)._GEO_COUNTRIES == ['NO']


# Generated at 2022-06-24 13:00:12.850499
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    class MockNRKPlaylistBaseIE(NRKPlaylistBaseIE):
        _VALID_URL = 'http://example.com/playlist/mock_playlist'

        def _extract_description(self, webpage):
            return 'mock_description'

    assert MockNRKPlaylistBaseIE.suitable(MockNRKPlaylistBaseIE._VALID_URL)
    assert MockNRKPlaylistBaseIE.IE_NAME == 'nrk:playlist'
    assert MockNRKPlaylistBaseIE.IE_DESC == 'NRK Playlists'
    assert MockNRKPlaylistBaseIE.ie_key() == 'NRKPlaylist'

    mock_info_extractor = MockNRKPlaylistBaseIE('test')
    assert mock_info_extractor._VALID_URL == MockNRKPlaylistBaseIE._

# Generated at 2022-06-24 13:00:16.744733
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # arguments are initialized as empty list
    assert (NRKTVEpisodesIE.__init__.__defaults__ == (list(),))
    # tested method
    func = NRKTVEpisodesIE._extract_title
    # check that it is a method of class NRKTVEpisodesIE
    assert (inspect.ismethod(func))
    # check that this method is the _extract_title method
    assert (func.__name__ == '_extract_title')

# Generated at 2022-06-24 13:00:22.347422
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.IE_NAME == NRKRadioPodkastIE.IE_NAME
    assert ie.IE_DESC == NRKRadioPodkastIE.IE_DESC
    assert ie._VALID_URL == NRKRadioPodkastIE._VALID_URL
    assert ie._downloader is None
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8') is True


# Generated at 2022-06-24 13:00:24.765419
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % ie._EPISODE_RE

# Generated at 2022-06-24 13:00:26.649127
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    try:
        NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1') is not None
    except Exception:
        assert False, 'NRKTVDirekteIE initialization failed'



# Generated at 2022-06-24 13:00:28.889128
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert try_getattr(NRKPlaylistBaseIE(), '_ITEM_RE') is not None

# Generated at 2022-06-24 13:00:39.751136
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # NRKTVSeriesIE is not exported from __init__.py
    from .nrktv import NRKTVSeriesIE
    assert isinstance(NRKTVSeriesIE.ie_key(), type(NRKTVIE))
    assert NRKTVSeriesIE.ie_key() == NRKTVIE
    assert NRKTVSeriesIE.suitable(None) is False
    assert NRKTVSeriesIE.suitable('') is False
    assert NRKTVSeriesIE.suitable('None') is False
    assert NRKTVSeriesIE.suitable('http://www.nrksuper.no/') is False
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/spellemann/sesong/1/episode/1') is False

# Generated at 2022-06-24 13:00:41.501467
# Unit test for constructor of class NRKIE
def test_NRKIE():
    IE = NRKIE()
    assert IE.IE_NAME == 'NRK.no'



# Generated at 2022-06-24 13:00:44.576428
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    'Unit tests for the NRKPlaylistBaseIE'
    # test constructor
    NRKPlaylistBaseIE('NRKPlaylistBaseIE')



# Generated at 2022-06-24 13:00:46.306898
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE(None, None)


# Generated at 2022-06-24 13:00:51.520940
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    """
    Test class NRKBaseIE(InfoExtractor) constructor.
    """
    assert NRKBaseIE('NRKBaseIE')
    assert NRKBaseIE('nRKBaseIE')
    assert NRKBaseIE('NrKBaseIE')



# Generated at 2022-06-24 13:00:59.143136
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert ie.domain == 'radio'
    assert ie.serie_kind == 'podkast'
    assert ie.serie == 'dagsnytt'
    assert ie.season_id == '201509'
    assert ie.display_id == 'dagsnytt/201509'
    assert ie.catalog_name == 'podcast'


# Generated at 2022-06-24 13:01:03.799111
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrk_tv_series_ie = NRKTVSeriesIE()
    nrk_tv_series_ie._call_api = lambda x, y, z, **k: {}
    nrk_tv_series_ie.url_result = lambda x, ie, **k: {}

# Generated at 2022-06-24 13:01:07.317755
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('nrk:6f2bd6a1-9d4b-4f63-a4bd-6a19d4bf63cb')
    

# Generated at 2022-06-24 13:01:19.423390
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'

    nrk = NRKPlaylistIE()

    # check that the constructor fails on no valid URL
    with pytest.raises(ExtractorError):
        nrk._real_extract('some non URL')

    # check that the constructor works on valid URL
    nrk._real_extract(url)

    webpage = nrk._download_webpage(url, playlist_id)


# Generated at 2022-06-24 13:01:28.849244
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrkplaylistie = NRKPlaylistIE()
    assert nrkplaylistie.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') == True
    assert nrkplaylistie.extract('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') != None
    assert nrkplaylistie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8') == False


# Generated at 2022-06-24 13:01:32.726663
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    nrk_ie = NRKSkoleIE(NRKSkoleIE.suitable(url))
    assert isinstance(nrk_ie, NRKSkoleIE)


# Generated at 2022-06-24 13:01:34.236321
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE("testId") == "nrk:testId"

# Generated at 2022-06-24 13:01:42.258646
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    obj = NRKPlaylistBaseIE(NRKPlaylistBaseIE.ie_key(), url='https://tv.nrk.no/listobj/wDfm/urn:nrk:playlist:4384238')
    assert obj.playlist_id == 4384238
    obj._real_extract('https://tv.nrk.no/listobj/wDfm/urn:nrk:playlist:4384238')


# Generated at 2022-06-24 13:01:44.361006
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Create object
    obj = NRKRadioPodkastIE()

# Generated at 2022-06-24 13:01:53.614230
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Check data from _TESTS[0]
    result = NRKTVIE._real_extract("https://tv.nrk.no/program/MDDP12000117")
    assert result["id"] == "MDDP12000117"
    assert result["title"] == "Alarm Trolltunga"
    assert result["description"] == "md5:46923a6e6510eefcce23d5ef2a58f2ce"
    assert result["duration"] == 22

    # Check data from _TESTS[1]
    result = NRKTVIE._real_extract("https://tv.nrk.no/serie/20-spoersmaal-tv/MUHH48000314/23-05-2014")
    assert result["id"] == "MUHH48000314"

# Generated at 2022-06-24 13:01:59.367737
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test_case = {'url': 'https://tv.nrk.no/programoversikt/episodes/[FITTE]', 'expected': 'FITTE'}
    assert NRKPlaylistBaseIE()._match_id(test_case['url']) == test_case['expected']


# Generated at 2022-06-24 13:02:02.525850
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert 0 == len(NRKTVEpisodeIE._TESTS[0]['info_dict'])
    assert 2 == len(NRKTVEpisodeIE._TESTS[1]['info_dict'])

# Generated at 2022-06-24 13:02:05.012902
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    try:
        NRKPlaylistIE('baekken_laerer_barn_om_sex_1.12173447')
    except Exception:
        assert False, 'constructor of class NRKPlaylistIE should not raise exception'



# Generated at 2022-06-24 13:02:07.299724
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie = NRKIE('NRK')
    ie = NRKIE('NRK', {})
    assert ie.IE_NAME == 'NRK'


# Generated at 2022-06-24 13:02:09.315717
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    class_nrk_radio_podkast_ie = NRKRadioPodkastIE(NRKBaseIE._create_get_request, None)
    asser_equals = class_nrk_radio_podkast_ie.suitable(NRKRadioPodkastIE._VALID_URL)
    assert asser_equals == True

# Generated at 2022-06-24 13:02:17.940681
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # When URL is not matched by pattern
    def test_NRKTVEpisodeIE_get_playlist_id_fail():
        url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episod'
        assert NRKTVEpisodeIE.get_playlist_id(url) is None
        # When URL is matched by pattern
        url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
        result = NRKTVEpisodeIE.get_playlist_id(url)
        assert result == ('backstage/sesong/1/episode/8', '1', '8')

    test_NRKTVEpisodeIE_get_playlist_id_fail()

# Generated at 2022-06-24 13:02:23.457732
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    playlist = NRKTVSeriesIE()._real_extract(url)
    assert playlist.id == 'groenn-glede'
    assert len(playlist.entries) == 90



# Generated at 2022-06-24 13:02:25.259099
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    unit_test.test_class_constructor(NRKPlaylistIE)



# Generated at 2022-06-24 13:02:27.739015
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    instance = NRKTVSerieBaseIE()
    assert isinstance(instance, NRKTVSerieBaseIE)


# Generated at 2022-06-24 13:02:30.311133
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert 'NRK Skole' in ie.IE_DESC



# Generated at 2022-06-24 13:02:38.697592
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE(NRKTVSeasonIE.create_ie_instance())._VALID_URL == 'https?://(?P<domain>tv|radio)\.nrk\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<serie>[^/]+)/(?:(?:sesong/)?(?P<id>\d+)|sesong/(?P<id_2>[^/?#&]+))'



# Generated at 2022-06-24 13:02:45.781249
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert not re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/backstage/sesong/1/episode')

# Generated at 2022-06-24 13:02:51.562451
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # call constructor of class NRKTVSeriesIE
    obj = NRKTVSeriesIE()
    assert obj.suitable('https://tv.nrk.no/serie/backstage'), \
        'NRKTVSeriesIE is not suitable for url https://tv.nrk.no/serie/backstage'
    assert not obj.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/2'), \
        'NRKTVSeriesIE is suitable for https://tv.nrk.no/serie/blank/sesong/1/episode/2'


# Generated at 2022-06-24 13:02:58.912694
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/supernytt/sesong/1/episode/9')
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/supernytt/sesong/1/episode/10')

# Generated at 2022-06-24 13:03:10.094180
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', 'https://tv.nrk.no/serie/trolljegerne', 'fylkesleksikon.nrk.no', True, 'NO')

    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/serie/(?P<id>.+)'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie.IE_NAME == 'NRKBaseIE'
    assert ie._downloader == 'fylkesleksikon.nrk.no'
    assert ie._NETRC_MACHINE == 'nrk'

    nrkbaseie_instance = IE()

# Generated at 2022-06-24 13:03:10.872567
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE()



# Generated at 2022-06-24 13:03:23.639160
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    NZL = {'test_cases': [{'url':  'http://v8.psapi.nrk.no/mediaelement/a036df78-12d3-4a63-8b9f-b5180800f889.json',
                           'note': 'Test constructor',
                           'expected': "GEO_COUNTRIES: ['NO']\n"
                                       "GEO_BYPASS: True\n"
                                       "IE_DESC: NRK Base Info Extractor\n"
                                       "IE_NAME: NRKBase"}]}
    obj = NRKBaseIE()

# Generated at 2022-06-24 13:03:29.486677
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    season = NRKTVSeasonIE("https://tv.nrk.no/serie/backstage/sesong/1")
    assert season._VALID_URL is not None
    assert season._TESTS is not None
    assert season._extract_assets_key({'episodes': {}}) == 'episodes'
    assert season._extract_assets_key({'instalments': {}}) == 'instalments'
    assert season._extract_assets_key({}) is None
    assert season._entries({}, "random") is not None
    assert season._real_extract("https://tv.nrk.no/serie/backstage/sesong/1") is not None

# Generated at 2022-06-24 13:03:31.938044
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert isinstance(ie, NRKSkoleIE)
# end of unit test for constructor of class NRKSkoleIE

# Test for function _extract_title

# Generated at 2022-06-24 13:03:42.631610
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk_base_ie = NRKBaseIE()
    assert isinstance(nrk_base_ie, NRKBaseIE)
    assert nrk_base_ie.IE_NAME == 'nrk'
    assert nrk_base_ie._GEO_COUNTRIES == ['NO']
    assert nrk_base_ie._CDN_REPL_REGEX == r'(?x)://\n            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|\n            nrk-od-no\.telenorcdn\.net|\n            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n        /'



# Generated at 2022-06-24 13:03:52.657340
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Check that an exception is raised if there is not at least one
    # video in video_info_data list
    def test_no_video_data():
        ie = NRKTVDirekteIE('nrk1')
        data = {'video': [{'videoReferences': []}]}
        ie._real_extract(data)

    with pytest.raises(ExtractorError):
        test_no_video_data()

    # Check that video is not processed if 'hasRights' is False
    def test_no_rights():
        ie = NRKTVDirekteIE('nrk1')
        data = {'video': [{'hasRights': False}]}
        ie._real_extract(data)

    with pytest.raises(ExtractorError):
        test_no_rights()



# Generated at 2022-06-24 13:04:00.991035
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Test for constructor by super class
    playlist_base_ie = NRKPlaylistBaseIE()
    assert playlist_base_ie.suitable('http://some.url') == False
    assert playlist_base_ie._VALID_URL == None
    assert playlist_base_ie.IE_DESC == None
    assert playlist_base_ie._TESTS == []
    assert playlist_base_ie._ITEM_RE == None
    assert playlist_base_ie._upload_date_re == None
    assert playlist_base_ie.ie_key() == None
    assert playlist_base_ie.report_video_info_url == None
    assert playlist_base_ie.report_video_download_webpage_read_error == None
    assert playlist_base_ie.report_extraction_error == None
    assert playlist_base_ie

# Generated at 2022-06-24 13:04:02.942442
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE('NRKTVSerieBaseIE','NRKTVSerieBaseIE','NRKTVSerieBaseIE') is not None


# Generated at 2022-06-24 13:04:03.809733
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    my_NRKTVSeasonIE = NRKTVSeasonIE()

# Generated at 2022-06-24 13:04:05.006481
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE()



# Generated at 2022-06-24 13:04:06.278000
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()


# Generated at 2022-06-24 13:04:09.602335
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    """
    Unit test for abstract class NRKBaseIE
    """
    ie = InfoExtractor(None, None)
    if not isinstance(ie, NRKBaseIE):
        raise TypeError('Did not create an instance of NRKBaseIE')

# Generated at 2022-06-24 13:04:17.079511
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_value = random.random()
    # NRKBaseIE._CDN_REPL_REGEX should be re.compile(...)
    assert isinstance(NRKBaseIE._CDN_REPL_REGEX, type(re.compile('')))
    # NRKBaseIE._GEO_COUNTRIES should be list
    assert isinstance(NRKBaseIE._GEO_COUNTRIES, list)
    # NRKBaseIE.IE_NAME should be str
    assert isinstance(NRKBaseIE.IE_NAME, str)
    for k in NRKBaseIE.__dict__:
        if k[0] != '_':
            assert callable(getattr(NRKBaseIE, k))



# Generated at 2022-06-24 13:04:19.477394
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    ie.url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    assert ie._real_extract_nrk(ie.url)



# Generated at 2022-06-24 13:04:32.214045
# Unit test for constructor of class NRKIE
def test_NRKIE():
    '''
    sanity check for constructor of class NRKIE
    '''
    # Instantiate the class with test values for the parameters.
    NRKIE(url='https://www.nrk.no/video/PS*150533', ie='NRKIE')
    NRKIE(url='nrk:program/ENRK10100318', ie='NRKIE')
    NRKIE(url='nrk:clip/150533', ie='NRKIE')
    NRKIE(url='nrk:clip/7707d5a3-ebe7-434a-87d5-a3ebe7a34a70', ie='NRKIE')

# Generated at 2022-06-24 13:04:36.466051
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    ie = NRKTVEpisodeIE(NRKTVEpisodeIE.ie_key())
    info = ie.extract(url)
    assert "Hellums kro" in info['title']
    assert info['season_number'] == 1
    assert info['episode_number'] == 2
    assert info['series'] == 'Hellums kro'
    assert info['episode'] == '2. Kro, krig og kjærlighet'

# Generated at 2022-06-24 13:04:41.230980
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    catalog_name = NRKTVSerieBaseIE._catalog_name('podcast')
    assert_true(catalog_name == 'podcast')
    catalog_name = NRKTVSerieBaseIE._catalog_name('series')
    assert_true(catalog_name == 'series')


# Generated at 2022-06-24 13:04:53.886128
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2'
    ie = NRKTVIE()
    video_id = ie._match_id(url)
    nrk_id = 'nrk:%s' % video_id
    actual_result = ie._call_api(nrk_id, video_id, 'playback')
    assert actual_result['_links']['self']['href'] == 'playback/'+video_id
    assert actual_result['playability'] == 'playable'

# Generated at 2022-06-24 13:04:55.547756
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Check that no exception is thrown
    ie = NRKIE('https://www.nrk.no/video/PS*150533')
    del ie


# Generated at 2022-06-24 13:04:58.981336
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    this = NRKSkoleIE()
    expected = InfoExtractor

    error_message = 'Invalid inherited class: expected %s != %s' % (expected, this)
    assert isinstance(this, expected), error_message


# Generated at 2022-06-24 13:05:01.472218
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    url = 'https://tv.nrk.no/serie/anno/'
    ie = NRKTVSerieBaseIE(url=url)
    assert isinstance(ie, NRKTVSerieBaseIE)
    assert ie.url == url
    assert isinstance(ie.program_id, compat_str)



# Generated at 2022-06-24 13:05:08.114136
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    class ConcreteNRKPlaylistBaseIE(NRKPlaylistBaseIE):
        IE_DESC = 'ConcreteNRKPlaylistBaseIE'
        _VALID_URL = 'https://tv.nrk.no/programmer/stikkordsarkiv/LMN'
        _ITEM_RE = r'<a href="(https?://tv\.nrk\.no/serie/[^"]+)"'
        _TITLE_RE = r'<title>([^<>]+)</title>'
        _DESCRIPTION_RE = r'<div class="description">(.+?)</div>'

    inst = ConcreteNRKPlaylistBaseIE()
    inst.url = 'https://tv.nrk.no/programmer/stikkordsarkiv/LMN'

# Generated at 2022-06-24 13:05:14.695117
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
   for serie_kind in NRKTVSerieBaseIE._SERIE_KIND:
      tv_serie_base_instance = NRKTVSerieBaseIE(serie_kind)
      assert tv_serie_base_instance
      assert tv_serie_base_instance._SERIE_KIND[serie_kind]['nrk-catalog-name'] == NRKTVSerieBaseIE._catalog_name(serie_kind)


# Generated at 2022-06-24 13:05:18.403319
# Unit test for constructor of class NRKIE
def test_NRKIE():
    try:
        NRKIE()
    except Exception as e:
        assert e.message == "NRKIE actually requires one argument, ie. url"
        return True
    return False


# Generated at 2022-06-24 13:05:23.183416
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._ITEM_RE == base64.b64decode('ZGF0YS1lcGlzb2RlPVsiXFNlczEyXCIiXQ==').decode()


# Generated at 2022-06-24 13:05:26.936761
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    a = NRKBaseIE('foo bar')
    assert a._GEO_COUNTRIES == ['NO']
    assert a._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 13:05:33.391244
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    with pytest.raises(RegexNotFoundError):
        NRKTVDirekteIE("NRKTVDirekteIE", "NRKTVDirekteIE")

    from ytdl.extractor.nrktv import NRKTVDirekteIE

    assert NRKTVDirekteIE("NRKTVDirekteIE", "NRKTVDirekteIE")._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert NRKTVDirekteIE("NRKTVDirekteIE", "NRKTVDirekteIE").IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-24 13:05:38.636585
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    iep = NRKPlaylistBaseIE()
    iep._match_id('http://tv.nrk.no/serie/lindmo/MUHH21000114/sesong/1/episode/4-4')
    return iep



# Generated at 2022-06-24 13:05:39.535469
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    it = NRKTVSeasonIE("""url""")



# Generated at 2022-06-24 13:05:42.667024
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()._download_webpage(NRKTVDirekteIE()._VALID_URL, "nrk1")


# Generated at 2022-06-24 13:05:47.912816
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE("https://tv.nrk.no/serie/groenn-glede")
    assert ie._API_BASE == "https://psapi.nrk.no/mediaelement/"
    assert ie._VALID_URL == r'https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)'
    assert ie.ie_key() == "NRKTVSeriesIE"
    assert ie.ie_name() == "NRK TV Series"
    assert ie.ie_description() == "NRK TV Series, NRK Super Series and NRK Radio Podkast Series"


# Generated at 2022-06-24 13:06:01.618707
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    from youtube_dl.extractor import gen_extractors
    NRKIE.extractors = gen_extractors()
    extractor = NRKTVEpisodesIE(NRKIE())
    test_cases = [{
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'expected_id': '69031'
    }, {
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031?filter=abc',
        'expected_id': '69031'
    }]
    for test_case in test_cases:
        result = extractor.suitable(test_case['url'])
        assert result

# Generated at 2022-06-24 13:06:06.666729
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """
    Unit test for constructor of class NRKTVDirekteIE
    """
    nrktvdirekte_ie = NRKTVDirekteIE()
    assert str(nrktvdirekte_ie) == "NRK TV and NRK Radio"
    assert nrktvdirekte_ie.IE_DESC == "NRK TV and NRK Radio"

# Generated at 2022-06-24 13:06:08.016155
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    testClass = NRKTVEpisodesIE()
    assert testClass

# Generated at 2022-06-24 13:06:11.955244
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    html = u"<html><body><div itemscope itemtype='http://data-vocabulary.org/Breadcrumb'><a href='https://tv.nrk.no/serie/anno' itemprop='url'><span itemprop='title'>Anno</span></a></div></body></html>"
    test = NRKTVSerieBaseIE(html)
    assert_equal(test.test_result, u'Anno')


# Generated at 2022-06-24 13:06:18.242531
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE(None)._raise_error({})
    NRKIE(None)._raise_error({
        'messageType': 'Unknown',
    })
    NRKIE(None)._raise_error({
        'messageType': 'ProgramRightsAreNotReady',
        'endUserMessage': 'Foo bar',
    })



# Generated at 2022-06-24 13:06:19.482439
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    """
    Unit test for constructor of class NRKTVEpisodesIE
    """
    NRKTVEpisodesIE()



# Generated at 2022-06-24 13:06:20.854695
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert isinstance(NRKTVEpisodesIE(), NRKTVEpisodesIE)



# Generated at 2022-06-24 13:06:24.466341
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    info = NRKTVEpisodeIE()._real_extract('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert info['id'] == 'MUHH36005220'
    assert info['series'] == 'Hellums kro'
    assert info['season_number'] == 1
    assert info['episode_number'] == 2
    assert info['episode'] == '2. Kro, krig og kjærlighet'
    assert info['age_limit'] == 6


# Generated at 2022-06-24 13:06:29.114919
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_ie = NRKTVEpisodesIE()
    assert nrktv_episodes_ie.__class__.__name__ == 'NRKTVEpisodesIE'
    assert nrktv_episodes_ie._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'
    assert nrktv_episodes_ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE


# Generated at 2022-06-24 13:06:30.082533
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie is not None

# Generated at 2022-06-24 13:06:41.073558
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE(None);
    ie.IE_DESC = 'Test Playlist';
    ie._VALID_URL = r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)';
    ie._ITEM_RE = r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="(?P<id>[^"]+)"';
    assert(ie.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'));
    assert(not ie.suitable('http://www.vg.no/'));


# Generated at 2022-06-24 13:06:45.326508
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    # Check if the regex works
    ie.url_result('https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533', 'NRKPlaylist')
    # Check if the regex for NRK URL
    assert ie.suitable('nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9')


# Generated at 2022-06-24 13:06:50.001212
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE()
        PrintOK('NRKPlaylistBaseIE()')
    except Exception as e:
        PrintError('Exception in NRKPlaylistBaseIE():'+repr(e))


# Generated at 2022-06-24 13:06:53.497054
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763', {})



# Generated at 2022-06-24 13:06:55.668732
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    r = NRKTVEpisodesIE()
    assert(r.IE_NAME == 'nrk:tv:episodes')
    assert(r.IE_DESC == 'NRK TV Episodes')

# Generated at 2022-06-24 13:06:57.055472
# Unit test for constructor of class NRKIE
def test_NRKIE():
    t = NRKIE()
    assert t != None


# Generated at 2022-06-24 13:07:01.771313
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL is not None
    assert ie._ITEM_RE is not None
    assert ie._TITLE_RE is not None
    assert ie.__name__ is not None
    assert ie.ie_key() is not None
    assert ie.test() is not None



# Generated at 2022-06-24 13:07:04.613063
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE(NRKTVSeasonIE(), 'https://tv.nrk.no/serie/backstage/sesong/1')



# Generated at 2022-06-24 13:07:08.346515
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    '''
    Test the constructor of class NRKTVIE
    '''
    tester = NRKTVIE()
    assert tester != None

test_NRKTVIE()

# Generated at 2022-06-24 13:07:14.461845
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.suitable('https://www.nrk.no/kultur/toppsaker/') == True
    assert NRKPlaylistBaseIE.suitable('nrk:muuh48000386aa') == False
    assert NRKPlaylistBaseIE.suitable('nrk:MUHH48000314AA') == False
    assert NRKPlaylistBaseIE.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus') == False
    assert NRKPlaylistBaseIE.suitable('https://tv.nrk.no/serie/heartland-ca/sesong/7/episode/20') == False

# Generated at 2022-06-24 13:07:15.621717
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()



# Generated at 2022-06-24 13:07:24.895122
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    test = {
        'url': 'https://tv.nrk.no/serie/backstage/sesong/1',
        'info_dict': {
            'id': 'backstage/1',
            'title': 'Sesong 1',
        },
        'playlist_mincount': 30,
    }
    ie = NRKTVSeasonIE()
    assert ie.suitable(test['url']) == True
    item = ie.extract(test['url'])

    assert item['title'] == test['info_dict']['title']
    assert item['id'] == test['info_dict']['id']
    assert len(item['entries']) == test['playlist_mincount']



# Generated at 2022-06-24 13:07:31.845336
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Test class NRKTVIE
    import re
    klass = NRKTVIE
    ie_key = NRKIE.ie_key()

    # Test key regex
    KEYS = [
        "NRKTVIE._EPISODE_RE",
        "NRKTVIE._VALID_URL",
    ]
    for key in KEYS:
        assert hasattr(klass, key), \
            "NRKTVIE class does not have attribute '%s'" % key

# Generated at 2022-06-24 13:07:36.379201
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2'
    NRKTVEpisodeIE(extract_flat('test_NRKTVEpisodeIE', url, expected_warnings=['Failed to download m3u8 information']))

# Generated at 2022-06-24 13:07:44.691763
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('Nrk')

    assert ie._GEO_COUNTRIES == ie.GEO_BYPASS_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'
    assert ie._extract_nrk_formats('https://foo/bar.m3u8', 'video_id') == []

# Generated at 2022-06-24 13:07:50.412182
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert not ie.suitable('https://tv.nrk.no/serie/lindmo/2017/11-28')



# Generated at 2022-06-24 13:07:58.051922
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    test_class = NRKTVSerieBaseIE()
    assert test_class._ASSETS_KEYS == ('episodes', 'instalments',)
    assert test_class._catalog_name('series') == 'series'
    assert test_class._catalog_name('podcast') == 'podcast'
    assert test_class._catalog_name('podkast') == 'podcast'
    assert test_class._catalog_name('anythingelse') == 'series'
    assert test_class._catalog_name('') == 'series'

