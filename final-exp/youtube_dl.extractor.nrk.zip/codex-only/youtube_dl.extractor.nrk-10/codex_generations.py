

# Generated at 2022-06-24 12:58:00.378335
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    """test class constructor of class NRKPlaylistIE"""
    NRKPlaylistIE(NRKPlaylistBaseIE)
    # verify that calling the constructor raises a TypeError with a specific
    # message
    with pytest.raises(TypeError) as excinfo:
        NRKPlaylistIE()
    assert excinfo.value.args[0] == 'NRKPlaylistIE cannot be called directly, use an instance'


# Generated at 2022-06-24 12:58:03.200801
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE(fake_NRKTVIE())
    assert isinstance(ie, NRKTVEpisodesIE)
    assert isinstance(ie._downloader, fake_NRKTVIE)



# Generated at 2022-06-24 12:58:05.581574
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    """Test for NRKSkoleIE"""
    nrkskole_ie = NRKSkoleIE()
    assert isinstance(nrkskole_ie, InfoExtractor)

# Generated at 2022-06-24 12:58:06.846103
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE("NRKPlaylistIE", "nrk.no")


# Generated at 2022-06-24 12:58:09.001650
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """Unit test for constructor of class NRKIE"""
    nrk = NRKIE()
    assert nrk is not None


# Generated at 2022-06-24 12:58:09.776696
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE() is not None

# Generated at 2022-06-24 12:58:13.112043
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    result = NRKTVSeasonIE._build_request(None, NRKTVSeasonIE._VALID_URL, {'display_id':'abc'})
    print(result)


# Generated at 2022-06-24 12:58:16.346870
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert_equal(ie._ASSETS_KEYS, ('episodes', 'instalments',))
    assert_equal(ie._catalog_name('podcast'), 'podcast')
    assert_equal(ie._catalog_name('program'), 'series')



# Generated at 2022-06-24 12:58:28.377337
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-24 12:58:37.669641
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie_episodes = NRKTVEpisodesIE()
    assert ie_episodes._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie_episodes._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie_episodes._TESTS[0] == {
        'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
        'info_dict': {
            'id': '69031',
            'title': 'Nytt på nytt, sesong: 201210',
        },
        'playlist_count': 4,
    }

# Generated at 2022-06-24 12:58:41.286539
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('NRKPlaylistBaseIE')
    assert ie.ie_key() == 'NRKPlaylistBaseIE'
    # It doesn't make sense to call validate_url() for this class
    # because there are so many different playlists.


# Generated at 2022-06-24 12:58:44.080316
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE(InfoExtractor())._real_extract(
        'https://www.nrk.no/sport/sykling/sesong/1/episode/4')


# Generated at 2022-06-24 12:58:52.476168
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    print(NRKSkoleIE()._extract_urls(u'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'))
    assert False == NRKSkoleIE().suitable(u'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    assert True == NRKSkoleIE().suitable(u'https://nrk.no/skole/?page=search&q=&mediaId=14099')

# Generated at 2022-06-24 12:58:53.538407
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    obj = NRKPlaylistBaseIE('abcd', {}, {}, {}, {}, 'abc')
    assert obj is not None


# Generated at 2022-06-24 12:59:04.548803
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    tvseries = NRKTVSeriesIE('id')
    tvseason = NRKTVSeasonIE('id')
    tvps = list(itertools.product((tvseries, tvseason), (NRKTVIE, NRKTVEpisodeIE, NRKRadioPodkastIE)))
    for (ie1, ie2) in tvps:
        assert not ie1.suitable('https://tv.nrk.no/serie/foo')
        assert ie2.suitable('https://tv.nrk.no/serie/foo')
        assert ie2.suitable('https://tv.nrk.no/bar/foo')
        assert ie2.suitable('https://nrksuper.no/serie/foo')


# Generated at 2022-06-24 12:59:07.261264
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():  # pylint: disable=missing-function-docstring
    for case in NRKTVEpisodeIE._TESTS:
        NRKTVEpisodeIE(case['url'])

# Generated at 2022-06-24 12:59:19.306288
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == '://nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|nrk-od-no\\.telenorcdn\\.net|minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no/'
    assert ie._extract_nrk_formats('https://psapi.nrk.no/programs/skam-6/NRK.Skam.6.Sesong.5.Episode.1.mp4/master.m3u8', '6').mpd_id

# Generated at 2022-06-24 12:59:20.623878
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    obj = NRKSkoleIE()
    return obj._VALID_URL;
# End of Unit test


# Generated at 2022-06-24 12:59:26.579497
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteIE = NRKTVDirekteIE()
    assert nrktvdirekteIE._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert nrktvdirekteIE.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-24 12:59:29.509115
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    instance = NRKTVSeasonIE()
    assert(instance._VALID_URL, NRKTVSeasonIE._VALID_URL)


# Generated at 2022-06-24 12:59:31.707384
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('NRKTVSeasonIE', {}, {}, {})
    expected = 'https://tv.nrk.no/serie/dagsnytt/sesong/1'
    assert ie._VALID_URL == expected


# Generated at 2022-06-24 12:59:41.635388
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert(NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'))
    assert(NRKTVEpisodesIE.suitable('http://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'))
    assert(NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031/'))
    assert(not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/nytt-paa-nytt'))

# Generated at 2022-06-24 12:59:45.286952
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    sys.modules['pyamf'] = FakePyamf()
    try:
        test_url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
        ie = NRKSkoleIE(NRKSkoleIE.ie_key())
        ie.extract(test_url)
    finally:
        del sys.modules['pyamf']



# Generated at 2022-06-24 12:59:46.994604
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE(None, 'http://')


# Generated at 2022-06-24 12:59:56.157902
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():

    try:
        # test the class constructor given a valid program id
        progid = "MDDP12000117"
        testUrl = NRKTVIE(progid, progid)
        assert testUrl.url == 'https://tv.nrk.no/program/' + progid
        assert testUrl.progid == progid

        # test the class constructor given an invalid program id
        progid = "invalidprogid"
        testUrl = NRKTVIE(progid, progid)
        assert testUrl.url == 'https://tv.nrk.no/program/' + progid
        assert testUrl.progid == progid

        print ("Test passed.")

    except:
        print ("Test failed.")


# Generated at 2022-06-24 12:59:57.470059
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # The method __init__ of NRKSkoleIE can be tested
    # by creating an instance of class NRKSkoleIE
    assert NRKSkoleIE is not None



# Generated at 2022-06-24 13:00:03.133018
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE.__name__ == 'NRKTVIE'
    assert str(NRKTVIE) == '<class NRKTVIE at 0x10b78c560>'


# Generated at 2022-06-24 13:00:06.940047
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    pass
    #nrk_skoleIE = NRKSkoleIE.__init__('NRKSkoleIE', True)
    #assert(nrk_skoleIE.ie_key()=='NRKSkoleIE')


# Generated at 2022-06-24 13:00:09.753554
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test construtor with all "extra" keyword arguments
    NRKTVDirekteIE(video_id='dummyid', video_url='dummyurl', video_title='dummytitle')



# Generated at 2022-06-24 13:00:11.252185
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(InfoExtractor())


# Generated at 2022-06-24 13:00:20.265014
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'NRKPlay'
    assert ie.GEO_COUNTRIES == ['NO']
    assert ie.CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 13:00:21.932952
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('nrk', 'NRK')



# Generated at 2022-06-24 13:00:23.827124
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE('url', 'playlist_id', 'webpage')


# Generated at 2022-06-24 13:00:24.951228
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE is not None

# Generated at 2022-06-24 13:00:28.186708
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nie = NRKPlaylistIE('https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    m = re.match(nie._VALID_URL, 'https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    m.group(1)
    return nie, m


# Generated at 2022-06-24 13:00:33.814163
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrkIE = NRKIE()
    assert nrkIE._VALID_URL
    assert nrkIE._TESTS
    assert nrkIE._GEO_COUNTRIES
    assert nrkIE._CDN_REPL_REGEX
    assert nrkIE._FETCH_TTL


# Generated at 2022-06-24 13:00:38.094017
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert NRKTVEpisodeIE._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert NRKTVEpisodeIE._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert NRKTVEpisodeIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:00:40.023000
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-24 13:00:52.838157
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    entry_list = [{'episodeId': 'EpisodeId1', 'description': 'description 1', 'type': 'video'},
                  {'episodeId': 'EpisodeId2', 'description': 'description 2', 'type': 'audio'},
                  {'episodeId': 'EpisodeId3', 'description': 'description 3', 'type': 'video'},
                  {'episodeId': 'EpisodeId4', 'description': 'description 4', 'type': 'video'},
                  {'episodeId': 'EpisodeId5', 'description': 'description 5', 'type': 'audio'}]
    test_class = NRKTVSeriesIE()

# Generated at 2022-06-24 13:00:55.378685
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    from unit_test_common import is_test_successful
    inp = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    out = NRKRadioPodkastIE()
    is_test_successful(out.suitable(inp))


# Generated at 2022-06-24 13:00:59.594182
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE(NRKTVDirekteIE.ie_key(), 'https://radio.nrk.no/direkte/p1_oslo_akershus')


# Generated at 2022-06-24 13:01:10.288639
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Test if class is constructed as expected
    ie = NRKRadioPodkastIE(NRKRadioPodkastIE._downloader)
    assert ie.suitable(None)
    assert not ie.suitable('http://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('http://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')


# Generated at 2022-06-24 13:01:12.888096
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from youtube_dl.utils import ExtractorError
    try:
        NRKTVSeriesIE()
    except ExtractorError as e:
        assert 'NRKTVSeriesIE is supposed to inherit' in str(e)


# Generated at 2022-06-24 13:01:18.353532
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    class TestNRKTVSerieBaseIE(NRKTVSerieBaseIE):
        desc = "Test " + NRKTVSerieBaseIE.__name__
        _VALID_URL = None

    ie = TestNRKTVSerieBaseIE()
    assert ie.desc == "Test " + NRKTVSerieBaseIE.__name__



# Generated at 2022-06-24 13:01:28.518626
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    t = NRKTVSerieBaseIE()
    assert issubclass(t.__class__, NRKTVSerieBaseIE)
    assert t._catalog_name('series') == 'series'
    assert t._catalog_name('podcast') == 'podcast'
    assert t._catalog_name('podkast') == 'podcast'
    assert t._catalog_name('xxx') == 'series'

# Generated at 2022-06-24 13:01:30.181671
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKIE.suitable('nrk:6021')
    NRKIE.suitable('nrk:14099')

# Generated at 2022-06-24 13:01:31.839087
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE(None,'test');

# Generated at 2022-06-24 13:01:32.872469
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    inst = NRKTVEpisodesIE(None)

# Generated at 2022-06-24 13:01:39.738231
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('https://tv.nrk.no/serie/spangas/sesong/1')
    assert ie.domain == 'tv'
    assert ie.serie_kind == 'serie'
    assert ie.serie == 'spangas'
    assert ie.season_id == '1'
    assert ie.display_id == 'spangas/1'



# Generated at 2022-06-24 13:01:41.957781
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():  
    # Create instance of class
    NRKTVDirekte = NRKTVDirekteIE()

    # Test if class is instance of NRKTVIE
    assert isinstance(NRKTVDirekte, NRKTVIE)

    # Test if class is instance of InfoExtractor
    assert isinstance(NRKTVDirekte, InfoExtractor)



# Generated at 2022-06-24 13:01:50.941112
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('Kaltura')
    assert ie
    assert ie.IE_NAME == 'Kaltura'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == '://(?:nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|nrk-od-no\\.telenorcdn\\.net|minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no)/'

# Generated at 2022-06-24 13:01:53.916667
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    if __name__ == '__main__':
        raise Exception('Using this module for running the tests by invoking __main__.py is deprecated. '
                        'Please use the test.py script.')
    return NRKTVIE()

# Generated at 2022-06-24 13:02:02.618939
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    ie = NRKTVSeriesIE()
    assert NRKTVSeriesIE.suitable(url)
    ie.suitable(url)
    ie.extract(url)
    url = 'https://radio.nrk.no/serie/dickie-dick-dickens'
    assert NRKTVSeriesIE.suitable(url)
    ie.suitable(url)
    ie.extract(url)


# Generated at 2022-06-24 13:02:07.204927
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie_obj = NRKPlaylistIE();
    assert_equals(ie_obj._VALID_URL, r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)');
    assert_equals(ie_obj._ITEM_RE, r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"');

# Generated at 2022-06-24 13:02:08.299256
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE(InfoExtractor())



# Generated at 2022-06-24 13:02:14.173367
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-24 13:02:15.517473
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    instanceNRKRadioPodkastIE = NRKRadioPodkastIE()
    assert isinstance(instanceNRKRadioPodkastIE, NRKRadioPodkastIE)



# Generated at 2022-06-24 13:02:28.406840
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    from xml.etree import ElementTree as ET
    import json
    import datetime
    
    # Expected object format

# Generated at 2022-06-24 13:02:32.595432
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    class _DummyIE(NRKTVSerieBaseIE):
        pass

    assert_raises_regex(NotImplementedError, 'This is just a base class', _DummyIE)



# Generated at 2022-06-24 13:02:37.188759
# Unit test for constructor of class NRKIE
def test_NRKIE():
    from .test_common import MOCK_CONFIG
    NRKIE_obj = NRKIE(MOCK_CONFIG)
    assert NRKIE_obj.IE_NAME == 'NRK'


# Generated at 2022-06-24 13:02:44.818603
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    # None as video_id
    assert ie._call_api('psapi/check/rights', '', 'archive') == None
    # Empty string as video_id
    assert ie._call_api('psapi/check/rights', '', 'archive') == None
    # Valid video_id
    assert ie._call_api('psapi/check/rights', '', 'archive') == None
    # Invalid video_id
    assert ie._call_api('psapi/check/rights', '', 'archive') == None


# Generated at 2022-06-24 13:02:46.029148
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie is not None


# Generated at 2022-06-24 13:02:50.801721
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE();

    expected = 'NRKBaseIE';
    assert ie._VALID_URL == '((?:nrk:|https?://(?:(?:www\\.)?nrk\\.no/video/(?:PS*|[^_]+_)|v8[-.]psapi\\.nrk\\.no/mediaelement/))(?P<id>[^?\\#&]+)'
    assert ie.IE_NAME == expected

# Generated at 2022-06-24 13:02:53.457483
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    c1 = NRKSkoleIE("", "https://nrkno-skole-prod.kube.nrk.no/skole/api/media/14099")
    assert c1._download_json("https://nrkno-skole-prod.kube.nrk.no/skole/api/media/14099")["psId"] == "6021"

# Generated at 2022-06-24 13:03:04.873556
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # test for old site domain
    curie = {'url': 'https://tv.nrksuper.no/serie/labyrint',
        'info_dict': {
            'id': 'labyrint',
            'title': 'Labyrint',
            'description': 'I Daidalos sin undersjøiske Labyrint venter spennende oppgaver, skumle robotskapninger og slim.',
            },
        'playlist_mincount': 3,
    }
    curie_res = NRKTVSeriesIE().suitable(curie['url'])
    assert(curie_res)
    curie_res = NRKTVSeriesIE().extract(curie['url'])
    assert(curie_res['id'] == 'labyrint')
    # test for new site domain


# Generated at 2022-06-24 13:03:12.395339
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    non_nrk_IEs = set()
    for ie_name, ie_cls in globals().items():
        if ( (ie_name.endswith('IE') or ie_name.endswith('IE')) and issubclass(ie_cls, InfoExtractor)):
            if issubclass(ie_cls, BaseIE) or issubclass(ie_cls, NRKTVSeriesIE):
                continue
            non_nrk_IEs.add(ie_cls)

    for ie_cls in non_nrk_IEs:
        assert issubclass(ie_cls, BaseIE) == False, 'Non-baseie inherited from NRKTVSeriesIE' + ie_cls.__name__


# Generated at 2022-06-24 13:03:13.733477
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'


# Generated at 2022-06-24 13:03:15.442255
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE()


# Generated at 2022-06-24 13:03:18.089775
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    constructor = NRKBaseIE("test_url", {})
    assert(isinstance(constructor, NRKBaseIE))



# Generated at 2022-06-24 13:03:24.999861
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    def test_non_overlap(cls):
        for ie_class in (NRKPlaylistIE, NRKTVIE, NRKTVEpisodeIE, NRKTVSeriesIE, NRKTVSeasonIE, NRKTVDirekteIE, NRKRadioPodkastIE):
            if cls != ie_class:
                assert not cls.suitable(ie_class._VALID_URL)
    test_non_overlap(NRKPlaylistIE)
    test_non_overlap(NRKTVIE)
    test_non_overlap(NRKTVEpisodeIE)
    test_non_overlap(NRKTVSeriesIE)
    test_non_overlap(NRKTVSeasonIE)
    test_non_overlap(NRKTVDirekteIE)

# Generated at 2022-06-24 13:03:29.272553
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Call the constructor of NRKIE with its parent class (calls __init__ of InfoExtractor)
    ie = NRKIE("Youtube")
    # Check the value of IE_NAME
    ie.IE_NAME.should.equal("NRK")


# Generated at 2022-06-24 13:03:40.828962
# Unit test for constructor of class NRKTVDirekteIE

# Generated at 2022-06-24 13:03:45.626462
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE().suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031') is True
    assert NRKTVEpisodesIE().suitable('https://tv.nrk.no/serie/blank/sesong/2') is False

# Generated at 2022-06-24 13:03:46.260305
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    pass


# Generated at 2022-06-24 13:03:48.946078
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    assert NRKSkoleIE._VALID_URL == url


# Generated at 2022-06-24 13:03:51.356318
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    serie_base_ie = NRKTVSerieBaseIE('NRKTVSerieBaseIE')
    assert serie_base_ie is not None


# Generated at 2022-06-24 13:03:55.407932
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/lindmo/2018/MUHU11006318/avspiller'
    ne = NRKTVEpisodeIE.suitable(url)
    ne.__init__()
    ne._real_extract(url)


# Generated at 2022-06-24 13:03:59.076124
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_obj = NRKTVEpisodeIE()
    assert test_obj.ie_key() == 'NRKTVEpisode'



# Generated at 2022-06-24 13:04:00.545145
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    if __name__ == '__main__':
        test_NRKBaseIE()

# Generated at 2022-06-24 13:04:03.160157
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('NRKTVDirekte')
    assert ie.ie_key() == 'NRKTVDirekte'


# Generated at 2022-06-24 13:04:04.493028
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    a = NRKBaseIE()
    assert(a._call_api('', ''))



# Generated at 2022-06-24 13:04:05.313178
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrkie = NRKIE()
    print(nrkie)

# Generated at 2022-06-24 13:04:06.796027
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.domain == 'tv.nrk'
    assert ie.serie == 'serie'



# Generated at 2022-06-24 13:04:12.303461
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """
    Test the constructor of class NRKTVIE
    """
    nrktvie = NRKTVIE(None);

    assert nrktvie.RE_EPISODE == NRKTVIE._EPISODE_RE
    assert nrktvie.VALID_URL == NRKTVIE._VALID_URL
    assert nrktvie.IE_DESC == NRKTVIE.IE_DESC


# Generated at 2022-06-24 13:04:17.750969
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    for x in re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2').groups():
        print(x)
    for x in re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8').groups():
        print(x)


# Generated at 2022-06-24 13:04:27.855890
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert_false(NRKTVSeasonIE.suitable('http://tv.nrk.no/program/EMNU41202315/28-02-2015'))
    assert_false(NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/skam'))
    assert_false(NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/skam/sesong/1/episode/2'))
    assert_true(NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/skam/sesong/1'))


# Generated at 2022-06-24 13:04:37.014766
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._VALID_URL is None
    assert ie.IE_NAME is None
    assert ie._TESTS == []
    assert ie.instance_type == 'NRKTVSerieBaseIE'
    assert ie.name == 'NRKTVSerieBaseIE'
    assert ie.supported_ie_key_map == {
        'nrk': NRKIE.ie_key(),
    }
    assert ie.expected_warnings == []
    assert ie.report_warnings == False
    assert ie.warning_reporting_key == None



# Generated at 2022-06-24 13:04:40.773867
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    try:
        IE = NRKTVDirekteIE()
    except:
        return
    if len(IE._TESTS) > 0:
        return
    print(
        "ERROR: NRKTVDirekteIE._TESTS must be updated to test for valid streams.")
    sys.exit(-1)


# Generated at 2022-06-24 13:04:43.671273
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert re.search(NRKTVSeriesIE._VALID_URL, 'https://tv.nrksuper.no/serie/labyrint')



# Generated at 2022-06-24 13:04:45.059564
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    construct_NRKTVSerieBaseIE()


# Generated at 2022-06-24 13:04:47.208771
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    instance = NRKBaseIE()
    assert repr(instance) == '<NRKBaseIE>'


# Generated at 2022-06-24 13:04:48.935259
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrkbaseie = NRKBaseIE()
    assert nrkbaseie._GEO_COUNTRIES is ['NO']


# Generated at 2022-06-24 13:04:51.326582
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    in_url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    i1 = NRKTVEpisodeIE()
    i2 = NRKTVIE()
    assert i1._VALID_URL == i2._VALID_URL
    assert type(i1) == type(i2)

# Generated at 2022-06-24 13:04:52.772009
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    instance = NRKRadioPodkastIE()

    assert instance is not None

    # Check that it actually returns a subclass.
    assert issubclass(NRKRadioPodkastIE, InfoExtractor)


# Generated at 2022-06-24 13:04:54.112382
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE()


# Generated at 2022-06-24 13:04:55.850344
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrk_tv_episodes_ie = NRKTVEpisodesIE()
    assert nrk_tv_episodes_ie.ie_key() == 'nrk:tv:episodes', 'ie_key is not "nrk:tv:episodes"'


# Generated at 2022-06-24 13:04:57.675070
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    print("NRKBaseIE.test_NRKBaseIE passed")


# Generated at 2022-06-24 13:05:04.578672
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Instance creation
    inst = NRKPlaylistIE('NRKPlaylistIE', 'nrk.no')
    # Assertions
    assert inst._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert inst._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'



# Generated at 2022-06-24 13:05:07.973537
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('tv') == 'series'



# Generated at 2022-06-24 13:05:16.572809
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/program/mdfp15000514'
    print("Testing NRKTVIE constructor...")
    ie = NRKTVIE(url)
    if ie is None:
        print("[ERROR] Failed to construct object instance.")
    elif type(ie) is not NRKTVIE:
        print("[ERROR] Expected object of type {0}, got {1} instead.".format(str(NRKTVIE), str(type(ie))))
    else:
        print("[OK] Successfully constructed an object instance.")
    print("Done testing NRKTVIE constructor.")


# Generated at 2022-06-24 13:05:18.737285
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE(NRKPlaylistIE.ie_key()) == NRKPlaylistIE



# Generated at 2022-06-24 13:05:26.371802
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    filename = 'NRKPlaylistBaseIE_test.txt'
    with open(filename, 'w', encoding='utf-8') as f:
        f.write('http://nrk.no\n')
        f.write('https://tv.nrk.no/serie/do-not-open\n')
    try:
        NRKPlaylistBaseIE(NRKIE()).extract_info(filename)
    finally:
        os.remove(filename)

# Generated at 2022-06-24 13:05:31.320972
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    from youtube_dl import YoutubeDL
    from youtube_dl.utils import DownloadError

    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    with YoutubeDL(NRKTVEpisodeIE._build_config(YoutubeDL())) as ydl:
        try:
            ydl.extract_info(url)
        except DownloadError as e:
            assert False, 'Failed to initialize NRKTVEpisodeIE'
        else:
            assert True, 'NRKTVEpisodeIE initialized successfully'



# Generated at 2022-06-24 13:05:34.018407
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE(None)._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE(None)._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE(None)._catalog_name('podkast') == 'podcast'


# Generated at 2022-06-24 13:05:46.183889
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKPlaylist', 'NRK')
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == '://nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|://nrk-od-no\\.telenorcdn\\.net|://minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no/'
    assert ie._VALID_URL == r'https?://(?:tv\.)?nrk\.no/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:05:59.601339
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # testing
    url = url_or_none("https://tv.nrk.no/serie/badehotellet/sesong/1/episode/1")
    ie = NRKTVIE()
    nrk = ie.extract(url)
    assert nrk["id"] == "MTP30000116"
    url = url_or_none("https://radio.nrk.no/serie/popul%C3%A6rmusikk/NNFA59004715")
    ie = NRKTVIE()
    nrk = ie.extract(url)
    assert nrk["id"] == "NNFA59004715"
    url = url_or_none("http://tv.nrk.no/program/MPTJ19000700")
    ie = NRKTVIE()
   

# Generated at 2022-06-24 13:06:05.684547
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE("nrk:MDDP12000117", "nrk:MDDP12000117")
    assert(ie.video_id == "MDDP12000117")
    assert(ie.url == "nrk:MDDP12000117")
    assert(ie.REAL_URL == "https://tv.nrk.no/program/MDDP12000117")
    assert(ie.NRK_RE is not None)

# Generated at 2022-06-24 13:06:11.911934
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_ie = NRKPlaylistIE()
    assert nrk_playlist_ie.IE_NAME == 'nrk:playlist'
    assert NRKPlaylistIE.suitable('https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') == True
    assert NRKPlaylistIE.suitable('https://www.nrk.no/video/PS*8659077') == False
    assert NRKPlaylistIE.suitable('https://tv.nrk.no/se/aldri-mer-natt-1') == False


# Generated at 2022-06-24 13:06:19.898514
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    base = NRKBaseIE()
    video_url = 'https://www.nrk.no/video/6rBKYD/how-to-deal-with-hostile-enemies'
    video_id = '6rBKYD'
    path = 'mediaelement/6rBKYD'
    item = 'video'
    note = 'Downloading video JSON'
    query = None
    assert base._call_api(path, video_id, item, note)


# Generated at 2022-06-24 13:06:22.262295
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('NRKPlaylistBaseIE', [])
    ie.playlist_result([], 'id', 'title', 'description')

# Generated at 2022-06-24 13:06:25.695350
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    try:
        video = NRKRadioPodkastIE('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
        print('End of unit test for class NRKRadioPodkastIE')
    except Exception as e:
        print('Unit test for class NRKRadioPodkastIE failed')
        print(str(e))


# Generated at 2022-06-24 13:06:28.465340
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert isinstance(ie._ITEM_RE, type(re.compile('literal')))
    assert(len(ie._TESTS) == 2)
    for test in ie._TESTS:
        assert(isinstance(test, dict))


# Generated at 2022-06-24 13:06:34.344434
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # testing constructor of a different class
    # pylint: disable=W0613
    class TestIE(NRKBaseIE):
        pass

    # testing __init__()
    ie = TestIE()
    assert ie._GEO_COUNTRIES == ['NO']
    # testing _GEO_COUNTRIES
    ie._GEO_COUNTRIES = ['DE']
    assert ie._GEO_COUNTRIES == ['DE']



# Generated at 2022-06-24 13:06:37.363968
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE() != None

# Generated at 2022-06-24 13:06:38.814463
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()


# Generated at 2022-06-24 13:06:40.345613
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    entries_list = NRKTVSerieBaseIE(NRKTVIE())._extract_entries(
        ['non-dict-element'])
    assert entries_list == []


# Generated at 2022-06-24 13:06:45.053739
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-24 13:06:46.082859
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL is not None


# Generated at 2022-06-24 13:06:57.987323
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE(None)
    test = assert_raises(NotImplementedError, ie.suitable, 'http:/www.nrk.no/test')
    test = assert_raises(NotImplementedError, ie._real_extract, 'http:/www.nrk.no/test')
    test = assert_raises(NotImplementedError, ie._extract_title, 'http:/www.nrk.no/test')
    test = assert_raises(NotImplementedError, ie._extract_description, 'http:/www.nrk.no/test')
    test = assert_raises(NotImplementedError, ie._match_id, 'http:/www.nrk.no/test')

# Generated at 2022-06-24 13:07:01.102006
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    NRKTVEpisodeIE = NRKTVEpisodeIE(url)


# Generated at 2022-06-24 13:07:06.031314
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    for cases in NRKTVSeasonIE._TESTS:
        extractor = NRKTVSeasonIE(
            NRKTVSeasonIE.create_ie(cases['url']), cases['url'])
        extractor._real_extract(cases['url'])



# Generated at 2022-06-24 13:07:09.849380
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    (NRKTVSeriesIE('NRKTVSeasonIE'), NRKTVSeriesIE('NRKTVEpisodeIE'),
     NRKTVSeriesIE('NRKTVIE'), NRKTVSeriesIE('NRKRadioPodkastIE'))



# Generated at 2022-06-24 13:07:20.791397
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-24 13:07:32.669688
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('NRKTVSeasonIE')
    ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    ie.suitable('https://tv.nrk.no/serie/lindmo/2016')
    ie.suitable('https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1')
    ie.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    not ie.suitable('https://tv.nrk.no/serie/spangas/sesong/1')

# Generated at 2022-06-24 13:07:34.076254
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE("test", "--test")


# Generated at 2022-06-24 13:07:40.018457
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE('NRKRadioPodkast', False)
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-24 13:07:45.489073
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie.IE_DESC == 'NRK TV and NRK Radio'
    assert nrktvie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert nrktvie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % nrktvie._EPISODE_RE


# Generated at 2022-06-24 13:07:49.711492
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    #tests from _TESTS
    for test in NRKRadioPodkastIE._TESTS:
        #get the test url
        url = test['url']
        #create the instance
        instance = NRKRadioPodkastIE(url)
        #get the test result
        expected = test['only_matching']
        #compare the result
        assert instance.suitable(url) == expected
        #get the test result
        expected = test['only_matching']
        #compare the result
        assert instance.suitable(url) == expected



# Generated at 2022-06-24 13:07:56.680404
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert ie.ie_key() == 'NRKPlaylist'