

# Generated at 2022-06-24 12:58:07.302453
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk = NRKIE()
    nrk_radio = NRKRadioPodkastIE()
    nrk_tv = NRKTVIE()
    nrk_tv_live = NRKTVDirekteIE()
    nrk_tv_series = NRKTVSeriesIE()
    nrk_tv_season = NRKTVSeasonIE()
    nrk_tv_episode = NRKTVEpisodeIE()
    assert(nrk.IE_NAME == "nrk" and nrk.ie_key() == "NRKIE" and nrk.IE_DESC == "NRK")

# Generated at 2022-06-24 12:58:13.039140
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-24 12:58:15.981922
# Unit test for constructor of class NRKIE
def test_NRKIE():
    inst = NRKIE()
    assert inst.IE_NAME == "nrk"
    assert inst.VALID_URL == NRKIE._VALID_URL
    assert inst.GEO_COUNTRIES == NRKBaseIE._GEO_COUNTRIES


# Generated at 2022-06-24 12:58:18.512535
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = "https://radio.nrk.no/serie/dagsnytt/201509"
    NRKTVSeasonIE.suitable(url)
    assert NRKTVSeasonIE.ie_key() == 'NRKTV:season'
    NRKTVSeasonIE(NRKTVSeasonIE.ie_key(), url)._real_extract(url)

# Generated at 2022-06-24 12:58:30.574481
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Create a dummy class with dummy parameter.
    class DummySkoleIE:
        def __init__(self, url, ie_key=None, video_id=None):
            pass

    # Ensure that the constructor of NRKSkoleIE is called instead.
    # Since unit test for NRKSkoleIE is not finished, the expected result
    # is that the url_result function should be called.
    ydl = YoutubeDL({
        'extractors': [
            'NRKSkoleIE',
            'YoutubeDL',
            'DummySkoleIE'
            ],
        'logger': YoutubeDLLogger(),
        })

# Generated at 2022-06-24 12:58:32.166619
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('http://nrk.no/1')



# Generated at 2022-06-24 12:58:41.852885
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    mobj = NRKTVSeriesIE._VALID_URL.match('https://radio.nrk.no/serie/dickie-dick-dickens')
    assert mobj
    nrkplaylist = NRKPlaylistBaseIE(NRKTVSeriesIE, {}, mobj.groupdict())
    assert nrkplaylist.suitable('https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1') == False
    assert nrkplaylist.suitable('https://tv.nrk.no/serie/dickie-dick-dickens/sesong/1') == False
    assert nrkplaylist.suitable('https://radio.nrk.no/serie/dickie-dick-dickens') == True
    assert n

# Generated at 2022-06-24 12:58:42.722699
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    NRKBaseIE()


# Generated at 2022-06-24 12:58:45.489239
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    from .nrk import NRKSkoleIE
    assert NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099') == True
    assert NRKSkoleIE.suitable('https://www.nrk.no') == False


# Generated at 2022-06-24 12:58:47.955931
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    assert nrk


# Generated at 2022-06-24 12:58:53.313407
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteie = NRKTVDirekteIE()
    assert nrktvdirekteie.ie_key == 'NRKTVDirekte'
    assert nrktvdirekteie.ie_desc == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-24 12:58:56.364442
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        season = NRKTVSeasonIE('NRKTVSeason')
    except:
        print("Constructor NRKTVSeasonIE failed")


# Generated at 2022-06-24 12:58:57.827304
# Unit test for constructor of class NRKIE
def test_NRKIE():
    instance = NRKBaseIE()
    print(instance)

# Generated at 2022-06-24 12:58:59.122513
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlist_base_ie = NRKPlaylistBaseIE()
    assert playlist_base_ie.IE_DESC == 'NRK Playlists'


# Generated at 2022-06-24 12:59:01.332796
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk = NRKRadioPodkastIE();
    nrk._real_extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

test_NRKRadioPodkastIE()

# Generated at 2022-06-24 12:59:06.036729
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    with mock.patch('youtube_dl.YoutubeDL.download') as mock_download:
        type(mock_download.return_value).__dict__ = {} # mock YoutubeDL object should be mutable dict
        NRKTVSeasonIE()._entries({}, 'test')
    assert mock_download.call_count == 1
    assert 'episodes' in mock_download.call_args[0][0]


# Generated at 2022-06-24 12:59:13.078418
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes = NRKTVEpisodesIE()
    assert nrktv_episodes._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert nrktv_episodes._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 12:59:19.248127
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE(None)
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|
            nrk-od-no\\.telenorcdn\\.net|
            minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no
        )/'''
    assert ie._extract_nrk_formats('http://whatever', 'id') is None

# Generated at 2022-06-24 12:59:28.721114
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Can't have this unit test inside NRKTVEpisodesIE because of
    # relative imports of extractor and downloader modules so we
    # have to put it here.
    test_url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    nrk_tv_episodes_ie = NRKTVEpisodesIE()

    # Sanity checks on extracted instance attributes
    assert nrk_tv_episodes_ie._VALID_URL == \
        'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\\d+)'
    assert nrk_tv_episodes_ie._TESTS[0]['url'] == test_url
    assert nrk_tv_episodes_ie._TESTS

# Generated at 2022-06-24 12:59:38.870973
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable("https://tv.nrk.no/serie/spangas/sesong/1")
    assert NRKTVSeasonIE.suitable("https://radio.nrk.no/serie/dagsnytt/sesong/201509")
    assert not NRKTVSeasonIE.suitable("https://tv.nrk.no/serie/spangas/sesong/11")
    assert not NRKTVSeasonIE.suitable("https://radio.nrk.no/serie/dagsnytt/sesong/201909")
    assert not NRKTVSeasonIE.suitable("https://tv.nrk.no/program/MSPO27000815")

# Generated at 2022-06-24 12:59:41.541484
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    obj = NRKTVEpisodesIE({})
    assert obj._ITEM_RE == 'data-episode=["\']%s' % NRKTVIE._EPISODE_RE



# Generated at 2022-06-24 12:59:48.619958
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    expected_output = {
        'id': 'MUHH36005220',
        'ext': 'mp4',
        'title': 'Hellums kro - 2. Kro, krig og kjærlighet',
        'description': 'md5:ad92ddffc04cea8ce14b415deef81787',
        'duration': 1563.92,
        'series': 'Hellums kro',
        'season_number': 1,
        'episode_number': 2,
        'episode': '2. Kro, krig og kjærlighet',
        'age_limit': 6,
    }
    ie_test_object = NRKTVE

# Generated at 2022-06-24 12:59:54.179624
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url_test = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    data_test = NRKTVEpisodeIE()._real_extract(url_test)
    # Checking the data type of fields in data_test
    for key in data_test.keys():
        if key == "age_limit": # Checking for int type
            assert isinstance(data_test[key], int)
        elif key == "duration": # Checking for float type
            assert isinstance(data_test[key], float)
        elif key == "season_number" or key == "episode_number":
            assert isinstance(data_test[key], int)
        else: # Checking for string type
            assert isinstance(data_test[key], str)

# Generated at 2022-06-24 13:00:08.004513
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert ie.suitable('https://radio.nrk.no/podcast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert not ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-24 13:00:09.405734
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    test = NRKTVSeriesIE()
    assert(test is not None)



# Generated at 2022-06-24 13:00:21.828123
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        from urllib.request import Request
    except ImportError:
        from urllib2 import Request

    try:
        from urllib.parse import urlparse
    except ImportError:
        from urlparse import urlparse

    def _mock_urlopen(request):
        url_obj = urlparse(request.get_full_url())
        url_path = url_obj.path

# Generated at 2022-06-24 13:00:24.126284
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE(None, 'https://tv.nrk.no/serie/bla-bla-bla')


# Generated at 2022-06-24 13:00:34.019685
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    inst = NRKTVSeasonIE()
    assert inst._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''


# Generated at 2022-06-24 13:00:40.809275
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('any_url')
    assert isinstance(ie, NRKBaseIE)
    assert ie._VALID_URL == None
    assert isinstance(ie._TESTS, list)
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._entries(None, None) == None
    assert ie._extract_entries(None) == []
    assert ie._extract_assets_key(None) == None
    assert ie._catalog_name(None) == None


# Generated at 2022-06-24 13:00:43.581848
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    class_ = globals()['NRKTVSeasonIE']
    assert(class_.__name__ == 'NRKTVSeasonIE')


# Generated at 2022-06-24 13:00:48.938808
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id, season_number, episode_number = re.match(NRKTVEpisodeIE._VALID_URL, url).groups()
    webpage = '<html><head><meta name="nrk:program-id" content="MUHH36005220"></head></html>'
    info = NRKTVEpisodeIE._search_json_ld(webpage, display_id, default={})

# Generated at 2022-06-24 13:00:53.106090
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE(None, url)
    assert ie.suitable(url)
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_key()



# Generated at 2022-06-24 13:00:55.037915
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    inst = NRKBaseIE()
    assert inst._GEO_COUNTRIES == ['NO']


# Generated at 2022-06-24 13:01:08.074596
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = 1
    episode_number = 2
    # Test 1: No value for NRK id
    info = {
        '@id': '',
    }
    expected_info = {
        '_type': 'url',
        'id': '',
        'url': 'nrk:',
        'ie_key': NRKIE.ie_key(),
        'season_number': season_number,
        'episode_number': episode_number,
    }
    assert expected_info == NRKTVEpisodeIE._extract_info(url, info, display_id)
    # Test

# Generated at 2022-06-24 13:01:09.755674
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()


# Generated at 2022-06-24 13:01:13.380333
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """Unit test of NRKTVIE
    """
    assert NRKTVIE.IE_DESC != None
    assert NRKTVIE._VALID_URL != None
    assert NRKTVIE._TESTS != None


# Generated at 2022-06-24 13:01:19.320462
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
# Arrange
    url = "https://www.nrk.no/skole/?page=search&q=&mediaId=14099"
    # Act
    test_NRKSkoleIE = NRKSkoleIE(NRKIE(), url)
# Assert
    assert test_NRKSkoleIE.ie_key() == "NRKSkole"



# Generated at 2022-06-24 13:01:29.044607
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    tn = NRKPlaylistIE(NRKPlaylistIE._create_getinfo())
    assert_true(tn._downloader is not None)
    assert_true(tn._LOG_DEBUG() is not None)
    assert_true(tn._LOG_WARNING() is not None)
    #assert_true(tn._APP_VERSION is not None)
    assert_true(tn._VALID_URL is not None)
    #assert_true(tn._NETRC_MACHINE is not None)
    #assert_true(tn._GEO_COUNTRIES is not None)
    #assert_true(tn._GEO_BYPASS_PAGE is not None)
    #assert_true(tn._GEO_BYPASS is not None)
    #assert_true(tn._SORT_KEY is not None)
    #assert_

# Generated at 2022-06-24 13:01:36.685456
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRK')
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\nnrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|\nnrk-od-no\.telenorcdn\.net|\nminicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n/'


# Generated at 2022-06-24 13:01:49.418808
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('nrk', 'NRK TV and NRK Radio')

    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 13:02:01.562411
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test no match
    assert NRKTVSeriesIE.suitable('foo') is False

    # Test matches

# Generated at 2022-06-24 13:02:09.336094
# Unit test for constructor of class NRKIE
def test_NRKIE():
    _test_NRKIE = NRKIE('test')
    assert _test_NRKIE._GEO_COUNTRIES == ['NO']
    assert _test_NRKIE._CDN_REPL_REGEX.count('nrk-od-no\.telenorcdn\.net') == 1
    assert _test_NRKIE._CDN_REPL_REGEX.count('nrkod\d') == 2

# Generated at 2022-06-24 13:02:10.272197
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE(NRKRadioPodkastIE._VALID_URL, "Testing", None, None)

# Generated at 2022-06-24 13:02:11.742139
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie._VALID_URL
    ie.IE_NAME
    ie._TESTS

# Generated at 2022-06-24 13:02:19.357758
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Without video_id
    with pytest.raises(AssertionError):
        nrk = NRKTVEpisodesIE(None)
    # With video_id
    nrk = NRKTVEpisodesIE('69031')
    assert nrk._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/' + '69031'
    assert nrk._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE


# Generated at 2022-06-24 13:02:23.100338
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    mm = NRKTVSeasonIE('NRKTVSeasonIE', 'https://tv.nrk.no/serie/backstage/sesong/1')
    assert isinstance(mm, NRKTVSeasonIE)



# Generated at 2022-06-24 13:02:25.374385
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test = NRKPlaylistIE()
    assert test.__class__.__name__ == "NRKPlaylistIE"

# Generated at 2022-06-24 13:02:36.974682
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Arrange
    test_nrktvdirekte = NRKTVDirekteIE()
    test_nrktv_id = 'nrk1'
    test_nrktv_url = 'https://tv.nrk.no/direkte/%s' % test_nrktv_id
    # Assert
    assert test_nrktvdirekte._VALID_URL == 'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert test_nrktv_id in test_nrktv_url



# Generated at 2022-06-24 13:02:40.578635
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # typical examples of URLs containing the video ID.
    # can be added here for easier debugging
    URLS = []

    for url in URLS:
        NRKTVIE(NRKTVIE())._real_extract(url)



# Generated at 2022-06-24 13:02:42.514383
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie._call_api('test', 'test', 'test')


# Generated at 2022-06-24 13:02:48.865494
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Get the m3u8 playlist URL and all the segments
    playlist_url = 'https://nrk-ssl-hls-v8.akamaized.net/hls/live/206942/nrk_radio_p1_ostlandssendingen/master_audioonly_no.m3u8'
    test = get_playlist(playlist_url)

    nrk_tv = NRKTVIE({}, dummy_url='dummy')
    assert nrk_tv.url == 'dummy'

# Generated at 2022-06-24 13:02:52.715182
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert "NRKPlaylistIE" in globals()

# Generated at 2022-06-24 13:02:55.650306
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    video_url = 'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/14099'
    nrk_id = '6021'

    # If the json file is not available, the unit test will fail.
    # We need to find a way to mock a json file as an object.
    json_content = self._download_json(video_url, video_id)
    self.assertEqual(nrk_id, json_content['psId'])

# Generated at 2022-06-24 13:02:58.304539
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('test')
    assert ie
    assert ie.geo_countries
    assert ie.geo_countries == ['NO']



# Generated at 2022-06-24 13:03:02.004925
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    o = NRKTVEpisodeIE()
    assert o.IE_DESC == 'NRK TV and NRK Radio'
    assert o.ie_key() == 'NRKTV'
    assert o.get_id() == NRKTVIE.get_id()
    assert o._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-24 13:03:06.600555
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    nrktv_episodes_ie = NRKTVEpisodesIE(NRKTVIE())
    nrktv_episodes_ie._download_webpage = mock.Mock()
    nrktv_episodes_ie._download_webpage.return_value = '<h1>Nytt på nytt, sesong: 201210</h1>'
    nrktv_episodes_ie._ITEM_RE = r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    nrktv_episodes_ie._match_id(url) == '69031'
    nrktv_episodes_ie._ITEM

# Generated at 2022-06-24 13:03:11.111985
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Constructor of class NRKTVIE
    nrk = NRKTVIE()
    # Ensure that the page is downloaded
    nrk._download_webpage(nrk._VALID_URL % 'MUHH46000317', 'MUHH46000317')

# Generated at 2022-06-24 13:03:14.998289
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE({'serie_kind': 'podkast', 'id': 'serieName'})
    assert ie.url == 'https://radio.nrk.no/podkast/serieName'

# Generated at 2022-06-24 13:03:15.868147
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    instance = NRKPlaylistIE()
    assert instance._ITEM_RE is None

# Generated at 2022-06-24 13:03:16.596086
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    tmp = NRKTVEpisodeIE()
    print(tmp._VALID_URL)

# Generated at 2022-06-24 13:03:18.360460
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    print(NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'))


# Generated at 2022-06-24 13:03:19.110160
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE('NRKTVIE') == 'NRKTVIE'

# Generated at 2022-06-24 13:03:22.630510
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    page = '{"_embedded": {"episodes": {"_embedded": {"episodes": [{"prfId": "MNTP13004115"}]}}}}'
    nrk_tv_serie_base_ie = NRKTVSerieBaseIE()
    nrk_tv_serie_base_ie._extract_entries(json.loads(page))



# Generated at 2022-06-24 13:03:31.668131
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktv_serie_base_ie = NRKTVSerieBaseIE()
    assert nrktv_serie_base_ie._extract_assets_key({'episodes': True}) == 'episodes'
    assert nrktv_serie_base_ie._extract_assets_key({'instalments': True}) == 'instalments'
    assert not nrktv_serie_base_ie._extract_assets_key({})
    assert not nrktv_serie_base_ie._extract_assets_key('')
    assert not nrktv_serie_base_ie._extract_assets_key([])
    assert nrktv_serie_base_ie._catalog_name('series') == 'series'
    assert nrktv_serie_

# Generated at 2022-06-24 13:03:32.999850
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    obj = NRKPlaylistBaseIE("")
    assert obj is not None


# Generated at 2022-06-24 13:03:43.196253
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """
    Note that this test function is only used for
    testing the constructor of class NRKTVDirekteIE.
    """
    # Arrange
    url = 'https://tv.nrk.no/direkte/nrk1'
    # Act
    direkte = NRKTVDirekteIE(url)
    # Assert
    direkte.preset = 'nrk_direkte'
    assert direkte.url == url
    assert direkte.title == 'NRK 1 direkte'
    assert direkte.thumbnail == 're:https://.*?\.nrk\.no/img/.*1.*\.jpg'
    assert direkte.ie_key() == 'NRKTVDirekte'



# Generated at 2022-06-24 13:03:45.358353
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://nrksuper.no/spillerliste/762333'
    nrkpl = NRKPlaylistBaseIE(None).suitable(url)
    assert nrkpl == True



# Generated at 2022-06-24 13:03:51.963238
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """
    Constructor test for the class NRKPlaylistBaseIE.
    """
    url = 'https://tv.nrk.no/serie/jul-i-blaafarvevÃ¦rket/sesong/1/episode/1'

    nrkIE = NRKPlaylistBaseIE()

    # Exception is thrown if _VALID_URL doesn't match valid URL
    with pytest.raises(ExtractorError):
        nrkIE.suitable(url)

    # Try to create a new instance and extract valid URL
    assert nrkIE.suitable(url)

# Generated at 2022-06-24 13:03:53.047077
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()

# Generated at 2022-06-24 13:03:56.964001
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Tests that the URL is being constructed properly in the _real_extract()
    # of NRKSkoleIE
    info_extractor = NRKSkoleIE()

    # Video 14099 is an example of the Genetikk og eneggede tvillinger
    # from the _TESTS above.
    # Video 6021 is the expected value of the corresponding 'psId' from
    # the JSON response from the API call.
    response = info_extractor._download_json(
        'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/14099', '14099')

    assert response['psId'] == '6021'



# Generated at 2022-06-24 13:03:59.889735
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE("NRKTVSeasonIE fake url")


# Generated at 2022-06-24 13:04:05.411563
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Extracting video_id
    radio_podkast_ie = NRKRadioPodkastIE()
    video_id = radio_podkast_ie._match_id(
        'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert video_id == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'


# Generated at 2022-06-24 13:04:07.069888
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    inst = NRKTVEpisodesIE()
    assert inst._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE



# Generated at 2022-06-24 13:04:08.111910
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE()

# Generated at 2022-06-24 13:04:11.320358
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    episodes = NRKTVEpisodesIE()
    assert episodes._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert episodes._ITEM_RE == 'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert hasattr(episodes, '_TESTS')



# Generated at 2022-06-24 13:04:14.905079
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    base_url = 'https://tv.nrk.no/serie/lindmo/2016'
    url_format = '%s'
    url_fixture = url_format % base_url
    assert url_fixture == NRKTVSeasonIE._VALID_URL
    assert NRKTVSeasonIE.suitable(url_fixture)
    assert not NRKTVSeasonIE.suitable(base_url)



# Generated at 2022-06-24 13:04:27.739364
# Unit test for constructor of class NRKTVDirekteIE

# Generated at 2022-06-24 13:04:32.213748
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    assert nrk._VALID_URL == nrk._VALID_URL
    assert nrk._TESTS == nrk._TESTS

if __name__ == '__main__':
    test_NRKIE()

# Generated at 2022-06-24 13:04:34.428591
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.IE_NAME == 'nrktv:episode'


# Generated at 2022-06-24 13:04:40.252516
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert NRKPlaylistIE('https://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert not NRKPlaylistIE('https://www.nrk.no/kultur/bok/')


# Generated at 2022-06-24 13:04:47.041683
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    instance = NRKTVEpisodeIE()
    urls = [
        'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2',
        'https://tv.nrk.no/serie/backstage/sesong/1/episode/8',
    ]
    for url in urls:
        instance._real_extract(url)


# Generated at 2022-06-24 13:04:57.772939
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
	print("####################################################")
	print("TESTING NRKTVEpisodeIE:")
	temp = NRKTVEpisodeIE()
	temp._VALID_URL = r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
	if(temp._match_id('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2') != 'hellums-kro/sesong/1/episode/2'):
		print('FAILED')
	else:
		print('SUCCESS')


# Generated at 2022-06-24 13:05:04.670671
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    i = NRKRadioPodkastIE(url)
    assert i.video_id == 'l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    assert i.url == url

# Generated at 2022-06-24 13:05:07.724992
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE('https://tv.nrk.no/serie/lindmo/2016')
    NRKTVSeasonIE('https://radio.nrk.no/serie/dagsnytt/sesong/201509')


# Generated at 2022-06-24 13:05:10.029779
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')

# Generated at 2022-06-24 13:05:14.235269
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    try:
        ie = NRKTVEpisodeIE()
    except Exception:
        assert False

NRKTVDirekteIE = NRKTVSeriesIE = NRKTVEpisodeIE



# Generated at 2022-06-24 13:05:16.429210
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE('/skole/?page=search&q=&mediaId=14099')


# Generated at 2022-06-24 13:05:18.626308
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.ie_key() == 'NRKTV'


# Generated at 2022-06-24 13:05:29.860936
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    params=NRKRadioPodkastIE()._real_extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert params['url'] == 'nrk:l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8', "Incorrect URL returned for NRKRadioPodkastIE"
    assert params['id'] == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8', "Incorrect ID returned for NRKRadioPodkastIE"


# Generated at 2022-06-24 13:05:31.889609
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE(NRKTVIE())._ITEM_RE == NRKTVIE._EPISODE_RE + r'"'

# Generated at 2022-06-24 13:05:37.450445
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.ie_key() == 'NRKTV'
    assert ie.ie_key() == ie.name
    assert ie._VALID_URL == ie._VALID_URL_TEMPL % ie._EPISODE_RE


# Generated at 2022-06-24 13:05:47.020367
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlist_id = 'MUHH48000314AA'
    webpage = '<div data-nrk-playlist-item-embedded-id="%s"></div>' % playlist_id
    url = 'https://www.nrk.no/not_a_valid_nrk_url'

    playlist = NRKPlaylistBaseIE()
    result = playlist._real_extract(url)

    # Verify that the method _real_extract returned a Playlist containing
    # a single Video with ID 'MUHH48000314AA'
    assert(len(result["entries"]) == 1)
    assert(result["entries"][0]["id"] == playlist_id)


# Generated at 2022-06-24 13:06:01.331047
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test for id with only letters
    ie = NRKTVDirekteIE(NRKTVDirekteIE.ie_key(), 'nrk1')
    assert ie.stream_url == 'http://v8.psapi.nrk.no/live/a1/128.mp3'

    # Test for id with only letters and underscore
    ie = NRKTVDirekteIE(NRKTVDirekteIE.ie_key(), 'p1_ostlandssendingen')
    assert ie.stream_url == 'http://v8.psapi.nrk.no/live/a1/128.mp3'

    # Test for id with only letters, digits and underscore

# Generated at 2022-06-24 13:06:04.441036
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    downloader = Downloader()
    obj = NRKTVSerieBaseIE('id', 'url', downloader, 'params')
    assert obj.downloader is downloader
    assert obj._API_BASE_URL is 'https://psapi.nrk.no/'
    assert obj._PLAYER_BASE_URL is 'https://tv.nrk.no/'
    assert isinstance(obj._API_HEADERS, dict)


# Generated at 2022-06-24 13:06:16.237333
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    class DummyIE(InfoExtractor):
        _VALID_URL = r'https?://example\.com/'

        def _real_extract(self, url):
            return self.url_result(url, 'DummyIE')

    ie = DummyIE()
    assert ie.SUCCESS == ie
    assert ie.Result() == ie
    assert ie.url_result('http://example.com/') == ie
    assert ie.url_result('http://example.com/#more', 'Other') == ie
    assert ie.playlist_result([], playlist_title='Cool') == ie
    assert ie.playlist_result([], playlist_id='id') == ie
    assert ie.playlist_result([], playlist_id='id', playlist_title='Cool') == ie

# Generated at 2022-06-24 13:06:17.954877
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test_url = 'https://www.nrk.no/x/playlist/1'
    with pytest.raises(NotImplementedError):
        NRKPlaylistBaseIE()._real_extract(test_url)



# Generated at 2022-06-24 13:06:18.545747
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE(None)

# Generated at 2022-06-24 13:06:21.315140
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk_ie = NRKIE()
    assert isinstance(nrk_ie, InfoExtractor)
    assert isinstance(nrk_ie, NRKBaseIE)

# Generated at 2022-06-24 13:06:27.555352
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    class_ = NRKTVEpisodesIE
    
# Following are the attributes of class_
#     _VALID_URL = r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
#     _TESTS = [{
#         'url': 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
#         'info_dict': {
#             'id': '69031',
#             'title': 'Nytt på nytt, sesong: 201210',
#         },
#         'playlist_count': 4,
#     }]
#     _API_KEY = '2a19c10774c97bfb8c6b941ebb2531

# Generated at 2022-06-24 13:06:29.026975
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie.ie_key() == 'NRKTV'


# Generated at 2022-06-24 13:06:37.433432
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == 'NRK'
    assert ie._VALID_URL == r'https?://(?:tv|radio|www)\.nrk\.no/serie/(?P<id>.+)|https?://www\.nrk\.no/sport/.*/.*/.*/\d{4}/\d{2}/\d{2}/.*\d+$'
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-24 13:06:39.631908
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    from youtube_dl.utils import SearchInfoExtractor

    obj = SearchInfoExtractor('nrktvseriebaseie')
    assert_false(not isinstance(NRKTVSerieBaseIE(), SearchInfoExtractor))

test_NRKTVSerieBaseIE.unit_test = True
del test_NRKTVSerieBaseIE



# Generated at 2022-06-24 13:06:47.737738
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2'

    ie = NRKTVIE()
    assert ie.suitable(url)

    # try to extract the id of a video
    extracted_id = ie._match_id(url)
    assert extracted_id == 'MSPO40010515'

    # check the instance variables of NRKTVIE
    assert ie.ie_key() == 'NRKTV'
    assert ie.host == 'tv.nrk.no'
    assert ie.name == 'NRKTV'

# Generated at 2022-06-24 13:06:50.193301
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    if sys.version_info[0] == 2:
        # __init__() got an unexpected keyword argument 'nrk'
        assert_raises_regexp(TypeError, r'__init__.*unexpected',
            NRKSkoleIE, 'http://www.nrk.no/skole/?page=search&q=&mediaId=14099')


# Generated at 2022-06-24 13:06:51.537202
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-24 13:06:59.972382
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-24 13:07:03.426749
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrk_ie = NRKTVEpisodesIE()
    print("OK!")

if __name__ == '__main__':
    test_NRKTVEpisodesIE()

# Generated at 2022-06-24 13:07:09.195230
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # test with url=https://www.nrk.no/skole/?page=search&q=&mediaId=14099
    # check if MediaId is 14099
    assert (NRKSkoleIE._VALID_URL.match('https://www.nrk.no/skole/?page=search&q=&mediaId=14099').group('id') ==
            '14099')

# Generated at 2022-06-24 13:07:12.323958
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    NRKTVEpisodesIE(url)

# Generated at 2022-06-24 13:07:21.531058
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # video
    vid = '150533'
    # audio
    vid = '154915'
    nrk = NRKIE('', {})
    path_templ = 'playback/%s/' + vid
    def call_api(item):
        return nrk._call_api(path_templ % item, vid, item)
    # success
    assert isinstance(call_api('manifest'), dict)
    assert isinstance(call_api('metadata'), dict)
    # failure
    try:
        call_api('nonsense')
    except:
        pass
    else:
        raise AssertionError('Expected non-existing API to fail')



# Generated at 2022-06-24 13:07:22.316510
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    e = NRKPlaylistBaseIE()
    assert e is not None


# Generated at 2022-06-24 13:07:24.173814
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert issubclass(NRKPlaylistBaseIE, InfoExtractor)
    return NRKPlaylistBaseIE



# Generated at 2022-06-24 13:07:31.394128
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    # test _VALID_URL
    m = re.flatten(ie._VALID_URL)
    rx = re.compile(m)
    assert rx.match('https://tv.nrk.no/program/MDDP12000117')
    assert rx.match('https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015')
    assert rx.match('https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13')
    assert rx.match('https://tv.nrk.no/serie/lindmo/2018/MUHU11006318/avspiller')

# Generated at 2022-06-24 13:07:32.859524
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ig = NRKTVDirekteIE()



# Generated at 2022-06-24 13:07:34.818310
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    class_name = ie.__class__.__name__
    assert class_name == 'NRKBaseIE'


# Generated at 2022-06-24 13:07:37.380026
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # test for NRKTVEpisodesIE constructor
    assert NRKTVEpisodesIE('http://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')

# Generated at 2022-06-24 13:07:38.483956
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    instance = NRKTVSeasonIE(None)
    assert isinstance(instance, NRKTVSeasonIE)



# Generated at 2022-06-24 13:07:46.212287
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IE = NRKBaseIE()
    assert IE.server_url() == "http://psapi.nrk.no"
    assert IE.IE_DESC == "NRK and NRKTV"
    assert IE.IE_NAME == "nrk"

# Generated at 2022-06-24 13:07:52.342662
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    from .nrk import NRKTVEpisodeIE
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-24 13:08:02.006833
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert_true(isinstance(NRKTVSerieBaseIE, type))
    assert_true(NRKTVSerieBaseIE.__name__, 'NRKTVSerieBaseIE')
    shall_return_none = NRKTVSerieBaseIE()._extract_assets_key('0')
    assert_true(shall_return_none is None)
    shall_return_none = NRKTVSerieBaseIE()._extract_assets_key(None)
    assert_true(shall_return_none is None)
    shall_return_none = NRKTVSerieBaseIE()._extract_assets_key(
        {"episodes": [{"episodeId": "MUHU11006318"}]})
    assert_true(shall_return_none == 'episodes')
    shall_return_none = NRKTVSerie