

# Generated at 2022-06-24 12:57:59.994718
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk_ie = NRKTVDirekteIE()
    assert nrk_ie.ie_key() == 'NRKTVDirekte'


# Generated at 2022-06-24 12:58:01.451700
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteie = NRKTVDirekteIE()
    assert nrktvdirekteie



# Generated at 2022-06-24 12:58:08.608110
# Unit test for constructor of class NRKIE

# Generated at 2022-06-24 12:58:10.758360
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert isinstance(NRKSkoleIE.ie_key(), type(NRKIE.ie_key()))


# Generated at 2022-06-24 12:58:18.046169
# Unit test for constructor of class NRKIE
def test_NRKIE():
    tmp = NRKIE()._GEO_COUNTRIES
    if tmp:
        raise Exception('NRKIE._GEO_COUNTRIES not empty')
    if not re.match(r'^http://psapi.nrk.no/playback/manifest/\d+$', NRKIE()._make_request_url(None)):
        raise Exception('NRKIE._make_request_url failed')
    tmp = NRKIE()._make_request_url(None, {'somekey': []})
    if not tmp or not tmp.startswith('http://psapi.nrk.no/playback/manifest/?'):
        raise Exception('NRKIE._make_request_url failed')
    tmp = NRKIE()._make_request_url(None, {'somekey': ['somevalue']})

# Generated at 2022-06-24 12:58:20.385019
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """
    Constructor of class NRKTVSeasonIE shouldn't throw exception.
    """

    # construct an instance of NRKTVSeasonIE and call its test_suitable method
    NRKTVSeasonIE().suitable('http://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')



# Generated at 2022-06-24 12:58:25.360992
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert isinstance(ie, NRKTVSeasonIE)
    assert ie.suitable('https://tv.nrk.no/serie/nytt-paa-nytt/MUHH46000317/27-01-2017') == False
    assert ie.suitable('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2') == False
    assert ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1') == True
    assert ie.suitable('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015') == False


# Generated at 2022-06-24 12:58:31.967772
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    jpg = 'http://nrk.no/img.jpg'
    assert type(NRKTVEpisodesIE(
        'URL', 'NRKTVEpisodesIE', 'Playlist title', 'Video description',
        'Video title', jpg, jpg, 'Video duration', 'Video uploader',
        'Video uploader ID', 'Video uploader URL', 'Video view count',
        'Video comment count', 'thumb')) is NRKTVEpisodesIE

# Generated at 2022-06-24 12:58:35.932513
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = "http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763"

    NRKPlaylistIE.suitable(url)
    ie = NRKPlaylistIE()
    ie.extract(url)


# Generated at 2022-06-24 12:58:39.398483
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    m = NRKRadioPodkastIE()
    assert m._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-24 12:58:46.279629
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # To be removed when the URL will work again
    r1 = NRKTVIE()
    r2 = NRKTVIE()
    # Test the __init__ method and check if the class is initialized properly.

# Generated at 2022-06-24 12:58:49.480059
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'


# Generated at 2022-06-24 12:58:52.881966
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE(None)
    assert isinstance(ie, NRKPlaylistIE)
    assert isinstance(ie, NRKPlaylistBaseIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:59:00.257094
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    a = NRKTVSerieBaseIE()
    assert type(a._ASSETS_KEYS) == tuple and len(a._ASSETS_KEYS) == 2
    assert type(a._catalog_name) == staticmethod
    assert type(a._entries) == function
    assert callable(a._extract_assets_key) == True
    assert callable(a._extract_entries) == True


# Generated at 2022-06-24 12:59:04.508614
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE('some url')
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == 'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie.ie_key() == 'NRKSkole'
    assert ie.name == 'NRK'

# Generated at 2022-06-24 12:59:16.194025
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/program/MDDP12000117'
    assert ie._TESTS[0]['md5'] == 'c4a5960f1b00b40d47db65c1064e0ab1'

# Generated at 2022-06-24 12:59:19.260525
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE._VALID_URL == NRKIE.VALID_URL
    assert NRKIE._TESTS == NRKIE.TESTS


# Generated at 2022-06-24 12:59:24.356176
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    target_class = __import__('nrk.nrkbase', globals(), locals(), ['NRKBaseIE']).NRKBaseIE
    assert issubclass(target_class, __import__('youtube_dl.extractor.common', globals(), locals(), ['InfoExtractor']).InfoExtractor)
# test_NRKBaseIE ends here


# Generated at 2022-06-24 12:59:31.559665
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    inst = NRKTVEpisodeIE('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert inst._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))', inst._VALID_URL
    assert inst._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2', inst._TESTS[0]['url']

# Generated at 2022-06-24 12:59:37.327590
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    obj = NRKTVSerieBaseIE('http://www.youtube.com')
    assert obj.IE_DESC == 'NRK TV and NRK Radio'
    assert obj.ASSETS_KEYS == ('episodes', 'instalments',)
    assert obj.base_url == 'https://tv.nrk.no/'
    assert obj.CATALOGS_URL == 'https://api.nrk.no/catalogs'



# Generated at 2022-06-24 12:59:38.553832
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(None)
    assert isinstance(ie, NRKTVSerieBaseIE)


# Generated at 2022-06-24 12:59:44.543315
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'
    nrkplaylistie = NRKPlaylistIE(url)
    assert nrkplaylistie._match_id(url) == 'rivertonprisen-til-karin-fossum-1.12266449'
    assert nrkplaylistie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert nrkplaylistie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'

# Generated at 2022-06-24 12:59:46.916662
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-24 12:59:51.998670
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """Test constructor of class NRKTVDirekteIE"""
    # Test all arguments are stored correctly
    ie = NRKTVDirekteIE('http://tv.nrk.no/direkte/nrk1')
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TEST == {'url': 'https://tv.nrk.no/direkte/nrk1', 'only_matching': True}
    assert ie._VALID_URL.endswith(r'(?P<id>[^/?#&]+)')


# Generated at 2022-06-24 12:59:56.614062
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlist_id = 'ALOHA-TEST'
    url = 'https://tv.nrk.no/programsubcategory/{}/test-test'
    meta = {'_type': 'subcategories', 'title': 'Test Test'}
    NRKPlaylistBaseIE(NRKIE(), playlist_id, meta, url)



# Generated at 2022-06-24 13:00:07.960037
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Here we use the nrk id as the podkast's id
    ie_class = NRKRadioPodkastIE
    nrk_id = 'nrk_id_for_test'
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert (ie_class._match_id(url) == nrk_id), \
            'extract nrk id in url failed'



# Generated at 2022-06-24 13:00:09.388755
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie is not None


# Generated at 2022-06-24 13:00:21.932426
# Unit test for constructor of class NRKTVSeasonIE

# Generated at 2022-06-24 13:00:25.095534
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('NRKPlaylistBase', 'nrk')
    assert ie._ITEM_RE == r'nrk:([0-9a-zA-Z]{8})'


# Generated at 2022-06-24 13:00:36.130478
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    class TestIE(NRKPlaylistBaseIE):
        _VALID_URL = 'https://tv.nrk.no/serie/foo'
        _ITEM_RE = r'bar'
        def _extract_title(self, _):
            return 'foo'
        def _extract_description(self, _):
            return 'bar'
    ie = TestIE()
    assert ie._TITLE_RE == r'(?s)id="h1-bar">(.*?)</h1'
    assert ie._DESCRIPTION_RE == r'(?s)<div[^>]+\bproperty="schema:description"[^>]+>(.*?)</div'



# Generated at 2022-06-24 13:00:40.741430
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    for url in ("https://tv.nrk.no/serie/lindmo/2018/MUHU11006318/avspiller",
                "https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#",
                "https://radio.nrk.no/serie/dagsnytt/sesong/201507/NPUB21019315"):
        mobj = re.match(ie._VALID_URL, url)
        assert mobj, "The URL '" + url + "' should match the regular expression"
        assert mobj.group("id"), "The URL '" + url + "' should contain an ID"


# Generated at 2022-06-24 13:00:44.738261
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    instance = NRKTVEpisodeIE()

    assert instance._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert instance._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'


# Generated at 2022-06-24 13:00:48.261690
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    assert re.match(NRKTVSeasonIE._VALID_URL, url)



# Generated at 2022-06-24 13:01:01.535252
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    class_obj = NRKTVEpisodeIE
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = 1
    episode_number = 2
    try_match = re.match(class_obj._VALID_URL, url)
    assert try_match.groups() == (display_id, season_number, episode_number)
    extracted_info = class_obj._real_extract(url)
    assert extracted_info.get('id') == 'MUHH36005220'
    assert extracted_info.get('url') == 'nrk:MUHH36005220'

# Generated at 2022-06-24 13:01:04.594437
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
  ie = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')



# Generated at 2022-06-24 13:01:14.418223
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert re.search(ie._VALID_URL, "https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2")
    assert re.search(ie._VALID_URL, "https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015")
    assert re.search(ie._VALID_URL, "https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13")

# Generated at 2022-06-24 13:01:25.736596
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant'

# Generated at 2022-06-24 13:01:35.639703
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from youtube_dl import YoutubeDL
    from youtube_dl.extractor.nrktvdirekte import (
        NRKTVDirekteIE,
        _get_channel,
        _get_channel_avi,
    )
    import json

    ie = NRKTVDirekteIE()
    with YoutubeDL() as ydl:
        r = ydl.extract_info(
            'https://radio.nrk.no/direkte/p1_oslo_akershus',
            download=False,
        )
    assert r['id'] == 'p1_oslo_akershus'

    # Check that _get_channel_avi was called with open(filename).read()

# Generated at 2022-06-24 13:01:48.736421
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    ie = NRKTVSeasonIE(url)
    assert ie.domain == 'tv'
    assert ie.serie_kind == 'serie'
    assert ie.serie == 'backstage'
    assert ie.season_id == '1'
    assert ie.display_id == 'backstage/1'
    assert ie.ASSETS_KEYS == ('episodes', 'instalments',)
    url_ = 'https://radio.nrk.no/serie/dagsnytt/sesong/201509'
    ie_ = NRKTVSeasonIE(url_)
    assert ie_.domain == 'radio'
    assert ie_.serie_kind == 'podkast'

# Generated at 2022-06-24 13:01:58.210524
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    audio_nrk_id = 'P1234'
    audio_url = 'https://radio.nrk.no/direkte/p1_oslo_akershus'
    audio_display_id = re.match(NRKTVDirekteIE._VALID_URL, audio_url).group('id')
    audio_title = 'P1 Oslo og Akershus'

    stream_urls = [
        'https://radio.nrk.no/direkte/p1_oslo_akershus.m3u?t=%d'
        % random.randint(0, 0x7FFFFFFF) for _ in range(2)]
    http_stream_url = 'https://radio.nrk.no/direkte/p1_oslo_akershus.rtsp'
    https

# Generated at 2022-06-24 13:01:59.261623
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert isinstance(NRKRadioPodkastIE(), InfoExtractor)

# Generated at 2022-06-24 13:02:01.271834
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE().suitable(NRKPlaylistIE._VALID_URL)



# Generated at 2022-06-24 13:02:02.159235
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-24 13:02:03.157721
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-24 13:02:10.396416
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """Test creation of class NRKTVSeriesIE"""
    # Test all types of possible URLs

# Generated at 2022-06-24 13:02:13.849464
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Test with a valid URL
    valid_url = "http://www.nrk.no/video/PS*150533"
    nrk = NRKIE()
    nrk.suitable('url', valid_url)
    assert nrk.suitable(valid_url)


# Generated at 2022-06-24 13:02:14.816677
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    from .nrk import NRKRadioPodkastIE
    instance = NRKRadioPodkastIE()

# Generated at 2022-06-24 13:02:20.892875
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'

# Generated at 2022-06-24 13:02:35.023966
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    import os
    import tempfile
    from io import BytesIO
    from pytube import request

    def _request(url, cacheFile):
        if not cacheFile:
            return request.urlopen(url)
        if not os.path.exists(cacheFile):
            cachedir = os.path.dirname(cacheFile)
            if cachedir and not os.path.exists(cachedir):
                os.makedirs(cachedir)
        request.retrieve(url, cacheFile)
        return BytesIO(open(cacheFile, 'rb').read())

    tempdir = tempfile.gettempdir()
    cache_dir = os.path.join(tempdir, 'urllib2_cache')

# Generated at 2022-06-24 13:02:36.619186
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    units = [NRKTVCategoryIE, NRKTVOmCategoryIE, NRKTVProgramIE, NRKTVSearchIE, NRKTVTopicIE]
    for unit in units:
        unit()



# Generated at 2022-06-24 13:02:38.637072
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE()
    except TypeError as e:
        assert 'abstract class' in str(e), (
            'Unexpected type error when instantiating a child class of '
            'NRKPlaylistBaseIE: %s' % str(e))



# Generated at 2022-06-24 13:02:40.069349
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL.count('(') <= 16

# Generated at 2022-06-24 13:02:42.044982
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert isinstance(ie, NRKPlaylistIE)



# Generated at 2022-06-24 13:02:47.916454
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    try:
        NRKSkoleIE('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    except Exception as e: 
        print(e)
        assert False, "Test test_NRKSkoleIE failed"
    else:
        assert True, "Test test_NRKSkoleIE is ok"


# Generated at 2022-06-24 13:02:50.814872
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    test = NRKTVSeasonIE()



# Generated at 2022-06-24 13:02:57.497262
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    ie._match_id('http://tv.nrk.no/serie/borettslaget/(S(xcfzjk55f4xh5w521p4mvj55))/sesong-1/episode-3/avspiller')
    ie._info_extractor_common_info('http://tv.nrk.no/serie/borettslaget/(S(xcfzjk55f4xh5w521p4mvj55))/sesong-1/episode-3/avspiller')

# Generated at 2022-06-24 13:02:58.323568
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert not hasattr(NRKTVIE(), '_real_extract')

# Generated at 2022-06-24 13:03:09.641274
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert video_id(NRKTVSeasonIE.suitable, 'https://tv.nrk.no/serie/backstage/sesong/1') == 'backstage/1'
    assert video_id(NRKTVSeasonIE.suitable, 'https://radio.nrk.no/serie/dagsnytt/sesong/201509') == 'dagsnytt/201509'
    assert video_id(NRKTVSeasonIE.suitable, 'https://tv.nrk.no/serie/lindmo/2016') == 'lindmo/2016'

# Generated at 2022-06-24 13:03:22.908154
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    class_under_test = NRKTVEpisodeIE()
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert class_under_test._match_id('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2') == 'hellums-kro/sesong/1/episode/2'
    url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    info = class_under_

# Generated at 2022-06-24 13:03:27.755264
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert isinstance(ie, NRKTVIE)
    assert ie.ie_key() == 'NRKTV'
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % NRKTVIE._EPISODE_RE



# Generated at 2022-06-24 13:03:31.038875
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    try:
        NRKTVIE(None)
    except Exception as e:
        assert False, "Unexpected exception in loading NRKTVIE class: %s" % e


# Generated at 2022-06-24 13:03:34.285514
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE(None).ie_key() == 'NRK'
    assert NRKIE(None)._VALID_URL == 'nrk:.*'



# Generated at 2022-06-24 13:03:40.451787
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/serie/(?P<id>[^/]+)(?:/(?P<episode_id>[^/]+))?'

# Generated at 2022-06-24 13:03:41.584405
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist = NRKPlaylistIE()


# Generated at 2022-06-24 13:03:43.146964
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # No exception raised
    NRKTVSeasonIE("")


# Generated at 2022-06-24 13:03:52.972129
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie.extract('nrk:150533')
    ie.extract('nrk:clip/150533')
    ie.extract('nrk:d1fda11f-a4ad-437a-a374-0398bc84e999')
    ie.extract('https://www.nrk.no/video/PS*150533')
    ie.extract('https://v8-psapi.nrk.no/mediaelement/ecc1b952-96dc-4a98-81b9-5296dc7a98d9')
    ie.extract('https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533')
    ie.extract('nrk:nrk1')

# Generated at 2022-06-24 13:03:54.008226
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE()



# Generated at 2022-06-24 13:03:56.095430
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Instance of class NRKIE
    cmd_inst = NRKIE()

    # Assert that the command is "nrk".
    assert cmd_inst.IE_NAME == 'nrk'

# Generated at 2022-06-24 13:03:57.044309
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    return NRKRadioPodkastIE()


# Generated at 2022-06-24 13:04:03.412360
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrksuper.no/serie/supernytt'
    expect_title = 'Supernytt'
    playlist = NRKPlaylistBaseIE()._real_extract(url)
    assert playlist['id'] == 'supernytt'
    assert playlist['title'] == expect_title
    assert playlist['title'] == 'Supernytt'


# Generated at 2022-06-24 13:04:05.334105
# Unit test for constructor of class NRKIE
def test_NRKIE():
    for url in itertools.chain(NRKIE._TESTS):
        NRKIE(url)



# Generated at 2022-06-24 13:04:07.002553
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    info_extractor = NRKPlaylistBaseIE()



# Generated at 2022-06-24 13:04:08.594483
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    print("\nTrying to instantiate NRKPlaylistIE class:")
    nrk_playlist = NRKPlaylistIE()
    print("Instantiated: ", nrk_playlist)


# Generated at 2022-06-24 13:04:12.472124
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    foo = NRKSkoleIE(downloader=None, downloader_options={})
    assert foo.IE_NAME == 'nrkskole'
    assert foo.IE_DESC == 'NRK Skole'
    assert foo._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-24 13:04:15.239298
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/dagsrevyen/DKV80104816/11-01-2016'
    ie = NRKPlaylistBaseIE(NRKTVSeasonIE(),url)
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk\.no/(?P<type>serie|pod[ck]ast)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 13:04:16.453458
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()


# Generated at 2022-06-24 13:04:18.087964
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE('NRKTVEpisodes', '1')



# Generated at 2022-06-24 13:04:31.119706
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from . import NRKTVDirekteIE

    input_url = 'https://radio.nrk.no/direkte/p1_oslo_akershus'
    ie = NRKTVDirekteIE(NRKTVDirekteIE._create_ie_instance(), input_url)
    func_name = '_real_extract'

    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'nrk:tv'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert isinstance(ie._TESTS, list)

# Generated at 2022-06-24 13:04:36.133272
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie
    assert ie.url_result('nrk:MDDP12000117') == {
        'url': 'nrk:MDDP12000117',
        'ie_key': 'NRKIE',
        'video_id': 'MDDP12000117',
    }

# Generated at 2022-06-24 13:04:39.919439
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    ie = NRKTVEpisodesIE()
    assert ie.suitable(url)
    assert ie.url_result(url) == 'nrk:69031'


# Generated at 2022-06-24 13:04:52.606182
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """
    Test class NRKPlaylistBaseIE
    """
    import unittest
    import copy
    import re

    from nrk_extractor import NRKPlaylistBaseIE

    class NRKPlaylistBaseIETest(unittest.TestCase):

        def setUp(self):
            self.nb = NRKPlaylistBaseIE()
            self.nb_copy = copy.copy(self.nb)

        def test_instance(self):
            """
            Test instance of class NRKPlaylistBaseIE
            """
            self.assertIsInstance(self.nb, NRKPlaylistBaseIE)

        def test_copy(self):
            """
            Test copy of class NRKPlaylistBaseIE
            """

# Generated at 2022-06-24 13:04:54.842418
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE(NRKBaseIE(), {}, '', '', {})


# Generated at 2022-06-24 13:05:02.716407
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE._GEO_COUNTRIES == ['NO']
    assert NRKBaseIE._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 13:05:05.364883
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/arkiv/nrk1')

# Generated at 2022-06-24 13:05:07.416013
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    a = NRKPlaylistBaseIE
    # check if _ITEM_RE is set
    assert a._ITEM_RE



# Generated at 2022-06-24 13:05:10.725785
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    tests = [NRKTVEpisodeIE._TESTS[0]]
    for t in tests:
        ie = NRKTVEpisodeIE()
        ie.url = t['url']
        ie._real_extract(ie.url)



# Generated at 2022-06-24 13:05:16.419850
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._TESTS[2]['url'] == "https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1"
    assert NRKTVSeasonIE._TESTS[2]['info_dict'] == {'id': 'dickie-dick-dickens/1', 'title': 'Sesong 1'}

# Generated at 2022-06-24 13:05:18.058135
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvseasonIE = NRKTVSeasonIE()
    assert type(nrktvseasonIE) == NRKTVSeasonIE


# Generated at 2022-06-24 13:05:19.856426
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()

# Generated at 2022-06-24 13:05:23.930482
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    serie = NRKTVSerieBaseIE.ie_key()
    assert serie == 'nrktv:serie'
    obj = serie(NRKTVSerieBaseIE)
    assert obj.IE_NAME == serie


# Generated at 2022-06-24 13:05:30.812437
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE("http://tv.nrk.no/program/episodes/nytt-paa-nytt/69031")
    NRKTVEpisodesIE("https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031")
    # invalid url
    with pytest.raises(RegexNotFoundError):
        NRKTVEpisodesIE("https://tv.nrk.no/program/episodes/nytt-paa-nytt/")  # noqa



# Generated at 2022-06-24 13:05:32.161247
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlistBaseIE = NRKPlaylistBaseIE()
    assert playlistBaseIE is not None


# Generated at 2022-06-24 13:05:33.149797
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert isinstance(NRKTVEpisodeIE(), InfoExtractor)



# Generated at 2022-06-24 13:05:34.245978
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert isinstance(ie, NRKTVEpisodeIE)


# Generated at 2022-06-24 13:05:40.247387
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """Test the constructor of class NRKPlaylistBaseIE."""
    # Test an empty constructor
    try:
        NRKPlaylistBaseIE()
        print("Constructor of class NRKPlaylistBaseIE works.")
    except:
        print("Constructor of class NRKPlaylistBaseIE doesn't works!")
        print("Possible problem: Load some modules not exactly.")

# Generated at 2022-06-24 13:05:49.612766
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE();
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._EPISODE_RE == '(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._VALID_URL == 'https?://(?:tv|radio)\\.nrk(?:super)?\\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert len(ie._TESTS) == 11
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/program/MDDP12000117'

# Generated at 2022-06-24 13:05:57.281853
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    kwargs = {}
    nrktvie = NRKTVIE(kwargs)
    assert nrktvie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert nrktvie.IE_NAME == 'NRK'

# Generated at 2022-06-24 13:05:59.950833
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('NRKPlaylistIE', 'www.nrk.no', {'id': 'mega-playlist'})



# Generated at 2022-06-24 13:06:06.593359
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    u = 'https://tv.nrk.no/programoversikt'
    vid_id = 'UVVVVV20000101'
    webpage = '''<html>
    <div id="%s" class="nrk-video nrk-video-mini" data-videoid="%s">
    ''' % (vid_id, vid_id)
    result = NRKPlaylistBaseIE()._real_extract(u)
    assert result['_type'] == 'playlist'



# Generated at 2022-06-24 13:06:10.060217
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == NRKTVIE._VALID_URL
    assert ie.IE_NAME == NRKTVIE.ie_key()
    assert ie.IE_DESC == NRKTVIE.IE_DESC
    assert ie.supported_extensions() == ['mp4']

# Generated at 2022-06-24 13:06:13.659692
# Unit test for constructor of class NRKIE
def test_NRKIE():
    info_extractor = NRKIE()
    assert info_extractor._VALID_URL == InfoExtractor._VALID_URL_TEMPL % info_extractor._TEMPLATE_URL

# Generated at 2022-06-24 13:06:17.543792
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # This test will not be executed by pytest, but we need it to test that
    # the constructor of NRKPlaylistBaseIE is properly implemented.
    NRKPlaylistBaseIE(None, None)



# Generated at 2022-06-24 13:06:22.029203
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    id_a = 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    id_b = 'l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    url_a = 'https://radio.nrk.no/podkast/hele_historien/sesong/1/' + id_a
    url_b = 'https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/' + id_b
    regex = NRKRadioPodkastIE._VALID_URL

    match_a = regex.match(url_a)

# Generated at 2022-06-24 13:06:26.321751
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist = NRKPlaylistUrl("NRKPlaylistIE", "NRKPlaylistIE._TITLE", NRKPlaylistIE._VALID_URL, "NRKPlaylistIE._TITLE_RE")
    assert playlist.ie_key() == "NRKPlaylistIE"
    assert playlist._TITLE == "NRKPlaylistIE._TITLE"
    assert playlist._VALID_URL == "NRKPlaylistIE._VALID_URL"
    assert playlist._TITLE_RE == "NRKPlaylistIE._TITLE_RE"



# Generated at 2022-06-24 13:06:30.177050
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    Test = NRKTVIE.__bases__[0]
    Test._real_extract = lambda self, url: None
    Test._TESTS = []
    Test.test_urls(Test(), 'http://tv.nrk.no/program/mdfp15000514', 'MSPO40010414')
    Test.test_urls(Test(), 'http://tv.nrk.no/program/MDDP12000117', 'MDDP12000117')



# Generated at 2022-06-24 13:06:38.394452
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE(
        compat_urllib_request.Request(
            'https://tv.nrk.no/serie/groenn-glede',
            headers={'Accept-Language': 'nb-no,nb;q=0.8,no;q=0.6,nn;q=0.4,en-us;q=0.2,en;q=0.2'}),
        {'page': 'page', 'page_url': 'page_url'})
    assert ie.page == 'page'
    assert ie.page_url == 'page_url'

# Generated at 2022-06-24 13:06:48.408893
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    import re
    PRE_URL = 'https://radio.nrk.no/direkte/'
    PRE_URL2 = 'https://tv.nrk.no/direkte/'
    URL_NRK = PRE_URL + 'p1_oslo_akershus'
    URL_NRK2 = PRE_URL2 + 'nrk1'
    TV_ID = 'p1_oslo_akershus'
    TV_ID2 = 'nrk1'
    direkte_nrk_regex = r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 13:06:51.194159
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    a = NRKBaseIE(NRKBaseIE.ie_key())
    assert repr(a) == '<NRKBaseIE>'
    assert NRKBaseIE.ie_key() == 'nrk'

# Generated at 2022-06-24 13:06:54.532788
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    id_ = 'nrk1'
    NRKTVDirekteIE(NRKTVDirekteIE.ie_key(), id_, 'id', 'id', 'id')
    assert NRKTVDirekteIE.suitable(
        'https://tv.nrk.no/direkte/' + id_), "Responsible regexp should match a URL pointing to a channel page."



# Generated at 2022-06-24 13:06:58.054528
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'



# Generated at 2022-06-24 13:07:09.618845
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_ie = NRKTVEpisodesIE()

    assert nrktv_episodes_ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert nrktv_episodes_ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 13:07:10.793780
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test_obj = NRKPlaylistBaseIE()
    test_obj._extract_description('test string')



# Generated at 2022-06-24 13:07:13.762217
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE()._VALID_URL == r'''(?x)
                                             https?://(?:tv|radio)\.nrk\.no/
                                             (?:serie/[^/]+/sesong/\d+|category/\d+/program)
                                             '''



# Generated at 2022-06-24 13:07:19.607878
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Check initializer, __dict__ is used because __init__ is private and not accessible
    assert NRKTVEpisodeIE.__dict__['_VALID_URL'] is NRKTVEpisodeIE._VALID_URL
    assert NRKTVEpisodeIE.__dict__['_TESTS'] is NRKTVEpisodeIE._TESTS
    assert NRKTVEpisodeIE.__dict__['_downloader'] is not None


# Generated at 2022-06-24 13:07:21.574000
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvSeason_ie = NRKTVSeasonIE()
    assert isinstance(nrktvSeason_ie, NRKTVSeasonIE)



# Generated at 2022-06-24 13:07:25.121953
# Unit test for constructor of class NRKIE
def test_NRKIE():
    import requests
    from .common import InfoExtractor
    from .nrk import NRKIE
    assert isinstance(NRKIE(), InfoExtractor)
    assert isinstance(NRKIE()._request_webpage, requests.Session)

# Generated at 2022-06-24 13:07:36.814831
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrk_test_url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    nrk_test_display_id = 'hellums-kro/sesong/1/episode/2'
    nrk_test_season_number = 1
    nrk_test_episode_number = 2

# Generated at 2022-06-24 13:07:38.193590
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVIE(NRKTVDirekteIE.ie_key())


# Generated at 2022-06-24 13:07:40.294380
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://nrksuper.no/serie/labyrint'
    ie = NRKTVSeriesIE(url)
    assert ie.suitable(url) == False

# Generated at 2022-06-24 13:07:46.211562
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    _NRKRadioPodkastIE = NRKRadioPodkastIE()
    assert _NRKRadioPodkastIE._VALID_URL == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert 'NRKRadioPodkastIE' == _NRKRadioPodkastIE.ie_key()


# Generated at 2022-06-24 13:07:50.248488
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('https://nrk.no/ut/noen-lenke-med-klassen-rich/bla.html','bla')



# Generated at 2022-06-24 13:07:56.326519
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    for url in ['https://tv.nrk.no/direkte/nrk1', 'https://radio.nrk.no/direkte/p1_oslo_akershus']:
        nrktv_direkte_ie = NRKTVDirekteIE()._real_extract(url)
        assert nrktv_direkte_ie



# Generated at 2022-06-24 13:08:02.390781
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test_NRKTVEpisodesIE = NRKTVEpisodesIE()
    print(test_NRKTVEpisodesIE.suitable("https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031"))
    print(test_NRKTVEpisodesIE.suitable("https://tv.nrk.no/serie/nytt-paa-nytt"))
    print(test_NRKTVEpisodesIE.suitable("https://tv.nrk.no/program/episodes/nytt-paa-nytt"))
