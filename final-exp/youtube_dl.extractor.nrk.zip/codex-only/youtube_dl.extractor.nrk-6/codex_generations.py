

# Generated at 2022-06-24 12:58:02.691582
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    print("Test NRKBaseIE")
    instance = NRKBaseIE(None)
    print("instance: \n%s" % instance)
    
if __name__ == '__main__':
    test_NRKBaseIE()

# Generated at 2022-06-24 12:58:12.787601
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') == True
    assert NRKPlaylistIE.suitable('https://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449') == True
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') == True
    assert NRKPlaylistIE.suitable('https://www.nrk.no/skole') == False

# Generated at 2022-06-24 12:58:18.761402
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE.suitable('http://www.nrk.no/programmer/')
    assert not ie

    ie = NRKTVSeriesIE.suitable('http://www.nrk.no/video/')
    assert not ie

    ie = NRKTVSeriesIE.suitable('http://www.nrk.no/video/1')
    assert not ie

    ie = NRKTVSeriesIE.suitable('http://www.nrk.no/video/MUHH37004614')
    assert not ie

    ie = NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/kringkastingsorkestret-korps/sesong/1/episode/1')
    assert not ie


# Generated at 2022-06-24 12:58:19.549159
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    inst = NRKPlaylistBaseIE()


# Generated at 2022-06-24 12:58:24.957386
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    youtube_dl_instance = YoutubeDL(default_options)
    result = NRKRadioPodkastIE()._real_extract(youtube_dl_instance, url)

# Generated at 2022-06-24 12:58:32.359591
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    test = NRKTVIE('nrk:program/MDDP12000117')
    assert test.video_id is not None
    assert test.extractor.ie_key() != 'NRKTV'
    assert test.NRKTVIE is False
    test = NRKTVIE('nrk:MDDP12000117')
    assert test.video_id is not None
    assert test.extractor.ie_key() != 'NRKTV'
    assert test.NRKTVIE is False



# Generated at 2022-06-24 12:58:38.966296
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():

    _entry_id = 'p1_oslo_akershus' # Replace with a valid entry id
    _media_id = 'b-7411406' # Replace with a valid media id

    # Validate constructor
    try:
        NRKTVDirekteIE(_entry_id, _media_id)
    except Exception as e:
        assert False, 'init constructor: %s\n' % str(e)

    # Validate from_url

# Generated at 2022-06-24 12:58:46.301388
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    if __name__ == "__main__":
        k = NRKBaseIE()
        test_str1 = r'http://nrkod04-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/no/mp4:2001738/Www/nrkno/2018/05/18/norges-tykkeste/106835_5ae6dddb-d0b0-44bc-aabd-46d5e638a65a_323427.mp4/master.m3u8'

# Generated at 2022-06-24 12:58:49.065357
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    info_extractor = NRKSkoleIE()
    assert info_extractor.IE_DESC == "NRK Skole"
    assert info_extractor.IE_NAME == "nrk"


# Generated at 2022-06-24 12:58:53.212499
# Unit test for constructor of class NRKIE
def test_NRKIE():
    from .. import NRKIE as nrk_class
    nrk_obj = nrk_class()
    assert nrk_obj.IE_NAME == "nrk"
    assert nrk_obj.IE_DESC == "NRK"
    assert nrk_obj._VALID_URL == nrk_class._VALID_URL
    assert nrk_obj._TESTS == nrk_class._TESTS

# Generated at 2022-06-24 12:58:57.144272
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        NRKBaseIE(None, None)
        assert False # Should be unreachable
    except NotImplementedError as e:
        assert str(e) == '%s is an abstract class' % (NRKBaseIE)


# Generated at 2022-06-24 12:58:58.061548
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist = NRKPlaylistIE()
    assert 'NRKPlaylistBaseIE' in str(playlist)


# Generated at 2022-06-24 12:59:08.937008
# Unit test for constructor of class NRKIE
def test_NRKIE():
    from .test_main import mock_content

    url = 'http://www.nrk.no/video/PS*150533'
    content = mock_content(url)
    nrk = NRKIE()
    nrk.extract(url)
    url = 'https://v8-psapi.nrk.no/mediaelement/ecc1b952-96dc-4a98-81b9-5296dc7a98d9'
    content = mock_content(url)
    nrk2 = NRKIE()
    nrk2.extract(url)
    url = 'nrk:clip/150533'
    content = mock_content(url)
    nrk3 = NRKIE()
    nrk3.extract(url)


# Generated at 2022-06-24 12:59:13.077404
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    field_names = {'_VALID_URL', 'suitable'}
    # Check that each field is a class variable
    for field in field_names:
        assert field in dir(NRKTVSeasonIE)


# Generated at 2022-06-24 12:59:17.465609
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_radio_podkast_ie = NRKRadioPodkastIE()

    # We don't really have anything to test, but just calling the
    # constructor to make sure no exceptions are raised.
    ok = nrk_radio_podkast_ie


# Generated at 2022-06-24 12:59:18.788254
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE is not None


# Generated at 2022-06-24 12:59:27.975921
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE("www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763")
    NRKPlaylistIE("http://nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763")
    NRKPlaylistIE("http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763")
    NRKPlaylistIE("http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449")



# Generated at 2022-06-24 12:59:31.056361
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE('NRKTVEpisodesIE', 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')

# Generated at 2022-06-24 12:59:31.795959
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE is not None

# Generated at 2022-06-24 12:59:34.381346
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE(InfoExtractor()) is not None

# Generated at 2022-06-24 12:59:41.249561
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == (
    r'(?x)://\n        (?:n'
    'rkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-ca'
    'cheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrk'
    'hd-osl-rr\.netwerk\.no/no\n        )/')
    assert ie._call_api
    assert ie._raise_error


# Generated at 2022-06-24 12:59:49.315917
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from ..compat import unittest
    from ..utils import unified_timestamp

    def _test_parse_duration(s, r):
        if not r:
            assert parse_duration(s) is None
        else:
            assert parse_duration(s) == r

    class TestNRKBaseIE(unittest.TestCase):
        def test_parse_duration(self):
            _test_parse_duration('01:02:03.456', 3723.456)
            _test_parse_duration('01:02:03', 3723)
            _test_parse_duration('01:02', 62)
            _test_parse_duration('02', 2)
            _test_parse_duration('00:00:05.5', 5.5)

# Generated at 2022-06-24 13:00:02.094128
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Create an object of class NRKRadioPodkastIE
    podkast_ie = NRKRadioPodkastIE()
    # Check
    assert podkast_ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-24 13:00:03.678459
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    obj = NRKRadioPodkastIE()
    assert obj

# Generated at 2022-06-24 13:00:08.612420
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    import time
    start_time = time.time()
    ie = NRKTVSeriesIE()
    for test in ie._TESTS:
        result = ie.suitable(test['url'])
        print(test['url'], result)
    print('Time: %.2f s' % (time.time() - start_time))

# Generated at 2022-06-24 13:00:11.242414
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant'
    ie = NRKTVSeasonIE(None)
    if ie.suitable(url):
        test = ie.suitable(url)
        assert test == None
        assert ie.get_info_extractor(url) == 'NRKTVSeasonIE'



# Generated at 2022-06-24 13:00:14.545988
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    NRKBaseIE(InfoExtractor('nrkbaseie', 'nrk.no'))._GEO_COUNTRIES
# assert test_NRKBaseIE() == ['NO']



# Generated at 2022-06-24 13:00:15.558230
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 13:00:18.642292
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Instantiate the class
    parser1 = NRKPlaylistIE()
    # call the member function with known inputs
    class_type = parser1.suitable("http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763")
    # Compare the known result with possible value
    assert class_type is True, "test_NRKPlaylistIE"

# Generated at 2022-06-24 13:00:31.047177
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant'
    N = NRKTVSeasonIE(url);
    assert isinstance(N, NRKTVSeasonIE), "Object is of wrong type!"

# Generated at 2022-06-24 13:00:32.109329
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    t = NRKTVSeasonIE()



# Generated at 2022-06-24 13:00:42.002200
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    for url in NRKTVIE._TESTS:
        extractor = NRKTVIE(NRKTVIE.IE_NAME, url)
        assert extractor.report_warning is not None
        assert extractor._match_id(url) is not None
        assert extractor.url_result(url) is not None
        assert extractor.extract_id(url) is not None
        assert extractor.suitable(url) is not None
    url_test = 'https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533'
    extractor = NRKTVIE(NRKTVIE.IE_NAME, url_test)
    assert extractor.suitable(url_test) is True

# Generated at 2022-06-24 13:00:42.606213
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE()



# Generated at 2022-06-24 13:00:47.644079
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist = NRKPlaylistIE()
    for ie in [NRKTVIE, NRKTVEpisodeIE, NRKRadioPodkastIE, NRKTVSeasonIE, NRKTVSeriesIE, NRKTVDirekteIE]:
        assert ie.suitable(playlist) == False


# Generated at 2022-06-24 13:01:00.797847
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('NRKTVDirekteIE', 'nrk1', 'https://tv.nrk.no/direkte/%s', 'NRK1')
    NRKTVDirekteIE('NRKTVDirekteIE', 'nrk2', 'https://tv.nrk.no/direkte/%s', 'NRK2')
    NRKTVDirekteIE('NRKTVDirekteIE', 'nrk3', 'https://tv.nrk.no/direkte/%s', 'NRK3')
    NRKTVDirekteIE('NRKTVDirekteIE', 'nrk_super', 'https://tv.nrk.no/direkte/%s', 'NRK Super')
    NRKTVDire

# Generated at 2022-06-24 13:01:01.998958
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE(NRKTVDirekteIE.ie_key(), 'NRK TV Direkte and NRK Radio Direkte')


# Generated at 2022-06-24 13:01:12.679217
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    entries = NRKTVSerieBaseIE._extract_entries(e for e in ({'episodeId': 'test1'}, {'prfId': 'test2'}))
    assert entries == [{
        '_type': 'url',
        'id': 'test1',
        'url': 'nrk:test1',
        'ie_key': 'NRK',
    },{
        '_type': 'url',
        'id': 'test2',
        'url': 'nrk:test2',
        'ie_key': 'NRK',
    }]

    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog

# Generated at 2022-06-24 13:01:14.557632
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    instance = NRKBaseIE()
    assert 'NRKBaseIE' in instance.IE_NAME


# Generated at 2022-06-24 13:01:23.201912
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', {})
    assert ie._GEO_COUNTRIES is ['NO']
    assert ie._CDN_REPL_REGEX is r'(?x)://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'



# Generated at 2022-06-24 13:01:24.652364
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE('NRKTVSeasonIE', 'NRK TV season', 'nrk.no')


# Generated at 2022-06-24 13:01:27.544325
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE_instance=NRKIE()
    assert(isinstance(NRKIE_instance,NRKIE))
    return True

test_NRKIE()

test_NRKIE()

test_NRKIE()

test_NRKIE()

# Generated at 2022-06-24 13:01:31.878307
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test = NRKPlaylistIE()
    assert test._real_extract('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')



# Generated at 2022-06-24 13:01:38.529269
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Call constructor of NRKTVSeasonIE
    tv_season_ie = NRKTVSeasonIE()

    # Test if URL is suitable for NRKRadioPodkastIE
    suitable_url = tv_season_ie.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    # Assert that result is False
    assert suitable_url == False


# Generated at 2022-06-24 13:01:39.738425
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()

# Generated at 2022-06-24 13:01:41.567612
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()


# Generated at 2022-06-24 13:01:42.736088
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    test_NRKTVIE()

# Generated at 2022-06-24 13:01:52.900638
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    info_dict = ie._extract_entries(None)
    assert len(info_dict) == 0
    info_dict = ie._extract_entries([])
    assert len(info_dict) == 0
    info_dict = ie._extract_entries("")
    assert len(info_dict) == 0
    info_dict = ie._extract_entries(0)
    assert len(info_dict) == 0
    info_dict = ie._extract_entries({})
    assert len(info_dict) == 0
    info_dict = ie._extract_entries({"episode": {}})
    assert len(info_dict) == 0
    info_dict = ie._extract_entries({"episode": {"episodeId": ""}})


# Generated at 2022-06-24 13:01:56.846810
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrk_test = NRKTVEpisodeIE()
    assert nrk_test._VALID_URL
    assert nrk_test._TESTS



# Generated at 2022-06-24 13:01:59.367377
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRK', 'NO')
    assert ie._GEO_COUNTRIES == ['NO']


# Generated at 2022-06-24 13:02:07.032340
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    self = copy.copy(NRKTVSerieBaseIE)
    self._extract_entries = lambda entry_list: entry_list
    self._extract_assets_key = lambda embedded: embedded.get('asset_key')

    list_ = [
        {'prfId': 'MDDP12000117', 'asset_key': 'episodes'},
        {'prfId': 'MDDP12000118', 'asset_key': 'episodes'},
        {'asset_key': 'instalments'},
    ]

    assert len(list(self._entries({'_embedded': {'episodes': {'_embedded': {'episodes': list_}}}}, 'test'))) == 2

# Generated at 2022-06-24 13:02:13.261239
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE()._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-24 13:02:15.337190
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Test the constructor of NRKTVIE
    assert NRKTVIE(nrk_ie).name == nrk_ie.name

# Generated at 2022-06-24 13:02:21.626364
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """ Test NRKTVIE.__init__ """
    object = NRKTVIE('NRKTVIE')
    assert object.ie_key() == 'NRKTV'
    assert object.server == 'hls-v8-psapi.nrk.no'
    assert object.api_base == 'https://v8-psapi.nrk.no/'

# Generated at 2022-06-24 13:02:35.255414
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no') == False
    assert NRKPlaylistIE.suitable('http://www.nrk.no/skole') == False
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms') == True
    assert NRKPlaylistIE.suitable('http://www.nrk.no/video') == False
    assert NRKPlaylistIE.suitable('http://tv.nrk.no/serie/lindmo/sesong/1') == False
    assert NRKPlaylistIE.suitable('http://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant') == False



# Generated at 2022-06-24 13:02:46.229009
# Unit test for constructor of class NRKIE
def test_NRKIE():
    media_id = 'cliptest'
    nrk = NRKIE(None)

    # Test valid url parsing
    url = 'https://www.nrk.no/video/%s' % media_id
    assert media_id == nrk._match_id(url) is not None

    url = 'http://www.nrk.no/video/%s' % media_id
    assert media_id == nrk._match_id(url) is not None

    url = 'http://nrk.no/video/%s' % media_id
    assert media_id == nrk._match_id(url) is not None

    # Test invalid url parsing
    url = 'https://www.nrk.no/'
    assert nrk._match_id(url) is None


# Generated at 2022-06-24 13:02:52.560190
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    info_dict = {
        'id': 'backstage/1',
        'title': 'Sesong 1',
    }

    nrktv_season_ie = NRKTVSeasonIE(NRKTVSeasonIE._downloader, url)
    assert(nrktv_season_ie._match_id(url) == info_dict['id'])
    assert(nrktv_season_ie._real_extract(url).get('id') == info_dict['id'])
    assert(nrktv_season_ie._real_extract(url).get('title') == info_dict['title'])


# Generated at 2022-06-24 13:02:53.889755
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    playlist = NRKTVEpisodesIE()


# Generated at 2022-06-24 13:02:58.339665
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    self = NRKRadioPodkastIE()
    self._match_id(
        'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    self._match_id(
        'https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-24 13:02:59.384386
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()


# Generated at 2022-06-24 13:03:07.115552
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    """Test if constructor of class NRKBaseIE works as expected."""
    media = NRKBaseIE()
    # This is a static test, so we don't need to use real values here.
    assert media._GEO_COUNTRIES == ['NO']
    assert re.match(media._CDN_REPL_REGEX, '//nrkod1-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/')


# Generated at 2022-06-24 13:03:12.578686
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\n            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|\n            nrk-od-no\.telenorcdn\.net|\n            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n        /'

# Generated at 2022-06-24 13:03:15.060044
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    obj = NRKBaseIE({})
    assert type(obj) == NRKBaseIE


# Generated at 2022-06-24 13:03:15.948322
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Should not raise any exception
    NRKPlaylistIE('12345')



# Generated at 2022-06-24 13:03:16.892346
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    test_constructor(NRKSkoleIE(NRKIE()))

# Generated at 2022-06-24 13:03:18.009375
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE(NRKTVIE(), 'url', 'NRKTVIE', 'IE_NAME')

# Generated at 2022-06-24 13:03:19.728437
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE(1)
    assert ie.__class__.__name__ == 'NRKTVEpisodesIE'



# Generated at 2022-06-24 13:03:23.941131
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_instance = NRKPlaylistIE()
    assert test_instance._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert test_instance._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'


# Generated at 2022-06-24 13:03:29.078404
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id, season_number, episode_number = re.match(NRKTVEpisodeIE._VALID_URL, url).groups()
    assert display_id == 'hellums-kro/sesong/1/episode/2'
    assert season_number == '1'
    assert episode_number == '2'

# Generated at 2022-06-24 13:03:33.472612
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    url = 'http://tv.nrk.no/serie/kroppen-min/sesong/1/episode/1'
    assert ie.suitable(url)
    assert ie.ie_key() == 'NRKTVSeries'
    assert ie.constructor == NRKTVSeriesIE
    assert NRKTVSeriesIE.constructor == NRKTVSeriesIE


# Generated at 2022-06-24 13:03:44.309641
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'nrk:episodes'
    assert ie.IE_DESC == NRKTVEpisodesIE.IE_DESC
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 13:03:46.928428
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE.suitable({"url": "https://tv.nrk.no/serie/backstage/sesong/1",
                            "ie_key": "NRKTVSeasonIE"})


# Generated at 2022-06-24 13:03:55.130165
# Unit test for constructor of class NRKIE
def test_NRKIE():
    def num_of_tests(tests_to_run, verbose=False):
        print("\nTesting %s..." % ie.IE_NAME)
        if verbose:
            print(tests_to_run)
        success = 0
        for t in tests_to_run:
            if t['only_matching']:
                m = re.search(nrk_regex, t['url'])
                if m is not None:
                    success += 1
                    continue
            else:
                info_dict = ie.extract(t['url'])
                if len(info_dict['id']) > 0:
                    success += 1
        print("%s/%s tests succeeded.\n" % (success, len(tests_to_run)))


# Generated at 2022-06-24 13:03:59.451802
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.ie_key() == 'NRK', ie.ie_key()
    assert ie.extractor_key() == 'NRKIE', ie.extractor_key()


# Generated at 2022-06-24 13:04:06.572422
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    """ Test the constructor of class NRKSkoleIE """
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie.ie_key() == 'NRKSkole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    # assert ie._TESTS == [{
    #     'url': 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099',
    #     'md5': '18c12c3d071953c3bf8d54ef6b2587b7',
    #     'info_dict': {
    #         'id': '6021',

# Generated at 2022-06-24 13:04:08.870698
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
	assert NRKTVIE('https://tv.nrk.no/program/MDDP12000117') is not None


# Generated at 2022-06-24 13:04:12.472021
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    try:
        NRKRadioPodkastIE('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    except Exception:
        assert False, 'Constructor of class NRKRadioPodkastIE failed'


# Generated at 2022-06-24 13:04:15.311629
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX
    ids = ['1', '2', '3']
    for i in ids:
        assert ie._extract_nrk_formats('http://' + i, 1)

# Generated at 2022-06-24 13:04:18.799848
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    try:
        NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    except AssertionError:
        pass



# Generated at 2022-06-24 13:04:29.845602
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Prepare test string
    url = u'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    expected = u'69031'
    # Get instance of class
    nrktvepisodesie = NRKTVEpisodesIE()
    # Extract NRKTVEpisodesIE ID from URL
    test = nrktvepisodesie._match_id(url)
    # Validate test
    if (expected != test):
        raise ValueError(u'Expected ID {0}, found {1} for URL {2}'.format(expected, test, url))
    # Return test
    return test


# Generated at 2022-06-24 13:04:31.014928
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()



# Generated at 2022-06-24 13:04:40.482563
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL == NRKTVSeasonIE._TESTS[0]['url']
    assert NRKTVSeasonIE._VALID_URL == NRKTVSeasonIE._TESTS[1]['url']
    assert NRKTVSeasonIE._VALID_URL == NRKTVSeasonIE._TESTS[2]['url']
    assert NRKTVSeasonIE._VALID_URL == NRKTVSeasonIE._TESTS[3]['url']
    assert NRKTVSeasonIE._VALID_URL == NRKTVSeasonIE._TESTS[4]['url']
    assert NRKTVSeasonIE._VALID_URL == NRKTVSeasonIE._TESTS[5]['url']


# Generated at 2022-06-24 13:04:47.741169
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    BASE_IE = NRKTVSerieBaseIE()
    BASE_IE_CATALOG_NAME = BASE_IE._catalog_name('serie')
    assert BASE_IE_CATALOG_NAME == 'series'
    BASE_IE_CATALOG_NAME_POD = BASE_IE._catalog_name('podcast')
    assert BASE_IE_CATALOG_NAME_POD == 'podcast'



# Generated at 2022-06-24 13:04:48.512789
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE(None, None)



# Generated at 2022-06-24 13:04:59.813448
# Unit test for constructor of class NRKIE

# Generated at 2022-06-24 13:05:00.586828
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    return NRKTVDirekteIE()

# Generated at 2022-06-24 13:05:01.225048
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    a = NRKTVEpisodeIE()


# Generated at 2022-06-24 13:05:02.834084
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    clean_filename = 'test_file'
    assert NRKTVDirekteIE('test_url', clean_filename)


# Generated at 2022-06-24 13:05:05.182603
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    nrk.IE_NAME = "nrk"
    nrk.IE_DESC = "NRK"
    return nrk


# Generated at 2022-06-24 13:05:11.682700
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert hasattr(NRKPlaylistBaseIE, 'suitable')
    assert hasattr(NRKPlaylistBaseIE, '_ENTRY_CLASS')
    assert hasattr(NRKPlaylistBaseIE, '_ITEM_RE')
    assert hasattr(NRKPlaylistBaseIE, '_TESTS')
    assert hasattr(NRKPlaylistBaseIE, '_ANNOTATIONS_RES')
    assert hasattr(NRKPlaylistBaseIE, '_EXTRACTOR')



# Generated at 2022-06-24 13:05:14.694865
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE_class = NRKTVIE("NRKTVIE", "nrktv")
    assert isinstance(NRKTVIE_class, NRKTVIE)



# Generated at 2022-06-24 13:05:21.865874
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    #Instantiates an object of the class
    testObj = NRKTVEpisodesIE()

    #Testing if the RUL given is valid
    if testObj._VALID_URL == testObj._VALID_URL:
        print("Test: test_NRKTVEpisodesIE [OK]")
    else:
        print("Test: test_NRKTVEpisodesIE [FAIL]")



# Generated at 2022-06-24 13:05:24.976279
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('serie') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('program') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'



# Generated at 2022-06-24 13:05:27.342301
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')

# Generated at 2022-06-24 13:05:28.411504
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE(NRKBaseIE())

# Generated at 2022-06-24 13:05:30.474533
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    inst = NRKTVSeasonIE()
    assert inst.suitable(NRKTVSeasonIE._VALID_URL)



# Generated at 2022-06-24 13:05:42.887217
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE(None)
    assert ie.IE_NAME == 'nrk'
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-24 13:05:44.381316
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE(NRKTVEpisodeIE.ie_key())._VALID_URL == NRKTVEpisodeIE._VALID_URL


# Generated at 2022-06-24 13:05:56.290828
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    args = [
        'https://tv.nrk.no/serie/backstage',
        'https://tv.nrk.no/serie/lindmo',
        'https://tv.nrk.no/serie/blank',
        'https://tv.nrksuper.no/serie/labyrint',
        'https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene',
        'https://tv.nrk.no/serie/saving-the-human-race',
        'https://radio.nrk.no/podkast/ulrikkes_univers'
    ]
    for arg in args:
        print("Testing for " + arg)
        ie = NRKTVSeriesIE(arg)
        assert ie.suitable(arg)
        assert ie

# Generated at 2022-06-24 13:05:59.122625
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        NRKBaseIE()
    except:
        assert False, 'NRKBaseIE failed'


# Generated at 2022-06-24 13:06:03.121674
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    assert NRKSkoleIE.suitable(url) == True
    download_test(url)


# Generated at 2022-06-24 13:06:07.711676
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    from youtube_dl.utils import QualTuple
    qual_tuple = QualTuple('video', 'vp9', '1080p', 32000000)
    item = NRKTVSerieBaseIE._get_quality_item(qual_tuple)
    assert item.get('format_id') == 'vp9-1080p'
    assert item.get('width') == 1080


# Generated at 2022-06-24 13:06:10.618741
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrkplaylistbaseIE = NRKPlaylistBaseIE('NRKPlaylistBaseIE')
    assertTrue(nrkplaylistbaseIE._VALID_URL)
    assertTrue(nrkplaylistbaseIE._ITEM_RE)
    assertTrue(nrkplaylistbaseIE._TITLE_RE)



# Generated at 2022-06-24 13:06:22.826759
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    with pytest.raises(TypeError):
        # The url is an episode url
        NRKTVSeriesIE('nrk:VUFOST15001116', {'ext': 'mp4'})
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede/sesong/1')
    assert not NRKTVSeriesIE.suitable(
        'https://tv.nrk.no/serie/groenn-glede/sesong/1/episode/1')
    assert not NRKTVSeriesIE.suitable('https://tv.nrk.no/program/UQFOST15001116')
    assert not NRKTV

# Generated at 2022-06-24 13:06:27.139357
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Unit test for the constructor of class NRKTVSerieBaseIE.
    assert issubclass(NRKTVSerieBaseIE, NRKBaseIE)
    assert issubclass(NRKTVSerieBaseIE, InfoExtractor)
    nrktv_serie_base_ie = NRKTVSerieBaseIE()
    assert isinstance(nrktv_serie_base_ie, NRKTVSerieBaseIE)
    assert isinstance(nrktv_serie_base_ie, NRKBaseIE)
    assert isinstance(nrktv_serie_base_ie, InfoExtractor)

# End unit tests for constructor of class NRKTVSerieBaseIE


# Generated at 2022-06-24 13:06:29.331222
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktv_ie = NRKTVIE()
    nrktv_ie.ie_key()
    nrktv_ie.suitable(None)
    nrktv_ie.can_extract(None)



# Generated at 2022-06-24 13:06:31.073290
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE('nrk:MDDP12000117')
    assert isinstance(ie, NRKTVEpisodeIE)
    assert ie.video_id == 'MDDP12000117'


# Generated at 2022-06-24 13:06:35.666308
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    instance = NRKTVEpisodeIE()
    assert instance._VALID_URL == 'https?://tv\.nrk\.no/serie/([^/]+/sesong/(\\d+)/episode/(\\d+))'
    assert instance._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert instance._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert instance._TESTS[1]['url'] == 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'


# Generated at 2022-06-24 13:06:41.838748
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE.suitable('http://www.nrk.tv')
    # http://radio.nrk.no/serie/dagsnytt exists, will be considered as NRKTVSeasonIE
    NRKTVSeasonIE.suitable('http://radio.nrk.no/serie/dagsnytt')


# Generated at 2022-06-24 13:06:43.391702
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    print(NRKTVEpisodesIE(None, 'NRKTVEpisodesIE', 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'))
    pass



# Generated at 2022-06-24 13:06:45.857079
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_url = 'https://www.nrk.no/norge/is-i-musene-1.13432868'
    ie = NRKPlaylistIE(NRKPlaylistIE._create_get_info_extractor(test_url))
    assert ie.playlist_id == 'is-i-musene-1.13432868'



# Generated at 2022-06-24 13:06:49.852458
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert_info_dict_equal(
        NRKTVSeasonIE()._real_extract(
            'https://tv.nrk.no/serie/backstage/sesong/1'),
        NRKTVSeasonIE()._real_extract(
            'https://tv.nrk.no/serie/backstage/1'),
    )



# Generated at 2022-06-24 13:06:51.074782
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('NRKTVDirekte')

# Generated at 2022-06-24 13:06:51.903048
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()


# Generated at 2022-06-24 13:06:55.971133
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_NRKTVEpisodeIE = NRKTVEpisodeIE()
    NRKTVEpisode_obj = NRKTVEpisodeIE._real_extract(test_NRKTVEpisodeIE, 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert NRKTVEpisode_obj["id"] == 'MUHH36005220'

# Generated at 2022-06-24 13:07:07.327938
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    entries = itertools.islice(NRKTVSerieBaseIE()._entries({
        '_embedded': {
            'instalments': [{
                'prfId': 'MDDP12000117',
            }, {
                'episodeId': 'MSPO40010515',
            }],
        },
    }, 'MDDP12000117'), 2)
    assert next(entries) == {
        '_type': 'url',
        'id': 'MDDP12000117',
        'ie_key': 'NRK',
        'url': 'nrk:MDDP12000117',
        'display_id': 'MDDP12000117',
    }

# Generated at 2022-06-24 13:07:18.798297
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    inst = NRKTVEpisodeIE()

# Generated at 2022-06-24 13:07:22.874127
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url="https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763"
    nrk_playlist_ie=NRKPlaylistIE()
    assert nrk_playlist_ie.suitable(url)

# Generated at 2022-06-24 13:07:24.314959
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE.suitable(None)


# Generated at 2022-06-24 13:07:25.065904
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    return NRKRadioPodkastIE(NRKIE())



# Generated at 2022-06-24 13:07:27.357105
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()

# Generated at 2022-06-24 13:07:37.462015
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE('https://tv.nrk.no/serie/blank')
    assert(ie.suitable('https://tv.nrk.no/serie/blank') is True)
    assert(ie.suitable('https://tv.nrk.no/serie/nei-takk-gutt') is True)
    assert(ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1') is False)
    assert(ie.suitable('https://tv.nrk.no/serie/blank/sesong/1/episode/1/') is False)
    assert(ie.suitable('https://tv.nrk.no/serie/groenn-glede/1') is False)

# Generated at 2022-06-24 13:07:38.852149
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test_class = NRKPlaylistBaseIE()
    assert(test_class.playlist_result())



# Generated at 2022-06-24 13:07:40.060384
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(NRKTVIE.IE_NAME, True)

# Generated at 2022-06-24 13:07:41.927267
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """Test if we can instantiate the NRKTVDirekteIE class"""
    direkte = NRKTVDirekteIE()
    assert direkte is not None

# Generated at 2022-06-24 13:07:43.183430
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE('NRKTVSerieBase', 'tv.nrk.no')



# Generated at 2022-06-24 13:07:44.247139
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    base = NRKTVSerieBaseIE('nrk.no')


# Generated at 2022-06-24 13:07:49.081100
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    for ie in NRKTVSeasonIE.__bases__:
        if ie.__name__ == 'NRKTVSeriesIE':
            return ie('NRKTVSeasonIE', NRKTVSeasonIE.ie_key(), 'url')


# Generated at 2022-06-24 13:07:59.957555
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031') == True
    assert NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/690311') == False
    assert NRKTVEpisodesIE._VALID_URL == 'https?://tv\\.nrk\\.no/program/[Ee]pisodes/[^/]+/(?P<id>\\d+)'