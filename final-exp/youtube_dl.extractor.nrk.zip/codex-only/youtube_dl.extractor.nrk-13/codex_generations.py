

# Generated at 2022-06-24 12:58:00.260631
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    webpage = NRKPlaylistIE(NRKIE())._download_webpage(url, '12270763')
    entries = re.findall(NRKPlaylistIE._ITEM_RE, webpage)
    assert len(entries) == 2

# Generated at 2022-06-24 12:58:07.670104
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    r = ie._real_extract(url)
    assert r['id'] == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    assert r['title'] == 'Gjenopplev den historiske solformørkelsen'
    assert r['description'] == 'md5:c2df8ea3bac5654a26fc2834a542feed'



# Generated at 2022-06-24 12:58:12.393565
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
  """ A unittest for the constructor of class NRKTVIE."""

# Generated at 2022-06-24 12:58:19.301558
# Unit test for constructor of class NRKIE
def test_NRKIE():
    import unittest
    import os
    """
    def setUp(self):
        # create object
        """

    nrk = NRKBaseIE()
    """
    def test_nrk_call_api(self):
        # test _call_api
        """
    response = nrk._call_api('/person/p_1', '1', "")
    if os.path.exists('config.json'):
        with open('config.json') as myfile:
            data=myfile.read()
        # Reading data back
        config = json.loads(data)
    else:
        config = {}
    assert 'foo' in response, config.get('error')

    """
    def test_nrk_download_json(self):
        # test _download_json
        """
    response

# Generated at 2022-06-24 12:58:25.771065
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == 'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-24 12:58:29.361272
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrkbaseie = NRKBaseIE()
    assert nrkbaseie.IE_NAME == 'NRK'
    assert nrkbaseie._GEO_COUNTRIES == ['NO']


# Generated at 2022-06-24 12:58:34.583323
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank'
    from youtube_dl.utils import unescapeHTML
    import json

    webpage = _download_webpage(url)
    embed_code = _search_regex(r'embedCode\s*=\s*"([^"]+)"', webpage, 'embed code')
    embed_code_html = unescapeHTML(embed_code)
    embed_params = re.findall(r'<param\s+([^>]+?)/?>', embed_code_html)
    params_dict = {}
    for p in embed_params:
        name = _search_regex(r'\s+name\s*=\s*"([^"]+)"', p, 'name')

# Generated at 2022-06-24 12:58:37.356900
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    a = NRKTVSeasonIE(None, 'NRKTVSeasonIE', url='https://tv.nrk.no/serie/backstage/sesong/1')
    assert a.url == 'https://tv.nrk.no/serie/backstage/sesong/1'



# Generated at 2022-06-24 12:58:46.769174
# Unit test for constructor of class NRKIE
def test_NRKIE():

    import copy
    IE = NRKIE()


# Generated at 2022-06-24 12:58:58.918893
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert isinstance(NRKTVSeriesIE.ie_key(), type(NRKTVIE.ie_key()))
    obj = NRKTVSeriesIE()
    assert obj.suitable('https://tv.nrk.no/serie/backstage')
    assert not obj.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert obj.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert not obj.suitable('https://tv.nrksuper.no/serie/sondag-sondag-sondag')
    assert obj.suitable('https://radio.nrk.no/serie/dickie-dick-dickens')

# Generated at 2022-06-24 12:59:08.040891
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    direkte = NRKTVDirekteIE()

# Generated at 2022-06-24 12:59:13.737044
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'


# Generated at 2022-06-24 12:59:15.097978
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()



# Generated at 2022-06-24 12:59:23.829696
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    e = NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert e.__class__.__name__ == 'NRKSkoleIE'
    assert e._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert e.IE_NAME == 'nrk:skole'
    assert e.IE_DESC == 'NRK Skole'
    assert e.ie_key() == 'NRKSkole'
    assert e._TESTS is not None


# Generated at 2022-06-24 12:59:32.812896
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    a = NRKBaseIE
    assert a._GEO_COUNTRIES == ['NO']
    assert a._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 12:59:38.397627
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE() # ie stands for info extractor
    assert ie.IE_NAME == 'nrktv' # assert that the ie is correct
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\\d{8})'

# Generated at 2022-06-24 12:59:47.474841
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    podkast_url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert(NRKRadioPodkastIE._VALID_URL == 
               r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})')
    assert(NRKRadioPodkastIE.suitable(podkast_url))

# Generated at 2022-06-24 12:59:56.743638
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_IE = NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    # Testing for _match_id
    if nrk_skole_IE.test_match_id('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'):
        print("test_id: OK")
    else:
        print("test_id: ERROR")

    print("The url of the video is: " + nrk_skole_IE._VALID_URL)
    # Testing for _real_extract
    nrk_skole_IE.test_real_extract()

# Unit tests for class NRKSkoleIE

# Generated at 2022-06-24 13:00:10.391441
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from youtube_dl.extractor.nrk import NRKTVSeriesIE
    assert NRKTVSeriesIE.suitable('https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1') is False
    assert NRKTVSeriesIE.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant') is False
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1') is False
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/lindmo/2016') is False

# Generated at 2022-06-24 13:00:12.190550
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()


# Generated at 2022-06-24 13:00:14.312868
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE('NRKTV') == NRKTVEpisodeIE


# Generated at 2022-06-24 13:00:15.731530
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert isinstance(NRKPlaylistBaseIE(), InfoExtractor)



# Generated at 2022-06-24 13:00:17.356187
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('nrk')
    assert ie is not None
    assert isinstance(ie, NRKTVSerieBaseIE)


# Generated at 2022-06-24 13:00:18.894649
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')



# Generated at 2022-06-24 13:00:31.358413
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/backstage')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://tv.nrksuper.no/serie/labyrint')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/saving-the-human-race')

# Generated at 2022-06-24 13:00:35.723196
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    item = NRKTVIE._call_api('programs/MDDP12000117', 'MDDP12000117', 'programs')
    assert item == [{'seriesTitle': 'Alarm'}, {'episodeTitle': 'Trolltunga'}, {'episodeNumber': '117'}, {'seasonNumber': '1'}, {'seasonId': 'MDDP12000117'}]

    item = NRKTVIE._call_api('playback/manifest/MDDP12000117', 'MDDP12000117', 'manifest')
    assert item == {'id': 'MDDP12000117', 'type': 'series'}

    item = NRKTVIE._call_api('playback/metadata/MDDP12000117', 'MDDP12000117', 'metadata')

# Generated at 2022-06-24 13:00:45.124503
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    with ie.assertRaisesRegex(ExtractorError, 'NRK has no rights to show this program outside Norway'):
        ie.geo_verification_headers = {'x-forwarded-for': '0.0.0.0'}
        ie._call_api('/mediaelement/media/23265460', '23265460', item='program', fatal=False)
    ie.report_warning('NRK said: %s' % ie._call_api('/mediaelement/media/23265460', '23265460', item='program')['endUserMessage'])
    ie.geo_verification_headers = {}

# Generated at 2022-06-24 13:00:47.795765
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        NRKTVSeriesIE
    except NameError:
        raise RuntimeError('No constructor of class NRKTVSeriesIE')


# Generated at 2022-06-24 13:00:50.374629
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 13:00:55.865377
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    for url in ('https://tv.nrk.no/direkte/nrk1', 'https://tv.nrk.no/direkte/nrk2', 'https://radio.nrk.no/direkte/p1_oslo_akershus'):
        assert url in NRKTVDirekteIE._VALID_URL


# Generated at 2022-06-24 13:00:59.456507
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IETest = NRKBaseIE('NRKPlaylistBaseIE', 'nrk.no')
    assert IETest._GEO_COUNTRIES == ['NO']
    assert IETest._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''



# Generated at 2022-06-24 13:01:01.815821
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Test that object constructed without errors
    assert NRKRadioPodkastIE()


# Generated at 2022-06-24 13:01:11.420006
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # pylint: disable=protected-access
    assert NRKTVDirekteIE._call_live_programs_api('nrk1', 'tv.nrk.no')
    assert NRKTVDirekteIE._call_live_programs_api('p1_oslo_akershus', 'radio.nrk.no')
    with pytest.raises(ExtractorError):
        NRKTVDirekteIE._call_live_programs_api('wrong_channel', 'tv.nrk.no')
        NRKTVDirekteIE._call_live_programs_api('wrong_channel', 'radio.nrk.no')



# Generated at 2022-06-24 13:01:18.185143
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    i = get_info_extractor(NRKTVEpisodeIE.ie_key())
    assert i.ie_key() == 'NRKTVEpisode'
    assert i.suitable('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert not i.suitable('https://tv.nrk.no/serie/hellums-kro/sesong/1/2')



# Generated at 2022-06-24 13:01:26.594894
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    info_extractor = NRKBaseIE()
    assert info_extractor._GEO_COUNTRIES == ['NO']
    assert info_extractor._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''



# Generated at 2022-06-24 13:01:28.664572
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert NRKTVIE._EPISODE_RE == ie._EPISODE_RE
    assert NRKTVIE._VALID_URL == ie._VALID_URL

# Generated at 2022-06-24 13:01:39.843567
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    m = NRKRadioPodkastIE()

# Generated at 2022-06-24 13:01:43.393424
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    class TestNRKTVSerieBaseIE(NRKTVSerieBaseIE):
        _VALID_URL = 'https://example.com'
        _TEST = {
            'url': 'https://example.com/series/some-serie/',
            'info_dict': {
                'id': 'some-serie',
                'display_id': 'some-serie',
            },
            'playlist_mincount': 9000,
        }
    ie = TestNRKTVSerieBaseIE()
    assert ie._VALID_URL == TestNRKTVSerieBaseIE._VALID_URL


# Generated at 2022-06-24 13:01:53.252211
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert 'NRKTVSeasonIE' in globals()
    assert 'NRKTVEpisodeIE' in globals()
    assert 'NRKTVSeriesIE' in globals()
    # Test URL patterns:
    season_url = 'https://tv.nrk.no/serie/blank/sesong/1'
    episode_url = 'https://tv.nrk.no/serie/blank/sesong/1/episode/2'
    series_url = 'https://tv.nrk.no/serie/blank'
    assert NRKTVSeasonIE.suitable(season_url)
    assert not NRKTVSeasonIE.suitable(episode_url)
    assert not NRKTVSeasonIE.suitable(series_url)
    assert not NRKTVEpisodeIE.suitable(season_url)
    assert NRKT

# Generated at 2022-06-24 13:02:02.386326
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # test for the constructor
    ie = NRKSkoleIE(1, None, None)
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    # test for the extract()
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    ie = NRKSkoleIE()
    ie._match_id(url)
    ie._real_extract(url)

# Generated at 2022-06-24 13:02:09.337119
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-24 13:02:10.064011
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
        class_NRKRadioPodkastIE = NRKRadioPodkastIE()



# Generated at 2022-06-24 13:02:11.506234
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE('NRK', None)
    return ie._GEO_COUNTRIES


# Generated at 2022-06-24 13:02:16.469160
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # If a stream is not 'live' or 'vod/replacement',
    # NRKTVIE constructor raises a RegexNotFoundError
    with pytest.raises(RegexNotFoundError):
        NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')._real_extract('svg_url')



# Generated at 2022-06-24 13:02:21.500585
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE("https://tv.nrk.no/program/MDDP12000117")
    assert nrktvie._match_id("https://tv.nrk.no/program/MDDP12000117") == "MDDP12000117"

# Generated at 2022-06-24 13:02:35.634584
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # We do not use the factories, because we need the results of the searches.
    # We do not use the internet, because it may be disconnected
    entry_list = [
        {'prfId': 'MUHH36005220', 'episodeId': 'MUHH36005220'},
        # {'episodeId': 'MVHH16001620'},
        # {'episodeId': 'MVHH16001620', 'prfId': 'MSDS15000216'},
        # {'prfId': 'MSDS15000216'},
        # {'prfId': 'MSDS15000216', 'episodeId': 'MVHH16001620'},
    ]
    catalog_name = NRKTVSerieBaseIE._catalog_name
    _ASSETS_KEYS = NRKTVSerieBaseIE._

# Generated at 2022-06-24 13:02:38.656569
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    instance = NRKRadioPodkastIE(NRKTVIE)
    result = instance.suitable(url)
    assert result == True


# Generated at 2022-06-24 13:02:40.674635
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert issubclass(NRKPlaylistBaseIE, InfoExtractor)



# Generated at 2022-06-24 13:02:46.800455
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    for url in ('https://tv.nrk.no/program/MDDP12000117', 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015'):
        ie = NRKTVIE(DummyIE([]), url, {})
        assert ie._VALID_URL == NRKTVIE._VALID_URL
        assert isinstance(ie, NRKIE) == True

# Generated at 2022-06-24 13:02:48.710893
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE('NRKTVSeriesIE', 'https://tv.nrk.no/serie/groenn-glede')


# Generated at 2022-06-24 13:02:56.503059
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    test_init = {
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'info_dict': {
            'id': 'MSIS70020917',
            'ext': 'mp4',
            'title': 'NRK1',
            'duration': 4707,
            'age_limit': 0,
        },
        'params': {
            'skip_download': True,
        },
    }
    test_NRKTVDirekteIE = NRKTVDirekteIE()
    test_NRKTVDirekteIE.init()
    test_NRKTVDirekteIE.suitable(test_init['url'])
    test_NRKTVDirekteIE.extract(test_init['url'])


# Generated at 2022-06-24 13:02:57.287761
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE(None)



# Generated at 2022-06-24 13:02:58.420998
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    base = NRKTVSerieBaseIE()
    assert base.IE_DESC == 'NRK TV and NRK Radio'


# Generated at 2022-06-24 13:03:07.017839
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._valid_url(
        'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763',
        NRKPlaylistIE) is True
    assert NRKPlaylistIE._valid_url(
        'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449',
        NRKPlaylistIE) is True


# Generated at 2022-06-24 13:03:08.653530
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IE = NRKBaseIE('', '', '')
    assert isinstance(IE, InfoExtractor)


# Generated at 2022-06-24 13:03:10.165535
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE('NRKTVSeasonIE', 'http:', 'tv.nrk.no')



# Generated at 2022-06-24 13:03:19.200488
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    info = {
        '_type': 'url',
        'url': 'nrk:%s' % 'KMTE52000316',
        'ie_key': 'NRKTV',
        'season_number': 1,
        'episode_number': 9,
        'id': 'KMTE52000316'
    }
    assert NRKTVEpisodeIE()._real_extract(
        'https://tv.nrk.no/serie/anno/sesong/1/episode/9') == info


# Generated at 2022-06-24 13:03:21.969321
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    import unittest
    class test_NRKPlaylistBaseIE(unittest.TestCase):
        nrk_playlist_base_instance = NRKPlaylistBaseIE()
        def test_nrk_playlist_base_extract_description(self):
            self.assertIsNone(self.nrk_playlist_base_instance._extract_description(""))
    test = unittest.main()

# test_NRKPlaylistBaseIE()


# Generated at 2022-06-24 13:03:31.178674
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    expected_result = {
        '_type': 'url',
        'id': 'MUHH36005220',
        'url': 'nrk:MUHH36005220',
        'ie_key': 'NRKTV',
        'season_number': 1,
        'episode_number': 2,
    }

# Generated at 2022-06-24 13:03:31.972254
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()

# Generated at 2022-06-24 13:03:34.726140
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        class TestNRKBaseIE(NRKBaseIE):
            IE_NAME = 'TestNRKBaseIE'
        raise Exception('')
    except TypeError:
        pass
    except Exception:
        raise Exception('NRKBaseIE should be an abstract class')

test_NRKBaseIE()

# Generated at 2022-06-24 13:03:37.719310
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+)'
    assert len(ie._TESTS) == 2



# Generated at 2022-06-24 13:03:41.191125
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_urls = ['https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2',
                'https://tv.nrk.no/serie/backstage/sesong/1/episode/8']
    for test_url in test_urls:
        episode = NRKTVEpisodeIE()
        episode._real_extract(test_url)


# Generated at 2022-06-24 13:03:47.669127
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrk_base_ie = NRKTVSerieBaseIE()
    nrk_base_ie._ASSETS_KEYS = ('episodes', 'instalments',)
    assert nrk_base_ie.__class__.__name__ == 'NRKTVSerieBaseIE'
    assert nrk_base_ie._VALID_URL is None
    assert nrk_base_ie._TESTS == []
    assert nrk_base_ie.IE_NAME == 'NRK'
    assert nrk_base_ie.IE_DESC == 'NRK TV and NRK Radio'
    assert nrk_base_ie._ASSETS_KEYS == ('episodes', 'instalments',)



# Generated at 2022-06-24 13:03:50.151777
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert isinstance(ie, NRKPlaylistBaseIE)
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 13:03:53.072371
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE("http://tv.nrk.no/program/episodes/nytt-paa-nytt/69031")
    assert(isinstance(ie, NRKTVEpisodesIE))


# Generated at 2022-06-24 13:04:01.226878
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('nrk:MDDP12000117')
    NRKIE('nrk:program/ENRK10100318')
    NRKIE('nrk:niN999999')
    NRKIE('nrk:clip/niN999999')
    NRKIE('nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9')
    NRKIE('nrk:clip/7707d5a3-ebe7-434a-87d5-a3ebe7a34a70')
    NRKIE('nrk:nrk1')
    NRKIE('nrk:channel/nrk1')

# Generated at 2022-06-24 13:04:10.707277
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_url = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    test_obj = NRKTVEpisodeIE()
    assert re.match(r'[a-zA-Z0-9]+', test_obj.LOGGER_NAME)
    assert re.match(r'[a-zA-Z0-9]+', test_obj.IE_NAME)
    assert re.match(r'[a-zA-Z0-9]+', test_obj.JR_NAME)
    assert isinstance(test_obj.IE_KEY, type(''))
    assert re.match(NRKTVEpisodeIE._VALID_URL, test_url)



# Generated at 2022-06-24 13:04:12.857189
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    tv_episodes = NRKTVEpisodesIE()
    assert tv_episodes is not None



# Generated at 2022-06-24 13:04:16.742208
# Unit test for constructor of class NRKIE
def test_NRKIE():
    from . import _get_testcases, _extract_info
    for url, info in list(_get_testcases().items())[:2]:
        try:
            res = _extract_info('nrk', url, 'NRK')
            assert res['title'] == info['title']
        except:
            pass



# Generated at 2022-06-24 13:04:17.456953
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    print('hello')


# Generated at 2022-06-24 13:04:22.548463
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteie = NRKTVDirekteIE()
    assert nrktvdirekteie.ie_key() in ['NRKDirekte']
    assert nrktvdirekteie.ie_key() not in ['NRKTVDirekte']
    assert nrktvdirekteie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert nrktvdirekteie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 13:04:32.045424
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE._GEO_COUNTRIES == ['NO']
    assert NRKBaseIE._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 13:04:35.352879
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        NRKTVSeriesIE('NRKTVSeasonIE')
    except Exception:
        raise AssertionError('Test fails for class NRKTVSeriesIE')


# Generated at 2022-06-24 13:04:42.905704
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

    ie = NRKSkoleIE(NRKIE())
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

    ie = NRKSkoleIE.from_url('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')

# Generated at 2022-06-24 13:04:48.610592
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    obj = NRKTVSerieBaseIE()
    assert obj._ASSETS_KEYS == ('episodes', 'instalments',)
    assert obj._catalog_name('serie') == 'series'
    assert obj._catalog_name('podcast') == 'podcast'
    assert obj._catalog_name('podkast') == 'podcast'



# Generated at 2022-06-24 13:04:59.899955
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE('NRKSkoleIE', 'nrk.no')
    ok_(ie.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099'))
    not ok_(ie.suitable('https://tv.nrk.no/serie/skam'))
    ok_(ie.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'))
    ok_(ie.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14098'))

# Generated at 2022-06-24 13:05:03.962720
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-24 13:05:10.058740
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    res = NRKRadioPodkastIE()._real_extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert res == {
        'id': 'MUHH48000314AA',
        'url': 'nrk:MUHH48000314AA',
        'ie_key': 'NRK',
        'display_id': 'MUHH48000314AA'
    }

# Generated at 2022-06-24 13:05:13.839539
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == "NRK TV Direkte and NRK Radio Direkte"


# Generated at 2022-06-24 13:05:15.573575
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    instance = NRKTVSerieBaseIE()
    assert isinstance(instance, InfoExtractor)



# Generated at 2022-06-24 13:05:16.992102
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    constructor_test(NRKBaseIE)


# Generated at 2022-06-24 13:05:24.030464
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_ie = NRKTVEpisodesIE('NRKTVEpisodes','NRK','http://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert nrktv_episodes_ie.SUFFIX == '/program/episodes/'
    assert nrktv_episodes_ie.IE_NAME == 'NRKTVEpisodes'

# Generated at 2022-06-24 13:05:26.529854
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/program/MDDP12000117'
    video_id = 'MDDP12000117'
    ie = NRKTVIE()._real_extract(url)
    assert(ie == 'nrk:%s' % video_id)



# Generated at 2022-06-24 13:05:33.066131
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():

    assert NRKRadioPodkastIE._VALID_URL

    # truncated uuid
    assert not NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/'
                                          'juks_og_fanteri/l_96f4f1b0-de54')

    # invalid uuid
    assert not NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/'
                                          'juks_og_fanteri/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af80')

    # no uuid

# Generated at 2022-06-24 13:05:37.726149
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK.no'
    assert repr(ie).startswith('<NRKIE>')

# Generated at 2022-06-24 13:05:38.625825
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    t = NRKTVEpisodeIE()
    t.suite()

# Generated at 2022-06-24 13:05:48.851017
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test_case1 = {
        'url': 'https://tv.nrk.no/serie/svart/MUHH48000314/sesong-1/episode-3',
        'expected_result': 'nrk:MUHH48000314',
        'expected_list': [u'nrk:MUHH48000314'],
    }
    test_case2 = {
        'url': 'https://tv.nrk.no/serie/svart/MUHH48000314',
        'expected_result': 'nrk:MUHH48000314',
        'expected_list': [u'nrk:MUHH48000314'],
    }

# Generated at 2022-06-24 13:05:58.530722
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    assert ie._match_id(url) == 'backstage/sesong/1/episode/8'
    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-24 13:06:03.026328
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE._asset_key(None)
    except Exception as e:
        raise AssertionError('NRKTVSerieBaseIE._asset_key(None) failed: %s' % e)
    return True



# Generated at 2022-06-24 13:06:09.324863
# Unit test for constructor of class NRKIE
def test_NRKIE():
    video_id = '1'
    inst = NRKIE(NRKBaseIE)
    assert inst
    assert inst.playable_path % video_id == 'playback/playable/' + video_id
    assert inst.manifest_path % video_id == 'playback/manifest/' + video_id
    assert inst.metadata_path % video_id == 'playback/metadata/' + video_id


# Generated at 2022-06-24 13:06:10.357265
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('NRK:tv-direkte')

# Generated at 2022-06-24 13:06:20.834102
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE(None)
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
    assert ie.IE_NAME == 'NRK'


# Generated at 2022-06-24 13:06:25.585565
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    # Check if url is givin to suitable when it returns False
    assert ie.suitable('nrk:MUHH36005220') is False
    assert ie.suitable('nrk:MUHH36005220') is False


# Generated at 2022-06-24 13:06:29.478161
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # ensure that all functions here are working and are used
    season_module = sys.modules[__name__]
    assert issubclass(getattr(season_module, 'test_NRKTVSeasonIE'), unittest.TestCase)
    assert season_module.test_NRKTVSeasonIE.__name__ == 'test_NRKTVSeasonIE'
    assert issubclass(getattr(season_module, 'NRKTVSeasonIE'), InfoExtractor)



# Generated at 2022-06-24 13:06:33.136115
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.suitable('http://www.nrk.no/skole/kroppen-menneskekroppen-1.11284879') == False
    assert ie.suitable('http://www.nrk.no/tema/skolesanger---skolehverdagen-i-sang-1.11284885') == True

# Generated at 2022-06-24 13:06:40.204723
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from anvato.extractor import AnvatoIE
    from nrktv.extractor import NRKTVIE
    from nrktv.extractor import NRKTVSeasonIE
    from nrktv.extractor import NRKTVEpisodeIE
    from nrktv.extractor import NRKRadioPodkastIE
    from nrktv.extractor.common import NRKBaseIE
    from nrktv.extractor.common import NRKTVSerieBaseIE
    from nrktv.extractor.common import NRKTVSeriesIE
    nrktv_series_ie = NRKTVSeriesIE._create_ie(NRKTVSeriesIE.ie_key())
    assert isinstance(nrktv_series_ie, NRKTVSeriesIE), "NRKTVSeriesIE is not a constructor."

# Generated at 2022-06-24 13:06:45.326038
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/program/frontpage/frontpage_avspiller/MDHP14000014'
    unit_test_url_result=NRKTVIE._is_valid_url(url, NRKTVIE._VALID_URL)
    assert unit_test_url_result.group('id') == 'MDHP14000014'

# Generated at 2022-06-24 13:06:46.670460
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    chpl = NRKTVEpisodesIE()
    assert(chpl.__class__.__name__ == 'NRKTVEpisodesIE')


# Generated at 2022-06-24 13:06:52.892045
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    print('Testing NRKRadioPodkastIE:')
    with open('tests/test_NRKRadioPodkastIE.py') as f:
        # Test that import of module NRKRadioPodkastIE will succeed.
        print('Test that import of module NRKRadioPodkastIE will succeed:')
        exec(f.read())



# Generated at 2022-06-24 13:06:53.851838
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE()


# Generated at 2022-06-24 13:06:56.489577
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    instance = NRKTVSeriesIE()
    expected_result = -1
    assert (instance.suitable(url=None) == expected_result)

# Generated at 2022-06-24 13:06:57.854583
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    tv_series_ie = NRKTVSeriesIE()


# Generated at 2022-06-24 13:07:04.206305
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'://nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no/'


# Generated at 2022-06-24 13:07:08.771720
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    class NRKTVSeasonIE_test(NRKTVSeasonIE):
        def __init__(self):
            pass
    example_inst = NRKTVSeasonIE_test()
    assert example_inst._ASSETS_KEYS == ('episodes', 'instalments')



# Generated at 2022-06-24 13:07:11.028859
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.ie_key() == 'NRKPlaylist'



# Generated at 2022-06-24 13:07:13.715365
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    obj = NRKSkoleIE()
    # assert obj.__class__.__name__ == class_name
    obj.suitable()

# Generated at 2022-06-24 13:07:14.797198
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    return NRKBaseIE


# Generated at 2022-06-24 13:07:25.044504
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert(ie.IE_NAME == 'nrk')
    assert(ie.IE_DESC == 'NRK TV, NRK Radio and NRK Super')
    assert(ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        ''')
    
    assert(len(ie._TESTS) == 19)
    url_info = ie._TESTS[0]

# Generated at 2022-06-24 13:07:28.184561
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL is not None

# Generated at 2022-06-24 13:07:29.710278
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    inst = NRKPlaylistBaseIE()
    assert inst is not None


# Generated at 2022-06-24 13:07:36.251422
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    dir_inst = NRKTVDirekteIE()
    assert dir_inst.ie_key() == 'NRKTVDirekte'
    assert dir_inst.ie_desc() == 'NRK TV Direkte and NRK Radio Direkte'
    assert NRKTVDirekteIE.ie_key() == 'NRKTVDirekte'
    assert NRKTVDirekteIE.ie_desc() == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-24 13:07:40.472239
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie.IE_DESC == 'NRK Skole'
    assert ie is not None



# Generated at 2022-06-24 13:07:47.260368
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # not a valid URL
    a = NRKBaseIE('url', 'display_id')
    assert not a.suitable('https://tv.nrk.no/program/')
    assert not a.suitable('https://tv.nrk.no/serie/an')
    assert not a.suitable('https://tv.nrk.no/serie/ann')
    assert not a.suitable('https://tv.nrk.no/serie/anno/')
    assert not a.suitable('https://tv.nrk.no/serie/anno/sesong/1')
    assert not a.suitable('https://tv.nrk.no/serie/anno/sesong/1/')



# Generated at 2022-06-24 13:07:48.390111
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    info_extractor = NRKTVEpisodeIE()
    assert info_extractor is not None


# Generated at 2022-06-24 13:07:53.148647
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    youtube_re_test = NRKTVEpisodesIE.youtube_re

    # Testing first part of code of constructor
    assert youtube_re_test.groups == 1

    # Testing second part of code of constructor
    assert youtube_re_test.pattern == r'(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)(?P<id>[^"&?/ ]{11})'

    # Testing third part of code of constructor
    assert youtube_re_test.flags == re.VERBOSE



# Generated at 2022-06-24 13:07:55.920903
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE('www.nrk.no', 'skole/?page=search&q=&mediaId=14099')

# Generated at 2022-06-24 13:08:02.579936
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''.replace('\n        ', '')
