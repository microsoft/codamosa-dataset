

# Generated at 2022-06-24 12:58:03.976440
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
# create a new object, and check that correct values are set
  ie = NRKTVIE('NRKTVIE', 'NRK TV and NRK Radio')
  assert ie.ie_key() == 'NRKTVIE'
  assert ie.ie_desc() == 'NRK TV and NRK Radio'
  assert 'nrktvie' not in globals().keys()
# run the test
test_NRKTVIE()

# Generated at 2022-06-24 12:58:15.720311
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    test_url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'

    site, ext, video_id = re.match(NRKSkoleIE._VALID_URL, test_url).groups()
    nrk_id = '6021'
    nrk_id_url = 'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/%s' % video_id
    nrk_id_data = '{"psId":"%s"}' %nrk_id

    # Mocking functions _download_webpage and _download_json

# Generated at 2022-06-24 12:58:17.997346
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE('www.nrk.no/skole/?q=bilde&mediaId=14099').get_url()


# Generated at 2022-06-24 12:58:20.310081
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name('series') == 'series'
    assert ie._catalog_name('podkast') == 'podcast'



# Generated at 2022-06-24 12:58:22.040196
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Just test that it works: no exception is raised
    info_extractor = NRKTVEpisodesIE()
    pass

# Generated at 2022-06-24 12:58:23.047358
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    info = NRKTVEpisodeIE()

# Generated at 2022-06-24 12:58:26.548661
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE("https://www.nrk.no/skole/?page=search&q=&mediaId=14099")

# Generated at 2022-06-24 12:58:29.779344
# Unit test for constructor of class NRKPlaylistIE

# Generated at 2022-06-24 12:58:32.263975
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # check if subclass
    assert issubclass(NRKTVSeriesIE, NRKTVSerieBaseIE)


# Generated at 2022-06-24 12:58:34.871510
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._ITEM_RE
    assert NRKPlaylistIE._VALID_URL
    assert NRKPlaylistIE._TESTS



# Generated at 2022-06-24 12:58:36.309159
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE(NRKTVSeasonIE())._VALID_URL == NRKTVSeasonIE._VALID_URL


# Generated at 2022-06-24 12:58:39.589134
# Unit test for constructor of class NRKIE
def test_NRKIE():
    testie=NRKIE()
    global nrkbase
    nrkbase=NRKBaseIE()
    assert testie.IE_NAME=="nrk"
# Test method _real_extract of class NRKIE

# Generated at 2022-06-24 12:58:46.681281
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''



# Generated at 2022-06-24 12:58:56.681103
# Unit test for constructor of class NRKIE
def test_NRKIE():
    "Unit test for constructor of class NRKIE"
    ie = NRKIE()
    assert(ie._GEO_COUNTRIES == ['NO'])
    assert(ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/''')


# Generated at 2022-06-24 12:59:00.862494
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE('NRKTVSerieBaseIE', None)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 12:59:04.684258
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE('http://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-24 12:59:05.945705
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    return nrk

# Generated at 2022-06-24 12:59:17.983024
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    constructor_test(
        NRKTVSeriesIE,
        [
            ('https://tv.nrk.no/serie/blank', {'id': 'blank'}),
            ('https://tv.nrk.no/serie/backstage', {'id': 'backstage'}),
            ('https://tv.nrk.no/serie/groenn-glede', {'id': 'groenn-glede'}),
            ('https://tv.nrk.no/serie/lindmo', {'id': 'lindmo'}),
        ],
    )

# Generated at 2022-06-24 12:59:28.089506
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk_base = NRKBaseIE()
    # Test for "nrkodn-httpcache0-47115-cacheodn.dna.ip-only.net"

# Generated at 2022-06-24 12:59:29.319729
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    try:
        NRKSkoleIE = NRKSkoleIE()
    except AttributeError:
        pass


# Generated at 2022-06-24 12:59:34.431639
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK and NRK Super'
    assert ie.GEO_COUNTRIES == ['NO']
    assert ie.VALID_URL == NRKIE._VALID_URL
    assert ie.TESTS == NRKIE._TESTS

# Generated at 2022-06-24 12:59:42.421677
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    import filecmp
    import tempfile
    import os

    # Check what is uploaded to YT by downloading video with pytube
    cache_dir_orig = get_cache_dir()
    tmp_dir = tempfile.mkdtemp()
    set_cache_dir(tmp_dir)
    url = 'https://tv.nrk.no/direkte/nrk1'
    filename = os.path.join(tmp_dir, 'nrk1.mp4')
    NRKTVDirekteIE().extract('nrk1')
    # TODO: remove explicit time.sleep. We have a retry mechanism.
    time.sleep(5)
    set_cache_dir(cache_dir_orig)

    # Compare video downloaded by pytube with video uploaded to YT

# Generated at 2022-06-24 12:59:46.995279
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL == 'https?://(?P<domain>tv|radio)\.nrk\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<serie>[^/]+)/(?:(?:sesong/)?(?P<id>\\d+)|sesong/(?P<id_2>[^/?#&]+))'


# Generated at 2022-06-24 12:59:47.694161
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert(True)


# Generated at 2022-06-24 12:59:54.932705
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    nrktvepisodesie = NRKTVEpisodesIE()
    playlist_id, entries, playlist_title, playlist_description = nrktvepisodesie._real_extract(url)
    assert playlist_id == '69031'
    assert len(entries) == 4
    assert playlist_title == 'Nytt på nytt, sesong: 201210'
    assert playlist_description is None

# Generated at 2022-06-24 12:59:55.923727
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE(None, None)



# Generated at 2022-06-24 12:59:58.824553
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_IE = NRKSkoleIE(None)
    assert(nrk_skole_IE.IE_DESC == 'NRK Skole')
    assert(nrk_skole_IE._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)')

# Generated at 2022-06-24 13:00:05.469843
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    NRKSkoleIE()._real_extract('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')


# Generated at 2022-06-24 13:00:11.859523
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    try:
        from .nrktv_direkte import NRKTVDirekteIE
    except ImportError:
        NRKTVDirekteIE = None
    if not NRKTVDirekteIE:
        return

    # nrktv_direkte.py is not part of the distribution
    # See https://github.com/ytdl-org/youtube-dl/issues/7466
    return NRKTVDirekteIE.suitable('http://tv.nrk.no/direkte/nrk1')



# Generated at 2022-06-24 13:00:14.822136
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015'
    tv = NRKTVIE(None)
    tv.url = url
    test = tv._match_id(url)
    assert test == 'MSPO40010515'

# Generated at 2022-06-24 13:00:15.815024
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrkplaylistie = NRKPlaylistIE()


# Generated at 2022-06-24 13:00:27.913951
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    class Tester(NRKTVSerieBaseIE):
        def __init__(self):
            NRKTVSerieBaseIE.__init__(self, 'NRKTVIE')
    t = Tester()
    assert t.ie_key() == 'NRKTVIE'
    assert t._extract_entries(None) == []
    assert t._extract_entries([]) == []
    assert t._extract_entries({'key': 'value'}) == []
    assert t._extract_entries({'episode': None}) == []
    assert t._extract_entries({'episode': {}}) == []

# Generated at 2022-06-24 13:00:31.605152
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    current_url = "http://www.nrk.no/sport/hopp/sveitsisk-seier-i-raw-air-1.12703346"
    NRKPlaylistIE.suitable(current_url)



# Generated at 2022-06-24 13:00:37.400100
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    for url in ['https://tv.nrk.no/serie/tour-de-ski/', 'https://tv.nrk.no/serie/a-gruppa/']:
        entry = NRKTVSerieBaseIE._extract_entries(NRKTVSerieBaseIE()._call_api(url, 'test'))
        assert entry != []


# Generated at 2022-06-24 13:00:43.311271
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """
    Simple controls for class NRKIE
    """
    URI = NRKIE()
    assert URI.IE_NAME == 'nrk'
    assert URI.IE_DESC == 'NRK'
    assert URI._VALID_URL == 'https?://(?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)(?P<id>[^?\#&]+)'


# Generated at 2022-06-24 13:00:50.145664
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE('NRKTV', 'NRK', 'NRKTV')
    assert ie._VALID_URL == NRKTVEpisodesIE._VALID_URL
    assert ie._ITEM_RE == NRKTVEpisodesIE._ITEM_RE
    assert ie._TESTS == NRKTVEpisodesIE._TESTS

# Generated at 2022-06-24 13:00:53.665567
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """Test whether objects created by in NRKTVIE constructor is initialized correctly."""
    ie = NRKTVIE("https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2")
    assert ie.url == "https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2"
    assert ie.video_id == "MSPO40010515"


# Generated at 2022-06-24 13:00:55.388898
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie
    assert NRKTVIE._EPISODE_RE
    assert NRKTVIE._VALID_URL
    assert NRKTVIE._TESTS


# Generated at 2022-06-24 13:00:57.924979
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    expected_id = 'nrk1'
    expected_program_id = 'nrk:program:%s' % expected_id
    url = 'https://tv.nrk.no/direkte/%s' % expected_id
    info = ie._real_extract(url)
    assert(info['id'] == expected_program_id)



# Generated at 2022-06-24 13:01:03.349716
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    inst = NRKTVSerieBaseIE()
    # Check if required methods are implemented
    assert callable(inst._extract_entries)
    assert callable(inst._extract_assets_key)
    assert callable(inst._catalog_name)
    assert callable(inst._entries)


# Generated at 2022-06-24 13:01:08.718028
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    obj = NRKTVEpisodeIE()
    assert obj._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'



# Generated at 2022-06-24 13:01:12.044491
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    direct_live_IE = NRKTVDirekteIE()
    assert directs_live_IE._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 13:01:16.059563
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    """Unit test for constructor of class NRKSkoleIE."""
    NRKSkoleIE()._real_extract(
        'https://www.nrk.no/skole/?page=search&q=&mediaId=14099')

# Generated at 2022-06-24 13:01:26.773202
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Test cases with string as input (non dict)
    non_dict_input = ['awesome', '', '{', '}']
    for data in non_dict_input:
        assert not NRKTVSerieBaseIE()._extract_assets_key(data)

    # Test cases with dict as input

# Generated at 2022-06-24 13:01:36.647670
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    description = 'I Daidalos sin undersjøiske Labyrint venter spennende oppgaver, skumle robotskapninger og slim.'
    # noinspection PyUnresolvedReferences
    nrk_tv_series_ie_instance = NRKTVSeriesIE({'url': 'https://tv.nrksuper.no/serie/labyrint'})
    # noinspection PyProtectedMember
    assert nrk_tv_series_ie_instance._VALID_URL == 'https?://(?P<domain>(?:tv|radio)\\.nrk|(?:tv\\.)?nrksuper)\\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)'
    # noinspection PyProtectedMember
    assert nrk

# Generated at 2022-06-24 13:01:39.300111
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'


# Generated at 2022-06-24 13:01:46.981912
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE('NRKSkoleIE', 'NRK Skole') == NRKSkoleIE('NRKSkoleIE', 'NRK Skole')
    assert NRKSkoleIE('NRKSkoleIE', 'NRK Skole')._VALID_URL == 'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-24 13:01:53.912776
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE('NRKTVSeasonIE', 'https://tv.nrk.no/serie/backstage/sesong/1')
    NRKTVSeasonIE('NRKTVSeasonIE', 'https://radio.nrk.no/podkast/loerdagsraadet/sesong/202101')
    NRKTVSeasonIE('NRKTVSeasonIE', 'https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    NRKTVSeasonIE('NRKTVSeasonIE', 'https://tv.nrk.no/serie/spangas/sesong/1')



# Generated at 2022-06-24 13:02:03.134800
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrkplaylist = NRKPlaylistIE()
    assert nrkplaylist._VALID_URL == 'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert nrkplaylist._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-24 13:02:07.255108
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    class_ = getattr(NRKTVSeriesIE, '__mro__')[1]
    assert class_.__name__ == 'NRKTVSerieBaseIE'
    assert '_extract_entries' in dir(class_)
    assert '_entries' in dir(NRKTVSeriesIE)
    assert '_extract_assets_key' in dir(class_)
    assert '_catalog_name' in dir(class_)

# Generated at 2022-06-24 13:02:07.929985
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE()

# Generated at 2022-06-24 13:02:11.591428
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    global NRKRadioPodkastIE
    # Test case for valid URL
    valid_url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    # Construct an NRKRadioPodkastIE object with valid_url
    NRKRadioPodkastIE(NRKRadioPodkastIE.ie_key(), valid_url)



# Generated at 2022-06-24 13:02:12.532283
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    episode = NRKRadioPodkastIE()
    assert episode is not None


# Generated at 2022-06-24 13:02:19.873731
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    if __name__ == '__main__':
        query = {
            'slug': 'urort_45376',
            'path': '/programsubsections/urort',
            'pageSize': '1',
            'pageNumber': '1',
            'type': 'radio',
            'range': 'day',
            'from': '2017-04-25T00:00:00',
            'to': '2017-04-26T00:00:00'
        }
        note = 'This is a test'
        NRK = NRKBaseIE()
        NRK._download_json(urljoin('http://psapi.nrk.no/', '/programs/entries'), url=None,
                           note=note, query=query)



# Generated at 2022-06-24 13:02:29.517850
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # The constructor of class NRKTVIE is tested here.
    url = 'https://tv.nrk.no/direkte/nrk1'
    ie = NRKTVDirekteIE(url, {}, '', '', '', None)
    assert str(ie) == 'NRK TV Direkte:nrk1'
    assert ie._get_feed_query({}) == {
        'channel': 'nrk1',
        'type': 'live',
        'profile': 'hls',
        'client': 'mestmulig',
    }



# Generated at 2022-06-24 13:02:42.215575
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    video_id = '19355'
    nrk_id = '6021'
    nrk_id_string = '"psId": "%s"' % nrk_id
    url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=%s' % video_id
    dataurl = 'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/%s' % video_id
    data = '{"requestUrl":"https://nrkno-skole-prod.kube.nrk.no/skole/api/media/%s",%s}' % (video_id, nrk_id_string)

# Generated at 2022-06-24 13:02:43.580739
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrkplaylistbaseie = NRKPlaylistBaseIE()


# Generated at 2022-06-24 13:02:51.429582
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    class Test(NRKPlaylistIE):
        pass
    assert Test.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert Test.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert not Test.suitable('http://www.nrk.no/video/PS*1.12334314')
    assert not Test.suitable('http://www.nrk.no/skole/kalender')
    assert not Test.suitable('http://www.nrk.no/skole/lindmo/overvaket-av-politiet-1.12282566')

# Generated at 2022-06-24 13:02:56.514789
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE(NRKPlaylistBaseIE._downloader,
                           NRKPlaylistBaseIE._match_id(None),
                           NRKPlaylistBaseIE._download_webpage(None, None),
                           re.findall(NRKPlaylistBaseIE._ITEM_RE, None))
    
    # Test for _extract_description function
    try:
        assert(ie._extract_description(None) == None)
    except NotImplementedError:
        pass



# Generated at 2022-06-24 13:02:58.076846
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie


# Generated at 2022-06-24 13:03:00.632565
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # This test verifies that the constructor of the class do not
    # throw any exception
    print(NRKIE())


# Generated at 2022-06-24 13:03:08.907560
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ydl = YoutubeDL({})
    ie = NRKPlaylistIE(ydl)
    assert_equal(ie._TYPE, 'playlist')
    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)')
    assert_equal(ie._ITEM_RE, r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"')



# Generated at 2022-06-24 13:03:22.282168
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie.IE_DESC == 'NRK TV and NRK Radio'
    assert nrktvie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % nrktvie._EPISODE_RE

# Generated at 2022-06-24 13:03:23.285601
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    dir = NRKTVDirekteIE({})
    pass

# Generated at 2022-06-24 13:03:29.451224
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    e = NRKPlaylistBaseIE()
    assert e.suitable('https://tv.nrk.no/programmer/')
    assert e.suitable('https://radio.nrk.no/programmer/')
    assert not e.suitable('https://tv.nrk.no/')
    assert not e.suitable('https://radio.nrk.no/')
    assert not e.suitable('https://www.nrk.no/')
    assert not e.suitable('https://tv.nrk.no/serie/')



# Generated at 2022-06-24 13:03:31.189766
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    wp = NRKPlaylistIE(NRKTVEpisodesIE)

# Generated at 2022-06-24 13:03:33.312215
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrk_tv_serie_base_instance = NRKTVSerieBaseIE(FakeYDL())
    assert nrk_tv_serie_base_instance._VALID_URL is None


# Generated at 2022-06-24 13:03:44.154928
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # no key provided
    nrktvie = NRKTVIE()
    # no name provided
    nrktvie = NRKTVIE(NRKTVIE.ie_key())

    # key is not NRKTVIE.ie_key()
    with pytest.raises(ExtractorError):
        NRKTVIE('non-NRKTV-key')

    # key and name are not provided
    with pytest.raises(ExtractorError):
        NRKTVIE(None, None)

    # key is None, but name is provided
    with pytest.raises(ExtractorError):
        NRKTVIE(None, 'non-None-name')

    nrktvie = NRKTVIE(NRKTVIE.ie_key(), 'NRKTV Extractor')
    assert nrktvie

# Generated at 2022-06-24 13:03:47.376727
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._VALID_URL == None
    assert ie.IE_NAME == None
    assert ie._TESTS == []
    assert ie.ie_key() == 'NRKTVSerieBase'
    assert ie.working == True


# Generated at 2022-06-24 13:03:48.183600
# Unit test for constructor of class NRKSkoleIE

# Generated at 2022-06-24 13:03:55.899253
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE._GEO_COUNTRIES == ['NO']
    assert NRKBaseIE._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
# End test_NRKBaseIE


# Generated at 2022-06-24 13:04:01.884170
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    from io import BytesIO
    import sys
    import unittest

    # Test construction of class
    if sys.version_info.major == 2:
        # In Python 2, urlopen returned a tuple
        # new_callable is a lambda function to emulate this behavior
        new_callable = lambda x: (BytesIO(b''), None)
    else:
        # In Python 3, urlopen returned a handle to the HTTP response
        new_callable = lambda x: BytesIO(b'')

    test_url = 'https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    real_urlopen = compat_urllib_request.urlopen

# Generated at 2022-06-24 13:04:12.004428
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id, season_number, episode_number = re.match(NRKTVEpisodeIE._VALID_URL, url).groups()
    webpage = NRKTVEpisodeIE._download_webpage(url, display_id)
    info = NRKTVEpisodeIE._search_json_ld(webpage, display_id, default={})

# Generated at 2022-06-24 13:04:17.904389
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    ie = NRKTVEpisodesIE()
    instance = ie(url)
    assert instance._VALID_URL == 'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'
    assert instance.IE_DESC == 'NRK TV episodes'
    assert instance._TESTS[0]['url'] == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert instance._TESTS[0]['info_dict']['id'] == '69031'

# Generated at 2022-06-24 13:04:28.034952
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_ie = NRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763','','','','','','','','')
    assert nrk_playlist_ie.playlist_count == 2 # playlist containes two videos
    assert nrk_playlist_ie.compat_urllib_parse.urlsplit('https://tv.nrk.no/program/t/1165/snow-business').hostname == 'tv.nrk.no' # URL is well formatted


# Generated at 2022-06-24 13:04:32.103359
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('nrktv')
    assert ie.num_entries == 10, 'Number of entries = 10'
    assert ie.type == 'series', 'Type of series = "series"'


# Generated at 2022-06-24 13:04:36.629014
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(NRKTVIE._downloader)
    NRKTVIE(NRKTVIE._downloader, downloader=None)
    NRKTVIE(NRKTVIE._downloader, downloader=NRKTVIE._downloader)

# Generated at 2022-06-24 13:04:38.198410
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE is not None



# Generated at 2022-06-24 13:04:44.334855
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._ASSETS_KEYS == ('episodes', 'instalments',)
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'


# Generated at 2022-06-24 13:04:46.045822
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie_NRKRadioPodkast = NRKRadioPodkastIE()



# Generated at 2022-06-24 13:04:56.993752
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    catalog_name = NRKTVSerieBaseIE._catalog_name('serie')
    if catalog_name != 'series':
        raise AssertionError('catalog_name expected to be series, but was %s instead.' % catalog_name)

    catalog_name = NRKTVSerieBaseIE._catalog_name('podcast')
    if catalog_name != 'podcast':
        raise AssertionError('catalog_name expected to be podcast, but was %s instead.' % catalog_name)

    catalog_name = NRKTVSerieBaseIE._catalog_name('podkast')
    if catalog_name != 'podcast':
        raise AssertionError('catalog_name expected to be podcast, but was %s instead.' % catalog_name)



# Generated at 2022-06-24 13:05:02.300163
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """
    Unit test for constructor of class NRKTVSeriesIE.
    """
    # Valid url
    url = 'https://tv.nrk.no/serie/groenn-glede'
    ie = NRKTVSeriesIE(url)

    assert(ie.url == url)
    assert(ie._VALID_URL == r'https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)')
    assert(ie.name == 'NRKTV')

    # Invalid url
    url = 'https://tv.nrk.no/serie/groenn-glede/bla'
    ie = NRKTVSeriesIE(url)

# Generated at 2022-06-24 13:05:10.958246
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    def _url2info(url):
        return NRKTVSeasonIE().url_result(url, 'NRKTVSeason')['_type']
    assert 'playlist' == _url2info('https://tv.nrk.no/serie/backstage/sesong/1')
    assert 'playlist' == _url2info('https://tv.nrk.no/serie/lindmo/2016')
    assert 'playlist' == _url2info('https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1')
    assert 'playlist' == _url2info('https://radio.nrk.no/serie/dagsnytt/sesong/201509')

# Generated at 2022-06-24 13:05:12.141129
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()


# Generated at 2022-06-24 13:05:15.702956
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % (
        ie._EPISODE_RE)

# Generated at 2022-06-24 13:05:21.120651
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    try:
        NRKSkoleIE("http://www.nrk.no/skole/?page=search&q=&mediaId=14099")
    except Exception as e:
        raise AssertionError("NRKSkoleIE expects an url as parameter")



# Generated at 2022-06-24 13:05:24.703504
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('https://tv.nrk.no/serie/backstage/sesong/1')
    assert(isinstance(ie, NRKTVSeasonIE))



# Generated at 2022-06-24 13:05:28.969863
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Test for not using the join method
    url = 'https://tv.nrk.no/api/catalog/series/spangas/seasons/1'
    assert NRKTVSeasonIE._call_api(url, 'spangas/1', 'season', query={'pageSize': 50})


# Generated at 2022-06-24 13:05:30.837197
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE(NRKPlaylistBaseIE(), 'url', 'id', 'title', 'description')

# Generated at 2022-06-24 13:05:35.929616
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    from youtube_dl.downloader.f4m import F4MDownloader
    from youtube_dl.cache import Cache

    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE()
    info = ie.extract(url)
    f4mdl = F4MDownloader(Cache())
    f4mdl.download(info['url'])
    srtfile = f4mdl.download_subtitles(info['url'])
    print(srtfile)

# Generated at 2022-06-24 13:05:41.239014
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Create object NRKRadioPodkastIE
    object_nrkradiopodkastIE = NRKRadioPodkastIE()

    # Extract url
    url_extract = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'

    # Extract video id
    video_id_extracted = 'l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'

    # Test method suitable
    url_suitable = object_nrkradiopodkastIE.suitable(url_extract)
    assert url_suitable == True

    # Test

# Generated at 2022-06-24 13:05:43.770929
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie is not None


# Generated at 2022-06-24 13:05:45.197818
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    instance = NRKBaseIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:05:58.174888
# Unit test for constructor of class NRKSkoleIE

# Generated at 2022-06-24 13:06:01.906814
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://www.nrk.no/kultur/toppsaker/1.7347905'
    return NRKPlaylistBaseIE(None).suitable(url)


# Generated at 2022-06-24 13:06:04.580837
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    ie.extract(NRKRadioPodkastIE._TESTS[0]['url'])
    ie.extract(NRKRadioPodkastIE._TESTS[1]['url'])
    ie.extract(NRKRadioPodkastIE._TESTS[2]['url'])



# Generated at 2022-06-24 13:06:09.796782
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(None)
    assert ie._extract_assets_key('episodes') == 'episodes'
    assert ie._extract_assets_key({'episodes': ''}) == 'episodes'
    assert ie._extract_assets_key({'instalments': ''}) == 'instalments'
    assert ie._extract_assets_key({'foo': ''})  is None
    assert ie._extract_assets_key({}) is None


# Generated at 2022-06-24 13:06:12.055249
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE("https://www.nrk.no/skole/?page=search&q=&mediaId=14099")
    assert ie.url == "https://www.nrk.no/skole/?page=search&q=&mediaId=14099"
    assert ie.IE_NAME == "nrkskole"




# Generated at 2022-06-24 13:06:12.781163
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()



# Generated at 2022-06-24 13:06:24.902630
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IE_NAME = 'nrk'
    IE = NRKBaseIE(IE_NAME)
    assert IE.ie_key() == IE_NAME
    assert IE.IE_NAME == IE_NAME
    assert IE._GEO_COUNTRIES == ['NO']
    assert IE._CDN_REPL_REGEX == r'''
        (?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 13:06:29.264932
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE._extract_title
        NRKPlaylistBaseIE._extract_description
        NRKPlaylistBaseIE._ITEM_RE
    except AttributeError as ae:
        pytest.fail(ae)



# Generated at 2022-06-24 13:06:30.411977
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_NAME == 'nrkskole'

# Generated at 2022-06-24 13:06:32.458349
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Test extractors
    instance = NRKBaseIE({})
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:06:43.845928
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    fake_test_url = 'fake_url'
    init_call_args = (fake_test_url,)
    init_call_kwargs = {}

    try:
        NRKTVIE(*init_call_args, **init_call_kwargs)
    except:
        assert False, 'NRKTVIE constructor threw exception'

    fake_test_url = 'https://tv.nrk.no/program/MDDP12000117'
    init_call_args = (fake_test_url,)
    init_call_kwargs = {}
    try:
        NRKTVIE(*init_call_args, **init_call_kwargs)
    except:
        assert False, 'NRKTVIE constructor threw exception'

# Generated at 2022-06-24 13:06:44.481798
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE(None, None)


# Generated at 2022-06-24 13:06:48.049590
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/sport/fotball/arsenal-med-tropp-i-boden-1.12279898'
    playList = NRKPlaylistIE()
    assert playList.suitable(url)


# Generated at 2022-06-24 13:06:51.764103
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    nrkskole_ie = NRKSkoleIE()
    nrkskole_ie.suitable(url)
    return nrkskole_ie.suitable(url)



# Generated at 2022-06-24 13:06:54.621210
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE("nrk:6021")
    assert(isinstance(ie, NRKSKoleIE))
    assert(ie._id == "6021")
    assert(ie._VALID_URL == None)


# Generated at 2022-06-24 13:07:01.730000
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test_case = NRKIE()
    assert (test_case._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        ''')


# Generated at 2022-06-24 13:07:06.873006
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    ie.url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert ie.match(ie.url) == 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

# Generated at 2022-06-24 13:07:08.876233
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'NRK:episodes'



# Generated at 2022-06-24 13:07:10.728241
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME

# Generated at 2022-06-24 13:07:13.812409
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE("NRKSkoleIE").extract("https://www.nrk.no/skole/?page=search&q=&mediaId=14099")

# Generated at 2022-06-24 13:07:15.505436
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Tests are sorted alphabetically.
    NRKTVDirekteIE()


# Generated at 2022-06-24 13:07:19.223866
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie._VALID_URL == NRKSkoleIE._VALID_URL
    assert ie.IE_DESC == NRKSkoleIE.IE_DESC
    assert ie.extract == NRKSkoleIE.extract


# Generated at 2022-06-24 13:07:20.912087
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    obj = NRKTVDirekteIE()
    assert obj.NAME == 'nrk'



# Generated at 2022-06-24 13:07:30.048920
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    argv = ['--username', NRKTVIE._TEST_USERNAME, '--password', NRKTVIE._TEST_PASSWORD]
    assert NRKTVEpisodeIE._TEST.startswith('https://tv.nrk.no/')
    assert NRKTVEpisodeIE._TEST.endswith('/sesong/1/episode/2')
    NRKTVEpisodeIE._real_initialize()
    try:
        NRKTVEpisodeIE(argv, test=True)
    except Exception as e:
        raise e
        assert False


# Generated at 2022-06-24 13:07:33.465627
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    assert NRKSkoleIE.suitable(url)
    assert NRKSkoleIE(url)._real_extract(url) == [{'id': '6021',
                                                   'ext': 'mp4',
                                                   'title': 'Genetikk og eneggede tvillinger',
                                                   'description': 'md5:3aca25dcf38ec30f0363428d2b265f8d',
                                                   'duration': 399}]


# Generated at 2022-06-24 13:07:38.405473
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ies = NRKTVEpisodesIE('NRKTV', 'NRK TV', 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert ies._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'
    assert ies._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ies._TESTS[0]['url'] == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert ies._TESTS[0]['info_dict']['id'] == '69031'
    assert ies._T

# Generated at 2022-06-24 13:07:45.895396
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """Unit test for constructor of class NRKIE"""

    from .nrktv import NRKTVIE
    from .nrkplay import NRKPlayIE

    url = 'http://www.nrk.no/video/PS*150533'
    nrk = NRKIE(NRKTVIE(), NRKPlayIE())
    info = nrk._real_extract(url)
    assert info == {
        'id': '150533',
        'ext': 'mp4',
        'title': 'Dompap og andre fugler i Piip-Show',
        'description': 'md5:d9261ba34c43b61c812cb6b0269a5c8f',
        'duration': 262,
    }


# Generated at 2022-06-24 13:07:50.626880
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        test_ie = NRKTVSerieBaseIE(None, {}, {}, {})
    except Exception as e:
        test_ie = None
    assert test_ie


# Generated at 2022-06-24 13:07:52.493804
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('youtube', "")
    print("NRKBaseIE init test OK")



# Generated at 2022-06-24 13:08:02.068047
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
    assert ie._extract_nrk_formats('https://not-a-real-url/', '123') is None