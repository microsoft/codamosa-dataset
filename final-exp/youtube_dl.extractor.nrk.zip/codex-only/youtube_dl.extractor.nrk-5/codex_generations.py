

# Generated at 2022-06-24 12:58:01.119403
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'

# Generated at 2022-06-24 12:58:10.427109
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Correct id
    nrk_skole_ie = NRKSkoleIE('https://nrkno-skole-prod.kube.nrk.no/skole/api/media/123')
    assert nrk_skole_ie.video_id == '123'

    # Invalid id
    with pytest.raises(ExtractorError):
        NRKSkoleIE('https://nrkno-skole-prod.kube.nrk.no/skole/api/media/a')

    # Missing id
    with pytest.raises(ExtractorError):
        NRKSkoleIE('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=')



# Generated at 2022-06-24 12:58:11.553000
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    info_extractor_instance = NRKPlaylistBaseIE()
    assert isinstance(info_extractor_instance, NRKPlaylistBaseIE)


# Generated at 2022-06-24 12:58:12.983364
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    a = NRKTVEpisodeIE()
    assert a._VALID_URL

# Generated at 2022-06-24 12:58:14.266582
# Unit test for constructor of class NRKIE
def test_NRKIE():
    instance = NRKIE()
    assert str(instance.IE_NAME) == "NRK"

# Generated at 2022-06-24 12:58:26.403325
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test that NRKTVSeriesIE supports catalog with instalments
    extractor = NRKTVSeriesIE()
    with pytest.raises(excepts.ExtractorError): # Test that IE not supported
        extractor._extract_assets_key({})
    extractor = NRKTVSeriesIE()
    assert 'instalments' == extractor._extract_assets_key({'instalments':None})

    # Test that NRKTVSeriesIE supports catalog with seasons
    extractor = NRKTVSeriesIE()
    assert 'episodes' == extractor._extract_assets_key({'episodes':None})

    # Test that NRKTVSeriesIE does not support catalog without seasons and instalments
    extractor = NRKTVSeriesIE()

# Generated at 2022-06-24 12:58:36.712406
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
	nrktvepisodesie = NRKTVEpisodesIE()
	assert nrktvepisodesie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
	assert nrktvepisodesie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 12:58:38.890482
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    game = NRKTVSeriesIE()
    assert game.suitable(url) == True
    assert game.suitable(url + 'test') == False

# Generated at 2022-06-24 12:58:40.182128
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert isinstance(NRKTVEpisodeIE(None), NRKTVEpisodeIE)


# Generated at 2022-06-24 12:58:43.696165
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    o = NRKRadioPodkastIE()
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = o.suitable(url)
    assert ie == True



# Generated at 2022-06-24 12:58:55.667450
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    import sys
    sys.path.append("../youtube_dl/YoutubeDL")
    sys.path.append("../youtube_dl")
    sys.path.append(".")
    from subprocess import Popen, PIPE
    from requests.compat import str
    import requests
    import json
    import pytest

    @pytest.mark.parametrize("NRK_url", ["http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763",
                                         "http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449"])

    def test_url_fetch(NRK_url):
        nrk_playlist_object

# Generated at 2022-06-24 12:59:05.659784
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    test_url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    result = NRKRadioPodkastIE().extract(test_url)
    expected_result = 'nrk:l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    print("expected_result: {}, result: {} ".format(expected_result, result))
    assert result == expected_result


# Generated at 2022-06-24 12:59:09.723449
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrkRadioPodkastIE = NRKRadioPodkastIE()
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrkRadioPodkastIE.suitable(url)

# Generated at 2022-06-24 12:59:11.527135
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-24 12:59:13.299365
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE().ie_key() == 'NRKSkole'


# Generated at 2022-06-24 12:59:20.475841
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk = NRKTVDirekteIE()
    assert nrk._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert nrk.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert nrk.ie_key() == 'NRKTVDirekte'



# Generated at 2022-06-24 12:59:25.539334
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant'
    content = compat_urlopen(url)
    extractor = NRKTVSeasonIE.new_from_url(url)
    assert(isinstance(extractor, NRKTVSeasonIE))


# Generated at 2022-06-24 12:59:32.423248
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_ie = NRKPlaylistIE()
    url = 'http://www.nrk.no/sport/fotball/forfulgt-over-hundre-meter-i-drammen-1.12271020'
    assert test_ie._match_id(url) is not None
    assert test_ie._match_id('') is None
    assert test_ie._ITEM_RE is not None



# Generated at 2022-06-24 12:59:41.781772
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE(): # pylint: disable=invalid-name
    ie_test = NRKTVEpisodeIE()
    result = ie_test._real_extract('https://tv.nrk.no/serie/backstage/sesong/1/episode/8') # pylint: disable=protected-access
    assert result['id'] == 'MSUI14000816'
    assert result['season_number'] == 1
    assert result['episode_number'] == 8
    assert result['duration'] == 1320
    assert result['_type'] == 'url'
    assert result['series'] == 'Backstage'
    assert result['url'] == 'nrk:MSUI14000816'
    assert result['ie_key'] == 'NRK'

# Generated at 2022-06-24 12:59:46.908883
# Unit test for constructor of class NRKIE
def test_NRKIE():
    IE = NRKIE('nrk:program/ENRK10100318')
    assert IE.IE_NAME == 'NRK'
    assert IE._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''


# Generated at 2022-06-24 12:59:56.392999
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    test_url = 'http://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    print(NRKRadioPodkastIE(), test_url)

NRK_SUBS = {
    'no': 'nrksupport@nrk.no',
    'en': 'nrksupport@nrk.no',
    'sv': 'nrksupport@nrk.no',
    'nb': 'nrksupport@nrk.no',
    'nn': 'nrksupport@nrk.no',
    'sk': 'podpora@nrk.no',
}



# Generated at 2022-06-24 13:00:00.917574
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    URL = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    ID = 'MUHH36005220'
    extractor = NRKTVEpisodeIE()
    info = extractor._real_extract(URL)
    # Check if the extracted id is the same as the one in the URL.
    if info['id'] != ID:
        sys.exit("Error: Expected id: " + ID + " got: " + info["id"])

if __name__ == "__main__":
    test_NRKTVEpisodeIE()

# Generated at 2022-06-24 13:00:09.715010
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    """ test constructor for class NRKSkoleIE """
    print("\nUnit test for constructor of class NRKSkoleIE")
    # Case 1:
    # input:
    #   nrk_id = 6021
    # expected result:
    #   NRKSkoleIE.nrk_id = 6021
    print("\nCase 1:")
    nrk_id = 6021
    NRKSkoleIEDut = NRKSkoleIE(nrk_id)
    print("Test result: ", "Passed"
          if NRKSkoleIEDut.nrk_id == nrk_id else "Failed")


# Generated at 2022-06-24 13:00:21.932765
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Test if extracting a NRKTVEpisodeIE works
    # NOTE: In the test above we are using a NRKTVEpisodeIE instead of the NRKTVIE to check if this
    # actually works. From now on only use the NRKTVIE to extract info.
    NRKTVEpisodeIE._download_webpage = _test_download_webpage
    NRKTVEpisodeIE._search_json_ld = _test_search_json_ld
    NRKTVEpisodeIE._html_search_meta = _test_search_meta
    NRKTVEpisodeIE._search_regex = _test_search_regex

    ie = NRKTVEpisodeIE()
    ie.extract('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')

# Generated at 2022-06-24 13:00:24.688147
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # no exception should be raised
    try:
        NRKPlaylistBaseIE()
    except:
        pytest.fail('NRKPlaylistBaseIE() raises exception')



# Generated at 2022-06-24 13:00:29.694543
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('https://www.nrk.no/telemarksavisa/a-%c3%b8demark-1.12783633')
    assert NRKPlaylistIE.suitable('https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert NRKPlaylistIE.suitable('https://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
    assert NRKPlaylistIE.suitable('https://www.nrk.no/rogaland/a-%c3%b8demark-1.12783633')

# Generated at 2022-06-24 13:00:31.573406
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE()._build_url('foo') == 'https://tv.nrk.no/serie/foo#'
    assert NRKTVIE()._build_url('foo', 'bar') == 'https://tv.nrk.no/serie/foo/bar#'

# Generated at 2022-06-24 13:00:39.164920
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """Unit test for constructor of class NRKTVEpisodeIE"""
    nrk_ep = NRKTVEpisodeIE('NRKTVEpisodeIE', '')
    assert(hasattr(nrk_ep, '_VALID_URL'))
    assert(nrk_ep._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))')



# Generated at 2022-06-24 13:00:40.470227
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE("NRKPlaylistBaseIE")


# Generated at 2022-06-24 13:00:44.684866
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Construct an instance of NRKBaseIE and call its test method
    NRKBaseIE()._test_valid_url(NRKBaseIE.IE_NAME, 'http://tv.nrk.no/serie/100-hager')



# Generated at 2022-06-24 13:00:54.458648
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    obj = NRKRadioPodkastIE()
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    expected_url = 'nrk:l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    actual_url = obj.url_result(url, 'NRKIE').url
    assert actual_url == expected_url


# Generated at 2022-06-24 13:00:56.100156
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE("NRKBaseIE")



# Generated at 2022-06-24 13:00:57.690595
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from .nrk import NRKBaseIE

    assert NRKBaseIE.from_url('https://tv.nrk.no/serie/meryvn') == NRKTVSeriesIE

# Generated at 2022-06-24 13:01:05.743010
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    try:
        NRKRadioPodkastIE('http://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    except Exception as e:
        print(e)
        raise

if __name__ == '__main__':
    test_NRKRadioPodkastIE()

# Generated at 2022-06-24 13:01:07.213227
# Unit test for constructor of class NRKIE
def test_NRKIE():
    global NRKIE
    NRKIE = NRKIE()


# Generated at 2022-06-24 13:01:16.996784
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert ie._TESTS[0]['url'] == 'http://www.nrk.no/video/PS*150533'


# Generated at 2022-06-24 13:01:27.500328
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    nrk_skole_id = '14099'
    nrk_skole_psId = '6021'

# Generated at 2022-06-24 13:01:37.764450
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    obj = NRKPlaylistBaseIE('IEKey', 'regex', '_download_webpage')
    obj.to_screen = lambda *args, **kwargs: None # Silence to_screen() output in unit test
    obj.url_result = lambda *args, **kwargs: None # Silence url_result() output in unit test
    obj.playlist_result = lambda *args, **kwargs: None # Silence playlist_result() output in unit test
    try:
        obj._real_extract('http://www.tv.no/program-d19f1cac-7fb9-4e9f-8a8b-f875e0a24bca')
    except UnavailableVideoError:
        pass

# Generated at 2022-06-24 13:01:49.805026
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # variables
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    video_id = '14099'
    nrk_id = '6021'
    # create NRKSkoleIE
    NRKSkole = NRKSkoleIE()
    # assert that it doesn't fail
    assert NRKSkole._match_id(url) == video_id
    # assert that it return a valid id
    assert NRKSkole._download_json(
            'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/%s' % video_id,
            video_id)['psId'] == nrk_id


# Generated at 2022-06-24 13:01:52.615279
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    try:
        NRKSkoleIE()
    except:
        assert False, "Can not instantiate class NRKSkoleIE"
        raise
    assert True


# Generated at 2022-06-24 13:02:04.266145
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Test NRKTVEpisodeIE._VALID_URL
    from extractor import Extractor
    from extractor.common import InfoExtractor
    from extractor.nrk import NRKTVEpisodeIE
    ie = NRKTVEpisodeIE("")
    ie.extractor = Extractor()
    ie.extractor.IE_DESC = "Extractor is an instance of InfoExtractor"

    assert NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

    # Test _real_extract

# Generated at 2022-06-24 13:02:05.401498
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('nrk:123')



# Generated at 2022-06-24 13:02:07.117320
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Unwrap the constructor and check that it doesn't raise any exceptions
    NRKSkoleIE._NRKSkoleIE__initialize()


# Generated at 2022-06-24 13:02:09.407529
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .nrktv import NRKTVDirekteIE
    ie = NRKTVDirekteIE();
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-24 13:02:18.928040
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk = NRKSkoleIE()
    assert nrk._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert nrk._TESTS[0]['url'] == 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    assert nrk._TESTS[0]['md5'] == '18c12c3d071953c3bf8d54ef6b2587b7'
    assert nrk._TESTS[0]['info_dict']['id'] == '6021'
    assert nrk._TESTS[0]['info_dict']['ext'] == 'mp4'


# Generated at 2022-06-24 13:02:21.244493
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie_NRKTVEpisodes = NRKTVEpisodesIE()
    assert ie_NRKTVEpisodes

# Generated at 2022-06-24 13:02:24.930738
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    #NRKBaseIE is not meant to be instantiated (it is an abstract class)
    try:
        ie = NRKBaseIE('test', 'query', {})
    except TypeError:
        pass


# Generated at 2022-06-24 13:02:36.166242
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE(None)
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 13:02:39.038187
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    with pytest.raises(TypeError):
        NRKTVSerieBaseIE(NRKBaseIE.ie_key(), 'NRKTVSerieBaseIE')



# Generated at 2022-06-24 13:02:48.528737
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'http://www.nrk.no/kultur/toppsaker/1.11330148'
    token = '8be0f6b850795c4ad4aad4f8e9ac6f06'
    self = NRKPlaylistBaseIE(token)
    self.URL_BASE = 'http://www.nrk.no'
    self.TOKEN = '8be0f6b850795c4ad4aad4f8e9ac6f06'

# Generated at 2022-06-24 13:02:49.600599
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    with pytest.raises(AssertionError) as excinfo:
        assert not NRKTVEpisodeIE('foo')



# Generated at 2022-06-24 13:02:50.582137
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:02:51.492394
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()

# Generated at 2022-06-24 13:03:02.581208
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    """Test constructor of class NRKPlaylistIE"""
    # create a test instance
    inst_obj = NRKPlaylistIE()
    # test url
    assert inst_obj._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    # test _ITEM_RE
    assert inst_obj._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    # test suitable
    assert inst_obj.suitable('https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert inst_obj

# Generated at 2022-06-24 13:03:06.967839
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrkradio_podkast_ie = NRKRadioPodkastIE()
    nrkradio_podkast_ie.suitable(url)
    nrkradio_podkast_ie.extract(url)
# ==================END OF NRK RADIO PODKAST==================



# Generated at 2022-06-24 13:03:08.989701
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/lindmo/sesong/1/AVSYN'
    inst = NRKPlaylistBaseIE()
    inst.suitable(url)
    inst._real_extract(url)


# Generated at 2022-06-24 13:03:17.892247
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank/sesong/1/episode/1/innhold'
    assert NRKTVSeriesIE.suitable(url), "NRKTVSeriesIE.suitable is wrong"
    obj = NRKTVSeriesIE.from_url(url)
    assert obj != None, "NRKTVSeriesIE.from_url is wrong"
    assert obj.__class__.__name__ == 'NRKTVSeriesIE', "NRKTVSeriesIE.from_url is wrong"

# Generated at 2022-06-24 13:03:26.975411
# Unit test for constructor of class NRKIE
def test_NRKIE():
    print('test_NRKIE')
    ie = NRKIE()
    video_id = 'MDDP12000117'
    path_templ = 'playback/%s/' + video_id
    print('test _call_api')
    manifest = ie._call_api(path_templ % 'manifest', video_id, 'manifest', {'preferredCdn': 'akamai'})
    print('test _raise_error')
    ie._raise_error(manifest['nonPlayable'])
    print('test _real_extract')
    ie._real_extract('nrk:MDDP12000117')


# Generated at 2022-06-24 13:03:30.888549
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2'
    NRKTVIE()._real_extract(url)

# Generated at 2022-06-24 13:03:34.960326
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE._ITEM_RE == r'data-episode=["\']\d{4}\/\d{2}\/\d{2}\/(?:\d+\/)*\d{4}'


# Generated at 2022-06-24 13:03:43.146342
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE()._GEO_COUNTRIES == ['NO']
    assert NRKBaseIE()._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''



# Generated at 2022-06-24 13:03:48.081689
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE()._GEO_COUNTRIES == ['NO']
    assert re.match(NRKBaseIE()._CDN_REPL_REGEX, '//nrkod%02d-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0')



# Generated at 2022-06-24 13:03:57.515075
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    serie = 'leo-dra-og-spiser'
    site = 'tv.nrk.no'
    serie_kind = 'serie'
    series_id = serie
    titles = {'title': 'Leo da og spiser', 'subtitle': 'subtitle'}
    episodes = [
        {'prfId': 'MSUI12002616', 'title': 'Episode 1'},
        {'prfId': 'MSUI12002617', 'title': 'Episode 2'},
    ]

# Generated at 2022-06-24 13:04:08.957917
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    import logging
    logging.basicConfig(level = logging.DEBUG)

    print("Running unit test for class NRKTVIE")

    # Test for a single playlist video
    urls = [
        "https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2"
    ]

    for url in urls:
        ie = NRKTVIE()
        ie.extract(url)

    # Test for videos with age restriction
    urls = [
        "https://tv.nrk.no/serie/fossegrim/NLEP24024016/04-02-2016",
    ]

    for url in urls:
        ie = NRKTVIE()

# Generated at 2022-06-24 13:04:15.873191
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE(): # pylint: disable=W0621
    fake_url = "https://www.nrk.no/skole/?page=search&q=&mediaId=14099"
    fake_id = "14099"
    fake_nrk_id = "6021"
    NRKSkole = NRKSkoleIE(NRKBaseIE._downloader)
    NRKSkole.url = fake_url
    NRKSkole.video_id = fake_id
    NRKSkole.nrk_id = fake_nrk_id
    eq_(NRKSkole.url, fake_url)
    eq_(NRKSkole.video_id, fake_id)
    eq_(NRKSkole.nrk_id, fake_nrk_id)


# Generated at 2022-06-24 13:04:28.733527
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    webpage = 'Irrelevant'
    NRKPlaylistIE._extract_title = lambda x: 'Title'
    NRKPlaylistIE._extract_description = lambda x: 'Description'

    playlist = NRKPlaylistIE._real_extract(NRKPlaylistIE(), url, webpage)


# Generated at 2022-06-24 13:04:39.750356
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # The webpages of two different types
    arg_list = [('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763', 'gjenopplev-den-historiske-solformorkelsen-1.12270763'),
                ('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449', 'rivertonprisen-til-karin-fossum-1.12266449')]
    for url, playlist_id in arg_list:
        playlist_nrk = NRKPlaylistIE(_download_webpage(url, playlist_id))
        assert playlist_nrk.playlist_id == playlist_id


# Generated at 2022-06-24 13:04:52.365018
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from youtube_dl.utils import SearchInfoExtractor
    from youtube_dl.extractor.generic import YoutubeSearchIE
    KEYS = ('id', 'url', 'title', 'description', 'thumbnail', 'duration')
    nrk_serie_ie = NRKTVSeriesIE()
    nrk_episode_ie = NRKTVEpisodeIE()
    result = nrk_serie_ie._real_extract('http://tv.nrk.no/serie/blank')

    assert(result['id'] == 'blank')
    assert(result['title'] == 'Blank')
    assert(result['description'] == 'md5:7664b4e7e77dc6810cd3bca367c25b6e')
    assert(len(result['entries']) == 30)

# Generated at 2022-06-24 13:04:56.993892
# Unit test for constructor of class NRKIE
def test_NRKIE():
    '''
    Test case for constructing NRKIE
    :return: None
    '''
    try:
        NRKIE()
    except Exception as e:
        # classes that extend NRKBaseIE can raise GeoRestrictedError
        if not isinstance(e, ExtractorError):
            raise e



# Generated at 2022-06-24 13:05:01.799133
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    example_nrk_id = 'https://www.nrk.no/natur/genetiske-koder-1.12176327'
    example_id = '14099'
    ie = NRKSkoleIE(example_nrk_id, example_id)
    assert ie.video_id == example_id


# Generated at 2022-06-24 13:05:04.244005
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """
    Make sure that the constructor of the class works.
    """
    assert(NRKPlaylistBaseIE(NRKPlaylistBaseIE.ie_key(), NRKPlaylistBaseIE._VALID_URL) is not None)



# Generated at 2022-06-24 13:05:09.282025
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    try:
        NRKTVDirekteIE(NRKTVDirekteIE.ie_key(), 'NRK TV Direkte and NRK Radio Direkte')
    except Exception:
        raise AssertionError('Constructor NRKTVDirekteIE(NRKTVDirekteIE.ie_key(), \'NRK TV Direkte and NRK Radio Direkte\') not working');

    return;


# Generated at 2022-06-24 13:05:17.419554
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    test_url_1 = 'https://tv.nrk.no/serie/jul-i-blaafarveværket/sesong/1'
    test_url_2 = 'https://tv.nrk.no/serie/lindmo/2016'
    test_url_3 = 'https://radio.nrk.no/podkast/hele_historien/'
    assert NRKTVSeasonIE.suitable(test_url_1) is True
    assert NRKTVSeasonIE.suitable(test_url_2) is True
    assert NRKTVSeasonIE.suitable(test_url_3) is False



# Generated at 2022-06-24 13:05:22.086050
# Unit test for constructor of class NRKIE
def test_NRKIE():
	url = "https://www.nrk.no/mp/30gdl5/"
	nrk = NRKIE('NRK.no')

# Generated at 2022-06-24 13:05:22.966095
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    pass


# Generated at 2022-06-24 13:05:29.515443
# Unit test for constructor of class NRKBaseIE

# Generated at 2022-06-24 13:05:32.419147
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME == 'NRK'
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == ''


# Generated at 2022-06-24 13:05:41.373421
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL == r'''(?x)
        https?://
            (?P<domain>tv|radio)\.nrk\.no/
            (?P<serie_kind>serie|pod[ck]ast)/
            (?P<serie>[^/]+)/
            (?:
                (?:sesong/)?(?P<id>\d+)|
                sesong/(?P<id_2>[^/?#&]+)
            )'''


# Generated at 2022-06-24 13:05:47.783536
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """Test extracting NRKTVSeasonIE."""
    nrk_tv_season = NRKTVSeasonIE().url_result('https://tv.nrk.no/serie/helt-perfekt/sesong/2')
    assert nrk_tv_season is not None
    assert nrk_tv_season.id == 'helt-perfekt/2'
    assert nrk_tv_season.title == 'Sesong 2'


# Generated at 2022-06-24 13:05:59.483920
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE()
    ie._downloader = FakeDownloader()
    ie._call_api = lambda *args, **kwargs: {
        'urls': [{'type': 'mp4', 'url': 'https://download.com/.../video.mp4'}],
    }
    result = ie.extract(url)
    assert result['id'] == 'MUHH48000314AA'


# Generated at 2022-06-24 13:06:02.640353
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebaseie = NRKTVSerieBaseIE()
    ASSERT_TRUE(nrktvseriebaseie)


# Generated at 2022-06-24 13:06:07.914599
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE('NRK TV')
    assert ie.IE_NAME == 'nrk:tv'
    assert ie.IE_DESC == 'NRK TV'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'


# Generated at 2022-06-24 13:06:10.290929
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie._VALID_URL(
        'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')



# Generated at 2022-06-24 13:06:12.546869
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    for t in (NRKTVSerieIE, NRKTVEpisodeIE, NRKTVPlaylistIE):
        assert t.__bases__[0] == NRKTVSerieBaseIE, t.__name__



# Generated at 2022-06-24 13:06:13.541756
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE(NRKBaseIE())._VALID_URL == ''


# Generated at 2022-06-24 13:06:14.551303
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    """
    Constructor should not raise error
    """
    NRKTVSerieBaseIE()


# Generated at 2022-06-24 13:06:15.468378
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    for url in NRKTVEpisodesIE._TESTS:
        NRKTVEpisodesIE(url)



# Generated at 2022-06-24 13:06:16.349433
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE('NRKTVEpisodesIE', 'nrkplaylistbaseie')


# Generated at 2022-06-24 13:06:17.332725
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    try:
        NRKTVEpisodesIE()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-24 13:06:22.735057
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE.ie_key()
    # According to https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/nrk.py#L85
    assert ie != 'nrk:programs'
    assert ie != 'nrk:series'
    assert ie != 'nrk:seasons'



# Generated at 2022-06-24 13:06:24.661191
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE('NRKTVEpisodesIE', 'http://tv.nrk.no/program/episodes/nytt-paa-nytt/69031', {})

# Generated at 2022-06-24 13:06:29.661762
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    def _test(url, expected_url, expected_id, expected_class):
        result_url, result_id, result_class = NRKRadioPodkastIE._parse_url(url)
        assert (result_url, result_id, result_class) == (expected_url, expected_id, expected_class)
    # A valid URL

# Generated at 2022-06-24 13:06:32.174753
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # pylint: disable=W0212
    ie = NRKTVDirekteIE()
    assert ie._VALID_URL == NRKTVDirekteIE._VALID_URL
    assert ie.IE_NAME == 'nrk:direkte'


# Generated at 2022-06-24 13:06:33.981382
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE('nrk:l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')


# Generated at 2022-06-24 13:06:45.896572
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    season = NRKTVSeasonIE('https://tv.nrk.no/serie/lindmo/2016')
    assert season.domain == 'tv'
    assert season.serie_kind == 'serie'
    assert season.serie == 'lindmo'
    assert season.season_id == '2016'
    season = NRKTVSeasonIE('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')
    assert season.domain == 'radio'
    assert season.serie_kind == 'podkast'
    assert season.serie == 'hele_historien'
    assert season.season_id == 'diagnose-kverulant'



# Generated at 2022-06-24 13:06:51.249106
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist_extractor = NRKPlaylistIE()
    assert playlist_extractor._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert playlist_extractor._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-24 13:06:56.395236
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrk_season = NRKTVSeasonIE('NRKTVSeasonIE', 'https://tv.nrk.no/serie/backstage/sesong/1', {})
    assert nrk_season.ie_key() == 'NRKTV'
    assert 'NRKTV' in NRKTVIE.embed_webpage



# Generated at 2022-06-24 13:07:05.294947
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url='http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    ie = NRKPlaylistIE(gen_extractors(), url)
    assert ie._match_id(url) == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    assert ie._ITEM_RE == 'class="[^"]*\\brich\\b[^"]*"[^>]+data-video-id="([^"]+)"'
    # Call _extract_title() method

# Generated at 2022-06-24 13:07:06.049915
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()

# Generated at 2022-06-24 13:07:09.348093
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    data = {
        'title': 'Moomin',
    }
    try:
        NRKTVEpisodeIE(data)
        assert(False)
    except:
        assert(True)


# Generated at 2022-06-24 13:07:13.956972
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert isinstance(ie, InfoExtractor)
    assert issubclass(NRKSkoleIE, InfoExtractor)
    assert issubclass(NRKSkoleIE, NRKBaseInfoExtractor)


# Generated at 2022-06-24 13:07:18.172313
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    season_obj = NRKTVSeasonIE()
    assert season_obj._VALID_URL is not None
    assert season_obj._TESTS is not None
    assert season_obj.suitable(season_obj._VALID_URL) is not True


# Generated at 2022-06-24 13:07:23.065501
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    nrk_radio_podkast_ie.suitable('')
    nrk_radio_podkast_ie._real_extract('')
    nrk_radio_podkast_ie._call_api('')
    nrk_audio_url_result = nrk_radio_podkast_ie._call_api('')
    nrk_audio_url_result.get_video_info()
    nrk_audio_url_result._download_json('')
    nrk_audio_url_result._download_webpage_handle('')
    nrk_radio_podkast_ie._call_api('')


# Generated at 2022-06-24 13:07:34.679474
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE(None)
    assert ie.suitable is None
    assert ie.ie_key() is None
    assert ie.description is None
    assert ie.extractor_key() is None
    assert ie._VALID_URL is None
    assert ie._TESTS is None
    assert ie._BASE_URL is None
    assert ie._API_BASE_URL is None
    assert ie._API_KEY is None
    assert ie._LATEST_URL is None
    assert ie._LATEST_URL_HOST is None
    assert ie._EMBED_URL is None
    assert ie._EMBED_URL_RE is None
    assert ie._NETRC_MACHINE is None

    NRKTVSeasonIE._assert_url(None)

# Generated at 2022-06-24 13:07:39.682760
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    podkast_ie = NRKRadioPodkastIE()
    assert podkast_ie.suitable(NRKRadioPodkastIE._VALID_URL)
    assert podkast_ie.IE_NAME == 'NRK:radio:podkast'
    assert podkast_ie._VALID_URL == NRKRadioPodkastIE._VALID_URL


# Generated at 2022-06-24 13:07:41.849591
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('NRKPlaylistBaseIE', 'http://www.nrk.no/bla')

    assert ie is not None



# Generated at 2022-06-24 13:07:46.250340
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie_object = NRKPlaylistBaseIE()
    info_dict = {
        'id': 'MUHH48000314AA',
        'ext': 'mp4',
        'title': '20 spørsmål 23.05.2014',
        'description': 'md5:bdea103bc35494c143c6a9acdd84887a',
        'duration': 1741,
        'series': '20 spørsmål',
        'episode': '23.05.2014',
    }
    url = ie_object.url_result('nrk:%s' % info_dict["id"], NRKIE.ie_key())

# Generated at 2022-06-24 13:07:58.421558
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE('http://www.nrk.no/skole/?mediaId=14099')
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    #assert ie._TESTS[0]['md5'] == '18c12c3d071953c3bf8d54ef6b2587b7'
    assert ie._TESTS[0]['info_dict']['id'] == '6021'