

# Generated at 2022-06-24 12:57:55.941670
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE()


# Generated at 2022-06-24 12:58:04.307609
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert isinstance(NRKRadioPodkastIE, type)
    # These tests are run for each feature of the extracted page
    assert NRKRadioPodkastIE._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-24 12:58:05.114390
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE(None)



# Generated at 2022-06-24 12:58:09.973818
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._VALID_URL == r'https?://play\.nrk\.no/playlist/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'<a[^>]+href="/serie/[^/]+/sesong/[^/]+/episode/\d+" class="link-section" title="[^"]+">\s+<div class="nrk-image[^>]+><img[^>]+src="(?P<item_id>[^"]+)"[^>]+>\s+</div>'
    assert ie._TESTS == []


# Generated at 2022-06-24 12:58:11.640504
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        NRKBaseIE()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 12:58:17.421674
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test NRKTVDirekteIE.suitable function
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1')
    assert NRKTVDirekteIE.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1/123')
    assert not NRKTVDirekteIE.suitable('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')



# Generated at 2022-06-24 12:58:18.451574
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    a = NRKSkoleIE()


# Generated at 2022-06-24 12:58:22.729906
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert re.match(NRKTVEpisodeIE._VALID_URL, url)
    NRKTVEpisodeIE(NRKTVEpisodeIE.suitable(url))


# Generated at 2022-06-24 12:58:27.010156
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from youtube_dl.extractor.nrktv import NRKTVSeriesIE
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/hellums-kro')

# Generated at 2022-06-24 12:58:31.498086
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    URL = 'https://tv.nrk.no/direkte/nrk1'

# Generated at 2022-06-24 12:58:41.156022
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """Test constructor of class NRKPlaylistBaseIE"""
    url = 'https://tv.nrk.no/programmer/speilet'

    # Remove format parameter, get correct test url
    url_test = re.sub(r'[?&]format=[a-z0-9]*', '', url)

    # Check if the test url exist in tests
    if not any(re.match(_TESTS['url'], url_test) for _TESTS in NRKPlaylistBaseIE._TESTS):
        return

    # Dynamically create a test class based on the url

# Generated at 2022-06-24 12:58:42.277670
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE().ie_key() == 'NRKTV'


# Generated at 2022-06-24 12:58:43.680144
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    b = NRKTVEpisodeIE()
    print(b)

# Generated at 2022-06-24 12:58:45.794774
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert isinstance(NRKTVSerieBaseIE(NRKBaseIE),
                      NRKTVSerieBaseIE)



# Generated at 2022-06-24 12:58:47.659980
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test = NRKPlaylistIE()


# Generated at 2022-06-24 12:59:00.524462
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    def mock_call_api(url, display_id, note, fatal=True):
        if url.endswith('/episodes'):
            return {
                '_embedded': {
                    'episodes': {
                        '_embedded': {
                            'episodes': [
                                {
                                    'prfId': '1'
                                }
                            ],
                            'instalments': [
                                {
                                    'episodeId': '2'
                                }
                            ]
                        }
                    },
                }
            }
        return {}

    def mock_nrktv_extractor(url):
        return url

    ie = NRKTVSerieBaseIE({
        '_call_api': mock_call_api,
    })
    ie.url_result = mock_nrktv

# Generated at 2022-06-24 12:59:04.325668
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    testobj = NRKTVIE()
    assert testobj._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % testobj._EPISODE_RE

if __name__ == '__main__':
    test_NRKTVIE()

# Generated at 2022-06-24 12:59:06.266562
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE(NRKTVDirekteIE.ie_key())

# Generated at 2022-06-24 12:59:07.937180
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKIE()
    ie = NRKTVEpisodeIE()

# Generated at 2022-06-24 12:59:10.625906
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    item = NRKSkoleIE('https://nrkno-skole-prod.kube.nrk.no/skole/api/media/14099')
    item.download()

# Generated at 2022-06-24 12:59:16.242084
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """ test_NRKTVSeriesIE() """
    url = 'https://tv.nrk.no/serie/groenn-glede'
    series_ie = NRKTVSeriesIE()
    series_ie._real_initialize()
    assert series_ie.suitable(url)


# Generated at 2022-06-24 12:59:21.955104
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktv_direkte_IE = NRKTVDirekteIE()
    nrktv_IE = NRKTVIE()
    nrk_IE = NRKIE()
    nrk_IE.ie_key()
    nrktv_IE.ie_key()
    nrktv_direkte_IE.ie_key()
    assert NRKTVDirekteIE.ie_key() == 'NRKTVDirekte'
    assert nrktv_direkte_IE.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert NRKTVIE.ie_key() == 'NRKTV'
    assert NRKIE.ie_key() == 'NRK'
    assert nrktv_direkte_

# Generated at 2022-06-24 12:59:24.400439
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX

# Generated at 2022-06-24 12:59:28.028258
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test = NRKTVEpisodesIE()
    test._real_extract('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')



# Generated at 2022-06-24 12:59:38.511080
# Unit test for constructor of class NRKTVSeasonIE

# Generated at 2022-06-24 12:59:44.391959
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # First test: program metadata
    metadata_url = 'https://v8.psapi.nrk.no/mediaelement/b17be115-6144-4932-a215-e115b144493b'
    data = compat_urllib_request.urlopen(metadata_url).read()

    data_dict = json.loads(data.decode())
    nrktivie = NRKTVIE(NRKTVIE.ie_key(), metadata_url, data_dict)

    info = nrktivie._extract_info(data_dict)
    print(info)

    #assert(info['age_limit'] == '12')
    #assert(info['description'] == 'Four women come together to form the "Mystikal Mistress" wrestling team.')
    #assert(info['title'] == 'Myst

# Generated at 2022-06-24 12:59:46.968626
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    instance = NRKTVSeasonIE(None, None, None)
    instance._extract_entries()



# Generated at 2022-06-24 12:59:55.504088
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():

    url1 = 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant'
    url2 = 'https://radio.nrk.no/serie/dagsnytt/sesong/201509'
    url3 = 'https://radio.nrk.no/podkast/loerdagsraadet/sesong/202101'

    Season1 = NRKTVSeasonIE.suitable(url1)
    Season2 = NRKTVSeasonIE.suitable(url2)
    Season3 = NRKTVSeasonIE.suitable(url3)

    Season = Season1 or Season2 or Season3

    assert(Season)


# Generated at 2022-06-24 12:59:56.265677
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE(NRKSkoleIE._WORKING_URL)

# Generated at 2022-06-24 13:00:01.703189
# Unit test for constructor of class NRKBaseIE

# Generated at 2022-06-24 13:00:04.193475
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')



# Generated at 2022-06-24 13:00:08.477281
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    valid_url = NRKPlaylistIE._VALID_URL
    valid_re = NRKPlaylistIE._ITEM_RE
    assert re.match(valid_url, valid_url)
    assert re.match(valid_re, valid_re)

# Generated at 2022-06-24 13:00:13.110425
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._VALID_URL == 'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert NRKPlaylistIE._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert NRKPlaylistIE._TESTS[0]['info_dict']['id'] == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    assert NRKPlaylistIE._TESTS[0]['info_dict']['title'] == 'Gjenopplev den historiske solformørkelsen'
    assert NRKPlaylistIE._T

# Generated at 2022-06-24 13:00:18.027011
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE(None, url='https://tv.nrk.no/serie/groenn-glede', expected_type='serie')
    NRKTVSeriesIE(None, url='https://radio.nrk.no/podkast/hele_historien', expected_type='podkast')


# Generated at 2022-06-24 13:00:19.002510
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test=NRKTVEpisodesIE()
    print(test._TESTS)


# Generated at 2022-06-24 13:00:31.408074
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Used to create an instance of NRKTVSeasonIE
    # Used to set the value of the attribute _VALID_URL
    url_test = 'https://tv.nrk.no/serie/backstage/sesong/1'
    test_class = NRKTVSeasonIE()
    # The following checks whether there is an instance of the NRKTVSeasonIE class created
    # 1. 2 are equal if they are the same object or
    # 2. type(test_class) == type(NRKTVSeasonIE)
    assert (test_class is NRKTVSeasonIE) or type(test_class) == type(NRKTVSeasonIE)
    # Call function suitable() of class NRKTVSeasonIE to check whether the url_test is in _VALID_URL
    result = test_class.suitable(url_test)
    #

# Generated at 2022-06-24 13:00:41.492896
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from youtube_dl.extractor import get_info_extractor
    info_extractor = get_info_extractor('NRKTVSeasonIE')
    assert not info_extractor.suitable('https://tv.nrk.no/')
    assert not info_extractor.suitable('https://tv.nrk.no/program')
    assert not info_extractor.suitable('https://tv.nrk.no/serie/dagsrevyen')
    assert not info_extractor.suitable('https://tv.nrk.no/serie/lindmo')
    assert not info_extractor.suitable('https://tv.nrk.no/serie/lindmo/2016/MUHU11000616/avspiller')

# Generated at 2022-06-24 13:00:44.517055
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk = NRKBaseIE()
    assert nrk
    assert nrk._GEO_COUNTRIES == ['NO']



# Generated at 2022-06-24 13:00:49.914587
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    ie = NRKTVSeriesIE()
    assert ie.suitable(url)
    ie = NRKTVSeriesIE(url)
    ie.updates()
    ie.download()

# Generated at 2022-06-24 13:00:52.386275
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL
    assert ie._ITEM_RE
    assert ie._TESTS

# Generated at 2022-06-24 13:00:54.777684
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktv_season_ie = NRKTVSeasonIE()
    assert nrktv_season_ie is not None



# Generated at 2022-06-24 13:01:02.395004
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    nrk._download_json('http://psapi.nrk.no/playback/manifest/', 'test', 'Downloading manifest JSON')
    nrk._download_json('http://psapi.nrk.no/playback/manifest/test', 'test', 'Downloading manifest JSON', headers={'Accept-Encoding': 'gzip, deflate, br'})


# Generated at 2022-06-24 13:01:06.582710
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    playlist = NRKTVEpisodesIE.suitable(url)

    assert(playlist)

# Generated at 2022-06-24 13:01:15.073828
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    class _TestingNRKRadioPodkastIE(NRKRadioPodkastIE):
        def _real_extract(self, url):
            return self.url_result(None)
    ie = _TestingNRKRadioPodkastIE()
    # Check response of method _real_extract
    assert ie._real_extract(Url("https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8").url)
    # Check specific unit test

# Generated at 2022-06-24 13:01:17.938109
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Example of a NRKTVSeasonIE constructor call
    test_call_object = NRKTVSeasonIE('https://tv.nrk.no/serie/backstage/sesong/1')
    # Print out the _VALID_URL constant
    print(test_call_object._VALID_URL)



# Generated at 2022-06-24 13:01:23.993750
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    extracted_result = NRKRadioPodkastIE()._real_extract(url)

# Generated at 2022-06-24 13:01:32.547546
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    def _test_nrktvseasonie(url, expected_result):
        season_ie = NRKTVSeasonIE(verbose=True)
        mobj = re.match(season_ie._VALID_URL, url)
        domain = mobj.group('domain')
        serie_kind = mobj.group('serie_kind')
        serie = mobj.group('serie')
        season_id = mobj.group('id') or mobj.group('id_2')
        display_id = '%s/%s' % (serie, season_id)


# Generated at 2022-06-24 13:01:39.358329
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE._ASSETS_KEYS = ['episodes', 'instalments',]
    assert NRKTVSerieBaseIE._catalog_name('podcast') is 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') is 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('') is 'series'



# Generated at 2022-06-24 13:01:45.388433
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    myModule = NRKSkoleIE()
    assert myModule._VALID_URL == 'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)', "The URL obtained by the constructor of the class is not correct"


# Generated at 2022-06-24 13:01:46.689278
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    instance = NRKTVEpisodeIE('')
    instance.suite()


# Generated at 2022-06-24 13:01:48.133492
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    class_ = NRKRadioPodkastIE()
    assert class_ is not None

# Generated at 2022-06-24 13:01:51.969700
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    NRKRadioPodkastIE._real_extract(url)


# Generated at 2022-06-24 13:02:00.644886
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteIE = NRKTVDirekteIE()
    assert nrktvdirekteIE.NAME == "NRK TV Direkte"
    assert nrktvdirekteIE.IE_NAME == "nrktvdirekte"
    assert nrktvdirekteIE.ie_key() == "NRKTVDirekte"
    assert nrktvdirekteIE.ie == "NRKTVDirekte"
    assert nrktvdirekteIE._VALID_URL == "https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 13:02:06.346718
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(None)
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._catalog_name(serie_kind=None) == 'series'
    assert ie._catalog_name(serie_kind='series') == 'series'
    assert ie._catalog_name(serie_kind='podkast') == 'podcast'
    assert ie._catalog_name(serie_kind='podcast') == 'podcast'


# Generated at 2022-06-24 13:02:13.637239
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_ie = NRKPlaylistIE()
    assert nrk_playlist_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert nrk_playlist_ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'

# Generated at 2022-06-24 13:02:19.239986
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    r = ie._real_extract('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert r['id'] == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'


# Generated at 2022-06-24 13:02:29.803060
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrkie = NRKIE()
    assert nrkie._GEO_COUNTRIES == ['NO']
    assert nrkie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-24 13:02:35.074176
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    nrk.IE_NAME = u'NRK'
    nrk._GEO_COUNTRIES = ['NO']
    nrk._CDN_REPL_REGEX = r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
    return nrk


# Generated at 2022-06-24 13:02:37.099323
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/20-sporsmaal/sesong/1/episode/3-20-sporsmaal-23-05-2014'
    ie = NRKPlaylistBaseIE()
    ie.suitable(url)



# Generated at 2022-06-24 13:02:47.569978
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Test non-static method
    test_NRKTVSerieBaseIE.__name__ = 'NRKTVSerieIE'
    # Test parameter `serie_kind`
    for serie_kind in ('series', 'podcast'):
        test_NRKTVSerieBaseIE.__name__ = 'NRKTVSerieIE'
        tmp_ie = NRKTVSerieBaseIE._test_class({}, {}, serie_kind)
        assert tmp_ie.catalog_name == NRKTVSerieBaseIE._catalog_name(serie_kind)
    # Test parameter `serie_id`
    for serie_id in (
            'iliketurtles_series_id',
            'iliketurtles_podcast_id',
            'iliketurtles_radio_id'):
        tmp_ie

# Generated at 2022-06-24 13:02:48.828720
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie is not None



# Generated at 2022-06-24 13:02:55.326405
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._call_api('test') == ie._download_json(
        'http://psapi.nrk.no/test',
        'test', 'Downloading test JSON',
        fatal=False, headers={'Accept-Encoding': 'gzip, deflate, br'})


# Generated at 2022-06-24 13:03:04.608482
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    webpage = fake_urlopen(url)
    playlist_title = self._og_search_title(webpage, fatal=False)
    playlist_description = self._og_search_description(webpage)
    return self.playlist_result(
            entries, playlist_id, playlist_title, playlist_description)



# Generated at 2022-06-24 13:03:07.500724
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/lindmo/sesong/1'
    ie = NRKTVSeasonIE._build_url_result(url)
    assert isinstance(ie, NRKTVSeasonIE)
    assert ie._VALID_URL == NRKTVSeasonIE._VALID_URL
    assert ie.IE_NAME == NRKTVSeasonIE.IE_NAME
    assert ie.IE_DESC == NRKTVSeasonIE.IE_DESC



# Generated at 2022-06-24 13:03:09.564489
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # test that an object of class NRKTVDirekteIE is created
    NRKTVDirekte = NRKTVDirekteIE()
    # test that extractor is of class NRKTVIE
    assert(isinstance(NRKTVDirekte.extractor, NRKTVIE))


# Generated at 2022-06-24 13:03:22.803848
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    global NRKTVIE
    NRKTVIE = type(
        'NRKTVIE',
        (NRKTVIE, InfoExtractor),
        {}
    )
    ie = NRKTVIE(
        compat_urllib_request.Request(
            'https://tv.nrk.no/serie/20-spoersmaal-tv/MUHH48000314/23-05-2014'
        )
    )
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'

# Generated at 2022-06-24 13:03:28.353614
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test only works if you have a video in your history
    # http://www.nrk.no/lokale-nyheter/midtnytt/nrk-midtnytt/
    url = 'http://www.nrk.no/lokale-nyheter/midtnytt/nrk-midtnytt/'
    ie = NRKPlaylistIE(NRKPlaylistIE.ie_key())

    # Test if class NRKPlaylistIE is able to extract the video
    new_url = ie.url_result('nrk:MUHH48000317AA', NRKIE.ie_key())
    assert 'nrk:MUHH48000317AA' in new_url.url
    assert 'nrk' in new_url.url


# Generated at 2022-06-24 13:03:38.121890
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # The purpose of this test is to see if class constructor gives the
    # correct extraction information for NRKTVEpisodesIE
    episodes_ie = NRKTVEpisodesIE()
    assert episodes_ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert episodes_ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert episodes_ie.IE_DESC == 'NRK TV and NRK Radio'
    assert episodes_ie.js_to_json == js_to_json



# Generated at 2022-06-24 13:03:41.131256
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # All instances of NRKPlaylistIE should have input URL as a parameter
    assert NRKPlaylistIE.__init__.__defaults__ == (None,)


# Generated at 2022-06-24 13:03:47.442283
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE()._TESTS[0].get("info_dict").get("id") == "69031"
    assert NRKTVEpisodesIE()._TESTS[0].get("info_dict").get("title") == "Nytt på nytt, sesong: 201210"
    assert NRKTVEpisodesIE()._TESTS[0].get("playlist_count") == 4
    return True


# Generated at 2022-06-24 13:03:52.038713
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    from . import NRKTVEpisodesIE
    test_cases = ['https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031',
                  'https://tv.nrk.no/program/episodes/gjengangere/69031']
    for url in test_cases:
        NRKTVEpisodesIE(url)


# Generated at 2022-06-24 13:03:54.200699
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    class inputObject:
        pass

    NRKTVIE.__init__(inputObject())
    assert inputObject.IE_DESC.startswith('NRK TV Direkte and NRK')

# Generated at 2022-06-24 13:04:00.349154
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    try:
        import youtube_dl.YoutubeDL
        youtube_dl_object = youtube_dl.YoutubeDL(youtube_dl.YoutubeDL.params)
    except ImportError:
        youtube_dl_object = None

    ie = NRKPlaylistIE(youtube_dl_object)
    assert ie.suitable('https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert not ie.suitable('https://tv.nrk.no/serie/tidenes-tivoli/MUHH48000314/15-04-2015#t=1h1m1s')
    assert not ie.suitable('https://tv.nrk.no/program/FOOOBAR')

# Generated at 2022-06-24 13:04:01.125381
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()


# Generated at 2022-06-24 13:04:02.805193
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    for url in NRKRadioPodkastIE._TESTS:
        assert NRKRadioPodkastIE.suitable(url['url'])
        raise

# Generated at 2022-06-24 13:04:05.777961
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie_NRKTVIE = NRKTVIE()
    assert ie_NRKTVIE._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % ie_NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 13:04:10.729328
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie_obj = NRKTVSerieBaseIE()
    assert ie_obj._ENTRIES_PER_PAGE == 15
    assert ie_obj._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie_obj._catalog_name('series') == 'series'
    assert ie_obj._catalog_name('podcast') == 'podcast'
    assert ie_obj._catalog_name('podkast') == 'podcast'
    assert ie_obj._catalog_name('other') == 'series'


# Generated at 2022-06-24 13:04:12.136732
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Test successful construction of class NRKRadioPodkastIE
    try:
        NRKRadioPodkastIE()
    except:
        assert False
test_NRKRadioPodkastIE()



# Generated at 2022-06-24 13:04:15.169402
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    from youtube_dl.extractor.nrk import NRKTVSerieBaseIE
    assert NRKTVSerieBaseIE.__name__ == 'NRKTVSerieBaseIE'
    assert NRKTVSerieBaseIE.__doc__ == 'NRK TV series and podcasts base class'



# Generated at 2022-06-24 13:04:21.166012
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/20-spoersmaal-tv/MUHH48000314/23-05-2014'
    NRKTVIE(NRKTVIE.ie_key()).suitable(url)
    NRKTVIE(NRKTVIE.ie_key()).extract(url)

# Generated at 2022-06-24 13:04:28.385478
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/20-spoersmaal/MUHH48000314/23-05-2014'

    # Testing instantiation of NRKTVIE class
    instance = NRKTVIE()
    assert (isinstance(instance, NRKTVIE))

    # Testing with url
    instance = NRKTVIE(url, {})
    assert (isinstance(instance, NRKTVIE))

# Generated at 2022-06-24 13:04:39.573640
# Unit test for constructor of class NRKTVEpisodeIE

# Generated at 2022-06-24 13:04:52.103741
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.IE_NAME == 'nrk:episode'
    assert ie.IE_DESC == 'NRK TV episode'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert ie._TESTS[0]['info_dict']['id'] == 'MUHH36005220'

# Generated at 2022-06-24 13:04:54.842549
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        NRKTVSeasonIE
        song = NRKTVSeasonIE()
    except:
        song = 0
    assert song != 0



# Generated at 2022-06-24 13:04:56.291492
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert u'NRKBaseIE' == NRKBaseIE.IE_NAME

# Generated at 2022-06-24 13:05:00.298314
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from .nrk import NRKPlaylistIE, NRKIE, NRKSkoleIE, NRKTVIE
    assert isinstance(NRKPlaylistIE('no')._GEO_COUNTRIES, list)
    assert isinstance(NRKIE('no')._GEO_COUNTRIES, list)
    assert isinstance(NRKSkoleIE('no')._GEO_COUNTRIES, list)
    assert isinstance(NRKTVIE('no')._GEO_COUNTRIES, list)



# Generated at 2022-06-24 13:05:07.016301
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Extracting from json URL
    testUrl = 'https://p-events.nrk.no/statistikk/radiodirekte/radiodirekte.json'
    testFile = 'NRK_RadioDirekte.json'
    url = 'https://radio.nrk.no/direkte/p1_oslo_akershus'
    nrktvdirekteIE = NRKTVDirekteIE(NRKTVDirekteIE.suitable(url))
    nrktvdirekteIE.download(url)
    # It should have produced a file with name testFile
    # in directory UnitTests
    # It can be used to manually test the program
    # when it's not supported by the network anymore
    # like it happened with NRK TV Dagsrevyen


# Generated at 2022-06-24 13:05:16.141349
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE('http://nrk.no/troms')
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie.IE_DESC == 'NRK playlists'
    assert ie.VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie.ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert ie.TESTS[0]['url'] == 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
   

# Generated at 2022-06-24 13:05:17.895592
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """just run the constructor of NRKTVIE"""
    NRKTVIE()

# Generated at 2022-06-24 13:05:27.467763
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    test_urls = {
        'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763': "NRKPlaylistIE[test_urls['http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763']]",
    }
    for url in test_urls:
        print(ie.suitable(url))
        print(ie.extract(url))



# Generated at 2022-06-24 13:05:28.831243
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'

# Generated at 2022-06-24 13:05:34.058150
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    temp = NRKPlaylistIE._TESTS[0]
    webpage = "This is webpage"
    playlist_id = "gjenopplev-den-historiske-solformorkelsen-1.12270763"
    # Create instance of NRKPlaylistIE
    a = NRKPlaylistIE(NRKPlaylistIE._VALID_URL)
    # Set url
    a.url = temp['url']
    # Call method _real_extract
    a._real_extract(webpage, playlist_id)
    return a


# Generated at 2022-06-24 13:05:35.530581
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE is not None

# Generated at 2022-06-24 13:05:38.205454
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE._build_url_result('nrk:123')
    assert isinstance(ie, NRKTVEpisodesIE)

# Generated at 2022-06-24 13:05:46.615281
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """NRKTVSeasonIE.__init__ misbehaves: requires url to match, but url is unused"""
    class MyIE(NRKTVSeasonIE):
        def _real_extract(self, url):
            return self.playlist_result([self.url_result('nrk:videoid')], 'displayid', 'title')
    assert MyIE()._real_extract('nrk:videoid')['_type'] == 'playlist'
    # must not raise AssertionError
    MyIE()._real_extract('nrk:videoid')



# Generated at 2022-06-24 13:05:50.176773
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    """Unit test for constructor of class NRKPlaylistIE."""
    # Setup
    result = NRKPlaylistIE('http://www.nrk.no/nyheter')

    # Verify
    assert result



# Generated at 2022-06-24 13:05:59.308161
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank'
    nrktvseriesie = NRKTVSeriesIE()
    result = nrktvseriesie._real_extract(url)
    assert isinstance(result, Playlist)
    assert result.get('_type') == 'playlist'
    assert result.get('id') == 'blank'
    assert result.get('title') == 'Blank'
    assert len(result.get('entries')) == 30

# Generated at 2022-06-24 13:06:03.800513
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    nrk_radio_podkastIE = NRKRadioPodkastIE()
    # Whenever we access the _VALID_URL property of a class, it results in its
    # execution.
    # It behaves like a static property
    nrk_radio_podkastIE._VALID_URL
    # Test if the constructor was able to assign the url to the 'url' member
    # variable
    assert(nrk_radio_podkastIE.url == url)



# Generated at 2022-06-24 13:06:07.914469
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrkSkole = NRKSkoleIE()
    assert(nrkSkole.IE_DESC == 'NRK Skole')
    assert(nrkSkole._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)')


# Generated at 2022-06-24 13:06:09.569683
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrktv_episodeie = NRKTVEpisodeIE()
    with pytest.raises(ExtractorError):
        nrktv_episodeie._real_extract()


# Generated at 2022-06-24 13:06:12.396561
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    try:
        # Test construction
        NRKBaseIE._download_json
        NRKBaseIE._download_webpage
        NRKBaseIE._extract_from_json
        _ = NRKTVDirekteIE()
        success = True
    except Exception:
        success = False
    assert success

# Generated at 2022-06-24 13:06:14.706559
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_key() in NRKTVIE._IES
    assert ie.SUCCESS == 1
    assert ie.FAILED == 0


# Generated at 2022-06-24 13:06:19.960463
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert isinstance(ie, NRKTVSerieBaseIE)
    assert re.match(NRKTVSerieBaseIE._VALID_URL, 'https://tv.nrk.no/serie/20-spoersmaal')
    assert re.match(NRKTVSerieBaseIE._VALID_URL, 'https://tv.nrk.no/serie/anno')
    assert re.match(NRKTVSerieBaseIE._VALID_URL, 'https://tv.nrk.no/serie/backstage')
    assert re.match(NRKTVSerieBaseIE._VALID_URL, 'https://tv.nrk.no/serie/hellums-kro')

# Generated at 2022-06-24 13:06:26.320959
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    import sys
    import os

    path = 'test/'
    if len(sys.argv) > 1:
        path = sys.argv[1]
    if not os.path.isdir(path):
        os.mkdir(path)
    
    download_file = os.path.join(path, 'test.html')
    if not os.path.isfile(download_file):
        from youtube_dl.utils import download_file
        download_url = 'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'
        download_file = os.path.join(path, 'test.html')
        download_file = download_file.replace('\\', '/')
        download_file = download_file.en

# Generated at 2022-06-24 13:06:28.116612
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    nrk.IE_NAME = 'test_NRKIE'
    assert nrk._VALID_URL == NRKIE._VALID_URL

# Generated at 2022-06-24 13:06:29.254178
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    import pprint
    pprint.pprint(NRKTVSerieBaseIE.__dict__)

# Generated at 2022-06-24 13:06:30.872197
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_ie = NRKPlaylistIE()
    assert nrk_playlist_ie.__class__ == NRKPlaylistIE


# Generated at 2022-06-24 13:06:33.802760
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Test with and without season
    for url in (
            'https://tv.nrk.no/serie/hellums-kro',
            'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'):
        instance = NRKTVSerieBaseIE(url)
        assert instance is not None


# Generated at 2022-06-24 13:06:46.082373
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKBaseIE('NRK.no', 'nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9')
    test_data = (
        ('NRK.no', 'code', 'nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9'),
        ('NRK', 'ie', 'NRKesports'),
        ('NRK', '_VALID_URL', ie._VALID_URL),
    )
    for info in test_data:
        if isinstance(info[2], compat_str):
            assert ie.suitable(info[2])
        else:
            assert ie.suitable(info[2]) == info[1]



# Generated at 2022-06-24 13:06:49.867698
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    instance = NRKPlaylistIE()
    assert issubclass(type(instance), InfoExtractor)


# Generated at 2022-06-24 13:06:55.827669
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    for site, channel_id in [('tv', 'nrk1'), ('radio', 'p1_oslo_akershus')]:
        url = 'https://%s.nrk.no/direkte/%s' % (site, channel_id)
        _, ie_result = NRKTVDirekteIE._extract_url(url)
        assert ie_result['id'] == channel_id
        assert ie_result['ie_key'] == 'NRKTVDirekte'
        assert ie_result['display_id'] == channel_id



# Generated at 2022-06-24 13:07:04.880483
# Unit test for constructor of class NRKIE
def test_NRKIE():
    obj = NRKIE()
    assert obj._GEO_COUNTRIES == ['NO']
    assert obj._CDN_REPL_REGEX == r'(?x)://\n(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'

# Generated at 2022-06-24 13:07:16.610495
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() is NRKTVEpisodesIE.ie_key()
    assert ie.compat_str() is NRKTVEpisodesIE.compat_str()
    assert ie.compat_url() is NRKTVEpisodesIE.compat_url()
    assert ie.compat_str_repr() is NRKTVEpisodesIE.compat_str_repr()
    assert ie.compat_str_repr() is NRKTVEpisodesIE.compat_str_repr()
    assert ie.compat_str_hash() is NRKTVEpisodesIE.compat_str_hash()
    assert ie.compat_str_search() is NRKTVEpisodesIE.compat_str_search()
    assert ie.compat_url_

# Generated at 2022-06-24 13:07:18.452559
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    tempNRKTVIE = NRKTVIE()
    assert(tempNRKTVIE != None)



# Generated at 2022-06-24 13:07:19.137216
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    pass

# Generated at 2022-06-24 13:07:23.195780
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrkSkoleIE = NRKSkoleIE('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert nrkSkoleIE.stream_info_key() == 'NRKSkoleIE'


# Generated at 2022-06-24 13:07:28.353243
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    x = NRKSkoleIE()

# Generated at 2022-06-24 13:07:29.852535
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE() != NRKIE()



# Generated at 2022-06-24 13:07:33.231923
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        from .test import test_NRKBaseIE_inner
        test_NRKBaseIE_inner()
    except ImportError:
        raise ImportError('The test for class NRKBaseIE does not exists!')



# Generated at 2022-06-24 13:07:42.245805
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE('https://tv.nrk.no/program/MDDP12000117')
    NRKTVIE('https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2')
    NRKTVIE('https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015')
    NRKTVIE('https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13')
    NRKTVIE('https://tv.nrk.no/serie/nytt-paa-nytt/MUHH46000317/27-01-2017')

# Generated at 2022-06-24 13:07:43.513059
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.ie_key() == 'NRKTV'

# Generated at 2022-06-24 13:07:54.817180
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """ Test constructor for class NRKTVDirekteIE """
    nrktv_direkte_ie = NRKTVDirekteIE()
    # check if correct value is returned when calling class function ie_key()
    assert 'nrktvdirekte' == nrktv_direkte_ie.ie_key()
    # check if correct value is returned when calling class function ie_key() on super class NRKBaseIE
    assert 'nrktv' == NRKBaseIE().ie_key()
    # check if correct value is returned when calling class function ie_desc()
    assert 'NRK TV Direkte and NRK Radio Direkte' == nrktv_direkte_ie.ie_desc()
