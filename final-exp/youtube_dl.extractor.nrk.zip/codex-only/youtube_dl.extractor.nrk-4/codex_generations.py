

# Generated at 2022-06-24 12:58:01.640683
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    id = 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/' + id
    assert NRKRadioPodkastIE._match_id(url) == id
    assert NRKRadioPodkastIE._match_id('') is None

# Generated at 2022-06-24 12:58:08.002799
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # pylint: disable=protected-access
    video_info = NRKTVIE()._real_extract("https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015")
    assert video_info['id'] == 'MSPO40010515'
    assert video_info['ext'] == 'mp4'
    assert video_info['title'] == 'Sprint fri teknikk, kvinner og menn 06.01.2015'
    assert video_info['description'] == 'md5:c03aba1e917561eface5214020551b7a'
    assert video_info['age_limit'] == 0



# Generated at 2022-06-24 12:58:12.206613
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    from .nrk import NRKRadioPodkastIE
    assert NRKRadioPodkastIE().constructor()


# Generated at 2022-06-24 12:58:13.038931
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE()


# Generated at 2022-06-24 12:58:14.607605
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    x = NRKTVSeasonIE('https://tv.nrk.no/serie/backstage/sesong/1')



# Generated at 2022-06-24 12:58:19.649073
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    entry_list = [
        {'episodeId': '1'},
        {'prfId': '2'}
    ]
    entries = list(ie._extract_entries(entry_list))
    assert len(entries) == 2
    assert entries[0]['id'] == '1'
    assert entries[0]['ie_key'] == 'NRK'
    assert entries[1]['id'] == '2'
    assert entries[1]['ie_key'] == 'NRK'



# Generated at 2022-06-24 12:58:21.256884
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    test_url = 'https://tv.nrk.no/program/MDDP12000117'
    nrk_tv = NRKTVIE()
    nrk_tv.suitable(test_url)


# Generated at 2022-06-24 12:58:26.295176
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+)/?'
    assert ie.IE_NAME == 'NRK TV'
    ie = NRKTVSerieBaseIE.from_crawler(crawler_with_factory())
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+)/?'
    assert ie.IE_NAME == 'NRK TV'


# Generated at 2022-06-24 12:58:27.926344
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE(None)

# Generated at 2022-06-24 12:58:34.205732
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    nrk_episode = NRKTVEpisodeIE()
    info_dict = nrk_episode._real_extract(url)
    assert info_dict.get("id") == "MUHH36005220"
    assert info_dict.get("title") == "Hellums kro - 2. Kro, krig og kjærlighet"

# Generated at 2022-06-24 12:58:37.203420
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    ie = NRKTVEpisodesIE(url)
    # test of _real_extract function
    # print ie._real_extract(url)



# Generated at 2022-06-24 12:58:38.889786
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://radi.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015'
    NRKTVIE(url)

# Generated at 2022-06-24 12:58:40.488394
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Create instance of IE
    ie = NRKTVDirekteIE()
    # Check for IE-key
    assert ie.ie_key() == 'nrktv_direkte'

# Generated at 2022-06-24 12:58:44.626238
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
    assert ie._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'


# Generated at 2022-06-24 12:58:57.150465
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-24 12:59:00.569302
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    class MockParser:
        def __init__(self, name):
            self.parser = name

    def mock_preferredcdns(name):
        return MockParser(name)
    NRKTVIE._preferred_cdns = mock_preferredcdns

    tv = NRKTVIE('test', 'test', {})
    assert tv.parser == 'PreferredCDNs'


# Generated at 2022-06-24 12:59:02.051262
# Unit test for constructor of class NRKIE
def test_NRKIE():
    _test_NRKIE = NRKIE()
    assert _test_NRKIE

# Generated at 2022-06-24 12:59:07.055318
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE()._download_json("https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533", "150533", "Downloading manifest JSON", fatal=True, query=None, headers={'Accept-Encoding': 'gzip, deflate, br'})

test_NRKIE()



# Generated at 2022-06-24 12:59:15.953136
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    obj = NRKPlaylistIE('NRKPlaylistIE', 'https://www.nrk.no/varsel/')

# Generated at 2022-06-24 12:59:19.171754
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE(NRKTVIE(), 'tv.nrk.no', {'id': 'nrk1'})
    assert ie.get_id() is not None
    assert ie.get_id() == 'nrk1'


# Generated at 2022-06-24 12:59:28.660282
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Test for program with subtitles of type vtt
    path_templ = 'playback/%s/' + 'ENRK10100318'

# Generated at 2022-06-24 12:59:30.242194
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrkplaylistbaseie = NRKPlaylistBaseIE()
    nrkplaylistbaseie._extract_description
    nrkplaylistbaseie._real_extract()


# Generated at 2022-06-24 12:59:35.631179
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
# Test end NRKTVDirekteIE



# Generated at 2022-06-24 12:59:45.244584
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    """Test the constructor and arguments of class NRKTVEpisodesIE"""
    # Constructor - No arguments
    IE = NRKTVEpisodesIE()
    # Test the _VALID_URL property
    assert IE._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    # Test the _ITEM_RE property
    assert IE._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    # Test the _TESTS property
    assert len(IE._TESTS) == 1
    test = IE._TESTS[0]

# Generated at 2022-06-24 12:59:46.532449
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    tve = NRKTVEpisodesIE();
    assert tve.extractor_key() == 'NRKTVEpisodes'

# Generated at 2022-06-24 12:59:51.037764
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    ie = NRKTVSeasonIE()
    obj = ie.suitable(url)


# Generated at 2022-06-24 12:59:52.470778
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE._TESTS[0]['url'] == NRKTVEpisodesIE._VALID_URL

# Generated at 2022-06-24 12:59:58.594979
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE('NRKTVSeries', 'NRK') == NRKTVSeriesIE('NRKTVSeries', 'NRK')
    assert NRKTVSeriesIE('NRKTVSeries', 'NRK') == NRKTVSeriesIE('NRKTVSeries', 'NRK')
    assert NRKTVSeriesIE('NRKTVSeries', 'NRK') != NRKTVSeriesIE('NRKTVSeason', 'NRK')
    assert NRKTVSeriesIE('NRKTVSeries', 'NRK') != NRKTVSeriesIE('NRKTVSeries', 'NRKP3')
    assert NRKTVSeriesIE('NRKTVSeries', 'NRK') != object()
    assert NRKTVSeriesIE('NRKTVSeries', 'NRK') != NRKTVEpisodeIE('NRKTVEpisode', 'NRK')
    assert NRK

# Generated at 2022-06-24 13:00:04.374849
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE('nrk:test') is not None
    nrkTVSeriesIE = NRKTVSeriesIE('nrk:test')
    assert nrkTVSeriesIE.get_output_dir() == 'NRKTVSeriesIE'

# Generated at 2022-06-24 13:00:08.300094
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    ie = NRKTVEpisodesIE(NRKTVIE())
    ie = ie.real_extract(url)

# Generated at 2022-06-24 13:00:15.852538
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    i = NRKTVEpisodeIE()
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert i._match_id('https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2') == 'hellums-kro/sesong/1/episode/2'
    assert i._match_id('https://tv.nrk.no/serie/backstage/sesong/1/episode/8') == 'backstage/sesong/1/episode/8'

# Generated at 2022-06-24 13:00:16.535379
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE(None)

# Generated at 2022-06-24 13:00:25.145612
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    import inspect
    assert inspect.isclass(NRKBaseIE)
    o = NRKBaseIE('NRKBaseIE')
    assert o._GEO_COUNTRIES == ['NO']
    assert o._CDN_REPL_REGEX == r'(?x)://\s(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'


# Generated at 2022-06-24 13:00:33.748408
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'
    info_dict = NRKPlaylistIE._TESTS[1]['info_dict']
    ie = NRKPlaylistIE()
    assert(ie._match_id(url) == info_dict['id'])
    assert(NRKPlaylistIE.suitable(url) is True)


# Generated at 2022-06-24 13:00:42.598255
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not ie.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert not ie.suitable('https://tv.nrk.no/program/backstage')
    assert not ie.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201507/NPUB21019315')
    assert not ie.suitable('https://tv.nrk.no/serie/20-spoersmaal-tv/MSPO40010515/06-01-2015')

# Generated at 2022-06-24 13:00:47.172834
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    nrktvepisodesIE = NRKTVEpisodesIE()
    assert nrktvepisodesIE.suitable(url)

# Generated at 2022-06-24 13:00:50.550330
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    """Unit test for constructor of class NRKBaseIE"""
    # pylint: disable=W0613
    NRKBaseIE()



# Generated at 2022-06-24 13:00:52.115693
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # test constructor
    assert NRKPlaylistBaseIE()



# Generated at 2022-06-24 13:00:53.346150
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    info_extractor = NRKTVIE()

    assert info_extractor._VALID_URL == NRKTVIE._VALID_URL

# Generated at 2022-06-24 13:00:59.257784
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    if not os.path.exists(TEST_RESOURCES_PATH):
        os.mkdir(TEST_RESOURCES_PATH)
    return NRKTVEpisodeIE()._download_webpage('https://tv.nrk.no/serie/mammon',
                                              'MAMMO')



# Generated at 2022-06-24 13:01:02.042356
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .nrk import NRKTVDirekteIE
    x = NRKTVDirekteIE()


# Generated at 2022-06-24 13:01:06.273299
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebase_ie = NRKTVSerieBaseIE()
    assert nrktvseriebase_ie._ASSETS_KEYS == ('episodes', 'instalments',)



# Generated at 2022-06-24 13:01:08.528155
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    return NRKPlaylistBaseIE('NRKPlaylistBaseIE', 'nrk.no')


# Generated at 2022-06-24 13:01:13.812339
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'http://www.nrk.no/xl/#!/kanal/hopp_playlist/paleet_alpint_hopp_herrer_15_02_2014/'
    nrkPlaylistBaseIE = NRKPlaylistBaseIE()
    assert nrkPlaylistBaseIE.suitable(url)


# Generated at 2022-06-24 13:01:15.695754
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE('NRKPlaylistBaseIE')


# Generated at 2022-06-24 13:01:20.255202
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_instance = NRKPlaylistIE()
    assert(test_instance._VALID_URL == NRKPlaylistIE._VALID_URL)
    assert(test_instance._ITEM_RE == NRKPlaylistIE._ITEM_RE)


# Generated at 2022-06-24 13:01:23.578177
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # always test with a failing url, since _real_extract would always return one
    with pytest.raises(ExtractorError) as excinfo:
        NRKTVSeasonIE()._real_extract(URLs.url_for_test('/tv.nrk.no/', 'wrong__url'))
    assert excinfo.value.args[0] == 'Unable to fetch info section for given url'


# Generated at 2022-06-24 13:01:24.954515
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    try:
        NRKPlaylistIE()
    except:
        assert False


# Generated at 2022-06-24 13:01:28.032808
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE()
    except TypeError as e:
        assert e.args[0] == "Can't instantiate abstract class NRKPlaylistBaseIE with abstract methods _extract_description"



# Generated at 2022-06-24 13:01:34.615840
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    _NRKTVEpisodeIE = NRKTVEpisodeIE(url)
    display_id, season_number, episode_number = re.match(_NRKTVEpisodeIE._VALID_URL, url).groups()
    assert display_id == 'hellums-kro/sesong/1/episode/2'
    assert season_number == '1'
    assert episode_number == '2'

# Generated at 2022-06-24 13:01:36.226020
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert type(NRKSkoleIE('NRKSkole')) == NRKSkoleIE

# Generated at 2022-06-24 13:01:40.770071
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    nrk_radio_podkast_ie.url = url
    actual_url_result = nrk_radio_podkast_ie.extract()
    url_result = nrk_radio_podkast_ie.url_result

# Generated at 2022-06-24 13:01:51.669459
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE('https://tv.nrk.no/program/MDDP12000117') != None
    assert NRKTVIE('https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2') != None
    assert NRKTVIE('https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015') != None
    assert NRKTVIE('https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13') != None
    assert NRKTVIE('https://tv.nrk.no/serie/nytt-paa-nytt/MUHH46000317/27-01-2017') != None


# Generated at 2022-06-24 13:02:01.069603
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    import sys
    import inspect
    from youtube_dl.utils import get_elements_by_attribute

    members = inspect.getmembers(sys.modules[__name__])
    classes = [memb[1] for memb in members if inspect.isclass(memb[1])]
    for c in classes:
        l = get_elements_by_attribute(c, '_TESTS')
        if l:
            url = l[0]
            ie = c.suitable(url)
            if ie:
                ie = ie()
                ie.extract(url)


# Generated at 2022-06-24 13:02:02.955268
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    _NRKRadioPodkastIE = NRKRadioPodkastIE('NRKRadioPodkastIE', 'NRK Radio Podcast')


# Generated at 2022-06-24 13:02:07.127987
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvsb = NRKTVSerieBaseIE()
    assert nrktvsb._ASSETS_KEYS == ('episodes', 'instalments',)
    assert nrktvsb._catalog_name('') == 'series'
    assert nrktvsb._catalog_name('podkast') == 'podcast'
    assert nrktvsb._catalog_name('podcast') == 'podcast'


# Generated at 2022-06-24 13:02:08.698836
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    unit_test_set_up()
    # no way to get a valid URL without a whole lot of mucking around
    # print_out = "NRKSkoleIE: constructor"
    # print(print_out + ": Success")


# Generated at 2022-06-24 13:02:10.465496
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """The constructor of NRKTVDirekteIE should not throw any exceptions"""
    NRKTVDirekteIE()


# Generated at 2022-06-24 13:02:11.394612
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE()


# Generated at 2022-06-24 13:02:12.911185
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    if sys.version_info >= (3, 8):
        NRKTVSeasonIE()  # no exception



# Generated at 2022-06-24 13:02:24.496856
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvseasonie = NRKTVSeasonIE('NRKTVSeasonIE')
    assert nrktvseasonie.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert not nrktvseasonie.suitable('https://tv.nrk.no/serie/backstage/sesong/1#del=2')
    assert not nrktvseasonie.suitable('https://tv.nrk.no/serie/backstage/sesong/201509')
    assert nrktvseasonie.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')

# Generated at 2022-06-24 13:02:27.950740
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE().extract('https://tv.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#')

# Generated at 2022-06-24 13:02:29.346838
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    obj = NRKPlaylistBaseIE('url', 'ie_key')
    assert obj._VALID_URL == r''
    assert obj.ie_key() == 'ie_key'


# Generated at 2022-06-24 13:02:37.967555
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    base_url = 'https://tv.nrk.no/serie/tour-de-ski/'
    episode_id = 'MSPO40010515'
    url = base_url + episode_id + '/06-01-2015'
    tv = NRKTVIE()
    info = tv._real_extract(url)
    assert info.get('id') == episode_id
    assert info.get('url') == 'nrk:' + episode_id

# Generated at 2022-06-24 13:02:38.722704
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE()



# Generated at 2022-06-24 13:02:48.490229
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    webpage = '''
        <html lang="no">
        <head>
        <meta name="nrk:program-id" content="MUHH36005220" />
        </head>
        </html>'''

    info = NRKTVEpisodeIE._extract_json_ld(webpage, display_id, default={})
    nrk_id = info.get('@id')
    assert nrk_id is None, 'nrk_id should be None'

    info = NRKTVEpisodeIE._search_json_ld(webpage, display_id, default={})
   

# Generated at 2022-06-24 13:02:54.517176
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    obj = NRKPlaylistIE()
    assert(obj._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)')
    assert(obj._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"')

# Generated at 2022-06-24 13:02:55.840895
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE(NRKTVSeasonIE.suitable)



# Generated at 2022-06-24 13:03:03.976614
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    def test_case(query_string, expected):
        custom_info_extractor = NRKBaseIE(InfoExtractor())
        assert custom_info_extractor._call_api('/', 'NRKBaseIE test_case', query=query_string) == expected
    test_case('', {})
    test_case('foo=bar', {})
    test_case('foo=bar&baz=quux', {'foo': 'bar', 'baz': 'quux'})



# Generated at 2022-06-24 13:03:12.757998
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/202101')
    assert not NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/hele_historien/202101')
    assert not NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/hele_historien/202101')
    assert not NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/other/podkast/hele_historien/sesong/202101')



# Generated at 2022-06-24 13:03:23.726864
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    sample_url = 'https://tv.nrk.no/program/MDDP12000117'
    url_matches = NRKTVIE._VALID_URL.match(sample_url)
    assert url_matches is not None
    assert url_matches.group('id') == 'MDDP12000117'
    assert NRKTVIE._EPISODE_RE.match('MDDP12000117').group('id') == 'MDDP12000117'
    assert NRKTVIE._EPISODE_RE.match('MDDP12000117') is not None
    assert NRKTVIE._EPISODE_RE.match('12') is None


# Generated at 2022-06-24 13:03:25.276555
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE('NRKTVIE')
    assert ie != None

# Generated at 2022-06-24 13:03:27.981139
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._calc_xor(
        ''.join(chr(ord('a') + i) for i in range(26))) == '0g'



# Generated at 2022-06-24 13:03:31.267703
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    constructor_test(NRKTVIE, [('https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015',)])

# Generated at 2022-06-24 13:03:35.725399
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    ie = NRKTVSeasonIE(NRKTVSeasonIE._download_webpage(url, None))
    assert type(ie) is NRKTVSeasonIE


# Generated at 2022-06-24 13:03:44.599004
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IE = NRKBaseIE()
    assert(IE._GEO_COUNTRIES == ['NO'])
    assert(IE._CDN_REPL_REGEX == '(?x):///nrkod\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|nrk-od-no\\.telenorcdn\\.net|minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no/')

# vim: ts=4 sw=4 sts=4 expandtab

# Generated at 2022-06-24 13:03:48.730329
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    loader = load_tests(__name__, module_name='test_NRKTVIE')
    for tests in loader:
        for test in tests:
            url = test.get('url', '')
            if url:
                ie = NRKTVIE()
                assert ie._match_id(url) is not None

# Generated at 2022-06-24 13:03:53.883048
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    obj = NRKTVDirekteIE()
    assert obj.IE_NAME == NRKTVIE.IE_NAME
    assert obj.IE_DESC == NRKTVDirekteIE.IE_DESC
    assert obj.IE_KEY == NRKTVIE.IE_KEY
    assert obj._VALID_URL == NRKTVDirekteIE._VALID_URL
    assert obj._TESTS == NRKTVDirekteIE._TESTS



# Generated at 2022-06-24 13:03:55.840730
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        NRKTVSeasonIE.suitable(url='https://tv.nrk.no/serie/lindmo/2016')
    except AssertionError:
        assert False



# Generated at 2022-06-24 13:03:58.473891
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvseasontest = NRKTVSeasonIE()
    assert isinstance(nrktvseasontest, NRKTVSeasonIE)
    assert nrktvseasontest.suitable('https://tv.nrk.no/serie/backstage/sesong/1')


# Generated at 2022-06-24 13:04:09.061338
# Unit test for constructor of class NRKIE
def test_NRKIE():
    from . import NRKIE
    import unittest
    class TestNRKIE(unittest.TestCase):
        def setUp(self):
            self.nrkie = NRKIE()
        
        def test_instance(self):
            self.assertIsInstance(self.nrkie, NRKIE)
        def test_name(self):
            self.assertEqual(self.nrkie.IE_NAME, 'nrk')
        def test_description(self):
            self.assertTrue(len(self.nrkie.IE_DESC) > 0)
        def test_supported_urls(self):
            self.assertEqual(self.nrkie._VALID_URL, NRKIE._VALID_URL)

# Generated at 2022-06-24 13:04:10.630251
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test_get_NRKIE = NRKIE()
    test_get_NRKIE._real_extract('http://www.nrk.no/video/PS*150533')

# Generated at 2022-06-24 13:04:16.593200
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    if not _is_url(NRKTVIE._VALID_URL):
        raise Exception('Not an URL')
    code = NRKTVIE._VALID_URL.partition('/')[2]
    nrk_id = re.match(NRKTVIE._EPISODE_RE, code).group('id')
    if nrk_id is None:
        raise Exception('No match')
    serie_url = 'https://tv.nrk.no/serie/%s' % nrk_id
    if not _is_url(serie_url):
        raise Exception('Not an URL')
    return serie_url
# ----------------------------------------------------


# Generated at 2022-06-24 13:04:22.687255
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Test various input combinations
    ie = NRKTVEpisodeIE(None)
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None
    assert ie._real_extract("https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2") is not None



# Generated at 2022-06-24 13:04:28.445470
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    videos = [
        'https://tv.nrk.no/serie/yndlingene-paa-skavlan',
        'https://radio.nrk.no/serie/arilds-publikumskvelder',
    ]
    for url in videos:
        NRKTVSeriesIE._test_suitable(url)

# Generated at 2022-06-24 13:04:29.509449
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    extractor = NRKRadioPodkastIE(None)
    assert extractor is not None



# Generated at 2022-06-24 13:04:34.428460
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = "https://www.nrk.no/skole/?page=search&q=&mediaId=14099"
    obj = NRKSkoleIE(None)
    """
    Test the is_suitable method of URL
    """
    assert(obj.suitable(url) == True)

# Generated at 2022-06-24 13:04:37.123125
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    assert re.match(nrk._VALID_URL, "nrk:clip/150533") is not None
    assert re.match(nrk._VALID_URL, "nrk:clip/150532") is None


# Generated at 2022-06-24 13:04:49.676306
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    extractor = NRKRadioPodkastIE()

    assert extractor.suitable(url)
    assert extractor._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert extractor.IE_DESC == 'NRK Radio'

# Generated at 2022-06-24 13:04:51.559448
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    result = NRKPlaylistBaseIE()


# Generated at 2022-06-24 13:05:02.403482
# Unit test for constructor of class NRKTVSeasonIE

# Generated at 2022-06-24 13:05:04.119364
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrkradiopodkastie = NRKRadioPodkastIE();
    assert isinstance(nrkradiopodkastie, InfoExtractor);
    return;

# Generated at 2022-06-24 13:05:05.834492
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """Simple test to see that a constructor of class NRKTVSeriesIE exists"""
    NRKTVSeriesIE([])

# Generated at 2022-06-24 13:05:07.357450
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE('lindmo')


# Generated at 2022-06-24 13:05:17.429261
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    entries_urls = ['https://tv.nrk.no/serie/groenn-glede']
    entries_playlist_mincount = [90]
    entries_info_dict = [{
        'id': 'groenn-glede',
        'title': 'Grønn glede',
        'description': 'md5:7576e92ae7f65da6993cf90ee29e4608',
    }]
    for i in range(len(entries_urls)):
        ie = NRKTVSeriesIE()
        if ie.suitable(entries_urls[i]):
            ie.extract(entries_urls[i])
            assert ie.info_dict['id'] == entries_info_dict[i]['id']
            assert ie.info_dict['title']

# Generated at 2022-06-24 13:05:29.286429
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert re.match(NRKRadioPodkastIE._VALID_URL, 'https://radio.nrk.no/podkast/ulrikkes_univers/sesong/1/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert re.match(NRKRadioPodkastIE._VALID_URL, 'https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c')

# Generated at 2022-06-24 13:05:33.734699
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    z = NRKTVSeriesIE()
    z.suitable('https://tv.nrk.no/serie/blank')
    z.suitable('https://tv.nrksuper.no/serie/labyrint')
    z.suitable('https://radio.nrk.no/serie/dickie-dick-dickens')
    z.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/1')



# Generated at 2022-06-24 13:05:34.583996
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('NRKDirekte')


# Generated at 2022-06-24 13:05:40.964383
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_NAME == "NRK TV and NRK Radio"
    assert ie.IE_DESC == "NRK TV and NRK Radio"
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 13:05:47.521452
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """Test for constructor of class NRKTVIE."""

    # Test a valid URL
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015'
    nrktv_ie = NRKTVIE(url)
    assert nrktv_ie.name == 'NRK TV'
    assert nrktv_ie.video_id == 'MSPO40010515'



# Generated at 2022-06-24 13:05:52.912253
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'



# Generated at 2022-06-24 13:05:59.482862
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_podkast = NRKRadioPodkastIE('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert(nrk_podkast != None)


# Generated at 2022-06-24 13:06:01.392808
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    extractor = NRKTVSerieBaseIE(object, 'catalog_name')
    assert extractor._catalog_name('podcast') == 'podcasts'
    assert extractor._catalog_name('podkast') == 'podcasts'
    assert extractor._catalog_name('series') == 'series'



# Generated at 2022-06-24 13:06:09.783820
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE('NRKTVSeriesIE', {}, {}, {})
    assert ie._extract_assets_key({'instalments': None}) == 'instalments'
    assert ie._extract_assets_key({'episodes': None}) == 'episodes'
    assert ie._extract_assets_key({'instalments': None, 'episodes': None}) == 'instalments'
    assert ie._extract_assets_key({}) is None


# Generated at 2022-06-24 13:06:15.932144
# Unit test for constructor of class NRKTVIE

# Generated at 2022-06-24 13:06:20.292700
# Unit test for constructor of class NRKTVSeasonIE

# Generated at 2022-06-24 13:06:28.005617
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert hasattr(NRKBaseIE, '_GEO_COUNTRIES')
    assert hasattr(NRKBaseIE, '_CDN_REPL_REGEX')
    assert hasattr(NRKBaseIE, '_extract_nrk_formats')
    assert hasattr(NRKBaseIE, '_raise_error')
    assert hasattr(NRKBaseIE, '_call_api')
    assert hasattr(NRKBaseIE, 'IE_NAME')
test_NRKBaseIE()



# Generated at 2022-06-24 13:06:29.223785
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrkdirekte_ie = NRKTVDirekteIE();


# Generated at 2022-06-24 13:06:34.750806
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.ie_key() == 'NRKTV'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-24 13:06:47.164328
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie.IE_DESC == 'NRK TV'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-24 13:06:58.261448
# Unit test for constructor of class NRKIE
def test_NRKIE():
    import re
    import pprint
    url1 = 'https://www.nrk.no/video/PS*150533'
    url2 = 'nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9'
    url3 = 'nrk:clip/7707d5a3-ebe7-434a-87d5-a3ebe7a34a70'
    url4 = 'https://v8-psapi.nrk.no/mediaelement/ecc1b952-96dc-4a98-81b9-5296dc7a98d9'
    url5 = 'https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533'

# Generated at 2022-06-24 13:07:10.021617
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    test_url_stream = 'https://rox-fms-fra-was-p.nrk.no/webprod/a/533/5332026.mp3?proxy=a/533/5332026.mp3'
    test_url_thumbnail = 'https://gfx.nrk.no/9XB0J4IFjD3qf13GzwOL0w_Gv250euDtrh8_e5gu9XfFA'
    test_url_info = 'https://tv.nrk.no/programsubtitles/tv/video-blob/subtitlelist/direkte-nrk1/12680546'

# Generated at 2022-06-24 13:07:12.914820
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert(NRKTVEpisodeIE(nrk_test.NRKTest())._VALID_URL == NRKTVEpisodeIE._VALID_URL)

# Generated at 2022-06-24 13:07:14.891495
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlistBase = NRKPlaylistBaseIE()
    assert playlistBase is not None



# Generated at 2022-06-24 13:07:16.724666
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE(None)
    except TypeError:
        pass


# Generated at 2022-06-24 13:07:17.933893
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE('https://tv.nrk.no/serie/backstage/sesong/1') != None


# Generated at 2022-06-24 13:07:18.975467
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE
    NRKIE

# Generated at 2022-06-24 13:07:22.471509
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    instance = NRKTVDirekteIE("input_file_path")
    assert instance._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 13:07:25.669812
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrkplaylist = NRKPlaylistIE("http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449")



# Generated at 2022-06-24 13:07:26.691111
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE.IE_DESC == 'NRK Radio Podkast'


# Generated at 2022-06-24 13:07:29.418969
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.NRKPlaylistBaseIE(None, None)



# Generated at 2022-06-24 13:07:32.077780
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE('', '', '', '')
    assert ie.get_parser('', '', '', '') == NRKIE


# Generated at 2022-06-24 13:07:40.767820
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Instance of NRKTVEpisodesIE
    NRKTVEpisodesIEInstance = NRKTVEpisodesIE()
    # Test for _VALID_URL
    assert(NRKTVEpisodesIEInstance._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)')
    # Test for _ITEM_RE
    assert(NRKTVEpisodesIEInstance._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE)
    # Test for _TESTS

# Generated at 2022-06-24 13:07:42.656455
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE("https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031")

# Generated at 2022-06-24 13:07:49.132814
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    class TestInfoExtractor(NRKBaseIE):
        _VALID_URL = r'https://www.nrk.no/some_video_id'
        _TEST = {
            'url': _VALID_URL,
            'info_dict': {
                'id': 'some_video_id',
                'ext': 'mp4',
                'title': 'This is the title',
                'description': 'This is the description',
                'thumbnail': r're:^https?://.*\.jpg$',
                'duration': 300,
                'view_count': 100500,
                'age_limit': 0,
            },
            'params': {
                # m3u8 download
                'skip_download': True,
            },
        }
        IE_NAME = 'nrk'


# Generated at 2022-06-24 13:07:59.997205
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebase = NRKTVSerieBaseIE()
    assert nrktvseriebase._ASSETS_KEYS == ('episodes', 'instalments')