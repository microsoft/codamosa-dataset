

# Generated at 2022-06-12 17:57:20.982825
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # assert that NRKTVSeasonIE.__init__ is defined
    assert(NRKTVSeasonIE.__init__ != object.__init__)

# Generated at 2022-06-12 17:57:23.002554
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE()
    NRKPlaylistIE._ITEM_RE

# Generated at 2022-06-12 17:57:24.255997
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE("NRKPlaylistBase")



# Generated at 2022-06-12 17:57:25.817716
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
	nrkskole_ie = NRKSkoleIE()


# Generated at 2022-06-12 17:57:31.756927
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('NRKTVIE')
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._extract_assets_key({}) is None
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podcasts') == 'podcast'
    assert ie._catalog_name('series') == 'series'
    assert ie._catalog_name('serieses') == 'series'


# Generated at 2022-06-12 17:57:32.994646
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE().name == 'NRK Radio Podkast'

# Generated at 2022-06-12 17:57:44.736717
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    class TestNRKPlaylistIE(NRKPlaylistIE):
        def _extract_title(self, webpage):
            return self._og_search_title(webpage, fatal=False)

        def _extract_description(self, webpage):
            return self._og_search_description(webpage)
    # Test that the constructor of class NRKPlaylistIE
    # correctly sets the parameters of the class
    testPlaylistIE = TestNRKPlaylistIE('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert testPlaylistIE.ie_key() == 'nrkPlaylist'

# Generated at 2022-06-12 17:57:53.114955
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from collections import OrderedDict
    from youtube_dl import YoutubeDL
    url = 'https://tv.nrk.no/serie/blank'
    ytdl = YoutubeDL(OrderedDict([
        ('skip_download', True),
        ('simulate', True),
        ('json', True),
        ('continue_dl', False),
        ('quiet', True),
        ('no_warnings', True),
    ]))
    data = ytdl.extract_info(url, download=True)
    assert data.get('id') == 'blank'
    assert data.get('title') == 'Blank'
    assert data.get('description') == 'md5:7664b4e7e77dc6810cd3bca367c25b6e'

# Generated at 2022-06-12 17:57:57.681009
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """
    Unit test for constructor of class NRKTVIE,
    """
    _nrktv = NRKTVIE()
    assert 'NRKTVIE' in repr(_nrktv)

# Generated at 2022-06-12 17:58:05.640918
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    instance = NRKBaseIE()
    assert str(instance._GEO_COUNTRIES) == "['NO']"
    assert str(instance._CDN_REPL_REGEX) == 'r(?:://|://nrkod\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|://nrk-od-no\\.telenorcdn\\.net|://minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no/)'
# Unit test ends

# Generated at 2022-06-12 17:59:22.546909
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    info_extractor = NRKPlaylistBaseIE()
    assert info_extractor._VALID_URL is None
    assert info_extractor._ITEM_RE is None
    assert info_extractor.IE_DESC is None



# Generated at 2022-06-12 17:59:31.103906
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE(NRKTVIE())
    # check it is the correct IE
    assert class_name_for_test(ie) == 'NRKRadioPodkastIE'
    # check that it is the correct URL
    assert ie.suitable(url)
    # check that id is set correctly
    assert ie._match_id(url) == 'l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    # check that is_radio is set correctly

# Generated at 2022-06-12 17:59:36.615097
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    direkte = NRKTVDirekteIE()
    assert direkte.ie_key() == 'NRKTVDirekte'
    if direkte.suitable('https://tv.nrk.no/direkte/nrk1'):
        info_dict = direkte.extract('https://tv.nrk.no/direkte/nrk1')
        for key in info_dict.keys():
            print('\'%s\': \'%s\'' % (key, info_dict[key]))


# Generated at 2022-06-12 17:59:43.510341
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podcast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'
    assert NRKTVSerieBaseIE._catalog_name('') == 'series'



# Generated at 2022-06-12 17:59:45.725309
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    video_url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    obj = NRKTVEpisodeIE()
    info = obj._real_extract(video_url)
    assert_equals(info['title'], 'Backstage - 8. episode')


# Generated at 2022-06-12 17:59:47.440338
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
	nrk = NRKTVSeriesIE()
	assert type(nrk) == NRKTVSeriesIE


# Generated at 2022-06-12 17:59:50.979080
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():

    """
    Constructor test
    """

    # Test property '_VALID_URL'.
    assertNRKSkoleIE = NRKSkoleIE(None)
    assert assertNRKSkoleIE._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-12 17:59:53.429312
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    class_instance = NRKTVEpisodesIE()
    assert class_instance.__class__.__name__ == 'NRKTVEpisodesIE'

# Generated at 2022-06-12 18:00:01.369458
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IE = NRKBaseIE()

    # Tests for _extract_nrk_formats
    test_url_1 = 'http://nrkod0-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/nb/2016/05/02/1735-160523-master.m3u8?bw_low=64000'

# Generated at 2022-06-12 18:00:07.663336
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    # Test first lines of the following template
    template = 'ie.suitable(url) and super(NRKTVSeriesIE, ie).suitable(url) and \\\n(False if any(ie.suitable(url) for ie in (NRKTVIE, NRKTVEpisodeIE, NRKRadioPodkastIE, NRKTVSeasonIE)) else True)'
    # Test first lines of the following if statement
    condition = 'if len(linked_seasons) > len(embedded_seasons):\n                for season in linked_seasons:\n                    season_url = urljoin(url, season.get(\'href\'))'
    # Test that the template and the if statement are correct

# Generated at 2022-06-12 18:02:48.471261
# Unit test for constructor of class NRKIE
def test_NRKIE():
    TestNRKIE = NRKIE(None)
    assert TestNRKIE


# Generated at 2022-06-12 18:02:49.770961
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-12 18:02:58.870250
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test_url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    ie = NRKTVEpisodesIE(NRKTVEpisodesIE.ie_key())
    r = ie._real_extract(test_url)
    assert(r['id'] == '69031')
    assert(r['title'] == 'Nytt på nytt, sesong: 201210')
    assert(len(r['entries']) == 4)
    assert(r['entries'][0]['id'] == 'NRK_135498')


# Generated at 2022-06-12 18:03:02.791118
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = "https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355"
    ie = NRKSkoleIE()
    assert ie.suitable(url)


# Generated at 2022-06-12 18:03:07.357923
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    res = NRKTVSerieBaseIE()
    assert 'NRKTVSerieBaseIE' == res.IE_DESC
    # TODO: Test for _ASSETS_KEYS and _extract_assets_key


# Generated at 2022-06-12 18:03:11.152123
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    individual_ie_class = NRKTVSeriesIE.ie_key()
    info_dict = {'id': 'hashstash'}
    result = individual_ie_class(info_dict)
    assert(result.info_dict['id'] == info_dict['id'])


# Generated at 2022-06-12 18:03:13.092070
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()

# Generated at 2022-06-12 18:03:13.929616
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()



# Generated at 2022-06-12 18:03:16.138233
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert(NRKSkoleIE()._VALID_URL == NRKSkoleIE._VALID_URL)

# Generated at 2022-06-12 18:03:22.547350
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    #Create instance of class NRKBaseIE
    nrk = NRKBaseIE()
    assert nrk
    #Test _GEO_COUNTRIES
    countries = nrk._GEO_COUNTRIES
    assert countries == ['NO']
    #Test _CDN_REPL_REGEX
    assert nrk._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''

