

# Generated at 2022-06-12 17:57:24.020945
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Test constructor
    try:
        NRKBaseIE()
    except TypeError:
        assert True
    # Test not implemented functions
    try:
        NRKBaseIE._extract_nrk_formats("http://psapi.nrk.no/", "master")
    except NotImplementedError:
        assert True
    try:
        NRKBaseIE._raise_error("http://psapi.nrk.no/")
    except NotImplementedError:
        assert True
    try:
        NRKBaseIE._call_api("master", "http://psapi.nrk.no/")
    except NotImplementedError:
        assert True


# Generated at 2022-06-12 17:57:33.744303
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    from compat.compat import compat_str
    from compat import json
    _playlist_data_json = None
    def _download_webpage(*args, **kwargs):
        return compat_str(_playlist_data_json)
    NRKPlaylistIE._download_webpage = _download_webpage
    # Simple test, the URL is not real
    _playlist_data_json = json.dumps({
        'content':{
            'title':'Real title',
            'lead':'Real description'
        },
        'assets':{
            'videos':[
                {'mediaId':'1'},
                {'mediaId':'2'}
            ]
        }
    })
    nrk_playlist_ie = NRKPlaylistIE('http://www.nrk.no/test')


# Generated at 2022-06-12 17:57:36.414879
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    from youtube_dl.extractor import gen_extractors
    NRKTVEpisodesIE(NRKTVEpisodesIE.ie_key(), 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert gen_extractors(["https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031"])

# Generated at 2022-06-12 17:57:36.835324
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    pass # TODO

# Generated at 2022-06-12 17:57:37.865979
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    instance = NRKTVIE()
    assert isinstance(instance, NRKTVIE)


# Generated at 2022-06-12 17:57:49.957603
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    import unittest
    import os
    import sys

# Generated at 2022-06-12 17:57:53.829774
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.im_func.__name__ == 'get_info'
    assert ie.re.pattern == NRKPlaylistIE._VALID_URL
    assert ie.__name__ == 'NRKPlaylist'
    assert ie.info_dict() == {'name': 'NRKPlaylist', 'title': 'NRKPlaylist'}

# Generated at 2022-06-12 17:57:58.839905
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    p = NRKPlaylistIE('NRKPlaylist', suite='unit_tests')
    assert p.IE_NAME == 'NRKPlaylist'
    assert p.ie_key == NRKPlaylistIE.ie_key()


# Generated at 2022-06-12 17:58:00.342600
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE();
    assert ie.name == 'NRK';

# Generated at 2022-06-12 17:58:01.776170
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE(nrk.NRKIE()) # Create instance of class by constructor

# Generated at 2022-06-12 17:59:09.876862
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrk = NRKTVEpisodesIE()

# Generated at 2022-06-12 17:59:12.056266
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    ie = NRKTVEpisodesIE()
    assert ie != None, ie


# Generated at 2022-06-12 17:59:13.703695
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    try:
        nrk_tv_episode_ie = NRKTVEpisodeIE()
        assert nrk_tv_episode_ie is not None
    except:
        assert False, 'NRKTVEpisodeIE() failed'

# Generated at 2022-06-12 17:59:22.020933
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Check initialisation of NRKTVIE class with given url
    result = NRKTVIE(NRKIE(), 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015')
    # Assert that url is stored as a private parameter
    assert result._url == 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015'
    # Assert that url replacement is not needed
    assert result._need_replace == False
    # Assert that NRKIE object is stored as a private parameter
    assert result._ie == NRKIE()


# Generated at 2022-06-12 17:59:25.143407
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    valid_tests = ie._TESTS
    for i in valid_tests:
        url = i['url']
        ie._real_extract(url)
        


# Generated at 2022-06-12 17:59:30.316165
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    instNRKTVEpisodesIE = NRKTVEpisodesIE('Nytt på nytt, sesong: 201210')
    assert instNRKTVEpisodesIE._extract_title('<h1>Nytt på nytt, sesong: 201210</h1>') == 'Nytt på nytt, sesong: 201210'
    assert instNRKTVEpisodesIE._extract_description('md5:c2df8ea3bac5654a26fc2834a542feed') == 'md5:c2df8ea3bac5654a26fc2834a542feed'

# Generated at 2022-06-12 17:59:31.433227
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.ie_key() == 'NRKTVDirekte'



# Generated at 2022-06-12 17:59:43.225277
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    from six import assertRaisesRegex
    from .nrk import NRKPlaylistIE
    assertRaisesRegex(
        AssertionError,
        'NRKPlaylistIE requires a \._ITEM_RE attribute',
        NRKPlaylistIE, 'http://nrk.no')
    assertRaisesRegex(
        AssertionError,
        'NRKPlaylistIE requires a \._ITEM_RE attribute',
        NRKPlaylistIE, 'http://nrk.no', '_item_re')
    assertRaisesRegex(
        AssertionError,
        'NRKPlaylistIE requires an \._VALID_URL attribute',
        NRKPlaylistIE, 'http://nrk.no', '_item_re', '_valid_url')

    # It is an abstract class so you cannot instantiate

# Generated at 2022-06-12 17:59:48.073443
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    webpage = '<html></html>'
    ie = NRKTVEpisodesIE(NRKTVEpisodesIE.ie_key())
    result = ie._real_extract(url)
    assert isinstance(result, Playlist)


# Generated at 2022-06-12 17:59:51.762119
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    new_ie = NRKTVDirekteIE()
    assert isinstance(new_ie, NRKTVIE)
    assert isinstance(new_ie, NRKTVDirekteIE)

# Generated at 2022-06-12 18:02:12.272377
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/spangas/sesong/1'
    NRKTVSeasonIE().suitable(url)



# Generated at 2022-06-12 18:02:14.755954
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    a = NRKTVDirekteIE()
    a.extract('https://tv.nrk.no/direkte/nrk1')
    a.extract('https://radio.nrk.no/direkte/p1_oslo_akershus')
    a.extract('https://radio.nrk.no/direkte/p1')



# Generated at 2022-06-12 18:02:17.243427
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    """
    Unit test for constructor of class NRKSkoleIE.
    """
    _valid_url = r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    test_ie = NRKSkoleIE(_valid_url)
    assert(test_ie._VALID_URL == _valid_url)



# Generated at 2022-06-12 18:02:18.214732
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE()._VALID_URL == NRKPlaylistIE._VALID_URL



# Generated at 2022-06-12 18:02:19.457219
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE('NRKPlaylistBaseIE') is not None


# Generated at 2022-06-12 18:02:21.335237
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert isinstance(NRKTVSerieBaseIE('NRKTVSerieBaseIE'), NRKTVSerieBaseIE)


# Generated at 2022-06-12 18:02:22.322659
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._TESTS



# Generated at 2022-06-12 18:02:24.902624
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    """Unit test for constructor of class NRKTVEpisodesIE"""
    assert NRKTVEpisodesIE

# Generated at 2022-06-12 18:02:28.716303
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # For subclasses it is a good practice to check that the constructor of the parent class works.
    # But the constructor of NRKTVIE class does not take arguments.
    NRKTVIE()



# Generated at 2022-06-12 18:02:35.565424
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .nrktv import get_NRKTVDirekteIE
    nrk_direkte = get_NRKTVDirekteIE()
    assert nrk_direkte._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'

