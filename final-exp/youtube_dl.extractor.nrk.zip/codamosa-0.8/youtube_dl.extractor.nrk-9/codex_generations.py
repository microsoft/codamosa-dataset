

# Generated at 2022-06-12 17:57:25.124607
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE(NRKTVSeasonIE._VALID_URL)
    mobj = re.match(ie._VALID_URL, 'https://tv.nrk.no/serie/spangas/sesong/1')
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''
    assert mobj.group('domain') == 'tv'
    assert mob

# Generated at 2022-06-12 17:57:30.620043
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_cases = [
        # test case 1
        {
            "url": "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2",
            "display_id": "hellums-kro/sesong/1/episode/2",
            "episode_number": 2,
            "season_number": 1
        },
        # test case 2
        {
            "url": "https://tv.nrk.no/serie/backstage/sesong/1/episode/8",
            "display_id": "backstage/sesong/1/episode/8",
            "season_number": 1,
            "episode_number": 8
        }
    ]

    for test_case in test_cases:
        ie = (NRKTVEpisodeIE())


# Generated at 2022-06-12 17:57:31.634185
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # TODO: fix unit test
    pass


# Generated at 2022-06-12 17:57:35.175351
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    catalog = NRKTVSerieBaseIE._catalog_name('tv')
    assert catalog == 'series'
    catalog = NRKTVSerieBaseIE._catalog_name('radio')
    assert catalog == 'series'
    catalog = NRKTVSerieBaseIE._catalog_name('podcast')
    assert catalog == 'podcast'


# Generated at 2022-06-12 17:57:39.974782
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == "NRK TV Episodes"
    assert ie.IE_DESC == "Episodes on NRK TV"
    assert ie._VALID_URL == "https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)"
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-12 17:57:46.114287
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE(
        NRKTVSeriesIE.ie_key(), {'_type': 'url', 'url': 'nrk:foo', 'id': 'foo'},
        NRKTVSeriesIE.ie_key())
    assert hasattr(ie, '_download_json')
    assert ie.SUITABLE == NRKTVSeriesIE.suitable

# Generated at 2022-06-12 17:57:54.658293
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    def construct_NRKRadioPodkastIE(url):
        from youtube_dl.extractor.nrk import NRKRadioPodkastIE
        return NRKRadioPodkastIE(NRKRadioPodkastIE.create_ie(url))

    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert construct_NRKRadioPodkastIE(url).suitable(url) == True

    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert construct

# Generated at 2022-06-12 17:57:57.840095
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_ie = NRKRadioPodkastIE()
    nrk_ie.IE_DESC = 'Test'
    nrk_ie.suitable(NRKRadioPodkastIE._TESTS[0]['url'])
    (nrk_ie.IE_DESC) == 'Test'


# Generated at 2022-06-12 17:57:59.100259
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()

# Generated at 2022-06-12 17:58:01.460547
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrkplaylistbaseie = NRKPlaylistBaseIE()
    assert nrkplaylistbaseie



# Generated at 2022-06-12 17:59:06.775763
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """Test constructor of class NRKTVIE with some examples."""
    examples = {
        'https://tv.nrk.no/program/MDDP12000117': 'MDDP12000117',
        'https://tv.nrk.no/serie/nytt-paa-nytt/MUHH46000317/27-01-2017':
        'MUHH46000317',
    }
    for url, expected in examples.items():
        NRKTVIE_test = NRKTVIE()
        assert(
            NRKTVIE_test.suitable(url)
        ), f"URL {url} should match NRKTVIE_test.suitable"
        NRKTVIE_test.suitable(url)

# Generated at 2022-06-12 17:59:08.916522
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk_ie = NRKIE()
    nrk_ie.IE_NAME
    # Calling a method of the class
    nrk_ie.suitable('http://nrk.no')


# Generated at 2022-06-12 17:59:11.329078
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    try:
        NRKRadioPodkastIE(None, "http://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8")
    except Exception as e:
        print(e)
        raise e



# Generated at 2022-06-12 17:59:15.386087
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-12 17:59:16.677731
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE(NRKTVEpisodeIE._downloader, "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2")

# Generated at 2022-06-12 17:59:27.767117
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrkRadioPodkastIE = NRKRadioPodkastIE()
    # Tests the regex of the _VALID_URL
    regex = NRKRadioPodkastIE._VALID_URL
    assert(re.match(regex, 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'))
    assert(re.match(regex, 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'))

# Generated at 2022-06-12 17:59:35.285230
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    # Constructor with url as argument
    ie = NRKRadioPodkastIE(url)
    # test case when url is given
    assert ie.suitable(url)



# Generated at 2022-06-12 17:59:39.953052
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    IE_NAME = 'NRKBaseIE'
    GEO_COUNTRIES = ['NO']
    CDN_REPL_REGEX = r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
    _call_api = 'http://psapi.nrk.no/'

# Generated at 2022-06-12 17:59:40.980243
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Should run without error
    NRKSkoleIE()


# Generated at 2022-06-12 17:59:43.684902
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE()._ITEM_RE == NRKTVIE._EPISODE_RE


# Generated at 2022-06-12 18:02:09.157121
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert_raises(TypeError, NRKTVSerieBaseIE, {}, 'https://tv.nrk.no/serie/20-spoersmaal-tv')


# Generated at 2022-06-12 18:02:10.024772
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Shouldn't raise exception.
    NRKPlaylistIE('', '', '', '')



# Generated at 2022-06-12 18:02:11.103543
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('NRKPlaylistBaseIE', 'http://mock.url/')
    assert ie is not None


# Generated at 2022-06-12 18:02:12.479011
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')


# Generated at 2022-06-12 18:02:13.053218
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
	NRKRadioPodkastIE()

# Generated at 2022-06-12 18:02:17.955702
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # pylint: disable=protected-access
    # test for the constructor of class NRKTVSeasonIE
    assert True == NRKTVSeasonIE._adapt_url(
        'https://tv.nrk.no/serie/backstage/sesong/1',
        NRKTVSeasonIE.suitable, NRKTVSeasonIE._VALID_URL
    )
    assert False == NRKTVSeasonIE._adapt_url(
        'https://tv.nrk.no/serie/backstage/sesong/1#',
        NRKTVSeasonIE.suitable, NRKTVSeasonIE._VALID_URL
    )

# Generated at 2022-06-12 18:02:19.181668
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert isinstance(NRKSkoleIE(), InfoExtractor)


# Generated at 2022-06-12 18:02:20.781739
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE()._VALID_URL == NRKTVSeriesIE._VALID_URL
# This class is for testing only

# Generated at 2022-06-12 18:02:21.941065
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE is not None


# Generated at 2022-06-12 18:02:27.717032
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'

