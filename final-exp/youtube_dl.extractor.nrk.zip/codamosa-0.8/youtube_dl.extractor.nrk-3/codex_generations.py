

# Generated at 2022-06-12 17:57:24.232837
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    dir(NRKTVSerieBaseIE)
    base = NRKTVSerieBaseIE()
    assert base._TYPE == 'serie'


# Generated at 2022-06-12 17:57:33.975756
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    mobj = NRKRadioPodkastIE(NRKIE())

    assert mobj._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-12 17:57:45.783367
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from six import assertRaisesRegex
    from youtube_dl.utils import ExtractorError

    assertRaisesRegex(
        ExtractorError, 'Invalid url for NRKTVSeriesIE', NRKTVSeriesIE, 'https://tv.nrk.no/serie/dag')
    assertRaisesRegex(
        ExtractorError, 'Invalid url for NRKTVSeriesIE', NRKTVSeriesIE, 'https://tv.nrk.no/program/MUHH40000917')
    assertRaisesRegex(
        ExtractorError, 'Invalid url for NRKTVSeriesIE', NRKTVSeriesIE, 'https://tv.nrk.no/serie/dag/sesong/1')

# Generated at 2022-06-12 17:57:49.119383
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    instance = NRKTVIE()
    assert instance._EPISODE_RE == r'(?P<id>[a-zA-Z]{4}\d{8})'
    assert instance._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % instance._EPISODE_RE


# Generated at 2022-06-12 17:57:52.697933
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    temp_NRKTVDirekteIE = NRKTVDirekteIE('nrk1')
    assert temp_NRKTVDirekteIE.program_id == 'nrk1'


# Generated at 2022-06-12 17:58:04.863025
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'
    assert ie.ie_key() not in globals()
    assert re.search(NRKTVDirekteIE._VALID_URL, 'https://tv.nrk.no/direkte/nrk1')
    assert re.search(NRKTVDirekteIE._VALID_URL, 'https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1')

# Generated at 2022-06-12 17:58:06.436688
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """
    >>> test_NRKTVSeasonIE()
    """
    assert 'season' in NRKTVSeasonIE.IE_NAME


# Generated at 2022-06-12 17:58:15.101645
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    import json
    import os
    from ytdl_nrk.extractor import NRKTVIE
    from ytdl_nrk.compat import compat_urllib_request

    def load_json_fixture(filename):
        with open(os.path.join('test', 'fixtures', filename), 'r') as f:
            return json.load(f)

    def _download_json(url, video_id, data_name, query, video_referer=None):
        if video_id == 'KMTE50001317':
            return load_json_fixture('tv_nrk_video.json')
        elif video_id == 'MDFP15000514':
            return load_json_fixture('tv_nrk_program.json')

# Generated at 2022-06-12 17:58:25.407694
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank'
    site, serie_kind, series_id = re.match(NRKTVSeriesIE._VALID_URL, url).groups()
    is_radio = site == 'radio.nrk'
    domain = 'radio' if is_radio else 'tv'
    series = NRKTVSeriesIE._call_api(
        '%s/catalog/%s/%s'
        % (domain, NRKTVSeriesIE._catalog_name(serie_kind), series_id),
        series_id, 'serie', query={'embeddedInstalmentsPageSize': 50})

# Generated at 2022-06-12 17:58:30.096697
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()


# Generated at 2022-06-12 17:59:44.569175
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    video_id = "1.12820275"
    url = "http://www.nrk.no/urix/1.12820275"
    entry = ie.url_result(url, NRKIE.ie_key())
    assert entry.video_id == video_id
    assert entry.ie_key() == "NRK"
    assert entry.url == "nrk:1.12820275"
    assert entry.__class__.__name__ == "URLResult"



# Generated at 2022-06-12 17:59:53.895927
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    _test_NRKTVSeasonIE = NRKTVSeasonIE('NRKTVSeasonIE', {})
    _test_NRKTVSeasonIE.suitable = lambda url: True
    assert _test_NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/lindmo/2016') is not False
    assert _test_NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509') is not False
    assert _test_NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/spangas/sesong/1') is not False


# Generated at 2022-06-12 18:00:00.862585
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    description = 'This is a description of this playlist'
    playlist_url = 'http://www.nrk.no/norge/this-is-a-test/1.1234'
    playlist_id = 'this-is-a-test/1.1234'
    playlist_title = 'This is a test'
    test_playlist = NRKPlaylistIE.suitable(playlist_url, webpage_url=playlist_url)
    assert playlist_id == test_playlist._match_id(playlist_url)
    assert playlist_title == test_playlist._extract_title(playlist_title)
    assert description == test_playlist._extract_description(description)


# Generated at 2022-06-12 18:00:03.184752
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    try:
        ie_NRKTVEpisodesIE = NRKTVEpisodesIE()
    except:
        pass


# Generated at 2022-06-12 18:00:06.179241
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE.suitable('https://www.nrk.no/x/')
    NRKTVSeriesIE.suitable('https://tv.nrksuper.no/serie/labyrint')
    NRKTVSeriesIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers')


# Generated at 2022-06-12 18:00:17.686609
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    tests = (('https://tv.nrk.no/serie/spangas/sesong/1',
              NRKTVSeasonIE, {'season_id': '1', 'serie': 'spangas'}),
              ('https://tv.nrk.no/serie/spangas/1',
               NRKTVSeasonIE, {'season_id': '1', 'serie': 'spangas'}))
    for url, ie, params in tests:
        ie_instance = ie.suitable(url)
        assert ie_instance is not False, 'Should be True for %s' % url
        assert isinstance(ie_instance, object), 'Should be instance for %s' % url
        assert ie_instance.__class__ is ie, 'Should be class %s for %s' % (ie, url)


# Generated at 2022-06-12 18:00:18.589896
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE(None)



# Generated at 2022-06-12 18:00:25.231274
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.IE_DESC != ''
    assert ie.IE_NAME == 'nrk:playlist'
    assert ie._VALID_URL == 'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == 'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert ie._TESTS != []
    assert ie.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')

# Generated at 2022-06-12 18:00:36.248946
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    import datetime, math
    url = 'https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13'
    display_id = 'KMTE50001317/sesong-3/episode-13'
    webpage = '<html></html>'

    ne = NRKTVEpisodeIE(None)

    # Test Exception
    assert_raises(RegexNotFoundError, ne._real_extract, url)

    # Test Exception
    assert_raises(AssertionError, ne._real_extract, 'https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13/')

    # Test Exception

# Generated at 2022-06-12 18:00:37.317409
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9')


# Generated at 2022-06-12 18:03:10.071311
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie is not None


# Generated at 2022-06-12 18:03:21.892395
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE()._GEO_COUNTRIES == ['NO']
    assert NRKBaseIE()._CDN_REPL_REGEX == '''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''

# Generated at 2022-06-12 18:03:26.333280
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert re.search(NRKBaseIE._CDN_REPL_REGEX, 'http://nrkod51-httpcache0-47115-cacheod0.dna.ip-only.net/47115-cacheod0/bbb/bbb-bbb.ism/bbb-bbb-bbb-bbb.mp4')
    assert re.search(NRKBaseIE._CDN_REPL_REGEX, 'http://nrk-od-no.telenorcdn.net/bbb/bbb-bbb.ism/bbb-bbb-bbb-bbb.mp4')


# Generated at 2022-06-12 18:03:29.814865
# Unit test for constructor of class NRKIE
def test_NRKIE():
    _ = NRKIE('NRK').extract('https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533')



# Generated at 2022-06-12 18:03:31.471133
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert issubclass(NRKTVDirekteIE, NRKTVIE)


# Generated at 2022-06-12 18:03:34.048978
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        _test_NRKBaseIE()
    except NameError as ne:
        return True           # Ok, so no unit test

    raise Exception('NameError! %r' % ne)


# Generated at 2022-06-12 18:03:35.873445
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    obj = NRKTVEpisodeIE()
    assert obj._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'



# Generated at 2022-06-12 18:03:41.559046
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """
    Just check that we can instanciate the NRKTVIE class
    """
    NRKTVIE()  # pylint: disable=pointless-statement

# Generated at 2022-06-12 18:03:51.432369
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE._match_id('nrk1') == 'NRK1'
    assert NRKTVDirekteIE._match_id('nrk2') == 'NRK2'
    assert NRKTVDirekteIE._match_id('nrksuper') == 'NRKSuper'
    assert NRKTVDirekteIE._match_id('nrk3') == 'NRK3'
    assert NRKTVDirekteIE._match_id('p1') == 'P1'
    assert NRKTVDirekteIE._match_id('p2') == 'P2'
    assert NRKTVDirekteIE._match_id('p3') == 'P3'
    assert NRKTVDirekteIE._match_id('p13') == 'P13'

# Generated at 2022-06-12 18:03:54.745960
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
