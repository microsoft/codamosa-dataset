

# Generated at 2022-06-12 17:57:27.473761
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank'
    tv_series_ie = NRKTVSeriesIE()
    assert not tv_series_ie.suitable(url)
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers'
    tv_series_ie = NRKTVSeriesIE()
    assert not tv_series_ie.suitable(url)
    url = 'https://tv.nrk.no/serie/groenn-glede'
    tv_series_ie = NRKTVSeriesIE()
    assert not tv_series_ie.suitable(url)
    url = 'https://tv.nrk.no/serie/labyrint'
    tv_series_ie = NRKTVSeriesIE()
    assert tv_series_ie.su

# Generated at 2022-06-12 17:57:29.533214
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrktv_episode_ie = NRKTVEpisodeIE()
    assert nrktv_episode_ie.get_id_from_url('https://tv.nrk.no/program/mdfp15000514') == 'mdfp15000514'


# Generated at 2022-06-12 17:57:36.910031
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Dummy values
    path = 'some.path'
    video_id = 'some.video.id'
    item = 'some.item'
    note = 'Asking for some.video.id of some.item'
    query = 'some.data=1&other.data=2'

    nrk_base_ie = NRKBaseIE(path, video_id, item, note, query)
    assert nrk_base_ie == "NRKBaseIE object"
    assert nrk_base_ie == "NRKBaseIE object"


# Generated at 2022-06-12 17:57:49.883593
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from contextlib import contextmanager
    from io import BytesIO
    from .common import (
        assertFailure,
        assertSuccess,
    )

    class MockExtractorsModule(object):
        class MockNRKTVIE(NRKTVIE):
            @staticmethod
            def _is_valid_url(url, video_id):
                return video_id == 'NRK_1234567'

            def _real_extract(self, url):
                return self.url_result(
                    url, ie=self.ie_key(), video_id=self._match_id(url))

        class MockNRKTVEpisodeIE(NRKTVEpisodeIE):
            _VALID_URL = r'https?://(?:www\.)?nrk\.no/(?:[^/]+/)+%s/.+'
            _

# Generated at 2022-06-12 17:57:57.299616
# Unit test for constructor of class NRKSkoleIE

# Generated at 2022-06-12 17:57:59.722448
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/blank/sesong/1/episode/1'
    obj = NRKPlaylistBaseIE()
    assert obj.suitable(url)


# Generated at 2022-06-12 17:58:08.247041
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """
    Test cases for constructor of class NRKTVSeriesIE.
    """
    # Constructor of class NRKTVSeriesIE using regex
    def regex_test_cases_NRKTVSeriesIE():
        """
        Test cases for the constructor of class NRKTVSeriesIE using regex.
        """
        _VALID_URL = NRKTVSeriesIE._VALID_URL

# Generated at 2022-06-12 17:58:09.221537
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE.__doc__

# Generated at 2022-06-12 17:58:17.022638
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    from youtube_dl.utils import ExtractorError
    from .testcases import TestCase
    from .nrktv import NRKTVIE, NRKTVEpisodeIE
    class TestNRKPlaylistIE(TestCase):
        def test_constructor(self):
            _NRKPlaylistIE = NRKPlaylistIE(NRKTVIE())
            self.assertEqual(_NRKPlaylistIE.IE_NAME, NRKPlaylistIE.ie_key())
            self.assertEqual(NRKPlaylistIE._VALID_URL, _NRKPlaylistIE._VALID_URL)
            self.assertEqual(_NRKPlaylistIE._ITEM_RE, NRKPlaylistIE._ITEM_RE)
            self.assertEqual(_NRKPlaylistIE._TESTS, NRKPlaylistIE._TESTS)

# Generated at 2022-06-12 17:58:18.063841
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE()

# Generated at 2022-06-12 17:59:33.945745
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()

    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % ie._EPISODE_RE
    assert ie.IE_DESC == 'NRK TV and NRK Radio'

    assert ie._real_extract('NRKTVIE TESTING')


# Generated at 2022-06-12 17:59:34.866225
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE(InfoExtractor())

# Generated at 2022-06-12 17:59:47.314033
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Runs all tests for the NRKTVEpisodesIE constructor
    obj = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert(obj._VALID_URL == 'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)')
    assert(obj._TESTS[0].get('url') == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert(obj._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE)
    assert(obj._TESTS[0].get('info_dict').get('id') == '69031')

# Generated at 2022-06-12 17:59:54.263310
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_ie = NRKTVEpisodesIE()
    assert nrktv_episodes_ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert nrktv_episodes_ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-12 18:00:00.845766
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Basic test of class NRKTVDirekteIE.__init__
    from youtube_dl.extractor.nrktv import NRKTVDirekteIE

    NRKTVDirekteIE('NRKTVDirekteIE', 'NRK TV Direkte and NRK Radio Direkte', '(?P<id>[^/?#&]+)', '(?:tv|radio)\.nrk\.no/direkte/')

# Generated at 2022-06-12 18:00:01.814112
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    test_object = NRKSkoleIE('http://nrk.no/skole/?mediaId=14099')

# Generated at 2022-06-12 18:00:04.489151
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = "http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763"
    nrk = NRKPlaylistIE()
    nrk._match_id(url)

# Generated at 2022-06-12 18:00:09.727825
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrkie = NRKIE()
    assert nrkie.ie_key() == 'NRK'
    assert nrkie.ie_name() == 'NRK'
    assert nrkie.ie_description() == 'Norwegian Broadcasting Corporation'

# Generated at 2022-06-12 18:00:10.450588
# Unit test for constructor of class NRKIE
def test_NRKIE():	
    obj = NRKIE()
    assert obj	


# Generated at 2022-06-12 18:00:14.225165
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test_ie = NRKTVEpisodesIE()
    assert test_ie.get_test_cases()[0].get('url', None) == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert test_ie.get_test_cases()[0].get('playlist_count', None) == 4, "playlist_count is wrong"



# Generated at 2022-06-12 18:02:46.345646
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE("NRKPlaylistIE", NRKPlaylistIE._VALID_URL, [], {})



# Generated at 2022-06-12 18:02:47.448632
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert isinstance(NRKIE(), NRKIE)



# Generated at 2022-06-12 18:02:52.808656
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    ie._ASSETS_KEYS = ie._ASSETS_KEYS + ('other_key',)
    ie._extract_assets_key({}) == None
    ie._extract_assets_key({'_embedded': {'episodes': {}, 'instalments': {}}}) == 'episodes'
    ie._extract_assets_key({'_embedded': {'instalments': {}}}) == 'instalments'
    ie._extract_assets_key({'_embedded': {'other_key': {}}}) == 'other_key'
    ie._extract_assets_key({'_embedded': {}}) == None


# Generated at 2022-06-12 18:03:00.297919
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') == True
    assert ie.suitable('http://www.nrk.no/skole') == False
    assert ie.suitable('http://www.nrk.no/video') == False
    assert ie.suitable('http://www.nrk.no/video/gjenopplev-den-historiske-solformorkelsen-1.12270763') == False
    assert ie.suitable('http://www.nrk.no/skole/gjenopplev-den-historiske-solformorkelsen-1.12270763') == False


# Generated at 2022-06-12 18:03:04.931989
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'

    # Constructor of class NRKTVEpisodesIE
    _NRKTVEpisodesIE = NRKTVEpisodesIE(url)

    # Calling the method _extract_title from NRKTVEpisodesIE
    _NRKTVEpisodesIE._extract_title(webpage)



# Generated at 2022-06-12 18:03:13.475511
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    nrk_playlist_ie = NRKPlaylistIE(NRKPlaylistIE._create_ie(url))
    assert nrk_playlist_ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert nrk_playlist_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert nrk_playlist_ie._TESTS
    assert nrk_play

# Generated at 2022-06-12 18:03:23.389761
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.ie_key() == 'nrk:series'
    assert ie.ie_key() == 'nrk:series'
    assert ie.ie_key() == 'nrk:series'
    assert ie.ie_key() == 'nrk:series'
    assert ie._SUCCESS == '{}'
    assert ie._API_BASE == 'https://psapi.nrk.no/'
    url = 'https://tv.nrk.no/serie/groenn-glede'

# Generated at 2022-06-12 18:03:25.276457
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE(NRKBaseIE.create_ie())
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-12 18:03:32.715481
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url ='https://tv.nrk.no/serie/backstage/sesong/1'
    obj = NRKTVSeasonIE(url)
    assert obj.suitable(url)
    mobj = re.match(NRKTVSeasonIE._VALID_URL, url)
    assert mobj.group('domain') == 'tv'
    assert mobj.group('serie_kind') == 'serie'
    assert mobj.group('serie') == 'backstage'
    assert mobj.group('id') == '1'


# Generated at 2022-06-12 18:03:33.773961
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE(NRKTVEpisodeIE.create_ie('NRKTVEpisodeIE'))

