

# Generated at 2022-06-12 17:57:20.616826
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie.IE_NAME
    assert ie._VALID_URL

# Generated at 2022-06-12 17:57:21.333967
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE()


# Generated at 2022-06-12 17:57:25.657263
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    e = NRKTVIE()
    assert e._EPISODE_RE == '(?P<id>[a-zA-Z]{4}\d{8})'
    assert e._VALID_URL == 'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % e._EPISODE_RE


# Generated at 2022-06-12 17:57:30.919791
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    result = NRKRadioPodkastIE()._download_json(
        'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8',
        'MUHH48000314AA')
    return assertEqual(result['title'], '20 spørsmål 23.05.2014')

# Generated at 2022-06-12 17:57:42.117236
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank')
    assert NRKTVSeriesIE.suitable('https://tv.nrksuper.no/serie/labyrint')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/backstage')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/broedrene-dal-og-spektralsteinene')
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/postmann-pat')

# Generated at 2022-06-12 17:57:45.411053
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    """
    Unit test for constructor of class NRKRadioPodkastIE
    """
    ie = NRKRadioPodkastIE()
    ie.extract(NRKRadioPodkastIE._TESTS[0])


# Generated at 2022-06-12 17:57:46.196630
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie is not None

# Generated at 2022-06-12 17:57:49.398884
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert isinstance(ie, NRKPlaylistIE)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, NRKPlaylistBaseIE)


# Generated at 2022-06-12 17:57:56.870497
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    expect = {
        'id': '774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c',
        '_type': 'url_transparent',
        'url': 'nrk:774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c',
        'ie_key': 'NRK',
    }
    result = NRKRadioPodkastIE._build_url_result(url)
    assert result == expect



# Generated at 2022-06-12 17:57:59.761667
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    series = NRKTVSeriesIE.get_instance()
    _ = series.suitable('https://tv.nrk.no/serie/lindmo')

# Generated at 2022-06-12 17:59:10.034381
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    """Unit test for constructor of class NRKSkoleIE"""
    ie = NRKSkoleIE('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    assert ie.__name__ == 'NRKSkoleIE'
    test_url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    ie.url = test_url
    video_id = ie._match_id(test_url)
    assert video_id == '19355'


# Generated at 2022-06-12 17:59:14.452953
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    # The following test url is taken from actual url
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    assert ie.suitable(url)
    assert url == ie.url_result(url, ie=NRKIE.ie_key(), video_id='l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')



# Generated at 2022-06-12 17:59:15.603243
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()

# Generated at 2022-06-12 17:59:20.352735
# Unit test for constructor of class NRKTVEpisodeIE

# Generated at 2022-06-12 17:59:26.626040
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    """Test whether NRKTVSeasonIE is constructed correctly"""
    url = 'https://tv.nrk.no/serie/backstage/sesong/1';

    # Establish that the regex is correct
    season_ie_object = NRKTVSeasonIE;
    mobj = re.match(season_ie_object._VALID_URL, url);
    assert mobj.group('domain') == 'tv'
    assert mobj.group('serie_kind') == 'serie'
    assert mobj.group('serie') == 'backstage'
    assert mobj.group('id') == '1'
    assert mobj.group('id_2') is None



# Generated at 2022-06-12 17:59:32.155262
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    """Check if constructor of class NRKTVSerieBaseIE works."""
    from urllib.parse import urlparse
    from youtube_dl.utils import parse_iso8601
    from .nrktv import NRKTVSerieBaseIE
    episode_1_found = False
    episode_2_found = False
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#'
    display_id = 'tour-de-ski'
    info_dict = NRKTVSerieBaseIE()._real_extract(url)
    assert info_dict is not None
    assert info_dict['id'] == display_id
    assert info_dict['title'] == 'Tour de Ski'

# Generated at 2022-06-12 17:59:44.309654
# Unit test for constructor of class NRKTVEpisodesIE

# Generated at 2022-06-12 17:59:52.268605
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    class MockInfoExtractor(NRKPlaylistBaseIE):
        _VALID_URL = None
        _ITEM_RE = None
        IE_NAME = "MockInfoExtractor"
        _TESTS = [{
            'url': 'https://tv.nrk.no/peis',
            'only_matching': True,
        }]

    ie = MockInfoExtractor()
    for test_id, test in enumerate(ie._TESTS):
        mobj = re.match(ie._VALID_URL, test['url'])
        assert mobj is not None, '%s is not valid URL' % test['url']
        playlist_id = mobj.group(ie._PLAYLIST_ID_RE)

# Generated at 2022-06-12 17:59:53.965936
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    try:
        NRKTVEpisodeIE("Re: http://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2")
    except:
        assert False, "Test failed: NRKTVEpisodeIE doesn't parse URL correctly"

# Generated at 2022-06-12 17:59:56.499789
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert NRKTVSerieBaseIE._catalog_name('series') == 'series'
    assert NRKTVSerieBaseIE._catalog_name('podkast') == 'podcast'



# Generated at 2022-06-12 18:02:23.202015
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    id = 'l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    url = 'https://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/' + id
    NRKRadioPodkastIE(NRKRadioPodkastIE._create_get_info_extractor(url))



# Generated at 2022-06-12 18:02:24.097389
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE(None)
    assert ie.GEO_COUNTRIES == ['NO']

# Generated at 2022-06-12 18:02:28.912701
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # We can't try to construct the class,
    # as it fails when run in a unittest and
    # we don't want to catch exceptions from
    # subclass constructors.
    # Instead we run the same test as for NRKTVIE
    test_NRKTVIE()

# Generated at 2022-06-12 18:02:32.495495
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    site = NRKSkoleIE()
    assert site.name == 'nrk:skole'
    assert site.description == NRKSkoleIE.IE_DESC
    assert site.ie_key() == 'nrk:skole'
    assert site.thumbnail == 're:^https?://.*\.jpg$'
    assert site.valid_url('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert site.valid_url('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')

# Generated at 2022-06-12 18:02:39.148014
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    podkastIE = NRKRadioPodkastIE()
    assert podkastIE.suitable('https://radio.nrk.no/podkast/nrkno-poddkast-19582-134079-05042018030000')
    assert podkastIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers')
    assert podkastIE.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')

# Generated at 2022-06-12 18:02:45.135312
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-12 18:02:50.611335
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-12 18:02:52.512125
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/lindmo/2019'
    nrktv_season_ie = NRKTVSeasonIE()

    assert nrktv_season_ie.suitable(url)



# Generated at 2022-06-12 18:02:55.351252
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE(None)._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-12 18:03:06.271108
# Unit test for constructor of class NRKTVSeasonIE