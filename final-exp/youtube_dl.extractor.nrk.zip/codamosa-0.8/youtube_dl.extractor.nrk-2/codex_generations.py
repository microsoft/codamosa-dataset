

# Generated at 2022-06-12 17:57:25.943357
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        NRKTVSeriesIE('nrk:%s' % 'MUHH36005220')
        assert False
    except RegexNotFoundError:
        pass

# Generated at 2022-06-12 17:57:34.619147
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    video_id = 'series/hellums-kro'

# Generated at 2022-06-12 17:57:43.346186
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert(ie.IE_NAME == 'nrk')
    assert(ie.IE_DESC == 'NRK')
    assert(ie.VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        ''')
    assert(ie.GEO_COUNTRIES == ['NO'])

# Generated at 2022-06-12 17:57:55.997505
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    i = NRKTVSeasonIE()
    assert isinstance(i, NRKTVSeasonIE)
    assert isinstance(i, NRKTVSerieBaseIE)
    assert isinstance(i, NRKBaseIE)
    assert isinstance(i, InfoExtractor)
    assert hasattr(i, '_VALID_URL')
    assert hasattr(i, '_TESTS')
    assert hasattr(i, '_ASSETS_KEYS')
    assert hasattr(i, '_extract_entries')
    assert hasattr(i, '_extract_assets_key')
    assert hasattr(i, '_catalog_name')
    assert hasattr(i, '_entries')
    assert hasattr(i, '_download_webpage')
    assert hasattr(i, '_call_api')

# Generated at 2022-06-12 17:57:57.351833
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()

# Generated at 2022-06-12 17:57:58.008425
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE()

# Generated at 2022-06-12 17:57:59.549804
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """Test constructor of class NRKTVDirekteIE."""
    NRKTVDirekteIE

# Generated at 2022-06-12 17:58:04.739315
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    info_extractor = NRKTVSerieBaseIE()
    assert info_extractor.url_result('http://www.youtube.com/watch?v=BaW_jenozKc') == {
        '_type': 'url',
        'ie_key': 'Youtube',
        'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
    }



# Generated at 2022-06-12 17:58:10.208467
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')
    assert re.match(NRKTVSeasonIE._VALID_URL, 'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant') is not None
    assert ie.extract()['id'] == 'hele_historien/diagnose-kverulant'
    assert ie.extract()['title'] == 'Diagnose kverulant'



# Generated at 2022-06-12 17:58:20.946688
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():

    def assert_result_for_url(url, expected_result):
        ie = NRKTVDirekteIE(DummyIE(url=url))
        assert ie.url == expected_result
        assert ie._VALID_URL == expected_result

    assert_result_for_url('https://tv.nrk.no/direkte/nrk1', r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)')
    assert_result_for_url('https://radio.nrk.no/direkte/p1_oslo_akershus', r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)')


# Generated at 2022-06-12 17:59:30.015122
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE()



# Generated at 2022-06-12 17:59:39.447800
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Test with an episode
    tv = NRKTVIE(NRKTVIE._downloader,
                 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015',
                 'test_episode')
    assert_equal('nrk', tv._site)
    assert_equal('MSPO40010515', tv._id)

    # Test with a playlist video
    tv = NRKTVIE(NRKTVIE._downloader,
                 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2',
                 'test_playlist')
    assert_equal('nrk', tv._site)
    assert_equal('MSPO40010515', tv._id)
   

# Generated at 2022-06-12 17:59:49.868225
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    module = NRKTVDirekteIE()
    assert module.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert module._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert module._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]


# Generated at 2022-06-12 17:59:59.387304
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-12 18:00:08.646645
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    input_url = 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355'
    expected_url = 'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/19355'
    expected_ie = 'nrk:6021'
    expected_playlist_count = 0
    expected_playlist_mincount = 0

    ie = NRKSkoleIE(NRKSkoleIE.ie_key())
    ie.googletag = GoogleTag(input_url, ie)

    # Unit test - test download of webpage
    webpage = ie._download_webpage(input_url, ie.googletag.video_id)
    assert webpage

    # Unit test - test

# Generated at 2022-06-12 18:00:09.931156
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()  # no exception



# Generated at 2022-06-12 18:00:21.249525
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():

    assert(issubclass(NRKPlaylistBaseIE, InfoExtractor)) # Test that NRKPlaylistBaseIE is a subclass of InfoExtractor
    assert(hasattr(NRKPlaylistBaseIE, '_real_extract')) # Test that NRKPlaylistBaseIE has a real_extract function
    assert(hasattr(NRKPlaylistBaseIE, '_extract_description')) # Test that NRKPlaylistBaseIE has a extract_description function
    assert(hasattr(NRKPlaylistBaseIE, '_ITEM_RE')) # Test that NRKPlaylistBaseIE has a ITEM_RE value
    assert(hasattr(NRKPlaylistBaseIE, 'IE_NAME')) # Test that NRKPlaylistBaseIE has a IE_NAME value

# Generated at 2022-06-12 18:00:25.909090
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE.IE_DESC == 'NRK TV and NRK Radio'
    assert NRKTVIE._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % NRKTVIE._EPISODE_RE


# Generated at 2022-06-12 18:00:28.888857
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    NRKTVIE._VALID_URL.__doc__ == 'Valid URLs for NRKTVIE'
    NRKTVIE._TESTS.__doc__ == 'Test cases for NRKTVIE'

# Generated at 2022-06-12 18:00:30.007832
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    object = NRKTVSerieBaseIE()
    assert object._ASSETS_KEYS == ('episodes', 'instalments',)



# Generated at 2022-06-12 18:02:04.499753
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    http = requests.get('https://nrkno-skole-prod.kube.nrk.no/skole/api/media/14099')
    ud = http.json()
    print(ud['psId'])


# Generated at 2022-06-12 18:02:08.906931
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    base = NRKTVSerieBaseIE()
    entries = base._extract_entries([{'prfId': 'MUHH36005220'}, {'episodeId': 'MSPO13082416'}])
    assert entries == [
        {'_type': 'url', 'id': 'MUHH36005220', 'url': 'nrk:MUHH36005220', 'ie_key': 'NRK'},
        {'_type': 'url', 'id': 'MSPO13082416', 'url': 'nrk:MSPO13082416', 'ie_key': 'NRK'}
    ]
    base = NRKTVSerieBaseIE()
    entries = base._extract_entries({'prfId': 'MUHH36005220'})
    assert entries == []

# Generated at 2022-06-12 18:02:12.306931
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    """
    Simple test for constructor of class.
    """
    serie_base_info_extractor = NRKTVSerieBaseIE()
    assert serie_base_info_extractor._extract_entries([]) == []



# Generated at 2022-06-12 18:02:21.151736
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    webpage = _download_webpage(url, 'hello')

    info = _search_json_ld(webpage, 'hello', default={})
    nrk_id = info.get('@id') or _html_search_meta(
            'nrk:program-id', webpage, default=None) or _search_regex(
            r'data-program-id=["\']([a-zA-Z]{4}\d{8})', webpage,
            'nrk id')
    assert re.match(NRKTVIE._EPISODE_RE, nrk_id)


# Generated at 2022-06-12 18:02:24.394119
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE.__bases__ == (InfoExtractor,)
    result = NRKPlaylistBaseIE()
    assert result is not None


# Generated at 2022-06-12 18:02:28.416653
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    test = NRKTVDirekteIE()
    assert isinstance(test, NRKTVIE)
    assert isinstance(test, InfoExtractor)
    assert isinstance(test, object)


# Generated at 2022-06-12 18:02:39.363622
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert isinstance(ie, NRKBaseIE)
    assert not isinstance(ie, NRKTVIE)
    assert ie._VALID_URL is None
    assert ie._TESTS is None
    assert ie.IE_NAME == 'nrk:base-serie'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'https://nrk.brightcove.com/viewer/video/Ref:%s'
    assert ie._EPISODE_RE is None
    assert ie._extract_entries is NRKTVSerieBaseIE._extract_entries
    assert ie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert ie._ext

# Generated at 2022-06-12 18:02:42.883635
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE._call_api = lambda a, b, c, **d: {}
    generator = NRKTVSerieBaseIE(
        '', '', 'https://tv.nrk.no/program/mdfp13000416')._entries(dict(), 'mdfp13000416')
    assert isinstance(generator, types.GeneratorType)
    assert tuple(generator) == ()


# Generated at 2022-06-12 18:02:50.553025
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    import unittest
    from youtube_dl.extractor import YoutubeDL
    from youtube_dl.utils import BrokenPageError

    class TestNRKTVDirekteIE(unittest.TestCase):
        def test_working(self):
            ydl_opts = {}
            NRKTVDirekteIE().working = lambda: True
            ydl = YoutubeDL(ydl_opts)
            self.assertEqual(
                ydl.extract_info(
                    'https://tv.nrk.no/direkte/nrk1',
                    download=False),
                ydl.extract_info(
                    'https://www.nrk.no/tv/direkte/nrk1',
                    download=False))

        def test_broken(self):
            ydl_opts = {}

# Generated at 2022-06-12 18:02:52.888557
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE(None)
    assert isinstance(ie, NRKPlaylistBaseIE)

# Generated at 2022-06-12 18:06:00.294241
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    info_dict = {
        'id': '69031',
        'title': 'Nytt på nytt',
        'description': 'md5:0c8b96f36d3eb3b0f9174c8dca1bae56',
    }
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    m = NRKTVEpisodesIE(url)
    assert m.url == url
    assert m._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'
    assert m._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE

# Generated at 2022-06-12 18:06:02.976784
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Object of class InfoExtractor
    nrk_tv_ie = NRKTVIE()

    # Test that the _VALID_URL is equal to _VALID_URL of NRKIE
    assert nrk_tv_ie._VALID_URL == NRKIE._VALID_URL

    # Test that the _TESTS is equal to _TESTS of NRKIE
    assert nrk_tv_ie._TESTS == NRKIE._TESTS

# Generated at 2022-06-12 18:06:04.912715
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktv_serie_base_ie = NRKTVSerieBaseIE()
    assert nrktv_serie_base_ie is not None


# Generated at 2022-06-12 18:06:06.926221
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = "http://nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355"
    assert url == NRKSkoleIE(NRKSkoleIE.ie_key(), url).url, "Url check failed"


# Generated at 2022-06-12 18:06:07.632128
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('NRK')



# Generated at 2022-06-12 18:06:11.938894
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRK')
    assert ie.IE_NAME == 'NRK'
    assert ie._WORKING == False
    assert isinstance(ie._GEO_COUNTRIES, list)
    assert isinstance(ie._CDN_REPL_REGEX, str)



# Generated at 2022-06-12 18:06:13.759856
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """Unit test for constructor of class NRKTVEpisodeIE."""
    print("Running test for constructor of class NRKTVEpisodeIE.")
    nrktv_episode_ie = NRKTVEpisodeIE()
    print("\nTest succeeded.")


# Generated at 2022-06-12 18:06:18.466975
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """Tests the constructor of NRKTVEpisodeIE"""
    url = "https://tv.nrk.no/serie/backstage/sesong/1/episode/8"
    info = {"id": "MSUI14000816",
            "ext": "mp4",
            "title": "Backstage - 8. episode",
            "description": "md5:de6ca5d5a2d56849e4021f2bf2850df4",
            "duration": 1320,
            "series": "Backstage",
            "season_number": 1,
            "episode_number": 8,
            "episode": "8. episode",
            "age_limit": 0
            }
    ie = NRKTVEpisodeIE()
    assert ie._real_extract(url) == info

# Generated at 2022-06-12 18:06:20.437160
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE({})._VALID_URL == NRKBaseIE._VALID_URL

