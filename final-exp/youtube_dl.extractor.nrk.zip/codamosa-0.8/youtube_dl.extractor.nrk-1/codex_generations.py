

# Generated at 2022-06-12 17:57:27.419174
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE(
        {}, {'url': 'https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015'})
    assert ie.params == {'skip_download': True}
    assert ie.extract_url == 'https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie.compat_str == 'NRKTVIE()'
    # Unit test for constructor of class NRKIE

# Generated at 2022-06-12 17:57:29.095675
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    x = NRKSkoleIE()
    assert 'nrk:6021' == x._real_extract('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')



# Generated at 2022-06-12 17:57:33.370606
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable(NRKTVIE.ie_key()) == False
    assert ie.suitable(NRKTVEpisodeIE.ie_key()) == False
    assert ie.suitable(NRKRadioPodcastIE.ie_key()) == False
    assert ie.suitable(NRKTVSeasonIE.ie_key()) == False

# Generated at 2022-06-12 17:57:36.991511
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Instance of InfoExtractor
    ie = InfoExtractor()
    # That is NRKBaseIE
    assert isinstance(ie, NRKBaseIE)


# Generated at 2022-06-12 17:57:38.868365
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekteIE = NRKTVDirekteIE(None)
    assert nrktvdirekteIE is not None

# Generated at 2022-06-12 17:57:43.921459
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    '''
    Test constructor of class NRKPlaylistBaseIE
    '''
    NRKPlaylistBaseIE(NRKPlaylistBaseIE.ie_key(), NRKPlaylistBaseIE.IE_NAME)


# Generated at 2022-06-12 17:57:56.403490
# Unit test for constructor of class NRKPlaylistIE

# Generated at 2022-06-12 17:57:57.529478
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    pass

# Generated at 2022-06-12 17:58:04.611550
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    #videos not available or removed
    urls_not_available = [
        'https://tv.nrk.no/serie/lindmo/2018/MUHU11006318/avspiller',
        'https://tv.nrk.no/serie/nytt-paa-nytt/MUHH46000317/27-01-2017'
    ]
    for url_not_available in urls_not_available:
        assert NRKTVIE()._is_valid_url(url_not_available) == True


# Generated at 2022-06-12 17:58:13.804180
# Unit test for constructor of class NRKIE
def test_NRKIE():
    class TestNRKIE(NRKIE):
        IE_NAME = 'nrk'
    ie = TestNRKIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert re.search(r'^(?:bw_(?:low|high)=\d+|no_audio_only)&?$', 'bw_high=1477')

# Generated at 2022-06-12 17:59:30.869418
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert re.match(NRKTVEpisodeIE._VALID_URL, 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8')
    assert (re.match(NRKTVIE._EPISODE_RE, 'MUHH36005220') != None)
    assert (re.match(NRKTVIE._EPISODE_RE, 'MSUI14000816') != None)

# Generated at 2022-06-12 17:59:35.455294
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    from .test_extractor_common import TestExtractorCommon
    test = TestExtractorCommon('nrktv:MUHH36005220')
    instance = test.get_instance(NRKTVEpisodeIE)
    assert isinstance(instance, NRKTVEpisodeIE)
    assert instance.EXTENSIONS == ('mp4', 'm3u8')
    assert instance.format_id == 'nrk_info'
    assert instance.episode_title == '2. Kro, krig og kjærlighet'
    assert instance.series_title == 'Hellums kro'
    assert instance.season_number == 1
    assert instance.episode_number == 2


# Generated at 2022-06-12 17:59:38.414096
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    test_url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    test_obj = NRKSkoleIE()
    result = test_obj.suitable(test_url)
    assert(result)


# Generated at 2022-06-12 17:59:46.695421
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrk_tv = NRKTVIE()
    assert nrk_tv._EPISODE_RE == '(?P<id>[a-zA-Z]{4}\d{8})'
    assert nrk_tv._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % nrk_tv._EPISODE_RE
    assert nrk_tv.IE_DESC == 'NRK TV and NRK Radio'

# Generated at 2022-06-12 17:59:49.141701
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_case = NRKTVEpisodeIE(NRKTVEpisodeIE.IE_NAME)
    test_case._VALID_URL = NRKTVEpisodeIE._VALID_URL
    test_case._TESTS = NRKTVEpisodeIE._TESTS
    test_case.IE_DESC = NRKTVEpisodeIE.IE_DESC
    return test_case


# Generated at 2022-06-12 17:59:53.204078
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE(NRKTVDirekteIE.suitable(NRKTVDirekteIE.ie_key()))
    assert ie.__class__ == NRKTVDirekteIE



# Generated at 2022-06-12 17:59:54.246293
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from .nrktv import NRKTVDirekteIE
    assert NRKTVDirekteIE is not None


# Generated at 2022-06-12 18:00:04.251715
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    try:
        NRKTVEpisodesIE(NRKTVEpisodesIE._TESTS[0])
    except Exception:
        assert False, '_TESTS[0] failed'
    try:
        NRKTVEpisodesIE(NRKTVEpisodesIE._TESTS[0]['url'])
    except Exception:
        assert False, '_TESTS[0]["url"] failed'
    try:
        NRKTVEpisodesIE(NRKTVEpisodesIE._TESTS[0]['url'], NRKTVEpisodesIE._TESTS[0]['id'])
    except Exception:
        assert False, '_TESTS[0]["url"]+id failed'
    return True


# Generated at 2022-06-12 18:00:05.443983
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    I = NRKBaseIE('NRB')
    assert I.name == 'NRB'
    assert I._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-12 18:00:09.484058
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    obj = NRKBaseIE()
    assert obj.geo_countries == ['NO']
    assert obj.cdn_regex == '(?x)://\n            nrkod\\d{1,2}-httpcache0-47115-cacheod0\\.dna\\.ip-only\\.net/47115-cacheod0|\n            nrk-od-no\\.telenorcdn\\.net|\n            minicdn-od\\.nrk\\.no/od/nrkhd-osl-rr\\.netwerk\\.no/no\n        /'


# Generated at 2022-06-12 18:02:44.486885
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    class DummyClass(object):
        def __init__(self, name):
            self.name = name
    class DummyNRKTVSerieBaseIE(NRKTVSerieBaseIE):
        _VALID_URL = r'https?://(?P<id>.+)'
        _TESTS = [{
            'url': 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2',
            'playlist_mincount': 12,
        }]
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'

# Generated at 2022-06-12 18:02:49.459516
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    info_extractor = NRKTVEpisodeIE()
    assert info_extractor._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert info_extractor == NRKTVEpisodeIE()


# Generated at 2022-06-12 18:02:52.050207
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._ITEM_RE == NRKPlaylistBaseIE._ITEM_RE



# Generated at 2022-06-12 18:02:58.049758
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test extractor using self._TESTS instance variable
    for test in NRKPlaylistIE._TESTS:
        # Instantiate extractor, using given URL
        ie = NRKPlaylistIE(NRKPlaylistIE._downloader, test['url'])
        # Test whether the URL given was valid
        assert ie._match_id(test['url']) is not None
        # Test whether the URL did not get any updates during extraction
        _, urlh = ie._download_webpage_handle(test['url'], test['id'])
        assert urlh.geturl() == test['url']
        # Test whether the expected title was found
        assert ie._og_search_title(None, test.get('title_regex'), default=None) == test.get('title')
        # Test whether the expected description was found
       

# Generated at 2022-06-12 18:03:01.492401
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Test that the NRKPlaylistBaseIE class is correctly instantiated
    obj = NRKPlaylistBaseIE('', {})
    assert obj


# Generated at 2022-06-12 18:03:06.318816
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrk_ie = NRKTVEpisodesIE()
    # Check if constructor gets the right parameters
    assert nrk_ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert nrk_ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE


# Generated at 2022-06-12 18:03:10.177993
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE._TESTS[0]['info_dict'] == {
        'id': 'hundre-for-oss',
        'title': 'Hundre for oss',
    }


# Generated at 2022-06-12 18:03:15.911006
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    #Instantiate class NRKRadioPodkastIE
    ie = NRKRadioPodkastIE();
    #Check that ie object is instantiated
    assert ie !=None, "NRKRadioPodkastIE instance not created"



# Generated at 2022-06-12 18:03:17.760461
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._match_id('dummy_url') == None
    assert ie._extract_description('dummy_webpage') == None



# Generated at 2022-06-12 18:03:20.653075
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    import tests.test_utils as test_utils
    from unittest import TestCase

    package = 'tests.ie.nrk.test_NRKTVIE'
    test_utils.run_tests(package, TestCase)
