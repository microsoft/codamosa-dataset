

# Generated at 2022-06-12 17:57:19.995837
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    result = NRKTVEpisodeIE().extract(
        'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')
    assert result['id'] == 'MUHH36005220'
    assert result['title'] == 'Hellums kro - 2. Kro, krig og kjærlighet'

# Generated at 2022-06-12 17:57:20.451549
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    NRKBaseIE()

# Generated at 2022-06-12 17:57:32.622894
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE.suitable('http://www.nrk.no/video/') == False
    assert NRKPlaylistIE.suitable('http://tv.nrk.no/video') == False
    assert NRKPlaylistIE.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763') == True
    assert NRKPlaylistIE.suitable('https://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449') == True
    assert NRKPlaylistIE.suitable('https://radio.nrk.no/direkte/p1_oslo_akershus') == False


# Generated at 2022-06-12 17:57:34.947505
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    obj_NRKTVEpisodeIE = NRKTVEpisodeIE();
    assert obj_NRKTVEpisodeIE._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'



# Generated at 2022-06-12 17:57:36.631328
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    pass

# Generated at 2022-06-12 17:57:45.242173
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/blank'
    assert NRKTVSeriesIE.suitable(url) is True
    nrk_series = NRKTVSeriesIE(url)
    assert repr(nrk_series) == '<NRKTVSeriesIE(blank)>'
    assert nrk_series._VALID_URL == NRKTVSeriesIE._VALID_URL

# Generated at 2022-06-12 17:57:54.633423
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        entry = dict(NRKTVSerieBaseIE())
    except TypeError:
        entry = dict(NRKTVSerieBaseIE(None))
    assert isinstance(entry, dict)
    assert isinstance(entry['_ASSETS_KEYS'], tuple)
    assert (entry['_ASSETS_KEYS'] == ('episodes', 'instalments',))
    assert isinstance(entry['_VALID_URL'], compat_str)
    assert not entry['_VALID_URL']



# Generated at 2022-06-12 17:58:05.823613
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    info = NRKTVIE('https://tv.nrk.no/program/MDDP12000117')
    assert info.url == 'nrk:MDDP12000117'
    assert info.video_id == 'MDDP12000117'
    assert info.title is None
    assert info.duration is None
    assert info.age_limit is None

    info = NRKTVIE('https://tv.nrk.no/program/mdfp15000514')
    assert info.url == 'nrk:mdfp15000514'
    assert info.video_id == 'mdfp15000514'
    assert info.title is None
    assert info.duration is None
    assert info.age_limit is None


# Generated at 2022-06-12 17:58:14.491835
# Unit test for constructor of class NRKPlaylistIE

# Generated at 2022-06-12 17:58:15.924765
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert isinstance(NRKTVSeriesIE(
        NRKTVIE()), NRKTVSerieBaseIE)



# Generated at 2022-06-12 17:59:28.515682
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert 'NRKTVEpisodesIE' == NRKTVEpisodesIE.__name__


# Generated at 2022-06-12 17:59:29.435856
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE()

# Generated at 2022-06-12 17:59:34.487069
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE(url='https://tv.nrk.no/direkte/nrk1')
    res_id = ie._call_api(
        'tv/programs/direkte', 'nrk1', 'direkte', query={'pageSize': 50}
    )
    nrk_id = res_id['id']
    info_id = res_id['info']
    assert nrk_id == 'TVV00013428'
    assert info_id == 'TVV00013428'

# Generated at 2022-06-12 17:59:35.274727
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    a = NRKRadioPodkastIE()



# Generated at 2022-06-12 17:59:38.857768
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    NRKTVEpisodesIE(url)



# Generated at 2022-06-12 17:59:48.157048
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/dicte/sesong/1/episode/7'
    _, data = test_download_json(
        url.replace('/episode/7', ''), NRKTVSeasonIE.ie_key())

    expected = {
        'url': 'https://tv.nrk.no/serie/dicte/sesong/1',
        '_type': 'url_transparent',
        'ie_key': 'NRKTV',
        'url_transparent': 'nrk:MUHH36000710',
    }
    assert_dict_equal(data, expected)

# Generated at 2022-06-12 17:59:48.931592
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # Test constructor
    NRKSkoleIE()

# Generated at 2022-06-12 17:59:58.707835
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    # constructor of class InfoExtractor
    nrktvepi = NRKTVEpisodesIE(
        {}, {}, {}, {}, {}, {})
    # test if the method _real_extract returns a dictionary
    assert isinstance(nrktvepi._real_extract(url), dict)
    # test if the method _real_extract returns a dict with field
    # 'playlist'
    assert 'playlist' in nrktvepi._real_extract(url).keys()
    # test if the method _real_extract returns a dict with field
    # 'playlist_mincount'

# Generated at 2022-06-12 18:00:02.253215
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    obj = NRKSkoleIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)', "Error"

# Generated at 2022-06-12 18:00:04.847345
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(None, None, None)
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podkast') == 'podcast'
    assert ie._catalog_name('something') == 'series'



# Generated at 2022-06-12 18:02:32.574430
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE()
    assert isinstance(ie, NRKIE)



# Generated at 2022-06-12 18:02:38.267485
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    tv_direkte = NRKTVDirekteIE(url)
    new_url = tv_direkte._real_extract(tv_direkte._VALID_URL, url)
    assert new_url['ie_key'] == TVNorgeIE.ie_key()

# Generated at 2022-06-12 18:02:48.419669
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrkIE = NRKIE()

# Generated at 2022-06-12 18:02:54.255404
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    test_url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    # Instantiate NRKRadioPodkastIE class
    NRKRadioPodkastIE_object = NRKRadioPodkastIE()
    # Check if URL parses correctly
    if not NRKRadioPodkastIE_object._match_id(test_url):
        raise Exception('NRKRadioPodkastIE URL does not parse correctly')
    # Extract video ID
    video_id = NRKRadioPodkastIE_object._match_id(test_url)
    # Check if correct video ID is extracted

# Generated at 2022-06-12 18:02:56.569666
# Unit test for constructor of class NRKIE
def test_NRKIE():
    pl = itertools.product('abc', 'def', 'ghi', 'ab')
    for i in pl:
        url = '%s%s%s%s' % i
        url_ = '%s/%s/%s/%s' % i
        assert NRKIE._VALID_URL.match(url)
        assert NRKIE._VALID_URL.match(url_)

# Generated at 2022-06-12 18:03:08.315962
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrktv_series_ie = NRKTVSeriesIE()


# Generated at 2022-06-12 18:03:14.796688
# Unit test for constructor of class NRKTVSerieBaseIE

# Generated at 2022-06-12 18:03:23.998664
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvseasontest = NRKTVSeasonIE("test.org")
    assert nrktvseasontest._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''

# Generated at 2022-06-12 18:03:25.710935
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    return NRKPlaylistIE



# Generated at 2022-06-12 18:03:26.489488
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE('NRK Skole', '0')
