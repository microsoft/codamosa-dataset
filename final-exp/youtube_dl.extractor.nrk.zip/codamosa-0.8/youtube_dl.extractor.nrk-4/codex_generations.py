

# Generated at 2022-06-12 17:57:28.590964
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist = NRKPlaylistIE()
    # Assert of the url in _VALID_URL
    assert playlist._VALID_URL=='https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    # Assert of the name of the site
    assert playlist.IE_NAME == 'nrk.no:playlist'
    # Assert of the regex type in _ITEM_RE
    assert re.match(playlist._ITEM_RE, 'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"')



# Generated at 2022-06-12 17:57:33.395411
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # For some reason this unit test fails if run by itself. When run together with other unit tests in
    # the same python process, it seems to run OK.
    ie = NRKTVEpisodesIE()
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS[0]['url'] == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert ie._TESTS[0]['info_dict'] == {'id': '69031', 'title': 'Nytt på nytt, sesong: 201210'}
    assert ie._TESTS[0]['playlist_count'] == 4


# Generated at 2022-06-12 17:57:35.033452
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert not hasattr(NRKTVDirekteIE, '_call_api')
    NRKTVDirekteIE()
    assert NRKTVDirekteIE._call_api.__name__ == 'call_api'



# Generated at 2022-06-12 17:57:36.984747
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skoleIE = NRKSkoleIE()
    assert isinstance(nrk_skoleIE, NRKSkoleIE)
    assert isinstance(nrk_skoleIE, InfoExtractor)
    assert isinstance(nrk_skoleIE, NRKBaseInfoExtractor)


# Generated at 2022-06-12 17:57:39.410415
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-12 17:57:40.628234
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    sie = NRKTVSeasonIE()

    assert not sie.suitable(NRKTVIE())
    assert not sie.suitable(NRKRadioPodkastIE())



# Generated at 2022-06-12 17:57:43.491724
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
            assert NRKBaseIE._GEO_COUNTRIES == ['NO']


# Generated at 2022-06-12 17:57:49.850090
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://radio.nrk.no/direkte/p1_oslo_akershus'
    treg = NRKTVDirekteIE.suitable(url)
    assert treg is not False, 'url = {}'.format(url)


# Generated at 2022-06-12 17:57:51.692128
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKBaseIE', {})
    assert ie is not None

# Generated at 2022-06-12 17:57:55.612252
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    from .nrk import NRKRadioPodkastIE
    play_url ='https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    d = NRKRadioPodkastIE.suitable(play_url)


# Generated at 2022-06-12 17:59:00.886388
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE(webpage='', video_id='nrk1')



# Generated at 2022-06-12 17:59:03.956699
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    new_constructor = NRKTVEpisodeIE('NRKTVEpisodeIE', NRKTVEpisodeIE._VALID_URL, NRKTVEpisodeIE._TESTS)
    new_constructor._real_extract(NRKTVEpisodeIE._TESTS[0]['url'])

# Generated at 2022-06-12 17:59:05.316949
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE('NRKTVSeasonIE', {})
    assert isinstance(ie, NRKTVSeasonIE)



# Generated at 2022-06-12 17:59:15.089065
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # This test is not meant to be run.
    # It just compares the output of the constructor to the expected output
    # This is to make sure that:
    # 1. Changes to the constructor don't destroy the regexes
    # 2. Addition of new regexes don't cause false positives

    # The expected output is ordered alphabetically
    expected = [
        re.compile(r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'),
    ]

    nrktvie = NRKTVIE()
    output = nrktvie._VALID_URL.__getattribute__('re')

    # Check that the regexes are the same
    assert output == expected


# Generated at 2022-06-12 17:59:17.993017
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('NRKTVDirekteIE', 'tv.nrk.no')
    assert ie != None


# Generated at 2022-06-12 17:59:27.958026
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    class TestPlaylistBase(NRKPlaylistBaseIE):
        _VALID_URL = 'https://example.com/playlist/playlist-id'
        _ITEM_RE = r'<div class="nrk-playlist-item" data-video-id="(?P<id>[^"]+)"'
        _TITLE_RE = r'<h1>(?P<title>[^<]+)</h1>'

        def _extract_title(self, webpage):
            return self._html_search_regex(
                self._TITLE_RE, webpage, 'playlist title')

        def _extract_description(self, webpage):
            return self._html_search_regex(
                self._DESCRIPTION_RE, webpage, 'playlist description')


# Generated at 2022-06-12 17:59:33.254232
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''


# Generated at 2022-06-12 17:59:35.599590
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(None)
    assert isinstance(ie, NRKTVSerieBaseIE)



# Generated at 2022-06-12 17:59:47.936431
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    sub_url = 'http://nrk-no.akamaized.net/i/mp4/test_revision.vtt'
    sub_key = 'nb-ttv'
    sub_type = 'webvtt'
    episode_info = {
        'prfId': 'test_prfId',
        'title': {'body': 'Episode Title'},
        'description': {'body': 'Description'},
        'legalAge': {'body': {'rating': {'code': '7'}}},
        '_links': {'series': {'name': 'series'}},
        '_embedded': {'subtitles': [{
            'url': sub_url, 'key': sub_key, 'type': sub_type}]},
    }

# Generated at 2022-06-12 17:59:51.625421
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebase_instance = NRKTVSerieBaseIE()
    assert isinstance(nrktvseriebase_instance, NRKTVSerieBaseIE)



# Generated at 2022-06-12 18:02:26.312094
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
	from .nrktv import NRKTVEpisodesIE
	s = NRKTVEpisodesIE()
	pass


# Generated at 2022-06-12 18:02:26.881522
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()



# Generated at 2022-06-12 18:02:28.666841
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE("NRKTV", "NRK")


# Generated at 2022-06-12 18:02:32.115192
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')

# Generated at 2022-06-12 18:02:39.911350
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert not NRKPlaylistBaseIE.suitable(NRKTVIE()._VALID_URL)
    assert not NRKPlaylistBaseIE.suitable(NRKTVEpisodeIE()._VALID_URL)
    assert not NRKPlaylistBaseIE.suitable(NRKTVSeasonIE()._VALID_URL)
    assert not NRKPlaylistBaseIE.suitable(NRKTVSeriesIE()._VALID_URL)
    assert not NRKPlaylistBaseIE.suitable(NRKTVDirekteIE()._VALID_URL)
    assert not NRKPlaylistBaseIE.suitable(NRKRadioPodkastIE()._VALID_URL)


# Generated at 2022-06-12 18:02:40.870869
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie._TESTS

# Generated at 2022-06-12 18:02:41.623435
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
        b = NRKTVEpisodesIE()
        self_ = vars(b)

# Generated at 2022-06-12 18:02:47.482799
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    try:
        assert_raises(AssertionError, NRKTVIE, url)
    except AssertionError as e:
        assert isinstance(e, AssertionError)
        assert str(e) == 'URL is not a valid NRK TV Direkte or NRK Radio Direkte URL!'
    assert isinstance(NRKTVDirekteIE(url), NRKTVDirekteIE)



# Generated at 2022-06-12 18:02:58.750116
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    ie = NRKRadioPodkastIE()
    assert ie._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert ie._real_extract(url).url == 'nrk:%s' % ie._match_id(url)

# Generated at 2022-06-12 18:03:02.297912
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert hasattr(NRKBaseIE, '_extract_nrk_formats')
    assert hasattr(NRKBaseIE, '_raise_error')
    assert hasattr(NRKBaseIE, '_call_api')
