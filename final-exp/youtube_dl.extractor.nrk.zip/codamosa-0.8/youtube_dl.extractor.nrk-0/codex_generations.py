

# Generated at 2022-06-12 17:57:24.823438
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/lindmo/2016')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1')
    assert NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/spangas/sesong/1')

# Generated at 2022-06-12 17:57:27.518194
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'


# Generated at 2022-06-12 17:57:28.525311
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    NRKPlaylistIE()


# Generated at 2022-06-12 17:57:31.139122
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert(NRKPlaylistIE._VALID_URL)
    assert(NRKPlaylistIE._ITEM_RE)
    assert(NRKPlaylistIE._TESTS)


# Generated at 2022-06-12 17:57:34.773839
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    obj = NRKBaseIE('http://tv.nrk.no/serie/skam', 'http://tv.nrk.no/skam/f5528e5c-caeb-4a1f-a9be-9682c2d8f8a4/skam.json')
    assert isinstance(obj, NRKBaseIE)


# Generated at 2022-06-12 17:57:43.433429
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte') == False
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/') == False
    assert NRKTVDirekteIE.suitable('http://tv.nrk.no/direkte') == True
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1') == True
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1/crew') == False

# Generated at 2022-06-12 17:57:47.709877
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    i = NRKTVEpisodesIE()
    assert i._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert i._TESTS[0]['url'] == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert i._TESTS[0]['info_dict']['id'] == '69031'
    assert i._TESTS[0]['info_dict']['title'] == 'Nytt på nytt, sesong: 201210'
    assert i._TESTS[0]['playlist_count'] == 4

# Generated at 2022-06-12 17:57:54.306623
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktvdirekte_ie = NRKTVDirekteIE()
    assert nrktvdirekte_ie.IE_NAME == 'nrktv:direkte'
    assert nrktvdirekte_ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert nrktvdirekte_ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:57:58.899014
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    for test in NRKTVIE._TESTS:
        url = test['url']
        assert url == NRKTVIE(NRKTVIE.IE_NAME, url, test)._TEST.get('url')

# Generated at 2022-06-12 17:58:07.792451
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    entry_list = [{'prfId': 'MUHH36005220'}, {'episodeId': 'MUHH36005220'}, {}]
    entries = NRKTVSerieBaseIE._extract_entries(entry_list)
    assert len(entries) == 2
    embedded = {'episodes': {'_embedded': {'episodes': entry_list}}}
    assert NRKTVSerieBaseIE._extract_assets_key(embedded) == 'episodes'
    embedded = {'episodes': entry_list}
    assert NRKTVSerieBaseIE._extract_assets_key(embedded) == 'episodes'
    embedded = {'instalments': entry_list}
    assert NRKTVSerieBaseIE._extract_assets_key(embedded) == 'instalments'

# Generated at 2022-06-12 17:59:16.804586
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    ie = NRKRadioPodkastIE(NRKIE(), url)
    assert ie.url == url, ie.url
    assert ie._VALID_URL == (r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+'
                             r'(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'), ie._VALID_URL
    assert ie._match_id(url)

# Generated at 2022-06-12 17:59:19.299163
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie=NRKRadioPodkastIE()

# Generated at 2022-06-12 17:59:22.858113
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    NRKSkoleIE(url=url)



# Generated at 2022-06-12 17:59:24.316843
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test for i != None
    infoExtractor = NRKPlaylistIE('Mock URL')
    assert infoExtractor != None



# Generated at 2022-06-12 17:59:29.114950
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie.IE_NAME == 'nrk'
    assert ie.IE_DESC == 'NRK TV'
    assert ie._VALID_URL == NRKIE._VALID_URL
    assert ie._GEO_COUNTRIES == NRKBaseIE._GEO_COUNTRIES
    assert ie._CDN_REPL_REGEX == NRKBaseIE._CDN_REPL_REGEX


# Generated at 2022-06-12 17:59:30.685884
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE('nrk')
    assert ie.IE_NAME == 'NRKTVEpisodeIE'


# Generated at 2022-06-12 17:59:32.274904
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE('NRKTVSeasonIE', 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')



# Generated at 2022-06-12 17:59:37.333191
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """NRK.TV unit test for regular expression for url definition for episodes and seasons."""
    info_extractor = NRKTVEpisodeIE()
    nrk_test_url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    regex = re.match(info_extractor._VALID_URL, nrk_test_url)
    if regex:
        # Constructor of NRKTVEpisodeIE will never be called.
        # Regex is tested on format:
        # def _VALID_URL = r'url(?P<id>season/episode(?P<season_number>\d+)/episode(?P<episode_number>\d+))'
        info_extractor.url = nrk_test_url
        info_ext

# Generated at 2022-06-12 17:59:45.675170
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    instance = NRKRadioPodkastIE('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert instance.IE_NAME == 'NRK'
    assert instance.IE_DESC == 'Norwegian Broadcasting Corporation'
    assert instance._VALID_URL == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'

# Generated at 2022-06-12 17:59:47.758190
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        NRKTVSeasonIE('NRKTV', 'NRKTV')
        assert False
    except Exception:
        pass


# Generated at 2022-06-12 18:02:10.854106
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    class_obj = NRKTVSerieBaseIE()
    assert class_obj._extract_assets_key({'episodes': True}) == 'episodes'
    assert class_obj._extract_assets_key({'instalments': True}) == 'instalments'
    assert class_obj._extract_assets_key({'episodes': True, 'instalments': True}) == 'episodes'
    assert class_obj._extract_assets_key({'series': True}) == None
    assert class_obj._extract_assets_key({}) == None
    assert class_obj._extract_assets_key({'_embedded': {'episodes': True}}) == 'episodes'

# Generated at 2022-06-12 18:02:11.822258
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # we just check that it is possible to create an instance
    NRKPlaylistIE()


# Generated at 2022-06-12 18:02:12.986131
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from ._test_common import common as common_test
    common_test.constructor_test(NRKTVSeasonIE)



# Generated at 2022-06-12 18:02:17.841598
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """Test that class NRKTVIE constructs a regex that matches urls of
    episodes hosted on tv.nrk.no or radio.nrk.no"""
    nrktv_ie = NRKTVIE('test', 'test', 'test')

    # test that a url of episode from tv.nrk.no is matched,
    # and that the regex also matches a url from radio.nrk.no
    assert re.match(nrktv_ie._VALID_URL, 'https://tv.nrk.no/program/MDDP12000117')
    assert re.match(nrktv_ie._VALID_URL, 'https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#')

    # test that a url of episode from tv.nrk.no is

# Generated at 2022-06-12 18:02:26.854170
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert NRKTVIE.suitable('https://tv.nrk.no/program/FOOOBAR123')
    assert NRKTVEpisodeIE.suitable('https://tv.nrk.no/serie/a-ha/sesong/1/episode/1')
    assert NRKRadioPodkastIE.suitable('https://tv.nrk.no/podkast/viten/sesong/2019/episode/26588')
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/a-ha/sesong/1')

    assert not ie.suitable('https://tv.nrk.no/program/FOOOBAR123')

# Generated at 2022-06-12 18:02:28.620807
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert isinstance(NRKPlaylistBaseIE(), InfoExtractor)


# Generated at 2022-06-12 18:02:31.505545
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE()._VALID_URL == NRKTVEpisodeIE._VALID_URL


# Generated at 2022-06-12 18:02:40.443414
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._TESTS[0]['url'] == 'https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763/'
    assert NRKPlaylistIE._TESTS[0]['info_dict']['id'] == 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    assert NRKPlaylistIE._TESTS[0]['info_dict']['title'] == 'Gjenopplev den historiske solformørkelsen'
    assert NRKPlaylistIE._TESTS[0]['info_dict']['description'] == 'md5:c2df8ea3bac5654a26fc2834a542feed'
   

# Generated at 2022-06-12 18:02:44.112208
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._TESTS[0]['md5'] == ie._real_extract(ie._TESTS[0]['url'])['id']

# Generated at 2022-06-12 18:02:49.187955
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    try:
        # No constructor was defined
        NRKBaseIE(None, None)
        # If no exception was thrown, the test fails
        assert False, "No exception was thrown"
    except TypeError as e:
        # The test is successful if the TypeError exception is thrown
        assert e.__class__ is TypeError, "Unexpected exception thrown: %s" % e.__class__