

# Generated at 2022-06-12 17:57:25.007917
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    (id, season, episode) = ie._VALID_URL.split('/episode/')
    display_id = id + '/sesong/' + season + '/episode/' + episode
    url = 'https://tv.nrk.no/serie/' + display_id
    assert ie.suitable(url)
    assert ie.IE_NAME == ie.ie_key()
# Unit test ends



# Generated at 2022-06-12 17:57:29.718728
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE(None)

    test_cases = [
        {
            'url': 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099',
            'id': 14099,
            'info_dict': {'mediaId': '14099'},
        },
        {
            'url': 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355',
            'id': 19355,
            'info_dict': {'mediaId': '19355'},
        }
    ]

    for test_case in test_cases:
        assert test_case['id'] == ie._match_id(test_case['url'])

# Generated at 2022-06-12 17:57:31.007966
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert issubclass(NRKPlaylistBaseIE, InfoExtractor)


# Generated at 2022-06-12 17:57:39.354886
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try_this = NRKPlaylistBaseIE('test')
    assert try_this.name == 'test'
    assert try_this._VALID_URL == r'https?://tv\.nrk\.no/serie/.*'
    assert try_this._VALID_URL == r'https?://tv\.nrk\.no/serie/.*'
    assert try_this._downloader is not None
    assert 'IE_NAME' in try_this.__dict__
    assert 'IE_DESC' in try_this.__dict__
    assert '_TESTS' in try_this.__dict__
    assert '_NETRC_MACHINE' in try_this.__dict__


# Generated at 2022-06-12 17:57:41.014510
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """
    Make sure that an instance of class NRKTVDirekteIE is constructed without exceptions.
    """
    NRKTVDirekteIE()



# Generated at 2022-06-12 17:57:51.001498
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        from collections import namedtuple
    except ImportError:
        from compat import namedtuple

    test_entry = namedtuple('entry', 'url')

    series_urls = (
        'https://tv.nrk.no/serie/groenn-glede',
        'https://tv.nrk.no/serie/backstage',
        'https://tv.nrk.no/serie/blank',
        'https://radio.nrk.no/serie/dickie-dick-dickens',
        'https://radio.nrk.no/podkast/ulrikkes_univers')

    tv_series = NRKTVSeriesIE()
    tv_season = NRKTVSeasonIE()
    tv_episode = NRKTVEpisodeIE()


# Generated at 2022-06-12 17:57:52.593351
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE(NRKTVEpisodeIE.create_ie())


# Generated at 2022-06-12 17:57:57.366006
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    if __name__ == '__main__':
        nrktv_season_ie_constructor_test('https://tv.nrk.no/serie/spangas/sesong/1');
        nrktv_season_ie_constructor_test('https://radio.nrk.no/serie/hele-historien/sesong/diagnose-kverulant');
    pass;


# Generated at 2022-06-12 17:58:03.412441
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    import uuid
    class_nrk_skole_IE = NRKSkoleIE()
    assert class_nrk_skole_IE.IE_DESC == 'NRK Skole'
    assert class_nrk_skole_IE._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-12 17:58:07.503964
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    info = ie._call_api('programs/MDDP12000117', 'MDDP12000117', 'program', query={'mediaType': 'tv'})
    print (info)


# Generated at 2022-06-12 17:59:07.284119
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    test_case = 'https://radio.nrk.no/serie/svidd-gummi/MOPR76000115/sesong-3/episode-5'
    instance = NRKTVSerieBaseIE()
    test_input = 'radio'
    test_output = instance._catalog_name(test_input)
    assert test_output == 'podcast'

# Generated at 2022-06-12 17:59:10.851264
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    result = NRKRadioPodkastIE()._real_extract(url)
    assert(result[0] == 'nrk:%s' % url.split('/')[-1])



# Generated at 2022-06-12 17:59:11.817115
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrk_series = NRKTVSeriesIE()


# Generated at 2022-06-12 17:59:15.313034
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'

    dic_info = NRKRadioPodkastIE()._real_extract(url)

    assert isinstance(dic_info, dict)
    assert isinstance(dic_info.get('_type'), compat_str)


# Generated at 2022-06-12 17:59:24.136091
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    info_extractor = NRKRadioPodkastIE()
    assert info_extractor.IE_DESC == 'NRK Radio Podkast'
    assert info_extractor._VALID_URL == r'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    assert len(info_extractor._TESTS) == 4


# Generated at 2022-06-12 17:59:31.365550
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('NRKPlaylist', 'playlist', 'no.nrk.nrktv,no.nrk.nrkradio')
    assert ie.ie_key == 'NRKPlaylist'
    assert ie.ie_name == 'nrk:playlist'
    assert ie.ie_id == 'no.nrk.nrktv,no.nrk.nrkradio'
    assert ie.ie_key == 'NRKPlaylist'
    assert ie.ie_name == 'nrk:playlist'
    assert ie.ie_id == 'no.nrk.nrktv,no.nrk.nrkradio'


# Generated at 2022-06-12 17:59:43.039203
# Unit test for constructor of class NRKIE
def test_NRKIE():
    IE = NRKIE()
    assert IE._GEO_COUNTRIES == ['NO']
    assert IE._CDN_REPL_REGEX == r'(?x)://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'

# Generated at 2022-06-12 17:59:53.648877
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.suitable(None) == False
    assert NRKTVSeriesIE.suitable('http://tv.nrk.no/serie/blank') == True
    assert NRKTVSeriesIE.suitable('http://tv.nrk.no/serie/blank/sesong/1/episode/1') == False
    assert NRKTVSeriesIE.suitable('http://tv.nrk.no/blank') == False
    assert NRKTVSeriesIE.suitable('http://tv.nrk.no/') == False
    assert NRKTVSeriesIE.suitable('http://nrk.no/') == False
    assert NRKTVSeriesIE.suitable('http://nrk.no') == False

# Generated at 2022-06-12 17:59:56.196126
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE("NRKRadioPodkastIE", "NRKRadioPodkastIE")



# Generated at 2022-06-12 18:00:03.450017
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    url = 'https://tv.nrk.no/serie/skam'
    object = NRKTVSerieBaseIE()
    object._VALID_URL = r'https?://tv\.nrk\.no/serie/(?P<id>.*)'
    assert object._match_id(url) == 'skam'
    assert object._real_extract(url)
    assert object._call_api('programs/skam', 'skam', 'programs')
    assert object.IE_DESC == 'NRK TV and NRK Radio'
    assert object._TESTS[0]['md5'] == 'f4a6061f1692e6b2d1ffb782af15b4e4'

# Generated at 2022-06-12 18:02:37.105759
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    import re
    import unittest
    from youtube_dl.utils import ExtractorError
    ie = NRKTVSeriesIE()
    assert ie.ie_key() == 'nrktv'
    assert ie.suitable('https://tv.nrk.no/serie/blank')
    assert ie.suitable('https://tv.nrksuper.no/serie/labyrint')
    assert ie.suitable('https://tv.nrk.no/serie/saving-the-human-race')
    assert ie.suitable('https://tv.nrk.no/serie/postmann-pat')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers')

# Generated at 2022-06-12 18:02:38.871514
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_unit_for_constructor(NRKPlaylistIE, 'NRKPlaylistIE', 'NRKPlaylistBaseIE')


# Generated at 2022-06-12 18:02:42.667023
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE("https://tv.nrk.no/serie/backstage/sesong/10")
    assert isinstance(ie, NRKTVSeasonIE)



# Generated at 2022-06-12 18:02:47.312186
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = "https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8"
    NRKRadioPodkastIE(NRKIE()).suitable(url)
    NRKRadioPodkastIE(NRKIE()).extract(url)


# Generated at 2022-06-12 18:02:51.064342
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2'
    NRKTVIE.suitable(url)
    ie = NRKTVIE.ie_key()
    v_url = NRKTVIE._real_extract(url)
    assert ie == 'nrk'
    assert v_url == 'nrk:MSPO40010515'

# Generated at 2022-06-12 18:02:54.325009
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    if hasattr(ie, '_match_id'):
        assert ie._match_id(ie._VALID_URL)


# Generated at 2022-06-12 18:03:04.733785
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    DirekteIE = NRKTVDirekteIE.ie_key()
    url_test = 'https://tv.nrk.no/direkte/nrk1'
    video_id = 'nrk1'
    assert DirekteIE(URLResolver())._match_id(url_test) == video_id
    # test for generated ie_key
    assert (NRKTVIE.ie_key() == NRKTVIE)
    assert (NRKTVEpisodeIE.ie_key() == NRKTVEpisodeIE)
    assert (NRKTVSeriesIE.ie_key() == NRKTVSeriesIE)
    assert (NRKTVDirekteIE.ie_key() == NRKTVDirekteIE)

# Generated at 2022-06-12 18:03:11.429575
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_url = 'http://www.nrk.no/mat/alt-om-mat-1.12270734'
    nrk_playlist_ie = NRKPlaylistIE(NRKPlaylistIE.ie_key(), test_url)
    test_info = nrk_playlist_ie._real_extract(test_url)
    assert test_info['id'] == 'alt-om-mat-1.12270734'
    assert test_info['title'] == 'Alt om mat'



# Generated at 2022-06-12 18:03:13.508326
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert isinstance(NRKTVEpisodesIE, type)



# Generated at 2022-06-12 18:03:15.657772
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE({})._type() == "NRKSkoleIE"


# Generated at 2022-06-12 18:06:05.326020
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert re.search(ie._VALID_URL, 'https://tv.nrk.no/direkte/nrk1')
    assert re.search(ie._VALID_URL, 'https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'


# Generated at 2022-06-12 18:06:09.851370
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk = NRKSkoleIE('NRKSkoleIE', {})
    assert nrk.IE_NAME == 'NRKSkoleIE'
    assert nrk.IE_DESC == 'NRK Skole'
    assert nrk.VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert nrk.IE_KEY == 'NRKSkole'
    assert nrk.url_result('nrk:69031', 'NRKIE').url == 'nrk:69031'
    assert nrk.url_result('nrk:69031', 'NRKIE').ie_key() == 'NRK'
    assert nrk.is_enabled()
    assert nrk

# Generated at 2022-06-12 18:06:11.328675
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE('url', 'name')
    assert ie.lang == 'nb'
    assert ie.name == 'name'


# Generated at 2022-06-12 18:06:12.997136
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from ..services.nrk import NRKTVIE
    assert NRKTVIE().IE_NAME == 'NRKTV'



# Generated at 2022-06-12 18:06:14.721091
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        NRKPlaylistBaseIE()
        assert True
    except Exception as exc:
        assert False, 'NRKPlaylistBaseIE raised exception: "%s"' % str(exc)



# Generated at 2022-06-12 18:06:17.029921
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE(None)
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == 'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'


# Generated at 2022-06-12 18:06:18.862529
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    NRKTVEpisodesIE(url)
