

# Generated at 2022-06-12 17:57:23.330538
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/program/TVR20000114/'
    nrk = NRKPlaylistBaseIE()
    assert nrk._real_extract(url) is not None



# Generated at 2022-06-12 17:57:29.400467
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from youtube_dl.extractor.nrk import NRKTVDirekteIE
    try:
        import json
    except ImportError:
        import simplejson as json
    import os
    import sys
    # set environment variables
    #
    # Note: This is a workaround because os.environ doesn't seem to handle
    # unicode values correctly.
    #
    #       See the following python issues:
    #       * http://bugs.python.org/issue1602
    #       * http://bugs.python.org/issue2128
    #
    os.environ[u'NRK_USER_ID'] = sys.modules[json.__module__].dumps(u'\U0001f60a')
    os.environ[u'NRK_USER_AGENT_IPHONE_4_APPSTORE']

# Generated at 2022-06-12 17:57:38.499178
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    req = lambda q: {'return_value': {'query': q}}
    assert NRKRadioPodkastIE._build_query(req) == {'query': {}}
    assert NRKRadioPodkastIE._build_query(req({'foo': 'bar', 'baz': 'qux'})) == {'query': {'foo': 'bar', 'baz': 'qux'}}
    assert NRKRadioPodkastIE._build_query(req({'foo': 'bar', 'baz': ''})) == {'query': {'foo': 'bar'}}
    assert NRKRadioPodkastIE._build_query(req({'foo': '', 'baz': 'qux'})) == {'query': {'baz': 'qux'}}
    assert NRKRadioPodkastIE._build_

# Generated at 2022-06-12 17:57:41.733605
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE(None, None)



# Generated at 2022-06-12 17:57:43.037294
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE


# Generated at 2022-06-12 17:57:44.497110
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    instance = NRKTVEpisodesIE(None)
    assert isinstance(instance,NRKTVEpisodesIE)
    assert isinstance(instance,NRKPlaylistBaseIE)


# Generated at 2022-06-12 17:57:48.582064
# Unit test for constructor of class NRKBaseIE

# Generated at 2022-06-12 17:57:51.963798
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie.suitable (('https://tv.nrk.no/serie/groenn-glede')) == True


# Generated at 2022-06-12 17:57:59.457374
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE()._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert NRKTVEpisodeIE()._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert NRKTVEpisodeIE()._TESTS[1]['url'] == 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'


# Generated at 2022-06-12 17:58:05.889385
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()

    test_url = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert ie.suitable(test_url)
    assert ie.IE_NAME == 'nrk:episodes'
    assert ie.IE_DESC == 'NRK TV Episodes'
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'



# Generated at 2022-06-12 17:59:50.109622
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebaseie_object = NRKTVSerieBaseIE()


# Generated at 2022-06-12 17:59:51.625191
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    print(NRKTVEpisodesIE())



# Generated at 2022-06-12 17:59:53.519120
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    x = NRKBaseIE()
    assert x._GEO_COUNTRIES == ['NO']


# Generated at 2022-06-12 17:59:54.944171
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('nrk')


# Generated at 2022-06-12 18:00:02.431914
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE('NRKTVSerie')
    info_dict = {
        '_type': 'url',
        'id': 'MUHH46000317',
        'url': 'nrk:%s' % 'MUHH46000317',
        'ie_key': 'NRKTVIE',
        'season_number': 0,
        'episode_number': 0
    }
    result = ie._entries({
         '_embedded': {
            'instalments': {
              '_embedded': {
                'instalments': [{'episodeId': 'MUHH46000317'},
                                {'episodeId': 'MUHH46000318'}]
              }
            }
        }
    }, 'muhta')

# Generated at 2022-06-12 18:00:03.621364
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    unit_test = NRKRadioPodkastIE()

# Generated at 2022-06-12 18:00:10.775011
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # case 1
    nrktv_episodes = NRKTVEpisodesIE('http://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert nrktv_episodes._VALID_URL == r'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\d+)'
    assert nrktv_episodes._TESTS[0]['url'] == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert nrktv_episodes._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE



# Generated at 2022-06-12 18:00:18.048913
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    instance = NRKTVIE()
    assert isinstance(instance, NRKTVIE)
    assert instance.IE_DESC == 'NRK TV and NRK Radio'
    assert instance._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*%s' % instance._EPISODE_RE



# Generated at 2022-06-12 18:00:18.603552
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    pass



# Generated at 2022-06-12 18:00:20.438057
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    TempUUID = NRKTVIE.UUID

# Generated at 2022-06-12 18:03:09.519733
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """
    To test for this on the command line, do
        python -m unittest discover -v
    in the directory that contains this file.
    """
    from .nrktv import NRKTVSeriesIE
    from .nrktvseason import NRKTVSeasonIE
    from .nrktvepisode import NRKTVEpisodeIE
    from .nrktv import NRKTVIE
    from .nrkradiopodkast import NRKRadioPodkastIE
    from .nrkradiopodkast import _debug_json
    import mock
    import unittest
    import six


# Generated at 2022-06-12 18:03:10.883909
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """Test that the superclass constructor is working."""
    NRKPlaylistBaseIE()


# Generated at 2022-06-12 18:03:21.994050
# Unit test for constructor of class NRKIE
def test_NRKIE():

    nrkie = NRKIE('', {})

    # Test case: Fetch a list of domains and check them against the list of domains on NRK API
    formats = nrkie._extract_nrk_formats('https://nrk-od-no.telenorcdn.net/no/dash/154915.mpd', '154915')
    assert(len(formats) == 4)

    assert(formats[0]['format_id'] == 'dash_mpd_low')
    assert(formats[1]['format_id'] == 'dash_mpd_medium')
    assert(formats[2]['format_id'] == 'dash_mpd_high')
    assert(formats[3]['format_id'] == 'dash_mpd_hd')

    # Test case: Throw an error when

# Generated at 2022-06-12 18:03:27.714158
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert ie._TESTS[0]['md5'] == '18c12c3d071953c3bf8d54ef6b2587b7'
    assert ie._TESTS[0]['info_dict']['id'] == '6021'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:03:30.005938
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    instance = NRKTVSeasonIE({})
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-12 18:03:37.820254
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    import requests
    from urllib.parse import parse_qs
    from youtube_dl.downloader.http import HttpRequest
    from youtube_dl.utils import sanitize_url
    # Build the url page
    url = 'https://tv.nrk.no/serie/backstage'
    url_page = requests.get(url).text
    # Build the url query
    url_query = re.findall('<script src="([^"]+)">', url_page)[0]
    url_query = urljoin(url + '/', url_query)
    url_data = requests.get(url_query).text
    url_data = re.search('\(({[^\)]+})\)', url_data).groups()

# Generated at 2022-06-12 18:03:40.107571
# Unit test for constructor of class NRKIE
def test_NRKIE():
	nrkie = NRKIE("NRKIE")
	assert (nrkie.IE_NAME == "NRK")
	assert (nrkie.IE_DESC == "NRK")
	assert (nrkie.VALID_URL == NRKIE._VALID_URL)

# Generated at 2022-06-12 18:03:42.177237
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert isinstance(NRKTVDirekteIE(), NRKTVIE)



# Generated at 2022-06-12 18:03:47.566962
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_ie = NRKSkoleIE()
    assert nrk_skole_ie.IE_NAME == 'NRK Skole'
    assert nrk_skole_ie.IE_DESC == 'NRK Skole'
    assert nrk_skole_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-12 18:03:49.084202
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert str(NRKTVSeriesIE(None, 'http://tv.nrk.no/serie/backstage/sesong/1')) == '<class NRKTVSeriesIE>'
