

# Generated at 2022-06-12 17:57:19.799765
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE()
    assert ie._ITEM_RE is None
    assert ie.IE_NAME is None
    assert ie._VALID_URL is None



# Generated at 2022-06-12 17:57:32.504864
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://tv.nrk.no/serie/groenn-glede'
    nrktv_series_ie = NRKTVSeriesIE(url)
    assert nrktv_series_ie._VALID_URL == r'https?://(?P<domain>(?:tv|radio)\.nrk|(?:tv\.)?nrksuper)\.no/(?P<serie_kind>serie|pod[ck]ast)/(?P<id>[^/]+)'
    assert nrktv_series_ie._TESTS[0]['url'] == 'https://tv.nrk.no/serie/groenn-glede'
    #assert nrktv_series_ie._TESTS[0]['info_dict'] == {'id': 'groenn-glede',

# Generated at 2022-06-12 17:57:40.649007
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.suitable('http://www.nrk.no/sport/du-far-ikke-se-sotra-pa-tv-uten-at-fotball-finner-det-ut-1.12281118')
    assert not ie.suitable('http://www.nrk.no/skole/skole/sjekk-hvordan-det-er-a-ga-pa-skole-paa-universitetet-1.12249602')
    assert ie.IE_NAME == 'nrk:playlist'


# Generated at 2022-06-12 17:57:44.905233
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    print("Unit test for constructor of class NRKSkoleIE")
    assert NRKSkoleIE.ie_key() == 'nrk:skole'
    assert NRKSkoleIE.ie_key() == 'nrk:skole'


# Generated at 2022-06-12 17:57:49.954789
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    constructor = NRKTVSeriesIE.__new__(NRKTVSeriesIE)
    instance = constructor()
    assert isinstance(instance, NRKTVSeriesIE)


# Generated at 2022-06-12 17:57:54.479201
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # this URL is not a valid url for NRKTVSeriesIE, so NRKTVSeriesIE(...) should return None
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    assert NRKTVSeriesIE.suitable(url) is False



# Generated at 2022-06-12 17:57:55.448917
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()

# Generated at 2022-06-12 17:58:05.895576
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    """ Unit test for class NRKBaseIE"""
    # test with YouTube video
    url = 'http://tv.nrk.no/dyn/tv/nrk_super/super_jr_KAN_2015_12_01_19_10_flv/superjr_2015_12_01_19_10_nrk_super_hele_uken.mp4'
    url_video = 'http://tv.nrk.no/dyn/tv/nrk_super/super_jr_KAN_2015_12_01_19_10_flv'
    nrkbaseie = NRKBaseIE(url)
    assert nrkbaseie.suitable(url) is True
    assert nrkbaseie.suitable(url_video) is True


# Generated at 2022-06-12 17:58:14.574162
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    print('Testing constructor of class NRKTVSerieBaseIE')


# Generated at 2022-06-12 17:58:20.737542
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    # type: () -> None

    # NRKSkoleIE
    assert NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    assert not NRKSkoleIE.suitable('https://www.nrk.no/skole/')
    assert NRKSkoleIE.ie_key() == 'nrk:skole'
    assert not NRKSkoleIE._WORKING

    # NRKSkoleIE

# Generated at 2022-06-12 17:59:31.301354
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031') == ('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031', '69031', 'Nytt på nytt, sesong: 201210', [])

# Generated at 2022-06-12 17:59:42.943482
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    site, serie_kind, series_id = re.match(NRKTVSeriesIE._VALID_URL, 'https://radio.nrk.no/podkast/hele_historien').groups()
    is_radio = site == 'radio.nrk'
    domain = 'radio' if is_radio else 'tv'
    nrktvseriesie = NRKTVSeriesIE(NRKTVSeriesIE._create_ie_instance({'_type': 'url', 'url': '', 'ie_key': 'NRKTVSeriesIE'}))
    size_prefix = 'p' if is_radio else 'embeddedInstalmentsP'

# Generated at 2022-06-12 17:59:43.875278
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert('NRKTVEpisodeIE' == NRKTVEpisodeIE()._VALID_URL)

# Generated at 2022-06-12 17:59:45.746063
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.ie_key() == 'NRKTVEpisodes'



# Generated at 2022-06-12 17:59:49.920285
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie.ie_key() is NRKTVDirekteIE



# Generated at 2022-06-12 17:59:56.570287
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    import unittest
    from .test_NRKIE import TestNRKIE
    from .test_NRKTVEpisodeIE import TestNRKTVEpisodeIE

    TestNRKIE.extract_info = \
        TestNRKTVEpisodeIE.extract_info = \
        NRKBaseIE._extract_info

    class TestNRKRadioPodkastIE(TestNRKIE, TestNRKTVEpisodeIE):
        IE = NRKRadioPodkastIE

    suite = unittest.TestLoader().loadTestsFromTestCase(TestNRKRadioPodkastIE)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-12 18:00:01.696216
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebaseie = NRKTVSerieBaseIE()
    for i in itertools.count(1):
        entries = nrktvseriebaseie._extract_entries(
            entry_list= [
                {'episodeId': 'episodeId_' + str(i)},
                {'episodeId': 'episodeId_' + str(i+1)},
                {'episodeId': 'episodeId_' + str(i+2)}
            ]
        )
        if entries is not None:
            break



# Generated at 2022-06-12 18:00:07.908302
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk = NRKIE()
    assert nrk._VALID_URL == 'http://www\.nrk\.no/video/PS\*([^?\#&]+)'
    assert nrk._TESTS == [{
        'url': 'http://www.nrk.no/video/PS*150533',
        'md5': 'f46be075326e23ad0e524edfcb06aeb6',
        'info_dict': {
            'id': '150533',
            'ext': 'mp4',
            'title': 'Dompap og andre fugler i Piip-Show',
            'description': 'md5:d9261ba34c43b61c812cb6b0269a5c8f',
            'duration': 262,
        }
    }]

# Generated at 2022-06-12 18:00:11.939724
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrkSkoleIE = NRKSkoleIE()
    if nrkSkoleIE.__class__.__name__ != 'NRKSkoleIE':
        print('Error: Constructor of class NRKSkoleIE does not work as expected')
    else:
        print('Constructor of class NRKSkoleIE works as expected')


# Generated at 2022-06-12 18:00:21.957922
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        from inspect import signature
        assert signature(NRKTVSeriesIE).parameters['url'].default == 'required'
    except ImportError:
        pass
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank') is True
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/saving-the-human-race') is True
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/postmann-pat') is True
    assert NRKTVSeriesIE.suitable('https://nrksuper.no/serie/labyrint') is True
    assert NRKTVSeriesIE.suitable('https://tv.nrksuper.no/serie/labyrint') is True
    assert NRKTV

# Generated at 2022-06-12 18:01:49.010929
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(NRKTVIE._downloader, NRKTVIE._url)


# Generated at 2022-06-12 18:01:50.800656
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._call_api('mediaelement', 'abcde') == None


# Generated at 2022-06-12 18:01:53.073069
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert isinstance(ie, NRKIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:01:56.137678
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    class TestInfoExtractor(NRKRadioPodkastIE):
        def _real_extract(self, url):
            assert self.__class__ == TestInfoExtractor
            return super(TestInfoExtractor, self)._real_extract(url)

    TestInfoExtractor()._real_extract('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')


# Generated at 2022-06-12 18:02:02.153495
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'
    assert ie._TESTS == [{
        'url': 'https://tv.nrk.no/direkte/nrk1',
        'only_matching': True,
    }, {
        'url': 'https://radio.nrk.no/direkte/p1_oslo_akershus',
        'only_matching': True,
    }]

# Generated at 2022-06-12 18:02:03.808672
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # test if the constructor of NRKTVEpisodesIE is correct
    assert (NRKTVEpisodesIE()._VALID_URL == NRKPlaylistBaseIE._VALID_URL)



# Generated at 2022-06-12 18:02:04.821969
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('NRKTVDirekte', {}, {}, {}, {})



# Generated at 2022-06-12 18:02:05.566655
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    instance = NRKTVIE()
    print(instance)


# Generated at 2022-06-12 18:02:10.564512
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """
    Unit test for constructor of class NRKTVEpisodeIE
    """
    print ("test_NRKTVEpisodeIE")
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id, season_number, episode_number = re.match(NRKTVEpisodeIE._VALID_URL, url).groups()

    webpage = test_NRKTVEpisodeIE._download_webpage(url, display_id)

    info = test_NRKTVEpisodeIE._search_json_ld(webpage, display_id, default={})
    print (info)

# Generated at 2022-06-12 18:02:14.851814
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    m = re.match(NRKTVDirekteIE._VALID_URL, 'https://tv.nrk.no/direkte/nrk1')
    assert m is not None and m.group('id') == 'nrk1'
    m = re.match(NRKTVDirekteIE._VALID_URL, 'https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert m is not None and m.group('id') == 'p1_oslo_akershus'
    try:
        NRKTVDirekteIE('http://example.com/not_nrk')
        assert False, "Invalid URL didn't raise exception"
    except ExtractorError:
        pass


# Generated at 2022-06-12 18:03:21.359105
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.description == 'NRK TV and NRK Radio'

# Generated at 2022-06-12 18:03:22.537540
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    NRKTVSeriesIE()



# Generated at 2022-06-12 18:03:27.829405
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    test_url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    test_obj = NRKRadioPodkastIE()
    assert test_obj.suitable(test_url)


# Generated at 2022-06-12 18:03:28.560424
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    assert ie



# Generated at 2022-06-12 18:03:29.639564
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # test __init__ function
    NRKPlaylistBaseIE()



# Generated at 2022-06-12 18:03:35.796305
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1/Hvorfor-har-vi-det-slik-at-vi-maa-drive-politisk-teater-for-a-fa-til-omstilling-spm-'
    try:
        NRKTVDirekteIE(url)
    except Exception as e:
        print("%s" % e)
    finally:
        assert False, "AssertionError: NRKTVDirekteIE should not throw an exception for url: %s" % url
    return True



# Generated at 2022-06-12 18:03:40.136494
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''



# Generated at 2022-06-12 18:03:50.702684
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    NRKSkoleIE.suitable('http://www.nrk.no/skole/?page=search&q=&mediaId=14099')
    NRKSkoleIE.suitable('http://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    assert NRKSkoleIE.suitable('http://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355') == False
    assert NRKSkoleIE.suitable('www.nrk.no/skole/') == False
    assert NR

# Generated at 2022-06-12 18:03:53.076253
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Simple test whether the constructor of NRKRadioPodkastIE is working.
    NRKRadioPodkastIE('NRK radio podkast', '', {})

# Generated at 2022-06-12 18:04:00.312099
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test_cases = [
        [['foo', 'bar', 'baz'],
         [{'type': 'NRK', 'id': 'foo'},
          {'type': 'NRK', 'id': 'bar'},
          {'type': 'NRK', 'id': 'baz'}]],
    ]

    for playlist_id, expected in test_cases:
        ie = NRKPlaylistBaseIE()
        ie._ITEM_RE = r'(%s)' % '|'.join(playlist_id)
        ie._download_webpage = lambda _: ''

        entries = ie._real_extract('http://localhost/')['entries']

        expected = {'entries': expected}

        assert_equal(entries, expected)



# Generated at 2022-06-12 18:05:50.281510
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    dir_ie = NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')
    assert dir_ie.channel_id == 'nrk1'
    assert dir_ie._API_BASE_URL == 'https://tv.nrk.no/'
    assert dir_ie._api_version == '2'

    dir_ie_radio = NRKTVDirekteIE('https://radio.nrk.no/direkte/p1_oslo_akershus')
    assert dir_ie_radio.channel_id == 'p1_oslo_akershus'
    assert dir_ie_radio._API_BASE_URL == 'https://radio.nrk.no/'
    assert dir_ie_radio._api_version == '2'



# Generated at 2022-06-12 18:05:55.906996
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # TODO: NRKIE() returns an object, so this test is useless?
    nrk_ie = NRKIE()
    nrk_ie.IE_NAME
    nrk_ie.IE_DESC
    nrk_ie._VALID_URL
    nrk_ie._TESTS


# Generated at 2022-06-12 18:06:05.541707
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test_url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_id = 'gjenopplev-den-historiske-solformorkelsen-1.12270763'
    nrk_playlist_ie = NRKPlaylistIE(NRKPlaylistIE.suitable(test_url))
    assert nrk_playlist_ie.VALID_URL == NRKPlaylistIE._VALID_URL
    assert nrk_playlist_ie.ITEM_RE == NRKPlaylistIE._ITEM_RE
    assert nrk_playlist_ie.TESTS == NRKPlaylistIE._TESTS
    assert nrk_playlist_ie.IE_DESC

# Generated at 2022-06-12 18:06:09.544594
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    type = 'NRKPlaylistIE'
    class_ = globals()[type]
    instance = class_(type, NRKPlaylistIE._VALID_URL, url)
    assert instance.type == type
    assert instance._VALID_URL == NRKPlaylistIE._VALID_URL
    assert instance.url == url
    assert instance.ie_key() == type

# Generated at 2022-06-12 18:06:12.079800
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    ie = NRKPlaylistBaseIE('http://www.nrk.no/urort', 'urort', 'Diverse')
    assert ie.url == 'http://www.nrk.no/urort'
    assert ie.ie_key() == 'NRKPlaylistBaseIE'
    assert ie.playlist_id == 'urort'
    assert ie.title == 'Diverse'



# Generated at 2022-06-12 18:06:16.481417
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'http://nrk.no/sport'
    expected_classname = 'NRKPlaylistBaseIE'
    inst = NRKPlaylistBaseIE(expected_classname)
    assert_equal(inst._match_id(url), 'sport')
    assert_equal(inst.IE_NAME, expected_classname)
    assert_equal(inst.IE_DESC, 'NRK Playlist: %s' % expected_classname)
    assert_equal(inst._VALID_URL, r'https?://nrk\.no/(?P<id>[^/]+)')


# Generated at 2022-06-12 18:06:21.171546
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_radio_podkast_ie = NRKRadioPodkastIE()
    nrk_radio_podkast_ie_test = nrk_radio_podkast_ie._VALID_URL
    nrk_radio_podkast_ie_test2 = nrk_radio_podkast_ie._TESTS
    nrk_radio_podkast_ie_test3 = nrk_radio_podkast_ie._real_extract
