

# Generated at 2022-06-12 17:57:23.278555
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    from .nrktvie import NRKTVEpisodeIE
    assert NRKTVEpisodesIE.__bases__[0] is NRKPlaylistBaseIE
    assert NRKTVEpisodesIE.__bases__[1] is NRKTVEpisodeIE

# Generated at 2022-06-12 17:57:24.190762
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE



# Generated at 2022-06-12 17:57:27.044263
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie._VALID_URL == r'https?://(?:tv|radio)\.nrk(?:super)?\.no/(?:[^/]+/)*' + NRKTVIE._EPISODE_RE

# Generated at 2022-06-12 17:57:35.325597
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    series_ie = NRKTVSeriesIE()
    title = "Good series"
    series_id = "name_of_series"
    data = {
        'titles': {
            'title': title,
            # no subtitle
        },
        '_embedded': {
            'instalments': [
                {
                    'prfId': 'episode_1',
                }
            ],
            'season': {
                '_embedded': {
                    'episodes': [
                        {
                            'episodeId': 'episode_2',
                        }
                    ]
                },
            }
        }
    }
    entries = list(series_ie._entries(data, series_id))
    assert len(entries) == 2
    assert entries[0]['id'] == 'episode_1'
    assert entries

# Generated at 2022-06-12 17:57:37.227811
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Test with empty input
    e = NRKTVSeasonIE()
    assert e.SEASON_ID_RE == '\d+'
    assert e._VALID_URL == NRKTVSeasonIE._VALID_URL
    assert e._TESTS == NRKTVSeasonIE._TESTS



# Generated at 2022-06-12 17:57:38.215475
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    inst = NRKTVIE()
    assert isinstance(inst, NRKTVIE)


# Generated at 2022-06-12 17:57:41.410567
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    for _ in (NRKTVSeriesIE,):
        pass

# Generated at 2022-06-12 17:57:53.655311
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlist_id = 'test_playlist'
    url = 'http://www.nrk.no/test_url'
    video_id = 'test_video_id'
    webpage = '<a href="nrk:%s" class="grouped-content__link" nrk-playable></a>' % video_id

    nrkplaylistbaseie = NRKPlaylistBaseIE()
    nrkplaylistbaseie._match_id = lambda x: 'test_playlist'
    nrkplaylistbaseie._ITEM_RE = r'"nrk:(?P<id>[^"]+)"'
    nrkplaylistbaseie._download_webpage = lambda *args: webpage
    nrkplaylistbaseie.url_result = lambda *args: 'url_result'

    assert NRKIE

# Generated at 2022-06-12 17:57:59.203865
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')

    assert ie._VALID_URL
    assert ie._ITEM_RE
    assert ie._TESTS



# Generated at 2022-06-12 17:58:07.986731
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    from .. import NRKBaseIE
    nrk_ie = NRKBaseIE()
    assert nrk_ie
    assert nrk_ie.IE_NAME

    # NRKBaseIE is abstract, it does not have a working _real_initialize
    # from .. import YoutubeIE
    # yt_ie = YoutubeIE()
    # nrk_ie = NRKBaseIE()
    # nrk_ie.SUCCESS_REGEXES.append(yt_ie.SUCCESS_REGEXES[0])
    # assert nrk_ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc') is True
    # assert nrk_ie.suitable('https://nrk.no/no/norge/') is True


# Generated at 2022-06-12 17:59:26.580427
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    orignal_constructor = NRKTVDirekteIE.__init__
    def new_constructor(self, *args, **kwargs):
        orignal_constructor(self, *args, **kwargs)
        assert self._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/]+)'
    NRKTVDirekteIE.__init__ = new_constructor
    try:
        NRKTVDirekteIE()
    finally:
        NRKTVDirekteIE.__init__ = orignal_constructor

# Generated at 2022-06-12 17:59:31.192242
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    """Test for constructing class NRKTVDirekteIE"""
    dir_ie = NRKTVDirekteIE()
    assert dir_ie.IE_NAME == 'NRKTVDirekte'
    assert dir_ie.IE_KEY == 'nrktvdirekte'
    assert dir_ie.IE_DESC == 'NRK TV Direkte and NRK Radio Direkte'
    assert dir_ie.IE_VERSION == '0.1'
    assert dir_ie._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:59:35.868565
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    InfoExtractor._sort_formats = lambda _: None
    NRKPlaylistBaseIE()._download_webpage = lambda *args, **kwargs: (
        '<html><head></head><body></body></html>')
    assert NRKPlaylistBaseIE()._real_initialize() is True


# Generated at 2022-06-12 17:59:37.847073
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE()



# Generated at 2022-06-12 17:59:42.020391
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    a = NRKTVEpisodesIE()
    a.IE_DESC = 'NRK TV Episodes'
    # print a
    # print a.IE_DESC


# Generated at 2022-06-12 17:59:45.211322
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE()
    r = re.compile(ie._VALID_URL)  # noqa: F841
    assert ie.IE_NAME == 'nrk:tv:episode'
    assert ie.IE_DESC == 'NRK TV and NRK Radio'
    assert ie.ie_key() == 'NRK:tv:episode'
    assert ie._VALID_URL == NRKTVEpisodeIE._VALID_URL
    assert ie._TESTS == NRKTVEpisodeIE._TESTS



# Generated at 2022-06-12 17:59:47.816147
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE(None)
    assert ie.get_id_re() == NRKTVEpisodeIE._VALID_URL
    assert ie.get_id_display_re() == NRKTVEpisodeIE._VALID_URL
    assert ie.get_id_examples()[0] == ('https://tv.nrk.no/serie/anno/sesong/3/episode/13')


# Generated at 2022-06-12 17:59:57.938240
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    i = NRKTVSeasonIE('https://tv.nrk.no/serie/spangas/sesong/1')
    assert i.suitable('https://tv.nrk.no/serie/spangas/sesong/1')
    assert i.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201509')
    assert i.suitable('https://tv.nrk.no/serie/lindmo/2016')
    assert i.suitable('https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant')
    assert not i.suitable('https://tv.nrk.no/serie/backstage/sesong/1/episode/8')

# Generated at 2022-06-12 18:00:01.728666
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    catalog_name = NRKTVSerieBaseIE._catalog_name('podcast')
    assert catalog_name == 'podcast'
    catalog_name = NRKTVSerieBaseIE._catalog_name('podkast')
    assert catalog_name == 'podcast'
    catalog_name = NRKTVSerieBaseIE._catalog_name('series')
    assert catalog_name == 'series'


# Generated at 2022-06-12 18:00:07.931003
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-12 18:02:41.148419
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(extractor='NRKTVIE', result='type: NRKTVIE')

# Generated at 2022-06-12 18:02:42.788881
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE(None)._real_initialize()


# Generated at 2022-06-12 18:02:44.112586
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE(NRKBaseIE._downloader)



# Generated at 2022-06-12 18:02:51.945864
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # First we need to instantiate NRKTVIE
    NRKTVIE_inst = NRKTVIE()
    # Check whether NRKTVIE implements the _real_extract method
    # (in this case, the method _real_extract is implemented as a class method in the NRKTVIE class)
    assert(hasattr(NRKTVIE_inst, '_real_extract'))
    # If a class method is actually implemented, it should be a function
    assert(inspect.isfunction(getattr(NRKTVIE_inst, '_real_extract')))
    # Now, we check if the _real_extract method takes a single parameter
    assert(len(inspect.getargspec(getattr(NRKTVIE_inst, '_real_extract'))[0]) == 2)
    # Finally,

# Generated at 2022-06-12 18:03:02.638426
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    assert ie.IE_DESC == 'NRK Skole'
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'
    # Test URL not existing
    assert ie.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=00000') == False
    # Test URL existing
    assert ie.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355') == True

# Generated at 2022-06-12 18:03:09.131937
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    url = 'http://radio.nrk.no/podkast/hele_historien/sesong/bortfoert-i-bergen/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c'
    url2 = 'http://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
    nrkpodkastie = NRKRadioPodkastIE()
    nrkpodkastie.suitable(url)
    nrkpodkastie.suitable(url2)


# Generated at 2022-06-12 18:03:18.908328
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from .test_MTVServicesInfoExtractor import construct_MTVServicesInfoExtractor
    ie = construct_MTVServicesInfoExtractor(NRKTVSeriesIE, 'NRKTVSeriesIE')
    assert ie.suitable('http://tv.nrk.no/serie/groenn-glede')
    assert not ie.suitable('http://tv.nrk.no/serie/koselig-med-peis')
    assert ie.IE_NAME == NRKTVSeriesIE.IE_NAME
    assert ie.ie_key() == NRKTVSeriesIE.ie_key()

# Generated at 2022-06-12 18:03:21.532842
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    try:
        NRKTVSerieBaseIE(None)
        assert False
    except TypeError as e:
        assert str(e) == 'NRKTVSerieBaseIE cannot be created directly'



# Generated at 2022-06-12 18:03:27.165378
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    catalogue_name = 'series'
    assert 'podcast' == NRKTVSerieBaseIE._catalog_name('podcast')
    assert catalogue_name == NRKTVSerieBaseIE._catalog_name('others')
    assert catalogue_name == NRKTVSerieBaseIE._catalog_name('live')
    assert catalogue_name == NRKTVSerieBaseIE._catalog_name('podkast')


# Generated at 2022-06-12 18:03:29.542553
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert(NRKPlaylistIE.__name__ == 'NRKPlaylistIE')
