

# Generated at 2022-06-26 12:32:21.699291
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    inst = NRKPlaylistIE()


# Generated at 2022-06-26 12:32:26.889111
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from youtube_dl.extractor import gen_extractors_dict
    from youtube_dl.extractor.nrk import NRKTVDirekteIE

    print('Testing %s constructor' % NRKTVDirekteIE.__class__.__name__)

    n_r_k_i_e_1 = gen_extractors_dict()['nrktvdirekte']()


# Generated at 2022-06-26 12:32:27.972446
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:32:29.216589
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e_0 = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:32:30.140998
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e = NRKIE()


# Generated at 2022-06-26 12:32:32.326738
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrktvepisodeie = NRKTVEpisodeIE()
    nrktvepisodeie.extract(u'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2')


# Generated at 2022-06-26 12:32:33.800349
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_tv_direkte_i_e_0 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:32:34.498879
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test_case_0()


# Generated at 2022-06-26 12:32:37.526125
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'NRKTVSeriesIE'
    n_r_k_t_v_series_i_e = NRKTVSeriesIE(NRKTVSeriesIE, url)


# Generated at 2022-06-26 12:32:38.755080
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_p_b_i_e = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:33:49.284949
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    unit = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:33:50.212949
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert isinstance(NRKTVDirekteIE(), NRKTVIE)


# Generated at 2022-06-26 12:33:52.286439
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url_0 = 'https://tv.nrk.no/direkte/nrk1'
    return _download_webpage(url_0)

# Test All Functions
if __name__ == '__main__':
    test_case_0()
    test_NRKTVDirekteIE()

# Generated at 2022-06-26 12:33:53.504347
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:33:54.542543
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_e_pisodes_i_e = NRKTVEpisodesIE()



# Generated at 2022-06-26 12:34:00.284127
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE.IE_DESC == 'NRK Skole'
    assert NRKSkoleIE._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

    n_r_k_s_k_o_l_e_i_e_0 = NRKSkoleIE()

    n_r_k_s_k_o_l_e_i_e_1 = NRKSkoleIE()


# Generated at 2022-06-26 12:34:01.215068
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    print(repr(NRKTVSerieBaseIE()))


# Generated at 2022-06-26 12:34:05.227100
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrk_t_v_direkte_i_e = NRKTVDirekteIE()


# Generated at 2022-06-26 12:34:07.014131
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e = NRKTVDirekteIE()


# Generated at 2022-06-26 12:34:16.344743
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()
    # Test to check if object is instance of NRKTVSerieBaseIE
    assert isinstance(n_r_k_t_v_serie_base_i_e_0, NRKTVSerieBaseIE)
# Problematic cases
# -----------------
# - https://tv.nrk.no/serie/anne-with-an-e/MUHU78000218
# - https://tv.nrk.no/serie/barne-tv
# - https://tv.nrk.no/serie/tour-de-ski
# - https://tv.nrk.no/program/MSUI14000816
# - https://tv.nrk.no/program/MSUI14000

# Generated at 2022-06-26 12:35:27.578708
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:35:28.198356
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    test_case_0()


# Generated at 2022-06-26 12:35:29.207182
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    t_v_s = NRKTVSeriesIE()


# Generated at 2022-06-26 12:35:30.232240
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:35:31.276750
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:35:32.840424
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:35:40.012762
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Provide test data.
    test_case = [
        (
            'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2',
            'MUHH36005220',
            '1',
            '2'
        )
    ]
    for url, display_id, season_number, episode_number in test_case:
        match_re_object = re.match(NRKTVEpisodeIE._VALID_URL, url)
        assert match_re_object
        assert display_id == match_re_object.group('id')
        assert season_number == match_re_object.group('season_number')
        assert episode_number == match_re_object.group('episode_number')

if __name__ == "__main__":
    test_case

# Generated at 2022-06-26 12:35:49.738442
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url_0 = 'http://radio.nrk.no/serie/skolebakken/sesong/1'
    url_1 = 'http://radio.nrk.no/serie/skolebakken/sesong/1/MY'
    assert not n_r_k_i_e_0.suitable(url_0)
    assert n_r_k_i_e_0.suitable(url_1)

# Generated at 2022-06-26 12:35:52.167584
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:35:53.228021
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE() is not None


# Generated at 2022-06-26 12:37:06.702453
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e_0 = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:37:08.199596
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    f_NRKTVSerieBaseIE_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:37:09.642240
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_1 = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:37:10.977518
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_t_v_i_e = NRKTVIE()


# Generated at 2022-06-26 12:37:11.853832
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_t_v_i_e_0 = NRKTVIE()

# Generated at 2022-06-26 12:37:13.371240
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:37:14.534012
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e = NRKPlaylistIE()


# Generated at 2022-06-26 12:37:16.542151
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrk_tv_episode_ie_0 = NRKTVEpisodeIE()


if __name__ == '__main__':
    test_case_0()
    test_NRKTVEpisodeIE()

# Generated at 2022-06-26 12:37:17.713219
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_t_v_i_e = NRKTVIE()


# Generated at 2022-06-26 12:37:19.151917
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_tv_episode_i_e_0 = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:39:57.763681
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from ytdl.extractor.nrk import NRKTVSeasonIE
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:39:58.896526
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert_raises(AttributeError, NRKTVEpisodesIE()._extract_title, "test")

# Generated at 2022-06-26 12:39:59.957165
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0=NRKSkoleIE()



# Generated at 2022-06-26 12:40:04.183108
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:40:06.818520
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:40:08.286888
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE

# Generated at 2022-06-26 12:40:10.806649
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:40:13.570600
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e = NRKSkoleIE()


# Generated at 2022-06-26 12:40:16.576479
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e = NRKTVSeriesIE()


# Generated at 2022-06-26 12:40:18.170013
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_p_l_b_i_e = NRKPlaylistBaseIE()
