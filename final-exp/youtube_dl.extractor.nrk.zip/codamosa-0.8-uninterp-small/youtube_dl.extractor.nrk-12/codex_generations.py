

# Generated at 2022-06-26 12:32:26.579488
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()
    assert n_r_k_t_v_episodes_i_e_0._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'



# Generated at 2022-06-26 12:32:27.768685
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e_0 = NRKPlaylistBaseIE()

# Generated at 2022-06-26 12:32:33.246352
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()
    n_r_k_t_v_direkte_i_e_1 = NRKTVDirekteIE()
    n_r_k_t_v_direkte_i_e_2 = NRKTVDirekteIE()
    n_r_k_t_v_direkte_i_e_3 = NRKTVDirekteIE()
    n_r_k_t_v_direkte_i_e_4 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:32:34.468710
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:36.852790
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:42.476212
# Unit test for constructor of class NRKPlaylistIE

# Generated at 2022-06-26 12:32:52.316298
# Unit test for constructor of class NRKTVDirekteIE

# Generated at 2022-06-26 12:32:54.994088
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()
    n_r_k_skole_i_e_1 = NRKSkoleIE()
    n_r_k_skole_i_e_2 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:56.392668
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e_0 = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:32:57.119143
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE()


# Generated at 2022-06-26 12:34:08.418625
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e_0 = NRKBaseIE('')



# Generated at 2022-06-26 12:34:15.113603
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrkRadioPodkastIE0 = NRKRadioPodkastIE()
    assert nrkRadioPodkastIE0._VALID_URL == 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
# Test case for method _real_extract of class NRKRadioPodkastIE

# Generated at 2022-06-26 12:34:15.780084
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert(NRKSkoleIE())


# Generated at 2022-06-26 12:34:16.631430
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    print('to test NRKTVEpisodesIE')

# Generated at 2022-06-26 12:34:17.695601
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    unit_test_case_NRKTVDirekteIE = NRKTVDirekteIE()



# Generated at 2022-06-26 12:34:18.931445
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Instance
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:34:21.509748
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_podcast_ie = NRKRadioPodkastIE()
    print(nrk_podcast_ie)


# Generated at 2022-06-26 12:34:22.911735
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    a_NRKTVSeriesIE = NRKTVSeriesIE()


# Generated at 2022-06-26 12:34:27.250100
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url_0 = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    response_0 = requests.get(url_0)
    webpage_0 = response_0.content
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()
    return_value_0 = n_r_k_t_v_episodes_i_e_0._extract_title(webpage_0)
    return n_r_k_t_v_episodes_i_e_0.playlist_result(webpage_0, return_value_0)


# Generated at 2022-06-26 12:34:28.147853
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()

# Generated at 2022-06-26 12:36:46.517058
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    sut = NRKTVSeriesIE()


# Generated at 2022-06-26 12:36:47.607669
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
	test_case_0()


# Generated at 2022-06-26 12:36:48.929558
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE().IE_NAME == "nrktv"

# Generated at 2022-06-26 12:36:50.509388
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:36:52.494030
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Initializing test case
    n_r_k_playlist_base_i_e_0 = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:36:53.466677
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:37:00.410568
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrkplaylistbaseie = NRKPlaylistBaseIE()
    assert nrkplaylistbaseie == nrkplaylistbaseie
    assert repr(nrkplaylistbaseie)
    if hasattr(nrkplaylistbaseie, '_real_extract'):
        nrkplaylistbaseie._real_extract('https://example.com/')
    else:
        nrkplaylistbaseie.real_extract('https://example.com/')
    NRKPlaylistBaseIE.suitable('https://example.com/')
    nrkplaylistbaseie.extract_from_url('https://example.com/')
    nrkplaylistbaseie.extract_info('https://example.com/')


# Generated at 2022-06-26 12:37:04.442718
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():

    # Instance created with arguments
    n_r_k_t_v_episodes_i_e = NRKTVEpisodesIE()

    expected_instance_type = "<class 'youtube_dl.extractor.nrk.NRKTVEpisodesIE'>"
    assert str(type(n_r_k_t_v_episodes_i_e)) == expected_instance_type,\
        "Expected: {}, Actual: {}".format(expected_instance_type, type(n_r_k_t_v_episodes_i_e))

# Generated at 2022-06-26 12:37:05.434140
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:37:06.324026
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()
