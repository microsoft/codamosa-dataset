

# Generated at 2022-06-26 12:32:24.648147
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_i_e = NRKPlaylistIE()


# Generated at 2022-06-26 12:32:29.053682
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:32:30.248037
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:31.601941
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_tv_i_e_0 = NRKTVIE()

# Generated at 2022-06-26 12:32:36.732125
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    #Make an instance of NRKPlaylistBaseIE and call it n_r_k_playlist_base_i_e
    n_r_k_playlist_base_i_e = NRKPlaylistBaseIE()
    #Assert that the variable n_r_k_playlist_base_i_e is an instance of NRKPlaylistBaseIE
    assert isinstance(n_r_k_playlist_base_i_e, NRKPlaylistBaseIE)


# Generated at 2022-06-26 12:32:42.384826
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE.ie_key() == 'NRKSkole'
    assert NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099') == True
    assert NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355') == True
    assert NRKSkoleIE.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449') == False
    assert NRKSkoleIE.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099') == True

# Generated at 2022-06-26 12:32:45.353158
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()


# Generated at 2022-06-26 12:32:47.776903
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e_0 = NRKTVEpisodeIE()
    test_case_0()


# Generated at 2022-06-26 12:32:56.190093
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    i_e = NRKPlaylistIE()

# Generated at 2022-06-26 12:32:58.763374
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    _ASSETS_KEYS = ('episodes', 'instalments',)
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:34:07.628880
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrk_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:34:08.938672
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:34:09.925347
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
	nrk_skole_i_e = NRKSkoleIE()


# Generated at 2022-06-26 12:34:12.934040
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrktv_episode_i_e_0 = NRKTVEpisodeIE()

if __name__ == '__main__':
    test_case_0()
    test_NRKTVEpisodeIE()

# Generated at 2022-06-26 12:34:14.172329
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:34:26.741929
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test case 1
    u_r_l_0 = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()
    assert(n_r_k_playlist_i_e_0._match_id(u_r_l_0) == 'gjenopplev-den-historiske-solformorkelsen-1.12270763')
    webpage = n_r_k_playlist_i_e_0._download_webpage(u_r_l_0, 'gjenopplev-den-historiske-solformorkelsen-1.12270763')

# Generated at 2022-06-26 12:34:27.506979
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k = NRKSkoleIE()


# Generated at 2022-06-26 12:34:30.486822
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()
    # Test of '_extract_description'
    test_case_0()


# Generated at 2022-06-26 12:34:34.301888
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'series.nrk.no/series'
    instance = NRKTVSeriesIE()
    assert isinstance(instance, NRKTVSeriesIE)


# Generated at 2022-06-26 12:34:36.263823
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._VALID_URL

    assert NRKTVEpisodeIE._TESTS

    assert NRKTVEpisodeIE._real_extract()

# Generated at 2022-06-26 12:36:55.891679
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e_0 = NRKTVSeriesIE()

    # # Testing URL in constructor of class NRKTVSeriesIE
    # test_url_0 = "https://tv.nrk.no/serie/groenn-glede"
    # n_r_k_t_v__series_i_e_0_0 = NRKTVSeriesIE.suitable(test_url_0)

    # assert n_r_k_t_v__series_i_e_0_0

    # # Testing URL in constructor of class NRKTVSeriesIE
    # test_url_1 = "https://tv.nrk.no/serie/groenn-glede"
    # n_r_k_t_v__series_i_e_0_1 = NRK

# Generated at 2022-06-26 12:36:57.483383
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()

# Generated at 2022-06-26 12:36:58.663881
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:37:00.049492
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


test_case_0()
test_NRKTVSeasonIE()

# Generated at 2022-06-26 12:37:01.670035
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE(NRKPlaylistBaseIE)


# Generated at 2022-06-26 12:37:04.267685
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()

    with pytest.raises(AttributeError):
        n_r_k_radio_podkast_i_e.extract_info()


# Generated at 2022-06-26 12:37:08.270441
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    n_r_k_playlist_i_e = NRKPlaylistIE()
    n_r_k_playlist_i_e.urls = [url]
    assert n_r_k_playlist_i_e.suitable(url) == True


# Generated at 2022-06-26 12:37:09.218039
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:37:10.263547
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    test_case_0()

# Generated at 2022-06-26 12:37:11.206598
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()
