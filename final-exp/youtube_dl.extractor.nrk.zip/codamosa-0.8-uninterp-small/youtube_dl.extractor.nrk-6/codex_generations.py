

# Generated at 2022-06-26 12:32:19.805756
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_t_v_i_e = NRKTVIE()


# Generated at 2022-06-26 12:32:23.764415
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    print("test_NRKPlaylistBaseIE:")
    assert test_case_0()

test_NRKPlaylistBaseIE()

# Generated at 2022-06-26 12:32:28.546625
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e = NRKTVSeriesIE()


# Generated at 2022-06-26 12:32:29.620007
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    instance_of_nrkplaylistie = NRKPlaylistIE()


# Generated at 2022-06-26 12:32:30.728771
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()


# Generated at 2022-06-26 12:32:31.773762
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e = NRKIE()



# Generated at 2022-06-26 12:32:39.252625
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    # Test for _valid_url()
    try:
        val = 'https://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
        assert n_r_k_playlist_i_e_0._valid_url(val) == True
        val = 'https://www.nrk.no/skole/klara-klok-1.12281779'
        assert n_r_k_playlist_i_e_0._valid_url(val) == False
    except AssertionError as ae:
        print("[test_NRKPlaylistIE] Failure in _valid_url !\n")
        raise ae
    # Test for _real_extract()

# Generated at 2022-06-26 12:32:43.897786
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_NRKTVEpisodeIE_0 = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:32:45.399772
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:48.139239
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:33:58.438973
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:34:00.139917
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:34:00.905767
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():       
    n = NRKBaseIE()


# Generated at 2022-06-26 12:34:01.998822
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:34:05.339666
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:34:06.854939
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:34:07.844359
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e = NRKBaseIE()


# Generated at 2022-06-26 12:34:09.345841
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e_0 = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:34:10.071342
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert(True)


# Generated at 2022-06-26 12:34:10.914430
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test = NRKIE()


# Generated at 2022-06-26 12:35:16.893132
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie.IE_NAME



# Generated at 2022-06-26 12:35:17.962018
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.IE_NAME == 'nrk:direkte'


# Generated at 2022-06-26 12:35:22.640745
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """
    Test class NRKTVIE
    """
    from ytdl_cardinal.ies.nrk import NRKTVIE
    print("Testing NRKTVIE...")
    _tv = NRKTVIE()
    assert (_tv != None)
    assert (_tv.ie_key() == 'NRKTVIE')
    tv_tests = _tv._TESTS
    print("Testing NRKTVIE...OK")


# Generated at 2022-06-26 12:35:25.234352
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nrktvseasonie = NRKTVSeasonIE()
    nrktvseasonie.suitable(NRKTVSeasonIE._TESTS[0]['url'])
    nrktvseasonie._real_extract(NRKTVSeasonIE._TESTS[0]['url'])


# Generated at 2022-06-26 12:35:25.939966
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    playlist = NRKPlaylistIE()


# Generated at 2022-06-26 12:35:26.796641
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    testObject = NRKTVEpisodesIE()
    assert testObject is not None

# Generated at 2022-06-26 12:35:31.150430
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    filename = 'test_NRKTVDirekteIE_NRK1_1.mp4'
    save_to = os.path.join(os.getcwd(), filename)
    remove_file_if_exists(save_to)

    ie = NRKTVDirekteIE()
    _, ext = os.path.splitext(save_to)
    info = {'id': 'nrk1'}
    return ie._download_and_save(url, info, save_to, ext, params={'skip_download': False})


# Generated at 2022-06-26 12:35:36.117708
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktovie=NRKTVIE()
    nrktovie._real_extract("https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13")
    nrktovie._real_extract("https://tv.nrk.no/program/MDDP12000117")
    nrktovie._real_extract("https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015")

# Generated at 2022-06-26 12:35:44.314403
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    nrk_radio_podkast = NRKRadioPodkastIE()
    nrk_radio_podkast.suitable("https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8")
    nrk_radio_podkast.extract("https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8")

# Generated at 2022-06-26 12:35:45.972734
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE('nrk', 'nrk.no')


# Generated at 2022-06-26 12:38:45.805465
# Unit test for constructor of class NRKBaseIE

# Generated at 2022-06-26 12:38:57.621664
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Simple, test only for exceptions and missing values
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/3'
    instance = NRKTVEpisodeIE(None)
    instance._real_extract(url)

# class NRKRadioIE(InfoExtractor):
#     _VALID_URL = r'https?://(?:radio\.)?nrk\.no/(?:[^/]+/)*(?P<id>[a-zA-Z]{4}\d{8})'
#     _TESTS = [{
#         'url': 'http://radio.nrk.no/serie/skam/NPUB21019315/30-01-2016',
#         'info_dict': {
#             'id': 'NPUB21

# Generated at 2022-06-26 12:39:09.122918
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from .nrktvepisode import NRKTVEpisodeIE
    from .nrkradiopodkast import NRKRadioPodkastIE

    # Suitable
    assert NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/backstage/sesong/1')
    # Unsuitable
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/spangas/sesong/1/episode/2')
    assert not NRKTVSeasonIE.suitable('https://tv.nrk.no/serie/spangas/sesong/1/episode/2?ending')
    assert not NRKTVSeasonIE.suitable('https://radio.nrk.no/serie/dagsnytt/sesong/201507/NPUB21019315')

# Generated at 2022-06-26 12:39:20.178135
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Basic check that formatting in regexps works
    ie = NRKBaseIE(None)
    assert ie._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''
    # Check that i in _GEO_COUNTRIES is replaced with y
    assert ie._GEO_COUNTRIES == ['NO']



# Generated at 2022-06-26 12:39:28.935040
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebaseie = NRKTVSerieBaseIE()
    assert nrktvseriebaseie._ASSETS_KEYS == ('episodes', 'instalments',)
    assert nrktvseriebaseie._extract_assets_key({'episodes': 1}) == 'episodes'
    assert nrktvseriebaseie._extract_assets_key({'instalments': 1}) == 'instalments'



# Generated at 2022-06-26 12:39:41.564279
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    season_url = 'https://radio.nrk.no/serie/dagsnytt/sesong/201509'
    season_doc = NRKTVSeasonIE._download_json(season_url, 'season')
    season_embedded = season_doc['_embedded']
    seasons = season_embedded['instalments']
    if season_embedded.get('extraMaterial'):
        seasons.append(season_embedded['extraMaterial'])
    season_embedded['seasons'] = seasons

    series_id = 'dagsnytt'
    series_titles = {
        'title': 'Dagsnytt',
        'subtitle': 'md5:fe0ed5d5a8def5f5b5e5b5a03b4f48b4',
    }

# Generated at 2022-06-26 12:39:43.439795
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE

# Generated at 2022-06-26 12:39:49.293276
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = "https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13"
    video_id = 'KMTE50001317'
    ie = NRKTVIE()
    assert ie._match_id(url) == video_id



# Generated at 2022-06-26 12:40:00.835049
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    ie._episodes_re = re.compile(ie._EPISODE_RE)
    ie._valid_url = re.compile(ie._VALID_URL)

    assert ie._episodes_re.match('MUHH46000317')
    assert ie._valid_url.match('https://tv.nrk.no/serie/lindmo/2018/MUHU11006318/avspiller')
    assert ie._valid_url.match('https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#')


# Generated at 2022-06-26 12:40:09.416186
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
