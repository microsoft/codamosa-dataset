

# Generated at 2022-06-26 12:32:25.732737
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e_0 = NRKIE()


# Generated at 2022-06-26 12:32:26.653391
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e = NRKIE()


# Generated at 2022-06-26 12:32:28.819938
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()

# test_case_0

if __name__ == '__main__':
    test_NRKPlaylistIE()
    test_case_0()

# Generated at 2022-06-26 12:32:38.660208
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e_0 = InfoExtractor()
    assert_equals(n_r_k_base_i_e_0._GEO_COUNTRIES, ['NO'])
    assert_equals(
        n_r_k_base_i_e_0._CDN_REPL_REGEX,
        r'(?x)://\n        (?:\n            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|\n            nrk-od-no\.telenorcdn\.net|\n            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no\n        )/'
    )

# Generated at 2022-06-26 12:32:42.504953
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_t_v_i_e_obj = NRKTVIE()


# Generated at 2022-06-26 12:32:44.812996
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e_0 = NRKTVSeriesIE()


# Generated at 2022-06-26 12:32:47.951380
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()
    assert n_r_k_radio_podkast_i_e_0 is not None


# Generated at 2022-06-26 12:32:49.830333
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/serie/blank'
    NRKPlaylistBaseIE._download_webpage()



# Generated at 2022-06-26 12:32:51.180701
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE.__bases__ == (NRKTVSerieBaseIE,)



# Generated at 2022-06-26 12:32:52.362653
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_i_e_0 = NRKPlaylistIE()


# Generated at 2022-06-26 12:34:17.246525
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE(None, None)
    assert ie._ASSETS_KEYS == ('episodes', 'instalments', )
    assert ie._catalog_name('') == 'series'
    assert ie._catalog_name('bogus') == 'series'
    assert ie._catalog_name('podcast') == 'podcast'
    assert ie._catalog_name('podkast') == 'podcast'


# Generated at 2022-06-26 12:34:20.380170
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Test that the constructor does not raise any exceptions
    NRKTVIE(None)



# Generated at 2022-06-26 12:34:25.241587
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE()
    assert ie._call_api('radio/catalog/podcast/hele_historien/seasons/test', 'test', 'season', {}) == 'test'
    assert ie._call_api('tv/catalog/series/test/seasons/1', 'test', 'season', {}) == 'test'
    assert ie._call_api('https://radio.nrk.no/catalog/podcast/test/seasons/test', 'test', 'season', {}) == 'test'
    assert ie._call_api('http://tv.nrk.no/catalog/series/test/seasons/1', 'test', 'season', {}) == 'test'

# Generated at 2022-06-26 12:34:34.361468
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    test_instance = NRKTVEpisodeIE()
    test_instance.url = url
    result = test_instance._real_extract(url)
    assert result == {
        '_type': 'url',
        'id': 'MSUI14000816',
        'url': 'nrk:MSUI14000816',
        'ie_key': 'NRK',
        'season_number': 1,
        'episode_number': 8
    }


# Generated at 2022-06-26 12:34:37.282900
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._ITEM_RE
    assert NRKPlaylistIE._VALID_URL
    assert NRKPlaylistIE.IE_DESC
    assert NRKPlaylistIE.ie_key() == 'NRKPlaylist'
    assert NRKPlaylistIE._TESTS



# Generated at 2022-06-26 12:34:41.822380
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert len(NRKTVEpisodesIE._TESTS) >= 1
    
    # Single test case
    test_case = NRKTVEpisodesIE._TESTS[0]
    assert test_case['url'] == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'

    # NRKTVEpisodesIE instance
    NRKTVEpisodesIE_instance = NRKTVEpisodesIE()

    # Check that the mandatory class attribute _VALID_URL is set
    assert getattr(NRKTVEpisodesIE_instance, '_VALID_URL', None) is not None

    # Check that the class method suitable() is defined

# Generated at 2022-06-26 12:34:49.228244
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrkbaseie = NRKBaseIE(None, None)
    assert nrkbaseie._GEO_COUNTRIES == ['NO']
    assert nrkbaseie._CDN_REPL_REGEX == r'://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'

# Generated at 2022-06-26 12:34:49.718532
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    NRKBaseIE()

# Generated at 2022-06-26 12:34:52.849631
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    instance = NRKTVDirekteIE()
    url = 'https://tv.nrk.no/direkte/nrk1'
    expected = {
        'url': 'nrk:nrk1',
        'id': 'nrk1',
        'title': 'nrk1',
        'ie_key': 'NRKTV',
    }
    assert instance.extract(url) == expected

# Generated at 2022-06-26 12:34:59.587511
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    nrktvepisodeie = NRKTVEpisodeIE()
    assert nrktvepisodeie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    assert nrktvepisodeie._match_id(url) == 'hellums-kro/sesong/1/episode/2'

# Generated at 2022-06-26 12:37:53.630945
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    url = 'https://tv.nrk.no/serie/20-spoersmaal'
    display_id = '20-spoersmaal'
    info = NRKTVSerieBaseIE()._call_api(
        'series/%s' % display_id, display_id, 'series')
    assert info['title'] == '20 spørsmål'
    assert info['@type'] == 'TVSeries'
    assert info['@id'] == 'https://tv.nrk.no/serie/20-spoersmaal'
    assert info['url'] == 'https://tv.nrk.no/serie/20-spoersmaal'

# Generated at 2022-06-26 12:38:01.359150
# Unit test for constructor of class NRKIE
def test_NRKIE():
    url = 'http://www.nrk.no/video/PS*150533'
    # The following line will fail with the exception raised by the above
    # if the constructor doesn't take the url parameter properly.
    nrk = NRKIE(url)
    if nrk.url != url:
        print('%s != %s' % (nrk.url, url))

test_NRKIE()



# Generated at 2022-06-26 12:38:05.146650
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # NRKTVSeasonIE should not be called directly but only through its super class NRKBaseIE
    # In order to fail in case constructor is called directly,
    # we raise exception when "mark_as_watched" is set to true
    NRKBaseIE.__init__ = _not_implemented_constructor
    with pytest.raises(NotImplementedError):
        NRKTVSeasonIE("test_url", True)
    NRKBaseIE.__init__ = _old_NRKBaseIE_init



# Generated at 2022-06-26 12:38:07.918779
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert (NRKSkoleIE('NRKSkoleIE', 'nrk:6021') == NRKSkoleIE(
        'NRKSkoleIE', 'nrk:6021'))

_SEARCH_KEY_RE = r'%7B%22(?P<catalog>[^%"]+)"%3A%22(?P<term>[^%"]+)%22%7D'



# Generated at 2022-06-26 12:38:13.048146
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Initialize a NRKPlaylistBaseIE object
    test_nrk_playlistBase_obj = NRKPlaylistBaseIE()
    # Test for existance of _extract_description method
    assert hasattr(test_nrk_playlistBase_obj, '_extract_description')


# Generated at 2022-06-26 12:38:23.336682
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert isinstance(NRKTVSerieBaseIE, InfoExtractor)
    assert hasattr(NRKTVSerieBaseIE, '_real_extract')
    assert hasattr(NRKTVSerieBaseIE, '_extract_entries')
    assert hasattr(NRKTVSerieBaseIE, '_extract_assets_key')
    assert hasattr(NRKTVSerieBaseIE, '_catalog_name')
    assert hasattr(NRKTVSerieBaseIE, '_entries')
    assert hasattr(NRKTVSerieBaseIE, '_ASSETS_KEYS')


# Generated at 2022-06-26 12:38:26.034145
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    """This is a test of constructor of class NRKTVSeriesIE.

    """
    NRKTVSeriesIE()



# Generated at 2022-06-26 12:38:34.175412
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
	url = 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'
	response = requests.get(url)
	assert response.status_code == 200
	html = response.text
	assert '<div id="radio-playlist-media-list" class="list-pad-left-right">' in html
	assert 'id="nrk-tv-pause-button"' not in html


# Generated at 2022-06-26 12:38:44.725548
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    m_call_api = MagicMock()
    m_call_api.return_value = 'data'

    nrktvie = NRKTVSeasonIE('url', m_call_api)
    nrktvie._real_extract('url')
    assert m_call_api.call_count == 2
    assert m_call_api.call_args_list[0][1].get('note') == 'Downloading episodes JSON page 1'
    assert m_call_api.call_args_list[1][1].get('note') == 'Downloading episodes JSON page 2'


# Generated at 2022-06-26 12:38:48.613037
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE().get_id() == 'NRKTVEpisodeIE'
