

# Generated at 2022-06-26 12:32:18.284449
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:32:24.715051
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    """Constructor for class NRKPlaylistBaseIE"""
    dummy_NRKPlaylistBaseIE = NRKPlaylistBaseIE()

test_case_0()
test_NRKPlaylistBaseIE()

# Generated at 2022-06-26 12:32:28.739596
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e_0 = NRKBaseIE()


# Generated at 2022-06-26 12:32:30.840918
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    url = 'https://tv.nrk.no/direkte/nrk1'
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE(url)



# Generated at 2022-06-26 12:32:37.426791
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test if result from call to NRKTVSeriesIE._download_webpage is not None
    assert NRKTVSeriesIE()._download_webpage(
        'https://tv.nrk.no/serie/groenn-glede', 'groenn-glede') is not None
    
    # Test if result from call to NRKTVSeriesIE._real_extract is not None
    assert NRKTVSeriesIE()._real_extract(
        'https://tv.nrk.no/serie/groenn-glede') is not None


# Generated at 2022-06-26 12:32:38.636142
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:39.792447
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:32:51.629050
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # class constructor:
    n_r_k_base_ie = NRKBaseIE()
    assert n_r_k_base_ie._GEO_COUNTRIES == ['NO']
    assert n_r_k_base_ie._COLLECTION_TITLE == 'NRK'
    assert type(n_r_k_base_ie.ie_key()) == str
    assert type(n_r_k_base_ie.IE_NAME) == str
    assert type(n_r_k_base_ie.IE_DESC) == str
    assert type(n_r_k_base_ie.ie_key()) == str
    assert type(n_r_k_base_ie.js_to_json(None)) == dict

# Generated at 2022-06-26 12:32:53.881858
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:33:00.603318
# Unit test for constructor of class NRKIE

# Generated at 2022-06-26 12:34:12.286542
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
	nrk_tv_series_ie_0 = NRKTVSeriesIE()

# Generated at 2022-06-26 12:34:13.620560
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktvepisodesIE = NRKTVEpisodesIE()
    assert nrktvepisodesIE is not None


# Generated at 2022-06-26 12:34:21.184981
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    _VALID_URL = 'https://tv.nrk.no/serie/backstage/sesong/1/episode/8'
    nrk_tv_eposide_i_e = NRKTVEpisodeIE()
    assert nrk_tv_eposide_i_e._VALID_URL == _VALID_URL


# Generated at 2022-06-26 12:34:26.682442
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert_raises(RegexNotFoundError, NRKTVEpisodesIE._get_all_episodes, 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert_raises(AttributeError, NRKTVEpisodesIE._extract_title, 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    assert_raises(AttributeError, NRKTVEpisodesIE._extract_description, 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')

# Generated at 2022-06-26 12:34:29.378223
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    try:
        case0 = test_case_0()
    except Exception as e:
        print('Exception caught: ' + repr(e))


# Generated at 2022-06-26 12:34:31.923776
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e_0 = NRKTVSeriesIE()


# Generated at 2022-06-26 12:34:33.990357
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrktvseriesie = NRKTVSeriesIE()


# Generated at 2022-06-26 12:34:35.581562
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    print('Testing constructor')
    nrktvseriesie = NRKTVSeriesIE()
    # Testing whether object created successfully
    assert nrktvseriesie != None


# Generated at 2022-06-26 12:34:37.288532
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    NRKBaseIE()



# Generated at 2022-06-26 12:34:38.317083
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert not NRKTVSeasonIE.suitable('nrk:MSPO30010116')


# Generated at 2022-06-26 12:37:10.693204
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e = NRKBaseIE()


# Generated at 2022-06-26 12:37:11.313674
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert test_case_0() is None


# Generated at 2022-06-26 12:37:12.774496
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test_case_NRKIE = NRKIE()


# Generated at 2022-06-26 12:37:15.621809
# Unit test for constructor of class NRKIE
def test_NRKIE():
    """
    Test constructor of class NRKIE.
    """
    n_r_k_i_e_0 = NRKIE()
    assert n_r_k_i_e_0.suitable('https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533')


# Generated at 2022-06-26 12:37:21.378539
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e_0 = NRKIE()
    # Even if setUp() is included in the test suite, it's not executed
    # before test cases.
    # Therefore, it's necessary to prepare the test fixtures in each test case.
    # It's possible to set a test fixture as a class field
    # (not to create it in each test case) by decorating a test case class by
    # @classmethod.
    n_r_k_i_e_0._setup_downloader()
    n_r_k_i_e_0._setup_query_compat()


# Generated at 2022-06-26 12:37:22.990013
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    try:
        test_case_0()
    except Exception as e:
        print('Exception while testing get_i_d: ' + str(e))


# Generated at 2022-06-26 12:37:24.578469
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e_0 = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:37:26.662098
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE() != None

# DocTests
if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)

# Generated at 2022-06-26 12:37:27.634363
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE.__dict__ is not None


# Generated at 2022-06-26 12:37:28.574501
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e = NRKSkoleIE()


# Generated at 2022-06-26 12:40:07.324623
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert_raises_regexp(NotImplementedError, '.*Override.*', NRKPlaylistBaseIE(None)._real_extract, "http://www.nrk.no/")



# Generated at 2022-06-26 12:40:14.924815
# Unit test for constructor of class NRKIE
def test_NRKIE():
    a = NRKBaseIE()
    assert a.IE_NAME == 'nrk'
    assert a._VALID_URL == r'''(?x)
                        (?:
                            nrk:|
                            https?://
                                (?:
                                    (?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)|
                                    v8[-.]psapi\.nrk\.no/mediaelement/
                                )
                            )
                            (?P<id>[^?\#&]+)
                        '''
    assert a._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-26 12:40:17.753378
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    LRU_cache = compat_lru_cache(maxsize=32)(lambda _: None)
    url = 'https://tv.nrk.no/direkte/nrk1'
    nrkdirekteie = NRKTVDirekteIE(LRU_cache)
    assert nrkdirekteie._match_id(url) == 'nrk1'



# Generated at 2022-06-26 12:40:25.788563
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/19355'
    test_values = (url, '19355', 'K15114', 'naturfag', 'https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355')
    nrkSkoleIE = NRKSkoleIE()
    assert(nrkSkoleIE._VALID_URL is test_values[4])
    assert(nrkSkoleIE._download_json(test_values[0], test_values[1])['psId'] is test_values[2])

# Generated at 2022-06-26 12:40:33.592204
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE(None, "http://tv.nrk.no/program/MSPP14001114")
    check_url = 'https://psapi.nrk.no/programs/MSPP14001114/episodes?pageSize=50&expanded=true'
    assert ie._get_m3u8_url(check_url) == 'https://psapi.nrk.no/programs/MSPP14001114/mediaelement/streams/pass.m3u8'

# Generated at 2022-06-26 12:40:34.775034
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()

# Generated at 2022-06-26 12:40:45.154870
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    obj = NRKTVEpisodesIE()
    assert isinstance(obj, NRKPlaylistBaseIE)
    assert obj._VALID_URL == r'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert obj._ITEM_RE == r'data-episode=["\']%s' % NRKTVIE._EPISODE_RE
    assert obj._TESTS[0]['url'] == 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031'
    assert obj._TESTS[0]['info_dict'] == {'id': '69031', 'title': 'Nytt på nytt, sesong: 201210'}
    assert obj._TESTS

# Generated at 2022-06-26 12:40:45.743101
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE()



# Generated at 2022-06-26 12:40:56.450844
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-26 12:40:59.337380
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # No value, no exception
    ie = NRKTVSeriesIE()
    assert ie is not None
