

# Generated at 2022-06-26 12:32:13.428030
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e_0 = NRKBaseIE()


# Generated at 2022-06-26 12:32:15.564978
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()


# Generated at 2022-06-26 12:32:21.301505
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test case NRKTVIE.__init__ with configuration None
    n_r_k_t_v_i_e_0 = NRKTVIE(configuration=None)


# Generated at 2022-06-26 12:32:24.149960
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e = NRKSkoleIE()


# Generated at 2022-06-26 12:32:29.096888
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktvepisodesie = NRKTVEpisodesIE()
    assert nrktvepisodesie.ie_key() == "NRKTVEpisodes"
    assert nrktvepisodesie.ie_key() == "NRKTVEpisodes"
    assert nrktvepisodesie.suitable("https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031")
    assert nrktvepisodesie._downloader is not None
    assert nrktvepisodesie.ie_key() == 'NRKTVEpisodes'


# Generated at 2022-06-26 12:32:31.269429
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()

from .common import ExtractorTest

from .nrk import NRKTVIE
from .nrk import NRKTVEpisodeIE
from .nrk import NRKTVSerieBaseIE



# Generated at 2022-06-26 12:32:40.148630
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e_0 = NRKBaseIE()
    n_r_k_base_i_e_1 = NRKBaseIE(_downloader=None)
    n_r_k_base_i_e_2 = NRKBaseIE(_downloader=None, _handle_error=None)
    n_r_k_base_i_e_3 = NRKBaseIE(_downloader=None, _handle_error=None, _download_retry=None)
    assert n_r_k_base_i_e_1._downloader is None
    assert n_r_k_base_i_e_2._handle_error is None
    assert n_r_k_base_i_e_3._download_retry is None


# Generated at 2022-06-26 12:32:45.442877
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Creation of object of class NRKPlaylistBaseIE
    n_r_k_playlist_base_i_e = NRKPlaylistBaseIE()



# Generated at 2022-06-26 12:32:46.871725
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert isinstance(NRKTVSeasonIE(), NRKTVSeasonIE)


# Generated at 2022-06-26 12:32:50.996399
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test without parameter
    try:
        nrktvseriesie = NRKTVSeriesIE()
    except Exception as e:
        print('FAIL: Could not create NRKTVSeriesIE object without parameter, actual error: ', repr(e))
        assert False


# Generated at 2022-06-26 12:34:02.830424
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e_0 = NRKTVEpisodeIE()

# Generated at 2022-06-26 12:34:04.199094
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
	n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:34:07.789015
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # testing proper initialization
    # invoked after proper instantiation
    assert(NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede') == True)
    # testing constructor
    NRKTVSeriesIE()


# Generated at 2022-06-26 12:34:08.776796
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e_0 = NRKIE()



# Generated at 2022-06-26 12:34:10.944340
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_case_0()
    test_NRKTVIE()
    n_r_k_t_v_episode_i_e_0 = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:34:13.099756
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert_raises(AttributeError, NRKRadioPodkastIE, None)


# Generated at 2022-06-26 12:34:14.147750
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_tv_series_i_e_0 = NRKTVSeriesIE()


# Generated at 2022-06-26 12:34:19.318286
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    t_v_nr_k_no = 'https://tv.nrk.no/program'
    e_pisodes_nytt_paa_nytt = '%s/episodes/nytt-paa-nytt' % t_v_nr_k_no
    _69031 = '69031'
    episodes_pages = {
        e_pisodes_nytt_paa_nytt: 'NRKTVEpisodesIE.test'
    }
    webpages = {episodes_pages[e_pisodes_nytt_paa_nytt]: 'NRKTVEpisodesIE.test'}
    items = {'NRKTVEpisodesIE.test': ['NRKTVEpisodesIE.test']}
    not_found_counts = {e_pisodes_nytt_paa_nytt: 0}

# Generated at 2022-06-26 12:34:20.985895
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Unit test for constructor of class NRKTVDirekteIE
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:34:22.018175
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert NRKTVIE()


# Generated at 2022-06-26 12:35:33.067239
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e_0 = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:35:37.969749
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert type(NRKTVEpisodesIE()) == NRKTVEpisodesIE
    assert type(NRKTVEpisodesIE.info()) == dict
    assert type(NRKTVEpisodesIE.suitable()) == bool
    assert type(NRKTVEpisodesIE.ie_key()) == str
    assert type(NRKTVEpisodesIE.update_ie_key()) == NoneType
    assert type(NRKTVEpisodesIE.test_and_report()) == NoneType
    assert type(NRKTVEpisodesIE.test()) == NoneType
    assert type(NRKTVEpisodesIE.test_with_descriptions()) == NoneType
    assert type(NRKTVEpisodesIE.test_with_all_descriptions()) == NoneType
    assert type(NRKTVEpisodesIE.test_playlist_links()) == NoneType


# Generated at 2022-06-26 12:35:39.040311
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e = NRKTVDirekteIE()


# Generated at 2022-06-26 12:35:39.956573
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
   n_r_k_skole_i_e = NRKSkoleIE()


# Generated at 2022-06-26 12:35:41.237084
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Check for correct initialization of variables
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:35:42.756055
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE()._VALID_URL == r'https?://(?:tv|radio)\.nrk\.no/direkte/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 12:35:47.609036
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = "https://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449"
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()
    n_r_k_playlist_i_e_0._real_extract(url)



# Generated at 2022-06-26 12:35:49.520804
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e = NRKTVSerieBaseIE()



# Generated at 2022-06-26 12:35:52.202153
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e_0 = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:35:53.751629
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:38:31.801469
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    import os
    os.chdir("/Users/hongbo/dev/wisen/wisen/wisen/YoutubeDL/YoutubeDL/extractor/NRKPlaylistBase")
    instance = NRKTVSerieBaseIE()
    print("type of NRKTVSerieBaseIE:", type(instance))

##############################################################################


# Generated at 2022-06-26 12:38:33.905789
# Unit test for constructor of class NRKIE
def test_NRKIE():
    try:
        from_ = 'ie'
        ie = NRKIE()
        ie._real_extract('nrk:ecc1b952-96dc-4a98-81b9-5296dc7a98d9', from_)
    except Exception as err:
        print(err)


# Generated at 2022-06-26 12:38:37.254104
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e = NRKBaseIE()


# Generated at 2022-06-26 12:38:39.027386
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    test_case_0()

# Generated at 2022-06-26 12:38:45.412768
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e_0 = NRKTVEpisodeIE()

if __name__ == '__main__':
    test_case_0()
    test_NRKTVEpisodeIE()
    # n_r_k_playlist_base_i_e_0 = NRKPlaylistBaseIE()
    # self.display_name = display_name
    # self.nrk_id = nrk_id
    # self.url = url
    # self.webpage_url = webpage_url
    # self.__class__.nrk_ie = self.nrk_ie = NRKIE()
    # self.__class__.nrk_ie = self.nrk_ie = NRKIE()
    # self.__class__.nrk_ie = self.nr

# Generated at 2022-06-26 12:38:55.022903
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrk_playlist_base_ie = NRKPlaylistBaseIE()
    assert issubclass(NRKPlaylistBaseIE, InfoExtractor)
    assert NRKPlaylistBaseIE.__doc__ == 'NRKPlaylistBaseIE()'
    assert isinstance(nrk_playlist_base_ie, NRKPlaylistBaseIE)
    assert isinstance(NRKPlaylistBaseIE, type)


# Generated at 2022-06-26 12:39:06.384040
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Input data
    x = 'test_NRKTVDirekteIE'
    # Expected output
    expected_output = 'test_NRKTVDirekteIE'
    # Instantiation of class
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE
    # Actual output
    actual_output = n_r_k_t_v_direkte_i_e_0.suitable(x)
    # Assertion point
    assert actual_output == expected_output


# Generated at 2022-06-26 12:39:19.665557
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e = NRKSkoleIE("NRKSkoleIE", "nrkskole.no", "http://nrkskole.no/media/1234", "1234")
    if n_r_k_skole_i_e.SUFFIX == "":
        raise AssertionError("SUFFIX set incorrectly")
    if n_r_k_skole_i_e.ie_key() != "NRKSkole":
        raise AssertionError("ie_key() returned incorrect value")
    if n_r_k_skole_i_e._extract_format("NRKSkole", "http://nrk.no/video/PS1234") != "1234":
        raise AssertionError("_extract_format() returned incorrect value")

# Unit

# Generated at 2022-06-26 12:39:21.765063
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE()


# Generated at 2022-06-26 12:39:22.572645
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrktvseriebaseie = NRKTVSerieBaseIE
