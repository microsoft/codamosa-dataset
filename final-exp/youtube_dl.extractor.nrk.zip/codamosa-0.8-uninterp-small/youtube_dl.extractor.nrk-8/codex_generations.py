

# Generated at 2022-06-26 12:32:23.067761
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert_equal(test_case_0(), None)


# Generated at 2022-06-26 12:32:36.331815
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():

    # Test with an empty url
    url = ''
    n_r_k_t_v_i_e = NRKTVIE()
    assert n_r_k_t_v_i_e._match_id(url) == None

    # Test with an invalid url
    n_r_k_t_v_i_e = NRKTVIE()
    assert n_r_k_t_v_i_e._match_id(url) == None

    # Test with a valid url
    url = 'https://tv.nrk.no/program/MDDP12000117'
    n_r_k_t_v_i_e = NRKTVIE()
    assert n_r_k_t_v_i_e._match_id(url) == 'MDDP12000117'

    # Test with

# Generated at 2022-06-26 12:32:37.283790
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e = NRKIE()


# Generated at 2022-06-26 12:32:39.422012
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    '''
    Unit tests for constructor of class NRKSkoleIE
    '''
    nrkskoleie = NRKSkoleIE()
    assert isinstance(nrkskoleie, NRKSkoleIE)


# Generated at 2022-06-26 12:32:46.790474
# Unit test for constructor of class NRKPlaylistBaseIE

# Generated at 2022-06-26 12:32:52.110940
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    vid = 'test_id'
    video_id = 'test_id'
    asset_url = 'test_url'
    expected_asset_url = 'test_url'
    formats = 'test_formats'
    test_NRKBaseIE = NRKBaseIE(vid)
    assert test_NRKBaseIE._extract_nrk_formats(asset_url, video_id) == formats


# Generated at 2022-06-26 12:32:53.778345
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()
    assert n_r_k_skole_i_e_0 != None


# Generated at 2022-06-26 12:32:55.265642
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert_raises(RegexNotFoundError, NRKTVSeriesIE._make_ie_url_regex, 'http://www.nrk.no')

# Generated at 2022-06-26 12:32:56.899019
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nRKTVEpisodesIE = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:32:57.902924
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    a = NRKTVDirekteIE()


# Generated at 2022-06-26 12:34:09.031948
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e = NRKTVDirekteIE()


# Generated at 2022-06-26 12:34:10.749572
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Assert that constructor for class NRKTVSeasonIE is not none
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()

# Generated at 2022-06-26 12:34:11.702712
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-26 12:34:13.010465
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()

# Generated at 2022-06-26 12:34:14.690901
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()


# Generated at 2022-06-26 12:34:15.751861
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:34:17.102523
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_ie = NRKBaseIE()

# Generated at 2022-06-26 12:34:19.574150
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE() is not None



# Generated at 2022-06-26 12:34:20.443176
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrkTVEpisodesIE = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:34:21.393610
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_i_e = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:35:35.932809
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    import sys
    import unittest
    test_case_0.__globals__['__name__'] = 'NRKSkoleIE'
    test_case_0.__globals__['__file__'] = __file__
    n_r_k_skole_i_e_0 = NRKSkoleIE()
    assert_equals(n_r_k_skole_i_e_0.IE_DESC, 'NRK Skole')
    assert_equals(n_r_k_skole_i_e_0._VALID_URL, r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)')

# Generated at 2022-06-26 12:35:37.077365
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    unit = NRKTVDirekteIE()
    assert unit.__class__ == NRKTVDirekteIE


# Generated at 2022-06-26 12:35:46.103707
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrk_episode_ie = NRKTVEpisodeIE()
    nrk_episode_ie.nrk_id = "Kampen om tungtvannet"
    nrk_episode_ie.display_id = "Kampen om tungtvannet"
    nrk_episode_ie.season_number = "1"
    nrk_episode_ie.episode_number = "1"
    assert nrk_episode_ie.nrk_id == "Kampen om tungtvannet"
    assert nrk_episode_ie.display_id == "Kampen om tungtvannet"
    assert nrk_episode_ie.season_number == "1"
    assert nrk_episode_ie.episode_number == "1"


# Generated at 2022-06-26 12:35:47.928695
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e_0 = NRKTVSeriesIE()


# Generated at 2022-06-26 12:35:48.721380
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    tv_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:35:49.929841
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    
    n_r_k_skole_i_e = NRKSkoleIE()
    assert n_r_k_skole_i_e_0.__init__() == None

# Generated at 2022-06-26 12:35:50.872826
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:35:52.367182
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e_0 = NRKIE()


# Generated at 2022-06-26 12:35:54.275152
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    _NRKTVDirekteIE = NRKTVDirekteIE()
    assert bool(_NRKTVDirekteIE) == True

if __name__ == '__main__':
    test_NRKTVDirekteIE()
    test_case_0()

# Generated at 2022-06-26 12:35:57.368206
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Create an instance of subclass NRKSkoleIE
    n_r_k_skole_i_e = NRKSkoleIE()
    # Check if it is an instance of NRKBaseIE
    assert(isinstance(n_r_k_skole_i_e, NRKBaseIE))



# Generated at 2022-06-26 12:38:38.183449
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_playlist_i_e_0 = NRKPlaylistIE()


# Generated at 2022-06-26 12:38:41.677277
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:38:44.332138
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Try, Try and Exception
    try:
        test_case_0()
    except Exception as e:
        print(e)
    finally:
        # No exceptions, everything's fine.
        pass


# Generated at 2022-06-26 12:38:47.945255
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()
    assert nrktvie is not None


# Generated at 2022-06-26 12:38:52.956909
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e = NRKSkoleIE()
    assert n_r_k_skole_i_e.ie_key() == 'NRKSkole'



# Generated at 2022-06-26 12:38:54.064437
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Initilizes the constructor of class NRKTVSeasonIE
    nrktv_season_i_e = NRKTVSeasonIE()


# Generated at 2022-06-26 12:38:55.145494
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert callable(NRKSkoleIE)


# Generated at 2022-06-26 12:38:57.687117
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e = NRKTVSeriesIE()


# Generated at 2022-06-26 12:39:03.117293
# Unit test for constructor of class NRKTVSeriesIE

# Generated at 2022-06-26 12:39:04.587686
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()