

# Generated at 2022-06-26 12:32:15.495109
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrktvie = NRKTVIE()

# Generated at 2022-06-26 12:32:18.398486
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    """
    Unit test for constructor of class NRKRadioPodkastIE
    """
    test_nrk_radio_podkast_i_e_0 = NRKRadioPodkastIE()

# Generated at 2022-06-26 12:32:19.963271
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:32:25.732512
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    test_object = NRKSkoleIE()


# Generated at 2022-06-26 12:32:26.933274
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_ie = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:32:27.599291
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert 'NRKIE'


# Generated at 2022-06-26 12:32:28.820117
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_ie_0 = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:32:30.899128
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e_0 = NRKBaseIE()


# Generated at 2022-06-26 12:32:33.054325
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    instance = NRKPlaylistBaseIE()
    assert isinstance(instance, NRKPlaylistBaseIE)
    assert issubclass(NRKPlaylistBaseIE, InfoExtractor)


# Generated at 2022-06-26 12:32:33.755930
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrktvie = NRKTVEpisodeIE()

# Generated at 2022-06-26 12:33:40.162582
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE(NRKIE.ie_key(), {'url': 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8'})


# Generated at 2022-06-26 12:33:44.762976
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    ie = NRKTVEpisodesIE()
    assert ie.IE_NAME == 'nrk:episodes'
    assert ie.IE_DESC == 'NRK TV and NRK Radio episodes'
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/program/[Ee]pisodes/[^/]+/(?P<id>\d+)'
    assert ie._ITEM_RE == 'data-episode=["\']%s' % (NRKTVIE._EPISODE_RE)

# Generated at 2022-06-26 12:33:48.924901
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    test_cases = ['https://tv.nrk.no/serie/lindmo/sesong/1', 'https://tv.nrk.no/serie/backstage/sesong/1']
    for url in test_cases:
        ie = NRKTVSeasonIE(url)
        assert ie
        assert ie.suitable(url)


# Generated at 2022-06-26 12:33:53.516620
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """Unit test for constructor of class NRKTVIE.
    """

    # Issue: https://github.com/rg3/youtube-dl/issues/9392
    def check_NRKTVIE(expected_video_id, url):
        actual_video_id = NRKTVIE._match_id(url)
        assert expected_video_id == actual_video_id, \
            'After NRKTVIE._match_id with url={url}, the expected video ID ' \
            'was {expected_video_id}, but the actual video ID was ' \
            '{actual_video_id}.'.format(
                    url=url,
                    expected_video_id=expected_video_id,
                    actual_video_id=actual_video_id)

    # ID: MDDP12000117
    # url: https://tv

# Generated at 2022-06-26 12:33:58.102009
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE._TESTS[0] == {
        'url': 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763',
        'info_dict': {
            'id': 'gjenopplev-den-historiske-solformorkelsen-1.12270763',
            'title': 'Gjenopplev den historiske solformørkelsen',
            'description': 'md5:c2df8ea3bac5654a26fc2834a542feed',
        },
        'playlist_count': 2,
    }


# Generated at 2022-06-26 12:34:02.794236
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert hasattr(NRKPlaylistBaseIE,'_download_webpage')==True
    assert hasattr(NRKPlaylistBaseIE,'_extract_description')==True
    assert hasattr(NRKPlaylistBaseIE,'playlist_result')==True
    assert hasattr(NRKPlaylistBaseIE,'_extract_title')==True
    assert hasattr(NRKPlaylistBaseIE,'_real_extract')==True
    assert hasattr(NRKPlaylistBaseIE,'url_result')==True
    assert hasattr(NRKPlaylistBaseIE,'_extract_description')==True
    assert hasattr(NRKPlaylistBaseIE,'_real_extract')==True



# Generated at 2022-06-26 12:34:08.232910
# Unit test for constructor of class NRKIE
def test_NRKIE():
    class_ = NRKIE()
    assert class_._CDN_REPL_REGEX == r'://(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no)/'


# Generated at 2022-06-26 12:34:08.970708
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
	assert NRKPlaylistBaseIE("url")



# Generated at 2022-06-26 12:34:10.440798
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    NRKTVDirekteIE('https://tv.nrk.no/direkte/nrk1')



# Generated at 2022-06-26 12:34:22.678958
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://tv.nrk.no/programmer/puls/puls-11-05-2013/SF24070313/sesong-1'
    ie = NRKPlaylistBaseIE(NRKPlaylistBaseIE._downloader, url)

    assert ie.url == url
    assert ie._VALID_URL == 'https?://(?:tv|radio)\.nrk\.no/(?:programmer/([^/?#&]+)/([^/?#&]+)/([^/?#&]+))'
    assert ie._ITEM_RE == r'nrk:([^&]+)'
    assert ie.ie_key() == 'NRKPlaylistBase'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILED == 'FAILED'



# Generated at 2022-06-26 12:36:38.243320
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    def check_num_series(nrktv_series_ie_obj, expected_num_series=0):
        'Check number of series in object'
        actual_num_series = 0
        for _url in nrktv_series_ie_obj._PAGE_TEMPLATES:
            nrktv_series_ie_obj._NRK_PAGES_PATTERN.match(_url)
            if int(nrktv_series_ie_obj._NRK_PAGES_PATTERN.match(_url).group('page')) == 1:
                actual_num_series = actual_num_series + 1
        return (actual_num_series == expected_num_series)
    test_obj = NRKTVSeriesIE()

# Generated at 2022-06-26 12:36:40.941922
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    v = NRKTVSeriesIE()
    url = 'https://tv.nrk.no/serie/c'
    result = v.suitable(url)
    assert result == True


# Generated at 2022-06-26 12:36:41.756115
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE()



# Generated at 2022-06-26 12:36:47.642189
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    info = NRKRadioPodkastIE._extract_info('l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8', 'https://radio.nrk.no/podkast/hele_historien/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert info['id'] == 'MUHH48000314AA'


# Generated at 2022-06-26 12:36:49.511685
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    info_extractor = NRKTVSerieBaseIE()

    # test __init__
    assert info_extractor


# Generated at 2022-06-26 12:36:50.042543
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    pass


# Generated at 2022-06-26 12:36:54.485703
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    mobj = re.match(NRKTVSeasonIE._VALID_URL, url)
    domain = mobj.group('domain')
    serie_kind = mobj.group('serie_kind')
    serie = mobj.group('serie')
    season_id = mobj.group('id') or mobj.group('id_2')
    display_id = '%s/%s' % (serie, season_id)
    catalog_name = NRKTVSeasonIE._catalog_name(serie_kind)

# Generated at 2022-06-26 12:36:55.730228
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    ie = NRKSkoleIE()
    return ie.suitable('https://www.nrk.no/skole/?page=search&q=&mediaId=14099')


# Generated at 2022-06-26 12:37:00.281742
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    from .nrktv import NRKTVSeasonIE
    assert NRKTVSeasonIE._VALID_URL == r'''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''

# Generated at 2022-06-26 12:37:02.687142
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    try:
        NRKTVSeasonIE()
    except Exception:
        pass
    try:
        NRKTVSeasonIE.suitable(None)
    except Exception:
        pass
    try:
        NRKTVSeasonIE._real_extract(None)
    except Exception:
        pass
