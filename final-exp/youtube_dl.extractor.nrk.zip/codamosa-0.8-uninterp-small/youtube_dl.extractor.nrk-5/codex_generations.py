

# Generated at 2022-06-26 12:32:24.025443
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    test_obj = NRKRadioPodkastIE()
    assert test_obj is not None, 'Test object is not NRKRadioPodkastIE'
    print(test_obj)


# Generated at 2022-06-26 12:32:25.213046
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:32:28.259672
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e = NRKBaseIE()


# Generated at 2022-06-26 12:32:38.240952
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert_equal(NRKRadioPodkastIE._TESTS[0]['url'], 'https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert_equal(NRKRadioPodkastIE._TESTS[0]['md5'], '8d40dab61cea8ab0114e090b029a0565')
    assert_equal(NRKRadioPodkastIE._TESTS[0]['info_dict']['id'], 'MUHH48000314AA')
    assert_equal(NRKRadioPodkastIE._TESTS[0]['info_dict']['ext'], 'mp4')
    assert_equal

# Generated at 2022-06-26 12:32:39.423367
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:43.992277
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:32:45.899265
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:32:46.738779
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrk_tv_i_e = NRKTVIE()


# Generated at 2022-06-26 12:32:48.429945
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()


# Generated at 2022-06-26 12:32:49.914439
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert isinstance(NRKTVEpisodesIE(), NRKTVEpisodesIE)


# Generated at 2022-06-26 12:34:00.292419
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-26 12:34:07.352779
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    try:
        import json
        import os
        import pathlib
        NRKTVSeriesIE
    except NameError as e:
        if 'json' == e.args[0]:
            print('SKIP: as this test requires json module')
            return
        else:
            raise
    json_file = os.path.join(pathlib.Path(__file__).parent.absolute(),'tv_nrk_no_series_jerks-json.json')
    with open(json_file) as json_file_object :
        n_r_k_tv_series_i_e_0 = NRKTVSeriesIE()
        n_r_k_tv_series_i_e_0.url = 'https://tv.nrk.no/serie/jerks'
        n_r_k_tv_series_i

# Generated at 2022-06-26 12:34:09.795143
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE.ie_key()
    # Still not implemented
    #assertListEqual(NRKTVIE._TESTS[1]['info_dict']['subtitles'].keys(), ['nb-nor', 'nb-ttv'])


# Generated at 2022-06-26 12:34:10.929156
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:34:13.059404
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e_obj = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:34:17.257336
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()

if __name__ == '__main__':
    test_case_0()
    test_NRKRadioPodkastIE()

# Generated at 2022-06-26 12:34:19.621900
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    obj = NRKBaseIE()


# Generated at 2022-06-26 12:34:21.737472
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url, ie = 'https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031', 'NRKTVEpisodesIE'
    test = NRKTVEpisodesIE()
    test.suitable(url)
    test.url_result(url, ie, video_id='69031')


# Generated at 2022-06-26 12:34:24.085411
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:34:25.108337
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:35:39.579204
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Test exception case
    try:
        NRKTVSeriesIE.suitable(None)
    except Exception as e:
        assert e == Exception('url is None')


# Generated at 2022-06-26 12:35:40.557512
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:35:41.786683
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e_0 = NRKIE()


# Generated at 2022-06-26 12:35:43.174855
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
	assert(NRKTVIE)


# Generated at 2022-06-26 12:35:44.652850
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()


# Generated at 2022-06-26 12:35:45.928802
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    a = NRKBaseIE()


# Generated at 2022-06-26 12:35:47.761569
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:35:48.694994
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()



# Generated at 2022-06-26 12:35:50.356873
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:35:51.146415
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nRKTVEpisodesIE = NRKTVEpisodesIE()



# Generated at 2022-06-26 12:37:13.616521
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    podkast_ie = NRKRadioPodkastIE()
    assert podkast_ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')



# Generated at 2022-06-26 12:37:15.028290
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE(NRKTVSeriesIE.suitable.__func__, NRKTVSeriesIE.__name__)



# Generated at 2022-06-26 12:37:16.398545
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/backstage/sesong/1'
    with pytest.raises(AttributeError):
        NRKTVSeasonIE()._match_id(url)



# Generated at 2022-06-26 12:37:17.144668
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE(NRKTVEpisodesIE._VALID_URL)

# Generated at 2022-06-26 12:37:24.409619
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    try:
        from urllib.parse import urlparse
    except ImportError:
        from urlparse import urlparse
    
    in_file = open('D:/Projects/extractors/__pycache__/nrktv.cpython-35.pyc','rb')
    out_file = open('D:/Projects/extractors/nrktv.pyc','wb')
    out_file.write(in_file.read())
    in_file.close()
    out_file.close()
    
    import extractors.nrktv
    reload(extractors.nrktv)
    extractors.nrktv.NRKPlaylistIE.suitable('')

# Generated at 2022-06-26 12:37:31.532888
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Test with default arguments
    ie = NRKTVEpisodeIE()
    assert ie._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Generated at 2022-06-26 12:37:34.324409
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrk_playlist_base_ie = NRKPlaylistBaseIE()
    assert nrk_playlist_base_ie



# Generated at 2022-06-26 12:37:35.070224
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    NRKTVSeasonIE.suitable(None)


# Generated at 2022-06-26 12:37:37.530559
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    test = NRKPlaylistIE()
    assert test._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'



# Generated at 2022-06-26 12:37:38.428446
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    ie = NRKTVSeasonIE(None)
    assert isinstance(ie, NRKTVSeasonIE)


# Generated at 2022-06-26 12:40:20.475481
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    NRKTVEpisodeIE("NRKTVEpisodeIE", "nrk.no")


# Generated at 2022-06-26 12:40:21.586260
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    NRKTVIE()

# Generated at 2022-06-26 12:40:26.900816
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    # Test that NRKTVDirekteIE is constructed with New style class
    assert isinstance(NRKTVDirekteIE(NRKTVDirekteIE.ie_key()), type)


# Generated at 2022-06-26 12:40:28.644485
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from youtube_dl.extractor import gen_extractors
    ext_list = gen_extractors()
    idx = ext_list.index(NRKTVIE)
    assert ext_list[idx+1] is NRKTVDirekteIE



# Generated at 2022-06-26 12:40:39.115975
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449'
    one_playlist_ie = NRKPlaylistIE(None)
    one_playlist_ie.suitable(url)
    one_playlist_ie.extract(url)
    assert one_playlist_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert one_playlist_ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert one_playlist_ie._T

# Generated at 2022-06-26 12:40:43.676454
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/20-spoersmaal-tv/MUHH48000314/23-05-2014'
    nrktvie = NRKTVIE(url)
    assert nrktvie._match_id(url) == 'MUHH48000314'
    assert nrktvie.match_url(url) == True

# Generated at 2022-06-26 12:40:56.139997
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():

    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    regex = r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'
    nrktv_ie = NRKTVEpisodeIE("testNRKTVEpisodeIE", url, regex)

    if re.match(nrktv_ie._VALID_URL, url):
        url_match = re.match(nrktv_ie._VALID_URL, url)
        display_id = url_match.group("id")
        season_number = url_match.group("season_number")
        episode_number = url_match.group

# Generated at 2022-06-26 12:40:57.311253
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    pass



# Generated at 2022-06-26 12:41:04.812538
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from .nrk_radio import test_NRKRadioSeriesIE
    url = 'https://tv.nrk.no/serie/groenn-glede'
    t = test_NRKRadioSeriesIE(NRKTVSeriesIE, "NRKTVSeriesIE", url)
    t.test()

# Unit tests for NRKTVSerieBaseIE

# Generated at 2022-06-26 12:41:07.697992
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE('nrk:MDDP12000117') is not None
