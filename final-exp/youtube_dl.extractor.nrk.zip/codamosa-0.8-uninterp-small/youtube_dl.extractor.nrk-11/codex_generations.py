

# Generated at 2022-06-26 12:32:21.794051
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    test_case_0()


# Generated at 2022-06-26 12:32:27.362213
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_tv_episode_i_e = NRKTVEpisodeIE()
    assert n_r_k_tv_episode_i_e._VALID_URL == 'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))', '_VALID_URL not as expected'
    assert n_r_k_tv_episode_i_e._TESTS[0]['url'] == 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2', '_TESTS[0] not as expected'

# Generated at 2022-06-26 12:32:28.952776
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    assert NRKTVSeriesIE() != None


# Generated at 2022-06-26 12:32:31.714414
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    test_url='https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    n_r_k_t_v_episode_i_e = NRKTVEpisodeIE()
    my_info = n_r_k_t_v_episode_i_e._real_extract(test_url)
    print(my_info)



# Generated at 2022-06-26 12:32:32.167200
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    int(0)

# Generated at 2022-06-26 12:32:33.302603
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_t_v_i_e_0 = NRKTVIE()


# Generated at 2022-06-26 12:32:34.418407
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert(NRKTVIE()._EPISODE_RE == 'MSPO48036114')


# Generated at 2022-06-26 12:32:36.824344
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:38.001283
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:32:44.307182
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()

if __name__ == '__main__':
    print(test_case_0())
    print(test_NRKTVSerieBaseIE())

# Generated at 2022-06-26 12:33:53.022182
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e_0 = NRKTVDirekteIE()


# Generated at 2022-06-26 12:33:54.686332
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()
    assert n_r_k_playlist_i_e_0._VALID_URL is not None


# Generated at 2022-06-26 12:33:55.750841
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:33:57.085227
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e = NRKIE()



# Generated at 2022-06-26 12:33:58.294126
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:33:59.458947
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_tv_episode_ie_0 = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:34:00.015941
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    pass


# Generated at 2022-06-26 12:34:01.209035
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e_1 = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:34:04.879245
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:34:05.827393
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    test_case_0()


# Generated at 2022-06-26 12:35:21.677934
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # Check that the class is correctly initialized
    ie = NRKIE()
    ie2 = NRKIE()
    # Check that the ID extractors are correctly initialized
    assert ie.IE_NAME == ie2.IE_NAME
    assert len(ie._TESTS) == len(ie2._TESTS)
    for test_dict in ie._TESTS:
        assert test_dict in ie2._TESTS
    # Check that the other extractors are correctly initialized
    assert ie._VALID_URL == ie2._VALID_URL
    # The CDN _CDN_REPL_REGEX regular expression should be identical and the same with the one
    # in the base class
    assert ie._CDN_REPL_REGEX == ie2._CDN_REPL_REGEX
    assert NRKBaseIE._CDN_RE

# Generated at 2022-06-26 12:35:25.286001
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    tested_object = ie.suitable('https://radio.nrk.no/serie/sladder_konsert/sesong/1/l_774d1a2c-7aa7-4965-8d1a-2c7aa7d9652c')
    expected_result = False
    assert tested_object == expected_result


# Generated at 2022-06-26 12:35:30.831897
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test the constructor of the class NRKTVEpisodesIE
    query_string = 'data-episode="https://tv.nrk.no/serie/nytt-paa-nytt/sesong/201210/episode/5" data-program-id="69031">'
    query_string_odd = 'data-episode="https://tv.nrk.no/serie/nytt-paa-nytt/sesong/201210/episode/5" data-program-id="69031"/>'
    # Test with even number of quotation marks
    assert re.findall(NRKTVEpisodesIE._ITEM_RE, query_string) == ['https://tv.nrk.no/serie/nytt-paa-nytt/sesong/201210/episode/5']
    # Test with odd number of quotation marks
   

# Generated at 2022-06-26 12:35:37.911777
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # tests for NRKTVSeriesIE
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/blank') == True
    assert NRKTVSeriesIE.suitable('https://radio.nrk.no/podkast/hele_historien') == True
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede') == True
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/spangas/sesong/1') == False
    assert NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/spangas/sesong/1/episode/1') == False

# Generated at 2022-06-26 12:35:38.960510
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE().IE_NAME == 'nrkbase'
#

# Generated at 2022-06-26 12:35:48.268849
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE('example.com')

# Generated at 2022-06-26 12:35:49.273933
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk_instance = NRKIE();

# Generated at 2022-06-26 12:35:51.625776
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk = NRKBaseIE()
    assert nrk._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-26 12:35:53.719892
# Unit test for constructor of class NRKIE
def test_NRKIE():
    nrk_ie = NRKIE()
    assert "NRK" in nrk_ie.IE_NAME
    assert nrk_ie._GEO_COUNTRIES == ['NO']


# Generated at 2022-06-26 12:36:01.320856
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    display_id = 'hellums-kro/sesong/1/episode/2'
    season_number = '1'
    episode_number = '2'

    webpage = NRKTVEpisodeIE._download_webpage(url, display_id)
    info = NRKTVEpisodeIE._search_json_ld(webpage, display_id, default={})
    nrk_id = info.get('@id')

    assert re.match(NRKTVIE._EPISODE_RE, nrk_id)
    assert type(season_number) == str
    assert type(episode_number) == str
    assert isinstance(display_id, compat_str)
    assert type

# Generated at 2022-06-26 12:38:56.599790
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    ie = NRKRadioPodkastIE('NRKRadioPodkastIE')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert ie.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/l_96f4f1b0-de54-4e6a-b4f1-b0de54fe6af8')
    assert not ie.suitable('https://tv.nrk.no/serie/dagsrevyen')


# Generated at 2022-06-26 12:38:58.746819
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    ie = NRKTVSeriesIE()
    assert ie == NRKTVSeriesIE



# Generated at 2022-06-26 12:39:09.470398
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    tests = [
        'https://tv.nrk.no/serie/backstage/sesong/1',
        'https://tv.nrk.no/serie/lindmo/2016',
        'https://radio.nrk.no/serie/dickie-dick-dickens/sesong/1',
        'https://radio.nrk.no/serie/dagsnytt/sesong/201509',
        'https://tv.nrk.no/serie/spangas/sesong/1',
        'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant',
        'https://radio.nrk.no/podkast/loerdagsraadet/sesong/202101']

# Generated at 2022-06-26 12:39:12.691223
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    instance = NRKPlaylistIE()
    assert(instance is not None)


# Generated at 2022-06-26 12:39:18.067973
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    ie = NRKTVIE()
    url = "https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015"
    if ie._VALID_URL.match(url):
        ie._real_extract(url)


# Generated at 2022-06-26 12:39:22.851762
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    assert ie._VALID_URL is NRKIE._VALID_URL
    assert ie._TESTS is NRKIE._TESTS


# Generated at 2022-06-26 12:39:25.787924
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE('NRKTVSerieBase', 'NRKTVSerieBase')

# Generated at 2022-06-26 12:39:26.868567
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('nrk1')
    assert ie._get_video_id() == 'nrk1'



# Generated at 2022-06-26 12:39:29.651301
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    test_class = NRKSkoleIE()
    assert test_class._VALID_URL == r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-26 12:39:38.762014
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE()
    assert ie.suitable('http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763')
    assert ie.suitable('http://www.nrk.no/kultur/bok/rivertonprisen-til-karin-fossum-1.12266449')
