

# Generated at 2022-06-26 12:32:17.457683
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    episode_info_extractor = NRKTVEpisodeIE()
    print(episode_info_extractor)

test_case_0()


# Generated at 2022-06-26 12:32:19.063245
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:32:20.608506
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:32:27.500173
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url = 'https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2'
    n_r_k_t_v_season_i_e = NRKTVSeasonIE()
    n_r_k_t_v_season_i_e.suitable(url)


# Generated at 2022-06-26 12:32:31.691347
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    fields = [
        'IE_NAME',
        '_VALID_URL',
        '_TESTS'
    ]
    for field in fields:
        assert field in dir(NRKTVIE), 'Field not found: %s ' % field



# Generated at 2022-06-26 12:32:33.476314
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e_0 = NRKTVSeriesIE()


# Generated at 2022-06-26 12:32:34.855996
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_tv_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:32:36.882063
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_p_l_i_e_0 = NRKPlaylistIE()


# Generated at 2022-06-26 12:32:38.893562
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:32:40.042486
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert test_case_0().IE_DESC == 'NRK Skole'


# Generated at 2022-06-26 12:33:43.681165
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_tv_series_i_e_0 = NRKTVSeriesIE()


# Generated at 2022-06-26 12:33:44.885919
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_tv_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:33:46.019280
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e = NRKIE()


# Generated at 2022-06-26 12:33:46.729322
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:33:48.512839
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    nRKTVSeasonIE = NRKTVSeasonIE()


# Generated at 2022-06-26 12:33:49.863076
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e = NRKBaseIE()


# Generated at 2022-06-26 12:33:50.858010
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_t_v_i_e = NRKTVIE()


# Generated at 2022-06-26 12:33:51.681359
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE()


# Generated at 2022-06-26 12:33:53.096605
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():

    # Positive testing
    # Constructor should init without any errors
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()

    # Negative testing
    # TODO

# Generated at 2022-06-26 12:33:54.149327
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:34:41.398150
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e = NRKTVSeriesIE()


# Generated at 2022-06-26 12:34:45.944923
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert_equals(NRKSkoleIE.IE_DESC, 'NRK Skole')
    assert_equals(NRKSkoleIE._VALID_URL, r'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)')

# Generated at 2022-06-26 12:34:51.832031
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    l_c_r_skole_a_1 = 'https://skole.nrk.no/litteratur-cappelen-7'
    n_r_k_skole_i_e_1 = NRKSkoleIE()
    result_1 = n_r_k_skole_i_e_1.suitable(l_c_r_skole_a_1)
    assert result_1 == True
    n_r_k_skole_i_e_2 = NRKSkoleIE()
    result_2 = n_r_k_skole_i_e_2.suitable(l_c_r_skole_a_1)
    assert result_2 == True
    n_r_k_skole_i_e_3 = NRKSkoleIE()
    result_

# Generated at 2022-06-26 12:34:55.472033
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrk_tv_i_e = NRKTVSeriesIE()
    nrk_tv_i_e.suitable('https://radio.nrk.no/podkast/ulrikkes_univers/nrkno-poddkast-26588-134079-05042018030000')
    # assert False # TODO: Invoke NRKTVSeriesIE._real_extract()

# Generated at 2022-06-26 12:34:57.637234
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    nrkpbIE = NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:34:59.527389
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    # Check that the object is of the right type
    assert isinstance(n_r_k_base_i_e_0, NRKBaseIE)



# Generated at 2022-06-26 12:35:00.539372
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_s_i_e = NRKTVSeriesIE()


# Generated at 2022-06-26 12:35:03.387389
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    url = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    e0 = NRKTVEpisodeIE()
    e0._real_extract(url)

# Generated at 2022-06-26 12:35:04.304945
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    nrktv_episodes_ie_0 = NRKTVEpisodesIE();


# Generated at 2022-06-26 12:35:06.210954
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # Create a NRKTVSeriesIE object
    nrktvseriesie = NRKTVSeriesIE()

# Generated at 2022-06-26 12:37:31.532551
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e_0 = NRKBaseIE()


# Generated at 2022-06-26 12:37:33.549510
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    NRKPlaylistBaseIE();
    return 0;


# Generated at 2022-06-26 12:37:37.586322
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    # assertEqual raises AssertionError if these two parameters are not equal
    assertEqual(NRKTVSeriesIE.suitable('https://tv.nrk.no/serie/groenn-glede'), True)
    assertEqual(NRKTVSeriesIE.suitable('https://www.youtube.com/watch?v=Oa-7Vu8wLHk'), False)



# Generated at 2022-06-26 12:37:39.631572
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Creating a test case for the constructor of class NRKPlaylistBaseIE
    playlist_base_ie = NRKPlaylistBaseIE()

NRKTVPlaylistIE.test() # This is not a real unit test, just a verification that the test cases are fine

# Generated at 2022-06-26 12:37:45.641836
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()
    assert n_r_k_playlist_i_e_0._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
    assert n_r_k_playlist_i_e_0._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'


# Generated at 2022-06-26 12:37:47.897488
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Tests for constructor of NRKTVEpisodesIE with/without SimpleExtractor
    nrk_tv_episodes_i_e = NRKTVEpisodesIE()
    if not isinstance(nrk_tv_episodes_i_e, NRKPlaylistBaseIE):
        raise TypeError('NRKTVEpisodesIE is not an instance of NRKPlaylistBaseIE')


# Generated at 2022-06-26 12:37:50.208655
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    nrktv_episode_i_e_0 = NRKTVEpisodeIE();


# Generated at 2022-06-26 12:37:51.553338
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE.__name__ == "NRKBaseIE"


# Generated at 2022-06-26 12:37:55.630335
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    # Test case 0
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()



# Generated at 2022-06-26 12:37:57.617847
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e = NRKIE()



# Generated at 2022-06-26 12:40:26.055701
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()



# Generated at 2022-06-26 12:40:27.355153
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    assert NRKTVSeasonIE.suitable(NRKTVSeasonIE._TESTS[0]['url'])


# Generated at 2022-06-26 12:40:33.461889
# Unit test for constructor of class NRKIE
def test_NRKIE():
    t = NRKIE('NRK', 'nrk.no')
    assert t.IE_NAME == 'NRK'
    assert t.IE_DESC == 'NRK'
    assert t.VALID_URL == r'https?://(?:www\.)?nrk\.no/video/(?:PS\*|[^_]+_)(?P<id>[^?\#&]+)'



# Generated at 2022-06-26 12:40:42.859666
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    assert NRKSkoleIE.nrk_skole_id_re.search("https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355") != None
    assert NRKSkoleIE()._match_id("https://www.nrk.no/skole/?page=objectives&subject=naturfag&objective=K15114&mediaId=19355") == "19355"


# Generated at 2022-06-26 12:40:56.084965
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    instance = NRKTVSeasonIE()
    assert instance._VALID_URL == '''(?x)
                    https?://
                        (?P<domain>tv|radio)\.nrk\.no/
                        (?P<serie_kind>serie|pod[ck]ast)/
                        (?P<serie>[^/]+)/
                        (?:
                            (?:sesong/)?(?P<id>\d+)|
                            sesong/(?P<id_2>[^/?#&]+)
                        )
                    '''
    assert instance._TESTS[0]['url'] == 'https://tv.nrk.no/serie/backstage/sesong/1'

# Generated at 2022-06-26 12:40:59.827930
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert NRKTVEpisodesIE()._ITEM_RE == r'data-episode=["\']78168735'



# Generated at 2022-06-26 12:41:06.741376
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.nrk import NRKTVIE, NRKTVDirekteIE
    import os
    import io
    # Create a dummy YoutubeDL object for getting content from NRKTVIE
    youtube_dl_object = YoutubeDL({})
    # Get the expected JSON-LD information for URL
    url = 'https://tv.nrk.no/direkte/nrk1'
    info = youtube_dl_object.extract_info(
        url, download=False, process=False)
    info = info['entries'][0]
    # Create an instance of NRKTVDirekteIE using extracted info
    direkte_tv_ie = NRKTVDirekteIE(youtube_dl_object, info['url'], info)

# Generated at 2022-06-26 12:41:10.311713
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    if NRKRadioPodkastIE.suitable("https://www.google.com"):
        assert False

