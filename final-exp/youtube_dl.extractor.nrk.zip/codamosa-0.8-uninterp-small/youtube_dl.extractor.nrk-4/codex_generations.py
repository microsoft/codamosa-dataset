

# Generated at 2022-06-26 12:32:23.519869
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_tv_episodes_i_e = NRKTVEpisodesIE()

# Generated at 2022-06-26 12:32:25.174539
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE.__name__ == 'NRKIE'



# Generated at 2022-06-26 12:32:26.370405
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:32:27.114717
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nRKTVSerieBaseIE = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:32:28.739963
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    unit_test_NRKTVIE = NRKTVIE();

# Generated at 2022-06-26 12:32:30.481062
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert not NRKRadioPodkastIE()


# Generated at 2022-06-26 12:32:31.771351
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:32:32.926890
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    nrkt_v_serie_base_i_e_0 = NRKTVSerieBaseIE()



# Generated at 2022-06-26 12:32:33.661520
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-26 12:32:34.766783
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_tv_serie_base_i_e = NRKTVSerieBaseIE()



# Generated at 2022-06-26 12:33:53.632300
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    from datetime import datetime
    from .nrktv import NRKTVDirekteIE
    if datetime.utcnow().hour < 7:
        # When it is past 00:00 UTC but still before 7:00 UTC,
        # NRKTVDirekteIE raises an IndexError exception from re.search
        return
    assert(NRKTVDirekteIE._VALID_URL == 'https?://(?:tv|radio)\\.nrk\\.no/direkte/(?P<id>[^/?#&]+)')
    assert(len(NRKTVDirekteIE._TESTS) == 2)

# Generated at 2022-06-26 12:33:54.623430
# Unit test for constructor of class NRKIE
def test_NRKIE():
    from .test_zl_constructor_error import _
    assert _('NRKIE')

# Generated at 2022-06-26 12:33:57.217811
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    test_inst = NRKTVSerieBaseIE()
    assert test_inst._ASSETS_KEYS == ('episodes', 'instalments')
    assert test_inst._catalog_name('podcast') == 'podcast'
    assert test_inst._catalog_name('podkast') == 'podcast'
    assert test_inst._catalog_name('series') == 'series'



# Generated at 2022-06-26 12:33:58.095818
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    test_obj = NRKPlaylistBaseIE()

# Generated at 2022-06-26 12:34:00.168823
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    ie = NRKTVEpisodeIE(NRKTVEpisodeIE._downloader, NRKTVEpisodeIE._VALID_URL)
    print(ie)
    assert ie


# Generated at 2022-06-26 12:34:07.326716
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    from youtube_dl.extractor import gen_extractors
    from youtube_dl.utils import ExtractorError
    from unittest.mock import patch
    NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031')
    NRKTVEpisodesIE.suitable('https://tv.nrk.no/program/episodes/SKAM/s02/69031')
    assert not NRKTVEpisodesIE.suitable('https://tv.nrk.no/serie/trekant')
    assert isinstance(NRKTVEpisodesIE.ie_key(), type(NRKTVEpisodesIE))
    assert isinstance(list(gen_extractors([]))[0], type(NRKTVEpisodesIE))
    NRKTVE

# Generated at 2022-06-26 12:34:08.455864
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert isinstance(NRKTVEpisodesIE, type)


# Generated at 2022-06-26 12:34:10.848054
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE('NRKTVDirekteIE', 'NRK Radio Direkte')
    assert ie.name() == 'NRKTVDirekteIE'
    assert ie.description() == 'NRK Radio Direkte'


# Generated at 2022-06-26 12:34:12.470507
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    ie = NRKTVDirekteIE()
    assert ie.ie_key() == 'NRKTVDirekte'


# Generated at 2022-06-26 12:34:23.468799
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    test_url = ['https://tv.nrk.no/program/MDDP12000117',
    'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2',
    'https://tv.nrk.no/serie/anno/KMTE50001317/sesong-3/episode-13',
    'https://radio.nrk.no/serie/dagsnytt/NPUB21019315/12-07-2015#']

    for url in test_url:
        assert NRKTVIE._valid_url(url, NRKTVIE._VALID_URL) == True

# Generated at 2022-06-26 12:36:46.482974
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    from youtube_dl.extractor.nrk import NRKTVSeriesIE
    url1 = "https://tv.nrksuper.no/serie/labyrint"
    ie1 = NRKTVSeriesIE()
    assert ie1.suitable(url1)



# Generated at 2022-06-26 12:36:48.229004
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    nrktv_direkte_ie = NRKTVDirekteIE()
    url = 'https://tv.nrk.no/direkte/nrk1'
    assert nrktv_direkte_ie.suitable(url)



# Generated at 2022-06-26 12:36:48.868553
# Unit test for constructor of class NRKIE
def test_NRKIE():
    NRKIE()

# Generated at 2022-06-26 12:36:54.298530
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    ie = NRKBaseIE()
    assert ie._GEO_COUNTRIES == ['NO']
    assert ie._CDN_REPL_REGEX == r'(?x)://\s+' \
        '(?:nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0' \
        '|nrk-od-no\.telenorcdn\.net|minicdn-od\.nrk\.no/od/nrkhd-osl-rr.netwerk.no/no)\s+/'


# Generated at 2022-06-26 12:36:58.495513
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    with pytest.raises(RegexNotFoundError):
        NRKTVIE('https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533')._real_extract('https://www.nrk.no/video/dompap-og-andre-fugler-i-piip-show_150533')

# Generated at 2022-06-26 12:36:59.677766
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    assert NRKTVDirekteIE.suitable('https://tv.nrk.no/direkte/nrk1')



# Generated at 2022-06-26 12:37:00.876848
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    # Test for constructor of class NRKTVEpisodesIE.
    assert NRKTVEpisodesIE

# Generated at 2022-06-26 12:37:06.051729
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    base_IE = NRKTVSerieBaseIE()
    entry_list = [{'prfId': 'MDDP12000117'}]
    assert 'nrk:MDDP12000117' in tuple(base_IE._extract_entries(entry_list))
    entry_list = [{'episodeId': 'MDDP12000117'}]
    assert 'nrk:MDDP12000117' in tuple(base_IE._extract_entries(entry_list))
    entry_list = None
    assert base_IE._extract_entries(entry_list) == []


# Generated at 2022-06-26 12:37:07.890273
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    testInstance = NRKTVSeriesIE()
    assert testInstance._VALID_URL is not None
    assert testInstance._TESTS is not None


# Generated at 2022-06-26 12:37:10.895764
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE._TESTS[0]['info_dict']['id'] == 'MUHH36005220'
    assert NRKTVEpisodeIE._TESTS[1]['info_dict']['id'] == 'MSUI14000816'
