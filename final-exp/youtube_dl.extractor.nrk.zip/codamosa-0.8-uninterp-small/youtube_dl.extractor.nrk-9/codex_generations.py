

# Generated at 2022-06-26 12:32:21.106116
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_s_b_ie = NRKTVSerieBaseIE()
    assert_equals(n_r_k_t_v_s_b_ie._ASSETS_KEYS, ('episodes', 'instalments',))
    assert_equals(n_r_k_t_v_s_b_ie._catalog_name('podcast'), 'podcast')
    assert_equals(n_r_k_t_v_s_b_ie._catalog_name('podkast'), 'podcast')
    assert_equals(n_r_k_t_v_s_b_ie._catalog_name('series'), 'series')


# Generated at 2022-06-26 12:32:22.269197
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:32:23.479028
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    n_r_k_t_v_i_e_0 = NRKTVIE()


# Generated at 2022-06-26 12:32:29.727797
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    url = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    playlist_ie = NRKPlaylistIE('NRKPlaylistIE', 'nrkplaylist')
    assert playlist_ie.suitable(url)
    assert playlist_ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert url == playlist_ie._real_extract(url)


if __name__ == '__main__':
    test_case_0()
    test_NRKPlaylistIE()

# Generated at 2022-06-26 12:32:34.359390
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    assert isinstance(NRKTVIE()._VALID_URL, str)
    assert isinstance(NRKTVIE()._EPISODE_RE, str)
    assert isinstance(NRKTVIE().IE_NAME, str)
    assert isinstance(NRKTVIE().IE_DESC, str)
    assert isinstance(NRKTVIE()._TESTS, list)

# Generated at 2022-06-26 12:32:36.732128
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    nrk_play_list = NRKPlaylistIE(downloader=None)



# Generated at 2022-06-26 12:32:38.538511
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrktvseriesie = NRKTVSeriesIE()



# Generated at 2022-06-26 12:32:39.875356
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    nrk_tv_series_ie = NRKTVSeriesIE(NRKTVEpisodesIE())

# Generated at 2022-06-26 12:32:44.396781
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert_raises(TypeError, NRKTVSerieBaseIE, True)


# Generated at 2022-06-26 12:32:46.467118
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e_0 = NRKBaseIE()


# Generated at 2022-06-26 12:33:53.021565
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:33:58.184744
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    # Test for class constructor
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()

    # Test for '_VALID_URL' attribute in class NRKRadioPodkastIE
    expected_str = 'https?://radio\.nrk\.no/pod[ck]ast/(?:[^/]+/)+(?P<id>l_[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12})'
    actual_str = n_r_k_radio_podkast_i_e._VALID_URL
    assert expected_str == actual_str, 'Expected and actual values do not match'

    # Test for 'IE_DESC' attribute in class NR

# Generated at 2022-06-26 12:33:58.859425
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    NRKRadioPodkastIE()

# Generated at 2022-06-26 12:34:00.698479
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e = NRKTVEpisodesIE()
    assert n_r_k_t_v_episodes_i_e.suitable(None) == False


# Generated at 2022-06-26 12:34:05.416494
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()
    test_case_0()


# Generated at 2022-06-26 12:34:06.906080
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:34:10.327204
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    r1 = 'http://nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    n_r_k_playlist_i_e_0 = NRKPlaylistIE()
    n_r_k_playlist_i_e_0.url_result(r1)


# Generated at 2022-06-26 12:34:16.004238
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    url = "https://tv.nrk.no/program/episodes/nytt-paa-nytt/69031"
    n_r_k_t_v_episodes_i_e_test = NRKTVEpisodesIE()
    assert n_r_k_t_v_episodes_i_e_test._VALID_URL == \
        'https?://tv\.nrk\.no/program/episodes/[^/]+/(?P<id>\\d+)'
    assert n_r_k_t_v_episodes_i_e_test._TESTS[0]['url'] == url

# Generated at 2022-06-26 12:34:17.265060
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()
    test_case_0()



# Generated at 2022-06-26 12:34:21.463065
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e = NRKTVSeriesIE()

## Unit test for function _set_http_auth_request_params

# Generated at 2022-06-26 12:36:33.935732
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    assert NRKPlaylistIE()
    assert NRKPlaylistIE()._real_extract


# Generated at 2022-06-26 12:36:37.044422
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episodes_i_e_1 = NRKTVEpisodeIE('NRKTVEpisodeIE', 'NRKTVEpisodeIE.py', 'NRKTVEpisodeIE test')
    return n_r_k_t_v_episodes_i_e_1


# Generated at 2022-06-26 12:36:39.697262
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()
    n_r_k_playlist_base_i_e_0 = NRKPlaylistBaseIE()



# Generated at 2022-06-26 12:36:40.909052
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    nrk_base_ie_0 = NRKBaseIE()


# Generated at 2022-06-26 12:36:42.559347
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:36:47.376894
# Unit test for constructor of class NRKIE
def test_NRKIE():
    test_url= 'http://www.nrk.no/video/PS*150533'
    n_r_k_i_e_0 = NRKIE()
    n_r_k_i_e_0._match_id(test_url)
    n_r_k_i_e_0._real_extract(test_url)



# Generated at 2022-06-26 12:36:48.965077
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    assert issubclass(test_case_0.__class__, NRKTVSerieBaseIE)


# Generated at 2022-06-26 12:36:50.321862
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:36:53.508164
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e = NRKRadioPodkastIE()
    assert n_r_k_radio_podkast_i_e != None

if __name__ == '__main__':
    test_case_0()
    test_NRKRadioPodkastIE()

# Generated at 2022-06-26 12:36:54.681936
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    n_r_k_playlist_base_i_e_ = NRKPlaylistBaseIE()
