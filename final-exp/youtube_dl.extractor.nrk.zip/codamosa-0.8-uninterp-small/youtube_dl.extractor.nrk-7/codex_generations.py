

# Generated at 2022-06-26 12:32:26.232102
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    # Discarding any error that may result from the following code
    try:
        NRKTVSerieBaseIE()
    except NameError:
        pass



# Generated at 2022-06-26 12:32:36.765597
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE().IE_NAME == "nrkbase"
    assert NRKBaseIE()._VALID_URL == r'http://(?:tv|radio)\.nrk(?:super|p3|no)?(?:\.no)?/(?:serie/|[^/]+/)[\da-z-]+'
    assert NRKBaseIE()._GEO_COUNTRIES == ['NO']

# Generated at 2022-06-26 12:32:38.451067
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert callable(NRKBaseIE.__init__)


# Generated at 2022-06-26 12:32:42.598114
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:32:49.880754
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    parallel_run_test(NRKTVSerieBaseIE._ASSETS_KEYS)
    parallel_run_test(NRKTVSerieBaseIE._catalog_name, 'podcast')
    assert test_func(NRKTVSerieBaseIE._extract_entries)
    parallel_run_test(NRKTVSerieBaseIE._extract_assets_key)
    parallel_run_test(NRKTVSerieBaseIE._entries)


# Generated at 2022-06-26 12:32:51.459463
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:32:52.198899
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    obj = NRKTVSeriesIE()


# Generated at 2022-06-26 12:32:53.186327
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    NRKTVEpisodesIE_instance = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:32:55.629037
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_t_v_season_i_e_0 = NRKIE()
    assert n_r_k_t_v_season_i_e_0 is not None


# Generated at 2022-06-26 12:32:57.248495
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    n_r_k_radio_podkast_i_e_0 = NRKRadioPodkastIE()


# Generated at 2022-06-26 12:34:11.511916
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    tester = NRKTVSeriesIE()
    # If is_radio is equal to False, then var site will be equal to 'tv'
    # If it will be True, then var site will be equal to 'radio'
    # In this case, is_radio is False
    site = 'radio' if tester.is_radio else 'tv'
    tester_titles = tester.titles or {}
    # In this case, var domain will be equal to 'tv'
    tester_domain = 'radio' if tester.is_radio else 'tv'
    # In this case, var count_entries will be equal to 9
    count_entries = 9



# Generated at 2022-06-26 12:34:24.212918
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()
    n_r_k_t_v_serie

# Generated at 2022-06-26 12:34:29.588183
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    # Check with correct arguments
    assert isinstance(nrk_tv_ie.NRKTVIE(
        "http://tv.nrk.no/program/frontkvinnen"), NRKTVIE)
    # Check with incorrect arguments
    assert isinstance(nrk_tv_ie.NRKTVIE(
        "http://tv.nrk.no/program/"), NRKTVIE)



# Generated at 2022-06-26 12:34:32.125984
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    n_r_k_t_v_episode_i_e = NRKTVEpisodeIE()


# Generated at 2022-06-26 12:34:34.473504
# Unit test for constructor of class NRKIE
def test_NRKIE():
    try:
        unit_NRK_IE = NRKIE()
    except:
        assert False


# Generated at 2022-06-26 12:34:37.100570
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    url = 'https://www.nrk.no/urort/_'
    playlist_id = 'https://www.nrk.no/urort/_'
    NRKPlaylistBaseIE()._download_webpage()

test_case_0()
test_NRKPlaylistBaseIE()

# Generated at 2022-06-26 12:34:42.337766
# Unit test for constructor of class NRKTVEpisodeIE

# Generated at 2022-06-26 12:34:44.869205
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e_0 = NRKIE()


# Generated at 2022-06-26 12:34:50.610617
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()

# Generated at 2022-06-26 12:34:51.310142
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    NRKSkoleIE()


# Generated at 2022-06-26 12:37:12.714186
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    n_r_k_skole_i_e_0 = NRKSkoleIE()


# Generated at 2022-06-26 12:37:13.483546
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    obj = NRKTVDirekteIE()


# Generated at 2022-06-26 12:37:15.493353
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    n_r_k_t_v_series_i_e_0 = NRKTVSeriesIE()

if __name__ == '__main__':

    test_case_0()
    test_NRKTVSeriesIE()

# Generated at 2022-06-26 12:37:16.571539
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    assert NRKBaseIE.IE_NAME == 'NRK'

# Generated at 2022-06-26 12:37:17.488631
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_1 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:37:19.237603
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()


# Generated at 2022-06-26 12:37:20.002300
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    instance = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:37:21.735543
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    assert NRKRadioPodkastIE.suitable(NRKRadioPodkastIE._VALID_URL) == True


# Generated at 2022-06-26 12:37:22.813675
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    n_r_k_t_v_direkte_i_e = NRKTVDirekteIE()


# Generated at 2022-06-26 12:37:29.709197
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Test default values
    # Try to use default value in case of NRKTVSeasonIE
    n_r_k_t_v_season_i_e_1 = NRKPlaylistBaseIE()
    # Test default value of _format
    assert n_r_k_t_v_season_i_e_1._format == 'JSON'
    # Test default value of _API_BASE_URL
    assert n_r_k_t_v_season_i_e_1._API_BASE_URL == 'https://nrk.no/'
    # Test default value of _API_SUFFIX
    assert n_r_k_t_v_season_i_e_1._API_SUFFIX == '?format={format}&amp;uri={uri}'
    # Test default value of _TESTS

# Generated at 2022-06-26 12:40:15.252425
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    # Initialize the object
    ie = NRKTVEpisodeIE()
    # Get the instance name of the object
    instance = str(ie)
    # Confirm that it's the expected instance
    assert instance == "<NRKTVEpisodeIE (nrk)>", "Unexpected instance: %s" % instance



# Generated at 2022-06-26 12:40:17.737026
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE(None).IE_NAME == 'NRK'

# Generated at 2022-06-26 12:40:21.032445
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    a = NRKBaseIE()
    assert a
    a = NRKBaseIE()
    b = a.test_the_test()
    assert b


# Generated at 2022-06-26 12:40:27.853013
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    nrkt = NRKTVIE()
    url = 'https://tv.nrk.no/program/MDDP12000117'
    assert nrkt.suitable(url)

NRKTVNorwayProgramIE = NRKTVIE
NRKTVNorwayIE = NRKTVIE

# Generated at 2022-06-26 12:40:30.385239
# Unit test for constructor of class NRKIE
def test_NRKIE():
    ie = NRKIE()
    ie.extract('nrk:150533')


# Generated at 2022-06-26 12:40:32.396587
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    """
    Test constructing NRKTVIE.
    """
    NRKTVIE("nrk")



# Generated at 2022-06-26 12:40:36.865079
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    # Check exception if wrong argument type
    with pytest.raises(TypeError):
        NRKPlaylistBaseIE()


# Generated at 2022-06-26 12:40:38.904066
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    playlist = NRKPlaylistBaseIE(None);



# Generated at 2022-06-26 12:40:40.551338
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    NRKTVSerieBaseIE('')


# Generated at 2022-06-26 12:40:42.578616
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    base_ie = NRKPlaylistBaseIE()
    print("NRKPlaylistBaseIE object created sucessfully")
