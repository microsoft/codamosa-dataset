

# Generated at 2022-06-26 12:32:25.831368
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    n_r_k_t_v_season_i_e_0 = NRKTVSeasonIE()


# Generated at 2022-06-26 12:32:26.751770
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    assert_raises(TypeError, NRKTVEpisodesIE)


# Generated at 2022-06-26 12:32:28.121223
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    test_case_0()


# Generated at 2022-06-26 12:32:30.106451
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    print("Testing constructor for class NRKTVEpisodesIE")
    n_r_k_t_v_episodes_i_e_0 = NRKTVEpisodesIE()


# Generated at 2022-06-26 12:32:31.145616
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
  NRKTVSeriesIE()


# Generated at 2022-06-26 12:32:39.846085
# Unit test for constructor of class NRKBaseIE
def test_NRKBaseIE():
    n_r_k_base_i_e = NRKBaseIE()
    assert((n_r_k_base_i_e._GEO_COUNTRIES[0] == 'NO'))
    assert((n_r_k_base_i_e._CDN_REPL_REGEX == r'''(?x)://
        (?:
            nrkod\d{1,2}-httpcache0-47115-cacheod0\.dna\.ip-only\.net/47115-cacheod0|
            nrk-od-no\.telenorcdn\.net|
            minicdn-od\.nrk\.no/od/nrkhd-osl-rr\.netwerk\.no/no
        )/'''))


# Generated at 2022-06-26 12:32:45.353800
# Unit test for constructor of class NRKIE
def test_NRKIE():
    assert NRKIE._VALID_URL == 'nrk:md5:f46be075326e23ad0e524edfcb06aeb6'


# Generated at 2022-06-26 12:32:53.156802
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    n_r_k_t_v_serie_base_i_e_0 = NRKTVSerieBaseIE()
    assert n_r_k_t_v_serie_base_i_e_0 is not None
    assert n_r_k_t_v_serie_base_i_e_0._ASSETS_KEYS == ('episodes', 'instalments',)
    assert n_r_k_t_v_serie_base_i_e_0._extract_entries(test_case_0.test_dict) == [test_case_0.test_url_result_0, test_case_0.test_url_result_1]


# Generated at 2022-06-26 12:32:59.197068
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    from .nrktv import test_case_0
    from .nrknettv import test_case_1
    from .nrktvepisodeie import test_case_2
    from .nrktvie import test_case_3
    from .nrktvplaylistie import test_case_4
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    n_r_k_skole_i_e = NRKSkoleIE()
    assert(n_r_k_skole_i_e is not None)


# Generated at 2022-06-26 12:33:00.169219
# Unit test for constructor of class NRKIE
def test_NRKIE():
    n_r_k_i_e = NRKIE()


# Generated at 2022-06-26 12:34:19.208645
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    url = 'https://www.nrk.no/skole/?page=search&q=&mediaId=14099'
    video_id = '6021'
    spec = 'https://nrkno-skole-prod.kube.nrk.no/skole/api/media/14099'
    nrk_id = '6021'

    ie = NRKSkoleIE(url)

    assert ie._match_id(url) == video_id
    assert ie._download_json(spec, video_id)['psId'] == nrk_id

# Generated at 2022-06-26 12:34:24.128257
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    assert NRKTVEpisodeIE()._VALID_URL == r'https?://tv\.nrk\.no/serie/(?P<id>[^/]+/sesong/(?P<season_number>\d+)/episode/(?P<episode_number>\d+))'

# Unit test to test if url is valid or not

# Generated at 2022-06-26 12:34:35.176547
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    from .nrk import NRKTVIE
    from .nrkplaytv import NRKPlayTVIE
    from .nrkplay import NRKPlayIE

    NRKTVIE(NRKPlayTVIE(), "ABCD15000105", "http://tv.nrk.no/serie/nytt-paa-nytt")
    NRKTVIE(NRKPlayIE(), "ABCD15000105", "http://tv.nrk.no/serie/nytt-paa-nytt")

    NRKTVIE(NRKPlayTVIE(), "ABCD15000105", "http://tv.nrk.no/serie/nytt-paa-nytt#")

# Generated at 2022-06-26 12:34:37.680917
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    url = 'https://nrksuper.no/serie/labyrint'
    assert not NRKTVSeriesIE.suitable(url)


# Generated at 2022-06-26 12:34:45.406141
# Unit test for constructor of class NRKIE
def test_NRKIE():
    # constructor of NRKIE(InfoExtractor)
    assert NRKIE(InfoExtractor)._TEST == {
        # 'only_matching': True
    }
    # assert NRKIE(InfoExtractor)._TEST.get('only_matching')
    assert NRKIE(InfoExtractor)._TEST.get('only_matching') is True
    # assert NRKIE(InfoExtractor)._TEST.get('only_matching', False)
    assert NRKIE(InfoExtractor)._TEST.get('only_matching', False) is True


# Generated at 2022-06-26 12:34:51.285456
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    nrkskole = NRKSkoleIE()
    assert nrkskole.IE_DESC == 'NRK Skole'
    assert nrkskole._VALID_URL == 'https?://(?:www\.)?nrk\.no/skole/?\?.*\bmediaId=(?P<id>\d+)'

# Generated at 2022-06-26 12:34:51.900489
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
	NRKSkoleIE()


# Generated at 2022-06-26 12:34:55.291799
# Unit test for constructor of class NRKRadioPodkastIE
def test_NRKRadioPodkastIE():
    unit_test_entry = NRKRadioPodkastIE()
    assert unit_test_entry._VALID_URL is not None and "https://radio.nrk.no/podkast/" in unit_test_entry._VALID_URL
    assert unit_test_entry._TESTS is not None and len(unit_test_entry._TESTS) > 0


# Generated at 2022-06-26 12:35:03.920288
# Unit test for constructor of class NRKTVEpisodeIE
def test_NRKTVEpisodeIE():
    """
    Function that test the constructor of class NRKTVEpisodeIE
    """
    test_url = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    test_result = "https://tv.nrk.no/serie/hellums-kro/sesong/1/episode/2"
    extract_url= NRKTVEpisodeIE(NRKTVEpisodeIE(None, test_url))._VALID_URL
    if extract_url == test_result:
        print("Test NRKTVEpisodeIE: url test PASS")
    else:
        print("Test NRKTVEpisodeIE: url test FAIL")

# Generated at 2022-06-26 12:35:10.668731
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    ie = NRKPlaylistIE(downloader=None)
    assert ie._VALID_URL == r'https?://(?:www\.)?nrk\.no/(?!video|skole)(?:[^/]+/)+(?P<id>[^/]+)'
    assert ie._ITEM_RE == r'class="[^"]*\brich\b[^"]*"[^>]+data-video-id="([^"]+)"'
# Test for testing the extraction of values for the title and description

# Generated at 2022-06-26 12:37:49.203578
# Unit test for constructor of class NRKPlaylistBaseIE
def test_NRKPlaylistBaseIE():
    assert NRKPlaylistBaseIE._VALID_URL is None
    assert NRKPlaylistBaseIE._ITEM_RE is None


# Generated at 2022-06-26 12:37:51.381316
# Unit test for constructor of class NRKTVSerieBaseIE
def test_NRKTVSerieBaseIE():
    ie = NRKTVSerieBaseIE()
    assert isinstance(ie, NRKTVSerieBaseIE)



# Generated at 2022-06-26 12:38:01.764827
# Unit test for constructor of class NRKTVIE
def test_NRKTVIE():
    url = 'https://tv.nrk.no/serie/tour-de-ski/MSPO40010515/06-01-2015#del=2'
    # create a NRKTVIE instance
    NRKTVIE_instance = NRKTVIE()
    match = NRKTVIE_instance.url_result(url)
    # test the method _real_extract of class NRKTVIE
    result = NRKTVIE_instance.extract(match)
    assert 'entries' in result

# Generated at 2022-06-26 12:38:12.168384
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():

    site, serie_kind, series_id = re.match(NRKTVSeriesIE._VALID_URL, 'https://tv.nrk.no/serie/blank').groups()
    is_radio = site == 'radio.nrk'
    domain = 'radio' if is_radio else 'tv'

    assert site == 'tv.nrk'
    assert serie_kind == 'serie'
    assert series_id == 'blank'
    assert is_radio == False
    assert domain == 'tv'

# Generated at 2022-06-26 12:38:19.994208
# Unit test for constructor of class NRKSkoleIE
def test_NRKSkoleIE():
    import unittest

    class NRKSkoleIETest(unittest.TestCase):
        def test_constructor(self):
            self.assertRaises(
                TypeError,
                NRKSkoleIE,
                'http://some.fake.url/',
                downloader=False
            )

    unittest.main()

# Generated at 2022-06-26 12:38:28.952010
# Unit test for constructor of class NRKPlaylistIE
def test_NRKPlaylistIE():
    import datetime
    testObj = NRKPlaylistIE()
    testPayload = {}
    testPayload['id'] = 'playlist_id'
    testPayload['url'] = 'http://www.nrk.no/troms/gjenopplev-den-historiske-solformorkelsen-1.12270763'
    testPayload['playlist_title'] = 'Gjenopplev den historiske solformørkelsen'
    testPayload['playlist_description'] = 'md5:c2df8ea3bac5654a26fc2834a542feed'
    testPayload['entries'] = []
    entry = {}
    entry['id'] = 'video_id1'
    entry['info_dict'] = {}
    entry['info_dict']['id']

# Generated at 2022-06-26 12:38:36.208985
# Unit test for constructor of class NRKTVSeasonIE
def test_NRKTVSeasonIE():
    url_list = [
        'https://tv.nrk.no/serie/backstage/sesong/1',
        'https://radio.nrk.no/podkast/hele_historien/sesong/diagnose-kverulant',
        'https://radio.nrk.no/serie/dagsnytt/sesong/201509'
    ]

    for url in url_list:
        ie = NRKTVSeasonIE(NRKTVSeasonIE.suitable(url))

        assert ie._match_id(url) is not None
        assert ie._VALID_URL == NRKTVSeasonIE._VALID_URL
        assert ie._TESTS == NRKTVSeasonIE._TESTS
        assert ie.IE_NAME == NRKTVSeasonIE.IE_NAME
        assert ie.ie_

# Generated at 2022-06-26 12:38:46.660996
# Unit test for constructor of class NRKTVDirekteIE
def test_NRKTVDirekteIE():
    for ie_class in (NRKTVIE, NRKTVDirekteIE):
        if not ie_class.working():
            continue
        # Test TV
        nrk = NRKTVDirekteIE.__new__(NRKTVDirekteIE)
        nrk.ie_key = 'NRKTVDirekte'
        nrk._VALID_URL = ie_class._VALID_URL
        nrk._API_URL = ie_class._API_URL
        nrk._live_title = ie_class._live_title
        nrk._search_regex = lambda self, pattern, string, name=None, default=NO_DEFAULT, fatal=True: self._TEST_SEARCH_REGEX(pattern, string, name, default, fatal)
        nrk._

# Generated at 2022-06-26 12:38:57.671805
# Unit test for constructor of class NRKTVSeriesIE
def test_NRKTVSeriesIE():
    import random

    class TestIE(NRKTVSeriesIE):
        def test_get_series_id(self, manifest_url):
            return manifest_url.split('/')[-1]

        def test_call_api(self, path, series_id, kind, query=None, fatal=True):
            url_data = compat_urllib_parse_urlparse(path)

            if url_data.netloc != 'apitest-tv.nrk.no':
                raise Exception('Wrong host, expected apitest-tv.nrk.no')

            if '?' in url_data.path:
                segments = url_data.path.split('?')
                path = segments[0]
                query = segments[1]


# Generated at 2022-06-26 12:39:03.114779
# Unit test for constructor of class NRKTVEpisodesIE
def test_NRKTVEpisodesIE():
    try:
        NRKTVEpisodesIE()
    except Exception as exception:
        assert False and 'Exception raised when creating instance of NRKTVEpisodesIE'
        return
    assert True

