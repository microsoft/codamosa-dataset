

# Generated at 2022-06-23 11:39:10.212030
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO

    # StringIO with properties file
    text_io = StringIO()
    text_io.write(u'user.name=toto\nuser.age=2\nuser.mail=toto@localhost\n')

    # StringIO with ini file
    ini_io = StringIO()
    ini_io.write(u'[FR]\nuser1=toto\nuser2=titi\n')

    lm = LookupModule()
    # Test with a section and a string key
    # This case is used when the ini file contains a section
    lm.cp = configparser.ConfigParser()
    lm.cp.readfp(ini_io)

# Generated at 2022-06-23 11:39:18.725133
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    l = LookupModule()

    l.cp = configparser.ConfigParser()
    l.cp.optionxform = str
    l.cp.readfp(StringIO("""
[section]
k1 = v1
k2 = v2
k3 = v3
k4 = v4
"""))

    assert l.get_value("k1", "section", "none", False) == "v1"
    assert l.get_value("k[123]", "section", "none", True) == ["v1", "v2", "v3"]


# Generated at 2022-06-23 11:39:26.145467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Retrieve all values from a section using a regexp
    #
    # Case 1:
    #   - file_name = "test.ini"
    #   - sections = ['section1']
    #   - key = '.*'
    #   - re = True
    #   - sections_result = {'section1': ['value1', 'value2', 'value3', 'value4,value5']}
    #
    file_name = "test.ini"

# Generated at 2022-06-23 11:39:27.876357
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    lookupMod = LookupModule()
    assert lookupMod is not None

# Generated at 2022-06-23 11:39:36.155481
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module.cp.readfp(StringIO(u'[section]\n'
                                u'key1=value1\n'
                                u'key2=value2\n'
                                u'key3=value\n'
                                u'key4=value\n'
                                u'key5=value\n'
                                u'key6=value\n'
                                u'key3=value\n'
                                u'key4=value\n'
                                u'key5=value\n'
                                u'key6=value'))
    # key1 exist

# Generated at 2022-06-23 11:39:46.599286
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'key1=value\n')
    config.write(u'key2=value1\n')
    config.seek(0, os.SEEK_SET)
    cp = configparser.ConfigParser()
    cp.readfp(config)
    l = LookupModule()
    l.cp = cp
    # Retrieve an inexistent key
    assert l.get_value('key0', 'section1', '', False) == ''
    # Retrieve a single value with re=False
    assert l.get_value('key1', 'section1', '', False) == 'value'
    # Retrieve a list of values with re=True

# Generated at 2022-06-23 11:39:56.423324
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookupmodule = LookupModule()
    lookupmodule.cp = configparser.ConfigParser()
    lookupmodule.cp.read_string(u'[section1]\nkey1=value1\nkey2=value2\n[section2]\nkey3=value3\n')
    assert lookupmodule.get_value('key1', 'section1', 'default', False) == 'value1'
    assert lookupmodule.get_value('key1', 'section2', 'default', False) == 'default'
    assert lookupmodule.get_value('key3', 'section2', 'default', False) == 'value3'
    assert lookupmodule.get_value('.*', 'section1', 'default', True) == ['key1=value1', 'key2=value2']


# Generated at 2022-06-23 11:40:04.309734
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of LookupModule
    lookup_module = LookupModule()

    # Create instance of configparser, set allow_no_value and write a simple ini to it
    cp = configparser.ConfigParser(allow_no_value=True)
    config = StringIO()
    config.write("""[global]
user = yannig
password = passwd

[integration]
user = integration

[production]
user = production""")
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)
    config.seek(0, os.SEEK_END)

    # Parsing of terms
    terms = ['user', 'password']

# Generated at 2022-06-23 11:40:05.578581
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:40:08.181108
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.run(['user', 'password'], allow_no_value=True, file='ansible.ini', section='default') == ['yannig']

# Generated at 2022-06-23 11:40:18.754285
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Instance of class LookupModule
    class MockLookupModule(LookupModule):
        def __init__(self):
            self.cp = configparser.RawConfigParser()
            return

        def _load_file(self, filename):
            self.cp.read(filename)
            return

        def get_options(self):
            self._load_file("tests/test.ini")
            return {
                'section' : 'section1',
                're' : False
            }

    instance = MockLookupModule()
    # When a key doesn't exist, return default value
    assert ['default'] == instance.get_value('non-existent key', 'section1', 'default', False)
    # When a key exists and is_regexp is False, return its value
    assert ['value1'] == instance.get_value

# Generated at 2022-06-23 11:40:21.203989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert os.path.isfile(l.get_option('file')) == True

# Generated at 2022-06-23 11:40:27.888042
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Start LookupModule class
    instance = LookupModule()
    # Start StringIO
    config = StringIO()
    # Create StringIO with
    config.write(u'[section]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'key1.1=value1.1\n')
    config.seek(0, os.SEEK_SET)
    # Create ConfigParser
    instance.cp = configparser.ConfigParser()
    # Read StringIO
    instance.cp.readfp(config)
    # Test get_value with regexp

# Generated at 2022-06-23 11:40:36.708465
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    """Test get_value of class LookupModule"""
    class TestLookupModule(LookupModule):
        def get_value(self, key, section, dflt, is_regexp):
            pass

    lookup_module = TestLookupModule()

    # test with section that exist
    config = configparser.ConfigParser()
    config.readfp(StringIO(u'[section]\nkey=value\n'))
    lookup_module.cp = config
    assert lookup_module.get_value('key', 'section', '', False) == 'value'

    # test with section that does not exist, which should return default value
    config = configparser.ConfigParser()
    config.readfp(StringIO(u'[section]\n'))
    lookup_module.cp = config
    assert lookup_module.get_value

# Generated at 2022-06-23 11:40:44.289287
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Initialize class
    lookup = LookupModule()

    # Test when section doesn't exist in the file
    with open('test/ini_test_file.ini', 'w') as f:
        f.write('foobar=baz\n')
        f.write('abc=def')

    lookup.cp = configparser.ConfigParser()
    lookup.cp.read('test/ini_test_file.ini')

    value = lookup.get_value('foobar', 'nosection', 'foobar', False)
    assert value == 'foobar'

    # Test when there is no option in the section
    value = lookup.get_value('foobar', 'nosection', 'foobar', False)
    assert value == 'foobar'

    # Test when regexp doesn't match any key
    value = lookup.get_value

# Generated at 2022-06-23 11:40:51.195726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.cp = configparser.ConfigParser()
    l.cp.add_section("production")
    l.cp.set("production", "user", "nardo")
    l.cp.add_section("integration")
    l.cp.set("integration", "user", "doe")
    assert l.run(["user", "section=production"], default="unknown") == ["nardo"]
    assert l.run(["user", "section=integration"], default="unknown") == ["doe"]
    assert l.run(["user", "section=development"], default="unknown") == ["unknown"]
    assert l.run(["user", "section=development"], default=["unknown"]) == ["unknown"]
    l.cp.set("production", "user", "nardo,john")
    assert l

# Generated at 2022-06-23 11:41:02.424162
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # special case for the java properties
    test_1 = LookupModule()
    test_1.cp = configparser.ConfigParser(allow_no_value=True)
    config = StringIO()
    config.write(u'[java_properties]\n')
    config.write(u'a.b=c\n')
    config.seek(0, os.SEEK_SET)
    test_1.cp.readfp(config)
    assert test_1.get_value('a.b', 'java_properties', '', False) == 'c'

    # normal case
    test_2 = LookupModule()
    test_2.cp = configparser.ConfigParser(allow_no_value=True)
    config = StringIO()
    config.write(u'[section1]\n')
    config.write

# Generated at 2022-06-23 11:41:13.602042
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lm = LookupModule()

    # Create ConfigParser object containing an ini file with several sections
    lm.cp = configparser.ConfigParser()

    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(u'[global]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'key3=value3\n')
    config.write(u'key4=value4\n')
    config.write(u'key5=value5\n')
    config.write(u'key6=value6\n')
    config.write(u'key7=value7\n')
    config.write(u'key8=value8\n')
   

# Generated at 2022-06-23 11:41:19.766267
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    module = LookupModule()
    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(u'[java_properties]\n')
    config.write(u'user=root\n')
    config.write(u'password=\n')
    config.write(u'\n')
    config.write(u'[integration]\n')
    config.write(u'user=root\n')
    config.write(u'password=\n')
    config.seek(0, os.SEEK_SET)
    # Parse ini
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.readfp(config)
    module.cp = cp
    assert module.get_value("user", "java_properties", "error", False)

# Generated at 2022-06-23 11:41:24.414473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test LookupModule")
    lookup_plugin = LookupModule()
    cp = configparser.ConfigParser()
    assert(cp, lookup_plugin.cp)
    print("Test LookupModule: completed")


# Generated at 2022-06-23 11:41:33.599214
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import pytest

    class FakeConfigParser():
        def items(self, section):
            return [('key1', 'value1'), ('key2', 'value2')]

    class FakeConfigParserNoOptionError(FakeConfigParser):
        def items(self, section):
            raise configparser.NoOptionError()

    class FakeConfigParserNoSectionError(FakeConfigParser):
        def items(self, section):
            raise configparser.NoSectionError()

    class FakeLookupModule(LookupModule):
        def __init__(self):
            self.cp = FakeConfigParser()

    class FakeLookupModuleNoOptionError(FakeLookupModule):
        def __init__(self):
            self.cp = FakeConfigParserNoOptionError()


# Generated at 2022-06-23 11:41:44.532174
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a fake config parser
    class FakeConfigParser(object):
        def __init__(self):
            self.d = dict()

        # Get value from a section
        def get(self, section, option):
            return self.d[section][option]

        # Get all values from a section using a regex
        def items(self, section):
            return [(k, v) for k, v in self.d[section].items() if re.match(option, k)]

    # Create a fake lookup module
    class FakeModule(object):
        def __init__(self):
            self.cp = FakeConfigParser()

    # Create a fake ini file

# Generated at 2022-06-23 11:41:55.393664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # GIVEN
    lookup_module = LookupModule()
    class Var:
        def __init__(self, var_name, var_value):
            self.name = var_name
            self.value = var_value
        def get_name(self):
            return self.name
        def get(self, var_name, var_value):
            return self.value
    class ModVars:
        def get_vars(self):
            return [Var('foo', 'bar'), Var('hello', 'world')]
    class AnsibleModule:
        def __init__(self, mod_vars):
            self.params = {}
            self.params['allow_no_value'] = False
            self.params['config_path'] = '/home/unknown/ansible/inventory'

# Generated at 2022-06-23 11:42:02.241870
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ## init LookupModule
    lookup = LookupModule()

    ## create configuration file
    path = "test.ini"
    config = """[section1]
option1 = value11
option2 = value12
option3 = value13

[section2]
option1 = value21
option2 = value22
option3 = value23
option4 = value24
option5 = value25

[section3]
option1 = value31
option2 = value32
option3 = value33

[section4]
option1= value41
option2= value42
option3= value43
"""

    ## create a file
    with open(path, "w") as ini_file:
        ini_file.write(config)

    ## load configuration file
    config = StringIO()
    config.write(config)
    config

# Generated at 2022-06-23 11:42:03.076829
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert configparser.ConfigParser(allow_no_value=True)

# Generated at 2022-06-23 11:42:04.542279
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l


# Generated at 2022-06-23 11:42:14.116641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys, os
    import pytest

    TEST_DIR = os.path.join(os.path.dirname(__file__), '..', '..', 'unit', '_data', 'lookup_plugins')
    sys.path.append(TEST_DIR)
    import test_utils

    lookup_module = LookupModule()
    test_utils.setup_loader_modules()
    with test_utils.create_temp_plugin_loaders(TEST_DIR):
        # no section and no default
        assert lookup_module.run(terms=["user"], variables=dict(ansible_user='test_user')) == ['test_user']
        assert lookup_module.run(terms=["notexists"], variables=dict(ansible_user='test_user')) == ['']

        # no section and default
       

# Generated at 2022-06-23 11:42:25.377512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Using the configuration file below, check if the methods
    - run
    - get_value
    - get_value with regexp
    return the expected values
    """

    config = StringIO()
    config.write(u'[global]\n')
    config.write(u'user=user1\n')
    config.write(u'group=group2\n')
    config.write(u'[integration]\n')
    config.write(u'user=user2\n')
    config.write(u'[production]\n')
    config.write(u'user=user3\n')
    config.write(u'[section1]\n')
    config.write(u'user1=value1\n')
    config.write(u'user2=value2\n')

# Generated at 2022-06-23 11:42:38.233826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing import vault
    terms = ['a=b', 'user', 'user1=name']
    variables = {'password': 'secret'}
    # create a test fixture
    ini_file = '''
[section]
user=John
user1=Bob

# Comment
user3={{ password }}
'''

    # Write ini file
    with open('ansible.ini', 'w') as f:
        f.write(ini_file)


# Generated at 2022-06-23 11:42:47.475493
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    lm = LookupModule()

    # Create a fake parameters array
    test_terms = [
        'key = value',
        'key2 = value2',
    ]

    # Create a fake variables array
    test_variables = {
        'section': 'section1',
        'type': 'ini',
        'file': 'test.ini',
    }

    # Create a fake config file
    with open ("test.ini", "w") as config_file:
        config_file.write("[%s]\n" % test_variables['section'])
        config_file.write("key=value\n")
        config_file.write("key2=value2\n")
        config_file.write("section2 key=value")

# Generated at 2022-06-23 11:42:53.253950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Options
    options = {
        '_terms': [
            'user',
            'password',
            'environment=dev',
            'type=properties',
            'file=user.properties'
        ],
        'file': 'user.properties',
        'section': 'user.properties',
        'type': 'properties',
        're': 'False',
        'default': '',
        'encoding': 'utf-8',
    }

    # Test
    ret = None

# Generated at 2022-06-23 11:42:54.067126
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 11:43:06.457579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ini file content:
    # [section1]
    # key1=value1
    # key2=value2
    # key3=value3
    #
    # [section2]
    # key4=value4
    # key5=value5
    # key6=value6
    #
    # [section3]
    # key7=value7
    # key8=value8
    # key9=value9

    lookup = LookupModule()
    content = '''
[section1]
key1=value1
key2=value2
key3=value3

[section2]
key4=value4
key5=value5
key6=value6

[section3]
key7=value7
key8=value8
key9=value9
'''
    lookup.cp

# Generated at 2022-06-23 11:43:18.564878
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    """
    Test that the class LookupModule does a good job on the method get_value().
    """

    # On definition a class
    class FakeLookupModule(LookupModule):
        """
        Fake class for the moment for the test of the method get_value().
        """

        def __init__(self):
            """
            Constructor of the class FakeLookupModule.
            """
            super(FakeLookupModule, self).__init__()

            config = StringIO()
            # On construction a config file in format INI
            config.write(u'[Test]\n')
            config.write(u'a=1\n')
            config.write(u'b=2\n')
            config.write(u'c=3\n')
            config.write(u'[Test2]\n')

# Generated at 2022-06-23 11:43:28.938379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Testcase for method run of class LookupModule
    '''
    global class_cp
    class_cp = configparser.ConfigParser()
    file_content = "[global]\nuser = yperre\n"
    file_content += "[integration]\nuser = yperre\n"
    file_content += "[production]\nuser = root\n"
    file_content += "[section1]\nuser = root\n"
    config = StringIO()
    config.write(u'[global]\nuser = yperre\n')
    config.write(u'[integration]\nuser = yperre\n')
    config.write(u'[production]\nuser = root\n')

# Generated at 2022-06-23 11:43:39.301874
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # set up test data and variables for testing
    cp = configparser.ConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.set('section1', 'key2', 'value2')
    cp.set('section1', 'key3', 'value3')
    cp.set('section1', 'key4', 'value4')

    # test for list of keys
    lk = LookupModule()
    lk.cp = cp
    values = lk.get_value('.*', 'section1', None, True)
    assert values == ['value1', 'value2', 'value3', 'value4']
    # test for single key
    value = lk.get_value('key3', 'section1', None, False)

# Generated at 2022-06-23 11:43:49.723022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['key1', 'key2']

    lookup = LookupModule()
    lookup.set_options = mock.Mock()
    lookup.get_options = mock.Mock()
    lookup.find_file_in_search_path = mock.Mock()
    lookup._loader._get_file_contents = mock.Mock()
    lookup._deprecate_inline_kv = mock.Mock()
    lookup.cp = mock.Mock()

    # Test
    lookup.run(terms, variables=None, **kwargs)

    # Assert
    lookup.set_options.assert_called_once_with(var_options=variables, direct=kwargs)
    lookup.get_options.assert_called_once_with()

# Generated at 2022-06-23 11:43:58.663702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section('section1')
    lookup.cp.set('section1', 'key1', 'value1')
    lookup.cp.set('section1', 'key2', 'value2')
    lookup.cp.add_section('section2')
    lookup.cp.set('section2', 'key3', 'value3')
    lookup.cp.set('section2', 'key4', 'value4')
    lookup.cp.set('section2', 'key5', 'value5')
    lookup.cp.set('section2', 'key6', 'value6')

    assert lookup.run(["key1"]) == ['value1']
    assert lookup.run(["key1=value1"]) == ['value1']

# Generated at 2022-06-23 11:43:59.516395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 11:44:01.553575
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert isinstance(test_lookup, LookupModule)


# Generated at 2022-06-23 11:44:13.456616
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit test: python -m ansible.plugins.lookup.ini test_LookupModule
    import pytest
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp._sections = dict()
    lookup.cp._sections['mysection'] = dict()
    lookup.cp._sections['mysection']['mykey'] = "myvalue"
    lookup.cp._sections['mysection']['mykey2'] = "myvalue2"
    assert lookup.cp.get('mysection', 'mykey') == "myvalue"
    assert lookup.get_value('mykey', 'mysection', "default_value", False) == "myvalue"
    assert lookup.get_value('.*', 'mysection', "default_value", True) == ["myvalue", "myvalue2"]

# Generated at 2022-06-23 11:44:22.863948
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create the class
    lookup_module = LookupModule()

    # Create a fake content
    content = "[Section1]\n" + "key1=value1\n\n" + "[Section2]\n" + "key2=value2"

    # Create a StringIO to pass to ConfigParser
    f = StringIO()
    f.write(content)
    f.seek(0, os.SEEK_SET)

    # Create a ConfigParser object and read the StringIO
    cp = configparser.ConfigParser()
    cp.readfp(f)

    # Test the get_value method
    assert get_value("key1", "Section1", "default", True) == "value1"
    assert get_value("key2", "Section2", "default", True) == "value2"

# Generated at 2022-06-23 11:44:35.018413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test case for LookupModule.run'''
    import os

    import ansible.plugins.lookup.ini as ini
    lookup_module_run = ini.LookupModule.run

    # Create a fake LookupModule object
    class FakeLookupModule(ini.LookupModule):
        def __init__(self):
            self.path = os.path.dirname(os.path.realpath(__file__))

    # Simple test
    # Expected result: 1st value of 'global' section of ansible.ini
    lookup_module = FakeLookupModule()
    assert lookup_module_run(lookup_module, ['lookup_plugin.dir']) == ['lib']
    assert lookup_module_run(lookup_module, ['foo']) == []

    # Specific section
    # Expected result

# Generated at 2022-06-23 11:44:45.441531
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # _parse_params(term, paramvals)
    paramvals = {'file': 'ansible.ini', 'section': 'global'}

    test_value = _parse_params('', paramvals)
    assert test_value == ['']

    test_value = _parse_params('key', paramvals)
    assert test_value == ['key']

    test_value = _parse_params('key=value', paramvals)
    assert test_value == ['key=value']

    test_value = _parse_params('key=value key=value', paramvals)
    assert test_value == ['key=value key=value']

    test_value = _parse_params('key=value file=ansible.ini', paramvals)
    assert test_value == ['key=value', 'file=ansible.ini']

    test_

# Generated at 2022-06-23 11:44:58.158631
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lu = LookupModule()
    lu.cp = configparser.ConfigParser()
    lu.cp.readfp(StringIO("[test]\nkey=value"))
    assert(lu.get_value("key", "test", "default", False) == "value")
    assert(lu.get_value("not_key", "test", "default", False) == "default")
    assert(lu.get_value("key", "not_test", "default", False) == "default")
    assert(lu.get_value("not_key", "not_test", "default", False) == "default")
    assert(lu.get_value("^.*$", "test", "default", True) == ["key", "value"])

# Generated at 2022-06-23 11:45:05.248493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_mod = LookupModule()

    # Create a configparser containing 2 sections named 'section1' and 'section2'
    # Each section contains 4 properties :
    #    - 'key1' = 'value1'
    #    - 'key2' = 'value2'
    #    - 'key3' = 'value3'
    #    - 'key4' = 'value4'
    cp = configparser.ConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.set('section1', 'key2', 'value2')
    cp.set('section1', 'key3', 'value3')
    cp.set('section1', 'key4', 'value4')
    cp.add_

# Generated at 2022-06-23 11:45:15.840192
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    ini_file = configparser.ConfigParser()
    ini_file.optionxform = str  # case sensitive mode
    ini_file.add_section('global')
    ini_file.set('global', 'key1', '1')
    ini_file.set('global', 'key2', '2')
    ini_file.set('global', 'key3', '3')
    lookup.cp = ini_file
    assert lookup.get_value('key1', 'global', None) == '1'
    assert lookup.get_value('key2', 'global', None) == '2'
    assert lookup.get_value('key3', 'global', None) == '3'
    assert lookup.get_value('key4', 'global', None) is None


#

# Generated at 2022-06-23 11:45:27.513186
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Check if a key without value and without '=' symbol can be read
    # configparser.ConfigParser will parse this case as a key
    config = StringIO()
    config.write(u'[java_properties]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2\n')
    config.seek(0, os.SEEK_SET)

    cp = configparser.ConfigParser()
    cp.readfp(config)

    # get_value fails if allow_no_value is False
    lu = LookupModule()
    lu.cp = cp
    assert lu.get_value('key2', 'java_properties', None, False) is None

    # get_value succeeds if allow_no_value is True
    lu = LookupModule()
   

# Generated at 2022-06-23 11:45:36.735302
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookupmodule = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section("section1")
    cp.add_section("section2")
    cp.set("section1", "key", "value")
    cp.set("section1", "key1", "value1")
    cp.set("section1", "key2", "value2")
    lookupmodule.cp = cp
    assert lookupmodule.get_value("key", "section1", None, False) == "value"
    # test with regex
    assert lookupmodule.get_value("key.", "section1", None, True) == ["key1", "key2"]

# Generated at 2022-06-23 11:45:37.800176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: use mock to test run
    pass

# Generated at 2022-06-23 11:45:48.543856
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_cp = configparser.ConfigParser()
    test_cp.add_section('section1')
    test_cp.set('section1', 'key1', 'value1')
    test_cp.set('section1', 'key2', 'value2')
    test_cp.set('section1', 'key3', 'value3')
    test_cp.set('section1', 'key4', 'value4')

    test_cp.add_section('section2')
    test_cp.set('section2', 'key1', 'value1')
    test_cp.set('section2', 'key2', 'value2')
    test_cp.set('section2', 'key3', 'value3')
    test_cp.set('section2', 'key4', 'value4')


# Generated at 2022-06-23 11:45:52.592600
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.get_value("key", "section", "dflt", True)
    lookup.get_value("key", "section", "dflt", False)
    lookup.get_value("key", "section", "dflt", "re")
    lookup.get_value("key", "section", "dflt", 1)

# Generated at 2022-06-23 11:46:01.304883
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    results = []
    # First test
    expected_results = ["toto", "tata"]
    test_data = "[section1]\nkey1=toto\nkey2=tata"
    test_io = StringIO(test_data)
    cp = configparser.ConfigParser()
    cp.readfp(test_io)
    lm = LookupModule()
    lm.cp = cp
    results = lm.get_value("key1", "section1", None, False)
    assert results in expected_results

    # Second test
    expected_results = ["toto", "tata"]
    test_data = "[section1]\nkey1=toto\nkey2=tata"
    test_io = StringIO(test_data)
    cp = configparser.ConfigParser()
    cp

# Generated at 2022-06-23 11:46:07.721716
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Create LookupModule object
    lookup = LookupModule()

    # Create ConfigParser object
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section('section')
    lookup.cp.set('section', 'user', 'yannig')

    # Get value
    assert lookup.get_value('user', 'section', '', False) == 'yannig'
    assert lookup.get_value('user', 'section', '', True) == []

# Generated at 2022-06-23 11:46:13.566288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test LookupModule.run

        Args:
            None

        Returns:
            None

        Raises:
            None
        """
    # Import module LookupModule
    import ansible.plugins.lookup.ini

    # Create instance of _LookupModule
    cls = ansible.plugins.lookup.ini.LookupModule

    # Create instance of class LookupModule
    mod = cls()

    # Create instance of class MutableMapping
    paramvals = {}

    # Populate paramvals
    paramvals['case_sensitive'] = False
    paramvals['allow_no_value'] = False
    paramvals['file'] = 'ansible.ini'
    paramvals['section'] = 'global'
    paramvals['encoding'] = 'utf-8'
    paramvals['re'] = False
    paramvals

# Generated at 2022-06-23 11:46:21.749224
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    list_ini = ['[MySection]\n', '#Comment\n', 'key=value\n', 'key1=value1\n']
    config = StringIO()
    for line in list_ini:
        config.write(line)
    config.seek(0, os.SEEK_SET)
    lookup_module.cp.readfp(config)
    # regexp to match key
    assert lookup_module.get_value(r'key.*', 'MySection', None, True) == ['value', 'value1']
    # no regexp to match key
    assert lookup_module.get_value('key', 'MySection', None, False) == 'value'
    # section not present
    assert lookup_module.get

# Generated at 2022-06-23 11:46:32.020670
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def find_file_in_search_path(variables, directories, filename, ignore_errors=False, all_paths=False):
        return "/tmp/ansible.ini"

    test_terms = [
        "user",
        "user=",
        "user=file=/tmp/ansible.ini=",
        "user=file=/tmp/ansible.ini",
        "user file=/tmp/ansible.ini re=False",
        "user file=/tmp/ansible.ini",
        "user file=/tmp/ansible.ini",
    ]


# Generated at 2022-06-23 11:46:42.010133
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    data = """
[section]
one=1
two=2
three=3
four=4
five=5
    """
    config = StringIO(data)
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.readfp(config)
    l = LookupModule()
    l.cp = cp
    # Get a value
    assert l.get_value('one', 'section', None, False) == '1'
    # Get a value with regexp
    assert l.get_value('tw.', 'section', None, True) == ['2']
    # Get a value with regexp
    assert l.get_value('two', 'section', None, True) == ['2']
    # Get a value with regexp

# Generated at 2022-06-23 11:46:43.270959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 11:46:44.184575
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 11:46:48.605321
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _module = LookupModule()
    assert _module.get_options() == {
        'type': 'ini',
        'file': 'ansible.ini',
        'section': 'global',
        're': False,
        'encoding': 'utf-8',
        'default': '',
        'case_sensitive': False
    }



# Generated at 2022-06-23 11:47:00.748876
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.plugins.lookup import LookupModule
    from io import StringIO
    from ansible.module_utils.six.moves import configparser

    options = dict()
    options['case_sensitive'] = False
    options['allow_no_value'] = False
    options['encoding'] = 'utf-8'

    file_content="""
[section]
key1=value1
key2=value2
    """
    test_file = StringIO(to_text(file_content, errors='surrogate_or_strict', encoding=options['encoding']))
    cp = configparser.ConfigParser(allow_no_value=options['allow_no_value'])
    cp.optionxform = to_native
    cp.readfp(test_file)
    lookup_module = LookupModule()
   

# Generated at 2022-06-23 11:47:01.189464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:47:08.178369
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    gv_var = LookupModule()
    # test get_value with regexp enabled
    gv_var.cp = configparser.ConfigParser()
    gv_var.cp.add_section('logging')
    gv_var.cp.set('logging', 'log_file', 'test_log')
    gv_var.cp.set('logging', 'log_rotation_age', '10')

    assert gv_var.get_value('log_file', 'logging', '', True) == ['test_log']
    assert gv_var.get_value('log_.+', 'logging', '', True) == ['test_log', '10']
    assert gv_var.get_value('log_rotation_age', 'logging', '', True) == ['10']
    assert g

# Generated at 2022-06-23 11:47:09.076861
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None)

# Generated at 2022-06-23 11:47:12.253413
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit tests for constructor"""
    lm = LookupModule()
    assert isinstance(lm, LookupBase)



# Generated at 2022-06-23 11:47:23.684995
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    t = LookupModule()
    t.cp = configparser.ConfigParser()
    t._templar = None
    t._loader = None
    t.cp.add_section('where')
    t.cp.set('where', 'who', 'world')
    t.cp.add_section('when')
    t.cp.set('when', 'what', 'hello')

    terms = [
        'who section=where',
        'what section=when',
    ]

    results = [
        'world',
        'hello',
    ]

    for idx, term in enumerate(terms):
        ret = t.run([term], None)
        assert ret == [results[idx]]

# Generated at 2022-06-23 11:47:25.733333
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test the constructor of class LookupModule
    lookup_module = LookupModule()
    assert lookup_module



# Generated at 2022-06-23 11:47:36.560907
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Given
    cp = configparser.ConfigParser()
    section = 'global'
    cp.add_section(section)
    for id, i in enumerate(['one', 'two', 'three']):
        cp.set(section, i, str(id))
    cp.set(section, 'four', 'four')
    lm = LookupModule()
    lm.cp = cp

    # When
    # Retrieve all values using a regexp
    v = lm.get_value(r'.*', section, 'default', True)

    # Then
    assert len(v) == 4
    assert isinstance(v, MutableSequence)
    assert v == ['0', '1', '2', 'four']

    # When
    # Retrieve one value

# Generated at 2022-06-23 11:47:45.617742
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser(allow_no_value=False)

    import os, textwrap
    fp = os.path.join(os.path.dirname(__file__), 'fixtures', 'lookup_get_value.ini')

    with open(fp, 'r') as f:
        s = f.read()

    config = StringIO()
    config.write(s)
    config.seek(0, os.SEEK_SET)

    cp.readfp(config)

    l = LookupModule()
    l.cp = cp

    assert l.get_value('key1', 'section1', '', False) == 'value1'
    assert l.get_value('key2', 'section1', '', False) == 'value2'

# Generated at 2022-06-23 11:47:56.089482
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ##############################################################################
    # Result for a ini for option type equal to ini
    ##############################################################################

    # Create the file
    path_file_ini = 'test.ini'
    config_ini = StringIO()
    config_ini.write(u'[section1]\nvalue1=toto\nvalue2=titi\nvalue3=tata\nvalue4=tutu\nvalue5=tete\n')
    config_ini.seek(0, os.SEEK_SET)
    lines = config_ini.readlines()
    with open(path_file_ini, 'w') as fd:
        fd.writelines(lines)

    # Create the lookup module
    lookup_module = LookupModule()

    # Create the options

# Generated at 2022-06-23 11:48:05.894735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the method run of the class LookupModule
    """

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.plugins.lookup import LookupBase

    class DummyLookupModule(LookupBase):
        def get_value(self, key, section, dflt, is_regexp):
            return "foo"

    options = dict(
        section="section1",
        file="test.ini",
        re=False)
    lookupmodule = DummyLookupModule()

    # Check if an empty list is returned
    assert lookupmodule.run(None, **options) == []

    # Empty string
    assert lookupmodule.run("", **options) == []

    # No option

# Generated at 2022-06-23 11:48:16.159975
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    module = LookupModule()

    # Create empty configparser object
    module.cp = configparser.ConfigParser()

    # Create an ini file
    file = '''
[users]
user1=David
user2=Joe
user3=Daniel
'''
    module.cp.readfp(StringIO(to_text(file)))

    # Test a simple regexp
    assert module.get_value('user', 'users', 'DEFAULT', True) == ['David', 'Joe', 'Daniel']

    # Test a simple regexp
    assert module.get_value('user1', 'users', 'DEFAULT', False) == 'David'



# Generated at 2022-06-23 11:48:21.204099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(terms=[]) == []
    assert lm.run(terms=['host'], variables={'host': 'hostname'}) == ['hostname']
    assert lm.run(terms=['host', 'host'], variables={'host': 'hostname'}) == ['hostname', 'hostname']

# Generated at 2022-06-23 11:48:28.235572
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:48:37.841837
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Check if a single value is correctly retrieved
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section('java_properties')
    cp.set('java_properties', 'file.encoding', 'UTF-8')
    cp.set('java_properties', 'user.name', 'John')
    lookup_module.cp = cp
    var = lookup_module.get_value('user.name', 'java_properties', None, False)
    assert var == 'John'
    # Check if a list of values is correctly retrieved
    var = lookup_module.get_value('file', 'java_properties', None, True)
    assert var == ['file.encoding']

# Generated at 2022-06-23 11:48:49.338373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

# Generated at 2022-06-23 11:48:59.713789
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # global vars
    import ansible.utils.module_docs as md
    import ansible.utils.module_docs_fragments as mdf

    # Create a LookupModule object
    lm = LookupModule()

    # Create a configparser object
    cp = configparser.ConfigParser()

    # Create a StringIO object
    config = StringIO()

    # Create a AnsibleModule object
    module = md.AnsibleModule(
        argument_spec=dict(
            terms=dict(required=True),
            var_options=dict(required=False),
            kwargs=dict(required=False),
        ),
    )

    # Create a AnsibleModuleDocFragment object
    fragment = mdf.AnsibleModuleDocFragment()

    # test run()