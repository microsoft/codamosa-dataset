

# Generated at 2022-06-23 11:39:10.291507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.inventory import Inventory

    # Below code from ansible.plugins.lookup.file.LookupModule
    def find_file_in_search_path(self, variables, search_path, file_name):
        # prepare the search_path
        if search_path is None:
            search_path = []

        if isinstance(search_path, MutableSequence):
            pass
        else:
            search_path = [search_path]

        # Add special handling for 'files' which was the default behavior
        path_backup = search_path
        search_path = []

# Generated at 2022-06-23 11:39:21.269849
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # import class
    from ansible.plugins.lookup import ini
    l = ini.LookupModule()

    # test read of a value using a regexp
    config = StringIO()
    config.write(u'[integration]\nuser1=ansible\nuser2=ansible\n')
    config.seek(0)
    cp = configparser.RawConfigParser(allow_no_value=True)
    cp.readfp(config)
    assert l.get_value('.*user1', 'integration', None, True) == ['ansible']

    # test read of a value
    config = StringIO()
    config.write(u'[integration]\nuser=ansible\n')
    config.seek(0)
    cp = configparser.RawConfigParser()
    cp.read

# Generated at 2022-06-23 11:39:32.448307
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(StringIO(b'[section1]\nkey1=value1\nkey2=value2\nkey3=value3'))
    # Test regexp
    assert lookup.get_value('.*', 'section1', 'default', True) == ['value1', 'value2', 'value3']
    # Test regexp with default
    assert lookup.get_value('.*', 'section2', 'default', True) == 'default'
    # Test non regexp
    assert lookup.get_value('key1', 'section1', 'default', False) == 'value1'
    # Test non regexp with default

# Generated at 2022-06-23 11:39:40.223266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with open('test_LookupModule_run.ini', 'w') as f:
        f.writelines([
            '[section1]\n',
            'user1=jdoe\n',
            'user2=jaoe\n',
            '[section2]\n',
            'user1=jdoe\n',
            'user2=jaoe\n',
        ])
    lookup = LookupModule()
    result = lookup.run(['user1', 'user2'], {}, file='test_LookupModule_run.ini', section='section1')
    assert result == ['jdoe', 'jaoe']

# Generated at 2022-06-23 11:39:47.298645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.parsing.vault import VaultLib

    test_values = ['global_var=10', 'global_var2=20', 'user=charles', 'password=foo']

    for term in test_values:
        params = _parse_params(term, {'file': 'users.ini', 'encoding': 'utf-8'})
        assert params[0] == term
        with open('users.ini', 'wb') as f:
            f.write(to_bytes(u'%s\n' % '\n'.join(test_values)))
        lookup = LookupModule()
        lookup.set_options({'file': 'users.ini'})

# Generated at 2022-06-23 11:39:57.187427
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # [section1]
    # key1=value1
    # key2=value2
    # [section2]
    # key3=value3
    # key4=value4
    cp = configparser.ConfigParser()
    cp.readfp(StringIO("[section1]\nkey1=value1\nkey2=value2\n[section2]\nkey3=value3\nkey4=value4"))
    lpm = LookupModule()
    lpm.cp = cp
    # Regexp on a section
    assert lpm.get_value("^key.*", "section1", "", True) == ["key1", "key2"]
    # Regexp on wrong section
    assert lpm.get_value("^key.*", "sectionX", "", True) == []
    # No regex

# Generated at 2022-06-23 11:39:59.529604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print(lookup.run([],{}))

# Generated at 2022-06-23 11:40:01.194224
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.cp is None
    assert lm is not None


# Generated at 2022-06-23 11:40:03.124201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:40:03.510373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:40:07.000292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert 'ini' in lookup.file_extensions, "Plugin does not support 'ini' file extension"
    assert 'properties' in lookup.file_extensions, "Plugin does not support 'properties' file extension"

# Generated at 2022-06-23 11:40:17.150695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModule:
        def __init__(self):
            self.cp = configparser.ConfigParser()
        def get_value(self, key, section, dflt, is_regexp):
            # Retrieve all values from a section using a regexp
            if is_regexp:
                return [v for k, v in self.cp.items(section) if re.match(key, k)]
            # Retrieve a single value
            try:
                value = self.cp.get(section, key)
            except configparser.NoOptionError:
                return dflt
            return value

    lm = LookupModule()
    lm.cp.readfp(StringIO("""
[section]
key1=value
key3=value3
    """))

# Generated at 2022-06-23 11:40:17.736086
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:40:25.708788
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Generate params
    re = False
    key = "user"
    section = "main"
    dflt = "root"
    is_regexp = re

    # Initialize the ini file
    config = StringIO()
    config.write("[main]\n")
    config.write("user=test\n")
    config.write("user=test2\n")
    config.write("user=test3\n")

    # Initialize the lookup module
    lm = LookupModule(loader=None, basedir=None, runner=None)
    lm.cp = configparser.ConfigParser()
    lm.cp.readfp(config)

    # Test get_value
    value = lm.get_value(key, section, dflt, is_regexp)

# Generated at 2022-06-23 11:40:36.068793
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_values = {'key': 'value', 'key1': 'value1'}
    cp = configparser.RawConfigParser(allow_no_value=True)
    cp.add_section('test')
    for k, v in test_values.items():
        cp.set('test', k, v)
    lm = LookupModule()
    lm.cp = cp
    # Test case sensitive
    # Test non regexp
    assert lm.get_value('key', 'test', '', False) == test_values['key']
    assert lm.get_value('Key', 'test', '', False) is None
    for k, v in test_values.items():
        assert lm.get_value(k, 'test', '', False) == v
    # Test regexp
    assert lm.get

# Generated at 2022-06-23 11:40:47.516536
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Retrieve file path
    filepath = os.path.dirname(os.path.abspath(__file__)) + '/../../../plugins/lookup/ini.py'
    # Read file
    with open(filepath, 'r') as fd:
        lines = fd.read()
    # Create StringIO later used to parse ini
    config = StringIO()
    # Open file using encoding
    contents, show_data = LookupBase._loader._get_file_contents(filepath)
    contents = to_text(contents, errors='surrogate_or_strict', encoding='utf-8')
    config.write(contents)
    config.seek(0, os.SEEK_SET)
    # Launch test

# Generated at 2022-06-23 11:41:00.313959
# Unit test for method get_value of class LookupModule

# Generated at 2022-06-23 11:41:11.722215
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class TestLookupModule(LookupModule):
        '''Class used to test get_value method'''
        def __init__(self):
            self.cp = configparser.ConfigParser()

    # Create a config parser object and load default configuration
    c = TestLookupModule()
    c.cp.read(os.path.join(os.path.dirname(__file__), 'ini_example.ini'))

    assert c.get_value('user', 'integration', '', False) == 'yannig'
    assert c.get_value('pass', 'integration', '', False) == 'yannigpwd'
    assert c.get_value('user', 'production', '', False) == 'root'
    assert c.get_value('pass', 'production', '', False) == 'rootpwd'



# Generated at 2022-06-23 11:41:13.602596
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.get_value('user', 'section', 'default', True) == []

# Generated at 2022-06-23 11:41:21.446190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule()
    lk.read_config_file = lambda: None
    lk.get_value = lambda k, s, dflt, rex: [k, s, dflt, rex]
    lk.find_file_in_search_path = lambda v, s, f: f
    lk.set_options(dict())
    lk._loader = LookupBase()
    lk._loader._get_file_contents = lambda f: [[''], '']
    try:
        lk.run([])
    except ValueError as e:
        assert "No section: 'global'".lower() in str(e).lower()
    assert lk.run(['k=v']) == [['k', 'global', '', False]]

# Generated at 2022-06-23 11:41:32.044774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # Config file used for the test
    TEST_INI_FILE = """
[global]
user = default_user

[integration]
user = integration_user

[production]
user = production_user
"""

    # Expected results
    expected_result_integration = ['integration_user']
    expected_result_production = ['production_user']
    expected_result_default = ['default_user']

    # Create LookupModule object
    lm = LookupModule()

    # Create lookup result list
    lr = []

    # Create a test file
    f = open("test", "w+")
    f.write(TEST_INI_FILE)
    f.close()


# Generated at 2022-06-23 11:41:43.379012
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    unit = LookupModule()
    test_key = 'user'
    test_section = 'test'
    test_dflt = 'test_dflt'
    test_is_regexp = True

    # Create StringIO later used to parse ini
    config = StringIO()

    # Fill the file
    config.write(u"[%s]\nuser=test_value\n" % test_section)
    config.seek(0, os.SEEK_SET)

    # Create parser
    unit.cp = configparser.ConfigParser()

    # Fill the parser
    unit.cp.readfp(config)

    # Test
    assert unit.get_value(test_key, test_section, test_dflt, test_is_regexp) == 'test_value'

    # Test section error
    assert unit

# Generated at 2022-06-23 11:41:54.528845
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class ConfigParser:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.section = {'key1':'value1', 'key2':'value2', 'key3':'value3'}

        def items(self, section):
            return self.section.items()

        def get(self, section, key):
            return self.section[key]

        def items(self, section):
            return self.section.items()

        def get(self, section, key):
            return self.section[key]

    # test regexp
    lookup_module = LookupModule(loader=None, basedir=None, run_once=False)
    lookup_module.cp = ConfigParser(allow_no_value=False)

# Generated at 2022-06-23 11:42:01.618524
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    """Tests LookupModule._get_value_re and _get_value_non_re."""

# Generated at 2022-06-23 11:42:12.015505
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    cfg = configparser.ConfigParser(allow_no_value=True)
    cfg.optionxform = to_native
    cfg.add_section('mysqld')
    cfg.set('mysqld', 'user', 'mysql')
    lookup_module.cp = cfg
    value = lookup_module.get_value("user", 'mysqld', "", False)
    assert value == 'mysql'

    cfg = configparser.ConfigParser(allow_no_value=True)
    cfg.optionxform = to_native
    cfg.add_section('mysqld')
    cfg.set('mysqld', 'user', 'mysql')
    lookup_module.cp = cfg

# Generated at 2022-06-23 11:42:23.688364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [u'user', u'password', u'foo=bar']
    paramvals = {'type': 'ini', 'encoding': 'utf-8', 'default': u'', 'section': u'global', 'allow_none': False, 'case_sensitive': False, 're': False, 'file': u'ansible.ini'}
    l = LookupModule()
    l.get_options = lambda: paramvals
    l.cp = configparser.ConfigParser(allow_no_value=paramvals.get('allow_no_value', paramvals.get('allow_none')))
    l.cp.readfp(StringIO(u'[global]\nuser=Yannig\npassword=secret'))
    assert l.run(terms) == [u'Yannig', u'secret', u'bar']



# Generated at 2022-06-23 11:42:35.720109
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule object
    lookup = LookupModule()

    # Create a defaultdict object
    kwargs = defaultdict()

    # Create a defaultdict object
    variables = defaultdict()

    # Create a str object
    terms = 'user=guest'

    # Create a configparser object
    configParser = configparser.ConfigParser()
    configParser.read('ansible.ini')
    lookup.cp = configParser

    # Create a str object
    path = 'ansible.ini'

    # Create a defaultdict object
    paramvals = defaultdict()

    # Set the default value for 'file' to 'ansible.ini'
    paramvals['file'] = 'ansible.ini'

    # Set the default value for 'type' to 'ini'
    paramvals['type'] = 'ini'

    # Set

# Generated at 2022-06-23 11:42:41.473353
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create config file
    config = StringIO()
    config.write(u'[section]\n')
    config.write(u'key1 = value1\n')
    config.write(u'key2 = value2\n')
    config.write(u'key3 = value3\n')
    config.write(u'key4 = value4\n')
    config.seek(0, os.SEEK_SET)

    # Create LookupModule
    lookup = LookupModule()

    # Parse file with configparser and give it to the LookupModule
    cp = configparser.ConfigParser()
    cp.readfp(config)
    lookup.cp = cp

    # Test get_value
    assert lookup.get_value('key1', 'section', None, False) == 'value1'

# Generated at 2022-06-23 11:42:42.831602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 11:42:47.475158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test LookupModule.run")
    lup = LookupModule()

    # Test with parameters specified
    terms = ["user=yperre", " section=integration", " file='test.ini'"]
    ret = lup.run(terms)
    assert ret == ["test"]

    # Test without parameters specified
    terms = ["test"]
    ret = lup.run(terms)
    assert ret == ["test"]

# Generated at 2022-06-23 11:42:57.885521
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import sys
    import shutil
    import tempfile
    import unittest

    if sys.version_info[:2] == (2, 6):
        import ConfigParser as configparser
    else:
        import configparser
    class TestLookupModuleGetValue(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            cls.working_dir = tempfile.mkdtemp(prefix="TestLookupModule", suffix="working_dir")
            cls.file_path = os.path.join(cls.working_dir, "file.ini")
            cls.cp = configparser.ConfigParser()
            cls.cp.add_section("section")
            cls.cp.set("section", "key", "value")


# Generated at 2022-06-23 11:43:00.307047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert len(l.cp.sections()) == 0



# Generated at 2022-06-23 11:43:09.504734
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # An ini file with only 2 sections
    # [section1]
    # key1=value1
    # [section2]
    # key2=value2
    ini_file = configparser.ConfigParser()
    ini_file.optionxform = to_native
    ini_file.readfp(StringIO("[section1]\nkey1=value1\n[section2]\nkey2=value2"))

    # A lookup module
    l = LookupModule()
    l.cp = ini_file

    assert 'value1' == l.get_value('key1', 'section1', '', False)
    assert 'value2' == l.get_value('key2', 'section2', '', False)

# Generated at 2022-06-23 11:43:22.634798
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Initialize lookupModule object
    lookupModule = LookupModule()
    # Initialize config parser
    lookupModule.cp = configparser.ConfigParser()
    # add section to config parser
    lookupModule.cp.add_section('section1')
    # add key to config parser
    lookupModule.cp.set('section1', 'key1', 'value1')
    lookupModule.cp.set('section1', 'key2', 'value2')
    lookupModule.cp.set('section1', 'key3', 'value3')
    assert lookupModule.get_value('key1', 'section1', 'default', False) == 'value1'
    assert lookupModule.get_value('key4', 'section1', 'default', False) == 'default'

# Generated at 2022-06-23 11:43:31.461609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a ModuleUtilsPlugin which has a method find_file_in_search_path
    class ModuleUtilsPlugin:
        def find_file_in_search_path(self, variables, path, filename):
            return "test.ini"

    # Create a MutableSequence object
    class MutableSequence(object):
        def __init__(self, value):
            self.value = value

    # Create a LookupBase object
    class LookupBase:
        def __init__(self):
            self.cp = configparser.ConfigParser(allow_no_value=True)
            self.cp.optionxform = to_native
            self._loader = ModuleUtilsPlugin()

        # Method set_options

# Generated at 2022-06-23 11:43:41.220662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    import contextlib
    @contextlib.contextmanager
    def get_lookup(arg, loader=None, templar=None, shared_loader_obj=None, **kwargs):
        lookup = LookupModule(loader=loader, basedir=arg, **kwargs)
        yield lookup
    lookup = LookupBase()
    lookup.get_loader =  lambda self, basedir: get_lookup(basedir)
    class TestException(Exception):
        pass

    # key, section, dflt, is_regexp, result

# Generated at 2022-06-23 11:43:51.097318
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'key3=value3\n')
    config.seek(0, os.SEEK_SET)
    lookup.cp.readfp(config)
    assert lookup.get_value('key1', 'section1', False, False) == 'value1'
    assert lookup.get_value('key2', 'section1', False, False) == 'value2'
    assert lookup.get_value('key4', 'section1', 'toto', False) == 'toto'
    assert lookup.get_

# Generated at 2022-06-23 11:43:52.092947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule == LookupModule

# Generated at 2022-06-23 11:43:59.875988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    def test_configparser(self):
        mycp = configparser.ConfigParser()
        mycp.readfp(StringIO(u'[java_properties]\nkey1=value1'))
        return mycp

    def test_get_value(self, value, config, section, dflt):
        if value == "value1":
            assert config.values(section) == dflt

    def test_find_file_in_search_path(self, file, config, section, dflt):
        if os.path.isfile(file):
            assert config.values(section) == dflt

    def test_run(self, paramvals):
        assert isinstance(paramvals, dict)

# Generated at 2022-06-23 11:44:07.236344
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing term without any option:
    # term = 'key1'
    # Testing term with section specified:
    # term = 'section2 key2'
    # Testing term with multiple key specified:
    # term = 'section1 key1 section2 key2'
    # Testing term with option file and section specified:
    # term = 'file=users.ini section=integration key1'

    # Init object LookupModule
    lookup = LookupModule()

    # Init parameters
    terms = ['key1', 'section2 key2', 'section1 key1 section2 key2', 'file=users.ini section=integration key1']
    result = ['value1', 'value2', ['value1', 'value2'], 'yperre']

    # Get result
    assert lookup._run(terms, {}) == result

    # Init error

# Generated at 2022-06-23 11:44:17.490392
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    # Initialize a cp with sections, options and values
    cp = configparser.ConfigParser(allow_no_value=False)
    cp.add_section('section1')
    cp.set('section1', 'k1', 'abc')
    cp.set('section1', 'k2', '123')
    cp.set('section1', 'k3', 'tom')
    cp.set('section1', 'k4', 'jerry')
    cp.add_section('section2')
    cp.set('section2', 'k1', 'ABC')
    cp.set('section2', 'k2', '456')
    cp.set('section2', 'k3', 'Jerry')
    cp.set('section2', 'k4', 'Tom')

    # 1, get value with

# Generated at 2022-06-23 11:44:18.943110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()



# Generated at 2022-06-23 11:44:24.413895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test method run of class LookupModule
    # Create LookupModule instance
    # test1.ini file
    # [section1]
    # key = 1
    # Test return of method run
    ini = LookupModule()
    ini.cp = configparser.ConfigParser()
    assert ini.run(['key', 'file=test1.ini', 'section=section1']) == ['1']
    assert ini.run(['key', 'file=test1.ini', 'section=section2', 'default=1']) == ['1']
    # test2.ini file
    # [section2]
    # prop1=1
    # prop2=2
    # prop3=3

# Generated at 2022-06-23 11:44:26.275397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 11:44:35.677893
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_section = 'test_section'
    test_value = 'test_value'
    dflt = 'default'
    cp = configparser.ConfigParser()
    cp.add_section(test_section)
    cp.set(test_section, 'test_key_regexp', test_value)
    cp.set(test_section, 'test_key', test_value)

    lookup = LookupModule()
    lookup.cp = cp
    assert lookup.get_value('test_key', test_section, dflt, False) == test_value
    assert lookup.get_value('.*_key', test_section, dflt, True) == [test_value]



# Generated at 2022-06-23 11:44:45.852202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock ansible variables
    variables={
        'ansible_search_path': '/home/ansible/playbooks/group_vars',
        'ansible_loader': '_'
    }

    # Mock terms
    terms=[]

    # Mock files
    files={
        u'ansible.ini': u'[global]\n#Test lookup ini plugin\nansible_user = yperre\n',
        u'settings.ini': u'[jenkins]\nuser = yperre\n'
    }

    # Mock options

# Generated at 2022-06-23 11:44:58.637257
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.crypto import constant_time_compare

    vault_pwd = 'pass'
    vault_sec = VaultLib(vault_pwd)
    enc_text = vault_sec.encrypt('something to encrypt')
    enc_text = constant_time_compare('$ANSIBLE_VAULT;' + enc_text, '$ANSIBLE_VAULT;' + enc_text)

    arrterms = ['key', 'key=value']
    for term in arrterms:
        lookup_module = LookupModule()

        lookup_module.set_options(dict(file='ansible.ini', section='test', case_sensitive=True, allow_no_value=True))

# Generated at 2022-06-23 11:45:05.854648
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(StringIO(u'[my_section]\nmy_key=my_value\n'))

    assert lookup_module.get_value(u'my_key', u'my_section', u'my_default_value') == u'my_value'

    assert lookup_module.get_value(u'unknown_key', u'my_section', u'my_default_value') == u'my_default_value'

    assert set(lookup_module.get_value(u'my_.*', u'my_section', u'my_default_value', is_regexp=True)) == set(['my_key', 'my_value'])

    assert lookup_module.get

# Generated at 2022-06-23 11:45:17.009143
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    ini_file = StringIO()
    ini_file.write("""
[section1]
key1=value1
key2=value2
key3=value3

[section2]
key1=value1""")
    ini_file.seek(0, os.SEEK_SET)
    lookup.cp.readfp(ini_file)
    assert lookup.get_value("key1", "section1", None, False) == "value1"
    assert lookup.get_value("key2", "section1", None, False) == "value2"
    assert lookup.get_value("key1", "section2", None, False) == "value1"

# Generated at 2022-06-23 11:45:17.727952
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:45:21.478651
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # init
    term = 'test'
    section = 'test'
    dflt = 'default'
    is_regexp = True
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    lm.cp.add_section(section)

    # case 1 - return default value
    assert lm.get_value(term, section, dflt, is_regexp) == dflt

    # case 2 - return single value
    lm.cp.set(section, term, 'test return')
    assert lm.get_value(term, section, dflt, is_regexp) == 'test return'

    # case 3 - return multiple values
    lm.cp.set(section, 'test1', 'test return 1')

# Generated at 2022-06-23 11:45:31.579773
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class IniParserStub(object):
        def __init__(self):
            self.section_dict = {}
            self.section_dict['section1'] = {'key1': 'val1', 'key2': 'val2'}

        def __getitem__(self, key):
            if key in self.section_dict:
                return self.section_dict[key]

        def __setitem__(self, key, value):
            self.section_dict[key] = value

        def items(self, section):
            return self.section_dict[section].items()

    class LookupModuleStub(LookupModule):

        def __init__(self):
            self.cp = IniParserStub()


# Generated at 2022-06-23 11:45:34.178082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Check if the inherited class has been created
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-23 11:45:45.743893
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os

    import pytest

    from ansible.plugins.loader import lookup_loader

    LookupModule = lookup_loader.get('ini')

    terms = ['user', 'password']
    file_name = os.path.join(os.path.dirname(__file__), 'ansible.ini')
    paramvals = {
        'file': file_name,
        'section': 'integration',
    }
    test = LookupModule()
    test.cp = configparser.ConfigParser()
    test.cp.read(file_name)

    assert test.get_value(terms[0], paramvals['section'], None, False) == 'test_user'
    assert test.get_value(terms[1], paramvals['section'], None, False) == 'test_password'

# Generated at 2022-06-23 11:45:54.600435
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    tmp_dir = basic.AnsibleModule(argument_spec={}).tmpdir
    data_root = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'plugins', 'lookup', 'data')
    plugin = LookupModule()

    path = os.path.join(tmp_dir, 'test.ini')
    config_file = open(path, 'w')

# Generated at 2022-06-23 11:46:06.831113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy class to simulate LookupBase
    class DummyLookupBase():
        def _get_file_contents(self, path):
            config = '[test]\n'
            config += 'test_default_case=test\n'
            config += 'tESt_lower_case=test\n'
            config += 'TEST_upper_case=test\n'
            return (config, None)

    # Dummy class to simulate configparser
    class DummyConfigParser(configparser.RawConfigParser):
        def __init__(self, *args, **kwargs):
            configparser.RawConfigParser.__init__(self, *args, **kwargs)
            self.case_sensitive_parameters = {}


# Generated at 2022-06-23 11:46:16.838608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with open("test.ini", "w") as f:
        f.write("""[section1]
prop1=value1
prop2=value2
prop3=value3

[section2]
prop4=value4
prop5=value5
prop6=value6

[section3]
prop7=value7
""")

    lookup = LookupModule()
    assert lookup.run(terms=["prop1"], variables={}, **{}) == ["value1"]
    assert lookup.run(terms=[], variables={}, **{}) == []
    assert lookup.run(terms=["prop3"], variables={}, **{}) == ["value3"]
    assert lookup.run(terms=["prop4"], variables={}, **{}) == ["value4"]
    assert lookup.run(terms=["prop5"], variables={}, **{})

# Generated at 2022-06-23 11:46:26.227621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['user=yannig', 'key', 'port', 'db=pgsql', 'user=mike']
    variables = {'ansible_user': 'mike'}
    kwargs = {'file': 'test.ini', 'section': 'mysection', 'default': 'example', 're': False, 'type': 'ini',
              'encoding': 'utf-8', 'allow_no_value': False}
    assert lookup_module.run(terms, variables, **kwargs) == ['yannig', '', '1234', 'pgsql', 'mike']

# Generated at 2022-06-23 11:46:36.563843
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lu = LookupModule()
    lu.cp = configparser.ConfigParser()
    lu.cp.readfp(StringIO('[section]\nparam1=value1\nparam2=value2\nparam3=value3\n'))
    result = lu.get_value('param1', 'section', 'dflt', False)
    assert result == 'value1'
    result = lu.get_value('param2', 'section', 'dflt', False)
    assert result == 'value2'
    result = lu.get_value('param3', 'section', 'dflt', False)
    assert result == 'value3'
    result = lu.get_value('param4', 'section', 'dflt', False)
    assert result == 'dflt'
    result = lu.get_

# Generated at 2022-06-23 11:46:45.850396
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Testing with a regexp
    l = LookupModule()
    l.cp = configparser.ConfigParser()
    l.cp.add_section('Section')
    l.cp.set('Section', 'RegexpKey1', 'RegexpValue1')
    l.cp.set('Section', 'RegexpKey2', 'RegexpValue2')
    assert l.get_value('RegexpKey[0-9]', 'Section', None, True) == ['RegexpValue1', 'RegexpValue2']
    assert l.get_value('RegexpKey[3-9]', 'Section', None, True) == []
    assert l.get_value('RegexpKey[1-2]', 'Section', None, True) == ['RegexpValue1', 'RegexpValue2']
   

# Generated at 2022-06-23 11:46:52.735131
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    file = StringIO()
    file.write("""
    ; comment
    [section1]
    key1 = ansible
    key2 = value2
    key3 = value3
    
    # comment
    [section2]
    key3 = value3
    key4 = value4
    key5 = value5
    """)
    file.seek(0, os.SEEK_SET)
    lookup.cp.readfp(file)

    assert lookup.get_value('key1', 'section1', None, False) == 'ansible'
    assert lookup.get_value('key3', 'section1', 'test', False) == 'value3'
    assert lookup.get_value('key3', 'section1', 'test', True)

# Generated at 2022-06-23 11:47:05.181083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_bytes

    test_data = b"""
[global]
user=root
[user]
creation=1000
[database]
user=123
[my_section]
user=456
"""
    with open('/tmp/test.ini', 'w') as f:
        f.write(test_data.decode('utf-8'))

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    lookup = LookupModule()

# Generated at 2022-06-23 11:47:13.563997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    path = 'unittest/files/ansible.ini'
    if not os.path.isfile(path):
        path = 'files/ansible.ini'
    f = open(path)
    config = StringIO()
    config.write('[global]\n')
    config.write(f.read())
    f.close()
    config.seek(0, os.SEEK_SET)
    lookup_module.cp.readfp(config)
    assert lookup_module.get_value('user', 'global', None, False) == 'root'
    res = lookup_module.get_value(r'u*', 'global', None, True)
    assert ('user' in res) and ('url' in res)

# Generated at 2022-06-23 11:47:19.881532
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.set_options(var_options='ansible.ini', direct=True)
    varvals = lm.get_options()
    # Check file names
    assert varvals['file'] == 'ansible.ini'
    # Check section names
    assert varvals['section'] == 'global'

# Generated at 2022-06-23 11:47:30.401976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization
    params = {
        'type': 'ini',
        'file': 'users.ini',
        'section': 'integration',
        'default': '',
        're': False,
        'encoding': 'utf-8',
        'case_sensitive': False,
        'allow_no_value': False,
    }
    parser = configparser.ConfigParser()
    parser.read('tests/files/users.ini')
    module = LookupModule()

    # Test with regexp
    term = 'log*'
    setattr(module, 'cp', parser)
    assert (module.get_value(term, params['section'], params['default'], True) == ['login', 'logout'])
    # Test with no regexp
    term = 'user'

# Generated at 2022-06-23 11:47:39.542760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    if lookup.run([':'], variables=None, file='users.ini') != ['']:
        raise Exception("test fail")

    if lookup.run(['user'], variables=None, file='users.ini', section='integration') != ['coucou']:
        raise Exception("test fail")

    if lookup.run(['user'], variables=None, file='users.ini', section='production') != ['toto']:
        raise Exception("test fail")

    if lookup.run(['user.name'], variables=None, file='user.properties', type='properties') != ['Yannig']:
        raise Exception("test fail")


# Generated at 2022-06-23 11:47:49.426259
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookupModule = LookupModule()
    cp = configparser.ConfigParser()
    cp.read_string("""
[section1]
key1=value1
key2=value2
[section2]
key3=value3
key4=value4
""")
    lookupModule.cp = cp
    values = lookupModule.get_value('key', 'section1', None, False)
    assert values == 'value1', "get_value should return 'value1'"

    values = lookupModule.get_value('.*', 'section1', None, True)
    assert values == ['value1', 'value2'], "get_value should return ['value1', 'value2']"

# Generated at 2022-06-23 11:48:00.486481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate lookuper
    l = LookupModule()

    # Read config file
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'key3=value3\n')
    config.write(u'\n')
    config.write(u'[section2]\n')
    config.write(u'key1=value4\n')
    config.write(u'key2=value5\n')
    config.write(u'key3=value6\n')
    config.write(u'\n')
    config.write(u'[section3]\n')

# Generated at 2022-06-23 11:48:07.815458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # Create a fake ansible options
    class FakeOptions():

        def __init__(self, encoding='utf-8', section='global', default='', re=False):
            self.encoding = encoding
            self.section = section
            self.default = default
            self.re = re

    class FakeTerm():
        def __init__(self, key):
            self.key = key

    class FakeModule():
        """Fake class for ansible module"""
        def __init__(self):
            self.params = {'file': 'test.ini', 'type': 'ini', 'ansible_facts': {'ansible_env': {}}}
            self.basedir = '.'
            self.tmpdir = '.'

    # create fake ansible variable

# Generated at 2022-06-23 11:48:20.191168
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Initialize cp object
    cp = configparser.ConfigParser()
    cp.read(os.path.join(os.path.dirname(__file__), 'data/users.ini'))

    # Initialize lookup object
    lookup = LookupModule()
    # Define cp attribute
    lookup.cp = cp

    # Case 1
    key = 'user'
    section = 'integration'
    dflt = 'dflt'
    is_regexp = False
    value = lookup.get_value(key, section, dflt, is_regexp)
    assert value == 'integration user'

    # Case 2
    key = 'user'
    section = 'production'
    dflt = 'dflt'
    is_regexp = False

# Generated at 2022-06-23 11:48:21.811928
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule()
    assert isinstance(cls, LookupModule)


# Generated at 2022-06-23 11:48:33.836278
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from collections import defaultdict
    cp = configparser.ConfigParser()

    # Create an instance of class LookupModule
    lookup = LookupModule()

    # Give the instance cp, the value of the variable cp
    lookup.cp = cp

    # Declare a variable with a section and keys
    sections = {}

    # Add a section to the variable sections
    sections['section'] = defaultdict()

    # Add a key to the section section
    sections['section']['key'] = 'value'

    # Add the variable sections to the variable cp
    cp.sections = sections

    # Test the method get_value with key, section, dflt and is_regexp value
    assert lookup.get_value('key', 'section', '', False) == 'value'

# Generated at 2022-06-23 11:48:45.085402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # 'file' is not exists
    try:
        LM = LookupModule(None, 'ansible.ini', {'file': 'a'})
        LM.run(['a'])
        assert False
    except AnsibleLookupError:
        assert True

    # 'file' is exists
    try:
        LM = LookupModule(None, 'ansible.ini', {'file': './ansible/plugins/lookup/ini.py'})
        LM.run(['a'])
        assert False
    except AnsibleOptionsError:
        assert True

    # 'section' is not exists

# Generated at 2022-06-23 11:48:54.192113
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    check = LookupModule()

    # Use of regexp to get all values
    check.cp = configparser.ConfigParser()
    check.cp.add_section('section1')
    check.cp.set('section1', 'test1', 'value1')
    check.cp.set('section1', 'test2', 'value2')
    assert check.get_value('.*', 'section1', '', True) == ['value1', 'value2']

    # Use of regexp to get all values with default value
    assert check.get_value('.*', 'section1', '', True) == ['value1', 'value2']

    # Use of regexp to get all values in a section wich does not exist
    assert check.get_value('.*', 'section2', '', True) == []

    # Use of

# Generated at 2022-06-23 11:49:05.679697
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a LookupModule object
    lm = LookupModule()
    # Create a StringIO later used to parse ini
    config = StringIO()
    # Write a section in the StringIO
    config.write(u'[section1]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'key3=value3\n')
    config.write(u'key4=value4\n')
    config.write(u'key5=value5\n')
    config.seek(0, os.SEEK_SET)
    # Read the StringIO using an instance of configparser.ConfigParser
    lm.cp = configparser.ConfigParser()
    lm.cp.readfp(config)
