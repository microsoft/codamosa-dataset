

# Generated at 2022-06-23 11:39:07.200833
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tag: <class 'ansible.errors.AnsibleError'>
    # Tags: <class 'ansible.errors.AnsibleFileNotFound'>
    # Tags: <class 'ansible.errors.AnsibleOptionsError'>
    # Tags: <class 'ansible.errors.AnsibleLookupError'>
    # Tags: <class 'ansible.errors.AnsibleParserError'>
    # Tags: <class 'ansible.errors.AnsibleUndefinedVariable'>
    # Tags: <class 'ansible.errors.AnsibleUnicodeError'>
    pass

# Generated at 2022-06-23 11:39:14.594734
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import tempfile
    import stat
    import shutil

    section = "global"
    key = "user"
    value = "yannigperre"
    default = "no user"
    is_regexp = False

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary ini file
    filename = os.path.join(temp_dir, 'test.ini')
    with open(filename, "w") as ini_file:
        ini_file.write("[{}]\n{}={}\n".format(section, key, value))

    # Instantiate class LookupModule
    lookup_plugin = LookupModule()

    # Call get_value method
    lookup_plugin.cp = configparser.ConfigParser()

# Generated at 2022-06-23 11:39:15.554105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 11:39:17.987374
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule.get_value(None, None, None, None)
    LookupModule.run(None, None, None)

# Generated at 2022-06-23 11:39:19.826730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test no file
    lookup = LookupModule()
    assert lookup is not None



# Generated at 2022-06-23 11:39:28.069058
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_ini = StringIO(u"""
[section1]
name=value
key=value1
key1=value2

[section2]
key=value3
""")
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    lm.cp.readfp(test_ini)

    assert ["value1", "value2"] == lm.get_value(
        "key", paramvals['section'], paramvals['default'], paramvals['re'])



# Generated at 2022-06-23 11:39:36.298661
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This function tests the constructor of class LookupModule and its method Check()
    """

    # Constructor
    lm = LookupModule()

    # Get_option: check that default values are set
    var = lm.get_options()
    if "file" in var:
        if var["file"] != "ansible.ini":
            raise AssertionError("file should have the value 'ansible.ini'")
    else:
        raise AssertionError("file should have the value 'ansible.ini'")

    if "re" in var:
        if var["re"] != False:
            raise AssertionError("re should have the value False")
    else:
        raise AssertionError("re should have the value False")


# Generated at 2022-06-23 11:39:37.550023
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')

# Generated at 2022-06-23 11:39:45.753414
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Retrieve a value
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section('section1')
    lookup.cp.set('section1', 'key1', 'value1')
    assert lookup.get_value('key1', 'section1', 'default', False) == 'value1'
    # Retrieve a value for not defined section
    assert lookup.get_value('key1', 'section2', 'default', False) == 'default'
    # Retrieve all values for a defined section using a regexp
    lookup.cp.add_section('section2')
    lookup.cp.set('section2', 'key1', 'value1')
    lookup.cp.set('section2', 'key2', 'value2')

# Generated at 2022-06-23 11:39:51.883897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section('global')
    cp.set('global', 'foo', 'bar')
    cp.set('global', 'foz', 'baz')
    lookup_instance.cp = cp
    print(lookup_instance.get_value('foo', 'global', None, False))
    print(lookup_instance.get_value('foo', 'global', None, True))

# Generated at 2022-06-23 11:40:01.442440
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    look = LookupModule()  # noqa
    # Create a new configparser object
    cp = configparser.RawConfigParser()
    # Add a new section with name section
    cp.add_section('section')
    # Add a new key/value to section
    cp.set('section', 'key1', 'value1')
    cp.set('section', 'key2', 'value2')
    cp.set('section', 'key3', 'value3')
    cp.set('section', 'key4', 'value4')
    cp.set('section', 'key5', 'value5')
    # Set configparser object to LookupModule class
    look.cp = cp
    # Test if the method return the right value
    assert look.get_value('key1', 'section', None, False) == 'value1'
    #

# Generated at 2022-06-23 11:40:11.986973
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class FakeConfig(configparser.ConfigParser):
        def __init__(self, *args, **kwargs):
            super(FakeConfig, self).__init__(*args, **kwargs)

# Generated at 2022-06-23 11:40:21.739582
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Happy path, section and key exits, no regexp
    lookupModule = LookupModule()
    parser = configparser.ConfigParser()
    parser.add_section("section")
    parser.set("section","key","value")
    lookupModule.cp = parser
    result = lookupModule.get_value("key","section","","")
    assert result == "value"
    # Section exists, key doesn't
    lookupModule = LookupModule()
    parser = configparser.ConfigParser()
    parser.add_section("section")
    parser.set("section","key","value")
    lookupModule.cp = parser
    result = lookupModule.get_value("wrongkey","section","","")
    assert result == ""
    # Section doesn't exist
    lookupModule = LookupModule()
    parser = configparser.ConfigParser()

# Generated at 2022-06-23 11:40:25.913568
# Unit test for constructor of class LookupModule
def test_LookupModule():
    file = open("testfiles/ansible.ini")
    test_cp = configparser.ConfigParser(allow_no_value=True)
    test_cp.readfp(file)
    assert(test_cp.sections() == ['global'])


# Generated at 2022-06-23 11:40:36.209705
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # If a key is not found, defaults to the default value
    # If the default value is empty, returns None
    test_default = "default value"
    assert(LookupModule.get_value("test", "test", test_default, False) == test_default)
    assert(LookupModule.get_value("test", "test", "", False) is None)
    assert(LookupModule.get_value("test", "test", [], False) == [])

    # When a key is found, returns its value
    configp = configparser.ConfigParser()
    configp.add_section("test")
    configp.set("test", "test", "value")

    assert(LookupModule.get_value("test", "test", test_default, False, configp) == "value")

# Generated at 2022-06-23 11:40:47.628629
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import unittest
    from StringIO import StringIO

    from ansible.module_utils.six import StringIO

    class TestLookupModule(unittest.TestCase):

        TEST_INI_FILE = StringIO("""
            [global]
            b = world
            [section]
            a = hello
            [section1]
            c = foo
            d = bar
            [section2]
            c = bar
            d = foo
        """)

        def setUp(self):
            self.lm = LookupModule()
            self.lm.cp = configparser.ConfigParser()
            self.lm.cp.readfp(self.TEST_INI_FILE)


# Generated at 2022-06-23 11:41:00.392728
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    config = configparser.RawConfigParser()
    config.add_section('main')
    config.set('main', 'd', "1")
    config.set('main', 'a', "2")
    config.set('main', 'b', "3")
    config.set('main', 'c', "4")
    config.set('main', 'e', "5")
    lookup_module.cp = config
    assert lookup_module.get_value("a", "main", '', False) == "2"
    assert lookup_module.get_value("a", "main", '', True) == "2"
    assert lookup_module.get_value("d", "main", '', False) == "1"

# Generated at 2022-06-23 11:41:11.824422
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.parsing.dataloader import DataLoader

    cp = configparser.ConfigParser()
    cp.add_section("regular_section")
    cp.set("regular_section", "key1", "value11")
    cp.set("regular_section", "key2", "value12")
    cp.set("regular_section", "key3", "value13")
    cp.set("regular_section", "key4", "value14")

    lu = LookupModule(loader=DataLoader())
    lu.cp = cp

    # Test regular section with regular key
    assert lu.get_value("key1", "regular_section", "default_value", False) == "value11"
    # Test regular section with regexp key

# Generated at 2022-06-23 11:41:20.458644
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Inits
    default_encoding = "utf-8"
    default_file = "ansible.ini"
    default_type = "ini"
    default_section = "global"
    default_key = "user"
    default_value = "test"
    default_param_value = "test"

    # Create an instance
    lkup = LookupModule()

    # Set options
    lkup.set_options({'encoding': default_encoding, 'file': default_file, 'type': default_type, 'section': default_section})

    # Read test file
    test_file = StringIO()
    test_file.write(u'[global]\n')
    test_file.write(u'user = test\n')

# Generated at 2022-06-23 11:41:31.692559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for test_input, expected in test_LookupModule_run_values:
        actual = LookupModule().run(test_input, dict())
        assert actual == expected, 'LookupModule().run(%s, {}) => %s. expected: %s' % (test_input, actual, expected)

# Unit test values

# Generated at 2022-06-23 11:41:33.022020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run([]) == []


# Generated at 2022-06-23 11:41:38.956760
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser()
    cp.readfp(StringIO('[section1]\nkey1=value1\nkey2=value2\n[section2]\nkey1=value1\nkey2=value2\n'))
    lm = LookupModule()
    lm.cp = cp
    assert lm.get_value('key1', 'section1', 'default', False) == 'value1'
    assert lm.get_value('key2', 'section1', 'default', False) == 'value2'
    assert lm.get_value('key3', 'section1', 'default', False) == 'default'
    assert lm.get_value(re.compile('^key1$'), 'section1', 'default', True) == ['value1']
    assert lm.get

# Generated at 2022-06-23 11:41:44.785161
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    assert lookup._deprecate_inline_kv() is None

    assert lookup._plugin_options is None
    lookup.set_options(var_options={}, direct={})
    assert lookup._plugin_options is not None

    assert lookup._plugin_options['allow_none']
    assert lookup._plugin_options['case_sensitive']
    assert lookup._plugin_options['default'] == ''
    assert lookup._plugin_options['encoding'] == 'utf-8'
    assert lookup._plugin_options['file'] == 'ansible.ini'
    assert lookup._plugin_options['re']
    assert lookup._plugin_options['section'] == 'global'
    assert lookup._plugin_options['type'] == 'ini'

    # test _parse_params
    term = 'key=value'
    paramvals = lookup

# Generated at 2022-06-23 11:41:55.472002
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import os
    import tempfile

    # Generate ini file
    f_ini = tempfile.NamedTemporaryFile(delete=False)
    f_ini.write("""[DEFAULT]
    value1=1
    value2=2
    value3=3
    [section1]
    value11=11
    value12=12
    value13=13
    [section2]
    value21=21
    value22=22
    value23=23
    """)
    f_ini.close()

    # Test ini retrieval
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    lm.cp.read(f_ini.name)

    assert lm.get_value("value1", "DEFAULT", None, False) == '1'
    assert l

# Generated at 2022-06-23 11:41:56.946675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module



# Generated at 2022-06-23 11:42:05.328652
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    # Test with exact match
    assert lookup.get_value('user', 'section1', 'default', False) == 'admin'
    # Test with regexp
    assert lookup.get_value('u.*', 'section1', 'default', True) == ['admin', 'postgres']
    # Test with missing key and default value
    assert lookup.get_value('user2', 'section1', 'default', False) == 'default'
    # Test with un-existing section
    assert lookup.get_value('user', 'section2', 'default', False) == 'default'

# Generated at 2022-06-23 11:42:14.615130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.ini import LookupModule
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils._text import to_text, to_native
    
    # Create a LookupModule object
    lookup = LookupModule()
    
    # Create a configparser object
    cp = configparser.ConfigParser()
    cp.readfp(open('input.ini'))
    
    # Update the config parser object
    lookup.cp = cp
    
    # Get the value
    lookup.get_value('global', 'global', '', False)
    print(lookup.get_value('user', 'production', '', False))
    
    # Get the value by regex
    lookup.get_value('.*', 'production', '', True)
    
# Unit

# Generated at 2022-06-23 11:42:17.745913
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        myLookup = LookupModule()
    except LookupError as e:
        print("Lookup error: " + str(e))


# Generated at 2022-06-23 11:42:27.679866
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test with a no value property
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(StringIO(u"[section1]\nkey1=value1\nkey2\nkey3=value3"))

    assert lookup.get_value("key2", "section1", "", False) == ""

    # Test with a regexp
    assert lookup.get_value(".*", "section1", "", True) == ["value1", "", "value3"]

    # Test with a no matching regexp
    assert lookup.get_value(".*", "section1", "", True) == ["value1", "", "value3"]

    # Test when the key is not found with default value
    assert lookup.get_value("key4", "section1", "", False)

# Generated at 2022-06-23 11:42:39.497286
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Arrange
    # A simple INI file
    inifile = """
[section1]
firstname1=John
firstname2=Mike
firstname3=Skye
[section2]
firstname4=Joe
firstname5=Lily
firstname6=Andy
"""
    # The INI file as a file-like stream
    config = StringIO(inifile)
    # The INI parser
    cp = configparser.ConfigParser()
    # Read the INI file
    cp.readfp(config)
    # The value where to store the result
    value = None
    # Try to read the value in the INI file
    try:
        value = cp.get('section1', 'firstname1')
    except configparser.NoOptionError:
        value = None
    # Check that the value has been

# Generated at 2022-06-23 11:42:40.097627
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Test class constructor
    assert(LookupModule)

# Generated at 2022-06-23 11:42:41.623985
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:42:53.565502
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test run
    print("test run")
    # create a mock configuration for a section
    config = StringIO()
    config.write("[section]\n")
    config.write("numbers=one,two,three,four\n")
    config.write("string=foo\n")
    config.seek(0, os.SEEK_SET)
    # initialize LookupModule class
    lk = LookupModule()
    lk.set_options(var_options=None, direct={"file": None, "encoding": "utf-8", "section": "section"})
    # create the configuration parser (cp)
    cp = configparser.ConfigParser()
    cp.readfp(config)
    lk.cp = cp
    # test get_value method with a regexp
    numbers = lk.get_

# Generated at 2022-06-23 11:43:05.950822
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Retrieve a non existing value
    test_section = 'test'
    test_key = 'user'
    test_dflt = 'root'
    test_is_regexp = False
    test_result = 'root'
    test_cp = configparser.ConfigParser()
    test_cp.read_file(open("/etc/passwd", "r"))
    ret = LookupModule.get_value(test_cp, test_key, test_section, test_dflt, test_is_regexp)
    assert(ret == test_result)

    # Retrieve a single value
    test_section = 'test'
    test_key = 'user'
    test_dflt = ''
    test_is_regexp = False
    test_result = 'root'

# Generated at 2022-06-23 11:43:15.644707
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["user"]

    path = "/Users/yannig/ansible/ansible/test/unit/module_utils/ansible_test/data/ini.ini"
    cp = configparser.ConfigParser()
    config = StringIO(u"""
[section1]
user=Yannig
password=123456789
[section2]
user=John
password=abc
""")
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)

    assert LookupModule(cp, path).run(terms) == ["Yannig"]


# Generated at 2022-06-23 11:43:24.390345
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_options() == {'encoding': 'utf-8', 'case_sensitive': False, 'section': 'global', 're': False, 'default': '', 'file': 'ansible.ini', 'type': 'ini'}
    assert l.get_value('password1', 'global', 'default', False) == 'default'
    assert l.get_value('password2', 'global', 'default', True) == 'default'
    assert l.get_value('password3', 'global', 'default', True) == ['password3']


# Generated at 2022-06-23 11:43:25.808004
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    return test_lookup

# Generated at 2022-06-23 11:43:36.682718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    lm = LookupModule()

    # LookupModule._parse_params
    # 1.1
    term = 'key1=value1 key2=value2'
    paramvals = {'key1': '', 'key2': '', 'file': '', 'section': '', 're': '', 'type': '', 'default': '', 'encoding': ''}
    result = [u'key1=value1', u'key2=value2']
    assert result == lm._parse_params(term, paramvals)

    # 1.2
    term = 'key1 =  value1'
    result = [u'key1 =  value1']
    assert result == lm._parse_params(term, paramvals)

# Generated at 2022-06-23 11:43:45.891509
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    from collections import defaultdict

    class LookupMock(LookupModule):

        def __init__(self, cp):
            self.cp = cp

        def get_value(self, key, section, dflt, is_regexp):
             return super(LookupMock, self).get_value(key, section, dflt, is_regexp)

    cp = configparser.RawConfigParser()
    cp.read("tests/unit/utils/fixtures/test.ini")

    l = LookupMock(cp)

    # Test get_values success
    assert l.get_value("user_admin", "global", "unknown", False) == "admin"
    assert l.get_value("user_admin", "global", "unknown", True) == "admin"

# Generated at 2022-06-23 11:43:56.597138
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ###############
    # unit test for 'ini' type
    terms = [u'section1', u'section2']
    vars = [u'var1', u'var2']
    values = [u'value1', u'value2']

    # Prepare file content

# Generated at 2022-06-23 11:44:04.254780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize fixtures
    terms = [
        "user",
        "user=",
        "user=toto",
        "user  section=section1  re=True",
        "user  section=section1  re=True  default=default value",
        "user section=section1 default=default value"]
    variables = {
        "lookup_file_search_path": [
            "/Users/yperre/ansible/lookup/"]}
    kwargs = {}
    # Run unit test
    lookup_obj = LookupModule()
    assert 'ansible' == lookup_obj.run(terms[0:1], variables=variables, **kwargs)[0]
    assert 'ansible' == lookup_obj.run(terms[1:2], variables=variables, **kwargs)[0]

# Generated at 2022-06-23 11:44:05.714355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule



# Generated at 2022-06-23 11:44:16.296797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockObject(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __call__(self, *args, **kwargs):
            return MockObject(**kwargs)

    class MockModule(MockObject):
        def __init__(self, *args, **kwargs):
            super(MockModule, self).__init__(*args, **kwargs)

# Generated at 2022-06-23 11:44:18.097134
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(lookup_module)
    pass

# Generated at 2022-06-23 11:44:20.217102
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.cp is None


# Generated at 2022-06-23 11:44:32.382568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    module = LookupModule()

    # Testing default section (global)
    terms = ['user']
    # Parameters
    options = {'file': 'users.ini', 'section': 'global'}

    results = module.run(terms, variables={}, **options)
    assert results == ['yperre']

    # Testing section 'dev'
    options = {'file': 'users.ini', 'section': 'dev'}
    results = module.run(terms, variables={}, **options)
    assert results == ['yperre']

    # Testing section 'integration'
    options = {'file': 'users.ini', 'section': 'integration'}
    results = module.run(terms, variables={}, **options)
    assert results == ['yannig']

    terms

# Generated at 2022-06-23 11:44:33.473628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('ini')

# Generated at 2022-06-23 11:44:44.266625
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a LookupModule object and create a fake find_file_in_search_path method
    lm = LookupModule()
    lm.find_file_in_search_path = lambda x, y, z: './test_ansible_lookup_ini.ini'

    # create paramvals with parameters of LookupModule.run()
    paramvals = {
        're': False,
        'type': 'ini',
        'encoding': 'utf-8',
        'default': '',
        'case_sensitive': False
    }

    # create terms
    terms = ['user']
    paramvals['section'] = 'integration'
    paramvals['file'] = 'ansible.ini'
    result = lm.run(terms, None, **paramvals)
    assert result[0] == 'test'



# Generated at 2022-06-23 11:44:56.266284
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    from io import StringIO

    # prepare ini file to use as configuration
    config = StringIO()
    config.write(u"[section1]\n")
    config.write(u"key1=value1\n")
    config.write(u"key2=value2\n")
    config.seek(0)

    # create parser object
    cp = configparser.ConfigParser()
    cp.readfp(config)

    # create LookupModule object
    lm = LookupModule()
    lm.cp = cp

    # test with key
    value = lm.get_value('key1', 'section1', 'dflt', False)
    assert value == "value1"

    # test with regexp
    value = lm.get_value('.*', 'section1', 'dflt', True)


# Generated at 2022-06-23 11:45:06.969442
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()

    # Retrieve all values from a section using a regexp
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section("section1")
    lookup.cp.set("section1", "key0", "value0")
    lookup.cp.set("section1", "key1", "value1")
    lookup.cp.set("section1", "key2", "value2")

    assert lookup.get_value("key[0-2]", "section1", None, True) == ["value0", "value1", "value2"]

    # Retrieve a single value
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section("section1")
    lookup.cp.set("section1", "key1", "value1")
    lookup.cp.set

# Generated at 2022-06-23 11:45:19.187975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test if each test case of the unit test is ok
    """
    import os
    import pytest
    #TODO: use FakeFS

    # Init vars
    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(current_dir, "test")
    test_cases_dir = os.path.join(test_dir, "test_LookupModule")

    # Unit test
    test_cases = os.listdir(test_cases_dir)
    for test_case in test_cases:
        print("- %s" % test_case)
        test_case_path = os.path.join(test_cases_dir, test_case)
        pytest_args = ["-s", test_case_path]


# Generated at 2022-06-23 11:45:29.998618
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import os
    import tempfile

    class Mock_loader():
        def _get_file_contents(self, path):
            with open(path, "r") as my_file:
                return my_file.read(), False

    class Mock_base():
        def get_options(self):
            return {'encoding': 'utf-8', 'section': 'default'}

        def find_file_in_search_path(self, variables, directories, filename):
            return filename

        def set_options(self, var_options, direct=None):
            return True

    l = LookupModule()
    l.set_loader(Mock_loader())
    l._loader = Mock_loader()
    l._templar = Mock_loader()
    l.set_basedir(".")
    l._loader.set_based

# Generated at 2022-06-23 11:45:31.465923
# Unit test for constructor of class LookupModule
def test_LookupModule():
  l = LookupModule()

test_LookupModule()

# Generated at 2022-06-23 11:45:43.401465
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # ConfigParser object
    cp = configparser.ConfigParser()
    cp.optionxform = to_native
    mockString = "[section1]\nproperty1=value1\nproperty2=value2\nproperty3=value3\n"
    config = StringIO()
    config.write(mockString)
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)

    # LookupModule object with mock ConfigParser
    lm = LookupModule()
    lm.cp = cp

    # Section
    section = 'section1'

    # Key
    key = 'property1'

    # Default
    dflt = None

    # Flag regexp
    is_regexp = False

    # Test

# Generated at 2022-06-23 11:45:52.800461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six.moves import configparser
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import StringIO

    # Test that when a file is specifed that does not exist or is not readable a LookupError is thrown
    with pytest.raises(AnsibleLookupError) as excinfo:
        terms = ['key']
        paramvals = {'file': './nosuchfile.txt', 'default': '', 're': False, 'type': 'ini'}
        lookup_plugin = LookupModule()
        lookup_plugin.run(terms, variables=ImmutableDict('somevars'))

# Generated at 2022-06-23 11:46:03.565678
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.utils.display import Display
    display = Display()
    display.display("test_LookupModule_get_value")

    cp = configparser.ConfigParser()
    f = open("test.ini", 'r')
    cp.readfp(f)
    f.close()

    l = LookupModule()
    l.cp = cp

    display.display("get_value with key=user and section=credentials should return yannigperre")
    assert l.get_value("user", "credentials", None, False) == "yannigperre"

    display.display("get_value with key=user and section=not_exists should return None")
    assert l.get_value("user", "not_exists", None, False) == None


# Generated at 2022-06-23 11:46:15.129654
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    # load the param to load the ini file
    term = "test.ini"
    param = {'file': term, 'section': 'test', 'encoding': 'UTF-8', 're': False}
    # create the ini file
    config = StringIO()
    config.write(u'[test]\n')
    config.write(u'one=1\n')
    config.write(u'two=2\n')
    config.write(u'three=3\n')
    config.seek(0, os.SEEK_SET)
    # use the ini file
    lookup_module.cp.readfp(config)
    # test with no section
    value = lookup_module.get_value("one", "", "", False)
    assert value

# Generated at 2022-06-23 11:46:16.304947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm != None


# Generated at 2022-06-23 11:46:18.959558
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None


# Generated at 2022-06-23 11:46:20.195014
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()

# Generated at 2022-06-23 11:46:30.323738
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ######################################################################
    # Parameters (global)
    # type=ini
    # file=ansible.ini
    # section=global
    # re=False
    # encoding=utf-8
    ######################################################################

    ######################################################################
    # Method run (no params)
    ######################################################################

    # Check ansible.ini
    # No match
    # Result: ''
    ######################################################################
    assert LookupModule().run(["not_exist"]) == ['']

    # Check ansible.ini
    # Match
    # Result: 'global'
    ######################################################################
    assert LookupModule().run(["section"]) == ['global']

    # Check ansible.ini
    # Match
    # Result: 'global'
    ######################################################################
    assert Lookup

# Generated at 2022-06-23 11:46:37.831197
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_instance = LookupModule()
    cfg = configparser.ConfigParser()
    string = r"""
[section1]
key1=value1
key2=value2
key3=value3
[section2]
key1=value1
key2=value2
key3=value3
    """
    cfg.readfp(StringIO(string))
    lookup_instance.cp = cfg
    assert lookup_instance.get_value('key1', 'section1', None, False) == 'value1'
    assert lookup_instance.get_value('key2', 'section1', None, False) == 'value2'
    assert lookup_instance.get_value('key3', 'section1', None, False) == 'value3'

# Generated at 2022-06-23 11:46:42.097219
# Unit test for constructor of class LookupModule
def test_LookupModule():
    key = 'key'
    section = 'section'
    dflt = 'dflt'
    is_regexp = False
    obj = LookupModule()
    value = obj.get_value(key, section, dflt, is_regexp)
    assert value == 'dflt'

# Generated at 2022-06-23 11:46:45.353494
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    assert isinstance(lookup_module, LookupBase)
    assert isinstance(lookup_module.cp, configparser.ConfigParser)
    assert lookup_module.cp == cp

# Generated at 2022-06-23 11:46:52.503548
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a test configparser
    cp = configparser.ConfigParser(allow_no_value=True)
    # Create sample  3 sections and 3 key/values
    cp['Section1'] = {'key1': 'val1', 'key2': 'val2', 'key3': 'val3'}
    cp['Section2'] = {'key4': 'val4'}
    cp['Section3'] = {'key5': 'val5', 'key6': 'val6', 'key7': 'val7'}

    # Create the LookupModule
    lm = LookupModule()
    lm.cp = cp

    # key exists in section
    assert lm.get_value('key1', 'Section1', 'default', False) == 'val1'

    # key does not exists in section
    assert lm.get

# Generated at 2022-06-23 11:47:05.005798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock class
    class LookupModule_MyMock(LookupModule):
        def __init__(self, *args, **kwargs):
            self.cp = None

        def run(self, terms, variables=None, **kwargs):
            if variables and variables['foo'] == 'bar':
                self.ctxt['bar'] = 'foo'
            return super(LookupModule_MyMock, self).run(terms, variables=variables, **kwargs)

        def get_value(self, key, section, dflt, is_regexp):
            if self.cp is None:
                raise configparser.NoSectionError
            elif self.cp[section] is None:
                raise configparser.NoOptionError
            else:
                return u"mock_value"


# Generated at 2022-06-23 11:47:13.447103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        from ansible.utils.vault import VaultLib

    # Init vault with password 'secret'
    vault = VaultLib(['--vault-password-file', 'test/ansible-vault/password.txt'])

    # Init test variables
    terms = ['key', 'key1']
    variable = dict()
    kwargs = dict()

    # Init test LookupModule
    lm = LookupModule()

    # Populate vault variable
    variable[lm._get_vault_secret_path('ansible-vault')] = 'secret'

    # Populate kwargs
    kwargs['file'] = 'test/ini/test.ini'

# Generated at 2022-06-23 11:47:23.736358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['user', 'password', 'section1']
    paramvals = {'file': 'tests/fixtures/module_utils/ansible_lookup_ini_test_file.ini', 'default': 'default', 'type': 'ini', 're': False, 'encoding': 'utf-8', 'section': 'general'}
    result = module.run(terms, variables={}, **paramvals)
    expected_result = ['jean', 'secret', 'section1_val']
    assert result == expected_result


# Generated at 2022-06-23 11:47:26.003391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        x = LookupModule()
    except Exception as e:
        print("LookupModule__init__ failed with error: '{0}'".format(e))
        raise e


# Generated at 2022-06-23 11:47:30.317902
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    assert isinstance(look.cp, configparser.ConfigParser)
    assert look.cp.allow_no_value == False
    assert look.cp.optionxform('aBc') == 'Abc'



# Generated at 2022-06-23 11:47:39.483420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test(file_content, search_path, key, section, dflt, type, encoding, is_regexp, output):
        cp = configparser.ConfigParser()
        cp.readfp(StringIO(file_content))
        lookup_module = LookupModule()
        lookup_module.cp = cp
        lookup_module.find_file_in_search_path = lambda variables, dirname, filename: search_path
        lookup_module._loader = FakeLoader()
        lookup_module.get_value = lambda key, section, dflt, is_regexp: lookup_module.cp.get(section, key)
        lookup_module.run([key], dict(ini_file_name=filename), type=type, encoding=encoding, file=filename, section=section, default=dflt, re=is_regexp)


# Generated at 2022-06-23 11:47:50.743980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.splitter import parse_kv
    from ansible.module_utils._text import to_bytes

    lookup_module = LookupModule()
    # test term that is "key=value"
    term = 'key1=value1'
    # with default parameters
    params = parse_kv(term)
    result = lookup_module.run(term, variables=None, **params)
    assert result == ['value1']

    # test term "key=value key=value"
    terms = ['key1=value1 key2=value2']
    # with default parameters
    params = parse_kv(terms[0])
    result = lookup_module.run(terms, variables=None, **params)
    assert result == ['value1']

    # Check that allow_no_value is true
   

# Generated at 2022-06-23 11:47:58.328094
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Build test fake config parser instance
    class FakeConfigParser:
        def __init__(self):
            self.fake_section = {}

        def items(self, section):
            return self.fake_section.items()

        def get(self, section, key):
            return self.fake_section[key]

    fake_cp = FakeConfigParser()

    # Load keys in fake config parser
    fake_cp.fake_section = {"key1": "value1", "key2": "value2"}

    # Build LookupModule
    lm = LookupModule()
    lm.cp = fake_cp

    # Test retrieve a single value
    assert "value1" == lm.get_value("key1", "section", "", False)

    # Test retrieve a single value that does not exist in fake config parser

# Generated at 2022-06-23 11:48:05.252475
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: This test is not complete
    test = LookupModule()

    # TODO: mock necessary files used by the lookup module

    terms = [
        "password=password file=users.ini section=integration re=True",
        "password=password file=users.ini section=production re=True default=foobar"
    ]
    variables = {
        "lookup_file": "users.ini",
        "lookup_password": "password"
    }
    paramvals = {
        "type": "ini",
        "case_sensitive": False
    }

    for term in terms:
        paramvals['file'] = None
        paramvals['section'] = 'global'
        paramvals['re'] = False
        paramvals['default'] = None

# Generated at 2022-06-23 11:48:17.400867
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create test instance of LookupModule
    test_instance = LookupModule()

    # Test with regexp and get value
    config = configparser.ConfigParser()
    config.add_section('test_section')
    config.set('test_section', 'test_key1', 'some_value1')
    config.set('test_section', 'test_key2', 'some_value2')
    config.set('test_section', 'test_key3', 'some_value3')
    test_instance.cp = config
    assert test_instance.get_value('test_key', 'test_section', 'default', False) == 'default'
    assert test_instance.get_value('test_key1', 'test_section', 'default', False) == 'some_value1'

# Generated at 2022-06-23 11:48:26.270073
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.module_utils._text import to_bytes
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    lm.cp.readfp(StringIO(to_bytes("""[java_properties]\nusername=jenkins\nhostname=jhost\n""",
                                   encoding='UTF-8')))
    return_value = lm.get_value("username", "java_properties", "", False)
    assert return_value == "jenkins", "Return value is not 'jenkins' but '%s'" % return_value
    return_value = lm.get_value(".*", "java_properties", "", True)

# Generated at 2022-06-23 11:48:32.695180
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.cp.optionxform is not None
    assert lookup_module.cp.allow_no_value is False
    assert lookup_module.cp.get('section', 'key') is None
    assert lookup_module.cp.get('section', 'key', fallback='default') == 'default'


# Generated at 2022-06-23 11:48:33.773241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([]) == []



# Generated at 2022-06-23 11:48:45.040555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    re_key_1 = 'regexp_key_[0-9]'
    re_key_2 = 'regexp_key_[a-z]'
    sio = StringIO(u'[ini_section]\nregexp_key_1=a\nregexp_key_2=b\nregexp_key_3=c')
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(sio)
    lookup_module.cp.has_section('ini_section')
    assert lookup_module.get_value(re_key_1, "ini_section", None, True) == ['a']

# Generated at 2022-06-23 11:48:54.192829
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lm = LookupModule()
    configparser.SafeConfigParser.optionxform = to_native
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'foo = One\n')
    config.write(u'bar = Two\n')
    config.write(u'foobar = Three\n')
    config.write(u'[section2]\n')
    config.write(u'foo = Four\n')
    config.write(u'bar = Five\n')
    config.write(u'foobar = Six\n')
    config.seek(0, os.SEEK_SET)
    lm.cp = configparser.SafeConfigParser()
    lm.cp.readfp(config)

    # Check return if key not found
   

# Generated at 2022-06-23 11:49:02.401116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['key1', 'key2']
    section = 'section1'
    file = './test.ini'
    #section = 'java_properties'
    #file = './user.properties'
    kwargs = {'section': section, 'file': file, 're': True}
    results = lm.run(terms, **kwargs)
    assert results[0] == 'value1'
    assert results[1] == 'value2'
    assert len(results) == 2
