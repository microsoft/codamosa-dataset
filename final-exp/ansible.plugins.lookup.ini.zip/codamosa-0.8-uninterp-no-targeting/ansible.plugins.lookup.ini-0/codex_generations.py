

# Generated at 2022-06-21 06:04:05.853259
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    '''Test the get_value method of the LookupModule class'''

    # Initialize a lookup module
    lookup = LookupModule()

    # Create a fake config file
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'e1 = value1\n')
    config.write(u'e2 = value2\n')
    config.write(u'e3 = value3\n')
    config.seek(0, os.SEEK_SET)

    # Get the lookup modules configparser
    cp = lookup.cp

    # Read the fake config file
    cp.readfp(config)

    # Test the get_value method using a regexp
    result = sorted(lookup.get_value('e.', 'section1', 'default', True))
   

# Generated at 2022-06-21 06:04:19.088853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import re
    import tempfile
    import logging
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase

    # test_lookup_module.py
    #   configparser.DuplicateOptionError
    #   configparser.NoSectionError

    class LookupModuleTest(LookupBase):

        def get_value_test(self, key, section, dflt, is_regexp):
            # Retrieve all values from a section using a regexp
            if is_regexp:
                return [v for k, v in self.cp.items(section) if re.match(key, k)]
            value = None
            # Retrieve a single value
           

# Generated at 2022-06-21 06:04:29.664131
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test to test run method of class LookupModule

    import pytest

    # Test on a properties file
    terms = [u'user.name']

    kwargs = {
        "type": 'properties',
        "file": 'user.properties',
        "encoding": 'utf-8',
        "default": ''
    }

    expected_result = u'Pierre'

    lm = LookupModule()
    result = lm.run(terms, **kwargs)

    assert result == [expected_result]

    # Test on an INI file
    terms = [u'user', u'login', u'password']


# Generated at 2022-06-21 06:04:34.286397
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    module = LookupModule()
    cp = configparser.ConfigParser()
    # Create configparser with empty section
    cp.readfp(StringIO('[example]\nkey1=value1\nkey2=value2'))
    # Retrieve all keys using a regexp
    assert module.get_value('.*', "example", None, True) == ['value1', 'value2']
    # Retrieve a key with a name
    assert module.get_value("key1", "example", None, False) == 'value1'
    # Retrieve a non existent key
    assert module.get_value("key3", "example", None, False) == None
    # Retrieve a key from a non existent section
    assert module.get_value("key1", "example1", None, False) == None

# Generated at 2022-06-21 06:04:42.751677
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(StringIO(u'[section]\nkey1=value1\nkey2=value2\nkey3=value3'))
    assert lookup.get_value(u'key1', u'section', u'', False) == u'value1'
    assert lookup.get_value(u'key2', u'section', u'', False) == u'value2'
    assert lookup.get_value(u'key3', u'section', u'', False) == u'value3'
    assert lookup.get_value(u'key4', u'section', u'default', False) == u'default'


# Generated at 2022-06-21 06:04:52.887704
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a mock of class LookupBase
    class LookupBaseMock(LookupBase):
        cp = configparser.ConfigParser()

    lookup_mock = LookupModule(loader=None, basedir=None, runner=None, templar=None)
    lookup_mock.cp.optionxform = to_native
    lookup_mock.cp.add_section('section')
    lookup_mock.cp.set('section', 'user', 'jacob')
    lookup_mock.cp.set('section', 'user', 'jason')
    lookup_mock.cp.set('section', 'foo', 'bar')
    lookup_mock.cp.set('section', 'fo=o', 'b=ar')
    lookup_mock.cp.set('section', 'fo:o', 'b:ar')

# Generated at 2022-06-21 06:05:05.254123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test method run from class LookupModule'''
    # Build a dummy class for LookupModule
    class DummyLookupModule(LookupModule):
        '''Dummy class for LookupModule'''
        def find_file_in_search_path(self, variables, dirname, filename):
            '''Dummy method for find_file_in_search_path'''
            return 'users.ini'
        def _loader_class(self, path, data=None, basedir=None):
            '''Dummy method for _loader_class'''
            return 'lookup.ini'

    lookup_module = DummyLookupModule()

# Generated at 2022-06-21 06:05:16.268614
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    lm.cp.add_section('section1')
    lm.cp.set('section1', 'name1', 'value1')
    lm.cp.set('section1', 'name2', 'value2')
    lm.cp.set('section1', 'name3', 'value3')
    lm.cp.add_section('section2')
    lm.cp.set('section2', 'name1', 'value1')
    lm.cp.set('section2', 'name2', 'value2')
    lm.cp.set('section2', 'name3', 'value3')
    assert lm.get_value('name1', 'section1', '', False) == 'value1'
    assert l

# Generated at 2022-06-21 06:05:18.328837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.cp = configparser.ConfigParser()

    # test_assert_instance_of_configparser
    assert isinstance(l.cp, configparser.ConfigParser)



# Generated at 2022-06-21 06:05:31.507305
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test method run of class LookupModule with a normal ini file and with one entry
    cp = configparser.ConfigParser()

# Generated at 2022-06-21 06:05:50.211086
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    dic = {"global": {"foo1": "bar1", "foo2": "bar2"}, "section1": {"foo3": "bar3", "foo4": "bar4"}}
    cp = configparser.ConfigParser(defaults=dic)
    # test_get_value method of class ansible.parsing.plugin_docs_fragments.LookupModule
    get_value = LookupModule.get_value
    assert get_value("foo1", "global", None, False, cp) == "bar1"
    assert get_value(".*foo.*", "global", None, True, cp) == ["bar1", "bar2"]
    assert get_value("foo3", "section1", None, False, cp) == "bar3"

# Generated at 2022-06-21 06:06:04.214345
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import unittest

    # Mock configparser class
    class _conf(object):
        def __init__(self):
            pass

        def items(self, section):
            if section == "section1":
                return [("k3", "v3"), ("k1", "v1"), ("k2", "v2")]
            else:
                return []

        def get(self, section, key):
            if section == "section2":
                return "v"
            raise configparser.NoOptionError(key, section)

    # Mock class LookupModule
    class _LookupModule(LookupModule):
        def __init__(self):
            pass


# Generated at 2022-06-21 06:06:13.401965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import unittest
    import shutil

    class TestLookupModule_run(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp(prefix='ansible-test-lookup')
            os.chdir(self.tempdir)
            self.test_vars = dict(
                tempdir=self.tempdir
            )

        def tearDown(self):
            os.chdir(self.test_vars['tempdir'])
            shutil.rmtree(self.test_vars['tempdir'])

        def test_LookupModule_get_value(self):
            # ConfigParser.items returns a list of (key, value) tuples
            # which is the expected result of re.match
            test_content

# Generated at 2022-06-21 06:06:25.359092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    testLookupModule = LookupModule()
    paths = ['test/fixtures/terms_ini.yaml']
    searchpath = ['test/fixtures/lookup-tests/ini']
    file = 'test/fixtures/lookup-tests/ini/users.ini'
    section = 'integration'
    file_properties = 'test/fixtures/lookup-tests/ini/user.properties'
    section_properties = 'java_properties'

# Generated at 2022-06-21 06:06:37.800458
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a string used to parse ini
    config_string = """[global]
user = pippo
pass = pluto

[integration]
user = user_int
pass = pass_int

[production]
user = user_prod
pass = pass_prod
"""

    # Create LookupModule instance
    lm = LookupModule()

    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(config_string)
    config.seek(0, os.SEEK_SET)

    # Create config parser
    lm.cp = configparser.ConfigParser()
    lm.cp.readfp(config)

    # Test positive cases
    assert lm.get_value('user', 'global', None, False) == 'pippo'

# Generated at 2022-06-21 06:06:48.048131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible.cfg not found
    # cp = ConfigParser()
    # cp.add_section(u'global')
    # cp.set(u'global',u'file', u'not/existing/path')
    # opt = cp.get(u'global',u'file')
    # print opt

    term = [u"key1", u"key2", u"key3", u"key4"]
    paramvals = {u'type': u'ini', u'file': u'/home/work/ansible/playbooks/test/test.ini',
                 u'section': u'ini', u're': True, u'default': u'',
                 u'case_sensitive': False, u'allow_no_value': False}

# Generated at 2022-06-21 06:06:57.572675
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import pytest

    terms = ['user', 'user', 'user', 'user']
    p = ['user=', 'user=', 'user=', 'user=']
    path = '/tmp/test.ini'
    section = 'section'
    key = 'user'
    dflt = 'default'
    is_regexp = [False, True, False, True]
    value = 'username'
    cp = configparser.ConfigParser()
    cp.read(path)

    l = LookupModule()
    l.cp = cp

    assert l.get_value(key, section, dflt, is_regexp[0]) == value

# Generated at 2022-06-21 06:07:02.346766
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    assert lookup.get_value('key1', 'section1', 'default_value', False) == 'value1'
    assert lookup.get_value('key2', 'section1', 'default_value', False) == 'value2'
    assert lookup.get_value('key1', 'section2', 'default_value', False) == 'value3'
    assert lookup.get_value('.*', 'section1', 'default_value', True) == ['value1', 'value2']
    assert lookup.get_value('key3', 'section3', 'default_value', False) == 'default_value'


# Generated at 2022-06-21 06:07:06.795435
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lm = LookupModule()
    cp = configparser.ConfigParser()
    cp.readfp(StringIO('[section1]\nkey1 = value1\nkey2 = value2\n[section2]\n'))
    lm.cp = cp

    assert lm.get_value('key1', 'section1', None, False) == 'value1'
    assert lm.get_value('key1', 'section1', 'a', True) == 'value1'
    assert lm.get_value('key2', 'section2', 'b', True) == 'b'

    assert lm.get_value('.*', 'section1', None, True) == ['value1', 'value2']
    assert lm.get_value('a', 'section2', None, True) is None

# Generated at 2022-06-21 06:07:20.200513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_string = u'[config]\n' \
                  u'user=foo\n' \
                  u'password=bar\n' \
                  u'port=8080\n' \
                  u'[section2]\n' \
                  u'user=toor\n' \
                  u'password=root\n' \
                  u'port=443\n' \
                  u'[section3]\n' \
                  u'user=root\n' \
                  u'password=toor\n' \
                  u'port=23'

    l = LookupModule()
    l.cp = configparser.ConfigParser()
    l.cp.readfp(StringIO(test_string))

# Generated at 2022-06-21 06:07:42.296235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Expected result: a list of users in test.ini
    # Python 3.x
    if True:
        tmp = configparser.ConfigParser(allow_no_value=False)
        tmp.read('test.ini')
        result = tmp.get('users', 'user1').splitlines()
        result += tmp.get('users', 'user2').splitlines()
        result += tmp.get('users', 'user3').splitlines()
        result += tmp.get('users', 'user4').splitlines()
        result += tmp.get('users', 'user5').splitlines()
    # Python 2.7.x
    else:
        tmp = configparser.SafeConfigParser(allow_no_value=False)
        tmp.read('test.ini')

# Generated at 2022-06-21 06:07:47.836691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)
    assert hasattr(lm, 'get_value')
    assert hasattr(lm, 'run')


# Generated at 2022-06-21 06:07:55.934620
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    # Create test file
    with open('test.ini', 'w') as f:
        f.write('[section1]\n')
        f.write('key1=value1\n')
        f.write('key2=value2\n')
        f.write('key3=value3\n')
        f.write('key4=value4\n')
        f.write('[section2]\n')
        f.write('key2=value2\n')
        f.write('key3=value3\n')
        f.write('key4=value4\n')
        f.write('[section3]\n')
        f.write('key4=value4\n')

    # Instantiate object
    lookup = LookupModule()

    # Test all values

# Generated at 2022-06-21 06:08:04.618335
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_subject = LookupModule()
    test_subject.cp = configparser.ConfigParser()
    test_subject.cp.readfp(StringIO("[test]\ntest_key=test_value"))
    assert test_subject.get_value("test_key", "test", None, False) == "test_value"
    assert test_subject.get_value(".*key", "test", None, True) == ["test_value"]
    assert test_subject.get_value("fake_key", "test", None, False) == None
    assert test_subject.get_value("fake_key", "test", "foo", False) == "foo"

# Generated at 2022-06-21 06:08:13.905786
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #### get value
    ## with no section
    # with no value
    assert LookupModule('').get_value('f', '', 'd', False) == 'd'
    # with value
    assert LookupModule('').get_value('f', '', 'd', False) == 'd'

    ## with section
    # with no value
    assert LookupModule('').get_value('f', 's', 'd', False) == 'd'
    # with value
    assert LookupModule('').get_value('f', 's', 'd', False) == 'd'

    #### run
    # with no term
    assert LookupModule('').run([], '') == []

    # with 1 term
    ## with key
    # with no value

# Generated at 2022-06-21 06:08:15.454989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.cp.allow_no_value is False

# Generated at 2022-06-21 06:08:26.606262
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test retrieving a single key in a section
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.set('section1', 'key2', 'value2')
    lookup_module.cp = cp
    assert lookup_module.get_value('key1', 'section1', None, False) == 'value1'

    # Test retrieving a single key in a section with case sensitivity
    cp = configparser.ConfigParser()
    cp.optionxform = str
    cp.add_section('section1')
    cp.set('section1', 'KEY1', 'value1')
    lookup_module.cp = cp

# Generated at 2022-06-21 06:08:29.609646
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 06:08:40.782661
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser()
    string_file = u"""[section1]
key1=value1
key2=value2

[section2]
key3=value3
key4=value4
value5

[section3]
key5=

[section4]
key6="value6"
key7=''
"""
    config = StringIO(string_file)
    cp.readfp(config)
    # Get a value
    l = LookupModule()
    l.cp = cp
    assert l.get_value("key1", "section1", None, False) == "value1"
    assert l.get_value("key3", "section2", None, False) == "value3"

# Generated at 2022-06-21 06:08:53.986341
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section('section')
    cp.set('section', 'test_key', 'test_value')
    lookup_module.cp = cp

    # Test a simple key in a section
    assert(lookup_module.get_value('test_key', 'section', 'default_value', False) == 'test_value')
    assert(lookup_module.get_value('test_key', 'section', 'default_value', True) == 'test_value')

    # Test a simple key not in a section
    assert(lookup_module.get_value('test_key', 'another_section', 'default_value', False) == 'default_value')

# Generated at 2022-06-21 06:09:19.471727
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:09:28.606852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["user", "password=pass"]  # Lookup keys
    section = "integration"
    parameters = {
        "type": "ini",
        "file": "test.ini",
        "section": section,
        "re": False,
        "encoding": "utf-8",
        "default": "",
        "case_sensitive": False
    }
    result = lookup.run(terms, parameters)
    assert result[0] == "oneuser"
    assert result[1] == "pass"


# Generated at 2022-06-21 06:09:39.451282
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    f = LookupModule()

    # Add a fake ini file
    f.cp = configparser.ConfigParser()
    f.cp.add_section("section1")
    f.cp.add_section("section2")
    f.cp.set("section1", "user1", "value1")
    f.cp.set("section1", "user2", "value2")
    f.cp.set("section1", "user3", "value3")
    f.cp.set("section2", "user1", "value_a")

    # Test is_regexp == False
    assert f.get_value("user1", "section1", "default", False) == "value1"
    assert f.get_value("user1", "section2", "default", False) == "value_a"
    assert f

# Generated at 2022-06-21 06:09:45.215673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.get_options() == {'case_sensitive': False, 'file': 'ansible.ini', 're': False, 'section': 'global', 'default': '', 'encoding': 'utf-8', 'type': 'ini', 'allow_no_value': False}


# Generated at 2022-06-21 06:09:50.640379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['first', 'second', 'third', 'fourth']
    ret = LookupModule().run(terms, {})
    assert ret[0] == 'first'
    assert ret[3] == 'fourth'


# Generated at 2022-06-21 06:09:59.895873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a fake section for the test
    fake_section = 'fake'
    # First test: no key
    # Create a fake file for the test
    fake_file_path = "/tmp/ansible_ini_test.ini"
    fake_file = open(fake_file_path, "w")
    fake_file.write("[fake]\n")
    fake_file.write("key1=value1\n")
    fake_file.close()
    # Create the LookupModule object
    lookup_object = LookupModule()
    # Create a term array
    fake_terms = []
    fake_terms.append("fake_key")
    fake_terms.append("fake_key2")
    fake_options = {}
    fake_options['file'] = fake_file_path

# Generated at 2022-06-21 06:10:09.302728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import json
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.plugins import lookup_loader
    from ansible.plugins.lookup_loader import find_plugin

    current_dir = os.path.dirname(__file__)
    current_dir = os.path.abspath(current_dir)
    lookup_dir = os.path.join(current_dir, 'lookup_plugins')
    lookup_dir = os.path.abspath(lookup_dir)
    lookup_plugin = find_plugin(lookup_loader, lookup_dir)
    lookup_plugin.set_loader_context(loaders=None, variables=dict())

# Generated at 2022-06-21 06:10:11.170713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupModule()
    assert isinstance(test_obj, LookupBase)
    assert type(test_obj) == LookupModule


# Generated at 2022-06-21 06:10:20.725982
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    module = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.set('section1', 'key2', 'value2')
    cp.add_section('section2')
    cp.set('section2', 'key1', 'value3')
    module.cp = cp
    assert module.get_value('key1', 'section1', '', False) == 'value1'
    assert module.get_value('key1', 'section2', '', False) == 'value3'
    assert module.get_value('key.*', 'section1', '', True) == ['value1', 'value2']

# Generated at 2022-06-21 06:10:27.146058
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    assert ['aa'] == lookup.get_value('^aa', 'section1', 'default', True)
    assert ['aa'] == lookup.get_value('aa', 'section1', 'default', False)
    assert ['aa'] == lookup.get_value('aa', 'section1', 'default', True)


# Generated at 2022-06-21 06:11:20.867515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    class OptionModule(object):
        def __init__(self, result):
            self.result = result
        def get_option(self, s):
            return self.result[s]
    class AnsibleModule(object):
        def __init__(self, result):
            self.params = OptionModule(result)
    lookup_options = dict(
        file='ansible.ini',
        section='global',
        default='',
        re=False,
        encoding='utf-8',
        case_sensitive=False,
        allow_no_value=False
    )
    ansible_module = AnsibleModule(lookup_options)
    class Runner(object):
        def __init__(self, result):
            self.name = 'lookup'
            self.src = result
           

# Generated at 2022-06-21 06:11:29.092919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameters
    terms = ['user']
    options = dict()
    options['section'] = 'production'
    options['file'] = 'users.ini'

    # Initialize lookup
    lookup = LookupModule()
    lookup.set_options(var_options=dict(), direct=options)
    assert lookup.run(terms) == ['user1']



# Generated at 2022-06-21 06:11:34.741132
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create mockup of class LookupModule
    class LookupModuleMockup(LookupBase):
        def get_value(self, key, section, dflt, is_regexp):
            if is_regexp:
                return [v for k, v in self.cp.items(section) if re.match(key, k)]
            else:
                value = None
                try:
                    value = self.cp.get(section, key)
                except configparser.NoOptionError:
                    return dflt
                return value

    lm = LookupModuleMockup()
    lm.cp = configparser.ConfigParser()

# Generated at 2022-06-21 06:11:42.183046
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the constructor
    variables = {'var1' : 'var1', 'var2' : 'var2'}
    lookup = LookupModule()
    lookup.run(['key'], variables)
    assert lookup.get_options() == {'type' : 'ini', 'section' : 'global', 're' : False, 'default' : '', 'case_sensitive' : False, 'allow_no_value' : False}
    # Test the constructor with parameters
    lookup = LookupModule()
    lookup.run(['key', 'file=file.ini', 'section=section', 'type=properties'], variables)

# Generated at 2022-06-21 06:11:55.603419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.lookup import LookupBase
    import ansible.constants as C
    import os

    class MockLookupBase(LookupBase):
        def find_file_in_search_path(self, variables, search_path, file_name):
            return os.path.join(self._loader.path_loader.get_basedir(), file_name)

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[os.getcwd() + '/test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source

# Generated at 2022-06-21 06:12:05.898142
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Some test datas
    keys = {
        'v1': 'a=b',
        'v2': 'a=b\nc=d\ne=f',
        'v3': 'a=b\nc=d\ne=f',
        'v4': 'a=b',
        'v5': 'a=b\nc=d\ne=f',
        'v6': 'a=b\nc=d\ne=f',
        'v7': 'a=b',
        'v8': 'a=b\nc=d\ne=f',
        'v9': 'a=b\nc=d\ne=f'
    }
    config1 = configparser.RawConfigParser()
    config1.add_section('section1')

# Generated at 2022-06-21 06:12:15.247043
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    config = configparser.ConfigParser(allow_no_value=True)
    config.optionxform = to_native

    config.readfp(StringIO(u"[section1]\n" + u"key1=value1\n" + u"key2=value2\n" + u"key3=value3\n" + u"key4\n" + u"\n" + u"[section2]\n" + u"key5=value5\n"))

    assert config.get('section1', 'key1') == 'value1'

    class MockModule(object):
        pass

    class MockFile(object):

        def __init__(self):
            self.data = ''

        def read(self):
            return self.data

        def __setitem__(self, key, value):
            self.data

# Generated at 2022-06-21 06:12:24.811072
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    """ the test case for get_value() of ini lookup  """
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(StringIO('[section1]\nkey1=value1\nkey2=value2\nkey3=value3\nkey4=value10'))

    # Retrieve a single value
    assert lookup.get_value('key1', 'section1', '', False) == 'value1'

    # Retrieve empty value
    assert lookup.get_value('key5', 'section1', '', False) == ''

    # Retrieve all values using regexp
    assert lookup.get_value('.*', 'section1', '', True) == ['value1', 'value2', 'value3', 'value10']

    # Retrieve all values from

# Generated at 2022-06-21 06:12:36.386699
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    myvar = []
    myvar.append(u'import_playbook = lu_playbook.yml\n')
    myvar.append(u'apic_base_url = https://192.168.0.252\n')
    myvar.append(u'apic_username = admin\n')
    myvar.append(u'apic_password = cisc0123\n')
    myvar.append(u'\n')
    myvar.append(u'[tenants]\n')
    myvar.append(u'cisco = 123\n')
    myvar.append(u'dell  = 456\n')

    mylookup = LookupModule()
    mylist = []

# Generated at 2022-06-21 06:12:47.240730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ 'user', 'user_db_host' ]
    config_content = """
[global]
user=root
user_db_host=127.0.0.1
user_db_port=3306
[integration]
user=integration
user_db_host=127.0.0.1
user_db_port=3306
[production]
user=production
user_db_host=127.0.0.1
user_db_port=3306
"""
    results = [ 'root', '127.0.0.1' ]
    lookup_module = LookupModule()
    assert lookup_module.run(terms=terms, variables=[], section='global', file='ansible.ini') == results