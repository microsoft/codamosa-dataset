

# Generated at 2022-06-21 06:04:06.333850
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    terms = []
    paramvals = {'default': 'test_default'}

    # Parameters for call
    term = 'test_key'
    section = 'test_section'
    dflt = 'test_default'
    is_regexp = False

    # Setup configParser instance
    cp = configparser.ConfigParser(allow_no_value=True)

    # Read test data from test.ini
    testfile = os.path.join(os.path.dirname(__file__), 'test.ini')
    contents, show_data = LookupBase()._loader._get_file_contents(testfile)
    contents = to_text(contents, errors='surrogate_or_strict', encoding='utf-8')
    config = StringIO(contents)

# Generated at 2022-06-21 06:04:14.347518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test case called with LookupModule.run('[[[this is my key]]]', section='my_section')"""
    expected = ['value_key']

    lookup_instance = LookupModule()

    # Returned value from LookupModule.run()
    ret = lookup_instance.run(['[[[this is my key]]]'], section='my_section', file='my.config')
    # Assertion
    assert ret == expected

# Generated at 2022-06-21 06:04:26.099087
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a key not in file
    config = '''
[section1]
key1=value
key2=value2
'''
    term = 'key3'
    paramvals = {
        'file': 'test.ini',
        'section': 'section1',
        're': False,
        'encoding': 'utf-8',
        'default': '',
        'case_sensitive': False,
        'allow_no_value': False,
    }
    lookup = LookupModule()
    assert lookup.run([term], paramvals=paramvals) == ['']

    # Test with a key in file
    config = '''
[section1]
key1=value
key2=value2
'''
    term = 'key1'

# Generated at 2022-06-21 06:04:32.894477
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test constructor LookupModule")
    lm = LookupModule()
    if isinstance(lm, LookupBase) is False:
        print("Error: LookupModule should be inherited from LookupBase")
        exit(1)


# Generated at 2022-06-21 06:04:41.874938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    file = """
    [section1]
    question1=answer1
    question2=answer2

    [section2]
    question3=answer3
    question2=answer2
    """
    path = os.path.join(os.path.dirname(__file__), "test.ini")
    open(path, 'w').write(file)

# Generated at 2022-06-21 06:04:51.676612
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    class LookupModule(object):

        def __init__(self, cp):
            self.cp = cp

        def get_value(self, key, section, dflt, is_regexp):
            # Retrieve all values from a section using a regexp
            if is_regexp:
                return [v for k, v in self.cp.items(section) if re.match(key, k)]
            value = None
            # Retrieve a single value
            try:
                value = self.cp.get(section, key)
            except configparser.NoOptionError:
                return dflt
            return value

    config = configparser.ConfigParser()
    config.add_section('general')
    config.set('general', 'key1', 'value1')

# Generated at 2022-06-21 06:05:04.334627
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_data = "foo=bar\n[section1]\nvar1=value1\nvar2=value2\nvar3=value3\n[section2]\nvar1=value1\nvar2=value2\nvar3=value3"
    cp = configparser.ConfigParser()
    config = StringIO()
    config.write(test_data)
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)

    mylookup = LookupModule()
    mylookup.cp = cp
    # Valid regexp
    assert mylookup.get_value(".*", "section1", "", True) == ['var1=value1', 'var2=value2', 'var3=value3']
    # Invalid regexp
    assert mylookup.get_

# Generated at 2022-06-21 06:05:15.432554
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    import unittest.mock

    # Create a mock to simulate the configparser
    cp = unittest.mock.Mock(spec=configparser, items=[])
    
    # Create a fake item
    item = [('key1', 'value1'), ('key2', 'value2')]

    # Assign item to the fake function items
    cp.items.return_value = item

    # Create a LookupModule object
    lm = LookupModule()

    # Use mock to simulate configparser
    lm.cp = cp

    # Test to retrieve one value
    assert lm.get_value('key1', 'section1', 'default', False) == 'value1'
    assert lm.get_value('key2', 'section1', 'default', False) == 'value2'

    # Retrieve all values using

# Generated at 2022-06-21 06:05:21.790272
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.plugins.lookup.ini import LookupModule

    test_string = "[section1]\
    key1=value1\
    key2=value2\
        \
    [section2]\
    foo1=bar1\
    foo2=bar2\
        \
    [section3]\
    foo3=bar3"

    # parser object is created with the test_string content
    # we use configparser.RawConfigParser instead of ConfigParser
    # to get no lowercasing of the keys
    cp = configparser.RawConfigParser()
    cp.readfp(StringIO(test_string))

    # get a list of values in [section1] where the keys are matching the regular expression 'key*'
    lookup = LookupModule()
    lookup.cp = cp
    assert lookup.get_value

# Generated at 2022-06-21 06:05:26.134024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    file = '../../../../../plugins/lookup/ini.py'
    name = 'user'
    section = 'integration'
    params = {'file': file, 'section': section, 're': True}
    terms = [name]
    result = module.run(terms, None, **params)
    print(result)

# Generated at 2022-06-21 06:05:51.871149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm_result = lm.run([], dict(ansible_config_dir=[
                                '/home/ansible/tests/lookups/'], ansible_config_file='ansible.ini'), file='ansible.ini')
    assert lm_result == ['value1', 'value2']
    # If wrong file, empty list
    lm_result = lm.run([], dict(ansible_config_dir=[
                                '/home/ansible/tests/lookups/'], ansible_config_file='ansible.ini'), file='ansible2.ini')
    assert lm_result == []
    # If wrong section, empty list

# Generated at 2022-06-21 06:06:04.963774
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = []
    path = 'some_file.ini'
    term = 'term1'
    section = 'section1'
    # Create StringIO later used to parse ini
    config = StringIO()
    # Open file using encoding
    config.write(u'[%s]\n%s = value1\n' % (section, term))
    config.seek(0, os.SEEK_SET)

    l = LookupModule()
    l.cp = configparser.ConfigParser()
    l.cp.readfp(config)
    var = l.get_value(term, section, None, False)
    assert var == "value1"
    var = l.get_value(term, section, None, True)
    assert var == "value1"

    config = StringIO()
    # Open file using encoding

# Generated at 2022-06-21 06:06:12.023764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([
        'key=value',
        'key1=value1 re=True type=properties file=test.properties',
        'key2=value2 re=True type=properties section=test2 file=test.properties',
        'key3=value3 re=True type=properties section=test2 file=test.properties encoding=utf-16 default=mydefault'
        ], variables={'role_path': './roles/role'})
    assert result == ['value', 'value1', 'value2', 'mydefault']


# Generated at 2022-06-21 06:06:23.331116
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # init
    module = LookupModule()

    # test with default parameters
    s = StringIO(u'[base]\na=b')
    module.cp.readfp(s)
    assert module.get_value('a', 'base', '', False) == 'b'
    assert module.get_value('b', 'base', '', False) == ''

    # test with not default parameters
    s = StringIO(u'[base]\na=b')
    module.cp.readfp(s)
    assert module.get_value('b', 'base', 'a', False) == 'a'

# Generated at 2022-06-21 06:06:35.307065
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.SafeConfigParser()

    # Create a cStringIO
    config = StringIO()
    config.write(u'[Section]\n')
    config.write(u'key_a=value\n')
    config.write(u'key_b=value\n')
    config.seek(0, os.SEEK_SET)
    try:
        lookup.cp.readfp(config)
    except configparser.DuplicateOptionError as doe:
        raise AnsibleLookupError("Duplicate option in '{file}': {error}".format(file=paramvals['file'], error=to_native(doe)))

    # Test all cases
    assert lookup.get_value('key', 'Section', 'default', False) == 'value'
   

# Generated at 2022-06-21 06:06:48.281891
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Create a LookupModule to parse configuration file
    lookup = LookupModule()

    # Create a mock configuration file
    config = StringIO()
    config.write(u'[main]\n')
    config.write(u'user=toto\n')
    config.write(u'password=tutu\n')
    config.write(u'port=1234\n')
    config.write(u'host=127.0.0.1\n')
    config.seek(0, os.SEEK_SET)

    try:
        lookup.cp.readfp(config)
    except configparser.DuplicateOptionError as doe:
        raise AnsibleLookupError("Duplicate option in '{file}': {error}".format(file='fake.ini', error=to_native(doe)))

# Generated at 2022-06-21 06:06:52.744848
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_thing = LookupModule()
    lookup_thing.get_options()
    lookup_thing.get_value()

    test_file_name = 'hello.ini'
    test_file = looku

# Generated at 2022-06-21 06:06:54.570208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-21 06:07:09.856573
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    config = """
[section1]
key1 = value1
key2 = value2
key3 = value3
"""
    data = StringIO(config)
    cp = configparser.ConfigParser()
    cp.readfp(data)

    # create instance of LookupModule
    m = LookupModule()
    m.cp = cp

    assert m.get_value('key1', 'section1', None, False) == 'value1'
    assert m.get_value('key2', 'section1', None, False) == 'value2'
    assert m.get_value('key3', 'section1', None, False) == 'value3'

    # Retrieve all values from a section using a regexp

# Generated at 2022-06-21 06:07:16.997837
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()

    # test normal usage
    terms = ['a=b', 'cd', 'ef']
    assert lookup_module._parse_params(terms[0], lookup_module.get_options()) == ['a=b', 'cd']
    assert lookup_module._parse_params(terms[1], lookup_module.get_options()) == ['cd']
    assert lookup_module._parse_params(terms[2], lookup_module.get_options()) == ['ef']

    # test no param specified
    assert lookup_module._parse_params(terms[2], lookup_module.get_options()) == ['ef']

    # if first term is 'key='
    term = 'key=value2'
    assert lookup_module._parse_params(term, lookup_module.get_options()) == ['key=value2']



# Generated at 2022-06-21 06:07:54.267719
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Create an ini file for testing
    terms = [u'test1=value1\ntest2=value2\ntest3=value3']
    ini = StringIO()
    ini.write(u'[section_one]\n')
    ini.write(terms[0])
    ini.seek(0, os.SEEK_SET)

    # Instantiate and test the lookup module
    lookup = LookupModule()
    cp = configparser.RawConfigParser()
    cp.readfp(ini)
    lookup.cp = cp
    key = 'test1'
    section = 'section_one'
    assert lookup.get_value(key, section, 'default', False) == 'value1'
    assert lookup.get_value(key, section, 'default', True) == 'value1'

    #

# Generated at 2022-06-21 06:08:02.138721
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    cp.optionxform = str
    cp.readfp(StringIO('[foo]\nbar=baz\nbiz=bang'))
    lookup_module.cp = cp
    assert lookup_module.get_value('bar', 'foo', None, False) == 'baz'
    assert lookup_module.get_value('.*', 'foo', None, True) == ['baz', 'bang']

# Generated at 2022-06-21 06:08:13.875215
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    mylookup = LookupModule()

    # test regexp
    cp = configparser.ConfigParser()
    cp.add_section('section')
    cp.set('section', 'keyA', 'valueA')
    cp.set('section', 'keyB', 'valueB')
    cp.set('section', 'keyC', 'valueC')
    mylookup.cp = cp

    result = mylookup.get_value('keyA', 'section', None, True)
    assert result == ['valueA']

    result = mylookup.get_value('key[AB]', 'section', None, True)
    assert result == ['valueA', 'valueB']

    result = mylookup.get_value('key[A-Z]', 'section', None, True)

# Generated at 2022-06-21 06:08:25.270791
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import tempfile

    with tempfile.NamedTemporaryFile('w') as tmp:
        # Write content in file
        tmp.write("[section]\n")
        tmp.write("key1=val1\n")
        tmp.write("key2=val2\n")
        tmp.write("key3=val3\n")
        tmp.write("key4=val4\n")
        tmp.write("key5=val5\n")
        tmp.write("key6=val6\n")
        tmp.flush()

        # Create a LookupModule
        lookup_module = LookupModule()

        # Use the file written
        lookup_module.cp = configparser.ConfigParser()
        # Open file using encoding

# Generated at 2022-06-21 06:08:36.843600
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import ansible.plugins.lookup.ini
    from ansible.module_utils.six.moves import configparser
    cp = configparser.ConfigParser()
    cp.optionxform = str
    data = u"""
[foo]
bar = baz
fubar =
spam = do not read this
    """
    cp.readfp(StringIO(data))
    assert ansible.plugins.lookup.ini.LookupModule.get_value(None, "bar", "foo", "NONE", False) == "baz"
    assert ansible.plugins.lookup.ini.LookupModule.get_value(None, "fubar", "foo", "NONE", False) == ""

# Generated at 2022-06-21 06:08:45.755847
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # type: () -> None
    lookup = LookupModule()
    config_parser_mock = configparser.ConfigParser()
    config_parser_mock.add_section('test')
    config_parser_mock.set('test', 'test', '1')
    config_parser_mock.set('test', 'test2', '2')
    lookup.cp = config_parser_mock

    ret = lookup.get_value('test', 'test', 'default', False)
    assert ret == '1'

    ret = lookup.get_value('test', 'test', 'default', True)
    assert ret == '1'

    ret = lookup.get_value('test2', 'test', 'default', False)
    assert ret == '2'


# Generated at 2022-06-21 06:08:52.742165
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser(allow_no_value=False)
    cp.read('ansible.ini')

    l = LookupModule()
    l.cp = cp
    assert l.get_value('key1', 'section1', '', False) == 'value1'
    assert l.get_value('key1', 'section1', '', True) == 'value1'
    assert l.get_value('key(.*)', 'section1', '', True) == ['value1', 'value2']
    assert l.get_value('key3', 'section3', '', False) == 'value3'
    assert l.get_value('key3', 'section3', '', True) == 'value3'

# Generated at 2022-06-21 06:08:55.673069
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None


# Generated at 2022-06-21 06:09:06.130987
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Read specific key from a specific section of a specific file
    terms = ['user']
    options = {
        'allowed_keys': ['file', 'section', 'encoding', 're', 'default'],
        'case_sensitive': False,
        'file': 'users.ini',
        'section': 'integration',
        'encoding': 'utf-8',
        're': False,
        'default': '',
    }
    config = StringIO()
    config.write(u'[integration]\n')
    config.write(u'user=yannig\n')
    config.seek(0, os.SEEK_SET)
    ret = [u'yannig']

    # Test
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()

# Generated at 2022-06-21 06:09:13.942267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    configparser_mock = configparser.ConfigParser()
    configparser_mock.items = lambda section: [(section + '-k1', section + '-v1'), (section + '-k2', section + '-v2')]
    configparser_mock.get = lambda section, option: '%s-%s' % (section, option)
    module_mock = LookupModule()
    module_mock.cp = configparser_mock
    assert module_mock.get_value('%s-.*' % 'section', 'section', None, True) == ['section-k1', 'section-v1', 'section-k2', 'section-v2']

# Generated at 2022-06-21 06:10:10.373625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
        test_LookupModule_run
        LookupModule.run()
    '''
    # Create LookupModule object
    lu = LookupModule()

    # Get fixtures
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'test_LookupModule_run')

    # ---- test 1 ----
    terms = ['user']
    variables = {'ansible_variable': fixtures_path}
    options = {
        'file' : 'users.ini',
        'section' : 'integration',
        'default' : '',
        're' : False,
        'encoding' : 'utf-8',
        'case_sensitive' : False
    }

    # Run method run
    ret = lu.run(terms, variables, **options)

# Generated at 2022-06-21 06:10:11.930846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert str(LookupModule) == "<class 'ansible.plugins.lookup.ini.LookupModule'>"


# Generated at 2022-06-21 06:10:20.999032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest, os
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import MutableSequence
    from io import StringIO
    from ansible.module_utils.six.moves import configparser

    # Set up a fake LookupBase object
    fake_loader = basic.AnsibleLoader()
    fake_loader.set_basedir(os.path.join(os.getcwd(), 'tests/test_lookup_plugin/files'))

# Generated at 2022-06-21 06:10:31.706796
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Mock ConfigParser
    class MockConfigParser(object):
        def __init__(self, *args, **kwargs):
            self.section = None
            self.is_allow_no_value = False

        def get(self, section, key):
            # Check if no section
            if section != 'integration':
                raise configparser.NoSectionError()

            # Check if wrong key
            if key != 'username':
                raise configparser.NoOptionError()

            return 'yperre'

        def items(self, section):
            # Check if no section
            if section != 'integration':
                raise configparser.NoSectionError()

            return [
                ('username', 'yperre'),
                ('password', 'secret')
            ]


# Generated at 2022-06-21 06:10:39.691186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock instance of class LookupModule
    lookup = LookupModule()

    # Create parameters to pass to the method run of LookupModule.
    terms = [
        'user',
        'hosts=192.168.0.101',
    ]
    params = dict(
        file="users.ini",
        section='integration',
        default="",
        type='ini',
        re=False,
        encoding='utf-8',
    )
    res = lookup.run(terms, params)
    assert res == ['yperre', '192.168.0.101']

# Generated at 2022-06-21 06:10:49.914403
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lm = LookupModule()
    # Run a test return a value from the ini file
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.seek(0, os.SEEK_SET)
    lm.cp.readfp(config)
    assert lm.get_value('key1', 'section1', None, False) == 'value1'
    assert lm.get_value('key2', 'section1', None, False) == 'value2'
    assert lm.get_value('key3', 'section1', 'value3', False) == 'value3'

    # Run a test return regexp values from the ini file


# Generated at 2022-06-21 06:11:01.794019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes

    # ansible 2.6
    import sys
    if sys.version_info[0] == 3:
        to_bytes = lambda x: x

    class TestObj(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return '%s(%r)' % (type(self).__name__, self.value)

        def __getattr__(self, name):
            if name == 'value':
                raise ValueError("bad")
            return getattr(self.value, name)

    from ansible.plugins.loader import lookup_loader

    lm = LookupModule()

    # input param, output parm, expected output

# Generated at 2022-06-21 06:11:13.753171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ----------------------------------
    # Run the test scenario
    # ----------------------------------
    # Create a instance of class LookupModule
    lookup_module = LookupModule()

    # Create a dict with the arguments
    paramvals = {'section': 'section1', 'file': 'tests/data/test.ini', 'default': '', 're': False, 'encoding': 'utf-8', 'type': 'ini'}


    # Set the current directory
    os.chdir(os.path.dirname(__file__))

    # Run the method run with the same sample data as in the ansible docs
    result = lookup_module.run(['key1'], [], paramvals)

    # Validate the result
    assert result[0] == 'value 1'



# Generated at 2022-06-21 06:11:19.994422
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    config = configparser.ConfigParser()
    config.add_section('MySection')
    config.set('MySection', 'MyKey', 'MyValue')
    lookup_module.cp = config

    result = lookup_module.get_value('MyKey', 'MySection', 'DefaultValue', False)
    assert result == 'MyValue', 'Result should be equal to MyValue'

    result = lookup_module.get_value('MyKey2', 'MySection', 'DefaultValue', False)
    assert result == 'DefaultValue', 'Result should be equal to DefaultValue because the key does not exist in the file'

    result = lookup_module.get_value('.*', 'MySection', 'DefaultValue', True)
    assert result == ['MyKey']


# Generated at 2022-06-21 06:11:33.408242
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1 : Method run returns empty list when key not found in given section
    module = LookupModule()
    res = module.run(["lookup_key"], {"file": "test_1", "section":"section_1"})
    assert res == [], "test case 1 : empty list returned when key not found in given section"

    # Test case 2 : Method run returns empty list when section name is not found in file
    module = LookupModule()
    res = module.run(["lookup_key"], {"file": "test_1", "section":"section_not_present"})
    assert res == [], "test case 2 : empty list returned when section name not found in file"

    # Test case 3 : Method run returns value when key present in given section
    module = LookupModule()

# Generated at 2022-06-21 06:12:25.234317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup_module = LookupModule()
    # Act and assert
    assert lookup_module.run([]) == []

# Generated at 2022-06-21 06:12:36.561587
# Unit test for method get_value of class LookupModule

# Generated at 2022-06-21 06:12:45.045917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  '''Test return value of method LookupModule.run()'''
  terms = ['ansible_version']
  # Create a config object
  c = configparser.ConfigParser()
  c.read('../../../../../ansible.cfg')
  # Create a LookupModule object
  lm = LookupModule()
  lm.cp = c
  # Test method run with different types
  assert lm.run(terms) == ['2.9.0']



# Generated at 2022-06-21 06:12:57.222073
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:13:05.708816
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test 1 : parameter is_regexp is False
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.add_section('TEST_SECTION')
    lookup_module.cp.set('TEST_SECTION', 'KEY1', 'VALUE1')
    assert 'VALUE1' == lookup_module.get_value('KEY1', 'TEST_SECTION', 'VALUE_DEFAULT', False)

    # Test 2 : parameter is_regexp is True
    assert 'VALUE1' == lookup_module.get_value('.*', 'TEST_SECTION', 'VALUE_DEFAULT', True)[0]

# Generated at 2022-06-21 06:13:15.719552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing a LookupModule object
    m = LookupModule()

    # Set the instance variable 'cp' of m
    m.cp = configparser.ConfigParser()

    # Create a file user.ini with 3 sections
    with open('user.ini', 'w') as file:
        file.write('[global]\nuser=toto\n[test]\nuser=titi\n[integration]\nuser=titi\n')

    # Retrieve the user configuration in section global
    m.get_value = lambda key, section=None, dflt=None, is_regexp=False: file.seek(0, os.SEEK_SET) or m.cp.get(section, key)
    ret = m.run(['user'], dict(), file='user.ini')

# Generated at 2022-06-21 06:13:25.683854
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Define some inputs
    key = "to"
    section = "DEFAULT"
    dflt = ""
    is_regexp = False
    lookup_module = LookupModule()
    # Define configparser object
    lookup_module.cp = configparser.ConfigParser(allow_no_value=False)
    # Define StringIO object
    config = StringIO()
    config_file_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__))) + "/test_lookup_plugins/test.ini"
    # Open file using encoding
    f = open(config_file_path, 'r')
    # Write file content to config object
    config.write(f.read())
    # Reset config from first line

# Generated at 2022-06-21 06:13:38.144000
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.SafeConfigParser()
    cp.readfp(StringIO(u'[section1]\nkey1=value1\nkey2=value2\n'))
    lm = LookupModule(loader=None, basedir=None)
    lm.cp = cp
    var = lm.get_value('key2', 'section1', 'default', False)
    assert(var == 'value2')
    # Add test to verify default value
    var = lm.get_value('key3', 'section1', 'default', False)
    assert(var == 'default')
    # Add test to verify regexp
    var = lm.get_value('key\\d', 'section1', 'default', True)
    assert(var == ['value1','value2'])
    # Add test to verify default

# Generated at 2022-06-21 06:13:43.055544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    config = "; comment\n[SERVER]\nhost=www.example.com\nip=1.1.1.1\n"
    l = LookupModule()
    l.cp = configparser.ConfigParser(allow_no_value=False)
    config = StringIO()
    config.write(to_text(config, encoding='utf-8'))
    config.seek(0, os.SEEK_SET)
    try:
        l.cp.readfp(config)
    except configparser.DuplicateOptionError as doe:
        raise AnsibleLookupError("Duplicate option in '{file}': {error}".format(file='test', error=to_native(doe)))

    terms = ["host", "ip"]

# Generated at 2022-06-21 06:13:49.843676
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lh = LookupModule()
    lh.cp = configparser.Parser()
    lh.cp.add_section('test')
    lh.cp.set('test', 'test1', 'test1')
    lh.cp.set('test', 'test2', 'test2')
    assert lh.get_value('test1', 'test', None, False) == 'test1'
    assert lh.get_value('test1', 'test', None, True) == ['test1']
    assert lh.get_value('test', 'test', None, True) == ['test1', 'test2']
    assert lh.get_value('test', 'test', None, False) == None