

# Generated at 2022-06-21 06:03:56.997942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run()


# Generated at 2022-06-21 06:04:07.385559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ## For ini plugin
    test_LookupModule_section1_key1()
    test_LookupModule_section1_key2()
    test_LookupModule_section1_key3()
    test_LookupModule_section1_key4()
    test_LookupModule_section1_key5()
    test_LookupModule_section2_key1()
    test_LookupModule_section2_key2()
    test_LookupModule_section2_key3()
    test_LookupModule_section2_key4()
    test_LookupModule_section2_key5()
    test_LookupModule_section3_key1()
    test_LookupModule_section99_key1()
    ## For properties plugin
    test_LookupModule_properties_key1()
    test_Lookup

# Generated at 2022-06-21 06:04:14.930446
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup.cp, configparser.ConfigParser)
    assert lookup.cp.allow_no_value == False

    # Test allow_no_value parameter
    lookup = LookupModule(allow_no_value=True)
    assert isinstance(lookup.cp, configparser.ConfigParser)
    assert lookup.cp.allow_no_value == True

# Generated at 2022-06-21 06:04:26.839545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Simple ini file

# Generated at 2022-06-21 06:04:27.939543
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert callable(LookupModule)

# Generated at 2022-06-21 06:04:35.880722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: move this test to an integration test, or at least to a lookup UT
    from ansible.module_utils.six import StringIO
    from ansible.plugins.loader import lookup_loader, action_loader
    from ansible.vars.manager import VariableManager

    lookup = LookupModule()
    lookup.set_loader(lookup_loader)
    lookup.set_inventory(VariableManager())
    lookup.set_action_plugin(action_loader.get('ini'))

    class Options:
        file = 'ansible.ini'
        section = None
        re = False
        encoding = None
        default = None
        type = 'ini'
        allow_none = False
        case_sensitive = True

    options = Options()
    # Test command with inline options
    config = StringIO()

# Generated at 2022-06-21 06:04:43.396080
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.RawConfigParser()
    string = u"""[section1]
key1 = value1
key2 = value2
key3 = value3

[section2]
key4 = value4
key5 = value5
key6 = value6

[section3]
key7 = value7
key8 = value8
key9 = value9
"""
    fp = StringIO(string)
    cp.readfp(fp)
    l = LookupModule()
    l.cp = cp

    # Test with a regular expression, section1 should be returned
    result = l.get_value("key1", "section1", "", True)
    assert result == ["value1"]

    # Test with a regexp and no match, default value should be returned

# Generated at 2022-06-21 06:04:49.132548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        import __main__
        __main__.__file__ = "ansible/lookup_plugins/ini.py"
        import ansible.lookup_plugins.ini
        lookup = ansible.lookup_plugins.ini.LookupModule()
    except ImportError:
        lookup = None

    assert lookup is not None, "LookupModule class not found"

# Generated at 2022-06-21 06:05:01.902223
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Initiate LookupModule
    obj = LookupModule()

    # Create a StringIO used to simulate an ini file
    obj.cp = configparser.ConfigParser()

    # create an ini file buffer
    stream = StringIO()
    stream.write(u'[section]\n')
    stream.write(u'key1=value1\n')
    stream.write(u'key2=value2\n')
    stream.write(u'key3=value3\n')
    stream.write(u'key4=value4\n')

    stream.seek(0, os.SEEK_SET)
    obj.cp.readfp(stream)

    # get_value should return key1
    assert obj.get_value('key1', 'section', None, False) == u'value1'

    #

# Generated at 2022-06-21 06:05:03.167287
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:05:23.301967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
# Retrieve a single value
    test_lookup_module = LookupModule()
    test_lookup_module.set_options(direct={'section': 'global', 'file': 'ansible.ini', 'type': 'properties'})
    assert test_lookup_module.run(terms=['user.name']) == ['Yogesh']
# Retrieve a single value with a regular expression
    test_lookup_module = LookupModule()
    test_lookup_module.set_options(direct={'section': 'global', 'file': 'ansible.ini', 'type': 'properties', 're': True})
    assert test_lookup_module.run(terms=['user\.*']) == ['Yogesh']
# Retrieve values from a section using a regular expression
    test_lookup_module = LookupModule()


# Generated at 2022-06-21 06:05:35.809034
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    parm_configparser = configparser.ConfigParser()
    parm_configparser.optionxform = str
    parm_configparser.readfp(StringIO("""
[integration]
user = Ansible

[production]
user = yannig
"""))

    # Create an instance of the LookupModule
    lookup = LookupModule()

    # Replace the protected member cp by a mock
    lookup.cp = parm_configparser

    # Replace the protected method find_file_in_search_path by a mock
    def parm_find_file_in_search_path():
        return "dummy"

    lookup.find_file_in_search_path = parm_find_file_in_search_path

    # Replace the protected member _loader by a mock

# Generated at 2022-06-21 06:05:48.110165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = [
        'key1-value',
        'key2-value',
        'key1-value key2-value',
        'key1-value key2-value key3=value',
        'key1-value key2-value file=my-file.ini section=my-section',
        'key3=value key1-value key2-value file=my-file.ini section=my-section'
    ]

    # Unit test of method _parse_params
    def test_LookupModule_run_parse_params():
        test_var_options = dict()

        test_var_options['file'] = 'file.ini'
        test_var_options['re'] = 'False'
        test_var_options['default'] = 'default_value'

# Generated at 2022-06-21 06:05:59.225980
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Check if regexp return all values
    cp = configparser.ConfigParser()
    test_str = StringIO()
    test_str.write(u"[section1]\n")
    test_str.write(u"key1=value1\n")
    test_str.write(u"key2=value2\n")
    test_str.write(u"key3=value3")
    test_str.seek(0, os.SEEK_SET)
    cp.readfp(test_str)
    lookup = LookupModule()
    lookup.cp = cp
    assert lookup.get_value('.*1', 'section1', None, True) == ['value1']
    assert lookup.get_value('.*', 'section1', None, True) == ['value1', 'value2', 'value3']


# Generated at 2022-06-21 06:06:02.803098
# Unit test for constructor of class LookupModule
def test_LookupModule():
    input_file = """
[section1]
key1=value1
key2=value2
    """
    lookup_module = LookupModule()
    config = StringIO(input_file)
    lookup_module.cp.readfp(config)
    values = lookup_module.get_value('key1', 'section1', 'default_test', False)
    assert values == "value1"

# Generated at 2022-06-21 06:06:15.144563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Ensure that the tested class is a subclass of LookupBase
    assert issubclass(LookupModule, LookupBase)

    # Create instance of LookupModule
    module = LookupModule()

    # Escape single quotes
    term = re.escape("[a b='c' d=\"e\" f=g h='i j' k\"l m=")

    # Create instance of configparser.ConfigParser
    cp = configparser.ConfigParser()
    orig_readfp = cp.readfp

    # Create instance of stringio.StringIO
    config = StringIO()
    config.write(u'[section0]\n')
    config.write(u'a=b\n')
    config.write(u'c=d\n')
    config.write(u'e=f\n')

# Generated at 2022-06-21 06:06:24.327697
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()

    config = StringIO("""
[section]
key=value
""")
    lookup_module.cp.readfp(config)

    assert lookup_module.get_value("key", "section", None, False) == "value"
    assert lookup_module.get_value("key", "section", None, True) == ["key=value"]
    assert lookup_module.get_value("^key", "section", None, True) == ["key=value"]
    assert lookup_module.get_value(".*", "section", None, True) == ["key=value"]

# Generated at 2022-06-21 06:06:30.748857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.plugins.lookup import LookupBase

    def test_get_value(self, key, section, dflt, is_regexp):
        return [dflt]

    LookupModule.get_value = test_get_value

    tmp = LookupModule()
    # Sanity test
    params = {'type': 'ini', 'file': 'ansible.ini', 'section': 'global', 're': False, 'default': '', 'case_sensitive': False}
    tmp.run([''], params)
    # Retrieve file path
    params = {'type': 'ini', 'file': 'test.ini', 'section': 'global', 're': False, 'default': '', 'case_sensitive': False}


# Generated at 2022-06-21 06:06:39.230097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from plugins.lookup.ini import LookupModule
    with open('test.ini', 'w') as f:
        f.write('[section1]\n')
        f.write('key1=value1\n')
        f.write('key2=value2\n')
        f.write('\n')
        f.write('[section2]\n')
        f.write('key3=value3\n')
        f.write('key4=value4\n')
        f.write('\n')
    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'case_sensitive': True})
    assert lookup_instance.run([('key1', {'section': 'section1'})]) == ['value1']

# Generated at 2022-06-21 06:06:48.369481
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    l = LookupModule()
    l.cp = configparser.ConfigParser()
    l.cp.add_section("test")
    l.cp.set("test", "foo", "bar")
    l.cp.set("test", "fooz", "barz")

    # get_value should return a single value
    assert l.get_value("foo", "test", "default", False) == "bar"
    # get_value should return a list
    assert l.get_value(".*", "test", "default", True) == ["bar", "barz"]
    # get_value should return a default value
    assert l.get_value("foo2", "test", "default", False) == "default"

# Generated at 2022-06-21 06:07:02.972521
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None, None).get_value('key', 'global', None, False) is None

# Generated at 2022-06-21 06:07:11.287760
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Case 1 : Get a single value using a regexp
    assert(LookupModule().get_value('^[a-z]+$', 'section1', '', True) == ['aaaaaaaa'])
    # Case 2 : Get a single value using a regexp with lowercase escaped
    assert(LookupModule().get_value('^[a-z\\\\]+$', 'section1', '', True) == ['aaaaaaaa\\\\'])
    # Case 3 : Get a single value using a regexp with uppercase escaped
    assert(LookupModule().get_value('^[a-z\\\\\\\\]+$', 'section1', '', True) == ['aaaaaaaa\\\\\\\\'])
    # Case 4 : Get a single value using a regexp with escaped escaped

# Generated at 2022-06-21 06:07:21.889585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test configuration
    test_lookup_result = [u'self.lookup_result']

    # Test cases
    class TestCase:
        def __init__(self, term, find_file_result, get_value_result, expected_msg):
            self.term = term
            self.find_file_result = find_file_result
            self.get_value_result = get_value_result
            self.expected_msg = expected_msg


# Generated at 2022-06-21 06:07:33.669184
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    '''Test for method get_value of class LookupModule'''
    lm = LookupModule()
    lm.cp = configparser.RawConfigParser()
    lm.cp.readfp(StringIO("""
[test]
key1 = value1
key2 = value2
key3 = value3
key4 = value4
key5 = value5
key6 = value6
"""))
    assert lm.get_value('key1', 'test', 'default', False) == 'value1'
    assert lm.get_value('key2', 'test', 'default', False) == 'value2'
    assert lm.get_value('key3', 'test', 'default', False) == 'value3'

# Generated at 2022-06-21 06:07:42.073507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable_manager = VariableManager()
    loader = DataLoader()
    lookup_module = LookupModule(loader=loader, variable_manager=variable_manager)
    paramvals = {
        'file': 'examples/ini_sample.ini',
        'default': 'NOT_FOUND',
        'type': 'ini',
        're': False,
        'encoding': 'utf-8',
        'allow_none': False,
        'case_sensitive': False,
    }
    # No key given
    result = lookup_module.run(['parameters_but_not_key'], paramvals)
    assert result == ['parameters_but_not_key']
    # A key given
    result = lookup_module.run(['key1', 'key2'], paramvals)

# Generated at 2022-06-21 06:07:54.339263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()

    # Unit test without terms parameter
    result = mod.run(terms=None, variables=None, file='file.ini', section='section')
    assert result == []

    # Unit test with file not found
    result = mod.run(terms=['key1'], variables=None, file='file2.ini', section='section')
    assert result == []

    # Unit test with file exists
    result = mod.run(terms=['key1'], variables=None, file='file.ini', section='section')
    assert result == ['value1']

    # Unit test with section not exists
    result = mod.run(terms=['key1'], variables=None, file='file.ini', section='section_not')
    assert result == []

    # Unit test with key not exists

# Generated at 2022-06-21 06:08:05.436327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # initialization
    assert l.cp.optionxform == to_native, "Failed to initialize cp to configparser"
    # get_value
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.add_section('global')
    cp.set('global', 'user', 'yannig')
    l.cp = cp
    assert l.get_value('user', 'global', None, False) == 'yannig', 'get_value failed'
    assert l.get_value('user', 'global', None, True) == ['yannig'], 'get_value with regexp failed'
    assert l.get_value('.*', 'global', None, True) == ['yannig'], 'get_value with regexp failed'
    assert l.get_value

# Generated at 2022-06-21 06:08:09.909168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm._load_name = "ini"
    lm.run([], None, file="ini.txt", encoding="ascii")

# Generated at 2022-06-21 06:08:15.780974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize LookupModule instance
    lookup_module = LookupModule()
    # Assert that file 'ansible.ini' is found in the path
    assert lookup_module.find_file_in_search_path({}, 'files', 'ansible.ini')

# Generated at 2022-06-21 06:08:16.916965
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, object)

# Generated at 2022-06-21 06:08:41.638661
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:08:54.426166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Check how run() return values from file 'test.ini'
    terms = ["key1", "key2", "key4", "key4", "key4"]
    variables = dict(file="test.ini", section="section1", re="False", default="")
    results = lookup.run(terms, variables)
    assert results == ["value1", "value2", "", "", ""]

    # Check how run() return values from file 'test.ini' (with regexp)
    terms = [".*"]
    variables = dict(file="test.ini", section="section1", re="True", default="")
    results = lookup.run(terms, variables)
    assert results == ["value1", "value2", "value3", "value4"]

    # Check how run() throw exception on bad

# Generated at 2022-06-21 06:08:59.609951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock a class with a lookup_fail() method which returns a single value
    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return map(lambda x: 'bar', terms)

    m = LookupModule()
    # Mock the get_option function
    class Options:
        def __init__(self, **entries):
            self.entries = entries
        def __getitem__(self, key):
            return self.entries[key]
        def __setitem__(self, key, value):
            self.entries[key] = value
        def get(self, key, default=''):
            return self.entries.get(key, default)

    m.set_options(Options({'default': 'unknown'}))

    # Test an empty terms list

# Generated at 2022-06-21 06:09:01.583363
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-21 06:09:14.973205
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test retrieving a single value
    test_term = 'key1'
    test_section = 'section'
    test_key = "test_key1"
    test_value = "test_value1"
    test_dflt = "test_default"
    test_is_regexp = False

    # Create mock class
    class MockClass:
        def __init__(self):
            self.items = {test_key: test_value}

        def get(self, section, key):
            try:
                return self.items[key]
            except KeyError:
                return None

    mock_cp = MockClass()
    modules = LookupModule()
    assert modules.get_value(test_key, test_section, test_dflt, test_is_regexp) == test_value
    modules.cp

# Generated at 2022-06-21 06:09:16.968784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    #ret = module.run([], {}, _terms=[], _params={'file': 'ansible.ini', 'section':'global'})

# Generated at 2022-06-21 06:09:19.437692
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule(None, None, None, {'file': 'test/test.ini'})
        assert false
    except AssertionError as ae:
        raise ae
    except Exception as e:
        # Expected result
        assert True



# Generated at 2022-06-21 06:09:20.093899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-21 06:09:33.778820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    test_terms = ('ik', 'section1', 'section2', 'section3')
    test_section = 'section1'
    test_dflt = 'dflt'
    test_is_regexp = True
    test_variables = {'_terms': 'term1, term2', 'term1': 'val1', 'term2': 'val2', 'test_variables': 'test_variables'}
    test_paramvals = {'type': 'test_type', 'file': 'test_file', 'section': test_section, 're': test_is_regexp, 'default': test_dflt}
    # TODO: add test for file 'ansible.ini'
    test_set_options = Mock()
    test_get_

# Generated at 2022-06-21 06:09:46.257082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    class Item:
        def __init__(self, name, value):
            self._args = {'name': name, 'value': value}
    class Collection:
        def __getitem__(self, name):
            return Item(name, name)
    class FileSystem:
        def exists(self, path):
            return True
        def is_file(self, path):
            return True
        def open(self, path):
            return StringIO("""[java_properties]
property = value
""")
    lookup.set_options(var_options={'_original_file': 'file'}, direct={'file': 'file'})
    lookup._loader._collection = Collection()
    lookup._loader._basedir = '.'
    lookup._loader._fs = FileSystem()

# Generated at 2022-06-21 06:10:21.117915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common._collections_compat import MutableSequence
    ll = LookupModule()
    ll.cp = configparser.ConfigParser(allow_no_value=False)
    ll.cp.readfp(StringIO(u'[global]\nuser=yannigperre\n'))

    # Test a single key
    result = ll.get_value('user', 'global', '', False)
    assert result == u'yannigperre'

    # Test a regexp
    result = ll.get_value('.*', 'global', '', True)
    assert isinstance(result, MutableSequence)
    assert result == ['yannigperre']

    # Test a regexp with not matching pattern

# Generated at 2022-06-21 06:10:31.764259
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:10:38.155555
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lk = LookupModule()
    cp = configparser.ConfigParser()
    cp.optionxform = str  # Change optionxform to keep case
    lk.cp = cp


# Generated at 2022-06-21 06:10:43.627902
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test_LookupModule"""
    # instance of LookupModule
    lookup_module = LookupModule()
    # test if type is LookupBase
    assert isinstance(lookup_module, LookupBase)


# Generated at 2022-06-21 06:10:52.999292
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class TestLookupModule_get_value(LookupModule):
        def __init__(self):
            self.cp = configparser.ConfigParser()

    l = TestLookupModule_get_value()
    l.cp.add_section('test_section')
    l.cp.set('test_section', 'key1', 'regex1')
    l.cp.set('test_section', 'key2', 'value2')
    l.cp.set('test_section', 'key3', 'value3')
    l.cp.set('test_section', 'key4', 'value4')

    # Test with re=False
    assert l.get_value('key1', 'test_section', 'default1', False) == "regex1"

# Generated at 2022-06-21 06:11:02.863553
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()

    # Retrieve value for an existing key using a regexp
    cp = configparser.ConfigParser()
    test_file = 'tests/test_lookup_plugins/ini/test.ini'
    with open(test_file) as f:
        cp.readfp(f)
    lookup_module.cp = cp
    value = lookup_module.get_value('bar', 'section1', 'default', True)
    assert value == ['bar2']

    # Retrieve value for a non-existing key using a regexp
    value = lookup_module.get_value('bar3', 'section1', 'default', True)
    assert value == []

    # Retrieve value for a regexp that match multiple keys

# Generated at 2022-06-21 06:11:14.441622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    lookup = LookupModule()
    test = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3'
    }

    def get_value(key, section, dflt, is_regexp):
        return test[key]

    lookup.get_value = get_value

    term = 'key1'
    paramvals = {
        'file': 'ansible.ini',
        'section': 'section1',
        're': False,
        'encoding': 'utf-8',
        'type': 'ini',
        'default': ''
    }
    result = lookup.run([term], paramvals=paramvals)

    assert result[0] == 'value1'


# Generated at 2022-06-21 06:11:19.135377
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser()
    cp.readfp(StringIO('[global]\nfoo=bar\n'))
    lm = LookupModule()
    lm.cp = cp
    eq_(lm.get_value('foo', 'global', '', False), 'bar')
    lm.cp.readfp(StringIO('[section1]\nfoo.key1=bar1\nfoo.key2=bar2\n'))
    eq_(lm.get_value('.*', 'section1', '', True), ['bar1', 'bar2'])

# Generated at 2022-06-21 06:11:33.174887
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test that the run method can retrieve the user in integration
    test = LookupModule()
    test.cp = configparser.RawConfigParser()
    test.cp.add_section('integration')
    test.cp.set('integration', 'user', 'John')
    test.cp.add_section('production')
    test.cp.set('production', 'user', 'Jack')
    term = 'user'
    paramvals = {'section':'integration', 'file':'users.ini'}
    assert test.get_value(term, paramvals['section'], paramvals.get('default', ''), paramvals.get('re', False)) == 'John'

    # Test that the run method can retrieve the user in production
    test = LookupModule()
    test.cp = configparser.RawConfigParser()

# Generated at 2022-06-21 06:11:44.350019
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a LookupModule object
    lm = LookupModule()
    # Create a ConfigParser object
    cp = configparser.ConfigParser()
    cp.read('test.ini')
    # Set the attribute cp
    lm.cp = cp
    # Test with a section containing the key
    assert lm.get_value('key1', 'section1', 'default', False) == 'value1'
    # Test with a section not containing the key
    assert lm.get_value('key2', 'section1', 'default', False) == 'default'
    # Test with a regexp
    assert lm.get_value('^key', 'section1', 'default', True) == ['key1']

# Generated at 2022-06-21 06:12:56.664101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Imports needed for unit tests
    from ansible.template import Templar

    module = LookupModule()
    templar = Templar(loader=None, variables={})
    terms = [
        'user section1 file=test.ini',
        'user section1 file=test.ini re'
    ]
    for term in terms:
        result = module.run([term], templar._available_variables)
        assert len(result) == 1
        assert result == ['testuser']

# Generated at 2022-06-21 06:13:04.094241
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockLoader(object):

        def _get_file_contents(self, path):
            return 'ini_file=test_ini_file', None
    config = configparser.RawConfigParser()
    config.optionxform = str
    config.readfp(StringIO('ini_file=test_ini_file'))

    lookup = LookupModule()
    lookup.cp = config
    lookup._loader = MockLoader()
    assert lookup.run('ini_file') == ['test_ini_file']

# Generated at 2022-06-21 06:13:05.410673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 06:13:08.099352
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 06:13:11.115087
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(terms=['hostname', 'port'], variables={}, type='ini', file='ansible.ini')

# Generated at 2022-06-21 06:13:15.405613
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ unit tests for the LookupModule constructor
    """

    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-21 06:13:17.625695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for constructor of class LookupModule.'''
    lookup_module = LookupModule()
    assert lookup_module is not None, 'Failed to create an instance of class LookupModule.'


# Generated at 2022-06-21 06:13:22.536129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["key1", "key2=value2", "key3=value3"], {"ini_file": "unit-test.ini"}) == \
           ["value1", "", "value3"]



# Generated at 2022-06-21 06:13:31.131531
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    def mock_get(*args, **kwargs):
        # If we were called with the right 'section', we return our mock items.
        if args[1] == 'section1':
            return [('key1', 'value1'), ('key2', 'value2')]
        else:
            return [('key3', 'value3')]

    class ConfigParserMock(configparser.ConfigParser, object):
        """
        A mock class to simulate configparser.ConfigParser behaviour, with a
        mocked 'items' method.
        """
        def __init__(self, *args, **kwargs):
            self._items = mock_get

        def items(self, *args, **kwargs):
            return self._items(*args, **kwargs)

    lookup_module = LookupModule()
    lookup_module.cp = ConfigParser

# Generated at 2022-06-21 06:13:38.144216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a temp file
    f = open("users.ini", "w")
    f.write("[global]\nuser=toto\n\n[integration]\nuser=titi\n")
    f.close()

    module = LookupModule()
    module.set_options({'file': 'users.ini',
                        'section': 'global'})
    # Test return value
    assert module.get_value("user", module.get_options()['section'], "", False) == "toto"

    # Clean
    os.remove("users.ini")