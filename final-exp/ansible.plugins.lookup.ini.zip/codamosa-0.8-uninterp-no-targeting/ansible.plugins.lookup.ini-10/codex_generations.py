

# Generated at 2022-06-21 06:04:05.439609
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Get the current path of the lookup_plugins directory
    lookup_plugin_dir = os.path.dirname(os.path.abspath(__file__)).split('/')
    lookup_plugin_dir.pop(-1)
    lookup_plugin_dir.append('lookup_plugins')

    custom_dir = os.path.join(*lookup_plugin_dir)

    # Create a custom lookup object
    custom_lookup = LookupModule()

    # Load the ini file
    config = StringIO()

# Generated at 2022-06-21 06:04:07.427898
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run(["user=some_user", "file=some_file"])

# Generated at 2022-06-21 06:04:20.356729
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a fake config parser to mock the content of the ini file
    cp = configparser.ConfigParser()
    cp.add_section('test_section')
    cp.set('test_section', 'key1', 'value1')
    cp.set('test_section', 'key2', 'value2')
    # Create a LookupModule object
    lm = LookupModule()
    # Mock the configparser object
    lm.cp = cp

    # Test that key1 and key2 exists in the ini file in the test_section section
    assert lm.get_value('key1', 'test_section', '', False) == 'value1'
    assert lm.get_value('key2', 'test_section', '', False) == 'value2'

    # Test that the default value is returned when key3 is not

# Generated at 2022-06-21 06:04:30.723461
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    """
    This test will check if the method get_value of class LookupModule works with the following conditions:

        - regexp : True
        - regexp : False
        - regexp : True and raise exception

    :return: Unit test Ok if the method returns the expected values
    """
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create configparser object
    cp = configparser.ConfigParser()
    cp.add_section('test')

    # config.ini content
    config_ini = '[test]\nname = John\n'

    # Create StringIO
    config = StringIO()
    config.write(config_ini)
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)

    # Expected values

# Generated at 2022-06-21 06:04:39.937745
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    # Create StringIO later used to parse ini
    config = StringIO()
    config.write("section1:\n"
                 "  key1=value1\n"
                 "  key2=value2\n"
                 "section2:\n"
                 "  keyA=valueA\n"
                 "  keyB=valueB\n")
    config.seek(0, os.SEEK_SET)
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(config)

    # Test get_value
    assert lookup_module.get_value("key1", "section1", "", False) == "value1"
    assert lookup_module.get_value("key2", "section1", "", False) == "value2"


# Generated at 2022-06-21 06:04:49.646627
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test configuration
    test_terms = [
        'user',
        'user=test@example.com',
        'user=test@example.com file=test.ini',
        'user=test@example.com file=test.ini section=test_section',
        'user=test@example.com file=test.ini section=test_section default=nodefault',
        'user=test@example.com file=test.ini section=test_section default=nodefault re=True',
        '^usr=test@example.com file=test.ini section=test_section default=nodefault re=True case_sensitive=True'
    ]

    # Unit test
    # mock config file
    # TODO: not sure how to mock it so that it will be used by class configparser.ConfigParser
    contents

# Generated at 2022-06-21 06:04:56.042898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing run method of LookupModule with a ini file
    try:
        import ansible.parsing.vault
        HAS_VAULT_LIBRARY = True
    except ImportError:
        HAS_VAULT_LIBRARY = False

    lookup = LookupModule()

    # build path
    test_path = os.path.dirname(__file__)
    test_ini_file = os.path.join(test_path, 'test.ini')
    test_no_option_file = os.path.join(test_path, 'test_no_option.ini')
    test_with_no_value = os.path.join(test_path, 'test_with_no_value.ini')
    test_java_properties_file = os.path.join(test_path, 'test.properties')


# Generated at 2022-06-21 06:05:07.242225
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import alarm
    import unittest

    class TestLookupModule(unittest.TestCase):
        def test_get_value(self):
            # Test for a single key in a section
            cp = configparser.ConfigParser(allow_no_value=True)
            cp.optionxform = to_native
            config = StringIO(u'[global]\nuser=admin\nuser2=admin\nuser3=admin\n')
            config.seek(0, os.SEEK_SET)
            cp.readfp(config)
            self.assertEqual(alarm.LookupModule.get_value('user', 'global', '', False), u'admin')
            # Test for a single regexp key in a section

# Generated at 2022-06-21 06:05:19.164897
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class TestLookupModule(LookupModule):
        def __init__(self):
            self.cp = configparser.ConfigParser()

    testLookupModule = TestLookupModule()

    section = 'PRODUCTION'

    testLookupModule.cp.add_section(section)
    testLookupModule.cp.set(section, 'ExpectedKey', 'ExpectedValue')
    testLookupModule.cp.set(section, 'AnotherExpectedKey', 'AnotherExpectedValue')

    assert testLookupModule.get_value('ExpectedKey', section, '', False) == 'ExpectedValue'
    assert testLookupModule.get_value('AnotherExpectedKey', section, '', False) == 'AnotherExpectedValue'


# Generated at 2022-06-21 06:05:31.770152
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        'user',
        'password',
        'user=root',
        'password=pass',
        'password=pass file=test.ini',
        'password section=test',
        'password section=test file=test.ini'
    ]

    lookup = LookupModule()

    # Tests when default values are used
    ret = lookup.run(terms)
    assert ret == ['ansible', 'ansible', 'root', 'pass', 'pass', 'ansible', 'ansible']

    # Tests when file option is used
    user = 'user=ansible file=test.ini'
    passwd = 'password=ansible file=test.ini'
    ret = lookup.run([user, passwd])
    assert ret == ['ansible', 'ansible']

    # Tests when section option is used
    user

# Generated at 2022-06-21 06:05:53.120133
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check ini file
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

    # Check properties file
    lookup = LookupModule()
    lookup.set_options(direct={'type': 'properties'})
    paramvals = lookup.get_options()
    assert paramvals['type'] == 'properties'

    # Check file with invalid type
    e = None
    try:
        lookup = LookupModule()
        lookup.set_options(direct={'type': 'invalid'})
    except Exception as error:
        e = error
    assert isinstance(e, AnsibleOptionsError)

    # Check encoding and default value
    lookup = LookupModule()
    lookup.set_options(direct={'encoding': 'ascii', 'default': 'my default'})

# Generated at 2022-06-21 06:06:05.433681
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.module_utils._text import to_text

    # Create a LookupModule object and add some configs for testing
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.optionxform = to_native
    lookup_module.cp.add_section("section1")
    lookup_module.cp.set("section1", "key", "value")
    lookup_module.cp.set("section1", "key_a", "value_a")
    lookup_module.cp.set("section1", "key_b", "value_b")
    lookup_module.cp.add_section("section2")
    lookup_module.cp.set("section2", "key", "value")

# Generated at 2022-06-21 06:06:13.846278
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test get_value method
    lunit = LookupModule()
    config = StringIO()
    config.write(u"[section1]\n")
    config.write(u"RegularKey1=RegularValue1\n")
    config.write(u"RegularKey2=RegularValue2\n")
    config.write(u"RegexKey=RegexValue\n")
    config.seek(0, os.SEEK_SET)
    lunit.cp.readfp(config)
    assert lunit.get_value("RegularKey1", "section1", "", False) == "RegularValue1"
    assert lunit.get_value(".*RegexKey", "section1", "", True) == ["RegexValue"]

# Generated at 2022-06-21 06:06:22.018831
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Test when single value to retrieve with no re
    cp = configparser.ConfigParser()
    cp.readfp(StringIO(u'[global]\nuser=bob\n'))
    lm = LookupModule()
    lm.cp = cp
    assert lm.get_value('user', 'global', None, False) == 'bob'

    # Test when single value to retrieve with re
    cp = configparser.ConfigParser()
    cp.readfp(StringIO(u'[global]\nuser=bob\n'))
    lm = LookupModule()
    lm.cp = cp
    assert lm.get_value('.*', 'global', None, True) == ['user=bob']

    # Test when multiple values to retrieve with re
    cp = configparser.ConfigParser()


# Generated at 2022-06-21 06:06:28.753991
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Fake variables
    variables = dict(
        ansible_managed="Ansible managed: {file}",
        ansible_user="User",
        ansible_password="Password"
    )

    # Create fake term
    term = "ansible_login"

    # Create fake ansible options
    ansible_options = dict(
        _raw_params="",
        _original_base_path="/tmp/ansible/base_path",
        _original_file="base_path/file",
        _original_follow=True,
        _original_path="/tmp/ansible/base_path/file"
    )

    # Create fake lookup_base_obj

# Generated at 2022-06-21 06:06:33.356312
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lines = ['[section1]', 'item_name1 = value1']
    config = StringIO()
    config.write(u'\n'.join(lines) + u'\n')
    config.seek(0, os.SEEK_SET)
    cp = configparser.ConfigParser()
    cp.readfp(config)
    # Test regexp True
    lm = LookupModule()
    lm.cp = cp
    assert lm.get_value('.*', 'section1', '', True) == ['item_name1 = value1']
    # Test regexp False
    assert lm.get_value('item_name1', 'section1', '', False) == 'value1'

# Generated at 2022-06-21 06:06:39.818014
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create class LookupModule
    lm = LookupModule()

    # Create object cp
    cp = configparser.ConfigParser()

    # Check if cp is an object
    assert isinstance(cp, configparser.ConfigParser)
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:06:48.961396
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Create a lookupmodule
    l = LookupModule()

    # Launch method with a valid section and a key
    assert "value1" == l.get_value("key1", "section1", "", False)

    # Launch method with a valid section and a key (regexp)
    assert "key1" == l.get_value("k", "section1", "", True)[0]

    # Launch method with a valid section and a key but with a regexp
    assert "value1" == l.get_value("key1", "section1", "", True)[0]

    # Launch method with a valid section and a key but with a regexp
    assert "key1" == l.get_value("k", "section1", "", False)

# Generated at 2022-06-21 06:06:57.138558
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Prepare parameters
    terms = ['user', 'password']
    section = 'integration'
    file_name = 'users.ini'
    config = StringIO()
    config.write("""
    [integration]
    user = name
    password = passwd
    """)
    config.seek(0, os.SEEK_SET)
    cp = configparser.ConfigParser()
    cp.readfp(config)
    # Mock LookupModule
    lookup = LookupModule()
    lookup.cp = cp
    # Run the test
    result = lookup.run(terms, section=section, file=file_name, default=None)
    # Verify results
    assert result == [u'name', u'passwd']

# Generated at 2022-06-21 06:07:03.306190
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # Testing anomalies
    ## TODO: deprecate this method
    assert _parse_params("", {"key": "value"}) == []

    ## TODO: deprecate this method
    assert _parse_params("key=val1 key=val2", {"key": "value"}) == ["key=val1", "key=val2"]

    ## TODO: deprecate this method
    assert _parse_params("key=val1 key=val2", {"key1": "value1"}) == ["key=val1", "key=val2"]

    ## TODO: deprecate this method
    assert _parse_params("key=val1 key1=val2", {"key": "value"}) == ["key=val1", "key1=val2"]

    ## TODO: deprecate this

# Generated at 2022-06-21 06:07:35.526271
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert LookupModule().run(terms=['user=toto'], variables={}, file='ansible.ini', section='global') == ['toto']
    assert LookupModule().run(terms=['user', 'group'], type='properties', file='ansible.properties', re=False, default='default', section='java_properties') == ['toto', 'user']
    assert LookupModule().run(terms=['user'], type='properties', file='ansible.properties', re=False, default='default', section='java_properties') == ['toto']
    assert LookupModule().run(terms=['nokey'], type='properties', file='ansible.properties', re=False, default='default', section='java_properties') == ['default']

# Generated at 2022-06-21 06:07:39.079381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-21 06:07:52.793292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re
    import tempfile
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_text = 'vault test'
    vault = VaultLib([('default', VaultSecret(vault_text))])

    # test a normal section
    ini_text = '''[normal]
    normal = normal'''
    ini_fp = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-21 06:08:03.645251
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_lookup=LookupModule()

    # Retrieve all values from a section using a regexp
    cp_regexp = configparser.ConfigParser()
    cp_regexp.add_section('test_ini')
    cp_regexp.set('test_ini', 'key1', u'test1')
    cp_regexp.set('test_ini', 'key2', u'test2')
    cp_regexp.set('test_ini', 'key3', u'test3')
    test_lookup.cp = cp_regexp
    assert_re = ['test1', 'test2', 'test3']
    assert_re_empty = []

    ret_re = test_lookup.get_value('key.', 'test_ini', '', True)

# Generated at 2022-06-21 06:08:15.350177
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Load file and parse it
    def _get_file_contents(filename):
        with open(filename) as file:
            config = StringIO()
            config.write(u'[global]\n')
            config.write(file.read())
            config.seek(0, os.SEEK_SET)
        return (config.getvalue(), None)

    class FakeLoader:
        def __init__(self):
            self._variable_manager = None

        def _get_file_contents(self, path):
            return _get_file_contents(path)

    lookup_module = LookupModule()
    # Patching find_file_in_search_path method
    lookup_module.find_file_in_search_path = lambda x, y, z: 'tests/unittest_data/%s'

# Generated at 2022-06-21 06:08:25.861619
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    #############################################################################################
    # Case 1 - Return None
    #############################################################################################

    module.cp = configparser.ConfigParser()
    module.cp.add_section('global')
    module.cp.set('global', 'user', 'foo')

    ret = module.get_value('user_unknown', 'global', 'default', False)
    assert ret == 'default'

    #############################################################################################
    # Case 2 - Return defautl
    #############################################################################################

    module.cp = configparser.ConfigParser()
    module.cp.add_section('global')
    module.cp.set('global', 'user', 'foo')

    ret = module.get_value('user_unknown', 'global', 'default', False)
    assert ret == 'default'

   

# Generated at 2022-06-21 06:08:37.167138
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test if regexp return expected values
    l_m = LookupModule()
    config = StringIO()
    config.write(u'[section1]\nkey1=value1\nkey2=value2')
    config.write(u'[section2]\nkey3=value3\nkey4=value4')
    config.seek(0, os.SEEK_SET)
    l_m.cp.readfp(config)
    assert l_m.get_value(".*1", "section1", "", True) == ["value1"]
    assert l_m.get_value(".*1", "section2", "", True) == []
    # Test if normal return expected values
    assert l_m.get_value("key3", "section2", "", False) == "value3"
   

# Generated at 2022-06-21 06:08:40.430834
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert type(module) is LookupModule


# Generated at 2022-06-21 06:08:55.007536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test good term
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section("global")
    lookup.cp.set("global", "ansible", "True")
    lookup.cp.set("global", "community", "Awesome")
    result = list(lookup.run(["ansible"]))
    assert len(result) == 1
    assert result[0] == "True"

    # Test with regexp
    result = list(lookup.run(["^ansible"]))
    assert len(result) == 2
    assert "True" in result
    assert "Awesome" in result

    # Test with a more complex regexp
    result = list(lookup.run(["^ans"]))
    assert len(result) == 3
    assert "True" in result


# Generated at 2022-06-21 06:09:04.133269
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Testing with a section without value
    error_message = "No section 'non_existent_section' in file"
    ini_content = """[non_existent_section]
    key=val"""

    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module.cp.readfp(StringIO(ini_content))

    try:
        lookup_module.get_value("non_existent_key", "non_existent_section", None, False)
    except AnsibleLookupError as e:
        assert e.message == error_message

# Generated at 2022-06-21 06:09:54.105798
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, dict(), dict(), dict(), dict())

# Generated at 2022-06-21 06:10:07.098154
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    value_test = LookupModule()
    value_test.cp = configparser.SafeConfigParser()
    with open('test/ini_test.ini') as config_file:
        value_test.cp.readfp(config_file)
    assert value_test.get_value('user', 'dog', '', False) == 'canigou'
    assert value_test.get_value('user', 'user', '', False) == 'canigou'
    assert value_test.get_value('user', 'global', '', False) == 'canigou'
    assert value_test.get_value('user', 'cat', '', False) == 'felix'
    assert value_test.get_value('user', 'fish', '', False) == 'nemo'

# Generated at 2022-06-21 06:10:10.340371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception:
        assert False


# Generated at 2022-06-21 06:10:16.911980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate the LookupModule
    lookup = LookupModule()
    result = lookup.run(["key1=value1", "key2=value2"], dict(type="ini", section="section1", encoding="utf-8"))
    # It's not possible to test the result of run because it returns 'None'
    # Verify run method is working:
    assert(run() == None)

# Generated at 2022-06-21 06:10:29.792539
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test default configuration
    lookup = LookupModule()
    assert lookup.cp.get('global', 'key') == ''
    assert lookup.cp.get('global', 'type') == 'ini'
    assert lookup.cp.get('global', 'file') == 'ansible.ini'
    assert lookup.cp.get('global', 'default') == ''
    assert lookup.cp.get('global', 'section') == 'global'
    assert lookup.cp.get('global', 'case_sensitive') == 'False'
    # Test configuration with option=value
    lookup = LookupModule("key=value")
    assert lookup.cp.get('global', 'key') == 'value'
    # Test configuration with many options
    lookup = LookupModule("key1=value1 key2=value2")

# Generated at 2022-06-21 06:10:40.905155
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # type="properties"
    term = dict(
        key='user.name',
        type="properties",
        file="user.properties",
        section="properties",
        re=False
    )
    # user.name=yannig
    lookup_module = LookupModule()
    lookup_module.find_file_in_search_path = lambda x, y, z: z
    lookup_module._loader._get_file_contents = lambda path: ("user.name=yannig", '')
    assert lookup_module.run([term['key']], variables=None, **term) == ["yannig"]

    # type="ini"
    term = dict(
        key='user',
        type="ini",
        file="users.ini",
        section="global",
        re=False
    )
    lookup_

# Generated at 2022-06-21 06:10:50.834321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create help classes
    class VarModule(object):

        def __init__(self, return_value):
            self.return_value = return_value

        def vars(self):
            return self.return_value

    class MyConfigParser(configparser.ConfigParser):

        def __init__(self, allow_no_value, return_value):
            super().__init__(allow_no_value=allow_no_value)
            self.return_value = return_value
            self.sections = []

        def get(self, section, key):
            self.sections.append(section)
            return self.return_value

    class LookupBaseClass(object):

        def __init__(self):
            self._loader_mock = None
            self._templar_mock = None

# Generated at 2022-06-21 06:10:51.965189
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test for constructor
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 06:10:59.777580
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    """
    This is test for method run of class LookupModule
    """

    print()
    # Create a simple configuration file
    config = StringIO()
    config.write(u'[users]\n'
                 u'user1=yperre\n'
                 u'user2=yannig\n'
                 u'user3=yannig\n'
                 u'\n'
                 u'[integration]\n'
                 u'user=yperre\n'
                 u'password=password1\n'
                 u'\n'
                 u'[production]\n'
                 u'user=yperre\n'
                 u'password=password2\n')

    config.seek(0, os.SEEK_SET)

# Generated at 2022-06-21 06:11:02.247885
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:12:02.923965
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_object = LookupModule()

    # Test regular expression
    assert test_object.get_value(r".*", "test", None, True) == []
    assert test_object.get_value(r"key3", "test", None, True) == ["val3"]

    # Test no section
    with pytest.raises(AnsibleLookupError) as context:
        test_object.get_value("key3", "test2", None, False)

    # Test default value
    assert test_object.get_value("key1", "test", "default", False) == "val1"
    assert test_object.get_value("key4", "test", "default", False) == "default"



# Generated at 2022-06-21 06:12:10.023843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.cp = FakeConfigParser()
    #
    # test data
    #
    terms = ['api_key']
    kwargs = {'case_sensitive': False,
              'default': '',
              'encoding': 'utf-8',
              'file': 'test.ini',
              're': False,
              'section': 'yannigperre',
              'type': 'ini'}
    #
    # test
    #
    ret = lookup.run(terms, **kwargs)
    #
    # assert
    #
    assert(ret == ['123456789'])


# Generated at 2022-06-21 06:12:16.687720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from textwrap import dedent
    import sys

    if sys.version_info[0] != 3:
        print("This unit test must be run with python3")
        return

    path = os.path.dirname(os.path.realpath(__file__))
    test_ini_file = os.path.join(path, "test_lookup_ini_file.ini")
    test_prop_file = os.path.join(path, "test_lookup_ini_file.properties")


# Generated at 2022-06-21 06:12:25.442911
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Ini file sample
    config = """
    [section1]
    key1 = value1
    key2 = value2
    [section2]
    key1 = value3
    key2 = value4
    key3 = value5
    """

    config = StringIO(config)
    cp = configparser.ConfigParser()
    cp.readfp(config)

    # LookupModule object
    lookup_module = LookupModule()

    # Define attributes
    lookup_module.cp = cp

    # Test get_value(key, section, dflt, is_regexp)
    #
    # Test with key (not a regexp)
    value = lookup_module.get_value('key1', 'section1', '', False)
    assert 'value1' == value

    # Test with regexp
    values

# Generated at 2022-06-21 06:12:27.738974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run(terms=['key'], variables={}, value='value',
               type='ini', file='ansible.ini', section='global', re=False, default='', encoding='utf-8')

# Generated at 2022-06-21 06:12:38.470056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test 1
    test_loookup_plugin = lookup_module.run([
        "user=bla section='production' type='properties'"
    ], None)
    assert test_loookup_plugin == []
    # Test 2
    test_loookup_plugin = lookup_module.run(["user", "password", "port"], None)
    assert test_loookup_plugin == []
    # Test 3
    test_loookup_plugin = lookup_module.run([
        "user", "password", "port", "bla", "ble"
    ], None)
    assert test_loookup_plugin == []
    # Test 4
    test_loookup_plugin = lookup_module.run(["user"], None)

# Generated at 2022-06-21 06:12:48.285422
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    config = StringIO()
    config.write('[section]\n')
    config.write('key1=value1\n')
    config.write('key2=value2')
    config.seek(0, os.SEEK_SET)
    lookup_module.cp.readfp(config)
    assert lookup_module.get_value('key1', 'section', 'default', False) == 'value1'
    assert lookup_module.get_value('key2', 'section', 'default', False) == 'value2'
    assert lookup_module.get_value('key3', 'section', 'default', False) == 'default'
    assert lookup_module.get_value('.*', 'section', 'default', True) == ['value1', 'value2']

# Generated at 2022-06-21 06:12:58.635608
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    l = LookupModule()

    l.cp = configparser.ConfigParser()
    l.cp.add_section('test')
    l.cp.set('test', 'my_key', 'my_value')
    l.cp.set('test', 'my_regexp_key', 'my_regexp_value')
    l.cp.set('test', 'my_key2', 'my_value2')

    assert l.get_value('my_key', 'test', None, False) == 'my_value'
    assert l.get_value('my_regexp_key', 'test', None, True) == ['my_regexp_value']
    assert l.get_value('my_key2', 'test', None, False) == 'my_value2'

# Generated at 2022-06-21 06:13:08.100059
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test retrieve value from a given key in a section
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module.cp.add_section('section1')
    lookup_module.cp.set('section1', 'name', 'John')
    lookup_module.cp.set('section1', 'age', '45')
    lookup_module.cp.set('section1', 'place', 'London')

    assert lookup_module.get_value('name', 'section1', '', True) == ['John']
    assert lookup_module.get_value('age', 'section1', '', True) == ['45']
    assert lookup_module.get_value('place', 'section1', '', True) == ['London']

    # Test retrieve all values from

# Generated at 2022-06-21 06:13:13.100710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from __main__ import LookupModule
    from ansible.utils.unicode import to_unicode
    from ansible.plugins.lookup import LookupBase

    class DummyLookup(LookupBase):

        def find_file_in_search_path(self, variables, path, file):
            return "unittest_resources/var1.ini"

        def _get_file_contents(self, path):
            data = None
            with open(path) as f:
                data = f.read()
                f.close
            return to_unicode(data), False

    # Ugly hack to get the path of the module
    import os
    import sys
    lookup = LookupModule()
    lookup._loader = DummyLookup()

    # Define parameters used for the test