

# Generated at 2022-06-21 06:04:04.990888
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import unittest

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.cp = configparser.ConfigParser()
            self.cp.add_section('section')
            self.cp.set('section', 'key1', 'value1')
            self.cp.set('section', 'key2', 'value2')
            self.cp.set('section', 'key3', 'value3')
            self.cp.set('section', 'key4', 'value4')
            self.cp.set('section', 'key5', 'value5')
            self.lookup = LookupModule()
            self.lookup.cp = self.cp


# Generated at 2022-06-21 06:04:17.633842
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Arrange
    # Create a new class object called LookupModuleTest
    LookupModuleTest = LookupModule()
    # Create a configparser() object
    LookupModuleTest.cp = configparser.ConfigParser()
    # Create a section called section_test
    LookupModuleTest.cp.add_section('section_test')
    # Create a dictionary with a key and a value
    LookupModuleTest.cp.set('section_test', 'key1', 'Value1')
    # Create a list with 'key1'
    key = ['key1']
    # Create a new variable dflt that contains a string
    dflt = "no value"

    # Action
    # Call the get_value method in the LookupModuleTest object

# Generated at 2022-06-21 06:04:29.328489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import unittest
    import tempfile

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}

    class AnsibleMock(object):
        def __init__(self):
            self.params = {}

        def get_version(self):
            return "2.0"

    class BuiltinMock(object):
        def __init__(self):
            pass

        def open(self, filename, mode='rb'):
            return open(filename, mode)

        def str(self):
            return "str"

    class LookupModuleMock(LookupModule):
        def __init__(self):
            # Add temp directory to path for proper config file location
            self.temp_dir = tempfile.mkdtemp()
            sys

# Generated at 2022-06-21 06:04:38.114008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(StringIO('[foo]\n'
                              'bar=baz\n'
                              'bar2=baz2\n'
                              'bar3=baz3\n'
                              ' foobar=baz\n'
                              'foobar2=baz2\n'
                              'foobar3=baz3\n'
                              ))
    assert lookup.run(['.*', 'section=foo', 'file=somefile'], variables={}) == ['bar', 'bar2', 'bar3']

# Generated at 2022-06-21 06:04:48.444044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test.cp = configparser.ConfigParser()

    # test for file not found
    try:
        test.run([''], variables={}, file='file_not_found')
    except AnsibleLookupError as e:
        assert "file 'file_not_found' not found" in to_text(e)

    # test for read ini file
    test.cp.add_section('section1')
    test.cp.set('section1', 'key1', "value1")
    test.cp.add_section('section2')
    test.cp.set('section2', 'key2', "value2")
    test.cp.readfp(StringIO('[section3]\nkey3=value3'))

# Generated at 2022-06-21 06:04:51.327931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # check default values
    assert "ini" == l.get_options()['type']

# Generated at 2022-06-21 06:04:56.954817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    paramvals = {'file': 'users.ini', 'section': 'global', 're': False, 'default': '', 'encoding': 'utf-8', 'type': 'ini', 'case_sensitive': False, 'allow_no_value': False}
    # test with a simple key
    terms = ['user']
    res = test_obj.run(terms, variables=None, **paramvals)
    assert res[0] == 'yannig'
    # test with a regexp
    paramvals['re'] = True
    res = test_obj.run(terms, variables=None, **paramvals)
    assert res[0] == 'yannig'
    assert res[1] == 'user1'
    # test with a key that does not exist

# Generated at 2022-06-21 06:05:07.980233
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lu = LookupModule()

    # load a small ini file in memory
    ini = StringIO()
    ini.write(u'[section1]\n')
    ini.write(u'key1=value1\n')
    ini.write(u'key2=value2\n')
    ini.write(u'key3=value3\n')
    ini.seek(0, os.SEEK_SET)
    cp = configparser.ConfigParser()
    cp.readfp(ini)
    lu.cp = cp

    # Test a regexp
    assert lu.get_value('.*', 'section1', None, True) == ['value1', 'value2', 'value3']

    # Test a single value

# Generated at 2022-06-21 06:05:19.984176
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_run_method(self):
        terms = [u'user']
        variables = dict()
        kwargs = dict(
            file='users.ini',
            section='integration'
        )

        results = self.run(terms, variables, **kwargs)
        assert results[0] == u'jdoe'

    # Note that invoking get_value inside run will fail as the method cp will not be initialized
    def test_get_value_method(self, cp):
        results = self.get_value(u'user', u'integration', u'', False)
        assert results == u'jdoe'

    def test_nonexistant_file(self):
        terms = [u'user']
        variables = dict()

# Generated at 2022-06-21 06:05:27.870193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run method of LookupModule.
    """
    file_name = 'test.ini'
    file_path = os.path.join("tests", "unit", "files", file_name)

    lkup = LookupModule()
    lkup.set_options(var_options={}, direct={'file': file_path})
    paramvals = lkup.get_options()

    lkup.cp = configparser.ConfigParser()
    contents = "[section1]\nkey1=value1\nkey2=value2\nkey3=value3\n"
    config = StringIO()
    config.write(contents)
    config.seek(0, os.SEEK_SET)

    lkup.cp.readfp(config)

    # Test with no regular expression

# Generated at 2022-06-21 06:05:46.439793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.add_section('section1')
    lookup_module.cp.set('section1', 'key1', 'value1')
    lookup_module.cp.set('section1', 'key2', 'value2')
    lookup_module.cp.set('section1', 'key3', 'value3')
    lookup_module.cp.set('section1', 'key4', 'value4')

    variables = {'ansible_dir': '.'}
    lookup_module.set_loader(loader_mock)

    # Get the value of a key, when section is not supplied in lookup
    assert lookup_module.run(terms=['key1'], variables=variables)[0] == 'value1'

# Generated at 2022-06-21 06:05:57.307666
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # we simulate the input ini file
    import io
    # Create the ini file
    config = io.StringIO()
    contents = """
[section1]
key = 0
key = 1
key = 2
key = 3
key = 4
key = 5
key = 6
key = 7
key = 8
key = 9
[section2]
key = 0
key = 1
key = 2
key = 3
key = 4
key = 5
key = 6
key = 7
key = 8
key = 9
[section3]
key = 0
key = 1
key = 2
key = 3
key = 4
key = 5
key = 6
key = 7
key = 8
key = 9
    """
    config.write(contents)
    config.seek(0, os.SEEK_SET)

   

# Generated at 2022-06-21 06:06:04.144617
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Retrieve a single value
    lu = LookupModule()
    lu.cp = configparser.ConfigParser()
    lu.cp.add_section('global')
    lu.cp.set('global', 'user', 'yannig')

    var = lu.get_value('user', 'global', '', False)
    assert var == 'yannig'

    # Retrieve all values from a section using a regexp
    lu.cp.add_section('section1')
    lu.cp.set('section1', 'user1', 'yannig')
    lu.cp.set('section1', 'user2', 'ansible')
    lu.cp.set('section1', 'notauser', 'notauser')

# Generated at 2022-06-21 06:06:15.427988
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import pytest

    class CP(configparser.ConfigParser):

        def items(self, section):
            return [(u'key1', u'value1'), (u'key2', u'value2'), (u'key3', u'value3')]

    cp = CP(allow_no_value=False)

    lm = LookupModule()
    lm.cp = cp
    assert lm.get_value(u'key1', u'section', u'', False) == u'value1'
    assert lm.get_value(u'key2', u'section', u'', False) == u'value2'
    assert lm.get_value(u'key4', u'section', u'dflt', False) == u'dflt'

# Generated at 2022-06-21 06:06:25.457147
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    module = LookupModule()
    config = StringIO()
    config.write(u'[integration]\n')
    config.write(u'user=admin\n')
    config.write(u'[production]\n')
    config.write(u'user=root\n')
    config.seek(0, os.SEEK_SET)
    module.cp.readfp(config)
    assert module.get_value('user', 'integration', None, False) == 'admin'
    assert module.get_value('user', 'production', None, False) == 'root'
    assert module.get_value('.*', 'integration', None, True) == ['user=admin']
    assert module.get_value('.*', 'production', None, True) == ['user=root']


# Generated at 2022-06-21 06:06:27.260546
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Unit test of constructor LookupModule.
    '''
    lookup_module = LookupModule()
    assert lookup_module.__class__.__name__ == 'LookupModule'

# Generated at 2022-06-21 06:06:32.441609
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create the parser
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    lm.cp.read_string("""[section]
param1=value1
param2=value2
param3=value3""")

    # Test with a valid key
    assert lm.get_value("param1", "section", None, False) == "value1"

    # Test with an invalid key
    assert lm.get_value("param4", "section", None, False) is None

    # Test with an regexp
    assert lm.get_value("param", "section", None, True) == ["param1=value1", "param2=value2", "param3=value3"]

# Generated at 2022-06-21 06:06:40.071025
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lm = LookupModule()
    lm.cp = configparser.ConfigParser(allow_no_value=False)
    lm.cp.read_file(StringIO('[section1]\nvalue1=1\nvalue2=2\n\n[section2]\nvalue3=3\n'))
    assert lm.get_value('value1', 'section1', 'default', False) == '1'
    assert lm.get_value('value2', 'section1', 'default', False) == '2'
    assert lm.get_value('value3', 'section2', 'default', False) == '3'
    assert lm.get_value('value4', 'section2', 'default', False) == 'default'

# Generated at 2022-06-21 06:06:41.580167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t



# Generated at 2022-06-21 06:06:42.132391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:07:02.645290
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    class FakeConfigParser(object):

        def __init__(self):

            self.items = lambda s: iter(s)

        def items(self, section):

            res = []
            if section == 'section1':
                res.append(('key1', 'value1'))
                res.append(('key2', 'value2'))
            return res

        def get(self, section, option):

            if section == 'section1':
                return self.items(section)[option]

    lookup_module = LookupModule()
    lookup_module.cp = FakeConfigParser()
    assert lookup_module.get_value('key1', 'section1', 'dflt1', False) == 'value1'

# Generated at 2022-06-21 06:07:09.835474
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser()
    cp.add_section("section1")
    cp.add_section("section2")
    cp.set("section1", "key1", "value1")
    cp.set("section1", "key2", "value2")
    cp.set("section1", "key3", "value3")
    cp.set("section2", "key1", "value1")
    cp.set("section2", "key2", "value2")
    cp.set("section2", "key3", "value3")

    lookup = LookupModule()
    lookup.cp = cp
    # Check the single key case
    result = lookup.get_value("key1", "section1", "", False)
    assert "value1" == result
    # Check the regexp case
    result = lookup

# Generated at 2022-06-21 06:07:16.998050
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    """
    Test the LookupModule.get_value method.
    """
    ini = LookupModule()
    config = StringIO('[section1]\nfirst = "value1"\nsecond = "value2"\n[section2]\nfirst = "value3"\nsecond = "value4"')
    config.seek(0, os.SEEK_SET)
    ini.cp.readfp(config)
    assert ini.get_value("first", "section1", "", False) == "value1"
    assert ini.get_value("second", "section1", "", False) == "value2"
    assert ini.get_value("first", "section2", "", False) == "value3"
    assert ini.get_value("second", "section2", "", False)

# Generated at 2022-06-21 06:07:18.125578
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    print(l)

# Generated at 2022-06-21 06:07:21.676837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.cp = configparser.ConfigParser()
    assert mod.cp is not None


# Generated at 2022-06-21 06:07:30.303046
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lm = LookupModule()
    config = configparser.ConfigParser()
    config.add_section('section')
    config.set('section', 'key', 'value')
    lm.cp = config
    assert lm.get_value('key', 'section', 'default', False) == 'value'
    assert lm.get_value('key', 'section', 'default', True) == ['value']
    assert lm.get_value('bad_key', 'section', 'default', False) == 'default'

# Generated at 2022-06-21 06:07:41.662673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest

    class ConfigurationParser( configparser.ConfigParser ):
        def __init__(self, allow_no_value):
            configparser.ConfigParser.__init__(self, allow_no_value=allow_no_value)
        def readfp(self, fp, filename=None):
            if fp.read() == "[java_properties]\nuser.name = Yannig\nuser.password = 123456\nuser.key =\n":
                configparser.ConfigParser.readfp(self, fp, filename=None)
            else:
                raise configparser.Error("Missing or corrupted file")

    class LookupModule_run_Test(unittest.TestCase):
        '''Unit test for method run of class LookupModule.'''


# Generated at 2022-06-21 06:07:50.084131
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['key', 'key2=value2']
    variables = None
    file = 'ansible.ini'
    section = 'section1'
    re = False
    lm = LookupModule(file, section, re, terms, variables)
    assert lm.file == file
    assert lm.section == section
    assert lm.re == re

# Unit tests for function _parse_params

# Generated at 2022-06-21 06:08:01.291068
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ls = LookupModule()

    # Create a StringIO to use as input file
    config = StringIO()
    config.write(u'[test]\n')
    config.write(u'key=value\n')
    config.write(u'key2=value2\n')
    config.seek(0, os.SEEK_SET)

    # ConfigParser to use
    cp = configparser.RawConfigParser()
    cp.readfp(config)

    # Test if method returns the right value 
    # in the case of a non regexp key
    value = ls.get_value("key", "test", "default", False)
    assert(value == "value")

    # Test if method return the right value 
    # in the case of a non regexp key
    # with a default value
    value = ls

# Generated at 2022-06-21 06:08:13.457329
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.module_utils.six import PY3

    # Define a section containing keys
    section = '[section]'
    keys = ['key1=value1', 'key2=value2', 'key3=value3']
    key_value = ""
    for key in keys:
        key_value += key + '\n'
    content = section + '\n' + key_value

    # Create a LookupModule object and prepare its config parser
    lm = LookupModule()
    config = StringIO()
    config.write(to_text(content, errors='surrogate_or_strict', encoding='utf-8'))
    config.seek(0, os.SEEK_SET)
    if PY3:
        lm.cp.read_string(config.getvalue())

# Generated at 2022-06-21 06:08:44.050660
# Unit test for constructor of class LookupModule
def test_LookupModule():
 
    # Create a LookupModule object
    terms = ['ansible_user']
    variables = {'files': ['/etc/ansible']}
    kwargs = {'file': 'sysctl.conf', 'section': 'properties', 're': False, 'default': 'some_default'}
    lookup = LookupModule()
    lookup.run(terms, variables, **kwargs)
    lookup.get_value('ansible_user', 'properties', 'some_default', False)

# Generated at 2022-06-21 06:08:55.244533
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create file used for test
    with open("test.ini", "w") as f:
        f.write("[section1]\nvalue1=5\nvalue2=6\nvalue3=7\nvalue4=8\n")

    fm = LookupModule()

    # Section and key already exists
    fm.run([("value1", {"section":"section1", "file":"test.ini"})])

    # Section exists and the key not
    fm.run([("", {"section":"section1", "file":"test.ini"})])

    # Section doesn't exist
    try:
        fm.run([("", {"section":"section11", "file":"test.ini"})])
    except AnsibleLookupError:
        pass

    # Section doesn't exist so the default value should be used

# Generated at 2022-06-21 06:08:56.204556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:09:06.365616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Real test for run method for LookupModule class
    """

    import os

    # Create file for testing
    with open("/tmp/testlookup", "w") as ini_file:
        ini_file.write("""[section1]
                        test=True
                        [section2]
                        test=False
                        """)

    # Create an instance of LookupModule
    lookup = LookupModule()

    # Load module for testing
    import ansible.plugins.lookup
    import imp
    f, p, d = imp.find_module('ini')
    path = p + '/ini.py'
    assert os.path.exists(path)
    ini_plugin = imp.load_source('ini', path)
    ini_plugin.LookupModule = LookupModule

    # Create instance of Mock

# Generated at 2022-06-21 06:09:17.044705
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 06:09:25.946817
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Given
    lookup = LookupModule()
    lookup.cp = configparser.RawConfigParser()
    lookup.cp.readfp(StringIO("""
[sec1]
one1 = one2
two2 = two3
three3 = three4
one1 = one5
4one4 = one6
[sec2]
one1 = one7
two2 = two8
four4 = four9
"""))
    # When
    val1 = lookup.get_value('^one.*', 'sec1', None, True)
    val2 = lookup.get_value('one1', 'sec1', None, False)
    val3 = lookup.get_value('^one.*', 'sec1', None, False)
    val4 = lookup.get_value('one1', 'sec2', None, False)

    # Then
   

# Generated at 2022-06-21 06:09:35.865265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.plugins.lookup.ini import LookupModule

    # Test LookupModule.run with a normal ini value
    paramvals = {
        'file': 'data.ini',
        'section': 'pwd',
        'default': None,
        'encoding': 'utf-8',
        're': False,
        'case_sensitive': False,
        'type': 'ini',
    }
    terms = ['password']
    lookup_module = LookupModule()
    assert lookup_module.run(terms, paramvals) == ['mysecret']

    # Test LookupModule.run with a non existent ini value

# Generated at 2022-06-21 06:09:42.751686
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test get value with regular expression
    config = configparser.ConfigParser()
    config.readfp(StringIO('[python]\nversion1=python-2.7\nversion2=python-3.1\nversion3=python-3.4'))
    lookup = LookupModule(loader=None, basedir=None, runner=None, templar=None)
    lookup.cp = config
    assert lookup.get_value('.*', 'python', '', True) == ['python-2.7', 'python-3.1', 'python-3.4']

    # Test get value without regular expression
    assert lookup.get_value('version3', 'python', '', False) == 'python-3.4'
    assert lookup.get_value('version4', 'python', '', False) == ''


# Generated at 2022-06-21 06:09:49.682725
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ms = '''
[section1]
key1 = value1
key2 = value2

[section2]
key3 = value3
key4 = value4
'''
    config = StringIO()
    config.write(ms)
    config.seek(0, os.SEEK_SET)

    lm = LookupModule()
    lm.cp.readfp(config)
    assert lm.get_value('key1', 'section1', None, False) == 'value1'
    assert lm.get_value('key1', 'section1', None, True) == 'value1'
    assert lm.get_value('key1', 'section2', None, False) is None
    assert lm.get_value('key4', 'section2', None, True) == 'value4'

# Generated at 2022-06-21 06:09:53.796749
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test constructor with section matching case
    test_config = configparser.ConfigParser()
    test_config.add_section('integration')
    test_config.set('integration', 'user', 'developer')
    test_config.add_section('production')
    test_config.set('production', 'user', 'sysadmin')

    # Test constructor with section not matching case
    test_config_case = configparser.ConfigParser()
    test_config_case.add_section('Integration')
    test_config_case.set('Integration', 'user', 'developer')
    test_config_case.add_section('Production')
    test_config_case.set('Production', 'user', 'sysadmin')

    ini1 = LookupModule()
    ini1.cp = test_config

# Generated at 2022-06-21 06:10:59.924311
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:11:07.200985
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Constructor of class LookupModule
    '''

    # Create a instance of class LookupModule
    obj = LookupModule()

    assert obj
    #if obj:
    #    print("LookupModule object is created successfully")
    #else:
    #    print("LookupModule object is not created")

# Generated at 2022-06-21 06:11:16.077999
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Creation variable AnsibleLookupError
    variable_AnsibleLookupError = AnsibleLookupError("")

    # Creation variable LookupModule
    variable_LookupModule = LookupModule()

    # Creation variable config
    variable_config = StringIO()
    variable_config.write(u'[integration]\n')
    variable_config.write(u'user=yannig\n')
    variable_config.write(u'[production]\n')
    variable_config.write(u'user=toto\n')
    variable_config.seek(0)

    # Creation variable config2
    variable_config2 = StringIO()
    variable_config2.write(u'user.name=yannig\n')
    variable_config2.seek(0)

    # Creation variable config3
    variable

# Generated at 2022-06-21 06:11:23.546298
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import logging
    logging.basicConfig(level=logging.DEBUG)

    test = LookupModule()
    test.cp = configparser.ConfigParser()
    test.cp.add_section("Test")
    test.cp.set("Test", "key1", "value1")
    test.cp.set("Test", "key2", "value2")

    assert test.get_value("key1", "Test", None, False) == "value1"
    assert test.get_value("key2", "Test", None, False) == "value2"

# Generated at 2022-06-21 06:11:34.778482
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Retrieve a single value
    cp = configparser.ConfigParser()
    cp.add_section("section1")
    cp.set("section1", "key1", "value1")

    t = LookupModule()
    t.cp = cp
    assert( t.get_value("key1", "section1", "default", False) == "value1" )

    # Test default value
    assert( t.get_value("key2", "section1", "default", False) == "default" )

    # Test regexp
    assert( t.get_value(".*1", "section1", "default", True) == ["key1"] )

    # Test no section
    cp = configparser.ConfigParser()
    t = LookupModule()
    t.cp = cp

# Generated at 2022-06-21 06:11:45.464492
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources='localhost,')
    variable_manager.set_inventory(inventory)

    variable_manager.extra_vars = {'hosts': 'localhost'}

# Generated at 2022-06-21 06:11:55.067893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Example 1
    term = 'user=yperre'
    variables = None
    kwargs = {'file': 'users.ini', 'section': 'integration'}
    result = lookup.run([term], variables, **kwargs)
    assert(len(result) == 1)
    assert(result[0] == 'yperre')

    # Example 2
    term = 'user'
    variables = None
    kwargs = {'file': 'users.ini', 'section': 'production'}
    result = lookup.run([term], variables, **kwargs)
    assert(len(result) == 1)
    assert(result[0] == 'yperre')

    # Example 3: Reading a Java property file
    term = 'user.name'
    variables = None
   

# Generated at 2022-06-21 06:11:56.531361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None).run(None, None, None) is None

# Generated at 2022-06-21 06:11:57.907564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create object of LookupModule
    lm = LookupModule()

    # assert type of object
    assert isinstance(lm , LookupModule)

# Generated at 2022-06-21 06:11:59.474783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

