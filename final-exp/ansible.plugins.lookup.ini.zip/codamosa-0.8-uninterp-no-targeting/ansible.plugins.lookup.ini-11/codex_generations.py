

# Generated at 2022-06-21 06:04:08.463724
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins import lookup_loader
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy


# Generated at 2022-06-21 06:04:21.068774
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import re
    import configparser
    class cp():
        def items(section):
            return {"k1":"v1", "k2":"v2"}.items()
        def get(section, key):
            if re.match(r"k.*", key):
                return "v1"
            raise configparser.NoOptionError(key)

    class lookupModule(LookupModule):
        def __init__(self):
            pass
        def get_value(self, key, section, dflt, is_regexp):
            return LookupModule.get_value(self, key, section, dflt, is_regexp)

    lm = lookupModule()
    lm.cp = cp
    assert lm.get_value("k1", "section", "default", False) == "v1"
    assert lm

# Generated at 2022-06-21 06:04:29.000380
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()

    content = """
[section]
key=value
another_key=another value
[section1]
key1=value1
key2=value2
another_key1=another value1
another_key2=another value2
"""

    config = StringIO()
    config.write(to_text(content))
    config.seek(0, os.SEEK_SET)

    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(config)
    assert lookup.get_value('key', 'section', None, False) == 'value'
    assert lookup.get_value('.*', 'section1', None, True) == ['value1', 'value2', 'another value1', 'another value2']

# Generated at 2022-06-21 06:04:39.043937
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This tests the following:
     - Instantiates a LookupModule
     - Creates a StringIO instance for testing
     - Tries to read the fake ini file
     - Tries to access a property in the ini file
    """

    import os
    import tempfile

    fake_ini_file = None

# Generated at 2022-06-21 06:04:49.303441
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create LookupModule instance and initialize it
    lookup = LookupModule()
    lookup.cp = configparser.SafeConfigParser()

    # Create a sample configuration file

# Generated at 2022-06-21 06:04:52.687269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Unit test for constructor of class LookupModule")
    lookup_module = LookupModule()

    # Check object attributes
    isinstance(lookup_module, LookupBase)
    self.assertEqual(doc, lookup_module.__doc__)



# Generated at 2022-06-21 06:05:01.273553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    '''
    with open('users.ini', 'w') as file:
        file.write('[integration]\n')
        file.write('user=michel\n')

        file.write('[production]\n')
        file.write('user=bob')
    '''
    assert LookupModule().run(['user', 'section1', 'section2'], {}, file='users.ini', section='integration', type='ini', case_sensitive=False, re=False) == ['michel']



# Generated at 2022-06-21 06:05:08.512597
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _create_configfile(path, content):
        with open(path, 'w') as fd:
            fd.write(content)

    # Define a mock loading class
    class Mock_Loader(object):
        def __init__(self):
            self.paths = ['./test/']

        def get_basedir(self, _):
            return './test/'

        def _get_file_contents(self, path):
            return (path, path)

        def path_dwim(self, _):
            return self.paths

    # Define a mock templating class
    class Mock_Vars(object):
        def __init__(self):
            self.variables = dict()

        def get(self, key):
            return self.variables.get(key)



# Generated at 2022-06-21 06:05:18.146419
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    # test for regexp
    cp = configparser.ConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.set('section1', 'key2', 'ok')
    lookup.cp = cp
    var = lookup.get_value('key1', 'section1', False, True)
    assert var == ['value1']
    # test for a single value
    var = lookup.get_value('key1', 'section1', False, False)
    assert var == 'value1'
    # test for a default value
    var = lookup.get_value('key3', 'section1', 'default', False)
    assert var == 'default'

# Generated at 2022-06-21 06:05:22.002814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test LookupModule constuctor
    """
    # Check that LookupModule initiate correctly
    assert LookupModule(None, None)

# Generated at 2022-06-21 06:05:32.931283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    args = {
        "file": "ansible.ini",
        "section": "ansible",
        "default": "",
        "re": False
    }
    lookup = LookupModule()
    lookup.run(terms=[], variables=args)

# Generated at 2022-06-21 06:05:43.020439
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    cp = configparser.ConfigParser()
    cp.readfp(StringIO(u"""[section1]\n
                            test=foobar\n
                            [section2]\n
                            test=foobaz\n
                            """))
    lookup.cp = cp
    assert lookup.get_value('test', 'section1', 'default', False) == 'foobar'
    assert lookup.get_value('test', 'section2', 'default', False) == 'foobaz'
    assert lookup.get_value('unknown', 'section1', 'default', False) == 'default'
    assert lookup.get_value('te.*', 'section1', 'default', True) == ['foobar']

# Generated at 2022-06-21 06:05:52.957861
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:06:03.461759
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_config = LookupModule()

    terms = [
       'ansible_python_interpreter=/opt/ansible/python/bin/python',
       'user=yperre',
       'max_user_instances=5'
    ]


# Generated at 2022-06-21 06:06:15.243907
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.module_utils.six.moves import StringIO
    test_obj = LookupModule()

    # Test for section with no key or default value, or is_regexp
    test_obj.cp = configparser.ConfigParser()
    test_obj.cp.add_section('s1')
    test_obj.cp.set('s1', 'k1', 'v1')
    test_obj.cp.set('s1', 'k2', 'v2')
    test_obj.cp.set('s1', 'k3', 'v3')
    test_obj.cp.set('s2', 'k1', 'v1')
    test_obj.cp.set('s2', 'k2', 'v2')

# Generated at 2022-06-21 06:06:25.032834
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Example to test
    lookup = LookupModule()
    params = dict(
        _context={'file': 'my.ini', 'encoding': 'UTF-8'},
        re=False,
        default='',
        case_sensitive=False,
        section='global',
        type='ini',
        # file=None,
    )

    # We need to set the 'file' attribute because it is required to find the file found in the search path.
    params['file']= '../../files/my.ini'

    # We need to create a fake search path
    lookup._loader._search_path = ['/var/lib/awx/venv/awx/projects/ansible/plugins/lookup/files']

    # Load ini file
    contents = "file=../../files/my.ini"

# Generated at 2022-06-21 06:06:37.800388
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # import LookupModule class
    from ansible.plugins.lookup.ini import LookupModule

    # create a LookupModule instance
    lm = LookupModule()

    # create a ConfigParser instance
    from ansible.module_utils.six.moves import configparser
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.add_section("section1")
    cp.set("section1", "property1", "value1")
    cp.set("section1", "property2", "value2")
    cp.set("section1", "property3", "value3")
    lm.cp = cp

    assert lm.get_value("property1", "section1", "default", False) == "value1"


# Generated at 2022-06-21 06:06:44.829897
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    test_file = """
[section1]
var = value
    """
    config = StringIO(test_file)
    lookup.cp.readfp(config)
    assert lookup.get_value("var", "section1", None, False) == "value"
    assert lookup.get_value("var", "section2", None, False) is None


# Generated at 2022-06-21 06:06:56.671368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test function run for class LookupModule
    """

    # Test str returned
    terms = ['user']
    variables = None
    kwargs = {'default': '', 'allow_none': 'FALSE',
              'file': 'tests/unit/ansible/plugins/lookup/test.ini',
              'section': 'integration', 'encoding': 'utf-8',
              're': 'FALSE', 'type': 'ini', 'case_sensitive': 'FALSE'}

    module_ = LookupModule()
    module_.set_options(var_options=variables, direct=kwargs)
    module_.run(terms)
    assert module_.get_value('user', 'integration', '', False) == 'johnd'

    # Test list returned
    terms = ['.*']

# Generated at 2022-06-21 06:06:58.808875
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None


# Generated at 2022-06-21 06:07:21.334919
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # setup
    test = LookupModule()
    test.cp = configparser.ConfigParser()
    test.cp.readfp(StringIO("[section1]\nkey1=value1\nkey2=value2\nkey3=value3"))

    # test 1 : get a single value
    assert test.get_value('key1', 'section1', None, False) == 'value1'

    # test 2 : get a single value using regex
    assert test.get_value('.1', 'section1', None, True) == 'value1'

    # test 3 : get a multiple values
    assert test.get_value('.*', 'section1', None, True) == ['value1', 'value2', 'value3']


# Generated at 2022-06-21 06:07:23.896955
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert LookupModule.run is LookupModule().run

# Generated at 2022-06-21 06:07:34.365898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test with file "test.ini" containing the following content:
    param0 = [
        'key1=value1',
        'key2=value2',
        'key3=value3'
    ]
    param1 = 'global'
    param2 = False
    param3 = 'ini'

    expected_result = [
        'value1',
        'value2',
        'value3'
    ]
    result = LookupModule().run(param0, type=param3, section=param1, re=param2)
    assert result == expected_result

    # Test with multiple parameters: input must be a single string that contains '='.
    param0 = 'key1=value1 key2=value2 key3=value3'
    param1 = 'global'
    param2 = False

# Generated at 2022-06-21 06:07:38.153841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    assert lookup_module.cp == cp

# Unit tests for method get_value

# Generated at 2022-06-21 06:07:44.603053
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test properties with no section
    lkup = LookupModule()
    with open("test_properties.properties", mode="r") as test_prop :
        # create a StringIO file
        config_str_io = StringIO()
        config_str_io.write(test_prop.read())
        config_str_io.seek(0, os.SEEK_SET)

    lkup.cp.readfp(config_str_io)
    assert lkup.get_value('user.name', 'java_properties', '', False) == "yperre"

    # test normal INI file
    lkup = LookupModule()
    with open("test_ini.ini", mode="r") as test_ini :
        # create a StringIO file
        config_str_io = StringIO()
        config_

# Generated at 2022-06-21 06:07:54.958029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """

    Tests for method run of class LookupModule.

    """
    lookup = LookupModule()
    test_data = """
[section1]
key1=value1
key2=value2
key3=value3

[section2]
key1=value1
key2=value2
key3=value3

[section3]
key1=value1
key2=value2
key3=value3
"""
    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(test_data)
    config.seek(0, os.SEEK_SET)
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(config)

    # Test if get_value method returns a value

# Generated at 2022-06-21 06:08:02.479333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ unit tests for the method run of class LookupModule """
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'file': '../files/data.ini', 'default': '', 're': False, 'type': 'ini', 'encoding': 'utf-8'})
    assert ["foo", "bar"] == lookup_module._plugin.run(["foo", "bar"], variables={})


# Generated at 2022-06-21 06:08:14.205165
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import os
    import sys
    import unittest

    class TestLookupModule(unittest.TestCase):

        def test_get_value(self):

            filename = "my.ini"
            section = "mysection"

            # Open file
            config = open(filename, 'w')
            config.write("[mysection]\n")

            # write some values in file
            config.write("key1=1\n")
            config.write("key2=2\n")
            config.write("key3=3\n")
            config.write("key4=4\n")

            # close file
            config.close()

            lk = LookupModule()
            lk.cp = configparser.ConfigParser()
            lk.cp.readfp(open(filename))

            # get value using a

# Generated at 2022-06-21 06:08:18.148487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_ret = LookupModule().run(['key1=value1 key2=value2 foo', 'key1=value1 key2=value2 bar'], variables={}, file='ansible.ini', section='global', default='')
    assert(lookup_ret == ['foo', 'bar'])

# Generated at 2022-06-21 06:08:20.221554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_LookupModule = LookupModule()
    assert test_LookupModule

# Generated at 2022-06-21 06:08:51.755717
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_plugin = LookupModule()
    # Parse a simple ini file
    # [section1]
    # key1=value1
    #
    # [section2]
    # key1=value1
    lookup_plugin.cp = configparser.ConfigParser()
    lookup_plugin.cp.readfp(StringIO('[section1]\nkey1=value1\n\n[section2]\nkey1=value2'))
    # Get value of a known key
    assert lookup_plugin.get_value('key1', 'section1', None, False) == 'value1'
    # Get value of a known key with a regexp
    assert lookup_plugin.get_value(r'key1', 'section1', None, True) == ['value1']
    # Get value of a unknown key
    assert lookup

# Generated at 2022-06-21 06:09:04.626871
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import re

    # Basic test : test the existence of a key in a section
    assert LookupModule.get_value(None, key="key1", section="section1", dflt="Default value", is_regexp=False) == "value1"

    # Test the existence of a key in a section with regexp
    assert LookupModule.get_value(None, key="key1", section="section_regexp", dflt="Default value", is_regexp=True) == "value1"

    # Test the non existence of a key in a section with default value
    assert LookupModule.get_value(None, key="key_unknown", section="section1", dflt="Default value", is_regexp=False) == "Default value"

    # Test the non existence of a key in a section with default value and regexp


# Generated at 2022-06-21 06:09:16.522747
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test reading value from section
    assert(LookupModule.get_value('key', '[section]', 'default', False)(None, None, None) == "value")
    # Test reading value with no section
    assert(LookupModule.get_value('key', None, 'default', False)(None, None, None) == "value")
    # Test reading value from section with regexp
    assert(LookupModule.get_value('key', '[section]', 'default', True)(None, None, None) == ['key=value'])
    # Test reading value with regexp
    assert(LookupModule.get_value('key', None, 'default', True)(None, None, None) == ["key=value"])
    # Test reading value with key that does not exist

# Generated at 2022-06-21 06:09:22.580708
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # To test get_value method.
    # Create a lookup object, some files and some ini data
    dummy_lookup = LookupModule()
    dummy_lookup.cp = configparser.ConfigParser(allow_no_value=True)
    f = open("test_get_value.ini", 'w+')
    f.write("a=42\n")
    f.flush()
    f.close()
    f = open("test_get_value.ini", 'r')
    dummy_lookup.cp.readfp(f)
    f.close()
    f = open("test.ini", 'w+')
    f.write("[test]\na=42\n")
    f.flush()
    f.close()
    f = open("test.ini", 'r')

# Generated at 2022-06-21 06:09:25.945726
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    """
    Unit tests for method get_value of class LookupModule
    """
    cp = configparser.ConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    l = LookupModule()
    l.cp = cp
    assert l.get_value('key', 'section1', 'default', False) == 'value1'

# Generated at 2022-06-21 06:09:35.864905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    LookupModule.run() should load ini properties for a section and return a value if it exists.
    '''
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    lookup_instance = LookupModule()
    term = 'foo'
    path = 'test/cfg'
    variables = {'__file__': path} # used by os.path.abspath to find the file
    paramvals = {
        'file': 'test.ini',
        'section': 'section1',
        're': False,
        'encoding': 'utf8',
        'default': '',
        'case_sensitive': False,
        'allow_no_value': False
    }
    config = u''
    config += u'[section1]\n'

# Generated at 2022-06-21 06:09:47.353457
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ini_string = """
[section1]
key=value
key2=value2
"""
    ini_file = StringIO(ini_string)
    cp = configparser.ConfigParser()
    cp.readfp(ini_file)
    # Create a new object of class LookupModule
    lookup_obj = LookupModule()
    # Register the config parser to the class object
    lookup_obj.cp = cp
    # Test the value of key1
    assert lookup_obj.get_value('key', 'section1', '', False) == 'value'
    # Test the value of key2
    assert lookup_obj.get_value('key2', 'section1', '', False) == 'value2'
    # Test the value of key3 which is not present

# Generated at 2022-06-21 06:09:54.846707
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_options() == {'encoding': 'utf-8',
                                    'file': 'ansible.ini',
                                    'section': 'global',
                                    're': False,
                                    'default': '',
                                    'case_sensitive': False,
                                    'type': 'ini',
                                    'allow_none': False}


# Generated at 2022-06-21 06:09:55.684130
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:10:07.651763
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup = LookupModule()
    key = 'user'
    section = 'integration'
    section_not_available = 'production'
    dflt = ''
    is_regexp = False
    is_regexp_true = True
    test_cp = configparser.ConfigParser()
    test_cp.add_section('integration')
    test_cp.set('integration', 'user', 'Yannig')
    test_cp.add_section('production')
    test_cp.set('production', 'user', 'Joss')

    lookup.cp = test_cp

    assert lookup.get_value(key, section, dflt, is_regexp) == 'Yannig'

    assert lookup.get_value(key, section_not_available, dflt, is_regexp) == ''

   

# Generated at 2022-06-21 06:10:55.221648
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() != None

# Generated at 2022-06-21 06:11:03.475635
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    dict = {'user1': 'admin', 'user2': 'admin', 'user3': 'user'}
    lk = LookupModule()
    lk.cp = configparser.ConfigParser()
    lk.cp.add_section('section1')
    for key, value in dict.items():
        lk.cp.set('section1', key, value)

    # Return a single value
    value1 = lk.get_value('user1', 'section1', None, False)
    assert value1 == 'admin'

    # Return a default value
    value2 = lk.get_value('user4', 'section1', 'default', False)
    assert value2 == 'default'

    # Return a list of values using a regexp

# Generated at 2022-06-21 06:11:14.499770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class fake:
        def __init__(self):
            self.options = {'file': 'test.ini',
                            'section': 'global',
                            'default': '',
                            're': False,
                            'encoding': 'utf-8'}
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(StringIO("[global]\nkey=value\n"))

    inputs = ['key', 'not_existing_key=default']
    assert lookup.run(inputs, variables=fake()) == ['value', '']
    inputs = ['key', 'default=default']
    assert lookup.run(inputs, variables=fake()) == ['value', 'default']
    inputs = ['key', 'key']

# Generated at 2022-06-21 06:11:26.006988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()

    term = 'user'
    variables = {'files': 'ansible.ini'}
    kwargs = {'type': 'ini', 'file': 'ansible.ini', 'section': 'user', 're': False,
              'encoding': 'utf-8', 'default': '', 'case_sensitive': False}

    # Retrieve file path
    path = test_LookupModule.find_file_in_search_path(variables, 'files', kwargs['file'])

    # Create StringIO later used to parse ini
    config = StringIO()

    # Open file using encoding
    config.write(file(path).read().decode(kwargs['encoding']))
    config.seek(0, os.SEEK_SET)

    test_LookupModule

# Generated at 2022-06-21 06:11:28.869505
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert (lookup.cp is not None)


# Generated at 2022-06-21 06:11:33.173826
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    assert LookupModule.get_value(None,"key","section","dflt",False) == "dflt"
    assert LookupModule.get_value(None,"key",None,"dflt",False) == "dflt"
    assert LookupModule.get_value(None,"key",None,None,False) == None


# Generated at 2022-06-21 06:11:45.156944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
        Run the test for the class LookupModule
        :return:
        """
    import types
    from ansible.module_utils.six.moves import configparser

    lookup_plugin = LookupModule()
    lookup_plugin.cp = configparser.ConfigParser()

    # Test the content of the file
    lookup_plugin.cp.add_section('test_section')
    lookup_plugin.cp.set('test_section', 'user', 'test_user')
    lookup_plugin.cp.set('test_section', 'password', 'test_password')
    lookup_plugin.cp.set('test_section', 'database', 'test_database')

    # Test with a key that not exists
    test_key = 'not_exists_key'
    test_default = 'default_value'
    result = lookup_plugin

# Generated at 2022-06-21 06:11:56.494785
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()

    test_file = """
[general]
name = Foo
[bar]
foo = Foobar
[foobar]
description = barfoo
"""

    try:
        file = open('temp.ini', 'w')
        file.write(test_file)
        file.close()

        lookup.cp.read('temp.ini')
        os.remove('temp.ini')
    except Exception as e:
        raise e

    returned_value = lookup.get_value('name', 'general', 'invalid', False)
    assert returned_value == 'Foo'

    returned_value = lookup.get_value('.*', 'bar', 'invalid', True)
    assert returned_value == ['Foobar']


# Generated at 2022-06-21 06:11:59.620267
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert 'Ansible' in lookup
    assert 'plugins' in lookup
    assert 'lookup' in lookup

# Generated at 2022-06-21 06:12:09.526780
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from collections import namedtuple

    FakeConfigParser = namedtuple('ConfigParser', ['get', 'items'])
    FakeConfigItem = namedtuple('ConfigItem', ['key', 'value'])


# Generated at 2022-06-21 06:13:56.647600
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ini_content_1 = "[section1]\nparameter1=value1\nparameter2=value2\n"
    ini_content_2 = "[section2]\nparameter1=value1\nparameter4=value4\n"
    ini_content_3 = "[section3]\nparameter3=value3\n"

    ini_file_1 = StringIO(ini_content_1)
    ini_file_2 = StringIO(ini_content_2)
    ini_file_3 = StringIO(ini_content_3)

    configparser_1 = configparser.ConfigParser()
    configparser_1.readfp(ini_file_1)

    configparser_2 = configparser.ConfigParser()
    configparser_2.readfp(ini_file_2)