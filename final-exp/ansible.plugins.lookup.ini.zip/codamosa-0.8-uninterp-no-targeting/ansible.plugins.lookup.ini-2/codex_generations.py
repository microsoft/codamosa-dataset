

# Generated at 2022-06-21 06:04:04.569836
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockLookup:
        def __init__(self):
            self.lookup_args = ''
            self.lookup_opts = ''
            self.lookup_args = ''
            self.lookup_opts = ''

        def find_file_in_search_path(self, variables, _dir, filename):
            self.lookup_args = variables
            self.lookup_opts = _dir
            return filename

    terms = ['key1', 'key2', 'key3']
    variables = {'a': 'b'}
    MockLookup = MockLookup()
    l = LookupModule()
    l.set_loader(MockLookup)
    ret = l.run(terms, variables)

    # Test if method find_file_in_search_path has been called with the right parameters


# Generated at 2022-06-21 06:04:10.484586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    
    # Test 1
    terms = []
    
    res = module.run(terms)

    assert res == [], res
    
    # Test 2
    terms = [
        "name=value"
    ]

    res = module.run(terms)

    assert res == [], res
    
    # Test 3
    terms = [
        "name="
    ]

    res = module.run(terms)

    assert res == [], res
    
    # Test 4
    terms = [
        "name"
    ]

    res = module.run(terms)

    assert res == [], res



# Generated at 2022-06-21 06:04:21.431323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # both "section" and "file" are required parameters
    # file name is relative to ansible_directory
    cwd = os.getcwd()
    files_dir= os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    files_path = os.path.join(files_dir, "files/")
    os.chdir(files_path)
    class Options(object):
        section = 'integration'
        file = 'users.ini'
        re = False

        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    options = Options()
    terms = ['user']
    # with file, section

# Generated at 2022-06-21 06:04:31.339927
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    testkeys = {
        'key1': '1',
        'key2': '2'
    }
    test_cp = configparser.ConfigParser()
    test_cp.add_section('section')
    for k in testkeys:
        test_cp.set('section', k, testkeys[k])
    test_cp.add_section('test')
    for k in testkeys:
        test_cp.set('test', k, testkeys[k])
    lookup = LookupModule()
    lookup.cp = test_cp

    # Test case where regexp is False
    var = lookup.get_value('key1', 'section', '', False)
    assert(var == '1')
    var = lookup.get_value('key2', 'section', '', False)
    assert(var == '2')

   

# Generated at 2022-06-21 06:04:38.114398
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    ret = l.run(["user", "password"], dict(file="users.ini"), section="global", default=0, re=0, encoding="utf-8")
    assert ret == []
    assert l.cp.sections() == []
    assert l.cp.defaults() == {}
    assert l.cp.has_section("global") == False
    assert configparser.ConfigParser().optionxform("A") == "a"
    assert configparser.ConfigParser().optionxform("a") == "a"
    assert configparser.ConfigParser(allow_no_value=True).optionxform("Topic") == "topic"
    assert configparser.ConfigParser(allow_no_value=True).optionxform("topic") == "topic"


# Generated at 2022-06-21 06:04:45.732182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #https://github.com/ansible/ansible/blob/devel/hacking/test-module.py
    #Load the module for testing
    lm = LookupModule()

    module_args = dict(
      _terms=['foo'],
      section='default',
      file='ansible.ini',
      type='ini',
      default='',
      re=False,
      encoding='utf-8',
      case_sensitive=False,
      allow_no_value=False
    )
    result = lm.run(**module_args)
    assert result == []

# Generated at 2022-06-21 06:04:49.907208
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    value_array = None
    value = None

    # Retrieve a single value
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.readfp(StringIO("""
    [section]
    key=value
    key_empty=
    key_no_value
    """))

    assert cp.get('section', 'key') == 'value'
    assert cp.get('section', 'key_empty') == ''
    assert cp.get('section', 'key_no_value') == ''

    # Retrieve all values from a section using a regexp
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.readfp(StringIO("""
    [section]
    key=value
    key_empty=
    key_no_value
    """))
    value_

# Generated at 2022-06-21 06:04:51.394920
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_plugin = LookupModule()
    except LookupError as e:
        assert False



# Generated at 2022-06-21 06:04:53.571041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    lookup = LookupModule()
    return lookup

# Unit test
test = test_LookupModule()
print(test)

# Generated at 2022-06-21 06:04:56.168590
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')


# Generated at 2022-06-21 06:05:13.333028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    test if Ini lookup works properly
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 06:05:21.153002
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    cp = configparser.ConfigParser()
    cp.add_section('test')
    cp.set('test', 'toto', 'titi')
    cp.set('test', 'tutu', 'tata')

    l = LookupModule()
    l.cp = cp

    assert l.get_value('toto', 'test', '', False) == 'titi'
    assert l.get_value('toto', 'test', '', True) == 'titi'
    assert l.get_value('.*', 'test', '', True) == ['titi', 'tata']
    assert l.get_value('titi', 'test', '', True) == ''

# Generated at 2022-06-21 06:05:29.152708
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    test_instance = LookupModule()
    test_instance.cp = configparser.ConfigParser()
    test_instance.cp.readfp(StringIO("""
[section1]
key1=foo
key2=bar
key3=foobar
"""))

    # Test 1, return foo
    assert test_instance.get_value("key1", "section1", "", False) == "foo"
    # Test 2, return bar
    assert test_instance.get_value("key2", "section1", "", False) == "bar"
    # Test 3, return foobar
    assert test_instance.get_value("key3", "section1", "", False) == "foobar"
    # Test 4, return default value
    assert test_instance.get_value("key4", "section1", "defaultvalue", False)

# Generated at 2022-06-21 06:05:29.756590
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:05:31.248889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plug = LookupModule()
    assert lookup_plug.cp == None


# Generated at 2022-06-21 06:05:41.643748
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class MyLookupModule(LookupModule):
        def __init__(self):
            self.cp = configparser.ConfigParser()
            self.cp.readfp(StringIO(u'[global]\nproperty1=value1\nproperty2=value2'))

    lm = MyLookupModule()

    # Test classic feature
    assert lm.get_value('property1', 'global', 'default', False) == 'value1'
    assert lm.get_value('property3', 'global', 'default', False) == 'default'

    # Test regexp
    assert lm.get_value('property.', 'global', 'default', True) == ['value1', 'value2']



# Generated at 2022-06-21 06:05:43.082019
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 06:05:52.212260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import tempfile, os
    fd, fname = tempfile.mkstemp()
    os.write(fd, b'[section1]\nkey1=value1\nkey2=value2\n[section2]\nkey3=value3')
    os.close(fd)

    km = LookupModule('')
    km.set_options({'file': fname})
    assert km.get_value('key1', 'section1', None, False) == 'value1'
    assert km.get_value('key2', 'section1', None, False) == 'value2'
    assert km.get_value('key3', 'section2', None, False) == 'value3'
    assert km.get_value('key2', 'section2', None, False) == None
    assert km.get_

# Generated at 2022-06-21 06:06:05.160382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # Create ini file to work on
    ini_file = '[default]\n' + 'key1=value1\n' + 'key2=value2\n'
    config = StringIO()
    config.write(ini_file)
    config.seek(0, os.SEEK_SET)

    # Check if boolean option is False
    lk = LookupModule(None, None, None)
    lk.set_options({'option_not_exists': False})
    assert lk.get_options().get('option_not_exists') is False

    # Test with no option
    assert lk.run([], {}, file='lookup_file') == []

    # Test with no ini file
    assert lk.run

# Generated at 2022-06-21 06:06:14.126452
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    from ansible.plugins.loader import lookup_loader
    import os
    from ansible.utils.display import Display
    from ansible.utils.hashing import checksum

    class FakeVarManager():
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True):
            return {}

    display = Display()
    display._verbosity = 3
    lookup_plugin = lookup_loader.get('ini', class_only=True)(
        loader=None,
        basedir='',
        display=display,
        runner_cache=None,
        var_manager=FakeVarManager(),
    )

    # load test.ini file

# Generated at 2022-06-21 06:06:34.358708
# Unit test for constructor of class LookupModule
def test_LookupModule():
    options = {
        'type': 'ini',
        'file': 'ansible.ini',
        'section': 'global',
        're': False,
        'encoding': 'utf-8',
        'default': '',
        'case_sensitive': False,
        'allow_no_value': False
    }
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct=options)
    assert lookup_plugin.get_options() == options

# Generated at 2022-06-21 06:06:48.246681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os
    import shutil
    import yaml
    import json

    # Prepare input parameters
    options = {'file': 'test.ini'}
    terms = ['user']

    # Prepare context
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost, '])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 06:06:54.958258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    args = {
        '_ansible_vars' : {'a': 'b'},
        'file' : 'test.ini',
        'case_sensitive' : False,
        'section' : 'section1',
        're' : False,
    }
    lookup = LookupModule(**args)
    assert lookup.run(['']) == ['']

# Generated at 2022-06-21 06:07:02.346375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_context = dict(
        loader=loader,
        variable_manager=variable_manager,
        inventory=inv_manager
    )
    test_play = Play().load({}, variable_manager=variable_manager, loader=loader)
    return LookupModule(loader=loader, variable_manager=variable_manager, play_context=play_context)

# Generated at 2022-06-21 06:07:03.245763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add unit test for class LookupModule
    pass

# Generated at 2022-06-21 06:07:03.912945
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 06:07:13.292904
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_config = configparser.ConfigParser()
    test_config.readfp(StringIO(u'''[section]
key1=value1
key2=value2
'''))
    result = LookupModule.get_value("key\d", "section", "default", test_config, True)
    assert result == ["value1", "value2"]
    result = LookupModule.get_value("key1", "section", "default", test_config, False)
    assert result == "value1"
    result = LookupModule.get_value("key3", "section", "default", test_config, False)
    assert result == "default"
    assert LookupModule.get_value("key\d", "section2", "default", test_config, True) == "default"

# Generated at 2022-06-21 06:07:22.564296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    ansible_options = basic.AnsibleOptions(listtags=False, listtasks=False,
                                            listhosts=False, syntax=False,
                                            connection=None, module_path=None,
                                            forks=None, remote_user=None,
                                            private_key_file=None,
                                            ssh_common_args=None,
                                            ssh_extra_args=None, sftp_extra_args=None,
                                            scp_extra_args=None, become=None,
                                            become_method=None, become_user=None,
                                            verbosity=None, check=False)

    # create a fake lookup plugin
    lookup_plugin = Look

# Generated at 2022-06-21 06:07:26.480648
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module
    assert lookup_module.cp
    assert lookup_module.cp.optionxform == str

# Generated at 2022-06-21 06:07:33.531894
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1:
    # Check if file is found in search path
    test_args = dict(
        terms=[
            {
                u'key': u'user',
                u'file': u'.',
                u'section': u'global',
                u'module_implementation': ['configparser.ConfigParser'],
                u'type':u'ini'
            }
        ],
        variables = {
            u'ansible_env': {
                u'HOME': u'/home/yannig'
            },
            u'ansible_user_dir': u'.'
        }
    )
    test_instance = LookupModule()
    test_instance._loader = FakeLoader()
    test_instance._loader.set_basedir("/home/yannig/ansible")
    assert test_instance.run

# Generated at 2022-06-21 06:07:48.530522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([], None, type='ini', file='ansible.ini', section='global', re=False, encoding='utf-8') == ['']

# Generated at 2022-06-21 06:07:53.154108
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import unittest
    class Test(unittest.TestCase):
        def test_case_1(self):
            cp = configparser.ConfigParser()
            cp.readfp(StringIO(u'[sec]\na = b\n'))

            assert LookupModule.get_value('a', 'sec', None, False) == 'b'
    unittest.main()

# Generated at 2022-06-21 06:08:01.936715
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test if get_value returns the value if exists
    test_cp = configparser.ConfigParser()
    test_cp.add_section('test')
    test_cp.set('test', 'key', 'value')
    assert LookupModule.get_value('key', 'test', None, False, test_cp) == 'value'

    # Test if get_value returns None if value is None (default value)
    test_cp = configparser.ConfigParser()
    test_cp.add_section('test')
    test_cp.set('test', 'key', None)
    assert LookupModule.get_value('key', 'test', None, False, test_cp) is None

    # Test if get_value returns default value if value does not exist
    test_cp = configparser.ConfigParser()
    test_cp.add_

# Generated at 2022-06-21 06:08:10.074912
# Unit test for constructor of class LookupModule
def test_LookupModule():
    paramvals = {
        "file": "ansible.ini",
        "section": "global",
        "re": False,
        "encoding": "utf-8",
        "default": "",
        "type": "ini",
        "case_sensitive": False
    }
    l = LookupModule()
    l.set_options(var_options={}, direct=paramvals)
    assert l.get_options() == paramvals

# Generated at 2022-06-21 06:08:12.943563
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test.get_value('test', 'default', 'test1', False)

# Generated at 2022-06-21 06:08:21.268401
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class DummyClass(object):
        def __init__(self):
            self.cp = configparser.ConfigParser()

    dummy = DummyClass()
    dummy.cp.add_section('dummy_section')
    dummy.cp.set('dummy_section', 'dummy_key', 'dummy_value')

    assert 'dummy_value' == dummy.get_value('dummy_key', 'dummy_section', None, None)

# Generated at 2022-06-21 06:08:21.996775
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:08:28.186166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.modules.extras.system.ini
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    doc = ansible.modules.extras.system.ini.__doc__

   # Create term
    term = 'key1=test'
    key = 'key1'
    value = 'test'

    # Parse term
    params = _parse_params(term, doc)

    # Try to retrieve value from section in file
    instance = LookupModule()
    var = instance.get_value(key, 'section1', '', '')

    # Check if var is equals to value
    assert var == value
    assert params == [value]

# Generated at 2022-06-21 06:08:32.726647
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    # Test if class is instance of LookupBase
    assert isinstance(module, LookupBase)
    # Test if cp is instance of ConfigParser
    assert isinstance(module.cp, configparser.ConfigParser)


# Generated at 2022-06-21 06:08:42.831539
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    import StringIO
    global term
    global cp

    cp = configparser.ConfigParser()
    config = StringIO.StringIO()

    # Construct config
    config.write('[section1]\n')
    config.write('key1=value1\n')
    config.write('key2=value2\n')
    config.write('key3=value3\n')
    config.write('[section2]\n')
    config.write('key1=value1bis\n')
    config.write('key3=value3bis\n')
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)

    lookup = LookupModule()
    lookup.cp = cp

    # Regexp

# Generated at 2022-06-21 06:09:11.019542
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule.get_value(None, "key1", "section1", "default1", True)
    LookupModule.run(None, [], {})

# Generated at 2022-06-21 06:09:18.934470
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()

    # Test with regexp
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section('test')
    lookup.cp.set('test', 'key1', 'value1')
    lookup.cp.set('test', 'key2', 'value2')

    assert lookup.get_value('key1', 'test', 'default', True) == ['value1']
    assert lookup.get_value('key2', 'test', 'default', True) == ['value2']
    assert lookup.get_value('key3', 'test', 'default', True) == []

    # Test with no regexp
    default = 'default'
    assert lookup.get_value('key1', 'test', default, False) == 'value1'

# Generated at 2022-06-21 06:09:31.296631
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LookupModule_Mock(LookupModule):

        def __init__(self, file_contents, loader=None, templar=None, cache=None, find_file_in_search_path=None, **kwargs):
            self.cp = configparser.ConfigParser()
            self.file_contents = file_contents
            self.fp = StringIO()
            self.fp.write(self.file_contents)
            self.fp.seek(0, os.SEEK_SET)
            self.cp.readfp(self.fp)
            self.get_value = LookupModule.get_value.__get__(self)


# Generated at 2022-06-21 06:09:32.666597
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.cp is not None

# Generated at 2022-06-21 06:09:40.629054
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.plugins.loader import lookup_loader

    lookup_plugin = lookup_loader.get('ini')

    # Create config parser
    ini_parser = configparser.ConfigParser()

    ini_parser.add_section('section1')
    ini_parser.set('section1', 'key1', 'value1')
    ini_parser.set('section1', 'key2', 'value2')

    # Regexp key, return a list of all values
    assert lookup_plugin.get_value('.*', 'section1' , '', True) == ['value1', 'value2']
    # Simple key
    assert lookup_plugin.get_value('key1', 'section1', '', False) == 'value1'

# Generated at 2022-06-21 06:09:49.027744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare parametrs for test
    terms = ['user']
    variables = {'ansible_user': 'yannigperre'}

    properties_file_content = '[java_properties]\n'
    properties_file_content += 'db.user=yannigperre'
    properties_file_content += 'db.password=password'

    ini_file_content = '[test]\n'
    ini_file_content += 'user=yannigperre'
    ini_file_content += 'password=password'

    # Load files in temporary variable
    properties_file = StringIO()
    ini_file = StringIO()
    properties_file.write(properties_file_content)
    ini_file.write(ini_file_content)

    # Initialise instance of class LookupModule with

# Generated at 2022-06-21 06:09:59.328929
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    '''Test get_value of lookup ini'''

    # Create 'dummy' plugin
    lpm = LookupModule()
    lpm.cp = configparser.ConfigParser()

    # Create 'test.ini'
    config = StringIO()
    config.write(u'[test]\n')
    config.write(u'option1=value1\n')
    config.write(u'option2=value2\n')
    config.write(u'option3=value3\n')
    config.seek(0, os.SEEK_SET)
    lpm.cp.readfp(config)

    assert lpm.get_value('option1', 'test', None, False) == 'value1'

# Generated at 2022-06-21 06:10:08.095106
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    lm = LookupModule()

    # Create a StringIO in order to parse the StringIO with ConfigParser
    config = StringIO()
    config.write("[section]\n")
    config.write("#comment\n")
    config.write("key1=value1\n")
    config.write("key2=value2\n")
    config.write("key3=value3\n")
    config.write("key4=value4\n")
    config.write("key5=value5\n")
    config.seek(0, os.SEEK_SET)

    # Create an instance of ConfigParser
    configp = configparser.ConfigParser()
    configp.readfp(config)

    # Test with a key in the section
    ret = lm._get_

# Generated at 2022-06-21 06:10:09.081726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:10:16.828026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = "host ansible_user='root' ansible_port='2222'"
    terms = [term]
    variables = {'ansible_user': 'ansible_user'}
    default = 'default_value'
    enc = 'utf-8'
    re = False
    lookup_module.run(terms, variables=variables, default=default, encoding=enc, re=re)
    assert lookup_module.cp.get('java_properties','ansible_user') == 'ansible_user'
    assert lookup_module.cp.get('java_properties','ansible_port') == '2222'
    assert lookup_module.get_value('ansible_user', 'java_properties', 'default_value', False) == 'ansible_user'

# Generated at 2022-06-21 06:11:15.334266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["key1=value1 key2=value2 key3=value3", "key4"]
    variables = { 'filesdir': '/home/vagrant'}
    options = { 'type': 'ini', 'file': 'test.ini', 'section': 'section1', 'encoding': 'utf-8', 're': False, 'default': ''}
    # Creating a mock object for class LookupBase
    lookupBase = LookupBase()

    # Mocking object behavior
    lookupBase.set_options = lambda var_options, direct: None
    lookupBase.get_options = lambda: options
    lookupBase.find_file_in_search_path = lambda variables, file_type, file_name: file_name
    lookupBase._loader = lambda: None

    # Creating a mock object for class MutableSequence
    mutableSequ

# Generated at 2022-06-21 06:11:26.390358
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lm = LookupModule()
    config = configparser.RawConfigParser()
    lm.cp = config
    lm.cp.add_section('section')
    lm.cp.set('section', 'key', 'value')
    assert 'value' == lm.get_value('key', 'section', None, False)
    assert None == lm.get_value('key2', 'section', None, False)
    config = configparser.RawConfigParser()
    lm.cp = config
    lm.cp.add_section('section')
    lm.cp.set('section', 'key', 'value')
    lm.cp.set('section', 'key2', 'value2')
    assert ['value', 'value2'] == lm.get_value('.*', 'section', None, True)


# Generated at 2022-06-21 06:11:35.987695
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Variables passed to read_ini_file method
    paramvals = {'type': 'properties',
                'section': 'java_properties',
                'file': None,
                'encoding': 'utf-8',
                're': False,
                'default': '',
                'key': "test",
                'case_sensitive': False}

    # Initialization
    lookupMod = LookupModule()

    # file does not exist
    lookupMod.cp = configparser.RawConfigParser()
    res = lookupMod.run(["test"], variables=None, **paramvals)
    assert isinstance(res, MutableSequence)
    assert res == []

    # file exists but section does not exist
    with open(os.path.join('files', 'user.properties'), 'r') as f:
        lookupMod.cp = config

# Generated at 2022-06-21 06:11:45.860243
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Build a mock Class to allow testing of method get_value
    class ConfigParserMock(object):
        def __init__(self, *args, **kwargs):
            self.key1 = "value1"
            self.key2 = "value2"
            self.key3 = "value3"

        def get(self, section, key):
            return getattr(self, key)

        def items(self, section):
            return [("key1", "value1"), ("key2", "value2"), ("key3", "value3")]

    class LookupModuleMock(LookupModule):
        def __init__(self):
            self.cp = ConfigParserMock()

    lookup = LookupModuleMock()

    # Given a key
    key = "key1"
    # When we retrieve the value
   

# Generated at 2022-06-21 06:11:56.853056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check with a simple key / value (no spaces, no equal sign)
    class MockConfigParser(configparser.SafeConfigParser):
        def get(self, section, option, raw=False, vars=None):
            return "ansible"

    LookupModule.cp = MockConfigParser()
    instance = LookupModule()
    ret = instance.run(["user"], {"file": "ansible.ini", "allow_no_value": False})
    assert ret == ["ansible"]

    # Check with the user using an equals sign, the value is on the right
    class MockConfigParser2(configparser.SafeConfigParser):
        def get(self, section, option, raw=False, vars=None):
            return "ansible"
    LookupModule.cp = MockConfigParser2()

# Generated at 2022-06-21 06:11:58.283213
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()


# Generated at 2022-06-21 06:12:07.465331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['user']
    parameters = {'file': 'users.ini', 'section': 'integration'}

    test = LookupModule()
    test.set_options(**parameters)
    assert test.run(terms) == ['yannig']

    terms = ['user']
    parameters = {'file': 'users.ini', 'section': 'production'}
    test = LookupModule()
    test.set_options(**parameters)
    assert test.run(terms) == ['yannig1']

    terms = ['user.name']
    parameters = {'file': 'user.properties', 'type': 'properties'}
    test = LookupModule()
    test.set_options(**parameters)
    assert test.run(terms) == ['yannig']

    terms = ['.*']
   

# Generated at 2022-06-21 06:12:09.537020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    new_object = LookupModule()
    assert new_object is not None, "LookupModule constructor error!"

# Generated at 2022-06-21 06:12:15.866318
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ini_content = """
    [section]
    key1=value1
    """
    config = StringIO(ini_content)
    cp = configparser.ConfigParser()
    cp.readfp(config)
    lm = LookupModule()
    lm.cp = cp
    assert lm.get_value("key1", "section", "default") == "value1"


# Generated at 2022-06-21 06:12:23.662747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugin import lookup_loader
    import io
    import textwrap
    tester = lookup_loader.get('ini', loader=None, templar=None)
    terms = """
        test_true=True
        file=__ansible_test.ini
        default=default_value
        section=section1
    """.strip().split('\n')
    paramvals = """
        [java_properties]
        test_bool=true
        test_int=42
        test_string=jdoe
    """.strip()
    pf = io.StringIO(paramvals)
    tester.cp.readfp(pf)
    assert tester.run(terms, variables=None, **{}) == ['default_value']
