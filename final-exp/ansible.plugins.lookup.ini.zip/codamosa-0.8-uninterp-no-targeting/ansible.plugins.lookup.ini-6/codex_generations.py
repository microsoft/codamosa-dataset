

# Generated at 2022-06-21 06:04:05.423946
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test with no section
    parser = configparser.ConfigParser()
    parser.readfp(StringIO(u'[section2]\nkey1=value1'))
    with pytest.raises(configparser.NoSectionError):
        LookupModule(None, None, None).get_value(u'key1', u'section1', u'', False)
    # Test with no value
    assert LookupModule(None, None, None).get_value(u'key2', u'section2', u'default', False) == u'default'
    # Test with a value
    assert LookupModule(None, None, None).get_value(u'key1', u'section2', u'default', False) == u'value1'

# Generated at 2022-06-21 06:04:18.400147
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    lookup_module = LookupModule()

    # Create a configparser.RawConfigParser object
    cp = configparser.RawConfigParser()

    # Add an option to configparser object
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')

    # Set cp attribute of LookupModule class to RawConfigParser object
    lookup_module.cp = cp

    # Test method run of LookupModule class
    test = ['key1']
    test_result = lookup_module.run(test)
    assert test_result == ['value1']

    # Test method run of LookupModule class with a regexp
    test = ['key']
    test_result = lookup_module.run(test, re=True)

# Generated at 2022-06-21 06:04:29.704119
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookupMod = LookupModule()
    config = StringIO()
    config.write(u'[global]\nuser=johndoe\n')
    config.seek(0, os.SEEK_SET)
    configFiles = configparser.ConfigParser()
    configFiles.readfp(config)
    lookupMod.cp = configFiles
    # value from key in section without regexp
    assert lookupMod.get_value('user', 'global', None, False) == u'johndoe'
    # value from key in section with regexp
    assert lookupMod.get_value('.*', 'global', None, True) == u'johndoe'
    # default value with unknown key in section with regexp
    assert lookupMod.get_value('.*', 'default', 'foo', False) == u'foo'
   

# Generated at 2022-06-21 06:04:36.133023
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Mock a constructor of class LookupBase
    lookup_base = LookupBase()
    lookup_module = LookupModule(loader=None, variables=None)
    # Check TypeError exception if both variables and direct arguments have the same keys.
    with pytest.raises(AnsibleOptionsError):
        lookup_base.set_options(var_options={'file': 'ansible.ini', 'section': 'global'}, direct={'file': 'ansible.cfg'})
        lookup_module.set_options(var_options={'file': 'ansible.ini', 'section': 'global'}, direct={'file': 'ansible.cfg'})
    # Check TypeError exception if a variable option is passed but dict is empty.

# Generated at 2022-06-21 06:04:37.377200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:04:44.170423
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ini_str = """[section1]
app1 = val1
app2 = val2
app3 = val3

[section2]
app1 = val1
app2 = val2
app3 = val3
"""
    l = LookupModule()
    l.cp = configparser.ConfigParser()
    l.cp.readfp(StringIO(ini_str))

    # Tests regexp cases
    assert l.get_value(".*", "section1", None, True) == ['val1', 'val2', 'val3']
    assert l.get_value(".*", "section2", None, True) == ['val1', 'val2', 'val3']
    assert l.get_value(".*", "section3", None, True) == []

    # Tests all cases of key existence
    assert l

# Generated at 2022-06-21 06:04:52.103581
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['app1', 'app2', 'app3', 'app4']
    variables = {'type': 'properties', 'file': 'test.properties'}
    lookup_plugin = LookupModule()

    # Initialization of LookupModule
    lookup_plugin.run(terms, variables, encoding='utf-8', case_sensitive=True, allow_no_value=True)

    # Check if __init__ executed correctly
    cp = lookup_plugin.cp
    assert cp.allow_no_value is True
    assert cp.optionxform is str
    assert cp._sections == defaultdict(list)



# Generated at 2022-06-21 06:05:04.644427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    def test_parse_params(params, expect_params, expect_error=None, msg=None):
        """Generic test for method _parse_params"""
        if expect_error is None:
            # positive cases
            result = _parse_params(params, {})
            assert result == expect_params, msg
        else:
            # negative cases
            try:
                result = _parse_params(params, {})
            except AnsibleLookupError:
                pass
            else:
                raise AssertionError('Method _parse_params should have raised an AnsibleLookupError')

    # Test method _parse_params
    msg = 'Params %s should give %s'
    # Positive cases

# Generated at 2022-06-21 06:05:15.787959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six.moves import configparser
    from io import StringIO

    class TestLookupModule(LookupModule):

        def get_value(self, key, section, dflt, is_regexp):
            return self.cp.get(section, key)

    tlm = TestLookupModule()
    tlm.cp = configparser.ConfigParser()
    tlm.cp.add_section("my_section")
    tlm.cp.set("my_section", "my_key", "my_value")
    tlm.cp.set("my_section", "my_other_key", "my_other_value")

# Generated at 2022-06-21 06:05:21.958255
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_file = '''
    [global]
    url = http://localhost
    '''


# Generated at 2022-06-21 06:05:30.392478
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 06:05:37.913508
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Empty ini
    empty_ini = "[global]\n"
    # Example of ini
    ini1 = """
        [global]
        user = Yannig
        [integration]
        user = Yannig
        password = secret
        [production]
        user = root
        password = supersecret
    """
    # Example of ini with spaces in the key
    ini2 = """
            [global]
            user = Yannig
            [integration]
            user = Yannig
            password = secret
            [production]
            user = root
            password = supersecret
            [with spaces]
            user = yannig
            """
    # Example of ini with no key

# Generated at 2022-06-21 06:05:50.250824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests of 'ini' type file
    import os
    import tempfile
    import shutil
    import configparser
    _tempdir = tempfile.mkdtemp()
    fd, path = tempfile.mkstemp(dir=_tempdir)
    f = os.fdopen(fd, 'w')
    cp = configparser.ConfigParser()
    cp.optionxform = to_native
    f.write('[section]\n')
    f.write('key1=val1\n')
    f.write('key2=val2\n')
    f.write('key3=val3\n')
    f.close()

    # Tests for regexp and default value
    paramvals = dict(file=path, section='section', re=False)

# Generated at 2022-06-21 06:06:03.931059
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    from ansible.module_utils._text import to_text

    lm = LookupModule()

    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(u'[java_properties]\n')

    # Open file using encoding
    config.write(to_text(u'foo=bar\nkey=value\nuser=yannig\nuser=yperre'))
    config.seek(0, os.SEEK_SET)

    lm.cp.readfp(config)

    assert(lm.get_value("user", "java_properties", "", False) == "yannig")
    assert(lm.get_value("user", "java_properties", "", True) == ["yannig", "yperre"])

# Generated at 2022-06-21 06:06:05.116351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module != None)

# Generated at 2022-06-21 06:06:14.098013
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    tmp_file='/tmp/test_LookupModule'
    os.system('touch '+tmp_file)
    os.system("echo '[section1]\nphrase1=value1\nphrase2=value2' > "+tmp_file)

    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.read(tmp_file)

    # Test regexp
    assert lookup_module.get_value('.*', 'section1', None, True) == ['value1', 'value2']

    # Test key
    assert lookup_module.get_value('phrase1', 'section1', None, False) == 'value1'

    # Test default value

# Generated at 2022-06-21 06:06:14.775359
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule(), 'run')

# Generated at 2022-06-21 06:06:25.729814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramval = dict()
    paramval['allow_no_value'] = True
    paramval['type'] = 'ini'
    paramval['file'] = 'file.ini'
    paramval['section'] = 'section1'
    paramval['default'] = ''
    paramval['re'] = True
    paramval['case_sensitive'] = False

    # The file has section: section1
    # The file has key: key1, key2
    terms = ['key1', 'key2']

    expected = []
    for term in terms:
        value = 'value-%s' % term
        expected.append(value)

    module = LookupModule()

    # The file has the following content
    # [section1]
    # key1 = value-key1
    # key2 = value-key2

# Generated at 2022-06-21 06:06:36.070138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term = 'lookup item'
    params = _parse_params(term, {'file': 'ansible.ini', 'section': 'global', 'default': '', 're': False, 'type': 'ini'})
    assert params == ['lookup item']
    term = 'param1=value1 param2=value2 lookup item'
    params = _parse_params(term, {'file': 'ansible.ini', 'section': 'global', 'default': '', 're': False, 'type': 'ini'})
    assert params == ['value1', 'value2', 'lookup item']
    term = 'param1=value1 "param2 = value2" lookup item'

# Generated at 2022-06-21 06:06:48.351497
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # c.f. https://gist.github.com/peterhudec/5295132
    # https://docs.python.org/2/library/configparser.html
    cfg = """

[section1]
# comment
key1 = value1
key2 = value2
key3 = value3

[section2]
key4 = value4
key5 = value5
key6 = value6

[section3]
key7 = value7
key8 = value8
key9 = value9

[section4]
# comment
key10 = value10
key11 = value11
key12 = value12

"""
    # Load the configuration
    cp = configparser.ConfigParser()
    cp.readfp(StringIO(cfg))
    # Reset the pointer

# Generated at 2022-06-21 06:07:06.861604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.option_names() == {'file', 'default', 'encoding', 'allow_no_value', 'allow_none', 'type', 'case_sensitive', 're', 'section'}
    # Check default values
    options = lookup_plugin.get_options()
    assert options == {'file': 'ansible.ini', 'section': 'global', 'type': 'ini', 'default': '', 'encoding': 'utf-8', 're': False, 'case_sensitive': False}


# Generated at 2022-06-21 06:07:20.238741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    config = StringIO()
    config.write("""[global]
    server = fakeserver
    [integration]
    user = fakeuser
    [production]
    user = produser
    """)
    config.seek(0, os.SEEK_SET)
    lookup.cp.readfp(config)
    assert lookup.get_value('server', 'global', None, False) == 'fakeserver'
    assert lookup.get_value('user', 'integration', None, False) == 'fakeuser'
    assert lookup.get_value('user', 'production', None, False) == 'produser'
    assert lookup.get_value('user', 'production', None, True) is None

# Generated at 2022-06-21 06:07:31.501916
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # create a test file
    # test.ini file has the following content:
    # [section1]
    # key1 = value1

    file = open('test.ini', 'w')
    file.write('[section1]\n')
    file.write('key1 = value1\n')
    file.close()

    # get_value shall raise a configParser.NoSectionError
    # because section section1 doesn't exist
    try:
        lookup_plugin.get_value('key1', 'section2', 'default value', False)
        assert False
    except configparser.NoSectionError:
        assert True
    finally:
        os.remove('test.ini')

# Generated at 2022-06-21 06:07:38.153710
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    res = lookup.run(['foo'], dict(), type='ini')
    assert res == []
    res = lookup.run(['foo'], dict(), type='ini', section='foo', file='foo')
    assert res == []

# Generated at 2022-06-21 06:07:44.602999
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a lookup base instance
    lookup = LookupModule()
    # Create a configuration parser
    lookup.cp = configparser.ConfigParser()
    # Set allow_no_value parameter to True
    lookup.cp.optionxform = lambda option: option
    lookup.cp.allow_no_value = True
    # Add a section
    lookup.cp.add_section('section1')
    # Add some options
    lookup.cp.set('section1', 'test1', 'test_value')
    lookup.cp.set('section1', 'test2', 'test_value2')
    lookup.cp.set('section1', 'test3', 'test_value3')
    # Retrieve all values from a section using a regexp

# Generated at 2022-06-21 06:07:45.909606
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 06:07:58.917241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    dummy_loader = DataLoader()
    variable_manager = VariableManager()
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(dummy_loader)
    lookup_plugin.set_variable_manager(variable_manager)
    searchpath = [os.path.dirname(os.path.realpath(__file__)) + "/lookup_plugins/files"]
    terms = ['user', 'group2', 'group1']
    # section = ini
    test_params = {'file': 'ansible.ini', 'type': 'ini', 'section': 'ini', 're': False}

# Generated at 2022-06-21 06:07:59.974077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 06:08:03.344701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instanciate a LookupModule Object
    test = LookupModule()

# Generated at 2022-06-21 06:08:05.948288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Validate the test of creation class LookupModule."""
    assert LookupModule


# Generated at 2022-06-21 06:08:24.642646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test type properties
    assert lookup_module.run(["user.name", "file=user.properties", "type=properties"], variables=dict(files='user.properties')) == ["John"]

    # Test type ini
    with open("test.ini", 'w') as f:
        f.write("[section1]\n")
        f.write("value1=John\n")
        f.write("value2=Doe\n")
        f.write("[section2]\n")
        f.write("multi=value1\n")
        f.write("multi=value2\n")
        f.write("multi=value3\n")
    assert lookup_module.run(["value1"], variables=dict(files='test.ini')) == ["John"]


# Generated at 2022-06-21 06:08:31.361934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Definition of arguments for method run of class LookupModule
    terms = None
    variables = None
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)

    # Check if the result is correct
    #assert
    return


# Generated at 2022-06-21 06:08:40.970510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test of LookupModule.run
    '''

    # create test file
    f = open("ansible.ini", "w")
    f.write("[global]\n")
    f.write("var1=value1\n")
    f.write("var2=value2\n")
    f.write("var3=value3\n")
    f.write("var4=value4\n")
    f.close()

    # init lookup module
    lm = LookupModule()

    # run the lookup module
    lm.run([], None)

    # remove test file
    os.remove("ansible.ini")

# Generated at 2022-06-21 06:08:54.124063
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()

    config = StringIO()
    # Java Properties
    config.write(u'[java_properties]\n')
    # Ini
    config.write(u'[global]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'[section]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')

    config.seek(0, os.SEEK_SET)
    lookup_module.cp.readfp(config)

    # Test: get value java property

# Generated at 2022-06-21 06:08:56.752926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    res = lookup.run(['user', 'password'], {}, file='users.ini')
    assert res == ['alice', 'secret']

    res = lookup.run(['user', 'password'], {}, file='users.ini', section='production')
    assert res == ['bob', 'not_so_secret']

# Generated at 2022-06-21 06:08:59.965378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:09:07.796809
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_file = '''
    [section-1]
    key_1=val1
    key_2=val2
    key_3=val3

    [section-2]
    key_1=val1
    key_2=val2
    key_3=val3
    '''

    # Simple test
    test_term = 'key_1'
    test_params = {
        'file': 'test.ini',
        're': False,
        'default': '',
        'section': 'section-1',
        'type': 'ini'
    }

    # Test LookupModule.run()
    lookup = LookupModule()

# Generated at 2022-06-21 06:09:17.652659
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test = LookupModule()
    test.cp = configparser.ConfigParser()
    test.cp.add_section('section1')
    test.cp.set('section1', 'key1', 'value1')
    test.cp.set('section1', 'key2', 'value2')
    result = test.get_value('key1', 'section1', None, False)
    assert result == 'value1'

    assert test.get_value('key1', 'nosuchsection', 'default', False) == 'default'

    test.cp.add_section('section2')
    test.cp.set('section2', 'key1', 'value1b')
    assert test.get_value('key1', 'section2', None, False) == 'value1b'


# Generated at 2022-06-21 06:09:23.910451
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    instance = LookupModule()
    cp = configparser.ConfigParser()
    instance.cp = cp
    #Test if return value is a list
    cp.readfp(StringIO(u'''
    [section1]
    key1=value1
    key2=value2
    '''))
    assert isinstance(instance.get_value('.*', 'section1', False), MutableSequence)
    #Test if return a value for a key for section
    cp.readfp(StringIO(u'''
    [section2]
    key1=value1
    key2=value2
    '''))
    assert instance.get_value('key1', 'section2', None, False) == 'value1'
    #Test if return a default value if key is not in the ini file
    assert instance.get_

# Generated at 2022-06-21 06:09:26.916515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(isinstance(lm, LookupModule))


# Generated at 2022-06-21 06:09:35.250196
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result.cp == configparser.ConfigParser(allow_no_value=False)
    assert result.cp.optionxform == to_native


# Generated at 2022-06-21 06:09:42.522421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def new_lookup_module():
        lookup_module = LookupModule()
        lookup_module.set_options(var_options=None, direct=None)
        return lookup_module

    def is_instance_of(object, class_name):
        return object.__class__.__name__ == class_name

    # Test init when param is not set
    lookup_module = new_lookup_module()
    assert lookup_module is not None
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:09:49.622385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    module = LookupModule()
    module.set_loader(DataLoader())

    # Empty config file
    config_content = u"""

"""
    # Create a tempory file with an empty content
    file_path = utils.create_tempfile(config_content, 'ini_test')
    # Make sure file is not empty
    assert os.path.isfile(file_path)

    # Test default parameters
    result = module.run([file_path])
    # Default section is 'global'
    expected_result = []
    assert result == expected_result

    # Test [section_in_empty] section with default key
    result = module.run([file_path + ":section_in_empty"])
    expected_result = []
    assert result

# Generated at 2022-06-21 06:09:59.582055
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Regexp(s)
    assert [u'akjhds', u'kadhs'] == LookupModule().get_value('a.*', 'section1', None, True)
    assert [u'kadhs'] == LookupModule().get_value('^k.*', 'section1', None, True)
    assert [u'kadhs'] == LookupModule().get_value('^k', 'section1', None, True)
    assert [u'akjhds', u'kadhs'] == LookupModule().get_value('^k|a', 'section1', None, True)
    assert [] == LookupModule().get_value('z', 'section1', None, True)
    # No regexp

# Generated at 2022-06-21 06:10:08.767151
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.add_section('section2')
    cp.set('section2', 'key2', 'value2')
    cp.set('section2', 'key3', 'value3')
    cp.set('section2', 'key4', 'value4')
    cp.set('section2', 'key5', 'value5')
    l = LookupModule()
    l.cp = cp
    # Test regexp
    assert l.get_value('.*', 'section1', 'value1', True) == ['value1']

# Generated at 2022-06-21 06:10:19.955339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import configparser
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup.ini import LookupModule

    # Create test data
    test_ini = """[section]
key=value
key2=42
key3="with spaces"
key4="list, separated, by, commas"
key5="1, 2, 3"
"""

    test_props = "key=value"

    # Create a test object
    lookup = LookupModule()

    # Test a basic ini
    ini_file = open('test.ini', 'w')

# Generated at 2022-06-21 06:10:22.085183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    src = LookupModule()
    assert src is not None


# Generated at 2022-06-21 06:10:32.225077
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_plugin = LookupModule()
    # Create a ini file
    ini_file = StringIO()
    ini_file.write(u'[section1]\n')
    ini_file.write(u'key1=value1\n')
    ini_file.write(u'key2=value2\n')
    ini_file.write(u'key3=value3\n')
    ini_file.write(u'[section2]\n')
    ini_file.write(u'key4=value4\n')
    ini_file.write(u'key5=value5\n')
    ini_file.seek(0, os.SEEK_SET)
    lookup_plugin.cp = configparser.ConfigParser()
    lookup_plugin.cp.read

# Generated at 2022-06-21 06:10:42.425845
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import io
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    def get_vars(**kwargs):
        return VariableManager(loader=DataLoader()).get_vars(play=dict(connection='local',), **kwargs)

    l = LookupModule()
    l.set_options(var_options=get_vars(), direct=dict(type='ini', re=False))

    # Create StringIO later used to parse ini
    config = io.StringIO()
    config.write(u'[section]\nkey=value\n')
    config.seek(0, os.SEEK_SET)

    l.cp.readfp(config)


# Generated at 2022-06-21 06:10:45.934370
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _ = LookupModule(
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-21 06:11:11.874508
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section('test')
    lookup.cp.set('test', 'key', 'value')

    assert lookup.get_value('key', 'test', 'default', False) == 'value'
    assert lookup.get_value('KEY', 'test', 'default', False) == 'value'
    assert lookup.get_value('non_existing_key', 'test', 'default', False) == 'default'

    lookup.cp.add_section('other')
    lookup.cp.set('other', 'foo', 'bar')
    lookup.cp.set('other', 'foo_value', 'bar_value')

    assert lookup.get_value('foo', 'other', 'default', True) == ['bar']
    assert lookup.get_value

# Generated at 2022-06-21 06:11:12.681049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-21 06:11:24.738071
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(u'[section1]\nkey1=value1\nkey2=value2\nkey3=value3\n')
    config.seek(0, os.SEEK_SET)
    lookup.cp.readfp(config)

    # Test with key and section in INI
    assert lookup.get_value('key1', 'section1', '', False) == 'value1'
    assert lookup.get_value('key2', 'section1', '', False) == 'value2'
    assert lookup.get_value('key3', 'section1', '', False) == 'value3'

    # Test with key not in INI

# Generated at 2022-06-21 06:11:35.290336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test that checks lookup() method of the LookupModule class'''
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    obj = LookupModule()
    obj.set_options(direct={'file': 'test_ini.ini', 'encoding': 'utf-8', 'case_sensitive': False})

    obj.cp = configparser.ConfigParser()
    obj.cp.readfp(StringIO(u'[section1]\n'
                           u'user=test\n'
                           u'passwd=test\n'
                           u'novalue='))

    assert obj.get_value('user', 'section1', '', False) == 'test'

    if PY3:
        assert obj.get

# Generated at 2022-06-21 06:11:38.116337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)


# Generated at 2022-06-21 06:11:46.890459
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule instance
    lm = LookupModule()
    # Set the default encoding to UTF8 
    lm.set_options(direct={ 'encoding': 'utf8' })

    # Set the terms we want to look up
    terms = ['user', 'password', 'special_char=\u2603']

    # Create a test ini file
    content = u"""
      [global]
      user = root
      password = hunter2
      special_char=\u2603
      user_from_includee = root
    """

    # Create a test ini file
    includee_content = u"""
      [global]
      user_from_includee = root
    """

    # Create a test ini file with duplicated option

# Generated at 2022-06-21 06:11:56.772541
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os

    # Prepare the config file
    config = StringIO()
    config.write(u'''
[global]
user=Bob F.
''')
    config.seek(0, os.SEEK_SET)

    # Create module
    lookup = LookupModule()

    # Read the config file
    cp = configparser.ConfigParser()
    cp.readfp(config)

    # Set some parameters
    term = "user=Bob F."
    paramvals = {'section': 'global', 'default': '', 're': False}

    # Get the value
    value = lookup.get_value(term, paramvals['section'], paramvals['default'], paramvals['re'])

    # Compare the result
    assert value == "Bob F."

# Generated at 2022-06-21 06:12:05.135114
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Given a config parser with a section
    cp = configparser.ConfigParser()
    config = "[section]\n"
    config += "key1=value1\n"
    config += "key2=value2\n"
    config += "key3=value3"
    cp.readfp(StringIO(config))

    # And a LookupModule with this config parser
    lookup_module = LookupModule()
    lookup_module.cp = cp

    # When I retrieve value with key that exists
    result = lookup_module.get_value("key1", "section", "", False)

    # Then the result is the value associated to key I gave
    assert result == "value1"


# Generated at 2022-06-21 06:12:14.987898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DictDataLoader({
        "test.ini": """
[Integration]
port = 8080
user = toto
password = toto

[Production]
port = 80
user = tata
password = tata

[global]
port = 8080
user = ansible
password = ansible
""",
        "user.properties": """
user.name = bob
user.password = bob
"""
    })

    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    lookup_plugin = LookupModule()


# Generated at 2022-06-21 06:12:24.520432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping
    args = {
        '_ansible_no_log': False,
        '__ansible_module_name': 'test'
    }
    loader = DataLoader()

# Generated at 2022-06-21 06:12:59.686278
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Get LookupModule instance
    lookup_module = LookupModule()

    params = {
        're' : True,
        'default' : '',
        'encoding' : 'utf-8',
        'allow_none' : False,
        'case_sensitive' : False,
    }
    # 1. No section in file
    data = """
        [section1]
        key=value
    """
    config = StringIO()
    config.write(data)
    config.seek(0, os.SEEK_SET)
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(config)
    assert lookup_module.get_value('key', 'section2', params['default'], params['re']) == ''

    # 2. Regexp in key
   

# Generated at 2022-06-21 06:13:07.705213
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    contents = "[section]\nkey=value\nkey1=value1\nkey2=value with space\nkey3=value3"
    fp = StringIO()
    fp.write(contents)
    fp.seek(0, os.SEEK_SET)

    config = configparser.ConfigParser(allow_no_value=True)
    config.readfp(fp)


# Generated at 2022-06-21 06:13:12.364876
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import unittest

    class TestLookupModule(unittest.TestCase):
        def test_get_value(self):
            test_lookup = LookupModule()
            path = os.path.dirname(__file__) + "/test.ini"
            config = configparser.ConfigParser()
            config.read(path)
            test_lookup.cp = config

            section = "section1"
            # Test match all
            self.assertEqual(test_lookup.get_value(".*", section, "", True), ['bar1', 'bar2', 'bar3', 'bar4'])
            # Test without regexp
            self.assertEqual(test_lookup.get_value("key3", section, "", False), 'bar3')
            # Test with regexp but without match

# Generated at 2022-06-21 06:13:25.072008
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    c = LookupModule()
    c.cp = configparser.ConfigParser()
    c.cp.add_section('global')
    c.cp.set('global', 'key1', 'value1')
    c.cp.set('global', 'foo', 'bar')
    c.cp.set('global', 'foo1', 'spam')
    c.cp.set('global', 'foo2', 'eggs')

    assert c.get_value('key1', 'global', None, False) == 'value1'
    assert c.get_value('key2', 'global', 'defaultvalue', False) == 'defaultvalue'
    assert c.get_value('.*', 'global', None, True) == ['value1', 'bar', 'spam', 'eggs']

# Generated at 2022-06-21 06:13:36.970322
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    module = LookupModule()
    class MockClass:
        def __init__(self, value):
            self.value = value
        def items(self, section):
            return (('key1', 'value1'), ('key2', 'value2'))
    class MockConfigParser:
        def __init__(self):
            pass
        def items(self, section):
            return (('key1', 'value1'), ('key2', 'value2'))
    module.cp = MockConfigParser()
    assert module.get_value('key1', 'section1', '', False) == 'value1'
    assert module.get_value('key2', 'section1', '', False) == 'value2'
    assert module.get_value('key3', 'section1', '', False) == ''
    assert module.get_

# Generated at 2022-06-21 06:13:48.985493
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Initialize LookupModule
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()

    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(u'[global]\nkey=value\n')
    config.seek(0, os.SEEK_SET)
    lm.cp.readfp(config)

    # Test with a valid key, the default value and a regexp
    assert lm.get_value('key', 'global', 'dflt', False) == 'value'

    # Test with an invalid key, the default value and a regexp
    assert lm.get_value('invalid_key', 'global', 'dflt', False) == 'dflt'

    # Test with a regexp