

# Generated at 2022-06-25 10:43:25.353151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path = "/tmp"
    term = "test"
    content = "[test]\ntest=value of test"
    with open(path + '/inifile', "w") as f_inifile:
        f_inifile.write(content)

    lookup_module = LookupModule()
    lookup_module.set_options({'file':'inifile', 'section':'test'}, direct={'file':'inifile', 'section':'test'})
    lookup_module.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module.cp.readfp(StringIO(content))
    result = lookup_module.get_value(term, "test", None, False)
    assert result == 'value of test'


# Generated at 2022-06-25 10:43:27.955409
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    obj = LookupModule()
    test_case_1 = obj.get_value("key1","section1","default",False)
    test_case_2 = obj.get_value(".*","section1","default",True)
    assert test_case_1 == "value1"
    assert test_case_2 == ["value1"]

# Generated at 2022-06-25 10:43:39.092458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a valid file
    lookup_module_1 = LookupModule()
    terms = ['foo', 'bar']
    assert(lookup_module_1.run(terms, variables=None, **{'file': 'plugins/lookup/ini_test/valid.ini', 'case_sensitive': True}) == ['baz', ['baz2', 'baz3']])

    # test with a file without section
    lookup_module_2 = LookupModule()
    terms = ['section1', 'section2']
    assert(lookup_module_2.run(terms, variables=None, **{'file': 'plugins/lookup/ini_test/no_section.ini', 'case_sensitive': True}) == ['value1', ['value2', 'value3']])

    # test with a file without value
    lookup_

# Generated at 2022-06-25 10:43:49.427112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    lookup_module_instance.cp = configparser.ConfigParser()
    lookup_module_instance.cp.readfp(StringIO("[section_0]\nkey_1=value_1\nkey_2=value_2"))

    terms_0 = ['key_1']
    section = "section_0"
    default = ""
    is_regexp = False

    lookup_module_instance.cp = configparser.ConfigParser()
    lookup_module_instance.cp.readfp(StringIO("[section_0]\nkey_1=value_1\nkey_2=value_2"))
    # call run method of LookupModule instance

# Generated at 2022-06-25 10:43:54.952549
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.get_value("key","a_section","",False) == None
    assert lookup_module_0.get_value("key","a_section","",True) == []
    assert lookup_module_0.get_value("^key","a_section","",True) == []


# Generated at 2022-06-25 10:44:04.692319
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    section = None
    dflt = None
    is_regexp = None

    # Test 1 get_value
    configparser_1 = configparser.ConfigParser()
    configparser_1._sections = {'global': {'user': 'ansible', 'hostname': '127.0.0.1'}}
    lookup_module_1.cp = configparser_1
    section = 'global'
    key = 'user'
    dflt = None
    is_regexp = False
    result = lookup_module_1.get_value(key, section, dflt, is_regexp)
    assert result == "ansible"

    # Test 2 get_value
    configparser_1 = configparser.ConfigParser()

# Generated at 2022-06-25 10:44:09.057991
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()

    # Has error
    assert lookup_module_0.get_value(key='DEFAULT.server_name', section='section1', dflt='', is_regexp=False) == ''

    # Has error
    assert lookup_module_0.get_value(key='.*', section='section1', dflt=[], is_regexp=True) == []

    # Normal
    assert lookup_module_0.get_value(key='.*', section='section1', dflt='', is_regexp=True) == ['se1', 'se2']


# Generated at 2022-06-25 10:44:19.394143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = '''[section1]
key1=value1
key2=value2
'''

    lookup_module = LookupModule()
    lookup_module.set_options({'file': 'test.ini', 'section': 'section1'})
    lookup_module.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module.cp.read_string(data)
    params = 'key1'
    assert lookup_module.run([params]) == ['value1']

    data = '''[section1]
key1=value1
key2=value2
'''

    lookup_module = LookupModule()
    lookup_module.set_options({'file': 'test.ini', 'section': 'section1'})

# Generated at 2022-06-25 10:44:26.852748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for the case where type is ini
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct={'type':'ini','file':'test.ini','section':'section1','default':''})
    paramvals = lookup_module_1.get_options()
    lookup_module_1.cp = configparser.ConfigParser()
    lookup_module_1.cp.optionxform = str

# Generated at 2022-06-25 10:44:38.161337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile
    from contextlib import contextmanager

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # With contextmanager we create a temporary directory
    @contextmanager
    def tempdir():
        dirpath = tempfile.mkdtemp()
        try:
            yield dirpath
        finally:
            shutil.rmtree(dirpath)

    with tempdir() as dirpath:
        # Is it a directory ?
        assert os.path.isdir(dirpath) == True
        # Create lookup module
        lookup_module_0 = LookupModule()
        # Create file

# Generated at 2022-06-25 10:45:00.137794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = StringIO()
    config.write(u'[java_properties]\n')
    config.write(u'anURL=http://localhost:8080')
    config.seek(0, os.SEEK_SET)
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.readfp(config)
    lookup_module = LookupModule()
    lookup_module.cp = cp
    paramvals = {'file': 'file.ini', 'type': "properties", 'section': 'java_properties', 'default': '', 're': False, 'case_sensitive': False, 'allow_no_value': False}
    ret = lookup_module.get_value('anURL', paramvals['section'], paramvals['default'], paramvals['re'])

# Generated at 2022-06-25 10:45:10.229126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = {
        "_terms": ['test1', 'test2'],
        "type": "ini",
        "file": "my_file",
        "section": "my_section",
        "re": False,
        "encoding": "utf-8",
        "default": "",
        "case_sensitive": False,
        "allow_no_value": False,
        "allow_none": False,
    }
    my_dict = {
        'user1': 'user1_value',
        'user2': 'user2_value',
        'user3': 'user3_value',
        'user4': 'user4_value',
    }


# Generated at 2022-06-25 10:45:17.195053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    txt = """
    [section1]
    var1 = foo
    var2 = bar

    [section2]
    var3 = baz
    """
    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(txt)
    config.seek(0, os.SEEK_SET)

    cp = configparser.ConfigParser()

    cp.readfp(config)

    # result = lookup_module.run(terms, variables=None, **kwargs)
    # assert result == expected


# Generated at 2022-06-25 10:45:26.783689
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 0
    ## test with missing required arg: terms
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(['test_ini'])
        assert False
    except AnsibleLookupError as exception_0:
        assert 'Missing required arguments: terms' == str(exception_0)

    # Case 1
    ## test with wrong args
    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run(['test_ini'], ['test_ini'])
        assert False
    except AnsibleLookupError as exception_1:
        assert 'Missing required arguments: terms' == str(exception_1)

    # Case 2
    ## test with wrong parameters

# Generated at 2022-06-25 10:45:36.463684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    lookup_module_instance.set_options(var_options=None,
                                       direct={u'file': u'users.ini', u'section': u'global', u're': False, u'default': u'', u'encoding': u'utf-8', u'case_sensitive': False, u'allow_no_value': False})
    lookup_module_instance.cp = configparser.ConfigParser()

    # `configparser.ConfigParser.items` returns an iterable in Python 2.7 but
    # an iterator in Python 3.6
    # This workaround prepares both cases.

# Generated at 2022-06-25 10:45:43.946107
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # test 1
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section("mysqld")
    cp.set("mysqld", "innodb_file_per_table", "on")
    cp.set("mysqld", "character-set-server", "utf8")
    cp.set("mysqld", "innodb_buffer_pool_size", "8M")
    cp.set("mysqld", "innodb_log_file_size", "5M")
    cp.set("mysqld", "innodb_log_buffer_size", "8M")
    cp.set("mysqld", "innodb_flush_log_at_trx_commit", "2")

# Generated at 2022-06-25 10:45:51.585017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import builtins

    b_open = builtins.open


# Generated at 2022-06-25 10:45:55.704254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'key1']
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:46:04.859681
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()

    # Test section is not present
    lookup_module_1.cp.read('ini_test_3.ini')
    assert lookup_module_1.get_value('user', 'test', None, False) == None

    # Test key is not present
    lookup_module_1.cp.read('ini_test_1.ini')
    assert lookup_module_1.get_value('user', 'test', None, False) == None

    # Test key is present
    assert lookup_module_1.get_value('user', 'test', None, False) == 'you'

    # Test key is a regexp
    lookup_module_1.cp.read('ini_test_2.ini')
    assert lookup_module

# Generated at 2022-06-25 10:46:13.225453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['user1',
             'user2',
             'user3',
             'user4',
             'user5',
             'user6']

    variables = {'ansible_env': {'HOME': '/home/user'}}

    kwargs_0 = {
        'type': 'properties',
        'file': 'user1.properties',
        'default': 'root',
        'encoding': 'iso-8859-1',
        're': False,
        'section': '',
        'case_sensitive': False,
    }

# Generated at 2022-06-25 10:46:42.186015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    cp_0 = configparser.ConfigParser()
    path_0 = lookup_module_0.find_file_in_search_path(variables, 'files', 'file')
    variables.write(path_0)
    with open(path_0, 'r') as file:
        show_data = file.read()
    contents = cp_0.readfp(file)
    assert contents == show_data


# Generated at 2022-06-25 10:46:48.884878
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_0 = LookupModule()

    config_parser_0 = configparser.ConfigParser()

    str_1 = StringIO()

    lookup_module_0._cp = config_parser_0

    str_2 = StringIO()

    str_2.write(u'[section1]\n')

    str_2.seek(0, os.SEEK_SET)

    config_parser_0.readfp(str_2)

    str_3 = StringIO()

    str_3.write(u'[section1]\n')

    str_3.seek(0, os.SEEK_SET)

    config_parser_0.readfp(str_3)

    var_0 = lookup_module_0.get_value(u'key1', u'section1', None, False)

    assert var

# Generated at 2022-06-25 10:46:50.188204
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.get_value('', '', '', False) == ''


# Generated at 2022-06-25 10:46:54.314094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(StringIO(u'[test_section]\nkey=value\n'))

    ret = lookup_module.run([u'key'], dict())
    assert isinstance(ret, list)
    assert ret == [u'value']

# Generated at 2022-06-25 10:47:04.944746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test for exception
    with pytest.raises(AnsibleOptionsError):
        lookup_module_0.run(terms=[''])
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(terms=['param1=value1'])
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(terms=['key=value1', 'param1=value1'])
    with pytest.raises(AnsibleOptionsError):
        lookup_module_0.run(terms=['key', 'param1=value1'])

# Generated at 2022-06-25 10:47:12.294971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    temp = {'file': 'mytest.ini', 'section': 'test'}
    terms = ["testkey"]
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(StringIO('[test]\ntestkey = 123'))
    lookup_module.get_options = Mock(return_value=temp)
    lookup_module.set_options = Mock()
    lookup_module.find_file_in_search_path = Mock(return_value="mytest.ini")
    lookup_module._loader = Mock()
    lookup_module._loader._get_file_contents = Mock(return_value=('[test]\ntestkey = 123\n', True))

    assert lookup_module.run(terms) == ['123']

# Generated at 2022-06-25 10:47:18.582717
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    contents = u'''
[section1]
key1=value1
key2=value2

[section2]
key1=value1
key2=value2

[section3]
key1=value1
key2=value2
'''

    config = StringIO(contents)

    ini_file_path = './test_lookup_ini.ini'

    with open(ini_file_path, 'w') as f:
        config.seek(0, os.SEEK_SET)
        f.write(config.read())

    lookup_module_0 = LookupModule()
    lookup_module_0._loader = DummyClass()
    lookup_module_0._loader._basedir = './'
    lookup_module_0._loader._searchpath = '.'

# Generated at 2022-06-25 10:47:23.679274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test no parameters
    lookup_module_0 = LookupModule()
    var = lookup_module_0.run(terms=[])
    assert var == []

    # Test one key
    lookup_module_1 = LookupModule()
    var = lookup_module_1.run(terms=[u"key1"])
    assert var == []

    # Test one key with parameters
    lookup_module_2 = LookupModule()
    var = lookup_module_2.run(terms=[u"file=/tmp/test.ini"])
    assert var == []

    # Test one key with section
    lookup_module_3 = LookupModule()
    var = lookup_module_3.run(terms=[u"key1 section=section1"])
    assert var == []

    # Test one key with section and file
    lookup_module_

# Generated at 2022-06-25 10:47:32.765489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ini_file_content = """[global]
key1=value1
key2=value2

[section1]
key3=value3
key4=value4

[section2]
key5=value5
key6=value6
"""
    for line in ini_file_content.split('\n'):
        print(line)
    config = StringIO(ini_file_content)
    cp = configparser.ConfigParser()
    cp.readfp(config)

    lookup_module_0 = LookupModule()
    lookup_module_0.cp = cp
    ret = lookup_module_0.get_value('key1', 'global', 'default', False)
    assert ret == 'value1'

# sample test

# Generated at 2022-06-25 10:47:39.442118
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()

    # Retrieve a single value
    # case 1: value exists
    assert lookup_module.get_value('key1', 'section1', 'dflt', False) == 'value1'

    # case 2: value does not exists, default value provided
    assert lookup_module.get_value('nokey', 'section1', 'dflt', False) == 'dflt'

    # case 3: value does not exists, default value not provided
    assert lookup_module.get_value('nokey', 'section1', None, False) == None

    # Retrieve all values from a section using a regexp
    # case 1: regexp matches
    assert lookup_module.get_value('key.*', 'section1', None, True) == ['value1', 'value2', 'value3']

    #

# Generated at 2022-06-25 10:48:08.614760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms_0 = ['user', 'port', 'password', '[section2]']
    variables_0 = {'lookup_plugin_ini': {'default': '', 'allow_none': False, 'type': 'ini', 'file': 'ansible.ini', 'case_sensitive': False}, 'allow_no_value': False}
    kwargs_0 = {'file': 'ansible.ini'}
    assert lookup_module.run(terms_0, variables_0, **kwargs_0) == [u'user', u'user', u'password', u'8080']


# Generated at 2022-06-25 10:48:12.566651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['key']
    variables = {'ansible_lookup_plugin_path': asmbase_path}
    kwargs = {}
    ret = lookup_module_0.run(terms, variables, **kwargs)
    print(ret)

    #assert ret == 'value', "Ret is not value"


# Generated at 2022-06-25 10:48:17.978929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Declare a LookupModule object
    lookup_module_1 = LookupModule()

    # Declare the parameters required by the method run
    terms = 'user'
    variables = [{'file': 'users.ini', 'section': 'integration', 'type': 'ini'}]

    # Execute the method run
    test_result = lookup_module_1.run(terms,variables)
    # Here the data returned by the lookup plugin is always of type list.
    assert(isinstance(test_result,list))



# Generated at 2022-06-25 10:48:19.408190
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.get_value(key='key3', section='section1', dflt='dflt', is_regexp=True) == ['teststring']


# Generated at 2022-06-25 10:48:22.211841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'MAMP/tmp/php/php5.5.6/php.ini']
    assert lookup_module_0.run(terms, variables=None) == [u"/Applications/MAMP/bin/php/php5.5.6/bin/php"]

# Generated at 2022-06-25 10:48:33.843809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare test data
    kwargs = {'case_sensitive': True}
    file_contents = ('[global]\noption1 = value1\n')
    term = '[global] option1='
    terms = ['[global] option1=', '[global] option2=']
    variables = {}
    assert kwargs == {'case_sensitive': True}

    # Run test lookup
    lookup_module_with_args = LookupModule()
    lookup_module_with_args.run(terms, variables=variables, **kwargs)

    # Run test lookup using inline parameters
    lookup_module_inline_parameters = LookupModule()
    lookup_module_inline_parameters.run(term, variables=variables, **kwargs)

    # Run test lookup using classic parameters
    lookup_module_classic_parameters

# Generated at 2022-06-25 10:48:42.002082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser()
    lookup_module_0.find_file_in_search_path = lambda parameters_0: 'find_file_in_search_path'
    lookup_module_0._loader = type('_', (object,), {'_get_file_contents': lambda s, p: ('contents', 'show_data')})
    lookup_module_0.cp.readfp = lambda parameters_1: None
    lookup_module_0.cp.items = lambda parameters_2: []
    lookup_module_0.cp.get = lambda p1, p2: None
    lookup_module_0.get_value = lambda p1, p2, p3, p4: None

# Generated at 2022-06-25 10:48:52.823467
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Load the test data from the data directory
    data_dir = os.path.dirname(os.path.realpath(__file__)) + '/data'

    file_ini = os.path.join(data_dir, "test_ini.ini")
    with open(file_ini, "r") as f:
        lines = f.readlines()

    if lines[0] != '[global]\n':
        return False, "No 'global' section in INI file where it should be"

    if lines[1].split('=')[0] != 'foo':
        return False, "Key '' in section 'global' is 'foo' but found '%s'." % lines[1].split('=')[0]


# Generated at 2022-06-25 10:49:01.718918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test run")
    data_load = {
        'file': "ansible.ini",
        'section': 'integration',
        'default': '',
        're': False,
        'encoding': 'utf-8'
    }
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'type': 'ini'})
    result = lookup_module_0.run([u'user'], {}, **data_load)
    assert result == [u'yannig']



# Generated at 2022-06-25 10:49:10.549019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    result = lm.run(terms=["S1.key5", "S1.subkey1"], variables={}, section="S1", file="test.ini")
    assert result == ["val5", "val5.1"]
    result = lm.run(terms=["S1.key5", "S1.subkey1"], variables={}, section="S2", file="test.ini")
    assert result == ["val16"]
    with pytest.raises(AnsibleOptionsError):
        lm.run(terms=["S1.key5", "key6"], variables={}, section="S1", file="test.ini")


# Generated at 2022-06-25 10:50:17.620112
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = test_case_0()
    key_0 = 'foo'
    section_0 = 'section'
    dflt_0 = 'bar'
    is_regexp_0 = True
    lookup_module_0.get_value(key_0, section_0, dflt_0, is_regexp_0)


# Generated at 2022-06-25 10:50:22.196417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of LookupModule
    lookup_module_0 = LookupModule()

    # Create mocks for instance and for methods of the class
    lookup_module_0.cp = mock

    # Call run with parameters
    lookup_module_0.run([])

# Generated at 2022-06-25 10:50:33.851721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = "[test]"
    variables_2 = None
    params_3 = dict()
    params_3["encoding"] = "utf-8"
    params_3["case_sensitive"] = False
    params_3["allow_no_value"] = False
    params_3["section"] = "global"
    params_3["initial_error_text"] = ""
    params_3["default"] = ""
    params_3["re"] = False
    params_3["file"] = "ansible.ini"
    params_3["type"] = "ini"
    try:
        lookup_module_0.run(terms_1, variables_2, params_3)
    except Exception as e:
        assert(e.message == "No key to lookup was provided.")


# Generated at 2022-06-25 10:50:39.931547
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Configuration
    contents = u'''
    [section1]

    k1=v1

    k2=v2

    k3=v3

    [section2]

    k4=v4

    k5=v5

    k6=v6

    '''

    config = StringIO(contents)
    cp = configparser.ConfigParser()
    cp.readfp(config)

    # Test
    params = {
        'allow_no_value': False,
        'case_sensitive': False,
        'default': '',
        'encoding': 'utf-8',
        'file': 'test.ini',
        're': False,
        'section': 'section1',
        'type': 'ini',
    }

    lookup_module = LookupModule()

# Generated at 2022-06-25 10:50:42.267792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    results_1 = lookup_module_1.run(["name"], {}, {'file': 'ansible.ini'})
    assert results_1 == ["ansible"]

# Generated at 2022-06-25 10:50:48.680793
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    lookup_module_1._loader = None
    lookup_module_1.cp = configparser.ConfigParser()
    lookup_module_1.cp.read_string(u'[test]\nkey = value')
    value_1 = lookup_module_1.get_value(u'key', u'test', 'default', False)
    assert value_1 == u'value'
    value_2 = lookup_module_1.get_value(u'key', u'test', 'default', True)
    assert value_2 == u'value'
    value_3 = lookup_module_1.get_value(u'key', u'missing', 'default', False)
    assert value_3 == 'default'

# Generated at 2022-06-25 10:50:52.853913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._parser = configparser.ConfigParser()
    assert not lookup_module._parser.sections()
    assert lookup_module.run(terms="answer=42", variables=None, **{'allow_no_value': True})
    assert lookup_module._parser.sections()


# Generated at 2022-06-25 10:50:59.553323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    with open('test_LookupModule_run.ini', 'w') as f:
        f.write("""[general]
key1=value1
key2=value2
[section1]
key1=value1
key2=value2
key3=value3
[section2]
key1=value1
key2=value2
key3=value3
key4=value4""")
    term_0 = [ 'key1', 'key2' ]
    variables_0 = {}
    kwargs_0 = {}
    term_1 = [ 'key1' ]
    variables_1 = {}
    kwargs_1 = {}
    ret_0 = lookup_module.run(term_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 10:51:10.926740
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()
    lookup_module_1.cp.add_section("section")
    lookup_module_1.cp.set("section", "key", "value")
    assert lookup_module_1.get_value("key", "section", "", False) == "value"
    assert lookup_module_1.get_value("key", "section", "default", True) == "default"
    assert lookup_module_1.get_value("key", "section", "default", False) == "value"
    assert lookup_module_1.get_value("keys", "section", "default", False) == "default"
    lookup_module_1.cp.set("section", "key2", "value2")
    assert lookup_module_

# Generated at 2022-06-25 10:51:16.119356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {
        'file': 'test.ini',
        'section': 'section1',
        'default': 'default',
        're': False
    }
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'file': 'test.ini', 'section': 'section1', 're': False})
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.add_section('section1')
    lookup_module.cp.set(paramvals['section'], 'key1', 'value1')
    lookup_module.cp.set(paramvals['section'], 'key2', 'value2')
    lookup_module.cp.set(paramvals['section'], 'key3', 'value3')