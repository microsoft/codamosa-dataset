

# Generated at 2022-06-25 10:43:19.476140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 10:43:23.204011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['INI_FILE'], {}) == [], 'Return value of run is incorrect'

# Generated at 2022-06-25 10:43:33.701584
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of an object for the look up plugin 'ini'
    lookup_module_0 = LookupModule()

    # Create an instance of an object for the look up plugin 'ini'
    lookup_module_1 = LookupModule()

    # Create an instance of an object for the look up plugin 'ini'
    lookup_module_2 = LookupModule()

    # Create an instance of an object for the look up plugin 'ini'
    lookup_module_3 = LookupModule()

    # Create a list of the required parameters 'file' and 'section'
    list_0 = list()
    list_0.append(paramvals['file'])
    list_0.append(paramvals['section'])

    # Create a list of the required parameters 'file' and 'section'
    list_1 = list()

# Generated at 2022-06-25 10:43:40.441641
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module_0.cp.optionxform = 'nothing'
    lookup_module_0.cp.read_string('[section]')
    lookup_module_0.cp.set('section', 'key', 'value')
    param0 = 'key'
    param1 = 'section'
    param2 = ''
    param3 = False

    try:
        return_value = lookup_module_0.get_value(param0, param1, param2, param3)
    except Exception as e:
        print('An exception is raised.')
        print(type(e))
        print(e.args)
        print(e)


# Generated at 2022-06-25 10:43:44.423501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule(), LookupBase)
    lookup_module_0 = LookupModule()
    assert_true = True
    lookup_module_0.run(assert_true)


# Generated at 2022-06-25 10:43:55.284825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.run([])
    lm.run(['$USER'])
    lm.run(['$USER', '$USER'])
    lm.run([''])
    lm.run(['*'])
    lm.run(['abc'])
    lm.run([''])
    lm.run(['/'])
    lm.run(['/', '/'])
    lm.run(['"a"'])
    lm.run(['"a"', '"a"'])
    lm.run([['"a"']])
    lm.run(['"a b"'])
    lm.run(["'a'"])
    lm.run(["'a'", "'b'"])
    lm.run

# Generated at 2022-06-25 10:43:58.461524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    terms_0 = set_0
    variables_0 = set_0
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == []


# Generated at 2022-06-25 10:44:05.328730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        path = lookup_module_0.find_file_in_search_path(None, 'files', 'ansible.ini')
        assert path
        with open(path, "rb") as config:
            contents = config.read()
            contents = to_text(contents, errors='surrogate_or_strict', encoding='utf-8')
    except configparser.DuplicateOptionError as doe:
        raise AnsibleLookupError("Duplicate option in '{file}': {error}".format(file=paramvals['file'], error=to_native(doe)))


# Generated at 2022-06-25 10:44:14.872251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'key1=value1',
        'key2=value2',
        'key3=value3',
        'key4=value4'
    ]
    kwargs = {'file': 'test.ini', 'allow_none': False, 'case_sensitive': False, 'encoding': 'utf-8', 'section': 'section1', 'default': '', 're': False, 'type': 'ini'}
    lookup_module = LookupModule()
    ret = lookup_module.run(terms, **kwargs)
    assert len(ret) == 0
    assert isinstance(ret, list)


# Generated at 2022-06-25 10:44:16.879106
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.get_value('key', 'section', 'default', False)
    assert ret_0 == 'default'


# Generated at 2022-06-25 10:44:24.297951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("LookupModule_run")
    lookup_module = LookupModule()


# Generated at 2022-06-25 10:44:30.875891
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    assert str(type(lookup_module_0.get_value('urls', 'Kodi', None, False))) == "<class 'str'>"
    assert str(type(lookup_module_0.get_value('urls', 'Kodi', None, True))) == "<class 'list'>"
    assert str(type(lookup_module_0.get_value('.*', 'Kodi', None, True))) == "<class 'list'>"
    assert str(type(lookup_module_0.get_value('.*', 'Kodi', None, False))) == "<class 'NoneType'>"

# Generated at 2022-06-25 10:44:42.646988
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Get the lookup module
    try:
        lookup_module = LookupModule()
    except Exception as e:
        print(e.args)
        raise

    # Create the lookup parameters
    lookup_params = {
        'type': 'ini',
        'section': 'global',
        'file': '../../../../../examples/ansible.cfg',
        're': False,
        'case_sensitive': False,
    }

    # Create the test terms
    terms = [
        'inventory = /tmp/hosts',
        'roles_path = /foo/bar/baz',
        'deprecated = True'
    ]

    # Run the lookup
    try:
        lookup_module.run(terms, lookup_params)
    except Exception as e:
        print(e.args)
        raise



# Generated at 2022-06-25 10:44:48.917163
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module_1.cp.read('/tmp/inventory.ini')
    assert lookup_module_1.get_value('1', 'section1', 'False', False) == '1.1'


# Generated at 2022-06-25 10:44:59.502564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    # Test coverage -- basic
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({
        'type': 'ini',
        'file': 'test/test.ini',
        'section': 'global',
        'default': '',
        'case_sensitive': True,
        'allow_no_value': False,
        'encoding': 'utf-8',
        're': False
    })
    config = StringIO()
    config.write("[global]\n")
    config.write("key=value")
    config.seek(0, os.SEEK_SET)
    lookup_module_1.cp = configparser.ConfigParser(allow_no_value=False)
    lookup_module_1.cp.readfp(config)
    assert lookup_module

# Generated at 2022-06-25 10:44:59.997526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:45:10.130706
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.get_value('foo').__class__.__name__ == 'NoneType'
    assert lookup_module_0.get_value('foo_bar').__class__.__name__ == 'NoneType'
    assert lookup_module_0.get_value('foo_bar_zoo').__class__.__name__ == 'NoneType'
    assert lookup_module_0.get_value('foo_bar_zoo').__class__.__name__ == 'NoneType'
    assert lookup_module_0.get_value('foo_bar_zoo').__class__.__name__ == 'NoneType'
    assert lookup_module_0.get_value('foo_bar_zoo').__class__.__name__ == 'NoneType'
    assert lookup

# Generated at 2022-06-25 10:45:14.397983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = 'apache_port'
    try:
        lookup_module.run(term)
    except Exception as e:
        assert isinstance(e, AnsibleLookupError)
        assert e.message.startswith("KeyError ini lookup expects a section")


# Generated at 2022-06-25 10:45:24.569041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Reading ini file with users.ini
    terms = [
        'user',
        'password',
    ]

    ret = lookup_module.run(terms, variables=None, file='users.ini', section='integration')
    assert ['user1', 'user2'] == ret[0]
    assert ['pass1', 'pass2'] == ret[1]

    ret = lookup_module.run(terms, variables=None, file='users.ini', section='production')
    assert ['user3', 'user4'] == ret[0]
    assert ['pass3', 'pass4'] == ret[1]

    # Reading properties file with user.properties
    terms = [
        'user.name',
        'user.age',
    ]


# Generated at 2022-06-25 10:45:25.660487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['type=ini']) == ['']

# Generated at 2022-06-25 10:45:37.598315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list(), None)
    return var_0

# Generated at 2022-06-25 10:45:47.609446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = False
    list_0 = [('get', str_0, str_0, bool_0)]
    list_1 = [('get_value', str_0, str_0, str_0)]
    str_1 = 'default'
    list_2 = [('get_value', str_0, str_0, str_1)]
    str_2 = 'default'
    list_3 = [('get_value', str_0, str_0, str_2)]
    list_4 = [('get', str_0, str_0, bool_0)]
    list_5 = [('get_value', str_0, str_0, str_0)]
    str_3 = 'default'
    list_6

# Generated at 2022-06-25 10:45:51.885511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  terms = ['file']
  variables = {}
  kwargs = {}
  res = lookup_module.run(terms, variables, **kwargs)
  assert res == 'ansible.ini'


# Generated at 2022-06-25 10:45:59.726916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_1 = 'host'
    str_2 = 'localhost'
    str_3 = '='
    str_4 = 'file'
    str_5 = 'hosts.ini'
    str_6 = 'type'
    str_7 = 'ini'
    str_8 = 'section'
    str_9 = 'global'
    str_10 = 're'
    bool_0 = True
    str_11 = 'default'
    str_12 = ''
    str_13 = 'encoding'
    str_14 = 'utf-8'
    str_15 = 'case_sensitive'
    bool_1 = False
    dict1 = dict()
    dict1.update({str_3 : str_2})

# Generated at 2022-06-25 10:46:02.928761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0, dict_0, file=str_0, encoding=str_0, type=str_0, section=str_0, re=bool_0)


# Generated at 2022-06-25 10:46:12.194626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'default'
    var_0 = lookup_module_0.run(terms_0)
    var_1 = lookup_module_0.run(terms_0, **{'default':str_0, 'file':str_0, 're':bool_0, 'section':str_0})
    var_2 = lookup_module_0.run(terms_0, **{'encoding':str_0, 'default':str_0, 'allow_no_value':bool_0, 'file':str_0, 'case_sensitive':bool_0, 're':bool_0, 'section':str_0})

# Generated at 2022-06-25 10:46:13.813332
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    assert callable(LookupModule.get_value)



# Generated at 2022-06-25 10:46:19.285339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser()
    lookup_module_0.cp.read('INI')
    list_0 = list()
    str_0 = 'default'
    dict_0 = dict()
    dict_0['default'] = str_0
    dict_0['case_sensitive'] = False
    dict_0['file'] = 'INI'
    dict_0['type'] = 'ini'
    dict_0['section'] = 'section1'
    dict_0['re'] = False
    dict_0['encoding'] = 'utf-8'
    dict_0['allow_no_value'] = False
    dict_0['allow_none'] = False
    dict_1 = dict()
    dict_1['default'] = str_

# Generated at 2022-06-25 10:46:21.929695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ''
    variables = ''
    lookup_module_run = lookup_module.run(terms, variables)


# Generated at 2022-06-25 10:46:27.682988
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = True
    var_0 = lookup_get_value(str_0, str_0, str_0, bool_0)
    print(var_0)
    var_0 = lookup_get_value(str_0, str_0, str_0, bool_0)
    print(var_0)


# Generated at 2022-06-25 10:46:49.247721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = ['web_server_user', 'db_server_user']
    dict_1 = {}
    dict_2 = None
    dict_1['type'] = 'ini'
    dict_1['file'] = 'test.ini'
    dict_1['section'] = 'test'
    dict_1['encoding'] = 'utf-8'
    # Testing on empty string for key 'default'
    dict_1['default'] = ''
    dict_1['case_sensitive'] = False
    # Testing on True for key 'allow_no_value'
    dict_1['allow_no_value'] = True
    # Testing on False for key 're'
    dict_1['re'] = False
    # Testing with the parameters above

# Generated at 2022-06-25 10:46:56.583103
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  lookup_module_0 = LookupModule()
  str_0 = 'default'
  bool_0 = False
  test_case_0()

  str_1 = "{{ lookup('template', './templates/' + item + '_systemd.j2') | to_nice_json }}"
  list_0 = ['listen_port', 'listen_addresses', 'postgresql_bin_dir', 'postgresql_data_dir', 'postgresql_log_dir', 'postgresql_piddir', 'postgresql_conf_dir', 'postgres_initdb_options']
  list_1 = [dict_0]
  str_2 = 'postgresql.service.j2'
  str_3 = 'template'
  str_4 = 'user'

# Generated at 2022-06-25 10:47:06.317235
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = False
    var_1 = lookup_get_value(str_0, str_0, str_0, bool_0)
    assert var_1 == 'default'
    str_1 = 'key_0'
    str_2 = '[section]'
    str_3 = 'value_0'
    var_2 = Mock(configparser.ConfigParser)
    var_2.items.return_value = [(str_1, str_3)]
    bool_1 = True
    var_2.getboolean.return_value = bool_1
    bool_2 = True
    lookup_module_0.cp = var_2

# Generated at 2022-06-25 10:47:08.900902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'test'
    bool_1 = False
    var_1 = lookup_run(str_1, str_1, bool_1)
    return var_1

# Generated at 2022-06-25 10:47:13.010762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = False
    term = _parse_params(str_0, str_0)
    var_0 = lookup_module_0.run(term, bool_0)



# Generated at 2022-06-25 10:47:22.291260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_0 = []
    str_0 = 'default'
    bool_0 = False
    var_1 = lookup_module_1.run(list_0, str_0, bool_0)
    bool_1 = 'file' in var_1
    bool_2 = 'type' in var_1
    bool_3 = 'section' in var_1
    bool_4 = 'default' in var_1
    bool_5 = 'encoding' in var_1
    bool_6 = 'case_sensitive' in var_1
    bool_7 = 'allow_no_value' in var_1



# Generated at 2022-06-25 10:47:28.829381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct={'encoding': 'utf-8', 'file': 'ansible.ini', 'section': 'global', 'default': '', 're': False, 'case_sensitive': False})
    lookup_module_0.get_options()
    configparser_0 = configparser.ConfigParser()
    lookup_module_0.cp = configparser_0
    lookup_module_0.find_file_in_search_path(None, 'files', 'ansible.ini')
    lookup_module_0.run(['user', 'pass'])

# Generated at 2022-06-25 10:47:31.430185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    bool_0 = False
    var_0 = lookup_module_0.run([list_0], bool_0)
    print(var_0)


# Generated at 2022-06-25 10:47:36.384389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'x=y'
    str_1 = 'file'
    str_2 = 'section2'
    str_3 = 'a'
    bool_0 = False
    var_0 = lookup_module_0.run(str_0, str_1, str_2, str_3, bool_0)
    if not (isinstance(var_0, list)):
        raise Exception('The value returned by LookupModule.run should have been a list')
    return var_0

# Generated at 2022-06-25 10:47:44.694423
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_0, str_0, bool_0)
    print(var_0)
    str_1 = 'default'
    str_2 = 'default'
    str_3 = ''
    bool_1 = False
    var_1 = lookup_get_value(str_1, str_2, str_3, bool_1)
    print(var_1)


# Generated at 2022-06-25 10:48:20.509554
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
  try:
    lookup_module = LookupModule()
    lookup_module.get_value('key', 'section', 'dflt', False)
  except:
    pass

# Generated at 2022-06-25 10:48:30.286043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    str_1 = 'ini'
    str_2 = 're'
    str_3 = 'file'
    str_4 = 'main.ini'
    str_5 = 'encoding'
    str_6 = 'default'
    str_7 = 'section'
    bool_0 = True
    str_8 = 'section1'
    str_9 = 'section 2'
    str_10 = 'section3'
    dict_0 = {}
    dict_0['type'] = str_1
    dict_0['re'] = bool_0
    dict_0['file'] = str_4
    dict_0['encoding'] = str_6
    dict_0['default'] = str_0
    dict_0['section']

# Generated at 2022-06-25 10:48:36.415380
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_0 = LookupModule()
    str_0 = 'user'
    str_1 = 'production'
    str_2 = 'default'
    bool_0 = False
    var_0 = lookup_get_value(lookup_module_0, str_0, str_1, str_2, bool_0)


# Generated at 2022-06-25 10:48:39.217522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    # The format of the string parameter may be incorrect.
    # The format of the string parameter may be incorrect.
    lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 10:48:44.219186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    tuple_0 = ()
    bool_0 = False
    ret_0 = lookup_module_0.run(tuple_0, bool_0)
    assert ret_0 is None


# Generated at 2022-06-25 10:48:54.391369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = False
    str_1 = 'default'
    bool_1 = False
    str_2 = 'default'
    bool_2 = False
    str_3 = 'default'
    bool_3 = False
    str_4 = 'default'
    bool_4 = False
    str_5 = 'default'
    bool_5 = False
    path = '/ansible/ansible/module_utils/encoding.py'
    str_6 = 'files'
    str_7 = 'ansible.ini'
    str_8 = 'files'
    str_9 = 'ansible.ini'
    str_10 = 'files'
    str_11 = 'ansible.ini'
    str_12 = 'files'

# Generated at 2022-06-25 10:48:57.093495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    path = "C:/ansible/test/test.ini"
    terms = ["key1"]
    var = lookup.run(terms, path)


# Generated at 2022-06-25 10:49:03.482567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test cases
    # [('username = root\npassword = root', 'password', 'global', 'root', False), ('username = root\npassword = root', 'password', 'global', 'root', False), ('username = root\npassword = root', 'password', 'global', 'root', False), ('username = root\npassword = root', 'password', 'global', 'root', False), ('username = root\npassword = root', 'password', 'global', 'root', False), ('username = root\npassword = root', 'password', 'global', 'root', False), ('username = root\npassword = root', 'password', 'global', 'root', False), ('username = root\npassword = root', 'password', 'global', 'root', False), ('username = root\npassword = root', 'password',

# Generated at 2022-06-25 10:49:06.236708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_case_0()

# Generated at 2022-06-25 10:49:18.688272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    str_1 = 'yannig'
    str_2 = 're'
    bool_0 = False
    list_0 = []
    lookup_module_0._ini_configparser = configparser.ConfigParser(allow_no_value=bool_0)
    str_3 = 'find_file_in_search_path'
    str_4 = 'ansible.ini'
    var_0 = lookup_module_0.find_file_in_search_path(str_0, str_3, str_4)
    str_5 = 'section'
    str_6 = 'global'
    str_7 = 'file'
    str_8 = 'ansible.ini'
    dict_0 = dict()

# Generated at 2022-06-25 10:50:34.675255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = True
    str_1 = 'file'
    str_2 = 're'
    str_3 = 'type'
    dict_0 = {}
    dict_0.update({str_1:str_0, str_2:bool_0, str_3:str_0})
    lookup_module_0.run(str_0, dict_0)


# Generated at 2022-06-25 10:50:41.970479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    list_0 = []
    str_0 = 'INI'
    lookup_module_0.get_value(str_0, str_0, str_0, False)
    lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 10:50:44.212803
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_0, str_0, bool_0)


# Generated at 2022-06-25 10:50:56.732612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'file'
    str_1 = 'ansible.ini'
    list_0 = [str_1]
    str_2 = 'section'
    str_3 = 'global'
    list_1 = [str_3]
    str_4 = 're'
    bool_0 = False
    list_2 = [bool_0]
    str_5 = 'encoding'
    str_6 = 'utf-8'
    list_3 = [str_6]
    str_7 = 'default'
    str_8 = ''
    list_4 = [str_8]
    str_9 = 'type'
    str_10 = 'ini'
    list_5 = [str_10]
    str_11 = 'case_sensitive'


# Generated at 2022-06-25 10:51:00.803993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    terms = ['key1']
    variables = [None]
    direct = [None]
    assert lookupModule.run(terms, variables, direct) == ['value1']
    assert lookupModule.run(terms, variables, direct) == ['value1']


# Generated at 2022-06-25 10:51:07.919701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0 is not None
    terms_0 =['section_1']
    assert terms_0 is not None
    variables_0 =None
    assert variables_0 is not None
    #res_0 = LookupModule.run(lookup_module_0, terms_0, variables_0)
    #assert res_0 is None

# Generated at 2022-06-25 10:51:14.394667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['key=value']
    kwargs_0 = {'allow_none': True}
    ret_0 = lookup_module_0.run(terms_0, **kwargs_0)


# Generated at 2022-06-25 10:51:18.929242
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'default'
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_0, str_0, bool_0)


# Generated at 2022-06-25 10:51:21.257844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

    # Call method run, passing in the correct parameters
    # and return the result
    lookup_instance.run(terms=[])

    # Test is complete
    assert True, 'unit test pass'


# Generated at 2022-06-25 10:51:28.795144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = 'default'
    bool_0 = False
    dict_0 = dict()
    dict_0['default'] = 'default'
    dict_0['re'] = bool_0
    dict_0['encoding'] = 'UTF-8'
    dict_0['case_sensitive'] = bool_0
    dict_0['allow_no_value'] = False
    dict_0['type'] = 'ini'
    dict_0['file'] = 'ansible.ini'
    dict_0['section'] = 'global'
    list_0 = list()
    str_1 = 'user'
    list_0.append(str_1)
    dict_0['key'] = list_0
    list_1 = list()