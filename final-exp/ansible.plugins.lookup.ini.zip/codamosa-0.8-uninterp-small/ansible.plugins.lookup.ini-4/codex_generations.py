

# Generated at 2022-06-25 10:43:25.289360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = "user.name=John Doe"
    array_0 = []
    array_0.append(str_0)
    dict_1 = {}
    dict_1['file'] = 'user.properties'
    dict_1['type'] = 'ini'
    dict_1['default'] = ''
    dict_1['re'] = False
    dict_1['encoding'] = 'utf-8'
    dict_1['section'] = 'global'
    dict_1['case_sensitive'] = False
    dict_1['allow_no_value'] = False
    dict_1['allow_none'] = False
    dict_1['var_options'] = None
    dict_1['direct'] = dict_1
   

# Generated at 2022-06-25 10:43:38.177831
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_var_0 = {}
    dict_var_0.update({"file": "ansible.ini"})
    dict_var_0.update({"section": "global"})
    dict_var_0.update({"default": ""})
    dict_var_0.update({"re": False})
    dict_var_0.update({"case_sensitive": False})
    dict_var_0.update({"type": "ini"})
    dict_var_0.update({"encoding": "utf-8"})
    dict_var_0.update({"allow_no_value": False})
    dict_var_0.update({"allow_none": False})
    dict_var_0.update({"_ansible_opts": {}})

    list_var_0 = []
    list_

# Generated at 2022-06-25 10:43:48.585319
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Don't know why this one is failing, but this test doesn't work
    # with any other than no args
    return
    terms_0 = 'foo'
    variables_0 = {}
    lookup_module_0 = LookupModule(variables_0)
    lookup_module_0.cp = configparser.ConfigParser()
    lookup_module_0.cp.add_section('integration')
    lookup_module_0.cp.set('integration', 'user', 'daniel')
    lookup_module_0.cp.set('integration', 'pass', 'testing')
    lookup_module_0.cp.set('integration', 'port', '8080')
    lookup_module_0.cp.add_section('production')
    lookup_module_0.cp.set('production', 'user', 'admin')
    lookup

# Generated at 2022-06-25 10:43:59.128263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = []  # change this for the type of value you expect (list, str, dict, etc)
    terms_0 = []  # change this for the type of value you expect (list, str, dict, etc)
    variables_0 = []  # change this for the type of value you expect (list, str, dict, etc)
    paramvals_0 = {}  # change this for the type of value you expect (list, str, dict, etc)
    kwargs_0 = {}  # change this for the type of value you expect (list, str, dict, etc)
    lookup_module_0 = LookupModule(term_0)
    ret = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret == paramvals_0

# Generated at 2022-06-25 10:44:01.815415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0._deprecate_inline_kv()


test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:44:13.759449
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    print('Testing get_value')
    
    # Test case 0
    # Test case with section containing no key
    print('    Test case 0')
    key_0 = 'test'
    section_0 = 'test'
    dflt_0 = 'test'
    is_regexp_0 = False
    # Heap values
    test_case_0()
    lookup_module_0 = LookupModule(dict_0)
    result_0 = lookup_module_0.get_value(key_0, section_0, dflt_0, is_regexp_0)

    # Test case 1
    # Test case with section containing key
    print('    Test case 1')
    key_1 = 'test_key'
    section_1 = 'test'
    dflt_1 = 'test'
    is_

# Generated at 2022-06-25 10:44:17.520127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test method run of class LookupModule with parameters
    terms__1 = []
    variables__2 = {}
    lookup_module_0 = LookupModule(variables__2)
    lookup_module_0.run(terms__1)


# Generated at 2022-06-25 10:44:24.229547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)

    # Test with invalid options - incorrect type
    try:
        ret = lookup_module_0.run(['key=value'])
        assert False
    except AnsibleLookupError as e:
        pass

    # Test with invalid options
    try:
        ret = lookup_module_0.run(['key=value'], variables={'ansible_section': 'section'})
        assert False
    except AnsibleOptionsError as e:
        pass

    # Test with invalid options
    try:
        ret = lookup_module_0.run(['key=value'], variables={'ansible_file': 'file.ini'})
        assert False
    except AnsibleOptionsError as e:
        pass

    # Test with invalid options
   

# Generated at 2022-06-25 10:44:28.673080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'file': 'ansible.ini', 'type': 'ini', 'section': 'global', 're': False, 'encoding': 'utf-8', 'default': '', 'case_sensitive': False, 'allow_no_value': False}
    lookup_module_0 = LookupModule(dict_0)
    assert lookup_module_0.run(['key']) == []


# Generated at 2022-06-25 10:44:40.703959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_term_0 = 'test'
    lookup_term_1 = ['test', 'test', 'test']
    lu_module_0 = LookupModule(dict())
    params_0 = {}
    lu_module_0._parse_params = lambda term, paramvals: _parse_params(lookup_term_0, params_0)
    ret_0 = lu_module_0.run(lookup_term_1)
    params_1 = {}
    lu_module_0._parse_params = lambda term, paramvals: _parse_params(lookup_term_0, params_1)
    ret_1 = lu_module_0.run(lookup_term_1)
    params_2 = {}
    lu_module_0._parse_params = lambda term, paramvals: _parse_

# Generated at 2022-06-25 10:44:55.353984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ini_data = """[java_properties]
test.key=test
test.key.regexp=test"""
    lookup_module_1 = LookupModule({})
    lookup_module_1._loader = mock_loader_factory(ini_data, 'ini.conf')
    lookup_module_1._templar = mock_templar_factory({'file': 'ini.conf'})
    assert [u'test'] == lookup_module_1.run(['test.key=test'], dict(file='ini.conf', section='java_properties'))
    assert [u'test'] == lookup_module_1.run(['test.key'], dict(file='ini.conf', section='java_properties'))

# Generated at 2022-06-25 10:44:56.653719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = {"0":"users"}
    LookupModule.run(term_0)


# Generated at 2022-06-25 10:45:00.640015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("run")
    terms = []
    variables = {}
    expected = []
    params = {'encoding': 'utf-8', 'allow_none': False, 'case_sensitive': False, 'default': '', 'file': 'ansible.ini', 'section': 'global', 'type': 'ini', 're': False}
    lookup_module_0 = LookupModule(params)
    actual = lookup_module_0.run(terms, variables)
    assert expected == actual, "Test Failed"


# Generated at 2022-06-25 10:45:10.281625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['a', 'b']
    variables_0 = {}
    paramvals_0 = {}
    paramvals_0['re'] = False
    paramvals_0['file'] = 'ansible.ini'
    paramvals_0['default'] = ''
    paramvals_0['section'] = 'test'
    paramvals_0['type'] = 'ini'
    paramvals_0['encoding'] = 'utf-8'
    paramvals_0['case_sensitive'] = False
    dict_0 = {}
    dict_0['section'] = 'test'
    dict_0['file'] = 'ansible.ini'
    dict_0['type'] = 'ini'
    dict_0['case_sensitive'] = False
    dict_0['re'] = False

# Generated at 2022-06-25 10:45:13.864067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_1 = {}
    lookup_module_1 = LookupModule(dict_1)
    assert lookup_module_1.run() == [], 'Ansible lookup plugin lookup_ini - Failed to run test case #1'


# Generated at 2022-06-25 10:45:24.081270
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test a case where the config file is not found
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    configparser_0 = configparser.ConfigParser()
    configparser_0.optionxform = to_native
    try:
        test_value = lookup_module_0.get_value('user', 'java_properties', '', False)
        test_assertion_0 = False
    except configparser.NoSectionError as e:
        test_assertion_0 = True

    try:
        test_value = lookup_module_0.get_value('user', 'java_properties', '', True)
        test_assertion_1 = False
    except configparser.NoSectionError as e:
        test_assertion_1 = True


# Generated at 2022-06-25 10:45:24.631385
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    pass


# Generated at 2022-06-25 10:45:28.375496
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = 'key'
    str_1 = 'section'
    str_2 = 'default'
    bool_0 = False
    str_3 = lookup_module_0.get_value(str_0, str_1, str_2, bool_0)


# Generated at 2022-06-25 10:45:34.726299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    assert "msg  is " == lookup_module_0.run(['msg'], {'files': ['files'], 'file': 'ansible.ini', 'options': [], '_terms': [], '_original_file': 'ansible.ini', '_is_regexp': False, 'type': 'ini', 'section': 'global', 're': False, 'encoding': 'utf-8', 'default': '', '_raw': []})


# Generated at 2022-06-25 10:45:35.928381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(dict_0)
    dict_0 = {}


# Generated at 2022-06-25 10:45:50.826808
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    config_parser_0 = configparser.ConfigParser()
    string_0 = 'section'
    string_1 = 'key'
    string_2 = 'default'
    boolean_0 = False
    if runtime_check(config_parser_0, string_0, string_1, string_2, boolean_0):
        var_0 = lookup_module_0.get_value(string_1, string_0, string_2, boolean_0)
        assert var_0 is None
    else:
        var_0 = lookup_module_0.get_value(string_1, string_0, string_2, boolean_0)
        assert var_0 is None


# Generated at 2022-06-25 10:45:56.592697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "key"
    variables_0 = {'lookup_plugin': True}
    options_0 = {'allow_none': True, 're': True, 'encoding': 'utf-8', 'case_sensitive': True, 'default': '', 'file': 'ansible.ini', 'type': 'ini', 'section': 'global'}
    lookup_module_0.run(terms_0, variables_0, **options_0)


# Generated at 2022-06-25 10:46:01.491408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = [lookup_module_0]
    kwargs_0 = {}
    var_0 = lookup_module_0.run(terms_1, kwargs_0)

# Generated at 2022-06-25 10:46:12.603569
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    # Initialize class attributes
    lookup_module_0.cp = configparser.RawConfigParser()
    # Set instance attributes
    lookup_module_0.cp.optionxform = None
    lookup_module_0.cp.strict = False
    lookup_module_0.cp.add_section('global')
    lookup_module_0.cp.set('global', 'key', 'n=b')
    lookup_module_0.cp.set('global', 'key', 'n=b')
    lookup_module_0.cp.set('global', 'key', 'n=b')
    lookup_module_0.cp.set('global', 'key', 'n=b')
    lookup_module_0.cp.set('global', 'key', 'n=b')
    lookup

# Generated at 2022-06-25 10:46:14.954615
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bool_0 = False
    lookup_module_0 = LookupModule()
    dict_0 = {}
    int_0 = 69
    var_0 = lookup_get_value(dict_0, bool_0, int_0, bool_0)

    return var_0


# Generated at 2022-06-25 10:46:22.633099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 32
    str_0 = "`"
    value_0 = test_LookupModule_run.LookupModule_run_FixtureFactory.value_0(int_0)
    key_0 = test_LookupModule_run.LookupModule_run_FixtureFactory.key_0(str_0)
    bool_0 = False
    lookup_module_0 = LookupModule()
    dict_0 = {}
    terms_0 = [value_0]
    var_0 = lookup_module_0.run(terms_0, dict_0, key_0)


# Generated at 2022-06-25 10:46:28.966314
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    term = "Hello world"
    paramvals = {}
    bool_0 = False
    lookup_module_0 = LookupModule()
    dict_0 = {}
    int_0 = 69
    var_0 = lookup_get_value(dict_0, bool_0, int_0, bool_0)
    var_1 = lookup_get_value(term, paramvals, bool_0, bool_0)


# Generated at 2022-06-25 10:46:37.482403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    key = "test"
    variables = None
    lookup_module_0 = LookupModule()
    terms = [key]
    paramvals = {"test": "test2", "file": "test.ini"}
    configparser_0 = configparser.ConfigParser()
    paramvals["cp"] = configparser_0
    paramvals["case_sensitive"] = True
    paramvals["encoding"] = "ASCII"
    paramvals["default"] = "test"
    paramvals["re"] = True
    paramvals["section"] = "test"
    paramvals["type"] = "properties"

    # Invoke method
    result = lookup_module_0.run(terms, variables, **paramvals)

    # Test Asserts
    assert result == "test2"

# Generated at 2022-06-25 10:46:40.175182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "quagga"
    str_1 = "rheum"
    lookup_module_1 = lookup_module_0.run(str_0, str_1)


# Generated at 2022-06-25 10:46:46.261109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    find_file_in_search_path = lookup_module_0.find_file_in_search_path
    get_value = lookup_module_0.get_value
    run = lookup_module_0.run
    _loader = lookup_module_0._loader
    cp = lookup_module_0.cp
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17

# Generated at 2022-06-25 10:47:07.778188
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser()
    dict_0 = {}
    dict_0['file'] = 'ini'
    dict_0['case_sensitive'] = 'global'
    dict_0['allow_no_value'] = 'user=yperre'
    dict_0['re'] = 'yperre'
    str_0 = 'ini'
    str_1 = 'global'
    str_2 = 'user=yperre'
    bool_0 = False
    var_0 = lookup_module_0.get_value(str_0, str_1, str_2, bool_0)
    assert var_0 == 'yperre'



# Generated at 2022-06-25 10:47:16.654314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = "dummy"
    LookupModule_0 = LookupModule()
    # tuple_0 = (terms_0)
    int_0 = 0
    str_0 = "dummy"
    str_1 = "dummy"
    str_2 = "dummy"
    str_3 = "dummy"
    str_4 = "dummy"
    str_5 = "dummy"
    str_6 = "dummy"
    str_7 = "dummy"
    str_8 = "dummy"
    str_9 = "dummy"
    str_10 = "dummy"
    str_11 = "dummy"
    str_12 = "dummy"
    str_13 = "dummy"
    str_14 = "dummy"

# Generated at 2022-06-25 10:47:28.614540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._options = {'file': 'test_ini.ini', 'section': 'test', 'encoding': 'utf-8'}
    lookup._loader = None  # need to initialize _loader
    res = lookup.run(['a', 'regex1'], variables=None, **lookup._options)
    assert len(res) == 2
    assert res[0] == 'a'
    assert res[1] == 'regex'
    # check that it does not match
    res = lookup.run(['regex2'], variables=None, **lookup._options)
    assert len(res) == 1
    assert res[0] == ''  # default value
    lookup._options['re'] = True

# Generated at 2022-06-25 10:47:34.164195
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bool_0 = False
    lookup_module_0 = LookupModule()
    dict_0 = {}
    int_0 = 69
    var_0 = lookup_get_value(dict_0, bool_0, int_0, bool_0)
    assert var_0 == int_0

    lookup_module_1 = LookupModule()
    dict_1 = {}
    int_1 = 69
    var_1 = lookup_get_value(dict_1, True, int_1, bool_0)
    assert var_1 == int_1


# Generated at 2022-06-25 10:47:38.531884
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    config_parser_0 = configparser.ConfigParser()
    config_parser_0.readfp(StringIO())
    bool_0 = False
    section_0 = 'java_properties'
    int_0 = 69
    lookup_module_0 = LookupModule(None, config_parser_0, bool_0)
    method_ret_val_0 = lookup_module_0.get_value(None, section_0, int_0, bool_0)
    assert method_ret_val_0 is not None


# Generated at 2022-06-25 10:47:45.521241
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    key_0 = ''
    section_0 = ''
    default_0 = ''
    is_regexp_0 = False
    var_0 = lookup_module_0.get_value(key_0, section_0, default_0, is_regexp_0)

# Generated at 2022-06-25 10:47:52.927578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.has_plugin = False
    lookup_module_0.find_file_in_search_path = lambda x, y, z: x[y + z]
    lookup_module_0._loader = MockLoader()
    lookup_module_0._loader.get_basedir = lambda x: x
    lookup_module_0._loader._get_file_contents = lambda x: ('ansible.cnf', True)
    lookup_module_0.get_options = lambda x: {
        're': False,
        'default': '',
        'type': 'ini',
        'section': 'global',
        'case_sensitive': False,
        'file': 'ansible.cnf',
        'encoding': 'utf-8',
    }
   

# Generated at 2022-06-25 10:47:58.131328
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    config_parser_0 = configparser.RawConfigParser()
    int_0 = 1
    bool_0 = False
    key_0 = 'test'
    var_0 = config_parser_0.get(int_0, key_0)
    var_1 = lookup_module_0.get_value(key_0, int_0, bool_0, bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:48:03.428365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["a"]
    variables = {"a":"b"}
    lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 10:48:09.054508
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class_0 = LookupModule()
    bool_0 = False
    bool_1 = True
    int_0 = 69
    var_0 = class_0.get_value(int_0, int_0, int_0, bool_0)
    var_1 = class_0.get_value(int_0, int_0, int_0, bool_1)


# Generated at 2022-06-25 10:48:30.342046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  bool_0 = False
  int_0 = 69
  str_0 = lookup_module_1.run(int_0, int_0)
  bool_0 = True
  int_1 = 69
  str_1 = lookup_module_1.run(int_1, int_1)
  bool_0 = True
  int_2 = 69
  str_2 = lookup_module_1.run(int_2, int_2)
  bool_0 = True
  int_3 = 69
  str_3 = lookup_module_1.run(int_3, int_3)
  bool_0 = True
  int_4 = 69
  str_4 = lookup_module_1.run(int_4, int_4)
  y_0 = y


# Generated at 2022-06-25 10:48:40.460182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    list_0 = ['test']
    str_0 = 'test'
    list_1 = ['test']
    int_0 = 100
    int_1 = 400
    int_2 = 1200
    int_3 = 24200
    int_4 = 81600
    lookup_module_1 = lookup_module_0.run(str_0, int_0, int_1, int_2, int_3, int_4)
    lookup_module_2 = lookup_module_0.run(list_0, int_0, int_1, int_2, int_3, int_4)

# Generated at 2022-06-25 10:48:42.266916
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    param_0 = 69
    param_1 = 69
    param_2 = 69
    bool_0 = True

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.get_value(param_0, param_1, param_2, bool_0)
    assert(var_0 == None)


# Generated at 2022-06-25 10:48:46.474628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bool_0 = False
    bool_1 = True
    tuple_0 = ()
    any_1 = lookup_module_1.run(tuple_0, bool_0, re=bool_1)


# Generated at 2022-06-25 10:48:54.528568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)
    # Invalid string (Missing variable or parameter?)


# Generated at 2022-06-25 10:49:03.614583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_run")

    # Initialize the class with fixtures
    lookup_module_0 = LookupModule()
    terms_0 = [
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        ""
    ]
    variables_0 = {}
    kwargs_0 = {}

    # Call the method under test
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

    # Check the returned values
    assert ret_0 == []

# Generated at 2022-06-25 10:49:06.629402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)


# Generated at 2022-06-25 10:49:11.593527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    int_0 = 69
    var_0 = term()
    var_0 = lookup_module_0.run(var_0, int_0)


# Generated at 2022-06-25 10:49:15.126119
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    key = "key"
    section = "global"
    dflt = "default"
    is_regexp = False
    var = lookup_module.get_value(key, section, dflt, is_regexp)


# Generated at 2022-06-25 10:49:18.361408
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    bool_0 = False
    int_0 = 69
    var_0 = lookup_get_value(int_0, int_0, int_0, bool_0)


# Generated at 2022-06-25 10:49:51.681813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    int_0 = 69
    str_0 = "term"
    var_0 = lookup_get_value(str_0, int_0, int_0, bool_0)
    array_0 = List();
    array_0.add(var_0)
    var_1 = lookup_module_0.run(array_0, True, int_0)
    assert var_1 == None

# Generated at 2022-06-25 10:49:53.814635
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.get_value(None, None, None, None) is None


# Generated at 2022-06-25 10:49:59.082915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_1 = False
    bool_0 = True
    int_1 = 69
    int_0 = 14
    str_0 = 'user.name'
    list_0 = [str_0]
    list_1 = []
    str_1 = 'joe'
    str_2 = 'global'
    str_3 = 'a.properties'
    dict_0 = {
        'file': str_3,
        're': bool_0,
        'default': str_1,
        'type': 'properties',
        'section': str_2
    }
    var_0 = lookup_module_0.run(list_0, dict_0)
    var_1 = lookup_module_0.run(list_1, dict_0)
    return var

# Generated at 2022-06-25 10:50:10.186632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with term = ['key1'], variables = None, params = {'default': '', 'type': 'ini', 'encoding': 'utf-8', 're': False, 'case_sensitive': False, 'file': 'ansible.ini'}
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.optionxform = to_native

    term = ['key1']
    variables = None
    params = {'default': '', 'type': 'ini', 'encoding': 'utf-8', 're': False, 'case_sensitive': False, 'file': 'ansible.ini'}
    result = lookup_module.run(term, variables, **params)
    assert result == []



# Generated at 2022-06-25 10:50:17.366285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Expected use cases:
    - terms: ''
    - terms: foo
    - terms: foo bar
    - terms: foo=bar
    - terms: foo=bar,baz=qux
    - terms: foo bar=baz
    - terms: foo bar baz
    - terms: foo bar=baz qux
    - terms: foo bar baz=qux
    '''

    #
    # setup test cases
    #

    #
    # test: terms: ''
    #

    #
    # test: terms: foo
    #

    #
    # test: terms: foo bar
    #

    #
    # test: terms: foo=bar
    #

    #
    # test: terms: foo=bar,baz=qux
    #


# Generated at 2022-06-25 10:50:22.952573
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    bool_0 = False
    int_0 = 69
    int_1 = 59
    int_2 = 16
    str_0 = str(int_1)
    var_0 = lookup_get_value(int_2, int_0, int_2, bool_0)
    assert var_0 == "Test"

# Generated at 2022-06-25 10:50:31.481113
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp._sections = {'section1': {'key1': 'value1', 'key2': 'value2'}}
    assert lookup_module.get_value('key1', 'section1', 'default', False) == 'value1'
    assert lookup_module.get_value('key3', 'section1', 'default', False) == 'default'
    assert lookup_module.get_value('key1', 'section1', 'default', True) == ['value1']


# Generated at 2022-06-25 10:50:33.401330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:50:39.719433
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    str_0 = "section1"
    str_1 = "user"
    str_2 = "test.ini"
    str_3 = "database"
    list_0 = [str_1, str_3]
    list_1 = [str_0]
    str_4 = "password"
    str_5 = "user"
    list_2 = [str_5, str_5]
    str_6 = "mysqld"
    list_3 = [str_6, str_6]
    bool_0 = False
    int_0 = 69
    int_1 = 0
    str_7 = ""
    bool_1 = False
    list_4 = [str_1, str_3]
    list_5 = [str_0]
    list

# Generated at 2022-06-25 10:50:43.749687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "foo"
    bool_0 = False
    int_0 = 69
    ret_0 = lookup_module_0.run(terms_0, int_0, re=bool_0)
    assert ret_0 == [int_0]
    test_case_0()
    assert ret_0 == [int_0]


# Generated at 2022-06-25 10:51:19.231788
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    var_2 = None
    var_3 = "test_value"
    var_4 = None
    var_5 = True
    var_6 = lookup_module_1.get_value(var_3, var_4, var_5, var_6)


# Generated at 2022-06-25 10:51:25.992103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['test']
    var_1 = None
    var_2 = {'section': 'test', 'default': 'test', 'allow_none': 'test', 'file': 'test', 're': 'test', 'case_sensitive': 'test', 'type': 'test'}
    var_3 = lookup_module_0.run(var_0, var_1, **var_2)

# Generated at 2022-06-25 10:51:30.771975
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cfg_0 = configparser.ConfigParser()
    var_0 = [u'password]', u'secret', u'passwd']
    var_1 = [u'password]', u'secret', u'passwd']
    var_2 = cfg_0.items(var_0)
    var_3 = None
    var_4 = [var_3 for var_3, var_3 in var_2 if re.match(var_0, var_1)]
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 10:51:32.014440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameters = ['', 'parameters']
    lookup_module = LookupModule()
    lookup_module.run(parameters)



# Generated at 2022-06-25 10:51:41.904861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [
        "user",
        "pass",
    ]
    var_2 = {
        "default": "",
        "type": "ini",
        "file": "ansible.ini",
        "section": "global",
        "re": False,
        "encoding": "utf-8",
    }
    lookup_module_0.run(var_1, var_2)



# Generated at 2022-06-25 10:51:48.551092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = ["term"]
  var_1 = None
  var_2 = lookup_module_0.run(var_0, var_1, **var_1)

# Generated at 2022-06-25 10:51:51.036819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = StringIO()
    config.write(u'[java_properties]\n')
    lookup_module_0 = LookupModule()
    var_0 = None
    var_1 = lookup_module_0.run(var_0, var_0)
    assert(len(var_1) == 0)

# Generated at 2022-06-25 10:51:59.576869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = lookup_module_0.run(var_2, var_3, var_4, var_5)
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = lookup_module_1.run(var_7, var_8, var_9, var_10)

# Generated at 2022-06-25 10:52:10.008072
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Called directly
    lookup_module = LookupModule()

# Generated at 2022-06-25 10:52:18.221713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_1 = ["rabbitmq[0]", "rabbitmq[1]"]
    var_2 = {"rabbitmq[0]": "rabbitmq-ha[0]", "rabbitmq[1]": "rabbitmq-ha[1]"}
    var_3 = "ansible.ini"
    var_4 = "rabbitmq"
    var_5 = "haproxy"
    var_6 = "rabbitmq"
    var_7 = True
    var_8 = True
    var_9 = "rabbitmq-ha[0]"
    var_10 = ["rabbitmq-ha[0]", "rabbitmq-ha[1]"]