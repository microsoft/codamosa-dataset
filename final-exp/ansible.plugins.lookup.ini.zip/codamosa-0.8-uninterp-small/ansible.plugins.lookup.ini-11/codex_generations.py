

# Generated at 2022-06-25 10:43:25.317353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        # no parameters
        'user',
        # one parameter with space
        'user john',
        # one parameter with equal sign and no space
        'user=john',
        # one parameter with equal sign with space
        'user = john',
        # multiple parameters with equal sign and no spaces
        'user=john group=admin',
        # multiple parameters with equal sign with spaces
        'user = john group = admin',
    ]

# Generated at 2022-06-25 10:43:30.440990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()
    lookup_module_16 = LookupModule()

# Generated at 2022-06-25 10:43:39.436167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_0
    cli_args_0 = [
        "/path/to/ansible/bin/ansible",
        "--version"
    ]
    cli_args_1 = [
        "--version"
    ]
    path_0 = "/path/to/ansible/bin/ansible-lookup"
    lookup_module_0 = LookupModule()
    lookup_module_0.run(
        terms = cli_args_1,
        variables = cli_args_0
    )
    # test_1
    cli_args_2 = [
        "ansible",
        "--version",
        "--extra-vars=extra_vars"
    ]

# Generated at 2022-06-25 10:43:48.657871
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    test_str = ''
    test_str += '''
[main]
test_value = 1
test_value2 = 2
test_value3 = 3
test_value4 = 4
'''
    test_str_2 = ''
    test_str_2 += '''
[main]
test_value=5
test_value2=6
test_value3=7
test_value4=8
'''
    test_str_3 = ''
    test_str_3 += '''
[main]
test_value = 9
a = 10
'''
    test_str_4 = ''
    test_str_4 += '''
'''
    test_str_5 = ''
    test_str_5

# Generated at 2022-06-25 10:43:58.301765
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_get_value = LookupModule()
    config_parser_instance = configparser.ConfigParser()
    config_parser_instance.add_section('test')
    config_parser_instance.set('test', 'user', 'ansible')
    lookup_module_get_value.cp = config_parser_instance
    assert lookup_module_get_value.get_value('user', 'test', None, False) == 'ansible'
    assert lookup_module_get_value.get_value('username', 'test', None, False) == None
    assert lookup_module_get_value.get_value('user', 'test', None, True)[0] == 'ansible'
    assert lookup_module_get_value.get_value('username', 'test', None, True) == []


# Generated at 2022-06-25 10:44:09.995229
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_run_0 = LookupModule()

    terms_0 = []

    variables_0 = {}

    # Test with file name as ansible.ini and type as ini
    # Test with file ansible.ini exists
    file_loader = DataLoader()
    file_loader._search_paths = ['tests/unit/lookup_plugins/files']
    lookup_module_run_0._loader = file_loader
    test_file_path = lookup_module_run_0.find_file_in_search_path(variables_0, 'files', 'ansible.ini')
    if not test_file_path:
        raise Exception("File %s not exists" % test_file_path)

# Generated at 2022-06-25 10:44:17.438877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = StringIO()
    config.write(u'[integration]\n')
    config.write(u'user=yannig\n')
    config.write(u'password=yannig_password\n')
    config.write(u'[production]\n')
    config.write(u'user=michel\n')
    config.write(u'password=michel_password\n')
    config.seek(0, os.SEEK_SET)

    cp = configparser.RawConfigParser()
    cp.readfp(config)

    lookup_module = LookupModule()
    lookup_module.cp = cp

    assert lookup_module.get_value('user', 'integration', None, False) == 'yannig'

# Generated at 2022-06-25 10:44:19.740125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    try:
        lookup_module.run([], [])
    except Exception as e:
        assert type(e) == AnsibleLookupError



# Generated at 2022-06-25 10:44:27.160181
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TestLookupModule_run_0
    test_LookupModule_run_0 = LookupModule()
    var_file = "ansible.ini"
    var_terms = [
        "user"
    ]
    var_variables = None
    var_section = "global"
    var_re = False
    var_encoding = "utf-8"
    var_default = ""
    var_case_sensitive = False
    var_allow_no_value = False
    var_return = [
        "root"
    ]


# Generated at 2022-06-25 10:44:38.532288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.read("test/AIX.ini")
    assert "I" == lookup_module.get_value("AIX", "AIX_MEM_TYPE", None, False)
    assert "I" == lookup_module.get_value("IBM", "AIX_MEM_TYPE", None, True)[0]
    assert "Unix" == lookup_module.get_value("IBM", "OS_NAME", None, True)[0]
    assert "Unix" == lookup_module.get_value("AIX", "OS_NAME", None, False)
    assert "I" == lookup_module.get_value("AIX", "OS_TYPE", None, False)



# Generated at 2022-06-25 10:44:56.857890
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    get_value = lookup_module.get_value
    cp = configparser.ConfigParser()
    cp.read('test.ini')
    # Testing with a regexp
    result = get_value(key='.*', section='section1', dflt=None, is_regexp=True)
    assert result == ['e', 'f', 'g']
    # Testing with a key which do not exist
    result = get_value(key='i', section='section1', dflt=None, is_regexp=False)
    assert result is None
    # Testing with a key and a section which exist
    result = get_value(key='f', section='section1', dflt=None, is_regexp=False)
    assert result == 'f'
    # Testing with a key

# Generated at 2022-06-25 10:45:07.574550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['key']

# Generated at 2022-06-25 10:45:11.236878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'file': 'ansible-test.ini', 'encoding': 'utf-8'})
    lookup_module_0.run(['foo=bar', 'bar'])


# Generated at 2022-06-25 10:45:22.126500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = StringIO()
    config.write(u'[global]\n')
    config.write(u'serverName = server\n')
    config.write(u'port = 1234\n')
    config.write(u'applications : \n')
    config.write(u'    domain : domain1\n')
    config.write(u'    name : app1\n')
    config.write(u'    type : type1\n')
    config.write(u'    username : user1\n')
    config.write(u'    password : password1\n')
    config.write(u'    maxSessions : 1')
    config.seek(0, os.SEEK_SET)

    lookup_module = LookupModule()


# Generated at 2022-06-25 10:45:25.733779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_LookupModule_run = lookup_module_0.run([], [])
    assert result_LookupModule_run == []

# Generated at 2022-06-25 10:45:36.400798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    contents = '''
    [dba]
    db_user=ansible
    db_password=ansible
    db_port=456

    [web]
    web_user=ansible
    web_password=ansible
    web_port=123
    '''

    config = StringIO()
    config.write(contents)
    config.seek(0, os.SEEK_SET)

    lookup_module_0 = LookupModule()

    assert lookup_module_0.run([
        'db_user'], variables={},
        file='file.ini', section='dba',
        re=False, case_sensitive=False,
        allow_no_value=False, encoding="utf-8") == ['ansible']

# Generated at 2022-06-25 10:45:47.915136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing LookupModule.run")
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(StringIO("""[global]
key_b=value_b
key_c=value_c

[section1]
key_d=value_d"""))

    terms = "key_a"

    variables = {'file': "ansible.ini", 'section': 'global', 'default': ""}

    ret = lookup_module.run(terms, variables=variables)

    result = ret == ['']
    assert result, "Error while testing LookupModule.run"


# Generated at 2022-06-25 10:45:54.349901
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with no value for argument term
    with pytest.raises(AnsibleLookupError):
        lookup_module_1 = LookupModule()

    # Test with invalid value for argument term
    with pytest.raises(AnsibleLookupError):
        lookup_module_2 = LookupModule()

    # Test with invalid value for argument term
    with pytest.raises(AnsibleLookupError):
        lookup_module_3 = LookupModule()

# Generated at 2022-06-25 10:45:54.898597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:46:04.512844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = """
[mysqld]
user = mysql
"""
    cp = configparser.ConfigParser(allow_no_value=True)
    config = StringIO()
    config.write(result)
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)
    lookup_module.cp = cp
    terms = ['']
    variables = None
    kwargs = {'section': 'mysqld', 'file': 'mysql.ini', 'default': '', 'allow_no_value': 'True'}
    user = lookup_module.run(terms, variables, **kwargs)
    assert user == ['mysql'], 'Return value is not the same'


# Generated at 2022-06-25 10:46:23.868485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._options = {'file': 'ansible.ini', '_original_file': 'ansible.ini'}
    lookup_module_0._display.warning = MagicMock(side_effect=AnsibleLookupError())
    
    try:
        lookup_module_0.run(['ansible.ini'], {'vars': {'playbook_dir': '/home/foo/ansible'}})
    except Exception as exception_0:
        if isinstance(exception_0, Exception):
            str_0 = str(exception_0)
            bool_0 = True
        else:
            bool_0 = False

    assert bool_0

# Generated at 2022-06-25 10:46:27.682983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = None
    variables = None
    kwargs = None
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms, variables, kwargs)

# Generated at 2022-06-25 10:46:36.265553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = defaultdict()
    paramvals.update({'file': 'ansible.ini'})
    paramvals.update({'type': 'ini'})
    paramvals.update({'encoding': 'utf-8'})
    paramvals.update({'re': False})
    paramvals.update({'default': ''})
    paramvals.update({'case_sensitive': False})
    paramvals.update({'allow_no_value': False})
    paramvals.update({'section': 'global'})
    terms = [{'user.name': 'yannig'}]
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms) == None


# Generated at 2022-06-25 10:46:38.533844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = {}
    variables_0 = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 10:46:44.437081
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:46:54.314062
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    print('get_value')
    lookup_module_0 = LookupModule()
    section = 'FnBjKSH8w0'
    key = 'FnBjKSH8w0'
    dflt = 'FnBjKSH8w0'
    is_regexp = 'FnBjKSH8w0'
    var_0 = lookup_module_0.get_value(key, section, dflt, is_regexp)
    assert var_0 == 'FnBjKSH8w0'


# Generated at 2022-06-25 10:47:04.944965
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    dict_0 = {}
    bool_0 = False
    lookup_module_0 = LookupModule()
    str_0 = "7"
    str_1 = ""
    str_2 = test_LookupModule_get_value()
    str_3 = test_LookupModule_get_value()
    str_4 = test_LookupModule_get_value()
    str_5 = "7"
    str_6 = ""
    str_7 = test_LookupModule_get_value()
    str_8 = test_LookupModule_get_value()
    str_9 = test_LookupModule_get_value()
    str_10 = "7"
    str_11 = ""
    str_12 = test_LookupModule_get_value()
    str_13 = test_LookupModule_get_

# Generated at 2022-06-25 10:47:12.167800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {
        'file' : 'file',
        'type' : "ini",
        'encoding' : 'utf-8',
        'default' : '',
        'case_sensitive' : False,
        'allow_no_value' : False
    }

    terms = ['key1', 'key2', 'key3']
    var_0 = LookupModule()

    # Call the method
    var_1 = var_0.run(terms, paramvals)

    # Get the value
    assert var_1 == ['value1', 'value2', 'value3']

# Generated at 2022-06-25 10:47:15.477107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = lookup_get_value(dict_0, lookup_module_0, bool_0, bool_0)
    lookup_module_1.run(var_0, dict_0)


# Generated at 2022-06-25 10:47:20.821494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'direct': {}}, var_options={})

# Generated at 2022-06-25 10:47:49.851617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_10 = '/run/secrets/ldap_password'
    lookup_module_2 = LookupModule()
    str_14 = 'secret'
    lookup_module_3 = LookupModule()
    str_16 = 'docker_dev'
    lookup_module_4 = LookupModule()
    str_18 = 'examples'
    lookup_module_5 = LookupModule()
    str_20 = 'ansible.ini'
    lookup_module_6 = LookupModule()
    str_23 = '=ldap_password'
    lookup_module_7 = LookupModule()
    str_26 = '=docker_dev'
    lookup_module_8 = LookupModule()
    str_29 = '=examples'
    lookup_module_9 = Look

# Generated at 2022-06-25 10:47:54.578105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    param_0 = {}
    param_1 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(param_0, param_1)
    assert var_0 == [], var_0


# Generated at 2022-06-25 10:47:56.951618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = tuple()
    variables = None
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(term, variables)
    print(ret_0)

# Generated at 2022-06-25 10:48:01.948276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Creating object of class LookupModule
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None)

    # Testing on a small ini file
    from ansible import constants
    terms = ['user', 'password']
    test_file = constants.DEFAULT_LOCAL_TMP + "/ini_test.ini"
    test_ini = u"""
[section1]
user = test_user
password = test_pass
"""
    with open(to_native(test_file), 'w') as f:
        f.write(to_native(test_ini))
    lookup_module_0.run(terms, variables=None, file=test_file, section='section1')

# Generated at 2022-06-25 10:48:11.979556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'type': 'ini', 'file': 'ansible.ini', 'section': 'global', 're': True, 'default': '', 'case_sensitive': False})
    # Create StringIO later used to parse ini
    config = StringIO()
    # Special case for java properties
    if lookup_module_0 == "properties":
        config.write(u'[java_properties]\n')
        lookup_module_0 = 'java_properties'
    # Open file using encoding
    contents, show_data = lookup_module_0._loader._get_file_contents(dict_0)
    contents = to_text(contents, errors='surrogate_or_strict', encoding=dict_0)

# Generated at 2022-06-25 10:48:15.862700
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = ""
    str_1 = ""
    str_0 = to_text(str_0, encoding='utf-8')
    str_1 = to_text(str_1, encoding='utf-8')
    var_0 = lookup_module_0.get_value(str_0, str_1, str_0, bool())
    assert var_0 == "", "Expected '', got '%s'" % var_0


# Generated at 2022-06-25 10:48:22.184037
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    dict_0 = {}
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_get_value(dict_0, lookup_module_0, bool_0, bool_0)
    var_1 = lookup_get_value(dict_0, lookup_module_0, bool_0, bool_0)
    assert var_0 == var_1



# Generated at 2022-06-25 10:48:27.384349
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    term_0 = "users.ini"
    paramvals_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = get_value(term_0, paramvals_0, lookup_module_0)


# Generated at 2022-06-25 10:48:31.482309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'foo'
    variable = None
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0, lookup_module_0, term, variable)

test_LookupModule_run()

# Generated at 2022-06-25 10:48:36.746023
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = "tst key"
    str_1 = "tst section"
    str_2 = "tst dflt"
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_1, str_2, bool_0)


# Generated at 2022-06-25 10:49:30.251519
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    dict_0 = {}
    lookup_module_0 = LookupModule()
    # No assertions.
    # We expect no exceptions.
    # Method get_value with parameters dict_0, lookup_module_0.
    try:
        LookupModule.get_value(dict_0, lookup_module_0)
    except Exception:
        pass


# Generated at 2022-06-25 10:49:34.113212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{}, {}, {}, {}, {}, {}]
    variables = {}
    kwargs = {"allow_no_value": True}
    lookup_module_0 = LookupModule()
    var_0 = lookup_get_value(terms, lookup_module_0, "run", variables, **kwargs)


# Generated at 2022-06-25 10:49:41.411842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Setup
  terms = ['a']
  variables = {}
  path_0 = 'ansible.ini'
  config_0 = StringIO()
  contents_0 = ''
  config_0.write(u'[a]\n')
  config_0.seek(0, os.SEEK_SET)
  cp_0 = configparser.ConfigParser()
  cp_0.readfp(config_0)
  lookup_module_0 = LookupModule()
  lookup_module_0.cp = cp_0

  # Invoke method
  return_value_0 = lookup_module_0.run(terms, variables, file=path_0)
  # Create expected values
  str_0 = 'b'
  expected_value_0 = [str_0]
  # Compare return values
  assert return_value_

# Generated at 2022-06-25 10:49:50.328238
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = "C(section=section0)"
    str_1 = "key0"
    str_2 = "dflt0"
    bool_0 = False
    var_0 = lookup_module_0.get_value(str_1, str_0, str_2, bool_0)


# Generated at 2022-06-25 10:49:52.232675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(term_0, term_1, var_0)


# Generated at 2022-06-25 10:50:00.497366
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_0 = LookupModule()
    str_0 = '{'
    str_1 = '['
    str_2 = ']'
    str_3 = '}'
    bool_0 = False
    str_4 = 'user'
    str_5 = 'debug'
    str_6 = 'false'
    str_7 = 'test'
    str_8 = 'case_0'
    str_9 = 'test'
    list_0 = []
    list_1 = []
    bool_1 = False
    bool_2 = False
    int_0 = 0
    int_1 = 0
    bool_3 = False
    bool_4 = False

    # Call method get_value of lookup_module_0

# Generated at 2022-06-25 10:50:08.176899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {}
    term = "test"
    variables = None
    lookup_module_0 = LookupModule()
    val_0 = lookup_module_0.run(term, variables, paramvals)
    assert val_0 == [], "AssertionError if method run of class LookupModule called with '{}', {}, {}".format(term, variables, paramvals)


# Generated at 2022-06-25 10:50:10.548366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    terms_0 = ['loolup_string']
    dict_1 = {'file': 'test_file_0'}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0, dict_0, **dict_1)


# Generated at 2022-06-25 10:50:17.639908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Method run with parameter terms and paramvals
    params = {}
    terms = ['test_var']
    paramvals = {'case_sensitive': True}
    lookup_module_0.run(terms, paramvals)

    # Method run with parameter terms and paramvals
    params = {}
    lookup_module_0 = LookupModule()
    terms = ['test_var', 'test_var']
    paramvals = {'case_sensitive': True}
    lookup_module_0.run(terms, paramvals)

    # Method run with parameter terms and paramvals
    params = {}
    lookup_module_0 = LookupModule()
    terms = ['test_var']
    paramvals = {'case_sensitive': False}
    lookup_module_0.run(terms, paramvals)

# Generated at 2022-06-25 10:50:24.469658
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # LookupModule.run is called with the first argument = [''], the second argument = {}, the third argument = False and the fourth argument = False
    # The return from the call is assigned to the variable var_0
    lookup_module_3 = LookupModule()
    var_0 = lookup_module_3.run([''], {}, case_sensitive=False)

    # Asserts that the value of the returned variable does not raise an exception
    assert not raises(Exception, var_0)


# Generated at 2022-06-25 10:52:10.055934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_0['FQDN'] = 'test-fqdn'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(dict_0)

test_LookupModule_run()

# Generated at 2022-06-25 10:52:16.379270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        dict_0 = {}
        dict_1 = {}
        lookup_module_0 = LookupModule()
        lookup_module_0.run(dict_0, dict_1)
        test_case_0()
    except Exception as err:
        import traceback
        traceback.print_tb(err.__traceback__)
        print(err)
    else:
        pass
    finally:
        pass

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:52:19.248909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 10:52:22.175233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ["string_0", "string_1"]
    lookup_module_0.run(term_0)



# Generated at 2022-06-25 10:52:26.211743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    int_0 = 0
    int_1 = 1


# Generated at 2022-06-25 10:52:34.105582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0, dict_0, lookup_module_0)

###
#  Unit test for method run of class LookupModule using Ini format
###

# Create a sample .ini file

# Generated at 2022-06-25 10:52:40.699850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_0['allow_none'] = True
    dict_0['section'] = 'section'
    dict_0['encoding'] = 'utf-8'
    dict_0['case_sensitive'] = True
    dict_0['type'] = 'properties'
    dict_0['file'] = 'ansible.ini'
    dict_0['re'] = False
    dict_0['default'] = ''
    lookup_module_0 = LookupModule()
    dict_1['file'] = dict_0['file']
    dict_1['re'] = dict_0['re']
    dict_1['default'] = dict_0['default']
    dict_1['section'] = dict_0['section']
    dict_1['type'] = dict_0['type']


# Generated at 2022-06-25 10:52:46.772806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Needs to import the ansible.plugins.loader.LookupModule module
    lookup_module_0 = LookupModule()
    try:
        # TODO: Seem to need to call execute_module in the same way as the protocol and actual plugins...
        # ansible.plugins.loader.LookupModule.run(lookup_module_0, terms_0, variables_0, **kwargs_0)
        pass
    except Exception as err:
        print(err)



# Generated at 2022-06-25 10:52:49.750194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    bool_0 = False
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(dict_0)


# Generated at 2022-06-25 10:52:58.312245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_