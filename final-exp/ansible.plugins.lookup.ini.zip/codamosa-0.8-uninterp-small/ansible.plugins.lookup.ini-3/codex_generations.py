

# Generated at 2022-06-25 10:43:25.312777
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a non existing file
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({'file': '/no/file/here'})
    with pytest.raises(AnsibleFileNotFound):
        lookup_module_1.run(['myhost'])

    # Test with a file with no section
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options({'file': 'lookup_plugins/ini/no_section.ini'})
    assert lookup_module_2.run(['myhost']) == []

    # Test with a file containing a section
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 10:43:31.566146
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.get_value("user", "section", None, False) == None
    assert lookup_module_0.get_value("user", "section", None, True) == None


# Generated at 2022-06-25 10:43:38.935893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_test_0 = LookupModule()

    # Prepare configparser
    config_parser_test_0 = configparser.ConfigParser(allow_no_value=False)
    config_parser_test_1 = configparser.ConfigParser(allow_no_value=False)
    config_parser_test_2 = configparser.ConfigParser(allow_no_value=False)

    config_parser_test_1.optionxform = to_native
    config_parser_test_2.optionxform = to_native




# Generated at 2022-06-25 10:43:48.638520
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser() # Makes no sense. do not do this.
    lookup_module.cp.read("tests/test.ini")

    result = lookup_module.get_value("key1", "section1", "test default", False)
    assert result == "value1"
    result = lookup_module.get_value("key1", "section2", "test default", False)
    assert result == "value12"
    result = lookup_module.get_value("key3", "section1", "test default", False)
    assert result == "test default"
    result = lookup_module.get_value(".*", "section1", "test default", True)
    assert result[0] == "value1"

# Generated at 2022-06-25 10:43:54.931859
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:43:58.032127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = {'key': 'user', 'file': 'users.ini', 'section': 'integration', 'type': 'ini'}
    result = lookup_module.run(terms=terms)
    print(list(result))

# Generated at 2022-06-25 10:43:59.104392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms="", variables="") == []


# Generated at 2022-06-25 10:44:05.688013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['asd']
    variables = {}
    kwargs = {'type':'ini', 'file': 'ansible.ini', 'section': 'global', 're': False, 'encoding': 'utf-8',
              'default': '', 'case_sensitive': False, 'allow_no_value': False}
    lookup_module = LookupModule()
    ret = lookup_module.run(terms=terms, variables=variables, **kwargs)
    assert(ret == [])


#Unit test for method read_configparser of class LookupModule

# Generated at 2022-06-25 10:44:10.709499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("TEST CASE 0")
    print(test_case_0())


if __name__ == '__main__':
    test_LookupModule_run()


# Generated at 2022-06-25 10:44:21.495108
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.optionxform = to_native

    config = StringIO()
    config.write(u"[java_properties]\n")
    config.write(u'key = value\n')
    config.write(u'default_without_ini=default\n')
    config.write(u'string = string\n')
    config.write(u'unicode_string=\\u554a\\u554a\\u554a\n')
    config.write(u'unicode=\\u43d5\\u43d5\\u43d5\n')
    config.write(u'unicode_other_format=\\u4e2d\\u6587\n')

# Generated at 2022-06-25 10:44:43.672756
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Test 1
    test_term_1 = 'user'
    test_variable_1 = None
    test_paramvals_1 = {'re': False, 'type': 'ini', 'case_sensitive': False, 'file': 'ansible.ini', 'allow_no_value': False, 'encoding': 'utf-8', 'section': 'global', 'default': ''}
    test_result_1 = lookup_module_1.run(test_term_1, test_variable_1, **test_paramvals_1)
    assert test_result_1 == []

    # Test 2
    test_term_2 = 'user'
    test_variable_2 = None

# Generated at 2022-06-25 10:44:53.758843
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # test when key exists in section
    lookup_module_1 = LookupModule()
    config_parser_1 = configparser.ConfigParser()
    config_parser_1.add_section('test')
    config_parser_1.set('test', 'name1', 'value1')
    lookup_module_1.cp = config_parser_1
    assert lookup_module_1.get_value('name1', 'test', "", False) == 'value1'

    # test when key does not exist in section
    lookup_module_2 = LookupModule()
    config_parser_2 = configparser.ConfigParser()
    config_parser_2.add_section('test')
    config_parser_2.set('test', 'name1', 'value1')
    lookup_module_2.cp = config_parser_2
   

# Generated at 2022-06-25 10:44:59.959366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    lookup_module_1 = LookupModule()
    
    terms_2 = ["key"]
    variables_3 = None
    ret_4 = lookup_module_1.run(terms_2, variables_3)
    assert ret_4 == ['mykey']


# Generated at 2022-06-25 10:45:02.842077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options([])
    lookup_module_0.get_options()
    lookup_module_0.cp = configparser.ConfigParser()
    lookup_module_0.run([])


# Generated at 2022-06-25 10:45:14.947963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [u'user', u'user=yannigperre', u'user file=users.ini section=integration is_regex=False']
    variables = u''
    kwargs = {u'file': u'users.ini', u'section': u'integration', u're': u'False'}
    lookup_module.run(terms, variables, **kwargs)

    terms = [u'user', u'user=yannigperre', u'user file=users.ini section=integration is_regex=False']
    variables = u''
    kwargs = {u'file': u'users.ini', u'section': u'integration', u're': u'False'}
    lookup_module.run(terms, variables, **kwargs)



# Generated at 2022-06-25 10:45:25.086389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    import unittest

    # create a temporary file
    fh, config_file = tempfile.mkstemp()
    os.close(fh)

    # create the content
    file_content = [
        '[global]',
        'user=root',
        'password=password',
        '\n',
        '[integration]',
        'user=admin',
        'password=admin',
        '\n',
        '[production]',
        'user=admin',
    ]

    # write the content
    with open(config_file, 'w') as f:
        f.writelines(file_content)

    # declare params

# Generated at 2022-06-25 10:45:26.700038
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()

    assert lookup_module_0.get_value('', '', '', False) == None


# Generated at 2022-06-25 10:45:35.169957
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser()
    cp.add_section('integration')
    cp.set('integration', 'integration_user', 'integration_user')
    cp.add_section('production')
    cp.set('production', 'production_user', 'production_user')
    config = StringIO()
    config.write(u'[integration]\nintegration_user=integration_user\n[production]\nproduction_user=production_user\n')
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = cp

    # Test 1
    expected_result = 'integration_user'

# Generated at 2022-06-25 10:45:48.739011
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    contents = u"""
    [global]
    user = root
    """
    config = StringIO()
    config.write(contents)
    config.seek(0, os.SEEK_SET)
    config_parser = configparser.ConfigParser(allow_no_value=True)
    config_parser.readfp(config)
    lookup_module = LookupModule()
    lookup_module.cp = config_parser
    key = 'user'
    section = 'global'
    dflt = 'titi'
    res = lookup_module.get_value(key, section, dflt, False)
    assert res == 'root'
    res = lookup_module.get_value('toto', section, dflt, False)
    assert res == 'titi'


# Generated at 2022-06-25 10:45:54.762484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['TEST_FILE']
    variables = None
    kwargs = {'file': 'test.ini', 'default': '123', 'section': 'DEFAULT', 're': False}

    expected = ['456']
    actual = LookupModule().run(terms, variables, **kwargs)
    assert expected == actual

# TODO: Write unit tests for the following:
# test_get_value
# test_run (with _parse_params)

# Generated at 2022-06-25 10:46:14.869852
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:46:19.288662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert [u'password'] == lookup_module.run(terms=["password"], variables={}, section="database", file="ansible.ini", type="ini", re=False, encoding="utf-8", default="")
    assert [u'password'] == lookup_module.run(terms=["password"], variables={}, section="database", file="ansible.ini", type="ini", re=False, encoding="utf-8", default="")
    assert [] == lookup_module.run(terms=["password"], variables={}, section="database", file="ansible.ini", type="ini", re=False, encoding="utf-8", default="")

# Generated at 2022-06-25 10:46:26.661212
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    assert lookup_module.get_value("name", "java_properties", "", False) == "value"
    assert lookup_module.get_value("name", "java_properties", "default", True) == ["value"]
    assert lookup_module.get_value("no_value", "java_properties", "default", True) == ["default"]
    assert lookup_module.get_value("no_value", "java_properties", "default", False) == "default"
    assert lookup_module.get_value("name", "property", "default", False) == "value"
    assert lookup_module.get_value("no_value", "property", "default", False) == "default"


# Generated at 2022-06-25 10:46:36.339816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check instance with default values
    lookup_module_0 = LookupModule()
    terms_0 = ['key']
    variables_0 = {}
    kwargs_0 = dict()
    kwargs_0['file'] = 'ansible.ini'
    kwargs_0['section'] = 'global'
    kwargs_0['type'] = 'ini'
    kwargs_0['default'] = ''
    kwargs_0['re'] = False
    kwargs_0['encoding'] = 'utf-8'
    ret_val_1 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret_val_1 == ['']
    # Check instance with changed defaults
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:46:40.058302
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    configparser_0 = configparser.ConfigParser()
    with patch.object(configparser.ConfigParser, 'items', return_value=(iter([('key', 'value')]))) as mock_items:
        res_0 = lookup_module_0.get_value('key', 'section', 'dflt', 'is_regexp')


# Generated at 2022-06-25 10:46:48.844324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Invoking the LookUpModule class with passing the required arguments
    lookup = LookupModule()
    # Reading the required INI file
    file_name = open("ansible.cfg")

    params = [
        "inventory",
        "library",
        "lookup_plugins"
    ]

    for term in params:
        # Passing the other optional arguments
        terms = [term]
        result = lookup.run(terms,variables=None,default=' ',file="ansible.cfg")
        # NameError: name 'result' is not defined
        result_expected = "file"
        assert result == result_expected

# Generated at 2022-06-25 10:46:57.154019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First test : a section is found and a key is found.
    lookup_module_1 = LookupModule()

    term = 'user'
    section = 'integration'
    key = 'user'
    dflt = None
    is_regexp = False
    cp = configparser.ConfigParser()
    cp.readfp(StringIO(u'[integration]\nuser=user'))
    lookup_module_1.cp = cp

    result = lookup_module_1.get_value(key, section, dflt, is_regexp)
    assert result == 'user'

    # Second test : a section is found and a key is not found.
    lookup_module_2 = LookupModule()

    term = 'user'
    section = 'integration'
    key = 'user'

# Generated at 2022-06-25 10:47:06.847377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path = "./test/ansible.ini"
    terms = [
        "user",
        "password",
        "UNKNOWN",
    ]
    variables = None
    kwargs = {
        "file": "",
        "default": "",
        "re": "",
        "section": "",
        "type": "",
        "encoding": ""
    }
    lookup_module = LookupModule()

    # Verify that function returns a list
    result = lookup_module.run(terms, variables, **kwargs)
    assert isinstance(result, list)

    # Verify that function returns a list of str
    result = lookup_module.run(terms, variables, **kwargs)
    assert all(isinstance(item, str) for item in result)

    # Verify that function returns the list ["test", "

# Generated at 2022-06-25 10:47:08.812105
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.get_value('username', 'section1', '', True) == ['uname1', 'uname2']

# Generated at 2022-06-25 10:47:15.111658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = [u'key1', u'key2']
    variables_2 = {u'file': u'ansible.ini'}
    kwargs_3 = {u'file': u'ansible.ini', u'default': u'', u'section': u'', u'type': u'ini'}
    contents_4 = u'key1=value1\nkey2=value2'
    show_data_5 = False
    path_6 = u'ansible.ini'
    config_7 = StringIO()
    config_7.write(u'[java_properties]\n')
    config_7.seek(0, os.SEEK_SET)

# Generated at 2022-06-25 10:47:50.926606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up
    lookup_module_1 = LookupModule()

    # Test 1
    terms_1 = ['a=b']
    variables_1 = {'test': ['1', '2']}
    kwargs_1 = {'allow_none': False}
    try:
        assert lookup_module_1.run(terms_1, variables_1, kwargs_1)
    except AssertionError:
        assert False

    # Test 2
    terms_2 = ['a=b']
    variables_2 = {'test': ['1', '2']}
    kwargs_2 = {'allow_none': True}
    try:
        assert lookup_module_1.run(terms_2, variables_2, kwargs_2)
    except AssertionError:
        assert False

# Generated at 2022-06-25 10:47:53.912291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:47:56.951272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {'allow_none': False}
    variables = None
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=['user', 'user'], variables=variables, **paramvals)


# Generated at 2022-06-25 10:48:02.259931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up unit test environment
    # See file test/ansible/vars/ini.yml for more.

    lookup_module = LookupModule()

    class FakeVarsModule(object):
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self, loader, path, entities, cache=True):
            return {'ansible_lookup_plugin_ini_file': self.vars['path']}

    class FakeLoaderModule(object):
        def _get_file_contents(self, path):
            if path == 'fake':
                return "[global]\nuser=yannig\n[integration]\nuser=nico\n[production]\nuser=gael\n", 'fake'

# Generated at 2022-06-25 10:48:09.466888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        'user=xxx password=xxx type=properties file=/home/vagrant/git/ansible-lookup-plugins/tests/test_data/user.properties'
        ]
    variables = {'lookup_file_path': ['.', '/home/vagrant/git/ansible-lookup-plugins/tests/test_data']}
    lookup_module.run(terms, variables)
    assert lookup_module.run(terms, variables) == ['yannig']

# Generated at 2022-06-25 10:48:16.015901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()
    lookup_module_1.cp.readfp(StringIO(u"""[test_section1]
test_key1=1
test_key2=2
test_key3=3
[test_section2]
test_key4=4
test_key5=5
test_key6=6
"""))

    # Normal use case
    lookup_module_1.get_options = lambda: defaultdict(lambda: '')
    ret = lookup_module_1.run(['test_key1', 'test_key2', 'test_key3'], {}, section='test_section1')

    assert len(ret) == 3
    assert ret[0] == u'1'

# Generated at 2022-06-25 10:48:25.746271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Declared variable
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:48:35.126681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with open('test_file', 'w') as testfile:
        testfile.write('[section1]\na1 = b1\na2 = b2\n[section2]\na3 = b3\na4 = b4\n')
    cp = configparser.ConfigParser()
    cp.read('test_file')
    lookup_module = LookupModule()
    lookup_module.cp = cp
    lookup_module.get_value = cp.get
    os.unlink('test_file')

    assert lookup_module.run(['a1'], variables={'files': ['test_file']}, file='test_file', section='section1', default='default') == ['b1']

# Generated at 2022-06-25 10:48:43.011603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # 1st parameter of the function run

# Generated at 2022-06-25 10:48:49.990069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    params = dict()
    params['encoding'] = 'utf-8'
    params['case_sensitive'] = False
    params['default'] = ''
    params['re'] = True
    params['allow_no_value'] = False
    params['file'] = 'file_path'
    params['type'] = 'ini'
    params['section'] = 'global'
    terms_0 = ['key']
    assert lookup_module_0.run(terms_0, params) is None


# Generated at 2022-06-25 10:49:22.789976
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False
    lookup_module_0.get_value(str_0, str_1, str_2, bool_0)


# Generated at 2022-06-25 10:49:33.858541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = 'key'
  bool_0 = True
  variables = 'value'
  file = 'file'
  lookup_module_0 = LookupModule()
  list_0 = []
  str_0 = 'type'
  str_1 = 'properties'
  lookup_module_0.set_options(var_options=variables, direct=kwargs)
  paramvals = lookup_module_0.get_options()

  lookup_module_0.cp = configparser.ConfigParser(allow_no_value=paramvals.get('allow_no_value', paramvals.get('allow_none')))
  if paramvals['case_sensitive']:
      lookup_module_0.cp.optionxform = to_native

  ret = list_0
  for term in terms:
    key = term
    # parameters specified?

# Generated at 2022-06-25 10:49:39.070822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    bool_0 = False
    obj_0 = None
    lookup_module_0.get_value(str_0, str_0, str_0, bool_0)
    lookup_module_0.get_options()
    lookup_module_0.run(str_0, obj_0, **{})
    #assert to_native(ret) == str_1

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:49:40.925452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['qwerty']
    variables = {}

    # Call method
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 10:49:44.034204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'test.txt'
    terms_0 = [['test.txt'], ['test.txt'], ['test.txt']]
    result_0 = lookup_module_0.run(terms=terms_0, variables=str_0)
    assert result_0 == [], 'unit-test failed'


# Generated at 2022-06-25 10:49:54.287023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    list_0 = ['126']
    bool_0 = False
    file_0 = "../examples/ansible.ini"
    str_1 = "global"
    str_2 = "utp user=shanmugavel"
    list_2 = [str_2]
    str_3 = "default"
    str_4 = "re"
    bool_1 = True
    str_5 = "case_sensitive"
    bool_2 = True
    str_6 = "allow_no_value"
    bool_3 = True
    str_7 = "type"
    str_8 = "properties"

# Generated at 2022-06-25 10:49:57.845306
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookupModule = LookupModule()
    key = 'key'
    section = 'section'
    dflt = 'dflt'
    is_regexp = 'is_regexp'
    var = lookupModule.get_value(key, section, dflt, is_regexp)


# Generated at 2022-06-25 10:50:04.264340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test a successful run with a single file
    terms = ['george']
    kwargs = {'file': 'employees.ini', 'section': 'customers', 'case_sensitive': False, 'allow_no_value': False}
    lookup_module = LookupModule()

    opts = {'file': 'employees.ini', 'section': 'customers', 'case_sensitive': False, 'allow_no_value': False,
            'encoding': 'utf-8'}
    lookup_module.set_options(direct=opts)
    paramvals = lookup_module.get_options()

    path = '/home/test/employees.ini'
    lookup_module.find_file_in_search_path = lambda variables, dirname, filename: path
    lookup_module._loader = FakeAnsibleFileLoader()

# Generated at 2022-06-25 10:50:09.496240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-25 10:50:11.889980
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_1, str_2, bool_0)


# Generated at 2022-06-25 10:51:27.758475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  properties = configparser.ConfigParser()
  properties.read('../../lookup/ini.ini')
  section = 'java_properties'
  terms = [properties.get(section, 'key')]
  lookup_module_0 = LookupModule()
  lookup_module_0._terms = terms
  lookup_module_0.run(terms)


# Generated at 2022-06-25 10:51:31.230288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str = ''
    str_0 = ''
    str_1 = ''
    bool_0 = False
    var = lookup_module.run(str, str_0, direct=bool_0, var_options=str_1)
    print(var)

if (__name__ == '__main__'):
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:51:36.389495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run()")

    lookup_mod1 = LookupModule()
    test_set = ['test_ans=test_ans', 'fake_section', 'test_ans', 'no_section=def_val']
    test_ans = ['test_ans']
    ans = lookup_mod1.run(test_set)
    assert ans == test_ans

    lookup_mod2 = LookupModule()
    test_set = ['test_ans=test_ans', 'fake_section', 'fake_key', 'no_section=def_val']
    test_ans = ['def_val']
    ans = lookup_mod2.run(test_set)
    assert ans == test_ans

    lookup_mod3 = LookupModule()

# Generated at 2022-06-25 10:51:41.307973
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    bool_0 = False

    assert_equal(lookup_module_0.get_value(str_0, str_1, str_1, bool_0), str_1)



# Generated at 2022-06-25 10:51:46.293239
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Native
    lookup_module_0 = LookupModule()
    args_0 = ['foo=bar']
    options_0 = {}
    ret_0 = lookup_module_0.run(terms=args_0, variables=options_0)
    assert ret_0[0] == 'bar'
    # Native
    lookup_module_1 = LookupModule()
    args_1 = ['section', 'foo']
    options_1 = {
        'section': 'section',
        'foo': 'bar'
        }
    ret_1 = lookup_module_1.run(terms=args_1, variables=options_1)
    assert ret_1[0] == 'bar'


# Generated at 2022-06-25 10:51:53.401899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path = '../ansible/modules/file/ini.yml'
    if os.path.isfile(path):
        os.remove(path)

    # Create 'ini.yml' file
    config = StringIO()
    config.write(u'[java_properties]\n')
    config.write(u'abcd=XXXX\n')
    config.write(u'defg=YYYY\n')
    config.write(u'[section1]\n')
    config.write(u'abcd=XXXX\n')
    config.write(u'defg=YYYY\n')
    config.write(u'[section2]\n')
    config.write(u'abcd=XXXX\n')
    config.write(u'defg=YYYY\n')
    config.write

# Generated at 2022-06-25 10:51:57.622110
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_1, str_2, bool_0)


# Generated at 2022-06-25 10:52:01.402656
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    bool_0 = False
    var_0 = lookup_get_value(lookup_module_0, str_0, str_1, str_2, bool_0)

# Generated at 2022-06-25 10:52:03.416742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    dict_0 = {}
    list_0 = []
    var_0 = lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 10:52:08.301288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)