

# Generated at 2022-06-25 10:43:24.222836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    datafiles_dir = os.path.join(os.path.dirname(__file__), '../../data/lookup')
    os.chdir(datafiles_dir)
    lookup_module_1 = LookupModule()
    terms_1 = [['key', 'file', 'ini', 'case_sensitive', 'encoding']]
    variables_1 = {}
    direct_1 = {'file': 'ini', 'case_sensitive': 'false', 'encoding': 'utf-8'}

    assert lookup_module_1.run(terms_1, variables_1, direct_1)==['value']


# Generated at 2022-06-25 10:43:35.561414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    contents = '''[pets]
    dog: Dog
    cat: Cat
    '''
    config = StringIO()
    config.write(contents)
    config.seek(0,os.SEEK_SET)
    params = defaultdict(lambda: '')
    params['file'] = 'none'
    params['allow_no_value'] = True
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module.cp.readfp(config)
    ret = lookup_module.get_value('cat', 'pets', params['default'], params['re'])
    assert ret == 'Cat'
    ret = lookup_module.get_value('nope', 'pets', params['default'], params['re'])
   

# Generated at 2022-06-25 10:43:46.257375
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_file = os.path.join(os.path.dirname(__file__), 'tests', 'test.ini')
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()
    lookup_module_1.cp.read(test_file)
    assert lookup_module_1.get_value("user1", "section1", "", False) == 'value_1'
    assert lookup_module_1.get_value("user2", "section2", "", False) == 'value_2'
    assert lookup_module_1.get_value("user3", "section3", "", False) == 'value_3'


# Generated at 2022-06-25 10:43:56.707103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._get_file_contents = lambda x, y: (to_text('''
[test_1]
key_1_1=value_1_1
key_1_2=value_1_2
[test_2]
key_2_1=value_2_1
key_2_2=value_2_2
''', errors='surrogate_or_strict', encoding='utf-8'), False)
    lookup_module.find_file_in_search_path = lambda x, y, z: 'test_file'
    lookup_module.get_options = lambda: dict(type='ini', section='test_1', file='test.ini')

    assert lookup_module.run(['key_1_1']) == ['value_1_1']

# Generated at 2022-06-25 10:44:05.496436
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1:
    # test_case_0 is loading from test/unittests/test_lookup_plugins/test_data/ini_lookup/run/ansible.ini.
    # Ansible.ini file content is:
    # ===============================================
    # [global]
    # host1 = 10.0.0.10
    #
    # [section1]
    # value = hello
    # value1 = world
    # ===============================================
    # test_case_0.run is running with parameters:
    # terms: key = section1.value, section = global, file = ansible.ini, re = False
    # Expecting result: hello
    lookup_module_0 = LookupModule()
    terms_0 = ['section1.value']

# Generated at 2022-06-25 10:44:14.173968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_cases = [['password', 'development', None, False, 'foo']]
    cp = configparser.ConfigParser()
    cp.read("test_configparser.ini")
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = cp
    for test_case in test_cases:
        result = lookup_module_1.get_value(test_case[0], test_case[1], test_case[2], test_case[3])
        assert result == test_case[4]



# Generated at 2022-06-25 10:44:22.218274
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    cp = configparser.ConfigParser()
    section = "integration"
    dd = "dflt"
    is_regexp = False
    look_up_key = "user"
    cp_1 = configparser.ConfigParser()
    cp_1.add_section(section) #Create the section
    cp_1.set(section, "user", "test_user")
    asrt_ret = lookup_module_1.get_value(look_up_key, section, dd, is_regexp)
    assert asrt_ret == dd
    #Assign the config
    lookup_module_1.cp = cp_1
    asrt_ret = lookup_module_1.get_value(look_up_key, section, dd, is_regexp)


# Generated at 2022-06-25 10:44:25.242137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing LookupModule::run')
    
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[u'key'], variables=None, **{u'file': u'file.ini', u'type': u'ini', u'section': u'global', u'default': u'', u'case_sensitive': False, u're': False})

# Generated at 2022-06-25 10:44:36.707380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._get_file_contents = lambda x, y: (u'[global]\nuser = yannig'), ''
    lookup_module_1.cp = configparser.ConfigParser(allow_no_value=None)
    lookup_module_1.cp.optionxform = to_native
    lookup_module_1.cp.readfp(StringIO(u'[global]\nuser = yannig'))
    lookup_module_1.cp.get = lambda x, y: 'yannig' if y == u'user' else ''
    lookup_module_1.cp.items = lambda x: [(u'user', u'yannig'), (u'password', u'pass')]

# Generated at 2022-06-25 10:44:38.439546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 10:44:54.330016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    # default section with default key
    terms = ['']
    variables = dict()
    kwargs = dict()
    result = obj.run(terms, variables, **kwargs)
    assert len(result) == 0
    # default section with several keys
    terms = ['key1 key2']
    variables = dict()
    kwargs = dict()
    result = obj.run(terms, variables, **kwargs)
    assert len(result) == 2
    # section with default key
    terms = ['', 'section']
    variables = dict()
    kwargs = dict()
    result = obj.run(terms, variables, **kwargs)
    assert len(result) == 0
    # section with several keys
    terms = ['key1 key2', 'section']
    variables = dict()

# Generated at 2022-06-25 10:45:04.768742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test string 
    test_input = {
        'terms': ['user'],
        'paramvals': {
            'allow_none': False,
            'case_sensitive': False,
            'default': '',
            'encoding': 'utf-8',
            'file': 'ansible.ini',
            're': True,
            'section': 'global',
            'type': 'ini'
        },
        'variables': {'foo': 'bar'},
        'kwargs': {'bar': 'foo'}
    }

    # Expected result
    expected_result = 'jsmith'

    lookup_module = LookupModule()
    actual_result = lookup_module.run(**test_input)
    assert expected_result == actual_result[0]



# Generated at 2022-06-25 10:45:15.157860
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.read_dict({'section1':{'key1':'value1', 'key2':'value2', 'key3':'value3'}})
    assert lookup_module.get_value('key1', 'section1', 'default', False) == 'value1'
    assert lookup_module.get_value('key2', 'section1', 'default', False) == 'value2'
    assert lookup_module.get_value('key3', 'section1', 'default', False) == 'value3'
    assert lookup_module.get_value('key4', 'section1', 'default', False) == 'default'

# Generated at 2022-06-25 10:45:19.127534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['key_1', 'key_2', 'key_3'], variables=None, file='test.ini', section='section1') == ['value1', 'value2', 'value3']


# Generated at 2022-06-25 10:45:24.161861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialization of variables used into the unit test
    terms = list()
    term_0 = "user"
    terms.append(term_0)
    variables = dict()
    kwargs = dict()
    lookup_module_0 = LookupModule() 
    lookup_module_0.run(terms, variables, **kwargs)
    pass



# Generated at 2022-06-25 10:45:32.455288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    import pytest

    # TODO: Add valid tests
    #__init__.return_value = '/tmp/test_Ansible_test_file'
    #__init__.side_effect = IOError()

    #with pytest.raises(AnsibleLookupError):
    #    lookup_module_0.run(terms=['test'], variables=None, **{'encoding': 'utf-8', 'case_sensitive': 'False', 'default': '', 'allow_no_value': 'False', 're': 'False', 'type': 'ini', 'file': 'ansible.ini', 'section': 'global'})


# Generated at 2022-06-25 10:45:40.026425
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module = LookupModule()

    # Parameters:
    key = 'key1'
    section = 'section1'
    dflt = None
    is_regexp = False

    # Return value:
    ret = lookup_module.get_value(key, section, dflt, is_regexp)
    #assert ret == None


# Generated at 2022-06-25 10:45:48.219686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0.cp = None
    lookup_module_0.set_options({})
    lookup_module_0.get_options()
    lookup_module_0.find_file_in_search_path({}, 'files', 'ansible.ini')
    lookup_module_0.get_value('user', 'global', paramvals['default'], paramvals['re'])
    lookup_module_0.run(terms)


# Generated at 2022-06-25 10:45:56.940998
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    file = """
[integration]
user=Yann

[production]
user=Yann
"""

    lookup_module = LookupModule()

    test_terms = ['user', 'file']
    test_params = ['user', 'file', 'section', 're', 'default']

    # Should raise error
    try:
        lookup_module.run(test_terms, test_params)
        assert False
    except AnsibleOptionsError:
        assert True

    # Should return user
    assert lookup_module.run(['user', 'file'], {'file': 'users.ini', 'type': 'ini', 'section': 'integration'}) == ['Yann', 'users.ini']


# Generated at 2022-06-25 10:46:02.156363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        'key1',
        'key2',
        'file=test.ini',
        'default=value3',
        're=False',
        'section=section1',
    ]
    variables = ''
    ret = lookup_module.run(terms, variables)
    print(ret)
    pass

# Generated at 2022-06-25 10:46:13.791038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    list_0 = [str_0]
    var_0 = lookup_module_0.run(list_0, None)

test_LookupModule_run()

# Generated at 2022-06-25 10:46:16.612164
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    str_1 = 'key1'
    bool_0 = False
    var_0 = lookup_module_0.get_value(str_0, str_1, bool_0, bool_0)
    test_case_0()


# Generated at 2022-06-25 10:46:18.424301
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    str_1 = 'key1'
    bool_1 = False
    var_1 = lookup_get_value(str_1, str_1, bool_1, bool_1)


# Generated at 2022-06-25 10:46:27.011496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = {}
    assert True
    params["file"] = "test.ini"
    params["section"] = "section1"
    params["case_sensitive"] = False
    params["_original_basename"] = "init"
    params["default"] = "no value"
    params["encoding"] = "utf-8"
    params["re"] = False
    params["type"] = "ini"
    params["allow_no_value"] = False

    lookup_module_0 = LookupModule()
    params["_templar"] = Templar()
    str_0 = "section1"
    str_1 = ".*"
    params["_loader"] = DataLoader()
    str_2 = "test.ini"
    str_3 = "global"
    bool_0 = False

# Generated at 2022-06-25 10:46:28.359891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:46:31.368897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'value1'
    terms_0 = ''
    var_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 10:46:34.574039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = 'key1'
    result = lookup_module_0.run(terms)
    assert result == ['value1'], "Wrong value. You can't expect not to have the right value of your own key"


# Generated at 2022-06-25 10:46:43.487030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize
    lookup_module_0 = LookupModule()
    str_0 = 'users.ini'
    str_1 = 'global'
    str_2 = 'user'
    str_3 = 'integration'
    str_4 = 'production'
    str_5 = 'user.name'
    str_6 = 'user.properties'
    str_7 = '.*'
    str_8 = 'section1'
    str_9 = 'test.ini'
    str_10 = 'user'
    str_11 = 'mysql.ini'
    str_12 = 'mysqld'
    dict_0 = dict()
    dict_0['file'] = str_0
    dict_0['section'] = str_1
    dict_0['default'] = str_0

# Generated at 2022-06-25 10:46:47.087341
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    str_1 = 'section'
    bool_0 = False
    bool_1 = False

    # Call the method
    var_return = lookup_module_0.get_value(str_0, str_1, bool_0, bool_1)
    assert var_return == 'value1'



# Generated at 2022-06-25 10:46:49.959770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.get_options()
    lookup_module_0.find_file_in_search_path()
    lookup_module_0.get_value()
    lookup_module_0.run()

# Generated at 2022-06-25 10:47:11.276870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    str_1 = 'key1'
    bool_0 = False
    list_0 = list_get2_index(str_0, int_0, str_1, str_0, bool_0)
    str_2 = 'key1'
    str_3 = 'key1'
    bool_1 = False
    str_4 = ''
    dict_0 = dict_get_value(str_2, str_3, bool_1, str_4)
    str_5 = 'key1'
    str_6 = 'key1'
    bool_2 = False
    str_7 = 'key1'
    str_8 = 'key1'
    bool_3 = True
    str_9 = 'key1'
   

# Generated at 2022-06-25 10:47:23.025392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser()
    str_0 = 'key1'
    str_1 = 'key1=value1'
    list_0 = ['key1']
    str_2 = 'key1'
    str_3 = '9F4Pu'
    str_4 = '4bVFu'
    str_5 = 'key1'
    list_1 = [str_2, str_3, str_4, str_5]
    str_6 = 'value1'
    str_7 = 'tZ5Rm'
    list_2 = [str_6, str_7]
    str_8 = 'key1'
    list_3 = [str_8]
    str_9 = 'value2'
   

# Generated at 2022-06-25 10:47:26.749213
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    str_1 = 'key1'
    bool_0 = False
    bool_1 = False
    var_0 = lookup_get_value(str_0, str_1, bool_0, bool_1)
    test_case_0()


# Generated at 2022-06-25 10:47:28.249413
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    bool_0 = False
    var_0 = lookup_module_0.get_value(str_0, str_0, bool_0, bool_0)



# Generated at 2022-06-25 10:47:35.847209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    dict_0['allow_no_value'] = False
    dict_0['case_sensitive'] = False
    dict_0['section'] = 'section'
    dict_0['type'] = 'ini'
    dict_0['file'] = 'file'
    dict_0['default'] = ''
    dict_0['re'] = False
    dict_0['encoding'] = 'encoding'
    str_0 = 'key1'
    lookup_module_0.run(str_0, dict_0)
    str_1 = 'key1'
    dict_1 = dict()
    dict_1['allow_no_value'] = False
    dict_1['case_sensitive'] = False
    dict_1['section'] = 'section'

# Generated at 2022-06-25 10:47:38.272000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # method call without argument, add a dummy argument if needed
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    bool_0 = False
    if lookup_module_0.run(str_0, bool_0):
        sys.exit(1)

# Generated at 2022-06-25 10:47:47.545943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_0 = 'key1'
    bool_0 = False
    list_0 = [str_0]
    dict_0 = {'file': str_0, 're': bool_0, 'default': str_0, 'type': str_0, 'case_sensitive': bool_0, 'section': str_0}
    p = lookup_module_2.run(list_0, dict_0)
    if p == ['value1']:
        assert True
    else:
        assert False


# Generated at 2022-06-25 10:47:53.981385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test case where there is no exception
    str_0 = 'key1'
    dictionary_0 = {}
    list_0 = [str_0]
    lookup_get_value = lookup_module_0.get_value
    lookup_run = lookup_module_0.run

    if str_0 in dictionary_0:
        lookup_run(list_0, dictionary_0)
        str_0 = 'key1'
        bool_0 = False
        var_0 = lookup_get_value(str_0, str_0, bool_0, bool_0)
        assert var_0

# Test for file lookup_ini_line.py

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:48:01.144874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    bool_0 = False
    str_1 = 'key1=value1'
    bool_1 = True
    str_2 = 'key1'
    bool_2 = True
    str_3 = 'key1=value1'
    bool_3 = False
    str_4 = 'key1'
    bool_4 = True
    str_5 = 'key1=value1'
    bool_5 = False
    str_6 = 'key1'
    bool_6 = True
    str_7 = 'key1=value1'
    bool_7 = False
    str_8 = 'key1'
    bool_8 = True
    str_9 = 'key1=value1'
    bool_9 = False
    str

# Generated at 2022-06-25 10:48:07.811032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = ''
    dict_0 = dict()
    list_0 = []
    list_1 = lookup_module_1.run(list_0, dict_0)
    bool_0 = False
    list_2 = []
    dict_1 = dict()
    list_3 = lookup_module_1.run(list_2, dict_1)


# Generated at 2022-06-25 10:48:40.337826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    list_0 = [str_0]
    dict_0 = { str_0: str_0 }
    abc_0 = lookup_module_0.run(list_0, dict_0)
    assert abc_0 is None
    

# Generated at 2022-06-25 10:48:47.390260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'key1'
    list_0 = []
    list_0.append(str_1)
    str_2 = 'key2'
    list_0.append(str_2)
    str_3 = 'key3'
    list_0.append(str_3)
    str_4 = 'key4'
    list_0.append(str_4)
    str_5 = 'key5'
    list_0.append(str_5)
    bool_0 = False
    bool_1 = True
    var_0 = lookup_module_1.run(list_0, bool_0, bool_0, bool_1)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule

# Generated at 2022-06-25 10:48:50.014567
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    str_1 = 'section'
    bool_0 = False
    bool_1 = False
    var_0 = lookup_get_value(lookup_module_0, str_0, str_1, str_0, bool_0, bool_1)



# Generated at 2022-06-25 10:48:55.566948
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'key1'
    str_1 = 'section'
    bool_0 = False
    bool_1 = True
    var_0 = lookup_module_0.get_value(str_0, str_1, bool_0, bool_1)


# Generated at 2022-06-25 10:49:05.261064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._get_plugin_options = lambda *arg, **kwargs: None
    lookup_module_0._load_name = lambda *arg, **kwargs: None
    lookup_module_0.get_option = lambda *arg, **kwargs: None
    lookup_module_0.set_options = lambda *arg, **kwargs: None
    lookup_module_0._check_file_for_escaping = lambda *arg, **kwargs: None
    lookup_module_0.find_file_in_search_path = lambda *arg, **kwargs: None
    lookup_module_0._get_file_contents = lambda *arg, **kwargs: None
    lookup_module_0._loader = None

# Generated at 2022-06-25 10:49:18.658216
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Verify list
    str_0 = 'file'
    str_1 = 'test.ini'
    str_2 = 'section'
    str_3 = 'global'
    str_4 = 'type'
    str_5 = 'ini'
    str_6 = 'encoding'
    str_7 = 'utf-8'
    str_8 = 'default'
    str_9 = ''
    str_10 = 'case_sensitive'
    bool_0 = False
    str_11 = 'allow_no_value'
    bool_1 = False
    str_12 = '_ansible_lookup_plugin'
    str_13 = 'ini'
    term_0 = ['key1', 'key2']

# Generated at 2022-06-25 10:49:28.963496
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = []
    kwargs_0 = {'a': '1', 'b': '2', 'c': '3'}
    str_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert str_0 == []

    lookup_module_1 = LookupModule()
    terms_1 = ['b', 'a']
    variables_1 = []
    kwargs_1 = {'a': '1', 'b': '2', 'c': '3'}
    str_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert str_1 == ['2', '1']


# Generated at 2022-06-25 10:49:34.061615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'lookup_1'
    list_0 = [str_0]
    dict_0 = {str_0:str_0}
    list_1 = lookup_module_0.run(list_0, dict_0)
    assert len(list_1) == 1 and list_1[0] == str_0

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:49:37.417505
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('test_var', {'test_var': 'test_value'})
    lookup_module_0.get_value('test_var', 'test_section', 'test_default', True)
    test_case_0()


# Generated at 2022-06-25 10:49:46.195589
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    str_1 = 'ini'
    lookup_module_1.cp = ConfigParser.ConfigParser()
    str_2 = 'section1'
    str_3 = 'key1'
    bool_1 = False
    var_1 = lookup_module_1.cp.items(str_2)
    return_value_1 = [v for k, v in var_1 if re.match(str_3, k)]
    eq_1 = return_value_1 == None
    eq_2 = lookup_module_1.cp.get(str_2, str_3) == None
    eq_3 = lookup_module_1.get_value(str_1, str_2, str_3, bool_1) == None
    return eq_1, eq_2, eq_3

# Generated at 2022-06-25 10:51:02.551101
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Setting up variables
    lookup_module_1 = LookupModule()
    str_0 = "c"
    str_1 = "b"
    str_2 = "a"
    str_3 = "a"
    str_4 = "a"
    int_1 = 1
    list_1 = []
    dict_0 = {"str_3": str_3, "str_4": str_4, "list_1": list_1}
    str_5 = "a"
    dict_1 = {
        str_5: dict_0
    }
    str_6 = "a"
    dict_2 = {
        str_6: dict_1
    }

    # Getting results

# Generated at 2022-06-25 10:51:06.599515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = ['user', 'password']
    variables_2 = 'foo'
    lookup_module_1.run(terms_2, variables_2)

# Generated at 2022-06-25 10:51:08.389496
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_get_value(bool_0, bool_0, bool_0, bool_0)



# Generated at 2022-06-25 10:51:19.034940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    bool_0 = False
    bool_1 = True
    dict_0 = dict()
    dict_1 = dict()
    dict_1['type'] = 'properties'
    dict_1['file'] = 'user.properties'
    dict_1['default'] = 'default'
    dict_1['case_sensitive'] = True
    dict_1['allow_no_value'] = True
    dict_1['encoding'] = 'utf-8'
    dict_2 = dict()
    dict_2['type'] = 'ini'
    dict_2['file'] = 'users.ini'
    dict_2['section'] = 'section'
    dict_2['default'] = 'default'
    dict_2['case_sensitive'] = True

# Generated at 2022-06-25 10:51:23.131695
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_ = LookupModule()
    bool_ = False
    var = lookup_get_value(bool_, bool_, bool_, bool_)



# Generated at 2022-06-25 10:51:31.025173
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Template context 'section' is defined
    try:
        test_case_0()
        assert False
    except UndefinedError:
        assert True
    # Template context 'key' is defined
    try:
        test_case_0()
        assert False
    except UndefinedError:
        assert True
    # Template context 'dflt' is defined
    try:
        test_case_0()
        assert False
    except UndefinedError:
        assert True
    # Template context 'is_regexp' is defined
    try:
        test_case_0()
        assert False
    except UndefinedError:
        assert True


# Generated at 2022-06-25 10:51:33.979079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'x'
    dict_0 = dict({str_0: str_0})
    list_0 = [str_0]
    list_1 = lookup_module_0.run(list_0, dict_0)

    assert list_1 == [], "Expected [], but got: %r" % list_1


# Generated at 2022-06-25 10:51:41.314122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # "No section '{section}' in {file}"
    assert lookup_module_0.run() == "No section '{section}' in {file}"



# Generated at 2022-06-25 10:51:46.445966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:51:53.518723
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    def wrapper(lookup_module, key_0, section_0, dflt_0, is_regexp_0, lookup_module_class_0=LookupModule, lookup_module_instance_0=None, key_1=None, section_1=None, dflt_1=None, is_regexp_1=None):
        if lookup_module_instance_0 is None:
            lookup_module_instance_0 = lookup_module
        if key_1 is None:
            key_1 = key_0
        if section_1 is None:
            section_1 = section_0
        if dflt_1 is None:
            dflt_1 = dflt_0
        if is_regexp_1 is None:
            is_regexp_1 = is_regexp_0
        lookup_module