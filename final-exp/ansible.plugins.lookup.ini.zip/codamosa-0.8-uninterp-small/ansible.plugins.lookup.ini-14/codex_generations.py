

# Generated at 2022-06-25 10:43:24.163108
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    print('Testing LookupModule - Method get_value')
    arg_0 = 'key_3'
    arg_1 = 'section_5'
    arg_2 = 'default_0'
    arg_3 = False
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser()
    # Call get_value
    try:
        ret = lookup_module_0.get_value(arg_0, arg_1, arg_2, arg_3)
    except Exception as e:
        print(e)
    # Check return value
    assert ret == 'default_0'


# Generated at 2022-06-25 10:43:28.100248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == [], 'Expected [], but got: ' + lookup_module_0.run()


# Generated at 2022-06-25 10:43:35.205685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "']]'&~>|{gt)"
    int_0 = 9
    dict_0 = {}
    dict_0['file'] = str_0
    dict_0['section'] = str_0
    dict_0['default'] = int_0
    dict_0['re'] = int_0

    lookup_module_0 = LookupModule(**dict_0)
    str_1 = 'JyT&T\x0bzB\tR'
    result = lookup_module_0.run(str_1)

    assert result == dict_0['default']

# Test for parsing an INI file

# Generated at 2022-06-25 10:43:46.809505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ';%c<OwRWp6U5'
    str_1 = '#(L/p:e+/%/<'
    str_2 = 'N!W2+8CYL}d]'
    str_3 = 'W)XI53=?Td2}M'
    list_1 = []
    list_1.append(str_0)
    list_1.append(str_1)
    list_1.append(str_2)
    list_1.append(str_3)
    dict_1 = {str_1: str_0, str_2: str_3}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_1, **dict_1)


# Generated at 2022-06-25 10:43:58.922171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(**{'run_add_file_common_args': False, '_templar': None, 'p_t': [], 'basedir': 'D'})
    lookup_module_0.run(terms=['M'], variables={'Q': 'V', 'P': 'U'}, type='properties', encoding='iso-8859-1', allow_no_value=True, case_sensitive=True)
    lookup_module_0.run(terms=['U', 'W'], variables=None, type='properties', re=True, encoding='iso-8859-1', allow_no_value=True, case_sensitive=True)

# Generated at 2022-06-25 10:44:00.928633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add tests for method run of class LookupModule
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:44:05.433254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    # TODO: explore other test values
    terms = 'terms'
    obj.run(terms)

# Generated at 2022-06-25 10:44:07.828398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}
    run_result = LookupModule().run(terms, variables)
    assert run_result is None, "AnsibleLookupError not raised as expected"

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:44:17.982615
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 's@iL!N3'
    list_0 = [str_0, str_0]
    list_1 = [str_0, str_0]
    list_2 = [str_0, str_0]
    str_1 = 'bac9e7423c5bbf1a12f8a54e49d36a20'
    str_2 = 'test_value'
    str_3 = 'access_key'
    str_4 = 'default_key'
    str_5 = 'secret_key'
    bool_0 = True
    list_3 = [str_3, str_5]
    list_4 = [str_3, str_4]
    list_5 = [str_1, str_1]

# Generated at 2022-06-25 10:44:25.681343
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_2 = LookupModule()
    str_0 = 'u/|..q;4K'
    str_1 = 'wLp]8P?Y'
    str_2 = '5@5c%K;a'
    str_3 = 'kcmw$S'
    str_4 = '9(x)aD4'
    str_5 = '6#kp6'
    list_0 = [str_2, str_2, '5', str_0, str_5]

# Generated at 2022-06-25 10:44:43.445354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # INPUT
    #file_name_0 = "ansible.ini"
    #file_name_0 = "yop.ini"
    #file_name_0 = "nop.ini"
    #file_name_0 = "content.ini"
    #file_name_0 = "multi.ini"
    #file_name_0 = "fail.ini"
    #file_name_0 = "list.ini"
    #file_name_0 = "empty.ini"
    #file_name_0 = "multi.ini"
    file_name_0 = "multi_empty.ini"
    #file_name_0 = "multi_default.ini"
    #file_name_0 = "multi_re.ini"
    #file_name_0 = "multi_list.ini"
    #

# Generated at 2022-06-25 10:44:53.694220
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.get_value(key='', section='', dflt='', is_regexp=True) == [], "Test case for method get_value of class LookupModule failed"
    assert lookup_module_0.get_value(key='', section='', dflt='', is_regexp=False) == None, "Test case for method get_value of class LookupModule failed"
    assert lookup_module_0.get_value(key='', section='', dflt='', is_regexp=True) == [], "Test case for method get_value of class LookupModule failed"

# Generated at 2022-06-25 10:45:04.339108
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()
    # case1: Find value of a key that is in the section
    testClass = LookupModule()
    testIni = "[section1]\nkey = value\nkey2 = value2"
    f = StringIO()
    f.write(testIni)
    f.seek(0, os.SEEK_SET)
    lookup_module_1.cp.readfp(f)
    lookup_module_1.cp.items("section1")
    result1 = testClass.get_value("key", "section1", "", False)
    assert result1 == "value"

    # case2: Find value of a key that is not in the section
    testClass = LookupModule()
    testIni

# Generated at 2022-06-25 10:45:06.022396
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    assert False


# Generated at 2022-06-25 10:45:13.394108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add specific tests for file format
    # TODO: Add specific tests using regexp
    lookup_module_0 = LookupModule()

    # TODO: Add specific tests using regexp
    test_terms_0 = ['yannig']
    test_vars_0 = {}
    test_kwargs_0 = {}
    test_expected_0 = ['mail-y.perre']
    test_result_0 = lookup_module_0.run(test_terms_0, test_vars_0, **test_kwargs_0)
    assert test_result_0 == test_expected_0

# Generated at 2022-06-25 10:45:23.704678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fp = open("test_file.ini", "r")
    config = StringIO()
    config.write(fp.read())
    config.seek(0, os.SEEK_SET)
    config.write("\n")
    config.seek(0, os.SEEK_SET)
    fp.close()

    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module_1.cp.readfp(config)
    terms_1 = ['user', '*']
    kwargs = {'type': 'ini', 'section': 'mysqld', 're': True}
    variables = {'lookup_file_search_paths': ['.']}
    returned_values_1 = lookup_module_1

# Generated at 2022-06-25 10:45:31.581930
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create new instance of class LookupModule
    lookup_module_1 = LookupModule()

    # Parametrize the method get_value
    user_0 = "user_0"
    global_0 = "global_0"
    key_0 = "key_0"
    default_0 = "default_0"
    is_regexp_0 = True
    assert lookup_module_1.get_value(key_0, global_0, default_0, is_regexp_0) is None
    # Changed global_0
    global_0 = "user"
    assert lookup_module_1.get_value(key_0, global_0, default_0, is_regexp_0) is None



# Generated at 2022-06-25 10:45:36.947951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  terms = ['user']
  variables = ''
  kwargs = {'allow_none': False, 'allow_no_value': True, 'encoding': 'ascii', 'file': 'mysql.ini', 'section': 'mysqld', 'case_sensitive': False, 'default': '', 'type': 'ini', 're': False}
  ret = lookup_module.run(terms, variables, **kwargs)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:45:44.096610
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    TEST_DIR = os.path.join(os.path.dirname(__file__), 'lookup_test')
    td = lambda fn: os.path.join(TEST_DIR, fn)

    TEST_FILE = td('test.ini')

    # Keys to lookup
    TERMS = [
        'DB_PORT',
        'DB_USER',
        'DB_SERVER',
        'DB_TYPE',
        'mydb',
        'not_a_key',
        'missing_section',
        '.ini',
    ]

    # Test default configuration
    # TODO: handle search path

# Generated at 2022-06-25 10:45:51.661759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test method run of class LookupModule
    '''
    lookup_module = LookupModule()

    # Test with a dictionary as params and a float as term
    terms = [float()]
    variables = {'lookup_plugin_pass': 'this is a test'}

    # run test case
    try:
        lookup_module.run(terms, variables=variables, **{'type': 'ini', 'content': 'test', 'section': 'test', 'file': 'test.ini'})
    except AnsibleOptionsError:
        pass

    # Test with a dictionary as params and a string as term
    terms = [str()]
    variables = {'lookup_plugin_pass': 'this is a test'}

    # init return value expected
    ret_exp = []

    # run test case
    ret

# Generated at 2022-06-25 10:46:03.062903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 0
    str_0 = "Hb2QD7z/t=4hmV7]"
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0)
    assert var_0 == '1'


# Generated at 2022-06-25 10:46:08.722157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_2 = 'M+6U\x0b\x1e\x15\x1b\x0e.\x19\x13\x1a\x1c\x0b\x0b\x1b\x06\x03\x14\n'
    str_3 = 'xND(=bky.%4\t!j'
    str_4 = 'H=%K\x05\x0f\x1e\x06\x08\x05\x0c\x1b\x05\x0b\x0c\x0e\x06\x06\x14'

# Generated at 2022-06-25 10:46:13.884401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # (path, terms)
  lookup_module_0 = LookupModule()
  lookup_module_0.run(path1)
  lookup_module_0.run(path2)


# Generated at 2022-06-25 10:46:17.357200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # since LookupModule is the top class in the inheritance tree the base class
    # Initialize variables
    ret = []
    paramvals = {}
    terms = ['']
    lookup_plugin = LookupModule()
    # Invoke the run method on the LookupModule
    var_0 = lookup_plugin.run(terms, paramvals)
    assert var_0 == ret


# Generated at 2022-06-25 10:46:26.988225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '8`}w:rQ\\k'
    var_0 = lookup_run(str_0)
    # Test lookup run with bad encoding of input data
    str_1 = 'U3nk(8M?W9'
    var_1 = lookup_run(str_1)
    # Test lookup run with bad encoding of input data
    str_2 = 'U3nk(8M?W9'
    var_2 = lookup_run(str_2)
    # Test lookup run with bad encoding of input data
    str_3 = 'U3nk(8M?W9'
    var_3 = lookup_run(str_3)
    # Test lookup run with bad encoding of input data

# Generated at 2022-06-25 10:46:32.030249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    var_2 = lookup_run(lookup_module_2)

if __name__ == '__main__':
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    try:
        import __main__ as main
    except ImportError:
        import main
    builtins._ = None

# Generated at 2022-06-25 10:46:39.736241
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    key = 'key'
    section = 'section'
    dflt = '__default__'
    is_regexp = False

    # If a configparser.NoOptionError is raised, then __default__ value is returned
    cp = configparser.ConfigParser()
    cp.add_section(section)
    lm = LookupModule()
    lm.cp = cp
    value = lm.get_value(key, section, dflt, is_regexp)
    assert value == dflt

    # If a configparser.NoSectionError is raised, then __default__ value is returned
    cp = configparser.ConfigParser()
    lm = LookupModule()
    lm.cp = cp
    value = lm.get_value(key, section, dflt, is_regexp)
    assert value == df

# Generated at 2022-06-25 10:46:46.876692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'fc?xv>%\x1a\x00#l'
    lookup_module_0 = LookupModule()
    var_0 = _parse_params(str_0, None)
    str_1 = 'c%\rY@n($'
    var_1 = _parse_params(str_1, None)
    lookup_module_1 = LookupModule()
    var_2 = lookup_run()

# Generated at 2022-06-25 10:46:49.789005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms)
    # TODO: test if any exception is thrown
    # assertEqual(expected, lookup_module_1.run(terms))


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:46:51.693521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'a,b,c'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0)
    print(var_0)


# Generated at 2022-06-25 10:47:13.383176
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: re-write tests as test_LookupModule and test_LookupModule_run
    # Need to find a way to check that file is closed by plugin.

    lookup_module_1 = LookupModule()
    str_1 = '2sZtR'
    str_2 = 'mono'
    lookup_module_3 = LookupModule()
    str_3 = 'C8A:~\x06\x04\x1b'
    lookup_module_4 = LookupModule()
    str_4 = 'My'
    lookup_module_5 = LookupModule()
    str_5 = 'n*9\x15\xf3\x86'
    lookup_module_6 = LookupModule()
    str_6 = 'z`9\x0e\xb3\x80'
    str

# Generated at 2022-06-25 10:47:19.903082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try_value = None
    lookup_module_0 = LookupModule()
    try:
        var_0 = lookup_module_0.run()
        var_1 = lookup_module_0.run()
        try_value = (var_0, var_1)
    except Exception as e:
        _error = e

    assert try_value is None

# Generated at 2022-06-25 10:47:22.988562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'B\x042#[\x1e\x17\x00\x00'
    var_1 = lookup_run(str_1)


# Generated at 2022-06-25 10:47:28.502206
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    key_0 = 'pk*  |\x83b'
    section_0 = '\x81\x82\x83\x84\x85\x86'
    dflt_0 = 'rY\r'
    is_regexp_0 = 0
    var_0 = lookup_module_0.get_value(key_0, section_0, dflt_0, is_regexp_0)
    assert var_0 is None


# Generated at 2022-06-25 10:47:30.827021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '&QMy9],w}C\r'
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:47:36.803152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    section_0 = '[%$A9/7dz"=]'
    defaults_0 = {'case_sensitive': True, 'section': section_0, 'default': '', 'encoding': 'utf-8', 'case_sensitive': False, 'type': 'ini', 'file': 'ansible.ini'}
    # Define the parameters that would be passed to the module
    terms_0 = ['test_3']
    var_0 = terms_0
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0, defaults_0)
    print(var_1)


# Generated at 2022-06-25 10:47:40.762820
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = '?,x;,'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.get_value(str_0, lookup_module_0, str_0, str_0)
    # Convert to str
    var_0 = str(var_0)
    # Assert result is '', not None
    assert '' == var_0


# Generated at 2022-06-25 10:47:43.850512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '&QMy9],w}C\r'
    lookup_module_0 = LookupModule()
    str_1 = lookup_module_0.run(str_0)
    assert repr(str_1) == repr('')


# Generated at 2022-06-25 10:47:52.000030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ';PJ@^5r(B6U&Y#'
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(str_0)
    str_1 = '~d?U'
    var_2 = lookup_run(str_1)
    int_0 = -431425278
    var_3 = lookup_run(int_0)
    str_2 = '!x.zTuT0'
    var_4 = lookup_run(str_2)
    str_3 = 'F0a{1'
    var_5 = lookup_run(str_3)
    str_4 = ')'
    var_6 = lookup_run(str_4)
    str_5 = 't'
    var_7 = lookup_run(str_5)

# Generated at 2022-06-25 10:47:59.849793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no scope
    lookup_module_0 = LookupModule()
    str_0 = 'key5'
    parameters_0 = {
        '_ansible_diff': None,
        '_ansible_vdiff': True,
        '_ansible_no_log': False,
        'default': '',
        'encoding': 'utf-8',
        'file': 'ansible.ini',
        're': False,
        'section': 'global',
        'type': 'ini',
        '_ansible_verbosity': 3
    }

# Generated at 2022-06-25 10:48:40.366507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals_0 = {'allow_no_value': 'allow_none', 'case_sensitive': 'False', 're': 'False', 'default': '', 'encoding': 'utf-8', 'file': 'ansible.ini', 'section': 'global', 'type': 'ini'}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables, direct=paramvals_0)
    paramvals_1 = lookup_module_0.get_options()
    lookup_module_0.cp = configparser.ConfigParser(allow_no_value=paramvals_1.get('allow_no_value', paramvals_1.get('allow_none')))
    if paramvals_1['case_sensitive']:
        lookup_module_0.cp.optionxform = to

# Generated at 2022-06-25 10:48:42.331358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test: test_LookupModule_run')


# Generated at 2022-06-25 10:48:45.680159
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = '&QMy9],w}C\r'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:48:54.487055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '#w2^R&\n'
    str_1 = '_;M7T}T$^O#.\nd@'
    # str_1 = None
    str_2 = 'dS<a\x00\x0c\x17ztc$h4J\x15\x0e\x03\x0c2/\x1f'
    # str_2 = None
    str_3 = '^3\x15\x1fj+G<a\x00\x0c\x17ztc$h4J\x15\x0e\x03\x0c2/\x1f'
    # str_3 = None
    str_4 = '}C\r'
    # str_4 = None

# Generated at 2022-06-25 10:48:59.308205
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    obj_0 = LookupModule()
    str_0 = '$Q{E^[%cj5 -Xx'
    str_1 = '~ha{e&k'
    str_2 = ':A$G&W,'
    int_0 = 0
    ret = obj_0.get_value(str_0, str_1, str_2, int_0)
    assert ret == ':A$G&W,'


# Generated at 2022-06-25 10:49:02.282971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ';'
    str_1 = '!=H'
    lookup_module_0 = LookupModule()
    return [lookup_module_0.run(str_0), lookup_module_0.run(str_1)]


# main

# Generated at 2022-06-25 10:49:07.732799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = 'test_terms'
    variables_0 = 'test_variables'
    var_0 = lookup_module_0.run(term_0, variables_0)


# Generated at 2022-06-25 10:49:12.117638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '192.168.0.1'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0)
    #assert var_0 == '192.168.0.1'
    print(var_0)



# Generated at 2022-06-25 10:49:24.234186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_1 = 'key=VHUToCQKZVmzMOR5\nPkRwR[y,\x00\x0c\x0c\x0c|\x0c|\x0c\x0c\x0c'
    variables_1 = 'BtF,X9C\r\r'
    options_1 = {'allow_none': False, 'encoding': 'utf-8', 're': False, 'case_sensitive': False, 'default': '', 'section': 'global', 'type': 'ini', 'file': 'ansible.ini'}
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=variables_1, direct=options_1)
    lookup_module_1.get_options()


# Generated at 2022-06-25 10:49:29.336927
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    section_0 = '\x13\x1c\x02\x1a6\x02\x00'
    dflt_0 = 'vY\x12\x02\x00'
    is_regexp_0 = '\x11\x03\x00\x15\x1c\x02\x11\x1b\x02\x00\x12\x0c\x0e\x05\x1c\x02\x07\x19\x02\x00'
    key_0 = '\x13\x1c\x02\x1a6\x02\x00'
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:50:48.757501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    str_0 = '/E8xr>3F2Y0AOF.'
    dict_0 = dict()
    dict_0['default'] = 'K_>8\x0b.\x1c\x1d\x01'
    dict_0['encoding'] = '5;<!'
    dict_0['type'] = 'properties'
    dict_0['file'] = 'I[)@P>\x1dWnL'
    dict_0['section'] = '(T\x1bM\\'
    dict_0['re'] = False
    dict_0['case_sensitive'] = True
    dict_0['allow_no_value'] = True
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:50:57.049551
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 'Q6YHk6Oj9\r'

    # Test case for type 'ini'
    config_parser_0 = configparser.ConfigParser()
    lookup_module_0 = LookupModule()
    config_parser_0.add_section(str_0)
    config_parser_0.set(str_0, str_0, str_0)
    lookup_module_0.cp = config_parser_0
    var_0 = lookup_module_0.get_value(str_0, str_0, str_0, False)

    # Test case for type 'regexp'
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.get_value(str_0, str_0, str_0, True)


# Generated at 2022-06-25 10:51:04.673953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'eZD'
    variables = None
    paramvals = {'allow_no_value': 'False', 'type': 'ini', 'file': 'ansible.ini', 'section': 'global', 'case_sensitive': 'False', 're': 'False', 'encoding': 'utf-8', 'default': ''}
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(term, variables, **paramvals)
    assert len(var_1) == 1
    assert var_1[0] == 'G?l#J'


# Generated at 2022-06-25 10:51:13.126816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    paramvals_1 = {'file': 'file_0', 'type': 'propertiess', 'case_sensitive': True,'section': 'section_0', 'allow_no_value': False}
    path_1 = '/path/to/file_0'
    encoding_1 = 'utf-8'
    contents_1 = 'str_0'
    contents_1 = 'str_1'
    contents_1 = 'str_2'
    config_1 = StringIO()
    var_1 = lookup_module_1.run(paramvals_1)


# Generated at 2022-06-25 10:51:23.686040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = abs(-1)
    str_0 = 'q'
    int_1 = random.randint(0, 10)
    list_0 = []
    list_0.append(int_1)
    list_0.append(int_1)
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_0)

# Generated at 2022-06-25 10:51:30.467564
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    config = configparser.ConfigParser(allow_no_value=paramvals.get('allow_no_value', paramvals.get('allow_none')))
    if paramvals['case_sensitive']:
        config.optionxform = to_native

    path = self.find_file_in_search_path(variables, 'files', paramvals['file'])

    # Create StringIO later used to parse ini
    config = StringIO()
    # Special case for java properties
    if paramvals['type'] == "properties":
        config.write(u'[java_properties]\n')
        paramvals['section'] = 'java_properties'

    # Open file using encoding
    contents, show_data = self._loader._get_file_contents(path)

# Generated at 2022-06-25 10:51:34.910897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("LookupModule.run")
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:51:44.512879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    ret_val_0 = LookupModule.run('p')
    assert ret_val_0 == '0~A%c;'
    # Test case 2:
    ret_val_2 = LookupModule.run('p', 'K;p[F')
    assert ret_val_2 == '%c'
    # Test case 3:
    ret_val_3 = LookupModule.run('p', '%c', 'K;p[F')
    assert ret_val_3 == '%c'
    # Test case 4:
    ret_val_4 = LookupModule.run('p', 'K;p[F', ']r\'[B')
    assert ret_val_4 == '%c'
    # Test case 5:
    ret_val_5 = LookupModule.run

# Generated at 2022-06-25 10:51:48.875153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 10:51:51.494390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize parameter term= and variables=
    str_1 = '  '
    str_0 = ''
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0)
