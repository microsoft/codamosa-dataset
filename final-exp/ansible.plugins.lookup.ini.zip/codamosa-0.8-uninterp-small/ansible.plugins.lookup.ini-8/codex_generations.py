

# Generated at 2022-06-25 10:43:18.343610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 10:43:22.537603
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.get_value('key1', 'section', '', False) == 'value1'


# Generated at 2022-06-25 10:43:33.215195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    x = lookup_module.run(terms=['key1=value1', 'section2', 'key2'], variables={}, allow_no_value=True, file='ansible.ini', section='section1', re=True, type='ini')
    assert x == ['value1', 'value2']



# Generated at 2022-06-25 10:43:40.176349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'ssh_port',
    ]
    variables_0 = {
        'ansible_check_mode': True,
        'ansible_connection': 'network_cli',
        'ansible_ssh_common_args': '',
        'ansible_ssh_port': 22,
        'module_defaults': [('DEFAULT_COMMAND_TIMEOUT', '1')],
    }

    kwargs_0 = {
        'allow_empty': True,
        'case_sensitive': False,
        'default': '',
        'encoding': 'utf-8',
        'file': 'ansible.ini',
        'section': 'global',
        'type': 'ini',
    }

    ret_0 = lookup_module_0

# Generated at 2022-06-25 10:43:48.699392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Test 1: test with type as "ini"
    # Expected result: No error
    test_lookup_module_run_1 = lookup_module_1.run(terms=[{'key': 'user1', 'section': 'section1', 'file': 'test.ini', 'dflt': 'Default', 'is_regexp': False}])

    # Test 2: test with type as "properties"
    # Expected result: No error
    test_lookup_module_run_2 = lookup_module_1.run(terms=[{'key': 'user1', 'section': 'java_properties', 'file': 'test.properties', 'dflt': 'Default', 'is_regexp': False}])

    # Test 3: test with type as "properties" and config file not

# Generated at 2022-06-25 10:43:58.348359
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    # Case 1, regexp = True
    key_1 = 'user'
    section_1 = 'integration'
    dflt_1 = ''
    is_regexp_1 = True
    ret_1 = lookup_module_1.get_value(key_1, section_1, dflt_1, is_regexp_1)
    assert ret_1 == 'yannig@localhost'
    # Case 2, regexp = False
    key_2 = 'user'
    section_2 = 'integration'
    dflt_2 = ''
    is_regexp_2 = False
    ret_2 = lookup_module_1.get_value(key_2, section_2, dflt_2, is_regexp_2)
    assert ret

# Generated at 2022-06-25 10:44:10.124996
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser(allow_no_value=True)

# Generated at 2022-06-25 10:44:17.536436
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Case 0: Key is a regexp
    config = u"""
[section1]
key1 = 5
key2 = 6
key3 = 7
        """
    cp = configparser.ConfigParser()
    cp.readfp(StringIO(config))
    lookup_module_0 = lookup_module(cp)
    assert lookup_module_0.get_value('key[0-9]', 'section1', '', True) == ['5', '6', '7']
    # Case 1: Key is not a regexp
    assert lookup_module_0.get_value('key2', 'section1', '', False) == '6'
    # Case 2: Key is not present in the file
    assert lookup_module_0.get_value('key0', 'section1', '', False) == ''


test_case_0

# Generated at 2022-06-25 10:44:23.099152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    lookup_module_2 = LookupModule()
    paramvals = {}
    paramvals['type'] = 'ini'
    paramvals['file'] = 'ansible.ini'
    paramvals['section'] = 'global'
    paramvals['re'] = False
    paramvals['encoding'] = 'utf-8'
    paramvals['default'] = ''
    paramvals['case_sensitive'] = False
    terms = ['user']
    assert( lookup_module_2.run(terms, paramvals) == ['root'] )

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:44:31.032060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = MockLoader()

    # Run ansible command with the given parameters
    ansible_command_args = [
        'ansible',
        'host0',
        '-m',
        'debug',
        '-a',
        'User in integration is {{ lookup(\'ini\', \'user\', section=\'integration\', file=\'users.ini\') }}'
    ]
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), './ansible_command_output')
    ansible_command = subprocess.Popen(ansible_command_args, stdout=subprocess.PIPE)

# Generated at 2022-06-25 10:44:39.582108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    float_0 = 1647.9
    var_0 = lookup_module.run(float_0)


# Generated at 2022-06-25 10:44:41.033806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:44:50.288222
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Return a list of key-value pairs (key1, value1, .... , keyn, valuen)
    # These are the key-value pairs retrieved from ini file
    values = run()

    # Return the look-up key which is being searched in the given ini file
    # The value of this key is being looked-up
    key = values[0]

    # Return the value of key
    # The searched value
    value = values[1]

    # Assert if value is equal to expected value
    # If it is not then a test failure exists
    assert value == expected_value



# Generated at 2022-06-25 10:44:51.777652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = lookup_run(False)
    assert len(var_0) == 2


# Generated at 2022-06-25 10:44:56.149437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    from ansible.cli.galaxy.user import User
    from ansible.module_utils._text import to_text
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    str_0 = to_text(float_0)
    terms_0 = [str_0]
    variables_0 = User()

    # Act
    ret_0 = lookup_module_0.run(terms_0, variables_0)

    # Assert
    #assert ret_0 == None



# Generated at 2022-06-25 10:44:58.887671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options()
    paramvals = {'re': False, 'default': '', 'type': 'ini', 'file': 'ansible.ini', 'encoding': 'utf-8', 'case_sensitive': False, 'allow_no_value': False}
    term = 'section.key'
    terms = [term]
    lookup_module.run(terms, paramvals)


# Generated at 2022-06-25 10:45:05.196359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    var_0 = lookup_module_0.run(float_0)
    assert var_0 == lookup_run(float_0)


# Generated at 2022-06-25 10:45:07.319382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 10:45:12.390816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    str_0 = 'config.ini'
    str_1 = 'global'
    str_2 = 'false'
    str_3 = 'utf-8'
    float_0 = 22.6
    bool_0 = lookup_run(terms_0, str_0, str_1, str_2, str_3, float_0)


# Generated at 2022-06-25 10:45:15.286789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    var_0 = lookup_run(float_0)
    var_1 = lookup_run(float_0)


# Generated at 2022-06-25 10:45:32.143275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9

    var_0 = lookup_module_0.run(float_0)
    print(var_0)

# Generated at 2022-06-25 10:45:40.423625
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    kwargs_0 = {}
    lookup_module_0 = LookupModule(**kwargs_0)
    section_0 = var_0
    key_0 = var_1
    dflt_0 = var_2
    is_regexp_0 = False
    var_3 = lookup_module_0.get_value(key_0, section_0, dflt_0, is_regexp_0)


# Generated at 2022-06-25 10:45:45.022947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 10:45:51.183012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["test=test value", "test2=test2 value"], {"test": "test value", "test2": "test2 value"}) is None

# Generated at 2022-06-25 10:46:01.882908
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Declare string var with value 'file.properties'
    string_var = 'file.properties'

    # Create an instance of class LookupModule called lookup_module_0
    lookup_module_0 = LookupModule()

    # Call method run of class LookupModule with parameters string_var and other arguments
    lookup_module_0.run(string_var)

    # Assert method run of class LookupModule has been called once
    assert lookup_module_0.run.call_count == 1

    # Assert method find_file_in_search_path of class LookupBase has been called once
    assert lookup_module_0.find_file_in_search_path.call_count == 1

    # Assert method _get_file_contents of class DataLoader has been called once
    assert lookup_module_0._loader._get

# Generated at 2022-06-25 10:46:04.607763
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    float_0 = float('inf')
    float_1 = float('inf')
    int_0 = lookup_module_0.get_value(float_0, float_1, 80.5, True)


# Generated at 2022-06-25 10:46:17.127596
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    int_0 = 2795
    int_1 = 2950
    int_2 = 2859
    int_3 = 2997
    int_4 = 2967
    int_5 = 3174
    int_6 = 2568
    str_0 = '66'
    str_1 = '67'
    str_2 = '68'
    str_3 = '69'
    str_4 = '70'
    str_5 = '71'
    str_6 = '49'
    str_7 = '50'
    str_8 = '51'
    str_9 = '52'
    str_10 = '53'
    str_11 = '54'
    str_12 = '55'
    str_13 = '56'

# Generated at 2022-06-25 10:46:25.235918
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cfg = configparser.ConfigParser()
    section = "default"
    config = StringIO()
    cfg.add_section(section)
    cfg.set(section, "foo", "bar")
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = cfg
    key = "foo"
    dflt = ""
    is_regexp = False

    var_return = lookup_module_0.get_value(key, section, dflt, is_regexp)
    assert var_return == "bar"


# Generated at 2022-06-25 10:46:32.249214
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    float_0 = 9451.0
    float_1 = 8667.0
    float_2 = 815.0
    str_0 = lookup_module_1.get_value(float_0, float_1, float_2, str_0)
    test_case_0()
    test_LookupModule_get_value()

# Generated at 2022-06-25 10:46:34.132568
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 10:47:06.885762
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.get_options()
    var_0 = lookup_module_0.get_value()
    lookup_module_0.set_options()


# Generated at 2022-06-25 10:47:15.844123
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.RawConfigParser()
    lookup_module_0.cp.add_section("global")
    lookup_module_0.cp.set("global", "user", "osboxes")
    lookup_module_0.cp.add_section("integration")
    lookup_module_0.cp.set("integration", "user", "evrardjp")
    lookup_module_0.cp.add_section("production")
    lookup_module_0.cp.set("production", "user", "ubuntu")
    lookup_module_0.cp.read('test.ini')

    assert lookup_module_0.get_value("user", "integration", None, False) == "evrardjp"

    lookup_module_0.cp.add

# Generated at 2022-06-25 10:47:17.278155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    float_0 = 1647.9
    var = lookup_run(float_0)


# Generated at 2022-06-25 10:47:25.304830
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    name_0 = "b"
    int_0 = 7
    str_0 = "d"
    int_1 = 17
    str_1 = "x"
    int_2 = 7
    var_0 = lookup_module_0.get_value(name_0, int_0, str_0, int_1, str_1, int_2)


# Generated at 2022-06-25 10:47:28.482291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 10:47:33.710228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    float_0 = 1647.9
    var_0 = lookup_module.run(float_0)

# Generated at 2022-06-25 10:47:35.431183
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    float_1 = 1647.9
    var_1 = lookup_run(float_1)

# Generated at 2022-06-25 10:47:39.338782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    float_0 = 1647.9
    var_1 = lookup_run(float_0)
    assert var_1 == float_0

# Generated at 2022-06-25 10:47:45.085850
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    bool_0 = bool(0)
    assert lookup_module_0.get_value(None, None, bool_0, bool_0) is None


# Generated at 2022-06-25 10:47:46.702977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[])


# Generated at 2022-06-25 10:48:55.073399
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.get_value(str_0, str_0, str_0, long_0)


# Generated at 2022-06-25 10:49:02.170342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    options = dict(
        connection='local',
        remote_user='root',
        ack_pass=False,
        sudo=False,
        sudo_user='root',
        become=False,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        listhosts=None,
        listtasks=None,
        listtags=None,
        syntax=None
    )

    loader = DataLoader()
    passwords

# Generated at 2022-06-25 10:49:07.979633
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    chars_0 = None
    chars_2 = lookup_module_0.get_value(chars_0, 'test_run_test_LookupModule_get_value', None, False)
    assert chars_2 is None


# Generated at 2022-06-25 10:49:10.843337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9

    var_0 = lookup_run(float_0)

    for var_1 in var_0:
        print(var_1)

    lookup_module_0.run(var_0)
    # TODO: assertions


# Generated at 2022-06-25 10:49:18.488386
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    int_0 = -1

    # Act
    var_0 = lookup_run(float_0, int_0)

    # Assert
    assert var_0 == '123', 'unit test failed'

if __name__ == '__main__':

    import sys

    if len(sys.argv) == 1:
        print("Using only the builtin Python unittest module.")
        print("Usage: %s test_case_number" % sys.argv[0])
        print("1 - test_case_0")
        sys.exit(1)
    if sys.argv[1] == "1":
        test_case_0()

# Generated at 2022-06-25 10:49:28.846736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "qJ6"
    float_0 = 933.2
    str_1 = "2JZC"
    str_2 = "s"
    str_3 = "n"
    str_4 = "^6U"
    str_5 = "y"
    str_6 = "O"
    str_7 = "J"
    float_1 = 4.4
    str_8 = "Gj"
    str_9 = "L"
    float_2 = 927.9
    float_3 = 5.2
    str_10 = "Zj"
    str_11 = "7q3Y"
    str_12 = "jm"
    str_13 = "W"
    str_14 = "i"
   

# Generated at 2022-06-25 10:49:30.525944
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    float_0 = 1647.9
    var_0 = test_LookupModule_get_value(float_0)


# Generated at 2022-06-25 10:49:36.128724
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    section_0 = random_string(random.randint(1, 9))
    key_0 = random_string(random.randint(1, 9))
    dflt_0 = random_string(random.randint(1, 9))
    is_regexp_0 = random.choice((True, False))
    lookup_module_1.get_value(key_0, section_0, dflt_0, is_regexp_0)


# Generated at 2022-06-25 10:49:39.453511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    float_1 = 1.9
    string_0 = str(float_1)
    str_0 = lookup_run(string_0)
    str_1 = lookup_run(string_2)


# Generated at 2022-06-25 10:49:50.833592
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    int_0 = 0
    bool_0 = True
    str_0 = 'str_0'
    dict_0 = dict()
    str_1 = 'str_1'
    dict_1 = dict()
    dict_1[str_1] = str_1
    str_2 = 'str_2'
    int_1 = 0
    dict_2 = dict()
    dict_2[str_2] = int_1
    dict_2[str_0] = dict_2
    dict_2[str_1] = str_0
    dict_1[str_1] = dict_2
    dict_1['str_3'] = str_1
    dict_1[str_0] = dict_2
    dict_1[str_0] = dict

# Generated at 2022-06-25 10:52:19.786724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars_0 = {}
    lookup_module_0.set_options(vars_0, False)
    list_0 = ['test1', 'test2']
    vars_1 = {}
    paramvals_0 = lookup_module_0.get_options()
    with pytest.raises(AnsibleOptionsError) as e_0:
        path_0 = lookup_module_0.run(list_0, vars_1)


# Generated at 2022-06-25 10:52:30.361189
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Find file in search path.
    searchpath = ['/etc/ansible/roles/role_under_test/vars/main.yml', '/etc/ansible/roles/role_under_test/defaults/main.yml', '/etc/ansible/roles/role_under_test/meta/main.yml', '/etc/ansible/group_vars/vagrant', '/etc/ansible/host_vars/localhost']
    'test.ini' in [x for y in searchpath for x in os.listdir(y) if x.endswith('.ini')]

    # Test case 1
    lookup_module_1 = LookupModule()
    params = ['test.ini', 'section_a', 'section_b']
    paramvals = configparser.ConfigParser()
    paramvals.option

# Generated at 2022-06-25 10:52:39.389383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = [' ']
    variables_0 = None
    arguments_0 = LOOKUP_OPTIONS
    var_0 = lookup_module_0.run(term_0, variables_0)

if __name__ == '__main__':
    # Example
    lookup_module = LookupModule()
    lookup_list = ['user', 'password']
    lookup_value = lookup_module.get_value(
        lookup_list[0], 'section1', 'default', False)
    print(lookup_value)
    lookup_list = ['user.name', 'user.password']
    lookup_value = lookup_module.get_value(
        lookup_list[0], 'java_properties', 'default', False)
    print(lookup_value)

# Generated at 2022-06-25 10:52:47.659440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options = object()
    lookup_module_2.find_file_in_search_path = object()
    lookup_module_2._loader = object()
    lookup_module_2.cp = object()
    lookup_module_2.get_options = object()
    lookup_module_2._loader._get_file_contents = object()
    lookup_module_2.get_value = object()
    terms_1 = "www.gutenberg.org/files/36/36-0.txt"
    ret_3 = lookup_module_2.run(terms_1)
    assert isinstance(ret_3, list)


# Generated at 2022-06-25 10:52:52.592370
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    section_0 = None
    key_0 = None
    dflt_0 = None
    is_regexp_0 = None
    var_0 = lookup_get_value(lookup_module_0, key_0, section_0, dflt_0, is_regexp_0)


# Generated at 2022-06-25 10:52:55.572549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = None
    kwargs_0 = {"encoding": "utf-8", "file": "ansible.ini", "section": "global"}
    var_0 = lookup_module_0.run(*list_0, **kwargs_0)



# Generated at 2022-06-25 10:53:06.708853
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    list_0 = None
    str_0 = ' '
    ansible_options_0 = LookupBase()
    ansible_options_0.get_options()
    ansible_options_0.set_options(None, True)
    ansible_options_0.get_options(None, {})
    lookup_module_0.get_options()
    lookup_module_0.get_options(None)
    lookup_module_0.set_options(None, True)
    lookup_module_0.set_options(None, True, None)
    lookup_module_0.set_options(None, True, None, False)
    lookup_module_0.set_options(None, True, None, False, None)

# Generated at 2022-06-25 10:53:13.667603
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_get_value(lookup_module_0, lookup_module_0, lookup_module_0, list_0)
    assert var_0 is None
