

# Generated at 2022-06-25 10:43:21.753734
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    value = None
    key = 'user'
    section = 'integration'
    dflt = None
    is_regexp = False
    ret = lookup_module_0.get_value(key, section, dflt, is_regexp)
    assert ret == value


# Generated at 2022-06-25 10:43:25.035030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(terms=['error -d'], variables=variables, plugindir='myplugin')

#   result = l.run(terms=['error -d'], variables=variables)
#   assert type(result) is list

# Generated at 2022-06-25 10:43:35.586500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

#    When contents equals None
    contents = None
    expected = []

    result = lookup_module.run(contents, variables=None, **{})

    assert result == expected

#    When contents equals 'a=b'
    contents = 'a=b'
    expected = ['b']

    result = lookup_module.run(contents, variables=None, **{})

    assert result == expected

#    When contents equals 'a=b, c=d'
    contents = 'a=b, c=d'
    expected = ['b', 'd']

    result = lookup_module.run(contents, variables=None, **{})

    assert result == expected

#    When contents equals 'a = b, c = d'

# Generated at 2022-06-25 10:43:47.134217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    example = ''' [section1]
                  key1=value1
                  key2=value2
                  key3=vA
                  key4=vB
                  [section2]
                  key1=value3
                  key2=value4
                  key3=vC
                  key4=vD
                  '''
    file = StringIO()
    file.write(example)
    file.seek(0)
    lookup.cp.readfp(file)
    assert lookup.get_value("key1", "section1", "", False) == "value1"
    assert lookup.get_value("key2", "section1", "", False) == "value2"
    assert lookup.get_value("key2", "section2", "", False) == "value4"
    assert lookup.get_

# Generated at 2022-06-25 10:43:54.378153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_terms_0 = [ostr]
    list_result_0 = lookup_module_0.run(list_terms_0)
    assert type(list_result_0) == list
    str_result_0 = ''
    assert type(str_result_0) == str



# Generated at 2022-06-25 10:43:58.883309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['ansible_ssh_user', 'ansible_become_user', 'ansible_default_ipv4', 'ansible_python_interpreter'], 'defaults', 'ansible.ini') == []

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:44:05.811504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case when file does not exist
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader(None)
    assert lookup_module_1.run([''], variables=None, **{'file': 'test_files/test_files_test.ini'}) == []
    # Case when file exists
    lookup_module_2 = LookupModule()
    lookup_module_2.set_loader(None)
    assert lookup_module_2.run([''], variables=None, **{'file': 'test_files/test_files_test.ini'}) == []

# Generated at 2022-06-25 10:44:15.016698
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Given
    lookup_module = LookupModule()
    lookup_module.cp = configparser.RawConfigParser(allow_no_value=True)
    lookup_module.cp.optionxform = str

    lookup_module.cp.readfp(StringIO("[test]\na=b\n"))
    key = "a"
    section="test"
    dflt = ""
    is_regexp = False

    # When
    ret = lookup_module.get_value(key, section, dflt, is_regexp)

    # Then
    assert ret == "b"



# Generated at 2022-06-25 10:44:22.773576
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    section = "global"
    key = "user"

    class CP():
        def get(section, key):
            return "root"

        def items(section):
            return [("user", "foo"), ("home", "/root")]

    lookup_module.cp = CP()
    ## Default value
    assert lookup_module.get_value(key, section, "toto", False) == "root"
    ## Value found
    assert lookup_module.get_value(key, section, "toto", False) == "root"
    ## Value not found (regex)
    assert lookup_module.get_value(key, section, "toto", True) == []
    ## Value not found (no regex)

# Generated at 2022-06-25 10:44:30.618152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['pattern'], inject={'file': 'test/inventory_test_ansible_host', 'section': 'host', 'encoding': 'utf-8', 're': False, 'default': '', 'allow_none': False})  == ['192.168.1.1']
    assert lookup_module.run(terms=['pattern'], inject={'file': 'test/inventory_test_ansible_host', 'section': 'group', 'encoding': 'utf-8', 're': False, 'default': '', 'allow_none': False}) == ['192.168.1.0/24']

# Generated at 2022-06-25 10:44:53.173382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_name = 'zoo.ini'
    config = configparser.ConfigParser(allow_no_value=False)
    config.read(file_name)
    assert config.get('bugs', 'bug_reporting', fallback=None) == 'https://bugs.zoo.com/'
    assert config.get('web', 'domain_name', fallback=None) == 'zoo.com'
    assert config.get('web', 'port', fallback=None) == '80'
    assert config.get('db', 'host', fallback=None) == 'localhost'
    assert config.get('db', 'user', fallback=None) == 'zoo'
    assert config.get('db', 'password', fallback=None) == '123'
    term = 'bug_reporting'

# Generated at 2022-06-25 10:45:01.722250
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Instantiate mocked ConfigParser.
    class ConfigParser:
        sections = []

        def add_section(self, section):
            self.sections.append(section)

        def items(self, *args, **kwargs):
            return []

    configparser = ConfigParser()
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser

    # Call tested method
    assert lookup_module_0.get_value('key', 'section', 'dflt', True) == []


# Generated at 2022-06-25 10:45:07.221775
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.get_value('key', 'section', 'dflt', 'is_regexp') == None


# Generated at 2022-06-25 10:45:12.089654
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()

    # Set parameters
    key = 'user'
    section = 'integration'
    dflt = ''
    is_regexp = False

    # Call method
    result = lookup_module_0.get_value(key, section, dflt, is_regexp)

    # Check returned type
    assert isinstance(result, str)


# Generated at 2022-06-25 10:45:15.072843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['key_0']
    variables_0 = 'var'
    lookup_module_0.run(terms=terms_0, variables=variables_0)

# Generated at 2022-06-25 10:45:25.205560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = FakeDataLoader()

    # Test 1: Test empty terms
    terms = []
    variables = {'inventory_dir': ''}
    result = lookup_module.run(terms, variables=variables)
    assert result == [], "Empty terms should return an empty list"

    # Test 2: Test string with no parameters
    terms = ['value']
    variables = {'inventory_dir': ''}
    paramvals = {'type': 'ini', 'file': 'ansible.ini', 'section': 'global', 're': False, 'encoding': 'utf-8',
                 'default': '', 'case_sensitive': False, 'allow_no_value': False}

# Generated at 2022-06-25 10:45:30.874695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_terms_0 = []
    var_variables_0 = [u'ansible_ssh_pass', u'ansible_python_interpreter', u'ansible_connection', u'ansible_ssh_extra_args', u'ansible_ssh_common_args', u'ansible_ssh_host', u'ansible_ssh_user']
    var_kwargs_0 = {
        'encoding': 'utf-8',
        'file': u'ansible.ini',
        'section': 'global',
        'default': '',
        're': False,
        'allow_no_value': False,
        '_ansible_check_mode': False,
        'case_sensitive': False,
        'type': u'ini'
    }
   

# Generated at 2022-06-25 10:45:37.448456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0.run(terms=['key1'], variables=None)


# Generated at 2022-06-25 10:45:44.337173
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:45:51.789060
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    kwargs = dict(file="ansible.ini", section="global", type="properties")
    lookup_module.set_options(var_options={}, direct=kwargs)
    paramvals = lookup_module.get_options()
    # TODO: look to use cache to avoid redoing this for every term if they use same file
    # Retrieve file path
    path = lookup_module.find_file_in_search_path({}, 'files', paramvals['file'])

    # Create StringIO later used to parse ini
    config = StringIO()
    # Special case for java properties
    if paramvals['type'] == "properties":
        config.write(u'[java_properties]\n')
        paramvals['section'] = 'java_properties'

    # Open file using encoding


# Generated at 2022-06-25 10:46:20.337453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = test_case_0()
    # Test for file exists.
    lookup_module_0.run(terms=["user"], variables={"var": "value"}, var_options={"file": "users.ini"})


# Generated at 2022-06-25 10:46:27.575320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    term_0 = "mysql"
    terms_0 = [term_0]
    variables_0 = "bob"
    paramvals_0 = {"file":"bob", "section":"bob", "default":"bob", "re":"bob", "type":"bob", "encoding":"bob"}
    kwargs_0 = {'allow_none': False}
    kwargs_1 = {"paramvals_0":"bob"}
    lookup_module_0.set_options(var_options=variables_0, direct=kwargs_1)
    try:
        lookup_module_0.run(terms_0, variables=variables_0, **kwargs_0)
    except:
        pass



# Generated at 2022-06-25 10:46:28.572220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:46:37.519964
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    params = _parse_params("file=ansible.ini section=global default=key1=value1 key2=value2 key3=value3", lookup_module_0.get_options())

# Generated at 2022-06-25 10:46:43.636560
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()

    # Pseudo-configuration
    # [section_0]
    # key_0_0 = value_0_0
    # key_0_1 = value_0_1
    # [section_1]
    # key_1_0 = value_1_0
    # [section_2]
    # key_2_0 = value_2_0
    # key_2_1 = value_2_1
    # key_2_2 = value_2_2
    lookup_module.cp = configparser.ConfigParser()
    section_0 = configparser.SectionProxy(lookup_module.cp, 'section_0')
    section_0['key_0_0'] = 'value_0_0'

# Generated at 2022-06-25 10:46:50.358671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run : start")

    # test_ini_type
    lookup_module_0 = LookupModule()

    paramvals_0 = {'type' : 'ini', 'section' : 'section1', 'default' : '', 're' : False, 'file' : 'test.ini', 'allow_none' : False, 'case_sensitive' : False, 'encoding' : 'utf-8'}
    terms_0 = 'user1'
    ret_0 = lookup_module_0.run(terms_0, paramvals_0)
    assert ret_0 == ['value1']

    # test_ini_type_regexp
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:46:58.414566
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    fp = open("test_LookupModule_run.ini", "w")
    fp.write("[section1]\n")
    fp.write("test1 = testvalue1\n")
    fp.write("test2 = testvalue2\n")
    fp.close()

    terms = [("test1", "")]
    options = {"file":"test_LookupModule_run.ini", "section":"section1", "default":"", "re" : False}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None, **options)
    assert result == ["testvalue1"]


# Generated at 2022-06-25 10:47:06.765492
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Parameter of type dict
    param_0 = {"file": "ansible.ini", "case_sensitive": True}
    # Parameter of type list
    param_1 = ["user", "email"]
    # Parameter of type dict
    param_2 = {}

    lookup_module = LookupModule()

    # Method execute, test of no exception raised
    # This use case is somewhat useless since it will raise an exception, but it tests the code
    try:
        lookup_module.run(param_1, param_2, file=param_0["file"], case_sensitive=param_0["case_sensitive"])
    except Exception as e:
        raise Exception(e)

# Generated at 2022-06-25 10:47:07.451718
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    pass


# Generated at 2022-06-25 10:47:16.438253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data_file = """
[section1]
title = value1
title2 = value2
title3 = value3
"""

    # Get an instance of the LookupModule class
    lookup = LookupModule()

    # Create a StringIO instance from string 'data_file'
    file_data = StringIO()
    file_data.write(data_file)
    file_data.seek(0, os.SEEK_SET)

    # Load stringIO into ConfigParser instance
    cp = configparser.ConfigParser()
    cp.readfp(file_data)

    # Call lookup method
    terms = ['title']
    parameters = {'file': ''}
    result = lookup.run(terms, parameters, cp=cp)

    # Test the result
    assert result == ['value1']



# Generated at 2022-06-25 10:47:46.055541
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
  str_0 = 'N'
  dictt_0 = dict()
  lookup_module_0 = LookupModule(str_0)
  bool_0 = False
  var_0 = lookup_get_value(bool_0, str_0, bool_0, bool_0)
  assert type(var_0) is not int
  assert '!Cc%BhjY=' in dictt_0
  lookup_module_0.cp.items(dictt_0)



# Generated at 2022-06-25 10:47:49.537105
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Input parameters
    key = 'test_value'
    section = 'test_section'
    dflt = 'default_value'
    is_regexp = True

    # Output parameters
    var = 'test_value'

    # Returned value  
    ret = 'test_value'

    # Check if method get_value returns correct value
    assert ret == get_value(key, section, dflt, is_regexp)
    print("Method get_value returned correct value")



# Generated at 2022-06-25 10:47:55.244650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing the class
    lookup_module_0 = LookupModule()
    terms = ['key1', 'key2']
    variables = {'key1': 'value1', 'key2': 'value2'}
    ret = lookup_module_0.run(terms, variables, file='file', section='section')
    assert ret == ['value1', 'value2']


# Generated at 2022-06-25 10:47:59.204132
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 'R-9z)p@9hUQsu{{V'
    lookup_module_0 = LookupModule(str_0)
    bool_0 = False
    var_0 = lookup_get_value(bool_0, str_0, bool_0, bool_0)


# Generated at 2022-06-25 10:48:09.990574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '>za'
    lookup_module_0 = LookupModule(str_0)
    config_parser_0 = configparser.ConfigParser(allow_no_value=False)
    config_parser_1 = configparser.ConfigParser(allow_no_value=False)
    config_parser_0.optionxform = config_parser_1.optionxform = str_0
    lookup_module_0.cp = config_parser_0
    bool_0 = False
    str_1 = 'string'
    str_2 = 'string'
    str_3 = 'string'
    str_4 = 'string'
    str_5 = 'string'
    str_6 = 'string'
    str_7 = 'string'
    str_8 = 'string'
    str_9 = 'string'
   

# Generated at 2022-06-25 10:48:13.744079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  """
  Input parameter 'param' is not used. Do not need test
  """
  pass

# Generated at 2022-06-25 10:48:23.820056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '=t\'n7Qc%j}'
    lookup_module_0 = LookupModule(str_0)
    str_1 = 'oq?C\'G:$B>|E.Nq'
    str_2 = 'U\'D/<}xM'
    str_3 = 'mec>A/8;l|iS'
    str_4 = '%c8n0i4}4_[=X1'
    dict_0 = {}
    dict_0['file'] = str_3
    dict_0['default'] = str_4
    dict_0['type'] = str_2
    dict_0['section'] = str_1
    bool_0 = False
    dict_0['case_sensitive'] = bool_0

# Generated at 2022-06-25 10:48:34.993878
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:48:36.968639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule(3)
    assert_equal(lookup_module_2.run('a', 'b', 'c', 'd'), None)

# Generated at 2022-06-25 10:48:47.534587
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    str_0 = 'R-9z)p@9hUQsu{{V'
    lookup_module_0 = LookupModule(str_0)
    var_0 = ["R-9z)p@9hUQsu{{V"]
    str_1 = 'R-9z)p@9hUQsu{{V'
    var_1 = lookup_module_0.run(var_0, str_1)
    if var_1 != ["R-9z)p@9hUQsu{{V"]:
        test_failed("Expected: %s, received: %s" % ("R-9z)p@9hUQsu{{V", var_1))
    else:
        test_success("OK")

# Generated at 2022-06-25 10:49:46.409650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'R-9z)p@9hUQsu{{V'
    lookup_module_0 = LookupModule(str_0)
    str_1 = 'k(%J@oM'
    list_0 = ['k(%J@oM']
    str_2 = '__b'
    dict_0 = {'__b': True}
    str_3 = '@:1E'
    dict_1 = {'@:1E': True}
    str_4 = 'O/2heC_3'
    dict_2 = {'O/2heC_3': False}
    str_5 = 'tY0XI@pc'
    dict_3 = {'tY0XI@pc': 'y-L'}

# Generated at 2022-06-25 10:49:48.435141
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = '[section]'
    str_1 = 'key=value1'
    lookup_module_0 = LookupModule(str_0)
    var_0 = test_case_0()


# Generated at 2022-06-25 10:49:51.201565
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 'R-9z)p@9hUQsu{{V'
    lookup_module_0 = LookupModule(str_0)
    bool_0 = False
    var_0 = lookup_get_value(bool_0, str_0, bool_0, bool_0)


# Generated at 2022-06-25 10:49:56.070843
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 'R-9z)p@9hUQsu{{V'
    lookup_module_0 = LookupModule(str_0)
    str_1 = '2R-9z)p@9hUQsu{{V'
    str_2 = 'S-9z)p@9hUQsu{{V'
    str_3 = 'T-9z)p@9hUQsu{{V'
    bool_0 = False
    bool_1 = True
    var_0 = lookup_module_0.get_value(str_1, str_2, str_3, bool_0)


# Generated at 2022-06-25 10:50:03.173903
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    str_0 = 'DHQoMdaW+F;D'
    lookup_module_0 = LookupModule(str_0)
    str_1 = 'O}g;8j'
    str_2 = '6Ud'
    str_3 = 'aEk[nf+F#/j'

    # Test case with options
    dict_0 = dict()
    dict_0['file'] = str_1
    dict_0['section'] = str_2
    dict_0['re'] = True
    dict_0['type'] = 'properties'
    dict_0['encoding'] = 'utf-8'
    dict_0['default'] = str_3

    bool_0 = False
    lookup_module_0.run([str_0, str_0], dict_0, **dict_0)

# Generated at 2022-06-25 10:50:08.937262
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_1 = 'R-9z)p@9hUQsu{{V'
    lookup_module_1 = LookupModule(str_1)
    ret_1 = lookup_module_1.run(1)
    lookup_module_1.get_value(str_1, str_1, str_1, ret_1)



# Generated at 2022-06-25 10:50:11.879221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test input parameters
    terms = ['ansible_ssh_host']
    variables = None
    kwargs = {}
    lookup_module = LookupModule(terms, variables, kwargs)
    # Test with:
    #   - paramvals['file'] = 'hosts' and
    #   - paramvals['type'] = 'ini'
    paramvals = {}
    lookup_module.run(terms, variables=variables, paramvals=paramvals)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:50:14.588919
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 'R-9z)p@9hUQsu{{V'
    str_1 = 'I2?4/x4nAV/UYH<u'
    lookup_module_0 = LookupModule(str_1)
    bool_0 = False
    var_0 = lookup_get_value(bool_0, str_0, bool_0, bool_0)


# Generated at 2022-06-25 10:50:17.155223
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 'R-9z)p@9hUQsu{{V'
    lookup_module_0 = LookupModule(str_0)
    bool_0 = False
    var_0 = lookup_get_value(bool_0, str_0, bool_0, bool_0)


# Generated at 2022-06-25 10:50:27.648465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str_0)
    str_0 = 'R-9z)p@9hUQsu{{V'
    str_1 = '--use-ssl=yes'
    bool_0 = False
    terms = [str_0, str_1]
    str_2 = 'ldap_host'
    str_3 = 'ldap_port'
    str_4 = 'ldap_binddn'
    str_5 = 'ldap_bindpw'
    str_6 = 'ldap_searchdn'
    str_7 = 'ldap_usersuffix'
    str_8 = 'ldap_groupsuffix'
    str_9 = 'ldap_attrs'
    str_10 = 'ldap_usermap'

# Generated at 2022-06-25 10:52:45.303478
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 'R-9z)p@9hUQsu{{V'
    lookup_module_0 = LookupModule(str_0)
    str_1 = '3iw9XW'
    str_2 = 'l5}5=?(4jsd!Y[t'
    bool_0 = False
    var_0 = lookup_get_value(bool_0, str_2, str_1, bool_0)


# Generated at 2022-06-25 10:52:55.107732
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    str_0 = 'KXp`/L-?J'
    lookup_module_0 = LookupModule(str_0)
    str_1 = ';<\x15Qc\x1d\x12\x14\x13\x12\x15\x1e'
    str_2 = 'L\x0f\x07\x13\x15\x02\x1f\x06\x11\x00\x01\x07\x00\x16\x01\x06\x04\x08'

# Generated at 2022-06-25 10:53:01.391563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Run unit test for method run of class LookupModule...')

    # unit test for: lookup_result = lookup_module.run(terms, variables=None, **kwargs)
    #  with terms = ['foo'], variables=None, kwargs = {'encoding': 'utf-8', 'file': '', 'case_sensitive': False, 'default': '', 're': False, 'allow_none': False, 'allow_no_value': False, 'type': 'ini', 'section': 'global'}


# Generated at 2022-06-25 10:53:07.711370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=too-many-branches
    lookup_module_0 = LookupModule('R-9z)p@9hUQsu{{V')
    str_0 = 'R-9z)p@9hUQsu{{V'
    str_1 = 'R-9z)p@9hUQsu{{V'
    str_2 = 'R-9z)p@9hUQsu{{V'
    str_3 = 'R-9z)p@9hUQsu{{V'
    str_4 = 'R-9z)p@9hUQsu{{V'
    str_5 = 'R-9z)p@9hUQsu{{V'
    str_6 = 'R-9z)p@9hUQsu{{V'
    str_

# Generated at 2022-06-25 10:53:14.784113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # StringIO object
    term_str_0 = StringIO()
    terms_str_0 = [term_str_0]
    lookup_module_0 = LookupModule(terms_str_0)
    lookup_module_1 = lookup_module_0.run(terms_str_0, variables=None)
