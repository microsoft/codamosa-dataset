

# Generated at 2022-06-25 10:43:27.971758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'some_variable': 'some_value'}, direct={'default': 'some_default'})
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp._sections['development'] = {'user': 'yannig'}

    terms = ['user']
    assert lookup_module.run(terms) == ['yannig']

    # Case sensitive
    lookup_module.set_options(var_options={'some_variable': 'some_value'}, direct={'default': 'some_default', 'case_sensitive': True})
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp._sections['development'] = {'USER': 'yannig'}

# Generated at 2022-06-25 10:43:39.122091
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    # This method return the value 'abc' of the section 'section1', key 'username'
    terms = ['username', 'section=section1', 'type=ini', 'file=test.ini']
    variables = None
    kwargs = {'encoding': 'utf-8', 'case_sensitive': False, 're': False, 'allow_none': True, 'default': ''}
    results = lookup_module.run(terms, variables, **kwargs)
    assert results == ['abc']
    assert results is not None

    # This method return the value 'abc' of the section 'section1', key 'username'
    terms = ['username', 'section=section1', 'type=ini', 'file=test.ini']
    variables = None

# Generated at 2022-06-25 10:43:49.457057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule_0 = LookupModule()
    test_terms_0 = [u'[section1]\nkey1=value']
    test_variables_0 = {}
    test_kwargs_0 = {}
    test_result_0 = lookupModule_0.run(test_terms_0, test_variables_0, **test_kwargs_0)
    assert test_result_0 == [u'value']

    lookupModule_1 = LookupModule()
    test_terms_1 = [u'key1']
    test_variables_1 = {}
    test_kwargs_1 = {}
    test_result_1 = lookupModule_1.run(test_terms_1, test_variables_1, **test_kwargs_1)
    assert test_result_1 == [u'value']



# Generated at 2022-06-25 10:43:57.927401
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    lookup_module_1.cp.read(StringIO(u'[global]\nhostname=hostname_2'))
    lookup_module_1.cp.read(StringIO(u'[group1]\nhostname=hostname_1\nhostaddress=hostaddress_1'))
    lookup_module_1.cp.read(StringIO(u'[group2]\nhostaddress=hostaddress_2'))
    result = lookup_module_1.get_value('hostaddress', u'group1', None, False)
    assert result == u'hostaddress_1'


# Generated at 2022-06-25 10:44:07.415986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_s = LookupModule()
    # C(file) is None
    try:
        lookup_module_s.run(terms=[], variables = None)
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleLookupError)
    # C(file) does not exist
    try:
        lookup_module_s.run(terms=[""], variables = {'lookup_file': 'test_files/test_files_p/test_files_p/test_files_p/test_files_p.ini'})
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleLookupError)
    # C(file) exists

# Generated at 2022-06-25 10:44:16.082522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    my_file = """
    [my_section]
    current_user=root
    """
    with open('test_LookupModule_run.ini', 'w') as f:
        f.write(my_file)

    output = lookup_module_1.run([':current_user'], variables=None, file='test_LookupModule_run.ini', section='my_section')
    assert output == ['root']
    try:
        os.remove('test_LookupModule_run.ini')
    except OSError:
        pass



# Generated at 2022-06-25 10:44:24.196557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config_file_contents = u'''
[section1]
key1 = value1
key2 = value2
key3 = value3

[section2]
key1 = value1
key2 = value2
key3 = value3
'''
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({
        'type': 'ini',
        'file': 'test.ini'
    })
    assert lookup_module_1.run([u'key1'], {u'files':[config_file_contents]}) == [u'value1']
    assert lookup_module_1.run([u'key1', u'key2'], {u'files':[config_file_contents]}) == [u'value1', u'value2']


# Generated at 2022-06-25 10:44:28.903637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [u'host', u'user', u'port', u'password', u'timeout']
    variables_1 = {}
    options_1 = {}
    result_1 = lookup_module_1.run(terms_1, variables_1, **options_1)
    assert result_1 == ['localhost', 'root', '3306', '', '30']


# Generated at 2022-06-25 10:44:40.909856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    contents_file = u'[java_properties]\nkey1=value1\nkey2=value2\nkey3==value3\n[integration]\nuser=Yannig\n[production]\nuser=Jane\n'

    terms_0 = [u'user']
    parameters_0 = {u'file': u'users.ini'}
    parameters_0[u'case_sensitive'] = False

    # Test simple case
    contents_file2 = contents_file + u'[other]\nkey4=value4'
    for section_0 in [u'integration', u'production']:
        parameters_0[u'section'] = section_0
        parameters_0[u're'] = False

# Generated at 2022-06-25 10:44:43.504532
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.get_value('key', 'section', None, False) == None


# Generated at 2022-06-25 10:45:06.196446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = "key=value"
    path = "/tmp/ansible.ini"
    contents = "# contents"
    encoding = "utf-8"

    def test_parse_params_0():
        phrase = "k1=v1 k2=v2"
        paramvals = { "k1": "v1", "k2": "v2", "key": "k1" }
        ret = _parse_params(phrase, paramvals)
        assert ret == ["k1=v1", "k2=v2"]

    def test_parse_params_1():
        phrase = "k3=v3 k4=v4"
        paramvals = { "k1": "v1", "k2": "v2", "key": "k1", "k3": "v3", "k4": "v4" }

# Generated at 2022-06-25 10:45:15.332856
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    contents = '''[section1]

key1=value1

key2=value2

[section2]

key1=value1

key2=value2'''
    path = '/path/to/file/test.ini'

    config = StringIO()
    config.write(contents)
    config.seek(0, os.SEEK_SET)

    cp = configparser.ConfigParser()
    cp.readfp(config)

    lookup_module = LookupModule()

    assert lookup_module.run([], {}, path='/path/to/file/test.ini', cp=cp, section='section1', key='key1', dflt='default1', is_regexp=False) == ['value1']

# Generated at 2022-06-25 10:45:21.278316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    key1 = "[development]"
    key2 = "user=bob"
    config = StringIO()
    config.write(key1 + "\n" + key2 + "\n")
    config.seek(0, os.SEEK_SET)

    lookup_module_run = LookupModule()
    lookup_module_run.cp.readfp(config)
    lookup_module_run.run([key2])


# Generated at 2022-06-25 10:45:31.899655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests with a file 'test.ini'
    #
    # [section1]
    # value1 = This is a value
    # value2 = This is another value
    #
    # [section2]
    # value3 = Case test
    # VALUE3 = Case test
    # value4 = Case test
    # VALUE4 = Case test
    # vAlUe4 = Case test
    # VALUE4 = Case test
    #
    # [section1]
    # valueX = This is another test
    # valueY = This is another test
    #
    # [section2]
    # valueZ = This is another test

    lookup_module = LookupModule()


# Generated at 2022-06-25 10:45:43.400241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    [section1]
    user = yannig
    '''

    assert (LookupModule().run([u'user'], {}, file='test.ini', section='section1') == [u'yannig'])
    assert (LookupModule().run([u'user', u'user'], {}, file='test.ini', section='section1') == [u'yannig', u'yannig'])
    assert (LookupModule().run([u'section'], {}, file='test.ini', section='section1') == [u''])
    assert (LookupModule().run([u'section2'], {}, file='test.ini', section='section1') == [u''])

# Generated at 2022-06-25 10:45:51.400817
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Make a temporary config file
    f = open("test.ini", "w")
    f.write("[DEFAULT]\n")
    f.write("var1=1\n")
    f.write("var2=2\n")
    f.write("var3=one\n")
    f.write("var4=two\n")
    f.write("var5=3\n")
    f.write("var6=four\n")
    f.write("var7=five\n")
    f.write("var8=six\n")
    f.write("var9=seven\n")
    f.write("var10=eight\n")
    f.write("var11=ten\n")
    f.write("var12=eleven\n")

# Generated at 2022-06-25 10:45:59.330473
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_0 = LookupModule()
    key_0 = "vpc_id"
    section_0 = "dev"
    dflt__0 = ""
    is_regexp_0 = "False"
    config_parser_0 = configparser.ConfigParser()

    # TODO: check if self.cp.items(section) return a dict
    # items_0 = config_parser_0.items(section_0)
    # TODO: check if self.cp.items(section) return a dict
    # items_1 = config_parser_0.items(section_0)
    # TODO: check if self.cp.items(section) return a dict
    # items_2 = config_parser_0.items(section_0)
    # TODO: check if self.cp.items(section) return a

# Generated at 2022-06-25 10:46:04.196185
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_get_value_0 = LookupModule()
    key_0 = 'user'
    section_0 = 'global'
    dflt_0 = ''
    is_regexp_0 = True
    result = lookup_module_get_value_0.get_value(key_0, section_0, dflt_0, is_regexp_0)
    assert result == ["Juanita"]


# Generated at 2022-06-25 10:46:08.543510
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    ret = lookup_module_1.get_value('key_0', 'section_0', 'default_0', False)
    assert ret == 'value_0'


# Generated at 2022-06-25 10:46:17.540333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        None,
    ]
    variables_0 = {
        'default': None,
        'type': 'ini',
        'case_sensitive': False,
        'section': 'global',
        'file': 'ansible.ini',
        'encoding': 'utf-8',
        're': False,
        'allow_none': False,
    }
    # TODO: how can we test this without throwing an exception?
    try:
        lookup_module_0.run(terms_0, variables_0)
    except Exception as e:
        print('Error: %s' % e)

# Generated at 2022-06-25 10:46:46.820182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    return_value_1 = lookup_module_1.run(terms=['config'], variables={'hostvars': {'host1': {'ansible_host': '127.0.0.1'}}}, allow_none=True, file=u'test.ini', section=u'global', re=True)
    assert return_value_1 == []



# Generated at 2022-06-25 10:46:55.038752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # mock arguments for function run of class LookupModule
    paramvals = {}
    paramvals['file'] = 'test.ini'
    paramvals['type'] = 'ini'
    paramvals['section'] = 'section1'
    paramvals['re'] = False
    paramvals['default'] = ''
    paramvals['case_sensitive'] = False
    paramvals['allow_no_value'] = False
    
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=['key1'], variables=paramvals)
    
    assert result == ['value1']
    


# Generated at 2022-06-25 10:47:05.603073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'integration',
        'production',
        'user.name',
        '.*',
        'user',
    ]
    variables_0 = defaultdict(lambda: '', {
        'file': 'users.ini',
        'type': 'ini',
        'section': 'section1',
    })
    expected_0 = [
        'johndoe',
        'janedoe',
        'johndoe',
        '',
        '',
    ]
    kwargs_0 = {
        'file': 'users.ini',
        'encoding': 'utf-8',
        'section': 'section1',
        'type': 'ini',
        'case_sensitive': False,
    }

# Generated at 2022-06-25 10:47:11.222779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.optionxform = to_native
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.get_options()
    lookup_module.run(terms=['key'], variables=None)


# Generated at 2022-06-25 10:47:18.126645
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_1 = LookupModule()
    try:
        value_ret_0 = lookup_module_1.get_value(None, None, None, None)
    except Exception:
        value_ret_0 = None

    assert value_ret_0 is None


# Generated at 2022-06-25 10:47:28.867661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        lookup_module = LookupModule()

        # Arguments provided as file to read
        arg = 'test.ini'
        errors = (AnsibleOptionsError, AnsibleLookupError)
        with pytest.raises(errors):
            lookup_module.run(arg)

        # Arguments provided as 'file=test.ini'
        arg = 'file=test.ini'
        errors = (AnsibleOptionsError, AnsibleLookupError)
        with pytest.raises(errors):
            lookup_module.run(arg)

        # Arguments provided as 'key=foo'
        arg = 'key=foo'
        errors = (AnsibleOptionsError, AnsibleLookupError)
        with pytest.raises(errors):
            lookup_module.run(arg)

        # Arguments provided as 'file=test

# Generated at 2022-06-25 10:47:36.395634
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing too many key with spaces delimiter
    lookup_module = LookupModule()
    ret = lookup_module.run([
        "key1 key2 key3",
        "key4",
        "key5"
    ])
    assert ret == []

    # Testing regex match
    lookup_module = LookupModule()

# Generated at 2022-06-25 10:47:37.789134
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # No exception should be thrown
    lookup_module.run(terms=[''])


# Generated at 2022-06-25 10:47:46.877608
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    cp_0 = configparser.ConfigParser()
    assert lookup_module_0.get_value(key='key', section='section', 
      dflt=None, is_regexp=False) == None
    key = 'key'
    section = 'section'
    dflt = None
    is_regexp = False
    assert lookup_module_0.get_value(key=key, section=section, dflt=dflt,
      is_regexp=is_regexp) == None


# Generated at 2022-06-25 10:47:58.503243
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Case 0 : key is contained in the configuration file
    lookup_module_0 = LookupModule()
    term_0 = 'user1=test@example.com user1=test@example.com'
    variables_0 = None
    kwargs_0 = dict(file='test.ini', section='integration', re=False, allow_no_value=True)
    term_0_key = 'user1'
    term_0_section = 'integration'
    lookup_module_0.get_value(term_0_key, term_0_section, '', False)
    # Case 1 : key is not contained in the configuration file
    lookup_module_0 = LookupModule()
    term_0 = 'user1=test@example.com user1=test@example.com'
    variables_0 = None
   

# Generated at 2022-06-25 10:48:29.331431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['user'], variable=['ansible']) == [None]


# Generated at 2022-06-25 10:48:40.423826
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: This could probably be done better
    # Create LookupModule object
    lookup_module = LookupModule()
    # Create terms (key to search in ini file)
    terms = ['foo', 'foo']
    # Create variables
    variables = {
                "FOO": "FOO_VAR_VALUE",
                "PATH": "/what/ever/path:/what/ever/path_bis",
                "BAR": "BAR_VAR_VALUE"
            }

    # Get path of ini file
    path = lookup_module.find_file_in_search_path(variables, 'files', 'user.ini')

    # Create StringIO later used to parse ini
    config = StringIO()

    # Open file using encoding

# Generated at 2022-06-25 10:48:50.949881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = "user"
    variables = None
    file_name = "ansible.ini"
    type_ = "ini"
    section = "global"
    re_ = False
    encoding = "utf-8"
    default_ = ""
    case_sensitive = False
    allow_no_value = False
    
    lookup_module_0 = LookupModule()

    # Get file path
    path = lookup_module_0.find_file_in_search_path(variables, 'files', file_name)

    # Create StringIO later used to parse ini
    config = StringIO()
    # Special case for java properties
    if type_ == "properties":
        config.write(u'[java_properties]\n')
        section = 'java_properties'

    # Open file using encoding
    contents, show_

# Generated at 2022-06-25 10:48:59.932806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser(allow_no_value=True)
    lookup_module.cp.readfp(StringIO(u'[section]\nitem=value\n'))
    term = "item"
    variables = None
    paramvals = {
      "case_sensitive": [False],
      "default": [""],
      "file": ["ansible.ini"],
      "re": [False],
      "section": ["global"],
      "type": ["ini"],
      "encoding": ["utf-8"],
      "allow_no_value": [True],
      "allow_none": [True]
    }

# Generated at 2022-06-25 10:49:02.380008
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    assert lookup_module.get_value("user", "integration", "default", False) == "john"
    assert lookup_module.get_value("user", "integration", "default", True) == ["john"]


# Generated at 2022-06-25 10:49:08.755219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [u'user', u'password']
    assert lookup_module_1.run(terms_1) == []

    lookup_module_2 = LookupModule()
    terms_2 = [u'user=test']
    assert lookup_module_2.run(terms_2) == []

# Generated at 2022-06-25 10:49:15.049255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: mock _get_file_contents to simulate file path, contents
    lookup_module = LookupModule()
    terms = ['key1']
    variables = {}
    kwargs = {}
    ret = lookup_module.run(terms, variables, **kwargs)
    print(ret)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:49:21.425540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['key1']
    variables_0 = {}
    kwargs_0 = {'file': 'ansible.ini', 'section': 'section1', 're': False, 'default': '', 'encoding': 'utf-8', 'case_sensitive': False, 'allow_no_value': False, 'allow_none': False}
    config_0 = StringIO()
    path_0 = lookup_module_0.find_file_in_search_path(variables_0, 'files', kwargs_0['file'])
    contents_0, show_data_0 = lookup_module_0._loader._get_file_contents(path_0)

# Generated at 2022-06-25 10:49:23.892528
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    cp = configparser.ConfigParser()
    cp.readfp(StringIO('[mysqld]\nuser=mysql\n'))
    lookup_module_0.cp = cp
    assert lookup_module_0.get_value('user', 'mysqld', '', False) == 'mysql'


# Generated at 2022-06-25 10:49:24.514011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 10:49:55.235405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test Case 1: {'direct': {'file': 'ansible.ini', 'type': 'ini', 'default': '', 'allow_none': False, 'case_sensitive': False}, 'var_options': {}, 'terms': ['user', 'password'], 'variables': {}}

    params = {'file': 'ansible.ini', 'type': 'ini', 'default': '', 'allow_none': False, 'case_sensitive': False}
    term_0_0 = 'user'
    term_0_1 = 'password'
    terms_0 = [term_0_0, term_0_1]
    variables_0 = {}
    var_options_0 = {}

# Generated at 2022-06-25 10:49:56.904904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    int_0 = None
    terms_0 = [int_0]
    bool_0 = lookup_module_1.run(terms_0)


# Generated at 2022-06-25 10:49:58.228032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import io
    int_0 = io.StringIO()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)

# Test for method run of class LookupModule

# Generated at 2022-06-25 10:49:59.072790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 10:50:10.419275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Run the test case when we run a simple lookup"""

    if not os.path.exists('test.ini'):
        with open('test.ini', 'w') as f:
            f.write('[section1]\n')
            f.write('key1=value1\n')
            f.write('key2=value2\n')
            f.write('key3=value3\n')
            f.write('[section2]\n')
            f.write('key1=value1\n')
            f.write('key2=value2\n')
            f.write('key3=value3\n')

    print("get_value simple lookup")
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:50:13.994328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'xxxxxxxxxxxxx'
    variables = None
    ret_0 = lookup_module_0.run(terms_0, variables)
    # check for successful call of the run method
    assert ret_0[0] == 'xxxxxxxxxxxxx'


# Generated at 2022-06-25 10:50:15.349297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0.run(int_0)


# Generated at 2022-06-25 10:50:18.705208
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    int_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser(allow_no_value=None)
    key_0 = ''
    section_0 = ''
    dflt_0 = ''
    is_regexp_0 = False
    var_0 = lookup_module_0.get_value(key_0, section_0, dflt_0, is_regexp_0)


# Generated at 2022-06-25 10:50:20.701188
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Each test method requires a single assert method to be called
    # Run the tests

    test_case_0()

# Generated at 2022-06-25 10:50:23.456039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = mock.MagicMock()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)


# Generated at 2022-06-25 10:51:19.862957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Asserts if the lookup_module.run(terms, variables, **kwargs) method runs without throwing an exception
    lookup_module_0 = LookupModule()
    int_0 = None
    list_0 = lookup_module_0.run(int_0, int_0)
    assert list_0 == []


# Generated at 2022-06-25 10:51:22.541003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    param = '[prod]\nuser=test'
    io = StringIO(param)
    lookupModule.cp.readfp(io)
    lookupModule.run(['user', 'fake', 'file=f1.ini'])



# Generated at 2022-06-25 10:51:29.488989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _test_result(test_id, term, default_expected, expected_params):
        paramvals = {}
        k = None
        params = lookup_module_1.run(term, term, paramvals)
        if not isinstance(params, list):
            params = [params]
        for param in params:
            if param and isinstance(param, string_type):
                if '=' in param:
                    if k is None:
                        raise AnsibleLookupError("lookup_plugin.run: failed to process test %d, expected key/value pair, got %s" % (test_id, param))
                    paramvals[k] = param
                    k = None
                else:
                    k = param

# Generated at 2022-06-25 10:51:35.749336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)
    var_1 = lookup_module_0.run(int_0, )


# Generated at 2022-06-25 10:51:44.614375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # no configuration
    b_0 = LookupModule()
    terms_0 = []
    try:
        lookup_run(terms_0)
        assert False
    except AnsibleOptionsError:
        pass

    # no file
    b_0 = LookupModule()
    terms_0 = ['default_value']
    try:
        lookup_run(terms_0)
        assert False
    except AnsibleOptionsError:
        pass

    # invalid file
    b_0 = LookupModule()
    terms_0 = ['default_value']
    b_0.set_options(file='/test')

    # invalid section
    b_0 = LookupModule()
    terms_0 = ['default_value']
    b_0.set_options(file='test.ini', section='test')

    # invalid key
   

# Generated at 2022-06-25 10:51:45.721782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0.run(int_0)


# Generated at 2022-06-25 10:51:49.494904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_run = lookup_module.run([], {}, {}, {'file': 'ansible.ini', 'section': 'lookup'})
    print(lookup_run)

# Generated at 2022-06-25 10:51:59.190822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = []
    try:
        lookup_module.run(terms)
    except:
        pass
    terms = None
    try:
        lookup_module.run(terms)
    except:
        pass
    try:
        lookup_module.run(terms)
    except:
        pass
    try:
        lookup_module.run(terms)
    except:
        pass
    try:
        lookup_module.run(terms)
    except:
        pass


# Generated at 2022-06-25 10:52:02.377205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = None
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(int_1)
    assert var_1 == None


# Generated at 2022-06-25 10:52:07.483303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0 == lookup_module_0
    parameters_0 = [_parse_params(term, paramvals) for term in terms]
    assert parameters_0 == parameters_0
