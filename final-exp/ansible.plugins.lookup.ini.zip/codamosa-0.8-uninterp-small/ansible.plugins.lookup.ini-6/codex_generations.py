

# Generated at 2022-06-25 10:43:22.245512
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()

    key = lookup_module_0.get_value(key, section, dflt, is_regexp)

    assert key is not None


# Generated at 2022-06-25 10:43:27.541250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module.set_variable_manager(None)
    str_arg = 'p;fh^-#7'
    list_arg = ['']
    paramvals = lookup_module.get_options()
    lookup_module.run(str_arg, None)
    lookup_module.run(list_arg, None)
    lookup_module.run(str_arg, None)
    lookup_module.run(list_arg, None)
    lookup_module.run(str_arg, None)
    lookup_module.run(list_arg, None)

# Generated at 2022-06-25 10:43:35.751756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = list()
    str_0 = 'V"G+yj2w^q0A;I}\n0e+'
    bool_0 = True
    list_1 = list()
    list_1.append(str_0)
    list_0.append(list_1)
    dict_0 = dict()
    dict_0['file'] = str_0
    dict_0['encoding'] = str_0
    dict_0['section'] = str_0
    dict_0['re'] = bool_0
    list_2 = list()
    list_2.append(dict_0)
    list_0.append(list_2)
    str_1 = lookup_module_0.run(list_0)

# Generated at 2022-06-25 10:43:47.133759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:43:58.960634
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = ';p"`K/\x7fI4Q1|>qc#oN~'
    configparser_0 = configparser.ConfigParser()
    str_1 = 'D$A|Ol_>\x7fykoLK'
    str_2 = 'K7+W#'
    str_3 = 'x^+CKjJ'
    dict_0 = {str_1:str_3, str_2:str_3}
    bool_0 = True
    lookup_module_1 = lookup_module_0
    lookup_module_1.cp = configparser_0
    str_4 = '9)s_L-:tJGdA'

# Generated at 2022-06-25 10:44:10.722141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser()
    list_0 = []

# Generated at 2022-06-25 10:44:17.855420
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = '\\?~fVg&_n'
    str_1 = 'Ez!#@}T'
    str_2 = 'B+YZ~hUc%[j^1rT@+'
    str_3 = 'omT+;!@'
    bool_0 = False
    int_0 = 9749

    lookup_module_0.cp = configparser.ConfigParser()
    lookup_module_0.cp.add_section(str_0)
    lookup_module_0.cp.set(str_0, str_1, value=str_2)
    lookup_module_0.cp.set(str_0, str_3, value=int_0)

# Generated at 2022-06-25 10:44:24.526165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_1 = LookupModule()
    file = "my.ini"
    section = "my_section"
    section_name = "my_section"
    contents = ""
    kwargs = {}
    contents += "[my_section]\n"
    contents += "key=value\n"
    res = lookup_module.run([section_name+"/key"], kwargs=kwargs, variables={'_original_file': file})
    assert res == ['value']
    res = lookup_module.run(['key'], kwargs=kwargs, variables={'_original_file': file})
    assert res == []

# Generated at 2022-06-25 10:44:29.642246
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = 'section0'
    str_1 = 'key0'
    str_2 = ''
    bool_0 = True
    # Call method get_value of lookup_module_0 for str_0, str_1, str_2 and bool_0
    var_0 = lookup_module_0.get_value(str_0,str_1,str_2,bool_0)


# Generated at 2022-06-25 10:44:41.676153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    str_0 = 'lookup.ini.fact'
    bool_1 = True
    bool_2 = False
    list_0 = [str_0]
    dict_0 = {}
    var_0 = {'lookup.ini.file': 'test.ini', 'lookup.ini.case_sensitive': bool_0, 'lookup.ini.allow_none': bool_1, 'lookup.ini.default': '', 'lookup.ini.re': bool_2, 'lookup.ini.encoding': 'utf-8', 'lookup.ini.section': 'section1'}
    str_1 = 'section2'
    str_2 = 'section1'
    str_3 = 'section1'

# Generated at 2022-06-25 10:44:53.230050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check if output of run is usefull
    lookup_module_0 = LookupModule()
    terms_0 = ['webapp.url']
    variables_0 = {'ansible_env': {'HOME': '/Users/yannigperre'}, 'ansible_check_mode': False, 'group_names': ['all', 'ungrouped']}
    paramvals = {"file": "ansible.ini", "type": "ini", "section": "global", "re": False, "encoding": "utf-8", "default": '', "case_sensitive": False, "allow_no_value": False}
    result_0 = lookup_module_0.run(terms_0, variables_0, **paramvals)

    # check if we have a list as output
    if not isinstance(result_0, list):
        raise

# Generated at 2022-06-25 10:45:04.011682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    terms = ['user', 'password', 'another']
    variables = {'ansible_app_user': 'appuser', 'ansible_app_password': 'apppass', 'ansible_app_another': 'appanother'}

# Generated at 2022-06-25 10:45:14.723517
# Unit test for method get_value of class LookupModule

# Generated at 2022-06-25 10:45:19.441096
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section("section")
    cp.set("section", "key", "value")
    lookup_module.cp = cp
    assert lookup_module.get_value("key", "section", None, False) == "value"


# Generated at 2022-06-25 10:45:28.101072
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Load test:
    # ==========

    # 1.
    # Test loading of properties
    #
    # Params:
    # =======
    file_path = './test_run.txt'
    terms = ['user=yannig']
    variables = None

    # Expected Result:
    # ================
    expected_result = {
        'allow_no_value': False,
        'case_sensitive': False,
        'default': '',
        'encoding': 'utf-8',
        'file': './test_run.txt',
        're': False,
        'section': 'global',
        'type': 'ini'
    }

    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()

    # Case 1.1

# Generated at 2022-06-25 10:45:35.572092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    pargs = [{'file': 'ansible.ini', 'type': 'ini', 'default': '', 'section': 'global'}]
    terms = ['pagination']
    pkwargs = {}
    ret = lookup_module_0.run(terms, **pkwargs)
    assert ret == []
    assert lookup_module_0._deprecated_types  == ['inline_options']
    assert lookup_module_0._deprecated_msg == "You can specify options for the lookup like this `lookup('file', 'section/key file=path_to_file.ini type=ini')`"
    assert lookup_module_0._deprecated_alternative == None

# Generated at 2022-06-25 10:45:45.102476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    # Get substring of filepath
    lookup_module.cp.read("../../../ansible/plugins/lookup/ini.py")
    assert("ini.py" == lookup_module.cp.get("DEFAULT", "plugin"))
    return "OK"


# Generated at 2022-06-25 10:45:51.528899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ServerAlias']
    variables = {}
    kwargs = {}
    assert type(lookup_module.run(terms, variables, **kwargs)) == list


# Generated at 2022-06-25 10:46:02.180845
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.seek(0, os.SEEK_SET)
    lookup_module.cp.readfp(config)
    # Case 1
    assert lookup_module.get_value("key1", "section1", None, False) == "value1"
    # Case 2
    assert lookup_module.get_value("key3", "section1", None, False) is None
    # Case 3

# Generated at 2022-06-25 10:46:11.211541
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()

    section = 'integration'
    key = 'user'
    dflt = 'yperre'
    is_regexp = False

    # Call method get_value with invalid arguments
    try:
        lookup_module_1.get_value(key, section, dflt, is_regexp)
    except Exception as e:
        assert isinstance(e, AnsibleOptionsError)
        assert str(e) == 'No path specified when searching for file in lookup'


# Generated at 2022-06-25 10:46:27.011309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Default values - no options
    terms = ['user', 'password']
    result = lookup_module.run(terms)
    assert result == ['yannig', 'secret']

    # Default values - no options
    terms = ['user', 'password3']
    result = lookup_module.run(terms)
    assert result == ['yannig', '']

    # Default values - no options
    terms = ['user', 'password3']
    result = lookup_module.run(terms, default='nothing')
    assert result == ['yannig', 'nothing']

    # File ansible.properties
    terms = ['user', 'password']
    result = lookup_module.run(terms, type='properties')
    assert result == ['yannig', 'secret']

    # Section integrations
    result

# Generated at 2022-06-25 10:46:33.753095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables
    lookup_module_0 = LookupModule()
    # test_terms
    test_terms_0 = ['user']
    test_terms_1 = None
    # test_variables
    test_variables_0 = None
    test_variables_1 = {}
    # test_kwargs
    test_kwargs_0 = {'file': 'users.ini', 'section': 'integration'}
    test_kwargs_1 = {}
    # test_ret
    test_ret_0 = ['root']
    test_ret_1 = []
    # test_ret_2 = ['usr1','usr2','usr3']
    # test_ret_3 = ['usr1','usr2']
    # test_ret_4 = ['']


# Generated at 2022-06-25 10:46:40.809308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes

    # test 1:
    #   INI file:
    #       [section1]
    #       key1=value1
    #       key2=value2
    #   Expected result: ['value1', 'value2']
    terms = ['key1', 'key2']
    data = '''[section1]
key1=value1
key2=value2
'''
    config = StringIO()
    config.write(to_bytes(data, errors='surrogate_or_strict'))
    config.seek(0, os.SEEK_SET)
    config = configparser.ConfigParser()
    config.readfp(config)
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = config
    assert lookup

# Generated at 2022-06-25 10:46:45.820949
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser()
    assert lookup_module_0.get_value('test_key', 'test_section', 'test_dflt', True) == ['test_dflt']

# Generated at 2022-06-25 10:46:46.789011
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    assert LookupModule().get_value("key", "section", "default", True) == []

# Generated at 2022-06-25 10:46:52.842044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run method of class LookupModule')
    lookup_module_0 = LookupModule()
    #Test with only one required parameter
    result = lookup_module_0.run(terms=['user'], variables=None)
    assert result == [u'root']
    print('Result is as expected')
    #Test with only one required parameter and a default value for the second parameter
    result = lookup_module_0.run(terms=['user'], variables=None, section='users', type='ini')
    assert result == [u'root']
    print('Result is as expected')
    #Test with two required parameters and a default value for the third parameter
    result = lookup_module_0.run(terms=['user'], variables=None, section='users', file='/etc/passwd')

# Generated at 2022-06-25 10:47:00.806128
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    cp = configparser.RawConfigParser()
    lookup_module.cp = cp
    cp.add_section('global')
    cp.set('global','user','root')
    key = 'user'
    section = 'global'
    dflt = ''
    is_regexp = False
    value = lookup_module.get_value(key, section, dflt, is_regexp)
    assert value == 'root'


# Generated at 2022-06-25 10:47:11.168766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO

    lookup_module_1 = LookupModule()

    # Replace with a mock for testing
    lookup_module_1._loader = getattr(__import__('ansible.parsing.yaml.objects', fromlist=['BaseLoader']), 'BaseLoader')

    lookup_module_1.set_options(direct=dict(encoding='utf-8', case_sensitive=False, re=False, allow_none=False))

    # Set paramvals
    paramvals = {'type': 'ini',
                 'file': 'ansible.ini',
                 'section': 'global',
                 'default': '',
                 'encoding': 'utf-8',
                 'case_sensitive': False,
                 're': False,
                 'allow_none': False}

   

# Generated at 2022-06-25 10:47:17.807511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # declaration
    lookup_module = LookupModule()

    # fisrt test with one key and no option passed
    t = [u"key1"]
    p = {u'file': u'../lookup_plugins/ini.ini', u'default': u'', u're': False, u'type': u'ini', u'encoding': u'utf-8', u'section': u'global'}
    ret = lookup_module.run(t, p)
    assert ret == [u'value1']

    p[u'section'] = u'section1'
    ret = lookup_module.run(t, p)
    assert ret == [u'value2']

    # test with regexp
    p[u're'] = True
    ret = lookup_module.run(t, p)
    assert ret == []

# Generated at 2022-06-25 10:47:27.229866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = StringIO()
    paramvals = defaultdict(lambda: '')
    paramvals['file'] = 'test.ini'
    paramvals['section'] = 'section1'
    paramvals['default'] = ''
    paramvals['re'] = False
    paramvals['case_sensitive'] = False
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()
    term_1 = 'reg1'
    variables_1 = None
    lookup_module_1.run(terms=term_1, variables=variables_1, paramvals=paramvals)


# Generated at 2022-06-25 10:47:47.666246
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    cp = configparser.ConfigParser(delimiters=('='), allow_no_value=True)
    cp.add_section('section')
    cp.set('section', 'key', 'value')
    lookup_module.cp = cp
    assert lookup_module.get_value('key', 'section', 'default', False) == 'value'


# Generated at 2022-06-25 10:47:55.553797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v = dict()
    v['file'] = 'test.ini'
    v['type'] = 'ini'
    v['section'] = 'section1'
    v['re'] = True

    lookup = LookupModule()
    terms = '.*'
    r = lookup.run(terms, None, **v)

    assert len(r) == 2
    assert r[0] == 'value1'
    assert r[1] == 'value2'


# Generated at 2022-06-25 10:47:57.310962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run('key1=value1') == ['value1']



# Generated at 2022-06-25 10:48:06.594879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}

# Generated at 2022-06-25 10:48:09.487518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()

    # lookup_module_1.cp.readfp(config)


# Generated at 2022-06-25 10:48:17.861989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = None
    contents = to_text('')

    # Call method run of class LookupModule with arguments
    # First argument : terms (list of 3 elements)
    terms = ['user', 'host', 'port']
    # Second argument : variables
    variables = None
    # Third argument : kwargs
    kwargs = {'file': 'ansible.ini', 'section': 'global'}
    try:
        lookup_module = LookupModule()
        result = lookup_module.run(terms, variables, **kwargs)
    except Exception as e:
        print(e)

    # Check value of result
    assert result == ['bob', 'localhost', '']


# Generated at 2022-06-25 10:48:27.230384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'key_name'
    variables_0 = {'var': 'ansible'}
    kwargs_0 = {'file': 'ansible.ini', 'section': 'global', 're': False, 'case_sensitive': False, 'allow_no_value': False, 'allow_none': False, 'default': '', 'encoding': 'utf-8', 'type': 'ini'}
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms=[term_0], variables=[variables_0], **kwargs_0)
    assert ret_0 == ['value']

# Generated at 2022-06-25 10:48:35.633699
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    cp = configparser.ConfigParser()
    cp.readfp(StringIO(u'[s1]\nk1 = v1\nk2 = v2\n[s2]\nk3 = v3\nk4 = v4\n'))
    lookup_module = LookupModule()
    lookup_module.cp = cp
    section = "s1"

    # Test1: key not found in section
    key = "k0"
    dflt = "v0"
    ret = lookup_module.get_value(key, section, dflt, False)
    assert ret == dflt

    # Test2: key found in section, is_regexp = False
    key = "k1"
    dflt = "v0"

# Generated at 2022-06-25 10:48:44.083112
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    list_config_0 = ['[test]', 'test_key_0 = test_value_0', 'test_key_1 = test_value_1', 'test_key_2 = test_value_2']
    list_config_1 = ['[test]', 'test_key_0 = test_value_0', 'test_key_1 = test_value_1', 'test_key_2 = test_value_2', 'test_key_3 = test_value_3', 'test_key_4 = test_value_4']
    list_config_2 = ['[test]', 'test_key_0 = test_value_0', 'test_key_1 = test_value_1', 'test_key_2 = test_value_2', 'false_key_3 = false_value_3']
    dict_config

# Generated at 2022-06-25 10:48:47.942802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([]) == []



# Generated at 2022-06-25 10:49:24.984635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 10:49:27.393419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:49:30.612982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = []
    variables_1 = {}
    kwargs_1 = {}
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == []



# Generated at 2022-06-25 10:49:32.130740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run() == []


# Generated at 2022-06-25 10:49:38.083853
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    paramvals = {
      'type': 'ini',
      're': False,
      'file': 'ansible.ini',
      'encoding': 'utf-8',
      'default': '',
      'case_sensitive': False,
      'allow_no_value': False
    }
    section = 'global'
    key = 'user'
    dflt = 'yperre'
    is_regexp = True
    lookup_module_1.get_value(key, section, dflt, is_regexp)


# Generated at 2022-06-25 10:49:42.717432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['user', 'user = production', 'user = production file = ansible.ini', 'foo = bar']
    variables = None
    direct = {'file': 'ansible.ini', 'type': 'ini', 'default': '', 'section': 'global', 're': False, 'allow_no_value': False}
    lookup_module.set_options(var_options=variables, direct=direct)
    lookup_module.run(terms, variables=variables, **direct)


# Generated at 2022-06-25 10:49:50.809155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo']
    variables_0 = None
    paramvals = {}
    path_0 = '.'
    ret_0 = lookup_module_0.run(terms_0, variables_0, file=path_0, type='ini', section='ini_section', case_sensitive=False, allow_no_value=False)
    assert(ret_0 == ['bar'])



# Generated at 2022-06-25 10:49:58.692489
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    paramvals = defaultdict(lambda: '')
    paramvals['type'] = 'ini'
    paramvals['file'] = 'tests/ini_test.ini'
    paramvals['section'] = 'section1'
    paramvals['re'] = False
    paramvals['encoding'] = 'utf-8'
    paramvals['default'] = ''
    paramvals['case_sensitive'] = False
    paramvals['allow_no_value'] = False
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=paramvals)
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.read("tests/ini_test.ini")
    assert lookup_module.get_value("key1", "section1", "", False) == "value1"



# Generated at 2022-06-25 10:50:04.714531
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: look for a more elegant way to test this (perhaps by creating a mock config object)
    # Create a class to replace the config object
    class ConfigParser():
        def __init__(self, *args):
            self.data = {'section1': {'key1': 'some value1'}}
        def items(self, section):
            return self.data[section].items()
        def get(self, section, key):
            return self.data[section][key]

    # Mock config object
    ConfigParser.get = ConfigParser().get
    ConfigParser.items = ConfigParser().items
    # Change self.cp object by mocked object
    exec("lookup_module_0.cp = ConfigParser()")

    # Basic test

# Generated at 2022-06-25 10:50:12.214266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    lookup_module_obj.set_options(var_options={}, direct={'file': 'ansible.ini', 'section': 'global', 're': False, 'encoding': 'utf-8', 'type': 'ini', 'default': '', 'case_sensitive': False})
    lookup_module_obj.get_options()
    lookup_module_obj.cp = configparser.ConfigParser(allow_no_value=False)
    lookup_module_obj.cp.optionxform = to_native
    lookup_module_obj.cp.readfp(StringIO(u'[global]\nuser=Yannig'))
    assert lookup_module_obj.run(['user']) == ['Yannig']

# Generated at 2022-06-25 10:51:31.930093
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Unit test for method get_value of class LookupModule
    # 
    # 		    Retrieve all values from a section using a regexp
    # 		
    lookup_module_0 = LookupModule()
    term_0 = 'user'
    paramvals_0 = {'default': '', 'case_sensitive': False, 'file': 'users.ini', 're': False, 'encoding': 'utf-8', 'allow_no_value': False, 'type': 'ini', 'allow_none': False, 'section': 'integration'}

    lookup_module_0 = LookupModule()
    term_1 = 'user'

# Generated at 2022-06-25 10:51:32.764044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run == lookup_module_0.run


# Generated at 2022-06-25 10:51:44.406617
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    i = 0

    # Test scenario 1
    # Test scenario description:
    # In this scenario, we check that the function 'run' behaves correctly
    # for the following parameters:
    # - term = 'user', section = 'integration', file = 'users.ini'
    # Expected result:
    # The function 'run' should return a list of string equal to ['toto']
    terms = ['user']
    variables = None
    paramvals = {'case_sensitive': False,
                 'type': 'ini',
                 'file': 'tests/utils/lookup_plugins/ini_file_for_unittests.ini',
                 're': False,
                 'encoding': 'utf-8',
                 'section': 'integration',
                 'default': ''}
    expected_result = ['toto']

    lookup_

# Generated at 2022-06-25 10:51:48.572936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_ansible_options(tmpdir):
        f = tmpdir.join('test1')
        f.write(u'''[test]
name=test
foo=bar
''')
        lookup_module = LookupModule()
        lookup_module.cp = configparser.ConfigParser()
        lookup_module.cp.read_file(open(f.strpath))

        assert lookup_module.get_value('name', 'test', 'default', False) == 'test'
        assert lookup_module.get_value('foo', 'test', 'default', False) == 'bar'
        assert lookup_module.get_value('no_key', 'test', 'default', False) == 'default'


# Generated at 2022-06-25 10:51:54.366078
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    os.environ['__ansible_tmp_vars'] = "{\"var1\": false, \"var2\": false, \"var3\": false}"
    lookup_module.cp.read_string("[section]\nkey1=val1\nkey2=val2\nkey3=val3")
    assert lookup_module.get_value("key1", "section", "default", False) == "val1"
    assert lookup_module.get_value("no_key", "section", "default", False) == "default"
    assert lookup_module.get_value(".*", "section", "default", True) == ['key1=val1', 'key2=val2', 'key3=val3']
    assert lookup_

# Generated at 2022-06-25 10:52:02.041695
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test the first branch
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    cp.read('./ansible.cfg')
    lookup_module.cp = cp
    value = lookup_module.get_value('inventory', 'defaults', 'default_value', False)
    assert value == '/etc/ansible/hosts'


# Generated at 2022-06-25 10:52:10.948071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Break the class constructor
    lookup_module.get_options = lambda: None
    lookup_module.find_file_in_search_path = lambda variables, files, file: file
    lookup_module._loader = lambda: None
    lookup_module._loader._get_file_contents = lambda path: ("""[global]
user=Global User
password=Global Password

[integration]
user=Integration User

[production]
user=Production User
""", 'xyz')

    # Test missing section
    try:
        assert lookup_module.run([':'])
        assert False
    except AnsibleLookupError as e:
        assert "No section ':' in " in to_native(e)

    # Test read from integration section

# Generated at 2022-06-25 10:52:16.407763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Retrieve a value using a non-regexp key in the global section"""
    lookup_module = LookupModule()
    term = 'user'
    kwargs = {'_raw_params': "file=users.ini", '_terms': ['user']}
    value = lookup_module.run(terms=term, variables=None, **kwargs)
    assert value == ['ansible_user']


# Generated at 2022-06-25 10:52:21.150729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test to load an ini file and extract a value from section.
    """
    lookup_module_0 = LookupModule()

    lookup_module_0.cp = configparser.ConfigParser()
    config_0 = StringIO()
    config_0.write(u'[section1]\n')
    config_0.write(u'key1=value1\n')
    config_0.write(u'key2=value2\n')
    config_0.write(u'key3=value3\n')
    config_0.write(u'key4=value4\n')
    config_0.seek(0, os.SEEK_SET)
    lookup_module_0.cp.readfp(config_0)


# Generated at 2022-06-25 10:52:27.381376
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    fp = StringIO('[foo]\nbar=baz')
    cp = configparser.ConfigParser()
    cp.readfp(fp)
    assert LookupModule.get_value(LookupModule, 'bar', 'foo', '', False) == 'baz'