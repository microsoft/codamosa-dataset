

# Generated at 2022-06-25 10:43:19.478662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: There is no assert for this method
    pass

# Generated at 2022-06-25 10:43:28.908812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    section_0 = 'integration'
    section_1 = 'production'
    file_0 = 'users.ini'
    value_1 = 'Yannig'
    type_0 = 'ini'
    file_1 = 'user.properties'
    key_0 = 'user.name'
    file_2 = 'test.ini'
    re_0 = True
    key_1 = '.*'
    section_2 = 'section1'
    file_3 = 'mysql.ini'
    section_3 = 'mysqld'
    allow_no_value_0 = True
    lookup_module_0 = LookupModule()
    lookup_module_0.get_value(key_0, section_1, false, false)

# Generated at 2022-06-25 10:43:39.413526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    cp = configparser.ConfigParser()
    config = StringIO()
    config.write('[java_properties]')
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)
    lookup_module.cp = cp
    terms = ['key1']
    variables = dict()
    paramvals = dict()
    paramvals['file'] = 'file'
    lookup_module.set_options(var_options=variables, direct=paramvals)
    assert lookup_module.run(terms, variables) == []
    cp = configparser.ConfigParser()
    config = StringIO()
    config.write('[java_properties]\n')
    config.write('key1=value1')
    config.seek(0, os.SEEK_SET)


# Generated at 2022-06-25 10:43:48.028943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["key", "key", "key"]
    variables = None
    file = "ansible.ini"
    section = "global"
    re = False
    default = ""
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, file=file, section=section, re=re, default=default)

    terms = ["key", "key", "key"]
    file = "ansible.ini"
    section = "global"
    re = False
    default = ""
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms, variables, file=file, section=section, re=re, default=default)

# Generated at 2022-06-25 10:43:59.072725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    list_0 = []
    lookup_module_0 = LookupModule()
    str_0 = '[[target]]'
    str_1 = '[[target]]'
    bool_1 = bool(str_0)
    bool_2 = bool(str_1)
    bool_3 = bool(str_0)
    bool_4 = bool(str_1)
    bool_5 = bool(str_0)
    bool_6 = bool(str_1)
    bool_7 = bool(None)
    bool_8 = bool(False)
    bool_9 = bool(False)
    bool_10 = bool(False)
    bool_11 = bool(False)
    bool_12 = bool(str_0)
    bool_13 = bool(str_1)
    # ERROR: C

# Generated at 2022-06-25 10:44:04.385638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    list_0 = []
    lookup_module_0 = LookupModule()
    params_0 = {}
    terms_0 = [u'ansible.ini']
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == [u'vault_password = !vaultpass']


# Generated at 2022-06-25 10:44:14.654913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module = LookupModule()
    to_text_0 = StringIO()
    list_0 = []
    to_text_1 = StringIO()
    from ansible.module_utils._text import to_text

    # Test case with term as bool_0 and paramvals as bool_0
    # testing for expected Behaviour
    lookup_module.run(bool_0, bool_0)
    assert True

    lookup_module.run(list_0, to_text_0)
    assert True

    lookup_module.run(list_0, to_text_1)
    assert True


# unit test for method get_value of class LookupModule

# Generated at 2022-06-25 10:44:17.303582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    list_0 = []
    lookup_module_0 = LookupModule()
    assert (list_0 == lookup_module_0.run(list_0))


# Generated at 2022-06-25 10:44:24.796322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    LookupModule_0 = LookupModule()
    str_0 = None
    tuple_0 = (
        str_0,
    )
    options_0 = dict()
    options_0['file'] = str_0
    options_0['section'] = str_0
    options_0['type'] = str_0
    options_0['case_sensitive'] = bool_0
    options_0['allow_no_value'] = bool_0
    options_0['allow_none'] = bool_0
    options_0['encoding'] = str_0
    options_0['re'] = bool_0
    options_0['default'] = str_0
    LookupModule_0.run(tuple_0, variables=options_0)

# Generated at 2022-06-25 10:44:36.146456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    valid_keys = []
    idp = 0
    boolean = True
    list_11 = []
    list_11 = []
    lookup_module_0 = LookupModule()
    params = defaultdict(lambda: '')
    thiskey = 'key'
    var = None
    valid_keys = []
    lookup_module_0 = LookupModule()
    ret = None
    terms = []
    var = None
    valid_keys = []
    lookup_module_0 = LookupModule()
    params = None
    thiskey = 'key'
    phrase = ''
    k = ''
    var = None
    valid_keys = []
    lookup_module_0 = LookupModule()
    ret = []
    variables = {}
    term = ''
    key = ''
    paramvals = {}
    path = ''


# Generated at 2022-06-25 10:44:48.874616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: add tests with bool_0, bool_1, bool_2, bool_3
    # TODO: add tests with str_0, str_1, str_2, str_3
    assert (lookup_module_0.run(terms=list_0, variables=bool_0)) == list_0


# Generated at 2022-06-25 10:44:52.382275
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bool_0 = None
    list_0 = []
    str_0 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.get_value(bool_0, list_0, str_0, list_0)


# Generated at 2022-06-25 10:44:59.084262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    list_0 = []
    str_0 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0, bool_0)
    assert var_0 == []


# Generated at 2022-06-25 10:45:08.611729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input = [
        [
            {
                'file': 'test.ini',
                'allow_no_value': 'False'
            }
        ],
        [
            {
                'type': 'properties',
                'file': 'test.ini',
                'allow_no_value': 'False'
            }
        ]
    ]
    expected = [
        [
            'test_value'
        ],
        [
            'properties_value'
        ]
    ]
    result = []
    for i in range(len(input)):
        value = LookupModule().run(terms = ['test'], variables = None, **input[i][0])
        result.append(value)
    assert result == expected

# Generated at 2022-06-25 10:45:13.823200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    list_0 = []
    str_0 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0, list_0, str_0)

# Generated at 2022-06-25 10:45:20.403818
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    assert 'ret' in locals()
    try :

        # Test case 0
        bool_0 = None
        list_0 = []
        str_0 = '0X(>L@E'
        lookup_module_0 = LookupModule()
        var_0 = lookup_module_0.get_value(bool_0, list_0, str_0, list_0)

    except Exception as e:
        assert False, "Exception caught in test_LookupModule_get_value"


# Generated at 2022-06-25 10:45:24.888621
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bool_0 = None
    str_0 = '2a%%)S'
    str_1 = 'W|pv>'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.get_value(bool_0, str_0, str_1, bool_0)


# Generated at 2022-06-25 10:45:28.024462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['0X(>L@E'], variables=None, allow_none=False)
    lookup_module_0.run(terms=['0X(>L@E'], variables=None)


# Generated at 2022-06-25 10:45:33.199068
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bool_0 = None
    list_0 = []
    str_0 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.get_value(bool_0, list_0, str_0, list_0)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_get_value()

# Generated at 2022-06-25 10:45:33.751333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:45:49.179425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '&b|>'
    str_1 = '%|'
    lookup_module_0 = LookupModule()
    params = []
    var_0 = ['key']
    str_2 = '9S<H$'
    str_3 = 'Z,G'
    str_4 = 'key=value'
    str_5 = 'E|2'
    lookup_module_0.set_options(var_0)
    var_1 = _parse_params(str_0, str_1)
    var_2 = lookup_module_0.run(var_0)


# Generated at 2022-06-25 10:45:55.798403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    
    path = os.path.dirname(os.path.realpath(__file__)) + '/test.ini'
    path = path.replace('/tests','/')

    terms = ['foo1', 'foo2']

    ret = []
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms, path)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:45:57.760686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_0 = lookup_module.run(var_0, var_0, var_0)


# Generated at 2022-06-25 10:46:04.573337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'duplicate-key=value'
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(term)
    except AnsibleOptionsError as aoe:
        assert aoe.msg == "No key to lookup was provided as first term with in string inline options: duplicate-key=value"
        assert aoe.orig_exc is None

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:46:12.514005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = dict()
    var_1['file'] = 'ansible.ini'
    var_1['allow_none'] = False
    var_1['case_sensitive'] = False
    var_1['encoding'] = 'utf-8'
    str_0 = '0X(>L@E'
    var_1['default'] = str_0
    var_1['section'] = 'global'
    var_1['re'] = False
    var_1['type'] = 'ini'
    var_2 = lookup_module_0.run(var_0, var_1)
    assert(var_2 == [])



# Generated at 2022-06-25 10:46:15.443180
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    var_0 = []
    str_0 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_1 = lookup_get_value(var_0, var_0, str_0, var_0)


# Generated at 2022-06-25 10:46:21.631953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []

    lookup_module_0 = LookupModule()
    str_0 = '0X(>L@E'

    # Test with params 1:
    var_2, str_1 = lookup_module_0.run(var_0, str_0, var_1)
    assert var_2 == var_0
    assert str_1 == str_0



# Generated at 2022-06-25 10:46:27.043703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = ['s', 'U_Z/c%~']
    paramvals = {'section': 'section1'}
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_0.run(var_0, var_1, **paramvals)
    assert type(var_2) == list
    assert var_2 == var_0


# Generated at 2022-06-25 10:46:35.127409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = {}
    var_2 = 'properties'
    var_3 = 'ansible.ini'
    var_4 = 'global'
    str_0 = '0X(>L@E'
    var_5 = 'utf-8'
    var_6 = False
    lookup_module_0 = LookupModule()
    var_7 = [var_0, var_1, var_2, var_3, var_4, str_0, var_5, var_6]
    var_8 = []
    var_9 = lookup_module_0.run(var_7, var_8)


# Generated at 2022-06-25 10:46:39.615162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [u'0X(>L@E']
    var_1 = lookup_module_0.run(var_0, None, file='ansible.ini', encoding='utf-8')
    # assert var_1 == [u'g6UaG6Ua']


if __name__ == '__main__':
    # test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:46:57.921827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = []
    str_1 = 'dSX9/N,}'
    lookup_module_1 = LookupModule()
    list_2 = lookup_module_1.run(list_1, variables=str_1, paramvals=list_1)


# Generated at 2022-06-25 10:47:02.278770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  suite = unittest.TestSuite()
  suite.addTest(TestLookupModule(methodName='test_case_0'))
  results = unittest.TextTestRunner().run(suite)
  return (True if results.wasSuccessful() else False)

# Generated at 2022-06-25 10:47:04.485764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    str_0 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_0.run(var_0, var_1)


# Generated at 2022-06-25 10:47:11.988950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = StringIO()
    config.write(u'[java_properties]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'key3=value3\n')
    config.write(u'key4=value4\n')
    config.write(u'key5=value5\n')
    config.seek(0, os.SEEK_SET)

    cp = configparser.RawConfigParser(allow_no_value=True)
    cp.readfp(config)

    var_0 = []
    str_0 = 'key1'
    str_1 = 'java_properties'
    str_2 = 'default value'
    bool_0 = False
    lookup_module_0 = Look

# Generated at 2022-06-25 10:47:23.047553
# Unit test for method get_value of class LookupModule

# Generated at 2022-06-25 10:47:30.061532
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    ini_0 = configparser.ConfigParser()
    key_0 = '&'
    section_0 = '}-0F'
    dflt_0 = []
    is_regexp_0 = [False]
    var_1 = lookup_get_value(lookup_module_0, key_0, section_0, dflt_0, is_regexp_0)

# Generated at 2022-06-25 10:47:36.315659
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    var_0 = ['_L6QJ#.6@', '^A', 'k#/:6D>', 'U;I6)', '55FZ9QEJ', 'wk=', '+', '7J:s<', 'mT{', '+', 'nsyZ', 'r']
    str_0 = '8R'
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.get_value(var_0, str_0, str_0, str_0)


# Generated at 2022-06-25 10:47:40.055075
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    var_0 = []
    str_0 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_1 = lookup_get_value(var_0, var_0, str_0, var_0)



# Generated at 2022-06-25 10:47:51.186213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '0X(>L@E'
    str_1 = 'YVN\n0X(>L@E'
    lookup_module_0.run(str_1, str_0)
    str_2 = '4d@I7H['
    str_3 = 'wS.'
    lookup_module_0.run(str_2, str_3)
    str_4 = '0X(>L@E'
    str_5 = 'YVN\n0X(>L@E'
    lookup_module_0.run(str_5, str_4)
    str_6 = '4d@I7H['
    str_7 = 'wS.'

# Generated at 2022-06-25 10:47:58.618873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Running test test_LookupModule_run')
    arg_1 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(arg_1)
    print('var_1: ' + str(var_1))
    print('Function test_LookupModule_run passed')


# Generated at 2022-06-25 10:48:40.396419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableSequence
    import os

    class MockModule(object):
        def __init__(self):
            self.params = {
            }

        def fail_json(self, *args, **kwargs):
            self.exception = args[0]
            self.fail_args = args
            self.fail_kwargs = kwargs
            raise Exception(args[0])

    class MockConfigParser(object):
        def __init__(self):
            self.items_call_count = 0
            self.get_call_count = 0

        def items(self, x):
            self.items_call_count

# Generated at 2022-06-25 10:48:46.035734
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    x_0 = []
    x_1 = []
    x_2 = '0X(>L@E'
    x_3 = []
    lookup_module_0 = LookupModule()
    lookup_module_0.get_value(x_0, x_1, x_2, x_3)


# Generated at 2022-06-25 10:48:46.842101
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    run_test_case(test_case_0)

# Generated at 2022-06-25 10:48:57.023737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])
    lookup_module_0.run([],[])
    lookup_module_0.run([],[],file='ansible.ini',default='',re=True,case_sensitive=False)
    lookup_module_0.run([],[],file='ansible.ini',default='',re=True,case_sensitive=False,section='section1',encoding='utf-8')
    lookup_module_0.run([],[],file='ansible.ini',default='',re=True,case_sensitive=False,section='section1',encoding='utf-8',type='ini')

# Generated at 2022-06-25 10:49:01.957816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = _parse_params(term, paramvals)
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables, **kwargs) == (ret)

# Generated at 2022-06-25 10:49:10.328200
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    var_0 = []
    str_0 = '0X(>L@E'
    lookup_module_0 = LookupModule()
    var_1 = lookup_get_value(var_0, var_0, str_0, var_0)

## Unit test for method run of class LookupModule
#def test_LookupModule_run():
#    terms_0 = var_0
#    variables_0 = var_0
#    lookup_module_0 = LookupModule()
#    var_1 = lookup_module_0.run(terms_0, variables_0, var_0)


# Generated at 2022-06-25 10:49:17.833031
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Store current values of environment variables
    store_environment_variables = dict(os.environ)

    # Test run with default values for params
    lookup_module_0 = LookupModule()
    contents_0 = 'R``>pzZ(1'
    params_0 = {}
    str_0 = '0X(>L@E'
    str_1 = 'Qnh'
    params_1 = {}
    str_2 = '0X(>L@E'
    str_3 = 'Qnh'
    text_0 = lookup_module_0.run(contents_0, params_0, str_0, str_1)

    # Test run with valid values for params
    lookup_module_1 = LookupModule()
    contents_1 = 'R``>pzZ(1'
   

# Generated at 2022-06-25 10:49:20.197924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = 'B3>VON#'
    var_1 = []
    var_1 = lookup_module_0.run(var_0, var_1, var_0)


# Generated at 2022-06-25 10:49:23.379623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # [Test input parameters]

    # terms : [{'type': 'str', 'value': 'str'}, {'type': 'str', 'value': 'str'}]
    # variables : {'type': 'dict', 'value': {'type': 'str', 'value': 'str'}}
    # kwargs : {'type': 'dict', 'value': {'type': 'str', 'value': 'str'}}

    # Test code here
    pass

# Generated at 2022-06-25 10:49:34.473867
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    key_0 = '0X(>L@E'
    section_0 = '0X(>L@E'
    dflt_0 = '0X(>L@E'
    is_regexp_0 = True
    test_var = lookup_module_1.get_value(key_0, section_0, dflt_0, is_regexp_0)
    test_var = lookup_module_1.get_value(key_0, section_0, dflt_0, is_regexp_0)
    test_var = lookup_module_1.get_value(key_0, section_0, dflt_0, is_regexp_0)

# Generated at 2022-06-25 10:50:52.274533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    lookup_module_0.get_options()
    lookup_module_0.get_value('key', 'section', 'dflt', 'is_regexp')
    lookup_module_0.run({})

# Generated at 2022-06-25 10:50:53.758692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    run = LookupModule()
    arr = ['test']
    ret = run.run(arr)
    assert ret == None

# Generated at 2022-06-25 10:50:55.275624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:51:04.211476
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    lookup_module_0.cp = configparser.ConfigParser()
    lookup_module_0.cp.readfp(StringIO("[section1]\nkey1=value1\nkey2=value2\n"))
    str_0 = ".*"
    str_1 = "section1"
    str_2 = ""
    # Execution
    var_0 = lookup_module_0.get_value(str_0, str_1, str_2, True)
    # Assertion
    assert var_0 == ["value1", "value2"]

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_get_value()

# Generated at 2022-06-25 10:51:08.109493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert func_0(str_0, str_0, str_0) == class_0(str_0, str_0, str_0)


# Generated at 2022-06-25 10:51:14.118438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        '',
        '',
    ]
    var_0 = lookup_module_0.run(var_0)
    assert var_0 is None

# Generated at 2022-06-25 10:51:24.133898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    boolean_0 = True
    str_1 = ''
    terms_0 = [str_0]
    boolean_1 = True
    str_2 = ''
    # TODO: Need a better way to test this
    # var_0 = lookup_module_0.run(terms_0, default=str_1, re=boolean_0, section=str_2, case_sensitive=boolean_1, type=str_0, allow_no_value=boolean_1)
    # Tested with:
    # var_0 = lookup_module_0.run(terms_0, re=boolean_0, allow_no_value=boolean_1, default=str_1, type=str_0, section=str_2, case_sensitive

# Generated at 2022-06-25 10:51:27.216486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    bool_0 = bool(str_0)
    bool_1 = bool(str_1)
    lookup_module_0.run(str_0, bool_0, bool_0, bool_1, bool_1, bool_1)


# Generated at 2022-06-25 10:51:28.877833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(str_0, str_0, str_0)



# Generated at 2022-06-25 10:51:40.892340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_plugin_0 = LookupModule()
  str_0 = '2'
  str_1 = '2'
  str_2 = '2'
  str_3 = '2'
  str_4 = '2'
  str_5 = '2'
  str_6 = '2'
  str_7 = '2'
  str_8 = '2'
  str_9 = '2'
  str_10 = '2'
  str_11 = '2'
  str_12 = '2'
  str_13 = '2'
  str_14 = '2'
  str_15 = '2'
  str_16 = '2'
  str_17 = '2'
  str_18 = '2'
  str_19 = '2'