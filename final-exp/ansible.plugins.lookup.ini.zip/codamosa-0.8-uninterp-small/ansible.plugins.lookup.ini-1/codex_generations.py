

# Generated at 2022-06-25 10:43:20.921835
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0 = LookupModule(terms_0, variables_0, kwargs_0)
    lookup_module_0.run()

    assert True

# Generated at 2022-06-25 10:43:22.247104
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True



# Generated at 2022-06-25 10:43:24.774697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = test_case_0()
    assert isinstance(lookup_instance, LookupModule) is True
    assert isinstance(lookup_instance.run(), list) is True


# Generated at 2022-06-25 10:43:38.178303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a lookup module using a path
    lookup_module_0 = LookupModule(
        '/Users/yannigperre/Documents/Projects/github/ansible-lookup-ini/ansible_lookup_ini/lookup_plugins/ini'
    )

    # Call method run of lookup_module_0
    # Type: dict
    params = dict()
    # Type: str
    param = "key=value"
    # Type: dict
    terms = dict()
    terms[param] = param
    # Type: list
    res = lookup_module_0.run(terms, params)
    res
    # Type: dict
    params = dict()
    param = "key=value"
    # Type: dict
    terms = dict()
    terms[param] = param
    # Type: str
    term

# Generated at 2022-06-25 10:43:48.585744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('begin test_LookupModule_run')

    # Basic tests
    def test(terms_value, variables_value, **kwargs):
        lookup_module_0 = LookupModule(terms_value)
        try:
            res = lookup_module_0.run(terms_value, variables_value, **kwargs)
            print(res, file=sys.stderr)
        except Exception as err:
            print(err, file=sys.stderr)
            print(terms_value, file=sys.stderr)
            assert False
    test(['not-existing-section.not-existing-key'], {})
    test(['existing-key'], {})
    test(['existing-key', 'default-value'], {})

# Generated at 2022-06-25 10:43:56.102787
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = ''
    str_1 = ''
    str_2 = ''
    int_0 = lookup_module_0.get_value(str_0, str_1, str_2, False)
    assert int_0 is None

# Test for method 'get_value' of class 'LookupModule'

# Generated at 2022-06-25 10:44:05.448038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
        ''.join(['foo']),
        ''.join(['foo\\n']),
    ]
    type_0 = 'properties'
    file_0 = 'hosts.ini'
    section_0 = 'section1'
    re_0 = True
    encoding_0 = 'utf-8'
    default_0 = 'default'
    case_sensitive_0 = False
    allow_no_value_0 = False
    lookup_module_0 = LookupModule(terms_0)

# Generated at 2022-06-25 10:44:16.328955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(b'\xdc0N')
    terms_0 = [b'\xdc0N']
    # Example of bad params passed
    exception_class_0 = AnsibleLookupError
    exception_0 = None
    try:
        lookup_module_0.run(terms_0)
    except AnsibleLookupError as error:
        exception_0 = error
    assert exception_0.message == "Could not use 'N' from '[b'\\xdc0N']': not enough values to unpack (expected 2, got 1)"
    assert type(exception_0) == exception_class_0
    # Example of no key provided
    exception_class_1 = AnsibleOptionsError
    exception_1 = None

# Generated at 2022-06-25 10:44:24.492012
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bytes_0 = b'\xdc0N'
    lookup_module_0 = LookupModule(bytes_0)
    lookup_module_0.cp = configparser.ConfigParser(allow_no_value=True)
    key_0 = 'L3yTt'
    section_0 = '\x88\xa8\x8c\x8bR'

# Generated at 2022-06-25 10:44:29.949494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xdc0N'
    lookup_module_0 = LookupModule(bytes_0)
    list_0 = list()
    params_0 = dict()
    params_0['list'] = list_0
    params_0['file'] = lookup_module_0.run(params_0['list'])
    params_0['list'] = list_0
    params_0['file'] = lookup_module_0.run(params_0['list'])



# Generated at 2022-06-25 10:44:44.310092
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Some tests for method LookupModule run
    config = StringIO()
    config.write(u'[section_one]\n')
    config.write(u'key1: value1a\n')
    config.write(u'key1: value1b\n')
    config.write(u'key2: value2\n')
    config.write(u'key3: value3\n')
    config.write(u'key4: value4\n')
    config.write(u'key5: value5\n')

    config.write(u'[section_two]\n')
    config.write(u'key1: value1\n')
    config.write(u'key2: value2\n')
    config.write(u'key1: value1\n')


# Generated at 2022-06-25 10:44:46.312339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = {}
    terms = ['key1']
    lookup_module = LookupModule(terms, params)


test_LookupModule_run()

# Generated at 2022-06-25 10:44:50.165507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    bytes_0 = b'\x9e'
    list_0 = lookup_run(bytes_0, None)


# Generated at 2022-06-25 10:44:59.393813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    list_0 = ['\xc3\x9c\xe2\x80\x94\xe2\x8b\x92\xea\x9e\x8b\xc3\xbf\xe2\xab\xa1\xe2\x89\xb2\xef\xb8\x9f\xe4\xbb\xab\xe2\x8a\x80']
    str_0 = ''
    dict_0 = {}
    var_0 = lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 10:45:07.183176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Params
    terms = ''
    variables = ''
    kwargs = ''

    lookup_module = LookupModule(terms, variables, kwargs)
    exceptions = (AnsibleLookupError, AnsibleOptionsError, ValueError)
    if any(exception in exceptions for exception in lookup_module.run(terms, variables, kwargs)):
        lookup_run = False


# Generated at 2022-06-25 10:45:12.562656
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    bool_0 = False
    var_0 = lookup_module_0.get_value(str_0, str_1, str_2, bool_0)


# Generated at 2022-06-25 10:45:15.545999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialization
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = ''
    bool_0 = False
    lookup_module_0.run(str_0, bool_0)


# Generated at 2022-06-25 10:45:22.667613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("inside test_LookupModule_run")
    file_path = os.path.realpath("ansible.ini")
    print("file_path:" + file_path)
    assert os.path.exists(file_path) is True
    lookup_module_0 = LookupModule(file_path)
    str_0 = ''
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_0, str_0, bool_0)



# Generated at 2022-06-25 10:45:32.060623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = 'E\x8b\x99'
    str_1 = '\x8a\x94\xeb\xb9\x9f\x8c\x8b.\x98\x05'
    str_2 = '\x9d\xaa\x9c\xba'
    str_3 = '\x90\x91\r\x8d\xd9\x9d\x83\x99\xf7\x86U'

# Generated at 2022-06-25 10:45:35.780315
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ret_0 = test_LookupModule_get_value_0()
    ret_1 = test_LookupModule_get_value_1()
    ret_2 = test_LookupModule_get_value_2()
    ret_3 = test_LookupModule_get_value_3()
    return ret_0, ret_1, ret_2, ret_3


# Generated at 2022-06-25 10:45:55.404423
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    value_0 = lookup_module_0.cp._sections.popitem()
    str_0 = ''
    bool_0 = False
    var_0 = lookup_module_0.get_value(str_0, value_0, str_0, bool_0)
    print(var_0)


# Generated at 2022-06-25 10:46:02.735234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters and expected output
    str_0 = ''
    var_0 = None
    str_1 = ''
    var_1 = None
    map_0 = {}
    map_1 = {}
    lookup_module_0 = LookupModule(None)
    assert lookup_module_0.run(str_0, None, **map_0) == [var_1]
    assert lookup_module_0.run(str_0, None, **map_1) == [var_1]


# Generated at 2022-06-25 10:46:09.678940
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    bytes_0 = b''
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False
    var_0 = lookup_module_0.get_value(str_0, str_1, str_2, bool_0)

# Generated at 2022-06-25 10:46:16.481896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xab\x88'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = ''
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_0, str_0, bool_0)
    str_1 = ''
    str_2 = ''
    bool_1 = False
    var_1 = lookup_get_value(str_2, str_1, str_1, bool_1)
    list_0 = []
    list_0.append(var_1)
    var_2 = lookup_module_0.run(list_0)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:46:21.307744
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Test example from the docs
    lookup_module_get_value_0 = LookupModule()
    # Test example from the docs
    str_0 = 'user'
    str_1 = 'users.ini'
    str_2 = 'integration'
    lookup_module_get_value_0.set_options(direct={'file': str_1, 'section': str_2})
    file_0 = lookup_module_get_value_0._loader.path_dwim_relative(None, str_1, True)
    # Test example from the docs
    with open('/Users/yannig/git/ansible-test/test/test_data/test_lookup_plugins/' + str_1, 'r') as file_1:
        str_3 = file_1.read()
    configparser_0

# Generated at 2022-06-25 10:46:23.958880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	
	# Create a test object
	test_obj = LookupModule()
	
	# Run the test
	test_obj.run()
	
	# Test assertions, if any...
	
	# Return success
	return 0
	

# Generated at 2022-06-25 10:46:32.613646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    list_0 = ['\uC5A7', '\uC5A7', '\uC5A7', '\uC5A7', '\uC5A7', '\uC5A7', '\uC5A7', '\uC5A7', '\uC5A7', '\uC5A7']
    lookup_module_0.run(list_0, case_sensitive=True)

# Generated at 2022-06-25 10:46:35.701788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_2 = b'\xec\x9a\x87'
    lookup_module_2 = LookupModule(bytes_2)
    assert lookup_module_2.run(['a', 'b', 'c', 'd', 'e']) == 'e'

# Generated at 2022-06-25 10:46:43.547072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_path = 'test.properties'
    lookup_module_0 = LookupModule(file_path)
    term_0 = 'foo=bar'
    lookup_module_0.run(term_0)
    term_1 = 'test'
    dict_val_0 = dict()
    dict_val_0['test'] = None
    lookup_module_0.run(term_1, dict_val_0)
    term_2 = 'test'
    dict_val_1 = dict()
    dict_val_1 = {}
    dict_val_1['test'] = 'test'
    lookup_module_0.run(term_2, dict_val_1, {})
    term_3 = 'file=bar'
    lookup_module_0.run(term_3)


# Generated at 2022-06-25 10:46:49.520793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xec\x93\x8e'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = ''
    str_1 = ''
    ansible_module_0 = Mock(AnsibleModule)
    variables = [str_0, str_1]
    del kwargs['utf-8']
    unicode_0 = unicode('utf-8')
    kwargs = {'encoding': unicode_0}
    ansible_module_ret_0 = lookup_module_0.run(variables, **kwargs)
    assert ansible_module_ret_0 == ansible_module_0

# Generated at 2022-06-25 10:47:29.236643
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # unit test using data passed through __main__
    main_0_input = [
        {
            "default": "",
            "section": "global",
            "key": "test_value",
            "type": "properties",
            "file": "test.properties"
        },
        {
            "default": "",
            "section": "global",
            "key": "test.value.*",
            "type": "properties",
            "file": "test.properties"
        }
    ]
    main_0_expect = [
        'val1=property_value',
        'val2=property_value2'
    ]
    main_0_output = []
    lookup_module_0 = LookupModule(main_0_input)

# Generated at 2022-06-25 10:47:35.703414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = '*'
    list_0 = [str_0]
    dict_0 = {}
    # Invocation
    ret = lookup_module_0.run(list_0, dict_0)
    # Assertions
    assert ret is not None



# Generated at 2022-06-25 10:47:38.391113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    list_0 = []
    dict_0 = dict()
    var_0 = lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 10:47:49.952686
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    paramvals = {
        'case_sensitive': False,
        'encoding': 'utf-8',
        'file': 'ansible.ini',
        're': False,
        'type': 'ini',
        'default': '',
    }
    term = 'user'
    section = 'integration'

    lookup_module_0 = LookupModule(term)
    var_0 = lookup_module_0.get_value(term, section, paramvals['default'], paramvals['re'])
    if var_0 == 'yannig':
        pass
    else:
        raise AssertionError("'var_0' should be 'yannig'. Got '%s'" % var_0)

    term = 'users.*'
    section = 'integration'
    bool_0 = True
    var_1

# Generated at 2022-06-25 10:48:00.723004
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Call method run of class LookupModule
    lookup_module_0 = LookupModule()
    str_0 = ''
    list_0 = []
    dict_0 = {}
    dict_1 = dict_0.copy()
    dict_2 = dict_1.copy()
    dict_2['encoding'] = 'utf-8'
    dict_2['re'] = False
    dict_2['case_sensitive'] = False
    dict_2['section'] = 'global'
    dict_2['file'] = 'ansible.ini'
    dict_2['default'] = ''
    dict_2['type'] = 'ini'
    var_0 = lookup_module_0.run(list_0, dict_2)

# Generated at 2022-06-25 10:48:10.090689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance_0 = LookupModule()

    # Testing error reporting for missing required arguments
    try:
        lookup_module_instance_0.run()
    except TypeError as err:
        assert (err.args[0].find('missing 1 required positional argument') != -1)

    # Testing error reporting for a bad type of argument
    try:
        lookup_module_instance_0.run(1)
    except TypeError as err:
        assert (err.args[0].find('an integer is required') != -1)

    # Testing error reporting for a bad value of argument
    try:
        lookup_module_instance_0.run([1, 2 ,3])
    except TypeError as err:
        assert (err.args[0].find('1, 2 ,3') != -1)

    # Testing error reporting for

# Generated at 2022-06-25 10:48:16.668488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = [b'foo']
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = 'ansible.ini'
    str_1 = 'global'
    str_2 = ''
    bool_0 = False
    var_0 = lookup_module_0.run(args_0, str_0, str_1, str_2, bool_0)

# Generated at 2022-06-25 10:48:25.799788
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Input params
    str_1 = '[test_section]\n'
    str_2 = 'test_key1=test_value1\n'
    str_3 = 'test_key2=test_value2\n'
    str_4 = 'test_key2=test_value2\n'
    str_5 = 'test_key1=test_value1\n'
    str_6 = 'test_key3=test_value3\n'
    str_7 = 'test_key2=test_value2\n'
    str_8 = 'test_key2=test_value2\n'
    byte_0 = b'\x00\x00\x00\x00\x00'
    byte_1 = b'\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 10:48:27.297711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass



# Generated at 2022-06-25 10:48:33.661081
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Setup
    bytes_0 = b'\xec\x9a\x87'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False

    # Invocation
    var_0 = lookup_module_0.get_value(str_0, str_1, str_2, bool_0)

    # Verification
    assert var_0 == None


# Generated at 2022-06-25 10:49:45.109163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    lookupModule.run(["test"], 'test')


# Generated at 2022-06-25 10:49:51.701905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_0 = ''
    bool_0 = False
    bool_1 = bool_0
    dict_0 = {'allow_none': bool_1}
    str_1 = 'properties'
    dict_1 = {'re': bool_0, 'case_sensitive': bool_0, 'allow_none': bool_1, 'default': str_0, 'type': str_1, 'encoding': str_0}
    str_2 = '='
    str_3 = '[java_properties]\n'
    str_4 = '\nplatypus'
    str_5 = '\n\n'
    str_6 = '\uac00'
    str_7 = '\n'
    str_8 = 'platypus'
    str_

# Generated at 2022-06-25 10:49:58.994926
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    class Stub(object):

        def __init__(self):
            self.cp = configparser.ConfigParser()

        def items(self, section):
            return [('k', 'v')]

    lookup_module = LookupBase()
    lookup_module.get_value = LookupModule.get_value
    lookup_module.cp = Stub()
    assert lookup_module.get_value('key', 'section', 'dflt', False) == 'dflt'
    assert lookup_module.get_value('k', 'section', 'dflt', False) == 'v'
    assert lookup_module.get_value('.*', 'section', 'dflt', True) == ['v']

# Generated at 2022-06-25 10:50:05.721529
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    #args
    key = ''
    section = ''
    dflt = ''
    is_regexp = False

    #Test code
    LookupModule_0 = LookupModule(None)
    var_0 = LookupModule_0.get_value(key, section, dflt, is_regexp)


# Generated at 2022-06-25 10:50:12.799540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    str_0 = '0'
    list_0 = [str_0]
    str_1 = '1'
    str_2 = '9'
    list_1 = [str_0, str_1, str_1, str_2]
    str_3 = ''
    str_4 = '2'
    list_2 = [str_3, str_3, str_4, str_4]
    str_5 = '4'
    str_6 = '8'
    list_3 = [str_5, str_5, str_5, str_6]
    str_7 = '1'
    str_8 = '2'
    str_9 = '3'

# Generated at 2022-06-25 10:50:15.028404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # Test case 0
        if 4==4:
            test_case_0()
    except Exception as ex:
        print(ex)
        raise

test_LookupModule_run()

# Generated at 2022-06-25 10:50:24.772048
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    lookup_module_0 = LookupModule()
    # Set private attribute cp of lookup_module_0
    lookup_module_0._cp = configparser.ConfigParser()
    # Assert the first element of attribute cp of lookup_module_0
    assert isinstance(lookup_module_0._cp, configparser.ConfigParser)
    # Assert the second element of attribute cp of lookup_module_0
    assert isinstance(lookup_module_0._cp, configparser.ConfigParser)
    # Assert the third element of attribute cp of lookup_module_0
    assert isinstance(lookup_module_0._cp, configparser.ConfigParser)
    # Assert the fourth element of attribute cp of lookup_module_0

# Generated at 2022-06-25 10:50:36.156935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xaa\x8b\x07'
    lookup_module_0 = LookupModule(bytes_0)

# Generated at 2022-06-25 10:50:45.539906
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
  # TODO: Fix test case so it works with the current implementation
  # lookup_module_0 = LookupModule(b'\xec\x9a\x87')
  lookup_module_0 = LookupModule(b'\xec\x9a\x87')
  str_0 = ''
  str_1 = '\uac00\ub137\uac00\ub137'
  bool_0 = False
  str_2 = '\uac00\ub137\uac00\ub137'
  var_0 = lookup_module_0.get_value(str_0, str_1, str_2, bool_0)


# Generated at 2022-06-25 10:50:56.822955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd7\xab\xd6\xbd\xd6\x8d'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = 'k\x0b\x1dG\xd0N\x1c7"'
    str_1 = '\x0f\xb7\x90.\xbe\xe3\x04\xcd?\x8c\x1d\x92\x1e\x13\x9aA'
    int_0 = 26
    bool_0 = True
    tuple_0 = (str_0,)
    ansible_options_error_0 = AnsibleOptionsError()
    ansible_options_error_0.args = (str_1,)