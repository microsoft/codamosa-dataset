

# Generated at 2022-06-25 10:43:22.245726
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.get_value('', '', None, False
    )
    assert str_0 is None


# Generated at 2022-06-25 10:43:27.766941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 10:43:38.971859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    tempdir = tempfile.mkdtemp()
    test_file = os.path.join(tempdir, 'test.ini')
    with open(test_file, 'w') as fp:
        fp.write('[section1]\n')
        fp.write('key_1=value1\n')
        fp.write('key_2=value2\n')
        fp.write('key_3=value3\n')
        fp.write('[section2]\n')
        fp.write('key_4=value4\n')
        fp.write('key_5=value5\n')
        fp.write('key_6=value6\n')
    lookup_module_1 = LookupModule()
    lookup_module_1

# Generated at 2022-06-25 10:43:45.808132
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    key_0 = 'key_0'
    section_0 = 'section_0'
    dflt_0 = 'dflt_0'
    is_regexp_0 = True
    result = lookup_module_1.get_value(key_0, section_0, dflt_0, is_regexp_0)
    assert result == 'dflt_0'


# Generated at 2022-06-25 10:43:50.235545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['key']
    variables_0 = {}
    paramvals = {}
    lookup_module_0.run(terms_0, variables_0, allow_no_value=False, case_sensitive=False, default='', encoding='utf-8', file='file_path_0', section='section_0', type='type_0')


# Generated at 2022-06-25 10:43:53.956899
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    input_0 = ('', '', '', True)
    assert type(lookup_module_0.get_value(*input_0)) is list
    # put your test here


# Generated at 2022-06-25 10:43:59.292070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:44:11.067288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {
        'file': 'ansible.ini',
        'type': 'ini',
        'section': 'global',
        're': False,
        'case_sensitive': False,
        'allow_no_value': False,
        'encoding': 'utf-8',
        'default': ''
    }
    terms = ['user']
    variables = None

    # test_var_0 = '.*'
    # test_var_1 = 'global'
    # test_var_2 = 'True'
    # test_var_3 = 'ansible.ini'
    # test_var_4 = 'user'
    test_var_5 = 'section1'
    # test_var_6 = 'test.ini'
    # test_var_7 = 'global'

    test_var_8

# Generated at 2022-06-25 10:44:18.025112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    
    # Unit test for LookupModule.run()
    # Read ini file with allow_no_value
    terms_0 = ['user']
    kwargs_0 = {'file': 'mysql.ini', 'allow_no_value': True}
    kwargs_1 = {}
    kwargs_1['file'] = kwargs_0['file']
    kwargs_1['allow_no_value'] = kwargs_0['allow_no_value']
    lookup_module_0.set_options(direct=kwargs_1)
    paramvals_0 = lookup_module_0.get_options()

# Generated at 2022-06-25 10:44:24.382596
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    dict_0 = {}
    lookup_module_0 = LookupModule()

    key = 'm_0'
    section = 'm_1'
    dflt = 'm_2'
    is_regexp = 'm_3'

    # Test case with arguments: key='m_0', section='m_1', dflt='m_2', is_regexp='m_3'
    # The assertion below will be caught by pytest. It is expected to fail
    with pytest.raises(LookupError):
        lookup_module_0.get_value(key, section, dflt, is_regexp)


# Generated at 2022-06-25 10:44:42.555353
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    lookup_module_1.cp = configparser.ConfigParser()
    lookup_module_1.cp.add_section("section1")
    lookup_module_1.cp.set("section1", "key1", "value1")
    lookup_module_1.cp.set("section1", "key2", "value2")
    lookup_module_1.cp.set("section1", "key3", "value3")
    lookup_module_1.cp.set("section1", "key4", "value4")
    lookup_module_1.cp.add_section("section2")
    lookup_module_1.cp.set("section2", "key1", "value1")
    lookup_module_1.cp.set("section2", "key2", "value2")

# Generated at 2022-06-25 10:44:49.258807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleLookupError):
        terms = [u'key']
        lookup_module_0.run(terms)
    with pytest.raises(AnsibleLookupError):
        terms = [u'key']
        variables = {}
        lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 10:44:58.850868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look_up = LookupModule()
    terms = ['app_user', 'app_user.name']
    vars = {'lookup_file_search_path': ['lookups'], 'lookup_file_append_path': 'False'}
    kwargs = {'file': 'user.properties', 'case_sensitive': 'False', 'allow_none': 'False', 'type': 'properties', 're': 'False'}
    result = look_up.run(terms, vars, **kwargs)
    assert result == ['jane', 'Jan'], 'test_1_1_1 failed'



# Generated at 2022-06-25 10:45:02.323866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = defaultdict(lambda: '')
    params['key'] = 'test.ini'
    params['file'] = 'test.ini'
    params['section'] = 'global'
    params['encoding'] = 'utf-8'
    params['default'] = ''
    params['re'] = False
    params['type'] = 'ini'

    term = 'user'

    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.read('test.ini')

    assert lookup_module.run(term, params) == 'yannig'

# Generated at 2022-06-25 10:45:11.817964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for paramvals in list:
        print(paramvals)
        lookup_module_0 = LookupModule()
        lookup_module_0.run(['key','key=value','key','key2','key2','key2','key2=value2','key2=value2','key2=value2 key2=value2','key2=value2','key3','key3=value3','key3=value3','key3=value3','key3=value3'], variables={'variable': 'value'}, **paramvals)


# Generated at 2022-06-25 10:45:22.401567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test parameters and responses

    test_terms = [
        'username',
        'Password1',
        'server_ip',
        'server_name',
        'port'
    ]

    test_paramvals = {
        'file': 'creds.ini',
        'section': 'dev',
        'type': 'ini',
        're': False,
        'encoding': 'utf-8',
        'default': '',
        'case_sensitive': False
    }

    test_results = [
        'admin',
        '12345',
        '192.168.12.1',
        'server-dev',
        '110'
    ]

    # Perform the test
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:45:32.060266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    lookup_module_run.cp = configparser.ConfigParser()
    lookup_module_run.cp.add_section('java_properties')
    lookup_module_run.cp.set('java_properties', 'user', 'harry')
    lookup_module_run.cp.set('java_properties', 'lang', 'Python')
    lookup_module_run.cp.set('java_properties', 'website', 'https://github.com/harry')
    print(lookup_module_run.run([('user', {'type': 'properties', 'file': 'user.properties'})],{}))
    print(lookup_module_run.run([('lang', {'type': 'properties', 'file': 'user.properties'})],{}))

# Generated at 2022-06-25 10:45:38.203009
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()

    # Call tested method
    assert(lookup_module_0.get_value("key", "section", "dflt", False) != None)

# Generated at 2022-06-25 10:45:39.060810
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    pass

# Generated at 2022-06-25 10:45:49.520257
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    # Test case with wrong data_set
    term = ''
    section = ''
    dflt = ''
    is_regexp = False
    try:
        ret = lookup_module_0.get_value(term, section, dflt, is_regexp)
    # Test if the exception raised matches the expected one
    except Exception as e:
        if 'No argument must be supplied' in str(e):
            assert True
    # Test case with correct data_set
    term = ''
    section = ''
    dflt = ''
    is_regexp = False
    ret = lookup_module_0.get_value(term, section, dflt, is_regexp)
    assert ret == paramvals['default']
    # Test case with wrong data_set
   

# Generated at 2022-06-25 10:46:01.109031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    bool_0 = False
    var_1 = lookup_get_value(str_0, str_0, lookup_module_0, bool_0)
    var_2 = lookup_module_0.run(var_1)


# Generated at 2022-06-25 10:46:05.557949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    paramvals = dict()
    paramvals["type"] = "ini"
    paramvals["file"] = "ansible.ini"
    paramvals["section"] = "global"
    paramvals["re"] = False
    paramvals["encoding"] = "utf-8"
    paramvals["default"] = ""
    paramvals["case_sensitive"] = False
    var_0 = lookup_module_0.run(list_0,paramvals)
    assert len(var_0) == 0



# Generated at 2022-06-25 10:46:08.962560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{"file": "test.ini", "type": "ini", "re": False, "default": "", "case_sensitive": True, "allow_no_value": False}]
    m = LookupModule()
    result = m.run(terms)
    return result


# Generated at 2022-06-25 10:46:16.404184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    lookup_options_0 = {str_0:str_1, str_2:str_3, str_4:str_5, str_6:str_7, str_8:str_7}
    terms_0 = [str_0]
    bool_0 = False
    str_9 = ''
    var_0 = lookup_module_0.run(terms_0, lookup_options_0, bool_0, file=str_9)
    lookup_module_0 = LookupModule()
    str_10

# Generated at 2022-06-25 10:46:23.867790
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Verify that the string returned was the same as the one provided,
    # when the default value ('') was used.
    str_0 = 'non-existent-property'
    str_1 = ''
    lookup_module_0 = LookupModule()
    str_2 = '.'
    var_0 = lookup_module_0.get_value(str_0, str_1, str_1, bool_0)
    assert var_0 == str_1
    str_3 = 'file'
    str_4 = 'ansible-vault.ini'
    str_5 = '.'
    var_1 = lookup_module_0.get_value(str_0, str_1, str_1, bool_0)
    assert var_1 == str_1

    # Verify that the string returned was a match for the regexp

# Generated at 2022-06-25 10:46:32.194081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    bool_0 = False
    dict_0 = dict()
    dict_0[str_0] = dict_0
    str_1 = ''
    dict_0[str_1] = str_0
    list_0 = list()
    list_0.append(dict_0)
    var_0 = lookup_module_0.run(list_0, dict_0, allow_no_value=bool_0)
    print(var_0)



# Generated at 2022-06-25 10:46:39.097095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = 'foo'
    var_2 = ['bar']
    var_3 = {}
    var_4 = ''
    str_1 = 'foo'
    var_5 = lookup_module_1.run(var_2, var_3, var_4)
    str_2 = 'foo'
    str_3 = 'bar'
    var_6 = lookup_module_1.run(var_2, var_3, var_4)
    str_4 = 'foo'
    str_5 = 'bar'
    var_7 = lookup_module_1.run(var_2, var_3, var_4)


# Generated at 2022-06-25 10:46:45.453729
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    str_0 = ''
    str_1 = ''
    bool_0 = False
    lookup_module.get_value(str_0, str_1, str_0, bool_0)


# Generated at 2022-06-25 10:46:49.699868
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_1, lookup_module_0, bool_0)
    # Calls _get_value(self, section, key, default, is_regexp)
    # The above function name changed in Ansible, need to refactor it later.


# Generated at 2022-06-25 10:46:53.326429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(None, None)
    lookup_module_1.get_value = get_value_1
    lookup_module_1.find_file_in_search_path = find_file_in_search_path_1
    str_1 = u'key'
    str_2 = u'value'
    str_3 = u'section'
    str_4 = u'file'
    lookup_module_1.run(str_1, str_2, str_3, str_4)


# Generated at 2022-06-25 10:47:12.020180
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
  try:
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_1, lookup_module_0, bool_0)
  except Exception as e:
    print(e)


# Generated at 2022-06-25 10:47:18.420791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    # Testcase('', 'integer')
    terms = lookup_module_0.run()
    assert len(terms) == 1

# Generated at 2022-06-25 10:47:28.758861
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # get a test object
    lookup_module_0 = LookupModule()

    # initialize test params
    terms_0 = [
        'key1=value',
        'key2=value',
    ]
    section_0 = 'global'
    file_0 = 'ansible.ini'
    default_0 = ''
    re_0 = False
    encoding_0 = 'utf-8'
    type_0 = 'ini'
    options_0 = dict(
        section=section_0,
        file=file_0,
        default=default_0,
        re=re_0,
        encoding=encoding_0,
        type=type_0,
    )

# Generated at 2022-06-25 10:47:30.779245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    # param
    var_0 = lookup_module_0.run(str_0)



# Generated at 2022-06-25 10:47:33.933788
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    key = "key"
    section = "section"
    default = ""
    is_regexp = False
    try:
        var = lookup_module.get_value(key, section, default, is_regexp)
    except Exception as e:
        pass


# Generated at 2022-06-25 10:47:40.103491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    list_0 = []
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == lookup_module_0.run(list_0, {})


# Generated at 2022-06-25 10:47:44.825947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:47:52.485536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    template_str_0 = ''.join([
        '[default]', '\n',
        'type = ini', '\n',
        'file = test', '\n',
        'section = test', '\n',
        're = False', '\n',
        'encoding = utf-8', '\n',
        'default = ', '\n',
        'allow_no_value = True', '\n'])
    template = ANSIBLE_MODULE_ARGS = {'_ansible_verbosity': 3, 'src': 'test', '_ansible_version': '2.5.5', '_ansible_no_log': False, '_ansible_debug': True, '_ansible_selectattr': None, '_ansible_keep_remote_files': False}

# Generated at 2022-06-25 10:47:54.589323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'section': 'section1', 'file': 'test.ini', 're': True})
    lookup_module_0.run(['.*', '.*'])


# Generated at 2022-06-25 10:47:58.213195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    lookup_module_0.run(str_0, str_1)

if __name__ == "__main__":

    test_case_0()
    # Unit test for method run of class LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 10:48:40.337666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    dict_0 = dict()
    dict_1 = dict()
    dict_1['_terms'] = str_0
    dict_0['lookup_options'] = dict_1
    dict_1 = dict()
    dict_1['file'] = str_0
    dict_1['default'] = str_0
    dict_1['re'] = False
    dict_1['section'] = str_0
    dict_1['encoding'] = str_0
    dict_0['lookup_plugin_options'] = dict_1
    bool_0 = False
    # Initialize lookup plugin
    lookup_module_0._setup_plugin(dict_0, bool_0)
    # Get lookup params
    lookup_module_1 = lookup_module_0

# Generated at 2022-06-25 10:48:47.171045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = ''
    lookup_module_2 = LookupModule()
    str_2 = ''
    bool_0 = False
    var_1 = lookup_run(str_1, str_2, lookup_module_1, lookup_module_2, bool_0)



# Generated at 2022-06-25 10:48:53.302460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:49:03.083703
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_0 = LookupModule()

    lookup_module_0.cp = configparser.ConfigParser(allow_no_value=paramvals.get('allow_no_value', paramvals.get('allow_none')))
    if paramvals['case_sensitive']:
        lookup_module_0.cp.optionxform = to_native


    key_0 = 'key_0'
    section_0 = 'section_0'
    dflt_0 = ''
    is_regexp_0 = False
    var_0 = lookup_module_0.get_value(key_0, section_0, dflt_0, is_regexp_0)



# Generated at 2022-06-25 10:49:09.535595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    terms_0 = [str_0, str_1, str_2]
    bool_0 = False
    variables_0 = None
    var_0 = lookup_module_0.run(terms_0, variables_0, case_sensitive=bool_0)
    assert var_0 == []


# Generated at 2022-06-25 10:49:11.291733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate an instance of LookupModule
    lookupModule_0 = LookupModule()

    # TODO: Add test cases



# Generated at 2022-06-25 10:49:15.447480
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_1, lookup_module_0, bool_0)

test_LookupModule_get_value()

# Generated at 2022-06-25 10:49:19.354862
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    config_0 = None
    sections_0 = None
    # Set up test data
    key = ''
    section = ''
    dflt = ''
    is_regexp = False

    # Invoke method
    ret = LookupModule._get_value(key, section, dflt, is_regexp)

    # Check for positive conditions
    assert ret is not None
    assert bool(ret)


# Generated at 2022-06-25 10:49:24.948691
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup_module_0 = LookupModule()
    str_0 = 'default'
    str_1 = 'section'
    bool_0 = False
    lookup_module_0.cp = configparser.ConfigParser()
    lookup_module_0.cp.optionxform = 'str'

# Generated at 2022-06-25 10:49:29.441545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    bool_0 = False
    str_1 = ''
    str_2 = ''
    lookup_module_0._parse_params(str_0, str_1, str_2, bool_0)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:50:49.460688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    str_0 = 'x'
    bool_0 = False
    dict_0 = dict()
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    dict_0['type'] = str_0
    dict_0['file'] = str_1
    dict_0['default'] = str_2
    dict_0['section'] = str_3
    dict_0['case_sensitive'] = bool_0
    dict_0['encoding'] = str_4
    dict_0['re'] = bool_0
    dict_0['allow_no_value'] = bool_0
    dict_1 = dict()
    dict_

# Generated at 2022-06-25 10:50:51.188211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_1 = ''
    variables = ''
    lookup_module_0.run(term_1, variables)

# Generated at 2022-06-25 10:50:58.257695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible.ini'
    terms_0 = [str_0]
    str_1 = ''
    str_2 = 'utf-8'
    bool_0 = False
    bool_1 = True
    item_0 = 'Ini file'
    item_1 = 'Ini file'
    item_2 = 'Ini file'
    str_3 = 'ini'
    bool_2 = True
    list_0 = lookup_module_0.run(terms_0, str_1, str_2, bool_0, bool_1, item_0, item_1, item_2, str_3, bool_2)
    assert list_0 == ['ini']


# Generated at 2022-06-25 10:51:05.309631
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module_1 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    bool_0 = False
    var_0 = lookup_get_value(str_0, str_1, lookup_module_1, bool_0)
    var_1 = lookup_get_value(str_0, str_2, lookup_module_1, bool_0)


# Generated at 2022-06-25 10:51:08.424153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = ''
    lookup_module.run(str_0)

# Generated at 2022-06-25 10:51:19.064013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("")
    print("** Unit test for LookupModule.run **")
    lookup_module_0 = LookupModule()
    bool_0 = False
    bool_1 = True
    list_0 = []
    list_1 = []
    list_2 = []
    list_2.append(bool_1)
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = ''
    str_16 = ''
   

# Generated at 2022-06-25 10:51:21.615283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_0 = []
    dict_0 = {}
    var_0 = lookup_module_1.run(list_0, dict_0)
    assert not var_0


# Generated at 2022-06-25 10:51:23.505166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = []
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(term_0)

# Generated at 2022-06-25 10:51:31.841162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    setup
    lookup_module_0 = LookupModule()
    lookup_module_0.get_value = MagicMock(name='run.get_value')
    lookup_module_0.get_value.return_value = None
    lookup_module_0.find_file_in_search_path = MagicMock(name='run.find_file_in_search_path')
    lookup_module_0.find_file_in_search_path.return_value = None
    lookup_module_0._loader = MagicMock(name='run._loader')
    lookup_module_0._loader._get_file_contents = MagicMock(name='run._loader._get_file_contents')
    lookup_module_0._loader._get_file_contents.return_value = (None, None)
    None
   

# Generated at 2022-06-25 10:51:34.341255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    x_0 = lookup_module_0.run(list_0, dict_0)
    try:
        assert x_0 == None
    except AssertionError as e:
        print("Test Failed -", e)
