

# Generated at 2022-06-11 15:33:35.017829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {'_terms': ['hostname', 'hostname', 'hostname', 'hostname'], 'type': 'ini', 'default': '', 'file': 'config.ini', 'section': 'global', '_original_file': 'the/path/to/the/file', '_original_terms': ['hostname', 'hostname', 'hostname', 'hostname'], 'encoding': 'utf-8', '_raw_params': 'hostname\nhostname\nhostname\nhostname\n', '_params': {}}

    l = LookupModule()

    # Test with mock
    import unittest.mock as mock

# Generated at 2022-06-11 15:33:45.148801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    """

    # Create a parser
    parser = configparser.ConfigParser()
    parser.optionxform = str
    # Create a StringIO to fake a file
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'key3=value3\n')
    config.write(u'\n')
    config.write(u'[section2]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.write(u'key3=value3\n')

# Generated at 2022-06-11 15:33:54.336072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test #1: Load string with properties type
    properties_filepath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files', 'user.properties')
    result = LookupModule().run([
        'user.name',
        'user.email',
        'user.role'
    ], variables={
        'ansible_user': 'ansible_test_user'
    }, file=properties_filepath, type='properties')
    assert result == ['robert', 'rob@gmail.com', 'admin']

    # Test #2: Load string with properties type and section
    properties_filepath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files', 'user.properties')

# Generated at 2022-06-11 15:34:05.964473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # Mock configparser module
    class MockConfigParser(object):

        def __init__(self, cp_init_allow_no_value):
            self.cp_init_allow_no_value = cp_init_allow_no_value
            self.cp_init_class_name = None

        def __call__(self, *args, **kwargs):
            self.cp_init_class_name = self.__class__.__name__
            return self

        def items(self, section):
            if 'section1' == section:
                return [('key1', 'key1_value'),
                        ('key2', 'key2_value'),
                        ('key3', 'key3_value')]

        def get(self, section, key):
            return key + '_value'


# Generated at 2022-06-11 15:34:09.880432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import data
    import os
    import sys
    import unittest

    # Create a python file called data.py in the same directory
    # This file will contain the ini file data used in the test
    #
    # data.py file content :
    #  # Test ini file
    #  # Test ini file
    #  [global]
    #  option1 = Test option1 Value
    #  option2 = Test option2 Value
    #  [section1]
    #  option1 = Test option1 Value in section1
    #  [section2]
    #  option1 = Test option1 Value in section2
    #  option2 = Test option2 Value in section2
    #  option3 = Test option3 Value in section2
    #  [section3]
    #  option1 = Test option1 Value in

# Generated at 2022-06-11 15:34:18.678850
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create class LookupModule
    look = LookupModule()
    # Create a configparser object
    look.cp = configparser.ConfigParser()
    # Create a StringIO later used to parse ini
    config = StringIO()
    # Create a ini file with one section
    config.write(u'[section]\n')
    config.write(u'key1=value1\n')
    config.write(u'key2=value2\n')
    config.seek(0, os.SEEK_SET)
    # Parse ini file
    look.cp.readfp(config)

    # Test get_value with a normal key
    k = 'key1'
    assert look.get_value(k, 'section', '', False) == 'value1'

    # Test get_value with a regexp

# Generated at 2022-06-11 15:34:27.110468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    LookupModule_Run
    """
    lookup_module = LookupModule()
    result = []
    test = [{'terms': [b'user=Bob'], 'paramvals': {'file': 'users.ini', 'section': 'integration'}}, {'terms': [b'user=Jim'], 'paramvals': {'file': 'users.ini', 'section': 'production'}}]
    for term in test:
        result += lookup_module.run(term['terms'], paramvals=term['paramvals'])
    assert result == ['Bob', 'Jim']


# Generated at 2022-06-11 15:34:34.179412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule and deprecate_inline_kv test."""
    import os
    import tempfile
    tmp_dir = tempfile.gettempdir()
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.close()
    file_path = os.path.join(tmp_dir, tmp_file.name)
    data = "[section1]\nkey1=value1\nkey2=value2\nkey3=value3"

    # Test 1: test deprecated values
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.close()
    with open(tmp_file.name, "w") as new_ini:
        new_ini.write(data)

    ini_file = LookupModule()
    ini_file

# Generated at 2022-06-11 15:34:42.893548
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    '''Test get_value method of LookupModule.'''

    from ansible import constants as C
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.cli.playbook.play_context import PlayContext

    from ansible.plugins.loader import lookup_loader

    MockLookupModule = lookup_loader.get('ini', class_only=True)

    display = Display()

    vault_pass = ''
    vault_id = ''
    vault_secrets = None
    vault_secrets_file = None
    vault_secrets_cache = {}
    loader = None
    variable_manager = VariableManager()

# Generated at 2022-06-11 15:34:53.888845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import PyTest and Ansible
    import pytest
    import ansible.modules.extras.system.ini as ini
    import ansible.plugins.loader as plugin_loader

    # load LookupModule which is tested
    module_cls = plugin_loader.get('lookup', 'ini')

    ini_content = '''[section1]
key1=value1
key2=value2
key3=value3
key4=value4
key5=value5
'''

    # create a mock class for testing
    class Options:
        module_name = ''
        pattern = 'ini'
    opts = Options()

    # create a mock class for testing
    class Runner:
        def get_basedir(self):
            return '.'
        def __init__(self):
            self.options = opts

# Generated at 2022-06-11 15:35:00.485305
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    pass

# Generated at 2022-06-11 15:35:12.178987
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.utils.display import Display
    from ansible.parsing.plugin_docs import read_docstring

    class DummyLookupModule(LookupModule):
        def __init__(self):
            LookupModule.__init__(self)
            self.cp = configparser.ConfigParser()
            self.cp.add_section('section')
            self.cp.set('section', 'key1', 'val1')
            self.cp.set('section', 'key2', 'val2')
            self.cp.set('section', 'key3', 'val3')
            self.cp.add_section('section2')
            self.cp.set('section2', 'key4', 'val4')
            self.cp.set('section2', 'key5', 'val5')

    l = DummyLookup

# Generated at 2022-06-11 15:35:22.254717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.find_file_in_search_path = lambda variables, directories, file: "test-ini-lookup.ini"
    lookup._loader = lambda: None
    lookup._loader._get_file_contents = lambda path: ("", "")

    # Test a property file
    term1 = "key1"
    terms1 = [ term1 ]
    options1 = { "type": "properties", "encoding": "utf-8" }
    result1 = lookup.run(terms1, options1)
    assert result1[0] == "value1"

    # Test an ini file
    term2 = "key1"
    terms2 = [ term2 ]
    options2 = { "encoding": "utf-8" }
    result2 = lookup.run(terms2, options2)

# Generated at 2022-06-11 15:35:33.439353
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import configparser
    class TestClass:
        def __init__(self):
            self.cp = configparser.ConfigParser()
            self.cp.add_section('section')
            self.cp.set('section', 'key1', 'value1')
            self.cp.set('section', 'key2', 'value2')
            self.cp.set('section', 'sub.key3', 'value3')
            self.cp.set('section', 'sub.key4', 'value4')
        def get_value(self, key, section, dflt, is_regexp):
            return LookupModule.get_value(self, key, section, dflt, is_regexp)
    test_obj = TestClass()

# Generated at 2022-06-11 15:35:44.402975
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.module_utils._text import to_bytes, to_text
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser(strict=False)
    config = StringIO()
    contents = b"""[section]
key=Test
key_re=Test1"""
    config.write(to_text(contents, 'utf-8'))
    config.seek(0, os.SEEK_SET)
    lookup_module.cp.readfp(config)
    # test get key
    assert lookup_module.get_value('key', 'section', None, False) == 'Test'
    # test get key with regexp
    assert lookup_module.get_value('key_re', 'section', None, False) is None

# Generated at 2022-06-11 15:35:49.149569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    terms = ['foo']
    variables = None
    options = {'file': '../../../../../../../tests/data/sample_ini.ini', 'type': 'ini'}
    assert my_lookup.run(terms, variables, **options) == ['bar']


# Generated at 2022-06-11 15:35:58.278219
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create fake config file
    config = StringIO()
    config.write("""[global]
# comment
key=value
empty=
key int=value int

[section2]
key=value
key int=value int

[section1]
key=value
key int=value int
""")
    config.seek(0, os.SEEK_SET)

    # Create lookup module
    lookup = LookupModule()

    # Set option to ini type
    lookup.set_options({'type': 'ini'})

    # Run lookup module

# Generated at 2022-06-11 15:36:05.911098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test patching method run without affecting the other methods"""

    lookup_module = LookupModule()

    real_run = lookup_module.run
    try:
        lookup_module.run = lambda terms, variables=None: real_run(terms, variables, file='ansible.ini', section='global', re='False', allow_no_value=False, type='ini', encoding='utf-8', case_sensitive=False, default='')
        assert lookup_module.run(['test2'], variables={'files': ['test.ini']}) == ['value2']
    finally:
        lookup_module.run = real_run


# Generated at 2022-06-11 15:36:11.322520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    term = [u"users=user=admin"]
    assert module.run(terms=term) == ["admin"]
    term = [u"users=user=admin", u"users=user=root", u"users=user=guest"]
    assert module.run(terms=term) == ["admin", "root", "guest"]


# Generated at 2022-06-11 15:36:23.044904
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test - Retrieve all values from a section using a regexp
    cp = configparser.ConfigParser()
    cp.optionxform = str
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.set('section1', 'key2', 'value2')
    cp.set('section1', 'key3', 'value3')
    values = LookupModule().get_value(".*", 'section1', '', True)
    assert len(values) == 3
    assert values[0] == 'value1'
    assert values[1] == 'value2'
    assert values[2] == 'value3'

    # Test - Retrieve a single value
    value = LookupModule().get_value('key1', 'section1', '', False)
   

# Generated at 2022-06-11 15:36:39.389907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create class
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    # test
    assert lm.get_value('test', 'section', 'test', False) == 'test'
    assert lm.get_value('test', 'section', 'test', True) == 'test'

# Generated at 2022-06-11 15:36:50.047241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # this unit test method is not self contained:
    # it depends on the existence of test_config.ini file
    #
    # content of test_config.ini:
    # # This is a comment
    # test_string = foo
    # test_integer = 42
    # test_float = 42.3
    # [section1]
    # test_string = foo
    # test_float = 42.3
    # [section2]
    # test_string = foo
    # test_integer = 42
    # test_float = 42.3

    lookup = LookupModule()
    variables = {}
    # Case 1: no term specified
    ret = lookup.run([], variables)
    assert len(ret) == 0, "No lookup term specified, should return []"
    # Case 2: non existing key
    ret = lookup

# Generated at 2022-06-11 15:37:00.910865
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import os
    import yaml
    from ansible.module_utils.six.moves import configparser
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_text, to_native
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.plugins.lookup import LookupModule

    lookup = LookupModule()
    path = os.path.abspath(os.path.dirname(__file__))
    fichier = os.path.join(path, 'lookup_ini_test_file.yml')

    with open(fichier) as f:
        test_cases = yaml.load(f)


# Generated at 2022-06-11 15:37:09.754288
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: use /tmp for test file?
    TEST_FILE = 'test.ini'
    cp = configparser.ConfigParser()
    cp.read_dict(dict(section1=dict(user='Alice', uid='alice'),
                      section2=dict(user='Bob', uid='bob'),
                      section3=dict(user='Charlie', uid='charlie')))
    with open(TEST_FILE, 'w') as f:
        cp.write(f)

    lookup_module = LookupModule()
    assert lookup_module.run([('key', 'section', 'default', 'type', False)], [('user', 'section1', '', '', False)]) == ['Alice']

# Generated at 2022-06-11 15:37:19.761338
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_term = "key1"
    mock_terms = [mock_term]
    mock_var = "value1"
    mock_variables = None
    mock_file = 'ansible.ini'
    mock_section = 'global'
    mock_re = False
    mock_encoding = 'utf-8'
    mock_default = ''
    mock_cp = configparser.ConfigParser()
    mock_cp_item = lambda section=None: [(mock_term, mock_var)]
    mock_cp.items = mock_cp_item

    mock_options = {"file": mock_file,
                    "section": mock_section,
                    "re": mock_re,
                    "encoding": mock_encoding,
                    "default": mock_default}

    mock_args = {}

    test_obj = Look

# Generated at 2022-06-11 15:37:31.424778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test initialization
    lm = LookupModule()

    # Test run with valid argument
    class Options:
        allow_no_value = False
        allow_none = False
        case_sensitive = False
        default = True
        encoding = 'utf-8'
        file = 'ansible.ini'
        re = False
        section = 'global'
        type = 'ini'
    class Variables:
        ansible_search_path = ''

# Generated at 2022-06-11 15:37:42.131156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    term = "INI_KEY"
    section = "SECTION"
    path = "PATH"
    dflt = "DEFAULT"
    is_regexp = True
    terms = ["t1", "t2"]

    # method get_value not mocked
    # ret = mod.run(terms, variables=None, **{'type': "ini", 'file': "FILE", 'section': section, 're': is_regexp, 'default': dflt, '_original_file': path})
    # assert ret == [mod.get_value(terms[0], section, dflt, is_regexp), mod.get_value(terms[1], section, dflt, is_regexp)]

    # with mock.patch('ansible.plugins.lookup.ini.LookupModule.

# Generated at 2022-06-11 15:37:53.171334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for file with key=value ini style (default behavior)
    terms = ['key1', 'key2', 'key3', 'key4', 'key5', 'key6', 'key7', 'key8']
    # is_regexp = False
    paramvals = {'type': 'ini', 're': False, 'allow_no_value': False}
    module_test = LookupModule()
    assert module_test.run(terms, dict(), section='section1', **paramvals) == ['value1', '', 'value3', 'value4', 'value5', '', '', 'value8']

    # Test for file with key=value ini style and key4 with empty value (see test.ini)
    terms = ['key4']

# Generated at 2022-06-11 15:38:04.083835
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    fp = StringIO()
    fp.write(u'[java_properties]\n')
    fp.write(u'key1=value1\n')
    fp.write(u'key2=value2\n')
    fp.seek(0, os.SEEK_SET)

    cp = configparser.ConfigParser()
    cp.readfp(fp)

    lm = LookupModule()
    lm.cp = cp

    # Get a single value using a regexp
    assert lm.get_value('key1', 'java_properties', '', True) == ['value1']

    # Get a single value
    assert lm.get_value('key1', 'java_properties', '', False) == 'value1'

    # Get multiple values using a regexp
    assert lm.get

# Generated at 2022-06-11 15:38:08.046778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ['PATH'] = os.pathsep.join([os.curdir])
    lookup_module = LookupModule()
    lookup_module.set_options({'file':'test.ini', 'section': 'section1'})
    lookup_module.run(terms=['key1'])

# Generated at 2022-06-11 15:38:39.594559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys

    # Prepare parameters
    terms = ["user", "password=password", "comment=no comment", "comment = no comment at all"]

    # Create a LookupModule with a fake file ansible.ini
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(StringIO("[database]\nuser=admin\npassword=secure\ncomment=This is a comment\n"))
    lookup.paths = ["/tmp/ansible/roles/test_role/test/ansible.ini"]

    # Check if method run returns the expected value
    assert lookup.run(terms, variables=None) == ["admin", "secure", "no comment at all"]

# Generated at 2022-06-11 15:38:50.683586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'file': "test.ini", 'type': 'ini', 'section': 'section1'})

    # Get all keys
    terms = ['.*']
    expected = ['key1=value1', 'key2=value2', 'key3=value3']
    assert lookup_module.run(terms) == expected

    # Get value of key1 (first occurrence)
    terms = ['key1']
    expected = ['value1']
    assert lookup_module.run(terms) == expected

    # Get value of key2 (second occurrence)
    terms = ['key2']
    expected = ['value2']
    assert lookup_module.run(terms) == expected

    # Get value of key3 (last occurrence)

# Generated at 2022-06-11 15:38:52.682735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['key_in_default'], {}, file='files/users.ini') == ['value1']


# Generated at 2022-06-11 15:39:04.213546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert [u'value1'] == lookup.run(terms=[u' key1'], variables=None, type=u'ini', file=u'ansible.ini', section=u'global', re=False, encoding=u'utf-8', default=u'', allow_no_value=False, Case_sensitive=False)
    assert [u'value1', u'value2'] == lookup.run(terms=[u' key1', u' key2'], variables=None, type=u'ini', file=u'ansible.ini', section=u'global', re=False, encoding=u'utf-8', default=u'', allow_no_value=False, Case_sensitive=False)

# Generated at 2022-06-11 15:39:11.557380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test data
    term1 = 'key1'
    term2 = 'key2'

    # Create LookupModule object
    cmodule = LookupModule(None)

    # Create StringIO later used to parse ini
    config = StringIO()

    # Write data to StringIO
    config.write(u'[section1]\n')
    config.write(u'key1 = value1\n')
    config.write(u'key2 = value2')

    # Return to start of StringIO
    config.seek(0, os.SEEK_SET)

    # Create config parser
    cp = configparser.ConfigParser()

    # Parse StringIO
    cp.readfp(config)

    # Create list of term
    terms = [term1, term2]
    # Create list of var

# Generated at 2022-06-11 15:39:22.276021
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Initialization
    cp = configparser.ConfigParser()
    cp.read("tests/parsing.ini")

    # init lookup
    lookup = LookupModule()

    # Tests
    # Verify if the value was retrieved
    assert lookup.get_value("", "", "", False) == ""

    assert lookup.get_value("a_str", "section1", "", False) == "hello world"
    # Check if return a default value
    assert lookup.get_value("b_str", "section2", "default", False) == "default"

    # Works with regexp ?
    assert lookup.get_value("a_.*", "section1", "", True) == ['hello world', '1']
    # Check if return a default value

# Generated at 2022-06-11 15:39:31.180962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.utils.path import makedirs_safe
    from configparser import SafeConfigParser

    # Create temporary directory with different encoding
    tmpdir = tempfile.mkdtemp()
    tempdir = os.path.join(tmpdir, 'test_lookup_ini')
    testfile = os.path.join(tempdir, 'test.ini')
    makedirs_safe(tempdir)

    # Create dummy configuration file
    cp = SafeConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.set('section1', 'key2', 'value2')
    cp.set('section1', 'key2.2', 'value2.2')

# Generated at 2022-06-11 15:39:41.725891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instanciate a lookup
    lookup_module = LookupModule()
    # Set parameters
    lookup_module.set_options()
    # Define terms
    terms = ['port',
             'password=pass',
             'name=Bob',
             'name=Bob password=pass',
             'name=Bob password=pass type=properties',
             'name=Bob password=pass type=properties file=user.properties',
    ]
    # Define expected output
    expected_output = ['33', 'pass', 'Bob', 'Bob', 'Bob', 'Bob']
    # Get current directory
    cwd = os.path.dirname(os.path.realpath(__file__))

    # Get the output
    output = []

# Generated at 2022-06-11 15:39:53.126098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class VarsModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return ["x=1"]
    var=VarsModule()
    ansible_options = {
        'default': '',
        'encoding': 'utf-8',
        'file': 'ansible.ini',
        'section': 'global',
        'type': "ini",
        're': False,
        'case_sensitive': False,
        'allow_no_value': False,
        'allow_none': False,
    }

# Generated at 2022-06-11 15:40:02.683962
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_obj = LookupModule()

    # Test default return value for empty section
    result = lookup_obj.get_value('key', 'section', 'default', False)
    assert result == 'default'

    # Test regexp with several values in file
    config_file = StringIO()
    config_file.write(u'[section]\n')
    config_file.write(u'key1=value1\n')
    config_file.write(u'key2=value2\n')
    config_file.seek(0, os.SEEK_SET)
    config_parser = configparser.ConfigParser()
    config_parser.readfp(config_file)
    lookup_obj.cp = config_parser

# Generated at 2022-06-11 15:41:01.745367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.set_options(var_options={}, direct={u'file': u'file.ini', u'section': u'logging', u'type': u'ini', u're': False, u'encoding': u'utf-8'})
    lm.cp = configparser.ConfigParser(allow_no_value=False)
    if not lm.cp.readfp(StringIO(u'[logging]\nhandlers=file,console\n')):
        raise Exception('Test: file reading error')
    ret = lm.get_value('handlers', u'logging', None, False)
    assert ret == u'file,console', 'Test: wrong value'
    ret = lm.get_value('handler', u'logging', None, False)
    assert ret

# Generated at 2022-06-11 15:41:11.757810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # input: terms
    terms = ['key1', 'key2']

    # input: variables

# Generated at 2022-06-11 15:41:22.948906
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    terms=['$USER', '$USER:', '$PATH']
    variables = {'HOME': '/home/test'}

    # test regexp
    value = LookupModule().get_value('USER', 'shell', "", True)
    assert value == ['$USER', '$USER:']

    # test case_sensitive
    value = LookupModule().get_value('user', 'shell', "", False)
    assert value == "$USER"

    # test case_sensitive, section and key do not match
    value = LookupModule().get_value('user', 'shell', "", False, case_sensitive=True)
    assert value == "$USER"

    # test default value
    value = LookupModule().get_value('foo', 'shell', "", False)
    assert value == ""

    # test NoSectionError

# Generated at 2022-06-11 15:41:33.204578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test if get_value return the right value if section and key are valid.
    module = LookupModule()
    content = StringIO('[section1]\nkey1=value1\nkey2=value2\n[section2]\nkey3=value3\n')
    module.cp.readfp(content)
    assert module.get_value('key1', 'section1', None, False) == 'value1'

    # Test if get_value return the right value if section is invalid.
    module = LookupModule()
    content = StringIO('[section1]\nkey1=value1\nkey2=value2\n')
    module.cp.readfp(content)
    assert module.get_value('key1', 'section2', None, False) is None

# Generated at 2022-06-11 15:41:41.378505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.cp = configparser.RawConfigParser()
    # content of test file
    lookup.cp.add_section('Integration')
    lookup.cp.set('Integration', 'user', 'John')
    lookup.cp.set('Integration', 'password', 'secret')

    lookup.cp.add_section('Production')
    lookup.cp.set('Production', 'user', 'Jack')
    lookup.cp.set('Production', 'password', 'qwerty')

    # Test 1 : Find user in the section 'Integration'
    result = lookup.run([u'user section=Integration file=config.ini'], inject={u'ansible_user': u'yannig'})
    assert result[0] == "John"


# Generated at 2022-06-11 15:41:52.389708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test with a simple ini file
    terms = ["nom", "prenom"]
    path_to_file = os.path.join(__file__, os.pardir, os.pardir, os.pardir, 'files', 'ansible.ini')
    variables = {'files': [path_to_file]}
    paramvals = {'type': 'ini',
                 'file': 'ansible.ini',
                 'section': 'global',
                 're': False,
                 'encoding': 'utf-8',
                 'default': '',
                 'case_sensitive': False}
    results = module.run(terms, variables, **paramvals)
    assert results == ['ansible', 'ansible']

    # Test for a non-existing option
    terms = ["doesnotexist"]

# Generated at 2022-06-11 15:42:03.114275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This unittest avoid invalid error type
    """

    test_file = """
[section1]
a.name = ansible
b.name = ansible
c.name = ansible
d.name = ansible
[section2]
a.name = ansible
b.name = ansible
c.name = ansible
d.name = ansible
    """

    # Run lookup_module
    lookup_module = LookupModule()
    lookup_module.set_options({'file': 'my_file.ini'})
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(StringIO(test_file))
    ret = lookup_module.get_value('.*', 'section1', '', True)

# Generated at 2022-06-11 15:42:14.541887
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    with open("tests/ini/test_ini.ini") as f:
        config = StringIO()
        config.write(f.read())
        config.seek(0, os.SEEK_SET)
        lookup.cp.readfp(config)
    # Lookup on sections
    assert lookup.get_value('user', 'section1', None, is_regexp=False) == "admin1"
    assert lookup.get_value('user', 'section2', None, is_regexp=False) == "admin2"
    assert lookup.get_value('user', 'section3', None, is_regexp=False) == "admin3"

# Generated at 2022-06-11 15:42:21.729261
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    terms = "user"
    variables = None
    section = "integration"
    file = "users.ini"

    # get_value with a parameter is_regexp equals to False
    test_lookup = LookupModule()
    test_lookup.cp = configparser.ConfigParser()
    config = StringIO()
    config.write(u"[integration]\n")
    config.write(u"user=john\n")
    config.seek(0, os.SEEK_SET)
    test_lookup.cp.readfp(config)
    test_value = test_lookup.get_value(terms, section, "", False)
    assert test_value == 'john'

    # get_value with a parameter is_regexp equals to True
    test_lookup = LookupModule()
    test

# Generated at 2022-06-11 15:42:33.500595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    paramvals = {
        'file': 'test/test.ini',
        'allow_no_value': True,
        'case_sensitive': False,
        'default': '',
        'encoding': 'utf-8',
        'section': 'section1',
        'type': 'ini',
        're': False
    }

    # Retrieve all values from a section
    key = '.*'
    section = 'section1'
    dflt = ''
    is_regexp = True
    result = lookup_module.get_value(key, section, dflt, is_regexp)
    assert result == ['dev', 'user1', 'user2']

    # Retrieve a single value
    key = 'user'
    section = 'section2'
    dflt