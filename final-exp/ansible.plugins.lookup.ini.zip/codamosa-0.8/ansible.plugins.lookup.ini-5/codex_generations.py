

# Generated at 2022-06-11 15:33:34.146564
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_class = LookupModule()

    # Test with a regexp key
    test_class.cp = configparser.ConfigParser()
    test_class.cp.add_section('test_section')
    test_class.cp.set('test_section', 'a', '1')
    test_class.cp.set('test_section', 'b', '2')
    test_class.cp.set('test_section', 'c', '3')
    var = test_class.get_value('[ab]', 'test_section', '', True)
    assert var == ['1', '2']

    # Test with a key matching a single element in the section
    test_class.cp = configparser.ConfigParser()
    test_class.cp.add_section('test_section')

# Generated at 2022-06-11 15:33:41.872092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #args=dict(type='ini', section='global',key='property' , file='sample.ini' ,  default='', re=False)
    args=dict(type='ini', section='global', key='PROXY_USER,PROXY_PASSWORD,PROXY_HOST,PROXY_PORT,log_path' , file='sample.ini' ,  default='', re=True)
    lm = LookupModule()
    print(lm.run(['property'], args))

test_LookupModule_run()

# Generated at 2022-06-11 15:33:51.719237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Declaration of parameters
    paramvals = {'allow_no_value': None, 'default': '', 'encoding': 'utf-8', 'file': 'ansible.ini', 're': False, 'section': 'global', 'type': 'ini', 'case_sensitive': False}
    terms = ['user', 'password']
    variables = {}

    # Create an instance of a LoolupModule
    lm = LookupModule()

    # Create a StringIO to simulate a file
    config = StringIO()
    contents = u"[ansible]\nuser=user1\npassword=password1\n[ansible_bis]\nuser=user2\npassword=password2\n"
    # File is read with 'encoding'

# Generated at 2022-06-11 15:34:03.334255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    mk = MockVaultSecret()
    mk.string = 'test'

    mv = MockVaultLib(None)
    mv.secrets = [mk]

    fd = open('/tmp/test_lookup_ini', 'w')
    fd.write(to_text(u"[hg]\ntest=test_value_1\n[fe]\ntest=test_value_2\n"))
    fd.close()

    ml = LookupModule()

# Generated at 2022-06-11 15:34:14.097743
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # initialize lookup module
    mod = LookupModule()

    # create mock `cp` attribute
    c = configparser.RawConfigParser()
    c.add_section('section')
    c.set('section', 'key', 'value')
    mod.cp = c

    # test get_value
    assert 'value' == mod.get_value('key', 'section', 'default', True)
    assert ['value'] == mod.get_value('key', 'section', 'default', True)
    assert 'default' == mod.get_value('key2', 'section', 'default', True)

    # retrieve a list (regexp)
    assert ['value1', 'value2'] == mod.cp.items('section')

# Generated at 2022-06-11 15:34:22.483199
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:34:31.730614
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Test 1: get value "TEST" of the key "test" of section "global"
    global_1 = configparser.ConfigParser()
    global_1.optionxform = str
    config = StringIO()
    config.write(u'[global]\n')
    config.write(u'test = TEST\n')
    config.seek(0, os.SEEK_SET)
    global_1.readfp(config)
    module = LookupModule()
    module.cp = global_1

    assert module.get_value('test', 'global', None, False) == 'TEST'
    assert module.get_value('test', 'global', 'N/A', True) == 'N/A'
    assert module.get_value('test', 'production', None, False) is None

    # Test 2:

# Generated at 2022-06-11 15:34:41.496023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for method run of class LookupModule
    #
    # It is important to test the behavior of this method in the same unit tests
    # because the if parameter is_regexp is True, the regexp is processed
    # and the method find_file_in_search_path is not called.
    t = LookupModule()
    # with 'is_regexp' = False
    terms_list = [ 'ansible', 'web', 'db' ]
    variables = {}
    ini_content=u"""[sections]
ansible=ansible
web=web server
db=database
"""
    config = StringIO()
    config.write(ini_content)
    config.seek(0, os.SEEK_SET)
    t.cp = configparser.ConfigParser(allow_no_value=False)
    t

# Generated at 2022-06-11 15:34:43.344775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule.run(
        LookupModule(),
    )
    assert ret == []

# Generated at 2022-06-11 15:34:54.271794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleLookupError

    import io
    import tempfile
    from unittest.mock import patch
    from unittest.mock import Mock

    def setup_config_mock(conf):
        config = io.StringIO()
        config.write(u'[java_properties]\n')
        config.write(u'foo=bar\n')
        config.seek(0, os.SEEK_SET)
        conf.readfp(config)

    def setup_config_mock_err(conf):
        config = io.StringIO()
        config.write(u'[java_properties]\n')

# Generated at 2022-06-11 15:35:12.322911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test get values
    lookup_plugin = LookupModule()
    params = {'type': 'ini', 'file': 'test.ini', 'section': 'global', 're': False, 'encoding': 'utf-8', 'default': ''}
    config = """
    [global]
    group=mygroup
    user=myuser
    """
    lookup_plugin._templar = None
    lookup_plugin._loader = None
    lookup_plugin.cp = configparser.SafeConfigParser()
    res = lookup_plugin.parse_ini(config)
    assert res == params
    #assert lookup_plugin.get_value("user", "global", "", False) == "myuser"

    # Test section does not exist

# Generated at 2022-06-11 15:35:22.362123
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create an instance of configparser
    config = configparser.ConfigParser()
    # Create an instance of LookupModule
    lookup = LookupModule()

    # Add a section
    config.add_section('test')
    # Add a key in the test section
    config.set('test', 'key1', 'value1')
    # Attribute the result of the get_value method to the var variable
    var = lookup.get_value('key1', 'test', 'default', False)
    # Assert that var has the right value
    assert var == 'value1'

    # Add a key in the test section
    config.set('test', 'key2', 'value2')
    # Attribute the result of the get_value method to the var variable

# Generated at 2022-06-11 15:35:33.522482
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a new instance of LookupModule
    lookup_mod = LookupModule()
    # Create configuration parser
    lookup_mod.cp = configparser.ConfigParser(allow_no_value=True)

    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(u'[section]\n')
    config.write(u'key=value\n')
    config.write(u'regexp=regexp\n')
    config.seek(0, os.SEEK_SET)

    # Init configuration parser
    lookup_mod.cp.readfp(config)

    # Test normal search
    assert lookup_mod.get_value(key='key', section='section', dflt=None, is_regexp=False) == 'value'

    # Test regexp search
    assert lookup

# Generated at 2022-06-11 15:35:44.520198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l.cp = configparser.ConfigParser()
    l.cp.read_string(
        """
        [global]
        key1 = value1
        key2 = value2
        key3 = value3
        key4 = value4
        key5 = value5
        """
    )

    # If a section is given then the section is used
    assert l.run([('key1', ['section1'])]) == ['value1']
    assert l.run([('key1', ['section1', 'section2'])]) == ['value1']

    # If no section is given then the section global is used
    assert l.run([('key1', [])]) == ['value1']

    # If there is no section given, the default section is used

# Generated at 2022-06-11 15:35:54.913721
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a fake LookupModule object
    class FakeLookupModule(object):
        def __init__(self, name, args, **kwargs):
            self.name = name
            self.args = args
            self.kwargs = kwargs

        def __repr__(self):
            return "%s.%s(%s, %s)" % (LookupModule.__module__, LookupModule.__name__, self.name, self.args)

    fake_lookup = FakeLookupModule('foo', 'bar', baz=True)

    # Create an instance of the LookupModule class
    lm = LookupModule()

    # Call the method run on the LookupModule instance
    ret = lm.run([fake_lookup])
    assert ret == ['foo']

# Generated at 2022-06-11 15:36:04.820338
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import sys
    import os

    # Create an instance of lookup module for test
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser(allow_no_value=False)

    # Add section to config parser to simulate file in INI format
    lookup.cp.add_section("global")

    # Test : Return value when key exist and is not a regexp
    assert lookup.get_value("user", "global", "", False) is None

    # Add key to section in config parser
    lookup.cp.set("global", "user", "toto")

    # Test : Return value when key exist and is not a regexp
    assert lookup.get_value("user", "global", "", False) == "toto"

    # Test : Return default value when key does not exist and is not a regexp

# Generated at 2022-06-11 15:36:16.339403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = ['user', 'password']
    paramvals = {
        'type': 'properties',
        'file': 'user.properties',
        'section': 'global',
        're': 'False',
        'default': '',
        'encoding': 'utf-8',
        'case_sensitive': False,
    }
    result = module.run(terms, **paramvals)
    assert result == ['johndoe', 'secretpassword']

    terms = ['user', 'password']
    paramvals = {
        'type': 'properties',
        'file': 'user.properties',
        'section': 'java_properties',
        're': 'False',
        'default': '',
        'encoding': 'utf-8',
        'case_sensitive': False,
    }


# Generated at 2022-06-11 15:36:26.506324
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Remove the following lines to protect develop branch
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), 'lookup_plugins'))

    cp = configparser.ConfigParser()
    cp.readfp(StringIO("""
[section1]
foo=bar
bar=foo
hello=world
[section2]
foo=bar
bar=foo
long=world
"""))
    lookup_module = lookup_module.LookupModule()
    lookup_module.cp = cp

    # test get_value
    assert lookup_module.get_value('foo', 'section1', 'dflt', False) == 'bar'
    assert lookup_module.get_value('hello', 'section1', 'dflt', False) == 'world'

# Generated at 2022-06-11 15:36:37.928474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Tests whether run() method of class LookupModule
    returns the correct value

    """
    lookup = LookupModule()

    # Definition of the test INI file
    data1 = u'''
    [global]
    host = 10.0.0.1
    user = ansible
    user2 = ansible2
    '''

    # Definition of the test properties file
    data2 = u'''
    user=ansible
    user2=ansible2
    '''

    # Create temporary file object
    test1 = StringIO(data1)
    test2 = StringIO(data2)

    # Create config parser object
    testcp1 = configparser.ConfigParser()
    testcp2 = configparser.ConfigParser()

    # Parse the INI file
    testcp1.readfp(test1)

   

# Generated at 2022-06-11 15:36:49.056350
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_plug = LookupModule()
    contents = """
    [section1]
    user=yannig%
    user2=yannig2
    user3=yannig3
    [section2]
    user=yannig4
    """
    config = StringIO()
    config.write(contents)
    config.seek(0, os.SEEK_SET)
    lookup_plug.cp = configparser.ConfigParser()
    lookup_plug.cp.readfp(config)

    assert lookup_plug.get_value('user', 'section1', 'n/a', False) == 'yannig%'
    assert lookup_plug.get_value('user', 'section2', 'n/a', False) == 'yannig4'

# Generated at 2022-06-11 15:37:09.696917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This tests if all the options and parameters are working correctly,
    # with the right values
    # And the right combination of parameters

    # This is the string to parse in a StringIO
    test_ini_1 = """
[server]
user=foo
password=bar
[client]
user=baz
password=foo
"""
    test_ini_2 = """
[server];
user=foo;
password=bar;
[client];
user=baz;
password=foo;
"""
    test_ini_3 = """
[global]
timeout = 22
[server]
user=foo
password=bar
[client]
user=baz
password=foo
"""

# Generated at 2022-06-11 15:37:19.727552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import io
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import StringIO

    class test_LookupBase(LookupBase):
        def __init__(self):
            super(test_LookupBase, self).__init__()

        def run(self, terms, variables=None, **kwargs):
            self.set_options(var_options=variables, direct=kwargs)
            paramvals = self.get_options()

            self.cp = configparser.ConfigParser()
            if paramvals['case_sensitive']:
                self.cp.optionxform = to_native

            ret = []
            for term in terms:

                key = term
                # parameters specified?
                if '=' in term or ' ' in term.strip():
                    params = _parse_params

# Generated at 2022-06-11 15:37:28.124325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.cp = configparser.ConfigParser()
    l.cp.read('files/ansible.ini')
    ret = l.run(['user', 'nouser', 'user', 'nouser'], {}, type='ini', section='integration', file='files/ansible.ini', default='')
    assert len(ret) == 4
    assert ret[0] == 'ansible'
    assert ret[1] == ''
    assert ret[2] == 'ansible'
    assert ret[3] == ''


# Generated at 2022-06-11 15:37:40.010707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from io import BytesIO

    lookup = LookupModule()
    content = '''[section1]
key1=1
key2=2
key3=3

[section2]
key1=a
key2=b
key3=c

[section3]
key1=aaa
key2=bbb
key3=ccc
'''
    config = BytesIO()
    config.write(to_bytes(content))
    config.seek(0, os.SEEK_SET)

    lookup.cp.readfp(config)
    assert lookup.get_value("key1", "section1", "", False) == "1"
    assert lookup.get_value("key2", "section2", "", False) == "b"

# Generated at 2022-06-11 15:37:51.754075
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Prepare test data
    cfg = configparser.ConfigParser()
    cfg.read('/tmp/test.ini')
    instance = LookupModule()
    instance.cp = cfg

    # Test return all values for a given regexp
    value = instance.get_value(r'\d+', 'section1', '', True)
    assert isinstance(value, list)
    assert len(value) == 2
    assert value[0] == 'val1'
    assert value[1] == 'val2'

    # Test return single value
    value = instance.get_value('key1', 'section1', '', False)
    assert isinstance(value, str)
    assert value == 'val1'

    # Test return default value because of bad key

# Generated at 2022-06-11 15:38:02.345795
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    list_var = []
    dict_var = dict()

    dict_var['section1'] = dict()
    dict_var['section1']['key1'] = '1'
    dict_var['section2'] = dict()
    dict_var['section2']['key1'] = '1'
    dict_var['section2']['key2'] = '2'

    list_var.append(dict_var)

    config = StringIO()

    for k_level1, v_level1 in dict_var.items():
        config.write(u'\n')
        config.write(u'[' + k_level1 + u']' + u'\n')

# Generated at 2022-06-11 15:38:11.642892
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    l = LookupModule({})
    l.cp = configparser.ConfigParser()
    l.cp.add_section('section1')
    l.cp.set('section1', 'foo', 'bar')
    l.cp.set('section1', 'foo2', 'bar2')

    # test non-regexp key
    assert l.get_value('foo', 'section1', 'default_value', False) == 'bar'

    # test non-regexp key not in section
    assert l.get_value('foo3', 'section1', 'default_value', False) == 'default_value'

    # test regexp key
    assert 'bar' in l.get_value('.*', 'section1', 'default_value', True)

# Generated at 2022-06-11 15:38:16.674698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Fail if file is not found or for any other exception
    def file_loader(path, *args, **kwargs):
        raise AnsibleFileNotFound(path = path)

    module._loader = file_loader

    # LookupModule.run throws an exception when the file isn't found
    # Since the file can't be found, it throws an error
    with pytest.raises(AnsibleLookupError):
        module.run({}, templar=dict(), variables=dict())

# Generated at 2022-06-11 15:38:27.018700
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ini_file = StringIO()
    ini_file.write(u'[section_one]\nfoo=bar\nkey=value\n\n[section_two]\nfoo=bar\nbar=foo')
    ini_file.seek(0, os.SEEK_SET)

    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser()
    lookup_module.cp.readfp(ini_file)

    # The key 'key' exists in the section 'section_one', so it should return 'value'
    assert lookup_module.get_value('key', 'section_one', None, False) == "value"

    # The key 'key' exists in the section 'section_one', so it should return a list containing 'foo' and 'bar'
    assert lookup_module

# Generated at 2022-06-11 15:38:37.818206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    ini_file = """
    # This is a comment
    [section1]
    key1=value1
    key2=value2
    key3=value3
    ; This is another comment
    [section2]
    key4=value4
    """
    ini_file_re = """
    # This is a comment
    [section1]
    key1=value1
    key2=value2
    key3=value3
    ; This is another comment
    [section2]
    key4=value4
    """
    ini_file_no_section = """
    # This is a comment
    key1=value1
    key2=value2
    key3=value3
    """
    ini_file_

# Generated at 2022-06-11 15:39:09.993991
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    terms = ['test']
    l = LookupModule(terms, '', '', [], '')

    section = 'section1'
    content = "[{0}]\ntest=value".format(section)
    fp = StringIO(content)

    # On un match
    l.cp.readfp(fp)
    assert [] == l.get_value('toto', section, None, False)
    # On un match avec regexp
    assert [] == l.get_value('toto', section, None, True)

    # On regexp match
    assert ['value'] == l.get_value('es', section, None, True)

    assert 'value' == l.get_value('test', section, None, False)

# Generated at 2022-06-11 15:39:20.294783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    def get_host_mock(vars=None):
        vars = vars or {}
        return Host(name='test', port=5678, variables=vars)

    class MockVars(list):
        def get(self, k, default=None):
            return self.__dict__.get(k, default)

        def __getitem__(self, k):
            return self.__dict__[k]


# Generated at 2022-06-11 15:39:30.206994
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test with a regexp
    l = LookupModule()
    l.cp = configparser.RawConfigParser()
    l.cp.readfp(StringIO("""[section]
key1=valeur1
key2=valeur2
regexp1=value1
regexp2=value2
regexp3=value3
"""))
    assert l.get_value("^regexp", "section", None, "True") == ['value1', 'value2', 'value3']
    # Test with a non-regexp
    assert l.get_value("key1", "section", None, "False") == "valeur1"
    # Test with a non-existent key (and a non-None default value)

# Generated at 2022-06-11 15:39:41.334989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # Test when no file is given
    test_terms = ['not_in_file']
    params = {'default': '', 'file': 'test.ini', 're': False, 'type': 'ini'}
    try:
        result = lookup_plugin.run(test_terms, params)
        assert result[0] == ''
    except AnsibleLookupError as err:
        assert False, 'Exception raised: %s' % err

    # Test when a file is given and a key is present
    test_terms = ['key']
    params = {'default': '', 'file': 'test.ini', 're': False, 'type': 'ini'}

# Generated at 2022-06-11 15:39:52.377086
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # check if no error is raised when file does not exist
    term_no_file = 'user'
    term_no_file_paramvals = {'file': 'blah', 'section':'global'}
    test_no_file = LookupModule()
    assert test_no_file.run(terms=[term_no_file], variables=None, **term_no_file_paramvals) == []

    # check if no error is raised when section does not exist
    term_no_section = 'user'
    term_no_section_paramvals = {'file': 'tests/data/lookup_ini/users.properties', 'section': 'blah'}
    test_no_section = LookupModule()

# Generated at 2022-06-11 15:40:02.666479
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    config_string = """
[section1]
key1=value1
key3=value3
key2=value2
"""
    config_ini = configparser.RawConfigParser(allow_no_value=True)
    config_ini.readfp(StringIO(config_string))

    assert LookupModule.get_value('key1', 'section1', None, False, config_ini) == 'value1'
    assert LookupModule.get_value('.*', 'section1', None, True, config_ini) == ['value1', 'value2', 'value3']
    assert LookupModule.get_value('key4', 'section1', None, False, config_ini) == None
    assert LookupModule.get_value('key4', 'section1', 'value4', False, config_ini) == 'value4'

# Generated at 2022-06-11 15:40:12.466702
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import pytest

    ini_data = """
[Section2]
key=value
key2=value2
"""
    config = StringIO()
    config.write(ini_data)
    config.seek(0, os.SEEK_SET)
    cp = configparser.ConfigParser()
    cp.readfp(config)

    assert LookupModule().get_value('key', 'Section2', None, True) == ['value']
    assert LookupModule().get_value('key2', 'Section2', None, False) == 'value2'
    assert LookupModule().get_value('keyx', 'Section2', None, False) == None
    assert LookupModule().get_value('key2', 'Section1', None, False) == None

# Generated at 2022-06-11 15:40:21.919871
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # _parser_params - test case no. 1
    assert _parse_params("key1=value1 key2=value2", {}) == ["key1=value1", "key2=value2"]

    # Parse a properties file
    config2 = StringIO()
    config2.write(u'# Section[java_properties]\n')
    config2.write(u'user=root\n')
    config2.seek(0, os.SEEK_SET)
    cp2 = configparser.ConfigParser()
    cp2.optionxform = to_native
    cp2.readfp(config2)

    # Define explicit options
    options = {}
    options['file'] = 'ansible.ini'  # No file by this name exists.
    options['section'] = 'java_properties'

# Generated at 2022-06-11 15:40:31.096312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for LookupModule class

    file test.ini:

    [section1]
    host1=192.168.1.10
    host2=192.168.1.11
    host3=192.168.1.12

    [section2]
    host4=192.168.1.13
    host5=192.168.1.14
    host6=192.168.1.15

    :return:
    """
    lookup_module = LookupModule()

    # Test with a list of terms
    result = lookup_module.run(["file=test.ini", "host.re=host[0-9]$", "section=section1"], lookup_module._display, section="", type="ini", re=True)
    assert result == ['host1', 'host2', 'host3']



# Generated at 2022-06-11 15:40:39.788223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test default arguments
    assert lookup_module._lookup_args() == {
            'allow_no_value': False,
            'allow_none': False,
            'case_sensitive': False,
            'default': '',
            'encoding': u'utf-8',
            'file': u'ansible.ini',
            're': False,
            'section': u'global',
            'type': u'ini',
        }

    # Test method find_file_in_search_path
    assert lookup_module.find_file_in_search_path(None, 'files', "users.ini") == "users.ini"

    # Test method run
    assert lookup_module.run(["user", "file=users.ini"], None)[0] == "yannig"

# Generated at 2022-06-11 15:41:34.952693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from io import StringIO
    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.plugin_docs import read_docstring

    lookup = LookupModule()
    doc = read_docstring(lookup)
    assert doc['name'] == 'ini'

    _cp = configparser.ConfigParser(allow_no_value=False)
    ini_file = StringIO("""
[section1]
key1=value1
key2=value2
""")
    _cp.readfp(ini_file)
    lookup.cp = _cp

    assert lookup.get_value("key2", "section1", "", False) == "value2"

# Generated at 2022-06-11 15:41:44.058251
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()

    lookup.cp.add_section("global")
    lookup.cp.set("global", "var1", "value1")
    lookup.cp.set("global", "var2", "value2")

    # Test with a normal key
    var = lookup.get_value("var1", "global", "default", False)
    assert var == "value1"

    # Test with a regex
    var = lookup.get_value("var.+", "global", "default", True)
    assert var == ["value1", "value2"]

    # Test with a non-existing key
    var = lookup.get_value("var3", "global", "default", False)
    assert var == "default"

    # Test with a non-existing section
    var

# Generated at 2022-06-11 15:41:53.805284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test a valid key in a valid section
    term = 'user'
    params = {'section': 'section1', 'file': 'test.ini', 're': False, 'default': ''}
    lk = LookupModule()
    var = lk._get_value(term, params['section'], params['default'], params['re'])
    assert var == 'user1'

    # Test an invalid key in a valid section
    term = 'user2'
    params = {'section': 'section1', 'file': 'test.ini', 're': False, 'default': ''}
    lk = LookupModule()
    var = lk._get_value(term, params['section'], params['default'], params['re'])
    assert var == ''

    # Test a valid key in an invalid section
    term

# Generated at 2022-06-11 15:42:04.142291
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import os
    import tempfile
    from ansible.errors import AnsibleLookupError
    from ansible.plugins.lookup.ini import LookupModule

    test_section = 'test_section'
    test_key1 = 'test_key1'
    test_key2 = 'test_key2'
    test_key3 = 'test_key3'
    test_key4 = 'test_key4'
    test_value1 = 'test_value1'
    test_value2 = 'test_value2'
    test_value3 = 'test_value3'
    test_value4 = 'test_value4'
    test_key1_value = '[u test_key1] test_value1'
    test_key2_value = '[u test_key2] test_value2'
    test_key

# Generated at 2022-06-11 15:42:15.986380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Tests LookupModule.run"""

    # Mocks
    class MockConfigParser(object):
        def __init__(self, *args, **kwargs):
            self.options = {}

        def readfp(self, config):
            config.seek(0, os.SEEK_SET)
            self.options = dict(config.read().splitlines())

        def items(self, section):
            return self.items(section) if section in self.options else []

        def get(self, section, key):
            return self.options[key] if key in self.options else None

        def sections(self):
            return []


# Generated at 2022-06-11 15:42:24.979775
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    attrs = {'re': True, 'section': 'section1'}
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'key1 = value1\n')
    config.write(u'key2 = value2\n')
    config.seek(0, os.SEEK_SET)
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(config)
    assert sorted(lookup.get_value('.*', **attrs)) == sorted(['key1=value1', 'key2=value2'])
    assert lookup.get_value('key1', **attrs) == 'value1'
    assert lookup.get_value('key3', **attrs) is None

# Unit test

# Generated at 2022-06-11 15:42:35.886721
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Mock configparser.ConfigParser
    cp = mock.Mock()
    cp.get.return_value = 'value'
    cp.items.return_value = [('key1', 'value1'), ('key2', 'value2')]
    # Instantiate LookupModule
    lookup = LookupModule()
    lookup.cp = cp
    # Test with a regexp
    assert lookup.get_value('.*', 'section', 'default', True) == ['value1', 'value2']
    # Test with a simple key
    assert lookup.get_value('key', 'section', 'default', False) == 'value'
    # Test with a non existing key
    assert lookup.get_value('missing', 'section', 'default', False) == 'default'

# Generated at 2022-06-11 15:42:43.385619
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    data = """
[section1]
key1=value1
key2=value2

[section2]
key3=value3
key4=value4

[section3]
key5=value5
key6=value6
"""
    fd = StringIO(data)
    cp = configparser.ConfigParser()
    cp.readfp(fd)
    # Positive test
    # Test on a single value
    assert LookupModule.get_value('key1', 'section1', None, False) == 'value1'
    # Test on a list of values
    assert LookupModule.get_value('key[0-9]', 'section1', None, True) == ['value1', 'value2']
    # Test on non-existent value (default value used)

# Generated at 2022-06-11 15:42:49.965420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os
    import pytest
    from tempfile import NamedTemporaryFile

    # create data loader
    loader = DataLoader()

    # create variable manager
    variable_manager = VariableManager()

    # create lookup module
    lookup_module = LookupModule()

    # create temporary file
    fd, path = NamedTemporaryFile(delete=False)
    fd.write(b'[main]\n')
    fd.write(b'log_root=/var/log\n')
    fd.close()

    # test section and key are set
    terms = ['log_root']

# Generated at 2022-06-11 15:42:59.386015
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Test regexp match
    cp = configparser.ConfigParser(allow_no_value=True)
    cp.readfp(StringIO(u'[java_properties]\nuser.name=test\nuser.password=toto'))
    l_m = LookupModule()
    l_m.cp = cp

    assert l_m.get_value('user.name', 'java_properties', '', True) == ['test']
    assert l_m.get_value('user.password', 'java_properties', '', True) == ['toto']
    assert l_m.get_value('toto', 'java_properties', '', True) is None

    # Test get single value
    assert l_m.get_value('user.name', 'java_properties', '', False) == 'test'
    assert l_