

# Generated at 2022-06-11 15:33:34.016048
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test = LookupModule()
    test.cp = configparser.ConfigParser()
    test.cp.readfp(StringIO("""[global]
name=toto
"""),'global.ini')

    assert test.get_value("name","global","","") == 'toto'
    assert test.get_value("[0-9]","global","","") == None
    assert test.get_value("name","toto","","") == None
    assert test.get_value("name","global","tata","") == None
    assert test.get_value("[0-9]","global","tata","") == "tata"

# Generated at 2022-06-11 15:33:44.755204
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    m = LookupModule()

    # Create a StringIO to use as file like object
    s = StringIO()

    # Set contents of this file to the variable content
    # TODO: variable is unused
    content = """
[global]
url = http://www.example.com

[integration]
user = foo

[production]
user = bar
"""
    s.write(content)
    s.seek(0, os.SEEK_SET)

    # Create a ConfigParser instance
    cp = configparser.ConfigParser()
    cp.readfp(s)

    # Add cp to the instance of LookupModule
    m.cp = cp

    # Run the method run

# Generated at 2022-06-11 15:33:53.788594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    data = """
[section1]
a1 = 1.1
a2 = 2.2

[section2]
b1 = 3.3
b2 = 4.4
"""
    data_file = open('data_file', 'w')
    data_file.write(data)
    data_file.close()
    assert lookup.run(terms=['a1'], variables={}, file="data_file", section="section1") == ['1.1']
    assert lookup.run(terms=['b1'], variables={}, file="data_file", section="section2") == ['3.3']
    assert lookup.run(terms=['a1'], variables={}, file="data_file", section="section2") == ['']

# Generated at 2022-06-11 15:34:05.462229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test ensure that 'value' is in the returned list
    import inspect
    import sys

    me = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    sys.path.append(os.path.join(me, os.pardir, os.pardir, os.pardir, 'test', 'lib'))

    from AnsibleModuleMock import AnsibleModuleMock
    module = AnsibleModuleMock()
    lookup_plugin = LookupModule(module=module)

    result = lookup_plugin.run(terms=['key1'], variables={'key1': 'value'},
                               file='test.ini', section='test',
                               case_sensitive=True, type='ini')
    assert result[0] == 'value'

# Generated at 2022-06-11 15:34:15.971088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    import ansible.plugins.lookup.ini as ini
    import ansible.plugins.loader as loader

    lookup = ini.LookupModule()
    options = {
        u'type': u'ini',
        u'file': u'test.ini',
        u'encoding': u'utf-8',
        u're': u'False',
        u'section': u'Default',
        u'case_sensitive': False,
        u'allow_no_value': False
    }
    loader.add_directory(os.path.join(os.path.dirname(__file__), u'../../lib/ansible/plugins/lookup'))
    lookup._loader

# Generated at 2022-06-11 15:34:21.926873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.add_section('section1')
    lookup.cp.set('section1', 'key1', 'value1')
    lookup.cp.add_section('section2')
    lookup.cp.set('section2', 'key2', 'value2')

    term = 'key1'
    variables = None
    kwargs = {'dflt': 'default', 'file': 'test', 'is_regexp': False, 're': False, 'section': 'section1', 'type': 'ini'}
    ret = lookup.get_value(term, kwargs['section'], kwargs['dflt'], kwargs['is_regexp'])
    assert ret == 'value1'

# Generated at 2022-06-11 15:34:31.398383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib

    lookup_module = LookupModule()
    assert lookup_module.run(['']) == []

    lookup_module.set_options(direct={'type': 'ini'})
    assert lookup_module.run(['']) == []

    lookup_module.set_options(direct={'type': 'properties'})
    assert lookup_module.run(['']) == []

    lookup_module.set_options(direct={'type': 'json'})
    assert lookup_module.run(['']) == []

    lookup_module.set_options(direct={'type': 'ini'})

# Generated at 2022-06-11 15:34:40.649186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Method run() without section and without re
    module = LookupModule()
    assert module.run(['.*'], {}, {}, file='ini_file_fixture.ini') == ['value1', 'value2']

    # Method run() without section and with re
    module = LookupModule()
    assert module.run(['.*'], {}, {}, file='ini_file_fixture.ini', re=True) == ['value1', 'value2']

    # Method run() with section and with re
    module = LookupModule()
    assert module.run(['.*'], {}, {}, file='ini_file_fixture.ini', re=True, section='section1') == ['value1']



# Generated at 2022-06-11 15:34:49.300732
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Init class
    lookup_plugin = LookupModule()
    # Init configparser
    lookup_plugin.cp = configparser.ConfigParser()
    # Add section to configparser
    lookup_plugin.cp.add_section('test')
    # Add ini value
    lookup_plugin.cp.set('test', 'name', 'value')

    # Retrieve ini value
    assert lookup_plugin.get_value('name', 'test', 'default', False) == 'value'
    # Retrieve ini value with .*
    assert lookup_plugin.get_value('na.*', 'test', 'default', True) == ['value']

# Generated at 2022-06-11 15:34:59.076135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test function for class LookupModule
    """

    # Create object of LookupModule
    lookup_module = LookupModule()

    # Create term
    term = 'key1 section1'

    # Create variables for test
    variables = {
        'file': 'test.ini',
        'section': 'section1',
        'default': 'default1',
        're': False,
        'encoding': 'utf-8',
        'type': 'ini'
    }

    # Mock method find_file_in_search_path
    def mock_find_file_in_search_path(variables, file):
        return 'test.ini'

    lookup_module.set_options(var_options=variables)
    lookup_module.find_file_in_search_path = mock_find_file_

# Generated at 2022-06-11 15:35:21.402195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test without regexp and without section
    lookup_params_1 = {
        '_terms': ['localhost'],
        'encoding': 'utf-8',
        'default': '127.0.0.1',
        'file': u'ansible.ini',
        'case_sensitive': False,
        'allow_no_value': False
    }
    lookup_obj_1 = LookupModule()
    lookup_obj_1.set_options(**lookup_params_1)
    assert lookup_obj_1.run(**lookup_params_1)[0] == "127.0.0.1"

    # test with regexp

# Generated at 2022-06-11 15:35:33.109372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModuleMock(LookupModule):
        def __init__(self, file):
            self.file = file

        def get_value(self, key, section, dflt, is_regexp):
            self.cp = configparser.ConfigParser()

            if self.file:
                config = StringIO()
                config.write(u'[%s]\n' % section)
                if key == 'mail':
                    config.write(u'%s="my.mail@gmail.com"\n' % key)
                config.write(u'a=12\n')
                config.write(u'b="abcdef"\n')
                config.write(u'c="+=|{}()/\\*"\n')
                config.seek(0, os.SEEK_SET)
                self

# Generated at 2022-06-11 15:35:43.978801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class AnsibleModule(object):
        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['invocation'] = self.invocation

    class Options(object):
        def __init__(self, params):
            self._params = params
        def __getattr__(self, name):
            return self._params[name]

    module = AnsibleModule()

    lookup = LookupModule(module)

    terms = ['user', 'user=esopo password=secret', 'user password=secret']
    for term in terms:
        module.exit_args = {}
        module.invocation = {}
        module._params = {}
        module._params['file'] = 'tests/ini_test.ini'
        module._params['section'] = 'test'

        #

# Generated at 2022-06-11 15:35:55.040262
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_string = """[section1]
key1=value1"""
    config = StringIO(test_string)

    lk = LookupModule()
    lk.here = '.'
    lk.cp = configparser.ConfigParser()
    lk.cp.readfp(config)

    # Test run() with single key
    result = lk.run(['key1'])
    assert result == ['value1']

    # Test run() with multiple keys
    result = lk.run(['key1 key1'])
    assert result == ['value1', 'value1']

    # Test run() with regexp
    result = lk.run(['.*'])
    assert result == ['value1']

    # Test run() with option str_type

# Generated at 2022-06-11 15:36:04.976316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import textwrap
    import tempfile

    # Make temp dir
    test_ansible_ini_path = tempfile.mkdtemp()

    # Make data file
    test_ansible_ini_filename = "ansible.ini"
    test_ansible_ini_filepath = os.path.sep.join([test_ansible_ini_path, test_ansible_ini_filename])
    with open(test_ansible_ini_filepath,"w") as f:
        f.write(textwrap.dedent("""
            # This is a comment
            [global]
            # And this is another comment
            user = root
            # This is a comment too
            [integration]
            user = foo

            [production]
            user = bar
        """))

    # Make data file
    test

# Generated at 2022-06-11 15:36:16.646309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test with a ini file which contains a section

    # test with a key and a section which exist
    term = "user.name"
    paramvals = dict(
        type="ini",
        file="user.ini",
        section="user1",
        re="False",
        encoding="utf-8",
        default="",
        allow_none=True,
        case_sensitive=False
    )
    variables = dict()
    path = os.path.join(_LookupModule_test_dir, paramvals['file'])
    with open(path, encoding=paramvals['encoding']) as config_file:
        cp = configparser.ConfigParser()
        cp.readfp(config_file)

# Generated at 2022-06-11 15:36:26.687454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # case of using a regex to retrieve all values
    terms = ['user']
    paramvals = dict(
        file='testLookupModule.ini',
        section='global',
        re=True,
        encoding='utf-8',
        default='',
        allow_no_value=False,
        allow_none=False,
        case_sensitive=False,
        type='ini'
    )
    module_Test = LookupModule()
    module_Test.cp = configparser.ConfigParser()
    module_Test.cp.readfp(StringIO('[global]\nuser=yperre\nuser=dclin\nuser=hguo\n'))
    result = module_Test.get_value('user', 'global', '', True)

# Generated at 2022-06-11 15:36:38.122505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Unit test for method run with section
    terms = ['user']
    variables = {'ansible_system_capabilities': {'privileged': True}}
    kwargs = {'file': 'tests/fixtures/test.ini', 'section': 'test', 'encoding': 'utf-8', 'default': '', 'case_sensitive': False, 're': False, 'type': 'ini'}
    result = lookup.run(terms, variables=variables, **kwargs)
    assert result == ['test1']

    # Unit test for method run without section
    terms = ['dbuser']
    variables = {'ansible_system_capabilities': {'privileged': True}}

# Generated at 2022-06-11 15:36:49.214757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Setting the option allow_no_value to True
    module.set_options(var_options=None, direct={'allow_no_value': True})

    # Test module using a property file
    path = "/tmp/my.properties"
    fp = open(path, "w")
    fp.write("user.name=Ansible\nuser.age=14\n")
    fp.close()
    terms = ["user.name", "user.age", "user.city", "user.foo"]
    direct = {"type": "properties", "default": "foo", "file": path}
    module.set_options(var_options=None, direct=direct)
    result = module.run(terms, variables=None)
    assert len(result) == 4

# Generated at 2022-06-11 15:36:59.881813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    # Test good regexp case
    terms = ['this_is.*_regexp']
    kwargs = dict(
        path = '/tmp',
        file = 'file.ini',
        section = 'section1',
        re = True,
        encoding = 'utf-8',
        default = '',
        case_sensitive = False,
    )
    parsed_params = _parse_params(terms[0], kwargs)
    for param in parsed_params:
        if '=' in param:
            name, value = param.split('=')
            kwargs[name] = value
    assert lookup_plugin.run(terms, variables=[], **kwargs) == ['true']
    # Test good case
    terms = ['var1']

# Generated at 2022-06-11 15:37:18.436873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test use of option file
    options = {u'file': u'test-vars-file.ini'}
    # Test use of option section
    options.update({u'section': u'TEST1'})
    # Test use of option re
    options.update({u're': u'False'})
    # Test use of option default
    options.update({u'default': u''})
    # Test use of option type
    options.update({u'type': u'ini'})
    # Test use of option case_sensitive
    options.update({u'case_sensitive': False})
    # Test use of option allow_no_value
    options.update({u'allow_no_value': False})
    terms = ['var1', 'var2', 'var3']



# Generated at 2022-06-11 15:37:23.017185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({'file': 'test_run.ini', 'type': 'ini', 'allow_no_value': 'true'})
    results = lookup.run([("test",)], variables={'var1': 'value1', 'var2': 'value2'})
    assert len(results) == 1
    assert results[0] is None

# Generated at 2022-06-11 15:37:24.579464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # TODO: ignore unit test until implemented
    #
    pass

# Generated at 2022-06-11 15:37:37.118879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.vars.vault import _VaultSecret
    class MockVaultSecret(_VaultSecret):
        def __init__(self):
            pass
        def get_decrypted_value(self, path):
            return "decrpath"
    # Override VaultSecret
    LookupBase._VaultSecret = MockVaultSecret
    LookupModule._VaultSecret = MockVaultSecret

    testfile = open("test_lookup_ini_run.txt","w")
    testfile.write("[section1]\nvar1=value1\nvar2=value2\nvar3=value3\nvar4=value4\nvar5=value5\n")
    testfile.close()

    lm = LookupModule()


# Generated at 2022-06-11 15:37:48.990777
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    cp = configparser.ConfigParser()
    # for python 2.6 compatibility it's important to not have a [DEFAULT] section
    with open('test.ini', 'w') as configfile:
        configfile.write('''[section1]
key1=value1
key2=value2
key3=value3

[section2]
key1=value1
key3=value3
''')
    cp.read('test.ini')

    # no default_value
    value = LookupModule().get_value('key1', 'section1', None, False)
    assert value == 'value1'

    # no default_value, regexp
    value = LookupModule().get_value('key2', 'section1', None, True)
    assert value == ['value2']

    # default_value

# Generated at 2022-06-11 15:37:57.969087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables
    class Options():
        def __init__(self, allow_no_value, case_sensitive, default, encoding, file, re, section, type):
            self.allow_no_value = allow_no_value
            self.case_sensitive = case_sensitive
            self.default = default
            self.encoding = encoding
            self.file = file
            self.re = re
            self.section = section
            self.type = type
    class LookupBaseTest():
        def set_options(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct
    class LookupBaseVariables():
        def __init__(self, ansible_env):
            self.ansible_env = ansible_env

# Generated at 2022-06-11 15:38:08.046947
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    config_parser = configparser.ConfigParser(allow_no_value=True)

    terms = [
        "user",
        "port=3306",
        "host=localhost",
        "host",
        "user=root",
        "user root"
    ]
    paramvals = {
        "type": "ini",
        "default": "",
        "re": False,
        "file": "ansible.ini",
        "section": "global",
        "encoding": "utf-8",
        "case_sensitive": False
    }

    results = [
        "johndoe",
        "3306",
        "localhost",
        "localhost",
        "root",
        "root"
    ]

    config = StringIO()

# Generated at 2022-06-11 15:38:16.315969
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import contextlib

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.display import Display

    display = Display()

    config = StringIO()
    config.write(u"""[section1]
Hostname = one.example.org
Token = one12345
[section2]
Hostname = two.example.org
Token = two12345
[section3]
Hostname = three.example.org
Token = three12345
[section4]
Hostname = four.example.org
Token = four12345
""")
    config.seek(0, os.SEEK_SET)

    # Create the lookup plugin instance

# Generated at 2022-06-11 15:38:26.678754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["user", "password=mypass", "password", "group", "user=myuser", "group=myhost", "re=True", "section=section1", "section"]
    var_options = {"file": "ansible.ini"}
    direct = {"type": "ini", "encoding": "utf-8", "re": False, "default": "", "case_sensitive": True, "allow_no_value": False}
    paramvals = {"file": "ansible.ini", "type": "ini", "re": False, "default": "", "encoding": "utf-8", "allow_no_value": False, "case_sensitive": True}
    cp = configparser.ConfigParser(allow_no_value=paramvals.get('allow_no_value', paramvals.get('allow_none')))

# Generated at 2022-06-11 15:38:37.525639
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a config file (config.ini)
    config = configparser.ConfigParser(allow_no_value=True)
    config.add_section('section1')
    config.set('section1', 'k1', 'v1')
    config.set('section1', 'k2', 'v2')
    config.set('section1', 'k3')
    with open('config.ini', 'w') as f:
        config.write(f)
    # Create a lookup module
    lookup_module = LookupModule()
    lookup_module.cp = configparser.ConfigParser(allow_no_value=True)
    # Test get_value
    assert ['v1', 'v2'] == lookup_module.get_value('.*', 'section1', None, True)

# Generated at 2022-06-11 15:39:10.211014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([], {}, None, None, None, None) == []

    # Use default arguments
    assert module.run(['yannig'], {}, None, None, None, None) == ['yannig']
    assert module.run(['yannig', 'sophie'], {}, None, None, None, None) == ['yannig', 'sophie']

    # Use given arguments
    assert module.run(['yannig'], {}, [], [], None, None) == []
    assert module.run(['yannig'], {}, [], '', None, None) == []
    # TODO: this doesn't make sense, these should be equivalent
    assert module.run(['yannig'], {}, [], None, None, None) == []


# Generated at 2022-06-11 15:39:20.494978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test ini file
    ini_file = """
    [section1]
    key = value
    """
    # test properties file
    properties_file = """
    key1=value1
    key2=value2
    key3=value4
    """

    module = LookupModule()
    assert module.run([], loader=None, templar=None) == []
    # FIXME: both of these tests fail when run with nosetests
    # assert module.run(['key',], loader=None, templar=None, variables=dict(ansible_config_file='test.ini')) == ['value']
    # assert module.run(['key1',], loader=None, templar=None, variables=dict(ansible_config_file='test.ini')) == ['value1']

# Generated at 2022-06-11 15:39:30.336945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Test(object):

        def __init__(self, return_value=None):
            self.return_value = return_value

        def __getitem__(self, key):
            return self.return_value

    f = Test('users.ini')
    file = Test(f)
    lookup_plugin = LookupModule()
    lookup_plugin.set_options({'file': 'users.ini'})
    lookup_plugin.get_options()
    lookup_plugin.find_file_in_search_path = Test('/etc/ansible/users.ini')
    lookup_plugin._loader = Test()
    lookup_plugin._loader._get_file_contents = Test(('''
[global]
user=yannig
''', None))
    config = StringIO()

# Generated at 2022-06-11 15:39:41.423496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    # Create a class object LookupModule
    lookup_plugin = LookupModule()
    # Create a config file using StringIO
    config = StringIO()
    # Add section and key to ini file
    config.write(u'[test]\nkey=value')
    config.seek(0)
    # Create a configparser object
    cp = configparser.ConfigParser()
    # Read ini file
    cp.readfp(config)
    # Call LookupModule method run
    ret = lookup_plugin.run(terms=['key', 'key1'], variables=None, section='test', file='', re=False,
        encoding='utf-8', default='', case_sensitive=False, _terms=['key', 'key1'])
    # Test LookupModule method

# Generated at 2022-06-11 15:39:44.944058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert LookupModule().run(["user", "section=integration", "file=ini_file", "re=False", "type=ini"], variables={'ini_file': './tests/ini_file'}) == ['user1']

# Generated at 2022-06-11 15:39:54.371982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # When not passing parameter `type`
    # Then it should initilize self.cp with `configparser.ConfigParser()`
    # And self.allow_no_value should be `False`
    cp = configparser.ConfigParser()
    assert_common(cp, type='ini', allow_no_value=False)

    # When passing parameter `type` with value `properties`
    # Then it should initilize self.cp with `configparser.ConfigParser()`
    # And self.allow_no_value should be `True`
    cp = configparser.ConfigParser()
    assert_common(cp, type='properties', allow_no_value=True)


# Generated at 2022-06-11 15:40:04.559041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    var = defaultdict(lambda: '')
    var['files'] = 'files'
    var['collections'] = 'collections'

    # Retrieve a key in a section with default INI file
    key_section_default = 'key_section_default'
    terms_key_section_default = [key_section_default]
    paramvals_key_section_default = {
        'type': 'ini',
        'file': 'test.ini',
        'section': 'test',
        're': 'False',
        'default': '',
        'case_sensitive': False,
        'allow_no_value': False,
        'allow_none': False,
        'encoding': 'utf-8'
    }

# Generated at 2022-06-11 15:40:13.051865
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: This test is not really useful, it needs to be changed to use
    #       a fake file and load it in the plugin.

    # This test is a basic test that should be moved in a common test
    #  but I could not manage to make it work

    # Test with re set to False
    lu = LookupModule()
    lu._options = {'file': 'ansible.log',
                   'section': 'production',
                   're': False}
    term = 'user'
    lu.cp = configparser.ConfigParser()
    lu.cp.readfp(StringIO("[production]\nuser=test_user"))
    lu.cp.readfp(StringIO("[integration]\nuser=test_user"))

# Generated at 2022-06-11 15:40:22.517721
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY2

    # Note: Since LookupModule.run is defined in this module, the method can only be tested here.
    #   We cannot mock the method as explained in other test files.

    module = LookupModule()
    path_to_file = '../../lookup_plugins/tests/ini_file.ini'
    module.set_options(var_options=None, direct={'file':path_to_file, 'section':'global'})

    module.cp = configparser.SafeConfigParser(allow_no_value=False)

    if PY2:
        from io import BytesIO
        config = BytesIO()
    else:
        config = StringIO()

# Generated at 2022-06-11 15:40:31.655707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    lookup = LookupModule()
    lookup.set_loader(loader)
    lookup.set_inventory(inventory)
    lookup.set_variable_manager(variable_manager)
    lookup.set_play_context(play_context)

    # Generate a test file

# Generated at 2022-06-11 15:41:27.106470
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Init class LookupModule
    class_LookupModule = LookupModule()

    # Init dict
    dict = {"file": "users.ini",
            "section": "integration"}
    class_LookupModule.set_options(var_options=None, direct=dict)

    # Init List
    list = ['user']

    result = class_LookupModule.run(list)

    assert result == ['Carlos', 'Gonzalo']


# Generated at 2022-06-11 15:41:35.836228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule('ini', os.path.dirname(__file__), None, None, None)

    # Search for a section whose name is not in the file
    assert lk.run([os.path.join(os.path.dirname(__file__), 'test.ini')]) == []

    # Search for a key which does not exist
    assert lk.run([os.path.join(os.path.dirname(__file__), 'test.ini'), 'key']) == []

    # Search for a key whose value must be a list
    assert lk.run([os.path.join(os.path.dirname(__file__), 'test.ini'), 'key2']) == ['valeur2']

# Generated at 2022-06-11 15:41:42.309764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    paramvals = {
        'type': 'ini',
        'file': 'users.ini',
        'section': 'integration',
        'default': '',
        're': False
    }

    fileContent = '''
[integration]
user=test
'''
    with open(paramvals['file'], 'w') as f:
        f.write(fileContent)

    terms = ['user']
    lookup_module.run(terms,paramvals)

test_LookupModule_run()

# Generated at 2022-06-11 15:41:52.984028
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    data = (
        ("key2", "section", "", False, "value2"),
        ("^key[0-9]$", "section", "", True, ["value0", "value1", "value2"]),
        ("key1", "section1", "", False, None),
        ("key", "section", "default", False, "default"),
        ("^key.*$", "section", "", True, ["value0", "value1", "value2"]),
    )
    for test_data in data:
        lookup = LookupModule()
        lookup.cp = configparser.ConfigParser()
        lookup.cp.readfp(StringIO(u'[section]\nkey0=value0\nkey1=value1\nkey2=value2'))
        lookup.cp.add_section('section1')


# Generated at 2022-06-11 15:42:03.496935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = ['user', 'password']
    variables = {}
    kwargs = {'file': 'test.ini', 'section': 'section1'}

    ret = module.run(terms, variables, **kwargs)
    assert ret == ['yannig', 'azerty']

    # Test with regexp
    terms = ['.*']
    variables = {}
    kwargs = {'file': 'test.ini', 'section': 'section1', 're': True}

    ret = module.run(terms, variables, **kwargs)
    assert ret == ['user', 'yannig', 'password', 'azerty']

    # Test with default value
    terms = ['user3']
    variables = {}

# Generated at 2022-06-11 15:42:15.394588
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    testclass = LookupModule()
    testclass.cp = configparser.ConfigParser(allow_no_value=False)
    testclass.cp.read(os.path.join(os.path.dirname(__file__), "test_ini.ini"))
    assert testclass.get_value("user", "production", None, False) == "John"
    assert testclass.get_value("user", "integration", None, False) == "Jack"
    assert testclass.get_value("secret", "integration", "abcd", False) == "efgh"
    assert testclass.get_value("secret", "production", "abcd", False) == "abcd"
    assert testclass.get_value("country", "global", None, False) == "France"


# Generated at 2022-06-11 15:42:24.549664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Common unit test for LookupModule()
    """

# Generated at 2022-06-11 15:42:36.219044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Verify that we can retrieve a value using a correct key and section
    terms = ['user']
    variables = None
    kwargs = {'file': 'users.ini', 'section': 'integration'}
    assert module.run(terms, variables, **kwargs) == ['bob']

    # Verify that we can retrieve a value using a correct key and section with a default value
    terms = ['user']
    variables = None
    kwargs = {'file': 'users.ini', 'section': 'production', 'default': 'john'}
    assert module.run(terms, variables, **kwargs) == ['john']

    # Verify that we can retrieve several values from a section using the regexp option
    terms = ['.*']
    variables = None

# Generated at 2022-06-11 15:42:43.619132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # Run test for a regexp
    terms = ["^[a-z]"]
    paramvals = {
        "section": 'section1',
        "file": "test.ini",
        "re": True, # It is a regexp
        "case_sensitive": False,
        "allow_no_value": False
    }
    lm.set_options(var_options=None, direct=paramvals)
    path = lm.find_file_in_search_path(None, 'files', paramvals['file'])

    config = StringIO()
    # Special case for java properties

# Generated at 2022-06-11 15:42:53.834675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    # class LookupModule: method run
    # 1)
    result = LookupModule().run(['data_in_the_ini_file'], {}, [], [], {})
    assert result == [''], result
    # 2)
    result = LookupModule().run(['data_in_the_ini_file', 'another_data'], {}, [], [], {})
    assert result == ['', ''], result
    # 3)
    result = LookupModule().run(['usr = super_user'], {}, [], [], {'dflt': 'toto'})
    assert result == ['super_user'], result
    # 4)
    result = LookupModule().run(['section = integration'], {}, [], [], {})
    assert result == [''], result
