

# Generated at 2022-06-11 15:33:34.085602
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    class MockConfigParser:

        def __init__(self):
            self.config = {}

        def items(self, section):
            return self.config[section].items()

        def get(self, section, key):
            value = self.config[section][key]
            if value == "":
                raise configparser.NoOptionError(key)
            if value == "exception":
                raise configparser.NoSectionError(section)
            return self.config[section][key]

    class MockLookupModule(LookupModule):

        def __init__(self):
            self.cp = MockConfigParser()

    # Create new instance of LookupModule
    lm = MockLookupModule()

    # Get value with no match
    lm.cp.config = {'section1': {'key1': 'value1'}}

# Generated at 2022-06-11 15:33:44.754056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialise LookupModule
    x = LookupModule()
    x.set_loader('/tmp/')
    x.set_basedir('/tmp/')
    x.get_options()
    # Initialise test parameters
    params = {'encoding': 'utf-8',
              'case_sensitive': False,
              'default': '',
              're': False,
              'type': 'ini',
              'file': 'ansible.ini',
              'section': 'global'}
    # Initialise ansible.ini file
    config = StringIO()
    config.write(u'# ansible.ini\n')
    config.write(u'[global]\n')
    config.write(u'user1=test1\n')
    config.write(u'user2=test2\n')

# Generated at 2022-06-11 15:33:54.066762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    import yaml

    yaml_file = os.path.dirname(__file__) + "/../../../../../tests/vars/lookup_ini.yml"
    vault_file = os.path.dirname(__file__) + "/../../../../../tests/vars/lookup_ini.yml.vault"
    ini_file = os.path.dirname(__file__) + "/../../../../../tests/vars/lookup_ini.ini"

    # CASE 1: Test with a regular file

# Generated at 2022-06-11 15:34:05.763106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # An object of class LookupModule must be created
    lm = LookupModule()

    # Create an instance of the class ConfigParser
    cp = configparser.ConfigParser()

    # Create a StringIO object. Later it is used to parse the string (ini file)
    config = StringIO()

    # Write in the file test_file.ini
    config.write(u"""
    [global]
    password = super_secret_passwd
    user = root
    """)
    config.seek(0, os.SEEK_SET)

    # Parse the file test_file.ini using readfp
    cp.readfp(config)

    assert (lm.get_value(key = 'user', section = 'global', dflt = '', is_regexp = False) == 'root')

# Generated at 2022-06-11 15:34:16.258440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    result = LookupModule().run(terms=["test"], variables={"role_path": "/test/test"})
    assert result == ["test"]

    result = LookupModule().run((["test\ntest"],), variables={"role_path": "/test/test"})
    assert result == ["test\ntest"]

    try:
        LookupModule().run((["test='test"],), variables={"role_path": "/test/test"})
    except AnsibleLookupError:
        pass

    result = LookupModule().run((["test=test"],), variables={"role_path": "/test/test"})
    assert result == ["test=test"]


# Generated at 2022-06-11 15:34:26.221274
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    tests = [
        {
            'key': 'key',
            'section': 'section1',
            'value': 'value1',
        },
        {
            'key': 'key',
            'section': 'section2',
            'value': 'value2',
        },
        {
            'key': 'key2',
            'section': 'section2',
            'value': 'value3',
        },
    ]

    data_string = '''
[section1]
key=value1

[section2]
key=value2
key2=value3
'''

    lm = LookupModule()
    config = StringIO(data_string)
    lm.cp.readfp(config)


# Generated at 2022-06-11 15:34:33.913632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import traceback
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.lookup.ini import LookupModule
    from ansible.parsing.utils.addresses import parse_host
    from ansible.plugins.cache.memory import LookupCache
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    result = "Failed"
    lookup_options = {
        'file': './test.ini',
        'section': 'global',
        'default': '',
        're': False,
        'encoding': 'utf-8',
        'terminated_by': '\n',
        'with_newline': True
    }
    inventory = InventoryManager

# Generated at 2022-06-11 15:34:42.746167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    # test on an ini file
    test_file = """
[section1]
key1=val1
key2=val2

[section2]
key1=val1
key2=val2
"""
    # mock the contents of the file
    lookup_obj._loader._mock_contents(test_file)
    # parameters list for test

# Generated at 2022-06-11 15:34:53.692514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if not os.environ.get('TEST_LOOKUP_PLUGIN_INI', False):
        return
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common._collections_compat import MutableMapping
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.ansible_module import AnsibleModule

    class MockModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = {}

# Generated at 2022-06-11 15:35:01.745975
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    cp = configparser.ConfigParser()
    cp.read_string(u'[integration]\nuser=toto\nuser.name=user\nuser.passwd=passwd\n')
    lookup = LookupModule()
    assert lookup.get_value('user', 'integration', None, False) == 'toto'
    assert lookup.get_value('user.name', 'integration', None, False) == 'user'
    assert lookup.get_value('user.passwd', 'integration', None, False) == 'passwd'
    assert lookup.get_value('user.notexist', 'integration', None, False) == None
    assert lookup.get_value('user([0-9])', 'integration', None, True) == ['user', 'passwd']

# Generated at 2022-06-11 15:35:19.780239
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Method run of class LookupModule return the value of the key in the ini file
    value = 'the value of the key'
    terms = ['key']
    path = 'file.ini'
    section = 'section'

    # Mock configparser and StringIO
    def get_value(key, section, dflt, is_regexp):
        """Mock method that return the value of the key in the ini file """
        return value
    cls = LookupModule()
    cls.get_value = get_value
    cls.cp = configparser.ConfigParser()
    cls.cp.readfp = lambda config: None
    config = StringIO()
    paramvals = {'file': path, 'section': section}
    paramvals['encoding'] = 'utf-8'

# Generated at 2022-06-11 15:35:27.536117
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    print("test_LookupModule_get_value")
    variables = {}
    term = 'test'
    section = 'section'
    dflt = 'default'
    is_regexp = False
    config = configparser.ConfigParser()
    config.add_section(section)
    config.set(section, term, term)

    lookup_module = LookupModule()
    lookup_module.cp = config
    assert 'test' == lookup_module.get_value(term, section, dflt, is_regexp)

# Generated at 2022-06-11 15:35:36.930127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with correct parameter key, section, type, file, re and default
    terms = ["k1"]
    var_options = dict()
    ret = LookupModule().run(terms, var_options, type="ini", file="ansible.ini", section='default', re=False, default='')
    assert ret == ['v1']
    # Testing with correct parameter key, section, type, file and re but no default
    ret = LookupModule().run(terms, var_options, type="ini", file="ansible.ini", section='default', re=False)
    assert ret == ['v1']
    # Testing with correct parameter key, section, type, file, re and default

# Generated at 2022-06-11 15:35:46.917609
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for ini type
    terms = ['global']
    LookupModule.run(terms, variables={}, **{'file': 'test/ansible.ini'}) == ['x']

    # Unit test for properties type
    terms = ['user.name']
    LookupModule.run(terms, variables={}, **{'file': 'test/user.properties', 'type': 'properties'}) == ['ansible']

    # Unit test for section
    terms = ['user']
    LookupModule.run(terms, variables={},
                     **{'file': 'test/ansible.ini', 'section': 'integration'}) == ['admin']

    terms = ['user']

# Generated at 2022-06-11 15:35:54.488515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ["notexist"]
    paramvals = {
        'file': 'test.ini',
        'section': 'section2',
        're': False,
        'encoding': 'ascii',
        'default': '',
        'case_sensitive': False,
        'allow_no_value': False
    }
    # Use side effect to run plugin
    test_instance = LookupModule()
    test_instance.run(terms, paramvals)
    # Assert - Check if test succeeds
    assert(True)

# Generated at 2022-06-11 15:36:04.459454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    file_path = './tests/fixtures/test.ini'
    term = 'username'

    # Parameters specified ?
    assert lookup_module.run(['username=fake_username'],{},file = file_path) == ['fake_username']
    assert lookup_module.run(['username fake_username'],{},file = file_path) == ['fake_username']
    assert lookup_module.run(['fake_username'],{},file = file_path) == ['fake_username']
    assert lookup_module.run(['username'],{},file=file_path, section='section2') == []

    # Retrieve file path
    path = lookup_module.find_file_in_search_path(None, 'files', file_path)
    config = StringIO()



# Generated at 2022-06-11 15:36:15.647368
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with default options
    terms = ['user1']
    variables = None
    options = {}
    lookup = LookupModule()

    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(u"[global]\nuser1=admin\nuser2=ansible\nuser3=yannig")
    config.seek(0, os.SEEK_SET)

    cp = configparser.ConfigParser()
    cp.readfp(config)

    lookup.cp = cp
    assert lookup.run(terms, variables, **options) == ['admin']

    # Test with section option
    terms = ['user3']
    variables = None
    options = {'section': 'global'}
    lookup = LookupModule()
    lookup.cp = cp

# Generated at 2022-06-11 15:36:26.100700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Arguments(dict):
        def __init__(self):
            self.update({
                'case_sensitive': False,
                'allow_no_value': False,
                '_raw_params': '',
                'var': 'ansible_var',
                '_terms': ['key', 'key1'],
                'default': '',
                'section': 'section1',
                'file': 'ansible/test/units/lookup/files/test.ini',
                'type': 'ini',
                're': False,
                'encoding': 'utf-8'
            })
            super(Arguments, self).__init__(**self)

    lm = LookupModule()

    expected = ['value_key', 'value_key1']
    terms = ['key', 'key1']

# Generated at 2022-06-11 15:36:37.551145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Info : unit test for method run of class LookupModule
    '''
    # test with ini file
    ini = '''
[log]
path=/var/log/ansible
level=warn
'''
    path = '/path/to/file/ansible.ini'
    with open(path, 'w') as w_file:
        w_file.write(ini)

    assert LookupModule().run(['level', 'path'], variables={
                              'ansible_config_file': path}) == ["warn", "/var/log/ansible"]

    # test with properties file
    prop = '''
user.name = root
user.group = root
'''
    path = '/path/to/file/user.properties'

# Generated at 2022-06-11 15:36:48.734791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test basic call
    var = lookup.run(terms=['user'], variables={}, file='ansible.ini', section='global')
    assert var[0] == 'toto'
    var = lookup.run(terms=['user'], variables={}, file='ansible.ini', section='global', encoding='latin-1')
    assert var[0] == 'toto'
    # Test with default
    var = lookup.run(terms=['user2'], variables={}, file='ansible.ini', section='global', default='tata')
    assert var[0] == 'tata'
    # Test with type properties
    var = lookup.run(terms=['user.name'], variables={}, file='user.properties', type='properties')

# Generated at 2022-06-11 15:37:10.308141
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    import configparser
    cp = configparser.ConfigParser()
    lookup = LookupModule()
    lookup.cp = cp
    # create config file
    config = StringIO()
    config.write(u'[section1]\n')
    config.write(u'a=b\n')
    config.write(u'ab=bc\n')
    config.write(u'ac=cd\n')
    config.seek(0, os.SEEK_SET)
    cp.readfp(config)
    section = "section1"
    # test a no regexp match
    key = "a"
    dflt = ""
    assert lookup.get_value(key, section, dflt, False) == 'b'
    # test a regexp match
    key = "a.*"
    dflt = ""
   

# Generated at 2022-06-11 15:37:20.217998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from collections import namedtuple
    Option = namedtuple('MyOption', ['value'])
    variable_manager = VariableManager()
    loader = DataLoader()
    lookup = LookupModule()
    lookup.set_options(variable_manager)
    def get_vault_password(*args, **kwargs):
        return 'vault_password'
    loader.set_vault_password(get_vault_password)
    path = loader.path_dwim_relative(None, "ini_test.ini")

# Generated at 2022-06-11 15:37:32.272913
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    myLookupModule = LookupModule()
    myLookupModule.cp = configparser.ConfigParser()
    myLookupModule.cp.readfp(StringIO(u'''
[section1]
fruit=apple
dog=poodle
#hello=
#=
[section2]
color=blue
color=red
color=yellow
'''))

    # Normal cases
    assert 'apple' == myLookupModule.get_value('fruit', 'section1', '', False)
    assert ['blue', 'red', 'yellow'] == myLookupModule.get_value('color', 'section2', '', False)

    # Regexp cases
    assert 'apple' == myLookupModule.get_value('fruit', 'section1', '', True)

# Generated at 2022-06-11 15:37:42.500462
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import ansible.plugins.lookup as lookup_plugins

    test_data = """
# foo.ini
[foo]
bar=baz
bah=bar
"""
    test_path = 'test/'

    terms_data = [
        ('bar', 'foo', '', False, "baz"),
        ('baz', 'foo', '', False, None),
        ('ba', 'foo', '', False, "bah"),
        ('ba', 'foo', '', True, ["bah", "bar"]),
    ]

    # Create a Mock class
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs


# Generated at 2022-06-11 15:37:48.929348
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    from io import StringIO
    from ansible.plugin.lookup import LookupModule

    l = LookupModule()
    l.cp = configparser.ConfigParser()

# Generated at 2022-06-11 15:37:57.480108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock, patch
    raw = "one = two"
    ret = "['two']"
    open_m = Mock(return_value = Mock(read = Mock(return_value = raw)))
    get_value_m = Mock(return_value = "two")
    run_m = LookupModule()

    with patch("ansible_collections.notstdlib.moveitallout.plugins.lookup.ini.open", open_m):
        with patch.object(LookupModule, "get_value", get_value_m):
            res = run_m.run(["one"], dict(file = "somefile"))
            assert str(res) == ret


# Generated at 2022-06-11 15:38:07.633581
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class options:
        default = "my default"
        re = True

    test_instance = LookupModule()
    config = configparser.RawConfigParser()
    config.readfp(StringIO(u'[global]\nkey=value'))
    test_instance.cp = config

    assert "value" == test_instance.get_value("key", "global", options.default, options.re)
    assert [] == test_instance.get_value("foo", "global", options.default, options.re)
    assert "my default" == test_instance.get_value("foo", "global", options.default, False)

    config = configparser.RawConfigParser()
    config.readfp(StringIO(u"[global]\nkey1=value1\nkey2=value2\nkey3=value3"))
   

# Generated at 2022-06-11 15:38:16.226875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from io import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.plugins.lookup import LookupModule

    lu = LookupModule()

    # Test with a ini file with a section and a key
    config = StringIO()
    config.write("[global]\n")
    config.write("user = root\n")
    config.seek(0, os.SEEK_SET)

    answer_ini = "root"
    user_ini = lu.get_value("user", "global", "", False)

    assert user_ini == answer_ini

    # Test with a ini file with a section, a key and a regexp
    config_regex = StringIO()
    config_regex.write("[global]\n")
    config

# Generated at 2022-06-11 15:38:26.592852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    keys = ['user', 'password']
    section = 'integration'
    filename = 'ansible.ini'

    data = {
        'file': filename,
        'default': '',
        're': False,
        'section': section,
        'type': 'ini',
        'case_sensitive': False
    }

    lookup = LookupModule()
    lookup.set_options(data)
    lookup.run(keys)

    assert lookup.cp is not None

    # Test if keys are found in the right section of the ini file
    assert lookup.get_value(keys[0], section, '', False) == 'ansible'
    assert lookup.get_value(keys[1], section, '', False) == 'ansible'

    # Test the default value

# Generated at 2022-06-11 15:38:37.450914
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test = """
    [section1]
    key1=value1
    key2=value2
    key3=value3
    key4=value4
    """
    config = StringIO()
    config.write(test)
    config.seek(0, os.SEEK_SET)

    cp = configparser.ConfigParser()
    cp.readfp(config)

    lookup = LookupModule()
    lookup.cp = cp

    assert lookup.get_value('key1', 'section1', None, False) == 'value1'
    assert lookup.get_value('key1', 'section1', 'default', False) == 'value1'
    assert lookup.get_value('key1', 'section1', 'default', True) == 'value1'

# Generated at 2022-06-11 15:39:11.464986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arrange
    terms = [
        "key1 user=toto section=titi",
        "key2",
        "user"
    ]

    variables = {
        "section": "tata"
    }

    kwargs = {
        "file": "users.ini",
        "section": "tutu"
    }

    lookup_module = LookupModule()
    lookup_module._deprecate_inline_kv = lambda : None

    config_parser = configparser.ConfigParser()
    config_parser.add_section("global")
    config_parser.set("global", "key1", "value1")
    config_parser.set("global", "key2", "value2")
    config_parser.set("global", "user", "value3")

# Generated at 2022-06-11 15:39:22.148003
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit tests
    # Different cases of run on LookupModule
    from ansible.plugins.lookup import LookupModule
    from io import StringIO

    # Empty list
    # Correct default value
    # Correct value
    # No section
    # No key
    # No file
    # Parameters

    # Empty list
    assert [] == LookupModule().run([], {})

    # Correct default value
    config = StringIO()
    config.write(u'[test]\n')
    config.seek(0, os.SEEK_SET)
    module = LookupModule()
    module.cp = configparser.ConfigParser()
    module.cp.readfp(config)
    assert ['default'] == module.run([''], {}, file='', default='default')

    # Correct value
    config = StringIO()
   

# Generated at 2022-06-11 15:39:30.669655
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    this = LookupModule()
    cp = configparser.ConfigParser()
    cp.add_section('section1')
    cp.set('section1', 'key1', 'value1')
    cp.set('section1', 'key2', 'value2')
    cp.set('section1', 'key3', 'value3')

    # Retrieve a single value
    var = this.get_value('key1', 'section1', 'default', False)
    assert var == 'value1'

    # Retrieve all values from a section using a regexp
    var = this.get_value('.*', 'section1', 'default', True)
    assert var == ['value1', 'value2', 'value3']


# Generated at 2022-06-11 15:39:41.630903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Import module for test lookup plugin
    from ansible.plugins.lookup.ini import LookupModule

    lookup_module = LookupModule()

    # Append section 'section1' in file test.ini
    with open('test.ini', "w+") as f:
        f.write(u'[section1]\n')
        f.write(u'key1 = value1\n')
        f.write(u'key2 = value2\n')

    # Retrieve the value of key 'key1' in section 'section1'
    key = 'key1'
    section = 'section1'
    default = 'default'
    is_regexp = False
    var = lookup_module.get_value(key, section, default, is_regexp)
    assert var == "value1"

    #

# Generated at 2022-06-11 15:39:53.028438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Create StringIO used to parse ini
    config = StringIO()
    config.write('[section1]\n')
    config.write('key1 = value1\n')
    config.write('key2 = value2\n')
    config.write('[section2]\n')
    config.write('key3 = value3\n')
    config.seek(0, os.SEEK_SET)
    # Define parameter used by run
    term = 'key1'
    variables = {'file': 'test.ini'}
    paramvals = {'type': 'ini',
                 'section': 'section1',
                 'default': '',
                 're': False,
                 'encoding': 'utf-8'}
    # Define expected value
    expected_

# Generated at 2022-06-11 15:39:56.548341
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    instance = LookupModule()
    instance.cp = configparser.ConfigParser()
    instance.cp.readfp(StringIO(u'[section]\nkey=value'))
    assert instance.get_value('key', 'section', None, False) == 'value'


# Generated at 2022-06-11 15:40:02.337892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create empty class with override method
    class LookupModuleEmpty(LookupModule):
        def __init__(self, cp):
            self.cp = cp
    # Create empty configparser
    cp = configparser.ConfigParser()
    # Create empty terms
    terms = []
    # Call LookupModuleEmpty run function
    lookup_module = LookupModuleEmpty(cp)
    result = lookup_module.run(terms)
    assert(result == [])


# Generated at 2022-06-11 15:40:12.266987
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    class MockConfig:
        def items(self, section):
            return {
                'key1': 'v1',
                'key2': 'v2',
                'key3': 'v3',
                'key4': 'v4',
                'key5': 'v5',
                'key6': 'v6'
            }

    class MockLookupModule(LookupModule):
        def __init__(self, cp):
            self.cp = cp

    l = MockLookupModule(MockConfig())

    # Test for case when 'is_regexp' is False
    a = l.get_value('key1', 'section', None, False)
    assert a == 'v1'

    # Test for case when 'is_regexp' is True

# Generated at 2022-06-11 15:40:21.676245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    lookup_module = LookupModule()
    # Test data
    test_file = 'test_file.ini'
    test_content = "[sectionA] \n keyA = valueA \n keyB = valueB \n keyC = valueC \n"
    test_find_file_in_search_path_result = '/path/to/' + test_file

    # mock ansible options
    class Options:
      def __init__(self):
        self.module_name = 'ini'
        self.file = test_file
        self.encoding = 'utf-8'
        self.case_sensitive = False
        self.allow_no_value = False


# Generated at 2022-06-11 15:40:30.837760
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Initialization
    cp = configparser.ConfigParser()
    cp.read_string(
        '''[section]
        key1=value1
        key2=value2
        ''')
    lookup_module = LookupModule()
    lookup_module.cp = cp

    # The section values are incorrect
    assert lookup_module.get_value('key2', 'unknown_section', None, False) == None

    # The key values are incorrect
    assert lookup_module.get_value('unknown_key', 'section', None, False) == None

    # The key values are correct but the key does not match the regexp
    assert lookup_module.get_value('key1', 'section', None, True) == None

    # The key values are correct and the key matches the regexp

# Generated at 2022-06-11 15:41:33.294087
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Initialize the class
    lookup = LookupModule()

    # Generate a configparser object and add a section 'name'
    cp = configparser.ConfigParser(allow_no_value=False)
    cp.add_section('name')
    cp.set('name', 'firstname', 'John')
    cp.set('name', 'surname', 'Doe')

    lookup.cp = cp

    # Get value with regexp
    regexp = '^(first|sur)'
    assert lookup.get_value(regexp, 'name', None, True) == ['John', 'Doe']
    assert lookup.get_value('firstname', 'name', None, False) == 'John'
    assert lookup.get_value('age', 'name', None, False) is None

# Generated at 2022-06-11 15:41:41.499395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six.moves import configparser
    l = LookupModule()

    # Check for a simple basic key
    myVar = l.run([
            'keyForTest'
        ], {
            'files': ['../test/files/test.ini'],
            'section': 'section1'
        })
    assert myVar == ['test1']

    # Check for several basic keys
    myVar = l.run([
            'keyForTest',
            'keyForTest2'
        ], {
            'files': ['../test/files/test.ini'],
            'section': 'section1'
        })
    assert myVar == ['test1', 'test2']

    # Check for default value

# Generated at 2022-06-11 15:41:52.423584
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_cases = [
        {'key': 'user', 'section': 'production',  'is_regexp': False, 'expected_value': 'bob'},
        {'key': 'u.*', 'section': 'production',   'is_regexp': True,  'expected_value': ['bob']},
        {'key': 'user', 'section': 'integration', 'is_regexp': False, 'expected_value': 'alice'},
        {'key': 'u.*', 'section': 'integration',  'is_regexp': True,  'expected_value': ['alice']},
        {'key': 'group', 'section': 'integration', 'is_regexp': False, 'expected_value': None},
    ]


# Generated at 2022-06-11 15:42:03.113904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TestLookupModule
    class TestLookupModule(LookupModule):
        def __init__(self, cp):
            self.cp = cp
        def find_file_in_search_path(self, variables, search_paths, file):
            return "fake_path"

    term = "user"
    section = "integration"
    default = ""
    is_regexp = False
    # Case 1 : configparser retrieve the value of a valid key
    cp = configparser.ConfigParser({'user': 'root'})
    cp.readfp(StringIO('[integration]\nuser=root'))
    test = TestLookupModule(cp)
    assert test.get_value(term, section, default, is_regexp) == "root"
    # Case 2 : configparser retrieve the default value of

# Generated at 2022-06-11 15:42:13.316537
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    c = configparser.ConfigParser()
    c.read("data/ini_example.ini")

    # Normal test
    module_test = LookupModule()
    module_test.cp = c
    assert module_test.get_value("user", "integration", None, False) == "toto"
    assert module_test.get_value("user", "production", None, False) == "tata"

    # Test with default value
    assert module_test.get_value("new_user", "production", "titi", False) == "titi"

    # Test with regexp
    assert module_test.get_value("u.*", "integration", None, True) == ["toto", "tata"]

# Generated at 2022-06-11 15:42:22.986124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAwareParameter

    vault_secret = VaultSecret('vault_secret')
    vault_secret.load(['secret_value'])

    lookup_module = LookupModule()
    lookup_module.set_options({})

    key = "key"
    section = "section"
    default = "default"
    is_regexp = "is_regexp"

    class configparser_mock:
        class NoOptionError(Exception):
            pass

        class NoSectionError(Exception):
            pass

        def __init__(self, allow_no_value=False):
            self.allow_no_value = allow_no_value
            self._config = {'section': { 'key': 'value'}}

# Generated at 2022-06-11 15:42:34.888133
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.lookup.plugins.ini import LookupModule
    lookup = LookupModule()
    config = """
[MySection]
mykey1 = value1
mykey2 = value2
mykey3 = value3
mykey4 = value4
mykey5 = value5
    """

    lookup.cp = configparser.ConfigParser(allow_no_value=True)
    if lookup.cp.optionxform('MyKey5'):
        if config.upper().startswith('[MYSECTION]'):
            config = '[MySection]' + config[10:]
        config = config.replace('mykey5', 'MyKey5').replace('value5', 'Value5')

    lookup.cp.readfp(StringIO(config))

    # Check that the key is found and returned by get_value
    var = lookup.get

# Generated at 2022-06-11 15:42:39.541475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # create a configuration file for testing
    config = StringIO()
    config.write(u'[java_properties]\n')
    config.write(u'var=value\n')
    config.seek(0, os.SEEK_SET)

    # create another configuration file for testing
    config2 = StringIO()
    config2.write(u'[section1]\n')
    config2.write(u'var=value\n')
    config2.seek(0, os.SEEK_SET)

    # Set of parameters to be test

# Generated at 2022-06-11 15:42:47.832966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from collections import defaultdict
    from ansible.module_utils.common._collections_compat import MutableSequence
    paramvals = defaultdict(lambda: 'ansible.ini', file='ansible.ini', section='global', re=False, encoding='utf-8', type='ini', default='', case_sensitive=False, allow_no_value=False)
    l = LookupModule()
    l.set_options(var_options=None, direct=paramvals)
    k = AnsibleUnsafeText('a=b c=d')
    params = _parse_params(k, paramvals)
    var = l.get_

# Generated at 2022-06-11 15:42:57.545802
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    ini_file = """
    [section]
    aaa=this-is-aaa
    aab=this-is-aab
    abc=this-is-abc
    [other_section]
    foo=bar
    baz=qux
    """

    lm = LookupModule()

    from io import StringIO
    ini_f = StringIO()
    ini_f.write(ini_file)
    ini_f.seek(0, os.SEEK_SET)
    lm.cp = configparser.ConfigParser()
    lm.cp.readfp(ini_f)

    # Test without regexp
    assert lm.get_value("aaa", "section", "", "") == "this-is-aaa"