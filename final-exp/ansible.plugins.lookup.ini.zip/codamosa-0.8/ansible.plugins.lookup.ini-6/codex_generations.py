

# Generated at 2022-06-11 15:33:36.552657
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    configfile = "[global]\nkey1=value1\nkey2=value2\nkey3=value3\n"
    config = StringIO()
    config.write(configfile)
    config.seek(0, os.SEEK_SET)
    lookup_module.cp.readfp(config)

    # Test with section section1
    results = lookup_module.get_value("key1", "section1", "default", False)
    assert results == "default"

    # Test with section global
    results = lookup_module.get_value("key1", "global", "default", False)
    assert results == "value1"

    # Test with section global and regexp
    results = lookup_module.get_value("key2", "global", "default", True)
   

# Generated at 2022-06-11 15:33:46.002669
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_module = LookupModule()
    config = configparser.ConfigParser()
    config.readfp(StringIO(u'[section1]\nkey1=value1\nkey2=value2\nkey3=value3\n[section2]\nkey1=value1\nkey2=value2\nkey3=value3\n[section3]\nkey1=value1\nkey2=value2\nkey3=value3'))
    lookup_module.cp = config
    assert lookup_module.get_value('key1', 'section1', 'default', False) == 'value1'
    assert lookup_module.get_value('key2', 'section1', 'default', False) == 'value2'

# Generated at 2022-06-11 15:33:54.612354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.common._collections_compat import MutableMapping
    import json
    import os

    test_filename = "ansible.ini"
    json_file = 'ansible.json'

    lookup_manager = LookupModule()

    # Create INI content
    ini_string = """[global]
user=root
password=secret

[integration]
user=bobt
password=tacob

[production]
user=foob
password=baarf
"""
    # Create JSON content

# Generated at 2022-06-11 15:33:57.009600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Unit test for method run of class LookupModule
  lookup = LookupModule()
  lookup.run([], {})

# Generated at 2022-06-11 15:34:08.200795
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import contextlib

    lm = LookupModule()
    testcase = {
        'terms': [
            'user',
            'user=tom',
            'user=tom file=users.ini section=integration',
            'user=tom file=users.ini section=integration type=ini'
            'user=tom file=user.properties section=java_properties type=properties',
            'user=tom file=user.properties section=java_properties type=properties default=tomcat'
        ],
        'expected_return': [
            'tom',
            'tom',
            'tom',
            'tom',
            'tom',
            'tomcat',
        ]
    }

    cp = configparser.ConfigParser()
    test_config = StringIO()

# Generated at 2022-06-11 15:34:17.771764
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:34:28.314246
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # Get instance of class LookupModule
    obj = LookupModule()

    # Create StringIO later used to parse ini
    config = StringIO()
    config.write(u'[global]\n')
    config.write(u'key_to_find=value_to_find\n')
    config.write(u'key_to_find_bis=value_to_find_bis\n')
    config.seek(0, os.SEEK_SET)

    obj.cp = configparser.ConfigParser()
    obj.cp.readfp(config)

    # Test with a regexp
    var = obj.get_value('key_to_find', 'global', 'default_value', True)
    assert var == [u'value_to_find', u'value_to_find_bis']

    # Test with

# Generated at 2022-06-11 15:34:38.828052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six.moves import configparser
    lookup_base = LookupBase()

    class TestClass(object):
        ''' Test class '''
        def __init__(self, file_path, section, key, default_key, is_regexp):
            self.cp = configparser.ConfigParser()
            self.path = lookup_base.find_file_in_search_path(variables={}, basedir=None, path='/tmp/tests/', file_name=file_path)
            self.cp.read(self.path)
            self.section = section
            self.key = key
            self.default_key = default_key

# Generated at 2022-06-11 15:34:46.523204
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Load class LookupModule
    lookup = LookupModule()

    # Create term
    term = "db_user=user section=integration file=users.ini"
    # Create option and set value
    kwargs = {}
    kwargs['type'] = 'ini'
    kwargs['section'] = 'integration'
    kwargs['default'] = ''
    kwargs['re'] = False
    kwargs['file'] = 'users.ini'

    # Call method run
    result = lookup.run(term, **kwargs)

    assert result == ['user']
    assert len(result) == 1


# Generated at 2022-06-11 15:34:56.867480
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:35:07.023704
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from ansible.module_utils.six.moves import StringIO
    import json
    import test.fixtures.lookup_ini_plugin_section as section
    import test.fixtures.lookup_ini_plugin_regexp as regexp
    import test.fixtures.lookup_ini_plugin_no_value as no_value

    # Unit test without regexp
    # Init
    path = 'test/fixtures/lookup_ini_plugin_section.ini'
    file_content = StringIO(open(path, 'r').read())
    section_name = 'mysection'
    descriptor = 'key1'
    not_found_value = 'not a value'

    # Run
    cp = configparser.ConfigParser()
    cp.readfp(file_content)
    lu = LookupModule()
   

# Generated at 2022-06-11 15:35:18.955363
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a new LookupModule class
    lookup = LookupModule()

    # Create the file
    f = open("section.ini", "w")
    f.write("[section]\n")
    f.write("user=yannig\n")
    f.close()

    # Set the terms and options
    terms = ["user"]
    variables =  None

    options = {
        'file': 'section.ini',
        'section': 'section',
        'default': '',
        're': False,
        'encoding': 'utf-8',
        'case_sensitive': False,
        'allow_no_value': False
    }

    # Run the lookup
    lookup.run(terms, variables, **options)
    # Test that the result is equal to the expected result

# Generated at 2022-06-11 15:35:26.214483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock configparser
    class MockConfigParser:

        def __init__(self, allow_no_value=None):
            self.items = [['section1_key1', 'section1_value1'],
                          ['section1_key2', 'section1_value2'],
                          ['section2_key1', 'section2_value1'],
                          ['section2_key2', 'section2_value1']]

        def readfp(self, config):
            return

    # Mock class LookupBase
    class MockLookupBase:

        def get_options(self):
            paramvals = {'type': "ini",
                         'file': "test.ini",
                         'section': "section1",
                         're': False,
                         'default': None,
                         'case_sensitive': True}

           

# Generated at 2022-06-11 15:35:36.250884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO

    # Test 'default' value
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    config = StringIO()
    config.write("[test]\nkey1=val1")
    config.seek(0, os.SEEK_SET)
    lm.cp.readfp(config)
    term = "key2"
    variables = {}
    paramvals = {'file':'test.ini', 'section':'test', 'type': 'ini', 're': False, 'default': 'ok', 'encoding':'utf-8', 'case_sensitive': False}
    var = lm.get_value(term, paramvals['section'], paramvals['default'], paramvals['re'])

# Generated at 2022-06-11 15:35:46.512777
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.ini import LookupModule
    from ansible.module_utils import basic

    class FakeVariableManager(object):

        def __init__(self):
            self.vars = dict()

        def __getitem__(self, key):
            return self.vars[key]

        def __setitem__(self, key, value):
            self.vars[key] = value

        def get_vars(self, loader, path, entities):
            return dict(self.vars)

        def set_vars(self, var_list):
            for key, value in var_list.items():
                self.vars[key] = value


# Generated at 2022-06-11 15:35:56.649149
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    test_cp = configparser.RawConfigParser()
    test_cp.readfp(StringIO(u'[section1]\n'
                            u'key1=value1\n'
                            u'key2=value2\n'
                            u'[section2]\n'
                            u'key1=value1\n'
                            u'key2=value2\n'))

    lm = LookupModule()
    lm.cp = test_cp

    # Test finding key in a specific section
    assert lm.get_value('key1', 'section1', None, False) == 'value1'
    assert lm.get_value('key2', 'section1', None, False) == 'value2'

    # Test finding key in a all sections

# Generated at 2022-06-11 15:36:06.461189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for LookupModule class run method
    """

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    class VaultSecretMock(VaultSecret):
        def __init__(self, cli):
            self.contents = u''
            self.cli = cli

        @property
        def password(self):
            return to_bytes(self.contents)

        @password.setter
        def password(self, value):
            self.contents = value


# Generated at 2022-06-11 15:36:18.541178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test when file is not an ini (properties file)
    lookup_module = LookupModule()
    lookup_module.set_options({'file': 'user.properties', 'type': 'properties'})
    assert lookup_module.run(['user.name']) == ['yperre']

    # Test when file is not an ini (ini file)
    lookup_module = LookupModule()
    lookup_module.set_options({'file': 'ansible.ini'})
    lookup_module.set_loader(LookupModule._loaders[0])
    assert lookup_module.run(['user']) == ['yperre']

    # Test when file is known_hosts
    lookup_module = LookupModule()
    lookup_module.set_options({'file': 'known_hosts'})
    lookup_module

# Generated at 2022-06-11 15:36:27.478431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    my_lookup.set_options({'file': 'users.ini',
                           'section': 'integration',
                           'default': 'johndoe',
                           're': False})
    assert my_lookup.run([]) == []
    assert my_lookup.run(["user"]) == ["johndoe"]
    assert my_lookup.run(["user="]) == ["johndoe"]
    assert my_lookup.run(["user=bob"]) == ["bob"]

    # test the regex
    my_lookup.set_options({'re': True})
    assert my_lookup.run(["user"]) == ["johndoe"]


# Generated at 2022-06-11 15:36:37.930217
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    l = LookupModule()
    l.cp = configparser.ConfigParser()
    l.cp.add_section('test')
    l.cp.set('test', 'foo', '')
    l.cp.set('test', 'bar', 'foobar')
    l.cp.set('test', 'baz', 'foobaz')
    assert l.get_value('foo', 'test', '', False) is None
    assert l.get_value('bar', 'test', '', False) == 'foobar'
    assert l.get_value('baz', 'test', '', False) == 'foobaz'
    assert l.get_value('f', 'test', '', True) == ['foo', 'foobaz']

# Generated at 2022-06-11 15:36:52.413786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        raise configparser.DuplicateOptionError()
    except configparser.DuplicateOptionError as doe:
        error = doe
    mod = LookupModule()
    mod.cp = configparser.ConfigParser()
    mod.cp.readfp(StringIO(u'[section]\na=1\na=2\n'))
    mod.get_value = lambda k, s, d, r: mod.cp.items(s)
    assert mod.run([u'', u'key=value'], variables={}) == [u'', u'value']
    assert mod.run([u'a']) == [u'1']
    assert mod.run([u'a', u'allow_no_value=True']) == [u'', u'1']

# Generated at 2022-06-11 15:37:03.355199
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create tmp file used as ini file
    f = open('testini.ini', 'w')
    f.write('[DEFAULT]\n')
    f.write('first_name=John\n')
    f.write('last_name=Doe\n')
    f.close()

    # Initialize a LookupModule
    lm = LookupModule()

    # Mock file lookup for LookupModule
    def _find_file_in_search_path(self, variables, paths, file=None):
        return 'testini.ini'
    lm.find_file_in_search_path = _find_file_in_search_path.__get__(lm, LookupModule)

    # Execute run method of LookupModule

# Generated at 2022-06-11 15:37:05.779823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'type': 'ini', 'file': 'users.ini'})
    l.run(['user', 'password'])

# Generated at 2022-06-11 15:37:12.862176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Options:
        connection = 'local'
        module_path = None
        forks = 100
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        verbosity = None

    variable_manager = VariableManager()
    loader = DataLoader()

    # Ini file

# Generated at 2022-06-11 15:37:21.392205
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class ConfigParser(object):
        """We pretend to be a ConfigParser"""
        def __init__(self, *args, **kwargs):
            self.values = {
                'section1': {
                    'key1': 'value1',
                    'key2': 'value2',
                    'key3': 'value3',
                    'key4': 'value4',
                    'key5': 'value5',
                },
            }

        def get(self, section, key):
            return self.values[section][key]

        def items(self, section):
            return self.values[section].items()


# Generated at 2022-06-11 15:37:33.335248
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.ini import LookupModule

    class VarManager:
        def __init__(self):
            self.vars = {}

    config_file_path = "/tmp/config.ini"
    config = """[section1]
key = value
    """
    with open(config_file_path, 'w') as cfg:
        cfg.write(config)


# Generated at 2022-06-11 15:37:43.208242
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Create a mock ConfigParser
    cp = configparser.ConfigParser()
    # mock sections, keys and values
    sections = {'global': ('global_val', 'global_val'), 'section1': ('value', 'section1_value')}
    cp.sections = sections
    # mock items
    items = [('key', 'value'), ('key', 'section1_value')]
    cp.items = sections.__getitem__
    # Create a LookupModule object
    lookup_module = LookupModule()
    lookup_module.cp = cp
    # Create test cases
    test_cases = [('key', 'section1', None, None, 'section1_value'), ('global_val', 'global', None, None, 'global_val')]

# Generated at 2022-06-11 15:37:54.028556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()

    variables = VariableManager()
    variables.extra_vars = {}

    terms = []
    terms += ['user', 'group', 'group_stg']
    terms += ['user=foo', 'section=staging']
    terms += ['user = foo', 'section = staging']
    terms += ['user=']
    terms += ['section=stg', 'section=staging']
    terms += ['section=stg', 'section=staging', 'group=sysadmins']

    # ini
    mylookup = LookupModule()
    mylookup.set_loader(loader)

# Generated at 2022-06-11 15:37:59.532595
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_terms = [
        "user",
        "user=passphrase default=foo section=integration",
        "user=passphrase default=foo section=integration file=users.ini",
        "section section=integration file=users.ini"
    ]

    module = LookupModule()
    for term in test_terms:
        module.run([term])

# Generated at 2022-06-11 15:38:09.396977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup LookupModule
    # test_LookupModule_run.py::test_LookupModule_run[ini_list1]
    lm = LookupModule()
    lm.set_options({'type':'ini'})
    # test_LookupModule_run.py::test_LookupModule_run[ini_list2]
    lm.set_options({'type':'properties'})
    # test_LookupModule_run.py::test_LookupModule_run[ini_list3]
    lm.set_options({'type':'ini', 're':True})
    # test_LookupModule_run.py::test_LookupModule_run[ini_list4]
    lm.set_options({'type':'ini', 'case_sensitive':True})
    # test_Look

# Generated at 2022-06-11 15:38:32.474439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=too-many-locals
    test_result = []
    # test file is build by test_lookup_plugins test_lookup_ini_plugin test
    test_file = os.path.join(os.path.dirname(__file__), 'unit', 'files', 'test_file.ini')
    # test user.properties file is build by test_lookup_plugins for test_lookup_ini_plugin
    test_user_file = os.path.join(os.path.dirname(__file__), 'unit', 'files', 'user.properties')
    # test user.properties file is build by test_lookup_plugins for test_lookup_ini_plugin

# Generated at 2022-06-11 15:38:40.833416
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    lookup.cp.readfp(StringIO("""[section_test_1]
key1=value1
key2=value2
key3_re=value3
key4_re=value4
"""))

    # test regexp
    assert lookup.get_value("key1", "section_test_1", None, True) == ["value1"]
    assert lookup.get_value("key2", "section_test_1", None, True) == ["value2"]
    assert lookup.get_value("key3_re", "section_test_1", None, True) == ["value3"]
    assert lookup.get_value("key4_re", "section_test_1", None, True) == ["value4"]

    # test not regexp

# Generated at 2022-06-11 15:38:48.491863
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()

    # Test with a key that exist
    expected = "yannig"
    actual = lookup.get_value('user', 'test', '', False)

    assert expected == actual

    # Test with a key that does not exist
    expected = "user"
    actual = lookup.get_value('user', 'test', 'user', False)

    assert expected == actual

    # Test with a regexp
    expected = ["yannig", "Lemon"]
    actual = lookup.get_value('user.*', 'test', '', True)
    assert expected == actual

# Generated at 2022-06-11 15:38:56.832136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    lookup = LookupModule()

# Generated at 2022-06-11 15:39:07.482935
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Init class
    ini = LookupModule(None)
    string = u"""
[section1]
key1 = value1
key2 = value2

[section2]
key1 = value1
key2 = value2
key3 = value3
        """
    ini.cp = configparser.ConfigParser()
    ini.cp.readfp(StringIO(string))
    # Test regexp
    assert ini.get_value(u'.*', u'section1', None, True) == ini.get_value(u'.*', u'section2', None, True)
    assert ini.get_value(u'key1', u'section2', None, False) == ini.get_value(u'key2', u'section2', None, False)

# Generated at 2022-06-11 15:39:17.488431
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.display import Display
    from ansible.plugins.lookup.ini import LookupModule
    from ansible.module_utils.common._collections_compat import MutableSequence

    display = Display()
    terms = ['key1', 'key2', 'key3', 'key4']
    dflt = "default"
    section = "simple"

    testc1 = StringIO('[simple]\nkey1=value1\nkey2=value2\nkey3=value3')
    testc2 = StringIO('[simple]\nkey1=value1\nkey2=value2\nkey3=value3\n#this is a comment\n   #this is a comment too')
    testc3 = StringIO('[simple]\nkey4=value4')

# Generated at 2022-06-11 15:39:28.387116
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Test with regexp
    lm = LookupModule()
    lm.cp = configparser.ConfigParser()
    lm.cp.add_section('integration')
    lm.cp.set('integration', 'user', 'yperre')
    lm.cp.set('integration', 'pass', 'yperre')
    lm.cp.set('integration', 'port', '8080')
    lm.cp.set('integration', 'host', 'localhost')
    assert lm.get_value(".*", 'integration', None, True) == ['yperre', 'yperre', '8080', 'localhost']
    assert lm.get_value("user", 'integration', None, True) == ['yperre']

# Generated at 2022-06-11 15:39:40.194926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    # Test case 1: no key in the INI file
    paramvals = {
        'type': 'ini',
        'file': 'examples/ini/no-key.ini',
        'section': 'DEFAULT',
        'default': '',
        're': False
    }
    ret = l.run([ 'key' ], paramvals=paramvals)
    assert ret == [ 'default' ]
    # Test case 2: key exists in the INI file
    paramvals = {
        'type': 'ini',
        'file': 'examples/ini/default.ini',
        'section': 'DEFAULT',
        'default': '',
        're': False
    }
    ret = l.run([ 'key' ], paramvals=paramvals)

# Generated at 2022-06-11 15:39:50.621537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    configparser.ConfigParser.get = mock_get
    configparser.ConfigParser.items = mock_items
    configparser.ConfigParser.readfp = mock_readfp
    lookup_module.find_file_in_search_path = mock_find_file_in_search_path
    lookup_module._loader._get_file_contents = mock_get_file_contents
    config_content = (
        [u'[section1]', u'name=machine1', u'ip=192.168.0.10', u'[section2]', u'name=machine2', u'ip=192.168.0.11', u'[section3]', u'key=value'])

# Generated at 2022-06-11 15:40:01.420319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.utils.path import unfrackpath
    config = configparser.ConfigParser()

    # create ini file in data dir
    ini_path = unfrackpath("/lookup_plugins/data/ini_test.ini")
    config.add_section('ini_test')
    config.set('ini_test', 'key1', 'value1')
    config.set('ini_test', 'key2', 'value2')
    config.set('ini_test', 'key3', 'value3')

    # create properties file in data dir
    properties_path = unfrackpath("/lookup_plugins/data/ini_test.properties")
    config.add_section('java_properties')

# Generated at 2022-06-11 15:40:35.266959
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check with a simple key
    lookup_instance = LookupModule()
    lookup_instance.cp = configparser.RawConfigParser()
    lookup_instance.cp.add_section('section1')
    lookup_instance.cp.set('section1', 'test', 'blah')

    assert lookup_instance.get_value('test', 'section1', '', False) == 'blah'
    assert lookup_instance.get_value('test', 'section2', '', False) == ''

    # Check with a regexp
    lookup_instance = LookupModule()
    lookup_instance.cp = configparser.RawConfigParser()
    lookup_instance.cp.add_section('section1')
    lookup_instance.cp.set('section1', 'test', 'blah')

# Generated at 2022-06-11 15:40:45.510662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a lookup to simulate a lookup for a project
    lookup = LookupModule()
    variable = 'my_project'

    # Create a type of variable project
    variables = dict()
    variables['project'] = variable

    # Create a term to simulate a lookup for a variable project
    terms = ['project']

    # Create a file ini to simulate a file to read
    content = dict()
    content['default'] = 'test'
    content['type'] = 'ini'
    # Create a paramvals to simulate a query in the file
    paramvals = dict()
    paramvals['section'] = 'section1'
    paramvals['default'] = 'test'
    paramvals['type'] = 'ini'
    paramvals['file'] = 'test.ini'
    paramvals['re'] = False

    # Create a test file to read

# Generated at 2022-06-11 15:40:56.391918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'user = root',
        'user',
        'bar = foo = baz',
    ]

    paramvals = {
        'section': 'global',
        're': False,
        'encoding': 'utf-8',
        'default': '',
        'case_sensitive': False,
        'allow_no_value': False,
        'allow_none': False,
        'type': 'ini',
        'file': 'ansible.ini',
    }

    # Create StringIO later used to parse INI
    config = StringIO()
    contents = """
[global]
user = test
bar = baz
"""
    config.write(contents)
    config.seek(0, os.SEEK_SET)


# Generated at 2022-06-11 15:41:03.868992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock class ConfigParses
    class ConfigParser:
        def __init__(self):
            self.items_return_value = {}
            self.get_return_value = None
        def items(self, section):
            return self.items_return_value
        def get(self, section, key):
            return self.get_return_value
    # Mock class LookupModule
    class LookupModule:
        def __init__(self):
            self.ConfigParser = ConfigParser
            self.cp = ConfigParser()
            self.get_options = lambda: {}

    lm = LookupModule()

    # Test regexp
    lm.cp.items_return_value = {'box1': 'blue',
                                'box2': 'green'}

# Generated at 2022-06-11 15:41:10.320165
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.ini import LookupModule
    from ansible.module_utils.six.moves import configparser

    # Create a config parser object
    cp = configparser.ConfigParser()
    cp.readfp(StringIO("[global]\nname=Jacques"))

    # Create a lookup module object
    lookup_module = LookupModule()
    lookup_module.cp = cp

    # Run unit test
    assert lookup_module.run([('name', 'section', '', False)]) == ['Jacques']

# Generated at 2022-06-11 15:41:17.180229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test class LookupModule
    """

    # TODO:
    # - test with several keys in the ini file (OK)
    # - test with default and with section exist with default
    # - no default with default and without default
    # - test with regex and without
    # - test with section and without section
    # - type can be ini or properties
    pass



# Generated at 2022-06-11 15:41:26.964591
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():

    # default test case
    dummy_cp = configparser.ConfigParser()
    dummy_cp.add_section('test')
    dummy_cp.set('test', 'key1', 'value1')
    dummy_cp.set('test', 'key2', 'value2')

    lookup_obj = LookupModule()
    lookup_obj.cp = dummy_cp

    assert lookup_obj.get_value('key1', 'test', None, False) == 'value1'
    assert lookup_obj.get_value('.*', 'test', None, True) == ['value1', 'value2']
    assert lookup_obj.get_value('key3', 'test', 'default value', False) == 'default value'

# Generated at 2022-06-11 15:41:36.390071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import tempfile
    '''Method run should return a list of values'''

    class MyTest(unittest.TestCase):
        def setUp(self):
            self.contents = u'''
            [global]
            host=localhost
            port=3306

            [integration]
            user=root
            pass=toor
            '''

        def test_run(self):
            '''Method run should return a list of values'''
            with tempfile.NamedTemporaryFile() as temp:
                temp.write(self.contents.encode('utf-8'))
                temp.flush()
                lookup = LookupModule()
                lookup.cp = configparser.ConfigParser()
                lookup.cp.readfp(open(temp.name, "r"))
                self.assertE

# Generated at 2022-06-11 15:41:48.064645
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lm = LookupModule()
    cfg = configparser.ConfigParser()
    cfg.add_section('global')
    cfg.set('global', 'name', 'value')
    cfg.set('global', 'name2', 'value2')
    cfg.set('global', 'name3', 'value3')
    lm.cp = cfg
    assert(lm.get_value('name', 'global', 'default', False) == 'value')
    assert(lm.get_value('name2', 'global', 'default', False) == 'value2')
    assert(lm.get_value('name3', 'global', 'default', False) == 'value3')
    assert(lm.get_value('name4', 'global', 'default', False) == 'default')

# Generated at 2022-06-11 15:41:54.981331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define a class containing all the properties and methods to mock in LookupModule
    class LookupModuleMock():
        def __init__(self):
            self.cp = None
            self.cp_allow_no_value = True
            self.get_value_value = None

        def set_options(self, var_options=None, direct=None):
            pass

        def get_options(self):
            return {'encoding': u'utf-8', 'section': u'global', 'file': u'ansible.ini', 're': False, 'default': u'', 'case_sensitive': False, 'allow_no_value': False}

        def find_file_in_search_path(self, variables, pathname, filename):
            return u'ansible.ini'


# Generated at 2022-06-11 15:42:49.904272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    l = LookupModule()
    l.cp = configparser.ConfigParser(allow_no_value=True)

    config = StringIO()
    config.write(
        b'[global]\n'
        b'user = ansible\n'
        
        b'[integration]\n'
        b'user = integration\n'
        
        b'[production]\n'
        b'user = production \n'
    )
    config.seek(0, os.SEEK_SET)
    l.cp.readfp(config)
    assert l.get_value('user', 'global', None, False) == 'ansible'
    assert l.get_value('user', 'integration', None, False) == 'integration'

# Generated at 2022-06-11 15:42:59.306279
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()

    # Test get_value when key exists
    lookup.cp.add_section('section1')
    lookup.cp.set('section1', 'key1', 'value1')
    assert lookup.get_value('key1', 'section1', 'not found', False) == 'value1'
    assert lookup.get_value('key1', 'section1', 'not found', True) == '[\'value1\']'

    # Test get_value when key doesn't exist but there is a default value
    assert lookup.get_value('key2', 'section1', 'not found', False) == 'not found'
    assert lookup.get_value('key2', 'section1', 'not found', True) == 'not found'

    # Test get_value when key

# Generated at 2022-06-11 15:43:00.409061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([]) == []

# Generated at 2022-06-11 15:43:08.677018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    # Necessary to initialize LookupModule
    import ansible
    ansible.__version__ = '2.12'

    # Arrange
    cls = LookupModule()
    cls.find_file_in_search_path = lambda a, b, c: a # Fake the method to return the arguments
    cls._loader = cls._loader_class()
    cls.set_options(var_options={}, direct={}) # Fake set_options to avoid error with encoding
    cls.get_options = lambda: {}

    ## Assert exception
    # Bad options
    try:
        cls.run(['key=value'])
        assert False
    except AnsibleOptionsError:
        pass

    # Beware, try .. except for a single test case is not very good but it allow to keep all test

# Generated at 2022-06-11 15:43:14.946696
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup_obj = LookupModule()
    # create a configparser object
    # Load file in it
    config = configparser.ConfigParser()
    config.readfp(StringIO('''
    [section]
    one = 1
    two = 2
    three = 3
    '''))
    lookup_obj.cp = config
    assert lookup_obj.get_value('one', 'section', '', False) == '1'
    # Try with a regexp
    assert lookup_obj.get_value('.*', 'section', '', True) == ['1', '2', '3']
    # Key is not in section
    assert lookup_obj.get_value('four', 'section', '', False) == ''
    # Section does not exist

# Generated at 2022-06-11 15:43:24.368511
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Uncomment this to test with a real file
    #import os
    #from ansible.parsing.dataloader import DataLoader
    #loader = DataLoader()
    #current_dir = os.path.dirname(os.path.realpath(__file__))
    #lookup_file = os.path.join(current_dir, 'lookup_fixtures/lookup_ini_config.ini')

    # Uncomment this to test with a StringIO
    fixture = StringIO("""
[integration]
user = foo
domain = bar

[production]
user = foo2
domain = bar2
""")

    fixture2 = StringIO("""
[java_properties]
test = true
test = false

[test]
test2 = false
""")
