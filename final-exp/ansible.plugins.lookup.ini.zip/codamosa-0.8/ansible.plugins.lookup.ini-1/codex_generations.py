

# Generated at 2022-06-11 15:33:35.018478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.constants import DEFAULT_MODULE_PATH
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    import os
    import pytest

    ini_file = os.path.dirname(os.path.dirname(os.path.realpath(__file__))) + '/lookup_plugins/ini/test.ini'
    key = 'key1'
    section = 'section1'
    dflt = 'default'
    is_regexp = False
    ret

# Generated at 2022-06-11 15:33:41.911308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = [
        "user=jdoe section=integration file=users.ini",
        "user=jane section=integration file=users.ini",
        "user=jane section=production file=users.ini",
        "user=jane section=production file=users.ini",
    ]
    result = module.run(terms)
    assert result == ['jdoe', 'jane', 'jane', 'jane'], result


# Generated at 2022-06-11 15:33:51.719957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import io
    import logging

    import pytest

    # Set up logger
    logging.basicConfig(level=logging.ERROR)
    logger = logging.getLogger('ansible')

    # Create mock file
    config_file = io.StringIO('''
[section1]
key1 = value11
key2 = value12
key3 = value13
key4 =

[section2]
key1 = value21
key2 = value22
key3 = value23
key4 =
''')

    # Create mock lookup
    lkl = LookupModule()
    lkl.cp = configparser.ConfigParser()
    lkl.cp.readfp(config_file)

    # Test get_value without regexp
    result = lkl.get_value('key1', 'section1', 'default', False)
   

# Generated at 2022-06-11 15:34:03.283844
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock ansible.plugins.loader.get
    from ansible.plugins.loader import get

    def mock_lookup_class(lookup_name):
        if lookup_name == 'ini':
            return LookupModule

    # Save original ansible.utils.module_docs_fragment.get function
    _get_original = get.get

    # Mock ansible.utils.module_docs_fragment.get
    def mock_get(lookup_name):
        if lookup_name == 'ini':
            return mock_lookup_class
        else:
            return _get_original(lookup_name)

    # Mock ansible.module_utils.basic.AnsibleModule.params

# Generated at 2022-06-11 15:34:14.053054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleLookupError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader

    # Initialisation des objects
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    # create play

# Generated at 2022-06-11 15:34:20.953765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    class _MockOptions(object):
        pass

    class _MockVars(object):
        pass

    class _MockAnsibleHost(object):
        def get_vars(self):
            return _MockVars()

    class _MockTask(object):
        def __init__(self):
            self._ds = {}
            self._ds["vars"] = {}
            self._ds['hosts'] = _MockAnsibleHost()
            self._ds['basedir'] = ""
            self._ds['role_path'] = ""

    class _MockPlay(object):
        def __init__(self):
            self._ds = {}
            self._ds['tasks'] = [_MockTask()]


# Generated at 2022-06-11 15:34:24.802840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_module = LookupModule()
    test_res = test_lookup_module.run(['test_key'], {}, encoding="utf-32")
    assert test_res[0] == "test_value"

# Generated at 2022-06-11 15:34:33.145280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Config file for unit test
    # [section1]
    # domain=example.com
    # regex_value=mytest
    # [section2]
    # domain=example.com
    # regex_value=mytest
    # [section3]
    # key=value
    # key2=value2
    # [section4]
    # key=value
    # key2=value2

    #return all value in section1
    terms = ['*']
    parameters = {'file': 'test.ini', 'section': 'section1'}
    res = lookup.run(terms, variables=None, **parameters)
    assert 'example.com' in res
    assert 'mytest' in res
    assert len(res) == 2

    # return the value of 'domain' in

# Generated at 2022-06-11 15:34:39.852485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["section1\nsection2", "section1", "section2", "section3\nsection3"]
    cp = configparser.ConfigParser(allow_no_value=False)
    cp.readfp(StringIO(u'[section1]\n[section2]\n[section3]'))
    lookup.cp = cp
    for term in terms:
        ret = lookup.run(terms=term)
        assert ret == [term]
        assert ret == [term]

# Generated at 2022-06-11 15:34:49.251503
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()
    # Init ConfigParser
    lookup.cp = configparser.ConfigParser()
    # Retrieve a section that doesn't exist
    lookup.cp.read_string("[section]\nkey=value")
    assert lookup.get_value('existing_key', 'existing_section', 'default', False) is None, \
        "Excepted None, got '%s'" % lookup.get_value('existing_key', 'existing_section', 'default', False)
    # Retrieve existing value
    assert lookup.get_value('key', 'section', 'default', False) == 'value', \
        "Excepted 'value', got '%s'" % lookup.get_value('key', 'section', 'default', False)


# Generated at 2022-06-11 15:35:04.941277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run the run method of class LookupModule for testing
    lookup_instance = LookupModule()
    user = lookup_instance.run(['user', 'file=lookup_ini.ini', 'section=integration'],
                               variables={"ansible_search_path": ["."]})
    assert user[0] == "yannig"
    user2 = lookup_instance.run(['user', 'file=lookup_ini.ini', 'section=production'],
                                variables={"ansible_search_path": ["."]})
    assert user2[0] == "thomas"
    user_default = lookup_instance.run(['user', 'file=lookup_ini.ini', 'section=test', 'default=anonymous'],
                                       variables={"ansible_search_path": ["."]})
   

# Generated at 2022-06-11 15:35:16.611493
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()

    # Test for value with single key and no regexp
    config = configparser.ConfigParser()
    config.readfp(StringIO('[section]\nkey=value'))
    lookup.cp = config
    assert lookup.get_value('key', 'section', 'default', False) == 'value'

    # Test for value with single key and regexp
    assert lookup.get_value('k.*', 'section', 'default', True) == ['value']

    # Test for undefined value and no regexp
    assert lookup.get_value('undefined', 'section', 'default', False) == 'default'

    # Test for undefined value and regexp
    assert lookup.get_value('undefined', 'section', 'default', True) == []

    # Test for undefined section and no regexp
    config = config

# Generated at 2022-06-11 15:35:23.376611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test LookupModule run method """
    module = LookupModule()
    # Test method on a file without a section
    terms = ['foo']
    ini_content = """[global]
    foo = bar"""
    # Set return list of configparser.readfp
    # pylint: disable=protected-access
    module.cp.readfp = lambda _: None

    module._loader = MockFileLoader(ini_content)

    # Test on file without a section
    ret = module.run(terms, {}, {}, '', '')
    assert ret == ['bar']

# Generated at 2022-06-11 15:35:34.405102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    import ansible.plugins.lookup as lookup
    s = StringIO()
    s.write(u"[default]\n")
    s.write(u"host=my.host\n")
    s.write(u"port=8080\n")
    s.write(u"service=http\n")
    s.seek(0, os.SEEK_SET)
    p = lookup.LookupModule()
    p.cp = configparser.ConfigParser()
    p.cp.readfp(s)
    assert p.run([u'host', u'port'], variables=None, file='some_file', section=u'default') == ['my.host', '8080']

# Generated at 2022-06-11 15:35:45.341014
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # create a new object of class LookupModule
    lm = LookupModule()
    # create a new configparser object
    cp = configparser.ConfigParser()
    # use setter to set configparser object into object of class LookupModule
    lm.cp = cp

    # create a new section and add some options
    cp.add_section('global')
    cp.set('global', 'user', 'yannig')
    cp.set('global', 'email', 'yannig.perre@gmail.com')
    cp.set('global', 'regexp', 'yannig')

    # get value of option user
    value = lm.get_value('user', 'global', '', False)
    assert value == 'yannig'

    # get value of option email
    value = lm.get_value

# Generated at 2022-06-11 15:35:55.761043
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.path import unfrackpath
    from ansible.plugins.lookup import LookupBase

    lookup_base = LookupBase()
    lookup_base.set_loader({'_basedir': './'})
    lookup_base.set_basedir({'_basedir': './'})

    lookup_module = LookupModule()

    # Basic test
    ret = lookup_module.run(['user', 'password'], {}, file='test_ini.ini')
    assert ret == ["ceilometer", "ceilometer"], \
            "The ini lookup fails to with a test minimal ini %s" % ret
    # Section test
    ret = lookup_module.run(['user=yperre', 'password=yperre'], {}, file='test_ini.ini', section='section1')


# Generated at 2022-06-11 15:36:05.739409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def noop_find_file_in_search_path(variables, directories=None, filename=''):
        return '/etc/ansible/hosts'

    # Mocking class LookupBase
    class MockLookupBase(LookupBase):
        def __init__(self):
            self.cp_ini = configparser.ConfigParser()
            self.cp_ini.optionxform = str
            self.cp_properties = configparser.ConfigParser()
            self.cp_properties.optionxform = str

        def get_value(self, key, section, dflt, is_regexp):
            # Retrieve all values from a section using a regexp
            if is_regexp:
                return [v for k, v in self.cp_ini.items(section) if re.match(key, k)]
            value

# Generated at 2022-06-11 15:36:17.807127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Verify that the method 'run' throws an AnsibleOptionsError if the
    # option 'key' is not provided in a valid way.
    #
    terms = ["option1=value1 option2=value2 option3=value3", "option4=value4"]
    variables = {}

    lookup = LookupModule()
    try:
        lookup.run(terms, variables)
        assert False
    except AnsibleOptionsError:
        assert True

    #
    # Verify that the method 'run' throws an AnsibleOptionsError if the
    # option 'key' is not provided in a valid way.
    #
    terms = ["option1=value1 option2=value2 option3=value3"]
    variables = {}

    lookup = LookupModule()

# Generated at 2022-06-11 15:36:27.282730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    class Options(object):
        def __init__(self, **kw):
            for k in kw:
                setattr(self, k, kw[k])

    def take_first_term(terms, variables=None, **kwargs):
        return module.run(terms, variables=None, **Options(**kwargs))[0]

    assert take_first_term(["key1"], type="properties", file="test.properties") == "value1"
    assert take_first_term(["user=root"], file="test.ini") == "root"
    assert take_first_term(["user"], file="test.ini") == "root"
    assert take_first_term(["key1"], file="test.ini") == "None"

# Generated at 2022-06-11 15:36:38.696011
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Tests with regexp
    # Test with an ini file that contains the key
    lookup_parameters = {'re': True, 'allow_no_value': False, 'section': 'section1', 'file': 'test.ini'}
    config_parameters = {'case_sensitive': False}
    assert LookupModule(loader=None, variables={}, **config_parameters).get_value('regexp1', **lookup_parameters) == 'value_regexp1'

    # Test with an ini file that doesn't contain the key
    with pytest.raises(AnsibleOptionsError) as execinfo:
        LookupModule(loader=None, variables={}, **config_parameters).get_value('regexp5', **lookup_parameters)

# Generated at 2022-06-11 15:37:03.598965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import sys

    class TestLookup(unittest.TestCase):
        """unit test for LookupModule run method"""

        def test_run_default_params(self):
            """LookupModule run method default parameters"""

            # test object
            lookup = LookupModule()
            lookup.set_options(direct={'file': 'test.ini'})

            # test 1, read from global section
            terms = ['global']
            result = lookup.run(terms)
            self.assertEqual(1, len(result))
            self.assertEqual('value1', result[0])

            # test 2, read from global section using regexp
            terms = ['.*']
            result = lookup.run(terms)
            self.assertEqual(2, len(result))
            self.assertEqual

# Generated at 2022-06-11 15:37:11.300421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    display = Display()

    # Basic test
    test_lookup = LookupModule(display=display)
    contents = """
[section1]
var1=value1
var2=value2
var3=value3

[section2]
var4=value4
var5=value5
"""
    test_lookup.cp = configparser.ConfigParser()
    config = StringIO()
    config.write(contents)
    config.seek(0, os.SEEK_SET)
    test_lookup.cp.readfp(config)
    assert test_lookup.get_value('var1', 'section1', '', False) == 'value1'
    assert test_lookup.get_value('var2', 'section1', '', True) == ''
   

# Generated at 2022-06-11 15:37:17.981934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1: Test section and key with ini value

    # Create an instance of LookupModule class
    lookup = LookupModule()

    # Create a fake section in the ini file
    contents = '[section]\n' + 'key=value\n'

    # Create a StringIO object
    config = StringIO()

    # Write content in the StringIO object
    config.write(contents)

    # Rewind the StringIO object
    config.seek(0, os.SEEK_SET)

    params = {
        'type': 'ini',
        'section': 'section',
        'file': 'file.ini'
    }

    # Parse the StringIO object
    lookup.cp.readfp(config)

    # Check if the method returns the correct value

# Generated at 2022-06-11 15:37:28.700767
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialisation
    lookup_module = LookupModule()
    def _loader_mock(*args, **kwargs):
        return 'files'
    lookup_module._loader = _loader_mock
    def _find_file_in_search_path_mock(*args, **kwargs):
        return 'test.ini'
    lookup_module.find_file_in_search_path = _find_file_in_search_path_mock

# Generated at 2022-06-11 15:37:40.091509
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    lookup = LookupModule()

    # fake data for ConfigParser
    data = """
[global]
key = value1
"""
    config = StringIO()
    config.write(data)
    config.seek(0, os.SEEK_SET)

    # fake ConfigParser
    class FakeConfigParser(object):
        def items(self,section):
            return [('key','value1')]

        def get(self, section, key):
            return 'value1'

        def __init__(self):
            pass

    lookup.cp = FakeConfigParser()

    assert lookup.get_value('key', 'global', None, False) == 'value1'
    assert lookup.get_value('.*', 'global', None, True) == ['value1']

# Generated at 2022-06-11 15:37:51.877091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.module_utils.six.moves import builtins
    # Necessary to avoid issue of Ansible/ansible #14359
    if sys.version_info < (3, 0):
        builtin_open = '__builtin__.open'
    else:
        builtin_open = 'builtins.open'

    # Test ordinary case with no parameter
    lookup_module = LookupModule()

    # Create the string that will be used to test the content of ini
    config = StringIO()
    config.write(u"[test]\n")
    config.write(u"user=Yannig\n")
    config.write(u"password=azerty\n")

    # Create the string that will be used to test the content of ini with a regexp

# Generated at 2022-06-11 15:37:59.673185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule. This method test if method run of class LookupModule
    # correctly modify its list of attributes (cp and var).
    test_str_1 = "[global]\nuser = test"
    test_str_2 = "[global]\nuser = test\nuser = test2"
    test_str_3 = "[global]\nuser = test\nuser = test2\nuser = test3"
    test_ini_1 = StringIO()
    test_ini_2 = StringIO()
    test_ini_3 = StringIO()
    test_ini_1.write(test_str_1)
    test_ini_1.seek(0, os.SEEK_SET)
    test_ini_2.write(test_str_2)

# Generated at 2022-06-11 15:38:09.397615
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from io import StringIO
    from ansible.module_utils.six.moves import configparser

    # test1
    section = 'global'
    key = 'user'
    paramvals = {
        'type': 'ini',
        'file': 'users.ini',
        'section': 'global',
        'default': '',
        're': False,
        'encoding': 'utf-8'
    }
    terms = [key]
    path = 'users.ini'

    # test2
    section2 = 'integration'
    key2 = 'user'

# Generated at 2022-06-11 15:38:15.883957
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a configparser object
    cp = configparser.ConfigParser()

    # Create a term
    term = "term"

    # Create a dict
    section = "section"
    dflt = "dflt"
    is_regexp = False
    key = "key"
    params = {}
    params['case_sensitive'] = False
    params['allow_no_value'] = False

    # FIRST TEST with an empty section
    new_cp = configparser.ConfigParser()
    new_cp.add_section(section)
    lookup_module.cp = new_cp
    assert lookup_module.get_value(key, section, dflt, is_regexp) == dflt

    # SECOND TEST with an non-empty section and a

# Generated at 2022-06-11 15:38:26.228427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init LookupModule
    lookup = LookupModule()

    # Test bad key
    try:
        lookup.run([None], None)
        assert False
    except AnsibleLookupError as e:
        assert "No key to lookup was provided" in to_native(e)

    # Test missing file
    try:
        lookup.run(['key'], None)
        assert False
    except AnsibleLookupError as e:
        assert "could not locate file in lookup: key" in to_native(e)

    # Test bad key
    try:
        lookup.run(['key'], {'_original_file: /tmp'})
        assert False
    except AnsibleLookupError as e:
        assert "could not locate file in lookup: key" in to_native(e)

    # Test bad file

# Generated at 2022-06-11 15:39:07.135172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a test class with needed properties
    class TestClass(object):
        def __init__(self):
            self.mycp = configparser.RawConfigParser()
            self.mycp.optionxform = str
            self.mycp.add_section('section1')
            self.mycp.set('section1', 'key1', 'value1')
            self.mycp.set('section1', 'key2', 'value2')
            self.mycp.set('section1', 'key3', 'value3')
            self.mycp.set('section1', 'key4', 'value4')
            self.mycp.set('section1', 'key5', 'value5')
            self.mycp.add_section('section2')

# Generated at 2022-06-11 15:39:17.102535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Basic test to run LookupModule class"""

    # Create new object of LookupModule class
    lookup = LookupModule()

    # Create test data
    test_data_file = StringIO()
    test_data_file.write(u'[integration]\n')
    test_data_file.write(u'user=foo\n')
    test_data_file.seek(0, os.SEEK_SET)

    # Create a configparser parser
    cp = configparser.ConfigParser()
    cp.readfp(test_data_file)

    # Create options ansible.ini file
    options = {'file': 'ansible.ini', 'section': 'integration', 're': False}

    # Create a term
    term = 'user=foo'

    # Run unit test
    result = lookup.get_

# Generated at 2022-06-11 15:39:28.164358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test parameters
    test_terms = [
        u'key1 value1',
        u'key2 value2',
        u'key3 value3',
    ]
    test_variables = {
        u'file': u'test.ini',
        u'section': u'test',
        u're': False,
        u'type': u'ini',
        u'encoding': u'utf-8',
        u'default': u'',
    }
    # Create object
    lookupModule = LookupModule()
    # Use method run
    lookupModule.run(test_terms, test_variables)
    # Check if 'configParser' is initialized with the right values
    assert lookupModule.cp.get(u'test', u'key1') == u'value1'
    assert lookupModule.cp.get

# Generated at 2022-06-11 15:39:40.046937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test that the run method of the class LookupModule"""

    import os
    import pytest

    # systemctl_reload_target_if_needed_lookup_plugin.py file content
    lookup_file_content = u"[section1]\n" \
                          u"key1=value1\n" \
                          u"key2=value2\n" \
                          u"key3=value3\n" \
                          u"\n" \
                          u"[section2]\n" \
                          u"key11=value11\n" \
                          u"key4=value4\n" \
                          u"key5=value5\n" \
                          u"key6=value6\n" \
                          u"key7=value7\n" \
                         

# Generated at 2022-06-11 15:39:50.348152
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    from collections import namedtuple
    from ansible.parsing.vault import VaultLib
    lookup_module = LookupModule()
    test_data = namedtuple('test_data', ['key', 'section', 'is_regexp', 'expected_result'])
    data = [test_data('test', 'section1', False, '1'),
            test_data('test', 'section2', False, '2'),
            test_data('test', 'section1', True, ['1', '1.1']),
            test_data('test', 'section2', True, ['2', '2.2']),
            test_data('test', 'section3', True, [])
           ]

# Generated at 2022-06-11 15:40:01.189147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes

    lm = LookupModule()

    # Test 1 : with section and key
    term = "user"
    cp = configparser.ConfigParser()
    cp.add_section('global')
    cp.set('global', 'user', 'yperre')

    lm.cp = cp
    lm._loader = DictDataLoader({'ansible.ini': to_bytes(cp.read())})

    variable = {"vars": {"ansible_user": "yperre"}}
    paramvals = {'file': 'ansible.ini', 're': False, 'case_sensitive': False, 'encoding': 'utf-8', 'default': '', 'allow_no_value': False, 'section': 'global'}


# Generated at 2022-06-11 15:40:11.664961
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:40:21.032802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert "test" == lookup.run(["test"])[0]
    assert ["test1", "test2"] == lookup.run(["test1", "test2"])
    assert "test" == lookup.run(["key=test"])[0]
    assert "test" == lookup.run(["key = test"])[0]
    assert "" == lookup.run(["key= test"])[0]
    assert "test" == lookup.run(["key=test", 'default="test"'])[0]
    assert "test" == lookup.run(["key=test", 'default="fail"'])[0]
    assert "default" == lookup.run(["key=test", 'default="default"'])[0]

# Generated at 2022-06-11 15:40:24.266917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test to check method run of class LookupModule
    """
    lookup = LookupModule()
    term = "user=yannig"
    lookup.run(terms=term)
    assert lookup.get_options()['user'] == 'yannig'

# Generated at 2022-06-11 15:40:33.650984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule."""

    def create_lookup_module_fake(term, variables, **kwargs):
        """Fake lookup module."""

        # Create fake variables
        fake_variables = {
            "ansible_inventory": "test",
            "environment": "test",
            "group_names": "test",
            "groups": "test",
            "inventory_dir": "test",
            "inventory_file": "test",
            "inventory_file_path": "test",
            "omit": "test",
            "play_basedir": "test",
            "playbook_dir": "test",
            "play_hosts": "test"
        }
        # Create fake kwargs

# Generated at 2022-06-11 15:41:50.679631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.plugins.lookup import LookupBase

    # Simple ini file
    test_ini = StringIO("""[section]
key=value
key2=value2
""")

    # Empty ini file
    empty_ini = StringIO("");

    # Test read exactly one key
    test_lookup = LookupBase()
    ret = test_lookup.run([
                "key",
                "file=ini",
                "section=section",
                "type=ini",
                "encoding=utf-8"
            ],
            inject={'_reader': test_ini}
    )
    assert ret == ["value"]

    # Test read all key in a section

# Generated at 2022-06-11 15:42:01.384970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path1 = os.path.join(os.path.dirname(__file__), '..', 'plugins', 'lookup_plugins', 'ini.py')
    module = imp.load_source('LookupModule_run', path1)
    LookupModule = module.LookupModule()
    term_ini = """
[section1]
key1a = value1a
key1b = value1b
key1c = value1c
    """

    term_ini2 = """
[section1]
key1a = value1a
key1b = value1b
key1c = value1c
[section2]
key2a = value2a
key2b = value2b
key2c = value2c
    """


# Generated at 2022-06-11 15:42:13.033054
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    # Initialisation of LookupModule
    lookup = LookupModule()
    lookup.cp = configparser.ConfigParser()
    # Init a fake file
    config = StringIO()
    # section test
    config.write(u"[test]\n")
    config.write(u"key0=value0\n")
    config.write(u"key1=value1\n")
    config.write(u"key2=value2\n")
    config.seek(0, os.SEEK_SET)
    # Fake config file
    lookup.cp.readfp(config)
    section = "test"
    # Check method get_value
    assert lookup.get_value("key1", section=section, dflt="", is_regexp=False) == "value1"

# Generated at 2022-06-11 15:42:22.952230
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:42:34.889165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    from ansible.parsing.mod_args import ModuleArgsParser
    module_args = ModuleArgsParser.parse(
        "a1\na2\na3\na4 b=value",
        None
    )
    assert [
        'a1',
        'a2',
        'a3',
        'a4 b=value'
    ] == _parse_params(
        "a1 a2\na3\na4 b=value",
        module_args
    )

    module_args['_raw_params']['b'] = "value"

# Generated at 2022-06-11 15:42:38.678414
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    look = LookupModule()
    look.get_value = lambda x, y, z, t: x * y * z * t
    look.cp = None
    look.find_file_in_search_path = lambda x, y, z: z

    # test: No section
    # 1. Return default value (1).
    # 2. Return value (1).
    paramvals = {'re': False, 'encoding': 'utf-8', 'file': 'file', 'section': 'section', 'default': 1}
    assert look.run(['.*'], paramvals=paramvals) == [1]
    assert look.run(['1'], paramvals=paramvals) == [1]

    # test: No key found
    # 1. Return default value (1).
    # 2. Return value (1).
    look

# Generated at 2022-06-11 15:42:47.225303
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    class FakeLookupModule(LookupModule):
        def __init__(self):
            self.cp = configparser.ConfigParser()

        def get_value(self, key, section, dflt, is_regexp):
            return super(FakeLookupModule, self).get_value(key, section, dflt, is_regexp)

    fake_lookup_module = FakeLookupModule()
    fake_lookup_module.cp.add_section('section1')
    fake_lookup_module.cp.set('section1', 'key1', 'value1')
    fake_lookup_module.cp.set('section1', 'key2', 'value2')

    # Test with regexp

# Generated at 2022-06-11 15:42:56.889031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    from ansible.module_utils.six import PY2
    from ansible.utils.unicode import to_bytes

    fd = open('users.ini', 'wb') if PY2 else open('users.ini', 'w', encoding='utf-8')
    fd.write(to_bytes(u'[integration]\n'))
    fd.write(to_bytes(u'user=abc\n'))
    fd.write(to_bytes(u'[production]\n'))
    fd.write(to_bytes(u'user=def\n'))
    fd.close()


# Generated at 2022-06-11 15:43:05.494844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test_LookupModule_run: test run function
    """

    import sys
    import os
    import tempfile
    import yaml
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.unicode import to_bytes
    from ansible.compat.tests import unittest


# Generated at 2022-06-11 15:43:13.009001
# Unit test for method get_value of class LookupModule
def test_LookupModule_get_value():
    """
    Test get_value method of class LookupModule
    """
    import pytest
    # Generate mock IniFile instance
    ini_file = StringIO()
    ini_file.write(u'[section1]\n')
    ini_file.write(u'key1 = value1\n')
    ini_file.write(u'key2 = value2\n')
    ini_file.write(u'key3 = value3\n')
    ini_file.write(u'key4 = value4\n')
    ini_file.seek(0, os.SEEK_SET)
    cp = configparser.ConfigParser()
    cp.readfp(ini_file)
    # Generate LookupModule instance
    lm = LookupModule()
    lm.cp