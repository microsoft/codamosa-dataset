

# Generated at 2022-06-17 13:09:54.876291
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = 1
    lookup_module.format = "%d"
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")

    lookup_module.start = 1
    lookup_module.count = 1
    lookup_module.end = 1
    lookup_module.stride = 1
    lookup_module.format = "%d"
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")


# Generated at 2022-06-17 13:10:07.251626
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()
    lm.reset()
    lm.parse_simple_args('5')
    assert lm.start == 1
    assert lm.end == 5
    assert lm.stride == 1
    assert lm.format == '%d'
    lm.reset()
    lm.parse_simple_args('5-8')
    assert lm.start == 5
    assert lm.end == 8
    assert lm.stride == 1
    assert lm.format == '%d'
    lm.reset()
    lm.parse_simple_args('2-10/2')
    assert lm.start == 2
    assert lm.end == 10
    assert lm.stride == 2
    assert lm.format == '%d'

# Generated at 2022-06-17 13:10:17.573644
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    lookup_module.reset()

    # Test 1: start, end, stride, format
    term = "1-10/2:test%02d"
    assert lookup_module.parse_simple_args(term) == True
    assert lookup_module.start == 1
    assert lookup_module.end == 10
    assert lookup_module.stride == 2
    assert lookup_module.format == "test%02d"

    # Test 2: start, end, stride
    term = "1-10/2"
    assert lookup_module.parse_simple_args(term) == True
    assert lookup_module.start == 1
    assert lookup_module.end == 10
    assert lookup_module.stride == 2
    assert lookup_module.format == "%d"

    # Test 3: start,

# Generated at 2022-06-17 13:10:30.668366
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:38.043398
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.parse_kv_args({'start': '0', 'end': '10', 'stride': '2', 'format': '%d'})
    assert lookup_module.start == 0
    assert lookup_module.end == 10
    assert lookup_module.stride == 2
    assert lookup_module.format == '%d'


# Generated at 2022-06-17 13:10:47.517325
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lm = LookupModule()
    lm.reset()
    lm.parse_kv_args({'start': '0', 'end': '10', 'stride': '2', 'format': '%d'})
    assert lm.start == 0
    assert lm.end == 10
    assert lm.stride == 2
    assert lm.format == '%d'
    assert lm.count is None
    lm.reset()
    lm.parse_kv_args({'start': '0', 'end': '10', 'stride': '2', 'format': '%d', 'extra': 'extra'})
    assert lm.start == 0
    assert lm.end == 10
    assert lm.stride == 2
    assert lm.format == '%d'
    assert l

# Generated at 2022-06-17 13:11:00.654141
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 5
    lookup.stride = 1
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["1", "2", "3", "4", "5"]

    lookup.start = 1
    lookup.end = 5
    lookup.stride = 2
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["1", "3", "5"]

    lookup.start = 5
    lookup.end = 1
    lookup.stride = -1
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["5", "4", "3", "2", "1"]

    lookup.start = 5
    lookup.end = 1
    lookup

# Generated at 2022-06-17 13:11:13.145309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with simple arguments
    lookup_module = LookupModule()
    assert lookup_module.run(["0-10"], None) == ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    assert lookup_module.run(["0-10/2"], None) == ["0", "2", "4", "6", "8", "10"]
    assert lookup_module.run(["0-10/2:host%02d"], None) == ["host00", "host02", "host04", "host06", "host08", "host10"]
    assert lookup_module.run(["0-10/2:host%02d"], None) == ["host00", "host02", "host04", "host06", "host08", "host10"]

# Generated at 2022-06-17 13:11:15.323717
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.sanity_check()


# Generated at 2022-06-17 13:11:22.041137
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.parse_kv_args(parse_kv("start=5 end=11 stride=2 format=0x%02x"))
    assert lookup_module.start == 5
    assert lookup_module.end == 11
    assert lookup_module.stride == 2
    assert lookup_module.format == "0x%02x"


# Generated at 2022-06-17 13:11:32.840388
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 2
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["1", "3", "5", "7", "9"]
    lookup_module.start = 10
    lookup_module.end = 1
    lookup_module.stride = -2

# Generated at 2022-06-17 13:11:44.155734
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()
    assert lookup.parse_simple_args("1") == True
    assert lookup.start == 1
    assert lookup.end == 1
    assert lookup.stride == 1
    assert lookup.format == "%d"
    assert lookup.count == None

    lookup.reset()
    assert lookup.parse_simple_args("1-2") == True
    assert lookup.start == 1
    assert lookup.end == 2
    assert lookup.stride == 1
    assert lookup.format == "%d"
    assert lookup.count == None

    lookup.reset()
    assert lookup.parse_simple_args("1-2/3") == True
    assert lookup.start == 1
    assert lookup.end == 2
    assert lookup.stride == 3
    assert lookup.format == "%d"
   

# Generated at 2022-06-17 13:11:54.503450
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["1", "2", "3", "4", "5"]

    lookup_module.start = 5
    lookup_module.end = 8
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["5", "6", "7", "8"]

    lookup_module.start = 2
    lookup_module.end = 10
    lookup_module.stride = 2
    lookup_module.format = "%d"

# Generated at 2022-06-17 13:12:08.241817
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.sanity_check()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = -1
    lookup.format = "%d"
    lookup.sanity_check()
    lookup.start = 10
    lookup.end = 1
    lookup.stride = 1
    lookup.format = "%d"
    try:
        lookup.sanity_check()
    except AnsibleError as e:
        assert str(e) == "to count backwards make stride negative"
    lookup.start = 10
    lookup.end = 1
    lookup.stride = -1
    lookup.format = "%d"
    lookup.sanity_check()


# Generated at 2022-06-17 13:12:20.219112
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["1", "2", "3", "4", "5"]

    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 2
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["1", "3", "5"]

    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = -1
    lookup_module.format = "%d"

# Generated at 2022-06-17 13:12:26.387350
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args("5") == True
    assert lookup_module.start == 1
    assert lookup_module.end == 5
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    assert lookup_module.parse_simple_args("5-8") == True
    assert lookup_module.start == 5
    assert lookup_module.end == 8
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    assert lookup_module.parse_simple_args("2-10/2") == True
    assert lookup_module.start == 2
    assert lookup_module.end == 10
    assert lookup_module.stride == 2
    assert lookup_module.format == "%d"
    assert lookup

# Generated at 2022-06-17 13:12:34.260346
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = 1
    lookup_module.format = "%d"
    try:
        lookup_module.sanity_check()
        assert False
    except AnsibleError:
        assert True
    lookup_module.count = 1
    try:
        lookup_module.sanity_check()
        assert False
    except AnsibleError:
        assert True
    lookup_module.count = None
    lookup_module.end = 1
    lookup_module.sanity_check()
    lookup_module.stride = -1
    lookup_module.sanity_check()
    lookup_module.stride = 1
    lookup_module.end = 0
    lookup

# Generated at 2022-06-17 13:12:40.841400
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.sanity_check()
    assert True


# Generated at 2022-06-17 13:12:51.652335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with_sequence with start, end, stride and format
    lookup_module = LookupModule()
    result = lookup_module.run(['start=5 end=11 stride=2 format=0x%02x'], None)
    assert result == ['0x05', '0x07', '0x09', '0x0a']

    # Test with_sequence with start, end, stride and format
    lookup_module = LookupModule()
    result = lookup_module.run(['start=5 end=11 stride=2 format=0x%02x'], None)
    assert result == ['0x05', '0x07', '0x09', '0x0a']

    # Test with_sequence with start, end, stride and format
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:13:03.437221
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.sanity_check()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = -1
    lookup.format = "%d"
    lookup.sanity_check()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 0
    lookup.format = "%d"
    lookup.sanity_check()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.count = 5
    lookup.sanity_check()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
   

# Generated at 2022-06-17 13:13:25.955078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with simple arguments
    lookup_module = LookupModule()
    assert lookup_module.run(['start=1 end=5'], None) == ['1', '2', '3', '4', '5']
    assert lookup_module.run(['start=1 end=5 stride=2'], None) == ['1', '3', '5']
    assert lookup_module.run(['start=1 end=5 format=test%02d'], None) == ['test01', 'test02', 'test03', 'test04', 'test05']
    assert lookup_module.run(['start=1 end=5 count=3'], None) == ['1', '2', '3']

# Generated at 2022-06-17 13:13:31.526927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with_sequence
    lookup_module = LookupModule()
    result = lookup_module.run(["start=5 end=11 stride=2 format=0x%02x"], None)
    assert result == ["0x05", "0x07", "0x09", "0x0a"]
    result = lookup_module.run(["start=0x0f00 count=4 format=%04x"], None)
    assert result == ["0f00", "0f01", "0f02", "0f03"]
    result = lookup_module.run(["start=0 count=5 stride=2"], None)
    assert result == ["0", "2", "4", "6", "8"]
    result = lookup_module.run(["start=1 count=5 stride=2"], None)

# Generated at 2022-06-17 13:13:38.550341
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.sanity_check()
    assert lookup_module.count is None
    assert lookup_module.end == 10

    lookup_module.count = 5
    lookup_module.sanity_check()
    assert lookup_module.count is None
    assert lookup_module.end == 5

    lookup_module.count = 0
    lookup_module.sanity_check()
    assert lookup_module.count is None
    assert lookup_module.end == 0
    assert lookup_module.start == 0
    assert lookup_module.stride == 0

    lookup_module.start = 10
    lookup_module.end = 0
    lookup_module.stride = -1


# Generated at 2022-06-17 13:13:50.274060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with_sequence with count
    lookup_module = LookupModule()
    assert lookup_module.run(["count=5"], None) == ["1", "2", "3", "4", "5"]

    # Test with_sequence with start, end and stride
    lookup_module = LookupModule()
    assert lookup_module.run(["start=0 end=10 stride=2"], None) == ["0", "2", "4", "6", "8", "10"]

    # Test with_sequence with start, end and stride
    lookup_module = LookupModule()
    assert lookup_module.run(["start=0 end=10 stride=2 format=0x%02x"], None) == ["0x00", "0x02", "0x04", "0x06", "0x08", "0x0a"]



# Generated at 2022-06-17 13:14:03.537806
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.parse_simple_args("5")
    assert lookup_module.start == 1
    assert lookup_module.end == 5
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    lookup_module.reset()
    lookup_module.parse_simple_args("5-8")
    assert lookup_module.start == 5
    assert lookup_module.end == 8
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    lookup_module.reset()
    lookup_module.parse_simple_args("2-10/2")
    assert lookup_module.start == 2
    assert lookup_module.end == 10
    assert lookup_module.stride == 2


# Generated at 2022-06-17 13:14:13.439547
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.sanity_check()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = -1
    lookup.format = "%d"
    lookup.sanity_check()
    lookup.start = 10
    lookup.end = 1
    lookup.stride = 1
    lookup.format = "%d"
    try:
        lookup.sanity_check()
        assert False
    except AnsibleError:
        pass
    lookup.start = 10
    lookup.end = 1
    lookup.stride = -1
    lookup.format = "%d"
    lookup.sanity_check()
    lookup.start = 1
    lookup.end

# Generated at 2022-06-17 13:14:23.748468
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()
    l.start = 1
    l.end = 5
    l.stride = 1
    l.format = "%d"
    assert list(l.generate_sequence()) == ["1", "2", "3", "4", "5"]
    l.start = 1
    l.end = 5
    l.stride = 2
    l.format = "%d"
    assert list(l.generate_sequence()) == ["1", "3", "5"]
    l.start = 1
    l.end = 5
    l.stride = 3
    l.format = "%d"
    assert list(l.generate_sequence()) == ["1", "4"]
    l.start = 1
    l.end = 5
    l.stride = 4

# Generated at 2022-06-17 13:14:32.990946
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.sanity_check()

    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = -1
    lookup_module.sanity_check()

    lookup_module.start = 10
    lookup_module.end = 1
    lookup_module.stride = 1
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        pass
    else:
        assert False, "should have raised AnsibleError"

    lookup_module.start = 10
    lookup_module.end = 1
    lookup_module.stride = -1
    lookup_module.sanity_check()



# Generated at 2022-06-17 13:14:45.200383
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 0
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert lookup_module.generate_sequence() == ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
    lookup_module.start = 0
    lookup_module.end = 10
    lookup_module.stride = 2
    lookup_module.format = "%d"
    assert lookup_module.generate_sequence() == ['0', '2', '4', '6', '8', '10']
    lookup_module.start = 0
    lookup_module.end = 10
    lookup_module.stride = -1

# Generated at 2022-06-17 13:14:56.210875
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.sanity_check()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = -1
    lookup.sanity_check()
    lookup.start = 10
    lookup.end = 1
    lookup.stride = 1
    try:
        lookup.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError("sanity_check should have raised AnsibleError")
    lookup.start = 10
    lookup.end = 1
    lookup.stride = -1
    lookup.sanity_check()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 0
    lookup.sanity_

# Generated at 2022-06-17 13:15:12.535248
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.sanity_check()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = -1
    lookup_module.sanity_check()
    lookup_module.start = 10
    lookup_module.end = 1
    lookup_module.stride = 1
    try:
        lookup_module.sanity_check()
    except AnsibleError as e:
        assert str(e) == "to count backwards make stride negative"
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = -1

# Generated at 2022-06-17 13:15:21.552046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with_sequence with simple arguments
    lookup_module = LookupModule()
    terms = ['5']
    variables = {}
    results = lookup_module.run(terms, variables)
    assert results == ['1', '2', '3', '4', '5']

    terms = ['5-8']
    results = lookup_module.run(terms, variables)
    assert results == ['5', '6', '7', '8']

    terms = ['2-10/2']
    results = lookup_module.run(terms, variables)
    assert results == ['2', '4', '6', '8', '10']

    terms = ['4:host%02d']
    results = lookup_module.run(terms, variables)
    assert results == ['host01', 'host02', 'host03', 'host04']

   

# Generated at 2022-06-17 13:15:33.854326
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 5
    lookup.stride = 1
    lookup.format = "%d"
    result = list(lookup.generate_sequence())
    assert result == ["1", "2", "3", "4", "5"]
    lookup.start = 5
    lookup.end = 1
    lookup.stride = -1
    result = list(lookup.generate_sequence())
    assert result == ["5", "4", "3", "2", "1"]
    lookup.start = 1
    lookup.end = 5
    lookup.stride = 2
    result = list(lookup.generate_sequence())
    assert result == ["1", "3", "5"]
    lookup.start = 1
    lookup.end = 5
    lookup.stride

# Generated at 2022-06-17 13:15:44.720423
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ['1', '2', '3', '4', '5']

    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 2
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ['1', '3', '5']

    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = -1
    lookup_module.format = "%d"

# Generated at 2022-06-17 13:15:53.146635
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:00.351896
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["1", "2", "3", "4", "5"]

    lookup_module.start = 5
    lookup_module.end = 8
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["5", "6", "7", "8"]

    lookup_module.start = 2
    lookup_module.end = 10
    lookup_module.stride = 2
    lookup_module.format = "%d"

# Generated at 2022-06-17 13:16:11.548656
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.sanity_check()
    lookup_module.start = 10
    lookup_module.end = 1
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.sanity_check()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = -1
    lookup_module.format = "%d"
    lookup_module.sanity_check()
    lookup_module.start = 10
    lookup_module.end = 1
    lookup_module.stride = -1

# Generated at 2022-06-17 13:16:19.982580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['start=1 end=5']
    variables = {}
    results = lookup_module.run(terms, variables)
    assert results == ['1', '2', '3', '4', '5']
    terms = ['start=1 end=5 format=testuser%02x']
    variables = {}
    results = lookup_module.run(terms, variables)
    assert results == ['testuser01', 'testuser02', 'testuser03', 'testuser04', 'testuser05']
    terms = ['start=1 end=5 format=testuser%02x']
    variables = {}
    results = lookup_module.run(terms, variables)
    assert results == ['testuser01', 'testuser02', 'testuser03', 'testuser04', 'testuser05']
    terms

# Generated at 2022-06-17 13:16:30.393387
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()
    lookup.parse_simple_args('5')
    assert lookup.start == 1
    assert lookup.end == 5
    assert lookup.stride == 1
    assert lookup.format == '%d'

    lookup.reset()
    lookup.parse_simple_args('5-8')
    assert lookup.start == 5
    assert lookup.end == 8
    assert lookup.stride == 1
    assert lookup.format == '%d'

    lookup.reset()
    lookup.parse_simple_args('2-10/2')
    assert lookup.start == 2
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == '%d'

    lookup.reset()
    lookup.parse_simple_args('4:host%02d')


# Generated at 2022-06-17 13:16:37.505562
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()
    lookup.parse_simple_args("5")
    assert lookup.start == 1
    assert lookup.end == 5
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_simple_args("5-8")
    assert lookup.start == 5
    assert lookup.end == 8
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_simple_args("2-10/2")
    assert lookup.start == 2
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_simple_args("4:host%02d")
    assert lookup

# Generated at 2022-06-17 13:16:59.869998
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Test for valid input
    lm = LookupModule()
    lm.reset()
    assert lm.parse_simple_args("5") == True
    assert lm.start == 1
    assert lm.end == 5
    assert lm.stride == 1
    assert lm.format == "%d"
    lm.reset()
    assert lm.parse_simple_args("5-8") == True
    assert lm.start == 5
    assert lm.end == 8
    assert lm.stride == 1
    assert lm.format == "%d"
    lm.reset()
    assert lm.parse_simple_args("2-10/2") == True
    assert lm.start == 2
    assert lm.end == 10
    assert lm.stride == 2

# Generated at 2022-06-17 13:17:12.363404
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 5
    lookup.stride = 1
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["1", "2", "3", "4", "5"]

    lookup.start = 1
    lookup.end = 5
    lookup.stride = 2
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["1", "3", "5"]

    lookup.start = 1
    lookup.end = 5
    lookup.stride = -1
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["1", "0", "-1", "-2", "-3"]

    lookup.start = 1
    lookup.end = 5
    lookup

# Generated at 2022-06-17 13:17:22.899099
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.sanity_check()
    assert lookup.start == 1
    assert lookup.end == 10
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.start = 1
    lookup.end = 10
    lookup.stride = -1
    lookup.format = "%d"
    lookup.sanity_check()
    assert lookup.start == 1
    assert lookup.end == 10
    assert lookup.stride == -1
    assert lookup.format == "%d"

    lookup.start = 10
    lookup.end = 1
    lookup.stride = 1
    lookup.format = "%d"

# Generated at 2022-06-17 13:17:33.548635
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()

    # Test shortcut form
    assert lookup.parse_simple_args("5") == True
    assert lookup.start == 1
    assert lookup.end == 5
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    assert lookup.parse_simple_args("5-8") == True
    assert lookup.start == 5
    assert lookup.end == 8
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    assert lookup.parse_simple_args("2-10/2") == True
    assert lookup.start == 2
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == "%d"

    lookup.reset()
    assert lookup.parse

# Generated at 2022-06-17 13:17:39.150469
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.sanity_check()
    assert True


# Generated at 2022-06-17 13:17:51.578253
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = 1
    lookup_module.format = "%d"
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        assert False, "sanity_check should not raise exception"
    lookup_module.count = 1
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        assert False, "sanity_check should not raise exception"
    lookup_module.end = 1
    try:
        lookup_module.sanity_check()
        assert False, "sanity_check should raise exception"
    except AnsibleError:
        pass
    lookup_module.end = None
   

# Generated at 2022-06-17 13:18:03.363414
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 5
    lookup.stride = 1
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["1", "2", "3", "4", "5"]

    lookup.start = 1
    lookup.end = 5
    lookup.stride = 2
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["1", "3", "5"]

    lookup.start = 5
    lookup.end = 1
    lookup.stride = -1
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["5", "4", "3", "2", "1"]

    lookup.start = 5
    lookup.end = 1
    lookup

# Generated at 2022-06-17 13:18:15.129891
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["1", "2", "3", "4", "5"]
    lookup_module.start = 5
    lookup_module.end = 8
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["5", "6", "7", "8"]
    lookup_module.start = 2
    lookup_module.end = 10
    lookup_module.stride = 2
    lookup_module.format = "%d"

# Generated at 2022-06-17 13:18:25.693387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:18:32.145164
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.sanity_check()
    lookup_module.start = 10
    lookup_module.end = 1
    lookup_module.stride = -1
    lookup_module.sanity_check()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = -1
    try:
        lookup_module.sanity_check()
        assert False
    except AnsibleError:
        assert True
    lookup_module.start = 10
    lookup_module.end = 1
    lookup_module.stride = 1

# Generated at 2022-06-17 13:18:51.811351
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.sanity_check()
    assert True


# Generated at 2022-06-17 13:18:58.231905
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()
    l.start = 1
    l.end = 5
    l.stride = 1
    l.format = "%d"
    assert list(l.generate_sequence()) == ["1", "2", "3", "4", "5"]
    l.start = 1
    l.end = 5
    l.stride = 2
    l.format = "%d"
    assert list(l.generate_sequence()) == ["1", "3", "5"]
    l.start = 1
    l.end = 5
    l.stride = 3
    l.format = "%d"
    assert list(l.generate_sequence()) == ["1", "4"]
    l.start = 1
    l.end = 5
    l.stride = 4

# Generated at 2022-06-17 13:19:08.323286
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Test 1:
    # Test case: count is None and end is None
    # Expected result: AnsibleError
    lookup_module = LookupModule()
    lookup_module.count = None
    lookup_module.end = None
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

    # Test 2:
    # Test case: count is not None and end is not None
    # Expected result: AnsibleError
    lookup_module = LookupModule()
    lookup_module.count = 1
    lookup_module.end = 1
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"

# Generated at 2022-06-17 13:19:14.409538
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Test case 1: count is None and end is None
    lookup_module = LookupModule()
    lookup_module.count = None
    lookup_module.end = None
    try:
        lookup_module.sanity_check()
    except AnsibleError as e:
        assert str(e) == "must specify count or end in with_sequence"
    else:
        assert False, "AnsibleError not raised"

    # Test case 2: count is not None and end is not None
    lookup_module = LookupModule()
    lookup_module.count = 1
    lookup_module.end = 2
    try:
        lookup_module.sanity_check()
    except AnsibleError as e:
        assert str(e) == "can't specify both count and end in with_sequence"

# Generated at 2022-06-17 13:19:21.803097
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()
    lm.reset()
    assert lm.parse_simple_args("5") == True
    assert lm.start == 1
    assert lm.end == 5
    assert lm.stride == 1
    assert lm.format == "%d"
    assert lm.parse_simple_args("5-8") == True
    assert lm.start == 5
    assert lm.end == 8
    assert lm.stride == 1
    assert lm.format == "%d"
    assert lm.parse_simple_args("2-10/2") == True
    assert lm.start == 2
    assert lm.end == 10
    assert lm.stride == 2
    assert lm.format == "%d"

# Generated at 2022-06-17 13:19:32.621398
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.sanity_check()
    assert lookup.start == 1
    assert lookup.end == 10
    assert lookup.stride == 1
    assert lookup.format == "%d"
    assert lookup.count is None

    lookup.start = 1
    lookup.end = 10
    lookup.stride = -1
    lookup.format = "%d"
    lookup.sanity_check()
    assert lookup.start == 1
    assert lookup.end == 10
    assert lookup.stride == -1
    assert lookup.format == "%d"
    assert lookup.count is None

    lookup.start = 1
    lookup.end = 10
    lookup.stride = 1
   