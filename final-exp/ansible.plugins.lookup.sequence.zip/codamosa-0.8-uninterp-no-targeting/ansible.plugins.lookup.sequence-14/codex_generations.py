

# Generated at 2022-06-21 06:27:31.917223
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():

    test_cases = [
        {
            "test_desc": "Test reset()",
            "instance": LookupModule(),
            "start": 1,
            "end": None,
            "stride": 1,
            "format": "%d",
        }
    ]

    for test in test_cases:
        instance = test["instance"]
        instance.reset()

        for attr in ["start", "end", "stride", "format"]:
            if test[attr] != getattr(instance, attr):
                raise Exception("%s failed: %s != %s" % (test["test_desc"], test[attr], getattr(instance, attr)))


# Generated at 2022-06-21 06:27:42.983137
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lm = LookupModule()

    lm.start = 0
    lm.count = None
    lm.end = 3
    lm.stride = 1
    lm.format = "%d"

    assert list(lm.generate_sequence()) == ['0', '1', '2', '3']

    lm.start = 2
    lm.count = None
    lm.end = 10
    lm.stride = 2
    lm.format = "%d"

    assert list(lm.generate_sequence()) == ['2', '4', '6', '8', '10']

    lm.start = 5
    lm.count = None
    lm.end = 1
    lm.stride = -2
    lm.format = "%04d"


# Generated at 2022-06-21 06:27:44.645251
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    assert LookupModule('/tmp').sanity_check() is None

# Generated at 2022-06-21 06:27:54.897030
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with simple/shortcut arguments
    lk = LookupModule()
    result = lk.run(["0-10"], dict())
    assert result == list(map(str, range(0, 11)))

    result = lk.run(["4:host%02d"], dict())
    assert result == ["host%02d" % i for i in range(4)]

    result = lk.run(["4:host%02d" % i for i in range(4)], dict())
    assert result == ["host%02d" % i for i in range(4)]

    # Test with key-value arguments
    lk = LookupModule()
    result = lk.run(["start=0 end=10"], dict())
    assert result == list(map(str, range(0, 11)))

    result = lk

# Generated at 2022-06-21 06:27:59.906081
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    a = LookupModule()
    a.reset()
    a.parse_kv_args(dict(start="0", end="10", stride="2"))
    assert a.start == 0
    assert a.end == 10
    assert a.stride == 2


# Generated at 2022-06-21 06:28:09.498003
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    l = LookupModule()
    l.reset()
    # parse_kv_args: good input
    l.parse_kv_args({'start': '1', 'end': '10', 'stride': '2', 'format': '%02d'})
    assert l.start == 1
    assert l.end == 10
    assert l.stride == 2
    assert l.format == '%02d'
    # parse_kv_args: bad input: start is not an integer
    try:
        l.parse_kv_args({'start':'abc'})
        assert False, "Error: #1, An exception was expected"
    except AnsibleError as e:
        assert str(e) == "can't parse start=abc as integer"
    # parse_kv_args: bad input: end is

# Generated at 2022-06-21 06:28:17.797638
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    l = LookupModule()
    num_tests = 0
    num_failures = 0

    def run_test(arg_dict, k, start, count, end, stride, format):
        # Tested method
        l.parse_kv_args(arg_dict)

        # Expected result
        expected = {
            "start" : start,
            "count" : count,
            "end" : end,
            "stride" : stride,
            "format" : format
        }

        # Compare expected vs actual
        actual = {
            "start" : l.start,
            "count" : l.count,
            "end" : l.end,
            "stride" : l.stride,
            "format" : l.format
        }


# Generated at 2022-06-21 06:28:26.191551
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    module = LookupModule()
    module.reset()
    module.end = 9
    module.stride = -2
    module.sanity_check()
    assert module.start == 9
    assert module.end == 9
    assert module.stride == -2
    assert module.format == "%d"
    module.reset()
    module.end = 4
    module.stride = 2
    module.sanity_check()
    assert module.start == 4
    assert module.end == 4
    assert module.stride == 2
    assert module.format == "%d"
    module.reset()
    module.start = 2
    module.end = 11
    module.stride = 2
    module.sanity_check()
    assert module.start == 2
    assert module.end == 11
    assert module.stride

# Generated at 2022-06-21 06:28:39.793540
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    lookup = LookupModule()
    lookup.start = 0
    lookup.end = 10
    lookup.stride = 2

    results = lookup.generate_sequence()

    assert list(results) == ["0", "2", "4", "6", "8", "10"]

    lookup = LookupModule()
    lookup.start = 0
    lookup.end = 10
    lookup.stride = -2

    results = lookup.generate_sequence()

    assert list(results) == ["0", "-2", "-4", "-6", "-8", "-10"]

    lookup = LookupModule()
    lookup.start = 0
    lookup.end = 0
    lookup.stride = 0

    results = lookup.generate_sequence()

    assert list(results) == []

# Generated at 2022-06-21 06:28:47.651211
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    l = LookupModule()
    l.parse_simple_args('5')
    assert l.start == 5
    assert l.count is None
    assert l.end == 5
    assert l.stride == 1
    assert l.format == '%d'

    l.parse_simple_args('5-8')
    assert l.start == 5
    assert l.count is None
    assert l.end == 8
    assert l.stride == 1
    assert l.format == '%d'

    l.parse_simple_args('2-10/2')
    assert l.start == 2
    assert l.count is None
    assert l.end == 10
    assert l.stride == 2
    assert l.format == '%d'

    l.parse_simple_args('4:host%02d')


# Generated at 2022-06-21 06:29:06.622106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:29:19.094108
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    test_obj = LookupModule()

    test_obj.parse_simple_args("8")
    assert test_obj.start == 1
    assert test_obj.end == 8
    assert test_obj.stride == 1
    assert test_obj.format == "%d"

    test_obj.parse_simple_args("3-6")
    assert test_obj.start == 3
    assert test_obj.end == 6
    assert test_obj.stride == 1
    assert test_obj.format == "%d"

    test_obj.parse_simple_args("2-10/2")
    assert test_obj.start == 2
    assert test_obj.end == 10
    assert test_obj.stride == 2
    assert test_obj.format == "%d"


# Generated at 2022-06-21 06:29:23.187246
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    a = LookupModule()
    a.reset()
    assert a.start == 1
    assert a.count == None
    assert a.end == None
    assert a.stride == 1
    assert a.format == "%d"


# Generated at 2022-06-21 06:29:31.920884
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    lookup = LookupModule()

    # Test invalid shortcut forms
    assert lookup.parse_simple_args("") == False
    assert lookup.parse_simple_args("-f") == False
    assert lookup.parse_simple_args("/f") == False
    assert lookup.parse_simple_args("f:/f") == False
    assert lookup.parse_simple_args("f:f:f:f") == False
    assert lookup.parse_simple_args("f-/f") == False
    assert lookup.parse_simple_args("f:0") == False
    assert lookup.parse_simple_args("f-f") == False
    assert lookup.parse_simple_args("f-f/f") == False
    assert lookup.parse_simple_args("f:-f") == False

    # Test valid shortcut forms
    assert lookup.parse

# Generated at 2022-06-21 06:29:44.459343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # we need to generate our own fake loader here,
    # as LookupModule is not a valid AnsibleModule
    module = AnsibleLoader("/fake/path", "name", False, None)
    print("--- test start")
    print("--- reset")
    lookup_plugin = LookupModule(loader=module, basedir=None, runner=None)
    # first try - LookupModule.run with no args
    print("--- run")
    data = lookup_plugin.run([], {})
    assert data == ["1"], data
    print("--- reset")
    lookup_plugin = LookupModule(loader=module, basedir=None, runner=None)
    # second try - LookupModule.run with simple arguments
    print("--- run")
    print("--- run")

# Generated at 2022-06-21 06:29:48.936802
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    base = LookupModule()
    base.start = 10
    base.end = 20
    base.stride = 1
    base.format = "%d"
    base.reset()
    assert base.start == 1
    assert base.end is None
    assert base.stride == 1
    assert base.format == "%d"


# Generated at 2022-06-21 06:30:01.221892
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    '''
    Test if method parse_simple_args() of class LookupModule
    works as expected
    '''

    # Create an instance of LookupModule class
    test = LookupModule()

    # Check if method parse_simple_args() works correctly for positive tests

# Generated at 2022-06-21 06:30:05.675607
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    term = None
    lk = LookupModule()
    try:
        lk.run([term], None)
    except Exception as e:
        if e.args[0] == "sequence start value is not set":
            return True
    return False


# Generated at 2022-06-21 06:30:12.969528
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    assert LookupModule().parse_simple_args('2') == True, "Value doesn't match"
    assert LookupModule().parse_simple_args('4:test%02d') == True, "Value doesn't match"
    assert LookupModule().parse_simple_args('-1') == True, "Value doesn't match"
    assert LookupModule().parse_simple_args('2-') == True, "Value doesn't match"
    assert LookupModule().parse_simple_args('0-3') == True, "Value doesn't match"
    assert LookupModule().parse_simple_args('5-8') == True, "Value doesn't match"
    assert LookupModule().parse_simple_args('3/4') == True, "Value doesn't match"
    assert LookupModule().parse_simple_args('5-8/2')

# Generated at 2022-06-21 06:30:25.316791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.reset()
    terms = [
        "start=1 end=2 stride=1 format=test%d",
        "start=1 end=2 stride=1 format=test%02d",
        "start=1 end=2 stride=2 format=test%02x",
        "1-2/1:test%d",
        "count=3:test%02d",
        "count=0:test%02x",
    ]
    results = [
        ["test1", "test2"],
        ["test01", "test02"],
        ["test01", "test02"],
        ["test1", "test2"],
        ["test01", "test02", "test03"],
        ["test00", "test01", "test02"],
    ]

# Generated at 2022-06-21 06:30:41.819712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    data = '''
- sequence: start=7
- sequence: start=2 end=10
- sequence: start=4 end=16 stride=2
- sequence: count=4
- sequence: start=10 end=0 stride=-1
- sequence: start=1 end=10
- sequence: start=1 end="{{ end_at }}"
  vars:
    - end_at: 10
    '''

    loader = AnsibleLoader(data, file_name='noname')
    # print(loader.get_single_data())
    tasks = loader.get_single_data()

# Generated at 2022-06-21 06:30:53.324215
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()
    lm.reset()

    lm.parse_simple_args('5')
    assert lm.start == 1
    assert lm.end == 5
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()
    lm.parse_simple_args('5-8')
    assert lm.start == 5
    assert lm.end == 8
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()
    lm.parse_simple_args('2-10/2')
    assert lm.start == 2
    assert lm.end == 10
    assert lm.stride == 2
    assert lm.format == "%d"

    lm.reset()


# Generated at 2022-06-21 06:30:56.564810
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    try:
        result = LookupModule().reset()
        assert type(result) == None,\
            "Unable to reset result"
    except Exception as e:
        assert False,\
            "Unexpected exception raised in test for method reset of class LookupModule: " + str(e)


# Generated at 2022-06-21 06:31:00.993892
# Unit test for constructor of class LookupModule
def test_LookupModule():
   assert LookupModule()

# Generated at 2022-06-21 06:31:11.679894
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.stride = 1
    lookup_module.start = 0
    lookup_module.end = 10
    lookup_module.sanity_check()
    lookup_module.stride = -1
    lookup_module.sanity_check()

    lookup_module.stride = 0
    lookup_module.sanity_check()

    lookup_module.stride = 1
    lookup_module.end = 10
    lookup_module.count = 20
    lookup_module.sanity_check()
    lookup_module.stride = -1
    lookup_module.sanity_check()
    lookup_module.stride = 0
    lookup_module.sanity_check()

    lookup_module.count = 0
    lookup_module.sanity_check()


# Generated at 2022-06-21 06:31:19.398771
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.start == 1
    assert lookup_module.count == None
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"


# Generated at 2022-06-21 06:31:33.804299
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    seq = LookupModule()

    seq.format = "%d"
    seq.stride = 1
    seq.start = 0
    seq.end = 5

    results = seq.generate_sequence()
    assert list(results) == ["0", "1", "2", "3", "4", "5"]

    seq.format = "%04d"
    seq.stride = 2
    seq.start = 0
    seq.end = 10

    results = seq.generate_sequence()
    assert list(results) == ["0000", "0002", "0004", "0006", "0008", "0010"]

    seq.format = "0x%x"
    seq.stride = -2
    seq.start = 10
    seq.end = 0

    results = seq.generate_sequence()

# Generated at 2022-06-21 06:31:44.347465
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lu = LookupModule()
    lu.start = 1
    lu.count = None
    lu.end = 10
    lu.stride = 2
    lu.format = "%d"
    gen = lu.generate_sequence()
    assert next(gen) == "1"
    assert next(gen) == "3"
    assert next(gen) == "5"
    assert next(gen) == "7"
    assert next(gen) == "9"
    try:
        next(gen)
    except StopIteration:
        pass
    else:
        assert False, "StopIteration should be triggered by next"



# Generated at 2022-06-21 06:31:49.056196
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    val = LookupModule()
    val.start = 5
    val.count = None
    val.end = None
    val.stride = 1
    val.format = "%d"
    val.reset()
    assert (val.start == 1)
    assert (val.count == None)
    assert (val.end == None)
    assert (val.stride == 1)
    assert (val.format == "%d")



# Generated at 2022-06-21 06:31:53.557907
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()

    # Test a valid string, return True.
    assert True == lm.parse_simple_args("1-10/2")
    assert (1, 10, 2) == (lm.start, lm.end, lm.stride)

    # Test a different valid string, return True.
    assert True == lm.parse_simple_args("5-8")
    assert (5, 8, 1) == (lm.start, lm.end, lm.stride)

    # Test a valid forma

# Generated at 2022-06-21 06:32:09.802351
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    config_args = "count=4"
    lookup = LookupModule()
    lookup.parse_kv_args(parse_kv(config_args))
    assert(lookup.start == 1)
    assert(lookup.end == 4)
    assert(lookup.count == 4)
    assert(lookup.stride == 1)
    assert(lookup.format == "%d")

    config_args = "start=10 end=0 stride=-1"
    lookup = LookupModule()
    lookup.parse_kv_args(parse_kv(config_args))
    assert(lookup.start == 10)
    assert(lookup.end == 0)
    assert(lookup.count == None)
    assert(lookup.stride == -1)
    assert(lookup.format == "%d")



# Generated at 2022-06-21 06:32:12.457134
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    try:
        lookup.sanity_check()
        assert False, "Expected error"
    except AnsibleError:
        pass

# Generated at 2022-06-21 06:32:24.333517
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # The following are test cases for the generate_sequence() method
    class TestLookupModule(LookupModule):
        start = None
        end = None
        stride = None
        format = "%d"

        def generate_sequence(self):
            return super(TestLookupModule, self).generate_sequence()


# Generated at 2022-06-21 06:32:36.606688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

# Generated at 2022-06-21 06:32:38.113037
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert(lookup_plugin != None)

# Generated at 2022-06-21 06:32:45.049274
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    lm.start = 10
    lm.end = 20
    lm.count = 30
    lm.stride = 40
    lm.format = '%d2'
    lm.reset()
    assert lm.start == 1
    assert lm.end is None
    assert lm.count is None
    assert lm.stride == 1
    assert lm.format == '%d'


# Generated at 2022-06-21 06:32:55.764810
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # Test one formula which is correct
    term = "start=1 end=5"
    LookupModule.parse_kv_args(LookupModule(), term)

    # Test one formula which is incorrect
    try:
        term = "start=a"
        LookupModule.parse_kv_args(LookupModule(), term)
    except AnsibleError:
        assert True
    else:
        raise Exception

    # Test one formula which is incorrect
    try:
        term = "start=1 end=a"
        LookupModule.parse_kv_args(LookupModule(), term)
    except AnsibleError:
        assert True
    else:
        raise Exception


# Generated at 2022-06-21 06:33:06.322016
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    class test_LookupModule(LookupModule):
        def __init__(self, arguments):
            self.start = 0
            self.count = None
            self.end = None
            self.stride = 0
            self.format = "%d"

    lookup = test_LookupModule(None)

    # count and end:
    lookup.count = 1
    lookup.end = 1
    try:
        lookup.sanity_check()
    except AnsibleError:
        pass
    else:
        assert False

    # count / end:
    lookup.count = None
    lookup.end = None
    try:
        lookup.sanity_check()
    except AnsibleError:
        pass
    else:
        assert False

    # stride > 0, end < start:
    lookup.count = None

# Generated at 2022-06-21 06:33:15.184687
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    lookup_module.parse_simple_args("0x00-0x64/0x0a:host%02d")
    assert lookup_module.start == 0
    assert lookup_module.end == 100
    assert lookup_module.stride == 10
    assert lookup_module.format == "host%02d"
    # reset
    lookup_module.parse_simple_args("01-0x64/10:host%02d")
    assert lookup_module.start == 1
    assert lookup_module.end == 100
    assert lookup_module.stride == 10
    assert lookup_module.format == "host%02d"
    # reset
    lookup_module.parse_simple_args("1-100/10:host%02d")
    assert lookup_module.start == 1
   

# Generated at 2022-06-21 06:33:23.666698
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    lm.start = 1
    lm.count = None
    lm.end = None
    lm.stride = 1
    lm.format = "%d"
    lm.reset()
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == None
    assert lm.stride == 1
    assert lm.format == "%d"


# Generated at 2022-06-21 06:33:31.634242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["start=3 end=14 stride=2", "start=3 count=5 stride=2"]
    variables = dict()
    lookup_module = LookupModule()
    assert len(lookup_module.run(terms, variables)) == 5


# Generated at 2022-06-21 06:33:34.908958
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    arguments = {'start': '10', 'end': '22', 'stride': '3', 'format': 'user%d'}
    l = LookupModule()
    l.parse_kv_args(arguments)
    assert l.start == 10
    assert l.end == 22
    assert l.stride == 3
    assert l.format == 'user%d'


# Generated at 2022-06-21 06:33:41.542781
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    print("Testing method parse_simple_args of class LookupModule.")
    lm = LookupModule()

# Generated at 2022-06-21 06:33:44.495198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)

# Generated at 2022-06-21 06:33:54.942716
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    # Check default values
    l = LookupModule()
    l.reset()
    assert l.start == 1
    assert l.end == None
    assert l.stride == 1
    assert l.format == "%d"

    # Check values according to shortcut format
    # [start-]end[/stride][:format]
    l = LookupModule()
    l.reset()
    assert l.start == 1
    assert l.end == None
    assert l.stride == 1
    assert l.format == "%d"
    # 5 -> ["1","2","3","4","5"]
    l.parse_simple_args("5")
    assert l.start == 1
    assert l.end == 5
    assert l.stride == 1
    assert l.format == "%d"
    # 5-8 -> ["5

# Generated at 2022-06-21 06:33:56.013958
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 06:34:03.399503
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    import os
    import ast
    import sys

    test_dir = os.path.dirname(__file__)
    test_file = os.path.join(test_dir, "with_sequence_test.py")

    with open(test_file) as f:
        test_code = f.read()

    tree = ast.parse(test_code)
    test_classes = [node for node in tree.body if isinstance(node, ast.ClassDef)]
    cls = test_classes[0]

    cls_obj = cls()
    cls_test_methods = [node.name for node in cls.body if isinstance(node, ast.FunctionDef)]
    for method_name in cls_test_methods:
        if method_name.startswith('test_'):
            getattr

# Generated at 2022-06-21 06:34:14.995107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testcase 1
    # terms is string will be parsed by LookupModule.parse_simple_args
    # expected result is a list of items generated by using arguments
    # start, end, stride and format
    terms = '0-32/4:testuser%02x'
    variables = {}
    expected_result = ['testuser00', 'testuser04', 'testuser08', 'testuser0c', 'testuser10', 'testuser14', 'testuser18', 'testuser1c']
    actual_result = LookupModule().run(terms, variables)
    assert expected_result == actual_result

    # Testcase 2
    terms = '5-8'
    variables = {}
    expected_result = ['5', '6', '7', '8']
    actual_result = LookupModule().run(terms, variables)


# Generated at 2022-06-21 06:34:15.595297
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:34:23.737218
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    import ast

    class T(object):
        pass

    test = T()
    test.lookup = LookupModule()
    test.lookup.parse_kv_args(ast.literal_eval('{}'))
    assert test.lookup.start == 1
    assert test.lookup.count == None
    assert test.lookup.end == None
    assert test.lookup.stride == 1
    assert test.lookup.format == "%d"

    test = T()
    test.lookup = LookupModule()
    test.lookup.parse_kv_args(ast.literal_eval('{"start":0}'))
    assert test.lookup.start == 0
    assert test.lookup.count == None
    assert test.lookup.end == None

# Generated at 2022-06-21 06:34:37.553953
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    self = LookupModule()
    self.reset()
    if self.start != 1:
        raise Exception("start default not 1: %s" % self.start)
    if self.count != None:
        raise Exception("count default not None: %s" % self.count)
    if self.end != None:
        raise Exception("end default not None: %s" % self.end)
    if self.stride != 1:
        raise Exception("stride default not 1: %s" % self.stride)
    if self.format != "%d":
        raise Exception("format default not %%d: %s" % self.format)


# Generated at 2022-06-21 06:34:41.664174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Declare variables
    lookup_module = LookupModule()
    # Test with simple argument
    lookup_module.run([ "1-10" ])
    # Test with key-value argument
    lookup_module.run([ "start=1", "end=10" ])

# Generated at 2022-06-21 06:34:45.901977
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    args = dict(start=0x0f00, count=4, format='%04x')
    start = 0x0f00
    stride = 1
    end = start + stride * args['count'] - 1
    ret_format = args['format']

    lm = LookupModule()
    lm.parse_kv_args(args)
    assert lm.start == start
    assert lm.end == end
    assert lm.format == ret_format


# Generated at 2022-06-21 06:34:56.757144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    sequence_lookup = LookupModule()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    options = {}

    # Generate sequence of ints
    sequence_lookup.run(['start=1 end=3'], variables={}, **options) == ['1', '2', '3']
    sequence_lookup.run(['start=1 end=3 format=%d'], variables={}, **options) == ['1', '2', '3']

# Generated at 2022-06-21 06:35:06.673411
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    try:
        lookup = LookupModule()
        lookup.end = 5
        lookup.start = 0
        lookup.stride = 1
        lookup.sanity_check()
        lookup.end = 8
        lookup.sanity_check()
        lookup.stride = -1
        lookup.sanity_check()
        lookup.stride = 1
        lookup.start = 10
        lookup.sanity_check()
        lookup.end = 6
        lookup.sanity_check()
        lookup.stride = -1
        lookup.sanity_check()
        lookup.end = 10
        lookup.sanity_check()
        lookup.start = 8
        lookup.sanity_check()
    except AnsibleError as e:
        assert False, e
    assert True


# Generated at 2022-06-21 06:35:18.933173
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    """Method sanity_check should raise AnsibleError if a sanity check fails."""
    lm = LookupModule()
    lm.start = 0
    lm.count = 1
    lm.end = None
    lm.stride = 1
    try:
        lm.sanity_check()
        assert False, "count and end both none did not raise AnsibleError"
    except AnsibleError: pass

    lm.reset()
    lm.start = 0
    lm.count = 1
    lm.end = 1
    lm.stride = 1
    try:
        lm.sanity_check()
        assert False, "count and end both not none did not raise AnsibleError"
    except AnsibleError: pass

    lm.reset()
    lm.start = 1
    l

# Generated at 2022-06-21 06:35:29.182378
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """lookup_plugins/sequence.py - test parse_simple_args"""
    print("lookup_plugins/sequence.py - test parse_simple_args")

    lookup_module = LookupModule()

    result = lookup_module.parse_simple_args('0')
    assert result is True, \
        "parse_simple_args('0') returned %r" % result

    result = lookup_module.parse_simple_args('5-8')
    assert result is True, \
        "parse_simple_args('5-8') returned %r" % result

    result = lookup_module.parse_simple_args('2-10/2')
    assert result is True, \
        "parse_simple_args('2-10/2') returned %r" % result


# Generated at 2022-06-21 06:35:32.143310
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    lm.reset()
    assert lm.start == 1
    assert lm.count is None
    assert lm.end is None
    assert lm.stride == 1
    assert lm.format == "%d"


# Generated at 2022-06-21 06:35:37.465236
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import random
    lookup = LookupModule()
    lookup.count = None
    lookup.end = None
    lookup.stride = 1
    for i in range(1, 100):
        lookup.start = random.randint(1, 100)
        lookup.end = random.randint(1, 200)
        if lookup.end == lookup.start:
            lookup.count = random.randint(1, 1000)
        else:
            lookup.count = None
        try:
            lookup.sanity_check()
            assert not (lookup.count is not None and lookup.end is not None)
            assert not (lookup.count is None and lookup.end is None)
            assert lookup.stride != 0
        except AssertionError:
            assert False
    lookup.start = random.randint(1, 100)


# Generated at 2022-06-21 06:35:48.925466
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()

# Generated at 2022-06-21 06:35:58.057803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None
    return l


# Generated at 2022-06-21 06:36:08.635634
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()

    lookup_module.parse_simple_args('5')
    assert(lookup_module.start == 1 and lookup_module.end == 5 and lookup_module.stride == 1 and lookup_module.format == '%d')

    lookup_module.parse_simple_args('5-8')
    assert(lookup_module.start == 5 and lookup_module.end == 8 and lookup_module.stride == 1 and lookup_module.format == '%d')

    lookup_module.parse_simple_args('2-10/2')
    assert(lookup_module.start == 2 and lookup_module.end == 10 and lookup_module.stride == 2 and lookup_module.format == '%d')

    lookup_module.parse_simple_args('5-11/2')

# Generated at 2022-06-21 06:36:17.288245
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    class TestLookupModule(LookupModule):
        def __init__(self):
            self.start = -1
            self.count = -1
            self.end = -1
            self.stride = -1
            self.format = -1
        def run(self, *args, **kwargs):
            return [self.start, self.count, self.end, self.stride, self.format]

    lookup = TestLookupModule()
    lookup.parse_kv_args(parse_kv("start=1 count=2 format=3"))
    assert lookup.run() == [1, 2, -1, -1, '3']

    lookup = TestLookupModule()
    lookup.parse_kv_args(parse_kv("start=1 end=2 stride=3 format=4"))
    assert lookup

# Generated at 2022-06-21 06:36:23.401396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run([], []) == []
    assert lm.run([""], []) == []
    assert lm.run(["bad"], []) == []
    assert lm.run(["bad"], []) == []
    assert lm.run([":bad"], []) == []
    assert lm.run(["bad:"], []) == []
    assert lm.run(["bad:bad"], []) == []
    assert lm.run(["-1"], []) == []
    assert lm.run(["1///"], []) == []
    assert lm.run(["count=foo"], []) == []

    assert lm.run(["4-"], []) == []
    assert lm.run(["4-6/"], []) == []

# Generated at 2022-06-21 06:36:29.690787
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule(None)
    lookup.start = 0
    lookup.count = 0
    lookup.end = 0
    lookup.stride = 0
    lookup.format = '%d'
    lookup.reset()

    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == '%d'


# Generated at 2022-06-21 06:36:39.437667
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lm = LookupModule()
    lm.stride = 1
    
    lm.stride = 10
    lm.start = 0
    lm.end = 15
    try:
        lm.sanity_check()
    except AnsibleError as e:
        assert False, "sanity_check failed! with {0}".format(str(e))
    else:
        assert True, "sanity_check succeeded!"

    lm.stride = -10
    lm.start = 15
    lm.end = 0
    try:
        lm.sanity_check()
    except AnsibleError as e:
        assert False, "sanity_check failed! with {0}".format(str(e))
    else:
        assert True, "sanity_check succeeded!"


# Generated at 2022-06-21 06:36:48.070128
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run([], {})

    assert lookup_module.start is None, "start should be None"
    assert lookup_module.count is None, "count should be None"
    assert lookup_module.end is None, "end should be None"
    assert lookup_module.stride is None, "stride should be None"
    assert lookup_module.format is None, "format should be None"



# Generated at 2022-06-21 06:36:53.597524
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 0
    lookup.end = 10
    lookup.count = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.reset()
    assert lookup.start == 1
    assert lookup.end == 0
    assert lookup.count == 0
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:36:56.883681
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    sequence = LookupModule()
    sequence.start = 1
    sequence.count = 1
    sequence.stride = 1
    sequence.format = "%d"
    sequence.sanity_check()
    # TODO: add more unit tests!

# Generated at 2022-06-21 06:37:04.610566
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.reset()
    # Test end
    lookup_module.end = 3
    lookup_module.sanity_check()
    # Test count
    lookup_module.end = None
    lookup_module.count = 2
    lookup_module.sanity_check()
    # Test both
    lookup_module.end = 3
    lookup_module.count = 2
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        pass
    else:
        assert(False)
    # Test end / count 0
    lookup_module.end = 0
    lookup_module.count = 0
    lookup_module.sanity_check()
    # Test stride > 0 and end < start
    lookup_module.end = 0

# Generated at 2022-06-21 06:37:16.140287
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.start == 1
    assert lookup_module.count == None
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"