

# Generated at 2022-06-21 06:27:39.121479
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    """
    Unit tests for method generate_sequence of class LookupModule
    """
    from ansible.plugins.lookup import LookupModule
    # Test positive start, positive end and positive stride
    positive_start_positive_end_positive_stride = LookupModule()
    positive_start_positive_end_positive_stride.start = 1
    positive_start_positive_end_positive_stride.end = 23
    positive_start_positive_end_positive_stride.stride = 1
    positive_start_positive_end_positive_stride.format = "%d"

# Generated at 2022-06-21 06:27:42.662568
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    module = LookupModule()
    assert module.start == 1
    assert module.count is None
    assert module.end is None
    assert module.stride == 1
    assert module.format == "%d"


# Generated at 2022-06-21 06:27:54.989385
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    class LmMock(LookupModule):
        def reset(self):
            self.start = None
            self.end = None
            self.stride = 1
            self.format = "%d"

        def parse_simple_args(self, term):
            match = SHORTCUT.match(term)
            if not match:
                return False

            _, start, end, _, stride, _, format = match.groups()

            if start is not None:
                self.start = start
            if end is not None:
                self.end = end
            if stride is not None:
                self.stride = stride
            if format is not None:
                self.format = format

            return True


# Generated at 2022-06-21 06:28:04.026494
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    testLookupModule = LookupModule()
    testLookupModule.start = 3
    testLookupModule.count = 5
    testLookupModule.end = 10
    testLookupModule.stride = 7
    testLookupModule.format = '%s'
    testLookupModule.reset()
    assert(testLookupModule.start == 1)
    assert(testLookupModule.count == None)
    assert(testLookupModule.end == None)
    assert(testLookupModule.stride == 1)
    assert(testLookupModule.format == '%d')


# Generated at 2022-06-21 06:28:11.339143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test Case 1
    lookup_module = LookupModule()
    terms = ["start=5 end=6", "start=5 end=6", "start=5 end=6"]
    variables = None
    output = lookup_module.run(terms, variables, **None)
    assert output == ['5', '6', '6']

    # Test Case 2
    lookup_module = LookupModule()
    terms = ["start=5", "start=5", "start=5"]
    variables = None
    output = lookup_module.run(terms, variables, **None)
    assert output == ['5']

    # Test Case 3
    lookup_module = LookupModule()
    terms = ["start=2 end=10 stride=2", "start=2 end=10 stride=2", "start=2 end=10 stride=2"]
   

# Generated at 2022-06-21 06:28:15.450167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.start == 1
    assert lm.stride == 1
    assert lm.end is None
    assert lm.count is None
    assert lm.format == "%d"


# Generated at 2022-06-21 06:28:25.021731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('LookupModule.run(terms) expects that terms is a list of strings and returns a resulting list of items')
    print('  and expects the following sequence of tests to pass')
    # Test 1: Expecting that the following Expecting that the following
    # expected and actual sequence will be the same:
    print('Test 1 - expected and actual sequence will be the same:')
    initial_terms = ['end=10']
    initial_vars = []
    expected = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
    actual = LookupModule().run(initial_terms, initial_vars)
    print('  expected:', expected)
    print('  actual:', actual)

    # Test 2: Expecting that the following Expecting that the following
    # expected

# Generated at 2022-06-21 06:28:28.507379
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    g = LookupModule()
    g.reset()
    assert g.start == 1
    assert g.count is None
    assert g.end is None
    assert g.stride == 1
    assert g.format == "%d"


# Generated at 2022-06-21 06:28:39.845951
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    results = []
    lookup_module.start = 2
    lookup_module.end = 10
    lookup_module.stride = 2
    results.extend(lookup_module.generate_sequence())

    assert(results == ['2', '4', '6', '8', '10'])

    lookup_module = LookupModule()
    lookup_module.start = 2
    lookup_module.end = 9
    lookup_module.stride = 2
    results.extend(lookup_module.generate_sequence())

    assert(results == ['2', '4', '6', '8', '10', '2', '4', '6', '8'])

# Generated at 2022-06-21 06:28:45.616645
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    # Missing arguments
    lookup.reset()
    try:
        lookup.sanity_check()
    except AnsibleError:
        pass
    else:
        raise Exception("end/count not specified")
    # Both count and end specified
    lookup.reset()
    lookup.count = 5
    lookup.end = 10
    try:
        lookup.sanity_check()
    except AnsibleError:
        pass
    else:
        raise Exception("both count and end")
    # Negative stride
    lookup.reset()
    lookup.stride = -1
    lookup.count = 5
    try:
        lookup.sanity_check()
    except AnsibleError:
        pass
    else:
        raise Exception("negative stride")
    # Positive stride up
    lookup.reset()

# Generated at 2022-06-21 06:29:02.288929
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule(None, None, {}, {})

    lookup.reset()
    lookup.parse_kv_args({'start': '5'})
    assert lookup.start == 5
    assert lookup.end == 0
    assert lookup.stride == 1
    assert lookup.format == '%d'

    lookup.reset()
    lookup.parse_kv_args({'start': '5', 'end': '10'})
    assert lookup.start == 5
    assert lookup.end == 10
    assert lookup.stride == 1
    assert lookup.format == '%d'

    lookup.reset()
    lookup.parse_kv_args({'start': '5', 'end': '10', 'format': '%02x'})
    assert lookup.start == 5
    assert lookup.end == 10
    assert lookup

# Generated at 2022-06-21 06:29:09.297866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with_sequence
    test_param = ('start=1 end=5')
    lookup = LookupModule()
    result = lookup.run(terms=[test_param], variables=None, **{})
    assert result == ['1', '2', '3', '4', '5']

    test_param = ('start=1 end=5')
    lookup = LookupModule()
    result = lookup.run(terms=[test_param], variables=None, **{})
    assert result == ['1', '2', '3', '4', '5']

    test_param = ('start=0 end=10 stride=2')
    lookup = LookupModule()
    result = lookup.run(terms=[test_param], variables=None, **{})

# Generated at 2022-06-21 06:29:13.673621
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # case: run with jinja environment
    lm = LookupModule()
    lm.run([], dict())

    # case: run without jinja environment
    lm = LookupModule()
    lm.run([], dict(), variables={})

# Generated at 2022-06-21 06:29:25.042265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Importing all methods/classes of ansible.plugins.lookup.sequence to avoid import error
    import ansible.plugins.lookup.sequence
    
    print('Testing run() of class LookupModule from ansible.plugins.lookup.sequence')
    # Defining arguments.
    terms = [
        '2-10/2',
        '4:host%02d',
        'start=5 end=11 stride=2 format=0x%02x',
        'start=0x0f00 count=4 format=%04x',
        'start=0 count=5 stride=2',
        'start=1 count=5 stride=2',
        'count=5',
    ]
    variables = {}
    l = LookupModule(terms, variables)
    result = l.run(terms, variables)

# Generated at 2022-06-21 06:29:28.379767
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.start == 1
    assert lm.count is None
    assert lm.end is None
    assert lm.stride == 1
    assert lm.format == "%d"

# Generated at 2022-06-21 06:29:41.838446
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    """
    generate_sequence method - sequence of numbers

    User can define a sequence of items. If the end is less than the start
    then the sequence will be in reverse order. If stride is negative, then the
    start must be greater than the end.
    """
    lookup = LookupModule()

    # positive integers
    lookup.start = 0
    lookup.end = 5
    lookup.stride = 1
    lookup.format = "%d"

    assert list(lookup.generate_sequence()) == [
        '0', '1', '2', '3', '4', '5'
    ]

    # negative integers
    lookup.start = -5
    lookup.end = 0
    lookup.stride = 1
    lookup.format = "%d"


# Generated at 2022-06-21 06:29:53.494962
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()
    l.start = 0
    l.end = 10
    l.stride = 1
    l.format = "%d"
    assert(list(l.generate_sequence()) == ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"])

    l.start = 0
    l.end = 10
    l.stride = 2
    l.format = "%d"
    assert(list(l.generate_sequence()) == ["0", "2", "4", "6", "8", "10"])

    l.start = 0
    l.end = -10
    l.stride = -2
    l.format = "%d"

# Generated at 2022-06-21 06:29:57.126720
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    l = LookupModule()
    l.parse_kv_args(parse_kv("start=5 end=10"))
    assert l.start == 5
    assert l.end == 10
    assert l.stride == 1

# Generated at 2022-06-21 06:30:07.132773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    # python2
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    # python3
    else:
        import builtins
    real_open = builtins.open
    builtins.open = None

    # Create a class object with empty function body
    lookup_class = LookupModule()

    #Create a dict to store class variables
    lookup_class.reset()

    # Assign values to the class variables
    lookup_class.end = 5
    lookup_class.start = 1

    #Create a dict to store function arguments
    terms = ['1-5']

    # Importing module_utils is required for utils function
    from ansible.module_utils.six.moves import builtins
    # Create an object for module_utils
    import_module = builtins

# Generated at 2022-06-21 06:30:18.622993
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    assert lookup_module.start == 1
    assert lookup_module.count == None
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"

    # Test with good input
    terms = {
        'start': '5',
        'end': '11',
        'stride': '2',
        'format': '%d'
    }
    try:
        lookup_module.parse_kv_args(terms)
    except AnsibleError:
        assert False
    else:
        assert lookup_module.start == 5
        assert lookup_module.count == None
        assert lookup_module.end == 11
        assert lookup_module.stride == 2
        assert lookup_module.format == "%d"



# Generated at 2022-06-21 06:30:30.575465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for LookupModule constructor
    """
    lm = LookupModule()
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == None
    assert lm.stride == 1
    assert lm.format == "%d"

# Generated at 2022-06-21 06:30:42.561556
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()
    l.start = 1
    l.end = 10
    l.stride = 2
    l.format = "%d"
    assert list(l.generate_sequence()) == ['1', '3', '5', '7', '9']
    l.start = 10
    l.end = 1
    l.stride = -2
    assert list(l.generate_sequence()) == ['10', '8', '6', '4', '2']
    l.start = 10
    l.end = 20
    l.stride = 2
    assert list(l.generate_sequence()) == ['10', '12', '14', '16', '18', '20']
    l.start = 20
    l.end = 10
    l.stride = -2

# Generated at 2022-06-21 06:30:44.005311
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print( LookupModule() )
    assert True


# Generated at 2022-06-21 06:30:53.930054
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    test_terms = ["start=1 end=5", "start=1 end=5 format=test%02d",
                  "start=0xff00 count=4 format=%04x",
                  "start=1 end=3 stride=2", "start=0 end=4",
                  "start=0 end=4 stride=2", "start=1 count=4",
                  "start=0xff00 count=4 format=0x%04x", "start=10 end=0 stride=-1",
                  ]
    lookup_plugin.run(test_terms, variables=None)


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:31:05.910450
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()

    lm.reset()
    assert lm.parse_simple_args("5") == True
    assert lm.start == 1
    assert lm.end == 5
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()
    assert lm.parse_simple_args("5-8") == True
    assert lm.start == 5
    assert lm.end == 8
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()
    assert lm.parse_simple_args("2-10/2") == True
    assert lm.start == 2
    assert lm.end == 10
    assert lm.stride == 2

# Generated at 2022-06-21 06:31:13.101526
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()

    assert lookup.parse_simple_args("5") == True
    assert lookup.start == 1
    assert lookup.end == 5
    assert lookup.stride == 1
    assert lookup.format == "%d"

    assert lookup.parse_simple_args("5-8") == True
    assert lookup.start == 5
    assert lookup.end == 8
    assert lookup.stride == 1
    assert lookup.format == "%d"

    assert lookup.parse_simple_args("2-10/2") == True
    assert lookup.start == 2
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == "%d"

    assert lookup.parse_simple_args("4:host%02d") == True
    assert lookup.start == 4
   

# Generated at 2022-06-21 06:31:24.815487
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lm = LookupModule()
    lm.count = None
    lm.end = None
    lm.start = 1
    lm.stride = 2
    try:
        lm.sanity_check()
        assert False
    except AnsibleError:
        pass

    lm.end = 3
    try:
        lm.sanity_check()
        assert True
    except AnsibleError:
        assert False

    lm.count = 1
    try:
        lm.sanity_check()
        assert False
    except AnsibleError:
        pass

    lm.end = None
    try:
        lm.sanity_check()
        assert True
    except AnsibleError:
        assert False

    lm.stride = 3
    lm.start = 3
    l

# Generated at 2022-06-21 06:31:25.820320
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-21 06:31:38.571226
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    x = LookupModule()

    # start, end, stride and format
    assert x.parse_simple_args("5-8") == True
    assert x.start == 5
    assert x.end == 8
    assert x.stride == 1
    assert x.format == '%d'

    assert x.parse_simple_args("5-8/2") == True
    assert x.start == 5
    assert x.end == 8
    assert x.stride == 2
    assert x.format == '%d'

    assert x.parse_simple_args("4:host%02d") == True
    assert x.start == 4
    assert x.end == 5
    assert x.stride == 1
    assert x.format == 'host%02d'

    # start and format
    assert x.parse_simple_args

# Generated at 2022-06-21 06:31:49.126690
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lm = LookupModule()

    # Simple parsing
    lm.parse_kv_args({'start': '2', 'count': '10', 'stride': '1', 'format': '%02x'})
    assert lm.start == 2
    assert lm.count == 10
    assert lm.stride == 1
    assert lm.format == '%02x'

    # With negative stride
    lm.parse_kv_args({'start': '5', 'count': '4', 'stride': '-2'})
    assert lm.start == 5
    assert lm.count == 4
    assert lm.stride == -2
    assert lm.format == '%d'

    # With negative end

# Generated at 2022-06-21 06:32:00.151219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """test if the output of lookup is generated as expected"""
    lookup = LookupModule()
    terms = ['start=1 end=3']
    variables = None
    data = lookup.run(terms=terms, variables=variables)
    assert data == ['1', '2', '3']
    terms = ['start=1 count=2']
    data = lookup.run(terms=terms, variables=variables)
    assert data == ['1', '2']
    terms = ['1', '3-4', '4:host%02d']
    data = lookup.run(terms=terms, variables=variables)
    assert data == ['1', '3', '4', 'host04']
    terms = ['1-5/2']
    data = lookup.run(terms=terms, variables=variables)

# Generated at 2022-06-21 06:32:04.660860
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    lm.reset()
    assert (lm.format == "%d")
    assert (lm.stride == 1)
    assert (lm.end is None)
    assert (lm.count is None)
    assert (lm.start == 1)


# Generated at 2022-06-21 06:32:17.382938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestVariables(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    lookup_module = LookupModule()

    # with_sequence
    result = lookup_module.run(
        [
            'start=0x0f00 count=4 format=%04x',
            'start=0 end=5',
            '-1-10/2',
            '4:host%02d',
            'start=4 end=16 stride=2',
            'start=1 end="{{ end_at }}"'
        ],
        TestVariables(
            end_at=10
        )
    )

# Generated at 2022-06-21 06:32:25.464282
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    assert "end must be greater than start for positive strides" in LookupModule(None, None).run(["start=4 end=2 stride=1"], None)[0]
    assert "end must be smaller than start for negative strides" in LookupModule(None, None).run(["start=4 end=6 stride=-1"], None)[0]
    assert "must specify count or end in with_sequence" in LookupModule(None, None).run(["start=0 end=10"], None)[0]
    assert "can't specify both count and end in with_sequence" in LookupModule(None, None).run(["start=0 end=10 count=20"], None)[0]
    assert "to count backwards make stride negative" in LookupModule(None, None).run(["start=4 end=2"], None)[0]

# Generated at 2022-06-21 06:32:26.718579
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    assert LookupModule().start == 1


# Generated at 2022-06-21 06:32:37.525027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method run of module ansible_collections.notstdlib.moveitallout.plugins.lookup.sequence"""

    # Run with terms (["1-10"], [], {})
    def func(terms):
        module = LookupModule()
        results = module.run(terms, {})
        # The expected result is a list
        assert isinstance(results, list)
        # The list contains 10 items
        assert len(results) == 10
        # The list has the expected content
        assert results == ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']

    func(["1-10"])

    # Run with terms (["1-10", "11-20"], [], {})
    def func(terms):
        module = LookupModule()


# Generated at 2022-06-21 06:32:47.584397
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()
    
    # Test correct inputs
    assert( lm.parse_simple_args('10') )
    assert( lm.start == 1 and lm.end == 10 and lm.stride == 1 
            and lm.format == "%d" and lm.count == None)
    
    assert( lm.parse_simple_args('0x0a') )
    assert( lm.start == 1 and lm.end == 10 and lm.stride == 1 
            and lm.format == "%d" and lm.count == None)
    
    assert( lm.parse_simple_args('0xa') )

# Generated at 2022-06-21 06:32:53.177694
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    start = 0
    end = 9
    stride = 1
    format = "%d"
    lm = LookupModule()
    lm.start = start
    lm.end = end
    lm.stride = stride
    lm.format = format

    numbers = [str(x) for x in range (start, end+stride, stride)]
    assert(list(lm.generate_sequence()) == numbers)


# Generated at 2022-06-21 06:32:54.381276
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-21 06:33:04.517940
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()
    
    # First check, immidiate after constructor call
    assert lookup_module.start == 1, 'start should be set to 1'
    assert lookup_module.count is None, 'count should be None'
    assert lookup_module.end is None, 'end should be None'
    assert lookup_module.stride == 1, 'stride should be set to 1'
    assert lookup_module.format == '%d', 'format should be set to %d'
    
    # Next, set values, and check reset
    lookup_module.start = 2
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = 2
    lookup_module.format = '%f'
    
    lookup_module.reset()
    assert lookup_module.start

# Generated at 2022-06-21 06:33:15.389993
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.start = 0
    lookup_module.end = 5
    lookup_module.stride = 1
    lookup_module.format = "%d"


# Generated at 2022-06-21 06:33:26.454646
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import random

# Generated at 2022-06-21 06:33:37.134688
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    class FakeLookupModule(LookupModule):
        def __init__(self):
            self._args = None
        def parse_kv_args(self, args):
            self.args = args
    lookup = FakeLookupModule()
    terms = [
        "",
        "start=5",
        "end=10",
        "stride=2",
        "format=%02d",
        "start=5 end=10 stride=2 format=%02d"
    ]
    for term in terms:
        lookup.parse_kv_args(parse_kv(term))
        myargs = dict(start=1, end=None, count=None, stride=1, format="%d")
        if "start=5" in term:
            myargs["start"] = 5

# Generated at 2022-06-21 06:33:46.268456
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.reset()
    args = {
        'start': '0',
        'end': '1',
        'stride': '1',
        'format': 'test%s'
    }
    lookup_module.parse_kv_args(args)
    assert lookup_module.start == 0
    assert lookup_module.end == 1
    assert lookup_module.stride == 1
    assert lookup_module.format == 'test%s'


# Generated at 2022-06-21 06:33:49.132304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = None
    variables = None
    lookupobj = LookupModule(terms, variables)
    print(lookupobj.run)

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:33:59.155323
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # Start with a generic LookupModule object
    lookupModule = LookupModule()
    # Make sure that the sequence plugin is loaded
    assert hasattr(lookupModule,'run')
    # Make sure that the sequence plugin does not fail without arguments
    assert lookupModule.run([''], None) == []

    # Test a typical use
    args = {'start': '1', 'end': '10', 'format': 'testuser%02x'}
    assert not hasattr(lookupModule, 'start')
    assert not hasattr(lookupModule, 'end')
    assert not hasattr(lookupModule, 'format')
    lookupModule.parse_kv_args(args)
    assert lookupModule.start == 1
    assert lookupModule.end == 10
    assert lookupModule.format == 'testuser%02x'
    assert not has

# Generated at 2022-06-21 06:34:10.659730
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # It should return an error if count is specified and end is specified
    lookup = LookupModule()
    lookup.count = 10
    lookup.end = 0
    result = lookup.sanity_check()
    assert result == AnsibleError("can't specify both count and end in with_sequence")

    # It should return an error if count is specified and stride is negative
    lookup = LookupModule()
    lookup.count = -10
    result = lookup.sanity_check()
    assert result == AnsibleError("to count backwards make stride negative")

    # It should return an error if end is specified and stride is negative
    lookup = LookupModule()
    lookup.end = -10
    lookup.stride = -1
    result = lookup.sanity_check()
    assert result == AnsibleError("to count forward don't make stride negative")

# Generated at 2022-06-21 06:34:15.270756
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 2
    lookup_module.end = 8
    lookup_module.stride = 2
    lookup_module.format = "%04d"
    assert list(lookup_module.generate_sequence()) == ['0002', '0004', '0006', '0008']

# Generated at 2022-06-21 06:34:23.524988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([], []) == []
    assert lookup.run(['1'], []) == ['1']
    assert lookup.run(['1-'], []) == ['1']
    assert lookup.run(['1-3'], []) == ['1', '2', '3']
    assert lookup.run(['1-3/2'], []) == ['1', '3']
    assert lookup.run(['1-9/4'], []) == ['1', '5', '9']
    assert lookup.run(['1-9/-4'], []) == []
    assert lookup.run(['1-9/-3'], []) == ['1', '4', '7']

# Generated at 2022-06-21 06:34:25.119381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-21 06:34:42.877070
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    from ansible_collections.aggressive.plugins.modules.lookup import LookupModule
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 3
    lookup.stride = 1
    lookup.format = "%d"
    if list(lookup.generate_sequence()) != [1, 2, 3]:
        raise Exception("failed test")
    lookup.start = 1
    lookup.end = 0
    lookup.stride = -1
    lookup.format = "%d"
    if list(lookup.generate_sequence()) != [1, 0]:
        raise Exception("failed test")
    lookup.start = 1
    lookup.end = 0
    lookup.stride = -1
    lookup.format = "one%03d"

# Generated at 2022-06-21 06:34:46.574780
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.reset()

    assert lookup.start is 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride is 1
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:34:50.628654
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()
    lookup_module.reset()
    assert lookup_module.start == 1
    assert lookup_module.count == None
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"


# Generated at 2022-06-21 06:35:02.844437
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()
    lookup.parse_simple_args("4:host%02d")
    assert lookup.start == 4
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == "host%02d"

    lookup.reset()
    lookup.parse_simple_args("start=5 end=10")
    assert lookup.start == 5
    assert lookup.end == 10
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_simple_args("3-8")
    assert lookup.start == 3
    assert lookup.end == 8
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_simple_args("8")

# Generated at 2022-06-21 06:35:12.615273
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    module = LookupModule()
    args = dict()

    # Case 1: empty arguments should leave the default values
    module.parse_kv_args(args)
    assert module.start == 1
    assert module.end == None
    assert module.stride == 1
    assert module.format == "%d"

    # Case 2: only "start" argument
    args = dict(start="10")
    module.parse_kv_args(args)
    assert module.start == 10
    assert module.end == None
    assert module.stride == 1
    assert module.format == "%d"

    # Case 3: only "end" argument
    args = dict(end="10")
    module.parse_kv_args(args)
    assert module.start == 1
    assert module.end == 10
    assert module.str

# Generated at 2022-06-21 06:35:19.164461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    args = [None, None, {'start': 6, 'end': 10, 'stride': 2, 'format': 'format'}]
    res = [u'format', u'format', u'format', u'format']
    # Act
    lookup_plugin = LookupModule()
    results = lookup_plugin.run(*args)
    # Assert
    assert results == res, 'results do not match'

# Generated at 2022-06-21 06:35:25.132734
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    assert list(LookupModule.generate_sequence(10, 1, 9, 1, "%d")) == ['1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert list(LookupModule.generate_sequence(8, 1, 9, -1, "%d")) == ['8', '7', '6', '5', '4', '3', '2', '1']
    assert list(LookupModule.generate_sequence(0, 1, 10, 2, "%d")) == ['0', '2', '4', '6', '8']
    assert list(LookupModule.generate_sequence(0, 1, 10, 4, "%d")) == ['0', '4', '8']

# Generated at 2022-06-21 06:35:33.744193
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    l = LookupModule()
    l.start = 0
    l.count = None
    l.end = None
    l.stride = 1
    l.format = "%d"
    test = l.sanity_check()
    assert test == "must specify count or end in with_sequence"

    l.end = 0
    test = l.sanity_check()
    assert test == None

    l.count = "a"
    test = l.sanity_check()
    assert test == "can't parse count=a as integer"

    l.count = 10
    l.end = 0
    test = l.sanity_check()
    assert test == "can't specify both count and end in with_sequence"

    l.end = None
    l.count = 5
    test = l.sanity_check()

# Generated at 2022-06-21 06:35:43.879715
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # Arrange
    args = {
        'start': '1',
        'end': '10',
        'stride': '2',
        'format': '%s'
    }
    expected_result = {
        'start': 1,
        'end': 10,
        'stride': 2,
        'format': '%s'
    }
    lookup = LookupModule()
    # Act
    lookup.parse_kv_args(args)
    # Assert
    assert expected_result['start'] == lookup.start
    assert expected_result['end'] == lookup.end
    assert expected_result['stride'] == lookup.stride
    assert expected_result['format'] == lookup.format


# Generated at 2022-06-21 06:35:49.913831
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    results = [1, 2, 3, 4]
    test_terms = ["start=1 end=5 stride=1 format=%d", "start=1 end=5 stride=1"]
    sequence_results = l.run(test_terms, None)
    assert results == sequence_results
    sequence_results = l.run(test_terms, None)
    assert results == sequence_results

# Generated at 2022-06-21 06:36:14.788465
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 2
    lookup.end = 10
    lookup.stride = 1
    lookup.format = "%d"
    lookup.reset()
    assert lookup.start == 1
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:36:21.850105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestVars(object):
        def __init__(self, hostvars):
            self.hostvars = hostvars

        def get_vars(self, play=None, task=None, host=None):
            return self.hostvars[host]

    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    test_vars = TestVars({
        'host1': {
            'hostname': 'host1',
            'group_names': [],
            'groups': {},
            'omit': '__omit_place_holder__123456789',
            'vars': {
                'omit': False,
            },
        },
    })
   

# Generated at 2022-06-21 06:36:26.289897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.reset()
    assert lookup_plugin.start == 1
    assert lookup_plugin.end == None
    assert lookup_plugin.count == None
    assert lookup_plugin.stride == 1
    assert lookup_plugin.format == '%d'

# Generated at 2022-06-21 06:36:32.108527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_class = LookupModule()
    assert test_class is not None
    assert test_class.start == 1
    assert test_class.count == None
    assert test_class.end == None
    assert test_class.stride == 1
    assert test_class.format == "%d"

# Unit tests for function parse_kv_args of class LookupModule

# Generated at 2022-06-21 06:36:39.880605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:36:51.846677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # initialise test class
    test_lookup_module = LookupModule()

    # test case: simple short form with end specified
    # set test input
    test_terms = ["5"]
    test_variables = None
    test_kwargs = {}
    expected_result = ["1", "2", "3", "4", "5"]
    test_result = test_lookup_module.run(test_terms, test_variables, **test_kwargs)
    assert test_result == expected_result

    # test case: simple short form with end, stride and format specified
    # set test input
    test_terms = ["2-10/2", "4:host%02d"]
    test_variables = None
    test_kwargs = {}
    expected

# Generated at 2022-06-21 06:37:01.417842
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    ret = None
    obj = LookupModule()
    obj.count = None
    obj.end = 1
    obj.stride = 1
    obj.start = 0
    try:
        ret = obj.sanity_check()
        ret = "no error"
    except Exception as e:
        ret = str(e)
    assert ret == "no error", "%s != 'no error'" % ret

    obj = LookupModule()
    obj.count = 5
    obj.end = None
    obj.stride = 1
    obj.start = 0
    try:
        ret = obj.sanity_check()
        ret = "no error"
    except Exception as e:
        ret = str(e)
    assert ret == "no error", "%s != 'no error'" % ret

    obj = LookupModule()


# Generated at 2022-06-21 06:37:11.468951
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    """Check the sanity_check method of with_sequence"""
    lookup = LookupModule()
    lookup.count = None
    lookup.end = None
    with pytest.raises(AnsibleError) as excinfo:
        lookup.sanity_check()
    assert "must specify count or end in with_sequence" in str(excinfo.value)
    
    lookup = LookupModule()
    lookup.count = 5
    lookup.end = 7
    with pytest.raises(AnsibleError) as excinfo:
        lookup.sanity_check()
    assert "can't specify both count and end in with_sequence" in str(excinfo.value)
    
    lookup = LookupModule()
    lookup.stride = 2
    lookup.end = -2

# Generated at 2022-06-21 06:37:17.778053
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    sequence = LookupModule()
    sequence.start = 0
    sequence.count = None
    sequence.end = None
    sequence.stride = 0
    sequence.format = ""
    sequence.reset()
    assert sequence.start == 1
    assert sequence.count == None
    assert sequence.end == None
    assert sequence.stride == 1
    assert sequence.format == "%d"
