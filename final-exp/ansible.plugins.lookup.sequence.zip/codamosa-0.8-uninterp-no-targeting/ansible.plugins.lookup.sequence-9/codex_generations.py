

# Generated at 2022-06-21 06:27:41.799587
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    from ansible.module_utils._text import to_text
    my_obj = LookupModule()
    my_obj.reset()
    assert SHORTCUT.match(to_text(u'5'))
    my_obj.parse_simple_args(to_text(u'5'))
    assert {'format': u'%d', 'count': None, 'stride': 1, 'start': 1, 'end': 5} == my_obj.__dict__
    my_obj.reset()
    assert SHORTCUT.match(to_text(u'5-8'))
    my_obj.parse_simple_args(to_text(u'5-8'))

# Generated at 2022-06-21 06:27:53.283512
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    import ansible.plugins.lookup.sequence as lookup_sequence
    lookup_seq = lookup_sequence.LookupModule()
    lookup_seq.format = "%d"
    # Test case when there is no sequence, because stride is zero
    lookup_seq.stride = 0
    lookup_seq.start = 0
    lookup_seq.end = 0
    assert list(lookup_seq.generate_sequence()) == []
    # Test case when start is zero
    lookup_seq.stride = 1
    lookup_seq.start = 0
    lookup_seq.end = 10
    assert list(lookup_seq.generate_sequence()) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    # Test case when start is not zero
    lookup_seq.start = 1
    lookup_

# Generated at 2022-06-21 06:28:05.122701
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.parse_kv_args({'start':0x0f00,'count':4,'format':'%04x'})
    assert lookup_module.start == 3840
    assert lookup_module.count == 4
    assert lookup_module.end is None
    assert lookup_module.stride == 1
    assert lookup_module.format == '%04x'
    lookup_module.reset()
    lookup_module.parse_kv_args({'start':0,'count':5,'stride':2})
    assert lookup_module.start == 0
    assert lookup_module.count == 5
    assert lookup_module.end is None
    assert lookup_module.stride == 2
    assert lookup_module.format == '%d'
    lookup

# Generated at 2022-06-21 06:28:09.333458
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()

    l.start = 1
    l.count = None
    l.end = None
    l.stride = 1
    l.format = "%d"

    l.reset()

    assert l.start == 0
    assert l.count is None
    assert l.end is None
    assert l.stride == 1
    assert l.format == "%d"


# Generated at 2022-06-21 06:28:13.500455
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This test creates a LookupModule object and test the
    """
    try:
        test_obj = LookupModule()
        assert test_obj is not None
    except Exception as e:
        assert False, "Got wrong exception"


# Generated at 2022-06-21 06:28:24.402820
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()

    assert lm.parse_simple_args('1') == True
    assert lm.start == 1
    assert lm.end == 1
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()
    assert lm.parse_simple_args('5') == True
    assert lm.start == 5
    assert lm.end == 5
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()
    assert lm.parse_simple_args('5-8') == True
    assert lm.start == 5
    assert lm.end == 8
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()

# Generated at 2022-06-21 06:28:36.694525
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    seq = LookupModule()
    assert not seq.parse_simple_args("")
    assert not seq.parse_simple_args("foo")
    assert not seq.parse_simple_args("start=foo end=bar")
    assert not seq.parse_simple_args("start=1 end=x")
    assert not seq.parse_simple_args("start=1/2/3")
    assert not seq.parse_simple_args("start=1/2/3/4")
    assert not seq.parse_simple_args("start=1/0")
    assert not seq.parse_simple_args("start=1/0x0")
    assert not seq.parse_simple_args("start=1/0x0f")
    assert not seq.parse_simple_args("start=1/2/3/4")

# Generated at 2022-06-21 06:28:46.120166
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    class LookupModuleMock(LookupModule):
        def __init__(self):
            self.reset()

    lm = LookupModuleMock()
    assert lm.parse_simple_args("5") == True
    assert lm.start == 1, "Start not set to default value"
    assert lm.end == 5, "End not set to value"
    assert lm.stride == 1, "Stride not set to default value"
    assert lm.format == "%d", "Format not set to default value"
    assert lm.count is None, "count not None"

    lm = LookupModuleMock()
    assert lm.parse_simple_args("5-8") == True
    assert lm.start == 5, "Start not set to value"

# Generated at 2022-06-21 06:28:58.783592
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()

    # Test start
    lookup.reset()
    lookup.parse_kv_args({"start": "1"})
    assert lookup.start == 1

    # Test end
    lookup.reset()
    lookup.parse_kv_args({"end": "1"})
    assert lookup.end == 1

    # Test count
    lookup.reset()
    lookup.parse_kv_args({"count": "1"})
    assert lookup.count == 1

    # Test stride
    lookup.reset()
    lookup.parse_kv_args({"stride": "1"})
    assert lookup.stride == 1

    # Test format
    lookup.reset()
    lookup.parse_kv_args({"format": "testformat"})
    assert lookup.format == "testformat"



# Generated at 2022-06-21 06:29:07.771735
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Sanity check with all parameters valid, should not raise any errors
    lookup_ = LookupModule()
    lookup_.start = 1
    lookup_.end = 10
    lookup_.stride = 2
    lookup_.sanity_check()

    # Sanity check with count, it will update the end value
    lookup_ = LookupModule()
    lookup_.start = 1
    lookup_.count = 5
    lookup_.stride = 2
    lookup_.sanity_check()
    assert lookup_.end == 9

    # Sanity check with count 0
    lookup_ = LookupModule()
    lookup_.start = 0
    lookup_.count = 0
    lookup_.stride = 0
    lookup_.sanity_check()
    assert lookup_.end == 0

    # Sanity check with non positive count
    lookup_ = LookupModule()
    lookup_.start

# Generated at 2022-06-21 06:29:15.831891
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    look = LookupModule()
    assert not look.parse_simple_args('hello')
    assert not look.parse_simple_args('5-10/3')


# Generated at 2022-06-21 06:29:27.016522
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()

    lookup.reset()
    lookup.start = 0
    lookup.end = 32
    lookup.stride = 1
    lookup.format = "testuser%02x"
    result = list(lookup.generate_sequence())

# Generated at 2022-06-21 06:29:31.553799
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    start = 2
    end = 20
    stride = 2
    format = "%d"
    lookup_module.start = start
    lookup_module.end = end
    lookup_module.stride = stride
    lookup_module.format = format
    assert lookup_module.start == start
    assert lookup_module.end == end
    assert lookup_module.stride == stride
    assert lookup_module.format == format

# Generated at 2022-06-21 06:29:39.241644
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    """
    LookupModule - sanity_check
    """
    args = dict(
        start = 1,
        count = None,
        end = None,
        stride = 1,
        format = "%d",
    )

    lm = LookupModule()
    for key in args.keys():
        setattr(lm, key, args[key])

    lm.sanity_check()


# Generated at 2022-06-21 06:29:42.940253
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert module.start == 1
    assert module.count == None
    assert module.end == None
    assert module.stride == 1
    assert module.format == '%d'


# Generated at 2022-06-21 06:29:44.169077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')


# Generated at 2022-06-21 06:29:56.194131
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.reset()
    lookup.start = 5
    lookup.stride = 1
    lookup.end = 8
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["5", "6", "7", "8"]
    lookup.reset()
    lookup.start = 5
    lookup.stride = 2
    lookup.end = 10
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ["5", "7", "9"]
    lookup.reset()
    lookup.start = 0xf00
    lookup.stride = 1
    lookup.end = 0xf04
    lookup.format = "0x%04x"

# Generated at 2022-06-21 06:30:06.174846
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # No stride
    lookup_obj = LookupModule()
    lookup_obj.start = 0
    lookup_obj.end = 5
    lookup_obj.stride = 1

    result = list(lookup_obj.generate_sequence())
    assert result == [0, 1, 2, 3, 4, 5]

    # With stride
    lookup_obj = LookupModule()
    lookup_obj.start = 0
    lookup_obj.end = 8
    lookup_obj.stride = 2

    result = list(lookup_obj.generate_sequence())
    assert result == [0, 2, 4, 6, 8]

    # With negative stride
    lookup_obj = LookupModule()
    lookup_obj.start = 0
    lookup_obj.end = -8
    lookup_obj.stride = -2

   

# Generated at 2022-06-21 06:30:18.581423
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    import unittest
    import mock
    import os

    results = []
    lookup_obj = LookupModule()
    lookup_obj.start = 1
    lookup_obj.end = 3
    lookup_obj.stride = 1
    lookup_obj.format = "%d"
    results.extend(lookup_obj.generate_sequence())

    class TestLookupModule(unittest.TestCase):
        @mock.patch.dict(os.environ, {})
        def test_generate_sequence(self):
            self.assertEqual(results, ['1', '2', '3'])

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTests(loader.loadTestsFromTestCase(TestLookupModule))
    return unittest

# Generated at 2022-06-21 06:30:22.739744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.errors import AnsibleError
    from ansible.parsing.splitter import parse_kv
    from ansible.plugins.lookup import LookupBase
    try:
        c = LookupModule()
    except TypeError as e:
        assert "abstract" in e, "lookup module.run() not declared abstract"
    assert c.reset() == None,  "lookup module.reset() not declared"
    assert c.parse_kv_args({}) == None,  "lookup module.parse_kv_args() not declared"
    assert c.parse_simple_args("") == False,  "lookup module.parse_simple_args() not declared"
    assert c.sanity_check() == None,  "lookup module.sanity_check() not declared"
    assert c.generate

# Generated at 2022-06-21 06:30:37.461518
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.format = '%d'
    results = []
    results.extend(lookup_module.generate_sequence())
    assert results == ['1', '2', '3', '4', '5']

# Generated at 2022-06-21 06:30:48.787107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # all points
    lm = LookupModule()
    assert lm.run(['start=5 end=11 stride=2 format=0x%02x'], None) == ["0x05","0x07","0x09","0x0a"]
    assert lm.run(['5-11/2:0x%02x'], None) == ["0x05","0x07","0x09","0x0a"]

    # all points
    lm.reset()
    assert lm.run(['start=5 end=11 stride=2 format=0x%02x'], None) == ["0x05","0x07","0x09","0x0a"]

    # make sure that defaults work
    lm.reset()

# Generated at 2022-06-21 06:30:57.479529
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    # Create an instance of LookupModule
    lookup = LookupModule()

    # Test with the argument end=3
    lookup.parse_kv_args({'end': 3})
    assert lookup.count == None
    assert lookup.end == 3
    assert lookup.format == '%d'
    assert lookup.start == 1
    assert lookup.stride == 1

    # Test with the argument start=3
    lookup.parse_kv_args({'start': 3})
    assert lookup.count == None
    assert lookup.end == 3
    assert lookup.format == '%d'
    assert lookup.start == 3
    assert lookup.stride == 1

    # Test with the argument stride=3
    lookup.parse_kv_args({'stride': 3})
    assert lookup.count == None

# Generated at 2022-06-21 06:31:06.927894
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    # Unit tests for all shortcut format strings
    t = LookupModule('')
    assert t.parse_simple_args('9')
    assert t.start == 1
    assert t.end == 9
    assert t.stride == 1
    assert t.format == '%d'
    t.reset()

    assert t.parse_simple_args('5-8')
    assert t.start == 5
    assert t.end == 8
    assert t.stride == 1
    assert t.format == '%d'
    t.reset()

    assert t.parse_simple_args('5-8/2')
    assert t.start == 5
    assert t.end == 8
    assert t.stride == 2
    assert t.format == '%d'
    t.reset()

    assert t.parse_simple_

# Generated at 2022-06-21 06:31:17.501419
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_mod = LookupModule()
    results = []
    lookup_mod.start = 1
    lookup_mod.end = 32
    lookup_mod.stride = 1
    lookup_mod.format = "testuser%02x"
    results.extend(lookup_mod.generate_sequence())
    lookup_mod.reset()
    lookup_mod.start = 4
    lookup_mod.end = 16
    lookup_mod.stride = 2
    results.extend(lookup_mod.generate_sequence())
    lookup_mod.reset()
    lookup_mod.start = 0
    lookup_mod.count = 4
    results.extend(lookup_mod.generate_sequence())
    lookup_mod.reset()
    lookup_mod.start = 10
    lookup_mod.end = 0
    lookup

# Generated at 2022-06-21 06:31:22.870392
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    module = LookupModule()
    module.parse_kv_args({'start':'2', 'end':'10', 'stride':'2', 'format':'0x%02x'})
    assert module.start == 2
    assert module.end   == 10
    assert module.stride == 2
    assert module.format == '0x%02x'


# Generated at 2022-06-21 06:31:29.977786
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    myLookupModule = LookupModule()
    myLookupModule.reset()
    myLookupModule.start = 1
    myLookupModule.end = None
    myLookupModule.stride = 1
    myLookupModule.format = "%d"
    try:
        myLookupModule.sanity_check()
    except AnsibleError:
        print("AnsibleError raised as expected")
    else:
        raise Exception("AnsibleError not raised")


# Generated at 2022-06-21 06:31:42.623528
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    assert LookupModule().parse_kv_args({"count":5}) == None
    assert LookupModule().parse_kv_args({"count":"0f00"}) == None
    assert LookupModule().parse_kv_args({"format":"%d"}) == None
    assert LookupModule().parse_kv_args({"count":"3"}) == None
    # negative number test
    assert LookupModule().parse_kv_args({"start":"-3"}) == None
    # Negative number test to confirm error handling
    try:
        LookupModule().parse_kv_args({"start":"-1","stride":"-2"})
    except AnsibleError:
        pass
    else:
        assert False

if __name__ == "__main__":
    import sys

    args = []
   

# Generated at 2022-06-21 06:31:56.304673
# Unit test for method generate_sequence of class LookupModule

# Generated at 2022-06-21 06:32:09.705455
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.start = 10
    lookup.end = 20
    lookup.stride = 1
    lookup.format = "%02d"
    assert list(lookup.generate_sequence()) == ['10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20']

    lookup.stride = 2
    assert list(lookup.generate_sequence()) == ['10', '12', '14', '16', '18', '20']

    lookup.start = 20
    lookup.end = 10
    lookup.stride = -2
    assert list(lookup.generate_sequence()) == ['20', '18', '16', '14', '12']

    lookup.start = 20
    lookup.end = 10

# Generated at 2022-06-21 06:32:18.343156
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    # Setup
    module = LookupModule()
    module.reset()
    # Test
    assert module.start == 1
    assert module.count == None
    assert module.end == None
    assert module.stride == 1
    assert module.format == "%d"


# Generated at 2022-06-21 06:32:22.351026
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    """
    we test that the values are overridden by their default vals
    """
    lookup_robot = LookupModule()
    assert lookup_robot.start == 1
    assert lookup_robot.end == None
    assert lookup_robot.stride == 1
    assert lookup_robot.format == "%d"


# Generated at 2022-06-21 06:32:31.936880
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    a = LookupModule()
    a.start = 10
    a.end = 15
    a.count = 4
    a.stride = 1
    a.format = "%d"
    a.reset()
    assert a.start == 1
    assert a.end == None
    assert a.count == None
    assert a.stride == 1
    assert a.format == "%d"


# Generated at 2022-06-21 06:32:39.332127
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    start = 0
    end = -1
    stride = 1
    count = 4
    l = LookupModule()

    l.start = start
    l.end = end
    l.stride = stride
    try:
        l.sanity_check()
        assert True
    except:
        assert False

    l.end = None
    try:
        l.sanity_check()
        assert False
    except:
        assert True

    l.end = end
    try:
        l.sanity_check()
        l.count = count
        assert False
    except:
        assert True

    try:
        l.sanity_check()
        l.count = None
        assert True
    except:
        assert False


# Generated at 2022-06-21 06:32:48.669499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import ansible.utils
    sys.modules['ansible'] = ansible
    sys.modules['ansible.utils'] = ansible.utils
    lookup = LookupModule()

    # test shortcut form
    # start, end, stride, format
    results = lookup.run(["5"], [], **{})
    assert(results == ['1', '2', '3', '4', '5'])

    results = lookup.run(["5-8"], [], **{})
    assert(results == ['5', '6', '7', '8'])

    results = lookup.run(["2-10/2"], [], **{})
    assert(results == ['2', '4', '6', '8', '10'])

    results = lookup.run(["5-9/2"], [], **{})

# Generated at 2022-06-21 06:32:58.044973
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    # test simple usage
    lookup = LookupModule()
    lookup.parse_kv_args({'start': '2', 'end': '8', 'stride': '2', 'format': '%02x'})
    assert lookup.start == 2
    assert lookup.end == 8
    assert lookup.stride == 2
    assert lookup.format == '%02x'

    # test conversion of non-decimal values
    lookup.reset()
    lookup.parse_kv_args({'start': '0x10', 'end': '020', 'stride': '01', 'format': '%02x'})
    assert lookup.start == 0x10
    assert lookup.end == 0o20
    assert lookup.stride == 1
    assert lookup.format == '%02x'

    # test multiple arguments in one string


# Generated at 2022-06-21 06:33:09.434775
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    import pytest
    from collections import Iterator

    lookup = LookupModule()

    lookup.start = 1
    lookup.count = None
    lookup.end = 5
    lookup.stride = 1
    lookup.format = "%d"

    expected = [1, 2, 3, 4, 5]

    gen_seq = lookup.generate_sequence()
    assert isinstance(gen_seq, Iterator)
    assert next(gen_seq) == 1
    assert list(gen_seq) == expected

    lookup.start = 1
    lookup.count = None
    lookup.end = -2
    lookup.stride = -1
    lookup.format = "%d"
    expected = [1, 0, -1, -2]

    gen_seq = lookup.generate_sequence()

# Generated at 2022-06-21 06:33:16.367742
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    try:
        instance = LookupModule()
        instance.sanity_check()
        # This point should have not been reached
        assert False
    except AnsibleError:
        pass
    except Exception:
        # This is the wrong error
        assert False

    try:
        instance = LookupModule()
        instance.count = 1
        instance.end = 1
        instance.sanity_check()
        # This point should have not been reached
        assert False
    except AnsibleError:
        pass
    except Exception:
        # This is the wrong error
        assert False

    try:
        instance = LookupModule()
        instance.count = 1
        instance.sanity_check()
    except AnsibleError:
        assert False
    except Exception:
        # This is the wrong error
        assert False


# Generated at 2022-06-21 06:33:21.328992
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()
    lookup_module.reset()

    assert lookup_module.start == 1
    assert lookup_module.count == None
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"


# Generated at 2022-06-21 06:33:32.557255
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # Test: sequence lookup module run()
    def test_run():
        # Test: arguments are not included
        assert lookup_plugin.run([''], dict()) == []

        # Test: arguments are included
        assert lookup_plugin.run(['1'], dict()) == ['1']

        # Test: arguments are included
        assert lookup_plugin.run(['start=1 end=3'], dict()) == ['1', '2', '3']

        # Test: arguments are included
        assert lookup_plugin.run(['count=3'], dict()) == ['1', '2', '3']

        # Test: arguments are included

# Generated at 2022-06-21 06:33:53.793480
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    l = LookupModule()

    assert l.parse_simple_args('5')
    assert l.start == 1
    assert l.end == 5
    assert l.stride == 1
    assert l.format == '%d'
    l.reset()

    assert l.parse_simple_args('5-8')
    assert l.start == 5
    assert l.end == 8
    assert l.stride == 1
    assert l.format == '%d'
    l.reset()

    assert l.parse_simple_args('2-10/2')
    assert l.start == 2
    assert l.end == 10
    assert l.stride == 2
    assert l.format == '%d'
    l.reset()

    assert l.parse_simple_args('4:host%02d')

# Generated at 2022-06-21 06:34:02.334618
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Arrange
    l = LookupModule()
    l.reset()


# Generated at 2022-06-21 06:34:13.825587
# Unit test for method parse_kv_args of class LookupModule

# Generated at 2022-06-21 06:34:17.283787
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert lookup_module.start == 1
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'



# Generated at 2022-06-21 06:34:19.873655
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.count = 5
    lookup.start = 10
    lookup.end = 15
    lookup.stride = 2

    lookup.sanity_check()



# Generated at 2022-06-21 06:34:26.091841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_term1 = 'start=5 end=11 stride=2 format=0x%02x'
    test_term2 = 'count=5'
    test_term3 = '-5-8'
    test_term4 = '5:host%02d'
    module = LookupModule()

# Generated at 2022-06-21 06:34:37.787727
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create lookup module and insert test data
    l = LookupModule()
    l._templar = None

    # Test shortcuts
    assert l.run(["0-10/2"], None) == ['0', '2', '4', '6', '8', '10']
    assert l.run(["10-0/-1"], None) == ['10', '9', '8', '7', '6', '5', '4', '3', '2', '1', '0']
    assert l.run(["0-10/2:testuser%02x"], None) == ['testuser00', 'testuser02', 'testuser04', 'testuser06', 'testuser08', 'testuser0a']

# Generated at 2022-06-21 06:34:46.126457
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    options = {
        'start': 1,
        'end': 5,
        'stride': 1,
        'format': "%d",
    }

# Generated at 2022-06-21 06:34:57.038903
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    l = LookupModule()
    l.count = 5  # invalid: end in use
    try:
        l.sanity_check()
        assert False, "control should not get here"
    except AnsibleError:
        pass

    l.reset()
    l.count = 5
    l.end = 10  # invalid: both end and count are in use
    try:
        l.sanity_check()
        assert False, "control should not get here"
    except AnsibleError:
        pass

    l.reset()
    l.stride = 2
    l.end = 10  # invalid: count backwards with positive stride
    try:
        l.sanity_check()
        assert False, "control should not get here"
    except AnsibleError:
        pass

    l.reset()
    l.stride

# Generated at 2022-06-21 06:35:04.830411
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 3
    lookup.count = 5
    lookup.end = 5
    lookup.stride = 5
    lookup.format = "%2"

    lookup.reset()

    assert lookup.start == 1, "start is not reset"
    assert lookup.count is None, "count is not reset"
    assert lookup.end is None, "end is not reset"
    assert lookup.stride == 1, "stride is not reset"
    assert lookup.format == "%d", "format is not reset"


# Generated at 2022-06-21 06:35:32.556514
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    # No value provided
    lm = LookupModule()
    lm.parse_kv_args(dict())
    assert lm.start == 1
    assert lm.count is None
    assert lm.end is None
    assert lm.stride == 1
    assert lm.format == "%d"

    # count provided
    lm = LookupModule()
    lm.parse_kv_args(dict(count="50"))
    assert lm.count == 50
    lm.parse_kv_args(dict(count="0x50"))
    assert lm.count == 0x50
    lm.parse_kv_args(dict(count="0"))
    assert lm.count == 0

    # count with format
    lm = LookupModule()
    lm.parse_kv

# Generated at 2022-06-21 06:35:43.033392
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    import os

    plugin = LookupModule()
    plugin.reset()
    plugin.parse_kv_args({"start": "0x123", "end": "0x234", "stride": "2", "format": "0x%04X"})
    assert(plugin.start == 0x123)
    assert(plugin.end == 0x234)
    assert(plugin.stride == 2)
    assert(plugin.format == "0x%04X")

    plugin = LookupModule()
    plugin.reset()
    plugin.parse_kv_args({"start": 0x123, "end": 0x234, "stride": 2, "format": "0x%04X"})
    assert(plugin.start == 0x123)
    assert(plugin.end == 0x234)

# Generated at 2022-06-21 06:35:46.533246
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.reset()

    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:35:55.287509
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 1
    lookup_module.stride = 1
    lookup_module.sanity_check()
    lookup_module.end = 0
    lookup_module.sanity_check()
    lookup_module.start = 0
    lookup_module.sanity_check()
    lookup_module.count = 1
    with pytest.raises(AnsibleError):
        lookup_module.sanity_check()
    lookup_module.count = None
    lookup_module.end = 1
    lookup_module.sanity_check()
    lookup_module.end = 0
    lookup_module.sanity_check()
    lookup_module.start = -1
    lookup_module.stride = -1

# Generated at 2022-06-21 06:36:05.265337
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()

    # No count, no end
    try:
        lookup.reset()
        lookup.sanity_check()
    except AnsibleError:
        assert True
    else:
        assert False, 'Expecting an AnsibleError exception'

    # Count and end
    try:
        lookup.reset()
        lookup.count = 6
        lookup.end = 10
        lookup.sanity_check()
    except AnsibleError:
        assert True
    else:
        assert False, 'Expecting an AnsibleError exception'

    # Negative stride and end > start
    try:
        lookup.reset()
        lookup.stride = -1
        lookup.end = 10
        lookup.start = 20
        lookup.sanity_check()
    except AnsibleError:
        assert True

# Generated at 2022-06-21 06:36:09.967569
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    print('')
    lookup_module = LookupModule()
    lookup_module.reset()
    assert lookup_module.start == 1
    assert lookup_module.count is None
    assert lookup_module.end is None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"



# Generated at 2022-06-21 06:36:18.335708
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()
    lookup.parse_simple_args("0")
    assert(lookup.start == 1 and lookup.end == 0 and lookup.stride == 1 and lookup.format == "%d")

    lookup.reset()
    lookup.parse_simple_args("0-5")
    assert(lookup.start == 1 and lookup.end == 5 and lookup.stride == 1 and lookup.format == "%d")

    lookup.reset()
    lookup.parse_simple_args("2-10/2")
    assert(lookup.start == 2 and lookup.end == 10 and lookup.stride == 2 and lookup.format == "%d")

    lookup.reset()
    lookup.parse_simple_args("4:host%02d")

# Generated at 2022-06-21 06:36:27.737915
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lu = LookupModule()

    # Start-end shortcut
    lu.reset()
    lu.parse_simple_args('5-8')
    assert lu.start == 5
    assert lu.end == 8
    assert lu.stride == 1
    assert lu.format == '%d'

    # Start-end/stride shortcut
    lu.reset()
    lu.parse_simple_args('5-8/2')
    assert lu.start == 5
    assert lu.end == 8
    assert lu.stride == 2
    assert lu.format == '%d'

    # End/stride shortcut
    lu.reset()
    lu.parse_simple_args('5/2')
    assert lu.start == 1
    assert lu.end == 5

# Generated at 2022-06-21 06:36:37.814101
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    exception_raised_count = 0
    test_cases = [
        'positive_stride_and_end_less_than_start',
        'negative_stride_and_end_greater_than_start',
        'formatting_string_without_percent',
        'formatting_string_with_multiple_percent',
        'both_count_and_end_specified',
        'neither_count_nor_end_specified',
    ]

    try:
        lookup_module.start = -1
        lookup_module.end = -2
        lookup_module.stride = 1
        lookup_module.sanity_check()
    except AnsibleError:
        exception_raised_count += 1


# Generated at 2022-06-21 06:36:50.431041
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    assert(lookup_module.run(["5"], {}) == ["1","2","3","4","5"])
    assert(lookup_module.run(["5-8"], {}) == ["5","6","7","8"])
    assert(lookup_module.run(["2-10/2"], {}) == ["2","4","6","8","10"])
    assert(lookup_module.run(["4:host%02d"], {}) == ["host01","host02","host03","host04"])

    assert(lookup_module.run(["start=5 end=11 stride=2 format=0x%02x"], {}) == ["0x05","0x07","0x09","0x0a"])

# Generated at 2022-06-21 06:37:04.287373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create and initialize test objects
    lookup_module = LookupModule()
    term = "start=20 end=30/5:format_%d"
    variables = None
    kwargs = {}

    # Execute test
    results = lookup_module.run([term], variables, **kwargs)

    # Check result
    assert results == ["format_20", "format_25", "format_30"]

# Generated at 2022-06-21 06:37:15.993488
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()
    lm.reset()
    format_string = "testuser%02x"
    default_start = 1
    default_end   = 10
    default_stride = 1
    default_format = "%d"

# Generated at 2022-06-21 06:37:21.229362
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    l.start = None
    l.count = None
    l.end = None
    l.stride = None
    l.format = None

    l.reset()
    assert(l.start == 1)
    assert(l.count is None)
    assert(l.end is None)
    assert(l.stride == 1)
    assert(l.format == '%d')
