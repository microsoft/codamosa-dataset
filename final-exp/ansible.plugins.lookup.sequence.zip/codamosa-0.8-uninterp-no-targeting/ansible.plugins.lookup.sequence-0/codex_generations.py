

# Generated at 2022-06-21 06:27:39.653485
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lk = LookupModule()
    lk.reset()
    lk.start = 1
    lk.end = 10
    lk.stride = 1
    lk.format = "test%02d"

    lk.sanity_check()
    # Test various combinations of start, end and stride with valid results
    assert set(lk.generate_sequence()) == set(["test01", "test02", "test03", "test04", "test05", "test06", "test07", "test08", "test09", "test10"])
    lk.reset()
    lk.start = 2
    lk.end = 2
    lk.stride = -1
    lk.format = "test%02d"
    lk.sanity_check()

# Generated at 2022-06-21 06:27:46.444096
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lm = LookupModule()
    # start
    lm.start = 1
    # end
    lm.end = 5
    # stride
    lm.stride = 1
    # format
    lm.format = "%d"
    assert lm.run(terms=["1-5"], variables={}) == ["1", "2", "3", "4", "5"]
    # start
    lm.start = 3
    # end
    lm.end = 5
    # stride
    lm.stride = 1
    # format
    lm.format = "%d"
    assert lm.run(terms=["3-5"], variables={}) == ["3", "4", "5"]
    # start
    lm.start = 3
    # end
    lm.end = 6
    #

# Generated at 2022-06-21 06:27:53.889156
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm_obj = LookupModule()
    lm_obj.start = 1
    lm_obj.count = 10
    lm_obj.end = 30
    lm_obj.stride = 2
    lm_obj.format = "%d"
    lm_obj.reset()
    assert lm_obj.start == 1
    assert lm_obj.count is None
    assert lm_obj.end == 0
    assert lm_obj.stride == 1
    assert lm_obj.format == "%d"


# Generated at 2022-06-21 06:28:05.427558
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lm = LookupModule()
    lm.count = 5
    lm.start = 0
    lm.end = None
    lm.stride = 0
    lm.format = "%d"
    lm.sanity_check()

    lm.count = None
    lm.start = 0
    lm.end = 5
    lm.stride = 0
    lm.format = "%d"
    lm.sanity_check()

    lm.count = None
    lm.start = 0
    lm.end = None
    lm.stride = 0
    lm.format = "%d"
    try:
        lm.sanity_check()
        assert False
    except AnsibleError:
        pass

    lm.count = 5
    lm.start

# Generated at 2022-06-21 06:28:12.330267
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.parse_kv_args({'start': '0', 'end': '28', 'stride': '2', 'format': 'testuser%02x'})
    assert lookup_module.start == 0
    assert lookup_module.count is None
    assert lookup_module.end == 28
    assert lookup_module.stride == 2
    assert lookup_module.format == 'testuser%02x'


# Generated at 2022-06-21 06:28:16.562836
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    l = LookupModule()
    l.start = 1
    l.end = 10
    l.stride = -1

    try:
        l.sanity_check()
    except AnsibleError:
        assert 1 == 2
    assert 1 == 1

# Generated at 2022-06-21 06:28:25.587353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        "1-10/2",
        "11:host%02d",
        "start=1 end=10 stride=2 format=host%02d"
    ]
    variables = {}
    kwargs = {}
    result = lookup_module.run(terms=terms, variables=variables, **kwargs)
    assert result == ['1', '3', '5', '7', '9', 'host01', 'host02', 'host03', 'host04', 'host05', 'host06', 'host07',
                      'host08', 'host09', 'host10']

    terms = ["1-10/2", "11:host%02d", "start=1 end=10 stride=2 format=host%02d"]
    variables = {}

# Generated at 2022-06-21 06:28:38.469347
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    l = LookupModule()
    l.reset()
    assert l.parse_simple_args('1-3') == True
    assert l.start == 1
    assert l.end == 3
    assert l.stride == 1
    assert l.format == '%d'

    l.reset()
    assert l.parse_simple_args('1') == True
    assert l.start == 1
    assert l.end == 1
    assert l.stride == 1
    assert l.format == '%d'

    l.reset()
    assert l.parse_simple_args('1-3/2') == True
    assert l.start == 1
    assert l.end == 3
    assert l.stride == 2
    assert l.format == '%d'

    l.reset()
    assert l.parse_simple_

# Generated at 2022-06-21 06:28:42.216053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_instance = LookupModule()

    # Test for run method of LookupModule
    # Invalid case for run method of LookupModule
    assert test_instance.run([]) == []

    # Valid case for run method of LookupModule
    assert test_instance.run(["9"]) == ['9']


# Generated at 2022-06-21 06:28:45.421552
# Unit test for constructor of class LookupModule
def test_LookupModule():
  print("Testing class LookupModule")
  lookup_module = LookupModule()
  assert lookup_module is not None
  lookup_module = LookupModule(start = 0, end = 10, stride = 1, format = '%d')
  assert lookup_module is not None


# Generated at 2022-06-21 06:28:58.694979
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    params = {
        'start': '10',
        'end': '13',
        'stride': '2',
        'format': 'test%02d'
    }
    lu = LookupModule()
    lu.parse_kv_args(params)

    assert lu.start == 10
    assert lu.count is None
    assert lu.end == 13
    assert lu.stride == 2
    assert lu.format == 'test%02d'


# Generated at 2022-06-21 06:29:07.706824
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:29:20.076600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes


# Generated at 2022-06-21 06:29:30.382491
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    test_cases = [
        # test
        # expected_results
        (SHORTCUT, "2-10/2", [
            None, "2", "10", None, "2", None, None,
        ]),
        (SHORTCUT, "2-10/2:test%d", [
            None, "2", "10", None, "2", None, "test%d",
        ]),
        (SHORTCUT, "2:test%d", [
            None, "2", None, None, None, None, "test%d",
        ]),
    ]

    for test_case, expected_results in test_cases:
        result = test_case.match("2-10/2")
        assert result is not None
        if result is not None:
            result = result.groups()


# Generated at 2022-06-21 06:29:31.640267
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    return lookup_plugin

# Generated at 2022-06-21 06:29:44.211901
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing method
    lookup = LookupModule()

    # Testing good arguments
    terms = ['start=0 end=10', 'start=1 count=10', 'start=1 end=10 count=10']
    results = [['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
               ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
               ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']]
    for i in range(len(terms)):
        assert results[i] == lookup.run([terms[i]], {})

    # Testing bad arguments

# Generated at 2022-06-21 06:29:56.235662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # with_sequence: "1-10/2"
    lm = LookupModule()
    assert lm.run(["1-10/2"], {}) == ["1", "3", "5", "7", "9"]

    # with_sequence: "start=1 end=10 stride=2"
    lm = LookupModule()
    assert lm.run(["start=1 end=10 stride=2"], {}) == ["1", "3", "5", "7", "9"]

    # with_sequence: "start=0x0f00 end=0x0f03 stride=1"
    lm = LookupModule()
    assert lm.run(["start=0x0f00 end=0x0f03 stride=1"], {}) == ["0f00", "0f01", "0f02"]

# Generated at 2022-06-21 06:30:00.604742
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    from ansible.plugins.lookup import LookupModule

    lookup = LookupModule()
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:30:06.597121
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    my_sequence = LookupModule()
    my_sequence.start = 4
    my_sequence.end = 32
    my_sequence.stride = 2
    my_sequence.format = "testuser%02x"
    my_sequence.reset()
    assert my_sequence.start == 1
    assert my_sequence.end == None
    assert my_sequence.stride == 1
    assert my_sequence.format == "%d"

# Generated at 2022-06-21 06:30:13.552007
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()

    lookup.parse_kv_args(dict())
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.parse_kv_args(dict(start=0, end=10, stride=2, format="%1"))
    assert lookup.start == 0
    assert lookup.count == None
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == "%1"

    lookup.parse_kv_args(dict(start=0, count=10, stride=2, format="%1"))
    assert lookup.start == 0
    assert lookup.count == 10
    assert lookup.end == 19
    assert lookup.stride == 2

# Generated at 2022-06-21 06:30:30.502428
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    from ansible.plugins.lookup import LookupModule

    # Test of valid arguments
    lookup = LookupModule()
    lookup.reset()

    # No arguments
    args = {}
    lookup.parse_kv_args(args)
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"

    # Start argument
    args = {"start": "5"}
    lookup.parse_kv_args(args)
    assert lookup.start == 5
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"

    # Start, End arguments
    args = {"start": "5", "end": "10"}
    lookup.parse

# Generated at 2022-06-21 06:30:33.042601
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    sequence = LookupModule(run_once=True)
    sequence.reset()
    assert sequence.start == 1
    assert sequence.end is None
    assert sequence.format == "%d"

# Generated at 2022-06-21 06:30:41.991790
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    kv_list = [
        ("start=2 end=9 count=12 format=0x%02x", {'start': 2, 'end': 9, 'format': '0x%02x'}),
        ("end=1", {'end': 1}),
        ("start=3", {'start': 3})
    ]
    lm = LookupModule()
    for kv, result in kv_list:
        assert(lm.parse_kv_args(parse_kv(kv)) == result)


# Generated at 2022-06-21 06:30:42.624119
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:30:54.143609
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()
    assert lookup.parse_simple_args("") is False
    assert lookup.parse_simple_args("2") is False
    assert lookup.parse_simple_args("x") is False
    assert lookup.parse_simple_args("start=10") is False
    assert lookup.parse_simple_args("10-") is False
    assert lookup.parse_simple_args("/10") is False
    assert lookup.parse_simple_args(":") is False
    assert lookup.parse_simple_args("0") is False
    assert lookup.parse_simple_args("5x") is False

    lookup.reset()
    assert lookup.parse_simple_args("-128") is True
    assert lookup.start == -128
    assert lookup.end == -128
    assert lookup.stride

# Generated at 2022-06-21 06:31:06.174748
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import pytest
    with pytest.raises(AnsibleError) as excinfo:
        try:
            sequence = LookupModule()
            sequence.start = 1
            sequence.end = 1
            sequence.sanity_check()
        except AnsibleError:
            raise
        except Exception as e:
            raise AnsibleError("unknown error generating sequence: %s" % e)
    assert "must specify count or end in with_sequence" in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        try:
            sequence = LookupModule()
            sequence.start = 1
            sequence.end = 1
            sequence.count = 1
            sequence.sanity_check()
        except AnsibleError:
            raise

# Generated at 2022-06-21 06:31:17.142857
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Create instance of LookupModule class
    class_instance = LookupModule()

    # Define empty variables to assert values
    start = None
    end = None
    stride = None
    format_ = None

    # Test Method
    assert class_instance.parse_simple_args("5")

    # Assert values
    assert start is None
    assert end == 5
    assert stride == 1
    assert format_ == "%d"

    # Reset values
    class_instance.reset()

    # Test Method
    assert class_instance.parse_simple_args("5:testuser%02x")

    # Assert values
    assert start is None
    assert end == 5
    assert stride == 1
    assert format_ == "testuser%02x"

    # Reset values
    class_instance.reset()

    # Test Method
   

# Generated at 2022-06-21 06:31:29.489061
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()

    # Test default values
    lookup.parse_kv_args(dict())
    assert lookup.start == 1
    assert lookup.end == 0
    assert lookup.stride == 1
    assert lookup.format == "%d"

    # Test valid values

    # Test start
    lookup.parse_kv_args(dict(start=0))
    assert lookup.start == 0

    # Test end
    lookup.parse_kv_args(dict(end=10))
    assert lookup.end == 10

    # Test stride
    lookup.parse_kv_args(dict(stride=2))
    assert lookup.stride == 2

    # Test format
    lookup.parse_kv_args(dict(format="testuser%02x"))
    assert lookup.format == "testuser%02x"

# Generated at 2022-06-21 06:31:33.752336
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == None
    assert lm.stride == 1
    assert lm.format == "%d"


# Generated at 2022-06-21 06:31:45.754762
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.reset()
    lm.run(terms=[], variables={}, **{})
    ret = lm.run(terms=["5"], variables={}, **{})
    assert(ret == ["1", "2", "3", "4", "5"])
    ret = lm.run(terms=["5-8"], variables={}, **{})
    assert(ret == ["5", "6", "7", "8"])
    ret = lm.run(terms=["2-10/2"], variables={}, **{})
    assert(ret == ["2", "4", "6", "8", "10"])
    ret = lm.run(terms=["4:host%02d"], variables={}, **{})

# Generated at 2022-06-21 06:31:51.432251
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    try:
        q = LookupModule()
        q.sanity_check()
        assert False, "Expected AnsibleError"
    except AnsibleError as e:
        assert "must specify count or end in with_sequence" == e.message



# Generated at 2022-06-21 06:31:59.550372
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()

    class args:
        term = "2-10/2"

    lookup_module.parse_simple_args(args.term)
    lookup_module.sanity_check()
    val = lookup_module.generate_sequence()
    assert(list(val) == ["2", "4", "6", "8", "10"])

    args.term = "start=2 end=10 stride=2"
    lookup_module.parse_kv_args(parse_kv(args.term))
    lookup_module.sanity_check()
    val = lookup_module.generate_sequence()
    assert (list(val) == ["2", "4", "6", "8", "10"])

    class args:
        term = "count=5"
        start = 1
       

# Generated at 2022-06-21 06:32:11.645281
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lr = LookupModule()
    lr.reset()
    lr.parse_kv_args(parse_kv('start=1 end=5 stride=2'))
    lr.sanity_check()
    lr.generate_sequence()

    lr.reset()
    lr.parse_kv_args(parse_kv('start=1 count=6'))
    lr.sanity_check()
    lr.generate_sequence()

    lr.reset()
    lr.parse_kv_args(parse_kv('count=5'))
    lr.sanity_check()
    lr.generate_sequence()

    # with_sequence: start=1 end=5 stride=2
    lr = LookupModule()

# Generated at 2022-06-21 06:32:24.253292
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Positive tests
    lm = LookupModule()
    assert list(lm.generate_sequence()) == []
    lm.start = 1
    lm.end = 5
    assert list(lm.generate_sequence()) == ["1", "2", "3", "4", "5"]

    lm.start = 2
    lm.end = 2
    assert list(lm.generate_sequence()) == ["2"]

    lm.start = 10
    lm.end = 12
    assert list(lm.generate_sequence()) == ["10", "11", "12"]

    lm.start = 10
    lm.end = 12
    lm.stride = 2
    assert list(lm.generate_sequence()) == ["10", "12"]

    lm.start = 10


# Generated at 2022-06-21 06:32:36.607411
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()

    # Forward sequence with default format
    lookup_module.reset()
    lookup_module.start = 0
    lookup_module.end = 3
    assert list(lookup_module.generate_sequence()) == ["0", "1", "2", "3"]

    # Forward sequence with custom format
    lookup_module.reset()
    lookup_module.start = 0
    lookup_module.end = 3
    lookup_module.format = "0x%x"
    assert list(lookup_module.generate_sequence()) == ["0x0", "0x1", "0x2", "0x3"]

    # Strided sequence
    lookup_module.reset()
    lookup_module.start = 0
    lookup_module.end = 3
    lookup_module.stride = 2
   

# Generated at 2022-06-21 06:32:40.601851
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.reset()
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == None
    assert lm.stride == 1
    assert lm.format == "%d"


# Generated at 2022-06-21 06:32:49.318581
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # assert validation success
    assert LookupModule.parse_simple_args(None, "5-22/3:test%04d")
    assert LookupModule.parse_simple_args(None, "5")
    assert LookupModule.parse_simple_args(None, "5-22")
    assert LookupModule.parse_simple_args(None, "5-22/3")
    assert LookupModule.parse_simple_args(None, "5-22/3:test")

    # assert validation error
    # invalid value for start
    try:
        LookupModule.parse_simple_args(None, "5a-22/3:test%04d")
    except AnsibleError as e:
        assert e.message == "can't parse start=5a as integer"

# Generated at 2022-06-21 06:32:54.901428
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Arguments
    start=0
    end=4
    stride=1

    # Initialize variables
    results = []
    sequence = 0

    # Test
    try:
        self.reset()
        results = self.generate_sequence()
    except Exception as e:
        raise AnsibleError("unknown error generating sequence: %s" % e)

    # Verification
    for result in results:
        if result == sequence:
            sequence += 1

    return sequence

# Generated at 2022-06-21 06:33:05.169294
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_obj = LookupModule()
    lookup_obj.reset()
    lookup_obj.parse_kv_args({'start': '0x1f00'})
    assert lookup_obj.start == 8256
    assert lookup_obj.count is None
    assert lookup_obj.end is None
    assert lookup_obj.stride == 1
    assert lookup_obj.format == "%d"

    lookup_obj.reset()
    lookup_obj.parse_kv_args({'start': '-3'})
    assert lookup_obj.start == -3

    lookup_obj.reset()
    lookup_obj.parse_kv_args({'start': '-3', 'end': '0x1f00'})
    assert lookup_obj.end == 8256

    lookup_obj.reset()

# Generated at 2022-06-21 06:33:09.530463
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    module = LookupModule()
    assert module.start == 1
    assert module.count is None
    assert module.end is None
    assert module.stride == 1
    assert module.format == "%d"


# Generated at 2022-06-21 06:33:20.092538
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import pytest

    lm = LookupModule()

    lm.start = 0
    lm.count = 5
    lm.stride = 2
    lm.sanity_check()
    assert lm.end == 8

    lm.start = 1
    lm.count = 5
    lm.stride = 2
    lm.sanity_check()
    assert lm.end == 9

    # Size is zero
    lm.start = 1
    lm.count = 0
    lm.stride = 2
    lm.sanity_check()
    assert lm.end == 0

    with pytest.raises(AnsibleError):
        lm.start = 0
        lm.end = 10
        lm.count = 5
        lm.sanity_check()

# Generated at 2022-06-21 06:33:30.373781
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lm = LookupModule()
    # Test with positive stride
    lm.start = 1
    lm.end = 10
    lm.stride = 2
    lm.format = '%d'
    result = lm.generate_sequence()
    assert(list(result) == ['1', '3', '5', '7', '9'])
    # Test with negative stride
    lm.start = 10
    lm.end = 1
    lm.stride = -2
    lm.format = '%d'
    result = lm.generate_sequence()
    assert(list(result) == ['10', '8', '6', '4', '2'])

# Generated at 2022-06-21 06:33:35.620717
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    seq = LookupModule()
    seq.start = 2
    seq.count = 4
    seq.end = 10
    seq.stride = 3
    seq.format = "test%02d"
    seq.reset()

    assert seq.start == 1
    assert seq.count is None
    assert seq.end is None
    assert seq.stride == 1
    assert seq.format == "%d"


# Generated at 2022-06-21 06:33:39.457152
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    term = "start=0x0f00 count=4 format=%04x"
    x = LookupModule()

    try:
        x.parse_kv_args(parse_kv(term))
    except Exception as e:
        print("LookupModule_parse_kv_args: Exception %s occured" % e)
        return False
    else:
        return True


# Generated at 2022-06-21 06:33:50.938272
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # case1: start < end and stride > 0
    start = 1
    end = 3
    stride = 1
    format = "%d"
    expected = ["1","2","3"]
    lookup = LookupModule()
    lookup.start = start
    lookup.end = end
    lookup.stride = stride
    lookup.format = format
    result = lookup.generate_sequence()
    assert list(result) == expected

    # case2: start > end and stride < 0
    start = 3
    end = 1
    stride = -1
    format = "%d"
    expected = ["3","2","1"]
    lookup = LookupModule()
    lookup.start = start
    lookup.end = end
    lookup.stride = stride
    lookup.format = format
    result = lookup.generate_sequence()
   

# Generated at 2022-06-21 06:33:55.364294
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    lm.reset()

    assert lm.start == 1
    assert lm.count is None
    assert lm.end is None
    assert lm.stride == 1
    assert lm.format == "%d"


# Generated at 2022-06-21 06:34:03.053036
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    import random
    random.seed()


# Generated at 2022-06-21 06:34:14.604591
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    class MockSequence( LookupModule ):
        def __init__(self):
            self.start = 1
            self.count = None
            self.end = None
            self.stride = 1
            self.format = "%d"

    def generate_sequence(self):
        if self.stride >= 0:
            adjust = 1
        else:
            adjust = -1
        numbers = xrange(self.start, self.end + adjust, self.stride)

        for i in numbers:
            try:
                formatted = self.format % i
                yield formatted
            except (ValueError, TypeError):
                raise AnsibleError(
                    "problem formatting %r with %r" % (i, self.format)
                )

    sequence = MockSequence()

# Generated at 2022-06-21 06:34:23.125627
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.count = 1
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        lookup_module.start = 1
        try:
            lookup_module.sanity_check()
        except AnsibleError:
            lookup_module.count = 2
            lookup_module.stride = -1
            try:
                lookup_module.sanity_check()
            except AnsibleError:
                lookup_module.start = 3
                lookup_module.end = 1
                try:
                    lookup_module.sanity_check()
                except AnsibleError:
                    lookup_module.stride = 1
                    lookup_module.format = '%d'

# Generated at 2022-06-21 06:34:24.166409
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-21 06:34:36.945921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup = LookupModule()
   variables = {}

   # Test a basic construct working
   terms = ['0-2']
   ret = lookup.run(terms, variables)
   assert ret == ['0', '1', '2']

   # Test a bad construct
   terms = ['1-4:%bad']
   try:
      lookup.run(terms, variables)
      assert False
   except AnsibleError:
      pass

   # Test a complex construct working
   terms = ['1-4:%0-5ab']
   ret = lookup.run(terms, variables)
   assert ret == ['1ab', '2ab', '3ab', '4ab']

# Generated at 2022-06-21 06:34:45.502145
# Unit test for method parse_simple_args of class LookupModule

# Generated at 2022-06-21 06:34:50.546824
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    l.count = 5
    l.start = 56
    l.end = 90
    l.stride = 4
    l.format = "Format"
    l.reset()
    assert l.start == 1
    assert l.count == None
    assert l.end == 0
    assert l.stride == 1
    assert l.format == "%d"


# Generated at 2022-06-21 06:34:56.080230
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.reset()
    # Test the default values of LookupModule Class
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == None
    assert lm.stride == 1
    assert lm.format == "%d"


# Generated at 2022-06-21 06:34:59.765312
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    expected = [1, 2, 3]
    actual = list(LookupModule().generate_sequence())
    assert expected == actual

# Generated at 2022-06-21 06:35:04.577598
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 5
    lookup.count = None
    lookup.end = 4
    lookup.stride = -1
    lookup.format = "%d"
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:35:10.340104
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    class TestLookupModule(LookupModule):
        def generate_sequence(self):
            return [item for item in self._generate_sequence()]

    assert TestLookupModule().run([':'], {}) == []
    assert TestLookupModule().run([':%x'], {}) == []

    assert TestLookupModule().run(['1'], {}) == ['1']
    assert TestLookupModule().run(['1:%x'], {}) == ['1']

    assert TestLookupModule().run(['1-10'], {}) == ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']

# Generated at 2022-06-21 06:35:21.990909
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    import unittest
    import copy

    class LookupModule_Parse_KV_Args_Test(unittest.TestCase):
        # pylint: disable=invalid-name
        def setUp(self):
            self.lookup = LookupModule()

        def test_empty_args(self):
            """
            Test parsing of empty arguments
            """
            self.lookup.reset()

            args = {}

            self.lookup.parse_kv_args(args)

            self.assertEqual(self.lookup.start, 1)
            self.assertIsNone(self.lookup.count)
            self.assertIsNone(self.lookup.end)
            self.assertEqual(self.lookup.stride, 1)

# Generated at 2022-06-21 06:35:31.512579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term = "count=5"
    lookup.reset()
    lookup.run(term, None, None)
    assert lookup.start == 1
    assert lookup.count == 5
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == '%d'
    term = "0x5-0x0a/2:0x%02x"
    lookup.reset()
    lookup.run(term, None, None)
    assert lookup.start == 5
    assert lookup.count == None
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == '0x%02x'
    term = "10-0/2"
    lookup.reset()
    lookup.run(term, None, None)

# Generated at 2022-06-21 06:35:33.324496
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.sanity_check()
    assert lookup_module.start == 1

# Generated at 2022-06-21 06:35:50.782123
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    assert not lookup.parse_simple_args("start=1 end=5")

    term = "5"
    lookup.parse_simple_args(term)
    assert lookup.start == 1
    assert lookup.end == 5
    assert lookup.stride == 1
    assert lookup.format == "%d"

    term = "5-8"
    lookup.parse_simple_args(term)
    assert lookup.start == 5
    assert lookup.end == 8
    assert lookup.stride == 1
    assert lookup.format == "%d"

    term = "5-8/2"
    lookup.parse_simple_args(term)
    assert lookup.start == 5
    assert lookup.end == 8
    assert lookup.stride == 2
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:35:54.589072
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 1
    lookup.count = 1
    lookup.end = 1
    lookup.stride = 1
    lookup.format = "default"
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:36:04.614195
# Unit test for constructor of class LookupModule
def test_LookupModule():
    sequence_lookup = LookupModule()
    assert not sequence_lookup.lookup(None, "start=5 end=10 stride=5 format=%02d", None, None, None)

    try:
        sequence_lookup.lookup(None, "start=5 end=10 stride=5 count=10 format=%02d")
    except AnsibleError:
        pass
    else:
        assert False, "Should have been AnsibleError"

    try:
        sequence_lookup.lookup(None, "start=5 stride=5 count=10 format=%02d")
    except AnsibleError:
        pass
    else:
        assert False, "Should have been AnsibleError"

    assert sequence_lookup.lookup(None, "start=5 count=10 format=%02d", None, None, None)

# Generated at 2022-06-21 06:36:11.833937
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    test_instance = LookupModule()
    assert [1, 2, 3] == list(test_instance.generate_sequence(1, 4, 1, "%d"))
    assert [1, 2, 3] == list(test_instance.generate_sequence(0, 3, 1, "%d"))
    assert [2, 4, 6] == list(test_instance.generate_sequence(1, 7, 2, "%d"))
    assert [10, 8, 6, 4] == list(test_instance.generate_sequence(10, 1, -2, "%d"))

# Generated at 2022-06-21 06:36:19.719369
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.stride = 1
    # test case 1.1
    try:
        lookup_module.sanity_check()
        assert True
    except AnsibleError as e:
        assert False
    # test case 1.2
    lookup_module.stride = -1
    try:
        lookup_module.sanity_check()
        assert True
    except AnsibleError as e:
        assert False
    # test case 2
    lookup_module.count = 5
    try:
        lookup_module.sanity_check()
        assert True
    except AnsibleError as e:
        assert False
    # test case 3
    lookup_module.count = 5
    lookup_module.end = 10

# Generated at 2022-06-21 06:36:24.624260
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    x = LookupModule()
    x.start = 1
    x.end = 9
    x.stride = 1
    x.format = "%d"
    x.sanity_check()
    sequence = list(x.generate_sequence())
    assert len(sequence) == 9
    assert sequence == ["1", "2", "3", "4", "5", "6", "7", "8", "9"]

# Generated at 2022-06-21 06:36:31.173054
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.stride = 1
    try:
        lookup.sanity_check()
    except AnsibleError:
        pass
    else:
        assert False, "Did not raise AnsibleError"

    lookup.stride = 0
    try:
        lookup.sanity_check()
    except AnsibleError:
        assert False, "Raised AnsibleError"

# Generated at 2022-06-21 06:36:39.438528
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    assert lookup.parse_simple_args("1-2")
    assert not lookup.parse_simple_args("1-2-3")
    assert lookup.parse_simple_args("1-")
    assert lookup.parse_simple_args("-2")
    assert not lookup.parse_simple_args("-2-3")
    assert lookup.parse_simple_args("-2/")
    assert lookup.parse_simple_args("-2/3")
    assert not lookup.parse_simple_args("/3")
    assert not lookup.parse_simple_args("1-2/3:4")
    assert not lookup.parse_simple_args("-2/3:4")
    assert lookup.parse_simple_args("-2:4")

# Generated at 2022-06-21 06:36:45.330893
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    test_instance = LookupModule()
    test_instance.start = 1
    test_instance.end = 2
    test_instance.stride = 1
    test_instance.format = "%d"
    assert list(test_instance.generate_sequence()) == [1, 2]

# Generated at 2022-06-21 06:36:55.785708
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 2
    lookup.sanity_check()
    assert lookup.start == 1
    assert lookup.end == 10
    assert lookup.stride == 2

    lookup.end = 5
    lookup.stride = -2
    lookup.sanity_check()
    assert lookup.end == 5
    assert lookup.stride == -2

    lookup.end = 10
    lookup.stride = -1
    lookup.sanity_check()
    assert lookup.end == 10
    assert lookup.stride == -1

    # test error cases
    lookup.start = 1
    lookup.end = 10
    lookup.stride = 2
    lookup.count = 2

# Generated at 2022-06-21 06:37:10.743493
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:37:20.810022
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.reset()
    test_arguments = dict(start=0, end=4, format='%2d')
    l.parse_kv_args(test_arguments)
    assert l.start == 0
    assert l.end   == 4
    assert l.stride == 1
    assert l.format == '%2d'
    assert l.count == None

    test_arguments = dict(start=0, count=4, format='%2d')
    l.parse_kv_args(test_arguments)
    assert l.start == 0
    assert l.end   == 3
    assert l.stride == 1
    assert l.format == '%2d'
    assert l.count == 4
