

# Generated at 2022-06-21 06:27:24.076656
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module_instance = LookupModule()
    assert lookup_module_instance.start == 1
    assert lookup_module_instance.count == None
    assert lookup_module_instance.end == None
    assert lookup_module_instance.stride == 1
    assert lookup_module_instance.format == "%d"


# Generated at 2022-06-21 06:27:36.899918
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    from ansible.plugins.lookup import LookupModule
    lookup = LookupModule()
    lookup.count = None
    lookup.end = None
    assert lookup.sanity_check() is None

    lookup.reset()
    lookup.count = 5
    lookup.end = 10
    try:
        lookup.sanity_check()
        assert False
    except AnsibleError:
        assert True

    lookup.reset()
    lookup.end = 10
    lookup.stride = 2
    assert lookup.sanity_check() is None

    lookup.reset()
    lookup.end = 10
    lookup.stride = -2
    assert lookup.sanity_check() is None

    lookup.reset()
    lookup.end = 10
    lookup.stride = 0
    assert lookup.sanity_check() is None


# Generated at 2022-06-21 06:27:42.165325
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Call LookupModule.generate_sequence with valid input arguments
    start = 0
    end = 10
    stride = 1
    format = ""
    lookup_module = LookupModule()
    result = lookup_module.generate_sequence(start, end, stride, format)
    # Assert
    assert result != None


# Generated at 2022-06-21 06:27:53.559143
# Unit test for method generate_sequence of class LookupModule

# Generated at 2022-06-21 06:27:58.221168
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    lm.reset()
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == None
    assert lm.stride == 1
    assert lm.format == "%d"
    

# Generated at 2022-06-21 06:28:01.051834
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm1 = LookupModule()
    assert isinstance(lm1, LookupModule)


# Generated at 2022-06-21 06:28:09.549571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing LookupModule_run')
    # testing LookupModule_run with AnsibleError
    print('\tTesting with AnsibleError')
    look = LookupModule()
    try:
        look.run(terms = '', variables = {})
    except AnsibleError as e:
        print('\t\tCorrectly raised AnsibleError: "%s"' % e)
    else:
        print('\t\tIncorrectly failed to raise AnsibleError "%s"' % e)
    # testing LookupModule_run with AssertionError
    print('\tTesting with AssertionError')
    try:
        look.run(terms = [None], variables = {})
    except AssertionError as e:
        print('\t\tCorrectly raised AssertionError: "%s"' % e)

# Generated at 2022-06-21 06:28:17.880444
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Skip test if we can't import LookupModule
    try:
        from ansible.plugins.lookup import LookupModule
    except ImportError:
        return

    # Create LookupModule object
    lookup_module = LookupModule()

    # Assert that the function returns True for
    # correct arguments and initializes the
    # correct fields of lookup module
    assert lookup_module.parse_simple_args('5') == True
    assert lookup_module.start == 1
    assert lookup_module.count == 5
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'

    # Assert that the function returns True for
    # correct arguments and initializes the
    # correct fields of lookup module

# Generated at 2022-06-21 06:28:26.238816
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    test = LookupModule()
    test.reset()
    # count=0 and count=1, return true, else failed
    test.start = 0
    test.end = 0
    test.stride = 0
    assert test.sanity_check()
    test.end = 1
    assert test.sanity_check()
    test.start = 1
    test.end = 0
    assert test.sanity_check()
    # count=0 and count=1, return true, else failed
    test.end = 1
    assert test.sanity_check()
    test.start = 1
    test.end = 0
    assert test.sanity_check()
    # start > end, return true, else failed
    test.start = 10
    test.end = 1
    assert test.sanity_check()
    # stride

# Generated at 2022-06-21 06:28:39.058792
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()
    assert lm.parse_simple_args("0-100") == True
    assert lm.start == 0
    assert lm.end == 100
    assert lm.stride == 1
    assert lm.format == "%d"

    lm = LookupModule()
    assert lm.parse_simple_args("0x10-100") == True
    assert lm.start == 16
    assert lm.end == 100
    assert lm.stride == 1
    assert lm.format == "%d"

    lm = LookupModule()
    assert lm.parse_simple_args("0x10-0x100") == True
    assert lm.start == 16
    assert lm.end == 256
    assert lm.stride == 1
    assert lm.format

# Generated at 2022-06-21 06:28:55.089766
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    lookup.reset()
    lookup.parse_kv_args({"start": "1", "end": "3", "stride": "2", "format": "%d"})
    assert lookup.start == 1
    assert lookup.end == 3
    assert lookup.count is None
    assert lookup.stride == 2
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_kv_args({"start": "0x0a", "count": "5", "format": "%04x"})
    assert lookup.start == 0x0a
    assert lookup.end == 0x0f
    assert lookup.count is None
    assert lookup.stride == 1
    assert lookup.format == "%04x"


# Generated at 2022-06-21 06:28:58.788898
# Unit test for constructor of class LookupModule
def test_LookupModule():
    sequence_instance = LookupModule()
    assert sequence_instance.stride == 1
    assert sequence_instance.format == "%d"

if __name__ == '__main__':
    pytest.main(args=[__file__])

# Generated at 2022-06-21 06:29:04.750608
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    lookup.reset()

    args = {'start': '5', 'end': '8', 'stride': '2', 'format': '%02d'}
    lookup.parse_kv_args(args)
    assert lookup.start == 5
    assert lookup.end == 8
    assert lookup.stride == 2
    assert lookup.format == '%02d'
    assert lookup.count is None



# Generated at 2022-06-21 06:29:06.485700
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert len(lm.run(['1'], dict())) == 1

# Generated at 2022-06-21 06:29:18.910563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result_0 = lookup_module.run([], dict(), dict())
    assert len(result_0) == 0
    result_1 = lookup_module.run(['4:host%02d'], dict(), dict())
    assert result_1 == ['host01', 'host02', 'host03', 'host04']
    result_2 = lookup_module.run(['10:host%02d'], dict(), dict())
    assert result_2 == ['host01', 'host02', 'host03', 'host04', 'host05', 'host06', 'host07', 'host08', 'host09', 'host10']
    result_3 = lookup_module.run(['10-16'], dict(), dict())

# Generated at 2022-06-21 06:29:20.366577
# Unit test for constructor of class LookupModule
def test_LookupModule():
    p = LookupModule()
    assert p


# Generated at 2022-06-21 06:29:30.558551
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()

    # check if all variables are reset
    lookup_module.start = 100
    lookup_module.count = 100
    lookup_module.end = 100
    lookup_module.stride = 100
    lookup_module.format = 'Test format'

    lookup_module.parse_kv_args({'start': '0', 'end': '3', 'stride': '1', 'format': '0x%02x'})

    assert (lookup_module.start == 0), lookup_module.start
    assert (lookup_module.count is None), lookup_module.count
    assert (lookup_module.end == 3), lookup_module.end
    assert (lookup_module.stride == 1), lookup_module.stride

# Generated at 2022-06-21 06:29:38.493920
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Setup
    lookup_obj = LookupModule()
    lookup_obj.start    = 1
    lookup_obj.stride   = 2
    lookup_obj.end      = 12
    lookup_obj.format   = "%d"

    # Exercise
    result = lookup_obj.generate_sequence()
    # Verify
    assert result == ['1', '3', '5', '7', '9', '11']



# Generated at 2022-06-21 06:29:42.203859
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    L = LookupModule()
    L.reset()
    assert L.start == 1
    assert L.count is None
    assert L.end is None
    assert L.stride == 1
    assert L.format == "%d"


# Generated at 2022-06-21 06:29:53.581596
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_obj = LookupModule()
    lookup_obj.start = 1
    lookup_obj.end = 10
    lookup_obj.stride = 1
    lookup_obj.format = "%d"

    # positive test
    lookup_obj.sanity_check()

    # negative test, missing end and count
    lookup_obj.end = None
    lookup_obj.count = None
    try:
        lookup_obj.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")

    # negative test, both end and count present
    lookup_obj.end = 10
    lookup_obj.count = 10
    try:
        lookup_obj.sanity_check()
    except AnsibleError:
        pass
    else:
        raise Assert

# Generated at 2022-06-21 06:30:02.963383
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    """
    Unit test for method reset of class LookupModule
    """
    lookup_mod = LookupModule()
    lookup_mod.reset()
    assert(lookup_mod.start == 1)
    assert(lookup_mod.end is None)
    assert(lookup_mod.stride == 1)
    assert(lookup_mod.count is None)
    assert(lookup_mod.format == '%d')


# Generated at 2022-06-21 06:30:09.860021
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    term = None
    variables = None
    lm = LookupModule(term, variables)
    lm.reset()

    lm.count = 0
    lm.start = 1
    lm.end = 1
    lm.stride = 1
    lm.format = "%d"
    if lm.count is None and lm.end is None:
        raise AnsibleError("must specify count or end in with_sequence")
    elif lm.count is not None and lm.end is not None:
        raise AnsibleError("can't specify both count and end in with_sequence")
    elif lm.count is not None:
        # convert count to end
        if lm.count != 0:
            lm.end = lm.start + lm.count * lm.stride

# Generated at 2022-06-21 06:30:21.535757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'start=0 end=4 count=3 stride=2 format=Test%02d'
    terms = [term]
    lookup_obj = LookupModule()
    result = lookup_obj.run(terms, dict())
    assert result == ['Test00', 'Test02', 'Test04']

    term = '0-4/2:Test%02d'
    terms = [term]
    result = lookup_obj.run(terms, dict())
    assert result == ['Test00', 'Test02', 'Test04']

    term = '1-100'
    terms = [term]
    result = lookup_obj.run(terms, dict())

# Generated at 2022-06-21 06:30:31.214706
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    try:
        inst = LookupModule()
        inst.count = 1
        inst.sanity_check()
    except AnsibleError:
        print("count=1 is invalid")

    try:
        inst = LookupModule()
        inst.count = 1
        inst.end = 1
        inst.sanity_check()
    except AnsibleError:
        print("count=1 and end=1 is invalid")

    try:
        inst = LookupModule()
        inst.count = 1
        inst.stride = 10
        inst.stride = 0
        inst.sanity_check()
    except AnsibleError:
        print("stride=0 is invalid")


# Generated at 2022-06-21 06:30:38.482868
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    l.start = 10
    l.end = 20
    l.count = 3
    l.stride = 2
    l.format = "%d"
    l.reset()
    assert l.start == 1
    assert l.end is None
    assert l.count is None
    assert l.stride == 1
    assert l.format == "%d"


# Generated at 2022-06-21 06:30:40.066152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test the constructor")
    lookup_plugin = LookupModule()


# Generated at 2022-06-21 06:30:51.654674
# Unit test for method generate_sequence of class LookupModule

# Generated at 2022-06-21 06:30:56.911209
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lkup = LookupModule()
    lkup.end = 5
    try:
        lkup.sanity_check()
    except AnsibleError:
        raise AssertionError('sanity_check() raised AnsibleError with end=5')
    lkup.count = 5
    try:
        lkup.sanity_check()
        raise AssertionError('sanity_check() did not raise AnsibleError with both end and count defined')
    except AnsibleError:
        pass

# Generated at 2022-06-21 06:31:07.679281
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lm = LookupModule()
    lm.start = 0
    lm.end = 9
    lm.stride = 1
    lm.format = "%d"

    assert list(lm.generate_sequence()) == ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
    lm.format = "%04d"
    assert list(lm.generate_sequence()) == ["0000", "0001", "0002", "0003", "0004", "0005", "0006", "0007", "0008", "0009"]
    lm.stride = 2
    assert list(lm.generate_sequence()) == ["0000", "0002", "0004", "0006", "0008"]
    lm.start = 5


# Generated at 2022-06-21 06:31:17.905654
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # initialise object as well as class attributes
    obj = LookupModule()
    try:
        obj.sanity_check()
    except AnsibleError:
        # now check the start and end attributes
        if obj.start == 0:
            if obj.end == 0:
                pass
            else:
                raise AssertionError()
        else:
            raise AssertionError()

    obj.end = 2
    try:
        obj.sanity_check()
    except AnsibleError:
        if obj.start == 0:
            if obj.end == 1:
                pass
            else:
                raise AssertionError()
        else:
            raise AssertionError()

    obj.start = 2
    obj.end = 2

# Generated at 2022-06-21 06:31:27.628078
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_mod = LookupModule()
    lookup_mod.count = 10
    lookup_mod.stride = 1
    try:
        lookup_mod.sanity_check()
    except AnsibleError as e:
        assert "can't specify both count and end in with_sequence" == e.message
    else:
        raise Exception("expected AnsibleError")
    lookup_mod.count = None
    lookup_mod.end = 10
    lookup_mod.stride = 1
    try:
        lookup_mod.sanity_check()
    except AnsibleError as e:
        assert "can't specify both count and end in with_sequence" == e.message
    else:
        raise Exception("expected AnsibleError")
    lookup_mod.count = 10
    lookup_mod.end = 2

# Generated at 2022-06-21 06:31:35.655359
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    strings = ['start=5 end=8', 'start=5', '1-3', 'start=5 count=4']
    for string in strings:
        lm = LookupModule()
        lm.run([string], {})
        lm.reset()
        assert lm.start == 1 and lm.count is None and lm.end is None and \
            lm.stride == 1 and lm.format == '%d'



# Generated at 2022-06-21 06:31:47.046380
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # error for count and end
    lookup_module = LookupModule()  # noqa
    lookup_module.reset()
    lookup_module.count = 10
    lookup_module.end = 10
    try:
        lookup_module.sanity_check()
        assert False
    except AnsibleError as e:
        assert "can't specify both count and end in with_sequence" in str(e)

    # error for no count and end
    lookup_module = LookupModule()  # noqa
    lookup_module.reset()
    try:
        lookup_module.sanity_check()
        assert False
    except AnsibleError as e:
        assert "must specify count or end in with_sequence" in str(e)

    # error for negative stride
    lookup_module = LookupModule()  # noqa
    lookup_

# Generated at 2022-06-21 06:31:53.617108
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    """
    Test - Method 'parse_kv_args' of class 'LookupModule'
    """
    lookup_module = LookupModule()
    lookup_module.parse_kv_args({'start': '1', 'end': '10'})
    assert lookup_module.start == 1
    assert lookup_module.end == 10
    assert lookup_module.format == '%d'


# Generated at 2022-06-21 06:32:07.091041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_gen = LookupModule()
    lookup_gen.reset()
    assert(lookup_gen.run(["0xfe-0x103:0x%02x"], []) == ['0xfe', '0xff', '0x100', '0x101', '0x102'])
    lookup_gen.reset()
    assert(lookup_gen.run(["0xfe-0x103"], []) == ['0xfe', '0xff', '0x100', '0x101', '0x102'])
    lookup_gen.reset()
    assert(lookup_gen.run(["0x100-0x101"], []) == ['0x100', '0x101'])
    lookup_gen.reset()

# Generated at 2022-06-21 06:32:19.687534
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    l = LookupModule()
    l.start = 1
    l.end = 3
    l.stride = 1
    l.sanity_check()
    assert(l.count == 23, "count is not None when end and stride are positive")

    l = LookupModule()
    l.start = 5
    l.end = 2
    l.stride = 2
    l.sanity_check()
    assert(l.count == 1, "count is not None when end is less than start, stride is positive")

    l = LookupModule()
    l.start = 5
    l.end = 5
    l.count = 1
    l.sanity_check()
    assert(l.stride == 0, "stride is not None when end is equal to start and count=1")

    l = LookupModule()

# Generated at 2022-06-21 06:32:23.017820
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    assert(l.start == 1)
    assert(l.count is None)
    assert(l.end is None)
    assert(l.stride == 1)
    assert(l.format == "%d")


# Generated at 2022-06-21 06:32:36.569419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test of LookupModule"""
    import copy
    import sys

    # Make sure that we are using python.exe from the original ansible install
    PYTHON_EXE = "python.exe"

    if sys.platform.lower() != "win32":
        PYTHON_EXE = "./python"

    my_env = copy.deepcopy(os.environ)
    my_env["PATH"] = os.path.dirname(sys.executable) + os.pathsep + os.environ["PATH"]

    lookup_path = os.path.join(os.path.dirname(__file__), "..", "..")
    lookup_cmd = [PYTHON_EXE, "-m", "ansible.plugins.lookup.sequence"]

    # Test with_sequence plugin

# Generated at 2022-06-21 06:32:42.902191
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    check = LookupModule()
    check.start = 10
    check.count = 5
    check.end = 7
    check.stride = 2
    check.format = "%04d"
    check.reset()
    assert check.start == 1
    assert check.count == None
    assert check.end == None
    assert check.stride == 1
    assert check.format == "%d"


# Generated at 2022-06-21 06:32:45.649505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['start=0 end=2']
    result = lm.run(terms, None)
    assert result ==['0','1','2']


# Generated at 2022-06-21 06:32:56.996068
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-21 06:33:04.604122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule().run([]) == [])
    assert(LookupModule().run([], []) == [])
    assert(LookupModule().run([], [], []) == [])
    
    l = LookupModule()
    l.generate_sequence = lambda: ["1", "2", "3", "4", "5"]
    assert(l.run(["1-5"]) == ["1", "2", "3", "4", "5"])
    assert(l.run(["1-10/2"]) == ["1", "3", "5", "7", "9"])
    assert(l.run(["4:host%02d"]) == ["host01", "host02", "host03", "host04"])


# Generated at 2022-06-21 06:33:14.377605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test(terms, variables):
        return LookupModule().run(terms=terms, variables=variables)

    assert test(terms=['-1-10/2'], variables={}) == ["0", "2", "4", "6", "8", "10"]
    assert test(terms=['2'], variables={}) == ["1", "2"]
    assert test(terms=['10-1'], variables={}) == ["10", "9", "8", "7", "6", "5", "4", "3", "2", "1"]

    assert test(terms=['10-1:test%02d'], variables={}) == ["test10", "test09", "test08", "test07", "test06", "test05", "test04", "test03", "test02", "test01"]


# Generated at 2022-06-21 06:33:25.799006
# Unit test for method parse_simple_args of class LookupModule

# Generated at 2022-06-21 06:33:36.590470
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    # Initializing a LookupModule object
    lookup_mod = LookupModule()
    lookup_mod.stride = 1

    # Test 1: check when both count and end is not specified
    lookup_mod.count = None
    lookup_mod.end = None
    try:
        lookup_mod.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised for the case when both count and end are not specified")

    # Test 2: check when both count and end are specified
    lookup_mod.count = 1
    lookup_mod.end = 2
    try:
        lookup_mod.sanity_check()
    except AnsibleError:
        pass

# Generated at 2022-06-21 06:33:42.270076
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    l = LookupModule()
    l.reset()

    # test parsing start
    l.parse_kv_args({"start": "10"})
    assert l.start == 10
    # test parsing end
    l.parse_kv_args({"end": "200"})
    assert l.end == 200
    # test parsing count
    l.parse_kv_args({"count": "20"})
    assert l.count == 20
    # test parsing stride
    l.parse_kv_args({"stride": "20"})
    assert l.stride == 20
    # test parsing format
    l.parse_kv_args({"format": "20"})
    assert l.format == "20"

    # test parsing multiple arguments
    l.reset()
    l.parse_kv_

# Generated at 2022-06-21 06:33:53.177253
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()

    # Test 1
    lookup_module.reset()
    lookup_module.parse_kv_args({'start': '1', 'end': '10'})
    results = lookup_module.generate_sequence()
    assert "1" in results
    assert "10" in results
    assert "11" not in results
    assert "20" not in results

    # Test 2
    lookup_module.reset()
    lookup_module.parse_kv_args({'start': '10', 'end': '1', 'stride': '-1'})
    results = lookup_module.generate_sequence()
    assert "1" in results
    assert "10" in results
    assert "11" not in results
    assert "20" not in results

    # Test 3
    lookup_module

# Generated at 2022-06-21 06:33:56.659909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['start=1 end=5']
    variables = {}
    lookup_module = LookupModule()
    results = lookup_module.run(terms, variables)
    assert isinstance(results, list) is True


# Generated at 2022-06-21 06:34:02.769942
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    lookup.parse_kv_args(parse_kv("start=4 end=16 stride=2 format=0x%02x"))
    assert lookup.start == 4
    assert lookup.end == 16
    assert lookup.stride == 2
    assert lookup.format == "0x%02x"
    assert lookup.count == None
    try:
        lookup.parse_kv_args(parse_kv("start=four end=16 stride=2 format=0x%02x"))
        assert False, "parse_kv_args() should have failed"
    except AnsibleError:
        pass


# Generated at 2022-06-21 06:34:14.311963
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.count = 10
    lookup_module.stride = 2
    lookup_module.format = "%d"

    # Check Exception
    try:
        lookup_module.sanity_check()
        assert False
    except AnsibleError:
        pass # Expected

    # Check Exception
    lookup_module.count = None
    try:
        lookup_module.sanity_check()
        assert False
    except AnsibleError:
        pass # Expected

    # Check Exception
    lookup_module.count = 1
    lookup_module.end = 1
    try:
        lookup_module.sanity_check()
        assert False
    except AnsibleError:
        pass # Expected

    # Check

# Generated at 2022-06-21 06:34:59.078206
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import pytest
    l = LookupModule()
    l.reset()
    with pytest.raises(AnsibleError) as sanity_check:
        l.stride = 1
        l.sanity_check()
    assert 'must specify count or end in' in str(sanity_check.value)
    with pytest.raises(AnsibleError) as sanity_check:
        l.count = 5
        l.end = 10
        l.sanity_check()
    assert 'can\'t specify both count and end in' in str(sanity_check.value)
    with pytest.raises(AnsibleError) as sanity_check:
        l.stride = 1
        l.start = 10
        l.end = 5
        l.sanity_check()

# Generated at 2022-06-21 06:35:07.596872
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """Unit test for LookupModule.parse_simple_args"""
    lookup_module = LookupModule()
    seq0 = "5"
    seq1 = "5-8"
    seq2 = "2-10/2"
    seq3 = "4:host%02d"
    seq4 = "10-0/-1"

    assert lookup_module.parse_simple_args(seq0) is True
    assert lookup_module.start == 1
    assert lookup_module.end == 5
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"

    lookup_module.parse_simple_args(seq1)
    assert lookup_module.start == 5
    assert lookup_module.end == 8
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"

# Generated at 2022-06-21 06:35:08.278772
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 06:35:16.556159
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    module = LookupModule()
    module.parse_kv_args( {'start': '5', 'end': '11', 'stride': '2', 'format': '%02x'} )
    assert module.start == 5, "start has wrong value"
    assert module.end == 11, "end has wrong value"
    assert module.stride == 2, "stride has wrong value"
    assert module.format == '%02x', "format has wrong value"


# Generated at 2022-06-21 06:35:21.490841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    assert lookup_module is not None
    assert lookup_module.start == 1
    assert lookup_module.count is None
    assert lookup_module.end is None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"


# Unit tests for method reset() of class LookupModule

# Generated at 2022-06-21 06:35:31.235502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=["end=10"], variables=None, **{})
    assert result == [
        '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'
    ]

    result = lookup_module.run(terms=["end=10","format=testuser%02x"], variables=None, **{})
    assert result == [
        'testuser01', 'testuser02', 'testuser03', 'testuser04', 'testuser05', 'testuser06', 'testuser07', 'testuser08', 'testuser09', 'testuser0a'
    ]

    result = lookup_module.run(terms=["start=4 end=16 stride=2"], variables=None, **{})


# Generated at 2022-06-21 06:35:36.997464
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    ansible_module = LookupModule()
    assert not ansible_module.parse_simple_args("20")
    assert not ansible_module.parse_simple_args("20-30")
    ansible_module.parse_simple_args("5-8")
    assert ansible_module.start == 5
    assert ansible_module.end == 8
    ansible_module.parse_simple_args("2-10/2")
    assert ansible_module.start == 2
    assert ansible_module.end == 10
    assert ansible_module.stride == 2
    ansible_module.parse_simple_args("3-20/-3")
    assert ansible_module.start == 3
    assert ansible_module.end == 20
    assert ansible_module.stride == -3

# Generated at 2022-06-21 06:35:44.292928
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.reset()

    lookup.start = 1
    assert(lookup.start == 1)

    lookup.count = None
    assert(lookup.count == None)

    lookup.end = None
    assert(lookup.end == None)

    lookup.stride = 1
    assert(lookup.stride == 1)

    lookup.format = "%d"
    assert(lookup.format == "%d")


# Generated at 2022-06-21 06:35:49.584814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    sequence_class = LookupModule()
    assert sequence_class is not None
    assert sequence_class.start   == 1
    assert sequence_class.count   is None
    assert sequence_class.end     is None
    assert sequence_class.stride  == 1
    assert sequence_class.format  == "%d"

    print ('Test: LookupModule class passed.')



# Generated at 2022-06-21 06:35:54.100855
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    result = dict()
    result['start']= 1
    result['end'] = 4
    result['stride'] = 2
    result['format'] = 'format'
    l = LookupModule()
    l.parse_kv_args(result)
    assert result['start'] == 1
    assert result['end'] == 4
    assert result['stride'] == 2
    assert result['format'] == 'format'


# Generated at 2022-06-21 06:36:16.698047
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    module = LookupModule()
    module.reset()
    assert hasattr(module, 'start')
    assert hasattr(module, 'count')
    assert hasattr(module, 'end')
    assert hasattr(module, 'stride')
    assert hasattr(module, 'format')
    assert module.start == 1
    assert module.count is None
    assert module.end is None
    assert module.stride == 1
    assert module.format == "%d"



# Generated at 2022-06-21 06:36:20.217945
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lkp = LookupModule()
    lkp.start = 0
    lkp.end = 4
    lkp.stride = 1
    lkp.format = '%d'
    res = lkp.generate_sequence()
    for i, val in enumerate(res):
        assert i == int(val)


# Generated at 2022-06-21 06:36:31.550594
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    x = LookupModule()
    x.start = 1
    x.end = 5
    x.stride = 2

    x.sanity_check()
    assert True

    x.start = 0
    x.count = 5
    x.stride = 2
    x.sanity_check()
    assert True

    x.count = None
    x.end = 5
    x.sanity_check()
    assert True

    x.start = 0
    x.count = None
    x.end = 5
    x.stride = -2
    x.sanity_check()
    assert True

    x.start = 0
    x.count = None
    x.end = 5
    x.stride = 2

# Generated at 2022-06-21 06:36:39.543953
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    """testing if parse_kv_args works correctly"""

    class DummyClass(LookupModule):
        def run(self):
            return 'pass'

    # check if parse_kv_args function raises an error if an argument is not
    # in the form of key=value pair
    lookup_plugin = DummyClass()
    args = ['test', '1234']
    try:
        lookup_plugin.parse_kv_args(args)
    except AnsibleError:
        pass
    else:
        assert False, 'Exception not raised'

    # check if parse_kv_args function returns the correct dictionary for
    # the given arguments in key=value pair
    lookup_plugin = DummyClass()
    args = 'start=5 end=11 stride=2 format=0x%02x'

# Generated at 2022-06-21 06:36:51.848225
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    test_class = LookupModule(None, None, None, {})
    test_class.count = None
    test_class.end = 3
    test_class.start = 0
    test_class.sanity_check()
    assert test_class.end == 3
    assert test_class.start == 0
    assert test_class.count == None

    test_class.count = 1
    test_class.end = None
    test_class.start = 0
    test_class.sanity_check()
    assert test_class.end == 1
    assert test_class.start == 0
    assert test_class.count == None

    test_class.start = 1
    test_class.count = 1
    test_class.sanity_check()
    assert test_class.end == 1

# Generated at 2022-06-21 06:36:59.446075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    # te_start = 1
    te_count = 5
    te_end = None
    te_stride = 1
    te_format = "%d"
    lmod = LookupModule()
    lmod.start = te_start
    lmod.count = te_count
    lmod.end = te_end
    lmod.stride = te_stride
    lmod.format = te_format

    # Act
    sequence = list(lmod.generate_sequence())

    # Assert
    assert sequence == ['5','4','3','2','1']

# Generated at 2022-06-21 06:37:06.037778
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    l = LookupModule()

    l.count = 10
    l.start = 10
    l.stride = 1
    l.sanity_check()

    l.reset()
    l.end = 10
    l.start = 10
    l.stride = 1
    l.sanity_check()

    l.reset()
    l.end = 10
    try:
        l.sanity_check()
    except Exception as e:
        assert isinstance(e, AnsibleError)
        pass
    else:
        assert False

    l.reset()
    l.end = 10
    l.count = 10
    try:
        l.sanity_check()
    except Exception as e:
        assert isinstance(e, AnsibleError)
        pass
    else:
        assert False

    l.reset

# Generated at 2022-06-21 06:37:17.554884
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
	# Test case when self.count != 0 and self.end == None
	lookupModule = LookupModule()
	lookupModule.count = 1
	lookupModule.end = None
	lookupModule.sanity_check()
	assert lookupModule.end == 2
	# Test case when self.count == 0 and self.end == None
	lookupModule = LookupModule()
	lookupModule.count = 0
	lookupModule.end = None
	lookupModule.sanity_check()
	assert lookupModule.end == 0
	assert lookupModule.start == 0
	assert lookupModule.stride == 0
	# Test case when self.count != 0 and self.end != None
	lookupModule = LookupModule()
	lookupModule.count = 1
	lookupModule.end = 1