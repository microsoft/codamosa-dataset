

# Generated at 2022-06-21 06:27:35.804692
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    cls = LookupModule()
    cls.reset()
    assert cls.end is None
    assert cls.format == '%d'
    assert cls.start == 1
    assert cls.stride == 1
    assert cls.count is None

    args = dict(end='2')
    cls.parse_kv_args(args)
    assert cls.end == 2
    assert cls.format == '%d'
    assert cls.start == 1
    assert cls.stride == 1
    assert cls.count is None

    args = dict(start='2')
    cls.parse_kv_args(args)
    assert cls.end == 2
    assert cls.format == '%d'
    assert cls.start == 2
    assert cls.stride

# Generated at 2022-06-21 06:27:48.559743
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:27:49.577491
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert(LookupModule.reset)

# Generated at 2022-06-21 06:27:56.660736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    from ansible.utils.unicode import to_bytes

    class DummyLookupBase(LookupBase):
        pass

    module = DummyLookupBase()

    # test start, end, format and stride
    terms = ['start=1 end=5 format=%d stride=2']
    results = module.run(terms, None)
    assert results == [b'1', b'3', b'5']

    # test start, end, format and negative stride
    terms = ['start=4 end=0 format=%d stride=-2']
    results = module.run(terms, None)
    assert results == [b'4', b'2', b'0']

    # test start, end in octal, format and stride
    terms = ['start=01 end=05 format=%d stride=1']
   

# Generated at 2022-06-21 06:28:04.248726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(
        [
            "1-5:testuser%02x",
            "4-8",
            "start=0 end=32 format=testuser%02x",
            "start=4 end=16 stride=2",
            "count=5",
            "count=4",
            "start=10 end=0 stride=-1",
            "start=1 end=10",
        ],
    )


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:28:06.568117
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'plugins.lookup' in str(LookupModule)
    assert 'Ansible' in str(LookupModule)

# Generated at 2022-06-21 06:28:18.772444
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_instance = LookupModule()

    # Three consecutive steps, arguments passed as simple strings
    args = {"start": "0", "count": "3", "stride": "1", "format": "Hello%02d"}
    lookup_instance.reset()
    lookup_instance.parse_kv_args(args)

    lookup_instance.sanity_check()
    assert(lookup_instance.start == 0)
    assert(lookup_instance.stride == 1)
    assert(lookup_instance.end == 2)
    assert(lookup_instance.format == "Hello%02d")

    # Three consecutive steps, arguments passed as integers
    args = {"start": 0, "count": 3, "stride": 1, "format": "Hello%02d"}
    lookup_instance.reset()
    lookup_instance.parse

# Generated at 2022-06-21 06:28:22.241286
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    assert lookup.start  == 1
    assert lookup.count  == None
    assert lookup.end    == None
    assert lookup.stride == 1
    assert lookup.format == "%d"



# Generated at 2022-06-21 06:28:34.622965
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.reset()
    try:
        lookup_module.parse_kv_args(parse_kv('start=1 end=5 count=10'))
    except AnsibleError:
        pass
    else:
        raise Exception('Failure')

    lookup_module.reset()
    lookup_module.parse_kv_args(parse_kv('start=1 end=10'))
    assert (lookup_module.start == 1)
    assert (lookup_module.end == 10)
    assert (lookup_module.stride == 1)
    assert (lookup_module.format == '%d')

    lookup_module.reset()
    lookup_module.parse_kv_args(parse_kv('end=10 start=3 stride=3'))
   

# Generated at 2022-06-21 06:28:44.565552
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import pytest
    lookup = LookupModule()
    lookup.end = 10
    lookup.stride = 1
    lookup.start = 0
    lookup.format = '%d'
    lookup.count = None

    with pytest.raises(AnsibleError) as excinfo:
        lookup.sanity_check()
    assert 'must specify count or end in with_sequence' in str(excinfo.value)

    lookup.count = 0
    lookup.sanity_check()
    assert lookup.start == 0
    assert lookup.end == 0
    assert lookup.stride == 0
    assert lookup.count is None

    lookup.count = 1
    lookup.sanity_check()
    assert lookup.end == 1

    lookup.count = 2
    lookup.sanity_check()
    assert lookup.end == 3

   

# Generated at 2022-06-21 06:28:51.658014
# Unit test for constructor of class LookupModule
def test_LookupModule():
   # test_LookupModule()
   look = LookupModule()
   look.run(["start=5 end=11 stride=2 format=0x%02x"], variables=["start=5 end=11 stride=2 format=0x%02x"])

# Generated at 2022-06-21 06:28:58.365372
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    from ansible.plugins.lookup import LookupBase
    lookup = LookupBase()
    assert not hasattr(lookup, 'start')
    assert not hasattr(lookup, 'end')
    assert not hasattr(lookup, 'stride')
    assert not hasattr(lookup, 'format')
    assert not hasattr(lookup, 'count')


# Generated at 2022-06-21 06:29:02.643902
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    assert LookupModule.parse_kv_args(None, {'start': '0x0F01', 'count': '2', 'format': '%s'}) == {'count': 2, 'format': '%s', 'start': 3841}


# Generated at 2022-06-21 06:29:04.252915
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    assert type(lookup) == LookupModule
    lookup.reset()


# Generated at 2022-06-21 06:29:10.574674
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()
    lookup_module.start = 10
    lookup_module.end = 2
    lookup_module.stride = 5
    lookup_module.format = '%d'
    lookup_module.reset()
    assert lookup_module.start == 1
    assert lookup_module.end is None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"


# Generated at 2022-06-21 06:29:15.312568
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    l.reset()
    assert l.start == 1
    assert l.count == None
    assert l.end == None
    assert l.stride == 1
    assert l.format == "%d"



# Generated at 2022-06-21 06:29:21.371393
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    args = {'start': '3', 'count': '3', 'stride': '0', 'format': "format"}
    module = LookupModule()
    module.parse_kv_args(args)
    assert module.start == 3
    assert module.count == 3
    assert module.stride == 0
    assert module.format == "format"
    assert not hasattr(module, 'end')


# Generated at 2022-06-21 06:29:30.960920
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    items = ['5',
             '5-8',
             '2-10/2',
             '4:host%02d',
             'start=5 end=11 stride=2 format=0x%02x',
             ]

# Generated at 2022-06-21 06:29:36.032556
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    sut = LookupModule()
    sut.start = 0
    sut.count = 0
    sut.end = 0
    sut.stride = 0

    # Make sure the method does not raise an exception for a valid case
    assert sut.sanity_check()

# Generated at 2022-06-21 06:29:46.563984
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lm = LookupModule()
    lm.stride = 1
    lm.count = None

    lm.start = 10
    lm.end = 0
    lm.sanity_check()

    lm.start = 0
    lm.end = 10
    lm.sanity_check()

    lm.start = 0
    lm.end = 0
    lm.sanity_check()

    lm.start = 0
    lm.end = -1
    try:
        lm.sanity_check()
    except AnsibleError as e:
        msg = "to count backwards make stride negative"
        assert msg in str(e), "Expected AnsibleError with '%s', got '%s'" % (msg, str(e))

    lm.end = 10
    l

# Generated at 2022-06-21 06:30:12.321700
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    tester = LookupModule()

    # valid arguments
    assert tester.parse_simple_args("1-10") is True
    assert tester.start == 1
    assert tester.end == 10
    assert tester.stride == 1
    assert tester.format == "%d"
    tester.reset()
    assert tester.parse_simple_args("2-9/2") is True
    assert tester.start == 2
    assert tester.end == 9
    assert tester.stride == 2
    assert tester.format == "%d"
    tester.reset()
    assert tester.parse_simple_args("2-9/2:host%02d") is True
    assert tester.start == 2
    assert tester.end == 9
    assert tester.stride == 2

# Generated at 2022-06-21 06:30:24.531209
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        u"start=1 end=11 stride=2 format=0x%02x",
        u"start=0x0f00 count=4 format=%04x",
        u"start=0 count=5 stride=2",
        u"start=1 count=5 stride=2"
    ]

    lookup_obj = LookupModule()

    result = lookup_obj.run(terms, dict())

    # Check the type of result, should be list
    assert(type(result) is list)

    # Check the values of result

# Generated at 2022-06-21 06:30:32.725296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule
    """

    # Test case: 1
    terms = ["5-8/2:%02x"]
    sequence_obj = LookupModule()
    result = sequence_obj.run(terms=terms, variables={})
    assert result == ["05", "07"]

    # Test case: 2
    terms = ['5-8:%02x']
    sequence_obj = LookupModule()
    result = sequence_obj.run(terms=terms, variables={})
    assert result == ["05", "06", "07", "08"]

    # Test case: 3
    terms = ['start=5 end=8 format=%02x']
    sequence_obj = LookupModule()
    result = sequence_obj.run(terms=terms, variables={})

# Generated at 2022-06-21 06:30:43.180383
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    result = LookupModule().parse_simple_args('3-8')
    assert result is True
    result = LookupModule().parse_simple_args('3-8/2')
    assert result is True
    result = LookupModule().parse_simple_args('3-8:test%02d')
    assert result is True
    result = LookupModule().parse_simple_args('3-8/2:test%02d')
    assert result is True
    result = LookupModule().parse_simple_args('7/2:test%02d')
    assert result is True
    result = LookupModule().parse_simple_args('8:test%02d')
    assert result is True

# Generated at 2022-06-21 06:30:54.634561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #import doctest
    #doctest.testmod(verbose=False)
    import unittest
    import copy
    from unittest import TestCase
    from collections import OrderedDict

    def get_terms(args):
        lu = LookupModule()
        lu.parse_kv_args(parse_kv(args))
        lu.sanity_check()
        rv = OrderedDict([
            ("start", lu.start),
            ("end", lu.end),
            ("stride", lu.stride),
            ("format", lu.format),
            ("values", list(lu.generate_sequence()))
        ])
        del lu
        return rv


# Generated at 2022-06-21 06:31:06.579279
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    term = dict(
        start=0,
        end=2,
        stride=2,
        format="%04x"
    )
    expected_result = dict(
        start=0,
        end=2,
        stride=2,
        format="%04x",
        count=None
    )
    result = parse_kv_args(term)
    print(result)
    assert result == expected_result

    term = dict(
        start=0,
        end=2,
        stride=2,
        format="%04x",
        count=2
    )
    expected_result = dict(
        start=0,
        end=None,
        stride=2,
        format="%04x",
        count=2
    )
    result = parse_kv_args(term)


# Generated at 2022-06-21 06:31:17.328673
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lm = LookupModule()
    lm.reset()
    lm.end = 10

    lm.sanity_check()
    assert lm.start == 1
    assert lm.end == 10
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()
    lm.count = 10
    lm.sanity_check()
    assert lm.start == 1
    assert lm.end == 10
    assert lm.stride == 1
    assert lm.format == "%d"

    lm.reset()
    lm.start = 1
    lm.count = 10
    lm.stride = 5
    lm.sanity_check()
    assert lm.start == 1
    assert lm.end == 26

# Generated at 2022-06-21 06:31:29.726370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #  A test case for with_sequence: start=0 end=32 format=testuser%02x
    lookup_module = LookupModule()
    lookup_module_results = lookup_module.run(["0-32/1:testuser%02x"], [])

# Generated at 2022-06-21 06:31:40.625182
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    """create a set of integers from which to generate a sequence"""
    start = 10
    end = 25
    stride = 3
    format = "%d"

    """create sequence generator and get its results"""
    test_sequence = LookupModule.generate_sequence(None, start, end, stride, format)
    results = list(test_sequence)

    """the sequence should be as long as expected"""
    expected_length = (end - start)/stride + 1

    assert len(results) == expected_length, "Sequence length is %d, not %d as expected" % (len(results), expected_length)

    i = start
    for x in results:
        assert int(x) == i, "Expected %d, got %s" % (i, x)
        i += stride

# Generated at 2022-06-21 06:31:50.670545
# Unit test for method parse_simple_args of class LookupModule

# Generated at 2022-06-21 06:32:00.702917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()
    assert isinstance(lookup_class, LookupModule), "Test failed"


# Generated at 2022-06-21 06:32:12.785445
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    """ Test reset() """

    lookup = LookupModule()
    assert lookup.start == 1
    assert lookup.end is None
    assert lookup.count is None
    assert lookup.stride == 1
    assert lookup.format == '%d'

    lookup.start = 2
    lookup.end = 4
    lookup.count = 5
    lookup.stride = 3
    lookup.format = '%s'

    assert lookup.start == 2
    assert lookup.end == 4
    assert lookup.count == 5
    assert lookup.stride == 3
    assert lookup.format == '%s'

    lookup.reset()

    assert lookup.start == 1
    assert lookup.end is None
    assert lookup.count is None
    assert lookup.stride == 1
    assert lookup.format == '%d'


# Generated at 2022-06-21 06:32:19.858505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import dependencies
    import sys
    import pytest

    # Import custom class
    sys.path.append('..')
    from lib.lookup_plugins.sequence import LookupModule

    # Define class obj
    lookup_module = LookupModule()

    # Test #1
    test_terms = ['start=0 end=5', 'start=1 count=5', 'start=1 end=5 stride=1', 'start=5 end=1 stride=-1', '0-10', '0-10:%03d']

# Generated at 2022-06-21 06:32:28.279329
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()

    # test that it works without parameters
    lookup.parse_kv_args({})
    assert lookup.start == 1
    assert lookup.end == None
    assert lookup.count == None
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.parse_kv_args({'start': '5', 'end': '10'})
    assert lookup.start == 5
    assert lookup.end == 10
    assert lookup.count == None
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_kv_args({'start': '5', 'count': '10'})
    assert lookup.start == 5
    assert lookup.end == 64
    assert lookup.count == 10
    assert lookup.stride

# Generated at 2022-06-21 06:32:34.597818
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 5
    lookup.end = 5
    lookup.count = 5
    lookup.stride = 5
    lookup.format = '%d'
    lookup.reset()
    assert lookup.start == 1
    assert lookup.end is None
    assert lookup.count is None
    assert lookup.stride == 1
    assert lookup.format == '%d'


# Generated at 2022-06-21 06:32:46.471461
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    o = LookupModule()
    o.reset()
    result = o.parse_simple_args("10")
    assert result is True, "The function should have returned True"
    assert o.start == 1 and o.end == 10 and o.stride == 1, "Did not parse 10 correctly"
    result = o.parse_simple_args("10-20")
    assert result is True, "The function should have returned True"
    assert o.start == 10 and o.end == 20 and o.stride == 1, "Did not parse 10-20 correctly"
    result = o.parse_simple_args("10-20/3")
    assert result is True, "The function should have returned True"
    assert o.start == 10 and o.end == 20 and o.stride == 3, "Did not parse 10-20/3 correctly"

# Generated at 2022-06-21 06:32:53.581066
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Normal use of the class
    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == "%d"
    # When parsing a simple argument term
    assert lookup.parse_simple_args("5-8")
    assert lookup.start == 5
    assert lookup.count is None
    assert lookup.end == 8
    assert lookup.stride == 1
    assert lookup.format == "%d"
    # When parsing a simple argument term
    assert lookup.parse_simple_args("2-10/2")
    assert lookup.start == 2
    assert lookup.count is None
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == "%d"
    # When parsing

# Generated at 2022-06-21 06:33:03.697899
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    l = LookupModule()
    l.parse_simple_args('1-3')
    assert l.start == 1
    assert l.end == 3
    assert l.stride == 1
    assert l.format == "%d"

    l.parse_simple_args('1-3:host%02d')
    assert l.start == 1
    assert l.end == 3
    assert l.stride == 1
    assert l.format == "host%02d"

    l.parse_simple_args('1-3/3')
    assert l.start == 1
    assert l.end == 3
    assert l.stride == 3
    assert l.format == "%d"

    l.parse_simple_args('1-3/3:host-%02d')
    assert l.start == 1

# Generated at 2022-06-21 06:33:10.031764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # input
    terms = ['10-1']
    variables = None
    kwargs = None

    # expected output
    result = ["10", "9", "8", "7", "6", "5", "4", "3", "2", "1"]

    # actual output
    lookup = LookupModule()
    actual = lookup.run(terms, variables, **kwargs)

    assert result == actual

# Generated at 2022-06-21 06:33:13.444230
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    test_case = LookupModule()
    test_case.reset()
    assert test_case.start == 1
    assert test_case.count is None
    assert test_case.end is None
    assert test_case.stride == 1
    assert test_case.format == "%d"


# Generated at 2022-06-21 06:33:25.068632
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()
    assert lookup_module.start == 1
    assert lookup_module.count == None
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"


# Generated at 2022-06-21 06:33:33.846348
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Set-up
    test_lookup = LookupModule()
    test_lookup.start = 1
    test_lookup.end = 3
    test_lookup.stride = 1
    test_lookup.format = "%d"
    test_lookup.sanity_check()

    # Test
    # 1. Generate a range from 1 to 3, with step = 1, and format as %d
    expected_results = ['1', '2', '3']
    returned_results = list(test_lookup.generate_sequence())

    assert returned_results == expected_results



# Generated at 2022-06-21 06:33:34.786210
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:33:39.192889
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lm = LookupModule()
    lm.reset()
    args = dict(start='5', end='11', stride='2', format='0x%02x')
    lm.parse_kv_args(args)
    assert lm.start == 5
    assert lm.end == 11
    assert lm.stride == 2
    assert lm.format == '0x%02x'


# Generated at 2022-06-21 06:33:50.767175
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    instance = LookupModule()
    instance.parse_simple_args('5')
    assert instance.start == 1
    assert instance.count == 5
    instance.reset()

    instance.parse_simple_args('0x1e-0x28')
    assert instance.start == 30
    assert instance.end == 40
    instance.reset()

    instance.parse_simple_args('12-20/3')
    assert instance.start == 12
    assert instance.end == 20
    assert instance.stride == 3
    instance.reset()

    instance.parse_simple_args('4:host_%d')
    assert instance.start == 1
    assert instance.count == 4
    assert instance.format == 'host_%d'
    instance.reset()


# Generated at 2022-06-21 06:34:00.604392
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_elem = LookupModule()
    lookup_elem.start = 1
    lookup_elem.stride = 3
    lookup_elem.end = 9
    sequence = list(lookup_elem.generate_sequence())
    assert sequence == [1, 4, 7]

    lookup_elem.start = 1
    lookup_elem.stride = 3
    lookup_elem.end = 10
    sequence = list(lookup_elem.generate_sequence())
    assert sequence == [1, 4, 7, 10]

    lookup_elem.start = 0
    lookup_elem.stride = 10
    lookup_elem.end = 100
    sequence = list(lookup_elem.generate_sequence())

# Generated at 2022-06-21 06:34:12.573777
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """Test parsing the shortcut forms, return True/False"""
    # Test format [start-]end[/stride][:format]
    lookup = LookupModule()
    # Case: Invalid format
    # Example: '10-5' (start > end)
    term = '10-5'
    lookup.reset()
    assert lookup.parse_simple_args(term) == True
    # Case: Invalid format
    # Example: '10/5-5' (start > end)
    term = '10/5-5'
    lookup.reset()
    assert lookup.parse_simple_args(term) == True
    # Case: Invalid format
    # Example: '10-5/5' (start > end)
    term = '10-5/5'
    lookup.reset()

# Generated at 2022-06-21 06:34:17.630220
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    test_params = {'start': 42, 'count': 42, 'end': 42, 'stride': 42, 'format': '%d'}
    lookup_module = LookupModule()
    lookup_module.reset()
    for arg in test_params:
        assert getattr(lookup_module, arg) == test_params[arg]



# Generated at 2022-06-21 06:34:24.898441
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lk = LookupModule()

    ################
    # POSITIVE TEST #
    ################

# Generated at 2022-06-21 06:34:34.954972
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()
    l.start = 0
    l.end = 4
    l.stride = 1
    l.format = '%d'
    print(list(l.generate_sequence()))
    l.stride = 2
    l.start = l.end = l.stride
    print(list(l.generate_sequence()))
    l.start = l.end = l.stride = 0
    print(list(l.generate_sequence()))
    l.start = 5
    l.end = 2
    l.stride = -1
    print(list(l.generate_sequence()))

# Generated at 2022-06-21 06:34:47.006233
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
  start_value = 3
  end_value = 7
  stride_value = 2
  format_value = 'hey%02d'
  test_module = LookupModule()
  test_module.reset()
  test_module.parse_kv_args({'start': start_value, 'end': end_value, 'stride': stride_value, 'format': format_value})
  assert len(test_module.__dict__) == 5
  assert test_module.start == start_value
  assert test_module.end == end_value
  assert test_module.stride == stride_value
  assert test_module.format == format_value


# Generated at 2022-06-21 06:34:53.059892
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    m = LookupModule()
    m.start = 2
    m.count = 3
    m.end = 4
    m.stride = 5
    m.format = 6
    m.reset()
    assert m.start == 1
    assert m.count is None
    assert m.end is None
    assert m.stride == 1
    assert m.format == "%d"


# Generated at 2022-06-21 06:35:04.283978
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()
    l.start = 1
    l.end = 5
    l.stride = 1
    l.format = "%d"
    sequence = list(l.generate_sequence())
    assert sequence == ['1', '2', '3', '4', '5']

    l = LookupModule()
    l.start = 5
    l.end = 1
    l.stride = -1
    l.format = "%d"
    sequence = list(l.generate_sequence())
    assert sequence == ['5', '4', '3', '2', '1']

    l = LookupModule()
    l.start = 5
    l.end = 1
    l.stride = 1
    l.format = "%d"
    sequence = list(l.generate_sequence())

# Generated at 2022-06-21 06:35:10.159330
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # set up
    lookup_module = LookupModule()

    # Test positive case
    args = {
        'start' : '5',
        'end' : '11',
        'stride' : '2',
        'format' : '0x%02x'
    }
    result = {
        'start' : 5,
        'end' : 11,
        'stride' : 2,
        'format' : '0x%02x'
    }

    # run
    lookup_module.parse_kv_args(args)

    # verify
    assert lookup_module.start == result['start']
    assert lookup_module.end == result['end']
    assert lookup_module.stride == result['stride']
    assert lookup_module.format == result['format']

    # Test negative cases


# Generated at 2022-06-21 06:35:21.992625
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """Unit test for method parse_simple_args of class LookupModule"""
    assert LookupModule({}).parse_simple_args('1-2/3') == True
    assert LookupModule({}).parse_simple_args('1-2/3:test_%02x') == True
    assert LookupModule({}).parse_simple_args('1-2:test_%02x') == True
    assert LookupModule({}).parse_simple_args('1-2:test_%02x') == True
    assert LookupModule({}).parse_simple_args('1-2') == True
    assert LookupModule({}).parse_simple_args('1-2') == True
    assert LookupModule({}).parse_simple_args('1-2') == True
    assert LookupModule({}).parse_simple_

# Generated at 2022-06-21 06:35:31.511132
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    l = LookupModule()
    l.reset()
    l.parse_kv_args({'start': 5, 'end': 14})
    assert(l.start == 5)
    assert(l.end == 14)
    assert(l.stride == 1)
    assert(l.format == "%d")
    l.reset()
    l.parse_kv_args({'start': '6', 'end': '0x0ff0', 'stride': '9', 'format': '%d'})
    assert(l.start == 6)
    assert(l.end == 4080)
    assert(l.stride == 9)
    assert(l.format == "%d")
    l.reset()

# Generated at 2022-06-21 06:35:36.081832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    term = 'start=1 end=10 format=test%02d'
    variables = None
    kwargs = None
    # exercise
    l = LookupModule()
    result = l.run(term, variables, **kwargs)
    # verify
    expected_result = ['test01', 'test02', 'test03', 'test04', 'test05',
                       'test06', 'test07', 'test08', 'test09', 'test10']
    assert result == expected_result, "expected %r, got %r" % (expected_result, result)
    # cleanup



# Generated at 2022-06-21 06:35:47.357473
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lm = LookupModule()
    lm.count = 1
    lm.stride = 1
    lm.sanity_check()

    lm = LookupModule()
    lm.end = 0
    lm.stride = -1
    lm.sanity_check()

    lm = LookupModule()
    lm.end = 10
    lm.stride = -1
    lm.sanity_check()

    with pytest.raises(AnsibleError) as excinfo:
        lm = LookupModule()
        lm.sanity_check()
    assert 'must specify' in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        lm = LookupModule()
        lm.end = 1
        l

# Generated at 2022-06-21 06:35:52.976582
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    class Test(LookupModule):
        def reset(self):
            self.start = 1
            self.count = None
            self.end = None
            self.stride = 1
            self.format = "%d"

    t = Test(None, None, None)

    assert t.start == 1
    assert t.count is None
    assert t.end is None
    assert t.stride == 1
    assert t.format == '%d'


# Generated at 2022-06-21 06:36:03.185671
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    pl = LookupModule()
    assert pl.count == 0
    assert pl.end == 0
    assert pl.start == 1
    assert pl.stride == 1
    assert pl.format == "%d"
    pl.parse_kv_args(dict(start=1))
    assert pl.count == 0
    assert pl.end == 0
    assert pl.start == 1
    assert pl.stride == 1
    assert pl.format == "%d"
    pl.parse_kv_args(dict(end=8))
    assert pl.count == 0
    assert pl.end == 8
    assert pl.start == 1
    assert pl.stride == 1
    assert pl.format == "%d"
    pl.parse_kv_args(dict(stride=2))
    assert pl.count == 0

# Generated at 2022-06-21 06:36:29.268566
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()

    assert lookup_module.parse_simple_args("5") == True
    assert lookup_module.start == 1
    assert lookup_module.end == 5
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'

    assert lookup_module.parse_simple_args("5-8") == True
    assert lookup_module.start == 5
    assert lookup_module.end == 8
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'

    assert lookup_module.parse_simple_args("2-10/2") == True
    assert lookup_module.start == 2
    assert lookup_module.end == 10
    assert lookup_module.stride == 2
    assert lookup_module.format == '%d'



# Generated at 2022-06-21 06:36:38.733988
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    args = LookupModule()


# Generated at 2022-06-21 06:36:51.060375
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Given
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = None
    lookup_module.count = None
    lookup_module.stride = 1
    lookup_module.format = "%d"

    # Then
    try:
        lookup_module.sanity_check()
        raise Exception("Should not reach this line.")

    # Catch
    except AnsibleError as e:
        assert str(e) == "must specify count or end in with_sequence"

    # Given
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 1
    lookup_module.count = 1
    lookup_module.stride = 1
    lookup_module.format = "%d"

    # Then

# Generated at 2022-06-21 06:36:59.811094
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    l = LookupModule()
    l.start = 10
    l.end = 2
    l.stride = 1
    try:
        l.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError("to count backwards make stride negative")

    l = LookupModule()
    l.start = 2
    l.end = 10
    l.stride = -1
    try:
        l.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError("to count forward don't make stride negative")
    l.stride = 1
    l.sanity_check()


# Generated at 2022-06-21 06:37:01.718299
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    assert range(0,99) != range(1,100)
    assert range(0,100) == range(1,101)


# Generated at 2022-06-21 06:37:07.191320
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    import pytest

    lookup_module = LookupModule()
    lookup_module.start = 0
    lookup_module.stride = 1
    lookup_module.end = 5
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == [0, 1, 2, 3, 4, 5]

    lookup_module = LookupModule()
    lookup_module.start = 2
    lookup_module.stride = 2
    lookup_module.end = 8
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == [2, 4, 6, 8]

    lookup_module = LookupModule()
    lookup_module.start = 2
    lookup_module.stride = -2
    lookup_module.end = -8
    lookup

# Generated at 2022-06-21 06:37:12.365159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ls = LookupModule()
    variables = {}
    kwargs = {}
    results = ls.run(["start=50 end=57 format=pod%02d"], variables, **kwargs)
    assert results == ["pod50", "pod51", "pod52", "pod53", "pod54", "pod55", "pod56", "pod57"]

# Generated at 2022-06-21 06:37:21.998488
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
  def check(spec, expected):
    instance = LookupModule()
    instance.reset()
    instance.parse_kv_args(spec)
    assert instance.start == expected[0]
    assert instance.end == expected[1]
    assert instance.count == expected[2]
    assert instance.stride == expected[3]
    assert instance.format == expected[4]
  #
  check({}, (1, None, None, 1, '%d'))
  check({'start': '3'}, (3, None, None, 1, '%d'))
  check({'end': '5'}, (1, 5, None, 1, '%d'))
  check({'count': '6'}, (1, 13, None, 1, '%d'))