

# Generated at 2022-06-23 12:00:00.156338
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Default from ansible lookup
    lookup = LookupModule()
    match = SHORTCUT.match('2-10/2')
    assert match is not None, 'This expression should be a match'
    assert lookup.parse_simple_args('2-10/2') is True, 'parse_simple_args should return True'

    # Should return False if not match
    assert lookup.parse_simple_args(666) is False, 'parse_simple_args should return False'

    # Just start with hexa
    lookup = LookupModule()
    match = SHORTCUT.match('0x10')
    assert match is not None, 'This expression should be a match'
    assert lookup.parse_simple_args('0x10') is True, 'parse_simple_args should return True'

    # Just end with hexa
    lookup

# Generated at 2022-06-23 12:00:08.778893
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()

    assert hasattr(lookup_module, 'start')
    assert hasattr(lookup_module, 'count')
    assert hasattr(lookup_module, 'end')
    assert hasattr(lookup_module, 'stride')
    assert hasattr(lookup_module, 'format')
    assert lookup_module.start == 1
    assert lookup_module.count is None
    assert lookup_module.end is None
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'


# Generated at 2022-06-23 12:00:13.830586
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.stride = 1
    lookup_module.end = 1

    # Test count = 1, end = 1
    lookup_module.sanity_check()

    # Test count = 1, end = 3
    lookup_module.end = 3
    lookup_module.sanity_check()

    # Test count = 4, end = 3
    lookup_module.count = 4
    lookup_module.sanity_check()

    # Test count = 4, end = 1
    lookup_module.end = 1
    lookup_module.sanity_check()

    # Test count = 1, end = 4    stride = -1
    lookup_module.end = 4
    lookup_module.stride = -1
    lookup_module.sanity_check()

# Generated at 2022-06-23 12:00:20.053545
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    result = LookupModule()
    try:
        result.reset()
        assert result.start == 1
        assert result.count == None
        assert result.end == None
        assert result.stride == 1
        assert result.format == "%d"
    except Exception as ex:
        assert False, 'initial reset in LookupModule failed with error: {}'.format(ex)


# Generated at 2022-06-23 12:00:24.262571
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    l = LookupModule()
    l.start = 1
    l.count = None
    l.end = 100
    l.stride = 1
    l.format = "%d"
    l.sanity_check()
    l.start = 1
    l.count = 100
    l.end = None
    l.stride = 1
    l.format = "%d"
    l.sanity_check()
    try:
        l.start = 1
        l.count = 100
        l.end = 100
        l.stride = 1
        l.format = "%d"
        l.sanity_check()
    except AnsibleError:
        pass

# Generated at 2022-06-23 12:00:34.227460
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    test_cases = []

    # empty, no return value
    test_cases.append(
        {
            "name": "no args",
            "args": {},
            "expect": None
        }
    )
    # start
    test_cases.append(
        {
            "name": "start",
            "args": {"start": "1"},
            "expect": 1
        }
    )
    # count
    test_cases.append(
        {
            "name": "count",
            "args": {"count": "1"},
            "expect": None
        }
    )
    # end
    test_cases.append(
        {
            "name": "end",
            "args": {"end": "1"},
            "expect": 1
        }
    )
    # stride

# Generated at 2022-06-23 12:00:41.192169
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lm = LookupModule()
    lm.reset()
    lm.parse_kv_args({"end": "5"})
    assert lm.end == 5
    lm.reset()
    lm.parse_kv_args({"start": "0xDEAD", "end": "0xBEEF"})
    assert lm.start == 57005
    assert lm.end == 48879
    lm.reset()
    lm.parse_kv_args({"count": "4", "format": "0x%02x"})
    assert lm.count == 4
    assert lm.format == "0x%02x"
    lm.reset()
    lm.parse_kv_args({"end": "32", "format": "testuser%02x"})

# Generated at 2022-06-23 12:00:46.538185
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()

    # Test case 1
    assert lookup.parse_simple_args('3')
    assert lookup.start == 1
    assert lookup.count == 3
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == '%d'
    lookup.reset()

    # Test case 2
    assert lookup.parse_simple_args('4-6')
    assert lookup.start == 4
    assert lookup.count is None
    assert lookup.end == 6
    assert lookup.stride == 1
    assert lookup.format == '%d'
    lookup.reset()

    # Test case 3
    assert lookup.parse_simple_args('1-3/2')
    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end == 3

# Generated at 2022-06-23 12:00:57.568083
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    sequence_lookup = LookupModule()
    sequence_lookup.reset()
    sequence_lookup.stride = 1
    sequence_lookup.end = 5
    sequence_lookup.start = 1
    sequence_lookup.sanity_check()
    assert sequence_lookup.end == 5
    sequence_lookup.reset()
    sequence_lookup.stride = 1
    sequence_lookup.end = 5
    sequence_lookup.start = 3
    sequence_lookup.sanity_check()
    assert sequence_lookup.end == 5
    sequence_lookup.reset()
    sequence_lookup.stride = 1
    sequence_lookup.end = -5
    sequence_lookup.start = 3
    sequence_lookup.sanity_check()

# Generated at 2022-06-23 12:01:04.702113
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.start = 1
    l.count = None
    l.end = None
    l.stride = 1
    l.format = "%d"
    assert(l.start == 1)
    assert(l.count == None)
    assert(l.end == None)
    assert(l.stride == 1)
    assert(l.format == "%d")


# Generated at 2022-06-23 12:01:10.513792
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    l = LookupModule()
    l.reset()
    key_value_pair = {"start":"5","end":"4","stride":"3","format":"4"}
    l.parse_kv_args(key_value_pair)
    assert l.start == 5
    assert l.end == 4
    assert l.stride == 3
    assert l.format == "4"


# Generated at 2022-06-23 12:01:13.440622
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 2
    lookup.count = 1
    lookup.end = 3
    lookup.stride = 1
    lookup.format = '%d'
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == '%d'



# Generated at 2022-06-23 12:01:24.422700
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    try:
        lookup.start = 1
        lookup.count = 10
        lookup.stride = 2
        lookup.sanity_check()
        lookup.count = 0
        lookup.sanity_check()
        lookup.count = 5
        lookup.end = 5
        lookup.sanity_check()
    except ValueError as e:
        assert False, e.args
    except Exception as e:
        assert False, e.args

    # Test for negative stride, where end > start
    lookup.count = None
    lookup.end = 10
    lookup.start = 5
    lookup.stride = -1

# Generated at 2022-06-23 12:01:35.458861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def reset(self):
        """set sensible defaults"""
        self.start = 0
        self.count = None
        self.end = 0
        self.stride = 1
        self.format = "%d"

    import sys
    if sys.version_info[0] > 2:
        LookupModule.reset = reset

    def parse_kv_args(self, args):
        """parse key-value style arguments"""

# Generated at 2022-06-23 12:01:36.196057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:01:41.827916
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
    lookup_plugin = LookupModule()
    lookup_plugin.reset()
    assert lookup_plugin.start == 1
    assert lookup_plugin.count == None
    assert lookup_plugin.end == None
    assert lookup_plugin.stride == 1
    assert lookup_plugin.format == "%d"


# Generated at 2022-06-23 12:01:49.311677
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    a = LookupModule()
    a.reset()
    a.parse_kv_args({"start": "0x0f00", "count": "4", "format": "%04x"})
    expected = {
        'start': 3840,
        'count': 4,
        'end': None,
        'stride': 1,
        'format': '%04x'
    }
    assert a.start == expected['start']
    assert a.count == expected['count']
    assert a.end == expected['end']
    assert a.stride == expected['stride']
    assert a.format == expected['format']


# Generated at 2022-06-23 12:02:00.978419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.plugins import lookup_loader

    variable_manager = VariableManager()
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=[])
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'local',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{item}}')), with_sequence='start=1 end=10')
        ]
    )


# Generated at 2022-06-23 12:02:07.803869
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lm = LookupModule()
    lm.reset()

    args = {
        "start": "0x0f00",
        "count": "4",
        "format": "%04x"
    }

    lm.parse_kv_args(args)

    assert lm.start == 3840
    assert lm.count == 4
    assert lm.format == "%04x"

    args_invalid = {
        "start": "0x0f00",
        "count": "4",
        "format": "%04x",
        "arg_invalid": "argument_invalid"
    }

    try:
        lm.parse_kv_args(args_invalid)
    except AnsibleError as e:
        assert "unrecognized arguments to with_sequence" in e.message



# Generated at 2022-06-23 12:02:15.713562
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    c = LookupModule()
    c.reset()

    test_str = "start=2 end=5 stride=2"
    c.parse_kv_args(parse_kv(test_str))
    assert c.start == 2
    assert c.end == 5
    assert c.stride == 2

    c.reset()

    test_str = "start=2 end=5 stride=2 format=test%02d"
    c.parse_kv_args(parse_kv(test_str))
    assert c.start == 2
    assert c.end == 5
    assert c.stride == 2
    assert c.format == "test%02d"

    c.reset()

    test_str = "start=0x0f00 count=4 format=%04x"
    c.parse_kv

# Generated at 2022-06-23 12:02:20.007122
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    test_class = LookupModule()
    assert test_class.start == 1
    assert test_class.count == None
    assert test_class.end == None
    assert test_class.stride == 1
    assert test_class.format == "%d"


# Generated at 2022-06-23 12:02:27.284902
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test LookupModule")

    lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:02:38.682058
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    """
    Test the method LookupModule.parse_kv_args
    """
    # create instance of class
    lkm = LookupModule()
    lkm.reset()

    # test for parse_kv_args without arguments
    lkm.parse_kv_args({})
    assert lkm.__dict__ == {'start': 1, 'count': None, 'end': None, 'stride': 1, 'format': '%d'}

    # test for parse_kv_args with start argument
    lkm.parse_kv_args({'start': '4'})
    assert lkm.__dict__ == {'start': 4, 'count': None, 'end': None, 'stride': 1, 'format': '%d'}

    # test for parse_kv_args with end argument
    l

# Generated at 2022-06-23 12:02:41.235235
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)
    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-23 12:02:52.374129
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:02:59.221344
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()
    lookup_module.start = 0
    lookup_module.count = 0
    lookup_module.end = 0
    lookup_module.stride = 0
    lookup_module.format = '%d'
    lookup_module.reset()
    assert lookup_module.start == 1
    assert lookup_module.count is None
    assert lookup_module.end is None
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'


# Generated at 2022-06-23 12:03:00.570181
# Unit test for constructor of class LookupModule
def test_LookupModule():
    sequence_lookup = LookupModule()
    assert sequence_lookup

# Generated at 2022-06-23 12:03:07.638421
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    import pytest

    with pytest.raises(AnsibleError, match=r"to count forward don't make stride negative"):
        LookupModule({}).generate_sequence(2, 1, -1)
    with pytest.raises(AnsibleError, match=r"to count backwards make stride negative"):
        LookupModule({}).generate_sequence(1, 2, 1)
    with pytest.raises(AnsibleError, match=r"bad formatting string: format"):
        LookupModule({}).generate_sequence(1, 2, 1, "format")
    # No errors
    assert list(LookupModule({}).generate_sequence(1, 2, 1, "%d")) == ["1", "2"]

# Generated at 2022-06-23 12:03:19.168259
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    l = LookupModule()
    l.reset()
    assert l.parse_simple_args("5-8") == True
    assert l.start == 5
    assert l.end == 8
    assert l.stride == 1
    assert l.format == "%d"

    l.reset()
    assert l.parse_simple_args("5-8:testuser%02x") == True
    assert l.start == 5
    assert l.end == 8
    assert l.stride == 1
    assert l.format == "testuser%02x"

    l.reset()
    assert l.parse_simple_args("5-8:testuser%02x") == True
    assert l.start == 5
    assert l.end == 8
    assert l.stride == 1

# Generated at 2022-06-23 12:03:29.858235
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Positive test
    l = LookupModule()
    l.start = 0
    l.end = 5
    l.stride = 1
    l.sanity_check()

    # Negative test, end defined with count
    l.end = None
    l.count = 5
    l.sanity_check()

    # Negative test, end and count both defined
    l.end = 5
    with pytest.raises(AnsibleError) as e_info:
        l.sanity_check()
    assert 'must specify count or end in with_sequence' in str(e_info.value)

    # Negative test, bad formatting string
    l.end = None
    l.count = 5
    l.format = '%d and %d'

# Generated at 2022-06-23 12:03:31.165140
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert lk is not None

# Generated at 2022-06-23 12:03:42.481028
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    import nose
    import nose.tools
    import unittest

    lookup = LookupModule()

    test_input_start = '1-10/2'
    expected_output_start = {'start': 1, 'end': 10, 'stride': 2}

    test_input_stride = '1-10/2:%s' % test_input_start
    expected_output_stride = expected_output_start.copy()
    expected_output_stride.update({'format': test_input_start})

    test_input_start_and_format = '1-10/2:%s' % test_input_stride
    expected_output_start_and_format = expected_output_stride.copy()
    expected_output_start_and_format.update({'start': 1})

    test_input

# Generated at 2022-06-23 12:03:45.004324
# Unit test for constructor of class LookupModule
def test_LookupModule():
    seq_module = LookupModule()
    assert seq_module._lookup_name == "sequence"

# Generated at 2022-06-23 12:03:56.757656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_input = ('start=1 end=3 stride=1 format=host%02d',
                  'start=1 end=3 stride=-1 format=host%02d',
                  '5-8',
                  '2-10/2',
                  '4:host%02d',
                  'start=5 end=11 stride=2 format=0x%02x',
                  'count=5',
                  'start=0x0f00 count=4 format=%04x',
                  'start=0 count=5 stride=2',
                  'start=1 count=5 stride=2')

# Generated at 2022-06-23 12:04:07.217801
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # Test default value
    lookup_obj = LookupModule()
    lookup_obj.reset()
    lookup_obj.parse_kv_args({})
    assert lookup_obj.start == 1
    assert lookup_obj.end == None
    assert lookup_obj.count == None
    assert lookup_obj.stride == 1
    assert lookup_obj.format == "%d"
    # Test values
    lookup_obj.reset()
    lookup_obj.parse_kv_args({"start": "1", "end": "10", "count": '3', "stride": "3", "format": "0x%02x"})
    assert lookup_obj.start == 1
    assert lookup_obj.end == 10
    assert lookup_obj.count == 3
    assert lookup_obj.stride == 3
    assert lookup_obj

# Generated at 2022-06-23 12:04:15.476125
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    # AnsibleError = exception
    reset_obj = LookupModule()

    lst = []
    if reset_obj.start != 1:
        lst.append('error start')
    if reset_obj.count != None:
        lst.append('error count')
    if reset_obj.end != None:
        lst.append('error end')
    if reset_obj.stride != 1:
        lst.append('error stride')
    if reset_obj.format != "%d":
        lst.append('error format')

    if len(lst) == 0:
        lst = 'test is passed'
    else:
        lst = 'test is failed'
    print(lst)


# Generated at 2022-06-23 12:04:26.062556
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()

    lookup.parse_kv_args({"start": 1, "end": 10, "stride": 2, "format": "0x%02X"})
    assert lookup.start == 1
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == "0x%02X"

    lookup.parse_kv_args({"end": 10, "stride": 2, "format": "0x%02X"})
    assert lookup.start == 1
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == "0x%02X"

    lookup.parse_kv_args({"end": 10, "stride": 2, "format": "0x%02X", "start": "0x5"})
   

# Generated at 2022-06-23 12:04:36.875263
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Ensure that shortcuts are parsable
    lm = LookupModule()
    lm.reset()
    lm.parse_simple_args('1')
    assert lm.start == 1
    assert lm.end == 1
    assert lm.stride == 1
    assert lm.format == '%d'

    lm.reset()
    lm.parse_simple_args('2-5')
    assert lm.start == 2
    assert lm.end == 5
    assert lm.stride == 1
    assert lm.format == '%d'

    lm.reset()
    lm.parse_simple_args('2-5/2')
    assert lm.start == 2
    assert lm.end == 5
    assert lm.stride == 2

# Generated at 2022-06-23 12:04:37.515823
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert( LookupModule({}) != None )

# Generated at 2022-06-23 12:04:48.726514
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule")
    lookup_module = LookupModule()
    print("  LookupModule instanced correctly")
    lookup_module.reset()
    print("  reset() correctly set default values")
    lookup_module.start = 1
    lookup_module.count = 5
    lookup_module.stride = 1
    print("  Testing generate_sequence")
    assert lookup_module.generate_sequence() == ["1", "2", "3", "4", "5"]
    print("  generate_sequence generated correct values")
    try:
        lookup_module.end = 5
        lookup_module.sanity_check()
        print("  Testing sanity_check")
        print("    count and end not both specified. Correct")
    except Exception:
        print("  Testing sanity_check")

# Generated at 2022-06-23 12:04:53.213093
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lm = LookupModule()
    lm.start = 5
    lm.end = 10
    lm.stride = 2
    lm.format = '%d'
    result = list(lm.generate_sequence())
    assert result == ['5', '7', '9']



# Generated at 2022-06-23 12:04:55.012971
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.reset()
    lm.sanity_check()
    lm.generate_sequence()

# Generated at 2022-06-23 12:05:01.324345
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 5
    lookup.count = 3
    lookup.end = 3000
    lookup.stride = 2
    lookup.format = "%d"

    lookup.reset()

    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-23 12:05:12.233174
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    seq = '5-8'
    lookup.parse_simple_args(seq)
    assert lookup.start == 5
    assert lookup.end == 8
    assert lookup.stride == 1
    assert lookup.format == '%d'
    seq = '2-10/2'
    lookup.parse_simple_args(seq)
    assert lookup.start == 2
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == '%d'
    seq = '4:host%02d'
    lookup.parse_simple_args(seq)
    assert lookup.start == 4
    assert lookup.end == 4
    assert lookup.stride == 1
    assert lookup.format == 'host%02d'

# Generated at 2022-06-23 12:05:18.880357
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # arrange
    instance = LookupModule()
    # act
    instance.parse_kv_args({'start': '5', 'end': '8', 'stride': '2', 'format': '%04x'})
    # assert
    assert instance.start == 5
    assert instance.end == 8
    assert instance.stride == 2
    assert instance.format == '%04x'


# Generated at 2022-06-23 12:05:24.460046
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    module = LookupModule()
    module.start = 2
    module.count = 5
    module.end = 8
    module.stride = 3
    module.format = '%20d'
    module.reset()
    assert module.start == 1
    assert module.count == None
    assert module.end == None
    assert module.stride == 1
    assert module.format == '%d'


# Generated at 2022-06-23 12:05:34.134138
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()

    def _assert(correct, actual):
        if correct != actual:
            raise AssertionError('%r != %r' % (correct, actual))

    _assert(False, lookup.parse_simple_args(''))
    _assert(False, lookup.parse_simple_args('a'))
    _assert(False, lookup.parse_simple_args('0'))
    _assert(False, lookup.parse_simple_args('/1'))
    _assert(False, lookup.parse_simple_args('/1:'))
    _assert(False, lookup.parse_simple_args(':'))
    _assert(False, lookup.parse_simple_args(':0'))

    _assert(False, lookup.parse_simple_args('0-0-0'))

# Generated at 2022-06-23 12:05:42.413797
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    l = LookupModule()
    # Test with start, end and count options
    l.reset()
    l.parse_kv_args(parse_kv("start=1 end=5 count=None"))
    assert l.start == 1
    assert l.end == 5
    assert l.count is None
    assert l.stride == 1
    assert l.format == "%d"
    # Test with start and end options
    l.reset()
    l.parse_kv_args(parse_kv("start=2 end=8"))
    assert l.start == 2
    assert l.end == 8
    assert l.count is None
    assert l.stride == 1
    assert l.format == "%d"
    # Test with start and count options
    l.reset()
    l.parse_kv_args

# Generated at 2022-06-23 12:05:52.104636
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    module = LookupModule()
    # test with empty dict
    module.parse_kv_args({})
    assert module.start == 1
    assert module.count is None
    assert module.end is None
    assert module.stride == 1
    assert module.format == "%d"

    # test with some arguments
    module.parse_kv_args({'start': '10', 'end': '50', 'stride': '2', 'format': '0x%x'})
    assert module.start == 10
    assert module.count is None
    assert module.end == 50
    assert module.stride == 2
    assert module.format == "0x%x"

    # test with start as negative

# Generated at 2022-06-23 12:05:58.607883
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.plugins.lookup.sequence import LookupModule
    l = LookupModule()
    l.reset()
    assert l.start == 1
    assert l.count == None
    assert l.end == None
    assert l.stride == 1
    assert l.format == "%d"



# Generated at 2022-06-23 12:06:04.482492
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    sequence = LookupModule()
    sequence.parse_kv_args({"start": 5, "end": 11, "stride": 2, "format": "0x%02x"})
    assert sequence.start == 5
    assert sequence.end == 11
    assert sequence.stride == 2
    assert sequence.format == "0x%02x"



# Generated at 2022-06-23 12:06:06.025122
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.sanity_check() == None


# Generated at 2022-06-23 12:06:16.474685
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # Init data for the test
    lookup = LookupModule()
    lookup.reset()
    args = {
        'start': '1',
        'end': '10',
        'stride': '1',
        'format': '%d'
    }

    # Execute the code and test result
    lookup.parse_kv_args(args)
    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end == 10
    assert lookup.stride == 1
    assert lookup.format == "%d"

    # Test with all default values
    lookup.reset()
    args = {}

    # Execute the code and test result
    lookup.parse_kv_args(args)
    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end == 0
    assert lookup

# Generated at 2022-06-23 12:06:22.650611
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 10
    lookup.end = 30
    lookup.stride = 2
    lookup.format = '%d'
    lookup.count = None

    lookup.reset()
    assert lookup.start == 1
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == '%d'
    assert lookup.count is None


# Generated at 2022-06-23 12:06:31.296471
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    module = LookupModule()

    args = dict()
    module.parse_kv_args(args)
    assert module.start == 1
    assert module.end == None
    assert module.stride == 1
    assert module.format == "%d"

    args = dict(start='5')
    module.parse_kv_args(args)
    assert module.start == 5
    assert module.end == None
    assert module.stride == 1
    assert module.format == "%d"

    args = dict(end='5')
    module.parse_kv_args(args)
    assert module.start == 1
    assert module.end == 5
    assert module.stride == 1
    assert module.format == "%d"

    args = dict(count='5')

# Generated at 2022-06-23 12:06:41.736962
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # case 1: start=5
    args = '5'
    lookup_obj = LookupModule()
    lookup_obj.reset()
    lookup_obj.parse_simple_args(args)
    assert lookup_obj.start == 5 and lookup_obj.count == None and lookup_obj.end == None and lookup_obj.stride == 1 and lookup_obj.format == '%d'

    # case 2: start=5, end=6
    args = '5-6'
    lookup_obj = LookupModule()
    lookup_obj.reset()
    lookup_obj.parse_simple_args(args)
    assert lookup_obj.start == 5 and lookup_obj.count == None and lookup_obj.end == 6 and lookup_obj.stride == 1 and lookup_obj.format == '%d'

    # case 3:

# Generated at 2022-06-23 12:06:47.335734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # sequence.run tests
    ##########
    # Normal parses
    ##########
    # Simple with_sequence
    inp_terms = ["1"]
    exp_results = ['1']
    assert LookupModule().run(inp_terms, {}, variables=None) == exp_results

    # With extra whitespace
    inp_terms = ["1 "]
    exp_results = ['1']
    assert LookupModule().run(inp_terms, {}, variables=None) == exp_results

    # Specify start value
    inp_terms = ["5"]
    exp_results = ['5']
    assert LookupModule().run(inp_terms, {}, variables=None) == exp_results

    # Specify end value
    inp_terms = ["1-5"]

# Generated at 2022-06-23 12:06:54.418576
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(issubclass(LookupModule, LookupBase))

    module = LookupModule()
    assert(hasattr(module, 'reset'))
    assert(hasattr(module, 'parse_kv_args'))
    assert(hasattr(module, 'parse_simple_args'))
    assert(hasattr(module, 'sanity_check'))
    assert(hasattr(module, 'generate_sequence'))


# Generated at 2022-06-23 12:07:00.002596
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    start = 0
    end = 4
    stride = 1
    format = "%d"
    _lk = LookupModule()
    _lk.start = start
    _lk.stride = stride
    _lk.format = format 
    _lk.end = end 
    actual = list(_lk.generate_sequence())
    expected = ['0', '1', '2', '3', '4']
    assert expected == actual


# Generated at 2022-06-23 12:07:09.966393
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 6
    lookup.stride = 1
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ['1','2','3','4','5','6']

    lookup = LookupModule()
    lookup.start = 1
    lookup.count = 6
    lookup.stride = 1
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ['1','2','3','4','5','6']

    lookup = LookupModule()
    lookup.start = 1
    lookup.count = 5
    lookup.stride = 2
    lookup.format = "%d"
    assert list(lookup.generate_sequence()) == ['1','3','5','7','9']


# Generated at 2022-06-23 12:07:21.862815
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    # test cases for method run

# Generated at 2022-06-23 12:07:32.380690
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None, None)
    term = "10-20/2"
    parsed_term = loader.construct_mapping(None, term)
    short_term = LookupModule().parse_simple_args(term)
    assert short_term == True, 'The shortcut form is correctly specified'
    assert LookupModule().start == int(parsed_term.get('start')), 'The start value is correctly read'
    assert LookupModule().end == int(parsed_term.get('end')), 'The end value is correctly read'
    assert LookupModule().stride == int(parsed_term.get('stride')), 'The stride value is correctly read'


# Generated at 2022-06-23 12:07:44.258147
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    # Creating instances of class LookupModule
    lm = LookupModule()

    # Testing for strange arguments
    assert lm.parse_simple_args("") == False
    assert lm.parse_simple_args("abc") == False
    assert lm.parse_simple_args("abc-") == False
    assert lm.parse_simple_args("-abc") == False
    assert lm.parse_simple_args("12/-") == False
    assert lm.parse_simple_args("---") == False
    assert lm.parse_simple_args("a-b") == False
    assert lm.parse_simple_args("-a-b") == False
    assert lm.parse_simple_args("a-b-c") == False

# Generated at 2022-06-23 12:07:56.572904
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    assert(LookupModule.parse_simple_args(LookupModule, "5") == True)
    assert(LookupModule.start == 1)
    assert(LookupModule.end == 5)
    assert(LookupModule.stride == 1)
    assert(LookupModule.format == "%d")

    assert(LookupModule.parse_simple_args(LookupModule, "5-") == True)
    assert(LookupModule.start == 1)
    assert(LookupModule.end == 5)
    assert(LookupModule.stride == 1)
    assert(LookupModule.format == "%d")

    assert(LookupModule.parse_simple_args(LookupModule, "5-8") == True)
    assert(LookupModule.start == 5)
    assert(LookupModule.end == 8)


# Generated at 2022-06-23 12:08:08.215700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test with_sequence plugin')
    assert LookupModule().run([], variables=None, **{}) == []

    terms = ['1-3', '4-8/2', '9-12/3::host%02d', 'start=1 end=3', 'start=4 end=8 stride=2',
             'start=9 end=12 stride=3 format=host%02d']
    wanted_results = [['1', '2', '3'], ['4', '6', '8'], ['host09', 'host12'], ['1', '2', '3'], ['4', '6', '8'],
                      ['host09', 'host12']]
    for i in range(len(terms)):
        results = LookupModule().run([terms[i]], variables=None, **{})
        assert results

# Generated at 2022-06-23 12:08:10.882456
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    l.start = 10
    l.end = 20
    l.stride = 30
    l.format = "hello"

    l.reset()

    assert l.start == 1
    assert l.end is None
    assert l.stride == 1
    assert l.format == "%d"


# Generated at 2022-06-23 12:08:14.906507
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_obj = LookupModule()
    lookup_obj.start = 0
    lookup_obj.end = 5
    lookup_obj.count = None
    lookup_obj.stride = 1
    lookup_obj.format = "%d"
    lookup_obj.sanity_check()



# Generated at 2022-06-23 12:08:23.486162
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    l = LookupModule(AnsibleModule(**{}))
    l.start = 1
    l.count = 2
    l.end = 3
    l.stride = 4
    l.format = "%d"

    l.reset()

    assert l.start == 1
    assert l.count == None
    assert l.end == None
    assert l.stride == 1
    assert l.format == "%d"


# Generated at 2022-06-23 12:08:35.057773
# Unit test for constructor of class LookupModule
def test_LookupModule():
    sequence = LookupModule()
    sequence.reset()
    sequence.parse_kv_args(parse_kv("start=1 end=4"))
    assert sequence.start == 1
    assert sequence.end == 4

    sequence = LookupModule()
    sequence.reset()
    sequence.parse_kv_args(parse_kv("start=1 end=4 count=5"))
    assert sequence.start == 1
    assert sequence.end == 4
    assert sequence.count == 5

    sequence = LookupModule()
    sequence.reset()
    sequence.parse_kv_args(parse_kv("start=1 end=4 stride=2"))
    assert sequence.start == 1
    assert sequence.end == 4
    assert sequence.stride == 2

    sequence = LookupModule()
    sequence.reset()

# Generated at 2022-06-23 12:08:45.221169
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    from ansible.plugins.loader import LookupModule as LookupHandler
    from ansible.plugins.loader import lookup_loader

    # create instance
    lm = LookupHandler()
    lookup = lookup_loader.get('sequence', basedir=[])
    lm._lookup_name = 'sequence'
    lm.set_loader(lookup)

    # test match
    ret = lm.parse_simple_args("1")
    assert ret is True
    assert lm.start == 1
    assert lm.end is None
    assert lm.stride == 1
    assert lm.format == "%d"

    # test no match
    ret = lm.parse_simple_args("bobo")
    assert ret is False
    assert lm.start == 1
    assert lm.end is None
    assert l

# Generated at 2022-06-23 12:08:56.715759
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    def parse_simple_args(term):
        l = LookupModule(None,{})
        return l.parse_simple_args(term)

    assert parse_simple_args("1-10/2") == True
    assert parse_simple_args("1-10/2:0x%02x") == True
    assert parse_simple_args("1-10:0x%02x") == True
    assert parse_simple_args("1-10") == True
    assert parse_simple_args("1") == True
    assert parse_simple_args("1/1") == True
    assert parse_simple_args("1-10/1/1") == False
    assert parse_simple_args(":0x%02x") == False
    assert parse_simple_args("1-") == False

# Generated at 2022-06-23 12:09:03.713939
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    seq = LookupModule()
    seq.start = 0
    seq.end = 10
    seq.stride = 2
    assert (list(seq.generate_sequence()) == [str(i) for i in range(0, 11, 2)])
    seq.stride = -1
    assert (list(seq.generate_sequence()) == [str(i) for i in range(10, -1, -1)])
    seq.stride = 0
    assert (list(seq.generate_sequence()) == [str(seq.start)])



# Generated at 2022-06-23 12:09:09.218169
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()
    l.start = 0x0f00
    l.stride = 1
    l.end = 0x0f03
    l.format = "%04x"
    assert l.generate_sequence() == ['0f00', '0f01', '0f02', '0f03']

# Generated at 2022-06-23 12:09:19.813193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing constructor LookupModule()...")

    lookup_class = LookupModule()
    
    if lookup_class.start != 1:
        print("Error: expected self.start to be 1, got %d instead" % lookup_class.start) 
    
    if lookup_class.count != None:
        print("Error: expected self.count to be None, got %d instead" % lookup_class.count) 
    
    if lookup_class.end != None:
        print("Error: expected self.end to be None, got %d instead" % lookup_class.end) 
    
    if lookup_class.stride != 1:
        print("Error: expected self.stride to be 1, got %d instead" % lookup_class.stride) 
    

# Generated at 2022-06-23 12:09:29.203047
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    from ansible.errors import AnsibleError
    #
    # Test case 1:
    #
    test_case = "1-4"
    lookup = LookupModule()
    lookup.reset()
    ret = lookup.parse_simple_args(test_case)
    assert ret is True
    assert lookup.start == 1
    assert lookup.end == 4

    #
    # Test case 2:
    #
    test_case = "0x64-0x68/0x10:0x%02x"
    lookup = LookupModule()
    lookup.reset()
    ret = lookup.parse_simple_args(test_case)
    assert ret is True
    assert lookup.start == 0x64
    assert lookup.end == 0x68
    assert lookup.stride == 0x10

# Generated at 2022-06-23 12:09:40.369150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    terms = [
        '1',
        '2-8',
        '0-10/2',
        '4:user%02d',
        'start=19 end=22',
        'start=19 end=22 stride=2',
        'start=1 count=4',
        'start=1 count=4 format=0x%02x',
        'count=4',
        'count=4 format=0x%02x',
        'start=0x0f00 count=4',
        'start=0x0f00 count=4 format=%04x',
        'start=0 count=5 stride=2',
        'start=1 count=5 stride=2',
        'start=10 end=0 stride=-1'
    ]

# Generated at 2022-06-23 12:09:51.568832
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lm = LookupModule()
    lm.start = 1
    lm.count = 2
    lm.end = 2
    lm.stride = 3
    lm.format = "%d"
    lm.sanity_check()
    seq = lm.generate_sequence()
    assert list(seq) == ["1"]

    lm.start = 1
    lm.count = None
    lm.end = 2
    lm.stride = 3
    lm.format = "%d"
    lm.sanity_check()
    seq = lm.generate_sequence()
    assert list(seq) == ["1"]

    lm.start = 3
    lm.count = None
    lm.end = 2
    lm.stride = 3
    lm.format