

# Generated at 2022-06-23 11:59:57.414235
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    f = LookupModule()

    # test empty gerenate
    f.start = 0
    f.end = 0
    f.stride = 0
    f.format = "%d"
    assert list(f.generate_sequence()) == []

    # test simple forwad generate
    f.start = 0
    f.end = 2
    f.stride = 1
    f.format = "%d"
    assert list(f.generate_sequence()) == ["0", "1", "2"]

    # test simple backward generate
    f.start = 2
    f.end = 0
    f.stride = -1
    f.format = "%d"
    assert list(f.generate_sequence()) == ["2", "1", "0"]

    # test simple forward generate with stride
    f.start = 0

# Generated at 2022-06-23 11:59:58.599409
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:00:05.291978
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import unittest.mock as mock

    sequence = LookupModule(mock.Mock())
    sequence.start = 1
    sequence.end = 10
    sequence.stride = 1

    assert sequence.sanity_check() is None

    sequence.end = 1
    sequence.stride = -1
    assert sequence.sanity_check() is None

    sequence.end = -1
    sequence.stride = 1
    with pytest.raises(AnsibleError):
        sequence.sanity_check()

    sequence.end = 10
    sequence.stride = -1
    with pytest.raises(AnsibleError):
        sequence.sanity_check()

    sequence.stride = 0
    with pytest.raises(AnsibleError):
        sequence.sanity_check()


# Unit

# Generated at 2022-06-23 12:00:08.918636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    assert plugin.run([
        'count=5',
        'start=0x0f00 count=4 format=%04x',
        'start=0 count=5 stride=2',
        'start=1 count=5 stride=2',
    ], []) == [
        '1',
        '2',
        '3',
        '4',
        '5',
        '0f00',
        '0f01',
        '0f02',
        '0f03',
        '0',
        '2',
        '4',
        '6',
        '8',
        '1',
        '3',
        '5',
        '7',
        '9',
    ]

# Generated at 2022-06-23 12:00:12.937395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    # Sample test data
    terms = ['start=1', 'end=5', 'count=5', 'stride=2', 'format=0x%02x']
    variables = ''
    kwargs = ''

    # Create instance of class
    L = LookupModule()

    # Test run method
    results = L.run(terms, variables, **kwargs)

    # Assert
    try:
        assert( isinstance(results, list) )
    except AssertionError as e:
        print("\nFAIL: test_LookupModule_run:\n")
        raise(e)


# Generated at 2022-06-23 12:00:15.788210
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lm = LookupModule()
    lm.stride = -1
    lm.start = 10
    lm.end = 0
    lm.format = '%d'
    expected = ['10', '9', '8', '7', '6', '5', '4', '3', '2', '1']
    result = list(lm.generate_sequence())
    assert expected == result, result

# Generated at 2022-06-23 12:00:27.229065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:00:32.089013
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    # Test 1
    lookup = LookupModule()
    args = dict(start="8", end="12", format="testuser%03x")
    lookup.parse_kv_args(args)
    assert lookup.start == 8
    assert lookup.end == 12
    assert lookup.stride == 1
    assert lookup.format == "testuser%03x"


# Generated at 2022-06-23 12:00:37.122961
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    l.start = 1
    l.count = None
    l.end = 5
    l.stride = 1
    l.format = "%d"
    l.reset()
    assert l.start == 1
    assert l.count == None
    assert l.end == None
    assert l.stride == 1
    assert l.format == "%d"


# Generated at 2022-06-23 12:00:46.408819
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    parse_sequence = LookupModule()

    parse_sequence.reset()
    assert parse_sequence.parse_simple_args("5") == True
    assert parse_sequence.start == 1
    assert parse_sequence.end == 5
    assert parse_sequence.stride == 1
    assert parse_sequence.format == "%d"

    parse_sequence.reset()
    assert parse_sequence.parse_simple_args("0x5") == True
    assert parse_sequence.start == 1
    assert parse_sequence.end == 5
    assert parse_sequence.stride == 1
    assert parse_sequence.format == "%d"

    parse_sequence.reset()
    assert parse_sequence.parse_simple_args("04") == True
    assert parse_sequence.start == 1
    assert parse_sequence.end == 4

# Generated at 2022-06-23 12:00:52.333274
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    module = LookupModule()
    module.start = 2
    module.count = 3
    module.end = 4
    module.stride = 5
    module.format = '%s'
    module.reset()

    assert module.start == 1
    assert module.count == None
    assert module.end == None
    assert module.stride == 1
    assert module.format == '%d'


# Generated at 2022-06-23 12:00:56.522253
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lu = LookupModule()
    lu.reset()
    assert lu.start == 1
    assert lu.end == None
    assert lu.count == None
    assert lu.stride == 1
    assert lu.format == "%d"


# Generated at 2022-06-23 12:00:58.887881
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    lookup = LookupModule()
    lookup.reset()

    terms = ["5", "5-8", "2-10/2", "4:host%02d", "0-a"]

    for term in terms:
        result = lookup.parse_simple_args(term)
        assert result == True, "test_LookupModule_parse_simple_args failed for term %s with result %s" % (term, result)


# Generated at 2022-06-23 12:01:08.777307
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    args = {
        'start': 0,
        'count': 1,
        'stride': 1,
        'format': "%d"
    }
    lookup_module.parse_kv_args(args)
    try:
        lookup_module.sanity_check()
    except AnsibleError as e:
        assert False, "Test failed: " + str(e)
    args = {
        'start': 0,
        'count': 1,
        'stride': -1,
        'format': "%d"
    }
    lookup_module.parse_kv_args(args)
    try:
        lookup_module.sanity_check()
    except AnsibleError as e:
        assert False, "Test failed: " + str(e)

# Generated at 2022-06-23 12:01:19.849213
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Test 1.
    # Tested method: sanity_check
    # Test case: no count given, no end given => AnsibleError
    test_lm = LookupModule()
    test_lm.reset()
    try:
        test_lm.sanity_check()
    except AnsibleError as e:
        assert "must specify count or end in with_sequence" in str(e)

    # Test 2.
    # Tested method: sanity_check
    # Test case: no count given, but end given => no error
    test_lm = LookupModule()
    test_lm.reset()
    test_lm.end = 10
    try:
        test_lm.sanity_check()
    except AnsibleError as e:
        assert False

    # Test 3.
    # Tested method

# Generated at 2022-06-23 12:01:25.925165
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    assert all(str(i) == i for i in LookupModule.generate_sequence(None, 1, 10, 1, '%d'))
    assert all(str(i) == i for i in LookupModule.generate_sequence(None, 1, 10, 2, '%d'))
    assert all(str(i) == i for i in LookupModule.generate_sequence(None, 10, 1, -1, '%d'))
    assert all(str(i) == i for i in LookupModule.generate_sequence(None, 10, 1, -2, '%d'))
    assert all(str(i) == i for i in LookupModule.generate_sequence(None, 1, 1, -1, '%d'))

# Generated at 2022-06-23 12:01:36.872574
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lm = LookupModule()
    lm.reset()
    lm.parse_simple_args("")
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == None
    assert lm.stride == 1
    assert lm.format == "%d"
    lm.reset()
    lm.parse_simple_args("0")
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == 0
    assert lm.stride == 1
    assert lm.format == "%d"
    lm.reset()
    lm.parse_simple_args("7")
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == 7

# Generated at 2022-06-23 12:01:42.579057
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    args = {
        'start': '2',
        'end': '10',
        'stride': '2',
        'format': '%02x'
    }
    l = LookupModule()
    l.parse_kv_args(args)

    assert l.start == 2
    assert l.end == 10
    assert l.stride == 2
    assert l.format == '%02x'
    assert args == {}



# Generated at 2022-06-23 12:01:45.378197
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    lookup.reset()
    lookup.parse_kv_args(parse_kv("start=1 end=5"))
    assert lookup.start == 1
    assert lookup.end == 5
    assert lookup.stride == 1


# Generated at 2022-06-23 12:01:57.515722
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # Create a LookupModule object and set some variables
    lookup = LookupModule()
    lookup.reset()

    # First test
    test_dict_1 = {'start': '1', 'end': '10', 'stride': '2', 'format': '0x%02x'}
    lookup.parse_kv_args(test_dict_1)
    assert lookup.start == 1
    assert lookup.end == 10
    assert lookup.stride == 2
    assert lookup.format == '0x%02x'
    assert lookup.count is None

    # Second test
    lookup.reset()
    test_dict_2 = {'start': '1', 'end': '10'}
    lookup.parse_kv_args(test_dict_2)
    assert lookup.start == 1

# Generated at 2022-06-23 12:02:00.722171
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    # Setup
    lookup_module = LookupModule()

    # Execute
    result = lookup_module.parse_simple_args("abc")

    # Verify
    assert result == False


# Generated at 2022-06-23 12:02:07.452245
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()

    lookup_module.start = 1
    lookup_module.end = 20
    lookup_module.stride = 2
    lookup_module.format = "%d"
    res = lookup_module.generate_sequence()
    assert len(list(res)) == 10

    lookup_module.start = 0
    res = lookup_module.generate_sequence()
    assert len(list(res)) == 11

    lookup_module.stride = -2
    res = lookup_module.generate_sequence()
    assert len(list(res)) == 10

    lookup_module.start = 10
    lookup_module.end = 1
    res = lookup_module.generate_sequence()
    assert len(list(res)) == 5


# Generated at 2022-06-23 12:02:11.490179
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    obj = LookupModule()
    obj.reset()
    assert obj.start == 1
    assert obj.count == None
    assert obj.end == None
    assert obj.stride == 1
    assert obj.format == "%d"


# Generated at 2022-06-23 12:02:22.505119
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Positive case, stride 1
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 1
    lookup_module.format = "%02d"

    result = list(lookup_module.generate_sequence())
    assert(result == ['01', '02', '03', '04', '05'])

    # Positive case, stride 2
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.stride = 2
    lookup_module.format = "%02d"

    result = list(lookup_module.generate_sequence())
    assert(result == ['01', '03', '05'])

    # Positive case, stride -1
    lookup_module

# Generated at 2022-06-23 12:02:25.011269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['1', '10', '100', '1000', '10000']
    results = lookup.run(terms, None)
    assert results == ['1', '10', '100', '1000', '10000']

# Generated at 2022-06-23 12:02:36.896643
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    term = "5-8"
    lookup_module.parse_simple_args(term)
    assert lookup_module.start == 5
    assert lookup_module.end == 8
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    term = "0x5-0x8/2"
    lookup_module.parse_simple_args(term)
    assert lookup_module.start == 5
    assert lookup_module.end == 8
    assert lookup_module.stride == 2
    assert lookup_module.format == "%d"
    term = "0x7-0x10:%#04x"
    lookup_module.parse_simple_args(term)
    assert lookup_module.start == 7
    assert lookup_module.end == 16

# Generated at 2022-06-23 12:02:44.406038
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    seq = LookupModule()
    seq.end = 3
    # no count no end
    try:
        seq.sanity_check()
        assert False
    except AnsibleError:
        assert True
    # no count no end
    seq.count = 3
    try:
        seq.sanity_check()
        assert False
    except AnsibleError:
        assert True
    # count
    seq.count = 0
    seq.sanity_check()
    assert seq.start == 0
    assert seq.end == 0
    assert seq.stride == 0
    # count
    seq.count = 3
    seq.sanity_check()
    assert seq.start == 0
    assert seq.end == 3
    assert seq.stride == 1
    seq.stride = 2
    seq.sanity_check()


# Generated at 2022-06-23 12:02:48.583058
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    lm.reset()
    lm.start == 1
    lm.count == None
    lm.end == None
    lm.stride == 1
    lm.format == "%d"



# Generated at 2022-06-23 12:02:57.831066
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    class _ModuleStub:
        def __init__(self, *args):
            pass

        def fail_json(self, msg):
            raise AssertionError(msg)

    class _LookupBaseStub:
        def __init__(self):
            self.term = None
            self.templar = None
            self.params = None
            self.basedir = None
            self.runner_on_lookup_fail = False
            self.runner_on_unreachable = False
            self.runner_on_async_poll = None
            self.runner_on_async_ok = None
            self.runner_on_async_failed = None
            self.runner = None
            self.inject = None

        def _configure_timeout(self):
            pass


# Generated at 2022-06-23 12:03:06.007009
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    module_args = dict(start=1, end=1, format=None, count=None, stride=-1)
    l = LookupModule()
    l.run(module_args, None)
    assert module_args['start'] == 1
    assert module_args['end'] == 1
    assert module_args['format'] == None
    assert module_args['count'] == None
    assert module_args['stride'] == -1
    l.reset()
    assert module_args['start'] == 1
    assert module_args['end'] == 1
    assert module_args['format'] == "%d"
    assert module_args['count'] == None
    assert module_args['stride'] == 1


# Generated at 2022-06-23 12:03:17.234283
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    import pytest

    with pytest.raises(AnsibleError):
        lm = LookupModule()
        lm.count = 10
        lm.end = 10
        lm.sanity_check()

    with pytest.raises(AnsibleError):
        lm = LookupModule()
        lm.count = None
        lm.end = None
        lm.sanity_check()

    with pytest.raises(AnsibleError):
        lm = LookupModule()
        lm.count = 10
        lm.end = 10
        lm.sanity_check()

    with pytest.raises(AnsibleError):
        lm = LookupModule()
        lm.start = 10
        lm.end = 8
        lm.stride = 2

# Generated at 2022-06-23 12:03:27.001046
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import pytest

    # arrange
    parm = LookupModule()

    # assert
    with pytest.raises(AnsibleError) as myerrorinfo:
        parm.count = 1
        parm.sanity_check()
    assert str(myerrorinfo.value) == "must specify count or end in with_sequence"

    # assert
    with pytest.raises(AnsibleError) as myerrorinfo:
        parm.count = 2
        parm.end = 2
        parm.sanity_check()
    assert str(myerrorinfo.value) == "can't specify both count and end in with_sequence"

    # assert
    with pytest.raises(AnsibleError) as myerrorinfo:
        parm.start = 1
        parm.end = 0

# Generated at 2022-06-23 12:03:29.294404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    o = LookupModule()
    res = o.run([], None)
    print("res=", res)

# Generated at 2022-06-23 12:03:32.314484
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"

# Generated at 2022-06-23 12:03:33.439144
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    pass

# Generated at 2022-06-23 12:03:43.734523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    t = [ 'start=1 end=5' ]
    v = {}
    result = lm.run(terms=t, variables=v)
    assert result == ['1', '2', '3', '4', '5']

    t = [ '1-5' ]
    v = {}
    result = lm.run(terms=t, variables=v)
    assert result == ['1', '2', '3', '4', '5']

    t = [ 'start=1 end=16 stride=2' ]
    v = {}
    result = lm.run(terms=t, variables=v)
    assert result == ['1', '3', '5', '7', '9', '11', '13', '15']

    t = [ '1-16/2' ]


# Generated at 2022-06-23 12:03:50.355199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # initialize and verify LookupModule object
    sequence = LookupModule()

    attributes = dir(sequence)
    assert 'run' in attributes
    assert 'generate_sequence' in attributes
    assert 'parse_simple_args' in attributes
    assert 'parse_kv_args' in attributes
    assert 'sanity_check' in attributes
    assert 'reset' in attributes

    return sequence



# Generated at 2022-06-23 12:03:53.480541
# Unit test for constructor of class LookupModule
def test_LookupModule():

    #Success test
    lm = LookupModule()
    assert lm

    #Failure test
    try:
        lm = LookupModule("Test")
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 12:04:04.855572
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    start = 1
    end = 9
    stride = 1
    format = '%02d'

    obj = LookupModule()
    obj.start = start
    obj.end = end
    obj.stride = stride
    obj.format = format
    result = obj.generate_sequence()
    assert(len(result) == end)
    for i, j in enumerate(result):
        assert(format % (start + stride*i) == j)

    start = 1
    end = 3
    stride = 3
    format = '%02d'

    obj = LookupModule()
    obj.start = start
    obj.end = end
    obj.stride = stride
    obj.format = format
    result = obj.generate_sequence()
    assert(len(result) == end)

# Generated at 2022-06-23 12:04:14.248914
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lm = LookupModule()
    lm.start = 100
    lm.end = 105
    lm.stride = 1
    lm.format = "%02d"
    assert lm.generate_sequence() is not None
    assert [i for i in lm.generate_sequence()] == ['100', '101', '102', '103', '104', '105']
    lm.start = 100
    lm.end = 105
    lm.stride = 2
    lm.format = "%02d"
    assert lm.generate_sequence() is not None
    assert [i for i in lm.generate_sequence()] == ['100', '102', '104']
    lm.start = 10
    lm.end = 0
    lm.stride = -1
   

# Generated at 2022-06-23 12:04:16.793580
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    """Unit test for method reset of class LookupModule"""
    lm = LookupModule()
    lm.reset()
    assert lm.start == 1
    assert lm.count == None
    assert lm.end == None
    assert lm.stride == 1
    assert lm.format == '%d'


# Generated at 2022-06-23 12:04:24.589786
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    assert lookup.start == 1, "default start value should be 1"
    assert lookup.count == None, "default count value should be None"
    assert lookup.end == None, "default end value should be None"
    assert lookup.stride == 1, "default stride value should be 1"
    assert lookup.format == "%d", "default format value should be '%d'"
    lookup.parse_kv_args(["start=2","end=3","stride=4","format=5"])
    assert lookup.start == 2, "start value should be 2"
    assert lookup.count == None, "count value should be None"
    assert lookup.end == 3, "end value should be 3"
    assert lookup.stride == 4, "stride value should be 4"

# Generated at 2022-06-23 12:04:30.854875
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    look = LookupModule()
    look.start = 1
    look.count = 2
    look.end = 3
    look.stride = 4
    look.format = '%d'

    look.reset()
    assert look.start == 1
    assert look.count == None
    assert look.end == None
    assert look.stride == 1
    assert look.format == '%d'


# Generated at 2022-06-23 12:04:40.654300
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import pytest
    sequence = LookupModule()
    sequence.reset()
    assert sequence.sanity_check() == None
    sequence.stride = -1
    sequence.start = 1
    sequence.end = 0
    with pytest.raises(AnsibleError, match=r"to count backwards make stride negative"):
        sequence.sanity_check()
    sequence.stride = 1
    sequence.start = 1
    sequence.end = 0
    with pytest.raises(AnsibleError, match=r"to count forward don't make stride negative"):
        sequence.sanity_check()
    sequence.stride = 1
    sequence.start = 0
    sequence.end = 0
    sequence.format = "%s"

# Generated at 2022-06-23 12:04:52.742515
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    import pytest
    from operator import ne, gt, lt
    from ansible.module_utils.six.moves import xrange

    class TestError(Exception):
        pass

    class LookupModule:
        def reset(self):
            self.start = 1
            self.count = None
            self.end = None
            self.stride = 1
            self.format = "%d"

        def parse_kv_args(self, args):
            raise TestError("parse_kv_args")

        def parse_simple_args(self, term):
            raise TestError("parse_simple_args")

        def sanity_check(self):
            pass

        def generate_sequence(self):
            return self._generate_sequence()


# Generated at 2022-06-23 12:04:53.819027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert isinstance(L, LookupBase)


# Generated at 2022-06-23 12:04:57.533997
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-23 12:05:08.622420
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    l = LookupModule()
    l.count = None
    l.end = None
    try:
        l.sanity_check()
        assert 0, "sanity  check should fail if both count and end are None"
    except AnsibleError:
        pass

    l.end = 0
    try:
        l.sanity_check()
        assert 0, "sanity  check should fail if both count and end are set"
    except AnsibleError:
        pass

    l.end = None
    l.count = 0
    l.sanity_check()

    l.start = 1
    l.end = 0
    l.stride = 1

# Generated at 2022-06-23 12:05:21.161942
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Covered cases:
    #  - Count and end are specified
    #  - Count is zero, end is None
    #  - Stride is positive, end is less than start
    #  - Stride is negative, end is greater than start
    #  - Format string is bad
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = 5
    lookup_module.stride = 1
    lookup_module.format = "%d"

    assert lookup_module.sanity_check() == None
    assert lookup_module.end == 5
    del lookup_module.count
    lookup_module.end = 10
    assert lookup_module.sanity_check() == None

    lookup_module.start = 1
    lookup_module.end = None
    lookup_module.count = 0


# Generated at 2022-06-23 12:05:32.026873
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # 1
    term = '5'
    start = None
    end = '5'
    stride = None
    format = None
    lm = LookupModule()
    lm.reset()
    lm.parse_simple_args(term)
    assert lm.start == start
    assert lm.end == end
    assert lm.stride == stride
    assert lm.format == format
    lm = None
    # 2
    term = '5-8'
    start = '5'
    end = '8'
    stride = None
    format = None
    lm = LookupModule()
    lm.reset()
    lm.parse_simple_args(term)
    assert lm.start == start
    assert lm.end == end
    assert lm.stride == stride


# Generated at 2022-06-23 12:05:39.394081
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    # Run test sequence with start = 10, end = 1, stride = -1
    lm = LookupModule()
    lm.reset()
    lm.parse_simple_args("10-1/-1")
    lm.sanity_check()
    result = list(lm.generate_sequence())
    assert (result == ["10", "9", "8", "7", "6", "5", "4", "3", "2", "1"])

    # Run test sequence with start = 10, end = 1, stride = -1111
    lm = LookupModule()
    lm.reset()
    lm.parse_simple_args("10-1/-1111")
    lm.sanity_check()
    result = list(lm.generate_sequence())

# Generated at 2022-06-23 12:05:50.587804
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    from ansible.plugins.lookup.sequence import LookupModule
    print("Test: LookupModule_parse_simple_args")
    l = LookupModule()
    l.reset()
    res = l.parse_simple_args("something")
    assert res == False
    assert l.start == 1
    assert l.count == None
    assert l.end == None
    assert l.stride == 1
    assert l.format == "%d"
    res = l.parse_simple_args("5")
    assert res == True
    assert l.start == 1
    assert l.count == None
    assert l.end == 5
    assert l.stride == 1
    assert l.format == "%d"
    res = l.parse_simple_args("5-8")
    assert res == True
    assert l.start

# Generated at 2022-06-23 12:06:02.574587
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.lookup import lookup_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import test_loader

    LOADER = AnsibleLoader(None, "")
    i = LOADER.get_single_data("- { start: 1, end: 5 }")
    i2 = LOADER.get_single_data("- { start: 1, count: 4 }")
    i3 = LOADER.get_single_data("- { start: 1, end: 2, count: 2 }")

    terms = [i, i2, i3]
    LookupModule.reset(None)
    for idx, term in enumerate(terms):
        assert LookupModule.parse_simple_

# Generated at 2022-06-23 12:06:08.915308
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    test_sequence = LookupModule()
    assert list(test_sequence.generate_sequence()) == []
    test_sequence.start = 3
    test_sequence.end = 5
    test_sequence.format = "%d"
    assert list(test_sequence.generate_sequence()) == ["3","4","5"]
    test_sequence.end = 2
    test_sequence.stride = -1
    assert list(test_sequence.generate_sequence()) == ["3","2"]
    assert list(test_sequence.generate_sequence()) == []
    test_sequence.reset()
    test_sequence.start=4
    test_sequence.end=16
    test_sequence.stride=2

# Generated at 2022-06-23 12:06:13.335031
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Parameterized test for method sanity_check
    # Testing both count and end specified
    # Expected result: AnsibleError
    lm = LookupModule()
    lm.count = 1
    lm.end = 1
    try:
        lm.sanity_check()
        assert False
    except AnsibleError:
        pass

    # Parameterized test for method sanity_check
    # Testing only count specified
    # Expected result: No exception thrown
    lm = LookupModule()
    lm.count = 1
    try:
        lm.sanity_check()
    except AnsibleError:
        assert False

    # Parameterized test for method sanity_check
    # Testing only end specified, start and end have same values, stride is 1
    # Expected result: No exception thrown

# Generated at 2022-06-23 12:06:21.636292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Validate Class Variables (module_utils.basic.AnsibleModule.construct_lookup_module)
    assert lookup.lookup_type == 'sequence'
    assert lookup.lookup_name == 'sequence'
    assert lookup.lookup_global_options == {}
    assert lookup.lookup_options == []
    assert lookup.case_sensitive == False
    assert lookup.safe_strings == True
    assert lookup.max_recursion_depth == None
    assert lookup.keep_trailing_newline == False


# Generated at 2022-06-23 12:06:27.497726
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()
    lookup_module.reset()
    # start
    assert lookup_module.start == 1
    # count
    assert lookup_module.count is None
    # end
    assert lookup_module.end is None
    # stride
    assert lookup_module.stride == 1
    # format
    assert lookup_module.format == "%d"


# Generated at 2022-06-23 12:06:39.403978
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    Input = {}
    Input['start'] = 1
    Input['count'] = None
    Input['end'] = None
    Input['stride'] = 1
    Input['format'] = "%d"
    test_zero = LookupModule()
    assert test_zero.sanity_check() == AnsibleError('must specify count or end in with_sequence')

    Input['end'] = 0
    test_one = LookupModule()
    assert test_one.sanity_check() == None

    Input['start'] = 0
    Input['end'] = 0
    Input['stride'] = 0
    test_two = LookupModule()
    assert test_two.sanity_check() == None

    Input['start'] = 0
    Input['end'] = 100
    Input['stride'] = 0
    test_three = LookupModule

# Generated at 2022-06-23 12:06:42.612885
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    res = LookupModule()
    try:
        assert(res.start == 1)
        assert(res.end == 0)
        assert(res.stride == 1)
        assert(res.format == "%d")
    except:
        return False


# Generated at 2022-06-23 12:06:54.511975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test sequence with simple arguments
    result = lookup_module.run(["end= 5"], variables=[], **{})
    assert result == ["1", "2", "3", "4", "5"]

    result = lookup_module.run(["5"], variables=[], **{})
    assert result == ["1", "2", "3", "4", "5"]

    result = lookup_module.run(["start= 5 end= 8"], variables=[], **{})
    assert result == ["5", "6", "7", "8"]

    result = lookup_module.run(["start= 5- 8"], variables=[], **{})
    assert result == ["5", "6", "7", "8"]


# Generated at 2022-06-23 12:07:01.736544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Build arguments
    terms = ['end=10 format=test%02d', {'start': 0, 'count': 5, 'stride': 2, 'format': 'test%02d'}]

    # Build variables
    variables = {}

    # Run unit test
    value_expected = ['test01', 'test02', 'test03', 'test04', 'test05', 'test00', 'test02', 'test04', 'test06', 'test08']
    value_obtained = lookup.run(terms, variables)
    assert value_expected == value_obtained

# Generated at 2022-06-23 12:07:06.565261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testmodule = LookupModule()
    terms = ["start=5 end=11 stride=2 format=0x%02x"]
    variables = None
    kwargs = {}
    results = testmodule.run(terms, variables, **kwargs)
    assert results == ['0x05','0x07','0x09','0x0a']

# Generated at 2022-06-23 12:07:11.723997
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lm = LookupModule()
    lm.start = 2
    lm.end = 4
    lm.stride = 1
    lm.format = ""

    lm.reset()

    assert lm.start == 1
    assert lm.end is None
    assert lm.stride == 1
    assert lm.format == "%d"

# Unit tests for method parse_kv_args of class LookupModule

# Generated at 2022-06-23 12:07:20.911829
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    lookup.reset()
    lookup.parse_kv_args(dict(start='1', end='5', stride='2', format='%02d'))
    assert lookup.start==1,'parse_kv_args() failed to set attribute start'
    assert lookup.end==5,'parse_kv_args() failed to set attribute end'
    assert lookup.stride==2,'parse_kv_args() failed to set attribute stride'
    assert lookup.format=='%02d','parse_kv_args() failed to set attribute format'


# Generated at 2022-06-23 12:07:29.185275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json

    # testing alternate options, one at a time
    options = {
        'start': '0',
        'end': '10',
        'count': '10',
        'stride': '5',
        'format': '%01d'
    }
    expected = [
        '1',
        '6'
    ]
    assert json.loads(LookupModule(None, options).run()[0]) == expected
    options = {
        'start': '0',
        'end': '10',
        'stride': '5',
        'format': '%01d'
    }
    expected = [
        '1',
        '6'
    ]
    assert json.loads(LookupModule(None, options).run()[0]) == expected


# Generated at 2022-06-23 12:07:34.031671
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    try:
        test_obj = LookupModule()
        assert test_obj.start == 1
        assert test_obj.end is None
        assert test_obj.stride == 1
        assert test_obj.format == "%d"
    except Exception:
        assert False


# Generated at 2022-06-23 12:07:41.661189
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    import os
    from ansible.plugins.lookup import LookupModule
    lookup = LookupModule()
    lookup.reset()
    lookup.parse_kv_args({"start": "0x100", "end": "0x200", "stride": "-6", "format": "0x%x"})
    assert lookup.start == 0x100
    assert lookup.end == 0x200
    assert lookup.stride == -6
    assert lookup.format == "0x%x"


# Generated at 2022-06-23 12:07:48.933179
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    test_module = LookupModule()
    test_module.start = -1
    test_module.count = -1
    test_module.end = -1
    test_module.stride = -1
    test_module.format = "test_format"
    test_module.reset()
    assert test_module.start == 1
    assert test_module.count is None
    assert test_module.end is None
    assert test_module.stride == 1
    assert test_module.format == "%d"


# Generated at 2022-06-23 12:07:59.179690
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    from six import PY2
    if PY2:
        from mock import patch
    else:
        from unittest.mock import patch

    with patch.object(LookupModule, 'generate_sequence', return_value=['test']):
        LOOKUP = LookupModule()
        LOOKUP.reset()
        LOOKUP.parse_kv_args({'format': '%-d', 'start': '2', 'end': '10', 'stride': '2'})

        assert LOOKUP.start == 2
        assert LOOKUP.end == 10
        assert LOOKUP.stride == 2
        assert LOOKUP.format == '%-d'

        LOOKUP.reset()

# Generated at 2022-06-23 12:08:06.498378
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    # simple arguments
    args = dict(start=1, end=100, stride=2, format="result %d")
    lookup.parse_kv_args(args)
    assert lookup.start == 1, "start should be 1"
    assert lookup.end == 100, "end should be 100"
    assert lookup.stride == 2, "stride should be 2"
    assert lookup.format == "result %d", "format should be result %d"
    assert len(args) == 0, "all arguments should be parsed"
    # octal/hex arguments
    args = dict(start="0o1", end="0x64", stride="0x02", format="result %d")
    lookup.parse_kv_args(args)
    assert lookup.start == 1, "start should be 1"

# Generated at 2022-06-23 12:08:16.568881
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    lookup.reset()
    assert not lookup.parse_simple_args("test")
    assert not lookup.parse_simple_args("1test")
    assert not lookup.parse_simple_args("1test/test")
    assert not lookup.parse_simple_args("1/test/test")
    assert not lookup.parse_simple_args("1/test/test:test")
    assert not lookup.parse_simple_args("1/test:test:test")
    assert not lookup.parse_simple_args("1-test/test:test")
    assert lookup.start == 1, "start should be 1: %r" % lookup.start
    assert lookup.end == 0, "end should be 0: %r" % lookup.end

# Generated at 2022-06-23 12:08:28.696584
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    module = LookupModule()
    module.format = "%d"

    # positive stride
    module.start = 1
    module.end = 5
    module.stride = 1
    assert list(module.generate_sequence()) == ['1', '2', '3', '4', '5']
    module.start = 0x11
    module.end = 0x15
    module.stride = 1
    assert list(module.generate_sequence()) == ['17', '18', '19', '20', '21']
    module.stride = 3
    assert list(module.generate_sequence()) == ['17', '20']

    # negative stride
    module.start = 4
    module.end = 1
    module.stride = -1

# Generated at 2022-06-23 12:08:37.990620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up a dummy AnisbleModule object to pass to run
    class DummyAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
        def fail_json(self, **kwargs):
            raise Exception('test_LookupModule_run fail_json')
    class DummyTerms(list):
        def __init__(self, l):
            for elem in l:
                self.append(elem)
        def __getitem__(self, item):
            return self.__getattribute__(item)
    fixture_terms = DummyTerms(["start=3 end=5:item%d", "start=0x1F7 end=0x1F8 format=hex%X"])
    fixture_variables = {}
    fixture

# Generated at 2022-06-23 12:08:40.572756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(terms=["count=5", "start=3 end=8"],
          variables=None,
          **{})


# Generated at 2022-06-23 12:08:45.567279
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 1
    lookup.count = 1
    lookup.end = 1
    lookup.stride = 1
    lookup.format = 1
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-23 12:08:46.568141
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule() != None)

# Generated at 2022-06-23 12:08:52.530229
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 2
    lookup.count = 2
    lookup.end = 3
    lookup.stride = 1
    lookup.format = "a"
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-23 12:09:03.264363
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    result = lookup.parse_simple_args('1-2/1')
    assert result == True
    assert lookup.start == 1
    assert lookup.end == 2
    assert lookup.stride == 1
    assert lookup.format == '%d'
    assert lookup.count is None

    result = lookup.parse_simple_args('1-2/1:%d')
    assert result == True
    assert lookup.start == 1
    assert lookup.end == 2
    assert lookup.stride == 1
    assert lookup.format == '%d'
    assert lookup.count is None

    result = lookup.parse_simple_args('1/2:%d')
    assert result == True
    assert lookup.start == 1
    assert lookup.end == 1
    assert lookup.stride == 2

# Generated at 2022-06-23 12:09:14.728904
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Test arguments being passed in
    assert list(LookupModule.generate_sequence(LookupModule(),
                                               start=0, end=10, stride=1, format="%04d")) == \
                                               ['0000', '0001', '0002', '0003', '0004', '0005', '0006', '0007', '0008', '0009', '0010']
    assert list(LookupModule.generate_sequence(LookupModule(),
                                               start=0, end=10, stride=2, format="%04d")) == \
                                               ['0000', '0002', '0004', '0006', '0008', '0010']

# Generated at 2022-06-23 12:09:21.535788
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Setup for test
    instance = LookupModule()
    instance.start = 1
    instance.end = 0
    instance.stride = 1
    instance.format = "%d"

    # Execute test method
    with pytest.raises(AnsibleError) as excinfo:
        instance.sanity_check()

    # Check exception type and message
    assert excinfo.type == AnsibleError
    assert excinfo.value.message == "to count backwards make stride negative"

# Generated at 2022-06-23 12:09:30.351243
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lmod = LookupModule()
    # Test 1:
    term = "2"
    assert lmod.parse_simple_args(term)
    assert lmod.start == 1
    assert lmod.end == 2
    assert lmod.stride == 1
    assert lmod.format == "%d"

    # Test 2:
    lmod.reset()
    term = "2-20"
    assert lmod.parse_simple_args(term)
    assert lmod.start == 2
    assert lmod.end == 20
    assert lmod.stride == 1
    assert lmod.format == "%d"

    # Test 3:
    lmod.reset()
    term = "2-20/2"
    assert lmod.parse_simple_args(term)
    assert lmod.start == 2

# Generated at 2022-06-23 12:09:31.000076
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:09:42.075031
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    def check_test_cases(test_cases, error_message):
        for test_case, expected_error in test_cases:
            try:
                lookup_module = LookupModule()
                lookup_module.sanity_check()
                assert not expected_error, "missing error"
            except AnsibleError as exc:
                assert expected_error, "unexpected error '%s'" % str(exc)
                assert error_message == str(exc), "unexpected error '%s'" % str(exc)
            except Exception as exc:
                assert not expected_error, "unexpected error '%s'" % str(exc)
                assert error_message == str(exc), "unexpected error '%s'" % str(exc)


# Generated at 2022-06-23 12:09:53.445206
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    look = LookupModule()
    # Shortcut form (0600): no start, no format
    assert look.parse_simple_args('0600')
    assert look.start == 0
    assert look.end == 0o600
    assert look.stride == 1
    assert look.format == "%d"
    # Shortcut form (0600): no start, no format
    assert look.parse_simple_args('0x3f8')
    assert look.start == 0
    assert look.end == 0x3f8
    assert look.stride == 1
    assert look.format == "%d"
    # Shortcut form (0600): no start, no format
    assert look.parse_simple_args('16')
    assert look.start == 0
    assert look.end == 16
    assert look.stride == 1
   