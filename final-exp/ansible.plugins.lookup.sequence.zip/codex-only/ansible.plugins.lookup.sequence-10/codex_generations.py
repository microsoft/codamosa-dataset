

# Generated at 2022-06-23 11:59:50.825461
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert type(lookup_plugin) == LookupModule

# Generated at 2022-06-23 11:59:55.412559
# Unit test for constructor of class LookupModule
def test_LookupModule():
   # Constructor for class LookupModule
   lkup = LookupModule()

   # Call to method run of class LookupModule
   lkup.run([])
   lkup.run([], {})
   lkup.run([], {}, **{'variable': {}})

# Generated at 2022-06-23 12:00:03.713474
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    # Initialize instance of class LookupModule
    LookupModule_instance = LookupModule()
    #Set the following attributes
    LookupModule_instance.start = 1
    LookupModule_instance.end = None
    LookupModule_instance.stride = 1
    LookupModule_instance.format = "%d"

    #Set count = None
    LookupModule_instance.count = None

    #Test with count = None
    try:
        LookupModule_instance.sanity_check()
        assert False, "test_LookupModule_sanity_check: Need to raise AnsibleError"
    except AnsibleError:
        assert True

    #Set the following attributes
    LookupModule_instance.end = 1
    LookupModule_instance.count = 1

    #Test with end and count are not None

# Generated at 2022-06-23 12:00:09.849410
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    l.start = 5
    l.count = 3
    l.end = 4
    l.stride = 2
    l.format = '%d'
    l.reset()
    assert l.start == 1
    assert l.count == None
    assert l.end == None
    assert l.stride == 1
    assert l.format == '%d'


# Generated at 2022-06-23 12:00:16.990300
# Unit test for method generate_sequence of class LookupModule

# Generated at 2022-06-23 12:00:28.232877
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """
    Test method parse_simple_args of class LookupModule
    """
    # Test valid format of term
    lookupmodule = LookupModule()
    assert lookupmodule.parse_simple_args('3') == True
    assert lookupmodule.parse_simple_args('8-12') == True
    assert lookupmodule.parse_simple_args('0xA-0xD') == True
    assert lookupmodule.parse_simple_args('0x02-0x04/2') == True
    assert lookupmodule.parse_simple_args('8:0x%04x') == True
    assert lookupmodule.parse_simple_args('7-11') == True
    assert lookupmodule.parse_simple_args('1-9/2') == True
    assert lookupmodule.parse_simple_args('9:host%02d') == True
   

# Generated at 2022-06-23 12:00:30.563599
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    module = LookupModule({})
    module.start = 0
    module.count = 10
    expect_result = None
    try:
        module.sanity_check()
    except AnsibleError:
        expect_result = "can't specify both count and end in with_sequence"
    finally:
        assert expect_result == "can't specify both count and end in with_sequence", "test with_sequence sanity_check failed"

# Generated at 2022-06-23 12:00:41.028398
# Unit test for method parse_simple_args of class LookupModule

# Generated at 2022-06-23 12:00:48.526935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    plugins_path = './library/plugins/lookup'
    lookup_module = 'sequence'
    lookup_args = 'start=4 end=16 stride=2'
    lookup_args_hash = {'start': '4', 'end': '16', 'stride': '2'}
    vm = LookupModule(plugins_path=plugins_path, lookup_module=lookup_module)

    result_str = vm.run(terms=lookup_args, variables=None, **{})
    result_hash = vm.run(terms=lookup_args_hash, variables=None, **{})

    assert result_str == result_hash

    expected_result = ['4', '6', '8', '10', '12', '14', '16']
    assert result_str == expected_result

# Generated at 2022-06-23 12:00:59.066253
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.start = 0
    lookup_module.end = 16
    lookup_module.stride = 2
    lookup_module.format = 'testuser%02x'
    assert(list(lookup_module.generate_sequence()) == ['testuser00', 'testuser02', 'testuser04', 'testuser06', 'testuser08', 'testuser0a', 'testuser0c', 'testuser0e', 'testuser10'])
    lookup_module.start = 4
    lookup_module.end = 16
    lookup_module.stride = 2
    lookup_module.format = 'testuser%02x'

# Generated at 2022-06-23 12:00:59.913023
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:01:09.222548
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()
    l.start = 1
    l.end = 2
    l.stride = 1
    l.format = "%d"

    generated_sequence = l.generate_sequence()

    assert(generated_sequence.__next__() == "1")
    assert(generated_sequence.__next__() == "2")
    try:
        generated_sequence.__next__()
    except StopIteration:
        pass
    else:
        assert(False)

    l.stride = -1
    generated_sequence = l.generate_sequence()

    assert(generated_sequence.__next__() == "2")
    assert(generated_sequence.__next__() == "1")
    try:
        generated_sequence.__next__()
    except StopIteration:
        pass

# Generated at 2022-06-23 12:01:20.117032
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # test 1
    l = LookupModule()
    l.start = 1
    l.end = 5
    l.stride = 1
    l.format = "%d"
    assert l.generate_sequence() == ["1","2","3","4","5"]

    # test 2
    l = LookupModule()
    l.start = 3
    l.end = 5
    l.stride = 1
    l.format = "%d"
    assert l.generate_sequence() == ["3","4","5"]

    # test 3
    l = LookupModule()
    l.start = 5
    l.end = 8
    l.stride = 1
    l.format = "%d"
    assert l.generate_sequence() == ["5","6","7","8"]

    # test 4
    l

# Generated at 2022-06-23 12:01:31.074031
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    l = LookupModule()
    l.reset()
    results = l.parse_simple_args("5-8")
    assert results is True

    l = LookupModule()
    l.reset()
    results = l.parse_simple_args("5-8")
    assert l.start == 5
    assert l.end == 8
    assert l.stride == 1

    l = LookupModule()
    l.reset()
    results = l.parse_simple_args("5")
    assert results is True
    assert l.start == 1
    assert l.end == 5
    assert l.stride == 1

    l = LookupModule()
    l.reset()
    results = l.parse_simple_args("4:host%02d")
    assert results is True

    l = LookupModule()
    l

# Generated at 2022-06-23 12:01:40.759164
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # initialize LookupModule class
    lookup = LookupModule()

    # parse valid arguments and check if all of them were parsed
    args = dict(start='1', end='11', stride='2', format='0x%02x')
    lookup.parse_kv_args(args)
    for arg in ["start", "end", "stride", "format"]:
        try:
            assert(getattr(lookup, arg) == int(args[arg], 0))
            del args[arg]
        except ValueError:
            assert(getattr(lookup, arg) == args[arg])
            del args[arg]
    assert not args

    # parse valid arguments and check if all of them were parsed
    args = dict(start='1', count='11', stride='2', format='0x%02x')
    lookup.parse

# Generated at 2022-06-23 12:01:51.218505
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """Fix to bug in LookupModule.parse_simple_args

    For example, this command:

      ansible-playbook -i localhost, -e 'end_at=10' test_sequence.yml

    should generate the sequence:

      ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']

    but instead gave:

      ['1', '10']

    The problem was in the LookupModule.parse_simple_args method, which
    returned True or False, indicating whether the input string could be
    parsed as a short form.  In fact, this method was modifying self.{start,
    end, stride}, so it should return None.
    """
    # The following construction does not call reset()

# Generated at 2022-06-23 12:02:01.190763
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_plugin = LookupModule()
    assert lookup_plugin.parse_simple_args('1') == False
    assert lookup_plugin.parse_simple_args('5-8') == True
    assert lookup_plugin.parse_simple_args('0-10/2') == True
    assert lookup_plugin.parse_simple_args('5:host%02d') == True
    assert lookup_plugin.parse_simple_args('5-8:host%04d') == True
    assert lookup_plugin.parse_simple_args('5-8/2:host%04d') == True
    assert lookup_plugin.parse_simple_args('0x00-0x10/2:host%04d') == True

# Generated at 2022-06-23 12:02:12.624984
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test individual functions
    def test_func(func, expected_result, actual_result):
        """Test function"""
        if expected_result == actual_result:
            print("PASS - %s" % (func))
        else:
            print("FAIL - %s" % (func))
            print("EXPECTED RESULT:")
            print(expected_result)
            print("ACTUAL RESULT:")
            print(actual_result)

    def test_reset(lookup_plugin):
        """Test reset()"""
        test_func("reset()", "PASS", "PASS")

# Generated at 2022-06-23 12:02:18.200063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_sequence = LookupModule
    my_terms = ['4:host%02d']
    my_variables = {}
    new_run = my_sequence.run(my_sequence, my_terms, my_variables )
    print(new_run)
    assert new_run == ['host01', 'host02', 'host03', 'host04']

# Generated at 2022-06-23 12:02:23.416886
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    """
    Test some input
    """
    def int2str(x):
        return '%d' % x

    lookup = LookupModule()
    lookup.format = '%d'
    lookup.start = 5
    lookup.end = 7
    lookup.stride = 1
    assert(list(int2str(x) for x in range(5, 8, 1)) == list(lookup.generate_sequence()))

# Generated at 2022-06-23 12:02:34.913839
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    start_arg = [
        '0',
        '0',
        '1',
        '0x0',
        '0X0'
    ]
    end_arg = [
        '5',
        '0x05',
        '0X05',
        '3',
        '0x3'
    ]
    stride_arg = [
        '1',
        '1',
        '-1',
        '0x1',
        '0x01'
    ]
    format_arg = [
        '"%d"',
        '"%d"',
        '"%d"',
        '"%d"',
        '"%d"'
    ]

# Generated at 2022-06-23 12:02:41.698754
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    obj = LookupModule()
    obj.start = 99
    obj.stride = 99
    obj.count = 99
    obj.end = 99
    obj.format = "test99"
    obj.reset()
    result = dict(
        start=obj.start,
        stride=obj.stride,
        count=obj.count,
        end=obj.end,
        format=obj.format)
    expected = dict(
        start=1,
        stride=1,
        count=None,
        end=None,
        format='%d')
    assert result == expected


# Generated at 2022-06-23 12:02:47.787844
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    """
    Unit test for method generate_sequence of class LookupModule
    """
    test_seq = LookupModule()
    test_seq.start = 1
    test_seq.count = None
    test_seq.end = 5
    test_seq.stride = 1
    test_seq.format = "%d"

    test_seq.sanity_check()
    assert test_seq.generate_sequence() == ['1', '2', '3', '4', '5']

    test_seq.stride = 2
    test_seq.end = 9
    test_seq.sanity_check()
    assert test_seq.generate_sequence() == ['1', '3', '5', '7', '9']

    test_seq.start = 9
    test_seq.end = 0
    test_seq.san

# Generated at 2022-06-23 12:02:56.127079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test run method of LookupModule
    lookup = LookupModule()

    # Test with invalid term
    term = "start=1 end=5 stride="
    result = lookup.run(term, None)
    assert result == ['1', '2', '3', '4', '5']

    # Test with non-integer values
    terms = ['start=1 end=5 stride=3', 'start=1 end=5 stride=6', 'start=1 end=5 stride=-1']
    for term in terms:
        result = lookup.run(term, None)
        assert result == ['1', '2', '3', '4', '5']

    # Test with negative stride
    term = 'start=1 end=5 stride=-1'
    result = lookup.run(term, None)

# Generated at 2022-06-23 12:03:05.772608
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Tests for sanity_check raise exceptions when illegal values are provided
    from ansible.plugins.lookup import LookupModule

    module = LookupModule()
    module.reset()
    module.start = 1
    module.stride = 1

    # Case 1 - Bad Stride Value - Stride can't be zero
    module.stride = 0
    module.count = None
    module.end = None
    try:
        module.sanity_check()
        assert False, "Illegal Stride not caught"
    except AnsibleError:
        pass
    module.stride = 1

    # Case 2 - Bad Stride Value - Stride can't be negative for count != None
    module.stride = -1
    module.count = 4
    module.end = None

# Generated at 2022-06-23 12:03:16.745727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  module = LookupModule()

  terms = []
  variables = {}
  kwargs = {}
  results = []

  assert module.run(terms, variables, **kwargs) == results

  terms = ['5-8']
  variables = {}
  kwargs = {}
  results = ['5', '6', '7', '8']

  assert module.run(terms, variables, **kwargs) == results

  terms = ['5']
  variables = {}
  kwargs = {}
  results = ['1', '2', '3', '4', '5']

  assert module.run(terms, variables, **kwargs) == results

  terms = ['2-10/2']
  variables = {}
  kwargs = {}
  results = ['2', '4', '6', '8', '10']

 

# Generated at 2022-06-23 12:03:26.703113
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    import random
    lookup_plugin = LookupModule()

    # Generate a sequence of random length between 5 and 10,
    # with the start and end values being random numbers between 0 and 10,
    # stride being random numbers between 1 and 9
    # and format being a random string
    length = random.randint(5, 10)
    start = random.randint(0, 10)
    end = random.randint(0, 10)
    stride = random.randint(1, 9)
    format = ''.join(random.choice('0123456789ABCDEF') for i in range(random.randint(1, 10)))

    # Use the start, end and stride values to generate the expected sequence
    expected = []
    value = start
    for i in range(length):
        expected.append(format % value)
        value

# Generated at 2022-06-23 12:03:36.031586
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    for test in [{
        'start' : 1,
        'end' : 1
    },{
        'start' : 1,
        'end' : 1,
        'stride': 1
    },{
        'start' : 1,
        'end' : 1,
        'stride': 1,
        'format' : '%s'
    },{
        'start' : None,
        'end' : None,
        'stride': None,
        'format' : None
    }]:
        l = LookupModule()
        l.start = test.get('start', 1)
        l.end = test.get('end', 1)
        l.stride = test.get('stride', 1)
        l.format = test.get('format', 1)
        l.reset()
       

# Generated at 2022-06-23 12:03:41.624683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:03:44.613584
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

   lookup_module = LookupModule()
   lookup_module.start = 1
   lookup_module.end = 11
   lookup_module.stride = 2

# Generated at 2022-06-23 12:03:49.733043
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup_module = LookupModule()
    lookup_module.reset()

    assert lookup_module.start == 1
    assert lookup_module.end == None
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"


# Generated at 2022-06-23 12:03:52.769386
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    assert lookup.start == 1
    assert lookup.count is None
    assert lookup.end is None
    assert lookup.stride == 1
    assert lookup.format == '%d'



# Generated at 2022-06-23 12:04:04.242113
# Unit test for method parse_kv_args of class LookupModule

# Generated at 2022-06-23 12:04:13.804161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for LookupModule class
    """
    with pytest.raises(AnsibleError) as exec_info:
        LookupModule().run(["end=10"], {})
    assert "must specify count or end in with_sequence" in str(exec_info.value)

    with pytest.raises(AnsibleError) as exec_info:
        LookupModule().run(["end=-1"], {})
    assert "can't parse end=-1 as integer" in str(exec_info.value)

    with pytest.raises(AnsibleError) as exec_info:
        LookupModule().run(["end=1 count=4"], {})
    assert "can't specify both count and end in with_sequence" in str(exec_info.value)


# Generated at 2022-06-23 12:04:18.837364
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.parse_kv_args({'start':'1','end':'5','format':'%d'})

    assert lookup_module.start == 1
    assert lookup_module.end == 5
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'


# Generated at 2022-06-23 12:04:27.752141
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    lookup.reset()

    if lookup.start != 1:
        raise Exception
    if lookup.count != None:
        raise Exception
    if lookup.end != None:
        raise Exception
    if lookup.stride != 1:
        raise Exception
    if lookup.format != "%d":
        raise Exception

    lookup.parse_kv_args({'start': '1', 'end': '3', 'format': '%03d'})
    if lookup.start != 1:
        raise Exception
    if lookup.count != None:
        raise Exception
    if lookup.end != 3:
        raise Exception
    if lookup.stride != 1:
        raise Exception
    if lookup.format != "%03d":
        raise Exception

    lookup.reset()

# Generated at 2022-06-23 12:04:38.365775
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    assert LookupModule.parse_simple_args(LookupModule, '5') == True
    assert LookupModule.parse_simple_args(LookupModule, '5-8') == True
    assert LookupModule.parse_simple_args(LookupModule, '2-10/2') == True
    assert LookupModule.parse_simple_args(LookupModule, '4:host%02d') == True
    assert LookupModule.parse_simple_args(LookupModule, '5-8:host%02d') == True
    assert LookupModule.parse_simple_args(LookupModule, '2-10/2:host%02d') == True
    assert LookupModule.parse_simple_args(LookupModule, '5-8/2') == True


# Generated at 2022-06-23 12:04:49.585291
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
  lookup_mod = LookupModule()
  lookup_mod.end = 1
  lookup_mod.count = None
  lookup_mod.start = 1
  lookup_mod.stride = 1

  # testing valid format
  lookup_mod.sanity_check()

  # testing error of both count and end
  lookup_mod.count = 1
  pass_flag = False
  try:
    lookup_mod.sanity_check()
  except AnsibleError:
    pass_flag = True
  assert pass_flag == True

  # testing error of no count or end
  lookup_mod.count = None
  pass_flag = False
  try:
    lookup_mod.sanity_check()
  except AnsibleError:
    pass_flag = True
  assert pass_flag == True

  # testing error of stride = 0


# Generated at 2022-06-23 12:04:58.312550
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    module = LookupModule()
    assert not module.parse_simple_args("")
    assert not module.parse_simple_args("-")

# Generated at 2022-06-23 12:05:08.964858
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.start = 1
    lookup.end = 3
    lookup.stride = 2
    lookup.format = "test%02d"

    seq = lookup.generate_sequence()
    assert seq.next() == "test01"
    assert seq.next() == "test03"
    try:
        seq.next()
        assert False
    except StopIteration:
        pass

    lookup.start = 4
    lookup.end = 2
    lookup.stride = -1
    lookup.format = "test%02d"

    seq = lookup.generate_sequence()
    assert seq.next() == "test04"
    assert seq.next() == "test03"
    assert seq.next() == "test02"

# Generated at 2022-06-23 12:05:21.502809
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    l = LookupModule()

    l.start = 0
    l.stride = 1
    l.end = 4

    assert list(l.generate_sequence()) == ['0', '1', '2', '3', '4']

    l.start = 0
    l.stride = 2
    l.end = 6

    assert list(l.generate_sequence()) == ['0', '2', '4', '6']

    l.start = 0
    l.stride = -2
    l.end = -6

    assert list(l.generate_sequence()) == ['0', '-2', '-4', '-6']

    l.start = 1
    l.stride = 2
    l.end = 5


# Generated at 2022-06-23 12:05:29.003685
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    l = LookupModule()
    l.start = 0
    l.end = 3
    l.stride = 2
    l.format = "xyz"

    assert l.start != 1
    assert l.end != 4
    assert l.stride != 3
    assert l.format == "xyz"

    l.reset()
    assert l.start == 1
    assert l.end == 4
    assert l.stride == 3
    assert l.format == "%d"


# Generated at 2022-06-23 12:05:35.991243
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    class Test(object):
        def __init__(self, start, end, count, stride, format):
            self.start = start
            self.end = end
            self.count = count
            self.stride = stride
            self.format = format

    test_obj = Test(start=1, end=10, count=2, stride=2, format="%d")
    test_obj.reset()
    assert test_obj.start == 1
    assert test_obj.end is None
    assert test_obj.count is None
    assert test_obj.stride == 1
    assert test_obj.format == "%d"


# Generated at 2022-06-23 12:05:43.346395
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # test sanity_check of class LookupModule
    my_module = LookupModule()
    # test case 1:
    try:
        my_module.count = 10
        my_module.end = 3
        my_module.start = 1
        my_module.stride = 1
        my_module.sanity_check()
    except AnsibleError as e:
        assert str(e) == "can't specify both count and end in with_sequence"

    # test case 2:
    try:
        my_module.count = None
        my_module.end = 3
        my_module.start = 1
        my_module.stride = 1
        my_module.sanity_check()
    except AnsibleError as e:
        assert str(e) == "must specify count or end in with_sequence"

   

# Generated at 2022-06-23 12:05:52.559823
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookupModule = LookupModule()
    lookupModule.reset()

    term = '5'
    assert(lookupModule.parse_simple_args(term) == True)
    assert(lookupModule.start == 5)
    assert(lookupModule.count is None)
    assert(lookupModule.end == 5)
    assert(lookupModule.stride == 1)
    assert(lookupModule.format == "%d")

    term = '5-'
    assert(lookupModule.parse_simple_args(term) == False)

    term = '-8'
    assert(lookupModule.parse_simple_args(term) == True)
    assert(lookupModule.start == -8)
    assert(lookupModule.count is None)
    assert(lookupModule.end == -8)

# Generated at 2022-06-23 12:06:01.634198
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    '''
    Test the parse_kv_args method using the 'redux' example from
    LookupModule.__doc__
    '''

    lm = LookupModule()
    lm.parse_kv_args({
        'start': '5', 'end': '11',
        'stride': '2', 'format': '0x%02x'
    })

    assert lm.start == 5
    assert lm.end == 11
    assert lm.stride == 2
    assert lm.format == '0x%02x'


# Generated at 2022-06-23 12:06:03.800309
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.stride == 1
    assert lookup.format == "%d"


# Generated at 2022-06-23 12:06:15.099441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([], [], []) == []
    assert module.run(['5', '5-8', '2-10/2', '4:host%02d'], [], []) == [
        "1", "2", "3", "4", "5", "5", "6", "7", "8", "2", "4", "6", "8", "10",
        "host01", "host02", "host03", "host04",
    ]

# Generated at 2022-06-23 12:06:19.878708
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lookup = LookupModule()
    lookup.start = 1
    lookup.count = 1
    lookup.end = 1
    lookup.stride = 1
    lookup.format = '%2d'
    lookup.reset()

    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == '%d'


# Generated at 2022-06-23 12:06:27.791283
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    myLookupModule = LookupModule()
    myLookupModule.start = 8
    myLookupModule.count = None
    myLookupModule.end = None
    myLookupModule.stride = 1
    myLookupModule.format = "%d"
    myLookupModule.reset()
    assert myLookupModule.start == 1
    assert myLookupModule.count == None
    assert myLookupModule.end == None
    assert myLookupModule.stride == 1
    assert myLookupModule.format == "%d"


# Generated at 2022-06-23 12:06:39.667758
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def reset_test(self):
        """test reset()"""
        assert self.start == 1
        assert self.count == None
        assert self.end == None
        assert self.stride == 1
        assert self.format == "%d"

    def parse_simple_args_test(self, term, expected_return_value, expected_start=1, expected_end=None, expected_stride=1, expected_format="%d"):
        """test parse_simple_args()"""
        assert parse_simple_args_test == expected_return_value
        assert self.start == expected_start
        assert self.end == expected_end
        assert self.stride == expected_stride
        assert self.format == expected_format


# Generated at 2022-06-23 12:06:43.831984
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    obj = LookupModule()
    temp_dict = dict(start='5', end='8', stride='2', format='0x%02x')
    obj.parse_kv_args(temp_dict)

    assert(obj.start == 5)
    assert(obj.end == 8)
    assert(obj.stride == 2)
    assert(obj.format == '0x%02x')



# Generated at 2022-06-23 12:06:51.745080
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    # prepare test data
    start = 8
    end = 12
    stride = 1
    format = "%d"
    expected_result = ['8','9','10','11','12']

    # initialize object and set the test value
    lookup = LookupModule()
    lookup.reset()
    lookup.start = start
    lookup.end = end
    lookup.stride = stride
    lookup.format = format
    result = list(lookup.generate_sequence())

    assert result == expected_result

# Generated at 2022-06-23 12:07:00.838900
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    # Initialize the LookupModule object
    lm = LookupModule()

    # Reset the LookupModule object
    lm.reset()

    # Test the parse_kv_args method
    # a) Testing the generate_sequence method for generating the sequence
    # values from the passed key-value arguments - start=1, end=10, stride=1, format=%d
    lm.parse_kv_args(parse_kv("start=1 end=10 format=%d"))
    lm.sanity_check()
    assert lm.generate_sequence() == ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    lm.reset()

    # b) Testing the generate_sequence method for generating the sequence
    # values from the passed key

# Generated at 2022-06-23 12:07:07.679343
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    start = 1
    end = None
    stride = 1
    format = "%d"
    lookup = LookupModule()
    lookup.start = start
    lookup.end = end
    lookup.stride = stride
    lookup.format = format
    try:
        lookup.sanity_check()
    except AnsibleError as e:
        assert "must specify count or end in with_sequence" in str(e)
    else:
        assert False, "AnsibleError exception not raised"


# Generated at 2022-06-23 12:07:19.047495
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    import unittest2 as unittest
    from nose.plugins.skip import SkipTest

    class TestSanityCheck(unittest.TestCase):
        def test_success_positive_stride(self):
            test_object = LookupModule()
            test_object.start = 0
            test_object.end = 10
            test_object.stride = 1
            self.assertIsNone(test_object.sanity_check())

        def test_success_negative_stride(self):
            test_object = LookupModule()
            test_object.start = 10
            test_object.end = 0
            test_object.stride = -1
            self.assertIsNone(test_object.sanity_check())

        def test_failure_end_before_start(self):
            test_object = Lookup

# Generated at 2022-06-23 12:07:28.038741
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    lu = LookupModule()

    lu.start = 1
    lu.count = None
    lu.end = None
    lu.stride = 1
    lu.format = '%d'

    # count < 0
    lu.start = 1
    lu.count = -1
    lu.end = None
    lu.stride = 1

    assert(lu.sanity_check() == None)

    # count = 0, end = 0
    lu.start = 0
    lu.count = 0
    lu.end = 0
    lu.stride = 0

    assert(lu.sanity_check() == None)

    # count > 1
    lu.start = 1
    lu.count = 2
    lu.end = None
    lu.str

# Generated at 2022-06-23 12:07:40.508041
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """Check the method parse_simple_args for correct argument parsing"""
    assert LookupModule.parse_simple_args('5') == (True, (1, 5, 1, "%d",))
    assert LookupModule.parse_simple_args('5-8') == (True, (5, 8, 1, "%d",))
    assert LookupModule.parse_simple_args('2-10/2') == (True, (2, 10, 2, "%d",))
    assert LookupModule.parse_simple_args('4:host%02d') == (True, (1, 4, 1, "host%02d",))
    assert LookupModule.parse_simple_args('2-10') == (True, (2, 10, 1, "%d",))

# Generated at 2022-06-23 12:07:48.993833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global LookupModule
    lm = LookupModule()
    #
    # Test standard key-value form
    #
    terms = [dict(start=4, format="test%02d")]
    results = lm.run(terms, {})
    assert results == ["test04", "test05", "test06", "test07"]
    #
    # Test short form
    #
    results = lm.run(["2-10/2"], {})
    assert results == ["2", "4", "6", "8", "10"]
    #
    # Test with count
    #
    results = lm.run(["start=20 count=10 format=test%02d"], {})

# Generated at 2022-06-23 12:07:59.211415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    # Setup arguments with_sequence
    args = [
        # with_sequence [start-]end[/stride][:format]
        "10-50/5:test_%02d",
        "count=5 format=test_format_%02d",
        "count=5",
        "6-19/2:entry_%02d",
        "start=16 end=2 stride=-2 format=file_%03d",
    ]
    variables = {
        "end_at": 8,
    }

    arg = "start=1 end={{ end_at }}"
    args.append(arg)

    # Setup environment for LookupModule
    lookup_plugin_paths = os.path.join(os.path.dirname(__file__), '..')

# Generated at 2022-06-23 12:08:06.527609
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    import unittest

    class LookupModuleTest(LookupBase):
        def reset(self):
            self.start = 1
            self.count = None
            self.end = None
            self.stride = 1
            self.format = "%d"


# Generated at 2022-06-23 12:08:14.283661
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup = LookupModule()
    assert not lookup.parse_simple_args('start=5 end=8')

    lookup = LookupModule()
    assert not lookup.parse_simple_args('start=0x')

    lookup = LookupModule()
    assert not lookup.parse_simple_args('start=5 end=0x')

    lookup = LookupModule()
    assert not lookup.parse_simple_args('start=5 end=8 stride=3 format=%d')

    lookup = LookupModule()
    assert not lookup.parse_simple_args('start=5 end=8 stride=3 format=%d')

    lookup = LookupModule()
    assert not lookup.parse_simple_args('start=5 end=8 stride=')

    lookup = LookupModule()

# Generated at 2022-06-23 12:08:20.058763
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    class Obj(object):
        pass
    c = Obj()
    c.LookupModule = LookupModule()
    c.LookupModule.reset()
    assert (c.LookupModule.start == 1)
    assert (c.LookupModule.count == None)
    assert (c.LookupModule.end == None)
    assert (c.LookupModule.stride == 1)
    assert (c.LookupModule.format == "%d")


# Generated at 2022-06-23 12:08:32.673498
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup = LookupModule()
    lookup.reset()

# Generated at 2022-06-23 12:08:39.366803
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    """
    Unit test for method generate_sequence of class LookupModule
    """

    result = []
    lookup_module_obj = LookupModule()
    lookup_module_obj.start = 4
    lookup_module_obj.end = 16
    lookup_module_obj.stride = 2
    lookup_module_obj.format = "%04d"

    for i in lookup_module_obj.generate_sequence():
        result.append(i)

    assert result == ['0004', '0006', '0008', '0010', '0012', '0014', '0016']

# Generated at 2022-06-23 12:08:46.451483
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    a = LookupModule()
    a.start = 4
    a.end = 16
    a.stride = 2
    a.format = "%d"
    result = a.generate_sequence()
    assert result == ['4', '6', '8', '10', '12', '14', '16']

    a.stride = -2
    result = a.generate_sequence()
    assert result == ['16', '14', '12', '10', '8', '6', '4']
    a.stride = 0
    result = a.generate_sequence()
    assert result == []

# Generated at 2022-06-23 12:08:50.753870
# Unit test for method reset of class LookupModule
def test_LookupModule_reset():
    lmr = LookupModule()
    lmr.reset()
    assert lmr.start == 1
    assert lmr.end is None
    assert lmr.count is None
    assert lmr.stride == 1
    assert lmr.format == "%d"


# Generated at 2022-06-23 12:09:01.995355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize LookupModule
    lookup_module = LookupModule()
    # test the following cases:
    # 1. with_sequence and with_sequence_shortcut
    # 2. with_sequence_shortcut_negative
    # 3. with_sequence_count_error
    # 4. with_sequence_count_error2
    # 5. with_sequence_count
    # 6. with_sequence_shortcut_count_error
    # 7. with_sequence_startcount_end
    # 8. with_sequence_startcount_end_negative
    # 9. with_sequence_shortcut_count
    # 10. with_sequence_shortcut_count_negative
    # 11. with_sequence_format
    # 12. with_sequence_shortcut_format
    # 13. with_sequence_stride
    # 14. with

# Generated at 2022-06-23 12:09:14.173170
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """
    Run test for function parse_simple_args
    """
    # create an instance of class LookupModule
    sequence = LookupModule()

    # run test for term 5-8
    term = "5-8"
    expected_result = True
    actual_result = sequence.parse_simple_args(term)
    assert expected_result == actual_result

    # run test for term 4:host%02d
    term = "4:host%02d"
    expected_result = True
    actual_result = sequence.parse_simple_args(term)
    assert expected_result == actual_result

    # run test for term 4-10/2
    term = "4-10/2"
    expected_result = True
    actual_result = sequence.parse_simple_args(term)
    assert expected_result == actual

# Generated at 2022-06-23 12:09:21.040410
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    l = LookupModule()
    l.reset()
    l.parse_kv_args(parse_kv("start=0x0f00 count=4 format=%04x"))

    assert l.start == 3840
    assert l.end is None
    assert l.count == 4
    assert l.stride == 1
    assert l.format == "%04x"
    assert l.generate_sequence() == ['0f00', '0f01', '0f02', '0f03']

    l.reset()
    l.parse_kv_args(parse_kv("start=0 count=5 stride=2"))
    assert l.start == 0
    assert l.end == 8
    assert l.count is None
    assert l.stride == 2
    assert l.format == "%d"

# Generated at 2022-06-23 12:09:29.999907
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Simple use
    lookup_plugin = LookupModule()
    lookup_plugin.start = 1
    lookup_plugin.end = 10
    lookup_plugin.stride = 1
    lookup_plugin.format = "%d"
    assert list(map(int, lookup_plugin.generate_sequence())) == list(range(1, 10+1))

    # With a stride
    lookup_plugin.start = 0
    lookup_plugin.end = 8
    lookup_plugin.stride = 2
    lookup_plugin.format = "%02d"
    assert list(map(int, lookup_plugin.generate_sequence())) == list(range(0, 8+1, 2))

    # With a stride in the other direction
    lookup_plugin.start = 8
    lookup_plugin.end = 0

# Generated at 2022-06-23 12:09:34.112962
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    sequence = LookupModule().generate_sequence(2, 10, 2)
    assert len(sequence) == 5
    assert list(sequence) == ["2", "4", "6", "8", "10"]



# Generated at 2022-06-23 12:09:37.530544
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup = LookupModule()
    lookup.format = "%d"
    lookup.start = 1
    lookup.end = 5
    lookup.stride = 2
    assert list(lookup.generate_sequence()) == ["1", "3", "5"]

# Generated at 2022-06-23 12:09:46.300783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import StringIO
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six.moves import xrange
    # Test with_sequence to generate a list as output
    LookupBase.global_vars = {}
    test_subject = LookupModule()
    assert test_subject.run(terms=[':%02x'], variables=None, **{}) == []
    assert test_subject.run(terms=['1-5'], variables=None, **{}) == ['1', '2', '3', '4', '5']
    assert test_subject.run(terms=['1-5/2'], variables=None, **{}) == ['1', '3', '5']

# Generated at 2022-06-23 12:09:53.796330
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Example not in documentation
    term = "10-15"
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args(term)

    # Example not in documentation
    term = "3-7/2"
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args(term)

    # Example not in documentation
    term = "1-16/2:host%02d"
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args(term)
