

# Generated at 2022-06-25 11:06:45.360695
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    term_0 = '3'
    term_1 = '3/2'
    term_2 = '3:test_%d'
    term_3 = '3-6'
    term_4 = '3-6/2'
    term_5 = '3-6:test_%d'
    term_6 = '3-6/2:test_%d'
    term_7 = '3/2:test_%d'

    lookup_module_0.parse_simple_args(term_0)
    lookup_module_1.parse_simple_args(term_1)
    lookup_module_2.parse_simple_args(term_2)
   

# Generated at 2022-06-25 11:06:51.952534
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = -1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:06:57.998901
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    try:
        test_LookupModule_parse_simple_args_term = '10-12'
        lookup_module_1 = LookupModule()
        lookup_module_1.parse_simple_args(test_LookupModule_parse_simple_args_term)

        test_stride = lookup_module_1.stride
        assert test_stride == 1
        test_end = lookup_module_1.end
        assert test_end == 12
        test_start = lookup_module_1.start
        assert test_start == 10
        test_format = lookup_module_1.format
        assert test_format == '%d'

    except Exception as e:
        print("\nException: ", e)



# Generated at 2022-06-25 11:07:07.263931
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # From test data
    term = "start=5 end=11 stride=2 format=0x%02x"
    ret = lookup_module_0.parse_simple_args(term)
    assert ret == False

    # From test data
    term = "5"
    ret = lookup_module_0.parse_simple_args(term)
    assert ret == True
    assert lookup_module_0.end == 5

    # From test data
    term = "start=0x0f00 count=4 format=%04x"
    ret = lookup_module_0.parse_simple_args(term)
    assert ret == False

    # From test data
    term = "5-8"
    ret = lookup_module_0.parse_simple_args(term)

# Generated at 2022-06-25 11:07:08.669068
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 11:07:19.130616
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.end = 5
    lookup_module_0.start = 3
    lookup_module_0.stride = 1
    lookup_module_0.count = 6
    lookup_module_0.sanity_check()
    if lookup_module_0.end == 9:
        lookup_module_0.end = 5
    if lookup_module_0.end != 5:
        print(lookup_module_0.end)
        raise Exception('Failed')
    if lookup_module_0.start != 3:
        print(lookup_module_0.start)
        raise Exception('Failed')
    if lookup_module_0.stride != 1:
        print(lookup_module_0.stride)
        raise Exception('Failed')
   

# Generated at 2022-06-25 11:07:21.881977
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:07:26.682111
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    str_1 = "5"
    var_0 = lookup_module_0.parse_simple_args(str_1)
    assert var_0
    assert lookup_module_0.end == 5


# Generated at 2022-06-25 11:07:33.133001
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookupmodule_0 = LookupModule()
    try:
        lookupmodule_0.sanity_check()
    except AnsibleError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 11:07:38.754614
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    lookup = LookupModule()
    lookup.reset()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_simple_args('42-43')
    assert lookup.start == 42
    assert lookup.count == None
    assert lookup.end == 43
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()
    lookup.parse_simple_args('5')
    assert lookup.start == 1
    assert lookup.count == 5
    assert lookup.end == None
    assert lookup.stride == 1
    assert lookup.format == "%d"

    lookup.reset()

# Generated at 2022-06-25 11:07:54.012188
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()

    with pytest.raises(AnsibleError):
        lookup_module_0.parse_kv_args({"start" : "s", "end" : "e", "count" : "c", "stride" : "S"})
    with pytest.raises(AnsibleError):
        lookup_module_0.parse_kv_args({})
    with pytest.raises(AnsibleError):
        lookup_module_0.parse_kv_args({"start" : "0", "count" : "5", "format" : "x"})

# Generated at 2022-06-25 11:07:59.449808
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    term_0 = lookup_module_0.reset()
    setattr(lookup_module_0, "count", 7)
    term_0 = lookup_module_0.sanity_check()
    setattr(lookup_module_0, "count", None)
    setattr(lookup_module_0, "end", 0)
    setattr(lookup_module_0, "stride", 0)
    term_1 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:04.440753
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    arg_raw_0 = '0x0'
    str_0 = 0x0
    arg_cooked_0 = int(arg_raw_0, 0)
    lookup_module_0.start = arg_cooked_0
    str_1 = 1
    arg_cooked_1 = int(str_1, 0)
    lookup_module_0.end = arg_cooked_1
    str_2 = -1
    arg_cooked_2 = int(str_2, 0)
    lookup_module_0.stride = arg_cooked_2
    lookup_module_0.format = '%d'


# Generated at 2022-06-25 11:08:06.416499
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.parse_kv_args(var_0)
    assert True


# Generated at 2022-06-25 11:08:08.680935
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    assert True

# Generated at 2022-06-25 11:08:09.614727
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    var_1 = lookup_sanity_check()



# Generated at 2022-06-25 11:08:20.282636
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_1 = LookupModule()
    lookup_module_1.reset()
    assert (lookup_module_1.start == 1)
    assert (lookup_module_1.count is None)
    assert (lookup_module_1.end is None)
    assert (lookup_module_1.stride == 1)
    assert (lookup_module_1.format == '%d')
    # Assignment: args

    args = { 'format' : '%d', 'end' : 1, 'start' : 1, 'count' : 1, 'stride' : 1 }

    lookup_module_1.parse_kv_args(args)
    assert (lookup_module_1.start == 1)
    assert (lookup_module_1.count == 1)

# Generated at 2022-06-25 11:08:25.621693
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    var_0 = parse_kv(var_1)
    lookup_module_0.parse_kv_args(var_0)


# Generated at 2022-06-25 11:08:30.289899
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    var_1 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:08:32.173610
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()
    assert isinstance(var_0, GeneratorType)


# Generated at 2022-06-25 11:08:41.464769
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # arguments passed
    #: Initialize a class plugin of type LookupModule
    lookup_module_0 = LookupModule()

    # absolute path
    lookup_module_0.run([""], {"ansible_check_mode": False}, )
    #: Initialize a class plugin of type LookupModule
    lookup_module_0 = LookupModule()

    # absolute path
    lookup_module_0.run([""], {"ansible_check_mode": True}, )

# Generated at 2022-06-25 11:08:45.796886
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.do_sanity_check()


# Generated at 2022-06-25 11:08:51.064114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["term_0"])
    assert var_0 == [], var_0
    var_0 = lookup_module_0.run([])
    assert var_0 == [], var_0
    var_0 = lookup_module_0.run(["term_0", "term_1"])
    assert var_0 == [], var_0


# Generated at 2022-06-25 11:08:55.457732
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:08:57.636054
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:09:00.997437
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 1
    lookup_module_0.start = (-1)
    lookup_module_0.end = (-1)
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as err:
        print(str(err))
    else:
        raise AssertionError("AnsibleError expected")


# Generated at 2022-06-25 11:09:02.534180
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    # Unknown: 


# Generated at 2022-06-25 11:09:10.506610
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()  # clear out things for this iteration
    try:
        if not lookup_module_0.parse_simple_args(""):
            lookup_module_0.parse_kv_args(parse_kv(""))
    except AnsibleError:
        raise
    except Exception as e:
        raise AnsibleError("unknown error parsing with_sequence arguments: %r. Error was: %s" % ("", e))

    lookup_module_0.sanity_check()
    if lookup_module_0.stride != 0:
        lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:09:11.937164
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:09:16.004535
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.sanity_check()


# Generated at 2022-06-25 11:09:38.254320
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args('5-0/2:0x%02x')
    # Test if var_0 is equal to True
    assert var_0 == True


# Generated at 2022-06-25 11:09:41.984518
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = "start=0x0f00 count=4 format=%04x"
    var_2 = lookup_module_0.parse_simple_args(var_1)
    assert len(getattr(lookup_module_0, 'start')) == 1



# Generated at 2022-06-25 11:09:47.079731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([], dict())
    var_1 = lookup_module_0.run([""], dict())

# Generated at 2022-06-25 11:09:50.122390
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    print("\n!! LookupModule_parse_simple_args")
    self_0 = LookupModule()
    term_0 = "5-8"
    lookup_module_0 = LookupModule(self_0)
    match_0 = lookup_module_0.parse_simple_args(term_0)
    print(match_0)
    print()


# Generated at 2022-06-25 11:09:57.207892
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = '%d'

    try:
        lookup_module_1.sanity_check()
    except AssertionError as e:
        raise AssertionError(str(e))


# Generated at 2022-06-25 11:10:02.308858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Create a list to hold return value
    ret_list = list()
    # Generate a sequence of terms
    terms_1 = ["0", "1-2", "3-4/2", "5-6/3", "10-12:host%02d"]
    # Call function run
    lookup_module_0.run(terms_1)

# Generated at 2022-06-25 11:10:10.464880
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = ""
    match_0 = lookup_SHORTCUT.match(term_0)
    if not match_0:
        return False
    _, start, end, _, stride, _, format = match_0.groups()
    if start is not None:
        try:
            start = int(start, 0)
        except ValueError:
            raise AnsibleError("can't parse start=%s as integer" % start)
    if end is not None:
        try:
            end = int(end, 0)
        except ValueError:
            raise AnsibleError("can't parse end=%s as integer" % end)
    if stride is not None:
        try:
            stride = int(stride, 0)
        except ValueError:
            raise

# Generated at 2022-06-25 11:10:11.824454
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args(str_0)
    assert False



# Generated at 2022-06-25 11:10:13.516477
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    assert "0x100" in lookup_module_0.parse_simple_args("0x100")

# Generated at 2022-06-25 11:10:15.094789
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()


# Generated at 2022-06-25 11:10:29.359401
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_3 = LookupModule()
    var_3 = lookup_module_3.reset()
    var_4 = lookup_module_3.end
    var_5 = lookup_module_3.count


# Generated at 2022-06-25 11:10:32.394774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(term, variable, **kwargs)
    assert var_0 == result

# Generated at 2022-06-25 11:10:42.173875
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0 = var_0 = lookup_reset()
    def test_case(self, var_0):
        self.start = 0
        self.count = None
        self.end = 5
        self.stride = 1
        self.format = "%d"
        lookup_sanity_check = lookup_module_0.sanity_check(self)
        var_1 = self.start
        var_2 = self.end + 1
        var_3 = self.stride
        var_4 = xrange(var_1, var_2, var_3)
        for i in var_4:
            try:
                formatted = self.format % i
                var_5 = results.append(formatted)
            except (ValueError, TypeError):
                raise

# Generated at 2022-06-25 11:10:44.674316
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule(0)
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:10:49.411179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_1 = None
    variables_1 = None
    lookup_module_1 = LookupModule()
    cache_1 = None
    term_1 = None
    variables_1 = None
    cache_1 = None

    # Call method run of LookupModule
    result_1 = lookup_module_1.run(term_1, variables_1, cache_1)


# Generated at 2022-06-25 11:10:50.589911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run()


# Generated at 2022-06-25 11:10:59.383882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    simple_lookup = LookupModule()
    arguments_0 = {}
    arguments_0["format"] = "%02d"
    arguments_0["stride"] = 2
    arguments_0["end"] = 8
    arguments_0["start"] = 4
    assert simple_lookup.run(arguments_0, 1, 2, 3) == [0]
    arguments_1 = {}
    arguments_1["format"] = "host%04d"
    arguments_1["stride"] = 1
    arguments_1["end"] = 5
    arguments_1["start"] = 1
    assert simple_lookup.run(arguments_1, 1, 2, 3) == [0]
    arguments_2 = {}
    arguments_2["count"] = 5
    arguments_2["format"] = "%02d"
    arguments_2

# Generated at 2022-06-25 11:11:08.022852
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = "5-8"
    var_2 = lookup_module_0.run(var_1, var_0)
    var_3 = ["5", "6", "7", "8"]
    assert var_2 == var_3
    var_4 = "2-10/2"
    var_5 = lookup_module_0.run(var_4, var_0)
    var_6 = ["2", "4", "6", "8", "10"]
    assert var_5 == var_6
    var_7 = "4:host%02d"
    var_8 = lookup_module_0.run(var_7, var_0)

# Generated at 2022-06-25 11:11:09.628696
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    LookupModule = LookupModule()
    LookupModule.generate_sequence()


# Generated at 2022-06-25 11:11:17.831009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(['1-2'])
    assert var_1 == [u'1', u'2'], \
        "expression 'var_1 == [u\"1\", u\"2\"]' failed!"

    var_1 = lookup_run(['1'])
    assert var_1 == [u'1'], "expression 'var_1 == [u\"1\"]' failed!"

    var_1 = lookup_run(['1-2/2'])
    assert var_1 == [u'1', u'2'], \
        "expression 'var_1 == [u\"1\", u\"2\"]' failed!"

    var_1 = lookup_run(['1-2/1'])

# Generated at 2022-06-25 11:11:37.708693
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    var_0 = LookupModule()
    var_0.reset()
    var_0.start = 1
    var_0.end = 1
    var_0.stride = 1
    var_0.format = "%d"
    var_0.sanity_check()

    var_0.reset()
    var_0.start = 1
    var_0.end = 1
    var_0.stride = -1
    var_0.format = "%d"
    var_0.sanity_check()

    var_0.reset()
    var_0.start = 0
    var_0.end = 0
    var_0.stride = 0
    var_0.format = "%d"
    var_0.sanity_check()

    var_0.reset()
    var_0.start

# Generated at 2022-06-25 11:11:49.395876
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    getattr(lookup_module_0, 'parse_simple_args')('3-7/2')
    # assert ?
    getattr(lookup_module_0, 'parse_simple_args')('3-7/2')
    # assert ?
    getattr(lookup_module_0, 'parse_simple_args')('5-8')
    # assert ?
    getattr(lookup_module_0, 'parse_simple_args')('3-3')
    # assert ?
    getattr(lookup_module_0, 'parse_simple_args')('3-3/0')
    # assert ?
    getattr(lookup_module_0, 'parse_simple_args')('3-3/1')
    # assert ?

# Generated at 2022-06-25 11:11:52.343115
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:12:00.342774
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.start = 1
    var_1 = lookup_module_0.count = None
    var_1 = lookup_module_0.end = None
    var_1 = lookup_module_0.stride = 1
    var_1 = lookup_module_0.format = '%d'
    var_1 = lookup_module_0.parse_kv_args({'start': '1', 'end': '1', 'format': 'testuser%02x', 'stride': '1'})
    var_1 = lookup_module_0.sanity_check()
    var_2 = lookup_module_0.generate_sequence()

# Generated at 2022-06-25 11:12:02.889892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [ '8' ]
    var_1 = lookup_module_0.run(['8'], {"vars": {}})
    assert var_1 == var_0


# Generated at 2022-06-25 11:12:07.576570
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    lookup_module_0.count = 1
    lookup_module_0.end = 1

    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:15.263706
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 0
    lookup_module_0.count = None
    lookup_module_0.end = 4
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    assert set(lookup_module_0.generate_sequence()) == {'0', '1', '2', '3', '4'}
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'

# Generated at 2022-06-25 11:12:20.353712
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    print("Test 0")

    lookup_module_0 = LookupModule()

    lookup_module_0.start = 1
    lookup_module_0.end = 4
    lookup_module_0.stride = 1

    lookup_module_0.format = "%d"

    var_0 = lookup_module_0.generate_sequence()

    assert(list(var_0) == ['1', '2', '3', '4'])


# Generated at 2022-06-25 11:12:31.276011
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    sequence = LookupModule()
    sequence.format = '%d'
    # Sequence without stride.
    sequence.start = 1
    sequence.end = 5
    sequence.stride = 1
    result = list(sequence.generate_sequence())
    assert result == ['1', '2', '3', '4', '5']
    # Sequence with stride.
    sequence.start = 1
    sequence.end = 6
    sequence.stride = 2
    result = list(sequence.generate_sequence())
    assert result == ['1', '3', '5']
    # Negative stride.
    sequence.start = 6
    sequence.end = 1
    sequence.stride = -2
    result = list(sequence.generate_sequence())
    assert result == ['6', '4', '2']
    # Invalid stride.
   

# Generated at 2022-06-25 11:12:35.573826
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args('end=0')
    var_1 = lookup_module_0.parse_simple_args('end=0')
    if var_1:
        var_0 = lookup_module_0.parse_simple_args('end=0')
    else:
        lookup_module_0.reset()
    var_0 = lookup_module_0.parse_simple_args('end=0')


# Generated at 2022-06-25 11:13:00.229100
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    try:
        lookup_module_0 = LookupModule()
        try:
            lookup_module_0.sanity_check()
        except AnsibleError:
            pass
    except Exception:
        pass

# Generated at 2022-06-25 11:13:02.083451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    var_0 = lookup_module.run()
    if var_0:
      print("0")
  except Exception as e:
    print("1")


# Generated at 2022-06-25 11:13:07.364465
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    # Testing for exceptions
    pass


# Generated at 2022-06-25 11:13:11.402513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = None  # Default for terms
    # Default for variables
    var_2 = None
    try:
        var_2 = dict()
        var_3 = lookup_module_0.run(var_1, var_2)
        print(var_3)
    except Exception as e:
        var_4 = None
        print(var_4)


# Generated at 2022-06-25 11:13:24.711541
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    var = lookup_module.parse_simple_args("start=10 end=0 stride=-1")
    assert var

    var = lookup_module.parse_simple_args("start=100 end=100")
    assert not var

    var = lookup_module.parse_simple_args("10-1")
    assert var

    var = lookup_module.parse_simple_args("1:-1")
    assert var

    var = lookup_module.parse_simple_args("5-10/5")
    assert var

    var = lookup_module.parse_simple_args("5-10/5/1")
    assert not var

    var = lookup_module.parse_simple_args("10-5")
    assert not var


# Generated at 2022-06-25 11:13:28.873094
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.parse_simple_args('0xf')
    lookup_module.sanity_check()
    assert True


# Generated at 2022-06-25 11:13:31.379768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.run(terms, variables)
    assert var_1 == 0


# Generated at 2022-06-25 11:13:32.716647
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_sanity_check(lookup_module_0)


# Generated at 2022-06-25 11:13:40.551011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'start=5 end=11 stride=2 format=0x%02x',
        'start=4 end=11 stride=2'
    ]
    variables = [
        {'result': ['0x05', '0x07', '0x09', '0x0a']},
        {'result': ['4', '6', '8', '10']}
    ]
    lookup_module_0 = LookupModule()
    for i in range(0,2):
        var_2 = lookup_module_0.run(terms[i], variables[i])
        assert var_2 == variables[i]['result'], 'Test case 0 failed'


# Generated at 2022-06-25 11:13:48.705993
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    var_0 = lookup_module_0.start
    var_1 = lookup_module_0.end
    var_2 = lookup_module_0.stride
    var_3 = lookup_module_0.format
    var_4 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:48.983005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['1', '2', '3', '4', '5']
    var_1 = parse_kv('start=1 end=5')
    var_2 = parse_kv('start=5 end=1')
    var_3 = parse_kv('start=5 end=1')
    var_4 = parse_kv('start=5 end=1')
    var_5 = parse_kv('start=5 end=1')
    var_6 = parse_kv('start=5 end=1')
    var_7 = parse_kv('start=5 end=1')
    var_8 = parse_kv('start=5 end=1')
    var_9 = parse_kv('start=5 end=1')
    var_10

# Generated at 2022-06-25 11:14:54.773776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables for testing
    expected_result_0 = [1]
    expected_result_1 = [1,3,5,7,9]
    expected_result_2 = ['0x0f00','0x0f01','0x0f02','0x0f03']
    expected_result_3 = ['0','2','4','6','8']
    expected_result_4 = ['0x05','0x07','0x09','0x0a']
    expected_result_5 = ['host01','host02','host03','host04']
    expected_result_6 = [10,9,8,7,6,5,4,3,2,1,0]

# Generated at 2022-06-25 11:14:59.871447
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    var_0 = LookupModule()
    var_1 = "foo"
    var_0.parse_simple_args(var_1)
    var_2 = "0x0f00 count=4 format=%04x"
    var_0.parse_simple_args(var_2)
    var_3 = "0 count=5 stride=2"
    var_0.parse_simple_args(var_3)
    var_4 = "1 count=5 stride=2"
    var_0.parse_simple_args(var_4)
    var_5 = "0 count=5 stride=2"
    var_0.parse_simple_args(var_5)


# Generated at 2022-06-25 11:15:08.275180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_get_terms()
    var_2 = lookup_get_variables()
    var_3 = lookup_get_kwargs()
    var_4 = lookup_module_0.run(var_1, var_2, var_3)
    assert var_4 is None
    assert var_1 is None
    assert var_2 is None
    assert var_3 is None


# Generated at 2022-06-25 11:15:11.808483
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    arg_0 = "2-10/2"
    var_0 = lookup_module_0.parse_simple_args(arg_0)


# Generated at 2022-06-25 11:15:17.790948
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    var_0 = LookupModule()
    # Arrange
    var_1 = "1-10/6"
    var_2 = "5-8"
    var_3 = "1-10/6:testuser%02x"
    var_4 = "4:host%02d"
    var_5 = "1-10:testuser%02x"
    var_6 = "5:"
    var_7 = "1"
    var_8 = "5:testuser%02x"
    var_9 = "1-10"
    var_10 = "5/6"
    var_11 = "1/6:testuser%02x"
    var_12 = "5/6:testuser%02x"
    var_13 = "1/6"
    var_14 = "5:-8"

# Generated at 2022-06-25 11:15:20.322115
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_5 = LookupModule()
    assert lookup_module_5.generate_sequence() == None



# Generated at 2022-06-25 11:15:21.809808
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:22.584230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True


# Generated at 2022-06-25 11:15:26.764161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["1", "2", "3"], ["4", "5", "6"], **{"7": "8"})
    assert var_0 == [0, 0]



# Generated at 2022-06-25 11:16:30.823989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['end=5']
    variables_0 = ''
    returned_value_0 = lookup_module_0.run(terms_0, variables_0, **{'end': '5'})
    assert returned_value_0 is None


# Generated at 2022-06-25 11:16:33.087449
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = 'answer = 42'
    var_0 = lookup_parse_simple_args(term_0)
    assert var_0 == False
    test_case_0()
