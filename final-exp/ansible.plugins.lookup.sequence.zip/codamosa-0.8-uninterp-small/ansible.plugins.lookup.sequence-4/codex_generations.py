

# Generated at 2022-06-25 11:06:43.343148
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    # test case for simple sequence
    term = "5"
    lookup_module_0.parse_simple_args(term)
    assert 5 == lookup_module_0.end
    assert 1 == lookup_module_0.start
    assert 1 == lookup_module_0.stride
    assert "%d" == lookup_module_0.format


# Generated at 2022-06-25 11:06:45.663639
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # Test with valid values for inputs, start = 1, end = 5 and stride = 1
    assert lookup_module_0.generate_sequence() == [0, 2, 4, 6, 8]



# Generated at 2022-06-25 11:06:56.565107
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:07:02.796905
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = ""
    lookup_module_0.parse_simple_args(term_0)
    term_1 = "1-1"
    lookup_module_0.parse_simple_args(term_1)
    term_2 = "1-1/1"
    lookup_module_0.parse_simple_args(term_2)
    term_3 = "1-1/1:"
    lookup_module_0.parse_simple_args(term_3)
    term_4 = "1-1/1:1"
    lookup_module_0.parse_simple_args(term_4)
    term_5 = "1-1/"
    lookup_module_0.parse_simple_args(term_5)

# Generated at 2022-06-25 11:07:12.503055
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 1
    lookup_module_0.start = 1
    lookup_module_0.format = "%d"
    lookup_module_0.end = 1
    assert lookup_module_0.generate_sequence() == [1]
    lookup_module_0.end = 0
    lookup_module_0.start = 0
    assert lookup_module_0.generate_sequence() == [0]
    lookup_module_0.end = 1
    assert lookup_module_0.generate_sequence() == [0, 1]
    lookup_module_0.stride = 2
    assert lookup_module_0.generate_sequence() == [0, 2]
    lookup_module_0.start = 4
    lookup_module_0.end

# Generated at 2022-06-25 11:07:18.897755
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.start = 1
        lookup_module_0.end = 4
        lookup_module_0.stride = 1
        lookup_module_0.format = "%d"
        lookup_module_actual_result = lookup_module_0.generate_sequence()
        lookup_module_expected_result = ["1", "2", "3", "4"]
        for i in range(len(lookup_module_expected_result)):
            assert lookup_module_actual_result[i] == lookup_module_expected_result[i]
    except Exception as err:
        print("Testcase 0: Unexpected exception raised: " + str(err))
        raise err


# Generated at 2022-06-25 11:07:20.852223
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    # set up object loopup_module_0

    # Call method parse_simple_args
    assert not lookup_module_0.parse_simple_args("")


# Generated at 2022-06-25 11:07:32.044006
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()

    assert False == lookup_module.parse_simple_args("")
    assert False == lookup_module.parse_simple_args("123")
    assert False == lookup_module.parse_simple_args("123-456")
    assert False == lookup_module.parse_simple_args("123-456/")
    assert False == lookup_module.parse_simple_args("123-456/789")
    assert False == lookup_module.parse_simple_args("123-456/789:")

    # Following the the examples from the doc string
    assert True == lookup_module.parse_simple_args("5")
    assert True == lookup_module.parse_simple_args("5-8")
    assert True == lookup_module.parse_simple_args("2-10/2")
    assert True == lookup_

# Generated at 2022-06-25 11:07:35.434939
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    term_0 = "RFS1"
    lookup_module_0.parse_simple_args(term_0)
    lookup_module_0.sanity_check()
    term_1 = "RFS2"
    lookup_module_0.parse_simple_args(term_1)
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:07:40.541300
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    lookup_module.parse_simple_args('1')
    assert lookup_module.start == 1
    assert lookup_module.end == 1
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'

    lookup_module = LookupModule()
    lookup_module.parse_simple_args('1-10/1')
    assert lookup_module.start == 1
    assert lookup_module.end == 10
    assert lookup_module.stride == 1
    assert lookup_module.format == '%d'

    lookup_module = LookupModule()
    lookup_module.parse_simple_args('1-10/2:%02d')
    assert lookup_module.start == 1
    assert lookup_module.end == 10
    assert lookup_module.str

# Generated at 2022-06-25 11:07:50.464588
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    assert lookup_module.parse_kv_args({'start': '2', 'end': '6', 'format': '%d', 'stride': '2'}) is None
    assert lookup_module.start == 2
    assert lookup_module.end == 6
    assert lookup_module.stride == 2
    assert lookup_module.format == '%d'


# Generated at 2022-06-25 11:07:54.548050
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    # Test the method generate_sequence of class LookupModule
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.end = 0
    assert lookup_module_0.generate_sequence() == []


# Generated at 2022-06-25 11:07:56.258153
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[''], variables={})


# Generated at 2022-06-25 11:08:00.639813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:08:06.115949
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    lookup_module_1.parse_simple_args("5")
    lookup_module_1.parse_simple_args("5-8")
    lookup_module_1.parse_simple_args("2-10/2")
    lookup_module_1.parse_simple_args("4:host%02d")



# Generated at 2022-06-25 11:08:14.341330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    parameters_1 = [["5"],["5-8"],["2-10/2"],["4:host%02d"],["start=5 end=11 stride=2 format=0x%02x"],["count=5"],["start=0x0f00 count=4 format=%04x"],["start=0 count=5 stride=2"],["start=1 count=5 stride=2"]]
    variables_1 = {}

# Generated at 2022-06-25 11:08:16.393175
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Arrange
    lookup_module_0 = LookupModule()
    lookup_module_0.end = 0
    lookup_module_0.start = 1
    lookup_module_0.stride = 1

    # Act
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:19.274104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    results_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:08:25.290248
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    lookup_module = LookupModule()
    terms = 'start=0 end=5'
    variables = None
    kwargs = None
    lookup_module.parse_kv_args(terms)
    assert lookup_module.start == 0
    assert lookup_module.end == 5


# Generated at 2022-06-25 11:08:27.742770
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    lookup_module_0 = LookupModule()

    result = lookup_module_0.parse_simple_args('5')

    assert result == False
    # Verify that the method does not return a failure
    assert result is not False


# Generated at 2022-06-25 11:08:40.184316
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
  term = "1-5"
  variables = None
  kwargs = None
  lookup_module_0 = LookupModule()
  lookup_module_0.run(term, variables, kwargs)
  for i in lookup_module_0.generate_sequence():
    print(i)


# Generated at 2022-06-25 11:08:49.899076
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = None
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = "%d"
    try:
        assert lookup_module_1.sanity_check() == None
        assert False
    except AnsibleError:
        assert True
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = "%d"
    try:
        assert lookup_module_1.sanity_check() == None
        assert False
    except AnsibleError:
        assert True
    lookup_module_1.start = 0
   

# Generated at 2022-06-25 11:08:57.853869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [("5", "8", "2", "2", "16")]
    variables_1 = {}
    with_sequence_results_1 = lookup_module_1.run(terms_1, variables_1)
    assert with_sequence_results_1 == [], with_sequence_results_1

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:09:05.953929
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    # Assigning a Tuple to a Attribute (line 621)
    # Declaration of the 'Term' class
    class Term:

        @staticmethod
        def parse(arg):
            # Declaration of the 'AttrDict' class

            class AttrDict:

                @staticmethod
                def __init__():
                    pass

                @staticmethod
                def __getitem__(value):
                    # Assigning a Str to a Name (line 622):
                    # Getting the type of 'value' (line 622)
                    value_1 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 622, 32), 'value')
                    # Assigning a type to the variable 'value' (line 622)
                    module

# Generated at 2022-06-25 11:09:09.439427
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0x01
    lookup_module_0.count = 0x02
    lookup_module_0.end = 0x03
    lookup_module_0.stride = 0x04
    lookup_module_0.format = '%04x'
    assert ['0001', '0005'], lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:09:14.787466
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    term_0 = '3~10/3:test%02d'
    lookup_module_0.parse_simple_args(term_0)
    assert 'format' in lookup_module_0.__dict__
    assert 'stride' in lookup_module_0.__dict__
    assert 'end' in lookup_module_0.__dict__
    assert 'start' in lookup_module_0.__dict__
    lookup_module_0.__dict__.clear()

    term_1 = '3~10/3'
    lookup_module_0.parse_simple_args(term_1)
    assert 'format' in lookup_module_0.__dict__
    assert 'stride' in lookup_module_0.__dict__
    assert 'end' in lookup_

# Generated at 2022-06-25 11:09:19.497189
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 'start'
    lookup_module_0.count = 'count'
    lookup_module_0.end = 'end'
    lookup_module_0.stride = 'stride'
    lookup_module_0.format = 'format'

    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:29.093192
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule();
    lookup_module_0.start = 0;
    lookup_module_0.count = None;
    lookup_module_0.end = 2;
    lookup_module_0.stride = 1;
    lookup_module_0.format = "%d";
    test_case_0 = lookup_module_0.generate_sequence();
    if (test_case_0.next() != 0):
        raise Exception
    if (test_case_0.next() != 1):
        raise Exception
    if (test_case_0.next() != 2):
        raise Exception


# Generated at 2022-06-25 11:09:30.346085
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    lookup_module_0.run([], {})


# Generated at 2022-06-25 11:09:36.598804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'foo'
    variables_0 = 'bar'
    str_0 = lookup_module_0.run(terms_0, variables_0)
    assert str_0 == None


# Generated at 2022-06-25 11:09:46.581931
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    lookup_module_0.sanity_check()
    assert True


# Generated at 2022-06-25 11:09:48.930876
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = "3-0x05"
    bool_1 = lookup_module_0.parse_simple_args(term_0)
    assert bool_1


# Generated at 2022-06-25 11:09:54.059987
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.count = 1
    try:
        lookup_module_0.sanity_check()
        assert False, "AnsibleError not raised"
    except AnsibleError as exc:
        assert exc.args[0] == "can't specify both count and end in with_sequence"


# Generated at 2022-06-25 11:09:58.691153
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(terms, variables, **kwargs)
    except Exception as e:
        print(e.args)
        assert False

# vim: set expandtab:ts=4:sw=4:

# Generated at 2022-06-25 11:10:07.054932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Regression test file for Ansible lookup modules
# Test the sequence lookup module by using it to generate the integers 1 through 10.
    assert lookup_module_0.run(terms=["start=1 end=10"], variables=None) == ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]

# Test the sequence lookup module by using it to generate the integers 1 through 9.
    assert lookup_module_0.run(terms=["start=1 end=9"], variables=None) == ["1", "2", "3", "4", "5", "6", "7", "8", "9"]

# Test the sequence lookup module by using it to generate the integers 10 through 0, but count backwards.
    assert lookup_module_

# Generated at 2022-06-25 11:10:13.664239
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.start = 1
    lookup_module.end = 32
    lookup_module.stride = 1
    lookup_module.format = 'testuser%02x'

# Generated at 2022-06-25 11:10:16.232944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['10', '20']
    variables_0 = {}
    actual_0 = lookup_module_0.run(terms_0, variables_0)
    expected_0 = ['10', '20']
    assert (expected_0 == actual_0)
    assert_is_instance(actual_0, list)



# Generated at 2022-06-25 11:10:25.649859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    print("Test of function run.")
    lookup_module_0_run_args = []
    lookup_module_0_run_kwargs = {'end': None, 'count': None, 'start': 1, 'format': '%d', 'stride': 1}
    lookup_module_0_run_kwargs['terms'] = ['5']
    lookup_module_0_run_kwargs['variables'] = {}
    result_print = lookup_module_0.run(**lookup_module_0_run_kwargs)
    print(result_print)


# Generated at 2022-06-25 11:10:29.536718
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        assert e.message == "must specify count or end in with_sequence"


# Generated at 2022-06-25 11:10:38.554098
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    """LookupModule: sanitize the inputs for a sequence and return the end value"""
    lookup = LookupModule()
    lookup.start = 1
    lookup.count = None
    lookup.end = None
    lookup.stride = 1
    lookup.format = "%d"

    # Test 1: All parameters not specified
    try:
        lookup.sanity_check()
        raise AssertionError
    except AnsibleError:
        pass

    # Test 2: Both - count and end specified
    lookup.start = 1
    lookup.count = 2
    lookup.end = 4
    lookup.stride = 1
    lookup.format = "%d"
    try:
        lookup.sanity_check()
        raise AssertionError
    except AnsibleError:
        pass

    # Test 3: count specified
    lookup.start

# Generated at 2022-06-25 11:10:52.019037
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = '%d'

    try:
        assertion_flag_0 = LookupModule.sanity_check(lookup_module_1)
        raise AssertionError("An error was expected")
    except Exception:
        pass
    try:
        assertion_flag_0 = LookupModule.sanity_check(lookup_module_1)
        raise AssertionError("An error was expected")
    except Exception:
        pass

# Generated at 2022-06-25 11:10:57.453690
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 0
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    assert len(list(lookup_module_0.generate_sequence())) == 0


# Generated at 2022-06-25 11:10:59.878069
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 0
    lookup_module_0.stride = -1
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:01.837270
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
#   Parameters:
#
#
#   Returns:
#       [Object].
    pass


# Generated at 2022-06-25 11:11:06.074621
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:13.888092
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    term = '1'
    variables = {'test_str': '', 'test_int': 0, 'test_dict': {}, 'test_list': [], 'test_bool': True, 'test_raw': '', 'test_datetime': '', 'test_null': '', 'test_zfile': ''}
    kwargs = {'load_file': ''}
    lookup_module_0.reset()
    lookup_module_0.parse_simple_args(term)
    lookup_module_0.sanity_check()
    assert len(list(lookup_module_0.generate_sequence())) == 1


# Generated at 2022-06-25 11:11:24.138260
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    lookup_module_0 = LookupModule()

    lookup_module_0.count = None

    lookup_module_0.end = None

    lookup_module_0.sanity_check()

    lookup_module_0.count = None

    lookup_module_0.end = 2

    lookup_module_0.sanity_check()

    lookup_module_0.count = 2

    lookup_module_0.end = None

    lookup_module_0.sanity_check()

    lookup_module_0.count = 2

    lookup_module_0.end = 4

    try:
        lookup_module_0.sanity_check()
    except AnsibleError:
        pass
    else:
        raise RuntimeError("AnsibleError not raised when expected")


# Generated at 2022-06-25 11:11:30.638734
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.start = 0x0000
        lookup_module_0.count = None
        lookup_module_0.end = 0x0014
        lookup_module_0.stride = 1
        lookup_module_0.format = "%04x"
        lookup_module_0.sanity_check()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-25 11:11:35.943509
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:40.055626
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args("5") == False
    assert lookup_module.parse_simple_args("5-8") == False
    assert lookup_module.parse_simple_args("2-10/2") == False
    assert lookup_module.parse_simple_args("4:host%02d") == False


# Generated at 2022-06-25 11:11:48.444937
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    terms_0 = lookup_reset()
    variables_0 = lookup_reset()
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:12:00.145164
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = -1
    lookup_module_0.end = 0
    lookup_module_0.start = 1

    lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.end = 1
    lookup_module_0.start = 1

    lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.end = 2
    lookup_module_0.start = 1

    lookup_module_0.sanity_check()
    lookup_module_0.stride = -1
    lookup_module_0.end = 1
    lookup_module_0.start = 1

    lookup_module_0.sanity_

# Generated at 2022-06-25 11:12:08.120359
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    if (lookup_module_0.stride > 0):
        var_0 = lookup_module_0.stride
    else:
        var_1 = -1
        var_0 = var_1
    var_2 = lookup_module_0.stride
    var_3 = 0
    var_4 = lookup_module_0.end
    var_5 = lookup_module_0.start
    var_6 = lookup_module_0.stride
    var_7 = 0
    var_8 = lookup_module_0.end
    var_9 = lookup_module_0.start
    var_10 = lookup_module_0.stride
    var_11 = 0

# Generated at 2022-06-25 11:12:12.589544
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    x = 5
    var_0 = lookup_module_0.reset()
    x = 10
    lookup_module_0.parse_kv_args(x)
    x = 10
    lookup_module_0.sanity_check()
    x = 10
    var_1 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:12:17.589795
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.sanity_check()
    except Exception as exception_0:
        var_0 = False
    else:
        var_0 = True
    assert var_0


# Generated at 2022-06-25 11:12:21.759460
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()

# Generated at 2022-06-25 11:12:26.904460
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:29.435954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(v1, v2, v3)
    assert type(var) == list
    assert "value" in var
    assert var["value"] == "test_value"



# Generated at 2022-06-25 11:12:31.802533
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args("start=5 end=8")


# Generated at 2022-06-25 11:12:38.655465
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.count = 10
    lookup_module_1 = None
    lookup_module_2 = lookup_module_0.sanity_check()
    assert len(lookup_module_2) >= 0, "lookup_module_0.sanity_check() didn't return a valid value"


# Generated at 2022-06-25 11:12:52.724797
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    str_1 = "5"
    result_0 = lookup_module_0.parse_simple_args(str_1)
    assert result_0 == True
    str_0 = "5-8"
    result_1 = lookup_module_0.parse_simple_args(str_0)
    assert result_1 == True
    str_14 = "2-10/2"
    result_2 = lookup_module_0.parse_simple_args(str_14)
    assert result_2 == True
    str_13 = "4:host%02d"
    result_3 = lookup_module_0.parse_simple_args(str_13)
    assert result_3 == True
    str_12 = "5:"

# Generated at 2022-06-25 11:12:53.702649
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:12:56.511316
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    print("In generate_sequence of class LookupModule")
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.parse_kv_args(parse_kv("start=5 end=11 stride=2 format=0x%02x"))
    lookup_module_0.sanity_check()
    var_0 = lookup_module_0.generate_sequence()
    print(var_0)


# Generated at 2022-06-25 11:12:59.443440
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Input params list
    params = []

    # Unit test framework of method sanity_check of class LookupModule
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()
    assert(var_0 == None)


# Generated at 2022-06-25 11:13:06.784980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([u'start=4 end=16 stride=2'])
    assert var_0 == [u'4', u'6', u'8', u'10', u'12', u'14', u'16']

    var_0 = lookup_module_0.run([u'1'])
    assert var_0 == [u'1']

    var_0 = lookup_module_0.run([u'start=0x100 end=0x105 stride=0x10'])
    assert var_0 == [u'256', u'272', u'288', u'304', u'320']

    var_0 = lookup_module_0.run([u'count=5'])

# Generated at 2022-06-25 11:13:09.303036
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 5
    lookup_module_0.end = None
    lookup_module_0.start = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:13:13.071522
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_case_1 = LookupModule()
    var_case_1 = lookup_module_case_1.reset()
    lookup_module_case_1.count = "10"
    lookup_module_case_1.stride = "1"
    lookup_module_case_1.start = "4"
    lookup_module_case_1.format = "%d"
    var_case_1 = lookup_module_case_1.sanity_check()


# Generated at 2022-06-25 11:13:16.926050
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    pass


# Generated at 2022-06-25 11:13:21.664494
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    # Stubber: test_case_0
    # set up instance.start and instance.end for sanity_check
    lookup_module_0.start = 0
    lookup_module_0.end = 0
    # Stubber: test_case_1
    # set up instance.start and instance.end for sanity_check
    lookup_module_0.start = 0
    lookup_module_0.end = 0
    # Stubber: test_case_2
    # set up instance.start and instance.end for sanity_check
    lookup_module_0.start = 0
    lookup_module_0.end = 0
    # Stubber: test_case_3
    # set up instance.start and instance.end for sanity_check
    lookup_module_0.start = 0
    lookup

# Generated at 2022-06-25 11:13:23.480413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('start=5 end=11 stride=2 format=0x%02x')

# Generated at 2022-06-25 11:13:38.270055
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 10
    lookup_module.count = 10
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.format = '%d'
    lookup_module.sanity_check()


# Generated at 2022-06-25 11:13:43.434483
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = "0x10-0x20/2:0x%02x"
    var_1 = lookup_module_0.parse_simple_args(var_0)
    assert var_1 and (lookup_module_0.start == var_1)

# Generated at 2022-06-25 11:13:45.030057
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_0.sanity_check()



# Generated at 2022-06-25 11:13:49.469821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_terms()
    var_1 = lookup_variables()
    var_2 = lookup_module_0.run(var_0, var_1)


# Generated at 2022-06-25 11:13:53.841737
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # setup context
    lookup_module = LookupModule()
    lookup_module.reset()

    # test the method, then compare results to the expected value
    result = lookup_module.generate_sequence()
    assert result == "expected value"


# Generated at 2022-06-25 11:13:58.014833
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.sanity_check()
    assert result == None



# Generated at 2022-06-25 11:14:03.374841
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_0.count=4
    var_0.end=None
    var_0.stride=2

    var_0.sanity_check()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:14:08.720490
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    # Check simple sequence
    lookup_module.start = 0
    lookup_module.end = 3
    lookup_module.stride = 1
    lookup_module.format = "%d"
    exp_arr = ["0", "1", "2", "3"]
    lookup_module.generate_sequence() == exp_arr
    # Check simple sequence with 2-digit result
    lookup_module.start = 10
    lookup_module.end = 21
    lookup_module.stride = 1
    lookup_module.format = "%d"
    exp_arr = ["10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21"]
    lookup_module.generate_sequence() == exp_arr
    # Check simple

# Generated at 2022-06-25 11:14:12.109910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_reset()

    var_3 = lookup_module_1.run(var_0)
    assert var_3 == var_0


# Generated at 2022-06-25 11:14:21.146097
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.count = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    lookup_module_0.sanity_check()
    numbers = xrange(lookup_module_0.start, lookup_module_0.end + adjust, lookup_module_0.stride)
    return_value_0 = lookup_module_0.generate_sequence()
    assert return_value_0 == ["1"]


# Generated at 2022-06-25 11:14:37.945895
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()

    # Test
    lookup_module_0.stride = 1
    lookup_module_0.start = 1
    lookup_module_0.end = 4
    lookup_module_0.format = "%d"
    var_0 = lookup_module_0.generate_sequence()
    assert (var_0 == [1, 2, 3, 4])



# Generated at 2022-06-25 11:14:43.566744
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.start = 1
    lookup_module.count = 2
    lookup_module.end = None
    lookup_module.stride = 2
    lookup_module.format = "%d"


# Generated at 2022-06-25 11:14:47.025664
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    term_0 = ''
    variables_0 = ''
    kwargs_0 = ''
    lookup_module_0 = LookupModule()
    lookup_module_0 = lookup_module_0.run(term_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:14:55.468968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["x","x","x"]) == ["x","y","z"]
    assert lookup_module_0.run(["x"]) == ["x"]
    assert lookup_module_0.run(["y"]) == ["y"]
    assert lookup_module_0.run(["z"]) == ["z"]

# Generated at 2022-06-25 11:14:57.578804
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.generate_sequence()
    assert var_1 == 'range(self.start, self.end + adjust, self.stride)'


# Generated at 2022-06-25 11:14:59.740742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()


test_cases = [test_case_0]



# Generated at 2022-06-25 11:15:05.012684
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.generate_sequence()
    assert isinstance(var_1, types.GeneratorType)


# Generated at 2022-06-25 11:15:10.916983
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.sanity_check()


# Generated at 2022-06-25 11:15:12.288097
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:15:18.609719
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.stride = 1
    lookup_module_0.end = 5


# Generated at 2022-06-25 11:15:42.043844
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.parse_kv_args(parse_kv('start=5 end=11 stride=2 format=0x%02x'))
    var_2 = lookup_module_0.sanity_check()
    var_3 = lookup_module_0.generate_sequence()
    for i in var_3:
        print(i)


# Generated at 2022-06-25 11:15:44.259472
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-25 11:15:54.146724
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    term = u'1-0'
    try:
        lookup_module_0.reset()  # clear out things for this iteration
        try:
            lookup_module_0.parse_simple_args(term)
        except AnsibleError:
            raise
        except Exception as e:
            raise AnsibleError("unknown error parsing with_sequence arguments: %r. Error was: %s" % (term, e))
        lookup_module_0.sanity_check()
        assert False
    except AnsibleError as err:
        assert err.message == u'to count backwards make stride negative'

    term = u'1-2/0'

# Generated at 2022-06-25 11:16:04.431072
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_5 = LookupModule()

    # values from https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/lookup/sequence.py#L148
    def test_case_1():
        term_0 = '5-8'
        match_0 = '(group 0): 5-8, (group 1): None, (group 2): 8, (group 3): None, (group 4): None, (group 5): None, (group 6): None'
        re_compile_0 = SHORTCUT.match(term_0)
        if not re_compile_0:
            raise AnsibleError("can't parse %s=%s as integer" % (arg, arg_raw))
        return_val = re_compile_0.groups()

# Generated at 2022-06-25 11:16:13.674528
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_0.stride = 1
    lookup_module_0.end = 1
    lookup_module_0.start = 0
    var_1 = lookup_module_0.generate_sequence()
    for var_2 in var_1:
        print(var_2)
        print(' ')
    lookup_module_0.stride = 2
    lookup_module_0.end = 1
    lookup_module_0.start = 0
    var_3 = lookup_module_0.generate_sequence()
    for var_4 in var_3:
        print(var_4)
        print(' ')
    lookup_module_0.stride = -1
    lookup_module_0.end = 1
   

# Generated at 2022-06-25 11:16:17.685006
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    var_0 = lookup_reset()
    var_0 = lookup_parse_simple_args('5')
    var_0 = lookup_sanity_check()
    var_0 = lookup_run(['5'], {}, ansible_vars={'a': '5'})
    assert var_0 == ['5']


# Generated at 2022-06-25 11:16:23.172132
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 3
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    var_0 = lookup_module_0.generate_sequence()
    assert var_0 == ['1', '2', '3'], "Expected [%r], got [%r]" % ([1, 2, 3], var_0)


# Generated at 2022-06-25 11:16:31.481910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.parse_simple_args('3')
    lookup_module_0.sanity_check()
    ret_0 = lookup_module_0.generate_sequence()
    ret_1 = ['1', '2', '3']
    assert ret_0 == ret_1