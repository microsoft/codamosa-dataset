

# Generated at 2022-06-25 11:06:47.704142
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    arg_1 = {}
    # ZCONTENT is the output from the vars()
    arg_1 = {"start": 5, "count": 3, "stride": 4, "format": "3"}
    ret_2 = lookup_module_0.parse_kv_args(arg_1)
    # Verify expected return
    # NOTE: "expected_ret" is an expected return value of the function.
    # An assertion fails if the function returns anything different.


# Generated at 2022-06-25 11:06:52.399379
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_sanity_ckeck()


# Generated at 2022-06-25 11:07:02.583845
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    test_case = {
        'start': 0,
        'end': 10,
        'stride': 1,
        'format': "%d",
        'expected': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    }
    
    lookup_module = LookupModule()
    lookup_module.start = test_case['start']
    lookup_module.end = test_case['end']
    lookup_module.stride = test_case['stride']
    lookup_module.format = test_case['format']
    lookup_module_generate_sequece_result = list(lookup_module.generate_sequence())   
    assert lookup_module_generate_sequece_result == test_case['expected']


# Generated at 2022-06-25 11:07:12.438643
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_1 = LookupModule()
    args_1 = {}
    arg_1_raw = lookup_module_1.parse_kv_args(args_1)
    var_1 = args_1.pop("stride", None)
    var_2 = int(arg_1_raw, 0)
    var_3 = args_1.pop("end", None)
    var_4 = int(arg_1_raw, 0)
    var_5 = args_1.pop("start", None)
    var_6 = int(arg_1_raw, 0)
    var_7 = args_1.pop("count", None)
    var_8 = int(arg_1_raw, 0)
    var_9 = args_1.pop("format")

# Generated at 2022-06-25 11:07:19.483357
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """Test method parse_simple_args of class LookupModule with valid inputs"""
    lookup_module_1 = LookupModule()
    var_2 = lookup_sanity_check()
    var_3 = test_case_0()
    var_4 = lookup_sanity_check()
    var_5 = lookup_sanity_check()
    

# Generated at 2022-06-25 11:07:22.518064
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    return


# Generated at 2022-06-25 11:07:30.240596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assertion setup
    assert (("1", "2", "3") == LookupModule().run("start=1 end=3", {}, ""))
    assert (("1", "2", "3", "4", "5") == LookupModule().run("1-5", {}, ""))
    assert (("5", "6", "7", "8") == LookupModule().run("5-8", {}, ""))
    assert (("2", "4", "6", "8", "10") == LookupModule().run("2-10/2", {}, ""))
    assert (("host01", "host02", "host03", "host04") == LookupModule().run("4:host%02d", {}, ""))

# Generated at 2022-06-25 11:07:32.882116
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    pass


# Generated at 2022-06-25 11:07:36.880723
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    _lookup_instance = LookupModule()

# Generated at 2022-06-25 11:07:42.548130
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_1 = LookupModule()
    param_1 = {}
    assert lookup_module_1.parse_kv_args(param_1) is None
    assert lookup_module_1.start is 1
    assert lookup_module_1.count is None
    assert lookup_module_1.end is None
    assert lookup_module_1.stride is 1
    assert lookup_module_1.format == "%d"


# Generated at 2022-06-25 11:07:50.805687
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert_equal(lookup_module_0.sanity_check(), None);


# Generated at 2022-06-25 11:07:55.543923
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    var_1 = parse_kv("start=6 end=11 stride=2 format=0x%02x")
    expected_1 = {"start": 6, "end": 11, "stride": 2, "format": "0x%02x"}
    lookup_module_0.parse_kv_args(var_1)
    assert expected_1 == var_1


# Generated at 2022-06-25 11:08:05.192341
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_generate_sequence_obj = LookupModule()
    var_1 = lookup_module_generate_sequence_obj.reset()
    var_2 = lookup_module_generate_sequence_obj.parse_simple_args("start=1 end=2")
    assert var_2 == True
    lookup_module_generate_sequence_obj.end = '0'
    assert isinstance(lookup_module_generate_sequence_obj.end, str)
    lookup_module_generate_sequence_obj.start = '0'
    assert isinstance(lookup_module_generate_sequence_obj.start, str)
    lookup_module_generate_sequence_obj.stride = '0'
    assert isinstance(lookup_module_generate_sequence_obj.stride, str)
    var_

# Generated at 2022-06-25 11:08:07.840414
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    var_0 = SHORTCUT.match('1-50')
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.parse_simple_args('1-50')
    if ( var_1 != False ):
        raise AssertionError()


# Generated at 2022-06-25 11:08:09.380485
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:10.557378
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    var_0 = parse_kv()


# Generated at 2022-06-25 11:08:16.157804
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    #
    # The variable results is used in a return statement, but no value has been
    # assigned to it.
    #
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as ansible_error_0:
        pass



# Generated at 2022-06-25 11:08:21.072864
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_1 = LookupModule()
    

    
    with pytest.raises(AnsibleError):
        lookup_module_1.parse_kv_args()
    
    
    
    
    



# Generated at 2022-06-25 11:08:26.055808
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args("4:host%02d")
    print(var_0)



# Generated at 2022-06-25 11:08:31.974325
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.parse_kv_args(parse_kv('start=0x3f8 end=0x3ff count=4 format=%04x'))
    lookup_module_0.sanity_check()

# Generated at 2022-06-25 11:08:36.935862
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args(term='5-8')


# Generated at 2022-06-25 11:08:38.916583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run
    print(str(var_0))

# Generated at 2022-06-25 11:08:43.902103
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    # Call the method with arguments
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:45.796497
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    results_1 = lookup_module_0.sanity_check()
    return results_1

# Generated at 2022-06-25 11:08:49.847397
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 3
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()
    assert(lookup_module_0.start == 1)
    assert(lookup_module_0.end == 3)
    assert(lookup_module_0.stride == 1)


# Generated at 2022-06-25 11:08:57.112514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        '1',
        '2',
        '3'
    ]
    var_0 = parse_kv(terms_0)
    var_1 = lookup_module_0.run(terms_0, var_0, **kwargs_0)
    assert var_1 == [
        '1',
        '2',
        '3'
    ]

# Generated at 2022-06-25 11:09:03.206660
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Source:
    lookup_module_1 = LookupModule()
    cn = "count"
    en = "end"
    ae = "ansibleerror"

    # Tests:
    # Case: If the count value is None and the end value is None
    lookup_module_1.count = None
    lookup_module_1.end = None
    try:
        lookup_module_1.sanity_check()
    except AnsibleError:
        pass
    # Case: If the count value is none and the end value is not none
    lookup_module_1.count = None
    lookup_module_1.end = 1
    try:
        lookup_module_1.sanity_check()
    except AnsibleError:
        pass
    # Case: If the count value is not none and the end value is none
   

# Generated at 2022-06-25 11:09:05.161687
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args("1-2")
    assert var_0 == True


# Generated at 2022-06-25 11:09:07.610527
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    var_0 = ansible.parsing.splitter.parse_kv("start=5 end=11 stride=2")
    var_1 = lookup_module_0.parse_kv_args(var_0)


# Generated at 2022-06-25 11:09:09.413073
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    try:
        var_0 = lookup_module_0.generate_sequence()
    except Exception as e:
        print (e)
        raise


# Generated at 2022-06-25 11:09:18.243493
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_generate_sequence()



# Generated at 2022-06-25 11:09:19.656881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(([])())
    assert var_0 == ()


# Generated at 2022-06-25 11:09:28.472015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    sequence_terms_0 = [
        '1',
        'start=1',
        'start=1 end=2',
        'start=1 end=2 stride=3',
        'start=1 end=2 stride=3 format=4',
    ]
    variables_0 = dict()
    var_0 = lookup_module_0.run(sequence_terms_0, variables_0)
    assert var_0 == ['0'], var_0  # Expected value


# Generated at 2022-06-25 11:09:34.636253
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:09:41.895154
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Class instance which generate_sequence method called
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()  # clear out things for this iteration
    lookup_module_0.start = 1
    lookup_module_0.end = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    # Save the result of function call
    result = lookup_module_0.generate_sequence()
    # Assertion with expected result
    assert result == [1, 2, 3, 4, 5]


# Generated at 2022-06-25 11:09:46.720844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()

    # Call method run on var_0
    # Start actual call
    term_0 = [
        "start=6 end=12 stride=2 format=0x%02x"
    ]
    var_1 = lookup_module_0.run(term=term_0, variables={})
    # End actual call


# Generated at 2022-06-25 11:09:49.703087
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.sanity_check()
    assert lookup_module.start == 1
    assert lookup_module.stride == 1
    assert lookup_module.end == None
    assert lookup_module.format == '%d'
    assert lookup_module.count == None
    

# Generated at 2022-06-25 11:09:58.433637
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = [1, 2, 3, 4, 5]
    var_2 = lookup_module_0.parse_simple_args("start=1 end=1 count=5")
    var_3 = lookup_module_0.sanity_check()
    var_4 = lookup_module_0.generate_sequence()
    assert var_0 is None
    assert var_1[0] == 1
    assert var_2 is True
    assert var_3 is None
    assert var_4 == None


# Generated at 2022-06-25 11:10:06.730758
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.start
    var_1 = lookup_module_0.count
    var_2 = lookup_module_0.end
    var_3 = lookup_module_0.stride
    var_4 = lookup_module_0.format
    try:
        lookup_module_0.sanity_check()
    except AnsibleError:
        pass
    var_0 = lookup_module_0.start
    var_1 = lookup_module_0.count
    var_2 = lookup_module_0.end
    var_3 = lookup_module_0.stride
    var_4 = lookup_module_0.format
    try:
        lookup_module_0.sanity_check()
    except AnsibleError:
        pass
   

# Generated at 2022-06-25 11:10:10.559660
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.generate_sequence()
    var_2 = '''['1', '2', '3', '4', '5']'''
    var_3 = list(var_1)
    assert var_3 == eval(var_2)


# Generated at 2022-06-25 11:10:20.966683
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    result = lookup_module.run([], {}, **{})
    assert result == []



# Generated at 2022-06-25 11:10:22.820201
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.parse_simple_args("start=0 count=5 format=%d")
    var_2 = lookup_module_0.parse_simple_args("0-8")


# Generated at 2022-06-25 11:10:26.986484
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = -1
    lookup_module_0.start = 10
    lookup_module_0.end = 0
    lookup_module_0.format = "%d"


# Generated at 2022-06-25 11:10:31.335491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_0 = {}
    terms_0 = []
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.run(terms_0, vars_0)

# Generated at 2022-06-25 11:10:33.811012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ("start=0 end=0 stride=0 format=testuser%02x", )
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = ["testuser00"]
    var_5 = lookup_module_0.run(var_0, var_1, var_2, var_3)
    assert var_4 == var_5


# Generated at 2022-06-25 11:10:43.434887
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    # sanity check 1
    var_0.sanity_check()
    # sanity check 2
    var_0.count = 1
    var_0.sanity_check()
    # sanity check 3
    var_0.count = None
    var_0.end = 1
    var_0.sanity_check()
    # sanity check 4
    var_0.count = 1
    var_0.sanity_check()
    # sanity check 5
    var_0.count = None
    var_0.start = 2
    var_0.end = 1
    var_0.sanity_check()
    # sanity check 6
    var_0.count = None
    var_0.start = 1

# Generated at 2022-06-25 11:10:47.528035
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.parse_simple_args(term)
    assert var_1 == true, "\n Expected result: %r\n Returned result: %r" % ( true, var_1 )


# Generated at 2022-06-25 11:10:57.384005
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()

    # Test default case
    result = lookup_module.parse_simple_args('start=1 end=5')
    assert not result

    # Test default case
    result = lookup_module.parse_simple_args('start=1 end=5')
    assert not result

    # Test default case
    result = lookup_module.parse_simple_args('start=1 end=5')
    assert not result

    # Test default case
    result = lookup_module.parse_simple_args('start=1 end=5')
    assert not result


# Generated at 2022-06-25 11:11:02.874247
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:07.878358
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    # The "2 + 2" is used for the sake of example
    var_1 = lookup_module_0.run(["2 + 2"])
    assert var_1 == 4


# Generated at 2022-06-25 11:11:24.380704
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:11:26.829329
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args('5-8')
    assert var_0 == True

# Generated at 2022-06-25 11:11:37.023109
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    var_1 = LookupModule()
    var_2 = var_1.sanity_check()
    var_1 = LookupModule()
    var_1.count = 0
    var_1.end = 0
    var_1.stride = 0
    var_3 = var_1.sanity_check()
    var_1 = LookupModule()
    var_1.count = None
    var_1.end = None
    var_4 = var_1.sanity_check()
    var_1 = LookupModule()
    var_1.count = 0
    var_1.end = 0
    var_1.stride = 0
    var_1.count = 1
    var_5 = var_1.sanity_check()
    var_1 = LookupModule()
    var_1.count

# Generated at 2022-06-25 11:11:44.157727
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 1
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.reset()
    lookup_module.parse_simple_args('0')
    lookup_module.sanity_check()
    lookup_module.start = 1
    lookup_module.end = 1
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.reset()
    lookup_module.parse_simple_args('0,1,2')
    lookup_module.sanity_check()
    lookup_module.start = 1
    lookup_module.end = 1
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup

# Generated at 2022-06-25 11:11:52.575358
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    from ansible.parsing.splitter import parse_kv
    lookup_module_0 = LookupModule()
    var_0 = str()
    var_0 = str()
    var_0 = None
    var_0 = int()
    var_0 = int()
    var_0 = int()
    var_0 = str()
    if (not (lookup_module_0.parse_simple_args(var_0))):
        raise Exception("parse_simple_args test0 failed.")

    if (not (lookup_module_0.parse_simple_args(var_0))):
        raise Exception("parse_simple_args test1 failed.")

    var_0 = 0

# Generated at 2022-06-25 11:11:54.092901
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.generate_sequence()) == 0


# Generated at 2022-06-25 11:11:58.065536
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    # set up
    # run
    var_return = lookup_module_0.generate_sequence()
    # assert


# Generated at 2022-06-25 11:12:00.238554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=var_0, variables=var_0)
    assert var_0 == var_0


# Generated at 2022-06-25 11:12:11.615276
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = '%d'
    lookup_module_2 = LookupModule()
    lookup_module_2.start = 1
    lookup_module_2.count = None
    lookup_module_2.end = None
    lookup_module_2.stride = 1
    lookup_module_2.format = '%d'
    lookup_module_2.count = 0
    lookup_module_3 = LookupModule()
    lookup_module_3.start = 1
    lookup_module_3.count = None


# Generated at 2022-06-25 11:12:21.616690
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = 'foobar'
    res_0 = lookup_module_0.parse_simple_args(term_0)
    assert res_0 == 0
    term_1 = '/2/2'
    res_1 = lookup_module_0.parse_simple_args(term_1)
    assert res_1 == 0
    term_2 = '0x/2/2'
    res_2 = lookup_module_0.parse_simple_args(term_2)
    assert res_2 == 0
    term_3 = ':foo'
    res_3 = lookup_module_0.parse_simple_args(term_3)
    assert res_3 == 0
    term_4 = ' 5'
    res_4 = lookup_module_0.parse_

# Generated at 2022-06-25 11:12:41.585560
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:12:48.571838
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.parse_simple_args('start=5 end=8') == False
    assert lookup_module_0.parse_simple_args('start=5 end=6/2') == False
    assert lookup_module_0.parse_simple_args('5:host%02d') == True
    assert lookup_module_0.parse_simple_args('start=5 end=11/2') == False


# Generated at 2022-06-25 11:12:51.938636
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a valid term
    terms = ["5-10/2"]
    variables = {}
    with_sequence = LookupModule().run(terms, variables, inject=None,
                                       basedir=None)

    assert with_sequence == ["5", "7", "9"]



# Generated at 2022-06-25 11:12:57.098596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'_terms': ['5']})
    lookup_module_0.set_options({'_variables': {}})
    lookup_module_0.set_options({'_use_check_mode': False})
    lookup_module_0.set_options({'_ansible_check_mode': False})
    lookup_module_0.set_options({'_ansible_debug': False})
    lookup_module_0.set_options({'_ansible_diff': False})
    lookup_module_0.set_options({'_ansible_module_name': ''})
    lookup_module_0.set_options({'_ansible_sni': False})

# Generated at 2022-06-25 11:12:59.730183
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.count = None
    lookup_module.end = 10
    lookup_module.sanity_check()
    assert lookup_module.sanity_check()


# Generated at 2022-06-25 11:13:02.382145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(
        terms=[''],
        variables={
            'item': 'host02',
            'item_int': 2,
        }
    )
    assert var_0[0] == "host02"
    assert var_0[1] == 2


# Generated at 2022-06-25 11:13:09.778577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "2-10/2"
    variables_0 = "2-10/2"
    kwargs_0 = "2-10/2"
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 is None


# Generated at 2022-06-25 11:13:11.494703
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = None
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:13:18.790881
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_0.stride = 1
    var_0.start = 1
    var_0.sanity_check()
    var_1 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:13:27.755917
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    lookup_module_0.end = 5
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    result = lookup_module_0.generate_sequence()
    assert result == "0x05", "The method generate_sequence return value does not match expected value"
    lookup_module_0.reset()
    lookup_module_0.end = 5
    lookup_module_0.start = True
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    result = lookup_module_0.generate_sequence()

# Generated at 2022-06-25 11:13:57.683063
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # type: (LookupModule) -> None
    lookup_module = LookupModule()
    lookup_module.reset()

    # sample term
    term = '5-8'

    # start count
    assert (lookup_module.start == 1)
    # start end
    assert (lookup_module.end == None)
    # start format
    assert (lookup_module.format == "%d")
    # start stride
    assert (lookup_module.stride == 1)

    lookup_module.parse_simple_args(term)

    # end count
    assert (lookup_module.count == None)
    # end end
    assert (lookup_module.end == 8)
    # end format
    assert (lookup_module.format == "%d")
    # end start

# Generated at 2022-06-25 11:14:03.944186
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    args = {
        'count': None,
        'end': None,
        'start': 5,
        'stride': 1,
        'format': '%d',
    }

    try:
        result = lookup_module.generate_sequence(args)
        assert result == ['5', '6', '7', '8', '9'], "Testcase failed"
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:14:10.458066
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    #
    # sanity check
    #
    var_1 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:14.252753
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:14:16.504985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()



# Generated at 2022-06-25 11:14:21.226428
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 2
    lookup_module_0.stride = 3
    lookup_module_0.format = '%2d'
    try:
        lookup_module_0.sanity_check()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 11:14:26.290185
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 4
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    assert_equals(list(lookup_module_0.generate_sequence())[0], "1")


# Generated at 2022-06-25 11:14:32.165176
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = 'LookupBase'
    var_0 = lookup_module_0.parse_simple_args(term_0)
    assert var_0 == False



# Generated at 2022-06-25 11:14:34.543832
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:43.381189
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()  # clear out things for this iteration
    try:
        if not lookup_module_0.parse_simple_args(term):
            lookup_module_0.parse_kv_args(parse_kv(term))
    except AnsibleError:
        raise
    except Exception as e:
        raise AnsibleError("unknown error parsing with_sequence arguments: %r. Error was: %s" % (term, e))

    # TODO: test with arguments
    # TODO: test with multiple arguments
    lookup_module_0.sanity_check()
    return lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:15:21.304014
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # Test case setup
    result = lookup_module_0.generate_sequence()
    assert 0 == result
    # Test case teardown
    lookup_module_0 = None


# Generated at 2022-06-25 11:15:24.022611
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    arg_list = []
    arg_list.append(self)
    # Test case parameters
    # Argument 0
    arg_list.append(arg_0)
    # Return type
    ret_type = type(xrange(1, 1))



# Generated at 2022-06-25 11:15:30.362192
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    with raises(AnsibleError):
        lookup_module_0.reset()  # clear out things for this iteration
        lookup_module_0.parse_simple_args('')  # parse the shortcut forms, return True/False
        lookup_module_0.parse_kv_args(parse_kv(''))  # parse key-value style arguments
        lookup_module_0.sanity_check()  # make sure the arguments make sense


# Generated at 2022-06-25 11:15:33.939776
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:35.142375
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    assert lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:15:39.748332
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    var_0 = lookup_reset()
    var_1 = "var_1"
    var_0 = lookup_module_1.parse_simple_args(var_1)
    assert var_0 == False
    var_2 = "4:host%02d"
    var_0 = lookup_module_1.parse_simple_args(var_2)
    assert var_0 == True
    var_3 = "0x3f8"
    var_0 = lookup_module_1.parse_simple_args(var_3)
    assert var_0 == True
    var_4 = "0600"
    var_0 = lookup_module_1.parse_simple_args(var_4)
    assert var_0 == True
    var_5 = "3"


# Generated at 2022-06-25 11:15:44.043595
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.parse_kv_args(dict())
    var_2 = lookup_module_0.sanity_check()
    var_3 = lookup_module_0.generate_sequence()



# Generated at 2022-06-25 11:15:47.328957
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.count = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.format = "%5d"
    # Test for AnsibleError(exception)
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        print("Ansible error: %s" % e)


# Generated at 2022-06-25 11:15:51.422093
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    var_0 = set()
    var_1 = frozenset()
    lookup_module_0 = ''
    lookup_module_1 = LookupModule()
    lookup_module_1.generate_sequence()


# Generated at 2022-06-25 11:15:58.768302
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    term = "1-5/1:test%02d"
    lookup_module_0.parse_simple_args(term)
    assert len(vars(lookup_module_0)) == 5
    assert lookup_module_0.format == "test%02d"
    assert lookup_module_0.start == 1
    assert lookup_module_0.end == 5
    assert lookup_module_0.stride == 1
    assert lookup_module_0.count == None
