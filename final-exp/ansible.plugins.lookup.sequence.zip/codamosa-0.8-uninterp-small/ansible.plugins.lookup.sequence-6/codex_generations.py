

# Generated at 2022-06-25 11:06:44.092575
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 1
    lookup_module_0.end = 1
    assert_raises(AnsibleError, lookup_module_0.sanity_check)


# Generated at 2022-06-25 11:06:53.461542
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    args = {}
    lookup_module_0.parse_kv_args(args)
    lookup_module_0.start = 1
    lookup_module_0.end = None
    lookup_module_0.count = None
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    assert lookup_module_0.start == 1
    assert lookup_module_0.end == None
    assert lookup_module_0.count == None
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == '%d'
    args = {}
    lookup_module_0.parse_kv_args(args)
    lookup_module_0.start = 1

# Generated at 2022-06-25 11:07:00.563398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    terms = 'start=3 end=9 stride=2'
    variables = 'var'
    kwargs = {
        'stride': 'stride'
    }

    # Test
    result = lookup_module_0.run(terms, variables, **kwargs)

    # Verify
    expected_result = ['3', '5', '7', '9']
    assert result == expected_result


# Generated at 2022-06-25 11:07:10.468347
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    test_cases = [
        {
            "inputs": {
                "args": {
                    "start": "1",
                    "end": "32"
                },
                "kwargs": {}
            },
            "result": {
                "start": 1,
                "end": 32,
                "count": None,
                "stride": 1,
                "format": "%d"
            }
        }
    ]

    for test_case in test_cases:
        lookup_module = LookupModule()
        lookup_module.parse_kv_args(test_case["inputs"]["args"])

        assert lookup_module.start == test_case["result"]["start"]
        assert lookup_module.end == test_case["result"]["end"]
        assert lookup_module.count == test_case

# Generated at 2022-06-25 11:07:17.501281
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.end = 0
    lookup_module_0.start = 1
    lookup_module_0.stride = 0
    lookup_module_0.count = None
    lookup_module_0.sanity_check()
    lookup_module_0.count = 0
    lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()
    lookup_module_0.count = None
    lookup_module_0.sanity_check()
    lookup_module_0.count = 5
    lookup_module_0.sanity_check()
    lookup_module_0.count = 6
    lookup_module_0.sanity_check()
    lookup_module_0.count

# Generated at 2022-06-25 11:07:18.876477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([], []) == []



# Generated at 2022-06-25 11:07:24.183577
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    _args = {}
    lookup_module_0.parse_kv_args(_args)


# Generated at 2022-06-25 11:07:25.426134
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    args = {}


# Generated at 2022-06-25 11:07:31.261048
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    params_0 = {'stride': -1, 'end': 0, 'start': 10}
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = params_0.get('stride')
    lookup_module_0.end = params_0.get('end')
    lookup_module_0.start = params_0.get('start')
    del params_0

    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:07:34.113681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test using default parameters of the run method
    lookup_module_0.run()


# Generated at 2022-06-25 11:07:49.737299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:07:54.409660
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = 5
    lookup_module.end = 5
    lookup_module.stride = 1
    lookup_module.format = '%d'
    lookup_module.sanity_check()
#test_case_0()
print(test_LookupModule_sanity_check())

# Generated at 2022-06-25 11:08:05.000265
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import mock
    import ansible.plugins.lookup.sequence
    import re

    my_start = 0
    my_end = 10
    my_stride = 1

    lookup_module_run_mock = mock.Mock(side_effect=ansible.plugins.lookup.sequence.LookupModule.run)
    ansible.plugins.lookup.sequence.LookupModule.run = lookup_module_run_mock
    ansible.plugins.lookup.sequence.re_compile = mock.Mock(return_value=re.compile(".*"))
    ansible.plugins.lookup.sequence.LookupModule().run(terms=["%d-%d/%d" % (my_start, my_end, my_stride)], variables={})

    my_start = 10

# Generated at 2022-06-25 11:08:11.930824
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 3
    lookup_module.format = "%d"
    lookup_module.stride = 1
    result = lookup_module.generate_sequence()
    assert next(result) == "1"
    assert next(result) == "2"
    assert next(result) == "3"
    assert next(result) == None


# Generated at 2022-06-25 11:08:20.452288
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    args = {
        'start': '5',
        'end': '11',
        'stride': '2',
        'format': '0x%02x'
    }
    lookup_module.parse_kv_args(args)
    assert lookup_module.start == 5
    assert lookup_module.end == 11
    assert lookup_module.stride == 2
    assert lookup_module.format == '0x%02x'
    args = {
        'start': 5,
        'end': 11,
        'stride': 2,
        'format': '0x%02x'
    }
    lookup_module.parse_kv_args(args)
    assert lookup_module.start == 5
    assert lookup_module.end == 11
    assert lookup_module

# Generated at 2022-06-25 11:08:25.513571
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        assert(type(e) == AssertionError)


# Generated at 2022-06-25 11:08:29.616499
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.start = 1
    lookup_module_0.end = 5
    res = [i for i in lookup_module_0.generate_sequence()]
    assert res == [1, 2, 3, 4, 5]

# Generated at 2022-06-25 11:08:34.796463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test the 'args' parameters
    lookup_module_0.run(terms=["0-5", "0-5:test%02d"], variables="")

    # Test the 'kwargs' parameters
    #lookup_module_0.run(terms=["0-5", "0-5:test%02d"], variables="", inject=None, basedir='', variable_manager=None)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:35.996308
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = "5-8"
    assert lookup_module_0.parse_simple_args(term_0)


# Generated at 2022-06-25 11:08:37.525723
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 0
    lookup_module.end = 3
    lookup_module.stride = 1
    lookup_module.sanity_check()


# Generated at 2022-06-25 11:08:42.894623
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    try:
        assert lookup_module_0.parse_simple_args('10') == False
    finally:
        lookup_module_0.reset()
        lookup_module_0 = None


# Generated at 2022-06-25 11:08:50.325455
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = "%d"
    lookup_module_1.sanity_check()

if __name__ == '__main__':
    print("Running test cases for class LookupModule")
    print("=====================")
    print("Testing method reset of class LookupModule")
    print("type(lookup_module_0) is %s" % (str(type(test_case_0()))))
    print("=====================")
    print("Testing method sanity_check of class LookupModule")
    test_LookupModule_sanity_check()

# Generated at 2022-06-25 11:09:01.181589
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args('5') == False
    assert lookup_module.parse_simple_args('5-9') == False
    assert lookup_module.parse_simple_args('5-9/2') == False
    assert lookup_module.parse_simple_args('5-9/2:test%02x') == False
    # assert lookup_module.parse_simple_args('5-9/2:test%02x') == True
    assert lookup_module.parse_simple_args('5-9/2:test%02x') == False
    assert lookup_module.parse_simple_args('') == False
    assert lookup_module.parse_simple_args('my_test_string') == False


# Generated at 2022-06-25 11:09:10.267912
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # test with argument 'term': 5 -> ["1","2","3","4","5"]
    term_0 = "5"
    assert not lookup_module_0.parse_simple_args(term_0)

    # test with argument 'term': 5-8 -> ["5", "6", "7", "8"]
    term_1 = "5-8"
    assert not lookup_module_0.parse_simple_args(term_1)

    # test with argument 'term': 2-10/2 -> ["2", "4", "6", "8", "10"]
    term_2 = "2-10/2"
    assert not lookup_module_0.parse_simple_args(term_2)

    # test with argument 'term': 4:host%02d -> ["host

# Generated at 2022-06-25 11:09:14.099364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    results = lookup_module_0.run([
        {
            'end': '3',
            'start': '1'
        }
    ], [
        'localhost'
    ], wantlist=False)
    assert results == ['1', '2', '3'], "bad results: " + " ".join(results)



# Generated at 2022-06-25 11:09:19.532998
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.format = '%d'
    lookup_module_0.start = 0
    lookup_module_0.end = 10
    lookup_module_0.stride = 1
    numbers = lookup_module_0.generate_sequence()
    assert numbers == ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10']

# Generated at 2022-06-25 11:09:26.144811
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = 4
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:29.033384
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    test_case_0()
    lookup_module_0 = LookupModule()
    lookup_module_0.start = None
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()  # should not raise AnsibleError


# Generated at 2022-06-25 11:09:32.316648
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = int()
    lookup_module_0.end = int()
    lookup_module_0.stride = int()
    lookup_module_0.format = str()
    try:
        lookup_module_0.generate_sequence()
    except Exception:
        assert False



# Generated at 2022-06-25 11:09:43.358571
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    # setting up variables used in test case
    lookup_module_1.start = 1
    lookup_module_1.end = 11
    lookup_module_1.stride = 2
    lookup_module_1.format = "0x%02x"

    lookup_module_2 = LookupModule()
    lookup_module_2.start = 0
    lookup_module_2.end = None
    lookup_module_2.count = 4
    lookup_module_2.format = "%04x"

    lookup_module_3 = LookupModule()
    lookup_module_3.start = 0
    lookup_module_3.end = None
    lookup_module_3.count = 5
    lookup_module_3.stride = 2

    lookup_module_4 = LookupModule

# Generated at 2022-06-25 11:09:52.998845
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 64
    lookup_module_0.end = 0
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        assert e.message == 'to count backwards make stride negative'
    lookup_module_0.start = 0
    lookup_module_0.end = 64
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        assert e.message == "to count forward don't make stride negative"


# Generated at 2022-06-25 11:10:01.612923
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    print('\n**** test_LookupModule_sanity_check ****')

    print('\n### Test Case 1 ###')
    x = LookupModule()
    x.start = 0
    x.end = 4
    x.stride = 1
    x.sanity_check()
    print(x.start)
    print(x.end)
    print(x.stride)

    print('\n### Test Case 2 ###')
    try:
        x = LookupModule()
        x.start = 0
        x.count = 4
        x.stride = 1
        x.sanity_check()
        print(x.start)
        print(x.end)
        print(x.stride)
    except AnsibleError as e:
        print(e)


# Generated at 2022-06-25 11:10:05.475573
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
   # Arrange
   lookup_module = LookupModule()
   lookup_module.start = 1
   lookup_module.end = 3
   lookup_module.stride = 1
   lookup_module.format = "%d"
   # Act
   lookup_module.sanity_check()
   # Assert
   # no exception raised


# Generated at 2022-06-25 11:10:09.985030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms='abc', variables='abc')
    lookup_module_0.run(terms=('abc', 'abc'), variables='abc')
    lookup_module_0.run(terms='abc', variables=('abc', 'abc'))
    lookup_module_0.run(terms=('abc', 'abc'), variables=('abc', 'abc'))



# Generated at 2022-06-25 11:10:15.645809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test first use case
    terms = [
        'start=0 end=32 format=testuser%02x'
    ]
    variables = []
    kwargs = {}
    ret = lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:10:25.314888
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.end = 0
    lookup_module_0.format = "%d"
    if lookup_module_0.generate_sequence() is not None:
        pass
        # State_0
        results = []
        for i in lookup_module_0.generate_sequence():
            # State_1
            results.append(i)
        assert results == []
    else:
        pass  # no state_1


# Generated at 2022-06-25 11:10:33.748495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    results = t.run(['5-10/2', '2-10/2:0x%02x'], dict())
    assert results == ['5', '0x02', '7', '0x04', '9', '0x06']
    results = t.run(['5-10/2', '2-10/2', '2-10/2:test%02x'], {})
    assert results == ['5', '2', '7', '4', '9', '6', 'test02', 'test04', 'test06']

# Generated at 2022-06-25 11:10:38.282533
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    start_0 = 0
    end_0 = 10
    stride_0 = 2
    lookup_module_0.start = start_0
    lookup_module_0.end = end_0
    lookup_module_0.stride = stride_0
    assert (["0","2","4","6","8"] == lookup_module_0.generate_sequence())


# Generated at 2022-06-25 11:10:48.417035
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 5
    lookup_module_1.end = 2
    lookup_module_1.stride = 2
    lookup_module_1.sanity_check()
    # Call sanity_check from class LookupModule with args
    lookup_module_1.sanity_check()
    lookup_module_2 = LookupModule()
    lookup_module_2.start = 10
    lookup_module_2.end = 5
    lookup_module_2.stride = -2
    lookup_module_2.sanity_check()
    # Call sanity_check from class LookupModule with args
    lookup_module_2.sanity_check()


# Generated at 2022-06-25 11:10:49.807705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    lookup_module_run.run(terms=['start=1', 'end=4'])

# Generated at 2022-06-25 11:11:07.876704
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    test_obj = LookupModule()
    test_obj.start = 5
    test_obj.count = None
    test_obj.end = 8
    test_obj.stride = 2
    test_obj.format = '%d'
    with pytest.raises(AnsibleError) as ans_err:
        test_obj.sanity_check()
    assert ans_err.match('must specify count or end')
    # test the second condition
    test_obj.count = 2
    with pytest.raises(AnsibleError) as ans_err:
        test_obj.sanity_check()
    assert ans_err.match('can\'t specify both count and end')
    # test the third condition
    test_obj.count = 10
    test_obj.stride = 2

# Generated at 2022-06-25 11:11:11.400575
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as err:
        print("AnsibleError exception caught")
        print("err.message = ", err.message)


# Generated at 2022-06-25 11:11:20.734297
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    #1
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.end = 32
    lookup_module_1.format = "testuser%02x"
    lookup_module_1.stride = 1
    result = lookup_module_1.generate_sequence()

# Generated at 2022-06-25 11:11:30.210164
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = "%d"
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_1.sanity_check()
    assert str(excinfo.value) == "must specify count or end in with_sequence"

    lookup_module_2 = LookupModule()
    lookup_module_2.start = 1
    lookup_module_2.count = 1
    lookup_module_2.end = 1
    lookup_module_2.stride = 1
    lookup_module_2.format = "%d"

# Generated at 2022-06-25 11:11:37.908737
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    lookup_module_0.reset()
    lookup_module_0.parse_kv_args({'format': 'host%02d'})
    lookup_module_0.end = 4
    lookup_module_0.start = 1

    # Sequence is generated correctly with valid inputs
    lookup_module_0.sanity_check()
    generated_list = list(lookup_module_0.generate_sequence())
    check_list = ["host01", "host02", "host03", "host04"]
    assert generated_list == check_list


# Generated at 2022-06-25 11:11:40.443782
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    # not sure how to check that sanity_check raises correct exception
    #lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:52.490192
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 0
    lookup_module_1.count = 0
    lookup_module_1.end = 0
    lookup_module_1.stride = 0
    lookup_module_1.format = "%d"
    list_generate_sequence_1 = lookup_module_1.generate_sequence()
    list_generate_sequence_1_str = map(str, list_generate_sequence_1)
    expected_output = "[]" 
    computed_output = str(list_generate_sequence_1_str)
    assert expected_output == computed_output  


# Generated at 2022-06-25 11:11:54.313954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:12:02.625453
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    # Simple case where the shortcut form is valid
    lookup_module = LookupModule()
    result = lookup_module.parse_simple_args("40-45")
    assert result == True

    # Case where the shortcut form is not valid
    lookup_module = LookupModule()
    result = lookup_module.parse_simple_args("-8")
    assert result == False

    # Simple case where the shortcut form is valid
    lookup_module = LookupModule()
    result = lookup_module.parse_simple_args("5-8")
    assert result == True

    # Case where the shortcut form is not valid
    lookup_module = LookupModule()
    result = lookup_module.parse_simple_args("__-_")
    assert result == False

    # Simple case where the shortcut form is valid
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:12:09.009038
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 0
    lookup_module.end = 4
    lookup_module.stride = 1
    lookup_module.format = '%d'
    result = lookup_module.generate_sequence()
    assert result == ['0', '1', '2', '3', '4']


# Generated at 2022-06-25 11:12:50.302238
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    # Example case
    lookup_module_0.reset()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.start = "5"
    lookup_module_0.stride = "1"
    lookup_module_0.sanity_check()

    # Example case
    lookup_module_0.reset()
    lookup_module_0.count = "5"
    lookup_module_0.end = "10"
    lookup_module_0.start = "1"
    lookup_module_0.stride = "1"
    with pytest.raises(AnsibleError) as ans_err0:
        lookup_module_0.sanity_check()

# Generated at 2022-06-25 11:12:54.439308
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    print("Testing method sanity_check of class LookupModule")
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    try:
        lookup_module_0.sanity_check()
        print("sanity_check method success")
    except Exception as e:
        print("Error in sanity_check method: " + str(e))


# Generated at 2022-06-25 11:12:57.309723
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()
    assert True


# Generated at 2022-06-25 11:13:04.977047
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    print('')
    lookup_module_1 = LookupModule()
    lookup_module_1.__init__()
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.sanity_check()

    lookup_module_1.count = None
    lookup_module_1.end = 3.14
    lookup_module_1.sanity_check()

    lookup_module_1.count = 1.1
    lookup_module_1.end = None
    lookup_module_1.sanity_check()

    lookup_module_1.count = 0
    lookup_module_1.end = None
    lookup_module_1.sanity_check()

    lookup_module_1.count = -13
    lookup_module_1.end = None
    lookup

# Generated at 2022-06-25 11:13:11.703414
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_1 = LookupModule()
    lookup_module_1.count = None
    lookup_module_1.end = 'val'
    lookup_module_2 = LookupModule()
    lookup_module_2.count = None
    lookup_module_2.end = 'val'
    lookup_module_3 = LookupModule()
    lookup_module_3.count = None
    lookup_module_3.end = 'val'
    lookup_module_4 = LookupModule()
    lookup_module_4.count = 'val'
    lookup_module_4.end = None
    lookup_module_5 = LookupModule()

# Generated at 2022-06-25 11:13:17.943017
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    term = "2-10/2"
    lookup_module = LookupModule()
    lookup_module.parse_simple_args(term)
    assert lookup_module.start == 2
    assert lookup_module.end == 10
    assert lookup_module.stride == 2


# Generated at 2022-06-25 11:13:27.679957
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # Populate the test data array
    test_data_0 = []
    test_data_0.append(["5",{"start":1,"end":5,"stride":1,"format":"%d"}])
    test_data_0.append(["5-8",{"start":5,"end":8,"stride":1,"format":"%d"}])
    test_data_0.append(["2-10/2",{"start":2,"end":10,"stride":2,"format":"%d"}])
    test_data_0.append(["4:host%02d",{"start":4,"end":4,"stride":1,"format":"host%02d"}])

# Generated at 2022-06-25 11:13:32.048287
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 1
    lookup_module_0.end = 1
    lookup_module_0.sanity_check()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.sanity_check()
    lookup_module_0.end = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:13:35.192392
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = None
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = None
    lookup_module_0.format = None
    method_result_0 = lookup_module_0.sanity_check()
    assert method_result_0 == None


# Generated at 2022-06-25 11:13:39.759046
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # Call method parse_simple_args of class LookupModule with argument "5"
    result_0 = lookup_module_0.parse_simple_args("5")

    # Check if result equals ["1","2","3","4","5"]
    if result_0 != ["1","2","3","4","5"]:
        print("Test Case 0: Failed")
        return
    print("Test Case 0: Success")


# Generated at 2022-06-25 11:14:02.710903
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = '0'
    # below is the expected result
    expected_0 = False
    # run the test and see if it matches the expected result
    result_0 = lookup_module_0.parse_simple_args(term_0)
    assert result_0 == expected_0

test_LookupModule_parse_simple_args()

# Generated at 2022-06-25 11:14:08.299898
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    start = 1
    end = 10
    stride = 1
    format = "%d"
    ansible_result = ["1","2","3","4","5", "6", "7", "8", "9", "10"]
    lookup_module = LookupModule()
    lookup_module.start = start
    lookup_module.end = end
    lookup_module.stride = stride
    lookup_module.format = format
    lookup_module.count = None
    lookup_module.sanity_check()
    assert lookup_module.generate_sequence() == ansible_result

    start = 10
    end = 1
    stride = -1
    format = "%d"
    ansible_result = ["10","9","8","7","6", "5", "4", "3", "2", "1"]
    lookup_module

# Generated at 2022-06-25 11:14:13.408882
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 1
    lookup_module_0.count = None
    lookup_module_0.end = 1
    lookup_module_0.start = 1
    try:
        lookup_module_0.sanity_check()
        assert False
    except AnsibleError as err_result:
        assert err_result.args == ("must specify count or end in with_sequence",)


# Generated at 2022-06-25 11:14:23.256089
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    test_input_0 = 'end'
    test_input_1 = 'start'
    test_input_2 = 'stride'
    try:
        lookup_module_0.sanity_check(
        )
    except AnsibleError:
        pass
    else:
        raise AssertionError('Raised AnsibleError unexpectedly.')
    lookup_module_0.start = 1
    lookup_module_0.end = 2
    lookup_module_0.count = 3
    lookup_module_0.stride = 1

# Generated at 2022-06-25 11:14:30.207384
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    assert lookup_module_0.parse_simple_args('7') == True

    assert lookup_module_0.parse_simple_args('8') == True

    assert lookup_module_0.parse_simple_args('9') == True

    assert lookup_module_0.parse_simple_args('10') == True

    assert lookup_module_0.parse_simple_args('11') == True

    assert lookup_module_0.parse_simple_args('12') == True

    assert lookup_module_0.parse_simple_args('13') == True

    assert lookup_module_0.parse_simple_args('14') == True

    assert lookup_module_0.parse_simple_args('15') == True

    assert lookup_module_0.parse_simple_args('16')

# Generated at 2022-06-25 11:14:36.234067
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    print("\nTesting parse_simple_args of class LookupModule")
    lookup_module_0 = LookupModule()
    term = "5-8"
    lookup_module_0.parse_simple_args(term)
    # Verify member variables
    assert lookup_module_0.format == "%d"
    assert lookup_module_0.count == None
    assert lookup_module_0.end == 8
    assert lookup_module_0.start == 5
    assert lookup_module_0.stride == 1
    print("parse_simple_args of class LookupModule: PASS")



# Generated at 2022-06-25 11:14:39.534728
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.stride = 1
    lookup_module_0.end = 9
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()
    lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:14:45.756119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['192.168.0.1']
    variables = {}
    kwargs = {}
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms, variables, **kwargs) == [u'192.168.0.1']


# Generated at 2022-06-25 11:14:46.914415
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()



# Generated at 2022-06-25 11:14:53.951244
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:33.445704
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start, lookup_module_0.end, lookup_module_0.stride, lookup_module_0.format = 1, 5, 1, '%d'
    try:
        assert ["1", "2", "3", "4", "5"] == list(lookup_module_0.generate_sequence())
        print("Unit test #1 for function 'generate_sequence' passed")
    except Exception as e:
        print("Unit test #1 for function 'generate_sequence' failed")
        print("Unhandled exception:", e)


# Generated at 2022-06-25 11:15:36.546533
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:39.692630
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.sanity_check() is None,\
        "Method sanity_check returns an unexpected value"


# Generated at 2022-06-25 11:15:42.554220
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    exception_raised = False
    try:
        lookup_module_0.sanity_check()
    except AnsibleError:
        exception_raised = True
    assert exception_raised == True


# Generated at 2022-06-25 11:15:46.004535
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 10
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    # Execution
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:52.720324
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 2
    lookup_module.sanity_check()

# Generated at 2022-06-25 11:15:57.619149
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    lookup_module_0.start = 0
    lookup_module_0.count = 2
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.format = "%d"
    lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:16:01.105423
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.count = 1
    lookup_module.start = 1
    lookup_module.stride = 1
    lookup_module.sanity_check()
    assert lookup_module.end == 1

test_case_0()

# Generated at 2022-06-25 11:16:08.284652
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    # Invalid arguments.
    try:
        lookup_module_0.sanity_check()
        raise Exception("Should have raised an exception")
    except AnsibleError:
        pass
    except:
        raise Exception("Should have raised an AnsibleError")

    lookup_module_0.count = 1
    try:
        lookup_module_0.sanity_check()
        raise Exception("Should have raised an exception")
    except AnsibleError:
        pass
    except:
        raise Exception("Should have raised an AnsibleError")

    lookup

# Generated at 2022-06-25 11:16:15.822650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # set 0:
    expected_1 = ["5"]
    actual_1 = lookup_module.run(['5'], None)
    assert actual_1 == expected_1

    # set 1:
    expected_1 = ["5", "6", "7", "8"]
    actual_1 = lookup_module.run(['5-8'], None)
    assert actual_1 == expected_1

    # set 2:
    expected_1 = ["2", "4", "6", "8", "10"]
    actual_1 = lookup_module.run(['2-10/2'], None)
    assert actual_1 == expected_1

    # set 3:
    expected_1 = ["host01", "host02", "host03", "host04"]