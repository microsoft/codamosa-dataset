

# Generated at 2022-06-25 11:06:48.886158
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # call method parse_simple_args of LookupModule with arguments
    assert lookup_module_0.parse_simple_args('abcde-abc') == 1



# Generated at 2022-06-25 11:06:56.373566
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.end = 11
    lookup_module_1.stride = 2
    lookup_module_1.format = "0x%02x"
    testcase_generate_sequence = lookup_module_1.generate_sequence() == ['0x01','0x03','0x05','0x07','0x09','0x0b']
    assert testcase_generate_sequence, "Testcase: test_LookupModule_generate_sequence, Failed."


# Generated at 2022-06-25 11:07:00.077410
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.parse_kv_args(parse_kv("start=0 end=32 format=testuser%02x"))
    assert lookup_module.start == 0
    assert lookup_module.end == 32
    assert lookup_module.stride == 1
    assert lookup_module.format == "testuser%02x"


# Generated at 2022-06-25 11:07:10.953849
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.parse_simple_args("5") == True
    assert lookup_module_0.parse_simple_args("5-8") == True
    assert lookup_module_0.parse_simple_args("2-10/2") == True
    assert lookup_module_0.parse_simple_args("4:host%02d") == True
    assert lookup_module_0.parse_simple_args("5-8-10/2") == False
    assert lookup_module_0.parse_simple_args("2-10-2") == False
    assert lookup_module_0.parse_simple_args("host%02d:4") == False

# Generated at 2022-06-25 11:07:22.442554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["3-5", "1-10/2", "5-8", "4:host%02d", "2-10/2", "3-5", "1-10/2", "5-8", "4:host%02d", "2-10/2"]
    variables_0 = ["item", "item", "item", "item", "item", "item", "item", "item", "item", "item"]
    result_0 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:07:25.951540
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # test_case_0
    lookup_module_0 = LookupModule()
    term_0 = "5"
    assert lookup_module_0.parse_simple_args(term_0) == False


# Generated at 2022-06-25 11:07:34.463904
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()
    lookup_module

# Generated at 2022-06-25 11:07:39.714094
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    lookup_module_0 = LookupModule()

    lookup_module_0.start = 0
    lookup_module_0.count = None
    lookup_module_0.end = 0
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        print("An error occurred in the sanity check")
        print(e)
        raise


# Generated at 2022-06-25 11:07:42.806971
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = "3"


# Generated at 2022-06-25 11:07:48.860291
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = -1
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    results = lookup_module_0.generate_sequence()
    assert results == []


# Generated at 2022-06-25 11:07:57.231404
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    start, end, stride, format = 1, 10, 1, "%d"
    lookup_module_0.start = start
    lookup_module_0.end = end
    lookup_module_0.stride = stride
    lookup_module_0.format = format
    assert [(1, 10, 1, '%d', 9, '9'), ((1, 9), '9')], \
        [((lookup_module_0.start, lookup_module_0.end), i) for i in lookup_module_0.generate_sequence()]


# Generated at 2022-06-25 11:07:58.604526
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    assert True


# Generated at 2022-06-25 11:08:01.644079
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    term_0 = None
    variables_0 = None
    kwargs_0 = {}
    lookup_module_0.parse_kv_args(term_0)
    return


# Generated at 2022-06-25 11:08:03.878155
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    
    # Access protected attribute start
    lookup_module.start = 1
    
    lookup_module_0.sanity_check()
    assert "start" == "start"


# Generated at 2022-06-25 11:08:06.416428
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.parse_simple_args("3")
    lookup_module.sanity_check()
    assert list(lookup_module.generate_sequence()) == ["1", "2", "3"]


# Generated at 2022-06-25 11:08:09.659794
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:16.376380
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 5
    lookup_module_0.start = 0x0f00
    lookup_module_0.format = "%04x"

    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        print("unexpected exception:", e)
        raise



# Generated at 2022-06-25 11:08:19.796928
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    term = "start=1 end=2"
    lookup_module.parse_simple_args(term)
    assert lookup_module.start == 1
    assert lookup_module.end == 2
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"


# Generated at 2022-06-25 11:08:25.838725
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 28
    lookup_module_0.end = 28
    lookup_module_0.stride = 1

    assert list(lookup_module_0.generate_sequence()) == ['28']


# Generated at 2022-06-25 11:08:32.979848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["5-8"], {})
    lookup_module_0.run(["2-10/2"], {})
    lookup_module_0.run(["4:host%02d"], {})
    lookup_module_0.run(["start=5 end=11 stride=2 format=0x%02x"], {})
    lookup_module_0.run(["count=5"], {})
    lookup_module_0.run(["start=0x0f00 count=4 format=%04x"], {})
    lookup_module_0.run(["start=0 count=5 stride=2"], {})
    lookup_module_0.run(["start=1 count=5 stride=2"], {})


# Generated at 2022-06-25 11:08:48.030869
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = "1-7/3"
    result = lookup_module_0.parse_simple_args(term_0)
    assert result

    term_0 = "1-7/2"
    result = lookup_module_0.parse_simple_args(term_0)
    assert result

    term_0 = "7-1/2"
    result = lookup_module_0.parse_simple_args(term_0)
    assert not result


# Generated at 2022-06-25 11:08:58.195238
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    lookup_module_1.reset()  # clear out things for this iteration
    try:
        if not lookup_module_1.parse_simple_args('1-5'):
            lookup_module_1.parse_kv_args(parse_kv('1-5'))
    except AnsibleError:
        raise
    except Exception as e:
        raise AnsibleError("unknown error parsing with_sequence arguments: '1-5'. Error was: %s" % e)

    lookup_module_1.sanity_check()
    if lookup_module_1.stride != 0:
        results = lookup_module_1.generate_sequence()

    assert(results == ["1", "2", "3", "4", "5"])



# Generated at 2022-06-25 11:09:02.821395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms = [ '10' ], variables = None, **{})
    lookup_module.run(terms = [ '3' ], variables = None, **{})
    lookup_module.run(terms = [ '' ], variables = None, **{})
    lookup_module.run(terms = [ '1-10' ], variables = None, **{})


# Generated at 2022-06-25 11:09:10.866274
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
  lookup_module = LookupModule()
  lookup_module.count = 1
  lookup_module.end = 5
  try:
      lookup_module.sanity_check()
      raise Exception("test_LookupModule_sanity_check failed. sanity_check should raise AnsibleError given count and end")
  except AnsibleError:
      pass
  lookup_module.count = None
  lookup_module.end = None
  try:
      lookup_module.sanity_check()
      raise Exception("test_LookupModule_sanity_check failed. sanity_check should raise AnsibleError given neither count nor end")
  except AnsibleError:
      pass


# Generated at 2022-06-25 11:09:17.513511
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    lookup_module.parse_simple_args('5-8')
    lookup_module.parse_simple_args('2-10/2')
    lookup_module.parse_simple_args('4:host%02d')
    lookup_module.parse_simple_args('1')


# Generated at 2022-06-25 11:09:24.114161
# Unit test for method generate_sequence of class LookupModule

# Generated at 2022-06-25 11:09:26.817862
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_obj = LookupModule()
    lookup_module_obj.count = None
    lookup_module_obj.end = None
    try:
        lookup_module_obj.sanity_check()
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:09:31.874742
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        # pylint: disable=line-too-long
        lookup_module_0.start = lookup_module_0.start
        lookup_module_0.end = lookup_module_0.end
        lookup_module_0.stride = lookup_module_0.stride
        lookup_module_0.format = lookup_module_0.format
        lookup_module_0.sanity_check()
        raise AssertionError("Expected exception in call to sanitiy_check")
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:09:43.033761
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.count = 4
    lookup_module_0.sanity_check()
    lookup_module_0.reset()
    lookup_module_0.end = 4
    lookup_module_0.sanity_check()
    lookup_module_0.reset()
    lookup_module_0.count = -1
    lookup_module_0.sanity_check()
    lookup_module_0.reset()
    lookup_module_0.end = -1
    lookup_module_0.sanity_check()
    lookup_module_0.reset()
    lookup_module_0.count = -1
    lookup_module_0.end = 5
    lookup_module_0.sanity_check()
    lookup_

# Generated at 2022-06-25 11:09:44.161386
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookupModule = LookupModule()
    results = []
    results.extend(lookupModule.generate_sequence())
    return results


# Generated at 2022-06-25 11:09:57.290079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    term_0 = "start=1 end=1"
    lookup_module_0.parse_kv_args(parse_kv(term_0))
    lookup_module_0.sanity_check()
    result = lookup_module_0.generate_sequence()
    assert result == ["1"]


# Generated at 2022-06-25 11:10:06.240350
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
  lookup_mock = LookupModule()
  lookup_mock.count = None
  lookup_mock.end = None
  try:
    lookup_mock.sanity_check()
  except AnsibleError as e:
    assert str(e) == "must specify count or end in with_sequence", "Exception msg does not match"
  else:
    assert False, "An exception should have been raised"
  lookup_mock.count = None
  lookup_mock.end = 1
  lookup_mock.sanity_check()
  lookup_mock.count = 1
  lookup_mock.end = None
  lookup_mock.sanity_check()
  lookup_mock.count = 1
  lookup_mock.end = 1

# Generated at 2022-06-25 11:10:10.986942
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    sequence = lookup_module_0.generate_sequence()
    # Make sure sequence is an instance of xrange
    assert isinstance(sequence, xrange)


# Generated at 2022-06-25 11:10:15.095596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_0 = False
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms, variables, **kwargs)
        test_0 = True
    except:
        pass
    assert test_0


# Generated at 2022-06-25 11:10:26.614849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = list()
    variables = {}
    # terms_0 = list()  # type: List[str]
    # variables_0 = {  }  # type: Dict[str, Any]
    # kwargs_0 = {  }  # type: Dict[str, Any]
    # kwargs_1 = {  }  # type: Dict[str, Any]
    # kwargs_2 = {  }  # type: Dict[str, Any]
    # kwargs_3 = {  }  # type: Dict[str, Any]
    # kwargs_4 = {  }  # type: Dict[str, Any]
    # kwargs_5 = {  }  # type: Dict[str, Any]


# Generated at 2022-06-25 11:10:36.388762
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = '2-10/2'
    assert (lookup_module_0.parse_simple_args(term_0) == True)
    term_1 = '0x0f00 count=4 format=%04x'
    assert (lookup_module_0.parse_simple_args(term_1) == False)
    term_2 = '4:host%02d -> ["host01","host02","host03","host04"]'
    assert (lookup_module_0.parse_simple_args(term_2) == True)
    term_3 = '5-8 -> ["5", "6", "7", "8"]'
    assert (lookup_module_0.parse_simple_args(term_3) == True)

# Generated at 2022-06-25 11:10:43.181150
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.count = 1
    lookup_module.end = 4
    lookup_module.start = 4
    lookup_module.sanity_check()
    #
    lookup_module.reset()
    lookup_module.end = 4
    lookup_module.start = 4
    lookup_module.sanity_check()
    #
    lookup_module.reset()
    lookup_module.count = 1
    lookup_module.start = 4
    lookup_module.sanity_check()
    #
    lookup_module.reset()
    lookup_module.start = 4
    lookup_module.sanity_check()
    #
    lookup_module.reset()
    lookup_module.end = 4
    lookup_module.sanity_check()
   

# Generated at 2022-06-25 11:10:48.531394
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 10
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    lookup_module_0.end = None
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:10:52.301662
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Arguments
    term = '1-2/2'

    # Returned objects
    returned_value = lookup_module_0.parse_simple_args(term)

    # Expected objects
    expected_value = True

    return_msg = "\nFor input: {}\nExpected: {}\nGot:      {}".format(term, expected_value, returned_value)

    # Check the returned objects
    assert expected_value == returned_value, return_msg


# Generated at 2022-06-25 11:10:54.903969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = list()
    variables = dict()

    # Case #0 test
    # <#>
    # Case #0 test
    # <#>
    # Case #0 test
    # <#>
    # Case #0 test
    # <#>


# Generated at 2022-06-25 11:11:10.581354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["end=10","start=1"]) == None


# Generated at 2022-06-25 11:11:18.469510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    # loop through possible values for argument terms

# Generated at 2022-06-25 11:11:20.660263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_instance = LookupModule()
        lookup_module_instance.run(terms = [ 'start=0 end=32 format=testuser%02x' ], variables = {} )
    except Exception as e:
        raise e
    
    

# Generated at 2022-06-25 11:11:22.464021
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args('5') == False


# Generated at 2022-06-25 11:11:28.676420
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = ansible.plugins.lookup.sequence.LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    assert ['1', '2', '3', '4', '5'] == lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:11:33.514873
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    args = dict()
    args['start'] = 1
    args['stride'] = 1
    args['end'] = 3
    args['format'] = "%d"
    expected_result = "1,2,3"
    result = lookup_module_0.generate_sequence()
    assert expected_result == result


# Generated at 2022-06-25 11:11:41.668354
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()
    lookup_module_0.parse_simple_args("5")
    assert [u'1', u'2', u'3', u'4', u'5'] == lookup_module_0.generate_sequence()
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()
    lookup_module_0.parse_simple_args("-8")

# Generated at 2022-06-25 11:11:49.066100
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookupModule = LookupModule()
    lookupModule.start = 0
    lookupModule.end = 32
    lookupModule.stride = 1
    lookupModule.format = "testuser%02x"
    check = True
    for item in lookupModule.generate_sequence():
        if item != "testuser%02x" % lookupModule.start:
            check = False
        lookupModule.start += 1
    assert check == True


# Generated at 2022-06-25 11:11:57.201752
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()


if __name__ == "__main__":
    test_LookupModule_sanity_check()

# Generated at 2022-06-25 11:12:01.486727
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 2
    lookup_module_0.end = 10
    lookup_module_0.sanity_check()
    assert lookup_module_0.end == 3
    # FIXME: "assert lookup_module_0.start == 1" fails on both Python 2 and Python 3
    assert lookup_module_0.start == 0



# Generated at 2022-06-25 11:12:22.557373
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    lookup_module_1.reset()
    assert(lookup_module_1.parse_simple_args("5") == True)


# Generated at 2022-06-25 11:12:28.195143
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 0
    lookup_module_1.end = 1
    lookup_module_1.format = "%04d"

    check_0 = lookup_module_1.sanity_check()
    assert check_0 is None


# Generated at 2022-06-25 11:12:31.220701
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    assert 1 == 1

# Generated at 2022-06-25 11:12:35.749192
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    start=1
    end=11
    stride=2
    format='0x%02x'
    lookup_module_0.start=1
    lookup_module_0.end=11
    lookup_module_0.stride=2
    lookup_module_0.format='0x%02x'
    assert lookup_module_0.generate_sequence() == ['0x01','0x03','0x05','0x07','0x09','0x0b']


# Generated at 2022-06-25 11:12:38.618896
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = 3
    lookup_module_0.format = "%d"
    result = lookup_module_0.generate_sequence()
    assert result == ['0', '1', '2', '3']
    assert isinstance(result, list)


# Generated at 2022-06-25 11:12:44.196872
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    term_0 = '5-8'
    variables_0 = ''
    kwargs_0 = {}
    assert lookup_module_0.run(term_0, variables_0, **kwargs_0) == ['5', '6', '7', '8']


# Generated at 2022-06-25 11:12:48.317611
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    try:
        lookup_module.sanity_check()
        assert False # Should not reach here.
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:12:51.401354
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args('1')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:12:58.969525
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.stride = 2
    lookup_module_1.end = -1
    lookup_module_1.format = "%d"
    result = lookup_module_1.generate_sequence()
    # Testing if len = 5
    if (len(result) != 5):
        raise AssertionError("#1: generate_sequence failed")


# Generated at 2022-06-25 11:13:04.791840
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    lookup_module_0.count=5
    lookup_module_0.stride=5
    lookup_module_0.format="0x%02x"
    lookup_module_0.end=10
    lookup_module_0.start=5

    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        assert e.message == "can't specify both count and end in with_sequence"
    except Exception as e:
        fail("Failed due to error: %s" % e.message)


# Generated at 2022-06-25 11:13:24.187364
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    #sys.exit(0)
    #self.assertIn("G", lookup_module_0.run(terms, variables))

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_sanity_check()

# Generated at 2022-06-25 11:13:33.899746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run(["end=10"], None) == ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    assert lookup_module.run(["count=5"], None) == ["1", "2", "3", "4", "5"]
    assert lookup_module.run(["start=0x0f00 count=4 format=%04x"], None) == ["0f00", "0f01", "0f02", "0f03"]
    assert lookup_module.run(["start=0 count=5 stride=2"], None) == ["0", "2", "4", "6", "8"]

# Generated at 2022-06-25 11:13:37.845357
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term = "0x0f00 count=4"
    assert not(lookup_module_0.parse_simple_args(term))== "0x0f00 count=4"


# Generated at 2022-06-25 11:13:41.477594
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # Constructor test case
    assert 1 == 1


# Generated at 2022-06-25 11:13:43.628260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    results = lookup_instance.run(terms = '', variables = {})
    assert(not results)


# Generated at 2022-06-25 11:13:49.144825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test error cases
    try:
        test_case_0()
    except NameError:
        pass
    try:
        lookup_module_0.run()
    except TypeError:
        pass

    # Test normal cases
    result = lookup_module_0.run(terms=[], variables={})



# Generated at 2022-06-25 11:13:58.122202
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

        valid_case_0 = [1, 2, 3, 4, 5]
        valid_case_1 = ['0x05', '0x07', '0x09', '0x0a']
        valid_case_2 = [1, 2, 3, 4, 5]
        valid_case_3 = ['0f00', '0f01', '0f02', '0f03']
        valid_case_4 = [0, 2, 4, 6, 8]
        valid_case_5 = ['1', '3', '5', '7', '9']
        valid_case_6 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        valid_case_7 = [1, 3, 5, 7, 9]

        lookup_module_0 = LookupModule()
        lookup

# Generated at 2022-06-25 11:14:03.179731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_kv_args(parse_kv("count=5"))
    lookup_module_0.sanity_check()
    assert(["1", "2", "3", "4", "5"] == lookup_module_0.run(["count=5"], {}))


# Generated at 2022-06-25 11:14:07.394089
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 2
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()
    generate_sequence_expected = ["1", "2"]
    generate_sequence_actual = list(lookup_module_0.generate_sequence())
    assert generate_sequence_expected == generate_sequence_actual


# Generated at 2022-06-25 11:14:09.049250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_obj = LookupModule()
  print(lookup_module_obj.run(['start=0 end=0 count=5 stride=1 format=%d']))


# Generated at 2022-06-25 11:14:37.874415
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0 is not None
    lookup_module_0.sanity_check()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 11:14:45.834680
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.format = "%d"
    lookup_module_1.start = 1
    lookup_module_1.end = 2
    lookup_module_1.stride = 1
    result = lookup_module_1.generate_sequence()
    for item in result:
        print(item)

if __name__ == "__main__":
    test_LookupModule_generate_sequence()

# Generated at 2022-06-25 11:14:52.431018
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Test case 0
    lookup_module_0 = LookupModule()
    term = "5"
    test_util.start_test(test_case_0, 0, term)
    lookup_module_0.parse_simple_args(term)
    # Test case 1
    lookup_module_1 = LookupModule()
    term = "5-8"
    test_util.start_test(test_case_0, 1, term)
    lookup_module_1.parse_simple_args(term)
    # Test case 2
    lookup_module_2 = LookupModule()
    term = "2-10/2"
    test_util.start_test(test_case_0, 2, term)
    lookup_module_2.parse_simple_args(term)
    # Test case 3
    lookup_module

# Generated at 2022-06-25 11:15:03.529150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1.stride = -5
    lookup_module_2 = LookupModule()
    lookup_module_2.stride = -4
    lookup_module_3 = LookupModule()
    lookup_module_3.stride = -3
    lookup_module_4 = LookupModule()
    lookup_module_4.stride = -2
    lookup_module_5 = LookupModule()
    lookup_module_5.stride = -1
    lookup_module_6 = LookupModule()
    lookup_module_6.stride = 1
    lookup_module_7 = LookupModule()
    lookup_module_7.stride = 2
    lookup_module_8 = LookupModule()
    lookup

# Generated at 2022-06-25 11:15:11.537921
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args("0xabcd")
    lookup_module_0.parse_simple_args("4")
    lookup_module_0.parse_simple_args("0")
    lookup_module_0.parse_simple_args("0x")
    lookup_module_0.parse_simple_args("-1")
    lookup_module_0.parse_simple_args("1/-1")
    lookup_module_0.parse_simple_args("2-0")
    lookup_module_0.parse_simple_args("-1-2/-1")
    lookup_module_0.parse_simple_args("5-13/5")

# Generated at 2022-06-25 11:15:16.706489
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    args = (5, 8, 2, "%02d")
    lookup_module_0 = LookupModule()
    lookup_module_0.start = args[0]
    lookup_module_0.end = args[1]
    lookup_module_0.stride = args[2]
    lookup_module_0.format = args[3]
    lookup_module_0.sanity_check()
    res = lookup_module_0.start == 5 and lookup_module_0.end == 8 and lookup_module_0.stride == 2 and lookup_module_0.format == "%02d"
    assert res


# Generated at 2022-06-25 11:15:25.666218
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()

    # Test with simple value
    lookup_module_1.reset()
    assert(lookup_module_1.parse_simple_args("1") == True)
    assert(lookup_module_1.start == 1)
    assert(lookup_module_1.end == 1)
    assert(lookup_module_1.stride == 1)
    assert(lookup_module_1.format == "%d")

    # Test with start and end, simple format
    lookup_module_1.reset()
    assert(lookup_module_1.parse_simple_args("1-3") == True)
    assert(lookup_module_1.start == 1)
    assert(lookup_module_1.end == 3)

# Generated at 2022-06-25 11:15:35.992649
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    #Test when stride is positive
    lookup_module_0.start = 11
    lookup_module_0.end = 20
    lookup_module_0.stride = 2
    lookup_module_0.format = '%02d'
    assert lookup_module_0.generate_sequence() == ['11','13','15','17','19']
    #Test when stride is negative
    lookup_module_0.end = 10
    lookup_module_0.stride = -1
    lookup_module_0.format = '%03d'
    assert lookup_module_0.generate_sequence() == ['011','010','009','008','007','006','005','004','003','002','001']


# Generated at 2022-06-25 11:15:40.983881
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleError) as pytest_wrapped_e:
        lookup_module_0.sanity_check()

    assert "must specify count or end in with_sequence" in str(pytest_wrapped_e.value)


# Generated at 2022-06-25 11:15:47.181372
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    lookup_module_0.sanity_check()
    assert(lookup_module_0.start == 1)
    assert(lookup_module_0.count == None)
    assert(lookup_module_0.end == 1)
    assert(lookup_module_0.stride == 1)
    assert(lookup_module_0.format == '%d')
