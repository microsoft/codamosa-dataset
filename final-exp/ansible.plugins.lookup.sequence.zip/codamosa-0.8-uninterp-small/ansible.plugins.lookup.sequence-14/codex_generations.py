

# Generated at 2022-06-25 11:06:44.968257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    ret = lookup_module_1.run(["", "", "", "", ""], ["", "", "", "", ""])
    assert ret == []


# Generated at 2022-06-25 11:06:52.946910
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_1 = LookupModule()
    lookup_module_1.parse_kv_args(parse_kv("start=1 end=11 stride=2 format=0x%02x"))
    assert [lookup_module_1.start, lookup_module_1.end, lookup_module_1.stride, lookup_module_1.format] == [1, 11, 2, "0x%02x"]


# Generated at 2022-06-25 11:07:00.473939
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.start = 1
    lookup_module_0.end = 2
    result = lookup_module_0.generate_sequence()
    assert result == ['1', '2']


# Generated at 2022-06-25 11:07:02.790751
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.sanity_check() is None


# Generated at 2022-06-25 11:07:06.821473
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.parse_kv_args(dict(start="0", end="1", stride="1", format="%d"))


# Generated at 2022-06-25 11:07:10.093423
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    args = {'start': '0', 'end': '10', 'stride': '1', 'format': '0x%02x'}
    lookup_module_0.parse_kv_args(args)

# Generated at 2022-06-25 11:07:17.199184
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args("1") == True
    assert lookup_module.parse_simple_args("1-3") == True
    assert lookup_module.parse_simple_args("1--3") == False
    assert lookup_module.parse_simple_args("-3") == False
    assert lookup_module.parse_simple_args("1-3/2") == True
    assert lookup_module.parse_simple_args("1-3/2:0x%x") == True
    assert lookup_module.parse_simple_args("1-3:0x%x") == False
    lookup_module.parse_simple_args("1-3/2:0x%x")
    assert lookup_module.start == 1
    assert lookup_module.end == 3

# Generated at 2022-06-25 11:07:23.503056
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()

    # Test 1: Positive scenario with start, end, stride parameters
    term = "start=0x001 end=0x003 stride=0x2"
    result = lookup_module.parse_simple_args(term)
    assert result == False
    assert lookup_module.start == 0x1
    assert lookup_module.end == 0x3
    assert lookup_module.stride == 0x2
    
    # Test 2: Positive scenario with start, end, stride parameters
    term = "0x02-0x05/0x2"
    result = lookup_module.parse_simple_args(term)
    assert result == True
    assert lookup_module.start == 0x2
    assert lookup_module.end == 0x5
    assert lookup_module.stride == 0x2

   

# Generated at 2022-06-25 11:07:28.338798
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.stride = 1
    lookup_module_0.end = 0
    lookup_module_0.format = "%d"
    res = lookup_module_0.generate_sequence()
    assert res == ['0']


# Generated at 2022-06-25 11:07:32.969878
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.sanity_check()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.sanity_check()
    lookup_module.stride = 2
    lookup_module.sanity_check()
    lookup_module.end = -1
    lookup_module.sanity_check()
    return "success"


# Generated at 2022-06-25 11:07:47.976927
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    term_1 = "5"
    assert lookup_module_1.parse_simple_args( term_1 ) == True
    assert lookup_module_1.format == "%d"
    assert lookup_module_1.stride == 1
    assert lookup_module_1.end == 5
    assert lookup_module_1.start == 1
    assert lookup_module_1.count == None

    term_2 = "5-8"
    assert lookup_module_1.parse_simple_args( term_2 ) == True
    assert lookup_module_1.format == "%d"
    assert lookup_module_1.stride == 1
    assert lookup_module_1.end == 8
    assert lookup_module_1.start == 5
    assert lookup_module_1.count == None

# Generated at 2022-06-25 11:07:51.608693
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    return_value_0 = lookup_module_0.sanity_check()
# assert return_value_0 == None


# Generated at 2022-06-25 11:08:03.845113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    terms = ""
    parameters = {"end": 7, "start": 2, "stride": 5}
    lookup_module_0.parse_kv_args(parameters)

    if (lookup_module_0.start == 2 and lookup_module_0.end == 7 and lookup_module_0.format == "%d" and lookup_module_0.stride == 5):
        ans = True
    else:
        ans = False
    print("Testing method run of class LookupModule ... [%s]" % ("PASS" if ans else "FAIL"))


# Generated at 2022-06-25 11:08:10.380797
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    term = 2-10/2
    # if self.stride >= 0:
    lookup_module_0.stride = 2
    # elif self.stride < 0:
    # lookup_module_0.stride = -1
    # else:
    # lookup_module_0.stride = 0
    # numbers = xrange(self.start, self.end + adjust, self.stride)
    lookup_module_0.start = 2
    lookup_module_0.end = 10
    lookup_module_0.format = "%d"
    # for i in numbers:
    # try:
    # formatted = self.format % i
    # yield formatted
    # except (ValueError, TypeError):
    # raise AnsibleError(
    # "problem formatting %

# Generated at 2022-06-25 11:08:20.315705
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.count = 4
    lookup_module_1.start = 8
    lookup_module_1.stride = 2
    lookup_module_1.sanity_check()
    lookup_module_2 = LookupModule()
    lookup_module_2.count = -8
    lookup_module_2.start = 0
    lookup_module_2.stride = -3
    lookup_module_2.sanity_check()
    lookup_module_3 = LookupModule()
    lookup_module_3.count = 2
    lookup_module_3.start = -9
    lookup_module_3.sanity_check()
    lookup_module_4 = LookupModule()
    lookup_module_4.end = 3
    lookup_module_4.start

# Generated at 2022-06-25 11:08:27.059561
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = 3
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    assert_expect(lookup_module_0.sanity_check, None)


# Generated at 2022-06-25 11:08:30.370847
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.generate_sequence() == None


# Generated at 2022-06-25 11:08:39.313955
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 4
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    generator = lookup_module_0.generate_sequence()
    assert (generator.__next__() == '1')
    assert (generator.__next__() == '2')
    assert (generator.__next__() == '3')
    assert (generator.__next__() == '4')
    try:
        generator.__next__()
        assert False
    except StopIteration: assert True


# Generated at 2022-06-25 11:08:46.621706
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.count = 1
    lookup_module_0.start = 1

    lookup_module_0.sanity_check()
    assert lookup_module_0.count is None
    assert lookup_module_0.end == 2
    assert lookup_module_0.stride == 1


# Generated at 2022-06-25 11:08:53.244308
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = None
    lookup_module.start = 1
    assert lookup_module.sanity_check() == None
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = None
    lookup_module.start = 2
    assert lookup_module.sanity_check() == None
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = None
    lookup_module.start = 3
    assert lookup_module.sanity_check() == None
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = None
    lookup_module.start = 4

# Generated at 2022-06-25 11:08:57.548480
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    test_case_0()


# Generated at 2022-06-25 11:09:00.144190
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:02.039861
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:09:11.175774
# Unit test for method generate_sequence of class LookupModule

# Generated at 2022-06-25 11:09:14.742791
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:09:19.143605
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    assert not lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:24.819120
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []



# Generated at 2022-06-25 11:09:31.858943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms=['5'], variables={}) == ["5"]
    assert lookup_module_1.run(terms=['5-8'], variables={}) == ["5-8"]
    assert lookup_module_1.run(terms=['2-10/2'], variables={}) == ["2-10/2"]
    assert lookup_module_1.run(terms=['4:host%02d', '5:host2%02d'], variables={}) == ["4:host%02d","5:host2%02d"]

# Generated at 2022-06-25 11:09:39.306375
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 6
    lookup_module.count = None
    lookup_module.end = 8
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert (list(lookup_module.generate_sequence()) == ['6', '7', '8'])


# Generated at 2022-06-25 11:09:49.389931
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        assert "did not diterminate between count and end" in str(e)
    lookup_module_0.count = 1
    lookup_module_0.end = 0
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        assert "did not diterminate between count and end" in str(e)

    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 10
    lookup_module_0.start = 0

# Generated at 2022-06-25 11:10:00.631601
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    term = '0'
    lookup_module = LookupModule()
    assert False == lookup_module.parse_simple_args(term)


# Generated at 2022-06-25 11:10:03.137885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['']
    variables_1 = {}
    lookup_module_1.run(terms_1, variables_1)


# Generated at 2022-06-25 11:10:11.077222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['start=0 end=32 format=testuser%02x']

    # Test case with argument terms using default values for all args
    result_0 = lookup_module_0.run(terms_0)

    assert isinstance(result_0, list) is True

# Generated at 2022-06-25 11:10:14.159251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [5, 10, 1]
    variables_1 = None
    results_1 = [1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert result_1 == results_1

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:10:15.774242
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.sanity_check()
    assert result is None


# Generated at 2022-06-25 11:10:25.010501
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # Try to test the case where end is less than start
    lookup_module_0.start = 1
    lookup_module_0.stride = 2
    lookup_module_0.end = -5
    lookup_module_0.format = "%d"
    exception_raised = False
    try:
        lookup_module_0.reset()
        #Call the method
        result = lookup_module_0.generate_sequence()
    except Exception as e:
        exception_raised = True
    assert exception_raised == True



# Generated at 2022-06-25 11:10:29.819766
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.count = 1
    lookup.stride = 10
    lookup.start = 2
    lookup.end = 3
    lookup.sanity_check()
    assert lookup.end == 12
    assert lookup.count == None


# Generated at 2022-06-25 11:10:33.085266
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    assert lookup_module_1
    lookup_module_1.run(["1-1"], [], [])
    assert lookup_module_1


# Generated at 2022-06-25 11:10:37.516247
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Tests the generate_sequence method of the LookupModule class

    # Assert if the generate_sequence method returns the required results
    obj = LookupModule()
    obj.start = 7
    obj.end = 9
    obj.stride = 1
    obj.format = '%02x'
    assert list(obj.generate_sequence()) == ['07', '08', '09']



# Generated at 2022-06-25 11:10:42.071084
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    lookup_module_0 = LookupModule()

    lookup_module_0.start = 0
    lookup_module_0.count = None
    lookup_module_0.end = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'

    assert lookup_module_0.generate_sequence() == ['0', '1', '2', '3', '4', '5']


# Generated at 2022-06-25 11:11:00.910822
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.sanity_check()
    lookup_module_1 = LookupModule()
    lookup_module_1.reset()
    lookup_module_1.sanity_check()
    lookup_module_2 = LookupModule()
    lookup_module_2.reset()
    lookup_module_2.sanity_check()
    lookup_module_3 = LookupModule()
    lookup_module_3.reset()
    lookup_module_3.sanity_check()
    lookup_module_4 = LookupModule()
    lookup_module_4.reset()
    lookup_module_4.sanity_check()
    lookup_module_5 = LookupModule()
    lookup_module_5.reset()
    lookup

# Generated at 2022-06-25 11:11:04.867784
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Instantiating LookupModule object
    lookup_module_0 = LookupModule()
    # Calling sanity check method
    lookup_module_0.sanity_check()

if __name__ == '__main__':
    test_LookupModule_sanity_check()

# Generated at 2022-06-25 11:11:10.500505
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 5
    lookup_module_0.count = None
    lookup_module_0.end = 8
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    assert list(lookup_module_0.generate_sequence()) == ['5', '6', '7', '8']
    lookup_module_0.start = 0
    lookup_module_0.count = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.format = '%d'
    assert list(lookup_module_0.generate_sequence()) == []


# Generated at 2022-06-25 11:11:18.412398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n\nSTART: test_LookupModule_run")

    # These variables are used in tests.
    x = 0
    assert x == 0
    test_terms = [
        'start=0 end=32 format=testuser%02x',
        'start=4 end=16 stride=2',
        'count=4',
        'start=10 end=0 stride=-1',
        'start=1 end=10'
    ]
    test_variables = {
        u'end_at': 10
    }

    # The test occurs here.
    # Method call on the LookupModule class object.
    result = lookup_module_0.run(test_terms, test_variables)

    # These variables are used in tests.
    x = 1
    assert x == 1

# Generated at 2022-06-25 11:11:19.193234
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    assert True

# Generated at 2022-06-25 11:11:23.935486
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:28.423268
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 2
    lookup_module_0.stride = 3
    lookup_module_0.format = '%d'
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:36.662812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["5", "5-8", "2-10/2", "4:host%02d"]
    variables_1 = ["start", "end", "count", "stride"]
    expected_1 = [["1", "2", "3", "4", "5"], ["5", "6", "7", "8"], ["2", "4", "6", "8", "10"], ["host01", "host02", "host03", "host04"]]
    actual_1 = lookup_module_1.run(terms_1, variables_1)
    assert actual_1 == expected_1



# Generated at 2022-06-25 11:11:38.027003
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:11:44.647053
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    lookup_module.parse_simple_args("0x2-0x7")
    assert lookup_module.start == 2
    assert lookup_module.end == 7
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    lookup_module.parse_simple_args("5-6")
    assert lookup_module.start == 5
    assert lookup_module.end == 6
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    lookup_module.parse_simple_args("10/2")
    assert lookup_module.start == 1
    assert lookup_module.end == 10
    assert lookup_module.stride == 2
    assert lookup_module.format == "%d"
    lookup_module.parse_simple

# Generated at 2022-06-25 11:12:02.129804
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    str_0 = '5-8'

    # Call method parse_simple_args of class LookupModule
    result = lookup_module_0.parse_simple_args(str_0)

    hasattr(lookup_module_0, 'start')
    assert lookup_module_0.start == 5
    hasattr(lookup_module_0, 'end')
    assert lookup_module_0.end == 8
    assert result == True

    str_0 = '2-10/2'

    # Call method parse_simple_args of class LookupModule
    result = lookup_module_0.parse_simple_args(str_0)

    hasattr(lookup_module_0, 'start')
    assert lookup_module_0.start == 2

# Generated at 2022-06-25 11:12:04.425910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run('', '', '')
    assert var is None


# Generated at 2022-06-25 11:12:07.787488
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:12:10.868410
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    _LookupModule_0 = LookupModule()
    _LookupModule_0.count = None
    _LookupModule_0.end = None
    _LookupModule_0.sanity_check()


# Generated at 2022-06-25 11:12:21.545935
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    from unittest import TestCase
    from nose.tools import raises, timed
    from ansible.errors import AnsibleError

    class TestLookupModule(TestCase):
        def test_start(self):
            lookup_module_0 = LookupModule()
            lookup_module_0.start = 1
            lookup_module_0.count = None
            lookup_module_0.end = 'None'
            lookup_module_0.stride = 1
            lookup_module_0.format = '%d'
            var_0 = lookup_reset()
            assert var_0 == lookup_module_0.start

        def test_count(self):
            lookup_module_0 = LookupModule()
            lookup_module_0.start = 1
            lookup_module_0.count = 'None'

# Generated at 2022-06-25 11:12:31.977477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = ["start=0 end=100"]
    lookup_module_0 = LookupModule()

    # Call method run
    var_return_0 = lookup_module_0.run(args_0, None)

    # Check if var_return_0 equals ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45',

# Generated at 2022-06-25 11:12:36.676288
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:37.444393
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    assert lookup_stride >= 0


# Generated at 2022-06-25 11:12:47.744469
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.reset()
    var_2 = lookup_module_0.start = 1
    var_3 = lookup_module_0.count = None
    var_4 = lookup_module_0.end = None
    var_5 = lookup_module_0.stride = 1
    var_6 = lookup_module_0.format = "%d"
    var_7 = lookup_module_0.count is None and lookup_module_0.end is None
    var_8 = lookup_module_0.count is not None and lookup_module_0.end is not None
    var_9 = lookup_module_0.count is not None
    var_10 = var_9 != 0
    if (var_10):
        var_11 = lookup_module

# Generated at 2022-06-25 11:12:50.727921
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()



# Generated at 2022-06-25 11:13:10.360932
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    results = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    results.append(isinstance(var_0, LookupModule))
    return results


# Generated at 2022-06-25 11:13:16.558706
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 3
    lookup_module_0.end = 4
    lookup_module_0.stride = 5
    lookup_module_0.format = "0x%02x"
    try:
        lookup_module_0.sanity_check()
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:13:21.293322
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    # should raise an error
    try:
        lookup_module_1.sanity_check()
    except AnsibleError:
        pass

    lookup_module_1.count = 1
    lookup_module_2.end = 1
    try:
        lookup_module_1.sanity_check()
    except AnsibleError:
        pass

    lookup_module_1.stride = -1
    lookup_module_1.count = None
    try:
        lookup_module_1.sanity_check()
    except AnsibleError:
        pass

    lookup_module_1.end = -1
    lookup_module_1.start = 10

# Generated at 2022-06-25 11:13:23.046637
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:13:31.860824
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    var_0 = LookupModule()
    var_0.start = 1
    var_0.end = 6
    var_0.stride = 1
    var_0.format = "%d"
    var_0.sanity_check()
    var_1 = var_0.stride >= 0
    var_0.adjust = (1 if var_1 else -1)
    var_0.numbers = xrange(1, 7, 1)
    for var_2 in var_0.numbers:
        var_3 = var_0.format % var_2
        pass


# Generated at 2022-06-25 11:13:32.650217
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    pass


# Generated at 2022-06-25 11:13:41.283732
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    lookup.reset()
    lookup.start = 1
    lookup.count = None
    lookup.end = 5
    lookup.stride = 1
    lookup.format = "%d"
    lookup.sanity_check()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == 5
    assert lookup.stride == 1
    assert lookup.format == "%d"
    # AssertionError: None != 5
    lookup.reset()
    lookup.start = 1
    lookup.count = None
    lookup.end = None
    lookup.stride = 1
    lookup.format = "%d"
    lookup.sanity_check()
    assert lookup.start == 1
    assert lookup.count == None
    assert lookup.end == None

# Generated at 2022-06-25 11:13:43.839699
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:13:55.489440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    
    # Test 0
    try:
        var_1 = parse_kv("")
    except AnsibleError as err:
        pass
    else:
        assert False, "Expected error not raised"
    
    # Test 1
    try:
        var_1 = parse_kv("f=b")
    except AnsibleError as err:
        pass
    else:
        assert False, "Expected error not raised"
    
    # Test 2
    try:
        var_1 = parse_kv("=b")
    except AnsibleError as err:
        pass
    else:
        assert False, "Expected error not raised"
    
    # Test 3

# Generated at 2022-06-25 11:13:58.138587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    assert var_0 == None # assert expression



# Generated at 2022-06-25 11:14:20.942361
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    test_range = [6, 5, 4, 3]
    assert test_range == list(lookup_module.generate_sequence())

# Generated at 2022-06-25 11:14:22.421474
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:28.202478
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0.count = 1
    lookup_module_0.end = 1
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = "1"
    try:
        var_0 = lookup_module_0.sanity_check()
    except AnsibleError as error:
        if error.message == "must specify count or end in with_sequence":
            pass
        else:
            assert False



# Generated at 2022-06-25 11:14:30.384090
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = lookup_module_0.end
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:14:32.039619
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    with testtools.ExpectedException(AnsibleError):
        lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:34.353049
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # Unit test for method parse_simple_args of class LookupModule

# Generated at 2022-06-25 11:14:37.129294
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    #You can test the exceptions with this:
    try:
        lookup_sanity_check()
    except AnsibleError as e:
        assert str(e) == "expected exception message"

# Generated at 2022-06-25 11:14:47.857309
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:14:55.750524
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 10
    lookup_module_0.stride = 2
    lookup_module_0.format = "%d"
    var_0 = lookup_module_0.sanity_check()
    var_1 = lookup_module_0.generate_sequence()
    assert var_1[0] == "1"



# Generated at 2022-06-25 11:14:58.472525
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = 2
    lookup_module_0.end = 3
    lookup_module_0.stride = 4
    lookup_module_0.format = 5
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:19.717914
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lu_module_obj = LookupModule()
    # Try to call LookupModule.sanity_check with args (self,)
    test_function_1 = lu_module_obj.sanity_check
    test_function_1()


# Generated at 2022-06-25 11:15:22.584739
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.end = 0
    var_0 = lookup_module_0.sanity_check()
    #TODO:
#     raise NotImplementedError

# Generated at 2022-06-25 11:15:25.724922
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    count = 5
    end = 7
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_0.count = count
    lookup_module_0.end = end
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:28.534158
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.end = None
    lookup_module.count = None
    lookup_module.start = 1
    lookup_module.stride = 1

    # Execution
    with pytest.raises(AnsibleError):
        lookup_module.sanity_check()

# Generated at 2022-06-25 11:15:36.185719
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.end = 5
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_sanity_check()

# Generated at 2022-06-25 11:15:39.691196
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_sanity_check()
    var_1 = lookup_generate_sequence()


# Generated at 2022-06-25 11:15:41.436758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance_0 = LookupModule()
    lookup_instance_0.run(terms=[], variables={}, **kwargs)


# Generated at 2022-06-25 11:15:44.740031
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.generate_sequence()
    assert var_1 != None


# Generated at 2022-06-25 11:15:54.515110
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()

    lookup_module_1 = LookupModule()
    lookup_module_1.count = 1
    lookup_module_1.end = None
    lookup_module_1.sanity_check()

    lookup_module_2 = LookupModule()
    lookup_module_2.count = None
    lookup_module_2.end = 3
    lookup_module_2.sanity_check()

    lookup_module_3 = LookupModule()
    lookup_module_3.count = 1
    lookup_module_3.end = 2
    lookup_module_3.sanity_check()

    lookup_module_4 = LookupModule()

# Generated at 2022-06-25 11:15:56.413912
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()
