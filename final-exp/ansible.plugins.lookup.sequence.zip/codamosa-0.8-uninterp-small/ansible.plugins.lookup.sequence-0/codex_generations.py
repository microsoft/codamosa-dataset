

# Generated at 2022-06-25 11:06:54.067100
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 5
    lookup_module_0.stride = -1
    lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:07:00.346552
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.parse_kv_args({'start': "5"})
    lookup_module.parse_kv_args({'end': "5"})
    lookup_module.parse_kv_args({'stride': "5"})
    lookup_module.parse_kv_args({'format': "5"})

# Generated at 2022-06-25 11:07:10.685979
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    i_0 = lookup_module_1.parse_simple_args('0')
    assert i_0 == False
    i_1 = lookup_module_1.parse_simple_args('10')
    assert i_1 == False
    i_2 = lookup_module_1.parse_simple_args('10-15')
    assert i_2 == True
    i_3 = lookup_module_1.parse_simple_args('10-15/2')
    assert i_3 == True
    i_4 = lookup_module_1.parse_simple_args('10-15/2:test%02x')
    assert i_4 == True
    # test_case_0()
    test_case_0()

# Generated at 2022-06-25 11:07:17.673373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_1 = {'start':'0', 'end':'32', 'format':'testuser%02x'}
    term_2 = {'start':'4', 'end':'16', 'stride':'2'}
    term_3 = {'count':'4'}
    term_4 = {'start':'10', 'end':'0', 'stride':'-1'}
    term_5 = {'start':'1', 'end':'{{ end_at }}'}
    terms = [term_1, term_2, term_3, term_4, term_5]
    variables = {'end_at':'10'}
    lookup_module_1.run(terms, variables)

test_LookupModule_run()

# Generated at 2022-06-25 11:07:31.150561
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Case 0: start = end = 1; count = None; stride = 1; format = '%d'
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.count = None
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    lookup_module_0.sanity_check()
    assert lookup_module_0.start == 1
    assert lookup_module_0.end == 1
    assert lookup_module_0.count == None
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == '%d'


# Generated at 2022-06-25 11:07:33.183779
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # look_up_module_0 = LookupModule()
    # look_up_module_0.generate_sequence()
    test_case_0()


# Generated at 2022-06-25 11:07:38.510848
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 0
    lookup_module_0.end = 10
    lookup_module_0.format = "%d"
    lookup_module_0.stride = 1

    gen_seq_result = lookup_module_0.generate_sequence()

    assert(len(gen_seq_result) == 11)
    assert(gen_seq_result[0] == "0")
    assert(gen_seq_result[3] == "3")
    assert(gen_seq_result[-1] == "10")


# Generated at 2022-06-25 11:07:49.832687
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()

    # Tests
    lookup_module.start = 1
    lookup_module.end = 3
    lookup_module.stride = 1
    lookup_module.format = "%d"
    expected = ["1", "2", "3"]
    result = lookup_module.generate_sequence()
    assert result == expected, "Expected %s but got %s" % (expected, result)

    lookup_module.start = 0x0f00
    lookup_module.end = 0x0f04
    lookup_module.stride = 1
    lookup_module.format = "%04x"
    expected = ["0f00", "0f01", "0f02", "0f03", "0f04"]
    result = lookup_module.generate_sequence()

# Generated at 2022-06-25 11:07:54.365165
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = int()
    lookup_module_0.end = int()
    lookup_module_0.stride = int()
    lookup_module_0.format = str()

    # Call method
    result = lookup_module_0.generate_sequence()

    assert result is not None


# Generated at 2022-06-25 11:08:04.970764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = [
        [
            '',
            '',
            '',
            '',
            '',
            '',
            '',
        ],
    ]
    variables_3 = {
        'a': [
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
        ],
        'b': [
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
        ],
    }
    _list_4 = lookup_module_1.run(terms_2, variables_3)
    assert _list_4 == []

    lookup_

# Generated at 2022-06-25 11:08:15.290625
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    with raises(AnsibleError, match=r"must specify count or end in with_sequence"):
        lookup_module_0.sanity_check()
    lookup_module_0.end = 0


# Generated at 2022-06-25 11:08:21.797217
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    term = {"start": 1, "end": 5, "format": '%3d', "stride": 2}
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=term)
    if not result == "101":
        raise AssertionError("Result should be 101 but is ", result)


# Generated at 2022-06-25 11:08:29.438359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    pseudo_terms_1 = [
        "0-4",
    ]
    pseudo_variables_1 = {
        'sequence': 'start=10 count=5'
    }
    result_1 = lookup_module_1.run(pseudo_terms_1, pseudo_variables_1)
    print (result_1)
    #assert result_1 == [
    #    '1',
    #    '2',
    #    '3',
    #    '4',
    #    '5'
    #]



# Generated at 2022-06-25 11:08:33.523512
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    args_0 = dict()
    args_0['count'] = ['0x3f8']
    args_0['start'] = ['0x3f8']
    args_0['end'] = ['0x3f8']
    args_0['stride'] = ['0x3f8']
    lookup_module_0.parse_kv_args(args_0)
    

# Generated at 2022-06-25 11:08:43.752858
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.end = 5
    lookup_module_1.stride = 1
    lookup_module_1.format = '%d'
    assert list(lookup_module_1.generate_sequence()) == ["1", "2", "3", "4", "5"]

    lookup_module_2 = LookupModule()
    lookup_module_2.start = 5
    lookup_module_2.end = 9
    lookup_module_2.stride = 2
    lookup_module_2.format = '%d'
    assert list(lookup_module_2.generate_sequence()) == ["5", "7", "9"]

    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 11:08:50.763027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """test run method of LookupModule"""
    lookup_module_0 = LookupModule()
    terms_0 = ['start=2 end=5 stride=2']
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == ["2", "4"]
    terms_0 = ['start=1 end=5 stride=2']
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == ["1", "3", "5"]
    terms_0 = ['start=1 end=4']
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == ["1", "2", "3", "4"]
    terms_0 = ['start=0 count=4']
    variables_0 = {}

# Generated at 2022-06-25 11:08:56.876282
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module = LookupModule()
    lookup_module.parse_kv_args(dict(count='5', start='3', stride='2'))
    assert lookup_module.start == 3
    assert lookup_module.count == 5
    assert lookup_module.stride == 2


# Generated at 2022-06-25 11:09:01.266187
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args("5")
    lookup_module_0.parse_simple_args("5-8")
    lookup_module_0.parse_simple_args("2-10/2")
    lookup_module_0.parse_simple_args("4:host%02d")


# Generated at 2022-06-25 11:09:05.367622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = "test_term_0"
    variables_0 = "test_variables_0"
    kwargs_0 = "test_kwargs_0"
    ret_val_0 = lookup_module_0.run(term_0, variables_0, **kwargs_0)
    assert ret_val_0 == ["0"]


# Generated at 2022-06-25 11:09:08.952357
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 1
    lookup_module_0.end = 5
    lookup_module_0.start = 1
    lookup_module_0.format = '%d'
    lookup_module_0.count = None
    result = lookup_module_0.generate_sequence()
    assert ["1", "2", "3", "4", "5"] == result


# Generated at 2022-06-25 11:09:17.754723
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:22.373977
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = 10
    lookup_module_0.stride = 1
    lookup_module_0.format = '%02d'
    expected = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10']
    actual = list(lookup_module_0.generate_sequence())
    assert expected == actual


# Generated at 2022-06-25 11:09:23.778327
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    assert True

# Generated at 2022-06-25 11:09:26.285686
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.count = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.format = "%d"
    assert_raises(AnsibleError, lookup_module_0.sanity_check)



# Generated at 2022-06-25 11:09:27.352939
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    output_val_0 = []
    output_val_0.append(test_case_0())
    return output_val_0


# Generated at 2022-06-25 11:09:34.267833
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:39.346601
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup = LookupModule()
    # Test setup
    lookup.start = 1
    lookup.end = 2
    lookup.stride = 2
    # Test execution
    lookup.sanity_check()
    # Test verification
    # Test cleanup
    # Test teardown
    del lookup


# Generated at 2022-06-25 11:09:49.388851
# Unit test for method sanity_check of class LookupModule

# Generated at 2022-06-25 11:09:54.185316
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 4
    lookup_module_0.format = "%02d"
    lookup_module_0.stride = 1
    assert lookup_module_0.generate_sequence() == ['01', '02', '03', '04']

# Generated at 2022-06-25 11:10:03.968513
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 0
    lookup_module_1.count = None
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = "%d"
    sequence_result_1 = lookup_module_1.generate_sequence()

# Generated at 2022-06-25 11:10:16.074362
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.count = 4
    lookup_module_0.stride = 1

    # Call method
    e = None
    try:
        lookup_module_0.sanity_check()
    except Exception as exception:
        e = exception
    assert type(e) == AnsibleError



# Generated at 2022-06-25 11:10:22.284942
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.stride = 0
    lookup_module_1.start = 1
    lookup_module_1.end = 1
    lookup_module_1.count = None
    var_1 = lookup_sanity_check()


# Generated at 2022-06-25 11:10:24.604708
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:10:33.490778
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    var_1 = parse_kv("start=1 end=5")
    lookup_module_0.parse_kv_args(var_1)
    var_2 = parse_kv("start=1 end=5 stride=2")
    lookup_module_0.parse_kv_args(var_2)
    var_3 = parse_kv("start=1 end=5 format=0x%04x")
    lookup_module_0.parse_kv_args(var_3)


# Generated at 2022-06-25 11:10:40.969458
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:10:44.570571
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:10:47.598767
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:10:56.820791
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = '5' # test
    var_1 = lookup_module_0.parse_simple_args(var_0)
    assert var_1 == [1, 2, 3, 4, 5]
    var_0 = '0-5' # test
    var_1 = lookup_module_0.parse_simple_args(var_0)
    assert var_1 == [0, 1, 2, 3, 4, 5]
    var_0 = '0-5/2' # test
    var_1 = lookup_module_0.parse_simple_args(var_0)
    assert var_1 == [0, 2, 4]
    var_0 = 'count=5' # test

# Generated at 2022-06-25 11:11:02.359190
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_generate_sequence(self)
    return result

# Generated at 2022-06-25 11:11:06.736555
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()
    assert_equals(var_0, "assert_equals(var_0, )")

# Generated at 2022-06-25 11:11:16.727288
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_kv_args(parse_kv("start=2 end=3"))
    lookup_module_0.sanity_check()
    assert lookup_module_0.end == 3
    assert lookup_module_0.start == 2
    lookup_module_0.parse_kv_args(parse_kv("start=2 count=3"))
    lookup_module_0.sanity_check()
    assert lookup_module_0.end == 4
    assert lookup_module_0.start == 2


# Generated at 2022-06-25 11:11:20.734278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 11:11:22.545777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 11:11:24.751316
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()

# Generated at 2022-06-25 11:11:27.998688
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    # Test exception bad formatting string
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        pass



# Generated at 2022-06-25 11:11:29.560468
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:31.328346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('', '', '')


# Generated at 2022-06-25 11:11:34.092597
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:11:42.016868
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.start = 1
    var_1 = lookup_module_0.count = None
    var_2 = lookup_module_0.end = None
    var_3 = lookup_module_0.stride = 1
    var_4 = lookup_module_0.format = "%d"
    assert test("_and7(var_0,_and6(var_1,var_2))", "[assert]")
    assert test("_and7(var_0,_and6(var_1,var_2))", "[assert]")
    assert test("_and7(var_0,_and6(var_1,var_2))", "[assert]")
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:48.069183
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:11:59.002793
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    """
    Test generate_sequence() of class LookupModule
    """
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_term("start=0 end=1")
    var_2 = lookup_result(["0", "1"])
    var_3 = test_static(var_1, var_2)
    print("Test generate_sequence() of class LookupModule:")
    print("var_3 is: {}".format(var_3))
    if var_3 == 1:
        print("test: PASS")
    else:
        print("test: FAIL")



# Generated at 2022-06-25 11:12:01.452186
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = '10'
    var_1 = lookup_module_0.parse_simple_args(var_0)


# Generated at 2022-06-25 11:12:02.833814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()

# Generated at 2022-06-25 11:12:10.108279
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Test case with assert/catch
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.reset()
        lookup_module_0.count = None
        lookup_module_0.end = None
        lookup_module_0.sanity_check()
    except AnsibleError:
        pass
    except Exception as e:
        raise AnsibleError("unknown error generating sequence: %s" % e)


# Generated at 2022-06-25 11:12:18.774232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_terms()
    var_2 = lookup_variables()
    var_3 = lookup_kwargs()
    var_4 = lookup_module_0.run(var_1, var_2, var_3)
    assert var_4 == [lookup_results()]


# Generated at 2022-06-25 11:12:24.195666
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_sanity_check(lookup_module_0)
    assert var_1 == 1
    assert var_1 == 1


# Generated at 2022-06-25 11:12:30.002855
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_0.start = 1
    var_0.count = None
    var_0.end = None
    var_0.stride = 1
    var_0.format = "%d"
    lookup_module_0.parse_simple_args('5-8')
    lookup_module_0.sanity_check()
    res = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:12:37.123965
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:42.693525
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:12:48.972198
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    if var_0:
        lookup_module_0.parse_kv_args(var_0)
    lookup_module_0.reset()
    if var_0:
        lookup_module_0.parse_kv_args(var_0)
    assert lookup_module_0.stride >= 0


# Generated at 2022-06-25 11:12:53.054052
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    assert True


# Generated at 2022-06-25 11:12:56.016304
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:12:57.523271
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    # TODO Need to check with_sequence error messages
    assert_equal(lookup_module_0.sanity_check(), None)


# Generated at 2022-06-25 11:13:00.440183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = ansible_variable()
    variables_0 = ansible_variable()
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(term_0, variables_0)
    assert type(result_0) == list

# Generated at 2022-06-25 11:13:01.783156
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()


# Generated at 2022-06-25 11:13:04.201023
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        assert e.message == 'must specify count or end in with_sequence'


# Generated at 2022-06-25 11:13:10.404930
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    # AssertionError: expected [] to equal ['0', '1']
    assert lookup_module_0.generate_sequence() == ['0', '1']

    # AssertionError: expected [] to equal ['0', '2', '4', '6', '8']
    assert lookup_module_0.generate_sequence() == ['0', '2', '4', '6', '8']


# Generated at 2022-06-25 11:13:14.468949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:13:16.792282
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_2 = LookupModule()
    var_12 = lookup_sanity_check()


# Generated at 2022-06-25 11:13:19.934597
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    # Assign values for parse_kv_args (bool, bool, int, int)
    lookup_module_0.var_0 = False
    lookup_module_0.var_1 = False
    lookup_module_0.var_2 = 0
    lookup_module_0.var_3 = 0

    # Call method generate_sequence
    lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:13:40.249531
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 7
    lookup_module_0.start = 6
    lookup_module_0.stride = 2
    lookup_module_0.sanity_check()
    lookup_module_0.count = 7
    lookup_module_0.start = 6
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()
    lookup_module_0.count = 7
    lookup_module_0.start = 6
    lookup_module_0.stride = -1
    lookup_module_0.sanity_check()
    lookup_module_0.count = 7
    lookup_module_0.start = 6
    lookup_module_0.stride = -2
    lookup_module_0.sanity_

# Generated at 2022-06-25 11:13:44.687091
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == None, 'Expected None, got %s : %s' % (type(var_0), var_0)


# Generated at 2022-06-25 11:13:48.668348
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:13:57.858826
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()

    lookup_module_0.end = 1
    lookup_module_0.sanity_check()

    lookup_module_0.end = 1
    lookup_module_0.start = 2
    lookup_module_0.sanity_check()

    lookup_module_0.end = 2
    lookup_module_0.start = 1
    lookup_module_0.sanity_check()

    lookup_module_0.end = 1
    lookup_module_0.start = 2
    lookup_module_0.count = 3
    lookup_module_0.sanity_check()

    lookup_module_0.end = 1
    lookup_module_0.start = 2
    lookup_module_0.count = 0
    lookup_module

# Generated at 2022-06-25 11:14:05.952964
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    
    # Test untimed code
    try:
        var_1 = lookup_module_0.parse_simple_args()
        var_2 = True
    except Exception:
        var_2 = False
    assert var_2
    
    # Test mapping with multiple inputs
    var_3 = lookup_reset()
    try:
        var_4 = lookup_module_0.parse_simple_args()
        var_5 = True
    except Exception:
        var_5 = False
    assert var_5
    
    # Test multiple inputs
    var_6 = lookup_reset()

# Generated at 2022-06-25 11:14:08.430217
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:12.522313
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()


# Generated at 2022-06-25 11:14:17.093947
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 1
    lookup_module_0.end = None
    lookup_module_0.count = None
    lookup_module_0.start = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:25.813458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [("start=4 end=16 stride=2 format=testuser%02x", "start=1 end=32", "count=4 format=testuser%02x", "start=10 end=0 stride=-1 format=testuser%02x"), ("start=4 end=16 stride=2 format=testuser%02x", "start=1 end=32", "count=4 format=testuser%02x", "start=10 end=0 stride=-1 format=testuser%02x")]
    var_1 = {'end_at': 10}
    var_2 = {}
    var_3 = lookup_module_0.run(var_0, var_1, var_2)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:14:30.486040
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:14:45.985641
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_sanity_check_0 = 'Test for sanity_check'
    print(lookup_sanity_check_0)
    lookup_sanity_check_1 = 'Expected: False'
    print(lookup_sanity_check_1)
    lookup_sanity_check_2 = 'Actual: False'
    print(lookup_sanity_check_2)
    assert False == False


# Generated at 2022-06-25 11:14:48.172219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = LookupModule()
    var_2 = list()
    var_3 = var_1.run(var_2, "arg_2")
    assert var_3 == list()


# Generated at 2022-06-25 11:14:49.627948
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.sanity_check(0) == 0


# Generated at 2022-06-25 11:14:50.836994
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args()


# Generated at 2022-06-25 11:14:53.919244
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.end = 5
    lookup_module.start = 1
    lookup_module.stride = 1
    lookup_module.format = '%d'
    lookup_module.sanity_check()
    assert list(lookup_module.generate_sequence()) == [1, 2, 3, 4, 5]



# Generated at 2022-06-25 11:14:59.934240
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.start
    var_2 = lookup_module_0.count
    var_3 = lookup_module_0.end
    var_4 = lookup_module_0.stride
    var_5 = lookup_module_0.format
    var_6 = lookup_module_0.parse_simple_args('4:host%02d')
    var_7 = lookup_module_0.start
    var_8 = lookup_module_0.count
    var_9 = lookup_module_0.end
    var_10 = lookup_module_0.stride
    var_11 = lookup_module_0.format
    var_12 = lookup_module_0.sanity_check()

# Generated at 2022-06-25 11:15:05.035842
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.sanity_check()
    assert var_1 == None, 'sanity_check() should return None.'


# Generated at 2022-06-25 11:15:11.556678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = "var_1"
    variables = "var_2"
    results = lookup_module_1.run(terms, variables)
    assert results == "var_3"

# Generated at 2022-06-25 11:15:16.280179
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:19.326674
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:15:45.470229
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 0
    lookup_module_0.start = 1
    lookup_module_0.end = 0
    lookup_module_0.format = '%d'
    assert lookup_module_0.generate_sequence() == [], "Expected [] to equal ['1', '2', '3', '4', '5']"
    lookup_module_0.stride = 1
    lookup_module_0.start = 1
    lookup_module_0.end = 5
    lookup_module_0.format = '%d'

# Generated at 2022-06-25 11:15:50.147284
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_sanity_check()

# Generated at 2022-06-25 11:16:01.854719
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.end = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    try:
        # Should be: ['1', '2', '3', '4', '5']
        # Actual:   ['1', '2', '3', '4', '5']
        assert ['1', '2', '3', '4', '5'] == lookup_module_0.generate_sequence()

    except AssertionError as e:
        print(e)

test_LookupModule_generate_sequence()


# Generated at 2022-06-25 11:16:03.890807
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    sequence_0 = lookup_module_0.generate_sequence()

    assert(sequence_0 == None)


# Generated at 2022-06-25 11:16:08.413169
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:16:15.972896
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.reset()  # clear out things for this iteration
    var_0 = None
    var_0 = lookup_module.parse_simple_args("5")
    var_1 = lookup_module.start
    var_2 = lookup_module.end
    var_3 = lookup_module.stride
    var_4 = lookup_module.format
    var_5 = lookup_module.sanity_check()
    var_6 = lookup_module.generate_sequence()
    var_7 = lookup_module.start
    var_8 = lookup_module.end
    var_9 = lookup_module.stride
    var_10 = lookup_module.format

# Generated at 2022-06-25 11:16:17.284070
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_sanity_check()


# Generated at 2022-06-25 11:16:22.627447
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    var_0 = "foo"
    var_1 = "bar"
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 0
    lookup_module_0.start = 1
    lookup_module_0.format = "%d"
    lookup_module_0.end = 0
    lookup_module_0.count = None
    assert lookup_module_0.generate_sequence() == (var_0, var_1)


# Generated at 2022-06-25 11:16:26.907676
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    length_items_0 = len([23, 2, 3])

    if (length_items_0 > 0):
        var_0 = lookup_module_0.generate_sequence(length_items_0) 
    else:
        var_0 = lookup_module_0.generate_sequence() 

    assert var_0 == [2, 3, 23]


# Generated at 2022-06-25 11:16:33.768805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run("start=3 count=3")
    assert var_0 == [3, 4, 5]
    var_1 = lookup_module_0.run("start=0x1e count=4 format=0x%04x")
    assert var_1 == ['0x001e', '0x001f', '0x0020', '0x0021']
    var_2 = lookup_module_0.run("start=0 end=8 stride=2 format=host%02d")
    assert var_2 == ['host00', 'host02', 'host04', 'host06', 'host08']
