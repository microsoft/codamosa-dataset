

# Generated at 2022-06-25 11:06:49.703984
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = None
    lookup_module_0.format = "%d"

    assert lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:06:57.978137
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    print("START: test_LookupModule_parse_simple_args")
    lookup_module_0 = LookupModule()
    term = '{start=10 end=0 stride=-1}'
    expected_result = True
    actual_result = lookup_module_0.parse_simple_args(term)
    assert expected_result == actual_result
    print("END: test_LookupModule_parse_simple_args")


# Generated at 2022-06-25 11:07:04.778192
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset() # clear out things for this iteration
    lookup_module_0.parse_simple_args("start=1 end=3 stride=1")
    lookup_module_0.sanity_check()
    assert lookup_module_0.generate_sequence() == ['1', '2', '3']


# Generated at 2022-06-25 11:07:10.262356
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    
    lookup_module_0.reset()  # clear out things for this iteration
    args = { 'start':"10", 'end':"11", 'format':"3%d4" }
    lookup_module_0.parse_kv_args(args)


# Generated at 2022-06-25 11:07:15.885520
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
  lookup_module = LookupModule()

  # test when condition
  # start = None
  # end = None
  # count = None
  exception_raised_0 = False
  # try block
  try:
    lookup_module.start = None
    lookup_module.end = None
    lookup_module.count = None
    lookup_module.sanity_check()
  except AnsibleError:
    exception_raised_0 = True
  # assert if condition is not met
  if not (exception_raised_0):
    raise AssertionError("condition not met")


# Generated at 2022-06-25 11:07:24.839923
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    ret = lookup_module.parse_simple_args("2-10/2")
    assert ret is True


# Generated at 2022-06-25 11:07:30.428293
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = 10
    lookup_module_0.stride = 1
    result = list(lookup_module_0.generate_sequence())
    assert result == ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10']



# Generated at 2022-06-25 11:07:36.963900
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.parse_kv_args({"end":"0", "start":"0", "stride":"0", "format":"%d"})
    assert (lookup_module_0.start == 0) and (lookup_module_0.end == 0) and (lookup_module_0.stride == 0) and (lookup_module_0.format == "%d")


# Generated at 2022-06-25 11:07:39.751367
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term = '0-10'
    try:
        lookup_module_0.parse_simple_args(term)
    except Exception as e:
        fail(e)


# Generated at 2022-06-25 11:07:43.990810
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()

    lookup_module.start = -5
    lookup_module.end = -5
    lookup_module.stride = -1

    lookup_module.format = "%d"

    assert lookup_module.generate_sequence() == ['0']


# Generated at 2022-06-25 11:07:56.279457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:08:02.674866
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = 32
    lookup_module_0.stride = 1
    assert lookup_module_0.generate_sequence() == ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32']


# Generated at 2022-06-25 11:08:07.769832
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 0
    lookup_module_0.end = 32
    lookup_module_0.stride = 1
    lookup_module_0.format = 'testuser%02x'
    result_1 = list(lookup_module_0.generate_sequence())

# Generated at 2022-06-25 11:08:10.500102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms_0 = [{"count": 5}, {"count": 5}, {"count": 5}, {"count": 5}, {"count": 5}]

    result = lookup_module_0.run(test_terms_0, None)
    print (result)


# Generated at 2022-06-25 11:08:15.560592
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    lookup_module_0.count = 0
    lookup_module_0.end = None
    lookup_module_0.stride = 0
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:22.276299
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 2
    lookup_module_1.end = 8
    lookup_module_1.stride = 1
    lookup_module_1.format = '%d'

    result = list(lookup_module_1.generate_sequence())

    assert result == [2, 3, 4, 5, 6, 7, 8]



# Generated at 2022-06-25 11:08:28.551295
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 0
    lookup_module_0.format = '%d'
    lookup_module_0.start = -1
    lookup_module_0.end = 0
    lookup_module_0.stride = 1
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        print(e)


# Generated at 2022-06-25 11:08:30.745550
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:33.179891
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.sanity_check()
        # Expect no error; Unit test passed
    except Exception as e:
        # Expect no error; Unit test failed
        raise AnsibleError("unknown error generating sequence: %s" % e)


# Generated at 2022-06-25 11:08:43.727828
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 0
    lookup_module_0.end = 1
    lookup_module_0.stride = 2

    try:
        lookup_module_0.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError('AnsibleError not raised')

    lookup_module_0.reset()
    lookup_module_0.start = 0
    lookup_module_0.end = -1
    lookup_module_0.stride = 1

    lookup_module_0.sanity_check()

    lookup_module_0.reset()
    lookup_module_0.start = 0
    lookup_module_0.end = 1

# Generated at 2022-06-25 11:08:59.116466
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    # Case 0.0:
    result = None
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.end = None
        lookup_module_0.sanity_check()
        raise Exception("Should have raised AnsibleError")
    except AnsibleError as e:
        if str(e) != "must specify count or end in with_sequence":
            raise AssertionError("Expected 'must specify count or end in with_sequence' but got '%s'" % str(e))
    except Exception as e:
        raise AssertionError("Expected AnsibleError, but got '%s'" % str(e))

# Generated at 2022-06-25 11:09:07.104529
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    bool_arg_0 = lookup_module_0.parse_simple_args("5-8")
    bool_arg_1 = lookup_module_0.parse_simple_args("5")
    assert isinstance(bool_arg_0, bool)
    assert bool_arg_0 is True
    assert isinstance(bool_arg_1, bool)
    assert bool_arg_1 is True
    assert isinstance(lookup_module_0.end, int)
    assert lookup_module_0.end == 8
    assert isinstance(lookup_module_0.start, int)
    assert lookup_module_0.start == 5
    assert lookup_module_0.format == "%d"
    assert lookup_module_0.stride == 1


# Generated at 2022-06-25 11:09:13.146409
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
# Start_test_code
    lookup_module_0.start = 1
    lookup_module_0.count = 5
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    assert (list(lookup_module_0.generate_sequence()) == ["1", "2", "3", "4", "5"]), "Return value of generate_sequence method of LookupModule class is wrong."
# End_test_code


# Generated at 2022-06-25 11:09:21.792320
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    term_0 = 'start=1 stride=1 count=1 format=%%d'
    variables_0 = {}
    kwargs_0 = {}
    try:
        ret_0 = LookupModule().run(term_0, variables_0, **kwargs_0)
        assert 0
    except AnsibleError as e_0:
        pass
    term_1 = 'count=1'
    variables_1 = {}
    kwargs_1 = {}
    try:
        ret_1 = LookupModule().run(term_1, variables_1, **kwargs_1)
        assert 0
    except AnsibleError as e_1:
        pass
    term_2 = 'count=1 stride=-1'
    variables_2 = {}
    kwargs_2 = {}

# Generated at 2022-06-25 11:09:27.536112
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 0
    lookup_module_0.format = '%d'
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:09:30.623050
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    # set the class attributes
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    # call the method
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:37.428302
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 0
    lookup_module.end = 1
    lookup_module.count = None
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.sanity_check()
    return True


# Generated at 2022-06-25 11:09:41.954168
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 1
    lookup_module.stride = 1
    lookup_module.format = "%d"
    result = True
    try:
        result = next(lookup_module.generate_sequence())
        if result != "1":
            result = False
    except StopIteration:
        result = False
    assert result



# Generated at 2022-06-25 11:09:47.031521
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 5
    lookup_module_0.end = 11
    lookup_module_0.stride = 2
    lookup_module_0.format = '0x%02x'

    assert lookup_module_0.generate_sequence() == ['0x05', '0x07', '0x09', '0x0b']


# Generated at 2022-06-25 11:09:48.358683
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
  lookup_module = LookupModule()
  assert lookup_module.generate_sequence() != None


# Generated at 2022-06-25 11:10:03.579442
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.stride = 0
    a = lookup_module_1.generate_sequence()
    assert a == '0x00', 'Ill-formed arguments'
    lookup_module_2 = LookupModule()
    lookup_module_2.end = 6
    lookup_module_2.format = "%02d"
    lookup_module_2.stride = -1
    lookup_module_2.start = 10
    lookup_module_2.count = None
    b = lookup_module_2.generate_sequence()
    assert b == '["10","09","08","07","06"]', 'Ill-formed arguments'
    lookup_module_3 = LookupModule()
    lookup_module_3.count = 10
    lookup_module_3.end = None

# Generated at 2022-06-25 11:10:06.775675
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 1
    lookup_module_0.start = 1
    lookup_module_0.end = 0
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:10:09.950889
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    memory = []
    term_0 = "2-10/2"
    lookup_module_0 = LookupModule()
    expected = True
    actual = lookup_module_0.parse_simple_args(term_0)
    memory.append((expected, actual))
    return memory[0]


# Generated at 2022-06-25 11:10:17.558521
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    assert isinstance(lookup_module_1.run(["5"], {}), list)

    lookup_module_1.run(["start=5 end=11 stride=2 format=0x%02x"], {})

    lookup_module_1.run(["count=5"], {})

    lookup_module_1.run(["start=0x0f00 count=4 format=%04x"], {})

    lookup_module_1.run(["start=0 count=5 stride=2"], {})

    lookup_module_1.run(["start=1 count=5 stride=2"], {})

# Generated at 2022-06-25 11:10:25.867538
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    lookup_module = LookupModule()
    assert_exception = None
    lookup_module.stride = 8
    lookup_module.end = 6
    lookup_module.start = 10

    try:
        lookup_module.sanity_check()
    except AnsibleError as exception:
        assert_exception = exception
    else:
        assert False, "Expected AnsibleError to be thrown due to end < start"

    assert_exception is not None
    assert str(assert_exception) == "to count backwards make stride negative"



# Generated at 2022-06-25 11:10:33.168987
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    assert lookup_module_0.parse_simple_args("") == False
    assert lookup_module_0.parse_simple_args("5-8") == True
    assert lookup_module_0.parse_simple_args("2-10/2") == True
    assert lookup_module_0.parse_simple_args("4:host%02d") == True


# Generated at 2022-06-25 11:10:34.060479
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()

    assert lookup_module.generate_sequence() == []



# Generated at 2022-06-25 11:10:36.502974
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term = 'lookup_module_0.term'
    result = lookup_module_0.parse_simple_args(term)


# Generated at 2022-06-25 11:10:40.075762
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    params_0 = {
        'term': '5',
        'variables': {},
        'kwargs': {},
    }
    result = lookup_module_0.generate_sequence(**params_0)
    assert result == ['1', '2', '3', '4', '5']



# Generated at 2022-06-25 11:10:43.734955
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    print(lookup_module_0.__doc__)
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    print(lookup_module_0.sanity_check())


# Generated at 2022-06-25 11:10:59.025870
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check = lambda : None
    lookup_module_0.start = 1
    lookup_module_0.end = 11
    lookup_module_0.format = '%d'
    lookup_module_0.stride = 1
    print(list(lookup_module_0.generate_sequence()))

test_case_0()
test_LookupModule_generate_sequence()

# Generated at 2022-06-25 11:11:02.180156
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 2
    lookup_module_0.end = 10
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:10.365284
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Setup test
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    # Invoke method
    e = None
    try:
        lookup_module_0.sanity_check()
    except Exception as __e:
        e = __e

    # Verify that all assertions were called
    assert(e is not None)


# Generated at 2022-06-25 11:11:15.637151
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    # Test for method generate_sequence(self)
    # Test for basic function
    lookup_module_0.start = 1
    lookup_module_0.end = 5
    lookup_module_0.stride = 3
    lookup_module_0.format = "%d"
    result_generate_sequence = lookup_module_0.generate_sequence()
    assert result_generate_sequence == [1, 4]


# Generated at 2022-06-25 11:11:17.048079
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
  lookup_module = LookupModule()
  assert lookup_module.generate_sequence() == None


# Generated at 2022-06-25 11:11:21.735891
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    terms = None
    variables = None
    kwargs = None
    assert isinstance(lookup_module.run(terms, variables, **kwargs), list)


# Generated at 2022-06-25 11:11:23.643299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['start=1 end=5'], None)


# Generated at 2022-06-25 11:11:27.112970
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 7
    lookup_module.end   = 19
    lookup_module.stride = 13
    res = list(lookup_module.generate_sequence())
    assert res == ["7"]


# Generated at 2022-06-25 11:11:33.905043
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    print('')
    print('Test sanity_check')
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    assert_equal(lookup_module_0.start, 1)
    assert_equal(lookup_module_0.end, None)
    assert_equal(lookup_module_0.stride, 1)
    assert_equal(lookup_module_0.format, "%d")



# Generated at 2022-06-25 11:11:36.000303
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.count = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.format = "%d"
    assert list(lookup_module_0.generate_sequence()) == []



# Generated at 2022-06-25 11:12:07.609021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        "0x100-0x103",
        "1",
        "0x8",
        "0x",
    ]
    variables_0 = dict()
    assert lookup_module_0.run(terms_0, variables_0) == [
        '0x100',
        '0x101',
        '0x102',
        '0x103',
        '1',
        '8',
        '0',
    ]

if __name__ == "__main__":
    test_LookupModule_run()
    print("Done.")

# Generated at 2022-06-25 11:12:15.288859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms,variables) == []
    terms = ['5']
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms,variables) == ['1','2','3','4','5']
    terms = ['5-8']
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms,variables) == ['5','6','7','8']
    terms = ['2-10/2']
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms,variables) == ['2','4','6','8','10']
    terms = ['4:host%02d']
    lookup

# Generated at 2022-06-25 11:12:20.129438
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    # Test condition 1
    # Test if Exception is raised
    try:
        lookup_module_0.count = 10
        lookup_module_0.end = 20
        lookup_module_0.sanity_check()
        raise Exception("Exception not raised")
    except AnsibleError:
        pass

    # Test condition 2
    # Test if Exception is raised
    try:
        lookup_module_0.count = 10
        lookup_module_0.sanity_check()
        raise Exception("Exception not raised")
    except AnsibleError:
        pass

    # Test condition 3
    # Test if Exception is raised

# Generated at 2022-06-25 11:12:29.385503
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    # This test needs the following class and global variables:
    # lookup_module.end =
    # lookup_module.count =
    # lookup_module.start =
    # lookup_module.stride =
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.sanity_check()
    assert str(excinfo.value) == "must specify count or end in with_sequence"
    lookup_module.end = None
    lookup_module.count = 1
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.sanity_check()
    assert str(excinfo.value) == "must specify count or end in with_sequence"
    lookup_module.end = None
    lookup_module.count = None
   

# Generated at 2022-06-25 11:12:35.984763
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.generate_sequence()
    assert result == [], "Return value was {} but was expected to be {}".format(result, [])


# Generated at 2022-06-25 11:12:38.654622
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args("1-10")
    lookup_module_0.sanity_check()
    lookup_module_0.parse_simple_args("10-1")
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:41.820725
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    # All members of 'LookupModule' are present.
    try:
        lookup_module_0.sanity_check()
        assert True # The statement was reached, and nothing was thrown.
    except AssertionError as e:
        raise(e)
    except Exception as e:
        print("sanity_check() raised Exception unexpectedly.")


# Generated at 2022-06-25 11:12:46.798603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        "start=5 end=11 stride=2 format=0x%02x",
        "1-3",
        "1-10/2",
        "6",
        "start=0x0f00 count=4 format=%04x",
        "5",
        "start=10 end=0 stride=-1",
        "5-8",
        "start=0 count=5 stride=2",
        "2-10/2",
    ]
    variables_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == [
        "0x05",
        "0x07",
        "0x09",
        "0x0a"]

# Unit test

# Generated at 2022-06-25 11:12:48.281300
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    assert lookup_module is not None
    assert lookup_module != False
    lookup_module.run(terms=["end=10"], variables=None, **None)


# Generated at 2022-06-25 11:12:51.780306
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.end = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    result = lookup_module_0.generate_sequence()
    assert list(result) == ["1","2","3","4","5"]


# Generated at 2022-06-25 11:13:07.564090
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 11:13:11.846546
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # Check with term: '0x01'
    assert not lookup_module_0.parse_simple_args('0x01')

    # Check with term: '1'
    assert not lookup_module_0.parse_simple_args('1')

    # Check with term: ':str%02d'
    assert not lookup_module_0.parse_simple_args(':str%02d')


# Generated at 2022-06-25 11:13:15.776169
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    res_0 = lookup_module_0.parse_simple_args("4:host%02d")
    assert res_0 == True


# Generated at 2022-06-25 11:13:22.180942
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    test_sequence = lookup_module_0.generate_sequence([lookup_module_0], lookup_module_0.run(['10-1/-1'], lookup_module_0))
    assert test_sequence == ["10", "9", "8", "7", "6", "5", "4", "3", "2", "1"]

# Generated at 2022-06-25 11:13:32.437095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    terms = ['start=5 end=11 stride=2 format=0x%02x']
    variables = None
    kwargs = {}
    output = ['0x05', '0x07', '0x09', '0x0a']
    assert(lookup_module_0.run(terms, variables, **kwargs) == output)

    lookup_module_1 = LookupModule()
    lookup_module_1._templar = None
    terms = ['start=0 count=5 stride=2 format=0x%02x']
    variables = None
    kwargs = {}
    output = ['0x00', '0x02', '0x04', '0x06', '0x08']

# Generated at 2022-06-25 11:13:37.524182
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # simple terms
    assert lookup_module_0.parse_simple_args('5')
    assert lookup_module_0.parse_simple_args('5-8')
    assert lookup_module_0.parse_simple_args('2-10/2')
    assert lookup_module_0.parse_simple_args('4:host%02d')
    assert lookup_module_0.start == 1
    assert lookup_module_0.end == 5
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == "%d"
    assert lookup_module_0.parse_simple_args('5-8')
    assert lookup_module_0.start == 5
    assert lookup_module_0.end == 8
    assert lookup_module_0.str

# Generated at 2022-06-25 11:13:42.777784
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = 1
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:13:47.459222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [0, 1, 2]
    variables = [0, 1, 2]
    lookup_module_run_result = lookup_module.run(terms, variables)
    assert lookup_module_run_result == ['0', '1', '2']


# Generated at 2022-06-25 11:13:53.442328
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()

    lookup_module_0.start = 0xdeadbeef
    lookup_module_0.end = 0xffffffff
    lookup_module_0.stride = 0

    try:
        lookup_module_0.sanity_check()
    except AnsibleError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 11:13:59.905350
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleError):
        lookup_module_0.start = 1
        lookup_module_0.end = 0
        lookup_module_0.stride = 1
        lookup_module_0.sanity_check()

    with pytest.raises(AnsibleError):
        lookup_module_0.start = 1
        lookup_module_0.count = 0
        lookup_module_0.stride = 1
        lookup_module_0.sanity_check()



# Generated at 2022-06-25 11:14:18.692654
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    from ansible.errors import AnsibleError
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    lookup_module_0.start = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.sanity_check()

    with pytest.raises(AnsibleError):
        lookup_module_0.start = 1
        lookup_module_0.end = 1
        lookup_module_0.stride = 1
        lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:23.766671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Return a list with "host02", "host03", "host04", "host05"
    terms=[{'count': 4, 'format': 'host%02d', 'start': 2}]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, None)
    assert result == ['host02', 'host03', 'host04', 'host05']


# Generated at 2022-06-25 11:14:25.436614
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    seq = LookupModule()
    seq.start = 5
    seq.end = 10
    seq.stride = 1
    seq.sanity_check()
    assert seq.start == 5 and seq.end == 10 and seq.stride == 1


# Generated at 2022-06-25 11:14:28.580489
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = -1
    lookup_module_0.stride = -1
    lookup_module_0.end = -3
    lookup_module_0.count = None
    lookup_module_0.format = '%d'

    # call the method
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:33.493400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    try:
        results = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except AnsibleError as e:
        print(e)
        print("AnsibleError raised. This value should be False.")
        print("")
    else:
        print("")
        print("results: ", results)
        print("")
        print("Loop finished without raising AnsibleError. This value should be True.")
        print("")


# Generated at 2022-06-25 11:14:37.264732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["1", "2", "3"]
    variables_0 = dict()
    kwargs_0 = dict()
    results_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    expected_0 = ["1", "2", "3"]
    assert expected_0 == results_0


# Generated at 2022-06-25 11:14:47.990095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_0 = [("0-32/4"),]
    var_5 = [
        "0",
        "4",
        "8",
        "12",
        "16",
        "20",
        "24",
        "28",
        "32",
    ]
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {
        "start": 0,
        "end": 32,
        "stride": 4,
    }
    var_13 = {
        "start": 0,
        "end": 32,
        "stride": 4,
    }

# Generated at 2022-06-25 11:14:54.989713
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 1
    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        print(e)
        assert isinstance(e, AnsibleError)
        assert str(e) == "must specify count or end in with_sequence"
    lookup_module_0.count = None
    lookup_module_0.end = 1
    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        print(e)
        assert isinstance(e, AnsibleError)
        assert str(e) == "can't specify both count and end in with_sequence"
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.str

# Generated at 2022-06-25 11:14:59.466451
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    try:
        import __builtin__
    except ImportError:
        import builtins as __builtin__
    lookup_module = LookupModule()
    lookup_module.start = 0
    lookup_module.end = 2
    lookup_module.stride = 1
    lookup_module.format = '%s'
    data = lookup_module.run(terms = ['start=0 end=2 stride=1','format=%s'], variables={})
    assert data[0] == '0'
    assert data[1] == '1'
    assert data[2] == '2'


# Generated at 2022-06-25 11:15:10.880954
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()

    start = 1
    end = 2
    stride = 1
    format = "%d"
    items = [1, 2]

    lookup_module.end = end
    lookup_module.start = start
    lookup_module.stride = stride
    lookup_module.format = format

    # Call with arguments: start, end, format, stride
    res = lookup_module.generate_sequence()

    assert next(res) == items[0]
    assert next(res) == items[1]

    with pytest.raises(StopIteration):
        next(res)

    lookup_module.end = end
    lookup_module.start = start
    lookup_module.stride = stride
    lookup_module.format = format

    # Call with arguments: start, end, format, stride


# Generated at 2022-06-25 11:15:37.177497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # I/O for method run
  term_0 = ["$_0_$"]
  variables_0 = ["$_1_$"]
  # expected result
  results_0 = "$_2_$"
  # actual result
  lookup_module_0 = LookupModule()
  results_1 = lookup_module_0.run(term_0, variables_0)
  try:
    assert results_0 == results_1
  except AssertionError:
    print(results_1)


# Generated at 2022-06-25 11:15:41.668676
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:48.455893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # From the documentation, with no further changes.
    # This should return a list with 10 elements of the form "testuserNN".
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:15:53.147116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Started test_LookupModule_run")
    lookup_module = LookupModule()
    v_terms = ["start=0", "end=10"]
    v_variables = {}
    res = lookup_module.run(terms=v_terms, variables=v_variables)
    print(res)
    assert res == ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]


# Generated at 2022-06-25 11:15:56.999791
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    variables = dict()
    terms = ['3']
    kwargs = dict()

    results = lookup_module.run(terms, variables, **kwargs)

    assert results == ['1', '2', '3']


# Generated at 2022-06-25 11:16:01.654202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_result = lookup_instance.run(["start=2 end=5"], {},
                                        wantlist=True)
    assert lookup_result == ['2', '3', '4', '5']

    lookup_instance = LookupModule()
    lookup_result = lookup_instance.run(["start=0 end=20 stride=5"], {},
                                        wantlist=True)
    assert lookup_result == ['0', '5', '10', '15', '20']

    lookup_instance = LookupModule()
    lookup_result = lookup_instance.run(["start=20 end=0 stride=-5"], {},
                                        wantlist=True)
    assert lookup_result == ['20', '15', '10', '5', '0']

    lookup_instance = LookupModule()


# Generated at 2022-06-25 11:16:05.112534
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    print ('Starting test for parse_simple_args')
    lookup_module_1 = LookupModule()
    assert lookup_module_1.parse_simple_args('2-10/2') == True
    lookup_module_1.reset()
    assert lookup_module_1.parse_simple_args('4:host%02d') == True
    print ('Test for parse_simple_args complete')


# Generated at 2022-06-25 11:16:09.486981
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.end = 1
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.count = 1
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:16:13.092773
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 2
    lookup_module.stride = -1
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        pass
    else:
        raise AssertionError
    del lookup_module


# Generated at 2022-06-25 11:16:18.033209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [5]
    variables_1 = dict()
    kwargs_1 = dict()
    ret_val_1 = lookup_module_1.run(terms_1, variables_1, *kwargs_1)
    assert ret_val_1 == [["1","2","3","4","5"]]
