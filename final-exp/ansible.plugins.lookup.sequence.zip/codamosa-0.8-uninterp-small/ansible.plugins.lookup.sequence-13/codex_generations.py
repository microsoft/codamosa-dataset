

# Generated at 2022-06-25 11:06:55.262539
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term = "5-8"
    assert lookup_module_0.parse_simple_args(term) == True
    term = "5"
    assert lookup_module_0.parse_simple_args(term) == True
    term = "5-9/2"
    assert lookup_module_0.parse_simple_args(term) == True
    term = "5-9/6"
    assert lookup_module_0.parse_simple_args(term) == True
    term = "5-9/4:test%02x"
    assert lookup_module_0.parse_simple_args(term) == True
    term = "5-9/4:test%02x"
    assert lookup_module_0.parse_simple_args(term) == True

# Generated at 2022-06-25 11:07:00.100224
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    # ansible.errors.AnsibleError: must specify count or end in with_sequence
    # bad strnide
    lookup_module_0.start = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    # self.sanity_check()
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        print(e)

    # ansible.errors.AnsibleError: must specify count or end in with_sequence
    # bad strnide
    lookup_module_0.start = 5
    lookup_module_0.end = 8
    lookup_module_0.stride = 0
    # self.sanity_check()

# Generated at 2022-06-25 11:07:06.048364
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 4
    lookup_module_0.end = 100
    lookup_module_0.stride = 2
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:07:09.650841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0_instance = LookupModule()
    test_terms_0 = []
    test_variables_0 = {}
    test_result_0 = lookup_module_0_instance.run(test_terms_0, test_variables_0)
    assert test_result_0 == []



# Generated at 2022-06-25 11:07:15.277129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_class = LookupModule()

    terms = list()
    terms.append('foo=bar count=1')
    terms.append('foo=bar end=1')
    terms.append('start=1 end=3')
    terms.append('start=1 end=3 format=%02d')
    terms.append('start=1 end=3 stride=2')
    terms.append('start=1 end=3 stride=2 format=%02d')
    terms.append('0x2-0x10')
    terms.append('0x2-0x10 format=%04x')
    terms.append('0x2-0x10/0x4')
    terms.append('0x2-0x10/0x4 format=%04x')
    terms.append('2-10/2')
   

# Generated at 2022-06-25 11:07:21.632502
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    term_0 = dict()
    term_0['start'] = '5'
    term_1 = dict()
    term_1['end'] = '11'
    term_2 = dict()
    term_2['stride'] = '2'
    term_3 = dict()
    term_3['format'] = '%d'
    variables_0 = dict()
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    assert lookup_module_0.start == 1
    assert lookup_module_0.count == None
    assert lookup_module_0.end == None
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == '%d'
    lookup_module_0.parse_kv_args(term_0)
    assert lookup_

# Generated at 2022-06-25 11:07:32.214692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['0-12/2']
    variables_0 = {'var_4': ["1", "2"], 'var_5': ["0", "1", "2", "3"], 'var_3': ["0", "1", "2"], 'var_2': ["2", "3", "4", "5"], 'var_1': ["0", "1", "2", "3", "4", "5"], 'var_0': ['0', '1', '10', '11']}
    assert lookup_module_0.run(terms_0, variables_0) == ["1", "3", "5", "7", "9", "11"]
    terms_0 = ['0-10/2']

# Generated at 2022-06-25 11:07:32.771506
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    assert True


# Generated at 2022-06-25 11:07:35.232321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameter1 = list()
    parameter2 = dict()
    parameter3 = dict()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(parameter1, parameter2, **parameter3)


# Generated at 2022-06-25 11:07:40.085339
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    lookup_module_1 = LookupModule()
    result1 = lookup_module_1.parse_simple_args("5")
    """
    AssertionError: True != False
    """
    assert result1 == False

    lookup_module_2 = LookupModule()
    result2 = lookup_module_2.parse_simple_args("5")
    """
    AssertionError: True != False
    """
    assert result2 == False

    lookup_module_3 = LookupModule()
    result3 = lookup_module_3.parse_simple_args("5")
    """
    AssertionError: True != False
    """
    assert result3 == False


# Generated at 2022-06-25 11:07:48.822463
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    str_0 = 'L'
    bool_0 = lookup_module_0.parse_simple_args(str_0)
    assert bool_0


# Generated at 2022-06-25 11:07:56.497353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
        '10',
        '-1',
        '10',
        '5',
        '10',
        '10',
        '10/1',
        '5/5',
        '5/5',
        '5/5'
    ]
    lu = LookupModule()
    assert lu.run(terms_0, None) == [
        '10',
        '10',
        '10',
        '5',
        '10',
        '10',
        '10',
        '5',
        '5',
        '5'
    ]

# Generated at 2022-06-25 11:07:57.979439
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    str_0 = 'L'
    assert not lookup_module_0.parse_simple_args(str_0)


# Generated at 2022-06-25 11:08:02.257372
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = 10
    lookup_module_0.start = 0
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:04.338664
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.parse_kv_args()
    except TypeError:
        assert True
    # TypeError raised as expected.


# Generated at 2022-06-25 11:08:10.809550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Zero Arguments
    try:
        lookup_module_1.run([]);
    except Exception as e:
        print ("Testcase 1 failed " + str(e))

    # One Argument
    try:
        lookup_module_1.run(["start=4 end=16 stride=2"]);
    except Exception as e:
        print ("Testcase 2 failed " + str(e))

    # Two Arguments
    try:
        lookup_module_1.run(["format=testuser%02x start=0 end=32"]);
    except Exception as e:
        print ("Testcase 3 failed " + str(e))

    # Three Arguments

# Generated at 2022-06-25 11:08:14.325046
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_kv_args(lookup_module_0)

# Generated at 2022-06-25 11:08:14.847518
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    assert False


# Generated at 2022-06-25 11:08:21.480406
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.end = 4
    lookup_module_0.start = 4
    lookup_module_0.stride = 1
    result = lookup_module_0.generate_sequence()
    assert result == [4]


# Generated at 2022-06-25 11:08:33.131255
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
  lookup_module_0 = LookupModule()
  lookup_module_0.start = 8
  lookup_module_0.end = 6
  lookup_module_0.stride = -2
  lookup_module_0.stride = -3
  lookup_module_0.stride = 2
  lookup_module_0.stride = -2
  lookup_module_0.stride = 2
  lookup_module_0.stride = 2
  lookup_module_0.stride = 2
  lookup_module_0.stride = 2
  lookup_module_0.stride = -2
  lookup_module_0.stride = -2
  lookup_module_0.end = 10
  lookup_module_0.stride = 0
  lookup_module_0.stride = -2
  lookup_module

# Generated at 2022-06-25 11:08:49.819403
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    # Unit test for method parse_simple_args of class LookupModule
    lookup_module_0 = LookupModule()
    expected = False
    var_0 = lookup_module_0.parse_simple_args(term)
    assert var_0 == expected
    # Test other types of inputs
    # Test other types of inputs
try:
    import pytest
except ImportError:
    pytest = None

if pytest:
    @pytest.mark.xfail()
    def test_parse_simple_args_prefix():
        lookup_module = LookupModule()
        assert lookup_module.parse_simple_args('start')



if pytest:
    @pytest.mark.xfail()
    def test_parse_simple_args_suffix():
        lookup_module = LookupModule()
        assert lookup_module

# Generated at 2022-06-25 11:08:50.851234
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:09:02.038968
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()

    # Make sure sanity_check is called.
    lookup_module_2 = LookupModule()
    lookup_reset(lookup_module_2)
    setattr(lookup_module_2, "end", None)
    with pytest.raises(AnsibleError):
        lookup_generate_sequence(lookup_module_2)

    # __doc__ (as of python 2.7.1) for range says:
    # Return a list containing an arithmetic progression of integers.
    # range(i, j) returns [i, i+1, i+2, ..., j-1]; start (!) defaults to 0.
    # When step is given, it specifies the increment (or decrement).
    # For example, range(4) returns [0, 1, 2, 3]. 

# Generated at 2022-06-25 11:09:03.766854
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:09:05.409314
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_generate_sequence(lookup_module_0)


# Generated at 2022-06-25 11:09:08.282048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["end=100","start=90","printf=%x"], "var_1")


# Generated at 2022-06-25 11:09:11.140511
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_kv_args(parse_kv("start=5 end=11 stride=2 format=0x%02x"))


# Generated at 2022-06-25 11:09:15.582156
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()



# Generated at 2022-06-25 11:09:18.088714
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.generate_sequence() == None



# vim: et ts=4 sw=4

# Generated at 2022-06-25 11:09:20.297717
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_2 = LookupModule()
    lookup_module_2.count = None
    lookup_module_2.end = None
    lookup_module_2.stride = 1
    lookup_module_2.start = 1
    lookup_module_2.sanity_check()



# Generated at 2022-06-25 11:09:25.957068
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_parse_simple_args(lookup_module_0)


# Generated at 2022-06-25 11:09:27.674739
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args("")


# Generated at 2022-06-25 11:09:29.233757
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:35.167536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.parse_kv_args(parse_kv(['count=4']))
    lookup_module_0.sanity_check()
    lookup_module_1 = LookupModule()
    lookup_module_1.reset()
    lookup_module_1.parse_simple_args('count=4')
    lookup_module_1.sanity_check()
    lookup_module_2 = LookupModule()
    lookup_module_2.reset()
    lookup_module_2.parse_kv_args(parse_kv(['end=22']))
    lookup_module_2.sanity_check()
    lookup_module_3 = LookupModule()
    lookup_module_3.reset()
    lookup

# Generated at 2022-06-25 11:09:40.436701
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    lookup_module_0 = LookupModule()
    test_0 = [
        0x0f00,
        0x0f01,
        0x0f02,
        0x0f03
    ]
    var_0 = lookup_module_0.generate_sequence()
    for item_0 in var_0:
        assert item_0 in test_0

# Generated at 2022-06-25 11:09:48.616231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [0]
    variables = [0]
    # Test with the basic arguments
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms=terms, variables=variables)
    # Test with the advanced arguments
    lookup_module_2 = LookupModule()
    kwargs = {'advanced_arg': 0}
    var_2 = lookup_module_2.run(terms=terms, variables=variables, **kwargs)
    # Test with an empty lists as arguments
    lookup_module_3 = LookupModule()
    var_3 = lookup_module_3.run(terms=[], variables=[])

# Generated at 2022-06-25 11:09:49.914022
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_sanity_check(lookup_module_1)


# Generated at 2022-06-25 11:09:52.427843
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    start = 1
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()
    return None


# Generated at 2022-06-25 11:09:55.465880
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_sanity_check(lookup_module_0)


# Generated at 2022-06-25 11:09:57.684822
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:10:13.751006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [u'0-0x7',u'0x7-0x0x10',u'0x2',u'0:testuser%02x',u'5-8',u'5-8/3']
    var_1 = {}
    var_2 = {}
    lookup_module_0.run(var_0,var_1,**var_2)
    var_0 = [u'0-0x7',u'0x7-0x0x10',u'0x2',u'0:testuser%02x',u'5-8',u'5-8/3']
    var_1 = {}
    var_2 = {}
    lookup_module_0.run(var_0,var_1,**var_2)

# Generated at 2022-06-25 11:10:15.077228
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_kv_args()

# Generated at 2022-06-25 11:10:18.169762
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # no code, just a test placeholder
    lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:10:25.352779
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    # Arrange
    lookup_module_0 = LookupModule()
    self = lookup_module_0
    lookup_module_0.count = None
    lookup_module_0.end = None

    # Act
    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        # Assert
        assert(e.message == "must specify count or end in with_sequence")


# Generated at 2022-06-25 11:10:28.472219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = "10"
    var_2 = lookup_module_1.run([var_1], dict())


# Generated at 2022-06-25 11:10:31.425935
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.sanity_check()


# Generated at 2022-06-25 11:10:33.041893
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()



# Generated at 2022-06-25 11:10:35.670318
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = "ABC"
    result = lookup_module_0.run(term_0)
    assert result == "def"


# Generated at 2022-06-25 11:10:39.917692
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:10:41.043161
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:12.583264
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    def sanity_check():
        lookup_module_0.count = None
        lookup_module_0.sanity_check()

    # The exception was raised, but not expected
    with pytest.raises(AnsibleError) as excinfo:
        sanity_check()
    the_exception = excinfo.value
    assert 'must specify count or end in with_sequence' in str(the_exception)



# Generated at 2022-06-25 11:11:14.778665
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module0 = LookupModule()
    var_0 = lookup_module0.sanity_check()
    assert var_0 == 0


# Generated at 2022-06-25 11:11:16.517259
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()



# Generated at 2022-06-25 11:11:22.382524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = LookupModule()
    var_0.run(terms=[], kwargs={}, variables=[])

# Test by default
if __name__ == '__main__':
    test_case_0()
    print("Success: %s" % __file__)

# Generated at 2022-06-25 11:11:23.479621
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_parse_simple_args(lookup_module_0)


# Generated at 2022-06-25 11:11:28.971869
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 2
    lookup_module_0.end = 8
    lookup_module_0.start = 4
    lookup_module_0.format = "%d"
    var_1 = lookup_module_0.generate_sequence()
    var_2 = list(var_1)
    print(var_2)


# Generated at 2022-06-25 11:11:30.790728
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:11:38.216546
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_stride = 1
    lookup_format = "%d"
    lookup_start = 0
    lookup_end = 10
    lookup_sanity_check(lookup_module)
    lookup_generate_sequence(lookup_module)
    lookup_stride = -1
    lookup_sanity_check(lookup_module)
    lookup_generate_sequence(lookup_module)
    lookup_stride = 0
    lookup_sanity_check(lookup_module)
    lookup_generate_sequence(lookup_module)

# Generated at 2022-06-25 11:11:44.756866
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # Test with a range that is positive.
    lookup_module_0.start = 0
    lookup_module_0.count = 10
    lookup_module_0.stride = 0
    lookup_module_0.format = "%d"
    var_0 = lookup_module_0.generate_sequence()
    assert var_0 == ['0','1','2','3','4','5','6','7','8','9']
    # Test with a range that is negative.
    lookup_module_0.start = -50
    lookup_module_0.count = 100
    lookup_module_0.stride = -1
    var_0 = lookup_module_0.generate_sequence()

# Generated at 2022-06-25 11:11:46.414543
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:18.875775
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.generate_sequence()
    assert result == None


# Generated at 2022-06-25 11:12:24.956628
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 1
    lookup_module_0.end = 5
    lookup_module_0.stride = 2
    lookup_module_0.start = 1
    lookup_module_0.sanity_check()


if __name__ == '__main__':
    print("Hi")

# Generated at 2022-06-25 11:12:26.298616
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()



# Generated at 2022-06-25 11:12:27.439779
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()



# Generated at 2022-06-25 11:12:31.658168
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:37.159125
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # assuming start=0 end=10 stride=1 format=%2d
    assert isinstance(lookup_module_0.generate_sequence(), object)


# Generated at 2022-06-25 11:12:43.827580
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.reset()
    lookup_module.parse_kv_args(parse_kv("start=0 end=3 stride=2"))
    lookup_module.sanity_check()
    assert lookup_module.generate_sequence() == ["0", "2"]

# Generated at 2022-06-25 11:12:50.695345
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    #
    # Set up test data
    #
    lookup_module_0 = LookupModule()
    var_0 = xrange(0, 10)
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    for i in var_0:
        assert lookup_module_0.generate_sequence() == var_0



# Generated at 2022-06-25 11:12:56.015567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for param in LookupModule():
        break
    lookup_module_0 = LookupModule()
    lookup_module_0.run(lookup_module_0)

# Generated at 2022-06-25 11:13:00.090078
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    term = "start=5 end=11 stride=2 format=0x%02x"
    
    try:
        if not lookup_module.parse_simple_args(term):
            lookup_module.parse_kv_args(parse_kv(term))
    except Exception as e:
        print("unknown error generating sequence: %s" % e)

# Generated at 2022-06-25 11:15:00.465494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(
        terms = [
            'var_0'
            ],
        variables = {
            'var_0': 'var_0'
            }
        )
    assert var == ['var_0']


# Generated at 2022-06-25 11:15:10.951531
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_sanity_check(lookup_module_1)
    var_1 = e.__repr__()
    assert var_1 == "['end']"
    lookup_module_1.end = 1
    lookup_sanity_check(lookup_module_1)
    var_2 = e.__repr__()
    assert var_2 == "['count']"
    lookup_module_1.count = 1
    lookup_sanity_check(lookup_module_1)
    var_3 = e.__repr__()
    assert var_3 == "['count', 'end']"
    lookup_module_1.count = None
    lookup_sanity_check(lookup_module_1)
    var_4 = e.__repr__()

# Generated at 2022-06-25 11:15:13.613560
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0
    var_1 = "5"
    var_0.parse_simple_args(var_1)
    # No assertions


# Generated at 2022-06-25 11:15:17.386652
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = -1
    assert lookup_module_0.sanity_check()==1



# Generated at 2022-06-25 11:15:21.008020
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    ret_0 = lookup_generate_sequence(lookup_module_0)
    assert(ret_0 == 0)

# Unit tests for method sanity_check of class LookupModule

# Generated at 2022-06-25 11:15:22.620181
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    var_1 = lookup_parse_simple_args(lookup_module_1)

# Generated at 2022-06-25 11:15:23.953692
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:31.155265
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    #    """Tests generate_sequence."""

    lookup_module_0 = LookupModule()
    lookup_module_0.start = int(1)
    lookup_module_0.format = str("%d")
    var_0 = lookup_module_0.generate_sequence()
    lookup_module_0.end = int(5)
    var_1 = lookup_module_0.generate_sequence()
    lookup_module_0.stride = int(2)
    var_2 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:15:34.845770
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()

# Generated at 2022-06-25 11:15:45.353737
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module_0.sanity_check()
    lookup_module_0.count = 1
    with pytest.raises(AnsibleError):
        lookup_module_0.sanity_check()
    lookup_module_0.count = None
    lookup_module_0.end = 1
    lookup_module_0.stride = 0
    with pytest.raises(AnsibleError):
        lookup_module_0.sanity_check()
    lookup_module_0.stride = 1
    lookup_module_0.end = None
    lookup_module_0.count = -1
    with pytest.raises(AnsibleError):
        lookup_module_0.sanity_check()