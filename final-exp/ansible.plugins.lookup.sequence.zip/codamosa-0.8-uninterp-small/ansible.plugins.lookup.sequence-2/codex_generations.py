

# Generated at 2022-06-25 11:06:52.363974
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = 1
    lookup_module.format = '%d'
    # call the method
    with pytest.raises(AnsibleError):
        lookup_module.sanity_check()
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = 2
    lookup_module.stride = 1
    lookup_module.format = '%d'
    # call the method
    lookup_module.sanity_check()
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = 10

# Generated at 2022-06-25 11:07:01.952512
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.count = 1
    lookup_module_1.end = 1
    lookup_module_1.stride = 1
    lookup_module_1.format = "%d"
    try:
        lookup_module_1.sanity_check()
    except AnsibleError:
        raise AssertionError("AssertionError: An unexpected Ansible exception was raised in the sanity_check method of the LookupModule class: 'must specify count or end in with_sequence'")

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_sanity_check()

# Generated at 2022-06-25 11:07:09.386174
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.sanity_check()
    assert 'must specify count or end in with_sequence' in str(excinfo.value)


# Generated at 2022-06-25 11:07:15.020125
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = '5-18'
    lookup_module_0.parse_simple_args(term_0)
    result_0 = lookup_module_0.start
    assert result_0 == 1
    result_1 = lookup_module_0.count
    assert result_1 == None
    result_2 = lookup_module_0.end
    assert result_2 == 18
    result_3 = lookup_module_0.stride
    assert result_3 == 1
    result_4 = lookup_module_0.format
    assert result_4 == '%d'
    lookup_module_1 = LookupModule()
    term_1 = '24-31/4'
    lookup_module_1.parse_simple_args(term_1)
    result_5 = lookup

# Generated at 2022-06-25 11:07:21.421742
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # No exception, no error
    lookup_module_0.start = 1
    lookup_module_0.end = 11
    lookup_module_0.stride = 2
    lookup_module_0.format = "0x%02x"
    lookup_module_0.generate_sequence()
    assert lookup_module_0.start == 1
    assert lookup_module_0.end == 11
    assert lookup_module_0.stride == 2
    assert lookup_module_0.format == "0x%02x"



# Generated at 2022-06-25 11:07:32.225596
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    args = {}
    lookup_module_0.parse_kv_args(args)
    assert lookup_module_0.start == 1
    assert lookup_module_0.count == None
    assert lookup_module_0.end == None
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == '%d'
    args = {'start': '0'}
    lookup_module_0.parse_kv_args(args)
    assert lookup_module_0.start == 0
    args = {'end': '0'}
    lookup_module_0.parse_kv_args(args)
    assert lookup_module_0.end == 0
    args = {'count': '0'}

# Generated at 2022-06-25 11:07:33.141310
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
	assert generate_sequence == [1,2,3,4,5,6,7]

# Generated at 2022-06-25 11:07:39.465400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    invocation = dict(
        lookup="sequence",
        terms=[
            "end=4",
            "start=5 end=8 stride=3",
            "0-9/3:test%02x",
            "start=0xa20 count=4 format=0x%04x",
            "start=1 count=5 stride=2"
        ],
        variables={}
    )
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(**invocation)
    assert result == ['1', '2', '3', '4', '5', '8', 'test02', 'test05', 'test08', '0xa20', '0xa21', '0xa22', '0xa23', '1', '3', '5', '7', '9']


# Generated at 2022-06-25 11:07:39.988835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 2 == 2

# Generated at 2022-06-25 11:07:44.237536
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 0
    try:
        lookup_module_0.sanity_check()
        raise AssertionError('AnsibleError not raised')
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:07:52.173265
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    var = lookup_module.sanity_check()


# Generated at 2022-06-25 11:08:01.538001
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_1 = lookup_module_0
    lookup_module_1.stride = 1
    lookup_module_1.end = 3
    lookup_module_1.start = 4
    lookup_module_0 = lookup_module_1
    lookup_module_0.sanity_check()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:08:05.168748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['5', '6', '7', '8']
    var_1 = ['5-8']
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = lookup_module_0.run(var_1, var_2, var_3)
    assert var_5 == var_0


# Generated at 2022-06-25 11:08:13.263263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_0 = lookup_reset()

    # Assign values for arguments of lookup_module_0.run()
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None

    lookup_module_0.reset()
    lookup_parse_simple_args(var_0)
    var_5 = lookup_sanity_check()
    var_6 = lookup_generate_sequence()
    var_5 = lookup_module_0.run(var_1, var_2, **var_3, **var_4)

# Generated at 2022-06-25 11:08:16.300815
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    term = '5'
    expected_result = ["1", "2", "3", "4", "5"]
    actual_result = lookup_module.run([term], None)
    assert (expected_result == actual_result)


# Generated at 2022-06-25 11:08:24.664760
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Tests the method generate_sequence of the class LookupModule
    # Ensures that the generate_sequence method of the LookupModule class returns
    # the correct result
    p = LookupModule()

    # Calling generate_sequence with a set of values
    p.start = 0x001
    p.end = 0x0fa
    p.stride = 0x10
    p.format = "%03x"
    result = p.generate_sequence()

    assert isinstance(result, list)
    assert len(result) == 0xfa - 0x001 + 1

# Generated at 2022-06-25 11:08:34.022793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n * Testing run method")
    # Setup
    terms = "start=0x0f00 count=4 format=%04x".split(" ")
    variables = None
    kwargs = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_0.run(terms, variables, **kwargs)
    var_1 = lookup_get_stride()
    var_2 = lookup_get_format()
    var_3 = lookup_get_end()
    var_4 = lookup_get_start()
    # Test
    assert var_0 == 1
    assert var_1 == 1
    assert var_2 == "%d"
    assert var_3 == None
    assert var_4 == 1


# Generated at 2022-06-25 11:08:38.954323
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term = None
    result = lookup_module_0.parse_simple_args(term)
    assert result == False


# Generated at 2022-06-25 11:08:43.563081
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    lookup_module_1.sanity_check()


# Generated at 2022-06-25 11:08:46.455835
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args(0)
    assert var_0 == 0

# unit test for method sanity_check of class LookupModule

# Generated at 2022-06-25 11:08:57.113319
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    print("Test for method parse_simple_args of class LookupModule")
    lookup_module_ = LookupModule()
    var = lookup_module_.parse_simple_args("5")

    # Assertion
    assert var == True



# Generated at 2022-06-25 11:08:59.043956
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_0.run()

# Generated at 2022-06-25 11:09:01.388353
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args()
    assert lookup_result == var_0



# Generated at 2022-06-25 11:09:03.766513
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    #
    # @param self instance of class LookupModule
    # @param term
    #
    # @return True or False
    #
    test_case_0()
    return



# Generated at 2022-06-25 11:09:06.363969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(LookupModule.run(terms, variables, kwargs)) == 0



# Generated at 2022-06-25 11:09:07.759973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["", "", "", ""], "", "")

# Generated at 2022-06-25 11:09:15.491437
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    # Call method generate_sequence with arguments
    # Return type is <class 'generator'>
    var_0 = xrange(lookup_module_0.start, lookup_module_0.end + (1 if lookup_module_0.stride >= 0 else -1), lookup_module_0.stride)
    for i in var_0:
        try:
            var_1 = lookup_module_0.format % i

            var_2 = yield var_1
        except ValueError:
            raise AnsibleError(
                "problem formatting %r with %r" % (i, lookup_module_0.format)
            )


# Generated at 2022-06-25 11:09:22.048351
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    var_1 = lookup_reset()
    var_2 = lookup_parse_kv_args(parse_kv("start=5 end=11 stride=2 format=0x%02x"))
    if (lookup_module_1.end < lookup_module_1.start):
        var_3 = True
    else:
        var_3 = False
    if (var_3):
        lookup_module_1.stride = -2
    var_4 = lookup_sanity_check()
    return var_4


# Generated at 2022-06-25 11:09:26.048915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = "start=2 count=4"
    var_1 = variables_
    var_2 = {"start" : 2, "count" : 4}
    obj_0 = lookup_module_0.run(var_0, var_1, var_2)
    assert lookup_module_0
    assert obj_0

# Generated at 2022-06-25 11:09:29.101455
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args("5")
    var_1 = (var_0 == False)
    assert var_1 == True, "Expect: True Actual: %s" % var_1


# Generated at 2022-06-25 11:09:43.823716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:09:50.231509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms = [ 'end=10' ], variables = [])
    assert var_0 == ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']

    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms = [ 'start=1 end=10' ], variables = [])
    assert var_1 == ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']

    lookup_module_2 = LookupModule()
    var_2 = lookup_module_2.run(terms = [ 'start=1 end=10/1' ], variables = [])


# Generated at 2022-06-25 11:09:52.636730
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_generate_sequence_0 = LookupModule()
    var_generate_sequence = lookup_module_generate_sequence_0.generate_sequence()


# Generated at 2022-06-25 11:09:59.214700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    var_1 = [terms, variables, kwargs]
    var_2 = lookup_module_2.run(var_1)
    var_3 = lookup_module_3.run(var_1)
    assert var_2 == var_3
    assert var_2 == var_3


# Generated at 2022-06-25 11:10:00.971398
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.parse_simple_args("5") == True


# Generated at 2022-06-25 11:10:09.236818
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_x = LookupModule()

    # Testing if raises error when end < start and stride > 0
    lookup_module_x.start = 5
    lookup_module_x.end   = 3
    lookup_module_x.stride= 2
    with pytest.raises(AnsibleError) as error:
        lookup_module_x.sanity_check()
    assert "to count backwards make stride negative" in str(error.value)

    # Testing if raises error when end > start and stride < 0
    lookup_module_x.start = 3
    lookup_module_x.end   = 5
    lookup_module_x.stride=-2
    with pytest.raises(AnsibleError) as error:
        lookup_module_x.sanity_check()

# Generated at 2022-06-25 11:10:15.954969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    params_0 = dict()
    params_0['end'] = 0x003f8

# Generated at 2022-06-25 11:10:20.700304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    var_0 = lookup_reset()
    var_1 = lookup_run(terms_0, var_0)
    assert var_1 == []


# Generated at 2022-06-25 11:10:28.905313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_with_sequence(start=1, end=3)
    var_2 = {"a": "b"}
    var_3 = lookup_with_sequence(start=1, end=3, format="x%d")
    var_4 = lookup_with_sequence(start=1, end=3, stride=2)
    var_5 = lookup_with_sequence(start=10, end=0, stride=-1)
    var_6 = lookup_with_sequence(count=4, format="x%d")
    var_7 = lookup_with_sequence(start=8, stride=2, count=6, format="dir-%02d")

# Generated at 2022-06-25 11:10:33.873926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.run([])
    assert var_1 is not None
    assert isinstance(var_1, list)
    assert len(var_1) == 1
    assert var_1[0] == ""


# Generated at 2022-06-25 11:10:47.598916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = { "start": 0, "end": 0, "stride": 1, "format": 0 }
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[{ "start": 0, "end": 2, "stride": 1, "format": 0 }], variables=0, )



# Generated at 2022-06-25 11:10:51.751203
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    valid_terms = [
        '5',
        '5-8',
        '2-10/2',
        '4:host%02d',
    ]
    for term in valid_terms:
        lookup_module_3 = LookupModule()
        assert lookup_module_3.parse_simple_args(term), "Invalid return value for parse_simple_args"

# Generated at 2022-06-25 11:10:55.038054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:11:00.133914
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()


if __name__ == '__main__':
    import sys
    if sys.argv[1] == 'test':
        test_LookupModule_sanity_check()
        test_case_0()

# Generated at 2022-06-25 11:11:02.455601
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_LookupModule_parse_simple_args(lookup_module_0, term_0)


# Generated at 2022-06-25 11:11:06.208322
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_mock_generate_sequence()


# Generated at 2022-06-25 11:11:08.724373
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = '01'
    var_0 = lookup_module_0.parse_simple_args(term_0)


# Generated at 2022-06-25 11:11:17.159535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    var_0 = lookup_module_0.parse_simple_args('10-30/2')
    # FIXME: This test case fails!
    lookup_module_0.check_sanity()
    var_0 = lookup_module_0.generate_sequence()
    lookup_module_0.reset()
    var_0 = lookup_module_0.parse_kv_args({'end': 14, 'start': 4})
    # FIXME: This test case fails!
    lookup_module_0.check_sanity()
    var_0 = lookup_module_0.generate_sequence()
    var_1 = lookup_module_0.run([], {})
    lookup_module_0.reset()

# Generated at 2022-06-25 11:11:21.855002
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    var_1 = lookup_reset()
    with pytest.raises(AnsibleError):
        lookup_module_1.sanity_check()


# Generated at 2022-06-25 11:11:23.479525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run("start=5 end=11 stride=2 format=0x%02x") # returns list
    assert len(var_0) == 4

# Generated at 2022-06-25 11:11:37.489712
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    res = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:11:43.720159
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()
    lookup_module_0.end = 0
    lookup_module_0.sanity_check()
    lookup_module_0.end = 2
    lookup_module_0.sanity_check()

# Generated at 2022-06-25 11:11:47.878827
# Unit test for method parse_simple_args of class LookupModule

# Generated at 2022-06-25 11:11:53.157492
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    # TODO


# Generated at 2022-06-25 11:11:57.761153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["start=0 end=32 format=testuser%02x"]
    var_0 = lookup_reset()
    assert lookup_module_0.run(terms_0, var_0) is not None


# Generated at 2022-06-25 11:12:02.453672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = [ "start=5 end=8" ]
    var_2 = {}
    var_3 = {}
    var_4 = lookup_module_1.run(var_1, var_2, **var_3)
    var_5 = [ "5", "6", "7", "8" ]
    success_1 = (var_4 == var_5)
    assert(success_1)


# Generated at 2022-06-25 11:12:13.043170
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = None #Cannot initialize type to None
    var_2 = None #Cannot initialize type to None
    var_3 = None #Cannot initialize type to None
    var_4 = None #Cannot initialize type to None
    var_5 = None #Cannot initialize type to None
    var_6 = None #Cannot initialize type to None
    var_7 = None #Cannot initialize type to None
    var_8 = None #Cannot initialize type to None
    var_9 = None #Cannot initialize type to None
    var_10 = None #Cannot initialize type to None
    var_11 = None #Cannot initialize type to None
    var_12 = None #Cannot initialize type to None
    var_13 = None #Cannot

# Generated at 2022-06-25 11:12:17.632299
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    var = lookup_reset()
    try:
        lookup_module.sanity_check()
    except AnsibleError as e:
        assert e.message == 'must specify count or end in with_sequence'


# Generated at 2022-06-25 11:12:22.021721
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    test_case_0()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:27.797255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    class AnsibleVars:
        def __init__(self):
            pass

    ansible_vars = AnsibleVars()

    lookup_module_0.run(terms=[], variables=ansible_vars)

# Generated at 2022-06-25 11:12:37.596262
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_generate_sequence_0 = LookupModule()
    var_0 = lookup_generate_sequence_0.generate_sequence()
    assert var_0 is not None


# Generated at 2022-06-25 11:12:47.769272
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_get_range()
    var_2 = (a == b)
    var_3 = lookup_get_range()
    var_4 = (a == b)
    var_5 = (d == e)
    var_6 = lookup_get_range()
    var_7 = (a == b)
    var_8 = (d == e)
    var_9 = lookup_get_range()
    var_10 = (a == b)
    var_11 = (d == e)
    var_12 = c == 0
    var_13 = ((var_7 or var_8) or (var_9 and var_11))
    var_14 = (c == 0)

# Generated at 2022-06-25 11:12:50.708166
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:55.810083
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:12:59.299004
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = -1
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    lookup_module_0.sanity_check()
# vim: expandtab ts=4 sw=4

# Generated at 2022-06-25 11:13:06.655850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #remove test/test_lookup_plugins/sequence/__init__.pyc from sys.path
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    lookup_module_0 = LookupModule()
    var_0 = lookup

# Generated at 2022-06-25 11:13:09.424685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = ["6", "7", "8", "9", "10"]
    var = [ "6", "7", "8", "9", "10"]
    lookup_module = LookupModule()
    assert lookup_module.run(term,var) == var

# Generated at 2022-06-25 11:13:12.071478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_8 = [ 'end=32', 'start=0', 'format=testuser%02x' ]
    var_9 = {}
    res_0 = lookup_module_0.run(var_8, var_9)


# Generated at 2022-06-25 11:13:18.792136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "foo"
    variables = "bar"
    kwargs = "foo"
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms, variables,**kwargs)
    assert result_0 == "foo"



# Generated at 2022-06-25 11:13:22.570662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = run(['5'], [], [])

# Generated at 2022-06-25 11:13:42.809049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables, **kwargs)
# Mocking of method __init__ of class LookupModule

# Generated at 2022-06-25 11:13:43.719348
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:13:47.768265
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    # start case 1
    var_0 = lookup_module_0.sanity_check()
    # end case
    assert True


# Generated at 2022-06-25 11:13:49.881163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()

    assert(len(results) == expected_length)
    assert(results == expected_results)

# Generated at 2022-06-25 11:13:59.872869
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    lookup_module_1 = LookupModule()
    # Start value is set to 1 here and then sequence is generated.
    lookup_module_1.start = 1
    lookup_module_1.stride = 1
    lookup_module_1.end = 7
    var_1 = lookup_module_1.generate_sequence()

    assert next(var_1) == 1
    assert next(var_1) == 2
    assert next(var_1) == 3
    assert next(var_1) == 4
    assert next(var_1) == 5
    assert next(var_1) == 6
    assert next(var_1) == 7

    lookup_module_2 = LookupModule()
    lookup_module_2.start = 4
    lookup_module_2.stride = 3
    lookup_module_2.end

# Generated at 2022-06-25 11:14:02.358513
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run("3")
    assert var_0  == ["1", "2", "3"]


# Generated at 2022-06-25 11:14:08.055581
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()  # instantiate LookupModule
    # test cases:
    var_1 = lookup_module_0.parse_simple_args('')
    var_2 = lookup_module_0.parse_simple_args('')
    var_3 = lookup_module_0.parse_simple_args('')
    var_4 = lookup_module_0.parse_simple_args('')
    var_5 = lookup_module_0.parse_simple_args('')
    var_6 = lookup_module_0.parse_simple_args('')
    var_7 = lookup_module_0.parse_simple_args('')
    var_8 = lookup_module_0.parse_simple_args('')
    var_9 = lookup_module_0.parse_simple

# Generated at 2022-06-25 11:14:14.417931
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()

    
    
    
    
    
    
    
    # Formatting string with a dynamically generated part.
    var_1 = lookup_module_0.run(test_terms_0,test_variables_0)
    assert var_1 == test_results_0



# Generated at 2022-06-25 11:14:23.958654
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    var_0 = ""  # parse_simple_args(term)
    if var_0:
        raise AssertionError("var_0 = %r" % var_0)
    var_1 = "2"  # parse_simple_args(term)
    if var_1:
        raise AssertionError("var_1 = %r" % var_1)
    var_2 = "5-8"  # parse_simple_args(term)
    if var_2:
        raise AssertionError("var_2 = %r" % var_2)
    var_3 = "2-10/2"  # parse_simple_args(term)
    if var_3:
        raise AssertionError("var_3 = %r" % var_3)

# Generated at 2022-06-25 11:14:25.169721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["1", "2", "3"]
    variables = []
    lookup_module.run(terms=terms, variables=variables)

# Generated at 2022-06-25 11:14:50.575330
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:14:53.893143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0_0 = LookupModule()
    var_0_0 = [0, 0]
    var_0_1 = {0: 0, 1: 0}
    var_0_2 = {}
    var_0_3 = test_run()
    var_0_4 = None
    var_0_5 = lookup_module_0_0.run(var_0_3, var_0_4)



# Generated at 2022-06-25 11:14:59.048531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['foo'], ['bar'], baz='qux')


# Generated at 2022-06-25 11:15:04.016192
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
	# generate_sequence() should return list of elements of type str
    assert True # TODO: implement your test here


# Generated at 2022-06-25 11:15:05.626280
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.sanity_check() == None


# Generated at 2022-06-25 11:15:14.400123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [
        'start=1',
        'end=10',
        'stride=2',
        'format=testuser%02x'
    ]
    var_1 = {}
    var_2 = {}
    var_3 = [
        'testuser01',
        'testuser03',
        'testuser05',
        'testuser07',
        'testuser09'
    ]
    assert lookup_module_0.run(var_0, var_1, var_2, **var_3) == (
        'testuser01',
        'testuser03',
        'testuser05',
        'testuser07',
        'testuser09'
    )


# Generated at 2022-06-25 11:15:16.805079
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
 

# Generated at 2022-06-25 11:15:25.724490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = [0.1729, 0.5111, 0.9698]
    var_1 = {'shuffle(0)': 0, 'shuffle(4)': 4, 'shuffle(2)': 2, 'shuffle(1)': 1, 'shuffle(3)': 3}
    var_2 = None
    var_3 = {'shuffle(3)': 3, 'shuffle(2)': 2, 'shuffle(0)': 0, 'shuffle(1)': 1, 'shuffle(4)': 4}
    var_4 = lookup_reset()

# Generated at 2022-06-25 11:15:27.056663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    expected = [1]
    actual = [1]
    assert expected == actual


# Generated at 2022-06-25 11:15:33.038411
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = "0"
    var_0 = lookup_module_0.parse_simple_args(term_0)
    assert var_0 == True
    print("\n{!r} = {!r}".format(var_0, True))
