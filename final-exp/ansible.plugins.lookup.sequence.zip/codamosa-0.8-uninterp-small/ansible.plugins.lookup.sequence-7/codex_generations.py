

# Generated at 2022-06-25 11:06:44.120737
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.sanity_check()
    except SystemExit as e:
        assert(str(e))
    except Exception as e:
        var_0 = lookup_reset("error")


# Generated at 2022-06-25 11:06:52.808378
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    if True:  # Just to avoid PyChecker warning
        lookup_module_0.reset()
#         lookup_module_0.parse_kv_args()
#         lookup_module_0.parse_simple_args()
#         lookup_module_0.sanity_check()
#         lookup_module_0.generate_sequence()
        lookup_module_0.run(["1-3"],{})
        pass


# Generated at 2022-06-25 11:06:58.675707
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.end = 0
    lookup_module.stride = 0
    lookup_module.start = 0

    lookup_module_0.sanity_check()

# Generated at 2022-06-25 11:07:01.279407
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    # This is a stub


# Generated at 2022-06-25 11:07:06.740982
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule(execute = None)
    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.sanity_check()


# Generated at 2022-06-25 11:07:10.494785
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    var_1 = lookup_reset()
    var_2 = parse_simple_args()
    return 0


# Generated at 2022-06-25 11:07:14.892650
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.parse_kv_args(var_0)
    except Exception as e:
        assert(type(e) == AnisbleError)
        assert(e.msg == "can't parse start=%s as integer")
    try:
        lookup_module_0.parse_kv_args(var_1)
    except Exception as e:
        assert(type(e) == AnisbleError)
        assert(e.msg == "unrecognized arguments to with_sequence: %s")


# Generated at 2022-06-25 11:07:19.928147
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'

    with pytest.raises(AnsibleError):
        lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:07:30.582795
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():

    lookup_module_0 = LookupModule()
    var_1 = {"start": "2", "end": "10", "stride": "2", "format": "0x%02x"}
    lookup_module_0.parse_kv_args(var_1)
    var_2 = lookup_module_0.start
    assert var_2 == 2
    var_3 = lookup_module_0.end
    assert var_3 == 10
    var_4 = lookup_module_0.stride
    assert var_4 == 2
    var_5 = lookup_module_0.format
    assert var_5 == "0x%02x"



# Generated at 2022-06-25 11:07:32.969615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.generate_sequence()
    print(var_1)

# Generated at 2022-06-25 11:07:47.590050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: add real unit tests
    # xfail: AssertionError
    assert lookup_module_0.run(terms=["arg1", "arg2"], variables={}) == [], "Test Failure: ".format()
    # xfail: AssertionError
    assert lookup_module_0.run(terms=[], variables={}) == [], "Test Failure: ".format()
    # xfail: AssertionError
    assert lookup_module_0.run(terms=[], variables={}) == [], "Test Failure: ".format()


# Generated at 2022-06-25 11:07:57.400974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['/first-term', '/second-term', '/third-term']
    variables = {}
    results = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:08:00.957614
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = lookup_module_0()
    match = match()
    term = term()
    lookup_module_0.parse_simple_args(term)


# Generated at 2022-06-25 11:08:07.811752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([
        'start=1 end=13 format=host%02d',
        'start=20 count=4 stride=-2 format=host%%%02d',
        '5',
        'start=0 end=10/2',
        'start=0 end=10:strange_%03d',
        'start=0 end=6/2:value_%03d',
        'start=0/2 end=6',
        'start=0 start=1'
    ], {}, **{})

# Generated at 2022-06-25 11:08:12.660442
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term = "5"
    result = lookup_module_0.parse_simple_args(term)
    assert result == False
    term = "5-8"
    result = lookup_module_0.parse_simple_args(term)
    assert result == False
    term = "2-10/2"
    result = lookup_module_0.parse_simple_args(term)
    assert result == False
    term = "4:host%02d"
    result = lookup_module_0.parse_simple_args(term)
    assert result == False


# Generated at 2022-06-25 11:08:20.548346
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.result_0 = None
    lookup_module_0.start = None
    lookup_module_0.end = None
    lookup_module_0.stride = None
    lookup_module_0.format = None
    lookup_module_0.count = None
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    try:
        lookup_module_0.sanity_check()
    except:
        lookup_module_0.result_0 = -1
    else:
        lookup_module_0.result_0 = 0

# Generated at 2022-06-25 11:08:30.639084
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 32
    lookup_module_0.stride = 1
    lookup_module_0.format = 'testuser%02x'

# Generated at 2022-06-25 11:08:36.018240
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 1
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        assert(str(e) == 'must specify count or end in with_sequence')

    lookup_module_0 = LookupModule()
    lookup_module_0.count = 0
    lookup_module_0.end = 5
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        assert(str(e) == 'can\'t specify both count and end in with_sequence')


# Generated at 2022-06-25 11:08:41.659307
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.end = 10
    lookup_module_0.stride = 1
    lookup_module_0.format = 'test%d'

    returned_0 = lookup_module_0.generate_sequence()
    for item in returned_0:
        print(item)

# Generated at 2022-06-25 11:08:48.382112
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    try:
        terms = [
            '5',
            '5-8',
            '2-10/2',
            '4:host%02d',
            'start=5 end=11 stride=2 format=0x%02x',
            'count=5',
            'start=0x0f00 count=4 format=%04x',
            'start=0 count=5 stride=2',
            'start=1 count=5 stride=2'
        ]
        for term in terms:
            lookup_module_0 = LookupModule()
            lookup_module_0.parse_simple_args(term)
    except Exception as err:
        print("Exception caught in test_LookupModule_parse_simple_args: " + str(err))


# Generated at 2022-06-25 11:09:03.519968
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:09:09.859548
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 0
    lookup_module_0.start = 1
    lookup_module_0.format = "%d"
    lookup_module_0.count = 10
    results_list = list(lookup_module_0.generate_sequence())
    assert results_list == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


# Generated at 2022-06-25 11:09:20.137280
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # Test 1

    term_1 = "0x3ff"
    lookup_module_0.parse_simple_args(term_1)
    assert lookup_module_0.start == 1
    assert lookup_module_0.count is None
    assert lookup_module_0.end == 1023
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == "%d"

    # Test 2

    term_2 = "0x3ff"
    lookup_module_0.parse_simple_args(term_2)
    assert lookup_module_0.start == 1
    assert lookup_module_0.count is None
    assert lookup_module_0.end == 1023
    assert lookup_module_0.stride == 1
    assert lookup

# Generated at 2022-06-25 11:09:24.637537
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.generate_sequence() == ['%d']


# Generated at 2022-06-25 11:09:28.079796
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    start_0 = 1
    end_0 = 10
    stride_0 = 1
    format_0 = "%d"
    result_0 = lookup_module_0.generate_sequence(start_0, end_0, stride_0, format_0)


# Generated at 2022-06-25 11:09:32.684701
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """test parse_simple_args of class LookupModule"""
    lookup_module_1 = LookupModule()
    lookup_module_1.reset()
    ret1 = lookup_module_1.parse_simple_args("2-10/2")
    assert ret1 == True
    lookup_module_2 = LookupModule()
    lookup_module_2.reset()
    ret2 = lookup_module_2.parse_simple_args("2-10")
    assert ret2 == True
    lookup_module_3 = LookupModule()
    lookup_module_3.reset()
    ret3 = lookup_module_3.parse_simple_args("2")
    assert ret3 == True
    lookup_module_4 = LookupModule()
    lookup_module_4.reset()
    ret4 = lookup_module_4.parse_

# Generated at 2022-06-25 11:09:43.087054
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.parse_simple_args('5') == False
    assert lookup_module_0.start == 1
    assert lookup_module_0.count == None
    assert lookup_module_0.end == None
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == '%d'
    assert lookup_module_0.stride == 1
    assert lookup_module_0.parse_simple_args('5-8') == True
    assert lookup_module_0.start == 5
    assert lookup_module_0.count == None
    assert lookup_module_0.end == 8
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == '%d'
    assert lookup_module_

# Generated at 2022-06-25 11:09:45.527553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    run_str_0 = lookup_module_0.run('lookup_module_0_var_0')
    assert run_str_0 is not None


# Generated at 2022-06-25 11:09:46.319774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=[], variables=()) == []


# Generated at 2022-06-25 11:09:48.621546
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # Test for method parse_simple_args.
    data = '5'
    assert lookup_module_0.parse_simple_args(data)


# Generated at 2022-06-25 11:09:53.915062
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.generate_sequence() is not None


# Generated at 2022-06-25 11:09:58.583317
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_instance = LookupModule()
    lookup_module_instance.count = None
    lookup_module_instance.end = None
    with pytest.raises(AnsibleError) as result:
        lookup_module_instance.sanity_check()


# Generated at 2022-06-25 11:10:00.363253
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.parse_simple_args("")


# Generated at 2022-06-25 11:10:04.832661
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.reset()

    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = None
    lookup_module.stride = 1
    lookup_module.format = "%d"
    lookup_module.sanity_check()
    assert lookup_module.generate_sequence() == xrange(1,10)


# Generated at 2022-06-25 11:10:12.020500
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    """
        Tests: https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/lookup/sequence.py
        Ansible tested on: https://github.com/ansible/ansible-modules-core/blob/devel/system/setup.py
    """
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 0
    lookup_module_0.count = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    expected_result = ["0", "1", "2", "3", "4"]
    assert list(lookup_module_0.generate_sequence()) == expected_result


# Generated at 2022-06-25 11:10:15.526566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    # Use this to verify results of lookup module
    returned_value_0 = lookup_module_0.run(terms_0, variables_0, **{})
    assert returned_value_0 == None


# Generated at 2022-06-25 11:10:22.624198
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.end = 2
    lookup_module_1.stride = 1
    lookup_module_1.format = '%d'
    assert lookup_module_1.generate_sequence() == ['1', '2']


# Generated at 2022-06-25 11:10:24.890087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    assert lookup_module_0.run(terms_0, set()) == []


# Generated at 2022-06-25 11:10:30.919486
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.count = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.format = 0
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:10:32.956211
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.parse_simple_args("0") == True


# Generated at 2022-06-25 11:10:40.209480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:10:42.172182
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    e = None
    try:
        lookup_module_0.generate_sequence()
    except Exception as e:
        pass
    assert e is not None


# Generated at 2022-06-25 11:10:44.260700
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()


# Generated at 2022-06-25 11:10:49.378982
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()
    lookup_module_1.stride = 1
    lookup_module_1.start = 1
    lookup_module_1.format = '%d'
    lookup_module_1.end = 6
    assert list(lookup_module_1.generate_sequence()) == [ "1", "2", "3", "4", "5", "6" ]


# Generated at 2022-06-25 11:10:58.816324
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 100
    lookup_module_0.end = 22
    lookup_module_0.stride = -1
    lookup_module_0.format = "%d"
    sequence = lookup_module_0.generate_sequence()

    list_0 = []
    list_1 = range(20)
    list_1 = list(map(str, list_1))

    for i in sequence:
        list_0.append(i)

    error_list_0 = list((x, y) for x, y in zip(list_0, list_1) if x != y)

    assert len(error_list_0) == 0



# Generated at 2022-06-25 11:11:02.239627
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    result = True
    sequence = []
    try:
        for i in lookup_module_0.generate_sequence():
            sequence.append(i)
    except Exception as e:
        result = False
        print(e)
    print('sequence: ', sequence)
    assert result


# Generated at 2022-06-25 11:11:12.883157
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    assert lookup_module.generate_sequence(start=10, end=0, stride=-1) == ['10', '9', '8', '7', '6', '5', '4', '3', '2', '1']
    assert lookup_module.generate_sequence(start=0, end=10, format="%02d", stride=2) == ['00', '02', '04', '06', '08']
    assert lookup_module.generate_sequence(start=4, end=16, stride=2) == ['4', '6', '8', '10', '12', '14', '16']
    assert lookup_module.generate_sequence(count=4, start=0) == ['0', '1', '2', '3']
    assert lookup_module.generate_

# Generated at 2022-06-25 11:11:23.161156
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    # testcase 0
    testcase_0_term = 1
    result_0 = lookup_module_0.parse_simple_args(testcase_0_term)
    assert result_0 is False

    # testcase 1
    testcase_1_term = 1-8
    result_1 = lookup_module_0.parse_simple_args(testcase_1_term)
    assert result_1 is False

    # testcase 2
    testcase_2_term = 1-8/2
    result_2 = lookup_module_0.parse_simple_args(testcase_2_term)
    assert result_2 is False

    # testcase 3

# Generated at 2022-06-25 11:11:25.427589
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.parse_simple_args("1-10/2")



# Generated at 2022-06-25 11:11:30.327082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = ['a', 'b', 'c']
    variables_0 = ['d', 'e', 'f']
    kwargs_0 = {'g': 'h'}
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)



# Generated at 2022-06-25 11:11:41.839249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.stride = 1
    lookup_module_0.end = 0
    lookup_module_0.start = 0
    lookup_module_0.format = '%d'
    lookup_module_0.count = None
    var_terms = []
    var_terms.insert(0, 'start=0 end=0 stride=-1')
    var_variables = {}
    var_variables['ANYTHING'] = 'ANYTHING'
    var_kwargs = {}
    var_kwargs['ANYTHING'] = 'ANYTHING'

# Generated at 2022-06-25 11:11:43.709483
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    try:
        assert lookup_module_0.generate_sequence() is not None
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-25 11:11:54.160390
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.format = "%d"
    lookup_module_0.start = 0
    lookup_module_0.end = 16
    lookup_module_0.stride = 2
    expected = list()
    expected.append("0")
    expected.append("2")
    expected.append("4")
    expected.append("6")
    expected.append("8")
    expected.append("10")
    expected.append("12")
    expected.append("14")
    expected.append("16")
    given = list()
    for element in lookup_module_0.generate_sequence():
        given.append(element)
    assert isinstance(given, list)
    assert len(expected) == len(given)
    assert expected == given

# Unit test

# Generated at 2022-06-25 11:12:02.483735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=["end=10"], variables='', warning='', use_cache='')
    assert result == ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]

    result = lookup_module_0.run(terms=["start=0 end=10"], variables='', warning='', use_cache='')
    assert result == ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]

    result = lookup_module_0.run(terms=["start=5 end=10"], variables='', warning='', use_cache='')

# Generated at 2022-06-25 11:12:10.431722
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    lookup_module_0.start = int(9, 0)
    lookup_module_0.end = int(13, 0)
    lookup_module_0.stride = int(1, 0)
    lookup_module_0.format = "%d"
    sequence_0 = list(lookup_module_0.generate_sequence())
    assert sequence_0 == ["9", "10", "11", "12", "13"]


# Generated at 2022-06-25 11:12:21.521044
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    """
    Test with simple argument
    """
    lookup_module = LookupModule()
    lookup_module.reset()

    assert lookup_module.parse_simple_args('1') is False
    assert lookup_module.start == 1
    assert lookup_module.end == 1
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    assert lookup_module.count is None
    lookup_module.reset()

    assert lookup_module.parse_simple_args('5-8') is False
    assert lookup_module.start == 5
    assert lookup_module.end == 8
    assert lookup_module.stride == 1
    assert lookup_module.format == "%d"
    assert lookup_module.count is None
    lookup_module.reset()

    assert lookup_module.parse_simple_args

# Generated at 2022-06-25 11:12:27.869758
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()

    lookup_module_0.end = 1
    lookup_module_0.count = None
    lookup_module_0.stride = 1
    lookup_module_0.start = 2

    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:29.775293
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    returned_result = lookup_module.parse_simple_args('5-8')
    assert returned_result == True


# Generated at 2022-06-25 11:12:33.692774
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()

    start = 1
    end = 20
    stride = 1
    format = "%d"
    lookup_module_1.start = start
    lookup_module_1.end = end
    lookup_module_1.stride = stride
    lookup_module_1.format = format
    lookup_module_1.sanity_check()
    lookup_module_1.generate_sequence()


# Generated at 2022-06-25 11:12:37.182732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # We have no idea which terms we're going to be using and there is no
    # value we can assign to variables
    terms = [
    ]
    variables = {}
    # This is what we expect the method to return
    result = [
    ]
    # This is what it actually returns
    assert lookup_module_1.run(terms, variables) == result


# Generated at 2022-06-25 11:12:44.165295
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    ret_val = lookup_module_0.parse_simple_args(None)
    assert ret_val == False


# Generated at 2022-06-25 11:12:52.477486
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.count = None
    lookup_module.end = None
    assert AnsibleError == type(lookup_module.sanity_check())
    lookup_module.count = None
    lookup_module.end = 1
    assert None == type(lookup_module.sanity_check())
    lookup_module.count = 1
    lookup_module.end = None
    assert AnsibleError == type(lookup_module.sanity_check())
    lookup_module.count = 1
    lookup_module.end = 1
    assert AnsibleError == type(lookup_module.sanity_check())
    lookup_module.count = None
    lookup_module.end = None
    assert AnsibleError == type(lookup_module.sanity_check())
    lookup_module.count

# Generated at 2022-06-25 11:12:56.239764
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 9
    lookup_module_0.stride = 2
    lookup_module_0.end = 29
    lookup_module_0.format = 'testuser%02x'
    assert lookup_module_0.generate_sequence() == ['testuser09', 'testuser0b', 'testuser0d', 'testuser0f', 'testuser11', 'testuser13', 'testuser15', 'testuser17', 'testuser19', 'testuser1b', 'testuser1d', 'testuser1f']


# Generated at 2022-06-25 11:13:03.391949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    dummy_terms_1 = [
        '5-8',
        '2-10/2',
        '4:host%02d',
        'start=5 end=11 stride=2 format=0x%02x',
        'count=5',
        'start=0x0f00 count=4 format=%04x',
        'start=0 count=5 stride=2',
        'start=1 count=5 stride=2',
    ]

# Generated at 2022-06-25 11:13:10.222568
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()

    try:
        lookup_module.start =1
        lookup_module.end = 20
        lookup_module.sanity_check()
        assert True
    except AnsibleError as e:
        assert False
    try:
        lookup_module.count = 10
        lookup_module.sanity_check()
        assert False
    except AnsibleError as e:
        assert True


# Generated at 2022-06-25 11:13:14.694558
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:13:25.124358
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = None
    lookup_module.end = 2
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["1", "2"]
    lookup_module.start = 5
    lookup_module.count = None
    lookup_module.end = 8
    lookup_module.stride = 1
    lookup_module.format = "%d"
    assert list(lookup_module.generate_sequence()) == ["5", "6", "7", "8"]
    lookup_module.start = 2
    lookup_module.count = None
    lookup_module.end = 10
    lookup_module.stride = 2
    lookup_module.format

# Generated at 2022-06-25 11:13:30.760557
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():

    # Error due to Exception #1
    try:
        test_LookupModule_parse_simple_args_0(
            '''2-4/2''',
        )
    except:
        pass
    else:
        raise Exception(
            'ExpectedException not raised for test_LookupModule_parse_simple_args_0'
        )


# Generated at 2022-06-25 11:13:33.332178
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.stride = 1
    lookup_module.end = 5
    lookup_module.format = "%d"
    lookup_module.generate_sequence()


# Generated at 2022-06-25 11:13:41.323979
# Unit test for method generate_sequence of class LookupModule

# Generated at 2022-06-25 11:13:50.294389
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    obj = LookupModule()
    seq = obj.generate_sequence()
    x = next(seq)
    print(x)


# Generated at 2022-06-25 11:13:53.369318
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    assert len(list(lookup_module_0.generate_sequence())) == 0



# Generated at 2022-06-25 11:13:57.734525
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term = "0x7f"
    lookup_module_0.parse_simple_args(term)
    assert lookup_module_0.start == 127
    assert lookup_module_0.count is None
    assert lookup_module_0.end == 127
    assert lookup_module_0.stride == 1
    assert lookup_module_0.format == "%d"


# Generated at 2022-06-25 11:14:05.876577
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    assert(LookupModule().parse_simple_args('8-10') == True)
    assert(LookupModule().parse_simple_args('0x8-0x10') == True)
    assert(LookupModule().parse_simple_args('0x8-0x10/2') == True)
    assert(LookupModule().parse_simple_args('0x4:host%02x') == True)
    assert(LookupModule().parse_simple_args('10/2:host%02x') == True)
    assert(LookupModule().parse_simple_args('10/2') == True)
    assert(LookupModule().parse_simple_args('0x8-10/2') == True)

# Generated at 2022-06-25 11:14:15.003618
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.count = None
    lookup_module_0.end = None
    assert_raises(AnsibleError, lookup_module_0.sanity_check)
    lookup_module_0.reset()
    lookup_module_0.count = 1
    lookup_module_0.end = 1
    assert_raises(AnsibleError, lookup_module_0.sanity_check)
    lookup_module_0.reset()
    lookup_module_0.count = 1
    lookup_module_0.end = None
    assert_raises(AnsibleError, lookup_module_0.sanity_check)
    lookup_module_0.reset()
    lookup_module_0.count = None
   

# Generated at 2022-06-25 11:14:18.475515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}
    kwargs = {
    }
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(terms, variables, **kwargs), list)


# Generated at 2022-06-25 11:14:27.033267
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.parse_simple_args('14') == True
    assert lookup_module_1.start == lookup_module_1.end == 14
    assert lookup_module_1.count is None
    assert lookup_module_1.stride == 1
    assert lookup_module_1.format == '%d'
    lookup_module_1.reset()

    assert lookup_module_1.parse_simple_args('-5') == False
    lookup_module_1.reset()

    assert lookup_module_1.parse_simple_args('0x10') == True
    assert lookup_module_1.end == 16
    assert lookup_module_1.start == 1
    lookup_module_1.reset()

    assert lookup_module_1.parse_simple_args

# Generated at 2022-06-25 11:14:36.844291
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
  term = '2-10/2'
  match = SHORTCUT.match(term)
  assert match.group(1) == '2'
  assert match.group(2) == '10'
  assert match.group(3) == '/2'
  assert match.group(4) == '2'
  assert match.group(5) == None
  assert match.group(6) == None
  term = '1'
  match = SHORTCUT.match(term)
  assert match.group(1) == None
  assert match.group(2) == '1'
  assert match.group(3) == None
  assert match.group(4) == None
  assert match.group(5) == None
  assert match.group(6) == None
  term = '0'
  match = SHORTC

# Generated at 2022-06-25 11:14:39.977627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tf_matrix_0 = [None]
    terms_0 = tf_matrix_0
    variables_0 = {
        'data': random.randint(0, 9999),
    }
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms_0, variables_0)

# Generated at 2022-06-25 11:14:47.099274
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # Test with start = , end = , stride = , format = 

# Generated at 2022-06-25 11:15:01.396416
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 10
    lookup_module.stride = 1
    lookup_module.format = "%d"
    expected = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    results = list(lookup_module.generate_sequence())
    assert(len(results) == len(expected))
    assert(results == expected)


# Generated at 2022-06-25 11:15:02.213167
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_1 = LookupModule()



# Generated at 2022-06-25 11:15:05.711867
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    # Input parameters
    lookup_module_0 = LookupModule()

    # Output parameters
    lookup_module_generate_sequence = None

    lookup_module_generate_sequence = lookup_module_0.generate_sequence()
    assert lookup_module_generate_sequence == None



# Generated at 2022-06-25 11:15:12.460854
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.count = 4
    lookup_module.end = None
    lookup_module.stride = 1
    # Run the code
    results = lookup_module.generate_sequence()
    
    assert results[2] == "3"
    

# Generated at 2022-06-25 11:15:15.540598
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    tester = LookupModule()
    tester.reset()
    tester.start = 1
    tester.end = 16
    tester.stride = 2
    tester.sanity_check()


# Generated at 2022-06-25 11:15:22.049322
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    # Testing when self.stride >= 0
    lookup_module_0.stride = 1
    assert list(lookup_module_0.generate_sequence()) == ["1", "2", "3", "4", "5"]

    # Testing when self.stride < 0
    lookup_module_0.stride = -1
    assert list(lookup_module_0.generate_sequence()) == ["5", "4", "3", "2", "1"]


# Generated at 2022-06-25 11:15:28.457023
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:15:34.952379
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    result = list(LookupModule.generate_sequence(lookup_module_0, 0, 0, 0, "%d"))
    
    # The following are fixed tests for the method generate_sequence of class LookupModule.
    assert (result == [])


# Generated at 2022-06-25 11:15:41.850199
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.count = 1
    lookup_module_0.end = 2
    lookup_module_0.stride = 1
    lookup_module_0.format = '%d'
    assert(list(lookup_module_0.generate_sequence()) == ['1', '2'])


# Generated at 2022-06-25 11:15:44.377216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True, "No unit tests written for method run of class LookupModule"

# Generated at 2022-06-25 11:15:55.636674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:15:59.528597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run()
    assert result_0 != None


# Generated at 2022-06-25 11:16:06.079057
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():

    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()

    lookup_module_0.start = 0
    lookup_module_0.end = 10
    lookup_module_0.stride = 2
    lookup_module_0.format = '%d'

    lookup_module_0.generate_sequence()

    var_0 = lookup_reset()

    lookup_module_0.start = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.format = '%d'

    lookup_module_0.generate_sequence()

    var_0 = lookup_reset()

    lookup_module_0.start = 0
    lookup_module_0.end = 1
    lookup_module_0.stride = 2
   

# Generated at 2022-06-25 11:16:13.773648
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()

    str_0 = "start=0x0f00 count=2"
    # Try to parse 'str_0' using parse_kv_args method of LookupModule
    try:
        lookup_module.parse_kv_args(parse_kv(str_0))
    except AnsibleError:
        raise
    except Exception as e:
        raise AnsibleError("unknown error parsing with_sequence arguments: %r. Error was: %s" % (str_0, e))

    # Try to parse 'str_0' using parse_simple_args method of LookupModule
    try:
        lookup_module.parse_simple_args(str_0)
    except AnsibleError:
        raise

# Generated at 2022-06-25 11:16:18.835813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_items_0 = lookup_module_0.run(terms=["blah"], variables=None, **kwargs)
    assert type(var_items_0) == list, "result is not a list: %r" % var_items_0
    assert not var_items_0, "result list should be empty: %r" % var_items_0
    var_items_1 = lookup_module_0.run(terms=["blah-blah"], variables=None, **kwargs)
    assert type(var_items_1) == list, "result is not a list: %r" % var_items_1
    assert not var_items_1, "result list should be empty: %r" % var_items_1
    var_items_2 = lookup_module_0

# Generated at 2022-06-25 11:16:25.587713
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    for var_0 in lookup_module_0.generate_sequence():
        var_0 = lookup_module_0.generate_sequence()
        var_0 = lookup_module_0.generate_sequence()
        var_0 = lookup_module_0.generate_sequence()
        var_0 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:16:26.465284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()

# Generated at 2022-06-25 11:16:31.951499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(['1-2/2'], dict())
    l.run(['1-2/2:%d'], dict())
    l.run(['1-2/2:%03d'], dict())
    l.run(['1-2/2:%02d'], dict())
    l.run(['1-2/2:%02x'], dict())
    l.run(['1-2/2:%03x'], dict())
    l.run(['1-2/2:%04x'], dict())
    l.run(['1-2/2:%04x'], dict())
    l.run(['1:%02x'], dict())
    l.run(['1-2/2:%x'], dict())
   

# Generated at 2022-06-25 11:16:33.887341
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 2
    assert list(lookup_module.generate_sequence()) == [1, 2]