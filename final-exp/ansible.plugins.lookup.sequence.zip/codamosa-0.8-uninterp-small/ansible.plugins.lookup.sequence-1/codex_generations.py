

# Generated at 2022-06-25 11:06:46.596321
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    var_1 = parse_kv('start:0')
    lookup_module_0.parse_kv_args(var_1)
    var_2 = parse_kv('end:10')
    lookup_module_0.parse_kv_args(var_2)
    var_3 = parse_kv('stride:2')
    lookup_module_0.parse_kv_args(var_3)
    var_4 = parse_kv('format:0x%02x')
    lookup_module_0.parse_kv_args(var_4)


# Generated at 2022-06-25 11:06:53.752657
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_1 = "10"
    var_2 = lookup_module_0.parse_simple_args(var_1)
    assert var_2 == True
    var_1 = "10-20"
    var_2 = lookup_module_0.parse_simple_args(var_1)
    assert var_2 == True
    var_1 = "10-20/2"
    var_2 = lookup_module_0.parse_simple_args(var_1)
    assert var_2 == True
    var_1 = "10-20/2:hello%d"
    var_2 = lookup_module_0.parse_simple_args(var_1)
    assert var_2 == True

# Generated at 2022-06-25 11:06:56.823320
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:06:59.566677
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    # First testcase before this one
    #self.assertEqual(["host01","host02","host03","host04"], lookup_module_0.generate_sequence())


# Generated at 2022-06-25 11:07:10.726324
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args("start=2 end=3")
    if var_0 != False:
        raise AssertionError('var_0 should be False, but it is ' + str(var_0))
    var_1 = lookup_module_0.parse_simple_args("start=2 end=3 stride=4")
    if var_1 != False:
        raise AssertionError(
            'var_1 should be False, but it is '+
            str(var_1)
            )
    var_2 = lookup_module_0.parse_simple_args("start=2 end=3 stride=4 format=5")

# Generated at 2022-06-25 11:07:20.510960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    # Construction of an instance of class LookupModule
    lookup_module_0 = LookupModule()

    # Call method run with parameters for for the test case
    var_0 = lookup_module_0.run(terms=['start=0 end=1337 format=testuser%04x'], variables=dict(), **{'unsafe': True})

# Generated at 2022-06-25 11:07:27.744095
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.end = 0
    lookup_module_0.stride = -1
    lookup_module_0.format = "%d"
    var_0 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:07:32.425776
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = -1
    lookup_module_0.start = 1
    lookup_module_0.end = 2
    lookup_module_0.stride = 0
    lookup_module_0.start = -1
    lookup_module_0.start = 1
    lookup_module_0.stride = 1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:07:34.280902
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # assert_raises raised
    with pytest.raises(AnsibleError,
                       match="problem formatting '1' with '%d'"):
        lookup_var_0 = lookup_module_0.generate_sequence()



# Generated at 2022-06-25 11:07:35.792712
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.parse_simple_args('a')
    assert var_0 == False, var_0


# Generated at 2022-06-25 11:07:47.415125
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = '1'
    lookup_module_0.stride = '1'
    lookup_module_0.sanity_check()

# Generated at 2022-06-25 11:07:52.433041
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 90210
    lookup_module_0.end = 1
    lookup_module_0.stride = -1
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:08:02.288015
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    # Testing
    assert compare_values(True, LookupModule().parse_simple_args('1'), "method parse_simple_args of class LookupModule")
    assert compare_values(True, LookupModule().parse_simple_args('1-20'), "method parse_simple_args of class LookupModule")
    assert compare_values(True, LookupModule().parse_simple_args('1-20/1'), "method parse_simple_args of class LookupModule")
    assert compare_values(True, LookupModule().parse_simple_args('1-20/1:1'), "method parse_simple_args of class LookupModule")
    assert compare_values(True, LookupModule().parse_simple_args('1-20:1'), "method parse_simple_args of class LookupModule")

# Generated at 2022-06-25 11:08:07.781876
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module = LookupModule()
    lookup_module.start = 1
    lookup_module.end = 5
    lookup_module.format = '%d'
    lookup_module.stride = 1
    # Test with a positive stride
    assert(list(lookup_module.generate_sequence()) == ['1','2','3','4','5'])
    # Test with a negative stride
    lookup_module.stride = -1
    assert(list(lookup_module.generate_sequence()) == ['5','4','3','2','1'])
    # Test with a zero stride
    lookup_module.stride = 0
    assert(list(lookup_module.generate_sequence()) == [])

# Generated at 2022-06-25 11:08:10.052401
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 2
    try:
        lookup_module_0.sanity_check()
    except Exception as e:
        raise


# Generated at 2022-06-25 11:08:14.243436
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.sanity_check()
    assert True


# Generated at 2022-06-25 11:08:16.831223
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = 0
    lookup_module_0.stride = 0
    lookup_module_0.end = 0
    lookup_module_0.start = 0
    try:
        lookup_module_0.sanity_check()
    except AnsibleError as e:
        raise Exception("Unexpected exception: {}".format(e))


# Generated at 2022-06-25 11:08:22.143161
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 2
    lookup_module_0.count = 3
    lookup_module_0.end = None
    lookup_module_0.stride = 7
    lookup_module_0.format = "12"
    assert lookup_module_0.sanity_check() == None


# Generated at 2022-06-25 11:08:33.185456
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()

    term = '5'
    expected_result = (
        False
    )
    actual_result = lookup_module_0.parse_simple_args(
        term
    )
    assert actual_result == expected_result

    term = '5-'
    expected_result = (
        False
    )
    actual_result = lookup_module_0.parse_simple_args(
        term
    )
    assert actual_result == expected_result

    term = '5-8'
    expected_result = (
        True
    )
    actual_result = lookup_module_0.parse_simple_args(
        term
    )
    assert actual_result == expected_result

    term = '5--8'
    expected_result = (
        False
    )
   

# Generated at 2022-06-25 11:08:42.692982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([], {}) == []
    assert lookup_module_0.run(['a-b'], {}) == []
    assert lookup_module_0.run(['a-b/c'], {}) == []
    assert lookup_module_0.run(['a-b/c:d'], {}) == []
    assert lookup_module_0.run(['a-b/c:d'], {}) == []
    assert lookup_module_0.run(['a-b/c:d'], {}) == []


# Generated at 2022-06-25 11:08:50.726707
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    result = lookup_module_0.sanity_check()
    assert result



# Generated at 2022-06-25 11:09:01.720021
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    # Test with args start=0 count=5
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
   # lookup_module_0.count = 5

    # Test with args start=0 count=5
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 0
    lookup_module_1.count = 5

    # Test with args start=0 count=5
    lookup_module_2 = LookupModule()
    lookup_module_2.start = 0
    lookup_module_2.count = 5

    # Test with args start=0 end=5
    lookup_module_3 = LookupModule()
    lookup_module_3.start = 0
    lookup_module_3.end = 5

# Generated at 2022-06-25 11:09:06.608883
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    lookup_module_0 = LookupModule()

    # set up some initial test conditions
    lookup_module_0.start = 0
    lookup_module_0.end = 4
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"

    # call method under test
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:09:13.261625
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()

    # Assigning 1 to start
    lookup_module_0.start = 1
    # Assigning 1 to stride
    lookup_module_0.stride = 1
    # Assigning 5 to end
    lookup_module_0.end = 5

    # Assigning "%d" to format
    lookup_module_0.format = "%d"

    results = []
    results_exp = [1, 2, 3, 4, 5]

    for i in lookup_module_0.generate_sequence():
        results.append(i)

    assert results == results_exp


# Generated at 2022-06-25 11:09:18.412116
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    test_case_0()
    lookup_module_0 = LookupModule()
    parse_kv_args_0 = lookup_module_0.parse_kv_args("count")
    assert parse_kv_args_0 == None


# Generated at 2022-06-25 11:09:24.190679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['5']
    variables = 'abc'
    kwargs = {}
    assert lookup_module_0.run(terms, variables, **kwargs) == ["1", "2", "3", "4", "5"]
    terms = ['5-8']
    variables = 'abc'
    kwargs = {}
    assert lookup_module_0.run(terms, variables, **kwargs) == ["5", "6", "7", "8"]
    terms = ['2-10/2']
    variables = 'abc'
    kwargs = {}
    assert lookup_module_0.run(terms, variables, **kwargs) == ["2", "4", "6", "8", "10"]
    terms = ['4:host%02d']

# Generated at 2022-06-25 11:09:27.812021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test case for the method run of class LookupModule.
    """

    # Uncomment the following lines and replace the values of parameters
    # as per your need to test the function run of class LookupModule

    # lookup_module_0 = LookupModule()
    # lookup_module_0.run(terms, variables, **kwargs)



# Generated at 2022-06-25 11:09:31.614096
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    kwargs = dict(
    )
    lookup_module_0.generate_sequence(**kwargs)


# Generated at 2022-06-25 11:09:43.005749
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module = LookupModule()
    assert lookup_module.parse_simple_args("5") == True and lookup_module.end == 5
    assert lookup_module.parse_simple_args("5-8") == True and lookup_module.end == 8
    assert lookup_module.parse_simple_args("0600") == True and lookup_module.end == 384
    assert lookup_module.parse_simple_args("0x3f8") == True and lookup_module.end == 1016
    assert lookup_module.parse_simple_args("2-10/2") == True and lookup_module.end == 10 and lookup_module.stride == 2
    assert lookup_module.parse_simple_args("4:host%02d") == True and lookup_module.end == 4

# Generated at 2022-06-25 11:09:47.467483
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    assert list(lookup_module_0.generate_sequence()) == ["1", "2", "3", "4", "5"]



# Generated at 2022-06-25 11:09:56.966018
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.start = 0
    lookup_module.end = 1
    lookup_module.stride = 1
    lookup_module.sanity_check()   # Calling sanity_check()

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_sanity_check()

# Generated at 2022-06-25 11:10:03.590410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        ('start=1', 'end=10'),
        ('start=3', 'end=10', 'stride=3'),
        ('start=3', 'end=10'),
        ('start=3', 'end=10', 'stride=3'),
    ]
    variables = {}
    kwargs = {}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=terms, variables=variables, **kwargs)
    assert len(result) == 10


# Generated at 2022-06-25 11:10:07.500697
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
  lookup_module_0 = LookupModule()
  term_0 = "468-473"
  lookup_module_0.parse_simple_args(term_0)
  term_1 = "24-30/3"
  lookup_module_0.parse_simple_args(term_1)
  term_2 = "4:host%02d"
  lookup_module_0.parse_simple_args(term_2)
  term_3 = "5"
  return lookup_module_0.parse_simple_args(term_3)


# Generated at 2022-06-25 11:10:16.086399
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 2
    lookup_module_0.stride = 2
    lookup_module_0.format = "%d"
    expected = ['1', '2']
    actual = list(lookup_module_0.generate_sequence())
    assert sorted(expected) == sorted(actual)


# Generated at 2022-06-25 11:10:26.987024
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module = LookupModule()
    lookup_module.count = 1
    lookup_module.end = 1
    try:
        lookup_module.sanity_check()
    except AnsibleError:
        pass
    else:
        assert False, "Test 1: Exception should have been raised."
    print("Test 1: Passed.")
    lookup_module.reset()
    lookup_module.count = 2
    lookup_module.end = None
    lookup_module.sanity_check()
    print("Test 2: Passed.")
    lookup_module.reset()
    lookup_module.start = 1
    lookup_module.count = 5
    lookup_module.stride = 2
    lookup_module.sanity_check()
    assert lookup_module.end == 9, "Test 3: Incorrect value of end."
    assert lookup_

# Generated at 2022-06-25 11:10:31.335428
# Unit test for method parse_kv_args of class LookupModule
def test_LookupModule_parse_kv_args():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()

    terms = ["start=5 end=8 format=testuser%02x"]
    variables = ""

    lookup_module_0.run(terms, variables)



# Generated at 2022-06-25 11:10:35.713270
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = 1
    lookup_module_0.start = 1
    lookup_module_0.stride = 1

    # Call method
    try:
        lookup_module_0.sanity_check()
    except:
        assert False


# Generated at 2022-06-25 11:10:36.540207
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    assert True


# Generated at 2022-06-25 11:10:43.282970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run')

# Generated at 2022-06-25 11:10:45.330516
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.parse_simple_args("2-8")


# Generated at 2022-06-25 11:10:51.054777
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:10:54.723521
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()
    if isinstance(var_0, types.GeneratorType):
        var_0 = list(var_0)
    assert var_0 == []


# Generated at 2022-06-25 11:10:57.079685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:11:00.071470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.run(terms, variables, **kwargs)
    assert var_1 == [], "Argument var_1: Expected [], actually {0}".format(var_1)
    print('All tests passed')


# Generated at 2022-06-25 11:11:08.066530
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 0
    lookup_module_0.count = 0
    lookup_module_0.end = 0
    lookup_module_0.stride = 0
    lookup_module_0.format = "%d"
    lookup_module_1 = LookupModule()
    lookup_module_1.start = 1
    lookup_module_1.count = 10
    lookup_module_1.end = None
    lookup_module_1.stride = 1
    lookup_module_1.format = "%d"
    lookup_module_2 = LookupModule()
    lookup_module_2.start = 1
    lookup_module_2.count = None
    lookup_module_2.end = 10
    lookup_module_2.stride = 1
    lookup

# Generated at 2022-06-25 11:11:16.727165
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_1 = SHORTCUT.match("5")
    assert var_1
    var_2 = SHORTCUT.match("5").groups(1)
    var_3 = SHORTCUT.match("5").groups(2)
    var_4 = SHORTCUT.match("5").groups(3)
    var_5 = SHORTCUT.match("5").groups(4)
    var_6 = SHORTCUT.match("5").groups(5)
    var_7 = SHORTCUT.match("5").groups(6)
    assert var_2 is None
    assert var_3 is not None
    assert var_4 is None
    assert var_5 is None
    assert var_6 is None
    assert var_7 is None
    var_

# Generated at 2022-06-25 11:11:20.399676
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_sanity_check()



# Generated at 2022-06-25 11:11:29.936324
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = 0
    lookup_module_1 = LookupModule()
    lookup_module_1.stride = 0
    lookup_module_2 = LookupModule()
    lookup_module_2.stride = 0
    lookup_module_3 = LookupModule()
    lookup_module_3.stride = 0
    lookup_module_4 = LookupModule()
    lookup_module_4.stride = 0

    # set up the test sequence 0
    lookup_module_0.start = 1
    lookup_module_0.end = 5
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    expected_0 = ["1","2","3","4","5"]
    actual_0 = lookup

# Generated at 2022-06-25 11:11:37.989329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    try:
        var__list_0, var_terms_0, var_variables_0 = lookup_module_0.run('description', [5,6,7])
        assert False
    except Exception as e:
        assert e == 'Unknown lookup plugin: description'
    else:
        assert False

    try:
        var__list_0, var_terms_0, var_variables_0 = lookup_module_0.run('sequence', [5,6,7])
        assert False
    except Exception as e:
        assert e == 'Unknown lookup plugin: sequence'
    else:
        assert False

# Generated at 2022-06-25 11:11:41.669834
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # Set instance variables
    lookup_module_0.start = 1
    lookup_module_0.end = 0
    lookup_module_0.stride = -1
    lookup_module_0.format = "%d"
    var_0 = lookup_module_0.generate_sequence()


# Generated at 2022-06-25 11:12:00.227294
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.start = 1
    var_1 = lookup_module_0.count = None
    var_2 = lookup_module_0.end = 3
    var_3 = lookup_module_0.stride = 1
    var_4 = lookup_module_0.format = "%d"
    var_5 = lookup_module_0.generate_sequence()
    res_0 = list(var_5)
    # Verify that the following expectations are met
    assert res_0 == ['1', '2', '3']



# Generated at 2022-06-25 11:12:03.426846
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:08.594444
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = "end"
    var_1 = lookup_module_0.parse_simple_args(var_0)
    assert var_1 == True


# Generated at 2022-06-25 11:12:15.879608
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()

    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_0 == lookup

# Generated at 2022-06-25 11:12:18.605255
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.parse_simple_args()


# Generated at 2022-06-25 11:12:22.963127
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    arg_0 = "5-8"
    var_0 = lookup_module_0.parse_simple_args(arg_0)


# Generated at 2022-06-25 11:12:26.758692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = [lookup_module_1.run()]


# Generated at 2022-06-25 11:12:30.361930
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    term_0 = "4-12"
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.parse_simple_args(term_0)
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:32.736892
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_parse_simple_args = LookupModule()
    var_parse_simple_args = lookup_module_parse_simple_args.parse_simple_args()
    assert(var_parse_simple_args == 0)


# Generated at 2022-06-25 11:12:38.012330
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.generate_sequence()

    var_1 = list(var_0)
    assert var_1 == ["1", "2", "3", "4", "5"], var_1


# Generated at 2022-06-25 11:12:47.658652
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.parse_simple_args(arg_1)


# Generated at 2022-06-25 11:12:53.652904
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_2.start = 0
    lookup_module_2.count = 4
    lookup_module_2.format = "%04x"
    lookup_module_3 = LookupModule()
    lookup_module_3.start = "0x0f00"
    lookup_module_3.count = 4
    lookup_module_3.format = "%04x"
    lookup_module_4 = LookupModule()
    lookup_module_4.start = 0
    lookup_module_4.count = 5
    lookup_module_4.stride = 2
    lookup_module_5 = LookupModule()
    lookup_module_5.start = 1
    lookup_module

# Generated at 2022-06-25 11:12:56.376543
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:12:57.163449
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    test_case_0()


# Generated at 2022-06-25 11:13:04.832751
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    var_0 = SHORTCUT.match("")
    var_0 = lookup_module_1.parse_simple_args(var_0)
    var_1 = lookup_module_1.parse_simple_args("")
    var_2 = lookup_module_1.parse_simple_args("")
    var_3 = lookup_module_1.parse_simple_args("")
    var_4 = lookup_module_1.parse_simple_args("")
    var_5 = lookup_module_1.parse_simple_args("")
    var_6 = lookup_module_1.parse_simple_args("")
    var_7 = lookup_module_1.parse_simple_args("")
    var_8 = lookup_module_1.parse_simple_args("")

# Generated at 2022-06-25 11:13:06.591412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_run()

test_LookupModule_run()

# Generated at 2022-06-25 11:13:10.327526
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    # Test with valid input
    try:
        lookup_module_0.start = 10
        lookup_module_0.stride = 2
        lookup_module_0.end = 10
        lookup_module_0.format = 'test_case_0'
        lookup_module_0.generate_sequence()
    except Exception:
        assert (False)


# Generated at 2022-06-25 11:13:15.348980
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.stride = -2
    lookup_module_0.end = 2
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:13:22.571190
# Unit test for method generate_sequence of class LookupModule
def test_LookupModule_generate_sequence():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 10
    lookup_module_0.end = 0
    lookup_module_0.stride = -1
    lookup_module_0.format = "%d"

    # Run test
    assert (lookup_module_0.generate_sequence() == [str(i) for i in range(10, 0, -1)])


# Generated at 2022-06-25 11:13:26.444396
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_0 = lookup_module_0.stride = 1
    var_0 = lookup_module_0.start = 8
    var_0 = lookup_module_0.end = 10
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:13:47.377854
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    assert None is not lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:13:53.915582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.reset()
    var_1 = lookup_module_0.parse_kv_args(arguments)
    var_2 = lookup_module_0.parse_simple_args(term)
    result = lookup_module_0.run(terms, variables)
    return result

# Main test process
if __name__ == '__main__':
    print(test_case_0())
    print(test_LookupModule_run())

# Generated at 2022-06-25 11:14:05.027275
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():


    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_generate_sequence()
    results_0 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:14:12.045260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = "option"
    variables_0 = list()
    kwargs_0 = {'test': "option"}
    lookup_module_0.run(term_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:14:17.828038
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module__obj = LookupModule()
    lookup_module__obj.start = 0
    lookup_module__obj.count = 0
    lookup_module__obj.end = 0
    lookup_module__obj.stride = 0
    lookup_module__obj.format = "%d"
    lookup_module__obj.sanity_check()
    lookup_module__obj.sanity_check()

# Generated at 2022-06-25 11:14:26.487180
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.parse_simple_args('5')
    assert var_0 == False, f'var_0 returned "{var_0}", expected "False"'
    var_1 = lookup_module_0.parse_simple_args(':1')
    assert var_1 == False, f'var_1 returned "{var_1}", expected "False"'
    var_2 = lookup_module_0.parse_simple_args(':')
    assert var_2 == False, f'var_2 returned "{var_2}", expected "False"'
    var_3 = lookup_module_0.parse_simple_args('')
    # assert var_3 == False, f'var_3 returned "{var_3}", expected "False"'

# Generated at 2022-06-25 11:14:32.472627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('terms_0', 'variables_0', **kwargs_0)
    print(var_0)



# Generated at 2022-06-25 11:14:38.321929
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    term_0 = '5'
    assert lookup_module_0.parse_simple_args(term_0)
    var_2 = lookup_module_0.get_start()
    assert 1 == var_2
    var_3 = lookup_module_0.get_count()
    assert None == var_3
    var_4 = lookup_module_0.get_end()
    assert 5 == var_4
    var_5 = lookup_module_0.get_stride()
    assert 1 == var_5
    var_6 = lookup_module_0.get_format()
    assert '%d' == var_6
    term_1 = '5-8'
    assert lookup_module_0.parse_simple_args(term_1)

# Generated at 2022-06-25 11:14:47.242650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = []
    var_2 = []
    var_2.append("count=2")
    var_2.append("start=0x0f00 count=4 format=%04x")
    var_2.append("start=0 count=5 stride=2")
    var_2.append("start=1 count=5 stride=2")
    var_2.append("count=2")
    var_3 = lookup_module_0.run(var_2, var_1)


# Generated at 2022-06-25 11:14:50.044779
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = 1
    lookup_module_0.end = 1
    lookup_module_0.stride = 1
    assert lookup_module_0.sanity_check() == None

#Unit test for method reset of class LookupModule

# Generated at 2022-06-25 11:15:03.974672
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()


# Generated at 2022-06-25 11:15:06.784755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module_0.run([], None, [], [], [])


# Generated at 2022-06-25 11:15:16.057490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:15:17.145403
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()

# Generated at 2022-06-25 11:15:25.541279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(start=5, end=8, stride=1, format='%d')
    results = dict(result=["5", "6", "7", "8"])
    assert LookupModule().run([args], variables=dict()) == results['result']
    var_1 = dict(start=5, end=8, stride=1, format='%d')
    var_1 = dict(start=5, end=8, stride=1, format='%d')
    assert LookupModule().run([var_1], variables=dict()) == results['result']
    var_2 = dict(start=5, end=8, stride=1, format='%d')
    assert LookupModule().run([var_2], variables=dict()) == results['result']

# Generated at 2022-06-25 11:15:27.401787
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:15:30.534609
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_1 = LookupModule()
    test_term_0 = "12"
    var_1 = lookup_module_1.parse_simple_args(test_term_0)


# Generated at 2022-06-25 11:15:35.585407
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_module_0.parse_simple_args(var_0)
    assert var_1 == True



# Generated at 2022-06-25 11:15:45.493436
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.reset()
    lookup_module_0.start = 1
    lookup_module_0.count = None
    lookup_module_0.end = None
    lookup_module_0.stride = 1
    lookup_module_0.format = "%d"
    try:
        lookup_module_0.sanity_check()
    except AnsibleError: pass
    lookup_module_0.count = None
    lookup_module_0.end = 1
    try:
        lookup_module_0.sanity_check()
    except AnsibleError: pass
    lookup_module_0.count = 1
    lookup_module_0.end = 1
    try:
        lookup_module_0.sanity_check()
    except AnsibleError: pass


# Generated at 2022-06-25 11:15:54.569484
# Unit test for method parse_simple_args of class LookupModule
def test_LookupModule_parse_simple_args():
    from ansible.plugins.lookup import LookupModule
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_

# Generated at 2022-06-25 11:16:14.150958
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_3 = LookupModule()
    lookup_module_3.start = 10
    lookup_module_3.count = 5
    lookup_module_3.stride = 1
    lookup_module_3.format = "%d"
    var_3 = lookup_module_3.sanity_check()
    sanity_check_expected_result = None
    assert var_3 == sanity_check_expected_result



# Generated at 2022-06-25 11:16:15.231139
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.sanity_check()


# Generated at 2022-06-25 11:16:16.498625
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True


# Generated at 2022-06-25 11:16:24.635830
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_0 = LookupModule()
    lookup_module_0.start = -6
    lookup_module_0.stride = 6
    lookup_module_0.end = -6
    lookup_module_0.format = '%1.2f'
    lookup_module_0.sanity_check()
    lookup_module_0.start = -3
    lookup_module_0.stride = 8
    lookup_module_0.end = 1
    lookup_module_0.sanity_check()
    lookup_module_0.start = -8
    lookup_module_0.stride = -2
    lookup_module_0.end = -5
    lookup_module_0.sanity_check()
    lookup_module_0.start = -9

# Generated at 2022-06-25 11:16:32.360996
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    if True:
        assert lookup_module_0.sanity_check() == '\n            if self.count is None and self.end is None:\n                raise AnsibleError("must specify count or end in with_sequence")\n            elif self.count is not None and self.end is not None:\n                raise AnsibleError("can\'t specify both count and end in with_sequence")\n            elif self.count is not None:', 'lookup_module_0.sanity_check()'



# Generated at 2022-06-25 11:16:34.029926
# Unit test for method sanity_check of class LookupModule
def test_LookupModule_sanity_check():
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.sanity_check()
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:16:37.062124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_reset()
    var_1 = lookup_terms()
    var_2 = lookup_variables()
    var_3 = lookup_arguments()
    lookup_module_0.run(var_0, var_1, var_2, var_3)
    return True
