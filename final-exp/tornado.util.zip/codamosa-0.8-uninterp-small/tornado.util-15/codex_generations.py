

# Generated at 2022-06-26 08:54:20.017070
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class TestClass(object):
        def __init__(self, arg1, arg2="default"):
            self.arg1 = arg1
            self.arg2 = arg2
    test_instance = TestClass(33)
    #replace arg1
    arg_replacer = ArgReplacer(TestClass.__init__, "arg1")
    old_value, args, kwargs = arg_replacer.replace(44, [], {"arg2":"not default"})
    assert old_value == 33
    assert args == []
    assert kwargs == {"arg1":44, "arg2":"not default"}
    #replace arg2
    arg_replacer = ArgReplacer(TestClass.__init__, "arg2")

# Generated at 2022-06-26 08:54:27.023609
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    replacer_0 = ArgReplacer(lambda x, y, z=1: None, 'y')
    old_value_0, args_0, kwargs_0 = replacer_0.replace('str_0', (2, 3, 4), {'z': 5})
    len_func_0 = lambda x: len(x)
    assert len_func_0(replacer_0._getargnames(lambda x, y, z=1: None)) == 3


# Generated at 2022-06-26 08:54:35.797004
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    function_0 = lambda : None
    arg_replacer_0 = ArgReplacer(function_0, "")
    if (str(arg_replacer_0.replace((object_dict_0), object_dict_0, object_dict_0)) != None):
        raise RuntimeError
    if (len(object_dict_0) == 0):
        raise RuntimeError


# Generated at 2022-06-26 08:54:37.276313
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    c = Configurable()


# Generated at 2022-06-26 08:54:40.472326
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    arg__0 = []
    kwarg_0 = {}
    # Call method __new__ of class Configurable:
    class_0 = Configurable.__new__(Configurable, *arg__0, **kwarg_0)


# Generated at 2022-06-26 08:54:50.643770
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # Unit test for ArgReplacer.__init__(self, func, name)
    def func_0(a, b):
        return a + b
    arg_replacer_0 = ArgReplacer(func_0, 'a')
    if arg_replacer_0 == 1:
        print(1)
    elif arg_replacer_0 == 2:
        print(2)
    elif arg_replacer_0 == 3:
        print(3)
    else:
        print(4)
    func_0(a=1, b=2)
    func_0(1, 2)
    test_ArgReplacer_0 = ArgReplacer(func_0, 'a')
    if test_ArgReplacer_0 == 1:
        print(1)

# Generated at 2022-06-26 08:54:54.009146
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer_0 = ArgReplacer(test_case_0, "test_case_0")
    old_value = arg_replacer_0.get_old_value([],{},None)
    return old_value


# Generated at 2022-06-26 08:54:59.973118
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    f = lambda x, y: True
    ArgReplacer(f, 'x')
    try:
        ArgReplacer(f, 'name')
    except ValueError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-26 08:55:11.556777
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = lambda x: x;
    name = "a";
    arg_replacer = ArgReplacer(func, name);
    new_value = "new_value";
    args = ["old_value"];
    kwargs = {};
    old_value, new_args, new_kwargs = arg_replacer.replace(new_value, args, kwargs);
    assert new_args == ["new_value"];
    assert new_kwargs == {};
    assert old_value == "old_value";


# Generated at 2022-06-26 08:55:25.115548
# Unit test for function import_object
def test_import_object():
    import unittest
    import math
    import importlib

    class TestImportObject(unittest.TestCase):

        def __init__(self, name: str) -> None:
            super(TestImportObject, self).__init__(name)
            self.module = importlib.import_module(".".join(("tornado", "util")))

        def test_import_object_0(self):
            result = self.module.import_object("math")
            expected = math
            self.assertEqual(result, expected)

        def test_import_object_1(self):
            result = self.module.import_object("math.pi")
            expected = math.pi
            self.assertEqual(result, expected)


# Generated at 2022-06-26 08:55:55.169425
# Unit test for method initialize of class Configurable

# Generated at 2022-06-26 08:55:59.973718
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    old_value = ArgReplacer.get_old_value(args = "", kwargs = object_dict_0, default = object_dict_0)
    assert old_value == object_dict_0


# Generated at 2022-06-26 08:56:06.734801
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    class_name = "ObjectDict"
    method_name = "__getattr__"
    object_dict_0 = ObjectDict()
    class ObjectDictSub(ObjectDict):
        def __getattr__(self, name):
            try:
                return self[name]
            except KeyError:
                raise AttributeError(name)

    test_case_0()


# Generated at 2022-06-26 08:56:15.377677
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class TestException(Exception):
        def __init__(self):
            super(TestException, self).__init__()

    e = TestException()
    errno_from_exception(e)

    e = TestException()
    e.errno = 12
    errno_from_exception(e)

    e = TestException()
    e.args = ["hello world"]
    errno_from_exception(e)



# Generated at 2022-06-26 08:56:22.830651
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(5, 'abc')
    except Exception as e:
        if errno_from_exception(e) == 5:
            print('errno_from_exception ok')
        else:
            print('errno_from_exception fail')

test_errno_from_exception()

# Generated at 2022-06-26 08:56:26.684291
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    obj = ArgReplacer(test_case_0, 'object_dict_0')
    obj.replace(object_dict_0, None, None)


# Generated at 2022-06-26 08:56:28.622146
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:56:29.779013
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass

# Generated at 2022-06-26 08:56:31.270300
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-26 08:56:34.402612
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configure_0 = Configurable()
    # no assert
    configure_0.initialize()


# Generated at 2022-06-26 08:56:52.923440
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # For this test case to work, you need to make sure that if you change the state of the object, you also put it back in the previous state.
    # Namely, you need to put in the if statement, an else-clause with the previous state.
    my_arg_replacer_0 = ArgReplacer(test_case_0, 'outfile')
    if my_arg_replacer_0.arg_pos is not None and len(my_arg_replacer_0.gzip_decompressor.stream) > my_arg_replacer_0.arg_pos:
        # The arg to replace is passed positionally
        old_value = my_arg_replacer_0.gzip_decompressor.stream[my_arg_replacer_0.arg_pos]
        my_arg_replacer_0.gzip_

# Generated at 2022-06-26 08:57:02.578575
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo_0(a, b, c, d):
        return a, b, c, d
    # args = [1, 2, 3, 4]
    # kwargs = {"d": 5}
    # output = [1, 2, 3, 5]
    # wd = ArgReplacer(foo_0, "d")
    # print(wd.get_old_value(args, kwargs))
    # print(foo_0(*args, **kwargs))
    a, b, c, d = foo_0(1, 2, 3, 4)
    print(a, b, c, d)
    print(foo_0(1, 2, 3, d=5))


# Generated at 2022-06-26 08:57:06.329542
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    r = ArgReplacer(test_case_0, "decompressor")
    r.replace(None, [None], {})


# Generated at 2022-06-26 08:57:08.295195
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable = Configurable()
    assert isinstance(configurable, Configurable)
    pass


# Generated at 2022-06-26 08:57:14.671348
# Unit test for function import_object
def test_import_object():
    import tornado
    try:
        import tornado.some_missing_module
    except ImportError:
        pass
    else:
        assert False, "Expected ImportError"
    tornado_1 = import_object('tornado')
    assert tornado_1 is tornado
    tornado_escape_1 = import_object('tornado.escape')
    assert tornado_escape_1 is tornado.escape
    tornado_escape_utf8_0 = import_object('tornado.escape.utf8')
    assert tornado_escape_utf8_0 is tornado.escape.utf8


# Generated at 2022-06-26 08:57:19.434716
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # [0, 1]
    obj = ObjectDict()
    obj['a'] = "abc"
    c = obj.a
    # []


# Generated at 2022-06-26 08:57:23.242994
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls): return MyConfigurable

        @classmethod
        def configurable_default(cls): return MyConfigurable


    gzip_decompressor_0 = MyConfigurable()


# Generated at 2022-06-26 08:57:26.993813
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert (None == errno_from_exception(Exception(""))), "Fail to errno_from_exception"
    assert (None == errno_from_exception(Exception())), "Fail to errno_from_exception"

test_case_0()
test_errno_from_exception()



# Generated at 2022-06-26 08:57:34.561719
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def meth_0(a, b=None, c=None, d=None, e=None, f=None, g=None):
        return (a, b, c, d, e, f, g)
    arg_replacer_0 = ArgReplacer(meth_0, 'd')
    dec_0 = DecompressorBuffer(arg_replacer_0.replace(100, (), {"d": 200}), None)
    if dec_0[3] == 100:
        return (100, 200)
    return (100, 200)


# Generated at 2022-06-26 08:57:45.903635
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # func_1 is a function object, will test more functions in the future
    func_1 = test_case_0
    # name_1 is a string, will test more names in the future
    name_1 = "gzip_decompressor_0"

    arg_replacer_1 = ArgReplacer(func_1, name_1)

    # test both len(args) == 0 and len(kwargs) == 0 cases
    args_1 = ()
    kwargs_1 = {}
    old_value_1 = arg_replacer_1.get_old_value(args_1, kwargs_1)
    assert(old_value_1 == None)
    # test both len(args) == 0 and len(kwargs) != 0 cases
    args_2 = ()

# Generated at 2022-06-26 08:57:57.227868
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = test_case_0
    replacer = ArgReplacer(func, "name")
    assert replacer.arg_pos == None
    assert replacer.get_old_value((), {}) == None
    assert replacer.replace(2, (), {}) == (None, (), {'name': 2})

# Generated at 2022-06-26 08:58:05.253992
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_of_Configurable = Configurable()
    test_of_Configurable.initialize()

    test_of_Configurable.initialize(1)
    test_of_Configurable.initialize(1, 2)
    test_of_Configurable.initialize(1, 2, a=3)
    test_of_Configurable.initialize(1, 2, a=3, b=4)



# Generated at 2022-06-26 08:58:07.377312
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:58:16.383932
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func_0(*args):
        return
    arg_replacer_0 = ArgReplacer(func_0, '0')
    arg_replacer_0.get_old_value(('0', '1'), {'2': '3'}, default='4')
    arg_replacer_0.get_old_value(('0', '1'), {'0': '3'}, default='4')
    arg_replacer_0.get_old_value(('0', '1'), {'0': '3', '2': '5'}, default='4')


# Generated at 2022-06-26 08:58:30.019178
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():

    class Configurable1(Configurable):
        def __init__(self):
            super().__init__()

    class Configurable2(Configurable):
        def __init__(self):
            super().__init__()

    class SocketImpl(object):
        def __init__(self):
            super().__init__()

    # Unit test for method __new__ of class Configurable
    class SocketImpl1(object):
        def __init__(self):
            super().__init__()

    Configurable.configure(SocketImpl1)
    socket_impl_0 = SocketImpl1()
    # Unit test for method __init__ of class Configurable
    Configurable.configure(SocketImpl)
    socket_impl_1 = SocketImpl1()

    # Unit test for method __init__ of class GzipDecompressor
    g

# Generated at 2022-06-26 08:58:41.402918
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import logging
    import re

    print ("Testing Configurable.__new__")

    # create a configurable class
    # - create a class that inherits from Configurable
    # - set the base class of the configurable hierarchy to Configurable
    # - set the default class/subclass of Configurable
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return Configurable

        @classmethod
        def configurable_default(cls):
            return MyConfigurable

        def __init__(self, name = "a"):
            self.name = name

    # - create a subclass of MyConfigurable
    # - set the default class/subclass of MyConfigurable

# Generated at 2022-06-26 08:58:51.979325
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(x,y):
        return x+y
    arg_replacer_0 = ArgReplacer(func = foo, name = "x")
    arg_replacer_1 = ArgReplacer(func = foo, name = "y")
    args = [100]
    kwargs = {"y":200}
    old_value_0 = arg_replacer_0.get_old_value(args,kwargs)
    old_value_1 = arg_replacer_1.get_old_value(args,kwargs)
    assert old_value_0 == 100
    assert old_value_1 == 200
    new_value_0 = 50
    new_value_1 = 150

# Generated at 2022-06-26 08:58:59.800833
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def gzip_decompressor_0(self, wbits = None):
        self.wbits = wbits
        self.decompress = zlib.decompressobj(wbits).decompress
    gzip_decompressor_0_obj = ArgReplacer(gzip_decompressor_0, "wbits")

# Generated at 2022-06-26 08:59:07.161683
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def replace(q: str, w: str) -> None:
        pass
    replacer = ArgReplacer(replace, "w")
    assert replacer.replace("a", ("b",), {"w": "c"}) == ("c", ("b",), {"w": "a"})


# Generated at 2022-06-26 08:59:15.885691
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl_class_0 = object()
    init_kwargs_0 = {}
    impl_class_1 = object()
    init_kwargs_1 = {}
    impl_class_2 = object()
    init_kwargs_2 = {}
    impl_class_3 = object()
    init_kwargs_3 = {}
    impl_class_4 = object()
    init_kwargs_4 = {}
    impl_class_5 = object()
    init_kwargs_5 = {}
    impl_class_6 = object()
    init_kwargs_6 = {}
    impl_class_7 = object()
    init_kwargs_7 = {}
    impl_class_8 = object()
    init_kwargs_8 = {}
    impl_class_9 = object()
    init_kwargs_9 = {}

# Generated at 2022-06-26 08:59:33.404173
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_2 = Configurable()


# Generated at 2022-06-26 08:59:34.819456
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_case_0()


# Generated at 2022-06-26 08:59:36.802722
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    testConfigurable = Configurable()


# Generated at 2022-06-26 08:59:43.766204
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    argreplacer_getoldvalue_0 = ArgReplacer(gzip_decompressor_0.flush, "callback")
    argreplacer_getoldvalue_1 = argreplacer_getoldvalue_0.get_old_value((), {})
    argreplacer_getoldvalue_2 = argreplacer_getoldvalue_0.get_old_value((), {}, 1)


# Generated at 2022-06-26 08:59:47.498202
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print(Configurable.__new__(Configurable))
    print(Configurable.__new__(Configurable, None))


# Generated at 2022-06-26 08:59:52.676257
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer_1 = ArgReplacer(test_ArgReplacer_get_old_value, 'args')
    arg_replacer_1.get_old_value((1, 2), {}, 1)


# Generated at 2022-06-26 08:59:57.611393
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(arg1, arg2, arg3):
        return arg1, arg2, arg3
    args = (1, 2, 3)
    kwargs = {"arg3": 2}
    arg_replacer = ArgReplacer(test_func, "arg2")

    old_val, args, kwargs = arg_replacer.replace(4, args, kwargs)
    print(args, kwargs)



# Generated at 2022-06-26 09:00:07.603871
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class T(object):
        def f(self, a: int, b: int) -> int:
            return a + b

    test = ArgReplacer(T.f, 'b')
    
    # test if not b in kwargs
    args = (3, )
    kwargs = {'c': 'test'}
    (old_value, args, kwargs) = test.replace(4, args, kwargs)
    if old_value != None:
        raise Exception('Unexpected result')
    if args != (3, ):
        raise Exception('Unexpected result')
    if kwargs != {'b': 4, 'c': 'test'}:
        raise Exception('Unexpected result')

    # test if b in kwargs
    args = (3, )

# Generated at 2022-06-26 09:00:10.312757
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    f1 = functools.partial(re_unescape, s="")
    f1()


# Generated at 2022-06-26 09:00:20.134408
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # test1: The arg to replace is passed positionally
    # test1_0: The arg to replace is passed positionally
    test1_0_func = test_case_0
    test1_0_name = "self"
    test1_0_args = [ gzip_decompressor_0 ]
    test1_0_kwargs = {  }
    test1_0_new_value = None
    
    test1_0_0_old_value, test1_0_0_args, test1_0_0_kwargs = ArgReplacer( test1_0_func, test1_0_name ).replace( test1_0_new_value, test1_0_args, test1_0_kwargs )
    test1_0_0_args_0 = [ None ]

    return


# Generated at 2022-06-26 09:00:59.360897
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    # The __new__ method of class Configurable has not been implemented yet
    assert False


# Generated at 2022-06-26 09:01:04.949578
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Prove that this call to replace function will successfully 
    # work and it doesn't raise any exception. 
    # This proves that ArgReplacer is safe to use.
    ArgReplacer.replace(None, None, None)


# Generated at 2022-06-26 09:01:06.856211
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_1 = Configurable()


# Generated at 2022-06-26 09:01:14.236106
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create an object from class Configurable in which:
    # - the method configurable_base() returns the class Configurable.
    # - the method configurable_default() returns the class Configurable.
    # - the method __init__ is overridden.
    class Configurable_0(Configurable):
        @classmethod
        def configurable_base(self):
            return Configurable

        @classmethod
        def configurable_default(self):
            return Configurable

        def __init__(self):
            pass

    # Create an object from class Configurable_0
    configurable_0 = Configurable_0()


# Generated at 2022-06-26 09:01:24.760289
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    _func = lambda x: 0
    _name = "test_ArgReplacer_get_old_value"
    _replacer = ArgReplacer(_func, _name)
    assert _replacer.get_old_value([], {}) is None
    assert _replacer.get_old_value([0], {}) == 0
    assert _replacer.get_old_value([], {"test_ArgReplacer_get_old_value":0}) == 0


# Generated at 2022-06-26 09:01:25.941131
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()


# Generated at 2022-06-26 09:01:28.221121
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    c = ArgReplacer(gzip_decompressor_0.read, 'length')
    print("\n\nvalue = ", c.get_old_value([0], {}, 0))


# Generated at 2022-06-26 09:01:36.661352
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(1, "errno_from_exception")
    except Exception as inst:
        errno = errno_from_exception(inst)
        if errno != 1:
            raise AssertionError("errno is not 1")

if __name__ == "__main__":
    test_errno_from_exception()


# Generated at 2022-06-26 09:01:50.007125
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    print("BEGIN: test_ArgReplacer_get_old_value")
    class SampleClass:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    s = SampleClass(1, 2, 3)
    argreps = ArgReplacer(SampleClass.__init__, "b")
    print(argreps.get_old_value((1, 2, 3), dict()))
    print(argreps.get_old_value((1, 2, 3), dict(b=4)))
    print(argreps.get_old_value((1, 2, 3), dict(b=4), default=-1))

# Generated at 2022-06-26 09:01:57.473415
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise TimeoutError()
    except Exception as e:
        assert errno_from_exception(e) == None

    try:
        raise TimeoutError()
    except Exception as e:
        e.errno = 10
        assert errno_from_exception(e) == 10

    try:
        raise RuntimeError(20)
    except Exception as e:
        assert errno_from_exception(e) == 20


# Generated at 2022-06-26 09:02:32.326782
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    print("Configurable:initialize")
    # Test 1
    configurable_0 = Configurable()
    # Test 2
    configurable_1 = Configurable()


# Generated at 2022-06-26 09:02:44.521053
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Test Args
    is_client = True
    decompress = True
    args = (is_client, decompress)
    kwargs = {'decompress':True, 'is_client':True}
    argreplacer_0 = ArgReplacer(gzip_decompressor_0.process_body, 'decompress')
    decompress_old = argreplacer_0.get_old_value(args, kwargs)
    decompress = False
    _, args, kwargs = argreplacer_0.replace(decompress, args, kwargs)
    assert (args == (is_client, False))
    assert (kwargs == {'decompress':False, 'is_client':True})
    assert (decompress_old == True)


# Generated at 2022-06-26 09:02:52.522334
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # calling class
    configurable_0 = Configurable()
    # arguments to __new__
    args_0 = (8,)
    # arguments to __new__
    kwargs_0 = {"impl": "input", "configurable_default": Configurable.configurable_default}
    # return value of __new__
    configurable___new___rv_1 = configurable_0.__new__(configurable_0)


# Generated at 2022-06-26 09:02:56.439859
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # global decompressor
    test_gzip_decompressor_0 = GzipDecompressor()
    arg_replacer_0 = ArgReplacer(GzipDecompressor, "write_size")
    arg_replacer_0.get_old_value((), {}, 16384)
    pass


# Generated at 2022-06-26 09:02:57.318827
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:02:58.408617
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:03:02.834879
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c):
        pass

    arguments = [1,2,3]
    keyword_arguments = {}
    default_value = 0
    get_old_value = ArgReplacer(foo, "a").get_old_value
    assert get_old_value(arguments, keyword_arguments, default_value) == 1


# Generated at 2022-06-26 09:03:05.693407
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    with pytest.raises(NotImplementedError):
        Configurable.initialize("x")


# Generated at 2022-06-26 09:03:12.052163
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class_0 = Configurable
    base = class_0.configurable_base()
    init_kwargs = {}  # type: Dict[str, Any]
    if class_0 is base:
        impl = class_0.configured_class()
        if base.__impl_kwargs:
            init_kwargs.update(base.__impl_kwargs)
    else:
        impl = class_0
    instance = super(Configurable, class_0).__new__(impl)




# Generated at 2022-06-26 09:03:13.772303
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    instance_0 = Configurable()
    instance_0.initialize()
