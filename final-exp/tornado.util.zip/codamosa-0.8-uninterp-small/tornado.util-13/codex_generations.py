

# Generated at 2022-06-26 08:54:15.742678
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass
    # TODO implement this test


try:
    import cStringIO as StringIO
except ImportError:
    import io as StringIO


# Generated at 2022-06-26 08:54:16.971889
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    _configurable_0 = Configurable.__new__(Configurable)


# Generated at 2022-06-26 08:54:27.458213
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Test case 0
    replacer_0 = ArgReplacer(GzipDecompressor, 'wbits')
    old_value, _1, _2 = replacer_0.replace(0,(),{})
    # The old value of wbits should be 16
    assert old_value == 16

    # Test case 1
    # A callable that has no positional parameters
    def f_1():
      pass
    replacer_1 = ArgReplacer(f_1, 'wbits')
    assert replacer_1.get_old_value((),{}, 0) == 0


# Generated at 2022-06-26 08:54:29.600111
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:54:40.555196
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import_object_0 = import_object('tornado.escape')
    import_object_1 = tornado.escape
    import_object_0 is import_object_1
    import_object_2 = import_object('tornado.escape.utf8')
    import_object_3 = tornado.escape.utf8
    import_object_2 is import_object_3
    import_object_4 = import_object('tornado')
    import_object_5 = tornado
    import_object_4 is import_object_5
    import_object_6 = import_object('tornado.missing_module')



# Generated at 2022-06-26 08:54:42.506410
# Unit test for function errno_from_exception
def test_errno_from_exception():
    gzip_decompressor_0 = GzipDecompressor()
    try:
        fp = open("test.errno")

    except Exception as e:
        if errno_from_exception(e) == e.errno:
            return True
        else:
            return False



# Generated at 2022-06-26 08:54:49.015917
# Unit test for function errno_from_exception
def test_errno_from_exception():
    import errno
    try:
        raise IOError('err msg', errno.EPERM)
    except Exception as e:
        errno_0 = errno_from_exception(e)
        assert errno_0 == -1
        print('test passed')


# Generated at 2022-06-26 08:54:53.999310
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import tornado
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado


# Generated at 2022-06-26 08:55:02.392211
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c, x=1, y=2, z=3):
        return (a, b, c, x, y, z)

    replacer_0 = ArgReplacer(f, 'c')
    assert replacer_0.replace(30, (10, 20, 3), {'y': 42, 'z': 43}) == (None, (10, 20, 30), {'y': 42, 'z': 43})


# Generated at 2022-06-26 08:55:07.344909
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Unit test for method __new__ of class Configurable
    conf_0 = Configurable()
    assert conf_0 is not None
    conf_0 = Configurable()
    return conf_0


# Generated at 2022-06-26 08:55:19.050938
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        x_0 = Configurable() 
    except NotImplementedError:
        return
    raise Exception('ExpectedNotImplementedError')

# Generated at 2022-06-26 08:55:27.501079
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # testing get_old_value with a dummy function
    # not that we don't care about the default value
    def f(foo1, foo2, foo3=1, foo4=2): pass
    def g(foo5=5, foo6=6, *foo7): pass
    def h(foo8=8, *, foo9=9): pass

    arg_replacer_0 = ArgReplacer(f, "foo2")
    # get_old_value, args and kwargs provided
    arg_replacer_0.get_old_value((1, 2, 3), dict(foo3=3, foo4=4))
    # get_old_value, args and kwargs provided

# Generated at 2022-06-26 08:55:33.336761
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(self, name):
        return name
    test_ArgReplacer = ArgReplacer(f, 'name')
    assert test_ArgReplacer.name == 'name'
    assert test_ArgReplacer.arg_pos == 1


# Generated at 2022-06-26 08:55:45.609777
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # No arguments

    # test class from above
    configurable_0 = Configurable()

    # With arguments (no implementation class chosen, so should defer to default)
    configurable_1 = Configurable()

    # With implementation class and argument
    configurable_2 = Configurable()

    # With implementation class string and argument
    configurable_3 = Configurable()

    # With implementation class from a subclass
    configurable_4 = Configurable()

    # With wrong implementation class string
    configurable_5 = Configurable()

    # With wrong implementation class string
    configurable_6 = Configurable()

    # With wrong implementation class string
    configurable_7 = Configurable()

    # With wrong implementation class string
    configurable_8 = Configurable()

    # With wrong implementation class
    configurable_9 = Configurable()

    # No arguments


# Generated at 2022-06-26 08:55:58.102055
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_0(arg1_0, arg2_0, arg3_0=10):
        print(arg1_0)
        print(arg2_0)
        print(arg3_0)

    arg_replacer_0 = ArgReplacer(func_0, 'arg3_0')
    print("old_value = %s" % str(arg_replacer_0.get_old_value((1, 2, 3, 4), {'arg3_0': 10}, None)))
    print("old_value = %s" % str(arg_replacer_0.replace(20, (1, 2, 3, 4), {'arg3_0': 10})))


if __name__ == '__main__':
    test_case_0()
    test_ArgReplacer_replace()

# Generated at 2022-06-26 08:56:00.429440
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    conf = Configurable()
    # conf.__new__()


# Generated at 2022-06-26 08:56:10.576923
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    old_value_0 = ArgReplacer('Method_0', 'Argument_1').get_old_value(['Argument_0', 'Argument_1'], {'key_0': 'value_0'})
    old_value_1 = ArgReplacer('Method_1', 'Argument_2').get_old_value(['Argument_0', 'Argument_1'], {'key_0': 'value_0'})
    old_value_2 = ArgReplacer('Method_2', 'Argument_3').get_old_value(['Argument_0', 'Argument_1'], {'key_0': 'value_0'})

# Generated at 2022-06-26 08:56:22.113003
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    class arg_replacer_test_0():
        def method_arg_replacer_test_0(self, a, b, c, d):
            pass
    
    arg_replacer_test_0_instance = arg_replacer_test_0()
    arg_replacer_test_0_instance.method_arg_replacer_test_0(1, 2, 3, d=4)

    replacer = ArgReplacer(arg_replacer_test_0.method_arg_replacer_test_0, "c")
    assert replacer.get_old_value((1, 2, 3, 4), {}) == 3

    replacer = ArgReplacer(arg_replacer_test_0.method_arg_replacer_test_0, "c")

# Generated at 2022-06-26 08:56:27.924968
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test_fun_0(arg1):
        return arg1
    test_fun_0_arg_replacer_0 = ArgReplacer(test_fun_0, 'arg1')
    test_fun_0_arg_replacer_1 = ArgReplacer(test_fun_0, 'arg1')


# Generated at 2022-06-26 08:56:31.274099
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.concurrent import Future
    future_0 = Future()
    pass


# Generated at 2022-06-26 08:56:58.776565
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    try:
        case_ObjectDict___getattr___0()
        case_ObjectDict___getattr___1()
        case_ObjectDict___getattr___2()
    except:
        return False
    else:
        return True

# Case for testing when self.dict is empty

# Generated at 2022-06-26 08:57:01.604955
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_1 = Configurable()
    configurable_2 = Configurable()


# Generated at 2022-06-26 08:57:14.262510
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_ArgReplacer_replace_0(a, b=1, c=2):
        ar = ArgReplressor(test_ArgReplacer_replace_0, 'b')
        old_value, args, kwargs = ar.replace(2, (1,), {'c':5})
        print(args)
        print(kwargs)
        print(old_value)

    def test_ArgReplacer_replace_1(a, b=1, c=2):
        ar = ArgReplressor(test_ArgReplacer_replace_1, 'b')
        old_value, args, kwargs = ar.replace(2, (1,), {'c':5})
        print(args)
        print(kwargs)
        print(old_value)


# Generated at 2022-06-26 08:57:16.674251
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Test the replace method of ArgReplacer
    # TODO: Test the replace method of ArgReplacer
    pass


# Generated at 2022-06-26 08:57:28.137263
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def method_replace(arg_name, new_value, args, kwargs):
        """
        This is a wrapper for the replace method of ArgReplacer that
        fixes the return type annotation of the replace method.
        """
        old_value, args, kwargs = ArgReplacer(method_replace, arg_name).replace(new_value, args, kwargs)
        return old_value, args, kwargs

    arg_name_0 = "arg_0"
    new_value_0 = 1
    args_0 = (1, 2)
    kwargs_0 = {arg_name_0: 0}
    assert method_replace(arg_name_0, new_value_0, args_0, kwargs_0) == (0, (1, 2), {})


# Generated at 2022-06-26 08:57:30.960977
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o.name = 'Cai'
    assert o['name'] == 'Cai'
    assert o.name == 'Cai'
    assert o.age == 'AttributeError'
    assert o.age == 'AttributeError'


# Generated at 2022-06-26 08:57:38.928693
# Unit test for function import_object
def test_import_object():
    print('test import_object')
    import tornado.escape
    if import_object('tornado.escape') is tornado.escape:
        print('test_import_object: pass')
    else:
        print('test_import_object: fail')

if __name__ == '__main__':
    test_import_object()

# Generated at 2022-06-26 08:57:40.553216
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-26 08:57:47.047047
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer_0 = ArgReplacer(func, "c")
    test_val_0 = (1, 2, 3)
    test_val_1 = {"c": 3}
    get_old_value_ret_0 = arg_replacer_0.get_old_value(test_val_0, test_val_1, 4)
    assert get_old_value_ret_0 == 3
    arg_replacer_0 = ArgReplacer(func, "d")
    get_old_value_ret_1 = arg_replacer_0.get_old_value(test_val_0, test_val_1, 4)
    assert get_old_value_ret_1 == 4


# Generated at 2022-06-26 08:57:51.131221
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    replace_0 = ArgReplacer(test_case_0, '0')
    replace_0.replace(test_case_0, tuple(), {})


# Generated at 2022-06-26 08:58:32.121411
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    global gzip_decompressor_1
    global nheaders
    nheaders = 1
    global headers_1
    headers_1 = {'GZ1': 'GZ1'}
    def test_func(fetch_request, x=None):
        return (fetch_request, x)
    args, kwargs = test_func(None, None)
    gzip_decompressor_1 = ArgReplacer(test_func, 'x').replace(True, args, kwargs)

    #return gzip_decompressor_1


# Generated at 2022-06-26 08:58:34.312326
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Case 0
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:58:42.881111
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func1 = functools.partial(test_ArgReplacer_func1, from_param=1)
    # Test case 1
    replacer_0 = ArgReplacer(func1, 'from_kwarg')
    new_value = -1 # If new_value = None, then old_value=None
    args = [0]
    kwargs = {}
    old_value, args, kwargs = replacer_0.replace(new_value, args, kwargs)
    if not (kwargs['from_kwarg'] == -1):
        raise ValueError()
    if not (old_value == None):
        raise ValueError()
    # Test case 2
    replacer_0 = ArgReplacer(func1, 'from_param')
    new_value = -1 # If new_value = None, then old

# Generated at 2022-06-26 08:58:47.674538
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class MyServer(TCPServer):
        def __init__(self, num_connections):
            super().__init__(TCPServer)

    # No replacement
    replacer = ArgReplacer(MyServer, "num_connections")
    num_connections = 5
    args = [num_connections]
    kwargs = {}
    assert replacer.replace(3, args, kwargs)[0] == 5
    assert replacer.replace(3, args, kwargs)[1] == [5]
    assert replacer.replace(3, args, kwargs)[2] == {}

    # Replacement
    replacer = ArgReplacer(MyServer, "num_connections")
    num_connections = 5
    args = []
    kwargs = {"num_connections": num_connections}
   

# Generated at 2022-06-26 08:59:01.168174
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # ==> test_method_initialize_of_class_Configurable()
    configurable_0 = Configurable()
    configurable_1 = Configurable()
    global_config = {
        "body": {},
        "headers": {},
        "max_buffer_size": 104857600,
        "max_body_size": 104857600,
        "max_header_size": 104857600,
        "max_headers": 200,
        "max_line_size": 65536,
        "request_timeout": 20.0,
        "validate_cert": True
    }
    httpclient_impl = Configurable.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient")
    httpclient_impl.initialize(io_loop=None, defaults=global_config)
    httpclient_impl

# Generated at 2022-06-26 08:59:10.322155
# Unit test for function errno_from_exception
def test_errno_from_exception():
    """Test for function errno_from_exception"""
    
    # raise IOError(2)
    try: 
        raise IOError(2)
    except IOError as e:
        assert errno_from_exception(e) == 2
    # raise IOError()
    try: 
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) == ()



# Generated at 2022-06-26 08:59:16.337516
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    obj = ArgReplacer(test_case_0, "gzip_decompressor")
    old_value = obj.get_old_value((), {}, None)
    assert old_value == None


# Generated at 2022-06-26 08:59:25.729314
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno is None
    try:
        raise Exception(1)
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 1
    try:
        raise Exception(1, 'message')
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 1
    try:
        raise Exception('message')
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno is None
    try:
        raise Exception('message', 1)
    except Exception as e:
        errno = errno_from_exception(e)
        assert err

# Generated at 2022-06-26 08:59:30.654120
# Unit test for function errno_from_exception
def test_errno_from_exception():
    errno_from_exception(3)
    errno_from_exception(ImportError("3"))
    errno_from_exception(ImportError("3", OSError("3")))


# Generated at 2022-06-26 08:59:34.226161
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b):
        return a, b
    replacer = ArgReplacer(foo, "a")
    assert (replacer.replace(5, (10, 20), {}) == (10, (5, 20), {}))


# Generated at 2022-06-26 09:00:45.322812
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    case = ObjectDict(x = "foo")
    assert_equals(case.x, "foo")
    assert_raises(AttributeError, getattr, case, "x1")


# Generated at 2022-06-26 09:00:51.038999
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Case 1
    func_0 = gzip_decompressor_0
    name_0 = 'zlib_mode'
    arg_replacer_0 = ArgReplacer(func_0, name_0)
    args_0 = (gzip_decompressor_0, )
    kwargs_0 = {'zlib_mode': 1}
    default_0 = 1
    old_value_0 = arg_replacer_0.get_old_value(args_0, kwargs_0, default_0)
    assert old_value_0 == 1


# Generated at 2022-06-26 09:00:54.773986
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_obj_0 = Configurable()
    test_obj_0.initialize()


# Generated at 2022-06-26 09:00:56.271493
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass


# Generated at 2022-06-26 09:00:57.677891
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    test_case_0()



# Generated at 2022-06-26 09:00:58.892449
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:01:05.027008
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        try:
            assert errno_from_exception(e) is None
        except BaseException as e:
            raise RuntimeError("test_errno_from_exception() fails")



# Generated at 2022-06-26 09:01:06.857284
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    test_f()


# Generated at 2022-06-26 09:01:10.060327
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    try:
        configurable_0.initialize()
    except NotImplementedError:
        pass


# Generated at 2022-06-26 09:01:16.073562
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b=2):
        return a * b

    arg_replacer_0 = ArgReplacer(foo, 'b')
    print(arg_replacer_0.replace(3, (1,), {}))


# Generated at 2022-06-26 09:02:31.853350
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    #
    # Test for default case
    #
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 09:02:38.227683
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    method_replace_argreplacer_0 = ArgReplacer(test_case_0, "in_buffer")
    in_buff = b"\0\0\0"
    in_buff, kwargs = method_replace_argreplacer_0.replace(in_buff, [b"\0\0\0\0", b"\0"], {})
    print(in_buff)

if __name__ == "__main__":
    test_ArgReplacer_replace()

# Generated at 2022-06-26 09:02:45.994344
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create a new instance of the class
    impl = Configurable()
    assert type(impl) == Configurable
    # Configure the base class, with keyword arguments
    Configurable.configure(impl, **kwargs)
    # Call the class method, that returns the configured class
    impl_class = impl.configured_class()
    assert type(impl_class) == Configurable
    # Save the configuration of the class
    impl_class = impl.save_configuration()



# Generated at 2022-06-26 09:02:48.961208
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # unit test for method initialize of class Configurable
    Configurable_0 = Configurable()
    # test method initialize, TODO


# Generated at 2022-06-26 09:02:59.891098
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    # No error is raised in this test case.
    # self.assertRaises(expected_exception, configurable_0.__new__, cls, *args, **kwargs)

    configurable_0.__new__(None)

    configurable_1 = Configurable()
    # No error is raised in this test case.
    # self.assertRaises(expected_exception, configurable_1.__new__, cls, *args, **kwargs)

    configurable_1.__new__(None)

    configurable_2 = Configurable()
    # No error is raised in this test case.
    # self.assertRaises(expected_exception, configurable_2.__new__, cls, *args, **kwargs)

    configurable_2.__new

# Generated at 2022-06-26 09:03:05.197640
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Arrange
    # act
    new_value = 'test'
    args = (1, )
    kwargs = {'test':1}
    arg_replacer = ArgReplacer(GzipDecompressor, 'test')
    result = arg_replacer.replace(new_value, args, kwargs)
    print(result)



# Generated at 2022-06-26 09:03:06.575354
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configuration_1 = Configurable()
    configuration_1.initialize()


# Generated at 2022-06-26 09:03:16.475567
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(i,j):
        pass

    def func2(i, j, k=1):
        pass

    def func3(i, j=1):
        pass
    
    def func4(i, j=2, k=1):
        pass
    
    def func5(i, j=1, k=2):
        pass

    argr = ArgReplacer(func1, 'i')
    print(argr.get_old_value((1, 2), {}))
    print(argr.get_old_value((1, 2), {'i': 3}))
    print(argr.get_old_value((1, 2), {'j': 3}))
    print(argr.get_old_value((1, 2, 'a'), {'j': 3}))

# Generated at 2022-06-26 09:03:24.655773
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Test for case 1
    def test_get_old_value_0_case_1():
        fn_0 = lambda x: x
        arg_replacer_0 = ArgReplacer(fn_0, 'x')
        args_0 = ()
        kwargs_0 = {'x': 1}
        default_0 = 2
        old_value_0 = arg_replacer_0.get_old_value(args_0, kwargs_0, default_0)
        assert old_value_0 == 1
    test_get_old_value_0_case_1()

# Generated at 2022-06-26 09:03:36.425981
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    # Test case for python2
    def test_func_0(arg_0, arg_1):
        return arg_0, arg_1

    # Test case for python3
    def test_func_1(arg_0, arg_1, kwarg_0=None):
        return arg_0, arg_1

    # Call wrapping function
    if os.name == 'nt':
        if sys.version_info[0] == 2:
            test_func_0 = wrapping_target.wrapping_target(test_func_0)
        else:
            test_func_1 = wrapping_target.wrapping_target(test_func_1)

    args_0 = (1, 2)
    kwargs_0 = {}