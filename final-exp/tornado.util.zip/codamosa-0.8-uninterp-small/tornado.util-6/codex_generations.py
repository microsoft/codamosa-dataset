

# Generated at 2022-06-26 08:54:13.588146
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create an object of type Configurable
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:54:16.771843
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyClass_0(Configurable):
        def __init__(self):
            pass

    myClass_0 = MyClass_0()


# Generated at 2022-06-26 08:54:21.802259
# Unit test for function raise_exc_info
def test_raise_exc_info():
    if __name__ == '__main__':
        try:
            raise ValueError('a')
        except:
            raise_exc_info(sys.exc_info())



# Generated at 2022-06-26 08:54:25.364598
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise Exception('dummy message')
    except Exception as e:
        raise_exc_info((type(e), e, e.__traceback__))


# Generated at 2022-06-26 08:54:27.864335
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Init args
    args_0 = ()
    # Init kwargs
    kwargs_0 = {}

    configurable_1 = Configurable(*args_0, **kwargs_0)


# Generated at 2022-06-26 08:54:35.717627
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    gzip_decompressor_0 = GzipDecompressor()
    argreplacer_1 = ArgReplacer(gzip_decompressor_0, "wbits")
    argreplacer_1.get_old_value(gzip_decompressor_0, 0)


# Generated at 2022-06-26 08:54:37.784799
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # instantiate
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:54:47.531704
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from io import IOBase
    # Test for overload #1 of Configurable.initialize
    configurable_0 = Configurable()
    configurable_0.initialize()

    # Test for overload #2 of Configurable.initialize
    configurable_1 = Configurable()
    configurable_1.initialize(file_obj=IOBase(), uri='', args=[], headers=None)

    # Test for overload #3 of Configurable.initialize
    configurable_2 = Configurable()
    configurable_2.initialize(write_func=lambda x: x, protocol_to_server=None, max_buffer_size=1)

    # Test for overload #4 of Configurable.initialize
    configurable_3 = Configurable()
    configurable_3.initialize(request_factory=lambda x: x)



# Generated at 2022-06-26 08:54:56.530918
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_arg_replacer_get_old_value(a: str, b: str = "str", *args: Any, **kwargs: Any) -> Any:
        args_0 = ArgReplacer(test_arg_replacer_get_old_value, "a")

        old_value_0 = args_0.get_old_value(args, kwargs)
        return old_value_0

    old_value_0 = test_arg_replacer_get_old_value("str_1")
    assert old_value_0 == "str_1"
    old_value_1 = test_arg_replacer_get_old_value("str_2", "str_1")
    assert old_value_1 == "str_2"


# Generated at 2022-06-26 08:55:04.111238
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(arg_0: int) -> float:
        return 2.0

    args_0 = (1, 2, 3, 4)
    kwargs_0 = {"a": "b", "c": "d"}
    arg_replacer = ArgReplacer(func, "arg_0")
    assert arg_replacer.get_old_value(args_0, kwargs_0) == 1
    assert arg_replacer.get_old_value(args_0, kwargs_0, 5) == 1


# Generated at 2022-06-26 08:55:34.089672
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func_0(a, b, c=3, d=4):
        pass
    arg_replacer_0 = ArgReplacer(func_0, 'c')
    assert arg_replacer_0.get_old_value(['a', 'b'], {}) is None

args0 = ['a', 'b']
args1 = []
kwargs0 = {'c':3, 'd':4}


# Generated at 2022-06-26 08:55:45.665238
# Unit test for function import_object
def test_import_object():
    # Test for function import_object
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        import sys
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        tb = traceback.format_exception(exc_type, exc_value, exc_traceback)
        assert tb[-1] == 'ImportError: No module named missing_module\n'
    else:
        raise AssertionError("Failed to raise import error")


# Generated at 2022-06-26 08:55:48.324832
# Unit test for function import_object
def test_import_object():
    # Tests for function import_object
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    assert import_object("tornado.missing_module")


# Generated at 2022-06-26 08:55:57.782171
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(x:int, y: int, z: int) -> Tuple[int, int, int]:
        pass

    arg_replacer_0 = ArgReplacer(foo, 'y')
    y = None
    x = None
    z = None
    old_value, args, kwargs = arg_replacer_0.replace(2, (x, y, z), {})
    assert old_value is None
    assert len(args) == 3
    assert args[0] is x
    assert args[1] == 2
    assert args[2] is z
    assert len(kwargs) == 0


# Generated at 2022-06-26 08:56:04.584491
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_0(x, y, z):
        return x + y + z
    _0 = ArgReplacer(func_0, "y")
    assert _0.replace(2, [2, 5], {'z': 6}) == (5, [2, 2], {'z': 6})


# Generated at 2022-06-26 08:56:08.093873
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # test_case_1
    configurable_0 = Configurable()
    configurable_0._initialize()


# Generated at 2022-06-26 08:56:12.217081
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    class MyClass(Configurable):
        def configurable_base(self):
            return MyClass

        def configurable_default(self):
            return GzipDecompressor

    # 创建一个MyClass的实例
    # testcase = MyClass()

    # 设置配置信息，这里将MyClass的实现类设置为GzipDecompressor
    # MyClass.configure(GzipDecompressor)

    # 创建一个实例
    testcase2 = MyClass()

    # 把配置信息还原回去
    MyClass.configure(None)



# Generated at 2022-06-26 08:56:14.322481
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    def test_case_0():
        configurable_0 = Configurable()

# Generated at 2022-06-26 08:56:18.865069
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # self = ArgReplacer(func, name)
    func = test_case_0
    name = "_gzip_decompressor"
    self = ArgReplacer(func, name)
    args = ()
    kwargs = {'name':'gzip_decompressor'}
    default = None
    print(self.get_old_value(args, kwargs, default))


# Generated at 2022-06-26 08:56:20.664734
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    gzip_decompressor_0 = GzipDecompressor()

    old_value = gzip_decompressor_0.get_old_value()


# Generated at 2022-06-26 08:56:37.152425
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print("Unit test for method __new__ of class Configurable")
    impl_class_0 = Configurable()
    args_0 = impl_class_0
    kwargs_0 = impl_class_0
    impl_class_0 = Configurable.__new__(impl_class_0, args_0, kwargs_0)
    assert impl_class_0 is not None


# Generated at 2022-06-26 08:56:37.753296
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass

# Generated at 2022-06-26 08:56:51.304808
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import _parse_content_range
    from tornado.httputil import _parse_headers
    from tornado.httputil import _parse_uri
    from tornado.httputil import _QuietException
    from tornado.httputil import _unicode
    from tornado.httputil import _UTF8_TYPES
    from tornado.httputil import _websocket_mask
    from tornado.httputil import _websocket_mask_python
    from tornado.httputil import _websocket_mask_python_native
    from tornado.httputil import _websocket_mask_python_pure
    from tornado.httputil import _websocket_mask_tornado
    from tornado.httputil import _websocket_mask_tornado

# Generated at 2022-06-26 08:57:02.742987
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def test_case_0(self, *args, **kwargs):
        # impl --> Configurable
        # init_kwargs --> Dict[str, Any]
        # instance --> Configurable
        module_0 = import_object('tornado.util')
        global Configurable
        Configurable = module_0.Configurable
        
        class Configurable_0(Configurable):
            def initialize(self, *_args, **_kwargs):
                self._initialize()
        
            def _initialize(self):
                pass
        
            @classmethod
            def configurable_base(cls):
                # type --> Type[Configurable]
                # type --> Type[Configurable]
                return Configurable_0
        

# Generated at 2022-06-26 08:57:12.360686
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # assert isinstance(Configurable(), Configurable)
    try:
        Configurable.configure(None)
    except:
        pass
    Configurable.configure(Configurable)
    try:
        Configurable.configure(ConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurableConfigurable)
    except:
        pass
    try:
        Configurable.configure('test_util.Configurable')
    except:
        pass
    try:
        Configurable.configure('test_util1.Configurable')
    except:
        pass


# Generated at 2022-06-26 08:57:19.556383
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    ok_0 = False
    try:
        ok_0 = True
    except:
        pass
    if ok_0:
        print("Test of replace of class \"ArgReplacer\" is OK.")
    else:
        print("Test of replace of class \"ArgReplacer\" failed.")


# Generated at 2022-06-26 08:57:20.361212
# Unit test for method initialize of class Configurable
def test_Configurable_initialize(): pass


# Generated at 2022-06-26 08:57:27.524698
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func():
        return "return value"

    arg_replacer_0 = ArgReplacer(func, "arg_name")
    old_value_0 = arg_replacer_0.get_old_value((), {}, default="default value")
    if old_value_0 != "default value":
        raise RuntimeError("Incorrect return value: %s" % (old_value_0,))

    return "return value"


# Generated at 2022-06-26 08:57:30.053152
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import_object('util')
    raise_exc_info((None, None, None))



# Generated at 2022-06-26 08:57:38.479790
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    objectdict_0 = ObjectDict()
    try:
        objectdict_0.get()
        assert False
    except Exception as e:
        assert isinstance(e, AttributeError)
    try:
        objectdict_0.get()
        assert False
    except Exception as e:
        assert isinstance(e, AttributeError)
    
    
    

# Generated at 2022-06-26 08:57:48.442312
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test that the __new__ method of an abstract class can be called
    test_case_0()



# Generated at 2022-06-26 08:57:51.865249
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    e = Configurable()
    # Expected call:
    #  Whatever.initialize(*args, **kwargs)
    e.initialize()

# Generated at 2022-06-26 08:57:53.403760
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass


# Generated at 2022-06-26 08:58:00.913229
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    args = (1, 2, 3, 4)
    kwargs = {'a':'a'}
    replacer = ArgReplacer(test_case_0, "decompress")
    old_value = replacer.get_old_value(args, kwargs)
    print(old_value)


# Generated at 2022-06-26 08:58:08.070703
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def def_Callable_0():
        return None
    name_0 = "name_0"
    args_0 = [None]
    kwargs_0 = {name_0: None}
    default_0 = None
    argreplacer_0 = ArgReplacer(def_Callable_0, name_0)
    old_value = argreplacer_0.get_old_value(args_0, kwargs_0, default_0)
    assert old_value == None


# Generated at 2022-06-26 08:58:15.355223
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    c = Configurable()
    try:
        c.initialize()
    except NotImplementedError as e:
        print(e)
    try:
        Configurable.configure(None, **{})
    except ValueError as e:
        print(e)
    try:
        Configurable.configure('base64', **{})
    except ValueError as e:
        print(e)


# Generated at 2022-06-26 08:58:17.220151
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-26 08:58:19.248329
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0._initialize()



# Generated at 2022-06-26 08:58:20.732987
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_object = Configurable()


# Generated at 2022-06-26 08:58:28.060209
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer_0 = ArgReplacer(test_case_0, 'old_value')
    args = [gzip_decompressor_0, ]
    kwargs = {}
    ret = arg_replacer_0.get_old_value(args, kwargs)
    print(ret)



# Generated at 2022-06-26 08:58:46.028152
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:58:50.257143
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    obj_name = "Configurable"
    gzip_decompressor_0 = GzipDecompressor()
    decompress_value = b"This is a test."
    max_len = 19
    result_0 = gzip_decompressor_0.decompress(decompress_value, max_len)
    assert(result_0 == decompress_value)


# Generated at 2022-06-26 08:58:56.350542
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    with mock.patch("tornado.util.Configurable.configurable_base") as mock_configurable_base:
        with mock.patch("tornado.util.Configurable.configurable_default") as mock_configurable_default:
            with mock.patch("tornado.util.Configurable.configured_class") as mock_configured_class:
                configurable_0 = Configurable()
                configurable_1 = Configurable()
                configurable_2 = Configurable()
                configurable_3 = Configurable()
                configurable_3.configure(None)
                configurable_4 = Configurable()
                configurable_5 = Configurable()
                configurable_6 = Configurable()
                configurable_7 = Configurable()
                configurable_8 = Configurable()
                configurable_8.configure("")
                config

# Generated at 2022-06-26 08:59:04.506193
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = SimpleAsyncHTTPClient
    from twisted.internet import reactor
    # Create a new subclass of class Configurable with
    # name 'HTTPTimeoutError'
    class HTTPTimeoutError(TimeoutError):
        pass
    class HTTPTooManyRedirectsError(HTTPError):
        pass
    import asyncio
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    response = HTTPResponse(request=None, code=200, headers=None, request_time=None,
                            body=None, buffer=None, effective_url=None)

# Generated at 2022-06-26 08:59:10.321770
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = test_case_0
    arg_replacer = ArgReplacer(func, "dst")
    arg_replacer.replace(new_value = gzip_decompressor_0, args = (1, 2, 3), kwargs = [])


# Generated at 2022-06-26 08:59:15.792139
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = typing.cast(Type[Configurable], import_object('tornado.netutil.0'))
    impl = Configurable.configured_class()


# Generated at 2022-06-26 08:59:25.956172
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(OSError()) is None
    assert errno_from_exception(OSError(0)) == 0
    assert errno_from_exception(OSError(b"test")) == b"test"
    try:
        raise OSError()
    except OSError as e:
        assert errno_from_exception(e) is None
    try:
        raise OSError(0)
    except OSError as e:
        assert errno_from_exception(e) == 0
    try:
        raise OSError(b"test")
    except OSError as e:
        assert errno_from_exception(e) == b"test"


# Generated at 2022-06-26 08:59:35.982534
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def function_1(first_arg_0, second_arg_2):
        return
    first_arg_0 = 5
    second_arg_2 = None
    args = [first_arg_0]
    kwargs = {'second_arg': second_arg_2}
    replacer_0 = ArgReplacer(function_1, 'first_arg')
    old_value_0, args_0, kwargs_0 = replacer_0.replace(47, args, kwargs)
    assert args_0 == [47]
    assert kwargs_0 == {'second_arg': None}
    assert old_value_0 == 5

if __name__ == '__main__':
    test_case_0()
    test_ArgReplacer_replace()

# Generated at 2022-06-26 08:59:47.095803
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    print("----- Test initialize of class Configurable -----")
    # Test case 1: Test object initialization
    configurable_0 = Configurable()
    assert_equals(isinstance(configurable_0, Configurable), True)

    # Test case 2: Test object initialization
    configure_0 = Configurable.configure(None)
    assert_equals(configure_0, None)

    # Test case 3: Test object initialization
    configured_class_0 = Configurable.configured_class()
    assert_equals(isinstance(configured_class_0, Configurable), True)

    # Test case 4: Test object initialization
    save_configuration_0 = Configurable._save_configuration()
    assert_equals(save_configuration_0, (None, None))

    # Test case 5: Test object initialization
    restore_config

# Generated at 2022-06-26 08:59:50.728858
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    arg_replacer_0 = ArgReplacer(test_case_0, 'kwargs')
    actual_exception = None
    try:
        arg_replacer_0.replace(new_value, args, kwargs)
    except Exception as exception:
        actual_exception = exception
    assert actual_exception == expected_exception


# Generated at 2022-06-26 09:00:17.056715
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func_0():
        return
    def func_1(key_0):
        return
    def func_2(key_0, key_1, key_2):
        return
    def func_3(key_0, key_1, key_2, key_3):
        return
    def func_4(key_0, key_1, key_2, key_3, key_4):
        return
    def func_5(key_0, key_1, key_2, key_3, key_4, key_5):
        return
    def func_6(key_0, key_1, key_2, key_3, key_4, key_5, key_6):
        return

# Generated at 2022-06-26 09:00:19.370961
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_value_0 = Configurable.configure("cls")


# Generated at 2022-06-26 09:00:22.058025
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    state_configurable_0 = Configurable()
    assert state_configurable_0 == {}


# Generated at 2022-06-26 09:00:29.206280
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Test case: test_arg
    test_args = [(1, 2), (4, 5), (7, 8), (10, 11)]
    test_kwargs = {
        "a": 172,
        "b": 514,
        "c": 999,
        "d": 10086
    }
    assert ArgReplacer(test_case_0, "a").replace(0, *test_args, **test_kwargs) == (172, [1, 0, 514, 999], {'c': 10086, 'd': 10086})

print("Test results: ")
test_ArgReplacer_replace()

# Generated at 2022-06-26 09:00:34.330849
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func = gzip_decompressor_0.decompress
    name = "wbits"
    arg_replacer_0 = ArgReplacer(func, name)
    value = 9
    args = (b'\x1f\x8b', value)
    kwargs = {}
    old_value = arg_replacer_0.get_old_value(args, kwargs, default=None)
    # Disable the following assert
    # assert value == old_value


# Generated at 2022-06-26 09:00:36.326798
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import_object(name = 'tornado.util.Configurable')


# Generated at 2022-06-26 09:00:38.385065
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass


# Generated at 2022-06-26 09:00:48.086705
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl_class_0 = Configurable.configure(None)
    configurable_0 = Configurable.configurable_default()
    configurable_1 = Configurable.configure(type)
    configurable_2 = Configurable.configurable_base()
    configurable_3 = Configurable.configured_class()
    saved_0 = Configurable._save_configuration()
    configurable_4 = Configurable._restore_configuration(saved_0)


# Generated at 2022-06-26 09:00:49.992235
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass


# Generated at 2022-06-26 09:00:58.993086
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # init_kwargs = {}  # type: Dict[str, Any]
    # instance = super(Configurable, cls).__new__(impl)
    # # initialize vs __init__ chosen for compatibility with AsyncHTTPClient
    # # singleton magic.  If we get rid of that we can switch to __init__
    # # here too.
    # instance.initialize(*args, **init_kwargs)
    pass


# Generated at 2022-06-26 09:01:27.535089
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base_0 = Configurable.configurable_base()
    init_kwargs_0 = {}
    if cls is base_0:
        impl_0 = Configurable.configured_class()
        if base_0.__impl_kwargs:
            init_kwargs_0.update(base_0.__impl_kwargs)
    else:
        impl_0 = cls
    init_kwargs_0.update(kwargs)
    if impl_0.configurable_base() is not base_0:
        return impl_0(*args, **init_kwargs_0)
    instance_0 = super(Configurable, cls).__new__(impl_0)
    instance_0.initialize(*args, **init_kwargs_0)
    return instance_0


# Generated at 2022-06-26 09:01:37.893833
# Unit test for function import_object
def test_import_object():
    tornado_escape = import_object('tornado.escape')
    assert tornado_escape is not None

# Same as json.loads, but supports comment syntax.
# This is not a public function, so there's no need to document it.  We
# just define it to remove the dependency on simplejson.
_COMMENT_RE = re.compile(r'//.*$|/\*.*?\*/|\'(?:\\.|[^\\\'])*\'|"(?:\\.|[^\\"])*"')


# Generated at 2022-06-26 09:01:40.041227
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    test_case_0()
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado



# Generated at 2022-06-26 09:01:41.038486
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-26 09:01:41.974808
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    assert False



# Generated at 2022-06-26 09:01:45.057284
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """Test the method __new__ of class Configurable"""
    configurable_0 = Configurable()



# Generated at 2022-06-26 09:01:54.137335
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):
        def configurable_base(self):
            return Configurable

        def configurable_default(self):
            return Configurable

        def initialize(self):
            pass

    implClass = MyConfigurable()
    implClass.configure(MyConfigurable, implClass)

    assert implClass.configurable_base() is Configurable
    assert implClass.configured_class() is Configurable

# Generated at 2022-06-26 09:01:59.658171
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # 1
    configurable_0 = Configurable.configurable_default()
    print(configurable_0)
    # 2
    # configurable_1 = Configurable()
    # 3
    # Configurable.configure(impl=None, **kwargs={})
    # 4
    # configurable_2 = Configurable.configured_class()
    # 5
    # configurable_3 = Configurable._save_configuration()
    # 6
    # Configurable._restore_configuration(saved=(configurable_0, None))


# Generated at 2022-06-26 09:02:01.485531
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    pass


# Generated at 2022-06-26 09:02:07.644393
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o['a'] = 1
    o['b'] = 2
    assert o.a == 1
    assert o['a'] == 1
    assert o.b == 2
    assert o['b'] == 2
    assert o.c  # ERROR
    #assert o.c == 3
    # ERROR:
    #   Expected:
    #     c == 3
    #   Got:
    #     AttributeError: c
    
    

# Generated at 2022-06-26 09:02:45.842632
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    __impl_class  = None 
    __impl_kwargs = None 
    impl = Configurable.configurable_base()
    if impl is Configurable:
        impl = Configurable.configurable_default()
    instance = super(Configurable, impl).__new__(impl)
    instance.initialize()

# Generated at 2022-06-26 09:02:57.170960
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    @gen.coroutine
    def f(x, y):
        return x + y
    # Test case 1
    r = ArgReplacer(f, "x")
    x, args, kwargs = r.replace("new_value", (1, 2), {"y": 2})
    assert args == ("new_value", 2)
    assert kwargs == {"y": 2}
    assert x == 1
    # Test case 2
    r = ArgReplacer(f, "y")
    y, args, kwargs = r.replace("new_value", (1, 2), {"y": 2})
    assert args == (1, "new_value")
    assert kwargs == {"y": 2}
    assert y == 2
    # Test case 3
    r = ArgReplacer(f, "z")
    z,

# Generated at 2022-06-26 09:02:59.361709
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    instance = Configurable()
    initialize_0 = instance.initialize
    assert initialize_0==instance._initialize

# Generated at 2022-06-26 09:03:09.817771
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Function definition for decorator
    def wrapper(func, *args, **kwargs):
        return ArgReplacer(func, "callback").replace(args, kwargs)

# Generated at 2022-06-26 09:03:11.228121
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable = Configurable()
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 09:03:21.794374
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Test 1
    argreplacer_0 = ArgReplacer(test_case_0, "name")
    #expected 2
    str_rep = "ArgReplacer(name)"
    #expected "name"
    str_rep = str(argreplacer_0)
    #expected 0
    str_rep = len(argreplacer_0)
    #expected True
    str_rep = argreplacer_0.get_old_value((), None, "default")
    #expected None
    str_rep = argreplacer_0.get_old_value((), None)
    #expected None
    str_rep = argreplacer_0.get_old_value((1,), None)
    #expected None
    str_rep = argreplacer_0.get_old_value(None, None)
    #expected None


# Generated at 2022-06-26 09:03:27.360993
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_0(self, arg_0, arg_1):
        pass
    argreplacer_0 = ArgReplacer(func_0, "arg_0")
    assert (argreplacer_0.arg_pos == 0)
    assert (argreplacer_0.name == "arg_0")


# Generated at 2022-06-26 09:03:28.870520
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 09:03:36.349979
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_ArgReplacer_get_old_value_0():
        gzip_decompressor_0 = GzipDecompressor()
        arg_replacer_0 = ArgReplacer(gzip_decompressor_0, 'wbits')
        test_ArgReplacer_get_old_value_0_1(arg_replacer_0)

    def test_ArgReplacer_get_old_value_0_1(arg_replacer_0):
        assert arg_replacer_0.get_old_value((), {}, -1) == -1


# Generated at 2022-06-26 09:03:41.330209
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    impl = Configurable()
    impl.initialize()
    print("{'__impl_class':None,'__impl_kwargs':None}")

if __name__ == "__main__":
    test_case_0()
    test_Configurable_initialize()