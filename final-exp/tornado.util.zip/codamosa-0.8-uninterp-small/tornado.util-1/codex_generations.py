

# Generated at 2022-06-26 08:54:18.013273
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurableClass(Configurable):
        def __init__(self, *args, **kwargs):
            self.initialize(*args, **kwargs)
            print('in TestConfigurableClass::__init__')

        def _initialize(self, *args, **kwargs):
            super(Configurable, self).initialize(*args, **kwargs)

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

    configurable_obj = TestConfigurableClass()
    assert isinstance(configurable_obj, TestConfigurableClass)


# Generated at 2022-06-26 08:54:20.697465
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()

if __name__ == "__main__":
    test_Configurable___new__()

# Generated at 2022-06-26 08:54:24.187902
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    greeter = ArgReplacer(lambda name: None, "name")
    greeter.replace('hello', (), {'name': 'world'}) == 'hello'

test_case_0()
test_ArgReplacer_replace()

# Generated at 2022-06-26 08:54:30.447496
# Unit test for function import_object
def test_import_object():
    # module test
    test.assert_true(import_object("tornado") is tornado)
    # from-module test
    test.assert_true(import_object("tornado.escape") is tornado.escape)
    # class test
    test.assert_true(import_object("tornado.escape.utf8") is tornado.escape.utf8)
    # non-existent test
    with test.assert_raises(ImportError):
        import_object("tornado.missing_module")


# Generated at 2022-06-26 08:54:33.018520
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print("Testing method __new__ of class Configurable")
    pass


# Generated at 2022-06-26 08:54:38.672033
# Unit test for function import_object
def test_import_object():
    import_object('tornado.http1connection')
    import_object('tornado.platform.asyncio.BaseAsyncIOLoop')

    # test for failure path
    try:
        import_object('torando.http1connection')
        assert False
    except:
        assert True




# Generated at 2022-06-26 08:54:41.637029
# Unit test for function import_object
def test_import_object():
    assert(import_object('test_object_import') == test_case_0)

import functools



# Generated at 2022-06-26 08:54:49.894394
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    args = ('arg1', 'arg2', 'arg3')
    kwargs = {'key1':'value1', 'key2':'value2'}
    ArgReplacer_ins = ArgReplacer(test_case_0, 'arg1')
    if 'arg1' != ArgReplacer_ins.get_old_value(args, kwargs, 1):
        raise Exception('Error')


# Generated at 2022-06-26 08:54:54.555368
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    args_0 = []
    kwargs_0 = {}
    default_0 = None
    arg_replacer_0 = ArgReplacer(test_case_0, "decompress")
    old_value = arg_replacer_0.get_old_value(args_0, kwargs_0)
    assert old_value is default_0


# Generated at 2022-06-26 08:55:00.614988
# Unit test for function import_object
def test_import_object():
    result = import_object('tornado.escape')
    print(result)
    result = import_object('tornado')
    print(result)

    try:
        import_object('tornado.missing_module')
    except ImportError as e:
        print(e)



# Generated at 2022-06-26 08:55:22.770242
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Configurable_0(Configurable):

        def configurable_base(self):
            # type: () -> Type[Configurable]
            pass

        def configurable_default(self):
            # type: () -> Type[Configurable]
            pass

        def initialize(self):
            # type: () -> None
            pass

    configurable_0 = Configurable_0()
    Configurable.configured_class()
    Configurable.configured_class()


# Generated at 2022-06-26 08:55:26.071770
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    impl=Configurable._Configurable__impl_class

    def initializ(self, *arg, **kwargs):
        Configurable.initialize(self, *arg, **kwargs)
    initializ(impl, {'a': 1, 'b': 2})

# Entry point of tests

# Generated at 2022-06-26 08:55:34.793447
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class_1 = Configurable()
    # PASS: Callable[..., None]
    assert isinstance(class_1.initialize, Callable)
    try:
        class_1.initialize()
    except NotImplementedError:
        assert True
#     except FunctionNotImplementedError:
#         assert True
    except:
        assert False
# PASS: FunctionNotImplementedError
    else:
        assert False


# Generated at 2022-06-26 08:55:42.689379
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(Exception('a')) == 'a'
    assert errno_from_exception(Exception(1)) == 1
    assert errno_from_exception(Exception()) == None
    try:
        raise Exception('a')
    except:
        assert errno_from_exception(Exception(sys.exc_info()[0])) == 'a'


# Generated at 2022-06-26 08:55:44.650417
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Initialize the object with default values
    configurable_obj = Configurable()
    # Initialize the object with custom values
    configurable_obj_2 = Configurable()


# Generated at 2022-06-26 08:55:48.172292
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    global_config_0 = Configurable()
    initialize_0 = global_config_0.initialize
    initialize_0()



# Generated at 2022-06-26 08:55:59.150891
# Unit test for method initialize of class Configurable

# Generated at 2022-06-26 08:56:06.036290
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    c = Configurable()
    c.initialize()
    # Tuple[Optional[type], Optional[BaseException], Optional[TracebackType]]
    t = None, None, None
    raise_exc_info(t)
    # Optional[int]
    i = errno_from_exception(None)
    # Type[Any]
    a = type(1)


# Generated at 2022-06-26 08:56:11.568495
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class_0 = Configurable()
    i = 1
    try:
        for loopIndex in range(loopCount):
            class_0.initialize(1, 2, i)
            i += 1
    except:
        pass


# Generated at 2022-06-26 08:56:13.952024
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    #context={}
    #context["a"] = 1
    #context["b"] = 2
    #context["c"] = 3
    #test_case_0(context)
    test_case_0()

# Generated at 2022-06-26 08:56:28.410670
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # kwargs = {'': None, '': None}
    args = ()

    # Return value of method __new__ of class Configurable
    impl = Configurable.configured_class()
    assert issubclass(impl, Configurable)

    # Call method __new__ of class Configurable
    instance = Configurable.__new__(impl, *args)
    assert isinstance(instance, Configurable)
    assert isinstance(instance, impl)


# Generated at 2022-06-26 08:56:30.809166
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # TODO unit test for Configurable.initialize
    pass


# Generated at 2022-06-26 08:56:39.043006
# Unit test for method __new__ of class Configurable

# Generated at 2022-06-26 08:56:43.602464
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Init the class
    configurable_0 = Configurable()
    # Assert type of configurable_0 is Configurable
    assert isinstance(configurable_0, Configurable)


# Generated at 2022-06-26 08:56:56.559623
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()
    # Test
    from tornado.concurrent import Future
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop

    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Bar

        def initialize(self):
            pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    class TestFoo(AsyncTestCase):
        def test_configure(self):
            with self.assertRaises(ValueError):
                Foo.configure(Baz)
            Foo.configure(Bar)
            self.assertIsInstance(Foo(), Bar)

# Generated at 2022-06-26 08:57:05.839871
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        # Test for Argument count mismatch
        configurable_0 = Configurable()
        configurable_1 = Configurable()
        configurable_2 = Configurable()
        configurable_3 = Configurable()
        configurable_4 = Configurable()
        configurable_5 = Configurable()
        configurable_6 = Configurable()
        configurable_7 = Configurable()
        configurable_8 = Configurable()
        configurable_9 = Configurable()
        configurable_10 = Configurable()
        configurable_11 = Configurable()
        configurable_12 = Configurable()
        configurable_13 = Configurable()
        configurable_14 = Configurable()
    except NotImplementedError:
        pass

    # Test case for abased class
    # Test for branch "if impl is not None and not issubclass

# Generated at 2022-06-26 08:57:11.314763
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestClass(Configurable):
        def __init__(self):
            pass
    try:
        TestClass().initialize()
    except NotImplementedError as e:
        pass
    except Exception as e:
        assert False
    else:
        assert False


# Generated at 2022-06-26 08:57:17.300472
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test __new__ without argument
    configurable_0 = Configurable(Configurable())
    # Test __new__ with arguments
    configurable_1 = Configurable()
    configurable_2 = Configurable(1, 1)


# Generated at 2022-06-26 08:57:20.351661
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:57:24.580481
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    err_str = "The 'impl' argument should be of type: Union[None, str, Type[Configurable]]"
    try:
        Configurable.configure(None)
    except ValueError as e:
        assert str(e) == err_str
    else:
        assert False, "ValueError not raised"


# Generated at 2022-06-26 08:57:44.182989
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def create_Configurable():
        return Configurable()

    try:
        create_Configurable()
    except TypeError as e:
        assert isinstance(e, TypeError)
        assert e.args == ("Can't instantiate abstract class Configurable with abstract methods configurable_base, configurable_default",)


# Generated at 2022-06-26 08:57:52.594273
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    conf_class = Configurable()

    with pytest.raises(NotImplementedError):
        conf_class.configurable_base()
    with pytest.raises(NotImplementedError):
        conf_class.configurable_default()
    with pytest.raises(TypeError):
        conf_class.__init__()

    conf_class.initialize()


# Generated at 2022-06-26 08:57:59.825786
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # Initialization
    _o = ObjectDict()
    _o['a'] = 0
    _o['b'] = 1
    if _o.a != 0:
        return False
    if _o.b != 1:
        return False

    # Return value
    return True


# Generated at 2022-06-26 08:58:01.819683
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Instanciate the class Configurable
    configurable_0 = Configurable()
    assert configurable_0 is not None
    assert configurable_0.initialize is not None


# Generated at 2022-06-26 08:58:12.050566
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Default case
    impl_class_0 = Configurable.configured_class()
    instance_0 = Configurable.__new__(impl_class_0)
    # Boundary case
    impl_class_1 = Configurable.configured_class()
    instance_1 = Configurable.__new__(impl_class_1)
    # Boundary case
    impl_class_2 = Configurable.configured_class()
    instance_2 = Configurable.__new__(impl_class_2)
    # Boundary case
    impl_class_3 = Configurable.configured_class()
    instance_3 = Configurable.__new__(impl_class_3)


# Generated at 2022-06-26 08:58:14.651070
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    new_instance = Configurable()
    # new_instance._initialize()


# Generated at 2022-06-26 08:58:15.908765
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # make instance of Configurable
    conf = Configurable()


# Generated at 2022-06-26 08:58:23.759619
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # pylint: disable=missing-docstring, protected-access
    obj1 = ObjectDict()
    obj1.a = 1
    obj1.c = 2
    assert obj1['a'] == 1
    assert obj1['b'] == 3
    assert obj1.a == 1
    assert obj1.b == 2


# Generated at 2022-06-26 08:58:32.865765
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
  expected_0 = None
  expected_1 = None
  expected_2 = None
  expected_3 = None

  # Test 0
  # Clear environment to ensure that test works correctly
  os.environ.pop('TORNADO_TEST_VALUE', None)

# Generated at 2022-06-26 08:58:38.301360
# Unit test for function errno_from_exception
def test_errno_from_exception():
    errno_from_exception(FileNotFoundError(2, 'No such file or directory'))
    errno_from_exception(FileNotFoundError())
    errno_from_exception(FileNotFoundError('No such file or directory'))


# Generated at 2022-06-26 08:58:49.404535
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create a Configurable instance
    configurable_0 = Configurable()
    assert isinstance(configurable_0, Configurable)


# Generated at 2022-06-26 08:58:52.795045
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    gzip_decompressor_0 = GzipDecompressor()
    assert type(gzip_decompressor_0) == GzipDecompressor

# Generated at 2022-06-26 08:59:03.400668
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    a_0 = A()
    a_1 = A()
    a_2 = A()
    assert_equal(a_0, a_0)
    assert_equal(a_0, a_1)
    assert_is_not(a_0, a_2)
    assert_is(a_0, a_1)
    assert_equal(a_2, a_2)
    assert_is_not(a_2, a_0)

    # Test argument passing
    A.configure(A)
    a_3 = A(10, 20)
    a_3.initialize(10, 20)


# Generated at 2022-06-26 08:59:06.203273
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0_instance = Configurable()
    configurable_0_instance.initialize()


# Generated at 2022-06-26 08:59:07.416042
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    gzip_decompressor_0 = GzipDecompressor()
    gzip_decompressor_0._initialize()


# Generated at 2022-06-26 08:59:12.789383
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    foo = Configurable()
    foo_0 = Configurable.configure(None)
    foo_1 = Configurable.configured_class()
    foo_2 = Configurable.configure(None)
    foo_3 = Configurable.configured_class()

test_case_0()
test_Configurable___new__()

# Generated at 2022-06-26 08:59:14.366887
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_case_0()



# Generated at 2022-06-26 08:59:20.314886
# Unit test for function import_object
def test_import_object():
    print(import_object('tornado.escape')) 
    print(import_object('tornado.escape.utf8')) 
    print(import_object('tornado')) 
    print(import_object('tornado.missing_module')) 


# Generated at 2022-06-26 08:59:24.577163
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = Configurable()
    base.configure("a.b.c")
    base.__new__(Configurable)
    base.__new__(Configurable)
    base.__new__(Configurable)
    base.__new__(Configurable)
    base.__new__(Configurable)
    base.__new__(Configurable)
    base.__new__(Configurable)



# Generated at 2022-06-26 08:59:31.827729
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print("\nBegin test: Method __new__ of class Configurable")
    demo_0 = Configurable()
    demo_0.configure('Configurable')
    demo_0.configure(Configurable)
    demo_1 = Configurable()
    print("\nEnd test: Method __new__ of class Configurable")


# Generated at 2022-06-26 08:59:57.242496
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Implicit call to _initialize method
    class Impl(object):
        def _initialize(self) -> None:
            pass
    class Impl1(object):
        def _initialize(self) -> None:
            pass
    class Config(Configurable):
        @classmethod
        def configurable_base(cls):
            return Configurable
        @classmethod
        def configurable_default(cls):
            return Impl

    # Implicit call to __init__ method
    class Impl1(object):
        def __init__(self) -> None:
            pass
    class Config1(Configurable):
        @classmethod
        def configurable_base(cls):
            return Configurable
        @classmethod
        def configurable_default(cls):
            return Impl

    # Implicit call to _initialize method

# Generated at 2022-06-26 09:00:00.152858
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_base_0 = Configurable()
    configurable_base_0.initialize()


# Generated at 2022-06-26 09:00:03.739955
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Arrange
    configurable_0 = Configurable()

    # Act
    print(configurable_0)

    # Assert
    configurable_0 = None


# Generated at 2022-06-26 09:00:16.249422
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_Configurable_initialize_args_0 = []
    test_Configurable_initialize_kwargs_0 = {}
    test_Configurable_initialize_args_1 = [arg_0_0]
    test_Configurable_initialize_kwargs_1 = {arg_1_0 : arg_1_1}
    test_Configurable_initialize_args_2 = [arg_0_0, arg_1_0]
    test_Configurable_initialize_kwargs_2 = {arg_2_0 : arg_2_1}
    test_Configurable_initialize_args_3 = [arg_0_0, arg_1_0, arg_2_0]
    test_Configurable_initialize_kwargs_3 = {arg_3_0 : arg_3_1}
    test_

# Generated at 2022-06-26 09:00:17.886780
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:00:21.771387
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Set up mock data
    init_kwargs = {}
    # Call method
    result = Configurable.initialize(init_kwargs)


# Generated at 2022-06-26 09:00:30.749046
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestClass(Configurable):
        def __init__(self, *args: Any, **kwargs: Any):
            self.args = args
            self.kwargs = kwargs
            self.initialize(*args, **kwargs)

        def _initialize(self, *args: Any, **kwargs: Any):
            self.args = args
            self.kwargs = kwargs

        def configurable_base(self):
            return self

        def configurable_default(self):
            return self

    test_class_0 = TestClass(1, 2, 3, a=4, b=5, c=6,)

    test_class_1 = TestClass(1, 2, 3, a=4, b=5, c=6,)


# Generated at 2022-06-26 09:00:32.844676
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_case = Configurable()
    test_case.initialize()


# Generated at 2022-06-26 09:00:39.688823
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass

test_case_0()
test_import_object()

# Named tuple that represents the result of parse_timedelta
_TimedeltaParsedResult = typing.NamedTuple(
    "TimedeltaParsedResult",
    [("days", int), ("seconds", int), ("microseconds", int)])



# Generated at 2022-06-26 09:00:48.112366
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Configurable_0(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return Configurable_0

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return Configurable_0

    Configurable_1 = Configurable_0()

test_case_0()
test_Configurable___new__()

# Generated at 2022-06-26 09:01:11.974339
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Initialize a Configurable instance with no args and no kwargs.
    # Then run method initialize
    # with no args and no kwargs.
    # Then run instance method _initialize
    # with no args and no kwargs.
    # Then assert that the output is None.
    assert Configurable().initialize() is None


# Generated at 2022-06-26 09:01:18.288674
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = IOStream
    impl = IOStream
    kwargs = {}

    Configurable.configure(impl, **kwargs)
    assert Configurable.configurable_base() == base
    assert Configurable.configured_class() == impl


# Generated at 2022-06-26 09:01:22.956742
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    TestConfigurable_0 = Configurable()
    TestConfigurable_0.initialize()



# Generated at 2022-06-26 09:01:26.791633
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base_0 = Configurable.configurable_base()
    print("Unit test for method __new__ of class Configurable")
    print("TODO...")
    print("---")


# Generated at 2022-06-26 09:01:29.048590
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # TODO
    pass


# Generated at 2022-06-26 09:01:32.275439
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    odict_0 = ObjectDict()
    odict_0.value = 'value'
    odict_0.value


# Generated at 2022-06-26 09:01:35.702165
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    obj_0 = Configurable()


# Generated at 2022-06-26 09:01:37.503843
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass


# Generated at 2022-06-26 09:01:43.436495
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # Create an instance of class ObjectDict
    object_dict_0 = ObjectDict()
    # Access attribute 'a' of object_dict_0
    # No exception should be raised
    object_dict_0.a = 'a'


# Generated at 2022-06-26 09:01:45.361954
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable.__new__(Configurable)


# Generated at 2022-06-26 09:02:09.529702
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_1 = Configurable.__new__(Configurable)


# Generated at 2022-06-26 09:02:11.257084
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    a = Configurable()


# Generated at 2022-06-26 09:02:18.094672
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize(1, 2, 3)
    configurable_0.initialize()
    configurable_0.initialize(1, 2)
    configurable_0.initialize((1, 2, 3))
    configurable_0.initialize((1, 2))


# Generated at 2022-06-26 09:02:23.382585
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_base_0 = Configurable()
    configurable_default_0 = Configurable()
    impl_class_0 = 'fake_impl_class_0'
    test_Configurable_configure_0 = Configurable.configure(impl_class_0)


# Generated at 2022-06-26 09:02:25.678563
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create an instance of the base class
    c = Configurable()
    assert c


# Generated at 2022-06-26 09:02:27.606025
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0._initialize()
    assert True


# Generated at 2022-06-26 09:02:31.547471
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    init_kwargs0 = 'TestException'
    configurable = Configurable()
    try:
        configurable.initialize(init_kwargs0)
    except Exception as e:
        pass


# Generated at 2022-06-26 09:02:42.404367
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj1 = ObjectDict()
    obj1["A"] = 123
    obj1["B"] = True
    print(obj1.A)
    print(obj1.B)
    obj2 = ObjectDict()
    obj2.C = "ABC"
    obj2.D = 999.99
    obj2["E"] = "XYZ"
    obj2["F"] = "Haha"
    obj2.G = [1,2,3,4,5]
    print(obj2.C)
    print(obj2["D"])
    print(obj2.E)
    print(obj2["F"])
    print(obj2.G)

# Generated at 2022-06-26 09:02:46.386923
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    @Configurable
    class Configurable_0(Configurable):
        def __init__(self):
            pass
        def configurable_base(self):
            return Configurable_0
        def configurable_default(self):
            return Configurable_0
    configurable_0 = Configurable_0()
    configurable_0.initialize()


# Generated at 2022-06-26 09:02:47.741476
# Unit test for function import_object
def test_import_object():
    test_case_0()


# Generated at 2022-06-26 09:03:30.011975
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    testcase = [configurable_0]
    #testcase = [test_case_0()]
    for t in testcase:
        t.__new__(t, *tuple())


# Generated at 2022-06-26 09:03:32.593653
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    test_dic = ObjectDict()
    test_dic.test_key = 2
    obj = test_dic["test_key"]


# Generated at 2022-06-26 09:03:34.572396
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    test_obj = Configurable()


# Generated at 2022-06-26 09:03:37.004033
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    _configurable_0 = Configurable()
    _configurable_0.initialize()

# Exports for typing
Configurable = Configurable

# Generated at 2022-06-26 09:03:37.949866
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-26 09:03:42.630106
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = None
    init_kwargs = {}
    instance = Configurable.__new__(impl, *(), **init_kwargs)
    instance_type = type(instance)
    assert(instance_type == impl)


# Generated at 2022-06-26 09:03:43.689411
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    arg0 = Configurable()
    arg0.__new__(Configurable)

# Generated at 2022-06-26 09:03:45.681232
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # The type of impl is <class 'bool'>, although it is not an instance of class bool
    impl_0 = Configurable.configured_class()
    assert impl_0 is not None


# Generated at 2022-06-26 09:03:47.304038
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    application_0 = Application()
    args_0 = [1]
    kwargs_0 = {'key': 2}

