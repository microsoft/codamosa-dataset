

# Generated at 2022-06-26 08:54:25.852431
# Unit test for function import_object
def test_import_object():
    # Should have TornadoObjectDict
    import tornado.util
    print(tornado.util.__dict__)

    import tornado.escape
    print(tornado.escape.__dict__)

    print(import_object('tornado.util') is tornado.util)
    print(import_object('tornado.escape') is tornado.escape)
    #print(import_object('tornado.escape.utf8') is tornado.escape.utf8)
    print(import_object('tornado') is tornado)
    #print(import_object('tornado.missing_module'))


# Generated at 2022-06-26 08:54:27.805145
# Unit test for function import_object
def test_import_object():
    import tornado.web  # noqa: F401
    import_object('tornado.web')


# Generated at 2022-06-26 08:54:34.393900
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    print("test_ArgReplacer_replace:")
    fun = lambda x: x
    arg_replacer_0 = ArgReplacer(fun, 'x')
    arg_replacer_0.replace(0, [1], {})


# Generated at 2022-06-26 08:54:40.513673
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():

    testObject = ArgReplacer(test_case_0, 'test_case_0')

    print('testObject.name = ', testObject.name)
    print('testObject.arg_pos = ', testObject.arg_pos)
    print('testObject.get_old_value = ', testObject.get_old_value)
    print('testObject.replace = ', testObject.replace)



# Generated at 2022-06-26 08:54:41.978900
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    obj = ArgReplacer(test_case_0, 'object_dict_0')
    obj.get_old_value(locals(), locals())


# Generated at 2022-06-26 08:54:46.029017
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # test class
    class TestConfigurable(Configurable):
        def configurable_base(cls):
            return cls

        def configurable_default(cls):
            return cls
    test_configurable_0 = TestConfigurable()
    test_configurable_0.initialize()


# Generated at 2022-06-26 08:54:50.087824
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    object_dict_0 = ObjectDict()
    try:
        object_dict_0.__getattr__('x')
        raise ValueError
    except AttributeError:
        pass

# Generated at 2022-06-26 08:55:03.254209
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    from functools import partial
    from types import FunctionType

    def get_arg_replacer(func, args, kwargs) -> ArgReplacer:
        if not isinstance(func, (partial, FunctionType)):
            raise TypeError("function is not callable")
        get_full_argspec = getattr(inspect, "getfullargspec", None)
        argspec = get_full_argspec(func.func) if get_full_argspec else inspect.getargspec(
            func.func)
        # if isinstance(func, partial):
        new_args = func.args + args
        new_kwargs = {**func.keywords, **kwargs}
        # else:
        # new_args = args
        # new_kwargs = kwargs
        # for i, arg in enumerate(

# Generated at 2022-06-26 08:55:12.253694
# Unit test for function import_object
def test_import_object():
    package_0 = "tornado"
    module_1 = "escape"
    module_2 = "utf8"
    module_3 = "missing_module"

    package_0_import_0 = import_object(package_0)
    module_1_import_0 = import_object(module_1)
    module_2_import_0 = import_object(module_2)
    module_3_import_0 = import_object(module_3)


# Generated at 2022-06-26 08:55:14.978141
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer_0 = ArgReplacer(func=test_case_0, name="object_dict_0")
    print(arg_replacer_0.get_old_value(args=[object_dict_0,], kwargs={}, default=None))


# Generated at 2022-06-26 08:55:39.118149
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base_0 = typing.cast(Type[Configurable], Configurable)
    cls_0 = typing.cast(Type[Configurable], Configurable)
    impl_0 = Configurable.configured_class()
    init_kwargs_0 = {}  # type: Dict[str, Any]
    if cls_0 is base_0:
        impl_0 = cls_0.configured_class()
        if base_0.__impl_kwargs:
            init_kwargs_0.update(base_0.__impl_kwargs)
    else:
        impl_0 = cls_0
    init_kwargs_0.update(init_kwargs_0)
    instance_0 = super(Configurable, cls_0).__new__(impl_0)
    # initialize vs __init__ chosen for

# Generated at 2022-06-26 08:55:52.494541
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # initialize vs __init__ chosen for compatibility with AsyncHTTPClient
    # singleton magic.  If we get rid of that we can switch to __init__
    # here too.
    gzip_decompressor_0 = GzipDecompressor()

    # Assert that gzip_decompressor_0 is of class GzipDecompressor
    assert isinstance(gzip_decompressor_0, GzipDecompressor)


# Generated at 2022-06-26 08:55:56.937629
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl_class_0 = Configurable.configured_class()
    # If the class is a new-style class, and if the class or its base class
    # is configurable, then __new__() is the default implementation,
    # otherwise it is the same as object.__new__().
    assert impl_class_0 is not None


# Generated at 2022-06-26 08:56:01.796035
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    try:
        configurable_0.initialize()
    except NotImplementedError:
        pass
    except:
        assert False


# Generated at 2022-06-26 08:56:09.260755
# Unit test for function import_object
def test_import_object():
    # Tests for module import
    result = import_object('sys')
    assert result is sys
    result = import_object('sys.version')
    assert result == sys.version
    # Tests for class import
    ioloop_class_obj = import_object('tornado.ioloop.IOLoop')
    assert ioloop_class_obj is IOLoop
    # Tests for variable import
    ioloop_class_obj = import_object('tornado.ioloop.IOLoop')
    assert ioloop_class_obj is IOLoop



# Generated at 2022-06-26 08:56:15.490370
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # testing for function ArgReplacer.get_old_value
    name = "test_name"
    args = [0, 1, 2, 3]
    kwargs = {name: 0}
    default_val = 3
    test_ArgReplacer = ArgReplacer(test_case_0, name)
    assert test_ArgReplacer.get_old_value(args, kwargs, default_val) == default_val
    assert test_ArgReplacer.get_old_value(args, kwargs) == kwargs[name]
    assert test_ArgReplacer.get_old_value(args[1:], kwargs) == default_val


# Generated at 2022-06-26 08:56:26.638540
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Prepare for testing
    # The following method call is expected to pass
    gzip_decompressor_0 = GzipDecompressor()

    def test_callback(name):
        # Prepare for testing
        # The following method call is expected to pass
        return gzip_decompressor_0.get_old_value(name)

    # Executing test cases
    # Case: p0 : name = None
    # Expecting: (default=None)
    test_callback(None)



# Generated at 2022-06-26 08:56:29.166799
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    assert configurable_0._initialize() is None

# Generated at 2022-06-26 08:56:35.024886
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class_0 = Configurable()
    print(type(class_0))
    class_1 = Configurable()
    print(type(class_1))
    print('unit test for Configurable.__new__() passed')


# Generated at 2022-06-26 08:56:38.498976
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    s = Configurable()
    s.initialize()

if __name__ == '__main__':
    print("Test Tornado Lib")
    test_case_0()
    test_Configurable_initialize()

# Generated at 2022-06-26 08:56:48.801858
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # ObjectDict is a subclass of Configurable
    obj_dict_0 = ObjectDict()


# Generated at 2022-06-26 08:56:53.936923
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create object of type Configurale
    object_0 = Configurable()


if __name__ == '__main__':
    test_case_0()
    test_Configurable___new__()

# Generated at 2022-06-26 08:56:55.399775
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # test for method initialize of class Configurable
    pass

# Generated at 2022-06-26 08:56:59.690445
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    if not (isinstance(Configurable(), Configurable)):
        raise AssertionError("Assertion failed at line number " + str(inspect.stack()[0][2]))


# Generated at 2022-06-26 08:57:07.556528
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = Configurable()  # type: Configurable
    impl = Configurable()  # type: Union[str, Type[Configurable]]
    init_kwargs = {}  # type: Dict[str, Any]
    instance = Configurable.__new__(Configurable, *args, **kwargs)


# Generated at 2022-06-26 08:57:10.642063
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        exc_info_0 = () #type: Tuple[Optional[type], BaseException, TracebackType]
        raise_exc_info_0 = raise_exc_info(exc_info_0)
    except NotImplementedError:
        pass


# Generated at 2022-06-26 08:57:18.734077
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func = get_object_as_string
    arg_replacer_0 = ArgReplacer(func, "obj")
    str_0 = "string"
    str_1 = str(arg_replacer_0.get_old_value((str_0,), {}, "default_val"))
    assert str_1 == "'string'"


# Generated at 2022-06-26 08:57:28.350346
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test case 1
    class _ConfigurableTest1(Configurable):
        def configurable_base(self):
            return self
        def configurable_default(self):
            return None
    c = _ConfigurableTest1()
    # Test case 2
    test_Configurable___new___class_0 = Configurable
    test_Configurable___new___class_1 = Configurable
    test_Configurable___new___class_2 = Configurable
    test_Configurable___new___class_3 = Configurable
    class _ConfigurableTest2(Configurable):
        def configurable_base(self):
            return self
        def configurable_default(self):
            return test_Configurable___new___class_0

# Generated at 2022-06-26 08:57:42.090404
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Uncomment the following line to test code:
    Configurable.configure("tornado.escape")
    # Uncomment the following line to test code:
    Configurable.configure("tornado.escape")
    # Uncomment the following line to test code:
    Configurable.configure("tornado.escape")
    # Uncomment the following line to test code:
    Configurable.configure("tornado.escape")
    # Uncomment the following line to test code:
    Configurable.configure("tornado.escape")
    # Uncomment the following line to test code:
    Configurable.configure("tornado.escape")
    # Uncomment the following line to test code:
    Configurable.configure("tornado.escape")
    # Uncomment the following line to test code:
    Configurable.configure("tornado.escape")

# Generated at 2022-06-26 08:57:55.028426
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # This test is incomplete.
    configurable_0 = Configurable()
    configurable_1 = Configurable()
    configurable_2 = Configurable()
    configurable_3 = Configurable()
    configurable_4 = Configurable()
    configurable_5 = Configurable()
    configurable_6 = Configurable()
    configurable_7 = Configurable()

    # Unit test for method configurable_base of class Configurable
    def test_configurable_base():
        # No tests for this method
        pass
    # Unit test for method configurable_default of class Configurable
    def test_configurable_default():
        # No tests for this method
        pass
    # Unit test for method configure of class Configurable
    def test_configure():
        # No tests for this method
        pass
    # Unit test for method configured_

# Generated at 2022-06-26 08:58:18.310877
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import tornado.escape
    import_object('tornado.escape')
    import_object('tornado.escape.utf8')
    import_object('tornado')
    # import_object('tornado.missing_module')
    #
    # This function's type annotation must use comments instead of
    # real annotations because typing.NoReturn does not exist in
    # python 3.5's typing module. The formatting is funky because this
    # is apparently what flake8 wants.
    #
    try:
        pass
    except:
        pass
    # Clear the traceback reference from our stack frame to
    # minimize circular references that slow down GC.
    pass


# Generated at 2022-06-26 08:58:30.677666
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_case_1_configurable_base_0 = Configurable()
    test_case_1_configurable_default_0 = Configurable()
    test_case_1_args_0 = (1, 2, 3)
    test_case_1_kwargs_0 = {'a': 1, 'b': 2.2, 'c': 'three'}

    # Test normal case
    test_case_1_configurable_0 = Configurable()
    test_case_1_configurable_0.configure(test_case_1_configurable_default_0)
    test_case_1_configurable_0.initialize(*test_case_1_args_0, **test_case_1_kwargs_0)

    # Test exception case
    test_case_1_configurable_0 = None

#

# Generated at 2022-06-26 08:58:38.456831
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    test_fn = _get_example_function()
    test_args = ("a", "b", "c")
    test_kwargs = {"d": "d", "e": "e", "f": "f"}
    arg_replacer_0 = ArgReplacer(test_fn, "d")
    arg_replacer_0.get_old_value(test_args, test_kwargs)


# Generated at 2022-06-26 08:58:40.261888
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    a = MyClass()


# Generated at 2022-06-26 08:58:45.569731
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    def test_case_Configurable_initialize_0():
        configurable_0 = Configurable()
        configurable_0.initialize()
    test_case_Configurable_initialize_0()


# Generated at 2022-06-26 08:58:47.662654
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(Exception(5)) == 5


# Generated at 2022-06-26 08:58:50.189790
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = Configurable()
    assert isinstance(impl, Configurable)


# Generated at 2022-06-26 08:58:53.456479
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Init the object
    configurable_0 = Configurable()
    # Call the method to test
    configurable_0.initialize()


# Generated at 2022-06-26 08:58:54.925281
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_1 = Configurable()


# Generated at 2022-06-26 08:59:00.127900
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    print("Unit test for method get_old_value of class ArgReplacer")
    ArgReplacer_0_instance_0 = ArgReplacer(test_case_0, "gzip_decompressor")
    ArgReplacer_0_instance_0.get_old_value()


# Generated at 2022-06-26 08:59:41.338124
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    instance = Configurable()


# Generated at 2022-06-26 08:59:50.027825
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class cls_0(Configurable):
        def test_method(self):
            print(self)
        def initialize(self):
            print(self)

    cls_0().test_method()

if __name__ == "__main__":
    test_case_0()
    test_Configurable_initialize()

# Generated at 2022-06-26 08:59:57.190983
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    global gzip_decompressor_0
    gzip_decompressor_0 = GzipDecompressor()
    test_dict = {}
    try:
        val = gzip_decompressor_0.__getattr__("dummy")
    except Exception as caught:
        if caught.args[0] == "dummy":
            internal_check("OK", "", caught.args[0], "")
        else:
            internal_check("Caught unexpected exception", "", caught.args[0], "dummy")
    else:
        internal_check("Expected an AttributeError", "", "", "")


# Generated at 2022-06-26 09:00:01.077101
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # To check the correct execution of method initialize of class Configurable
    # test case 0
    test_case_0()

# Generated at 2022-06-26 09:00:02.986253
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class test_case_1(Configurable):
        pass


# Generated at 2022-06-26 09:00:15.830806
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def test_case_0():
        impl_value_0 = Configurable()
        base_value_0 = Configurable().configurable_base()
        args_value_1 = ()
        kwargs_value_1 = {"a": 1}
        class_value_1 = Configurable()
        class_value_1.__impl_class = impl_value_0
        class_value_1.__impl_kwargs = kwargs_value_1
        __impl_class_value_1 = class_value_1
        __impl_kwargs_value_1 = kwargs_value_1
        if class_value_1 is base_value_0:
            impl = class_value_1.configured_class()

# Generated at 2022-06-26 09:00:19.224986
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0_0 = Configurable.configure(impl=None, **{})
    assert configurable_0_0 is not None


# Generated at 2022-06-26 09:00:26.394875
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(0)
    except Exception as e:
        assert errno_from_exception(e) == 0
    try:
        raise Exception(0, 0)
    except Exception as e:
        assert errno_from_exception(e) == 0



# Generated at 2022-06-26 09:00:37.133982
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class test_case_Configurable___new___Configurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return test_case_Configurable___new___Configurable
        @classmethod
        def configurable_default(cls):
            return test_case_Configurable___new___Configurable
        def initialize(self):
            pass
    test_case_Configurable___new___Configurable.configure(test_case_Configurable___new___Configurable)
    test_case_Configurable___new___Configurable()


# Generated at 2022-06-26 09:00:38.889709
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:01:59.561753
# Unit test for function errno_from_exception
def test_errno_from_exception():
    e = IOError()
    res = errno_from_exception(e)
    assert res == None

    e.errno = 1
    res = errno_from_exception(e)
    assert res == 1

    #if __name__ == "__main__":
    #    test_case_0()
    #    test_errno_from_exception()
# Command line arguments for pytest

# If called like `python x.py`, invoke the pytest runner
if __name__ == "__main__":
    import os
    import pytest

    # This runs all the tests associated with the file(s) named
    cur_file = os.path.abspath(__file__)
    pytest.main([cur_file, "-v", "-rw"])

# Generated at 2022-06-26 09:02:01.425742
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    assert False



# Generated at 2022-06-26 09:02:04.421723
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict({"a":1, "b":2})
    assert o.a == 1
    assert o.b == 2


# Generated at 2022-06-26 09:02:06.533820
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o['b'] = 1
    o['b'] # type: ignore


# Generated at 2022-06-26 09:02:09.833298
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    gzip_decompressor_1 = GzipDecompressor()
    pass


# Generated at 2022-06-26 09:02:18.094167
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def test(impl, **kwargs):
        # type: (Union[None, str, Type[Configurable]], Any) -> None
        Configurable.configure(impl, **kwargs)
        instance = Configurable()
        assert instance.__class__ is impl
        assert len(kwargs) == 0

    test(Configurable)
    test(Configurable, a=1, b=2)


# Generated at 2022-06-26 09:02:24.406810
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Initialize global variables
    # Call function
    time_obj = time.time()

    #assert(time_obj == 1533281271.069908)
    #assert(time_obj == 1533281271.069908)
    #assert(time_obj == 1533281271.069908)


# Generated at 2022-06-26 09:02:30.767793
# Unit test for function import_object
def test_import_object():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()


# Generated at 2022-06-26 09:02:33.489127
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = Configurable
    if isinstance(impl, str):
        impl = import_object(impl)
    instance = Configurable.__new__(impl)


# Generated at 2022-06-26 09:02:35.118488
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print('do it yourself')


# Generated at 2022-06-26 09:03:45.013229
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print(Configurable.__new__(Configurable))
