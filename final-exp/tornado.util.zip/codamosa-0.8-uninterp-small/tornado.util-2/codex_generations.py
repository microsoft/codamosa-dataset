

# Generated at 2022-06-26 08:54:10.029019
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # declare variables
    arg1 = None
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
    arg7 = None
    arg8 = None
    arg9 = None

    # Setup
    arg3 = "test_Configurable___new__"
    arg4 = {"1": "one", "2": "two"}
    arg5 = "contents"
    arg6 = 5
    arg7 = True
    arg9 = False
    arg8 = {True, False}

    # Test
    try:
        rtn = Configurable.__new__(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)

    # Verify
    except:
        pass


# Generated at 2022-06-26 08:54:16.445311
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():

    def func(a, b=0):
        pass

    replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = replacer.replace(1, (1,), {})

    assert old_value == 0
    assert args == (1,)
    assert kwargs == {}


# Generated at 2022-06-26 08:54:28.666671
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    arg_name = "foo"

    # Test with *args
    def foo(*args):
        pass

    arg_replacer_0 = ArgReplacer(foo, arg_name)

    expected_old_value = 1
    expected_new_value = 2
    old_value, actual_args, actual_kwargs = arg_replacer_0.replace(expected_new_value, [expected_old_value], {})

    assert len(actual_args) == 1
    assert actual_args[0] == expected_new_value
    assert actual_kwargs == {}
    assert old_value == expected_old_value

    # Test with **kwargs
    def foo(**kwargs):
        pass

    arg_replacer_0 = ArgReplacer(foo, arg_name)

    expected_old_value = 1
    expected

# Generated at 2022-06-26 08:54:34.889379
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    expected_values = [
("foo", "bar")
,("foo", "bar")
,("foo", "bar")
,("foo", "bar")
,("foo", "bar")
,("bar", "foo")
,("foo", "bar")
,("foo", "bar")
,("foo", "bar")
,("foo", "bar")
,("foo", "bar")
,("foo", "bar")
,("foo", "bar")
]

    def f_0(foo, bar):
        return foo,bar

    def f_1(foo, bar):
        return foo,bar

    def f_2(foo, bar):
        return foo,bar

    def f_3(foo, bar):
        return foo,bar

    def f_4(foo, bar):
        return foo,bar


# Generated at 2022-06-26 08:54:38.693444
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl_class_0 = Configurable.configured_class()
    impl_class_0
    impl_kwargs_0 = Configurable.__impl_kwargs
    impl_kwargs_0
    cls_0 = 5
    impl_0 = 5
    impl_0
    kwargs_0 = {1: 5}
    kwargs_0
    base_0 = Configurable
    base_0
    init_kwargs_0 = {}
    init_kwargs_0.update(kwargs_0)
    instance_0 = super(Configurable, cls_0).__new__(impl_0)
    instance_0.initialize()


# Generated at 2022-06-26 08:54:45.085997
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    old_value = ArgReplacer(gzip_decompressor_0.read_from_stream, "stream").get_old_value((gzip_decompressor_0,), {}, None)
    assert old_value == gzip_decompressor_0


# Generated at 2022-06-26 08:54:46.740992
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    business_logic_0 = Configurable()
    business_logic_0._initialize()


# Generated at 2022-06-26 08:54:51.323030
# Unit test for function import_object
def test_import_object():
    test_case_0()

# Constant from module object
# This constant is used in type comments.
# The value is not used.
# It is also declared in module __main__ in order to allow unit tests.
# It is declared redundantly in order to specify type.
MockType = Type


# Generated at 2022-06-26 08:54:53.362683
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Initialize an instance of the Configurable class
    configurable_0 = Configurable()
    # Call the initialize method of the instance
    configurable_0.initialize()
    # Call the initialize method of the class
    Configurable.initialize()


# Generated at 2022-06-26 08:55:04.161488
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Foo(object):
        def __init__(self, a: int, b: int, c: str) -> None:
            pass

    args_0 = (1, 2, 3)
    kwargs_0 = {'c': 'c'}
    arg_replacer_0 = ArgReplacer(Foo, 'c')

    replace_0 = arg_replacer_0.replace('new_value', args_0, kwargs_0)
    assert replace_0[0] == kwargs_0['c']
    assert replace_0[1][2] == 3
    assert replace_0[2]['c'] == 'new_value'

# Generated at 2022-06-26 08:55:11.671875
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(TypeError()) == None
    assert errno_from_exception(OSError(9, "foo")) == 9



# Generated at 2022-06-26 08:55:16.423254
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    a = 1
    b = 2
    cc = Configurable()
    cc.configure()
    cc = Configurable()
    cc.configure(impl='impl')


# Generated at 2022-06-26 08:55:18.828170
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Oneway functions do not return any value
    pass


# Generated at 2022-06-26 08:55:24.308853
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    test_case_0()
    # assert(import_object('tornado.escape') is tornado.escape)
    # assert(import_object('tornado.escape.utf8') is tornado.escape.utf8)
    # assert(import_object('tornado') is tornado)
    # assert(import_object('tornado.missing_module'))


# Generated at 2022-06-26 08:55:28.105320
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    Configurable.configure(None, a=4)
    instance_0 = Configurable()
    assert(isinstance(instance_0, Configurable))


# Generated at 2022-06-26 08:55:35.219577
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a: str, b: int) -> int:
        return a, b

    arg_replacer_0 = ArgReplacer(test_func, 'a')
    assert arg_replacer_0.get_old_value('a', None, None) == 'a'
    print('Test get_old_value passed !')


# Generated at 2022-06-26 08:55:40.764301
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(self, a, b=0):
        pass

    # Verify the constructor raises a ValueError
    # when the given argument name is not found
    # in the argument list
    with pytest.raises(ValueError):
        ArgReplacer(func, 'c')



# Generated at 2022-06-26 08:55:44.320575
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = lambda x, y=None, z=None: []
    arg_replacer_0 = ArgReplacer(func, 'y')
    arg_replacer_0.replace("newvalue", [], {})


# Generated at 2022-06-26 08:55:47.788415
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable = Configurable()
    configurable.initialize()

T = TypeVar("T")
V = TypeVar("V")


# Generated at 2022-06-26 08:55:55.657009
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Custom __new__ in Configurable()
    configurable_1 = Configurable()
    configurable_2 = Configurable()
    configurable_3 = Configurable()
    configurable_4 = Configurable()
    configurable_5 = Configurable()
    configurable_6 = Configurable()
    configurable_7 = Configurable()
    configurable_8 = Configurable()
    configurable_9 = Configurable()


# Generated at 2022-06-26 08:56:17.135131
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    print("\033[1;32m" + "Running Unit test: test_Configurable_initialize" + "\033[0;0m")
    import_object_0 = import_object("tornado.util")
    _initialize_0 = import_object_0._initialize
    import_object_1 = import_object("tornado.util")
    initialize_0 = import_object_1.initialize
    if _initialize_0 != initialize_0:
        raise ValueError(
            "TEST FAILED: Expected _initialize to be equal to initialize. Got: "
            + _initialize_0
            + " VS "
            + initialize_0
        )


# Generated at 2022-06-26 08:56:25.412545
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    x = Configurable.configure('x.x', x=1)
    if isinstance(x, Configurable):
        assert x.initialize(x=1) == None
    # Run unit test for method _initialize of class Configurable
    if hasattr(x, "_initialize"):
        assert x._initialize() == None


# Generated at 2022-06-26 08:56:27.310707
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print("Running test test_Configurable___new__()")
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:56:34.321869
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = {'value': None}
    impl['value'] = Configurable.configured_class()
    # TODO: Use assert statement to test the result
    
if __name__ == '__main__':
    test_case_0()
    test_Configurable___new__()

# Generated at 2022-06-26 08:56:35.801228
# Unit test for function import_object
def test_import_object():
    import_object("import_object")


# Generated at 2022-06-26 08:56:39.193287
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Testing variables
    args_0 = (1,)
    kwargs_0 = {'a': 1}
    # Call the function
    Configurable.initialize(args_0, kwargs_0)


# Generated at 2022-06-26 08:56:40.488905
# Unit test for function import_object
def test_import_object():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 08:56:52.119542
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Dummy_Configurable_0(Configurable):
        @classmethod
        def configurable_base(cls):
            return Dummy_Configurable_0
        @classmethod
        def configurable_default(cls):
            return Dummy_Configurable_0
    dummy_configurable_0 = Dummy_Configurable_0()
    dummy_configurable_0.initialize()

if __name__ == '__main__':
    import atexit
    import sys
    import time
    def exit():
        print("time: %6.3f sec." % (time.time() - start_time))
        print("%s: %d tests OK." % (sys.argv[0], passed,))
    atexit.register(exit)
    print("%s: running... " % sys.argv[0])

# Generated at 2022-06-26 08:56:58.732937
# Unit test for function import_object
def test_import_object():
    import importlib
    escape_0 = import_object('tornado.escape')
    escape_1 = importlib.import_module('tornado.escape')
    assert escape_0 is escape_1
    utf8_0 = import_object('tornado.escape.utf8')
    utf8_1 = importlib.import_module('tornado.escape').utf8
    assert utf8_0 is utf8_1
    tornado_0 = import_object('tornado')
    tornado_1 = importlib.import_module('tornado')
    assert tornado_0 is tornado_1
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass


# Generated at 2022-06-26 08:57:02.028990
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def _test_Configurable___new__(self, *args, **kwargs):
        pass

    cls = Configurable()
    cls.__new__ = _test_Configurable___new__


# Generated at 2022-06-26 08:57:15.409164
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize(1)


# Generated at 2022-06-26 08:57:19.985758
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """
    test_Configurable___new__
    """
    obj = Configurable()
    assert isinstance(obj, Configurable)
    


# Generated at 2022-06-26 08:57:20.978661
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    assert Configurable.__new__(Configurable)


# Generated at 2022-06-26 08:57:25.888629
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestableConfigurable(Configurable):
        def __new__(cls, *args, **kwargs):
            self = super().__new__(cls)
            return self

    impl_class = TestableConfigurable.configured_class()
    assert impl_class == TestableConfigurable

    impl_class = TestableConfigurable.configurable_base()
    assert impl_class == TestableConfigurable

# Generated at 2022-06-26 08:57:27.415025
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:57:32.326746
# Unit test for function import_object
def test_import_object():
    tornado_0 = import_object("tornado")
    tornado_1 = import_object("tornado.escape")
    tornado_2 = import_object("tornado.escape.utf8")
    tornado_3 = import_object("tornado.missing_module")

test_case_0()
test_import_object()

# Generated at 2022-06-26 08:57:34.066220
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:57:39.923277
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Creating an object instance of Configurable
    obj_0 = Configurable()

    # Call method initialize of class Configurable
    # with arguments (obj_0)
    Configurable.initialize(obj_0)


# Generated at 2022-06-26 08:57:41.166451
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    obj = Configurable()
    obj.initialize(*[])


# Generated at 2022-06-26 08:57:44.903199
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # ObjectDict___getattr__
    my_object_dict = ObjectDict({'a':1})
    assert my_object_dict.has_key('a') == True
    try:
        my_object_dict.a
        assert False
    except AttributeError as e:
        pass
    except Exception as e:
        assert False



# Generated at 2022-06-26 08:57:58.055515
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    iol_loop_0 = ioloop.IOLoop()
    # Test the behavior of the method __new__ of the Configurable class
    # The tested method __new__ is defined in the Configurable class
    iol_loop_0 = ioloop.IOLoop()
    # Test the behavior of the method _initialize of the Configurable class
    # The tested method _initialize is defined in the Configurable class
    iol_loop_0 = ioloop.IOLoop()


# Generated at 2022-06-26 08:57:59.657517
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test the case with 0 arguments
    Configurable_instance_0 = Configurable()
    # Test the case with 1 arguments
    Configurable_instance_1 = Configurable("impl")


# Generated at 2022-06-26 08:58:09.775257
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    global_conf_0 = Configurable.configure('tornado.httpclient._AnyThreadHTTPConnection')
    global_conf_1 = Configurable.configure(None)
    global_conf_2 = Configurable.configure(None)
    global_conf_3 = Configurable.configure('tornado.httpclient._AnyThreadHTTPConnection')
    global_conf_4 = Configurable.configure(None)
    global_conf_5 = Configurable.configure(impl=None)
    global_conf_6 = Configurable.configure(impl=None)
    global_conf_7 = Configurable.configure('tornado.options._LogFormatter', datefmt='%Y-%m-%d %H:%M:%S')
    global_conf_8 = Configurable.configure(impl=None)
    global_

# Generated at 2022-06-26 08:58:12.491100
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print('test_Configurable___new__()')
    print('TODO')


# Generated at 2022-06-26 08:58:15.263298
# Unit test for function import_object
def test_import_object():
    for i in range(1000):
        test_case_0()
        result_0 = import_object(None)
        result_1 = import_object("")

test_import_object()


# Generated at 2022-06-26 08:58:21.938505
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    var1 = ObjectDict()
    var1[0] = 0
    var1[1] = 1
    var1[2] = 2

    var1.test_1
    var1.test_2
    var1.test_3


# Generated at 2022-06-26 08:58:30.285732
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    #private function should be executed
    test_case_0()
    # input value
    test_Configurable_initialize_instance = Configurable()
    Configurable.configure(Configurable)
    Configurable.configure(Configurable)
    Configurable.configure(Configurable)
    Configurable.configure(Configurable)
    # expect value
    expected = None
    # actual value
    actual = test_Configurable_initialize_instance.initialize()
    # compare
    assert actual == expected, "actual: {}, expected: {}".format(actual, expected)

# Generated at 2022-06-26 08:58:31.827006
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # TODO
    pass

# Generated at 2022-06-26 08:58:42.074620
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    print('Testing Configurable.initialize')

    import _locale
    import socket
    import select
    import logging
    import select
    import socket
    import ssl
    import _socket
    import ssl
    import select
    import socket
    import ssl
    import time
    import logging
    import time
    import logging
    import socket
    import time
    import logging
    import ssl
    import _ssl
    import socket
    import time
    import logging
    import socket
    import ssl
    import os
    import socket
    import ssl
    import os
    import socket
    import ssl
    import array
    import socket
    import ssl
    import os
    import socket
    import ssl
    import os
    import socket
    import ssl
    import os
    import socket

# Generated at 2022-06-26 08:58:52.240230
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Define a concrete subclass to use
    class MyClass(Configurable):
        def configurable_base(self):
            return MyClass

        def configurable_default(self):
            return SubClass

        def _initialize(self):
            pass

        initialize = _initialize

    # Define a subclass that MyClass can be configured to use
    class SubClass(MyClass):
        pass

    # Try it out
    MyClass.configure(None)
    assert issubclass(MyClass.configured_class(), SubClass)
    assert isinstance(MyClass(), SubClass)
    old_config = MyClass._save_configuration()
    MyClass.configure(SubClass)
    assert MyClass.configured_class() is SubClass
    assert isinstance(MyClass(), SubClass)
    MyClass._restore_

# Generated at 2022-06-26 08:59:15.176139
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def test_impl(  # type: ignore
        __imp_class = None,  # type: Optional[Type[Configurable]]
        __imp_kwargs = None,  # type: Optional[Dict[str, Any]]
        args = (),  # type: Tuple[Any, ...]
        kwargs = {},  # type: Dict[str, Any]
    ):
        # type: (...) -> Configurable
        return Configurable.__new__(Configurable, __imp_class, __imp_kwargs, *args, **kwargs)

    try:
        test_impl()
    except NotImplementedError:
        pass
    else:
        assert False, "Did not raise NotImplementedError"


# Generated at 2022-06-26 08:59:17.174690
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:59:23.162104
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    a = Configurable()
    # Uncomment if any of the instance methods use __new__.
    # b = a._Configurable__new__()
    # assert isinstance(b, Configurable)
    # assert a is b
    # assert b.__impl_class == None
    # assert b.__impl_kwargs == None


# Generated at 2022-06-26 08:59:31.612564
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test case definition
    class DummyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return DummyConfigurable

        @classmethod
        def configurable_default(cls):
            return DummyConfigurable

        def initialize(self, *args, **kwargs):
            pass

    dummy_configurable_0 = DummyConfigurable()


# Generated at 2022-06-26 08:59:32.953335
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    gzip_decompressor_0 = GzipDecompressor()


# Generated at 2022-06-26 08:59:37.195929
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from topi.util.tvm import tvm_compile_from_file

    def __init__(self):
        pass

    Configurable.initialize = __init__


# Generated at 2022-06-26 08:59:43.393660
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    gzip_decompressor_0 = GzipDecompressor()
    # test for type Configurable
    assert isinstance(gzip_decompressor_0, Configurable)
    # test for class GzipDecompressor
    assert isinstance(gzip_decompressor_0, GzipDecompressor)


# Generated at 2022-06-26 08:59:46.822150
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        (cls_0, kwargs_0) = Configurable._save_configuration()
        Configurable.configure(None, **{})
        Configurable.initialize()
        Configurable._restore_configuration((cls_0, kwargs_0))
    except (AttributeError, TypeError) as e:
        print(e)
        raise e


# Generated at 2022-06-26 08:59:53.913478
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    dict_0 = ObjectDict({'0': '', '1': '1'})
    str_1 = dict_0.update()
    str_2 = dict_0.get('0')
    str_3 = dict_0.get('1')
    str_4 = str_1
    str_5 = str_2
    str_6 = str_3


# Generated at 2022-06-26 08:59:55.927385
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_0.configure('test')
    configurable_0.configured_class()


# Generated at 2022-06-26 09:00:25.606805
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0._initialize()
    configurable_0.initialize()


# Generated at 2022-06-26 09:00:38.485895
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # The 1st round of configuration
    Configurable.configure(impl = "tornado.iostream.IOStream", backend = "libuv")
    assert Configurable.configured_class.__name__ == "IOStream"
    configurable_0 = Configurable()
    configurable_0.initialize()

    # The 2nd round of configuration
    configuration_1 = Configurable._save_configuration()
    Configurable.configure(impl = "tornado.httpserver.HTTPServer", xheaders = True)
    assert Configurable.configured_class.__name__ == "HTTPServer"
    configurable_1 = Configurable()
    configurable_1.initialize()

    # The 3rd round of configuration
    configuration_2 = Configurable._save_configuration()

# Generated at 2022-06-26 09:00:39.394809
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass

# Generated at 2022-06-26 09:00:44.819620
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    gzip_decompressor_0 = GzipDecompressor()
    impl = Configurable()
    impl.configure(impl)
    f = Configurable.configurable_base()
    impl = f()

# Generated at 2022-06-26 09:00:49.097516
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj_dict_0 = ObjectDict()
    result_0 = obj_dict_0.__getattr__(str())
    assert result_0 == None
    result_1 = obj_dict_0.__getattr__(str())
    assert result_1 == None


# Generated at 2022-06-26 09:01:00.993005
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Define a global variable instead of creating a class attribute
    # in order to be able to delete it (since the class attribute will
    # still exist in the base class)
    global impl
    global impl_kwargs

    # Reset configuration
    Configurable.configure(None)
    impl = None
    impl_kwargs = {}

    # Ensure we test the base class
    assert Configurable.configured_class() == Configurable.configurable_default()

    # Test initializing a subclass of Configurable
    class BaseClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return BaseClass

        @classmethod
        def configurable_default(cls):
            return BaseClass

        def initialize(self, *args, **kwargs):
            pass


# Generated at 2022-06-26 09:01:02.538371
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-26 09:01:11.913985
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print("Testing __new__ of class Configurable")
    local_init_kwargs = {}
    local_impl = Configurable
    local_impl.configured_class()
    local_impl.configured_class()
    local_init_kwargs[1] = 2
    local_init_kwargs[2] = 3
    local_init_kwargs["a"] = "b"
    local_init_kwargs["b"] = "c"
    Configurable.configure(None, **local_init_kwargs)
    instance = Configurable()
    assert issubclass(instance.__class__, local_impl)

# Generated at 2022-06-26 09:01:13.304010
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    s = Configurable()


# Generated at 2022-06-26 09:01:18.521681
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_1 = Configurable()
    configurable_1.configure(configurable_0)
    configurable_1.configured_class()


# Generated at 2022-06-26 09:02:30.433060
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o.x = 10
    o.z = 20
    o.y = 20
    o.a = 30
    # The following line of code was generated to test if the method
    # __getattr__ of class ObjectDict returns the expected result.
    # self.assertEqual(o.z, 20, 'Method ObjectDict.__getattr__ did not return the expected result.')



# Generated at 2022-06-26 09:02:35.705522
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test parameters that can be passed in constructor

    # Test for when impl is None
    #  Test for when impl is str
    # Test for when impl is not a subclass of Configurable
    # Test for other cases

    # Test for when some keyword arguments are passed in
    # Test for when all keyword arguments are passed in
    pass


# Generated at 2022-06-26 09:02:36.965842
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    d1 = Configurable()


# Generated at 2022-06-26 09:02:37.794320
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()

# Generated at 2022-06-26 09:02:42.214592
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        raise ValueError("Invalid subclass of %s")
    except ValueError as exc:
        pass
    finally:
        pass


# Generated at 2022-06-26 09:02:46.368472
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_1 = Configurable()



# Generated at 2022-06-26 09:02:47.742708
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    assert False


# Generated at 2022-06-26 09:02:51.073573
# Unit test for function import_object
def test_import_object():
    try:
        import_object("tornado.escape.utf8")
    except ImportError as e:
        print("the imported object failed")



# Generated at 2022-06-26 09:02:53.402764
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test case for class Configurable
    test_case_0()

if __name__ == "__main__":
    test_Configurable___new__()

# Generated at 2022-06-26 09:02:55.208399
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()
