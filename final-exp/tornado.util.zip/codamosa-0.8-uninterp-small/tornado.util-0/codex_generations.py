

# Generated at 2022-06-26 08:54:03.681267
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-26 08:54:06.375264
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func = ArgReplacer(func, name)
    assert func.get_old_value(value) == expected_value_0


# Generated at 2022-06-26 08:54:18.871085
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_ArgReplacer_replace_0():
        def test_ArgReplacer_replace_0_0():
            class test_ArgReplacer_replace_0_0_test_class(object):
                var_1 = object()
                var_0 = object()
                def func_0(self, arg_1, arg_2, arg_3):
                    replacer = ArgReplacer(
                        func_0, "arg_3"
                    )
                    old_value, args, kwargs = replacer.replace(999, args, kwargs)
                    assert old_value is self.var_0
                    assert args[0] is self.var_1
                    assert args[1] is self.var_2
                    assert args[2] == 999
                    assert len(args) == 3
                    assert kwargs == {}
               

# Generated at 2022-06-26 08:54:20.172900
# Unit test for function import_object
def test_import_object():
    test_case_0()



# Generated at 2022-06-26 08:54:24.776869
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    test_0 = ArgReplacer()

    # Instantiate an ArgReplacer, with a function and a name
    # Call the get_old_value method of the created object
    # Check that the return value is None

    assert(test_0.get_old_value() == None)


# Generated at 2022-06-26 08:54:28.688821
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Type test 1
    var_0 = errno_from_exception(RuntimeError(2))
    assert isinstance(var_0, int)
    # Type test 2
    var_1 = errno_from_exception(RuntimeError())
    assert var_1 is None


# Generated at 2022-06-26 08:54:32.016177
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    def function_0(arg_0, arg_1, kwarg_0=None, kwarg_1=None):
        """
        Docstring stub.
        """
        # body of function_0
        pass

    # Stub constructor
    var_0 = ArgReplacer(function_0, 'arg_0')

    # Stub destructor
    del var_0


# Generated at 2022-06-26 08:54:38.205087
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def func(self, *args, **kwargs):
        return self.__new__(self, *args, **kwargs)
    def func2():
        return object.__new__
    assert func(Configurable) is object.__new__(Configurable)
    assert func2() is object.__new__


# Generated at 2022-06-26 08:54:46.345981
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    ret_val = True
    obj = ObjectDict()
    obj['a'] = 1
    obj['b'] = 2

    ret_val &= obj.a == 1
    ret_val &= obj.b == 2
    ret_val &= obj.c == ObjectDict.__getattr__(obj, 'c')

    return ret_val


# Generated at 2022-06-26 08:54:49.855103
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    s = ArgReplacer(test_case_0, "string")
    with pytest.raises(NameError):
        s.replace("Hello", [1,2,3], {"var_0" : "string"})


# Generated at 2022-06-26 08:55:16.757322
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Test with Exception object that has a 'errno' attribute
    class TestException(Exception):
        def __init__(self):
            self.errno = 1
    assert errno_from_exception(TestException()) == 1

    # Test with Exception object that has a 'errno' attribute
    class TestException2(Exception):
        def __init__(self):
            self.args = (1,)
    assert errno_from_exception(TestException2()) == 1

    # Test with Exception object that doesn't have a 'errno' attribute
    # and no args
    class TestException3(Exception):
        pass
    assert errno_from_exception(TestException3()) is None


if typing.TYPE_CHECKING:
    _TestCaseType = Type[unittest.TestCase]  # This can't be more

# Generated at 2022-06-26 08:55:18.572703
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    #TODO
    pass


# Generated at 2022-06-26 08:55:26.946008
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func = test_case_0
    name = 'value'

# Generated at 2022-06-26 08:55:38.073269
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test_func(tt1_0: object = object(), tt2_0: object = object(), tt3_0: object = object()) -> Any:
        pass
    test_arg_replacer_0 = ArgReplacer(func=test_func, name="tt2")
    # First, test the get_old_value method
    test_arg_replacer_0.get_old_value((ArgReplacer(func=test_func, name="tt2"), object(), object()), {"tt3": object()})

# def test_case_1():
#     test_case_0()
#     test_ArgReplacer()

if __name__ == "__main__":
    test_case_0()
    test_ArgReplacer()

# Generated at 2022-06-26 08:55:42.988520
# Unit test for function import_object
def test_import_object():
    from tornado.log import gen_log
    gen_log.info("type of import_object : %s ", type(import_object))
    gen_log.info("dir of import_object : %s ", dir(import_object))



# Generated at 2022-06-26 08:55:54.181330
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    gzip_decompressor_0 = GzipDecompressor()
    arg_replacer_0 = ArgReplacer(gzip_decompressor_0.stream_decompress, 'new_data')
    result = arg_replacer_0.get_old_value((gzip_decompressor_0,), None, None)
    if result is None:
        raise Exception("ArgReplacer.get_old_value doesn't work.")
    print("Test for method get_old_value of class ArgReplacer passed.")


# Generated at 2022-06-26 08:55:59.672612
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado


# Generated at 2022-06-26 08:56:05.307964
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    try:
        ArgReplacer(test_case_0, 'name')
    except TypeError as e:
        assert True
        return
    except Exception as e:
        assert False, "unexpected error: " + str(e)
    assert False, "unexpected success"


# Generated at 2022-06-26 08:56:07.588971
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    type_0 = Configurable()
    type_0.initialize()


# Generated at 2022-06-26 08:56:11.167179
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Create test instance
    test = ArgReplacer(lambda x: x, 'x')
    new_new_value = None
    new_x = None
    new_y = None
    (new_value, new_args, new_kwargs) = test.replace(new_new_value, (new_x,), {'y': new_y})


# Generated at 2022-06-26 08:56:30.446440
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test(a: int, b: int, c: int) -> Tuple[int, int, int]:
        return a, b, c
    arg_replacer = ArgReplacer(test, "a")
    arg_replacer.get_old_value((1, 2, 3), {})
    arg_replacer.get_old_value((1, 2, 3), {}, default=1)
    arg_replacer.replace("new_value", (1, 2, 3), {})
    arg_replacer = ArgReplacer(test, "b")
    arg_replacer.get_old_value((1, 2, 3), {})
    arg_replacer.get_old_value((1, 2, 3), {}, default=1)

# Generated at 2022-06-26 08:56:31.975793
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()


# Generated at 2022-06-26 08:56:41.918434
# Unit test for function errno_from_exception
def test_errno_from_exception():
    import errno
    try:
        errno_from_exception(IOError())
    except TypeError:
        pass
    else:
        raise Exception("test errno_from_exception: Failed")
    try:
        errno_from_exception(IOError("12"))
    except TypeError:
        pass
    else:
        raise Exception("test errno_from_exception: Failed")
    try:
        errno_from_exception(IOError("12", "34"))
    except TypeError:
        pass
    else:
        raise Exception("test errno_from_exception: Failed")
    try:
        errno_from_exception(IOError("test", "34"))
    except TypeError:
        pass

# Generated at 2022-06-26 08:56:51.065444
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def my_function(foo, bar, baz):
        return foo
    arg_replacer_0 = ArgReplacer(my_function, 'foo')
    assert arg_replacer_0.get_old_value((), {}, 0), 0
    assert arg_replacer_0.get_old_value((1,), {}, 0), 1
    assert arg_replacer_0.get_old_value((1,), {'foo': 2}, 0), 2
    assert arg_replacer_0.get_old_value((1,), {'foo': 2}, 3), 2


# Generated at 2022-06-26 08:56:55.697627
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # initialize test
    configurer_0 = Configurable()
    configurer_0.configure("configure_test")
    

test_case_0()
test_Configurable_initialize()

# Generated at 2022-06-26 08:57:01.814602
# Unit test for function import_object
def test_import_object():
    tornado_escape = import_object('tornado.escape')
    assert tornado_escape is tornado.escape
    import_object('tornado.escape.utf8') is tornado.escape.utf8
    import_object('tornado.escape') is tornado.escape
    import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False



# Generated at 2022-06-26 08:57:08.267001
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Initialization
    # Configurable class has been tested in test_case_0
    gzip_decompressor_0 = GzipDecompressor()
    # Configurable object instantiation

    configurable_0 = Configurable()


# Generated at 2022-06-26 08:57:15.930795
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def example_function(arg_0: int, arg_1: str, arg_2: bool) -> Optional[str]:
        return "ret"

    # 1.
    apl: Optional[ArgReplacer] = ArgReplacer(example_function, "arg_0")
    assert apl.name == "arg_0"
    assert apl.arg_pos == 0
    apl = None

    # 2.
    apl: Optional[ArgReplacer] = ArgReplacer(example_function, "arg_1")
    assert apl.name == "arg_1"
    assert apl.arg_pos == 1
    apl = None

    # 3.
    apl: Optional[ArgReplacer] = ArgReplacer(example_function, "arg_2")
    assert apl.name == "arg_2"


# Generated at 2022-06-26 08:57:22.454503
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Normal test
    try:
        raise_exc_info_0 = ArgReplacer(test_case_0, "exc_info")
        test_case_0()
    except Exception as e:
        exc_info = sys.exc_info()
    old_value = raise_exc_info_0.get_old_value(exc_info, {}, default=None)
    assert isinstance(old_value, GzipDecompressor.Error)


# Generated at 2022-06-26 08:57:30.683945
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f1(a=1, b=2, c=3):
        r = ArgReplacer(f1, 'b')
        old_value, args, kwargs = r.replace(11, (1, ), {'c':3})
        assert old_value == 2
        assert args == (1, )
        assert kwargs == {'c':3, 'b':11}

    f1()


# Generated at 2022-06-26 08:57:43.747783
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    errno_from_exception_0()
    import_object_0()
    re_unescape_0()
    raise_exc_info_0()
    _get_emulated_is_finalizing_0()
    a = Configurable()


# Generated at 2022-06-26 08:57:49.490521
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    f = lambda x: x
    arg_replacer_0 = ArgReplacer(f, "x")
    assert arg_replacer_0.get_old_value((1,), {}, None) == 1


# Generated at 2022-06-26 08:57:52.201264
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    for _ in range(10):
        _ = ArgReplacer(test_case_0, "decompressor")

# Generated at 2022-06-26 08:58:00.764905
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    result_0 = None
    try:
        result_0 = Configurable.__new__(Configurable)
    except NotImplementedError:
        pass
    if result_0 is not None:
        raise Exception(
            "Expected exception \"NotImplementedError\" not raised. args: {}".format(
                ()
            )
        )



# Generated at 2022-06-26 08:58:06.712808
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_0(a: int, b: int, c: int = 3, d: str = "d"):
        pass

    expected_0 = None
    actual_0 = ArgReplacer(func_0, "d").replace(1, (1, 2), {})
    assert expected_0 == actual_0, (expected_0, actual_0)


# Generated at 2022-06-26 08:58:14.756810
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = test_case_0
    name = 'decompress'
    arg_replacer_0 = ArgReplacer(func, name)
    args = (1, 2, 3)
    kwargs = {'a': 'b', 'c': 'd'}
    new_value = 'e'
    result = arg_replacer_0.replace(new_value, args, kwargs)


# Generated at 2022-06-26 08:58:17.102481
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test that class attribute __impl_class is retrieved
    # properly in method __new__
    unittest.TestCase().assertEqual(Configurable().__impl_class, None)


# Generated at 2022-06-26 08:58:24.274019
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_1 = Configurable()
    configurable_2 = Configurable()
    configurable_1.configure(None)
    configurable_2.configure(None)
    assert(configurable_1 is not None)
    assert(configurable_2 is not None)


# Generated at 2022-06-26 08:58:29.930795
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Verify if the number of arguments and their types are correct
    try:
        test_case_0()
    except Exception as err:
        # Verify if the exception is expected
        with open('Tests/unit_tests.log', mode='a') as file_handler:
            file_handler.write(str(err))
            file_handler.write('\n')
test_Configurable_initialize()

# Generated at 2022-06-26 08:58:39.815623
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    gzip_decompressor_0 = GzipDecompressor()
    gzip_decompressor_0_0 = gzip_decompressor_0
    arg_replacer_0 = ArgReplacer(gzip_decompressor_0_0.__init__, "decompress")
    arg_replacer_0_0 = arg_replacer_0
    (str_0, seq_0, dict_0) = arg_replacer_0_0.replace(False, (), {})
    assert not(str_0)
    assert not(seq_0)
    assert not(dict_0)


# Generated at 2022-06-26 08:58:54.994749
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(arg_0, arg_1):
        pass

    arg_replacer_0 = ArgReplacer(test_func, "arg_0")
    tuple_var_0 = arg_replacer_0.replace("", tuple(), dict())


# Generated at 2022-06-26 08:59:03.139613
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_1 = Configurable.configure(3)
    # configurable_2 = Configurable.configure(impl = 'abc')
    configurable_3 = Configurable.configured_class()
    configurable_4 = Configurable.configurable_base()
    configurable_5 = Configurable.configurable_default()
    configurable_6 = Configurable._save_configuration()
    configurable_7 = Configurable._restore_configuration(configurable_6)

if __name__ == '__main__':
    test_case_0()

    test_Configurable___new__()

# Generated at 2022-06-26 08:59:05.299050
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    type_test_0 = Configurable()


# Generated at 2022-06-26 08:59:09.008363
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    unit_test_0 = Configurable()
    unit_test_0 = Configurable.__new__(Configurable)


# Generated at 2022-06-26 08:59:10.823019
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_obj = Configurable()
    configurable_obj.initialize()


# Generated at 2022-06-26 08:59:20.840655
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = None
    configurable_1 = Configurable.configure()
    configurable_2 = Configurable.configured_class()
    configurable_3 = Configurable.configurable_base()
    configurable_4 = Configurable.configurable_default()
    assert configurable_4 is None, 'configurable_4 = %s' % (configurable_4,) 


# Generated at 2022-06-26 08:59:22.285175
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:59:23.848202
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-26 08:59:26.450158
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_initialize = Configurable.initialize
    test_initialize(Configurable())


# Generated at 2022-06-26 08:59:36.291331
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    logging.info('Test for Configurable.__new__')
    # Test for arg1 impl
    logging.info('  Test for arg impl')
    impl = re.compile('\d')
    kwargs = {}
    class TestConfigurableBase(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurableBase

        @classmethod
        def configurable_default(cls):
            return re.compile('\d')
    TestConfigurableBase.configure(impl, **kwargs)
    # Test for arg1 impl:
    #     impl is not None and impl is a subclass of cls -> impl
    logging.info('    Test for arg impl:')
    logging.info('      impl is not None and impl is a subclass of cls -> impl')

# Generated at 2022-06-26 08:59:51.393082
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    first_class_0 = Configurable()
    first_class_0.initialize()

# Generated at 2022-06-26 08:59:56.393818
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict({'a': 0, 'b': 1})
    if obj.a != 0:
        raise RuntimeError('Failed test: obj.a != 0')
    if obj.b != 1:
        raise RuntimeError('Failed test: obj.b != 1')
    try:
        obj.c
        raise RuntimeError('Failed test: obj.c not raised')
    except AttributeError:
        pass


# Generated at 2022-06-26 08:59:59.485767
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 09:00:03.579893
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    asyncclient_0 = AsyncHTTPClient()
    asyncclient_0.initialize(asyncclient_0)
    asyncclient_0.initialize()

# Generated at 2022-06-26 09:00:10.877290
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    bytes_1 = b''
    int_2 = 0
    Configurable_0 = Configurable()
    Configurable_1 = Configurable()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-26 09:00:13.909378
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    dict_0: ObjectDict = ObjectDict()
    dict_0['a'] = 1
    assert dict_0.a == 1



# Generated at 2022-06-26 09:00:19.603369
# Unit test for method __new__ of class Configurable
def test_Configurable___new__(): 
    # Configurable.__new__()
    global_configuration_0 = Configurable.configure(impl=None, **{"arg1":1})
    decorated_with_0 = Configurable.__new__(Configurable)


# Generated at 2022-06-26 09:00:29.632472
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_0(arg_0, arg_1, arg_2):
        return (arg_0, arg_1, arg_2)

    instance_0 = ArgReplacer(func_0, "arg_0")
    print("arg_0")
    print("arg_1")
    print("arg_2")
    print("(arg_0, arg_1, arg_2)")
    print("(1, 2, 3)")
    print("{}")
    # print(type(instance_0.replace("1", ["2"], {})[0]))
    print("(1, 2, 3)")
    print("{}")
    print("(1, 2, 3)")
    # print(type(instance_0.replace("1", ["2"], {})[0]))



# Generated at 2022-06-26 09:00:36.894784
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """Test __new__ of Configurable"""
    Configurable.configure('json')
    impl = Configurable.configurable_default()
    assert impl.configurable_base() == Configurable
    assert impl.configurable_default() == impl
    assert Configurable.configured_class() == impl


if __name__ == "__main__":
    test_case_0()
    test_Configurable___new__()

# Generated at 2022-06-26 09:00:38.677404
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:01:23.362598
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create a concrete subclass of Configurable to call __new__ on.
    class ConcreteConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConcreteConfigurable

        @classmethod
        def configurable_default(cls):
            return ConcreteConfigurable

    # Call __new__ using the classmethod.
    cc = ConcreteConfigurable.__new__(ConcreteConfigurable)


# Generated at 2022-06-26 09:01:29.638905
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(object):
        a = 1

    class B(object):
        b = 2

    class C(Configurable):
        @classmethod
        def configurable_default(cls):
            return A

        @classmethod
        def configurable_base(cls):
            return C

    C.configure(None)
    c = C()
    assert c.a == 1

    C.configure(B)
    c = C()
    assert c.b == 2


# Generated at 2022-06-26 09:01:40.493905
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class _Foo(Configurable):
        def configurable_base(self):
            return _Foo

        def configurable_default(self):
            return _Foo

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_

# Generated at 2022-06-26 09:01:47.138500
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(x, y, z):
        print(x, y, z)
    a = ArgReplacer(foo, 'x')
    x = a.replace(None, (1, 2, 3), {})
    assert x[0] == 1
    assert x[1] == (None, 2, 3)
    assert x[2] == {}


# Generated at 2022-06-26 09:01:58.994804
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_method_0(arg_0, arg_1):
        return
    test_method_0_0 = test_method_0
    test_method_0_1 = test_method_0
    test_method_0_0(1, 10)
    test_method_0_1(10, 1)
    test_method_0_2 = test_method_0
    test_method_0_1 = test_method_0
    test_method_0_1(1, 10)
    test_method_0_2(10, 1)
    test_method_0_3 = test_method_0
    test_method_0_2 = test_method_0
    test_method_0_2(1, 10)
    test_method_0_3(10, 1)
    test_method_

# Generated at 2022-06-26 09:02:08.799668
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import random
    import string
    from io import BytesIO

    def rand_str(n):
        return ''.join([random.choice(string.ascii_letters + string.digits) for i in range(n)])


    gzip_text = b"hello world!\n"
    for i in range(10):
        fp = BytesIO()
        f = gzip.GzipFile(fileobj=fp, mode="wb")
        f.write(gzip_text)
        f.close()
        test_data = fp.getvalue()

        with gzip.GzipFile(fileobj = BytesIO(test_data)) as f:
            data = f.read()

        unzipper = GzipDecompressor()

# Generated at 2022-06-26 09:02:12.593952
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 09:02:20.965642
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    impl_class_0 = Configurable.configured_class()
    impl_class_0.configure(impl = "tornado.util.Configurable")
    impl_kwargs_0 = {"test1": "test1"}
    impl_kwargs_1 = {"test0": "test0"}
    impl_kwargs_0.update(impl_kwargs_1)
    gi_kwargs_1 = {"test0": "test0"}
    impl_class_0.configure(impl = "tornado.util.Configurable", **gi_kwargs_1)
    impl_kwargs_0 = {"test1": "test1"}
    impl_kwargs_1 = {"test0": "test0"}
    impl_kwargs_0.update(impl_kwargs_1)
    impl_kwargs_0 = impl

# Generated at 2022-06-26 09:02:25.572944
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import tornado.simple_httpclient
    tornado.simple_httpclient.Configurable.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient")
    instance_0_0 = tornado.simple_httpclient.Configurable()


# Generated at 2022-06-26 09:02:27.852834
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable = Configurable()
    configurable.initialize(**{'a': 1, 'b': True})


# Generated at 2022-06-26 09:03:35.782711
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 09:03:42.560697
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# Generated at 2022-06-26 09:03:48.923791
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    if True:
        import threading
        from concurrent.futures import ThreadPoolExecutor

        # This is needed to avoid error messages.
        # ThreadPoolExecutor uses the default IOloop, so
        # this is required.
        IOLoop.clear_current()

        # Configure the thread pool size to a large number.
        #
        # This assumes that the thread pool is not already
        # in use, but that assumption is tenuous.
        thread_pool_executor = ThreadPoolExecutor(10)
        Configurable.configure(thread_pool_executor)
        # Now the thread pool is configured.
        # its initialized with the large number of threads.
        # the __new__ creates an instance of the class
        # configured.

        # Create an instance of AsyncIOEventLoop, which should
        # be created asynchron