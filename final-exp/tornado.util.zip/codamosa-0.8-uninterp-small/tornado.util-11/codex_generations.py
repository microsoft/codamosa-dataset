

# Generated at 2022-06-26 08:54:18.931584
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    _ = ([], {})
    _ = ArgReplacer._replace("", _)
    # Unit test for method get_old_value of class ArgReplacer

# Generated at 2022-06-26 08:54:20.871310
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test that a missing implementation class has no effect.
    cls_0 = test_case_0.configurable_base.im_class
    test_case_0.configure(None)
    instance_0 = cls_0()

test_Configurable___new__()

# Generated at 2022-06-26 08:54:24.196382
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Test:
        def test_method(self, a, b, c = "c", *args, **kwargs):
            for i in range(10):
                for i in range(10, 20):
                    pass
                pass
            for i in range(20, 30):
                pass

    def test_method():
        pass

    def test_method():
        pass

    def test_method():
        pass

    def test_method():
        pass

    def test_method():
        pass

    def test_method():
        pass

    def test_method():
        pass

    def test_method():
        pass



# Generated at 2022-06-26 08:54:29.680594
# Unit test for function import_object
def test_import_object():
    tornado = import_object('tornado')
    assert tornado is not None
    escape = import_object('tornado.escape')
    assert escape is not None
    utf8 = import_object('tornado.escape.utf8')
    assert utf8 is not None
    try:
        import_object('tornado.missing_module')
        assert False
    except:
        pass



# Generated at 2022-06-26 08:54:41.414365
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    #
    #   Test correct execution
    #
    test_case_ArgReplacer_get_old_value_test_0()
    #
    #   Test wrong type
    #
    #test_case_ArgReplacer_get_old_value_test_1()
    #
    #   Test wrong type
    #
    #test_case_ArgReplacer_get_old_value_test_2()
    #
    #   Test wrong type
    #
    #test_case_ArgReplacer_get_old_value_test_3()
    #
    #   Test wrong type
    #
    #test_case_ArgReplacer_get_old_value_test_4()


# Generated at 2022-06-26 08:54:43.130987
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    initialize_0 = Configurable.initialize
    test_case_0()


# Generated at 2022-06-26 08:54:55.111453
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    str_0 = "0xE"
    str_1 = "application/json"
    str_2 = 'crumbs'
    str_3 = 'pytest_tornado.plugin'
    str_4 = 'False'
    str_5 = 'application/json'
    str_6 = "/"
    str_7 = 'pytest_tornado.plugin'
    str_8 = 'application/x-msgpack'
    str_9 = 'application/x-msgpack'
    str_10 = 'True'
    str_11 = 'localhost'
    str_12 = '0xE'
    str_13 = " 0xE"
    str_14 = '0xE'
    str_15 = '0xE'
    str_16 = "0xE"

# Generated at 2022-06-26 08:55:04.655428
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import tornado.locks

    test_case_0()
    test_case_1()
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    assert import_object("tornado.locks.Condition") is tornado.locks.Condition
    try:
        import_object('tornado.locks')
    except ImportError:
        pass


# Generated at 2022-06-26 08:55:13.088620
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    class FunctionWithArgument(object):
        def func(self, arg):
            pass

    function_with_argument_instance = FunctionWithArgument()
    args = (None,)
    kwargs = {'arg': None}
    method_0 = ArgReplacer(function_with_argument_instance.func, "arg")
    test_0 = method_0.get_old_value(args, kwargs)
    assert test_0 == None


# Generated at 2022-06-26 08:55:19.198992
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    print("Testing constructor for class ArgReplacer")
    assert issubclass(ArgReplacer, object)
    arg_replacer_0 = ArgReplacer(test_case_0, "")
    assert arg_replacer_0.name == ""
    # Verify that member arg_pos is set properly
    arg_replacer_1 = ArgReplacer(test_case_0, "")
    assert arg_replacer_1.arg_pos is None
    # Check that a wrong type for the argument func raises an exception
    with pytest.raises(TypeError):
        ArgReplacer(None, None)


# Generated at 2022-06-26 08:55:36.521091
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Test case 1
    print("Test case 1")
    TestCase1_errno = errno_from_exception()
    print(TestCase1_errno)
    # Test case 2
    print("Test case 2")
    TestCase2_errno = errno_from_exception()
    print(TestCase2_errno)

if __name__ == "__main__":
    test_case_0()
    test_errno_from_exception()

# Generated at 2022-06-26 08:55:38.648487
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    obj = Configurable()
    obj.initialize()


# Generated at 2022-06-26 08:55:41.298326
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    el = Configurable()
    assert el is None, "Expected None, got " + str(el)


# Generated at 2022-06-26 08:55:44.466439
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    object_dict_0 = ObjectDict()
    str_0 = None
    any_0 = object_dict_0._ObjectDict__getattr__(str_0)



# Generated at 2022-06-26 08:55:53.103170
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    if __name__ == '__main__':
        obj_dict_0 = ObjectDict()
        obj_dict_0.__setattr__('key1', 'value1')
        ret_0 = obj_dict_0.__getattr__('key1')  # expected str
        assert ret_0 == 'value1', 'return value check failed'
    else:
        test_case_0()


# Generated at 2022-06-26 08:55:56.056700
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    try:
        test_case_0()
    except BaseException as e:
        print("Exception: " + str(e))

if __name__ == '__main__':
	test_Configurable_initialize()

# Generated at 2022-06-26 08:56:08.801606
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def get_old_value(self, args: Sequence[Any], kwargs: Dict[str, Any], default: Any = None) -> Any:
        return self.arg_pos
    def get_new_value(self, args: Sequence[Any], kwargs: Dict[str, Any], default: Any = None) -> Any:
        return default
    def get_args(self, args: Sequence[Any], kwargs: Dict[str, Any], default: Any = None) -> Any:
        return args
    def get_kwargs(self, args: Sequence[Any], kwargs: Dict[str, Any], default: Any = None) -> Any:
        return kwargs

    arg_pos = None
    name = None
    func = None
    replacer = ArgReplacer(func, name)
    repl

# Generated at 2022-06-26 08:56:10.414459
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    test_case_0()


# Generated at 2022-06-26 08:56:14.247217
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    assert_equal(isinstance(configurable_0, Configurable), True)

    # Ensure that the exception is raised on an invalid subclass
    with assert_raises_regex(ValueError, r'Invalid subclass of .*'):
        configurable_0.configure(type('TestClass', (), {}), keyword_0='value_0')


# Generated at 2022-06-26 08:56:21.831334
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    str_1 = None
    str_2 = None
    if '__main__':
        if len(sys.argv) > 1:
            str_1 = sys.argv[1]
            str_2 = sys.argv[2]
        else:
            str_1 = "../test/common_test/config.py"
            str_2 = "../test/common_test/config.py"
    func_0 = None
    with open(str_1, 'r') as file_1:
        with open(str_2, 'r') as file_2:
            str_3 = file_1.read()
            str_4 = file_2.read()
            func_0 = replace_with_file(str_3, str_4, func_0)

# Generated at 2022-06-26 08:56:53.072405
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    object_0 = object();
    print(id(object_0))
    object_0 = object();
    print(id(object_0))
    object_0 = object();
    print(id(object_0))
    object_0 = object();
    print(id(object_0))
    object_0 = Configurable();
    print(id(object_0))
    object_0 = object();
    print(id(object_0))
    object_0 = object();
    print(id(object_0))
    object_0 = object();
    print(id(object_0))
    object_0 = object();
    print(id(object_0))
    object_0 = Configurable();
    print(id(object_0))
    object_0 = Configurable();

# Generated at 2022-06-26 08:57:03.281865
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_method_0(arg_0, arg_1, arg_2):
        str_0 = "arg_0"
        arg_replacer_0 = ArgReplacer(test_method_0, str_0)
        list_0 = []
        dict_0 = {}
        any_0, list_1, dict_1 = arg_replacer_0.replace(arg_0, list_0, dict_0)
        print(any_0)

    # Test a positional argument
    def test_method_1(arg_0, arg_1, arg_2, arg_3):
        str_0 = "arg_2"
        arg_replacer_0 = ArgReplacer(test_method_1, str_0)

# Generated at 2022-06-26 08:57:14.649296
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable = Configurable()
    assert Configurable.configurable_base, "Callable method configurable_base does not exist"
    assert Configurable.configurable_base(), "Callable method configurable_base does not return value"
    assert Configurable.configurable_default, "Callable method configurable_default does not exist"
    assert Configurable.configurable_default(), "Callable method configurable_default does not return value"
    assert Configurable._initialize, "Callable method _initialize does not exist"
    assert Configurable.configure, "Callable method configure does not exist"
    assert Configurable.configured_class, "Callable method configured_class does not exist"
    assert Configurable._save_configuration, "Callable method _save_configuration does not exist"

# Generated at 2022-06-26 08:57:21.500002
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = None
    argReplacer_instance = ArgReplacer(func, 'any_0')
    try:
        any_0 = argReplacer_instance.replace((1,), {}, any_0)
    except Exception as e:
        pass
    else:
        assert True


__all__ = ["Configurable", "import_object", "ArgReplacer", "raise_exc_info"]

# Generated at 2022-06-26 08:57:31.273589
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Test 1
    test_class = Configurable

    test_initialize = test_class.initialize
    assert(test_initialize == test_class._initialize)

    # Test 2
    class Test_class(Configurable):
        def _initialize(self):
            return
        def initialize(self):
            print("")
    test_class = Test_class

    test_initialize = test_class.initialize
    assert(test_initialize == test_class._initialize)

# Test for configure method from Configurable

# Generated at 2022-06-26 08:57:40.318729
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    old_value = None
    str_0 = 'a'
    any_0 = import_object(str_0)
    list_0 = []
    argreplacer_0 = ArgReplacer(any_0,str_0)
    any_1, any_2 = argreplacer_0.get_old_value(list_0,any_0,old_value)


# Generated at 2022-06-26 08:57:41.632200
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()


# Generated at 2022-06-26 08:57:45.324390
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def any_0(any_0 : object, any_1 : object) -> object:
        return any_0
    any_0 = ArgReplacer(any_0, 'any_0')
    any_1 = any_0.get_old_value(['any_0', 'any_1'], {})
    assert any_1 == 'any_0'




# Generated at 2022-06-26 08:57:53.413242
# Unit test for function errno_from_exception
def test_errno_from_exception():
    exception_1 = Exception()
    exception_1.errno = 1
    exception_2 = Exception()
    exception_2.args = [2]
    exception_3 = Exception()
    assert(errno_from_exception(exception_1) == 1)
    assert(errno_from_exception(exception_2) == 2)
    assert(errno_from_exception(exception_3) is None)


# Generated at 2022-06-26 08:57:56.556305
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Create an instance of arg_replacer
    arg_replacer_0 = ArgReplacer(configure, "impl")
    # Call the method get_old_value
    arg_replacer_0.get_old_value((),{},None)

# Generated at 2022-06-26 08:58:14.954909
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_arg_replacer = ArgReplacer(test_case_0, 'str_0')
    test_arg_replacer.replace(None, [], {})


# Generated at 2022-06-26 08:58:21.794078
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    str_0 = None
    any_0 = import_object(str_0)
    str_0 = None
    any_1 = import_object(str_0)
    str_0 = None
    any_2 = import_object(str_0)



# Generated at 2022-06-26 08:58:28.017763
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    str_0 = None
    arg_replacer_0 = ArgReplacer(test_case_0, str_0)
    tuple_0 = ('', [], {})
    any_0 = arg_replacer_0.get_old_value(*tuple_0)
    assert any_0 is None


# Generated at 2022-06-26 08:58:36.960655
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # __init__()
    arg_replacer = ArgReplacer(test_case_0, "str_0")

    # get_old_value()
    str_0 = None
    any_0 = arg_replacer.get_old_value(("test",), {"str_0": "test2"}, None)
    print("any_0: " + str(any_0))


# Generated at 2022-06-26 08:58:43.471566
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    assert Configurable.__new__ is not object.__new__
    assert issubclass(Configurable, object)
    class_0 = type('',(object,),{'__module__': __name__})
    if type(class_0) is type:
        assert issubclass(class_0, object)
    assert not issubclass(type(class_0), object)
    class_0 = type('',(object,),{'__module__': __name__})
    if type(class_0) is type:
        assert issubclass(class_0, object)
    assert not issubclass(type(class_0), object)
    class_0 = type('',(object,),{'__module__': __name__})

# Generated at 2022-06-26 08:58:47.092208
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    any_0 = None
    ArgReplacer.replace(any_0, [(any_0,)], any_0)


# Generated at 2022-06-26 08:58:49.593018
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    str_1 = None
    any_1 = Configurable.__new__(str_1)
    assert any_1 is not None


# Generated at 2022-06-26 08:58:51.235800
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable = Configurable()

# Generated at 2022-06-26 08:58:56.308136
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    str_0 = None
    str_1 = None
    dict_0 = None
    tuple_0 = None
    tuple_1 = ArgReplacer.replace(str_0, tuple_0, dict_0)


# Generated at 2022-06-26 08:59:01.331963
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    # Unit test for __new__
    print("\nTest __new__")
    # Test case: Configurable.__new__
    with pytest.raises(TypeError):
        test_case_0()

    # Test case: Configurable.__new__
    with pytest.raises(TypeError):
        test_case_0()


# Generated at 2022-06-26 08:59:43.395759
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    arg_replacer_0 = ArgReplacer(test_case_0, 's')
    test_case_0()
    test_case_0()
    arg_replacer_0.replace(None, None, None)
    int_0 = test_case_0()
    int_1 = test_case_0()
    if int_0 == int_1:
        return 1
    else:
        return 0


# Generated at 2022-06-26 08:59:45.310452
# Unit test for function errno_from_exception
def test_errno_from_exception():
    global int_0
    int_0 = 0
    errno_from_exception(int_0)


# Generated at 2022-06-26 08:59:50.880670
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    str_0 = None
    any_0 = ArgReplacer(test_case_0, str_0)
    any_0.replace(str_0, test_case_0, test_case_0)


# Generated at 2022-06-26 08:59:58.274529
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    test_str_0 = 'wF'
    test_str_1 = 'bv'
    test_str_2 = 'jK'
    test_str_3 = 'Zb'
    test_str_4 = 'zW'
    test_str_5 = 'vB'
    test_str_6 = 'A4'
    test_str_7 = 'Jz'
    test_str_8 = 'Qw'
    test_str_9 = 'mj'
    test_seq_0 = (
        test_str_0, test_str_1, test_str_2, test_str_3, test_str_4, test_str_5, test_str_6,
        test_str_7, test_str_8, test_str_9,
    )
    test_

# Generated at 2022-06-26 09:00:02.806200
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    #print('test_Configurable___new__')
    # Create an instance of class Configurable
    #configurable = Configurable()

    # TODO: test_Configurable___new__
    pass


# Generated at 2022-06-26 09:00:07.910325
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Prepare test
    # Create instance of ArgReplacer with arguments
    instance = ArgReplacer(test_case_0, 'str_0')
    # Assign values to variables
    any_2 = None
    list_0 = []
    dict_0 = {}
    # Run method replace of ArgReplacer
    any_4, list_4, dict_4 = instance.replace(any_2, list_0, dict_0)
    # Verify result
    assert any_4 == None
    assert list_4 == []
    assert dict_4 == {'str_0': None}

# Generated at 2022-06-26 09:00:18.597274
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # unit test for replace
    func = globals()['test_ArgReplacer_replace']
    def func_0():
        str_1 = 'a1'
        str_2 = 'b2'
        int_1 = 2
        int_2 = 3
        any_0 = globals()['test_ArgReplacer_replace']
        int_3 = any_0(4)
        tuple_0 = import_object(str_1, str_2, int_1, int_2)
        int_4 = tuple_0[0]
        int_5 = 4
        ArgReplacer_1 = ArgReplacer(func_0, 'a1')
        any_1 = ArgReplacer_1.get_old_value(tuple_0, int_3)

# Generated at 2022-06-26 09:00:25.568481
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    kind = _kinds[0]
    impl = Configurable.configured_class()
    impl = kind()
    impl.initialize(impl)
    impl = kind()
    impl.initialize(impl, *None)
    impl = kind()
    impl.initialize(impl, *None, **None)


# Generated at 2022-06-26 09:00:31.650043
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        # raise an exception
        raise Exception()
    except Exception as e:
        errno_1 = errno_from_exception(e)
        errno_0 = None
        assert errno_1 == errno_0



# Generated at 2022-06-26 09:00:36.193485
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def function_0(arg_0):
        return arg_0
    argReplacer_0 = ArgReplacer(function_0, 'arg_0')
    assert argReplacer_0


# Generated at 2022-06-26 09:01:17.660570
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    from typing import Optional
    from typing import Sequence

    ArgReplacer.get_old_value(Sequence[Optional[ArgReplacer.replace]], dict(), dict())


# Generated at 2022-06-26 09:01:27.799306
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Method signature: __new__(cls, *args, **kwargs)
    # cls: type
    # args: Any
    # kwargs: Any
    # Returns: Any

    # Properties tested: __impl_class, __impl_kwargs,

    # We want to test Configurable.__new__, not Configurable.__init__,
    # so we need to avoid calling the parent class's __init__.
    # As a hack we pass "object" as the parent, but then we have
    # to set up the Configurable methods manually.
    class ConfigurableSubClass(object):

        def initialize(self):
            pass

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return None


# Generated at 2022-06-26 09:01:32.275026
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Instantiate an instance of class Configurable
    instance0 = Configurable()
    # Call method initialize of class Configurable on the above instance
    instance0.initialize()


# Generated at 2022-06-26 09:01:37.817177
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    str_0 = None
    any_0 = ArgReplacer(str_0, None).replace(None, (), {})


# Generated at 2022-06-26 09:01:50.476744
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from datetime import datetime
    from datetime import timedelta
    from json import loads
    from json import dumps
    from os import path
    from sys import version_info
    from time import strptime
    from time import mktime
    from time import strftime
    from time import time
    from time import localtime
    from time import gmtime
    from datetime import datetime
    from datetime import timedelta
    from datetime import tzinfo
    from json import loads
    from json import dumps
    from os import path
    from sys import version_info
    from time import strptime
    from time import mktime
    from time import strftime
    from time import time
    from time import localtime
    from time import gmtime
    from datetime import datetime
    from datetime import timedelta

# Generated at 2022-06-26 09:01:59.878974
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Test case that are expected to raise exceptions
    # new_value is incompatible with the arg to be replaced
    # have not had time to look at this one further
    # nv_0 = "The value that you want to replace"
    # w/o type info, should be str, using str as example
    # seq_0 = "initial input arguments"
    # w/o type info, should be Sequence[Any], using str as example
    # dict_0 = "initial input kwarguments"
    # w/o type info, should be Dict[str, Any], using str as example

    nv_0 = str()
    seq_0 = list()
    dict_0 = dict({})
    for i in range(10):
        seq_0.append(i)
        dict_0[i] = i

    # case 1

# Generated at 2022-06-26 09:02:06.617456
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Test with any valid parameters
    impl = Configurable.configured_class()
    if impl.configurable_base() is not Configurable:
        # The impl class is itself configurable, so recurse.
        test_Configurable_initialize()
    instance = super(Configurable, impl).__new__(impl)
    instance.initialize(*test_case_0())


# Generated at 2022-06-26 09:02:19.303433
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # test method on function read_headers of module httputil
    func = httputil.read_headers
    # name = 'max_headers'
    test_arg_replacer = ArgReplacer(func, 'max_headers')
    # input args, kwargs
    args = (1, 2)
    kwargs = {'abc': 3, 'def': 4, 'ghi': 5}
    # test_arg_replacer.get_old_value(args, kwargs, default=800)
    # test_arg_replacer.replace(800, args, kwargs)

if __name__ == '__main__':
    test_case_0()
    test_ArgReplacer_get_old_value()

# Generated at 2022-06-26 09:02:32.657936
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    counter = 0
    if testCounter(counter, 0):
        new_value_0_0 = None
        args_0_0 = None
        kwargs_0_0 = None
        obj_0_0 = ArgReplacer.ArgReplacer(new_value_0_0, args_0_0)
        ret_0_0 = obj_0_0.replace(new_value_0_0, args_0_0, kwargs_0_0)
        new_value_0_1 = None
        args_0_1 = None
        kwargs_0_1 = None
        obj_0_1 = ArgReplacer.replace(new_value_0_1, args_0_1)

# Generated at 2022-06-26 09:02:35.577365
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    str_0 = "love pythontype"
    any_0 = import_object(str_0)
