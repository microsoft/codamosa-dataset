

# Generated at 2022-06-26 08:54:10.371432
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = replace
    name = 'not_found'
    assert(ArgReplacer(func,name).replace(3,3,3)==(None,3,3))


# Generated at 2022-06-26 08:54:16.629373
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    object_ArgReplacer_0 = ArgReplacer(test_ArgReplacer_replace, "this")
    test_ArgReplacer_replace_local_value = (object_ArgReplacer_0.replace(
    "a", (), {"this": "b"})
    )
    print(test_ArgReplacer_replace_local_value)


# Generated at 2022-06-26 08:54:20.303865
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Instantiate an object of class Configurable
    test_configurable = Configurable()


# Generated at 2022-06-26 08:54:28.454101
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    old_value, args, kwargs = testArgReplacer.replace(1, (1, 2), {'a': 3, 'b': 4})
    for arg in args:
        if arg is not 1:
            print('Failed on line {}'.format(file_lineno()))
    for key, value in kwargs.items():
        if key  is not 'a' and value is not 4:
            print('Failed on line {}'.format(file_lineno()))

test = [[1, 2], [3, 4], [5, 6], [7, 8]]


# Generated at 2022-06-26 08:54:33.522972
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func_0(arg_0, arg_1):
        pass
    arg_replacer_0 = ArgReplacer(func_0, "arg_1")


# Generated at 2022-06-26 08:54:40.296026
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    arg_replacer_0 = ArgReplacer(lambda: None, "a")
    old_value, args, kwargs = arg_replacer_0.replace("new_value", (), {})
    if (old_value != None):
        raise RuntimeError("Test failed")
    if (kwargs == {}):
        raise RuntimeError("Test failed")
    if (args != ()):
        raise RuntimeError("Test failed")


# Generated at 2022-06-26 08:54:50.389033
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # object_dict_0 = ObjectDict()
    print('test_Configurable_initialize')
    object_dict_0 = ObjectDict()
    object_dict_0['foo'] = 'bar'
    print(object_dict_0.foo)
    # print(object_dict_0['__init__'])
    # print(object_dict_0['__new__'])
    # print(object_dict_0['foo'])
    # print(object_dict_0['bar'])
    # print(object_dict_0['__dict__'])
    # print(object_dict_0['__class__'])
    # print(object_dict_0['__doc__'])
    # print(object_dict_0['__init__'])
    # print(object_dict_0['__new

# Generated at 2022-06-26 08:54:52.816928
# Unit test for function import_object
def test_import_object():
    assert import_object('tornado') == tornado

if __name__ == "__main__":
    test_case_0()
    test_import_object()

# Generated at 2022-06-26 08:55:03.842386
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    object_ArgReplacer = ArgReplacer(test_case_0, "object_dict_0")
    new_value_ArgReplacer = object_ArgReplacer.get_old_value([], {}, {})
    print(new_value_ArgReplacer)
    new_value_ArgReplacer = object_ArgReplacer.get_old_value([object_dict_0], {}, {})
    print(new_value_ArgReplacer)
    new_value_ArgReplacer = object_ArgReplacer.get_old_value([object_dict_0], {"object_dict_0": object_dict_0}, {})
    print(new_value_ArgReplacer)


# Generated at 2022-06-26 08:55:07.362082
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    args = ['a', 'b', 'c']
    kwargs = {'a': 1, 'b': 2, 'c': 3}
    arg_replacer_0 = ArgReplacer(test_case_0, 'd')
    res = arg_replacer_0.get_old_value(args, kwargs, 4)
    assert res == 4


# Generated at 2022-06-26 08:55:26.252715
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    object_dict_0 = ObjectDict()
    object_dict_0['a'] = 'b'
    object_dict_0['c'] = 'd'
    object_dict_1 = ObjectDict()
    object_dict_2 = ObjectDict()
    object_dict_2['e'] = 'f'
    object_dict_2['g'] = 'h'
    object_dict_0['i'] = 'j'
    object_dict_0['k'] = 'l'
    object_dict_0['m'] = 'n'
    object_dict_0['o'] = 'p'
    object_dict_0['q'] = 'r'
    object_dict_0['s'] = 't'
    object_dict_0['u'] = 'v'
    object_dict_0['w']

# Generated at 2022-06-26 08:55:30.340721
# Unit test for function import_object
def test_import_object():
    assert(import_object('tornado.util.import_object') is import_object)
    assert(import_object('tornado') is tornado)


# Generated at 2022-06-26 08:55:33.085271
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    obj = Configurable.__new__(Configurable)
    assert obj is not None


# Generated at 2022-06-26 08:55:45.525245
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    """Test method '__new__' of class Configurable"""

    # Create an instance of IOStream
    iostream_0 = IOStream()

    # Create an instance of IOStream using the default constructor
    iostream_1 = IOStream()

    # Create an instance of IOStream from a Configurable instance
    # TODO: need to figure out how to create a Configurable instance for this
    # iostream_2 = IOStream(configurable_0)

    # Create an instance of IOStream from a Configurable subclass
    # TODO: need to figure out how to create a Configurable subclass for this
    # iostream_3 = IOStream(configurable_subclass_0)

    # Check to make sure that the iostream instances created previously
    # are all distinct

# Generated at 2022-06-26 08:55:58.059407
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Import necessary modules
    import asyncio
    from typing import Dict, List, Optional
    import unittest


    META = ["text/html"]


    class Foo(Configurable):
        """Dummy class for testing Configurable."""
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Foo

        def _initialize(self, name, meta=None):
            self.name = name
            self.meta = meta or META

        initialize = _initialize


    class Bar(Foo):
        """Dummy subclass for testing Configurable."""
        def __init__(self, name, meta=None):
            self.name = name
            self.meta = meta or META



# Generated at 2022-06-26 08:56:02.265313
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    a = ArgReplacer(test_case_0, 'object_dict_0')
    b = a.get_old_value(())
    assert b == None


# Generated at 2022-06-26 08:56:08.973341
# Unit test for function import_object
def test_import_object():
    print(import_object('tornado'))
    print(import_object('tornado.escape'))
    import tornado.escape
    print(import_object('tornado.escape') is tornado.escape)
    import tornado.escape.utf8
    print(import_object('tornado.escape.utf8') is tornado.escape.utf8)
    print(import_object('tornado') is tornado)
    print(import_object('tornado.missing_module'))


test_import_object()


# Generated at 2022-06-26 08:56:13.577186
# Unit test for function import_object
def test_import_object():
    tornado = import_object("tornado")
    assert(tornado is tornado)

if __name__ == '__main__':
    test_case_0()
    test_import_object()

# Generated at 2022-06-26 08:56:21.605916
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    _impl_class = None  # type: Optional[Type[Configurable]]
    _impl_kwargs = None  # type: Dict[str, Any]

    class _Configurable(Configurable):
        # Type annotations on this class are mostly done with comments
        # because they need to refer to Configurable, which isn't defined
        # until after the class definition block. These can use regular
        # annotations when our minimum python version is 3.7.
        #
        # There may be a clever way to use generics here to get more
        # precise types (i.e. for a particular Configurable subclass T,
        # all the types are subclasses of T, not just Configurable).
        __impl_class = None  # type: Optional[Type[Configurable]]
        __impl_kwargs = None  # type: Dict[str, Any]

# Generated at 2022-06-26 08:56:29.134019
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def replace_func(new_value, *args, **kwargs):
        return new_value
    replacer_0 = ArgReplacer(replace_func, "new_value")
    old_value = replacer_0.get_old_value((),{}, "" if False else "")
    old_value = replacer_0.replace("", (), {})
    old_value = replacer_0.replace("", (), {})
    old_value = replacer_0.replace("", (), {})


# Generated at 2022-06-26 08:56:48.332911
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    object_dict_0 = ObjectDict()
    object_dict_0.initialize()


# Generated at 2022-06-26 08:56:51.671386
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    object_dict_1 = ObjectDict()
    object_dict_0 = ObjectDict()

# Generated at 2022-06-26 08:56:54.592524
# Unit test for function raise_exc_info
def test_raise_exc_info():
    exc_info = (None, None, None)
    raise_exc_info(exc_info)


# Generated at 2022-06-26 08:56:59.558728
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    object_ArgReplacer_0 = ArgReplacer("func", "name")
    # Invalid parameter - the test will fail
    object_ArgReplacer_0.get_old_value("args", "kwargs", "default")


# Generated at 2022-06-26 08:57:13.253449
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():

    class C(Configurable):
        def initialize(self):
            self.x = test_Configurable_initialize.x
        def configurable_base():
            return TestCase
        def configurable_default():
            return TestCase

    # Configure the base class.
    C.configure(C, x=1)
    # You can instantiate the base class directly.
    assert C().x == 1
    # You can instantiate any subclass of the base class.
    test_case_0 = TestCase()
    assert test_case_0.x == 1
    # Subclasses are not affected by changes to the base class.
    C.configure(C, x=2)
    assert C().x == 2
    assert test_case_0.x == 1



# Generated at 2022-06-26 08:57:16.218647
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func = test_case_0()
    test_object = ArgReplacer(func, object_dict_0)

# Generated at 2022-06-26 08:57:24.236107
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():

    class DummyImpl(Configurable):
        @classmethod
        def configurable_base(cls):
            return DummyImpl

        @classmethod
        def configurable_default(cls):
            return DummyImpl

    def check_init(**kwargs):
        # type: (Any) -> None
        DummyImpl.configure(DummyImpl, **kwargs)
        impl = DummyImpl()
        for k, v in kwargs.items():
            assert getattr(impl, k) == v

        DummyImpl.configure("tests.util_test.DummyImpl", **kwargs)
        impl = DummyImpl()
        for k, v in kwargs.items():
            assert getattr(impl, k) == v


# Generated at 2022-06-26 08:57:25.713274
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_case_0()


# Generated at 2022-06-26 08:57:33.656973
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func_0 = dummy_function
    name_0 = 'name_0'
    arg_replacer_0 = ArgReplacer(func_0, name_0)
    args_0 = (0,)
    kwargs_0 = object_dict_0
    kwargs_0.name_0 = 0
    for i in range(int(1e4)):
        arg_replacer_0.get_old_value(args_0, kwargs_0)



# Generated at 2022-06-26 08:57:38.249294
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    argreplacer_0 = ArgReplacer(test_case_0, "object_dict_0")
    # TODO: add test logic here



# Generated at 2022-06-26 08:57:54.292719
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    replacer = ArgReplacer(lambda: None, "a")
    assert replacer.replace(0, (1,), {"a": 2}) == (1, (0,), {"a": 2})
    assert replacer.replace(0, (1,), {}) == (None, (1,), {"a": 0})
    assert replacer.replace(0, (), {"a": 2}) == (2, (), {"a": 0})


# Generated at 2022-06-26 08:57:59.106175
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # new_value = "str", args = ("str", ), kwargs =  {}
    # return old_value, new_args, kwargs
    # old_value: "str", new_args: ("str", ), kwargs: {}
    function_0 = ArgReplacer(test_case_0, *("__name__", ))
    test_list = []
    for i in range(300):
        test_list.append(function_0.replace("str", ("str", ), {}))
    return test_list


# Generated at 2022-06-26 08:58:09.554100
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():

    def print_args(a: int, b: int = 0, *c: int, d: int = 0, **e: int) -> None:
        pass

    def f1(a, b, c, d, e):
        r = ArgReplacer(print_args, "a")
        return r.replace(1, (a, b, c, d, e), {})

    def f2(a, b, c, d, e):
        r = ArgReplacer(print_args, "b")
        return r.replace(1, (a, b, c, d, e), {})

    def f3(a, b, c, d, e):
        r = ArgReplacer(print_args, "c")
        return r.replace(1, (a, b, c, d, e), {})

   

# Generated at 2022-06-26 08:58:10.910769
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_1 = Configurable()
    configurable_1.__new__()


# Generated at 2022-06-26 08:58:15.232085
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    f = test_ArgReplacer_get_old_value
    ar = ArgReplacer(func=f, name='f')
    ar.get_old_value(args=0, kwargs=0)


# Generated at 2022-06-26 08:58:19.526704
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    tp_0 = ArgReplacer()
    new_value_0, args_0, kwargs_0 = tp_0.replace()


# Generated at 2022-06-26 08:58:21.721758
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import_object('a')


# Generated at 2022-06-26 08:58:31.571869
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    test_ArgReplacer_get_old_value_arg_0 = ArgReplacer(test_case_0, "")
    test_ArgReplacer_get_old_value_arg_1 = ()
    test_ArgReplacer_get_old_value_arg_2 = {"": None}
    test_ArgReplacer_get_old_value_arg_3 = None
    test_ArgReplacer_get_old_value_arg_0.get_old_value(test_ArgReplacer_get_old_value_arg_1, test_ArgReplacer_get_old_value_arg_2, test_ArgReplacer_get_old_value_arg_3)


# Generated at 2022-06-26 08:58:41.988557
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func_name = 'test_func'
    def test_func(a=None, b=None, *args, **kwargs):
        pass
    arg_name = 'a'
    old_value = 'a_old'
    new_value = 'a_new'
    replacer = ArgReplacer(test_func, arg_name)
    args = ()
    kwargs = {'a': old_value}
    _old_value, args, kwargs = replacer.replace(new_value, args, kwargs)
    assert(_old_value == old_value)
    assert(args == ())
    assert(kwargs == {'a': new_value})

    kwargs = {'a': old_value, 'b': 'b_old'}
    _old_value, args, kwargs

# Generated at 2022-06-26 08:58:52.215195
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    print("configurable_0.ArgReplacer.replace()")
    # TEST CASE 0
    # args = (1, "A", 2, "B")
    # kwargs = {"one":"a", "three":"b", "five":"c"}
    # name = "four"
    # new_value = 4
    # expected_value = None
    # expected_args = (1, "A", 2, "B", 4)
    # expected_kwargs = {"one":"a", "three":"b", "five":"c"}
    #
    # # TEST CODE 0
    # configurable_0 = ArgReplacer(test_case_0, name)
    # value_0, args_0, kwargs_0 = configurable_0.replace(new_value, args, kwargs)
    #
    # # VERIF

# Generated at 2022-06-26 08:59:09.705259
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # test_case_0
    configurable_0 = Configurable()
    # test_case_1
    configurable_1 = Configurable()
    # test_case_2
    configurable_2 = Configurable()
    # test_case_3
    configurable_3 = Configurable()
    # test_case_4
    configurable_4 = Configurable()
    # test_case_5
    configurable_5 = Configurable()


# Generated at 2022-06-26 08:59:16.636521
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = Configurable.configurable_base()
    init_kwargs = {}  # type: Dict[str, Any]
    if cls is base:
        impl = Configurable.configured_class()
        if base.__impl_kwargs:
            init_kwargs.update(base.__impl_kwargs)
    else:
        impl = cls
    init_kwargs.update(kwargs)
    if impl.configurable_base() is not base:
        # The impl class is itself configurable, so recurse.
        return impl(*args, **init_kwargs)
    instance = super(Configurable, cls).__new__(impl)
    # initialize vs __init__ chosen for compatibility with AsyncHTTPClient
    # singleton magic.  If we get rid of that we can switch to __init__
   

# Generated at 2022-06-26 08:59:19.896064
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:59:20.604774
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:59:26.710078
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    #
    # Testing is done in main because we need access to certain flags
    # that are not present in this module, such as io_loop, which is
    # needed by the test.
    #
    # assert_raises(
    #     NotImplementedError, Configurable.__new__, Configurable(),
    # )
    # assert_raises(
    #     TypeError, Configurable.configurable_base,
    # )
    # assert_raises(
    #     NotImplementedError, Configurable.configurable_default,
    # )
    # assert_raises(
    #     TypeError, Configurable.configure,
    # )
    # assert_raises(
    #     TypeError, Configurable.configured_class,
    # )
    pass


# Generated at 2022-06-26 08:59:28.885884
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:59:33.165403
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Result: pass
    try:
        configurable_0 = Configurable()
    except:
        pass


# Generated at 2022-06-26 08:59:38.077541
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
	configurable_0 = Configurable()
	# assertEqual(expected, Configurable.__new__(cls, *args, **kwargs))
	raise NotImplementedError()


# Generated at 2022-06-26 08:59:47.089547
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    assert hasattr(configurable_0, '__impl_class'), \
        "Object should have an attribute __impl_class"
    assert hasattr(configurable_0, '__impl_kwargs'), \
        "Object should have an attribute __impl_kwargs"
    impl_class = configurable_0.__impl_class
    assert isinstance(impl_class, type), \
        "__impl_class should be of class Type, got %s instead" % type(impl_class)
    impl_kwargs = configurable_0.__impl_kwargs
    assert isinstance(impl_kwargs, dict), \
        "__impl_kwargs should be of class Dict, got %s instead" % type(impl_kwargs)


# Generated at 2022-06-26 08:59:53.393757
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func_1(x_1):
        return x_1

    arg_replacer_1 = ArgReplacer(test_func_1, "x_1")
    res_1 = arg_replacer_1.get_old_value((0,), {})


# Generated at 2022-06-26 09:00:09.773885
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    arg_replacer_0 = ArgReplacer(Configurable, 'name')
    print(arg_replacer_0.replace('new_value', 'args', 'kwargs'))

# Generated at 2022-06-26 09:00:11.371177
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:00:16.569389
# Unit test for function import_object
def test_import_object():
    assert import_object("tornado.util") is util
    assert import_object("tornado.util.Configurable") is Configurable
    assert import_object("tornado.test.test_util") is test_util

_NO_DEFAULT = object()

_ARG_DEFAULT = dict()  # type: typing.Mapping[str, Any]


# Generated at 2022-06-26 09:00:19.444481
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_0.__new__(configurable_0)


# Generated at 2022-06-26 09:00:23.177853
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    Configurable.configure(Configurable())
    Configurable.configured_class()


# Generated at 2022-06-26 09:00:26.336699
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    if 'TMP_BASE' not in globals():
        TMP_BASE = Configurable()
    assert TMP_BASE.__new__(Configurable) is not None


# Generated at 2022-06-26 09:00:36.863083
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func_0(x, y, z):
        replacer = ArgReplacer(test_func_0, 'x')
        old_value, args, kwargs = replacer.replace(1, (2, 3), {})
        assert old_value == 2
        new_x, new_y, new_z = args
        assert new_x == 1
        assert new_y == 3
        assert new_z is None
        assert not kwargs
    test_func_0(0, 0, 0)


# Generated at 2022-06-26 09:00:38.599958
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass



# Generated at 2022-06-26 09:00:40.029086
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    pass


# Generated at 2022-06-26 09:00:50.151417
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer_0 = ArgReplacer(test_case_0, 'configurable')
    assert arg_replacer_0.get_old_value((), {}) == None
    arg_replacer_0 = ArgReplacer(test_case_0, 'configurable')
    assert arg_replacer_0.get_old_value((configurable_0,), {}) == configurable_0
    arg_replacer_0 = ArgReplacer(test_case_0, 'configurable')
    assert arg_replacer_0.get_old_value((), {'configurable': configurable_0}) == configurable_0


# Generated at 2022-06-26 09:01:47.973035
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    args_0: Any = ()
    kwargs_0: Any = {}
    assert False, "Test not implemented"
    # test return type
    assert isinstance(instance_0, Configurable)


# Generated at 2022-06-26 09:01:51.166074
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj_dict_0 = ObjectDict()
    test_case_0()

dummy = None


# Generated at 2022-06-26 09:01:54.668412
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    case_0 = test_case_0()
    actual = case_0
    assert actual == case_0


# Generated at 2022-06-26 09:01:57.079268
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    try:
        configurable = Configurable()
        configurable.initialize()
    except:
        pass


# Generated at 2022-06-26 09:02:00.043733
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_0.__new__(Configurable, )
    configurable_0.__new__(Configurable, (), {}, )


# Generated at 2022-06-26 09:02:03.018390
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_1 = Configurable()
    configurable_1.initialize()




# Generated at 2022-06-26 09:02:06.499879
# Unit test for function import_object
def test_import_object():
    name_0 = "tornado.escape.utf8"
    obj = import_object(name_0)
    assert obj == tornado.escape.utf8


# Generated at 2022-06-26 09:02:17.654590
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Initialization
    func = test_case_0
    name = "data"
    new_value = "new data"
    args = []
    kwargs = {}

    # Test
    test_obj = ArgReplacer(func, name)
    old_value, args, kwargs = test_obj.replace(new_value, args, kwargs)
    assert old_value is None
    assert args == []
    assert kwargs == {"data": "new data"}


# Generated at 2022-06-26 09:02:30.092984
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_0_impl_class = configurable_0.__impl_class
    configurable_0_impl_kwargs = configurable_0.__impl_kwargs
    configurable_0_impl_class = configurable_0.__impl_class
    configurable_0_impl_kwargs = configurable_0.__impl_kwargs
    configurable_0_impl_class = configurable_0.__impl_class
    configurable_0_impl_kwargs = configurable_0.__impl_kwargs



# Generated at 2022-06-26 09:02:31.751389
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 09:03:41.380438
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = Configurable()
    impl = Configurable()
    init_kwargs = {}

    configurable = Configurable()
    if base is not impl:
        if configurable is not impl:
            assert(False)

test_case_0()


# Generated at 2022-06-26 09:03:48.326704
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # First, we create an ArgReplacer object for the function
    #    def print_nums(first, second=4, third=5)
    # where 'first' is the string we should be replacing.
    #
    # For example, we might call this function as
    #    print_nums(1, second=3, third=7)
    # where the second and third arguments are named explicitly, but the first
    # is only named by position.
    #
    # We want to replace the first argument with a number, and get back the old value.
    # In this case, the old value is the object '1', but in other cases the old value
    # may be the default value.
    def print_nums(first, second=4, third=5):
        print(first, second, third)

    a = ArgReplacer