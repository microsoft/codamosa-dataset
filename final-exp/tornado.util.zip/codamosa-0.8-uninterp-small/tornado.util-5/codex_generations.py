

# Generated at 2022-06-26 08:54:06.564868
# Unit test for function import_object
def test_import_object():
    import random
    name_0 = random.sample(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'], 24)
    name_0 = ''.join(name_0)
    name_0 = name_0+'.fake_module'

    imp_0 = import_object(name_0)
    
    return imp_0



# Generated at 2022-06-26 08:54:18.441921
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test_func(arg_1, *args, **kwargs):
        pass
    arg_replacer_0 = ArgReplacer(test_func, "arg_1")
    if not isinstance(arg_replacer_0, ArgReplacer):
        raise AssertionError
    if hasattr(arg_replacer_0, "get_old_value"):
        raise AssertionError
    if hasattr(arg_replacer_0, "replace"):
        raise AssertionError
    if not hasattr(arg_replacer_0, "name"):
        raise AssertionError
    if not hasattr(arg_replacer_0, "arg_pos"):
        raise AssertionError


# Generated at 2022-06-26 08:54:28.858687
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func_0 = lambda x:x
    arg_replacer_0 = ArgReplacer(func_0, 'x')
    actual = arg_replacer_0.replace(1, (2, 3, 4), {})
    expected = (1, (2, 3, 4), {})
    assert actual == expected
    func_1 = lambda x:x
    arg_replacer_1 = ArgReplacer(func_1, 'x')
    actual = arg_replacer_1.replace(3, [1, 2, 3], {})
    expected = (1, [3], {})
    assert actual == expected
    func_2 = lambda x:x
    arg_replacer_2 = ArgReplacer(func_2, 'x')

# Generated at 2022-06-26 08:54:33.594371
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Create an instance of class Configurable
    configurable_0 = Configurable()

    # Call method initialize
    configurable_0.initialize()


# Generated at 2022-06-26 08:54:38.964295
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado

    try:
        import_object('tornado.missing_module')
        assert False
    except ImportError:
        assert True



# Generated at 2022-06-26 08:54:42.444815
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise_exc_info((None, 1, None))
    except Exception as e:
        assert e.args == (1, )



# Generated at 2022-06-26 08:54:45.873802
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyClass0(Configurable):
        def initialize(): pass
        def configurable_base(): return Configurable
        def configurable_default(): return Configurable
    my_class0_0 = MyClass0()


# Generated at 2022-06-26 08:54:47.314846
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-26 08:54:51.285430
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert(import_object('tornado.escape') is tornado.escape)
    assert(import_object('tornado.escape.utf8') is tornado.escape.utf8)
    assert(import_object('tornado') is tornado)



# Generated at 2022-06-26 08:54:55.262177
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    get_old_value_0 = ArgReplacer(test_case_0, 'gzip_decompressor')
    get_old_value_1 = get_old_value_0.get_old_value(args, kwargs)
    assert get_old_value_1 is None


# Generated at 2022-06-26 08:55:13.200936
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()

    class _Configurable_0(Configurable):
        def _initialize(self):
            pass
    _configurable_0 = _Configurable_0()
    _configurable_0.initialize()


# Generated at 2022-06-26 08:55:25.465858
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # We test this method by constructing each of the three concrete
    # implementations of Configurable in this module and checking
    # whether the right class is invoked.
    global_stub_value = 0
    class Base(Configurable):
        def configurable_base(cls):
            return Base

        def configurable_default(cls):
            return Foo

        def initialize(self):
            pass

    class Foo(Base):
        def initialize(self):
            global_stub_value = 1

    class Bar(Base):
        def initialize(self):
            global_stub_value = 2

    class Baz(Base):
        def initialize(self):
            global_stub_value = 3

    class Quux(Foo):
        pass

    Configurable.configure(Base, impl=Foo)
    assert global_stub

# Generated at 2022-06-26 08:55:30.022794
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = {'a': 1}
    obj_dict_0 = ObjectDict(d)
    assert obj_dict_0.a == 1



# Generated at 2022-06-26 08:55:31.686149
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-26 08:55:33.862141
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:55:45.797217
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Make sure that errno_from_exception returns the errno attribute
    # even if the exception's constructor did not set it as an
    # attribute.
    try:
        raise OSError(2, "No such file or directory")
    except OSError as e:
        assert errno_from_exception(e) == 2

    try:
        raise OSError("dummy error message")
    except OSError as e:
        assert errno_from_exception(e) == 0

    # Make sure that errno_from_exception handles the tuple arg style
    # of OSError correctly (which was the way it was historically
    # constructed)

# Generated at 2022-06-26 08:55:51.499031
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Configurable_0(Configurable):
        def configurable_base(self):
            pass
        def configurable_default(self):
            pass

    configurable_0 = Configurable_0()
    configurable_0.initialize()

# Generated at 2022-06-26 08:55:54.858947
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from datetime import datetime

    lis= [1,2,3]
    gzip_decompressor_0 = GzipDecompressor()


# Generated at 2022-06-26 08:55:57.758311
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # TODO implement test
    print('test_Configurable_initialize(): TODO')
    assert True


# Generated at 2022-06-26 08:56:06.841553
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    import unittest
    import tornado.testing
    import tornado.util

    class ObjectDict___getattr__TestCase(tornado.testing.AsyncTestCase):
        def test_0(self):
            gzip_decompressor_0 = GzipDecompressor()
            gzip_decompressor_0.unused_data = b'\x00'
            res = gzip_decompressor_0.unused_data
            self.assertEqual((res),(b'\x00'))
    tornado.testing.main()


# Generated at 2022-06-26 08:56:42.539961
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Implementation of method __new__ of class Configurable
    pass


# Generated at 2022-06-26 08:56:48.380291
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = {"name": "Maria"}
    assert d["name"] == "Maria"
    assert d.name == "Maria"
    assert d.get("name") == "Maria"
    assert d.get("name", "Ana") == "Maria"


# Generated at 2022-06-26 08:56:50.608128
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:56:58.308392
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    expecting_exception_0 = False
    try:
        test_Configurable_0 = Configurable()
        expecting_exception_0 = True
    except Exception as exc:
        print(exc)
        # Verify that exc is a NotImplementedError
        assert(type(exc) == NotImplementedError)
    assert(not expecting_exception_0)



# Generated at 2022-06-26 08:57:00.546482
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    config = object.__new__(Configurable)
    config.initialize("a", "b", "c")


# Generated at 2022-06-26 08:57:13.448125
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_0.initialize()

if __name__ == '__main__':
    import sys
    import optparse
    parser = optparse.OptionParser()
    parser.add_option('-v', '--verbose', action='store_true')
    options, args = parser.parse_args()
    if options.verbose:
        def say(s):
            sys.stderr.write(s + '\n')
    else:
        def say(s):
            pass
    for name in args or sorted(globals()):
        if name.startswith('test_'):
            say('%s...' % name)
            globals()[name]()
            say('ok')

# Generated at 2022-06-26 08:57:15.322796
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:57:23.015180
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    try:
        # configure the KVS to use Redis
        with redis_connection_0 as redis_instance_0:
            redis_connection_0 = redis.Redis(connection_pool=redis_pool_0)
            configurable_0.configure(redis_instance_0)
    except ValueError as exception_0:
        print(exception_0)
    # the configured class must be the same as the one
    # that was given to the configure method
    assert configurable_0.configured_class() == redis_instance_0

# Generated at 2022-06-26 08:57:24.922980
# Unit test for function import_object
def test_import_object():
    test_case_0()



# Generated at 2022-06-26 08:57:26.966755
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test case 1
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:58:08.825244
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()

# Generated at 2022-06-26 08:58:12.851586
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = Configurable.configurable_default()
    Configurable.configure(impl)
    # invoke __new__
    inststance = Configurable()
    return inststance


# Generated at 2022-06-26 08:58:14.995735
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = {"test_key": "test_value"}
    o = ObjectDict(d)
    o.__getattr__("test_key")


# Generated at 2022-06-26 08:58:29.680260
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Global variables for test_Configurable___new__.
    global gzip_decompressor_0
    global gzip_decompressor_1
    global initialized_0
    global initialized_1
    global initialized_2
    global initialized_3
    gzip_decompressor_0 = GzipDecompressor()
    GzipDecompressor.configure("tornado.util.GzipDecompressor")
    gzip_decompressor_1 = GzipDecompressor()
    initialized_0 = False
    initialized_1 = False
    initialized_2 = False
    initialized_3 = False
    class ConfigurableTestClass(Configurable):
        def initialize(self):
            global initialized_0
            global initialized_1
            global initialized_2
            global initialized_3
            initialized_0 = True

# Generated at 2022-06-26 08:58:33.030983
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0_0 = {}  # type: Dict[str, Any]

    configurable_0 = Configurable(**configurable_0_0)

# Generated at 2022-06-26 08:58:34.625178
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_0 = Configurable()


# Generated at 2022-06-26 08:58:42.938388
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    ioloop_0 = IOLoop()
    ioloop_1 = IOLoop()
    ioloop_2 = IOLoop()
    ioloop_3 = IOLoop()
    ioloop_4 = IOLoop()
    ioloop_5 = IOLoop()
    ioloop_6 = IOLoop()
    ioloop_7 = IOLoop()
    ioloop_8 = IOLoop()
    ioloop_9 = IOLoop()
    ioloop_10 = IOLoop()
    ioloop_11 = IOLoop()
    ioloop_12 = IOLoop()
    ioloop_13 = IOLoop()
    ioloop_14 = IOLoop()
    ioloop_15 = IOLoop()

# Generated at 2022-06-26 08:58:44.349149
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    gen_0 = _MultipleChoiceIterator([1, 2, 3])
    gen_0.trace_call_chain([gen_0.choice])

# Generated at 2022-06-26 08:58:47.664680
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Test method initialize of class Configurable

    # Test default behavior
    assert_equals(1,1)
    print('Unit test completed successfully')


# Generated at 2022-06-26 08:59:00.510765
# Unit test for function errno_from_exception
def test_errno_from_exception():
    errno_from_exception(OSError())
    errno_from_exception(OSError(1))

_COMPAT_UNICODE_TEST = (
    u"\u043b\u043e\u0432\u0438\u0448\u0435"
    u"\u043a\u0430\u0446"
    u"\u0435\u0432\u043e\u0439"
    u"\u0441\u0438\u043c\u0432\u043e\u043b"
    u"\u043e\u043c\u0435\u0447\u0435\u043d\u0438\u0435"
)



# Generated at 2022-06-26 08:59:36.197856
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = Configurable.configurable_default()
    base = Configurable.configurable_base()
    impl_class = impl.configurable_base()
    base.__impl_class = impl_class
    base.__impl_kwargs = {}
    if base.__impl_class is not None:
        instance = super(Configurable, base).__new__(impl_class)
        instance.initialize()


# Generated at 2022-06-26 08:59:47.209702
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable.configure("9675b476-2b8a-4f2e-904e-66a6b8f6b86a")
    # unit test for Configurable.configure()
    assert id(Configurable.configure("9675b476-2b8a-4f2e-904e-66a6b8f6b86a")) == id(Configurable)
    # unit test for Configurable.configure()
    assert id(Configurable.configure("0feb622d-e7f2-4d2b-ae0c-8385ab735658")) == id(Configurable)
    # unit test for Configurable.configure()

# Generated at 2022-06-26 08:59:50.568848
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    gzip_decompressor_0 = GzipDecompressor()

test_case_0()
test_Configurable___new__()

# Generated at 2022-06-26 08:59:53.597697
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_pet_1 = Dict[str, Any]()
    pet_0 = Configurable.__new__(Configurable)


# Generated at 2022-06-26 08:59:57.952130
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    class TestObjectDict(unittest.TestCase):
        # test function __getattr__.
        def test_getattr(self):
            obj = ObjectDict()
            obj['t'] = 1
            assert obj.t == 1

    # Run test
    suite = unittest.TestSuite()
    suite.addTest(TestObjectDict("test_getattr"))
    runner = unittest.TextTestRunner()
    runner.run(suite)


# Generated at 2022-06-26 08:59:59.898615
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_1 = Configurable()

# Generated at 2022-06-26 09:00:07.357505
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test if __new__ works without passing in extra args
    # initialize() gets called within __new__
    class MyConfigurable(Configurable):
        def initialize(self, *args, **kwargs):
            pass
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
    new_my_configurable = MyConfigurable()
    # Test if __new__ works when passing in extra args
    # initialize() gets called within __new__
    new_my_configurable_2 = MyConfigurable(1, 2, 3, 4)


# Generated at 2022-06-26 09:00:13.351198
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    x = ObjectDict()
    x['a'] = 'foo'
    try:
        x.a
    except Exception as e:
        # print('Exception in test_ObjectDict___getattr__:', e)
        pass
    else:
        assert False


# Generated at 2022-06-26 09:00:18.115633
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    try:
        test_case_0()
        return
    except Exception as e:
        print("Exception raised in test case: ", str(e))
        raise e



# Generated at 2022-06-26 09:00:20.134120
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    c1 = Configurable()
    c1.initialize()

    c2 = Configurable()
    c2.initialize()


# Generated at 2022-06-26 09:01:38.286966
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 09:01:41.508002
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # There is no test case for this method as it is only used internally.
    pass


# Generated at 2022-06-26 09:01:47.343948
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # https://github.com/tornadoweb/tornado/blob/master/tornado/util.py
    client_0 = HTTPClient()
    msg_0 = "T | TypeError: object.__new__(HTTPClient) is not safe, use HTTPClient.configured_class()"
    assert False, msg_0


# Generated at 2022-06-26 09:01:49.785396
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # case0
    test_case_0()


# Generated at 2022-06-26 09:01:52.299680
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # a = Configurable() # Call init here
    pass



# Generated at 2022-06-26 09:01:56.027230
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestBase(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestBase



# Generated at 2022-06-26 09:02:00.194512
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    params = _Params()
    params.headers["content-type"] = "text/html"
    assert params.headers["content-type"] == "text/html"
    assert params.headers["content-type"] == "text/html"


# Generated at 2022-06-26 09:02:06.737689
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test for Configurable._initialize

    # Test for Configurable.configure

    # Test for Configurable.configured_class

    # Test for Configurable.save_configuration
    saved_configuration = Configurable._save_configuration()

    # Test for Configurable.restore_configuration
    Configurable._restore_configuration(saved_configuration)


# Generated at 2022-06-26 09:02:10.090857
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_case_0()

if __name__ == '__main__':
    test_Configurable_initialize()

# Generated at 2022-06-26 09:02:10.462192
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-26 09:03:27.656586
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:03:37.754388
# Unit test for function import_object
def test_import_object():
    test_case_0()

import_object('tornado.escape')
import_object('tornado')

# Note that we cannot autodetect these, since [gs]etdefaultencoding only
# applies to the *next* call to [gs]etdefaultencoding, so if test_utf8.py
# is run with a non-utf8 default encoding we will get a false negative.
_DEFAULT_ENCODING = "utf-8"
_DEFAULT_ERRORS = "strict"

# Types for typing
AnyBytes = Union[bytes, bytearray]
AnyStr = Union[str, bytes]

# string types for PY3
if str is not bytes:
    # python3 or better
    native_str = str
else:
    # python2
    native_str = unicode

# exec returns

# Generated at 2022-06-26 09:03:42.463880
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    gzip_decompressor_0 = GzipDecompressor()
    gzip_decompressor_0.initialize(None)

if __name__ == '__main__':
    test_case_0()
    test_Configurable_initialize()