

# Generated at 2022-06-26 08:54:14.661804
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    arg_replacer_instace = ArgReplacer('test_func', 'name')
    assert arg_replacer_instace.replace('new_value', [1, 2, 3], {'name': 4}) == (4, [1, 2, 3], {'name': 'new_value'})


# Generated at 2022-06-26 08:54:25.444324
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Test get_old_value() with one argument
    my_argument_0 = ArgReplacer(test_ArgReplacer_get_old_value, "my_argument_0")
    value_0 = my_argument_0.get_old_value([1, 2, 3], {"my_argument_0": 4, "my_argument_1": 5, "my_argument_2": 6}, 7)
    value_1 = my_argument_0.get_old_value([1, 2, 3], {"my_argument_1": 5, "my_argument_2": 6}, 7)
    value_2 = my_argument_0.get_old_value([1, 2, 3], {"my_argument_2": 6}, 7)

# Generated at 2022-06-26 08:54:37.495021
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import tornado
    impl_class_0 = Configurable.configured_class()
    assert impl_class_0 == tornado.netutil.Resolver
    kwargs_0 = {}
    args_0 = ()
    instance_0 = Configurable(*args_0, **kwargs_0)
    inst_attr_0 = instance_0.__class__.__name__
    assert inst_attr_0 == 'Resolver'
    Configurable.configure(impl = 'TODO', **kwargs_0)
    impl_class_1 = Configurable.configured_class()
    assert impl_class_1 == tornado.netutil.ThreadedResolver
    kwargs_1 = {}
    args_1 = ()
    instance_1 = Configurable(*args_1, **kwargs_1)
    inst_attr_1

# Generated at 2022-06-26 08:54:45.677869
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    str_0 = '%:%ft6c(B|b6'
    str_1 = re_unescape(str_0)
    int_0 = errno_from_exception(TimeoutError())
    print(int_0)
    str_2 = '%:%ft6c(B|b6'
    str_3 = re_unescape(str_2)
    str_4 = '%:%ft6c(B|b6'
    str_5 = re_unescape(str_4)
    configured_class = Configurable.configured_class()
    instance = configured_class()
    assert(type(instance) == configured_class)


# Generated at 2022-06-26 08:54:49.936428
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    with patch("sys.stdout", new=StringIO()) as fake_out:
        ArgReplacer.get_old_value("foo.bar",("foo.bar",),{})
    assert(True)

# Generated at 2022-06-26 08:54:55.213539
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    args = [1, 2]
    kwargs = {'arg1': 1, 'arg2': 2}
    # Abstract class 'ObjectDict' is instantiated
    # Configurable class is instantiated
    # Method __new__ is equivalent to construction function
    # Arguments and keyword arguments are passed to the
    # constructor of implementations
    # Keyword arguments are saved and added to the arguments
    # passed to the constructor
    # Keyword arguments set global defaults for some parameters
    # The configured class is used if none is configured
    # The configured class is set to the class to be instantiated
    # Method __new__ is equivalent to construction function
    # Arguments and keyword arguments are passed to the
    # constructor of implementations
    # Keyword arguments are saved and added to the arguments
    # passed to the constructor
    # Keyword arguments set global defaults for some

# Generated at 2022-06-26 08:55:02.140402
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func_0 = str.translate
    arg_0 = ArgReplacer(func_0, 's')
    new_value_0 = 'a'
    _args = ['a', 'b']
    _kwargs = {'s': 'b'}
    _old_value, _args, _kwargs = arg_0.replace(new_value_0, _args, _kwargs)


# Generated at 2022-06-26 08:55:14.652369
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    x = Configurable()
    print(x.__impl_class)
    print(x.__impl_kwargs)
    print("("+str(x.configurable_base())+")")
    print("("+str(x.configurable_default())+")")
    print("("+str(x.configured_class())+")")
    print("("+str(x._save_configuration())+")")
    x._restore_configuration(x._save_configuration())
    print("("+str(x.configurable_base())+")")
    print("("+str(x.configurable_default())+")")
    print("("+str(x.configured_class())+")")
    print("("+str(x._save_configuration())+")")

# Generated at 2022-06-26 08:55:17.702490
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    for n in range(100):
        configurable = Configurable()
        configurable.initialize()

# Generated at 2022-06-26 08:55:22.353589
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(x, y):
        x_old, new_args, new_kwargs = y_replacer.replace(y, args, kwargs)
        print("x", x_old, new_args[0])
        print("y", new_args[1])
        return

    y_replacer = ArgReplacer(f, 'y')
    args = (1, 2)
    kwargs = {}
    f(99, 5)


# Generated at 2022-06-26 08:55:33.722276
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create a new object of class Configurable
    if Configurable.configured_class() is Configurable:
        Configurable.configure(None)
    obj_0 = Configurable()


# Generated at 2022-06-26 08:55:43.183396
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # create the object
    name = '%'
    func = re_unescape
    arg_replacer = ArgReplacer(func, name)
    
    # input arguments
    args = [1,2]
    kwargs = {'a':1}
    default = 2
    # execute the method
    old_value = arg_replacer.get_old_value(args, kwargs, default)
    print(old_value)


# Generated at 2022-06-26 08:55:45.978945
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c):
        pass
    test_0 = ArgReplacer(foo, 'b')

# Generated at 2022-06-26 08:55:58.261353
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # Initialization of variable obj_dict_0
    obj_dict_0 = ObjectDict()
    # Initialization of variable str_0
    str_0 = '!@4*x6U'
    # Initialization of variable str_1
    str_1 = '\+'
    obj_dict_0[str_1] = str_1
    # Assignment of variable str_2 to method __getattr__ of obj_dict_0
    str_2 = obj_dict_0.__getattr__(str_0)
    # Evaluation of result str_2
    assert str_2 == str_1
    # Evaluation of method __getattr__ of obj_dict_0

# Generated at 2022-06-26 08:55:59.824709
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()


# Generated at 2022-06-26 08:56:05.398157
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Impl(Configurable):
        def configurable_base(self):
            return Impl

        def configurable_default(self):
            return Impl,

        def initialize(self, *args, **kwargs):
            return
    
    instance = Impl()



# Generated at 2022-06-26 08:56:07.657669
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    inst = Configurable()
    inst.initialize()


# Generated at 2022-06-26 08:56:13.653960
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    try:
        raise ValueError
    except:
        bool_0 = False
        while not bool_0:
            configurable_0 = Configurable()
            bool_0 = True
    test_case_0()



# Generated at 2022-06-26 08:56:15.163609
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable = Configurable()
    configurable.initialize(1, 2, k="kkk")


# Generated at 2022-06-26 08:56:18.298247
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    deconst = Configurable.configurable_default()
    print(deconst)



# Generated at 2022-06-26 08:56:32.262751
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def testfunc(a: int, b: str, c: int, d: int) -> None:
        old_value, args, kwargs = ArgReplacer('c', testfunc).replace(500, (1, '2', 3, 4), {})
        assert args == (1, '2', 500, 4)
        assert kwargs == {}
        assert old_value == 3
        old_value, args, kwargs = ArgReplacer('f', testfunc).replace(500, (1, '2', 3, 4), {})
        assert args == (1, '2', 3, 4)
        assert kwargs == {'f': 500}
        assert old_value == None

    testfunc(1, '2', 3, 4)


# Generated at 2022-06-26 08:56:35.087343
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print("Testing method __new__ of class Configurable")
    var_0 = Configurable()
    # tests.py:48: ValueError: configuration not initialized
    var_0 = Configurable.configure(impl=None, kwargs=None)
    # tests.py:50: TypeError: Invalid subclass of Configurable
    # tests.py:53: ValueError: configuration not initialized


# Generated at 2022-06-26 08:56:41.017477
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    name = 'test'
    new_value = 'new_value'
    arg_pos = 1
    args = ("a", new_value)
    func = lambda x:x
    ArgReplacer_0 = ArgReplacer(func, name)
    ArgReplacer_0.arg_pos = arg_pos
    ArgReplacer_0.get_old_value(args, {})
    # call method .append() on object 'args'
    args.append(new_value)

# Generated at 2022-06-26 08:56:42.467420
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    a = Configurable()


# Generated at 2022-06-26 08:56:52.853392
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    print("Test ArgReplacer_replace")

    # A := True
    # B := False
    # OLD_VALUE := False
    # NEW_VALUE := True
    # __ARGS := 1 . 2 . 3 . 4 . 5 . 6 . 7 . 8 . 9 . 10 . 11 . 12
    # __KWARGS := A: False . B: False . C: True . D: True . E: True

    arg_replacer = ArgReplacer(test_case_0, "B")
    old, args, kwargs = arg_replacer.replace(True, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], { "A": False, "B": False, "C": True, "D": True, "E": True })
    assert old == False

# Generated at 2022-06-26 08:56:55.261489
# Unit test for function import_object
def test_import_object():
    var_0 = import_object('http.server')
    if type(var_0) != type:
        return (1, 'Line :120')
    return (0, None)


# Generated at 2022-06-26 08:57:05.258932
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    __args = ["new_value", "args", "kwargs"]
    __error_indices = [[0, 2], [0, 1]]
    __error_arguments = [
        (
            "new_value",
            "args",
            "kwargs",
        ),
        (
            "new_value",
            "args",
            "kwargs",
        ),
    ]
    __return_index = [0, 1, 2]
    __return_arguments = [("old_value", "args", "kwargs",)]
    __return_value = [None]
    __return = [("old_value", "args", "kwargs",)]

# Generated at 2022-06-26 08:57:08.057160
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    #
    # Test for method __new__ of class Configurable
    #
    pass


# Generated at 2022-06-26 08:57:12.263331
# Unit test for function import_object
def test_import_object():
    # AssertionError
    import_object('x') is tornado.escape
    import_object('x.y.z') is tornado.escape.utf8
    import_object('tornado') is tornado
    import_object('tornado.missing_module')


# Generated at 2022-06-26 08:57:16.631047
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # mock of class Configurable
    class Configurable(object):
        def __new__(cls, *args, **kwargs):
            return None
    test_instance = Configurable()
    test_case_0()


# Generated at 2022-06-26 08:57:27.977371
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj_dict_0 = ObjectDict()
    # line: str = ""
    # line: str = ""
    # line: str = ""
    # line: str = ""


# Generated at 2022-06-26 08:57:29.916322
# Unit test for function import_object
def test_import_object():
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado


# Generated at 2022-06-26 08:57:30.755166
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass


# Generated at 2022-06-26 08:57:43.747467
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from tornado.web import Application
    from tornado.web import RequestHandler
    from tornado.ioloop import IOLoop
    from tornado.http1connection import HTTP1ServerConnection
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

# AsyncIOMainLoop.install()
# AsyncIOMainLoop().install()
    loop = IOLoop(make_current=True)
    app = Application([(r'/', ArgReplacerTestHandler),
                       (r'/gzip', GzipArgReplacerTestHandler)])
    app.listen(8888)
    IOLoop.current()
# IOLoop.current().start()


# Generated at 2022-06-26 08:57:47.594616
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    try:
        configurable_0.initialize()
    except NotImplementedError:
        pass


# Generated at 2022-06-26 08:57:52.892013
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

    t = MyConfigurable()


# Generated at 2022-06-26 08:57:57.482940
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    instance_0 = ArgReplacer(test_case_0, 'gzip')
    instance_0.get_old_value((), {}, None)


# Generated at 2022-06-26 08:58:05.377692
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func_0 = test_case_0
    arg_replacer_0 = ArgReplacer(func_0, 'decompressor')
    gzip_decompressor_0 = GzipDecompressor()
    assert arg_replacer_0.get_old_value( (), {'decompressor':gzip_decompressor_0} ) == gzip_decompressor_0


# Generated at 2022-06-26 08:58:14.153988
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_case_0()
    def w(x, y):
        return x + y
    args_0 = [1, 2]
    kwargs_0 = {}
    replacer_0 = ArgReplacer(w, 'x')
    result_0 = replacer_0.replace(2, args, kwargs)
    assert result_0 == (1, [2, 2], {})


# Generated at 2022-06-26 08:58:16.103106
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    replacer = ArgReplacer(a, "name")
    assert replacer.get_old_value(a, b, None) == None


# Generated at 2022-06-26 08:58:29.413682
# Unit test for function import_object
def test_import_object():
    from tornado.escape import json_encode, json_decode, utf8
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    with pytest.raises(ImportError):
        import_object('tornado.missing_module')



# Generated at 2022-06-26 08:58:37.491314
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    print('Pass!')

if __name__ == '__main__':
    test_case_0()
    test_import_object()

# Generated at 2022-06-26 08:58:40.261677
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    a = ArgReplacer()
    old_value = a.get_old_value(None, None)


# Generated at 2022-06-26 08:58:48.440843
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a, b=10, c=20):
        pass
    arg_replacer_0 = ArgReplacer(test, 'b')
    default_value = int()
    old_value_0 = arg_replacer_0.get_old_value((int(),), {}, default_value)
    if __name__ == '__main__':
        print(old_value_0)



# Generated at 2022-06-26 08:58:59.504385
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise ValueError("Hello")
    except ValueError as ve:
        errno = errno_from_exception(ve)
        if errno != None:
            print(errno)
        else:
            print("errno is None")

    try:
        raise ValueError
    except ValueError as ve:
        errno = errno_from_exception(ve)
        if errno != None:
            print(errno)
        else:
            print("errno is None")


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 08:59:10.403759
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    args = [1, 2, 3]
    kwargs = {"a": 1, "b": 2, "c": 3}
    arg_replacer = ArgReplacer(test_ArgReplacer_replace, "b")
    old_value, args, kwargs = arg_replacer.replace(99, args, kwargs)
    assert old_value == 2
    assert args == [1, 99, 3]
    assert kwargs == {"a": 1, "b": 99, "c": 3}


# Generated at 2022-06-26 08:59:16.967609
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class _Func(object):
        def __init__(self, name, args, kwargs):
            self.name = name 
            self.args = list(args)
            self.kwargs = dict(kwargs)

        def _getargnames(self, func):
            return [self.name]

        def get_old_value(self, *args, **kwargs):
            return self.name, self.args, self.kwargs

        def replace(self, v, *args, **kwargs):
            self.value = v

    r = ArgReplacer(_Func('a', [1], {}), 'a')
    assert r.replace(2, [1], {}) == (1, [1], {})

# Generated at 2022-06-26 08:59:19.685181
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_1 = Configurable()
    configurable_1.initialize()

# Generated at 2022-06-26 08:59:21.841135
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    
    configurable_obj = Configurable()
    pass



# Generated at 2022-06-26 08:59:31.096914
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    try:
        gzip_decompressor_1 = GzipDecompressor()
        args = []
        kwargs = {"wbits": 16}
        arg_replacer_0 = ArgReplacer(GzipDecompressor, "wbits")
        assert arg_replacer_0.get_old_value(args, kwargs) == 16
    except:
        import traceback
        traceback.print_exc()


# Generated at 2022-06-26 08:59:43.942143
# Unit test for function errno_from_exception
def test_errno_from_exception():
    e = Exception(1)
    if errno_from_exception(e) == 1:
        print("~ test_errno_from_exception() passed")
    else:
        print("~ test_errno_from_exception() failed")

#test_errno_from_exception()


# Generated at 2022-06-26 08:59:46.374034
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    unittest.skip('Not Implemented')



# Generated at 2022-06-26 08:59:55.622968
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    GzipDecompressor.configure = configure
    GzipDecompressor.configure()

    func = GzipDecompressor
    name = "wbits"
    default = -15

    arg_replacer = ArgReplacer(func, name)

    new_value = -15
    args = [None, None] # type: Sequence[Any]
    kwargs = {"wbits": new_value, "zdict": None} # type: Dict[str, Any]

    assert arg_replacer.get_old_value(args, kwargs, default) == new_value



# Generated at 2022-06-26 09:00:06.930805
# Unit test for method initialize of class Configurable

# Generated at 2022-06-26 09:00:13.059403
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    dic = ObjectDict()
    dic.x = 10
    dic.y = 20
    x = dic.__getattr__('x')
    y = dic.__getattr__('y')
    r = x + y
    return r


# Generated at 2022-06-26 09:00:19.813969
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    unit = ArgReplacer("foo", 1)
    result = unit.replace("foo", 1, 2)
    assert result == (1, 2)

if __name__ == "__main__":
    test_case_0()
    test_ArgReplacer_replace()

# Generated at 2022-06-26 09:00:24.806976
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    _args = ["a"]
    _kwargs = {"1": "a"}
    _arg_replacer_0 = ArgReplacer(lambda: 0, "1")
    _arg_replacer_0.replace("a", _args, _kwargs)[0]
    _arg_replacer_0.replace("a", _args, _kwargs)[1][0]
    _arg_replacer_0.replace("a", _args, _kwargs)[2]["1"]


# Generated at 2022-06-26 09:00:27.443219
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # TODO: Implement test_Configurable___new__
    return


# Generated at 2022-06-26 09:00:38.934240
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # class tornado.util.Configurable(object)
    # Configuration interface for `.Configurable`.
    #
    # See Also:
    # `Configurable <http://www.tornadoweb.org/en/stable/tcpserver.html#tornado.tcpserver.TCPServer>`_
    # `.AsyncHTTPClient`
    # `.AsyncHTTPClient <http://www.tornadoweb.org/en/stable/asyncio.html#tornado.platform.asyncio.AsyncIOMainLoop>`_
    #
    # A configurable interface is an (abstract) class whose constructor
    # acts as a factory function for one of its implementation subclasses.
    # The implementation subclass as well as optional keyword arguments to
    # its initializer can be set globally at runtime with `configure`.
    teardown_

# Generated at 2022-06-26 09:00:43.823786
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print("")
    print("Testing '__new__' method of Configurable")
    # TODO: write unit test for method __new__ of class Configurable


# Generated at 2022-06-26 09:01:07.589207
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    print('Testing class method initialize of class Configurable')
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 09:01:15.446195
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # 1. Create a new class 'Example'
    class Example(Configurable):
        def configurable_base():
            return Example

        def configurable_default():
            return DefaultExample

    # 1.1 Create a new class 'DefaultExample'
    class DefaultExample(Example):
        pass

    # 2. Create an instance of default class 'DefaultExample'
    ex0 = Example._Configurable__new__(Example)

    # 3. Create a new class 'NewExample'
    class NewExample(Example):
        pass

    # 4. Configure class
    Example.configure(NewExample)

    # 5. Create a new instance of 'NewExample'
    ex1 = Example._Configurable__new__(Example)

    # 6. Test
    if type(ex0) is not DefaultExample:
        raise Exception

# Generated at 2022-06-26 09:01:27.279716
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    s_0 = 'abc'
    list_0 = [None] * 5
    list_0[1] = 1
    list_0[3] = 3
    list_0[4] = 4
    dict_0 = dict()
    dict_0['1'] = 1
    dict_0['3'] = 3
    dict_0['4'] = 4
    arg_replacer_0 = ArgReplacer(test_case_0, s_0)
    #assert s_0 == "abc"
    #assert list_0 == [None, 1, None, 3, 4]
    #assert dict_0 == {"1": 1, "3": 3, "4": 4}
    #assert arg_replacer_0.name == "abc"

# Generated at 2022-06-26 09:01:38.729029
# Unit test for function errno_from_exception
def test_errno_from_exception():
    test_errno = 1
    test_exception_args = ("test",)
    test_exception_1 = OSError(test_errno, test_exception_args)
    assert errno_from_exception(test_exception_1) == test_errno

    test_exception_2 = OSError(test_exception_args)
    assert errno_from_exception(test_exception_2) == test_exception_args[0]

    test_exception_3 = OSError()
    assert errno_from_exception(test_exception_3) is None


# Generated at 2022-06-26 09:01:50.884502
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class A:
        def b(self, a, b):
            pass
    arg_replacer_0 = ArgReplacer(A().b, 'a')
    (old_value_2, args_2, kwargs_2) = \
        arg_replacer_0.replace(123, (1, 2), {'a': 2, 'b': 3})
    assert (args_2 == (123, 2))
    assert (kwargs_2 == {'a': 2, 'b': 3})
    assert (old_value_2 == 1)
    arg_replacer_1 = ArgReplacer(A().b, 'c')

# Generated at 2022-06-26 09:01:53.766264
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable = Configurable()
    assert isinstance(configurable, Configurable)


# Generated at 2022-06-26 09:02:00.805162
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    t_0 = Configurable()
    t_1 = Configurable("httpclient")
    t_2 = Configurable("httpclient", {})
    t_3 = Configurable("httpclient", {}, {})
    t_4 = Configurable("httpclient", {}, {}, some_arg="some_value")


# Generated at 2022-06-26 09:02:07.755818
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.util import Configurable

    # Configurable(...)
    # Configurable.configure(...)
    # Configurable.configured_class()
    # Configurable.configurable_base()
    # Configurable.configurable_default()
    # Configurable.initialize(...)

    print(Configurable)
    print(Configurable.configure)
    print(Configurable.configured_class)
    print(Configurable.configurable_base)
    print(Configurable.configurable_default)
    print(Configurable.initialize)


# Generated at 2022-06-26 09:02:19.912975
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    @classmethod
    def test_some_func(cls, key: str, value: str, name: str) -> str:
        pass
    test_arg_replacer_0 = ArgReplacer(test_some_func, "name")
    test_arg_replacer_0.get_old_value([], {"key":"test", "name":"test", "value":"test"})
    test_arg_replacer_0.get_old_value([], {"value":"test", "key":"test"})
    test_arg_replacer_0.get_old_value([], {"value":"test"}, default="test")
    test_arg_replacer_0.get_old_value(["test", "test"], {"name":"test"})

# Generated at 2022-06-26 09:02:22.945759
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    str_0 = str(configurable_0)
    print(str_0)


# Generated at 2022-06-26 09:02:55.681503
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def dummy_decompress(data, decompress):
        return (decompress(data))
    dummy_decompress_args=[('arg1', 'arg2'),{'arg':'arg', 'decompress': 'decompress'}]
    arg_replacer_0 = ArgReplacer(dummy_decompress, 'decompress')
    decompress_mock = mock.create_autospec(dummy_decompress)
    old_value, args_ret, kwargs_ret = arg_replacer_0.replace('new_decompress',*dummy_decompress_args)
    dummy_decompress(*args_ret, **kwargs_ret)
    decompress_mock.assert_called_once()


# Generated at 2022-06-26 09:02:56.903247
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    assert Configurable.__new__ is Configurable._Configurable__new__


# Generated at 2022-06-26 09:03:06.608285
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    cls_0 = Configurable
    impl_0 = None
    kwargs_0 = {}
    if impl_0 is not None and not issubclass(impl_0, cls_0):
        raise ValueError("Invalid subclass of %s " % cls_0)
    base_0 = cls_0.configurable_base()
    base_0.__impl_class = impl_0
    base_0.__impl_kwargs = kwargs_0
    instance = super(Configurable, cls_0).__new__(impl_0)
    if instance is not None and not isinstance(instance, cls_0):
        raise ValueError("Invalid subclass of %s " % cls_0)


# Generated at 2022-06-26 09:03:07.468545
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    demo_configurable_0 = Configurable()


# Generated at 2022-06-26 09:03:12.768434
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.ioloop import IOLoop

    # Call __new__ method of Configurable.
    # Note: IOLoop is a subclass of Configurable.
    ioloop = IOLoop()

    # Call __new__ method of Configurable.
    # Note: IOLoop is a subclass of Configurable.
    test_case_0()


# Generated at 2022-06-26 09:03:23.084518
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ArgsImpl(Configurable):
        @classmethod
        def configurable_base(cls):
            return ArgsImpl

        @classmethod
        def configurable_default(cls):
            return ArgsImpl

        def initialize(self, name, value):
            self.name = name
            self.value = value

    ArgsImpl.configure(ArgsImpl)
    args_impl_0 = ArgsImpl(
        "Rc8",
        "5jJCTgY#r[rqB5qy(?Xy1'UlI]DvQPWx_<JnK{",
    )
    assert args_impl_0.name == "Rc8"

# Generated at 2022-06-26 09:03:33.096092
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_arg_0 = ArgReplacer(test_case_0, 'exc_info')
    test_arg_1 = test_arg_0.replace('new_value', ('args', 'kwargs'))
    assert test_arg_1 == (None, ['args'], {'exc_info': 'new_value', 'kwargs': 'kwargs'})

    test_arg_0 = ArgReplacer(test_case_0, 'exc_info')
    test_arg_1 = test_arg_0.replace('new_value', ('args', 'kwargs'))
    assert test_arg_1 == (None, ['args'], {'exc_info': 'new_value', 'kwargs': 'kwargs'})


# Generated at 2022-06-26 09:03:44.202384
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_0(arg_0):
        pass
    argreplacer_0 = ArgReplacer(func_0, 'arg_0')
    if True:
        args = ()
        kwargs = {'arg_0': 0}
    else:
        args = (0,)
        kwargs = {}
    old_value, args, kwargs = argreplacer_0.replace(42, args, kwargs)
    assert old_value == 0

    def func_1(arg_0):
        pass
    argreplacer_1 = ArgReplacer(func_1, 'arg_0')
    if True:
        args = ()
        kwargs = {}
    else:
        args = (0,)
        kwargs = {'arg_0': 0}
    old_value, args, kw