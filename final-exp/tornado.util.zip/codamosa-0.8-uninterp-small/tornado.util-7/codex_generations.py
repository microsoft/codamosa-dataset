

# Generated at 2022-06-26 08:54:08.740684
# Unit test for function import_object
def test_import_object():
    try:
        from tornado.escape import utf8
    except ImportError:
        print("SKIP")
        raise unittest.SkipTest("tornado.escape not importable")
    assert import_object("tornado.escape") is escape
    assert import_object("tornado.escape.utf8") is utf8
    assert import_object("tornado") is tornado
    assert import_object("tornado.util") is util
    try:
        import_object("tornado.missing_module")
        assert False, "did not get expected exception"
    except ImportError:
        pass


# Generated at 2022-06-26 08:54:19.403213
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    #
    # Verify that ArgReplacer.replace works for positional arguments
    #
    def foo(x, y):
        pass

    # Test replacing the first argument
    old_value, args, kwargs = ArgReplacer(foo, "x").replace(100, (1, 2), {})
    assert old_value == 1
    assert args == (100, 2)

    # Test replacing the second argument
    old_value, args, kwargs = ArgReplacer(foo, "y").replace(200, (1, 2), {})
    assert old_value == 2
    assert args == (1, 200)

    # Test replacing the first argument when some arguments are omitted
    old_value, args, kwargs = ArgReplacer(foo, "x").replace(100, (1,), {})
    assert old_value == 1

# Generated at 2022-06-26 08:54:20.892040
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Set up test objects
    obj = Configurable()
    # Execute the method under test
    try:
        obj.initialize()
    except:
        pass
    # Check the results


# Generated at 2022-06-26 08:54:24.953753
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise TypeError()
    except:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)

# Doctest for function raise_exc_info

# Generated at 2022-06-26 08:54:28.528976
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Test 0:
    var_0 = ArgReplacer(doctests, "name")
    var_1 = var_0.get_old_value((doctests,), {}, None)
    assert var_1 == doctests


# Generated at 2022-06-26 08:54:36.451486
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    var_0 = ArgReplacer(doctests,'func')
    var_1 = var_0.get_old_value((),{'func': doctests},None)
    assert var_1 == doctests, 'AssertionError: %s != %s' % (str(var_1),str(doctests))



# Generated at 2022-06-26 08:54:42.916050
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestCls:
        def initialize(self, **kwargs):
            self.arg_0 = kwargs.get('arg_0')
    test_instance = TestCls()
    test_instance_1 = TestCls(arg_0 = 0)
    # Check that argument arg_0 had a value assigned
    assert test_instance_1.arg_0 == 0
    # Check that argument arg_0 did not have a value assigned
    assert not hasattr(test_instance, 'arg_0')


# Generated at 2022-06-26 08:54:49.236635
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer = ArgReplacer()
    args = ()
    kwargs = {}
    default = 'default'
    result = arg_replacer.get_old_value(args, kwargs, default)
    assert result == default


# Generated at 2022-06-26 08:54:51.593106
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Try to create an instance of class Configurable
    var_0 = Configurable()


# Generated at 2022-06-26 08:54:54.250916
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        if errno_from_exception(e) is None:
            return True
    return False


# Generated at 2022-06-26 08:55:12.971333
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create mock object with fixed side effects
    class mock_cls(Configurable):
        # Type: (...) -> typing.NoReturn
        def __new__(self, *args, **kwargs):
            return raise_exc_info
    #
    # Create object with variable side effects
    var_0 = mock_cls()
    #
    # Call method
    var_1 = Configurable.__new__(var_0)
    #
    # Check return value
    assert var_1 == raise_exc_info
    #
    # Check if the side effects were applied


# Generated at 2022-06-26 08:55:18.007114
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    glob_0 = globals()
    loc_0 = locals()
    impl = Configurable()
    glob_0['impl'] = impl
    loc_0['impl'] = impl
    impl._initialize()


# Generated at 2022-06-26 08:55:21.924300
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    obj = ArgReplacer("doctests", "object_pairs_hook")
    assert obj.replace("new_value", "args") == ("None", "args")



# Generated at 2022-06-26 08:55:22.813770
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    assert Configurable().initialize()


# Generated at 2022-06-26 08:55:24.559872
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    var_0 = ObjectDict({'a': 1, 'b': 2})
    var_1 = var_0.a
    var_2 = var_0.b
    var_3 = var_0.c


# Generated at 2022-06-26 08:55:28.961644
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise KeyError
    except:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)
    raise AssertionError('Should have raised an exception')


# Generated at 2022-06-26 08:55:39.826939
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer_0 = ArgReplacer(str, str)

# Generated at 2022-06-26 08:55:47.949034
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # pylint: disable=missing-docstring
    def _test_wrap(func):
        # type: (Callable) -> Callable[..., Any]
        @functools.wraps(func)
        def wrapper(self: Type[UnitTest], *args: Any, **kwargs: Any) -> Any:
            # pylint: disable=missing-docstring
            saved = ArgReplacer(func, "callback").get_old_value(args, kwargs, None)

# Generated at 2022-06-26 08:55:57.902043
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    from tornado.util import ObjectDict
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future

    class T(AsyncTestCase):

        def test_0(self):
            # Line 144
            o = ObjectDict({"a": 3, "b": 4})
            self.assertEqual(o.a, 3)
            self.assertEqual(o.b, 4)
            var_0 = o.__dict__
            self.assertEqual(var_0, {"a": 3, "b": 4})
            self.assertRaises(AttributeError, lambda: o.c)

    T().test_0()


# Generated at 2022-06-26 08:55:59.603803
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise Exception('test')
    except Exception as e:
        raise_exc_info((e.__class__, e, e.__traceback__))



# Generated at 2022-06-26 08:56:16.110429
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Initialize a Configurable subclass instance.
    #
    # Configurable classes should use _initialize instead of __init__.
    class Configurable_0_test(Configurable):
        def __init__(self, *args, **kwargs):
            self.initialize(*args, **kwargs)
        def initialize(self, *args, **kwargs):
            pass
    configurable_0_test_0 = Configurable_0_test()
    configurable_0_test_0._initialize()


# Generated at 2022-06-26 08:56:29.592812
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_arg_replacer_0(arg_replacer_0: str) -> str:
        return arg_replacer_0
    arg_replacer_0 = ArgReplacer(func_arg_replacer_0, "arg_replacer_0")
    old_value_arg_replacer_0, old_value_arg_replacer_1, old_value_arg_replacer_2 = arg_replacer_0.replace("", (), {})
    assert old_value_arg_replacer_0 == None
    assert old_value_arg_replacer_1 == []
    assert old_value_arg_replacer_2 == {}
    #
    def func_arg_replacer_1(arg_replacer_0: str = "") -> str:
        return arg_replacer_0
    arg_replacer

# Generated at 2022-06-26 08:56:31.499489
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_case_configurable_0 = Configurable()
    test_case_configurable_0.initialize()

if __name__ == "__main__":
    test_case_0()
    test_Configurable_initialize()

# Generated at 2022-06-26 08:56:38.460686
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # case 0
    gzip_decompressor_0 = GzipDecompressor()
    def foo_0(x,y):
        return x**y
    old_value = gzip_decompressor_0.get_old_value(foo_0(x=2,y=4), args, kwargs)
    assert old_value == 16


# Generated at 2022-06-26 08:56:50.736679
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Arrange
    test_function = test_case_0
    test_param_name = "decompress"
    test_param_value = "test_value"
    expected_result = "test_value"
    test_arg_replacer = ArgReplacer(test_function, test_param_name)

    # Act
    actual_result = test_arg_replacer.get_old_value(args = (), kwargs = {test_param_name: test_param_value}, default = "test_default")

    # Assert
    assert expected_result == actual_result, "Expected value is %s but the actual value is %s" % (expected_result, actual_result)


# Generated at 2022-06-26 08:57:02.494609
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # test String type
    args = [1, None, 'b', 'c']
    kwargs = {}
    args_2 = args
    kwargs_2 = kwargs.copy()
    old_value, args_2, kwargs_2 = ArgReplacer('b').replace('a', args_2, kwargs_2)
    # expected:
    # old_value = 'b'
    # args_2 = [1, None, 'a', 'c']
    # kwargs_2 = {}
    assert(old_value == 'b' and args_2 == [1, None, 'a', 'c'] and kwargs_2 == {}), "Failed test_ArgReplacer_replace"
    # test number type
    args = [1, None, 'b', 'c']
    kw

# Generated at 2022-06-26 08:57:14.432486
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Test the get_old_value method in the following way:
    # 1. Call the method on the initialized ArgReplacer object.
    #    Check that the return value is as expected.
    # 2. Call the method on the initialized ArgReplacer object with
    #    a default value. Check that the return value is as expected.

    def func_0(a, b, c):
        pass

    arg_replacer_0 = ArgReplacer(func_0, 'a')
    l_0 = ['a', 'b', 'c']
    l_1 = ['a', 'b', 'c']
    l_2 = ['a', 'b', 'c']
    assert arg_replacer_0.get_old_value(l_0, l_1) == 'a'
    assert arg_replacer_0.get_old

# Generated at 2022-06-26 08:57:18.527439
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test_func_0(arg1, arg2):
        return arg1, arg2

    arg_replacer_0 = ArgReplacer(test_func_0, "arg1")


# Generated at 2022-06-26 08:57:19.999517
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    a = Configurable()


# Generated at 2022-06-26 08:57:26.150511
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    # test 2
    try:
        configurable_0.configure(None, {})
        configurable_1 = Configurable()
        configurable_1.initialize()
    except Exception as e:
        print("EXCEPTION: {}".format(e))


if __name__ == '__main__':
    # unit test for class TimeoutError
    test_case_0()

    test_Configurable___new__()

    print("All tests passed!")

# Generated at 2022-06-26 08:58:07.146515
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    logger = logging.getLogger()
    test_func = logging.basicConfig
    arg_replacer_0 = ArgReplacer(test_func, "filename")
    args = [__file__]
    kwargs = {'level': DEBUG}
    old_val, args, kwargs = arg_replacer_0.replace("new_filename", args, kwargs)
    assert(old_val == __file__)
    assert(args[0] == "new_filename")
    assert(kwargs['level'] == DEBUG)

if __name__ == '__main__':
    test_ArgReplacer_replace()

# Generated at 2022-06-26 08:58:11.834671
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    Configurable.configure(impl = None, **{})
    assert Configurable.configured_class() == Any
    assert Configurable._save_configuration() == (None, {})

# Generated at 2022-06-26 08:58:14.435859
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:58:17.298265
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Create ArgReplacer object
    arg_rep_0 = ArgReplacer(gzip_decompressor_0.decompress, 'size')
    # Test get_old_value function
    assert arg_rep_0.get_old_value() == 0


# Generated at 2022-06-26 08:58:30.320607
# Unit test for function errno_from_exception
def test_errno_from_exception():
    e = Exception()
    assert errno_from_exception(e) is None
    e = Exception("test")
    assert errno_from_exception(e) == "test"
    e = Exception(10)
    assert errno_from_exception(e) == 10
    e = Exception(10, "test")
    assert errno_from_exception(e) == 10
    e = Exception(errno=10, strerror="test")
    assert errno_from_exception(e) == 10

byte_types = (bytes, bytearray)  # type: Tuple[type, ...]

# Fake byte literal support:  In python 2, literal strings are bytestrings
# and there is no way to have a literal that is not of type str.  In python 3,
# bytes literals are

# Generated at 2022-06-26 08:58:39.471998
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func_0 = test_case_0
    arg_replacer_0 = ArgReplacer(func_0, "")
    test_args_0 = ()
    test_kwargs_0 = {"": ""}
    default_value_0 = ""
    output_0 = arg_replacer_0.get_old_value(test_args_0, test_kwargs_0, default_value_0)
    print(output_0)
    print(type(output_0))
    return output_0


# Generated at 2022-06-26 08:58:41.782469
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()


# Generated at 2022-06-26 08:58:47.451254
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    expected = (None, [1, 2, 3, 4], {'name': 5})
    actual = ArgReplacer('name').replace(5, [1, 2, 3, 4], {})
    assert(expected == actual)


# Generated at 2022-06-26 08:58:50.035285
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:59:01.266635
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    test_args = [1, 2, 3, 4]
    test_kwargs = {'arg1': 1, 'arg2': 2, 'arg3': 3, 'arg4': 4}
    test_func = lambda x, y, z, a: (x, y, z, a)
    test_name = 'arg2'
    def test_func_0(x, y, z, a):
        return (x, y, z, a)
    ArgReplacer_instance = ArgReplacer(test_func_0, test_name)
    test_result = ArgReplacer_instance.get_old_value(test_args, test_kwargs)
    assert test_result == 2, test_result


# Generated at 2022-06-26 08:59:33.116811
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    with pytest.raises(ValueError):
        ArgReplacer(test_case_0, "gzip_decompressor_0")


# Generated at 2022-06-26 08:59:36.802796
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    instance = ArgReplacer(test_case_0, "code")
    assert instance.get_old_value([], {}) is None


# Generated at 2022-06-26 08:59:42.440200
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """Unit test for method __new__ of class Configurable"""
    configurable_0 = Configurable.__new__(Configurable)
    configurable_1 = Configurable.__new__(Configurable, [(int)])


# Generated at 2022-06-26 08:59:55.785890
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    logger = logging.getLogger('test_ArgReplacer_replace')
    logger.info('Start test of ArgReplacer.replace')

    def wrapper_0(func, cb):
        return func(cb)

    def wrapper_1(func, cb):
        return func(cb)

    def wrapper_2(func, cb):
        return func(cb)
    
    def test_0(cb):
        logger.info('test_0 called')
        return cb

    def test_1(cb):
        logger.info('test_1 called')
        return cb

    def test_2(cb):
        logger.info('test_2 called')
        return cb

    def cb_0():
        logger.info('cb_0 called')
    

# Generated at 2022-06-26 09:00:04.603511
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class T(Configurable):
        def configurable_base(self):
            return T
        def configurable_default(self):
            return T

    # Test instantiating an unconfigured subclass
    T().initialize()
    # Test subclassing a configured class
    class A(T):
        pass
    # Test that configure only affects the top-level configurable class
    T.configure(T)
    A().initialize()
    A.configure(A)
    A().initialize()


# Generated at 2022-06-26 09:00:10.019599
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    get_old_value_arg_replacer = ArgReplacer(func = test_case_0, name = 'decompressor')
    get_old_value_arg_replacer.get_old_value(args = [], kwargs = {}, default = None) 



# Generated at 2022-06-26 09:00:20.057060
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class MyClass:
        def my_method(self, a, b, c):
            pass

    assert ArgReplacer(MyClass.my_method, "c").replace(100, (1, 2, 3), {}) == (3, (1, 2, 100), {})
    assert ArgReplacer(MyClass.my_method, "b").replace(100, (1, 2, 3), {}) == (2, (1, 100, 3), {})
    assert ArgReplacer(MyClass.my_method, "a").replace(100, (1, 2, 3), {}) == (1, (100, 2, 3), {})
    assert ArgReplacer(MyClass.my_method, "d").replace(100, (1, 2, 3), {}) == (None, (1, 2, 3), {"d": 100})



# Generated at 2022-06-26 09:00:21.379972
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    impl = Configurable()
    impl.initialize()


# Generated at 2022-06-26 09:00:25.139755
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    test_case_ArgReplacer_0()  # type: ignore
    test_case_ArgReplacer_1()  # type: ignore


# Generated at 2022-06-26 09:00:33.687202
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(arg_int, arg_str='', *args, **kwargs):
        pass

    arg_replacer_0 = ArgReplacer(test_func, 'arg_str')
    old_value = arg_replacer_0.get_old_value(['__main__', '__main__.py'], {'arg_int':1}, '')

# Generated at 2022-06-26 09:01:58.925987
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()

if __name__ == '__main__':
    test_Configurable___new__()

# Generated at 2022-06-26 09:02:03.761928
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print ("Testing method Configurable.__new__")
    obj_0 = Configurable()
    assert isinstance(obj_0, Configurable)
    assert obj_0.configurable_base() is Configurable


# Generated at 2022-06-26 09:02:10.072865
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f0(a: str, b: int) -> None:
        return
    t0 = ArgReplacer(f0, 'a')
    t1 = t0.replace('111', ('222', None), {'b': 1})
    assert t1[0] == '222' and t1[1][0] == '111'
    t2 = t0.replace('123', ('234', 345), {'a': '456', 'b': 4567})
    assert t2[0] == '456' and t2[1][0] == '234'
    t3 = t0.replace('123', ('234', 345), {'b': 4567})
    assert t3[0] == None and t3[1][0] == '234'



if __name__ == "__main__":
    import inspect


# Generated at 2022-06-26 09:02:17.576494
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    aList = [1, 2, 3]
    aDict = {'a': 1, 'b': 2}
    aArgReplacer = ArgReplacer(test_ArgReplacer_get_old_value, 'aDict')
    aArgReplacer.get_old_value(aList, aDict)


# Generated at 2022-06-26 09:02:22.736672
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_case_ArgReplacer_replace_0()
    test_case_ArgReplacer_replace_1()


# Generated at 2022-06-26 09:02:28.566517
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Get function under test
    args = [1,2,3]
    kwargs = {'foo': 'bar'}
    func = ArgReplacer(test_case_0, 'args')
    old_value = func.get_old_value(args, kwargs)
    assert(old_value == [1,2,3])


# Generated at 2022-06-26 09:02:38.614411
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    gzip_decompressor_1 = GzipDecompressor()
    s = "0123456789"
    arg_replacer_0 = ArgReplacer(gzip_decompressor_1.decompress, "max_length")
    old_value = arg_replacer_0.get_old_value((gzip_decompressor_1, s), {})
    new_value = 3
    old_value, args, kwargs = arg_replacer_0.replace(new_value, (gzip_decompressor_1, s), {})
    assert old_value == None
    assert args[1] == "0"

if __name__ == "__main__":
    test_ArgReplacer_replace()

# Generated at 2022-06-26 09:02:47.674880
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import_object_0 = import_object('str')
    configurable__configured_class_0 = Configurable.configured_class()
    configurable__initialize_0 = Configurable.initialize
    configurable__configure_0 = Configurable.configure(import_object_0)
    configurable_1 = Configurable()
    configurable_2 = Configurable(configurable__configured_class_0)
    configurable_3 = Configurable(configurable__initialize_0)
    configurable_4 = Configurable(configurable__configure_0)

if __name__ == '__main__':

    test_case_0()
    test_Configurable___new__()
    time.sleep(0.1)

# Generated at 2022-06-26 09:02:59.089666
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    string_0 = 'tornado.util.ArgReplacer.get_old_value'
    string_1 = 'tornado.concurrent.Future.obj.is_ready'
    string_2 = 'tornado.util.ArgReplacer.get_old_value.if_instance'
    string_3 = 'tornado.util.ArgReplacer.get_old_value.if_instance.kwargs'
    string_4 = 'tornado.util.ArgReplacer.get_old_value.if_instance.set'
    list_0 = ['tornado.util.ArgReplacer.get_old_value.if_instance.dict']
    list_1 = ['tornado.concurrent.Future.obj.is_ready.try_call']
    list_2 = [string_2]

# Generated at 2022-06-26 09:03:01.445206
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def example_function(arg1, arg2, arg3):
        pass

    arg_replacer = ArgReplacer(example_function, "arg1")
