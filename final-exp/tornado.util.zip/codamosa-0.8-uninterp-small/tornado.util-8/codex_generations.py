

# Generated at 2022-06-26 08:54:14.355825
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    c = Configurable()


# Generated at 2022-06-26 08:54:15.196178
# Unit test for function import_object
def test_import_object():
    test_case_0()

    if __name__ == "__main__":
        test_import_object()
        print("Test finished.")

# Generated at 2022-06-26 08:54:21.219296
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    class Test():
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    args = [1, 2, 'hi']
    kwargs = {}
    arg_replacer = ArgReplacer(Test, 'a')
    arg_replacer.get_old_value(args, kwargs)


# Generated at 2022-06-26 08:54:25.803259
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(x, y, z=5):
        return x+y+z
    arg_rep = ArgReplacer(test_func, 'x')
    assert arg_rep.get_old_value((1,2,3), {'z':3}) == 1


# Generated at 2022-06-26 08:54:33.174090
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import_object = __import__("importlib")
    inspect = __import__("inspect")
    orig_ArgReplacer = import_object.import_module("tornado.util").ArgReplacer
    class ArgReplacer(orig_ArgReplacer):
        def __init__(self, *args: Any, **kwargs: Any) -> Any:
            self.name = "name"
            self.arg_pos = 0
        def _getargnames(self, func: Callable) -> List[str]:
            return [
                "arg_0",
                "arg_1",
                "arg_2",
                "arg_3",
                "arg_4",
                "arg_5",
                "arg_6",
                "arg_7",
                "arg_8",
                "arg_9",
            ]


# Generated at 2022-06-26 08:54:38.512455
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    func = get_stack_context()
    name = 'self'
    arg_replacer_0 = ArgReplacer(func, name)
    name = 'self'
    arg_replacer_0 = ArgReplacer(arg_replacer_0.__class__, name)
    arg_replacer_0 = ArgReplacer(arg_replacer_0.__class__, name)


# Generated at 2022-06-26 08:54:42.704089
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    print(">>> test_Configurable_initialize")
    ioloop_class_0 = Configurable()
    test_Configurable_initialize_instance_1 = Configurable()
    test_Configurable_initialize_instance_1.initialize(ioloop_class_0)

test_case_0()
test_Configurable_initialize()

# Generated at 2022-06-26 08:54:50.479913
# Unit test for function import_object
def test_import_object():
    import io
    import tornado.escape
    assert not import_object('tornado.escape') is not tornado.escape
    assert not import_object('tornado.escape.utf8') is not tornado.escape.utf8
    assert not import_object('tornado') is not tornado
    assert not import_object('tornado.missing_module') is not ImportError
    print("Test for import_object passed")


# Generated at 2022-06-26 08:55:03.665125
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_(self, a, b=None):
        pass
    arg_replacer_1 = ArgReplacer(test_, "a")
    assert arg_replacer_1.replace(None, (), {'a':'a', 'b':'b'}) == (None, (), {'a':None, 'b':'b'})
    assert arg_replacer_1.replace(None, ("a", ), {'b':'b'}) == ('a', (None, ), {'b':'b'})
    assert arg_replacer_1.replace(None, ("a", ), {'a':'a'}) == ('a', (None, ), {'a':None})
    #get_old_value test

# Generated at 2022-06-26 08:55:04.653211
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-26 08:55:25.181325
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = type('func', (object,), {})
    args_0 = [1]
    kwargs_0 = {'a': 2}
    arg_replacer_0 = ArgReplacer(func, 'a')
    result_tuple = arg_replacer_0.replace(3, args_0, kwargs_0)
    if (result_tuple[0] != 2):
        raise RuntimeError("Failed, expected: 2")
    if (len(result_tuple[1]) != 1 or result_tuple[1][0] != 1):
        raise RuntimeError("Failed, expected: [1]")
    if (result_tuple[2] != {'a': 3}):
        raise RuntimeError("Failed, expected: {'a': 3}")

# Generated at 2022-06-26 08:55:26.602030
# Unit test for function raise_exc_info
def test_raise_exc_info():
    test_case_0()



# Generated at 2022-06-26 08:55:36.343067
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f_0(a: int, b: int, c: int, d: int) -> int:
        return a + b + c + d
    f_0_0 = f_0
    asr_0 = ArgReplacer(f_0_0, "d")
    r, a_0, k_0 = asr_0.replace(10, (1, 2, 3), {"c": 4})
    assert r == 1
    assert a_0 == (1, 2, 3)
    assert k_0 == {"c": 4, "d": 10}


# Generated at 2022-06-26 08:55:44.715320
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    global flag
    flag = False
    class Configurable_Test(Configurable):
        def configurable_base(self):
            pass
        def configurable_default(self):
            pass
        def initialize(self):
            pass
    def _():
        flag = True
        assert issubclass(Configurable_Test.configured_class(), Configurable_Test) == True
    Configurable_Test.configure(_)

if __name__ == "__main__":
    test_Configurable___new__()
    test_case_0()

# Generated at 2022-06-26 08:55:53.989335
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(x, y, z=3):  # type: ignore
        pass
    arg = ArgReplacer(f, "y")
    old_value, args, kwargs = arg.replace("new", (1, 2), dict(z=4))
    assert old_value == 2
    assert args == (1, "new")
    assert kwargs == dict(z=4)


# Generated at 2022-06-26 08:55:58.358613
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):
        def __init__():
            raise NotImplementedError()
    myconfigurable = MyConfigurable.configured_class()


# Generated at 2022-06-26 08:55:59.897932
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:56:02.812376
# Unit test for function raise_exc_info
def test_raise_exc_info():
    exc_info_0 = None
    raise_exc_info(exc_info_0)


# Generated at 2022-06-26 08:56:04.428621
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()


# Generated at 2022-06-26 08:56:06.427847
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    obj = Configurable()
    obj.initialize()


# Generated at 2022-06-26 08:56:20.762932
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()

# Generated at 2022-06-26 08:56:25.557132
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    print("Testing method initialize of class Configurable")
    configurable_0 = Configurable()
    configurable_0.initialize()
    print ("Testing method initialize of class Configurable finished")

# Generated at 2022-06-26 08:56:28.593345
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    old_value, args, kwargs = ArgReplacer('replace', None).replace('new_value', 'args', 'kwargs')

if __name__ == '__main__':
    test_case_0()
    test_ArgReplacer_replace()

# Generated at 2022-06-26 08:56:36.934050
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    class myclass(Configurable):

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

    assert isinstance(myclass.configure(myclass), myclass)
    assert isinstance(myclass.configure(None), myclass)


# Generated at 2022-06-26 08:56:38.850581
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    gzip_decompressor_0 = GzipDecompressor()
    gzip_decompressor_0.initialize()




# Generated at 2022-06-26 08:56:46.862478
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    args = ["tornado.concurrent.Future", "add_done_callback", "callback", "None", "None"]

    def func():
        return getfullargspec(Future.add_done_callback)
    func_0 = ArgReplacer(func, None)
    ArgReplacer_arg_replacer = ArgReplacer(Future.add_done_callback, "callback")



# Generated at 2022-06-26 08:56:52.366846
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer_0 = ArgReplacer(test_case_0, )
    arg_replacer_0.get_old_value(
        args=(gzip_decompressor_0, ),
        kwargs={
            "test_case_0": test_case_0,
            "arg_replacer_0": arg_replacer_0,
            "gzip_decompressor_0": gzip_decompressor_0,
        },
        default=None,
    )


# Generated at 2022-06-26 08:57:00.970181
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        # This test does not work for all versions of Python.
        # Specifically, it does not work on Python 2 with Tiny Core Linux
        # (it fails with a TypeError). However, because the function is
        # primarily used by the test suite itself, that should be fine.
        # On other versions of Python, it is expected to work just fine.
        try:
            assert errno_from_exception(e) == 0
        except TypeError:
            pass


# Generated at 2022-06-26 08:57:13.633286
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def ff(a, b, c=3, d=4):
        return a, b, c, d 
    arg_replacer_0 = ArgReplacer(ff, "c")
    if (arg_replacer_0.get_old_value((1,2),{},4) != 4):
        raise RuntimeError("Test #1 failed")
    if (arg_replacer_0.get_old_value((1,2),{"c":5},4) != 5):
        raise RuntimeError("Test #2 failed")
    if (arg_replacer_0.get_old_value((1,2,None),{"c":5},4) != None):
        raise RuntimeError("Test #3 failed")


# Generated at 2022-06-26 08:57:16.141099
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()
# test_case_0()
# test_Configurable___new__()


# Generated at 2022-06-26 08:57:30.713028
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Check that OSError is handled correctly
    assert errno_from_exception(OSError(123, "TEST")) == 123
    # Check that None is returned for an exception with no args
    assert errno_from_exception(Exception()) is None
    # Check that None is returned if the args[0] is not an int
    assert errno_from_exception(OSError("TEST")) is None



# Generated at 2022-06-26 08:57:44.560933
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import inspect
    import sys

    test_case_0.func_globals['__name__'] = 'test_case_0'
    test_case_0.func_globals['__file__'] = __file__
    test_case_0.__module__ = '__main__'
    sys.modules['__main__'] = test_case_0.func_globals
    scope = dict(__name__='__main__')
    scope.update(test_case_0.func_globals)
    scope.update(locals())
    arg_replacer_0 = ArgReplacer(gzip_decompressor_0.__init__, 'wbits')

# Generated at 2022-06-26 08:57:46.491557
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    objDict = ObjectDict()


# Generated at 2022-06-26 08:57:52.977801
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class SomeBaseClass(object):
        pass
    tested_class = Configurable()
    tested_instance = SomeBaseClass()
    exc = None


    try:
        tested_instance = tested_class.__new__(tested_instance)
    except Exception as e:
        exc = e

    assert exc is not None


# Generated at 2022-06-26 08:58:00.099413
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Replace a keyword argument
    def f(a: Tuple[int, int, int], b: int = 2) -> None:
        return a, b

    ar = ArgReplacer(f, "b")

    old_b, args, kwargs = ar.replace(3, (), {"b": 2})
    assert (args, kwargs) == ((), {"b": 3})
    assert old_b == 2

    old_b, args, kwargs = ar.replace(3, (), {})
    assert (args, kwargs) == ((), {"b": 3})
    assert old_b is None

    old_b, args, kwargs = ar.replace(3, (1, 2, 3), {})
    assert (args, kwargs) == ((1, 2, 3), {"b": 3})
   

# Generated at 2022-06-26 08:58:06.055742
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Unit test for method replace of class ArgReplacer
    t = ArgReplacer("test_func_0", "name")
    t.replace("AAAA", "BBBB", "CCCC")
    t.replace("AAAA", "BBBB", "CCCC")
    t.replace("AAAA", "BBBB", "CCCC")


# Generated at 2022-06-26 08:58:11.484286
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a = ObjectDict()
    a.a = 1
    try:
        a.b
    except AttributeError as e:
        assert str(e) == 'b'
    else:
        assert 0


# Generated at 2022-06-26 08:58:12.957286
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    conf_0 = Configurable()
    conf_0.initialize()
    conf_0.initialize(1, 2)

if __name__ == "__main__":
    test_case_0()
    test_Configurable_initialize()

# Generated at 2022-06-26 08:58:16.162012
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    dict_0:ObjectDict
    dict_0 = ObjectDict()
    dict_0['name'] = "test" 
    print("-->" + dict_0.name)

test_ObjectDict___getattr__()



# Generated at 2022-06-26 08:58:18.374062
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    test_case = Configurable()
    test_case.initialize()


# Generated at 2022-06-26 08:58:31.045322
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass



# Generated at 2022-06-26 08:58:41.760663
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    object_dict_0 = ObjectDict()
    object_dict_1 = ObjectDict()
    object_dict_2 = ObjectDict()
    object_dict_3 = ObjectDict()
    object_dict_0.setdefault("val_8", None)
    object_dict_0.setdefault("val_9", "9")
    object_dict_1.setdefault("val_10", None)
    object_dict_2.setdefault("val_11", "11")
    object_dict_0.setdefault("val_12", None)
    object_dict_0.setdefault("val_13", "13")
    object_dict_1.setdefault("val_14", None)
    object_dict_2.setdefault("val_15", "15")

# Generated at 2022-06-26 08:58:52.112300
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Closure2(object):
        def __init__(self, arg1):
            self.arg1 = arg1

    r = ArgReplacer(Closure2, 'arg1')
    # Test args and kwargs are None
    x = r.replace(None, None, None)
    assert (None, (), {}) == x
    # Test args is not None, kwargs is None
    x = r.replace(None, (0,), None)
    assert (0, (), {}) == x
    # Test args is not None, kwargs is not None
    x = r.replace(None, (0,), {'arg1': 1})
    assert (0, (), {'arg1': None}) == x
    # Test args is None, kwargs is not None

# Generated at 2022-06-26 08:59:02.169339
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    expected_name = "name"
    expected_arg_pos = -1
    expected_value = "test"
    expected_args = [None, None, None, None]
    expected_kwargs = {"key1": "not_none", "key2": 1}

    arg_replacer = ArgReplacer(_test_case_1, expected_name)

    assert arg_replacer.name == expected_name
    assert arg_replacer.arg_pos == expected_arg_pos

    value = arg_replacer.get_old_value(expected_args, expected_kwargs)
    assert value == expected_value

    arg_replacer.replace(expected_value, expected_args, expected_kwargs)


# Generated at 2022-06-26 08:59:10.594235
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj["key1"] = "value3"
    obj["key2"] = "value3"
    obj["key3"] = "value3"
    res = obj.__getattr__("key2")
    # Check res value (res is 'value3')
    assert res == "value3"
    # Check return type (res should be 'str')
    assert isinstance(res, str)


# Generated at 2022-06-26 08:59:21.207325
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_function(a, b, c=23, d=42):
        return a, b, c, d

    kwargs = {'d': 100}
    args = ('a', 'b')
    a = ArgReplacer(test_function, 'd')
    a.replace(101, args, kwargs)
    args, kwargs = a.replace(101, args, kwargs)



# Generated at 2022-06-26 08:59:33.347199
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # TODO: find a better way to test abstract methods
    try:
        Configurable.initialize()
    except NotImplementedError:
        return

    class DummyConfigurable(Configurable):
        def initialize(self):
            print("Configure test OK")

    DummyConfigurable().initialize()

#    @classmethod
#    def _save_configuration(cls):
#        # type: () -> Tuple[Optional[Type[Configurable]], Dict[str, Any]]
#        base = cls.configurable_base()
#        return (base.__impl_class, base.__impl_kwargs)


# Generated at 2022-06-26 08:59:42.827951
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # init
    gzip_decompressor_0 = GzipDecompressor()
    if gzip_decompressor_0.decompressobj != gzip_decompressor_0.decompressobj:
        raise ValueError('expected ' + str(gzip_decompressor_0.decompressobj) + ' but found ' + str(gzip_decompressor_0.decompressobj))


# Generated at 2022-06-26 08:59:52.675777
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # The following code is copied verbatim from function
    # ArgReplacer.replace
    def some_function(a: int, b: int, c: int) -> None:
        """None"""
        print(a, b, c)

    obj = ArgReplacer(some_function, "a")
    assert obj.replace(1, (2, 3, 4), {'a': 123}) == (2, (1, 3, 4), {'a': 1})


# Generated at 2022-06-26 08:59:53.952517
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass

# Generated at 2022-06-26 09:00:19.743554
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    args = []
    kwargs = {}
    print(ArgReplacer(test_case_0, "gzip_decompressor").get_old_value(args, kwargs))


# Generated at 2022-06-26 09:00:21.842302
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    test_case_0()



# Generated at 2022-06-26 09:00:24.094139
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-26 09:00:31.463944
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test 1 of method __new__
    # Parameters:
    #   cls:
    #     The class calling the method.
    #   *args:
    #     Any arguments.
    #   **kwargs:
    #     Any keyword arguments.
    class configurable_base_0(Configurable):
        def __new__(cls, *args: Any, **kwargs: Any) -> Any:
            base = cls.configurable_base()
            init_kwargs = {}  # type: Dict[str, Any]
            if cls is base:
                impl = cls.configured_class()
                if base.__impl_kwargs:
                    init_kwargs.update(base.__impl_kwargs)
            else:
                impl = cls
            init_kwargs.update(kwargs)

# Generated at 2022-06-26 09:00:39.948557
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    TestConfigurable0 = type('TestConfigurable0', (Configurable,), {'_Configurable__impl_class': None, '_Configurable__impl_kwargs': None, 'configurable_base': lambda self: TestConfigurable0, 'configurable_default': lambda self: TestConfigurable0})
    TestConfigurable0 = TestConfigurable0
    TestConfigurable0.configure(TestConfigurable0)
    TestConfigurable0.configure(None)
    # TypeError should be raised here
    try:
        TestConfigurable0.configure(str)
    except:
        pass
    # TypeError should be raised here
    try:
        TestConfigurable0.configure(int)
    except:
        pass
    # TypeError should be raised here

# Generated at 2022-06-26 09:00:47.961490
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_method(x : int, y : int):
        pass
    test_obj = ArgReplacer(test_method,name = "y")
    old_value, args, kwargs = test_obj.replace(9,(2,3),{})
    assert old_value == 3
    assert args == (2,9)
    assert kwargs == {}


# Generated at 2022-06-26 09:00:58.261391
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():

    def add_num_0(a: int, b: int) -> int:
        return a + b

    def add_num_1(a: int, b: int) -> int:
        return a + b

    # Test method __init__ of class ArgReplacer
    add_num_replacer_0 = ArgReplacer(add_num_0, "")
    add_num_replacer_1 = ArgReplacer(add_num_1, "")


# Generated at 2022-06-26 09:01:08.363889
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Test case 1
    gzip_decompressor_1 = GzipDecompressor()
    args = ()
    kwargs = {'nodict': None}
    default = None
    replacer_1 = gzip_decompressor_1.replacer
    old_value = replacer_1.get_old_value(args, kwargs, default)
    assert old_value == None, "Actual: " + old_value


# Generated at 2022-06-26 09:01:15.659834
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    global cls
    global base
    global impl
    global init_kwargs

    args = {"args": args, "cls": cls, "base": base, "impl": impl, "init_kwargs": init_kwargs}
    AssertionError['__init__'](AssertionError)
    try:
        raise AssertionError
    except:
        ex = sys.exc_info()
    raise_(ex[0], ex[1], ex[2])
    #e:BaseException
    try:
        raise e
    except:
        ex = sys.exc_info()
    raise_(ex[0], ex[1], ex[2])
    AssertionError['__init__'](AssertionError)
    try:
        raise AssertionError
    except:
        ex = sys.exc_

# Generated at 2022-06-26 09:01:19.066841
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    glob=globals()
    p1=glob["Configurable"]
    def test_body():
        args={}
        kwargs={}
        c=Configurable()
        c.initialize(**kwargs)
    glob["Configurable"].initialize=test_body
    test_case_0()
    del glob["Configurable"].initialize
    glob["Configurable"]=p1


# Generated at 2022-06-26 09:02:18.838803
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    s_0 = ""
    s_1 = ""
    o = ArgReplacer(s_0, s_1)
    f_0 = ""
    f_1 = ""
    f_2 = []
    f_3 = {}
    try:
        f_0 = o.replace(f_1, f_2, f_3)
    except:
        assert False



# Generated at 2022-06-26 09:02:24.594819
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    assert True
    # obj = ObjectDict()
    # assert obj.__getattr__("this_method_does_not_exist", "does_not_return_anything")


# Generated at 2022-06-26 09:02:36.504617
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Setup
    http_client_impl_0 = AsyncHTTPClient()
    base_url = 'https://www.google.com'
    user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
    connect_timeout = 20.0
    request_timeout = 20.0
    follow_redirects = True
    max_redirects = 5
    max_buffer_size = 104857600
    proxy_host = None
    proxy_port = None
    proxy_username = None
    proxy_password = None
    proxy_auth_mode = None
    ca_certs = None
    allow_ipv6 = True
    validate_cert = True
   

# Generated at 2022-06-26 09:02:37.457316
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:02:47.479925
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    ar = ArgReplacer(gzip_decompressor_0.write, 'data')
    assert ar.get_old_value(gzip_decompressor_0.write.__code__.co_varnames, gzip_decompressor_0.write.__code__.co_varnames) == 'data'
    o, a, k = ar.replace(1, gzip_decompressor_0.write.__code__.co_varnames, gzip_decompressor_0.write.__code__.co_varnames)
    assert o == 'data'
    assert a == ('data', gzip_decompressor_0.write.__code__.co_varnames, True, False)
    assert k == ('fragment',)


# Generated at 2022-06-26 09:02:52.956417
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # replace is a protected method of class ArgReplacer
    old_value_0, args_0, kwargs_0 = ArgReplacer(socket.socket, 'family').replace(AF_INET, (), {})
    print(args_0, kwargs_0, old_value_0)



# Generated at 2022-06-26 09:02:54.720658
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create an instance of Configurable
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:02:57.353131
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # 0
    configurable_0 = Configurable.__new__(Configurable)
    print(configurable_0)
test_case_0()
test_Configurable___new__()

# Generated at 2022-06-26 09:03:01.288194
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def add_two(a,b):
        return a + b
    replacer_0 = ArgReplacer(add_two, 0)
    assert replacer_0.get_old_value([1,2],{},default=0) == 1


# Generated at 2022-06-26 09:03:11.544759
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Set up data for test
    num_args = 2
    arg_0 = 1
    arg_1 = 2
    kw_args = {'arg_0': 3, 'arg_1': 4}

    # Set up expected results
    expected_args = [arg_0, arg_1, kw_args['arg_0'], kw_args['arg_1']]

    # Perform test
    class TestConfigurable(Configurable):
        def _initialize(self, *args, **kwargs) -> None:
            if len(args) is not num_args:
                raise ValueError("Wrong number of args - expected {}, got {}".format(num_args, len(args)))