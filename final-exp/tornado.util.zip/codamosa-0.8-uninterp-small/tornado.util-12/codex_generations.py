

# Generated at 2022-06-26 08:54:17.611733
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_func = lambda x: None
    replace_0 = ArgReplacer(test_func, "gzip_config")
    new_value_0 = GzipDecompressor()
    args_0 = ()
    kwargs_0 = {}
    old_value, args, kwargs = replace_0.replace(new_value_0, args_0, kwargs_0)
    assert old_value == None

    test_func_1 = lambda x: None
    replace_1 = ArgReplacer(test_func_1, "gzip_config")
    new_value_1 = GzipDecompressor()
    args_1 = (new_value_1,)
    kwargs_1 = {}

# Generated at 2022-06-26 08:54:27.513163
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def function_0(a0, a1):
        pass
    arg_replacer_0 = ArgReplacer(function_0, "a0")
    try:
        actual_result_0 = arg_replacer_0.get_old_value((), {}, None)
    except BaseException as err:
        actual_result_0 = err
    except:
        actual_result_0 = Exception(sys.exc_info())

    expected_result_0 = None
    assert_equal_with_print(actual_result_0, expected_result_0)


# Generated at 2022-06-26 08:54:31.197176
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    configurable_0 = Configurable()
    configurable_0.initialize()


# Generated at 2022-06-26 08:54:41.773927
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # It is good practice to define a function called test_constructor.
    # test_constructor should take no argument and return an instance of the class.
    def test_constructor():
        return ArgReplacer(test_case_0, name="test")
    # deriving the types of the arguments is undecidable
    instance = test_constructor()
    assert type(instance.name) == str
    assert type(instance.arg_pos) == int
    assert type(instance.get_old_value(instance.args, instance.kwargs, default=None)) == object
    assert type(instance.replace(instance.new_value, instance.args, instance.kwargs)) == tuple



# Generated at 2022-06-26 08:54:45.469378
# Unit test for function import_object
def test_import_object():
    test_case_0()

# ... (TODO: Implement more unit tests.  The current ones are not enough)



# Generated at 2022-06-26 08:54:51.444709
# Unit test for function errno_from_exception
def test_errno_from_exception():
    err = 0
    try:
        e = Exception(err)
        if err != errno_from_exception(e):
            raise Exception
    except Exception:
        pass

    err = 1
    try:
        e = Exception(err)
        if err != errno_from_exception(e):
            raise Exception
    except Exception:
        pass


# Generated at 2022-06-26 08:54:57.808523
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass

import_object("tornado.testing")

# test for function import_object
test_import_object()


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__"
# aren't supported in threading.

# Generated at 2022-06-26 08:55:05.439518
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    test_func = get_absolute_url
    name = 'value'
    arg_replacer = ArgReplacer(test_func, name)
    test_func_args = ('abc',)
    test_func_kwargs = {'value': 'xyz'}
    new_value = '123'
    (old_value, args, kwargs) = arg_replacer.replace(new_value, test_func_args, test_func_kwargs)
    assert old_value == 'xyz' and args == test_func_args and kwargs == {'value': '123'}


# Generated at 2022-06-26 08:55:09.769143
# Unit test for function import_object
def test_import_object():
    print(import_object('tornado'))
    print(import_object('tornado.escape'))
    print(import_object('tornado.escape.utf8'))



# Generated at 2022-06-26 08:55:12.212144
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    """Unit test for method initialize of class Configurable"""

    def test_case_0():
        configurable_0 = Configurable()


# Generated at 2022-06-26 08:55:22.770195
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()

# Module

# Generated at 2022-06-26 08:55:36.448271
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(x, y):
        pass
    arg_replacer_0 = ArgReplacer(test_func, 'x')
    old_value_0, new_args_0, new_kwargs_0 = arg_replacer_0.replace('test_string_0', (), {})
    assert old_value_0 == None
    assert new_args_0 == ()
    assert new_kwargs_0 == {'x': 'test_string_0'}
    old_value_1, new_args_1, new_kwargs_1 = arg_replacer_0.replace('test_string_1', (1,), {})
    assert old_value_1 == 1
    assert new_args_1 == (1,)

# Generated at 2022-06-26 08:55:46.623530
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test1(x, y, z):
        return x, y, z
    def test2(x, y, z=1):
        return x, y, z
    def test3(x, y=False, z=1):
        return x, y, z
    def test4(x=True, y=False, z=1):
        return x, y, z


# Generated at 2022-06-26 08:55:58.519611
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    global impl
    impl = None
    global init_kwargs
    init_kwargs = {}
    global instance
    instance = None

    # assert issubclass(impl,cls)
    # assert impl.configurable_base() is not base
    # instance = super(Configurable,cls).__new__(impl)
    # instance.initialize()
    # return instance

    # if impl.configurable_base() is not base:
    # return impl(*args, **init_kwargs)

    # assert impl.configurable_base() is not base
    # assert impl.configurable_base() is not base

    # assert cls is base
    # assert impl is cls
    # assert impl.configurable_base() is base
    # instance = super(Configurable,cls).__new__(impl)
    #

# Generated at 2022-06-26 08:56:06.661219
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    gzip_decompressor_0 = GzipDecompressor()
    def test_function(arg_replacer_arg_0, arg_replacer_arg_1):
        arg_replacer_arg_2 = arg_replacer_arg_0
        arg_replacer_arg_3 = arg_replacer_arg_1
        arg_replacer_arg_0 = GzipDecompressor()
    assert_equal(1, 0)


# Generated at 2022-06-26 08:56:09.007247
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    impl = object()
    obj = object()
    arg = object()
    kwarg = object()
    old_initialize = Configurable.initialize # type: ignore


# Generated at 2022-06-26 08:56:10.573232
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass




# Generated at 2022-06-26 08:56:16.068639
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # initialize vs __init__ chosen for compatibility with AsyncHTTPClient
    # singleton magic.  If we get rid of that we can switch to __init__
    # here too.
    print("test_Configurable___new__")
    test_case_0()

test_Configurable___new__()

# Generated at 2022-06-26 08:56:29.594028
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from tornado.httputil import _parse_proxy
    from types import MethodType
    class ArgReplacer_a:
        def __init__(self, func: Callable, name: str) -> None:
            self.name = name
            try:
                self.arg_pos = self._getargnames(func).index(name)  # type: Optional[int]
            except ValueError:
                # Not a positional parameter
                self.arg_pos = None

# Generated at 2022-06-26 08:56:41.188013
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun_0(arg_0, arg_1 = None, arg_2 = None, *args, **kwargs):
        return arg_0, arg_1, arg_2, args, kwargs
    
    arg_replacer_0 = ArgReplacer(fun_0, "arg_1")
    value_0, value_1, _, _, _ = arg_replacer_0.replace(1, ("a",), {"arg_2": 2})
    assert value_0 == "a"
    assert value_1 == 1
    _, value_1, _, _, _ = arg_replacer_0.replace(1, ("a", "b"), {"arg_2": 2})
    assert value_1 == "b"
    _, value_1, _, _, _ = arg_replacer_0.replace

# Generated at 2022-06-26 08:56:58.852914
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl_class_0 = Configurable()
    gzip_decompressor_1 = GzipDecompressor()
    impl_class_1 = gzip_decompressor_1.configured_class()
    assert impl_class_1 == GzipDecompressor
    assert impl_class_0 == impl_class_1

test_case_0()
test_Configurable___new__()

# Generated at 2022-06-26 08:57:02.084553
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def function_0(a):
        return a
    new_value = 'Word'
    old_value = new_value
    assert function_0(new_value) == old_value


# Generated at 2022-06-26 08:57:10.257703
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = Configurable()

    impl = Configurable()

    init_kwargs = {}

    if impl.configurable_base() is not base:
        # The impl class is itself configurable, so recurse.
        instance = impl(**init_kwargs)

    instance = super(Configurable, base).__new__(impl)

    # initialize vs __init__ chosen for compatibility with AsyncHTTPClient
    # singleton magic.  If we get rid of that we can switch to __init__
    # here too.
    instance.initialize(**init_kwargs)


# Generated at 2022-06-26 08:57:23.110860
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # test 1: default values
    replacer = ArgReplacer(test_ArgReplacer_replace, 'new_value')
    old_value, args, kwargs = replacer.replace("new_value", [], {})
    assert old_value is None
    assert args == []
    assert kwargs == {'new_value': "new_value"}

    # test 2: positional args
    replacer = ArgReplacer(test_ArgReplacer_replace, "new_value")
    old_value, args, kwargs = replacer.replace("new_value", ["old_value"], {})
    assert old_value == "old_value"
    assert args == ["new_value"]
    assert kwargs == {}

    # test 3: keyword args

# Generated at 2022-06-26 08:57:26.621045
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Test "FileNotFoundError" exception
    try:
        f = open("a" + "b")
        return 1
    except Exception as e:
        if errno_from_exception(e) == 2:
            return 0
    return 1


# Generated at 2022-06-26 08:57:36.131321
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.httpclient import AsyncHTTPClient
    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    assert AsyncHTTPClient.configured_class() == AsyncHTTPClient
    assert AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient") == None
    assert AsyncHTTPClient == AsyncHTTPClient.configurable_base()
    assert AsyncHTTPClient.configurable_base == Configurable.configurable_base.__get__(AsyncHTTPClient, AsyncHTTPClient)
    assert AsyncHTTPClient.configure == Configurable.configure.__get__(AsyncHTTPClient, AsyncHTTPClient)


# Generated at 2022-06-26 08:57:45.668403
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    assert ArgReplacer.replace(True,(10,20,30),{'args':[10,20,30]}) == (True,(True,20,30),{'args':[10,20,30]})
    assert ArgReplacer.replace(True,(10,20,30),{'kwargs':True}) == (True,(True,20,30),{'kwargs':True})
    assert ArgReplacer.replace(True,(10,20,30),{}) == (True,(True,20,30),{})


# Generated at 2022-06-26 08:57:47.105799
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    replacer = ArgReplacer(gzip_decompressor_0, name)
    old_value = replacer.get_old_value(args, kwargs, default)

# Generated at 2022-06-26 08:57:53.597687
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def print_reverse_params(name, value = 10):
        arg = ArgReplacer(print_reverse_params, name)
        print(arg.get_old_value((name, value), {}, default=0))
    # For the following case, the function should return 10
    test_case_0()
    print_reverse_params("value")


# Generated at 2022-06-26 08:57:59.057000
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    try:
        gzip_decompressor_0 = GzipDecompressor()
    except Exception as exc:
        arg_replacer_0 = ArgReplacer(gzip_decompressor_0.initialize, "format")
        arg_replacer_0.get_old_value()
        new_value_0 = None
        args_0 = ()
        kwargs_0 = {}
        arg_replacer_0.replace(new_value_0, args_0, kwargs_0)
        raise_exc_info([None, exc, None])


# Generated at 2022-06-26 08:58:10.738838
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):
        def __init__(self):
            super().__init__()

    configurable_0 = MyConfigurable()

# Generated at 2022-06-26 08:58:18.337467
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    sampleFunction_0 = func_0
    args_0 = [2]
    kwargs_0 = {"a": 3}
    name_0 = "a"
    argReplacer_0 = ArgReplacer(sampleFunction_0, name_0)
    test_value_0 = 4
    old_value_0, args_1, kwargs_1 = argReplacer_0.replace(test_value_0, args_0, kwargs_0)
    assert sampleFunction_0(2, a=4) == 7
    assert old_value_0 == 3
    assert args_1 == [2]
    assert kwargs_1 == {"a": 4}


# Generated at 2022-06-26 08:58:30.254989
# Unit test for function errno_from_exception
def test_errno_from_exception():
    import errno
    import socket
    import errno

    ex = Exception()  # type: Exception
    assert errno_from_exception(ex) is None
    ex = socket.error()  # type: OSError
    assert errno_from_exception(ex) == 0
    ex = socket.error(errno.EINVAL)
    assert errno_from_exception(ex) == errno.EINVAL
    ex = socket.error((errno.EINVAL, "error1"))
    assert errno_from_exception(ex) == errno.EINVAL
    ex = socket.error(("error2", "error3"))
    assert errno_from_exception(ex) == "error2"



# Generated at 2022-06-26 08:58:37.281389
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Parameter test data
    impl = 'assertion_failure'
    kwargs = {'a': 1}

    # Call test target
    try:
        c = Configurable.configure(impl, **kwargs)
    except ValueError:
        assert True
    except:
        assert False


# Generated at 2022-06-26 08:58:38.495777
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:58:41.373188
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    gzip_decompressor_0 = Configurable()



# Generated at 2022-06-26 08:58:45.183672
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()
    configurable_0.test_case_0()

test_Configurable___new__()

# Generated at 2022-06-26 08:58:50.531938
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_0(a, b, c):
        pass

    a = ArgReplacer(func_0, 'b')
    old_value_0, args_0, kwargs_0 = a.replace("ghi", ("abc", "def", "ghi"), {})
    assert("def" == old_value_0)
    assert("ghi" == args_0[1])
    assert("def" == kwargs_0.get("b"))


# Generated at 2022-06-26 08:59:00.282619
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func1(a,b,c,d=None):
        return a,b,c,d
    r=ArgReplacer(test_func1,"b")
    r.replace("new_b_value",("a","b","c",),{"d":"d_value"})
    print(r.get_old_value(("a","b","c"),{"d":"d_value"},default="default_value"))

if __name__ == "__main__":
    test_case_0()
    test_ArgReplacer_replace()
    pass

# Generated at 2022-06-26 08:59:06.933004
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class cls_0(Configurable):
        def configurable_base(self):
            raise NotImplementedError()

        def configurable_default(self):
            raise NotImplementedError()

    cls_0_instance = cls_0()


# Generated at 2022-06-26 08:59:25.946110
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # gzip_decompressor_0 needs to be defined as a global var. This is because the argument 'self' of replace is of the class ArgReplacer, ArgReplacer is a subclass of object. So this is a test case that covers the replace function which has argument self of the class object.
    # gzip_decompressor_0 needs to be ast.Name node and its id needs to be the name of the global variable.
    gzip_decompressor_0 = GzipDecompressor()
    test_case_0()
    ar_0 = ArgReplacer(GzipDecompressor, 'decompress_until')
    old_value, args, kwargs = ar_0.replace((gzip_decompressor_0.decompress_until), (), {})
    return args[0] is gzip_decompressor_0.dec

# Generated at 2022-06-26 08:59:29.086387
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Creating a new instance of class Configurable
    configurable_0 = Configurable()


# Generated at 2022-06-26 08:59:32.874261
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # public __new__(cls: type, *args: Any, **kwargs: Any) -> Any
    # TypeError: object() takes no parameters
    # pass
    pass


# Generated at 2022-06-26 08:59:44.387734
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Create a dummy class
    class A():
        __impl_class = None
        __impl_kwargs = None
        def __new__(cls, *args, **kwargs):
            return object.__new__(cls)
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    # Call __new__ of Configurable with a class instance
    a0 = Configurable.__new__(A, )
    # Instantiate the return value and check if it is an instance of the correct type
    a1 = a0()
    assert isinstance(a1, A)


# Generated at 2022-06-26 08:59:45.662511
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case_0()

test_Configurable___new__()

# Generated at 2022-06-26 08:59:56.844881
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    def foo(bar, baz='qwerty'):
        print(bar, baz)

    arg_replacer_0 = ArgReplacer(foo, 'bar')

    #Positive
    old_value = arg_replacer_0.get_old_value((1,), {'baz' : 'uiop'})
    if old_value == 1:
        pass
    else:
        raise Exception('test_ArgReplacer_get_old_value: Positive Test Failed')

    #Negative
    old_value = arg_replacer_0.get_old_value((1,), {'baz' : 'qwerty'})
    if old_value == 1:
        raise Exception('test_ArgReplacer_get_old_value: Negative Test Failed')
    else:
        pass


# Generated at 2022-06-26 09:00:07.497525
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_argreplacer_0 = ArgReplacer(foo, 'bar')
    test_argreplacer_0.replace(1, [2], { 4: 3, 'bar': 5 })
    test_argreplacer_1 = ArgReplacer(foo, 'bar')
    test_argreplacer_1.replace(1, [6, 2], { 4: 3 })
    test_argreplacer_2 = ArgReplacer(foo, 'bar')
    test_argreplacer_2.replace(1, [2], { 'bar': 5 })
    test_argreplacer_3 = ArgReplacer(foo, 'bar')
    test_argreplacer_3.replace(1, [2], { 'bar': 5, 4: 3 })
    test_argreplacer_4 = ArgReplacer(foo, 'bar')
    test_

# Generated at 2022-06-26 09:00:18.450601
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = Configurable.configurable_base()
    impl = Configurable.configured_class()
    if base.__impl_class:
        init_kwargs.update(base.__impl_kwargs)
    else:
        impl = cls
    init_kwargs.update(kwargs)
    if impl.configurable_base() is not base:
        # The impl class is itself configurable, so recurse.
        return impl(*args, **init_kwargs)
    instance = super(Configurable, cls).__new__(impl)
    # initialize vs __init__ chosen for compatibility with AsyncHTTPClient
    # singleton magic.  If we get rid of that we can switch to __init__
    # here too.
    instance.initialize(*args, **init_kwargs)
    return instance

# Unit test

# Generated at 2022-06-26 09:00:21.194399
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # There is no '__new__ for class type
    if True:
        raise Exception()


# Generated at 2022-06-26 09:00:28.057888
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # This is a fake unit test to make sure the code runs.

    # Create object
    m = ArgReplacer(gzip_decompressor_0._read_from_stream, 'stream')
    # Get old arg value
    old_value = m.get_old_value(gzip_decompressor_0._read_from_stream.__code__, gzip_decompressor_0._read_from_stream.__code__.co_varnames)
    print(old_value)

# TODO: Finish writing this test case

# Generated at 2022-06-26 09:00:55.467684
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:00:59.183304
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    gzip_decompressor_0 = GzipDecompressor()
    assert gzip_decompressor.get_old_value(gzip_decompressor_0._wbits) == 16


# Generated at 2022-06-26 09:01:00.962244
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:01:13.152552
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def __test_0(new_value, args, kwargs, expect_1, re_expect_2):
        _0 = ArgReplacer(__test_0, 'new_value')
        expect_0, re_expect_0, re_expect_2 = _0.replace(new_value, args, kwargs)
        assert re_expect_0 == expect_1
        assert re_expect_2 == re_expect_2
    test_0 = __test_0
    test_1 = (0, )
    test_2 = {'new_value': 0}
    test_3 = True
    test_4 = True
    test_0(test_1, test_2, test_3, test_4)


# Generated at 2022-06-26 09:01:19.597651
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func1 = test_case_0
    name1 = 'fun'
    replacer1 = ArgReplacer(func1, name1)
    result1 = replacer1.get_old_value((), {})
    assert result1 == None


# Generated at 2022-06-26 09:01:25.123218
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(x, y=None, **kwargs):
        pass

    replacer = ArgReplacer(foo, 'x')
    old_value = replacer.get_old_value((), {'y':2})
    print(old_value)


# Generated at 2022-06-26 09:01:31.646687
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Test case for method get_old_value of class ArgReplacer
    # Checking for a non-existent argument in a function that needs to be tested for coverage
    gzip_decompressor_0 = GzipDecompressor()
    gzip_decompressor_0._ArgReplacer__getargnames = MagicMock(return_value = range(3))
    gzip_decompressor_0._ArgReplacer__getargnames.__name__ = '_ArgReplacer__getargnames'
    gzip_decompressor_0.name = 'arg'
    gzip_decompressor_0.arg_pos = None
    gzip_decompressor_0.get_old_value(['s', 2, 'a'], {'arg': 'abc'})

# Generated at 2022-06-26 09:01:37.585758
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def initialize(self):
            pass
        def configurable_base(self):
            pass
        def configurable_default(self):
            pass
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 09:01:47.885936
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Create an instance of class ArgReplacer
    test_ArgReplacer_get_old_value_instance = ArgReplacer(test_case_0, "gzip_decompressor")

    # Call method get_old_value using positional arguments
    get_old_value_result = test_ArgReplacer_get_old_value_instance.get_old_value([],{})

    # Test return values and type
    assert(get_old_value_result == None)
    assert(type(get_old_value_result) == type(None))


# Generated at 2022-06-26 09:01:53.113083
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer_0 = ArgReplacer(test_case_0, 'name')
    arg_replacer_0.get_old_value('args', 'kwargs', 'default')


# Generated at 2022-06-26 09:02:35.216077
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    conf = Configurable()
    conf.initialize()


# Generated at 2022-06-26 09:02:36.404998
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_0 = Configurable()


# Generated at 2022-06-26 09:02:51.114667
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(arg1, arg2):
        pass
    expected_arg2 = 'a2'
    replacer = ArgReplacer(func, 'arg2')
    actual_old_arg2, args, kwargs = replacer.replace(expected_arg2, [], {})
    expected_old_arg2 = None
    if actual_old_arg2 != expected_old_arg2:
        raise ValueError('Replacing arg2 failed.')
    if args != []:
        raise ValueError('replacing arg2 failed.')
    if kwargs.keys() != ['arg2']:
        raise ValueError('replacing arg2 failed.')
    if kwargs['arg2'] != expected_arg2:
        raise ValueError('replacing arg2 failed.')


# Generated at 2022-06-26 09:03:01.023730
# Unit test for function errno_from_exception
def test_errno_from_exception():
    errno_from_exception(Exception(123))
    errno_from_exception(Exception())
    try:
        1 / 0
    except Exception as e:
        e2 = Exception(e)
        errno_from_exception(e2)
    errno_from_exception(Exception(Exception(123)))
    errno_from_exception(Exception(Exception()))

# Based on six.reraise from
# https://bitbucket.org/gutworth/six/src/9bf1f0b7f2b2d0cdb5bdf2e59b7d78e3c9b7f84b/six.py?at=default#cl-619
#
# As of six 1.14.0 this function is no longer necessary; it's possible to
# write ``raise value.

# Generated at 2022-06-26 09:03:04.213653
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.util import Configurable
    some_arg = ""
    some_kwarg = ""
    instance = Configurable.initialize(some_arg, some_kwarg)
    assert isinstance(instance, Configurable)


# Generated at 2022-06-26 09:03:10.161614
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        with_timeout
    except:
        pass
    try:
        async_to_sync
    except:
        pass
    try:
        TimeoutError
    except:
        pass
    try:
        reraise
    except:
        pass
    try:
        stack_context
    except:
        pass
    try:
        configurable_default
    except:
        pass


# Generated at 2022-06-26 09:03:15.970225
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    TestCase = Configurable
    assert TestCase.initialize.__name__ == TestCase._initialize.__name__
    test_case_1 = TestCase.configurable_base()
    test_case_1.initialize()
    test_case_2 = test_case_1.configurable_base()
    test_case_2.initialize()
    test_case_3 = test_case_2.configurable_base()
    test_case_3.initialize()


# Generated at 2022-06-26 09:03:23.641149
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # initialize a ArgReplacer
    arg_replacer_0 = ArgReplacer.ArgReplacer(gzip_decompressor_0, "wbits")
    # Test getting old value of wbits
    wbits_0 = arg_replacer_0.get_old_value(args_0, kwargs_0, -1)
    # Test replacing argument wbits
    old_value_0, args_1, kwargs_1 = arg_replacer_0.replace(16, args_0, kwargs_0)


# Generated at 2022-06-26 09:03:34.617794
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print_twice, log_prefix.append, log_prefix is print_twice
    def mock_log_prefix(string):
        pass
    
    mock_log_prefix, log_prefix.append, log_prefix is mock_log_prefix
    def mock_print_twice(string):
        pass
    
    print_twice = mock_print_twice
    from tornado.escape import _unicode
    log_prefix = mock_log_prefix
    from typing import Any, Optional, cast
    from tornado.util import _UTF8_TYPES
    class mock_Configurable(Configurable):
        def configurable_base(self):
            pass
        
        def configurable_default(self):
            pass
        
        def initialize(self, *args, **kwargs):
            pass
        
    
    mock

# Generated at 2022-06-26 09:03:38.753231
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Testing for replacement of a positional argument
    class Test_ArgReplacer_replace:
        def __init__(self, old_value, *args, **kwargs):
            self.old_value = old_value
            self.args = args
            self.kwargs = kwargs

    def arg_replacer_test(val0, val1, val2):
        pass

    arg_replacer = ArgReplacer(arg_replacer_test, "val1")
    old_value, args, kwargs = arg_replacer.replace(10, [0, 1, 2], {})
    obj = Test_ArgReplacer_replace(old_value, args, kwargs)
    assert obj.old_value == 1
    assert obj.args == (0, 10, 2)
    assert obj.kwargs == {}
   