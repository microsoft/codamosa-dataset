

# Generated at 2022-06-22 04:30:07.115982
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"foo") == "foo"
    assert re_unescape(r"foo\x00bar") == "foo\x00bar"
    assert re_unescape(r"\s") == r"\s"
    assert re_unescape(r"\\") == "\\"
    assert re_unescape(r"\d") == r"\d"
    assert re_unescape(r"\\d") == r"\d"
    assert re_unescape(br"foo\x00bar") == "foo\x00bar"
    assert re_unescape(br"\s") == r"\s"
    assert re_unescape(br"\\") == "\\"
    assert re_unescape(br"\d") == r"\d"

# Generated at 2022-06-22 04:30:12.225291
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    o = ObjectDict()
    o.foo = '123'
    assert o['foo'] == '123'
    assert o.foo == '123'
    o.foo = '456'
    assert o['foo'] == '456'
    assert o.foo == '456'


# Generated at 2022-06-22 04:30:19.165893
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Fake(object):
        def __init__(self, x, y):
            pass
    def fake(x, y):
        return Fake(x, y)

    # Replace a keyword argument.
    ar = ArgReplacer(fake, "x")
    old_value, args, kwargs = ar.replace("new", (1,), {"x": "old", "y": 2})
    assert old_value == "old" and args == (1,) and kwargs == {"x": "new", "y": 2}

    # Replace a positional argument.
    ar = ArgReplacer(fake, "y")
    old_value, args, kwargs = ar.replace("new", (1, "old"), {"y": 2})
    assert old_value == "old" and args == (1, "new") and kwargs

# Generated at 2022-06-22 04:30:30.644739
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import binascii

    DATA = (b"H4sIAAAAAAAA/3SMBRd7RFiUbfc+ltw40JHcR5xQ2IsGg3NaJWfDvZ9k5RffN5P5ecHwY8cL5h/B"
        b"/wdPwr8CuB/f+P4oEA6fzG6DQAAAA==")

    UNCOMPRESSED_DATA = b"Hello world!"

    decompressor = GzipDecompressor()
    data = decompressor.decompress(binascii.a2b_base64(DATA))
    assert data == UNCOMPRESSED_DATA
    assert not decompressor.unconsumed_tail
    assert decompressor.flush() == b""


# Generated at 2022-06-22 04:30:38.966075
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=3)) == 3
    assert timedelta_to_seconds(datetime.timedelta(seconds=3.5)) == 3.5
    assert timedelta_to_seconds(datetime.timedelta(seconds=3, microseconds=500)) == 3.0005
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=3000)) == 3


# pylint: disable=unused-argument
# type: Callable[[int], None]

# Generated at 2022-06-22 04:30:52.044949
# Unit test for constructor of class Configurable
def test_Configurable():
    def mock_constructor(self):  # type: ignore
        return self
    class Base(Configurable):
        def configurable_base(self):
            return Base
        def configurable_default(self):
            return BaseImpl
    class BaseImpl(Base):
        def configurable_base(self):
            return Base
        def configurable_default(self):
            return BaseImpl
        def initialize(self):
            self._initialize()
        initialize = mock_constructor
    class Impl1(Base):
        def configurable_base(self):
            return Base
        def configurable_default(self):
            return BaseImpl
        def initialize(self):
            self._initialize()
        initialize = mock_constructor
    class Impl2(Base):
        def configurable_base(self):
            return Base

# Generated at 2022-06-22 04:30:53.948882
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    TimeoutError()
    TimeoutError("foo")



# Generated at 2022-06-22 04:30:55.896682
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d['a'] = 0
    
    assert d.a == 0



# Generated at 2022-06-22 04:31:06.004782
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert (import_object('tornado.escape.utf8')
            is tornado.escape.utf8)
    assert import_object('tornado') is tornado
    import sys
    if "tornado.test.test_util" in sys.modules:
        # don't want to give an error during `python setup.py test`
        del sys.modules["tornado.test.test_util"]
    try:
        import_object('tornado.test.test_util')
    except ImportError:
        pass
    else:
        raise Exception("expected import failure")



# Generated at 2022-06-22 04:31:18.352912
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("a\\(b") == "a(b"
    assert re_unescape("a\\)b") == "a)b"
    assert re_unescape("a\\.b") == "a.b"
    assert re_unescape("a\\*b") == "a*b"
    assert re_unescape("a\\+b") == "a+b"
    assert re_unescape("a\\A") == "aA"
    assert re_unescape("a\\A[b") == "aA[b"
    assert re_unescape("a\\d") == "a\\d"
    assert re_unescape("a\\wb") == "a\\wb"
    assert re_unescape("a\\x41b") == "aAb"

# Generated at 2022-06-22 04:31:34.309186
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b=1):
        pass

    args = (1,)
    kwargs = {"b": 2}

    # test replace with an arg passed positionally
    old_value, args, kwargs = ArgReplacer(func, "a").replace(2, args, kwargs)
    assert old_value == 1
    assert args == (2,)
    assert kwargs == {"b": 2}

    # test replace with an arg passed by keyword
    old_value, args, kwargs = ArgReplacer(func, "b").replace(2, args, kwargs)
    assert old_value == 2
    assert args == (2,)
    assert kwargs == {"b": 2}

    # test add an arg with keyword

# Generated at 2022-06-22 04:31:38.568582
# Unit test for constructor of class Configurable
def test_Configurable():
    class Example(Configurable):
        @classmethod
        def configurable_base(cls): return Example

        @classmethod
        def configurable_default(cls): return ExampleImpl

        def initialize(self, value=None, **kwargs): self.value = value

    class ExampleImpl(Example):
        def initialize(self, value=None, **kwargs):
            super(ExampleImpl, self).initialize(value, **kwargs)
            self.impl = True

    class SubExample(Example):
        @classmethod
        def configurable_base(cls): return Example

        @classmethod
        def configurable_default(cls): return SubExampleImpl

        def initialize(self, value=None, **kwargs):
            super(SubExample, self).initialize(value, **kwargs)
            self.sub = True



# Generated at 2022-06-22 04:31:48.926306
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import zlib
    for x in ["hello", [1, 2, 3], {'a': 'b'}, 3.0, b"hi"]:
        gzip_compressor = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
        gzip_compressed_data = gzip_compressor.compress(repr(x).encode('utf-8')) + gzip_compressor.flush()
        gzip_decompressor = GzipDecompressor()
        data = gzip_decompressor.decompress(gzip_compressed_data)
        assert data == repr(x).encode('utf-8')



# Generated at 2022-06-22 04:32:00.695695
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    r"""Tests the method :meth:`decompress` of the class
    :class:`GzipDecompressor`

    For further information, see the documentation of the class
    :class:`GzipDecompressor`
    """
    decompressor = GzipDecompressor()

    # Test the decompress method
    print("Testing decompress method")

    decoder = zlib.decompressobj()
    file_content = open("tornado/test/fixtures/sample_reading.txt.gz", "rb").read()
    expected_content = decoder.decompress(file_content)

    compressed_content = open("tornado/test/fixtures/sample_reading.txt.gz", "rb").read()
    decompressed_content = decompressor.decompress(compressed_content)

    assert decompressed_

# Generated at 2022-06-22 04:32:12.756302
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class MyBase(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

        def initialize(self):
            # type: () -> None
            pass

    class MyImpl1(MyBase):
        pass

    class MyImpl2(MyBase):
        pass

    def initialize_args(mybase):
        # type: (MyBase) -> Tuple[Type[MyBase], ...]
        return (mybase.__class__,)

    # By default, we get the default implementation
    assert MyBase().__class__ is MyBase

    # configure an implementation
    My

# Generated at 2022-06-22 04:32:17.659778
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    a = ObjectDict()
    a.x = 1
    assert a['x'] == 1
    assert a.x == 1
    a['y'] = 2
    assert a.y == 2



# Generated at 2022-06-22 04:32:27.497455
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import zlib
    gd = GzipDecompressor()
    c1 = zlib.compress(b'Hello') + zlib.compress(b'World')
    assert gd.decompress(c1) == b'Hello'
    assert gd.decompress(b'') == b'World'
    assert gd.flush() == b''
    gd = GzipDecompressor()
    gd.flush()
    assert gd.decompress(c1) == b'HelloWorld'
    assert gd.flush() == b''


# Per http://www.xfree86.org/4.8.0/DRI.html, the drawable modifier
# is the high 16 bits of the drawable value.
DRAWABLE_MOD_XFREE86 = 0x1


# Generated at 2022-06-22 04:32:38.644357
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def sample_func(arg1, arg2, arg3):
        return arg1, arg2, arg3
    sample_arg1 = 1
    sample_arg2 = "arg2"
    sample_arg3 = "arg3"
    sample_arg = ("arg",)
    sample_kwarg2 = "kwarg2"
    sample_kwarg3 = "kwarg3"
    sample_kwarg = ("kwarg",)

    def sample_func1(*args, **kwargs):
        return args, kwargs

    # test case
    old_value, args, kwargs = ArgReplacer(sample_func, "arg1").replace(
        sample_arg, (sample_arg1, sample_arg2, sample_arg3), {})
    assert old_value == sample_arg1
    assert args == sample_

# Generated at 2022-06-22 04:32:42.536583
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass
    except Exception:
        raise Exception("Failed to instantiate TimeoutError")



# Generated at 2022-06-22 04:32:48.867187
# Unit test for function exec_in
def test_exec_in():
    def test():
        x = 1
        exec_in("y = x + 1", globals(), locals())
        assert y == 2
    test()
    try:
        exec_in("z = y + 1", globals(), locals())
        raise Exception("did not get expected exception")
    except NameError as e:
        assert e.args[0] == "name 'y' is not defined"



# Generated at 2022-06-22 04:33:09.758017
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import time

    class TestConfigurable(Configurable):

        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurableBase

        def initialize(self):
            pass

        def start(self):
            pass

    class TestConfigurableBase(TestConfigurable):

        def initialize(self, *args, **kwargs):
            super(TestConfigurableBase, self).initialize(*args, **kwargs)
            # print("Base:In initialize()")

        def start(self):
            pass

    class TestConfigurableImpl(TestConfigurable):

        def initialize(self, *args, **kwargs):
            super(TestConfigurableImpl, self).initialize(*args, **kwargs)
            # print("Impl:In initialize()")


# Generated at 2022-06-22 04:33:15.834073
# Unit test for function re_unescape
def test_re_unescape():
    import random

    for i in range(100):  # type: int
        s = "".join(
            chr(i)
            for i in range(256)
            if random.random() > 0.8 and chr(i) not in _alphanum
        )
        assert re_unescape(re.escape(s)) == s



# Generated at 2022-06-22 04:33:25.507285
# Unit test for function import_object
def test_import_object():
    # Simple and direct test of import_object
    assert import_object("time") is time
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError as e:
        assert str(e) == 'No module named missing_module'
    else:
        assert False, 'expected ImportError'
    # Test of import_object used by application
    import_object('os')
    import_object('os.path')



# Generated at 2022-06-22 04:33:29.327611
# Unit test for function import_object
def test_import_object():
    assert import_object('sys') is sys
    assert import_object('tornado.escape.url_escape') is tornado.escape.url_escape
    try:
        import_object('tornado.missing_module')
        assert False, "import_object did not raise an exception"
    except ImportError:
        pass



# Generated at 2022-06-22 04:33:34.341158
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
        assert False
    except ImportError:
        pass
    del tornado



# Generated at 2022-06-22 04:33:46.301674
# Unit test for function re_unescape
def test_re_unescape():
    # Special cases
    assert re_unescape("") == ""
    assert re_unescape(".") == "."
    assert re_unescape("\\") == "\\"

    # More or less random selection of characters to escape.
    assert re_unescape("\\a") == "\a"
    assert re_unescape("\\n\\r") == "\n\r"
    assert re_unescape("\\b\\f\\07\\377") == "\b\f\x07\xff"
    assert re_unescape("\\xAA\\XaA\\u1234\\U00012345") == "\xaa\xaa\u1234\U00012345"
    assert re_unescape("\\0123\\00123\\123") == "\x0123\x123{123"

    # Named groups cannot be unescaped; they are

# Generated at 2022-06-22 04:33:50.576226
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d['x'] = 42
    assert d.x == 42

    # __getattr__ shouldn't get mixed up with __getitem__
    d = ObjectDict()
    d.x = 42
    assert d['x'] == 42


# Generated at 2022-06-22 04:33:53.768711
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0



# Generated at 2022-06-22 04:34:04.667632
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError(u"test")
    TimeoutError(u"test") == u"test"
    assert TimeoutError(u"test") != 123
    try:
        raise TimeoutError(u"test")
    except TimeoutError as e:
        assert e.args == (u"test",)
    assert u"test" in str(TimeoutError(u"test"))
    assert str(TimeoutError(u"test")) == u"Message: 'test'"
    assert repr(TimeoutError(u"test")) == u"TimeoutError(u'test')"


# Make our own version so that its exception syntax matches other Tornado
# exceptions.

# Generated at 2022-06-22 04:34:08.738577
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass
    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, None) == 2
    assert r.get_old_value((1,), {"b": 2, "c": 3}) == 2
    assert r.replace(4, (1, 2, 3), {}) == (2, (1, 4, 3), {})
    assert r.replace(4, (1,), {"b": 2, "c": 3}) == (2, (1,), {"b": 4, "c": 3})

# Generated at 2022-06-22 04:34:27.230833
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception("Test Exception")
    except Exception as e:
        assert errno_from_exception(e)
    try:
        raise Exception(123)
    except Exception as e:
        assert errno_from_exception(e) == 123
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-22 04:34:38.028618
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    test_cases = [
        ("tornado.escape", tornado.escape, None),
        ("tornado.escape.utf8", tornado.escape.utf8, None),
        ("tornado", tornado, None),
        ("tornado.missing_module", None, ImportError),
    ]
    for input, expected, expected_fail in test_cases:
        try:
            result = import_object(input)
            if expected_fail:
                raise AssertionError("expected failure %s = %s" %
                                     (input, result))
            assert result is expected
        except Exception as e:
            if expected_fail:
                assert isinstance(e, expected_fail), (input, expected_fail, e)
                continue
            raise



# Generated at 2022-06-22 04:34:47.990563
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Testing the whole behaviour of method replace
    class TestArgReplacer(object):
        def __init__(self, test_value_1, test_value_2, test_value_3):
            self.test_value_1 = test_value_1
            self.test_value_2 = test_value_2
            self.test_value_3 = test_value_3
        
        def test_method(self, first_arg, second_arg):
            return first_arg, second_arg

    test_object = TestArgReplacer(1, 2, 3)

    replacer = ArgReplacer(test_object.test_method, "second_arg")
    
    test_args = ["a", "b"]
    test_kwargs = {"first_arg": "a", "second_arg": "b"}

    old

# Generated at 2022-06-22 04:34:53.612554
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    dict_ = {}
    obj_dict = ObjectDict(dict_)
    obj_dict.value = "value"
    assert dict_["value"] == "value"


# Generated at 2022-06-22 04:35:02.051821
# Unit test for function re_unescape
def test_re_unescape():
    testing = '\a\b\f\n\r\t\v\\\'"'
    test_result = re_unescape(testing)
    assert len(test_result) == 11
    assert test_result[0] == 7  # this is the ascii BEL character
    assert test_result[1] == 8  # this is the ascii BS character
    assert test_result[2] == 12  # this is the ascii FF character
    assert test_result[3] == 10  # this is the ascii LF character
    assert test_result[4] == 13  # this is the ascii CR character
    assert test_result[5] == 9  # this is the ascii TAB character
    assert test_result[6] == 11  # this is the ascii VT character
    assert test_

# Generated at 2022-06-22 04:35:12.656956
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest


    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurableImpl

        def __init__(self, arg, kwarg="default"):
            # Configurable uses initialize instead of __init__.
            pass

        def initialize(self, arg, kwarg="default"):
            self.arg = arg
            self.kwarg = kwarg

    class TestConfigurableImpl(TestConfigurable):
        pass

    class TestConfigurableSubclass(TestConfigurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurableSubclass

        @classmethod
        def configurable_default(cls):
            return

# Generated at 2022-06-22 04:35:19.229574
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(
        datetime.timedelta(10, 3600, 12345)) == 86410.12345
    assert timedelta_to_seconds(datetime.timedelta(days=-10)) == -864000.0



# Generated at 2022-06-22 04:35:28.677403
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 1e-06
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=1)) == 1e-03
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 3600 * 24
    assert timedelta_to_seconds(datetime.timedelta(weeks=1)) == 3600 * 24 * 7



# Generated at 2022-06-22 04:35:31.770790
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    e = TimeoutError("foo")  # type: Exception
    assert e.args == ("foo",)



# Generated at 2022-06-22 04:35:43.543096
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\"") == '"'
    assert re_unescape(r"\\") == "\\"
    assert re_unescape(r"\(") == "("
    assert re_unescape(r"\?") == "?"
    assert re_unescape(r"\a") == "\a"
    assert re_unescape(r"\b") == "\b"
    assert re_unescape(r"\f") == "\f"
    assert re_unescape(r"\n") == "\n"
    assert re_unescape(r"\r") == "\r"
    assert re_unescape(r"\t") == "\t"
    assert re_unescape(r"\v") == "\v"

# Generated at 2022-06-22 04:36:14.736461
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class SomeClass(object):
        def __init__(
            self,
            m1: int,
            m2: int = 0,
            m3: str = "",
            m4: int = 0,
            m5: Optional[int] = None,
            m6: List[str] = None,
            m7: str = "",
            *args: Any,
            **kwargs: Any
        ) -> None:
            pass

    replacer = ArgReplacer(SomeClass.__init__, "m7")
    assert replacer.name == "m7"
    assert replacer.arg_pos == 6



# Generated at 2022-06-22 04:36:26.011427
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta()) == 0.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(days=-1)) == -86400.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, minutes=1)) == 90060.0


if not hasattr(datetime.timedelta, "total_seconds"):
    timedelta_to_seconds = timedelta_to_seconds  # type: ignore



# Generated at 2022-06-22 04:36:31.426534
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        try:
            raise ValueError("foo")
        except:
            raise_exc_info(sys.exc_info())
    except ValueError as e:
        print("got exception", e)
    else:  # noqa: B011
        raise Exception("did not get exception")



# Generated at 2022-06-22 04:36:43.302939
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # This function is only for testing and has no function outside of that
    def f(a, b, c=3, d=4, *args, **kwargs):
        pass

    value0, args0, kwargs0 = ArgReplacer(f, "a").replace(0, (1, 2, 3), {})
    assert value0 == 1
    assert args0 == (0, 2, 3)

    value1, args1, kwargs1 = ArgReplacer(f, "b").replace(0, (1, 2, 3), {})
    assert value1 == 2
    assert args1 == (1, 0, 3)

    value2, args2, kwargs2 = ArgReplacer(f, "c").replace(0, (1, 2, 3), {})
    assert value2 == 3
    assert kw

# Generated at 2022-06-22 04:36:50.314559
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    compressed = b"fake gzipped data"
    assert decompressor.decompress(compressed) == b""
    assert decompressor.unconsumed_tail == compressed

# Based on
# http://stackoverflow.com/questions/1838699/how-can-i-decompress-a-gzip-stream-with-zlib/1838704#1838704
# This solution is not great (it would be better to use the zlib
# library directly to avoid the data copying) but it's better than
# nothing.



# Generated at 2022-06-22 04:36:54.805724
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():

    @typing.overload
    def GzipDecompressor_flush(self) -> bytes: ...

    def GzipDecompressor_flush(self) -> bytes:
        ...
    return GzipDecompressor_flush

# Generated at 2022-06-22 04:36:59.044788
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def test_fn():
        try:
            # Raise an exception
            raise ValueError()
        except ValueError:
            exc_info = sys.exc_info()
            # Raise that exception again using raise_exc_info
            raise_exc_info(exc_info)
    with pytest.raises(ValueError):
        test_fn()



# Generated at 2022-06-22 04:37:09.005971
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    from tornado.testing import AsyncTestCase, gen_test

    def test_gzip_decompressor(data: bytes) -> None:
        d = GzipDecompressor()
        decompressed = d.decompress(data)
        # only one call to decompress is allowed
        if d.unconsumed_tail:
            decompressed += d.decompress(d.unconsumed_tail)
        # if decompress returns b'' and unconsumed_tail is also b'',
        # decompress will raise an exception
        assert decompressed != b'' or d.unconsumed_tail != b''
        # return decompressed data and flush the decompressor
        decompressed += d.flush()
        assert decompressed, b''
        assert d.unconsumed_tail, b''


# Generated at 2022-06-22 04:37:19.337793
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gz = GzipDecompressor()
    data = gz.decompress(
        b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xed\xcd\xc9\xc9'
        b'\x07\x00!\x08\xceL\xcaI,I\xe1\x02\x00D\xac\n\x8c,\x08\x00\x00\x00')
    assert gz.flush() == b'pag'
    assert gz.unconsumed_tail == b''



# Generated at 2022-06-22 04:37:21.148311
# Unit test for function exec_in
def test_exec_in():
    foo = object()
    exec_in('foo = bar', {'bar': foo})
    assert foo is foo



# Generated at 2022-06-22 04:37:49.815383
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c):
        return a, b, c

    arg_replacer = ArgReplacer(test_func, 'a')
    print(arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c':3}))

# Generated at 2022-06-22 04:37:50.916321
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    t = Configurable()
    t.initialize()


# Generated at 2022-06-22 04:37:55.664321
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
    try:
        raise_exc_info(exc_info)
    except ValueError:
        pass



# Generated at 2022-06-22 04:38:06.012402
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f1(x: int, y: int = 2) -> int:
        """This function is used for testing ArgReplacer.
        """
        return x + y

    def test(args: Tuple[int, int], kwargs: Dict[str, int], new: int) -> None:
        """This function is used for testing ArgReplacer.
        """
        replacer = ArgReplacer(f1, "x")
        old_value = replacer.get_old_value(args, kwargs)
        assert old_value == args[0]
        _, new_args, new_kwargs = replacer.replace(new, args, kwargs)
        assert new_args[0] == new
        replacer = ArgReplacer(f1, "y")
        old_value = replacer.get_old

# Generated at 2022-06-22 04:38:17.821966
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"""\$ ^ \. \+ \* \\ """) == "$ ^ . + * \\ "
    assert re_unescape(r"\\t") == "\t"
    assert re_unescape(r"\\u") == "\\u"
    assert re_unescape(r"ab\\") == "ab\\"
    assert re_unescape(r"ab\\c") == "ab\\c"
    assert re_unescape(r"\\q") == "q"
    assert re_unescape(r"\\u") == "\\u"
    assert re_unescape(r"\d") == "d"
    assert re_unescape(r"\\011") == "\011"
    assert_raises(
        ValueError, lambda: re_unescape(r"\\q"),
    )


# Generated at 2022-06-22 04:38:29.954355
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    a = ['test_name']
    b = {'test_name': 'test_value'}
    c = ArgReplacer(test_ArgReplacer_replace, 'test_name')
    assert c.replace('test_value1', a, b) == ('test_value', ['test_value1'], {'test_name': 'test_value'})
    a = []
    b = {'test_name': 'test_value'}
    assert c.replace('test_value1', a, b) == (None, [], {'test_name': 'test_value1'})
    a = []
    b = {}
    assert c.replace('test_value1', a, b) == (None, [], {'test_name': 'test_value1'})


# Generated at 2022-06-22 04:38:34.058417
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Sample(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
        def initialize(self):
            pass
    s = Sample()



# Generated at 2022-06-22 04:38:42.838486
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    class ObjectDict(Dict[str, Any]):
        """Makes a dictionary behave like an object, with attribute-style access.
        """

        def __getattr__(self, name: str) -> Any:
            try:
                return self[name]
            except KeyError:
                raise AttributeError(name)

        def __setattr__(self, name: str, value: Any) -> None:
            self[name] = value

    test = ObjectDict()
    test.aaa = 1
    aaa = test.aaa
    assert aaa == 1



# Generated at 2022-06-22 04:38:52.149764
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    test_string = 'test_string'
    test = zlib.compress(test_string.encode())
    decompressor = GzipDecompressor()
    decompressor.decompress(test)
    assert decompressor.flush() == test_string.encode()
    decompressor.decompress(b'')
    assert decompressor.flush() == test_string.encode()
    assert decompressor.unconsumed_tail == b''
    test_string = 'test_string'
    test = zlib.compress(test_string.encode())
    decompressor = GzipDecompressor()
    decompressor.decompress(test)
    assert decompressor.flush() == test_string.encode()
    # decompressor.decompress(b'error')
    # assert decompressor.flush() == b''

# Generated at 2022-06-22 04:39:02.625318
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=3):
        pass

    ar = ArgReplacer(f, "b")
    assert ar.arg_pos == 1
    assert ar.get_old_value((10, 20, 30), {}) == 20
    v, args, kwargs = ar.replace(50, (10, 20, 30), {})
    assert v == 20
    assert args == (10, 50, 30)
    assert kwargs == {}
    v, args, kwargs = ar.replace(50, (10,), {"c": 30})
    assert v is None
    assert args == (10,)
    assert kwargs == {"b": 50, "c": 30}



# Generated at 2022-06-22 04:39:34.201598
# Unit test for function re_unescape
def test_re_unescape():
    def assert_unescape(s: str, unescaped: str) -> None:
        assert s == re.escape(unescaped)
        assert re_unescape(s) == unescaped

    assert_unescape(re.escape("\\"), "\\")
    assert_unescape(re.escape("a"), "a")
    assert_unescape(re.escape("."), ".")
    assert_unescape(re.escape("\\t"), "\\t")
    assert_unescape(re.escape("abc"), "abc")
    assert_unescape(re.escape("a\\bc"), "a\\bc")



# Generated at 2022-06-22 04:39:45.803635
# Unit test for constructor of class Configurable
def test_Configurable():
    # pylint: disable=W0212
    class Test1(Configurable):
        @classmethod
        def configurable_base(cls):
            return Test1

        @classmethod
        def configurable_default(cls):
            return Test1Impl

        def initialize(self):
            pass

    class Test2(Test1):
        @classmethod
        def configurable_base(cls):
            return Test2

        @classmethod
        def configurable_default(cls):
            return Test2Impl

        def initialize(self):
            pass

    class Test1Impl(Test1):
        pass

    class Test2Impl(Test2):
        pass

    assert issubclass(Test1.configured_class(), Test1)
    assert issubclass(Test2.configured_class(), Test2)

   