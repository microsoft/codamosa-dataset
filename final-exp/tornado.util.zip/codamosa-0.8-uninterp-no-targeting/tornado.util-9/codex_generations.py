

# Generated at 2022-06-22 04:30:22.418902
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    @typing.no_type_check
    def TestGzipDecompressor_flush(self: 'unittest.TestCase'):
        import binascii

# Generated at 2022-06-22 04:30:28.816408
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        def initialize(self, init_arg):
            pass

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    class B(A):
        def initialize(self, init_arg):
            pass
    A.configure(B)
    A()  # B is created



# Generated at 2022-06-22 04:30:29.553369
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 04:30:39.946538
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # Baseline: What GzipDecompressor does
    gd = GzipDecompressor()
    gd.decompress(b"")
    assert gd.unconsumed_tail == b""
    assert gd.flush() == b""
    assert gd.unconsumed_tail == b""

    # 1. Prove that GzipDecompressor is actually a wrapper around
    #    zlib.decompressobj.
    assert gd.decompressobj is gd.flush().__self__
    assert gd.decompressobj.unconsumed_tail == b""

    # 2. Test that the flush() works the same way as
    #    decompressobj.flush()
    gd.decompress(b"xyz")
    assert gd.unconsumed_tail == b"xyz"


# Generated at 2022-06-22 04:30:49.734394
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def fake_func(*args, **kwargs):
        pass

    a = ArgReplacer(fake_func, "arg1")
    assert a.name == "arg1"
    assert a.arg_pos == 0

    a = ArgReplacer(fake_func, "arg2")
    assert a.name == "arg2"
    assert a.arg_pos is None

    try:
        a = ArgReplacer(fake_func, "arg4")
        assert False
    except ValueError:
        pass


# For others to subclass

# Generated at 2022-06-22 04:30:59.602657
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    def test(**kwargs: Any) -> None:
        obj = ObjectDict(**kwargs)
        for k, v in kwargs.items():
            obj.setdefault(k, None)
            assert obj[k] == v

            if isinstance(k, str):
                assert getattr(obj, k) == v
                setattr(obj, k, v)
                assert getattr(obj, k) == v

        assert obj.setdefault('hello', 'world') == 'world'
        assert obj.setdefault('hello', 'mars') == 'world'
        assert obj.get('hello', 'mars') == 'world'
        assert obj.get('goodbye') is None
        assert obj.pop('goodbye', 'mars') == 'mars'
        assert obj.pop('hello', 'mars')

# Generated at 2022-06-22 04:31:01.703100
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    __args = []  # type: List[Any]
    __kwargs = {}  # type: Dict[str, Any]
    __return = None  # type: Any
    pass

# Generated at 2022-06-22 04:31:11.661442
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    x = ObjectDict({"a": "b"})
    assert x.a == "b"
    assert x["a"] == "b"
    x.a = "d"
    assert x.a == "d"
    assert x["a"] == "d"
    x["a"] = "e"
    assert x.a == "e"
    assert x["a"] == "e"


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__"
# break tab completion in the interactive interpreter.  We can't detect
# whether the runtime is 2 or 3 so we just always add the marker.

# Generated at 2022-06-22 04:31:18.265772
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    def run_test():
        # Test `GzipDecompressor`
        data = b"Testing compress and decompress: GzipDecompressor"
        source_data = zlib.compress(data)
        decompressor = GzipDecompressor()
        assert decompressor.decompress(source_data) == data
        assert decompressor.flush() == b""

    run_test()



# Generated at 2022-06-22 04:31:28.349438
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    x = ObjectDict()
    assert repr(ObjectDict()) == repr({})
    assert repr(x) == repr({})
    x["test"] = "test"
    assert x.test == "test"
    x.test2 = "test2"
    assert x["test2"] == "test2"
    x[3] = 3
    assert x[3] == 3
    x.y = ObjectDict(z=3)
    assert x.y.z == 3
    x.w = ObjectDict()
    x.w.a = 1
    x.w.b = ObjectDict(c=1)
    assert x.w.a == 1
    assert x.w.b.c == 1

# Generated at 2022-06-22 04:31:48.443752
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\t") == "\t"
    assert re_unescape(r"\A") == "A"
    assert re_unescape(r"\b") == "\b"
    assert re_unescape(r"\f") == "\f"
    assert re_unescape(r"\n") == "\n"
    assert re_unescape(r"\r") == "\r"
    assert re_unescape(r"\t") == "\t"
    assert re_unescape(r"\v") == "\v"

    assert re_unescape(r"\d") == "d"
    assert re_unescape(r"\x41") == "x41"
    assert re_unescape(r"\11") == "11"

# Generated at 2022-06-22 04:31:50.407632
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.b = 'test'
    assert isinstance(a, dict)
    assert a['b'] == 'test'



# Generated at 2022-06-22 04:31:59.109174
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(foo=1, bar='a')
    assert d.foo == d['foo']
    assert d.bar == d['bar']
    d.foo = 2
    assert d.foo == d['foo']
    assert d.bar == d['bar']
    d['foo'] = 3
    assert d.foo == d['foo']
    assert d.bar == d['bar']
    assert 'foo' in d
    assert 'missing' not in d
    try:
        d.missing
    except Exception as e:
        assert isinstance(e, AttributeError)



# Generated at 2022-06-22 04:32:11.527392
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f1(a, b, c=3):
        return a+b+c
    def f2(a, b, c,**kwargs):
        return a+b+c,kwargs
    def f3(a=1,b=2,c=3,**kwargs):
        return a+b+c,kwargs
    def f4(a=1,b=2,c=3,**kwargs):
        return a+b+c,kwargs
    r=ArgReplacer(f1,'c')
    assert r.get_old_value((1,2),{},None)  == 3
    assert r.get_old_value((1,2,4),{},None) == 4
    assert r.get_old_value((1,2,4),{'c':'c'},None)

# Generated at 2022-06-22 04:32:15.893168
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    td = datetime.timedelta(1, 1, 1)
    assert timedelta_to_seconds(td) == timedelta_to_seconds(td)
    assert timedelta_to_seconds(td) == (1.0 + 1.0/10**6 + 1.0/10**12)
    assert timedelta_to_seconds(datetime.timedelta(hours=25)) == timedelta_to_seconds(
        datetime.timedelta(days=1, hours=1)
    )
    assert timedelta_to_seconds(datetime.timedelta(-5, -4, -3)) == timedelta_to_seconds(
        datetime.timedelta(-6, -83_904 - 3)
    )
test_timedelta_to_seconds.__test__ = False  # type: ignore




# Generated at 2022-06-22 04:32:26.213073
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    test_data = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff" + \
                b"\x4a\xcc\x4b\x55\x28\xcf\x2f\xca\x49\xe1\x02\x00\x15\x0f" + \
                b"\x8b\x8a\xac\x94\x0f\x00\x00\x00"
    compressed_stream = io.BytesIO()
    compressed_stream.write(test_data)
    compressed_stream.seek(0)
    f = GzipFile(fileobj=compressed_stream, mode='rb')

# Generated at 2022-06-22 04:32:30.271055
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d):
        return (a, b, c, d)
    has_a, args, kwargs = ArgReplacer('a', foo).replace('has_a', (1, 2), dict(c=3, d=4))
    assert foo(*args, **kwargs) == ('has_a', 2, 3, 4)
    assert has_a is None
    has_b, args, kwargs = ArgReplacer('b', foo).replace('has_b', ('a', 2), dict(c=3, d=4))
    assert foo(*args, **kwargs) == ('a', 'has_b', 3, 4)
    assert has_b is 2

# Generated at 2022-06-22 04:32:38.645048
# Unit test for function import_object
def test_import_object():
    def test_equal(name: str, function: Any) -> None:
        assert function is import_object(name)
    test_equal("tornado.util.import_object", import_object)
    test_equal("tornado.escape._url_escape", tornado.escape.url_escape)
    test_equal("tornado.escape._utf8", tornado.escape.utf8)
    test_equal("tornado", tornado)
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected import error"



# Generated at 2022-06-22 04:32:42.113391
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict({'a': 1})
    obj.b = 2
    assert isinstance(obj, ObjectDict)


# Generated at 2022-06-22 04:32:44.621772
# Unit test for function import_object
def test_import_object():
    test=import_object('tornado.util') is tornado.util
    print(test)



# Generated at 2022-06-22 04:32:57.066826
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    if True:
        p = ObjectDict()
        p.name = 'Jim'
        p.age = 25
        assert p.name == 'Jim'



# Generated at 2022-06-22 04:33:01.821753
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d["x"] == 1
    d.x = 2
    assert d["x"] == 2



# Generated at 2022-06-22 04:33:06.142175
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    for cls in [TestClassforConfigurable, TestClassforConfigurable1]:
        cls.configure(TestClassforConfigurable, x=1)
        a = cls()
        assert a.x == 1


# Generated at 2022-06-22 04:33:17.130447
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    a = ArgReplacer(lambda: None, "replace_me")
    assert a

    class Test(object):
        def __init__(self, x, a):
            pass

    a = ArgReplacer(Test, "x")
    assert a
    old_value, args, kwargs = a.replace(1, (), {"a": 2})
    assert old_value is None
    assert args == ()
    assert kwargs == {"a": 2, "x": 1}

    a = ArgReplacer(Test, "a")
    assert a
    old_value, args, kwargs = a.replace(3, (4,), {"x": 1})
    assert old_value == 2
    assert args == (4,)
    assert kwargs == {"x": 1}

# Generated at 2022-06-22 04:33:27.833803
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b):
        return a, b

    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.replace(1, (2, 3), {}) == (3, (2, 1), {})
    assert arg_replacer.replace(1, (2,), {"b": 3}) == (3, (2,), {"b": 1})
    assert arg_replacer.replace(1, (), {"b": 3}) == (3, (), {"b": 1})
    assert arg_replacer.replace(1, (2,), {}) == (None, (2,), {"b": 1})
    try:
        arg_replacer.replace(1, (), {})
    except TypeError as e:
        assert "func() missing 1 required positional argument" in str(e)

# Generated at 2022-06-22 04:33:28.404470
# Unit test for function doctests
def test_doctests():
    test_mod(module=None)


# Generated at 2022-06-22 04:33:30.282650
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.x = 10
    d['y']
    d['z'] = 50



# Generated at 2022-06-22 04:33:31.091052
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    assert TimeoutError().__cause__ is None



# Generated at 2022-06-22 04:33:32.295427
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    _ = GzipDecompressor()



# Generated at 2022-06-22 04:33:34.609047
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    x = ObjectDict()  # type: ObjectDict
    x.a = 1
    assert x['a'] == 1
    assert x.a == 1



# Generated at 2022-06-22 04:33:54.034317
# Unit test for constructor of class Configurable
def test_Configurable():
    class DummyConfigurable(Configurable):
        """Implements Configurable for use in tests.
        """

        @classmethod
        def configurable_base(cls):
            return DummyConfigurable

        @classmethod
        def configurable_default(cls):
            return DefaultImpl

    class DefaultImpl(DummyConfigurable):
        """Default implementation of DummyConfigurable.
        """
        initialized = False

        def initialize(self):
            self.initialized = True

    class AlternateImpl(DummyConfigurable):
        """Alternate implementation of DummyConfigurable.
        """
        initialized = False

        def initialize(self):
            self.initialized = True

    c = DummyConfigurable()
    assert isinstance(c, DefaultImpl)
    assert c.initialized
    DummyConfigurable.configure(AlternateImpl)

# Generated at 2022-06-22 04:33:58.131048
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import doctests
    import unittest
    import sys
    import os

    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite())
    # Test some doctests that can't be run automatically
    # use nose's automatic doctest selector
    top_dir = os.path.dirname(os.path.dirname(doctests.__file__))
    globs = {'tornado': tornado, 'gen': gen, 'ArgReplacer': ArgReplacer}
    for module in (tornado, gen, httputil, options, platform, stack_context, iostream):
        globs[module.__name__] = module

# Generated at 2022-06-22 04:34:09.377080
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        exc_type, exc_value, _ = sys.exc_info()
        assert exc_type is TimeoutError
        assert str(exc_value) == ''


# aliases for backward compatibility
gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log = gen_log

# Generated at 2022-06-22 04:34:21.680840
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    import datetime
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    # timedelta's constructor isn't friendly to float days
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1.1)) == 86401.1
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=1)) == -86399.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=-1)) == 86399.0

# Generated at 2022-06-22 04:34:33.766727
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\1\2\a") == "\1\2\a"
    assert re_unescape(r"a\\\ +b") == r"a\\\ +b"
    assert re_unescape(r"\x00\x01\x42") == "\x00\x01B"
    assert re_unescape(r"\\\\x\n\\n") == r"\\x\n\n"
    assert re_unescape(r"\x61\u0062\U00000063") == "abc"
    assert re_unescape(r"\U00010203") == "\x00\x01\x02\x03"
    assert re_unescape(r".*\\") == r".*\\"

# Generated at 2022-06-22 04:34:35.729990
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d["x"] = 5
    assert d.x == 5
    assert d["x"] == 5


# Generated at 2022-06-22 04:34:46.488187
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is a copy of code in tornado/httputil.py.
    # We need to make sure that the code path that calls the
    # GzipDecompressor constructor is exercised at least once.
    # If you change GzipDecompressor, you should also update
    # this test.
    decompressor = GzipDecompressor()
    with open(__file__, "rb") as file:
        with GzipDecompressor() as decompressor:
            data = decompressor.decompress(file.read(1024))
            for chunk in iter(lambda: file.read(1024), b""):
                data += decompressor.decompress(chunk)
            data += decompressor.flush()
            assert decompressor.unconsumed_tail == b""
            assert data



# Generated at 2022-06-22 04:34:54.428078
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    # The empty string is gzip-encoded and base64 encoded, so it
    # was compressed and then encoded.
    from io import BytesIO
    from base64 import b64decode
    from functools import partial
    import gzip

# Generated at 2022-06-22 04:35:00.087740
# Unit test for function exec_in
def test_exec_in():  # type: () -> None
    glob = {}
    exec_in('foo = 6', glob)
    assert glob['foo'] == 6, glob
    loc = {}
    exec_in('bar = 8', glob, loc)
    assert loc['bar'] == 8, loc
    loc = {}
    exec_in('baz = 10', glob, loc)
    assert glob['baz'] == 10, glob
test_exec_in()



# Generated at 2022-06-22 04:35:12.360409
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) == 0

    try:
        raise Exception(None)
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception([1])
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception({1: 1})
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception([1, 2])
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-22 04:35:25.258743
# Unit test for function import_object
def test_import_object():
    def test(name: str, expected: Any) -> None:
        assert import_object(name) is expected, name
        assert import_object(name + '.__class__') is expected.__class__, name
        try:
            import_object(name + '.missing_attribute')
        except ImportError:
            pass
        else:
            assert False, name

    test("tornado.ioloop.IOLoop", IOLoop)
    test("tornado.escape.utf8", utf8)
    test("tornado", tornado)
    test("sys", sys)



# Generated at 2022-06-22 04:35:26.879565
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o.foo = 123
    assert o.foo == 123



# Generated at 2022-06-22 04:35:33.646886
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(a, b, c):
        pass

    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 4}

# Generated at 2022-06-22 04:35:37.527837
# Unit test for function exec_in
def test_exec_in():
    loc = {}
    exec_in("a = 42", globals())
    assert a == 42
    exec_in("b = 43", loc)
    assert b == 43
    exec_in("c = 44", globals(), loc)
    assert c == 44



# Generated at 2022-06-22 04:35:50.678462
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    def func(a, b, c=42, d=40, *e, **f):
        pass
    replacer = ArgReplacer(func, "c")
    assert replacer.get_old_value((1, 2), {'d': 0}) == 42
    assert replacer.get_old_value((1, 2), {'c': 0}) == 0
    assert replacer.get_old_value((1, 2), {}) == 42
    assert replacer.get_old_value((1, 2), {'c': 0, 'd': 0}) == 0
    assert replacer.get_old_value((1, 2), {'c': 0, 'd': 0}, None) == 0
    assert replacer.get_old_value((1, 2), {'h': 0}) == 42

# Generated at 2022-06-22 04:35:54.022482
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    b = ObjectDict()
    b.attr = 'value'
    assert b == {"attr": "value"}
    assert b['attr'] == 'value'
    assert b.attr == 'value'
    assert b.foo == None



# Generated at 2022-06-22 04:36:07.086089
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    from inspect import Parameter, Signature

    def func1(x, y, z):
        pass

    def func2(x, z=4):
        pass

    def func3(*a):
        pass

    def func4(**a):
        pass

    def func5(x=1):
        pass

    def func6(*x, **y):
        pass

    def func7(x, *, y=1):
        pass

    def func8(x, *y, **z):
        pass

    def func9(x, y=2, z=3):
        pass

    def func10(x, y, z=4):
        pass

    def func_none(a):
        pass

    def func_empty():
        pass

    # Test the various types of arguments

# Generated at 2022-06-22 04:36:16.640255
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\a") == "a"
    with pytest.raises(ValueError):
        re_unescape(r"\d")
    assert re_unescape(r"\\") == "\\"
    assert re_unescape(r"\\\a") == r"\a"
    with pytest.raises(ValueError):
        re_unescape(r"\\d")
    assert re_unescape(r"\\\d") == r"\d"


# Note that this code will not work in a __str__ method within a class that
#  uses logging--str(self) will call logging.Formatter.format() (since
#  it's part of a LogRecord), which will in turn call self.__str__().

# Generated at 2022-06-22 04:36:30.044697
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def myfunc(a: int, b: int, c: int = 3) -> None:
        pass
    r = ArgReplacer(myfunc, "c")
    assert r.arg_pos is None
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {}, default=None) == 3
    assert r.get_old_value((1, 2), {"c": 3}) == 3
    assert r.get_old_value((1, 2), {}) is None
    assert r.replace(4, (1, 2, 3), {}) == (3, (1, 2, 4), {})

# Generated at 2022-06-22 04:36:41.920812
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return DefaultImpl

    class DefaultImpl(Base):
        pass

    class Impl1(Base):
        pass

    class Impl2(Base):
        pass

    # Test default
    x = Base()
    assert isinstance(x, DefaultImpl)

    # Test configure
    Base.configure(Impl1)
    x = Base()
    assert isinstance(x, Impl1)

    # Test configure args
    Base.configure(Impl2, foo="bar")
    x = Base()
    assert isinstance(x, Impl2)
    assert x.foo == "bar"
    Base.configure(None)
    x = Base()
   

# Generated at 2022-06-22 04:36:59.126647
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'a')

    old, new_args, new_kwargs = arg_replacer.replace(1, (2, 3,), {'c' : 4, 'a' : 7})
    assert(old == 7)
    assert(new_args == (1, 3,))
    assert(new_kwargs == {'c' : 4, 'a' : 7})

    old, new_args, new_kwargs = arg_replacer.replace(1, (2, 3,), {'c' : 4, })
    assert(old == None)
    assert(new_args == (1, 3,))
    assert(new_kwargs == {'c' : 4, 'a' : 1})


# Unit test

# Generated at 2022-06-22 04:37:09.034743
# Unit test for function re_unescape
def test_re_unescape():
    # type: () -> None
    assert re_unescape(r"\a") == "\\a"
    assert re_unescape(r"abc") == "abc"
    assert re_unescape(r"\.\*\?") == ".*?"
    assert re_unescape(r"\a\b\f\n\r\t\v") == "\\a\\b\\f\\n\\r\\t\\v"
    assert re_unescape(r"\x61\x62\x63") == "abc"
    assert re_unescape(r"\u0061\u0062\u0063") == "abc"
    assert re_unescape(r"\U00000061\U00000062\U00000063") == "abc"

# Generated at 2022-06-22 04:37:09.998867
# Unit test for function doctests
def test_doctests():
    # type: () -> unittest.TestSuite
    import doctest

    return doctest.DocTestSuite()



# Generated at 2022-06-22 04:37:22.431793
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = GzipDecompressor()
    # 由于无法在if语句里判断对象是否是文件，所以用字符串代替

# Generated at 2022-06-22 04:37:28.278774
# Unit test for function re_unescape
def test_re_unescape():
    for s in [
        "abc",
        "abc\\def",
        "abc\\def\\",
        "abc\\def\\\\",
        "abc\\20def",
        "abc\\0020def",
        "abc\\000020def",
        "\\5e",
        "\\75e",
        "\\75\\0065",
        "\\75\\000065",
        "\\055",
    ]:
        try:
            assert re_unescape(s) == re_unescape(re.escape(s))
        except ValueError:
            assert re.escape(s) != s
    assert re_unescape("\\d") == r"\d"



# Generated at 2022-06-22 04:37:39.463709
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    orig_data = b"This is a test"
    f = open('/tmp/gzip_decompressor.gz', 'wb')
    g = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS + 16)
    f.write(g.compress(orig_data))
    f.write(g.flush())
    f.close()

    f = open('/tmp/gzip_decompressor.gz', 'rb')
    g = GzipDecompressor()
    decomp = b""
    while True:
        buf = f.read()
        if not buf:
            break
        decomp += g.decompress(buf)
    f.close()
    os.remove('/tmp/gzip_decompressor.gz')
    assert decomp == orig_data


# Generated at 2022-06-22 04:37:44.599982
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-22 04:37:49.634480
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    from typing import Any
    from typing import Dict
    from typing import Optional
    from typing import Type
    from typing import TypeVar

    T = TypeVar('T')

    def _cast(T: Type[T], x: Any) -> T:
        assert isinstance(x, T)
        return x



# Generated at 2022-06-22 04:37:50.987179
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a = {'x': 1}
    assert ObjectDict(a).x == 1

# Generated at 2022-06-22 04:37:54.229244
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    D = {"test": 123}
    assert ObjectDict(D).test == 123



# Generated at 2022-06-22 04:38:16.052272
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0


# This is the same as typing.cast except that it also works in python 3.5.

# Generated at 2022-06-22 04:38:27.883517
# Unit test for constructor of class Configurable
def test_Configurable():
    # Configure the class with a subclass
    class MockConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return None

        def _initialize(self, *args, **kwargs):
            pass

    class MockConfigurableSubclass(MockConfigurable):
        pass

    MockConfigurable.configure(MockConfigurableSubclass)
    assert MockConfigurable.configured_class() is MockConfigurableSubclass
    assert isinstance(MockConfigurable(x=1), MockConfigurableSubclass)

    # Configure the class with a string
    MockConfigurable.configure("tornado.util.Configurable")
    assert MockConfigurable.configured_class() is Configurable

# Generated at 2022-06-22 04:38:37.790618
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    # In the case of an IOError or OSError (subclasses of Exception),
    # the errno attribute was added in Python 3.3.
    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise OSError()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception('test message')
    except Exception as e:
        assert errno_from_exception(e) == 'test message'


# Generated at 2022-06-22 04:38:49.892423
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(arg1, arg2, arg3):
        pass
    
    test_obj = ArgReplacer(f, "arg2")
    test_args = ("test11", "test12", "test13")
    test_kwargs = {"arg3": "test3"}
    
    # Test that arg2 has been replaced and the old value is returned
    val = test_obj.replace("test2", test_args, test_kwargs)
    assert val == ("test12", ("test11", "test2", "test13"), {"arg3": "test3"})
    
    # Test that if arg2 is missing, new_value is added to kwargs
    test_args = ("test11", "test13")
    val = test_obj.replace("test2", test_args, test_kwargs)
    assert val

# Generated at 2022-06-22 04:38:57.657860
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    """Unit test for method flush of class GzipDecompressor"""
    data = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\x0b\x00\x1b\x00\xff\xff\n/\x00\x1a\x00\x00\x00"
    dec = GzipDecompressor()
    result = dec.decompress(data)
    assert result == b"\n/\x00\x1a"
    result = dec.flush()
    assert result == b""
    result = dec.unconsumed_tail
    assert result == b""



# Generated at 2022-06-22 04:39:00.611200
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    d = GzipDecompressor()
    assert isinstance(d, GzipDecompressor)


# Generated at 2022-06-22 04:39:04.406850
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    e = RuntimeError("test")  # type: BaseException
    try:
        try:
            raise e
        finally:
            e = None
    except Exception as e2:
        assert e2 is not e
        tb1 = e2.__traceback__
        raise_exc_info((None, e2, None))
        tb2 = e2.__traceback__
        assert tb1 is tb2



# Generated at 2022-06-22 04:39:16.643301
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b):
        return

    ar = ArgReplacer(func, "a")
    assert ar.get_old_value(("c", "d"), {}) == "c"
    assert ar.get_old_value(("c", "d"), {}, "x") == "c"
    assert ar.get_old_value(("c", "d"), {"a": "e"}) == "e"
    assert ar.get_old_value(("c", "d"), {"a": "e"}, "x") == "e"

    ar = ArgReplacer(func, "b")
    assert ar.get_old_value(("c", "d"), {}) is None
    assert ar.get_old_value(("c", "d"), {}, "x") == "x"
    assert ar.get_old

# Generated at 2022-06-22 04:39:29.482392
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():  # type: () -> None
    # We are using this stream
    gzip_stream = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6d\x54\xcf\x4f\xca\x24'\
                  b'\x08\xce\xcf\x4f\x4a\x4c\x49\x55\x2c\x4e\x2c\x49\x2c\x49\xe5\x04'\
                  b'\x00\x90\x5a\x9d\x5b\x0e\x00\x00\x00'

    # Initialize GzipDecompressor
    decompressor = GzipDecompressor()

    # Test decomp

# Generated at 2022-06-22 04:39:36.770317
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    assert str(e) == ''
    e = TimeoutError('hello')
    assert str(e) == 'hello'
    # Test that the alias works
    from tornado.gen import TimeoutError as GenTimeoutError
    e = GenTimeoutError('hello')
    assert str(e) == 'hello'
    from tornado.ioloop import TimeoutError as IOLoopTimeoutError
    e = IOLoopTimeoutError('hello')
    assert str(e) == 'hello'

