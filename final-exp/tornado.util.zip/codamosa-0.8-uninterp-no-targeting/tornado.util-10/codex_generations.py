

# Generated at 2022-06-22 04:30:21.678723
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return None

    class B(A):
        def configurable_base(self):
            return B

        def configurable_default(self):
            return None

    # Tests for not configured
    try:
        A()
    except ValueError:
        pass
    else:
        raise AssertionError("Not configured A class should raise ValueError")
    try:
        B()
    except ValueError:
        pass
    else:
        raise AssertionError("Not configured B class should raise ValueError")

    # Test configuration of A
    A.configure("tornado.test.util.test_configurable.A")
    a = A()
    assert type(a) is A

# Generated at 2022-06-22 04:30:24.590801
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(2, 3)) == 172800 + 3



# Generated at 2022-06-22 04:30:35.478817
# Unit test for function re_unescape
def test_re_unescape():
    # type: () -> None
    assert re_unescape("abc") == "abc"
    assert re_unescape("abc\\.") == "abc\\."
    assert re_unescape("abc\\\n\\\r\\\t\\\\\\!\\(\\)\\*\\+\\-\\?\\[\\]\\{\\}\\^\\|") == "abc\n\r\t\\!()*+-?[]{}^|"
    assert re_unescape("\\d") == "\\d"
    assert re_unescape("\\D") == "\\D"
    assert re_unescape("\\x") == "\\x"
    assert re_unescape("\\X") == "\\X"
    assert re_unescape("\\w") == "\\w"

# Generated at 2022-06-22 04:30:43.788535
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import types
    import unittest

    class TestConfigurable(Configurable):
        "This is just a test"
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestConfigurable
        def initialize(self, *args, **kwargs):
            pass
    # Test the class TestConfigurable
    TestConfigurable().__new__(TestConfigurable)
    # Test the super class Configurable
    Configurable().__new__(Configurable)



# Generated at 2022-06-22 04:30:56.100504
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    class B(A):
        def _initialize(self):
            self.x = 0
            self.y = 1
            self.z = 2
    with pytest.raises(NotImplementedError):
        B.configured_class()
    with pytest.raises(NotImplementedError):
        B.configurable_base()
    with pytest.raises(NotImplementedError):
        B.configurable_default()
    with pytest.raises(ValueError):
        B.configure(object)
    A.configure(B, x = 3, y = 4)

# Generated at 2022-06-22 04:31:06.849876
# Unit test for function raise_exc_info
def test_raise_exc_info():  # type: () -> None
    def raises():  # type: () -> typing.NoReturn
        # use raise_exc_info to avoid raising a new traceback and losing the
        # stack of the original exception.
        raise_exc_info(sys.exc_info())

    try:
        raises()
    except Exception as e:
        # ok to access outer scope variables
        assert excinfo == sys.exc_info()
        assert e is excinfo[1]
    else:
        # no exception? that is bad
        assert False

    try:
        raise Exception("foo")
    except Exception as e:
        excinfo = sys.exc_info()

        raises()
    else:
        assert False



# Generated at 2022-06-22 04:31:08.976314
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def f():
        pass
    o = ObjectDict()
    o.attr = False
    o.attr2 = f()


# Generated at 2022-06-22 04:31:21.159027
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # test with position and keyword args
    def foo(bar, baz, qux=1):
        return (bar, baz, qux)
    ar = ArgReplacer(foo, "qux")
    assert ar.replace(2, (1, 2), {}) == (1, (1, 2), {})
    assert ar.replace(2, (1, 2), {'qux': 3}) == (3, (1, 2), {'qux': 2})
    assert ar.replace(2, (1, 2), {'qux': 3, 'corge': 4}) == (3, (1, 2), {'qux': 2, 'corge': 4})

# Generated at 2022-06-22 04:31:24.658356
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    od = ObjectDict()
    od.a = 1
    od.b = 2
    answer = [1, 2]
    assert od.a == answer[0]
    assert od.b == answer[1]

# Generated at 2022-06-22 04:31:28.348516
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a,b):
        pass
    obj = ArgReplacer(f, "a")
    args = [1,2,]
    kwargs = {}
    print(obj.get_old_value(args, kwargs))


# Generated at 2022-06-22 04:31:54.784553
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f():  # type: () -> typing.NoReturn
        raise ArithmeticError()

    try:
        f()
    except ArithmeticError:
        pass

    try:
        raise_exc_info((None, ArithmeticError(), None))
    except ArithmeticError:
        pass

    # shouldn't be passed a tuple without an exception in it
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass



# Generated at 2022-06-22 04:31:58.120378
# Unit test for function exec_in
def test_exec_in():
    l = locals()
    exec_in('a = 5', globals(), l)
    assert(l['a'] == 5)

# Generated at 2022-06-22 04:32:00.554366
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError.__init__(TimeoutError(), "message")


# This exception is no longer used internally anywhere, but we leave it
# defined here in case any external users are depending on it.
DeprecatedTimeo

# Generated at 2022-06-22 04:32:05.844159
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-22 04:32:10.010880
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    e = 'def do_call(self, *args, **kwargs):'
    code = compile(e, 'do_call.py', 'exec')
    def test_get_old_value(name, args, kwargs, expect):
        # type: (str, Sequence[Any], Dict[str, Any], Any) -> None
        argReplacer = ArgReplacer(test_get_old_value, name)
        assert expect == argReplacer.get_old_value(args, kwargs)
    test_get_old_value('key', [], {'key':1}, 1)
    test_get_old_value('key', [3, 4], {'key':1}, 1)

# Generated at 2022-06-22 04:32:12.461954
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    GzipDecompressor()

# In Python 2, str objects are not bytes objects, and do not have the
# buffer interface.  This class allows them to be used where bytes objects
# and the buffer interface are required.

# Generated at 2022-06-22 04:32:24.272956
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test, LogTrapTestCase

    class DocTestCase(AsyncTestCase, LogTrapTestCase):
        def test_doctests(self):
            # type: () -> None
            tests = doctests()
            for test in tests:
                if test._dt_test.name.startswith("tornado.escape"):
                    self.io_loop.run_sync(lambda: self.io_loop.run_sync(test.run))

            self.assertEqual(0, self.flushLoggedErrors(Exception))

    tests = doctests()
    if tests.countTestCases():
        return DocTestCase  # type: ignore


# Generated at 2022-06-22 04:32:36.780913
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """Test case for method '__new__' of class 'Configurable'."""

    class TestClass(Configurable):
        def configurable_base(cls):
            return cls

        def configurable_default(cls):
            return cls

        def _initialize(self, a, b, c=3):
            self.a, self.b, self.c = a, b, c

    instance1 = TestClass(1, 2)
    assert instance1.a == 1
    assert instance1.b == 2
    assert instance1.c == 3

    instance2 = TestClass(1, 2, c=4)
    assert instance2.a == 1
    assert instance2.b == 2
    assert instance2.c == 4

    TestClass.configure(None, c=5)
    assert TestClass.configured

# Generated at 2022-06-22 04:32:49.274037
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\.") == r"."
    assert re_unescape(r"\a") == r"\a"
    assert re_unescape(r"\b") == r"\b"
    assert re_unescape(r"\f") == r"\f"
    assert re_unescape(r"\n") == r"\n"
    assert re_unescape(r"\r") == r"\r"
    assert re_unescape(r"\t") == r"\t"
    assert re_unescape(r"\v") == r"\v"
    assert re_unescape(r"\_") == r"_"

# Generated at 2022-06-22 04:32:57.388134
# Unit test for function exec_in
def test_exec_in():
    x = 1
    loc = dict(x=0)
    glb = dict(x=2)
    exec_in('x = 3', glb, loc)
    assert loc["x"] == 3
    assert glb["x"] == 2
    exec_in('assert x == 3')
    exec_in('assert x == 3', glb)
    assert "x" not in glb
    assert "x" not in globals()


# Fake byte literal for non-3.x tests
if bytes is str:
    def b(s: str) -> bytes:
        return s.encode("latin1")  # type: ignore
else:
    b = bytes


_UNSET = object()

_ARGSPEC_PARAMS = getfullargspec(lambda x: None)[0]  # type: ignore



# Generated at 2022-06-22 04:33:08.856773
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise Exception("foo")
    except Exception:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-22 04:33:16.000270
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-22 04:33:26.908873
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # pragma: no cover
    import operator

    d = ObjectDict(a=1, b=2)
    assert d["a"] == 1
    assert d.a == 1
    assert d.b == 2
    assert sorted(d.keys()) == ["a", "b"]
    assert sorted(list(d.items()), key=operator.itemgetter(0)) == [("a", 1), ("b", 2)]
    d.c = 3
    assert hasattr(d, "c")
    assert d["c"] == 3
    del d.c
    assert not hasattr(d, "c")


# Fake byte literal support:  In python 2.6+, you can say b"foo" to
# get a byte literal (str in 2.x, bytes in 3.x).  There's no way to
# do this in

# Generated at 2022-06-22 04:33:34.867705
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(5)
    except Exception as e:
        assert errno_from_exception(e) == 5
    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-22 04:33:47.028291
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(1)
    except IOError as e:
        assert errno_from_exception(e) == 1
    try:
        raise IOError(1, "a")
    except IOError as e:
        assert errno_from_exception(e) == 1
    try:
        try:
            raise IOError(1, "a")
        except IOError as e:
            assert errno_from_exception(e) == 1
            raise IOError(2) from e
    except IOError as e:
        assert errno_from_exception(e) == 2
        assert errno_from_exception(e) == 2


_DEFAULT

# Generated at 2022-06-22 04:33:51.490561
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class B(Configurable):
        def initialize(self, arg1, arg2, arg3):
            print("arg1 = {}, arg2 = {}, arg3 = {}".format(arg1, arg2, arg3))
    B.configure(None)
    b = B(1, 2, 3)



# Generated at 2022-06-22 04:34:04.235377
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return DefaultFoo

        def initialize(self):
            self._args = [1, 2]
            self._kwargs = {'k': 1}

    class DefaultFoo(Foo):
        def initialize(self):
            self._args = [0]
            self._kwargs = {}

    class BadFoo(Foo):
        def initialize(self):
            raise Exception('Should not be called')

    class Bar(Foo):
        @classmethod
        def configurable_base(cls):
            return Bar

        @classmethod
        def configurable_default(cls):
            return DefaultBar


# Generated at 2022-06-22 04:34:10.003270
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(42, 'Test')
    except OSError as e:
        errno = errno_from_exception(e)
        assert errno == 42, errno

    try:
        raise OSError('Test')
    except OSError as e:
        errno = errno_from_exception(e)
        assert errno == 'Test', errno


# Generated at 2022-06-22 04:34:22.229737
# Unit test for constructor of class Configurable
def test_Configurable():  # noqa: F811
    class Dummy(Configurable):
        x = 1
        @classmethod
        def configurable_base(cls):
            return Dummy
        @classmethod
        def configurable_default(cls):
            return DefaultDummy
    class DefaultDummy:
        x = 2

    class SubDummy(Dummy):
        y = 1
    class OtherDummy(Dummy):
        y = 2
    class SubSubDummy(SubDummy):
        z = 1

    assert SubDummy().x == 1
    assert SubDummy.configured_class() == SubDummy
    assert SubDummy().y == 1
    assert isinstance(SubDummy(), SubDummy)
    assert not isinstance(SubDummy(), OtherDummy)


# Generated at 2022-06-22 04:34:34.259592
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # Test 1:
    o = ObjectDict({'a': 1})
    assert o.a == 1
    assert o['a'] == 1

    # Test 2:
    with pytest.raises(AttributeError):
        o.b

    # Test 3:
    with pytest.raises(KeyError):
        o['b']

    # Test 4:
    for name in '__getattr__', '__setattr__', '__delattr__':
        with pytest.raises(AttributeError):
            getattr(o, name)


# Tell nose to skip this module
__test__ = False  # type: ignore[attr-defined]

# These constants are no longer used in Tornado itself but remain as
# documentation of their use in other projects.  Many other projects
# have copied these constants, sometimes with minor modifications,


# Generated at 2022-06-22 04:34:58.056125
# Unit test for constructor of class Configurable
def test_Configurable():
    class ConfigurableTest(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableTest

        @classmethod
        def configurable_default(cls):
            return ConfigurableTest

        def initialize(self, clear=False):
            if clear:
                self.params = {}
            else:
                self.params = kwargs
        #enddef

    kwargs = dict(foo=1, bar=2)
    args = []
    assert(ConfigurableTest.configured_class() == ConfigurableTest)
    instance = ConfigurableTest(*args, **kwargs)
    assert(isinstance(instance, ConfigurableTest))
    assert(instance.params == kwargs)

    class ConfigurableSubclassTest(ConfigurableTest):
        pass
    #endclass

# Generated at 2022-06-22 04:35:00.311181
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    class D(ObjectDict):
        def __init__(self):
            # type: () -> None
            Dict.__init__(self, a=1)

    assert D()['a'] == 1


# Generated at 2022-06-22 04:35:12.404886
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    a = [1, 2]
    b = {}

    ar = ArgReplacer(test_args, 'a')
    old, newa, newb = ar._replace('a', a, b)
    assert old == None
    assert newa == [1, 2]
    assert newb == {'a': 'a'}
    old, newa, newb = ar._replace('b', a, b)
    assert old == 1
    assert newa == [2, 'b']
    assert newb == {'a': 'a'}
    old, newa, newb = ar._replace('c', a, b)
    assert old == None
    assert newa == [2, 'b']
    assert newb == {'a': 'a', 'c': 'c'}


# Generated at 2022-06-22 04:35:15.515493
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            print('configurable_base')
            return TestConfigurable

        def configurable_default(self):
            print('configurable_default')
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            print('TestConfigurable_initialize')
            self.args = args
            self.kwargs = kwargs

    TestConfigurable.configure(None, configurable=True)
    TestConfigurable('abc')


# Generated at 2022-06-22 04:35:22.792570
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=1)
    d.b = 2
    del d.a
    d.c = 3
    assert d.b == 2
    assert d.c == 3
    try:
        d.d
        assert False
    except AttributeError:
        pass
    try:
        d.d = 4
        assert False
    except AttributeError:
        pass
    assert repr(d) == "{'b': 2, 'c': 3}"



# Generated at 2022-06-22 04:35:34.392671
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Test that GzipDecompressor works in the face of random input
    import itertools

    def random_iter(n: int) -> List[bytes]:
        # Iterate over a series of n random bytes.  It's not *quite*
        # random input because the test cases repeat, but it's good
        # enough for a unit test.
        return [os.urandom(1) for i in range(n)]

    for i in range(100):
        x = GzipDecompressor()
        chunks = random_iter(i)
        for chunk in chunks:
            x.decompress(chunk)
        remainder = x.unconsumed_tail
        for remainder in itertools.chain((remainder,), random_iter(i)):
            x.decompress(remainder)
        assert x.un

# Generated at 2022-06-22 04:35:42.414061
# Unit test for function import_object
def test_import_object():
    assert import_object('sys') is sys
    assert import_object('mock.Mock').__name__ == 'Mock'
    # Note this will raise an ImportError on Python 3
    import mock
    import_object('mock.Mock').__name__ == 'Mock'
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    with pytest.raises(ImportError):
        import_object('tornado.missing_module')



# Generated at 2022-06-22 04:35:45.720317
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise IndexError(123)
    except IndexError as e:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-22 04:35:50.049368
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b=None): pass
    ar = ArgReplacer('a', foo)
    ar.get_old_value((1, 2), {})



# Generated at 2022-06-22 04:36:00.754718
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import zlib
    stream = zlib.compress('foo')
    stream += zlib.compress('bar')
    stream += zlib.compress('baz')
    gzip_stream = bytes()
    gzip_stream += b'\x1f'
    gzip_stream += b'\x8b'
    gzip_stream += b'\x08'
    gzip_stream += b'\x08'
    gzip_stream += b'\xbd\x4c\x5e\x4f'
    gzip_stream += b'\x00\x03'
    gzip_stream += b'\xcb'
    gzip_stream += b'H'
    gzip_stream += b'\xcd'
    gzip_stream += b'C'
    gzip_stream

# Generated at 2022-06-22 04:36:15.513649
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    replaced_args = []
    replaced_kwargs = {}
    def f(*args, **kwargs):
        a = ArgReplacer(f, "foo")
        old_value, args, kwargs = a.replace("new", args, kwargs)
        replaced_args.append(args)
        replaced_kwargs.update(kwargs)
        return old_value
    assert f("old", foo="old") == "old"
    assert f("old", foo="new") == "new"
    assert f("old") == None
    assert f("old", bar="bar") == None
    assert f(foo="old") == "old" # type: ignore
    assert f(foo="old", bar="bar") == "old" # type: ignore

# Generated at 2022-06-22 04:36:18.509849
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    settings = ObjectDict()
    settings.is_debug = True
    settings.cookie_secret = "cookie secret"
    del settings["cookie_secret"]
    del settings.is_debug
    
    

# Generated at 2022-06-22 04:36:26.122436
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-22 04:36:36.670421
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"a\s\Qb\E") == "a\\s\\Qb\\E"
    assert re_unescape(r"a\s\\Qb\\E") == "a\\s\\\\Qb\\\\E"
    assert re_unescape(r"a\s\\\\Qb\\\\E") == "a\\s\\\\\\\\Qb\\\\\\\\E"
    # \d is an error
    try:
        re_unescape(r"a\d")
        assert False, "expected ValueError"
    except ValueError as e:
        assert str(e) == "cannot unescape '\\\\d'"
    # \Z is an error
    try:
        re_unescape(r"a\Z")
        assert False, "expected ValueError"
    except ValueError as e:
        assert str(e)

# Generated at 2022-06-22 04:36:41.865589
# Unit test for function raise_exc_info
def test_raise_exc_info():  # type: () -> None
    try:
        raise ValueError()
    except ValueError:
        _exc_info = sys.exc_info()
        raise_exc_info(_exc_info)



# Generated at 2022-06-22 04:36:46.547953
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj_dict = ObjectDict()
    obj_dict['a'] = 1
    assert obj_dict.a == 1
    try:
        obj_dict.b
    except AttributeError:
        pass
    else:
        assert False


# Deprecated alias
ObjectDictMixin = ObjectDict



# Generated at 2022-06-22 04:36:53.274919
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    from io import BytesIO
    from gzip import GzipFile
    from optparse import OptionParser

    def utf8(s: str) -> bytes:
        return s.encode("utf-8")

    def test(s: str) -> bytes:
        return GzipDecompressor().decompress(utf8(s))

    parser = OptionParser()
    parser.add_option("-l", "--length", type = "int",
                      help = "test decompress(buf, length) (default 0)")
    options, args = parser.parse_args()

    # Unfortunately, it's not easy to actually test
    # decompress(buf, length) in Python 3.3, because gzip doesn't
    # support incremental compression.
    tail = b""
    if options.length is None:
        buf = utf8

# Generated at 2022-06-22 04:37:02.355473
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, foo, bar=8, **kwargs):
            pass

    Base.configure(BaseImpl)
    assert Base().__class__ == BaseImpl
    assert Base(foo=17)

    class Impl1(Base):
        def initialize(self, foo, bar=8, **kwargs):
            pass

    class Impl2(Base):
        def initialize(self, foo, bar=9, **kwargs):
            pass

    Base.configure(Impl1)
    assert Base().__class__ == Impl1
    assert Base(foo=17).__class__ == Impl1

# Generated at 2022-06-22 04:37:12.042295
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from typing import Callable
    from functools import wraps

    class IOLoop(object):
        @classmethod
        def instance(cls):
            raise NotImplementedError()

        def start(self):
            pass

        def stop(self):
            pass

    def when_ready(func: Callable, io_loop: IOLoop):
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper


    @when_ready
    def get_app(io_loop):
        return 1

    assert get_app(IOLoop.instance) == 1

    replacer = ArgReplacer(get_app, "io_loop")
    old_io_loop = replacer.get_old_value([], {})
    assert old_

# Generated at 2022-06-22 04:37:12.583384
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()

# Generated at 2022-06-22 04:37:25.364589
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # object_dict = ObjectDict()
    # with pytest.raises(AttributeError):
    #     object_dict.name = 3
    #     assert object_dict.name == 3
    #     assert object_dict['name'] == 3
    # object_dict['name'] = 3
    # assert object_dict.name == 3
    pass



# Generated at 2022-06-22 04:37:36.817267
# Unit test for function re_unescape

# Generated at 2022-06-22 04:37:47.566892
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict()
    obj['foo'] = 'bar'
    assert obj.foo == 'bar'
    assert obj['foo'] == 'bar'

    obj.bar = [1, 2, 3]
    assert obj['bar'] == [1, 2, 3]
    assert obj.bar == [1, 2, 3]

    obj.bar.append(4)
    assert obj['bar'] == [1, 2, 3, 4]
    assert obj.bar == [1, 2, 3, 4]

    obj['bar'].append(5)
    assert obj.bar == [1, 2, 3, 4, 5]
    assert obj['bar'] == [1, 2, 3, 4, 5]


# Generated at 2022-06-22 04:37:59.307779
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, x):
            self.value = x

    a1 = A(1)
    a2 = A(2)
    assert a1.value == 1
    assert a2.value == 2

    class B(A):
        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self, x):
            self.value = x * 2

    a3 = B(1)
    a4 = B(2)
    assert a3.__class__ is B
    assert a3.value == 2
    assert a4.value == 4

    # A is still configurable

# Generated at 2022-06-22 04:38:09.631944
# Unit test for function import_object
def test_import_object():
    from tornado.escape import native_str
    # Relative import in same module.
    from . import util
    assert import_object('.') is util
    assert import_object('.util') is util
    # Relative import in parent module.
    import tornado
    assert import_object('..') is tornado
    assert import_object('..tornado') is tornado
    assert import_object('tornado.util') is util
    assert import_object('tornado.util.import_object') is import_object
    # Relative import in grandparent module.
    assert import_object('...') is tornado
    assert import_object('...tornado') is tornado
    # Absolute import.
    assert import_object('tornado.util') is util
    assert import_object('tornado.util.import_object') is import_object
    # Missing module.


# Generated at 2022-06-22 04:38:16.776446
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import zlib
    source = b'hello world'
    z = zlib.compressobj()
    compressed = z.compress(source)
    compressed += z.flush()
    decompressor = GzipDecompressor()
    decompressed = decompressor.decompress(compressed)
    assert b'hello world' == decompressed
    remainder = decompressor.flush()
    assert remainder == b''
    return
test_GzipDecompressor_flush()



# Generated at 2022-06-22 04:38:18.203333
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None

    a = ObjectDict({"x": 2})
    # Test for __getattr__
    assert a.x == 2

# Generated at 2022-06-22 04:38:28.196158
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass

    arg = ArgReplacer(foo, 'c')
    assert arg.replace(3, [1, 2], dict(b=20)) == (None, [1, 2], dict(b=20, c=3))
    assert arg.replace(30, [1, 2], dict(b=20, c=3)) == (3, [1, 2], dict(b=20, c=3))
    assert arg.replace(300, [1, 2, 3], dict(b=20)) == (3, [1, 2, 300], dict(b=20))


# Generated at 2022-06-22 04:38:33.749143
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = {"a":1, "b":2}
    obj = ObjectDict(d)
    assert isinstance(obj, ObjectDict)
    assert obj.a == 1
    obj = ObjectDict(a=1, b=2)
    assert isinstance(obj, ObjectDict)
    assert obj.get("b") ==2
    obj.c = 3
    assert obj.c == 3



# Generated at 2022-06-22 04:38:37.666967
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(a, b):
        pass
    func = ArgReplacer(f, "a")
    args = (1, 2)
    kwargs = {}
    assert func.replace(100, args, kwargs) == (1, (100, 2), {})


# Generated at 2022-06-22 04:39:05.773443
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    from tornado.web import Application, RequestHandler
    from tornado.ioloop import IOLoop
    import tornado.testing
    import tornado.httpserver
    import sys

    class ErrorHandler(RequestHandler):
        def get(self):
            # Use sys.exc_info() here because it's cheaper than
            # re-raising the exception, and it's the same format
            # that would be used by traceback.print_exc.
            raise_exc_info(sys.exc_info())
        post = get

    def error_wrapper(method):
        def wrapper(self, *args, **kwargs):
            try:
                return method(self, *args, **kwargs)
            except Exception:
                raise_exc_info(sys.exc_info())

# Generated at 2022-06-22 04:39:08.259622
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.foo = 'bar'
    baz = obj.foo



# Generated at 2022-06-22 04:39:18.577992
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func = lambda a,b,c: None

    assert ArgReplacer(func,"c").get_old_value((1,2,3),{},"d") == 3
    assert ArgReplacer(func,"b").get_old_value((1,2,3),{},"d") == 2
    assert ArgReplacer(func,"a").get_old_value((1,2,3),{},"d") == 1

    assert ArgReplacer(func,"c").get_old_value((1,),{},"d") == "d"
    assert ArgReplacer(func,"b").get_old_value((1,),{},"d") == "d"
    assert ArgReplacer(func,"a").get_old_value((1,),{},"d") == 1


# Generated at 2022-06-22 04:39:22.977669
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 1
    d.bar = 2
    d.foo != 2
    assert len(d) == 2


# Generated at 2022-06-22 04:39:33.752478
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(x, y, z):
        pass

    class someclass(object):
        def bar(self, x, y, z):
            pass

    assert ArgReplacer(foo, "x").arg_pos == 0
    assert ArgReplacer(foo, "y").arg_pos == 1
    assert ArgReplacer(foo, "z").arg_pos == 2
    assert ArgReplacer(foo, "w").arg_pos is None

    assert ArgReplacer(someclass.bar, "x").arg_pos == 1
    assert ArgReplacer(someclass.bar, "y").arg_pos == 2
    assert ArgReplacer(someclass.bar, "z").arg_pos == 3
    assert ArgReplacer(someclass.bar, "w").arg_pos is None



# Generated at 2022-06-22 04:39:41.478930
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    """
    >>> def foo():
    ...   try:
    ...     1/0
    ...   except:
    ...     raise_exc_info(sys.exc_info())
    ...
    >>> foo()
    Traceback (most recent call last):
      ...
    ZeroDivisionError: division by zero
    """
    pass

# Shortcuts for common Exception classes.
# Keep in alphabetical order.
_exc_info = (Exception, Exception("dummy"), None)



# Generated at 2022-06-22 04:39:50.299376
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    replacer = ArgReplacer(func, "b")
    assert replacer.get_old_value((1, 2, 3), {}, True) == 2
    assert replacer.get_old_value((1, 2, 3), {"c": 3}, True) == 2
    assert replacer.get_old_value((1, 2, 3), {"b": 100, "c":3}, True) == 100
    assert replacer.get_old_value((1, 2, 3), {"b":100}, True) == 100
    replacer2 = ArgReplacer(func, "d")
    assert replacer2.get_old_value((1, 2, 3), {}, True) is True
