

# Generated at 2022-06-22 04:30:14.743714
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    class A:
        def f(self, a, b=2):
            pass
    func = A().f
    replacer = ArgReplacer(func, "b")
    assert not replacer.get_old_value((1,),{}, False)
    assert replacer.get_old_value((1,5),{}, False) == 5


# Generated at 2022-06-22 04:30:22.987093
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return D

        def initialize(self, a, b=1):
            # type: (int, int) -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        def initialize(self, a, b=2):
            # type: (int, int) -> None
            pass

    class E(A):
        def initialize(self, a, b=3):
            # type: (int, int) -> None
            pass


# Generated at 2022-06-22 04:30:28.865319
# Unit test for function raise_exc_info
def test_raise_exc_info():
    r1 = re.compile(r"^\s*raise_exc_info\(\)")
    def line_with_raise_exc_info():
        return list(filter(r1.match,
                           [l.lstrip()
                            for l in traceback.format_stack()]))[0]

    try:
        raise Exception("foo")
    except:
        exc_info = sys.exc_info()
        try:
            raise_exc_info(exc_info)
        except Exception as e:
            assert e is exc_info[1]
            assert type(e) is exc_info[0]
            assert e.args == ("foo",)
            assert line_with_raise_exc_info() not in e.__traceback__.tb_frame.f_code.co_code


# Generated at 2022-06-22 04:30:39.855632
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import zlib

    class TestConfigurable(Configurable):
        def initialize(self):
            pass

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurableDefault

    class TestConfigurableDefault(TestConfigurable):
        pass

    class TestConfigurableNonDefault(TestConfigurable):
        pass

    TestConfigurable.configure(None)
    assert TestConfigurable()

    saved = TestConfigurable._save_configuration()

    TestConfigurable.configure("tornado.util.TestConfigurableNonDefault")
    assert isinstance(TestConfigurable(), TestConfigurableNonDefault)

    TestConfigurable._restore_configuration(saved)
    assert isinstance(TestConfigurable(), TestConfigurableDefault)

   

# Generated at 2022-06-22 04:30:43.500120
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    value = b'hello\0\0\0\0\0'
    test_GzipDecompressor_decompress(value)




# Generated at 2022-06-22 04:30:50.725875
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    def foo():
        from tornado.log import gen_log
        from tornado.web import RequestHandler
        from tornado.escape import to_unicode
    class _ConfigurableSubclass(Configurable):
        def configurable_base(self):
            return ConfigurableSubclass
        def configurable_default(self):
            return ConfigurableSubclass
        def initialize(self, *args, **kwargs):
            pass

# Generated at 2022-06-22 04:31:00.249582
# Unit test for constructor of class Configurable
def test_Configurable():
    class TestConfigurable(Configurable):
        default_impl = None  # type: Type[Configurable]
        initialized = False

        def initialize(self):
            self.initialized = True

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return cls.default_impl

    class Impl1(TestConfigurable):
        pass

    class Impl2(TestConfigurable):
        pass

    class SubImpl(Impl2):
        pass

    # Constructor of Impl1 should always function as expected.
    inst = Impl1()
    assert inst.initialized

    # Constructor of SubImpl should always function as expected.
    inst = SubImpl()
    assert inst.initialized

    # Constructor of Impl2 is initially configured to be the same


# Generated at 2022-06-22 04:31:03.383675
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ZeroDivisionError()
    except ZeroDivisionError:
        raise_exc_info(sys.exc_info())  # Should not return.



# Generated at 2022-06-22 04:31:05.461306
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        x = 1 / 0
    except:
        ex = sys.exc_info()
        raise_exc_info(ex)



# Generated at 2022-06-22 04:31:10.659114
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=60)) == 60.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=-60)) == -60.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=60, microseconds=1)) == 60.000001
    assert timedelta_to_seconds(datetime.timedelta(minutes=1, seconds=60)) == 120.0
    assert timedelta_to_seconds(datetime.timedelta(minutes=-1, seconds=-60)) == -120.0
    # https://github.com/tornadoweb/tornado/issues/3679
    assert timedelta_to_seconds(datetime.timedelta(seconds=2534, microseconds=1)) == 2534.000001
    assert timed

# Generated at 2022-06-22 04:31:27.743666
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    pass



# Generated at 2022-06-22 04:31:38.766087
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"
    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(1)
    except IOError as e:
        assert errno_from_exception(e) == 1
    try:
        raise IOError("foo")
    except IOError as e:
        assert errno_from_exception(e)

# Generated at 2022-06-22 04:31:49.952341
# Unit test for function errno_from_exception

# Generated at 2022-06-22 04:31:51.885049
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    if sys.version_info < (2, 7):
        assert timedelta_to_seconds(datetime.timedelta(1, 1, 1)) == 86401.000001
    else:
        assert timedelta_to_seconds(datetime.timedelta(1, 1, 1)) == 86401.0



# Generated at 2022-06-22 04:31:54.526452
# Unit test for function exec_in
def test_exec_in():
    globals = {}
    locals = {}
    exec_in("foo = 'bar'", globals, locals)
    assert globals["foo"] == "bar"
    assert locals["foo"] == "bar"



# Generated at 2022-06-22 04:31:58.325023
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    args = ('a', 'b')
    kwargs = dict(name='c')
    func = lambda a, b, name: (a, b, name)
    replacer = ArgReplacer(func, 'name')
    assert replacer.get_old_value(args, kwargs) == 'c'
    assert replacer.get_old_value(args, {}) is None
    assert replacer.get_old_value(args, {'name': None}, None) is None

# Generated at 2022-06-22 04:32:10.460599
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    """Test that the `GzipDecompressor` class correctly handles decompressing
    corrupted gzip files.  Note that this test requires Python 2.7 or
    newer.
    """
    import zlib
    gz_decompressor = GzipDecompressor()

    # If the decompressor fails to decompress properly, it will throw
    # a zlib.error exception.
    zlib.decompress(gz_decompressor.flush())

if bytes != str:
    # Python 2 doesn't have a native b'literal'.
    # This function is a no-op on Python 3.
    def native_str(s: bytes, encoding: str = "latin-1") -> str:
        return s.decode(encoding)

# Generated at 2022-06-22 04:32:21.632974
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import functools
    import tornado.httpclient
    import tornado.httpclient
    import tornado.log
    import tornado.process
    import tornado.locks
    #
    @functools.total_ordering
    class TestClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestClass
        @classmethod
        def configurable_default(cls):
            return TestClass
        def initialize(self, x=None, y=None):
            super().initialize()
            self.x = x
            self.y = y
        def __repr__(self):
            return f'{self.__class__.__name__}(x={self.x!r}, y={self.y!r})'

# Generated at 2022-06-22 04:32:23.324626
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    with pytest.raises(TimeoutError):
        raise TimeoutError()



# Generated at 2022-06-22 04:32:31.461381
# Unit test for function import_object
def test_import_object():
    """
    Unit test for function import_object
    """
    import tornado.escape
    import tornado.testing
    test_modules = [("tornado.escape", tornado.escape), ("tornado.escape.utf8", tornado.escape.utf8), ("tornado", tornado)]
    for module_name, module in test_modules:
        assert import_object(module_name) == module
    with tornado.testing.assertRaisesRegexp(ImportError, "No module named"):
        import_object("tornado.missing_module")



# Generated at 2022-06-22 04:32:55.707912
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This test is duplicated in test_util_test

    import binascii
    from tornado.testing import AsyncTestCase

    class GzipDecompressorTest(AsyncTestCase):
        def test_gzip_decompressor(self):
            raw = binascii.a2b_hex(
                b"1f8b080000000000000bcb4bcc4db57db16e170099a4bad608000000"
            )
            expected_uncompressed = b"foo"
            self.assertEqual(
                zlib.decompress(raw), GzipDecompressor().decompress(raw)
            )
            self.assertEqual(zlib.decompress(raw), expected_uncompressed)

    GzipDecompressorTest().test_gzip_decompressor()



# Generated at 2022-06-22 04:32:59.604751
# Unit test for function import_object
def test_import_object():
    assert import_object("os.path") is os.path, "os.path was not imported"
    assert (
        import_object("tornado.util") is util
    ), "tornado.util was not imported"
    try:
        import_object("tornado.missing_module")
        assert False, "should have raised exception"
    except ImportError:
        pass



# Generated at 2022-06-22 04:33:03.523387
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    _ = ObjectDict()
    _.__setattr__('aa','bb')
    assert _.aa == 'bb'



# Generated at 2022-06-22 04:33:08.721875
# Unit test for function import_object
def test_import_object():
    import tornado.escape

    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError as e:
        assert "No module named missing_module" in str(e)



# Generated at 2022-06-22 04:33:15.187226
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    dict1 = ObjectDict()
    dict1.__setattr__("test", "test")
    assert dict1["test"] == "test"
test_ObjectDict___setattr__()


# Generated at 2022-06-22 04:33:17.269312
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    x = ObjectDict()
    ObjectDict.__getattr__(x, "a")
    ObjectDict.__getattr__(x, "a")

# Generated at 2022-06-22 04:33:20.170217
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
  # TODO
  pass


# Generated at 2022-06-22 04:33:21.678539
# Unit test for function exec_in
def test_exec_in():
    d = {}
    exec_in('a = 42', d)
    assert d['a'] == 42



# Generated at 2022-06-22 04:33:23.731881
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzipdecompressor = GzipDecompressor()
    GzipDecompressor.decompress(gzipdecompressor, value="", max_length=0)



# Generated at 2022-06-22 04:33:27.070612
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = util.GzipDecompressor()
    gzip_decompressor.decompress(value, max_length)

# Generated at 2022-06-22 04:33:47.215516
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado.testing import AsyncTestCase, expect_errors

    class GzipDecompressorTest(AsyncTestCase):
        def test_flush(self):
            with expect_errors(Exception):
                decompressor = GzipDecompressor()
                self.assertEqual(decompressor.decompress(b"garbage"), b"")
                decompressor.flush()


# Generated at 2022-06-22 04:33:48.461133
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def test_asserts(d: ObjectDict) -> None:
        pass
    # check the signature of the function test_asserts
    assert getfullargspec(test_asserts).args == ['d']



# Generated at 2022-06-22 04:33:50.907716
# Unit test for function exec_in
def test_exec_in():
    ns = {}
    exec_in("x = 6", ns)
    exec_in("y = 7", ns)
    assert ns == {"x": 6, "y": 7}



# Generated at 2022-06-22 04:34:03.426600
# Unit test for function re_unescape
def test_re_unescape():
    assert(re_unescape(r"\.") == ".")
    assert(re_unescape(r"\+") == "+")
    assert(re_unescape(r"\(") == "(")
    assert(re_unescape(r"\)") == ")")
    assert(re_unescape(r"\?") == "?")
    assert(re_unescape(r"\$") == "$")
    assert(re_unescape(r"\^") == "^")
    assert(re_unescape(r"\[") == "[")
    assert(re_unescape(r"\]") == "]")
    assert(re_unescape(r"\{") == "{")
    assert(re_unescape(r"\}") == "}")

# Generated at 2022-06-22 04:34:14.858931
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def test(a, b):
        # type: (int, Optional[int]) -> None
        pass

    arg_replacer = ArgReplacer(test, "b")
    _, args, kwargs = arg_replacer.replace(2, (1,), {})
    assert args == (1,)
    assert kwargs == {"b": 2}

    _, args, kwargs = arg_replacer.replace(3, (1,), {"b": 2})
    assert args == (1,)
    assert kwargs == {"b": 3}

    _, args, kwargs = arg_replacer.replace(3, (1,), {"b": 2, "c": 1})
    assert args == (1,)

# Generated at 2022-06-22 04:34:26.176792
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f1(a, b, c=4, d=5):
        pass
    arepl = ArgReplacer(f1, 'd')
    assert arepl.replace(0, (1, 2), dict(c=3)) == (5, (1, 2), dict(c=3, d=0))
    arepl = ArgReplacer(f1, 'c')
    assert arepl.replace(0, (1, 2), dict(c=3)) == (3, (1, 2, 0), dict(d=5))
    arepl = ArgReplacer(f1, 'b')
    assert arepl.replace(0, (1, 2), dict(c=3)) == (2, (1, 0), dict(c=3, d=5))



# Generated at 2022-06-22 04:34:29.694919
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    o = ObjectDict({'foo': 'bar'})
    assert o.foo == 'bar'
    o.foo2 = 'baz'
    assert o['foo2'] == 'baz'



# Generated at 2022-06-22 04:34:34.293275
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class DummyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return DummyConfigurable

        @classmethod
        def configurable_default(cls):
            return DummyConfigurable

    class Implementation(DummyConfigurable):
        def __init__(self, value):
            self.value = value

        def initialize(self, value):
            self.value = value

    DummyConfigurable.configure(Implementation, value=None)
    assert DummyConfigurable().value is None

    DummyConfigurable.configure(None)

    DummyConfigurable.configure(Implementation, value="foo")
    assert DummyConfigurable().value == "foo"

    DummyConfigurable.configure(Implementation)
    assert DummyConfigurable().value == "foo"

    D

# Generated at 2022-06-22 04:34:38.343923
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from tornado.test.util import skipIfNoPymongo
    from tornado.testing import AsyncTestCase, log_unittest_info

    if _websocket_mask is _websocket_mask_python:
        log_unittest_info(__file__, "using pure-python masking algorithm")

# Generated at 2022-06-22 04:34:43.142701
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test_func(old_arg, new_arg=None):
        pass

    test_replacer = ArgReplacer(test_func, "new_arg")
    assert test_replacer.arg_pos == None


# Generated at 2022-06-22 04:35:10.031279
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=1):
        pass
    replacer = ArgReplacer(func, "b")
    args, kwargs = replacer.replace(2, (1, 2, 3), {})
    assert args == (1, 2, 3)
    assert kwargs == {}
    args, kwargs = replacer.replace(2, (1, 2, 3), {"b": 3, "c": 4})
    assert args == (1, 2, 3)
    assert kwargs == {"b": 3, "c": 4}
    args, kwargs = replacer.replace(2, (1, 3, 3), {"c": 4})
    assert args == (1, 2, 3)
    assert kwargs == {"c": 4}
    args, kwargs = replacer.replace

# Generated at 2022-06-22 04:35:16.969918
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # Constructor
    GzipDecompressor()
    # Method
    GzipDecompressor.flush
    # Verify bad args are rejected

    gzip = GzipDecompressor()
    gzip.decompress(b"")
    # no exception; sets unconsumed_tail
    assert gzip.unconsumed_tail
    gzip.flush()
    # no exception
    assert not gzip.unconsumed_tail
    # no exception
    gzip.decompress(b"")
    # no exception; sets unconsumed_tail
    assert gzip.unconsumed_tail
    # no exception
    gzip.flush()
    # no exception


# Generated at 2022-06-22 04:35:23.961523
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # getargnames returns a list of positional names and a list of keyword
    # names as a list, in a list.
    # (This test was failing with mypy 0.601, but I didn't notice until
    # after I committed the change to make this a plain list.  This version
    # of the test should still work in both cases.)
    # (This test is a function so that mypy can see the definition of
    # ArgReplacer)
    def test(a: str, b: int, c: int = None) -> None:
        pass

    f = ArgReplacer(test, "a")
    assert f.get_old_value(["a", 1, 2], {}) == "a"
    assert f.get_old_value(["a", 1], {}) == "a"
    assert f.get_old_value

# Generated at 2022-06-22 04:35:29.365050
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise Exception()
    except Exception:
        typ, value, traceback = sys.exc_info()

    assert isinstance(value, Exception)
    assert isinstance(traceback, types.TracebackType)

    raise_exc_info((None, None, None))

    try:
        raise_exc_info((typ, value, traceback))
    except Exception as e:
        assert e is value



# Generated at 2022-06-22 04:35:37.221221
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        errno = errno_from_exception(e)
        if errno is not None:
            raise ValueError("errno must be None in this case")

    try:
        raise Exception(1)
    except Exception as e:
        errno = errno_from_exception(e)
        if errno != 1:
            raise ValueError("errno must be 1 in this case")



# Generated at 2022-06-22 04:35:40.150334
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(3, 'foo')
    except Exception as e:
        assert errno_from_exception(e) == 3
        # TODO: add test for socket.error and socket.gaierror



# Generated at 2022-06-22 04:35:53.200112
# Unit test for function re_unescape
def test_re_unescape():
    # type: () -> None
    assert re_unescape("\\\\") == "\\"
    assert re_unescape("\\a") == "\a"
    assert re_unescape("\\12") == "\n"
    assert re_unescape("\\123") == "\0123"
    assert re_unescape("\\x20") == " "
    assert re_unescape("\\x7f") == "\x7f"
    assert re_unescape("\\u1234") == "\u1234"
    assert re_unescape("\\U00012345") == "\U00012345"
    assert re_unescape("\\U0010ffff") == "\U0010ffff"
    assert re_unescape("\\A") == "\\A"
    # \d \D \w, \W \s and \S are excluded because they are


# Generated at 2022-06-22 04:35:55.504482
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    a = ObjectDict(foo=None, bar='baz')
    assert a.foo is None
    assert a.bar == 'baz'



# Generated at 2022-06-22 04:36:08.142854
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, 'Input/output error')
    except OSError as e:
        assert e.errno == errno_from_exception(e)
        assert e.errno == 5
    # test the args
    try:
        raise OSError('Input/output error')
    except OSError as e:
        assert e.errno == errno_from_exception(e)
        assert e.errno == 'Input/output error'

    # test a generic exception
    try:
        raise Exception('Input/output error')
    except Exception as e:
        assert e.errno == errno_from_exception(e)
        assert e.errno == 'Input/output error'



# Generated at 2022-06-22 04:36:09.289687
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):
        pass
    Foo.configure(Foo)
    assert isinstance(Foo(), Foo)



# Generated at 2022-06-22 04:36:46.758350
# Unit test for function import_object
def test_import_object():
    """Test the import_object function with different types of input.

    :return:
    """
    try:
        assert import_object('tornado.escape')
        print('test_import_object')
    except ImportError:
        import tornado.escape
        assert tornado.escape



# Generated at 2022-06-22 04:36:53.379881
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    if sys.version_info >= (3, 6):
        # Use the standard typing module function annotations
        def __init__(
                self,
                defaults: Optional[Union[Mapping[str, Any], object]] = None) \
                -> None:
            pass
        assert(getfullargspec(__init__) ==
                getfullargspec(ObjectDict.__init__))
    else:
        # Need to use the getfullargspec workaround for Python 3.5
        __init__ = ObjectDict.__init__
        assert(getfullargspec(__init__).args == ['self', 'defaults'])
        assert(getfullargspec(__init__).defaults == (None,))
        assert(getfullargspec(__init__).varargs is None)

# Generated at 2022-06-22 04:37:02.354810
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("foo%sbar") == "foo%sbar"
    assert re_unescape("foo\\sbar") == "foo bar"
    assert re_unescape("foo\\x20bar") == "foo bar"
    assert re_unescape("foo\\u1234bar") == "foo\\u1234bar"
    assert re_unescape("foo\\\\bar") == "foo\\bar"
    assert re_unescape("foo\\\\\\nbar") == "foo\\\nbar"
    # Can't unescape \d
    try:
        re_unescape("foo\\dbar")
    except ValueError:
        pass
    else:
        assert False, "didn't get expected ValueError"
    # Unescape groups are limited to alphanumerics

# Generated at 2022-06-22 04:37:08.970798
# Unit test for function errno_from_exception
def test_errno_from_exception():
    def test(errno) -> bool:
        try:
            raise IOError(errno, os.strerror(errno))
        except BaseException:
            return errno_from_exception(sys.exc_info()[1]) == errno

    assert test(0)
    assert test(1)
    assert test(100)

    try:
        raise IOError
    except BaseException:
        assert errno_from_exception(sys.exc_info()[1]) is None



# Generated at 2022-06-22 04:37:19.297089
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    """Tests the GzipDecompressor class
    """
    data = b'abcdefgh' * 100
    compressed_data = zlib.compress(data)
    decompressor = GzipDecompressor()
    assert decompressor.decompress(compressed_data) == data
    try:
        decompressor.flush()
    except OSError:
        assert False, "Shouldn't raise exception at this point"

# A do-nothing context manager, for convenience when a real
# context manager isn't needed.  This is a Python 2-compatible version of
# contextlib.nullcontext (Python 3.7+).

# Generated at 2022-06-22 04:37:24.295172
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    s = b'asdf\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIK\x04\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00'
    d = GzipDecompressor()
    assert s == d.decompress(s) + d.flush()


# Generated at 2022-06-22 04:37:35.834701
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import zlib

    def get_data():
        return zlib.compress("""
        Some test data
        """)

    decomp = GzipDecompressor()
    # Decompress all data
    data = get_data()
    buf = []
    while True:
        chunk = decomp.decompress(data)
        if not chunk:
            break
        buf.append(chunk)
    # Check that flush() returns all data
    data = decomp.flush()
    buf.append(data)
    assert b''.join(buf) == b"""
        Some test data
        """
    # Check that flush() raises an exception if we try to decompress again
    with pytest.raises(Exception):
        decomp.decompress(get_data())


# Generated at 2022-06-22 04:37:41.266504
# Unit test for function raise_exc_info
def test_raise_exc_info():
    __pychecker__ = "no-argsused"
    def g():
        try:
            f()
        except ValueError:
            return sys.exc_info()

    def f():
        raise ValueError()

    tb = g()[2]
    raise_exc_info(tb)
    assert False, "should not get here"



# Generated at 2022-06-22 04:37:43.668352
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.foo = 'bar'
    assert d.foo == 'bar'
    with pytest.raises(AttributeError):
        d.foo_bar



# Generated at 2022-06-22 04:37:48.398865
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def initialize(self):
            pass
        @classmethod
        def configurable_base(c):
            return Foo
        @classmethod
        def configurable_default(c):
            return Foo
    Foo()

# Generated at 2022-06-22 04:38:21.435571
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(self, x, y, z=1):
        pass

    assert ArgReplacer(f, "z").get_old_value((), {}) == 1
    assert ArgReplacer(f, "z").get_old_value((1, 2), {}) == 1
    assert ArgReplacer(f, "z").get_old_value((1, 2), {}, 0) == 0
    assert ArgReplacer(f, "z").get_old_value((1, 2), {"z": 3}) == 3

    assert (
        ArgReplacer(f, "z")
        .replace(4, (1, 2), {})
        == (1, (1, 2), {"z": 4})
    )

# Generated at 2022-06-22 04:38:28.472217
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.foo = "foo!"
    assert d.foo == "foo!"
    py_ver = sys.version_info[0]
    PY3 = py_ver == 3
    if PY3:
        with pytest.raises(AttributeError):
            d.bar
    else:
        assert d.bar == ""



# Generated at 2022-06-22 04:38:35.119221
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    class B(A):
        pass

    A.configure(B)

    b1 = A()
    assert b1.__class__ is B
    assert A().__class__ is B
    assert issubclass(B, A)
    assert isinstance(b1, A)



# Generated at 2022-06-22 04:38:47.609850
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    print("testing function replace of class ArgReplacer...", end="")

    def foo(a, b, c):
        pass

    args = (1, 2, 3)
    kwargs = {"b": 5}

    # get the number of attributes in ArgReplacer
    num_attrs = len(ArgReplacer.__dict__.keys())

    # test the case when the argument is in args
    _, args, kwargs = ArgReplacer(
        foo, "a"
    ).replace("new", args, kwargs)
    eq(
        args,
        ("new", 2, 3)
    )
    eq(
        kwargs,
        {"b": 5}
    )

    # test the case when the argument is in kwargs

# Generated at 2022-06-22 04:38:57.085453
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(pos, keyword=42):
        pass
    r = ArgReplacer(f, "pos")
    assert r.get_old_value((1,), {}) == 1
    assert r.get_old_value((1,), {}, default=2) == 1
    assert r.get_old_value((), {"pos": 3}) == 3
    assert r.get_old_value((), {}, default=2) == 2
    assert r.get_old_value((), {"notpos": 3}, default=2) == 2
    assert r.replace(4, (1,), {}) == (1, (4,), {})
    assert r.replace(5, (), {"pos": 3}) == (3, (), {"pos": 5})

# Generated at 2022-06-22 04:39:01.640989
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("a") == "a"
    assert re_unescape("\\a") == "a"
    assert re_unescape("a\\") == "a\\"
    assert re_unescape("\\\\a") == "\\a"
    assert re_unescape("a\\b") == "a\\b"
    assert re_unescape("a\\\\b") == "a\\\\b"
    assert re_unescape("\\") == "\\"
    with pytest.raises(ValueError):
        re_unescape("\\d")



# Generated at 2022-06-22 04:39:07.856055
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):
        def configurable_base(cls):
            return Foo

        def configurable_default(cls):
            raise ValueError("not expecting default")

        def initialize(self, x):
            self.x = x

    # Should use subclass with no arguments.
    class MyIOStream(Foo):
        pass

    MyIOStream.configure(MyIOStream)
    stream = MyIOStream(1)
    assert stream.x == 1

    # Should use subclass with arguments.
    class MyIOStream2(Foo):
        def initialize(self, x, y):
            self.x, self.y = x, y

    MyIOStream2.configure(MyIOStream2)
    stream = MyIOStream2(1, 2)
    assert stream.x == 1
    assert stream.y

# Generated at 2022-06-22 04:39:13.416130
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    class Test:
        def __init__(self):
            self.foo = 'bar'
    x = Test()
    y = ObjectDict()
    assert type(x) == type(y)
    assert type(y) is not ObjectDict
    y.foo = 'bar'
    assert y.foo == 'bar'


# Generated at 2022-06-22 04:39:14.606342
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(2, 3)) == 2 * 24 * 60 * 60 + 3



# Generated at 2022-06-22 04:39:26.304912
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 1
    d.bar = ObjectDict()
    d.bar.baz = 2
    assert d.foo == 1
    assert d.bar.baz == 2
    assert "foo" in d and "bar" in d
    assert "baz" not in d
    assert hasattr(d, "foo") and hasattr(d, "bar")
    assert not hasattr(d, "baz")
    assert d.get("foo") == 1
    assert d.get("bar").baz == 2
    assert d.get("baz") is None
    d.clear()
    assert not hasattr(d, "foo")
    assert not hasattr(d, "bar")
