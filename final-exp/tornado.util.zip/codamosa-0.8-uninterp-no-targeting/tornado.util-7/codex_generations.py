

# Generated at 2022-06-22 04:30:23.025403
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    try:
        os.mkdir('test')
    except:
        pass
    file_path = os.path.join('test', 'test_GzipDecompressor_decompress.py')
    with open(file_path, 'w') as f:
        f.write('a = 1\nb = 2\nc = a + b\nprint(c)')
    with open(file_path, 'rb') as f:
        data = f.read()
    with open(file_path, 'rb') as f:
        gz_data = zlib.compress(data, 9)
    gz_decompressor = GzipDecompressor()
    data_decom = gz_decompressor.decompress(gz_data, len(gz_data))
    assert data == data_decom
    os

# Generated at 2022-06-22 04:30:33.952147
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def myfun(a, b, d=1):
        pass

    def myfun_varargs(*args, **kwargs):
        pass

    def myfun_kwonly(*, a, b, d=1):
        pass

    arg_replacer = ArgReplacer(myfun, "a")

    assert arg_replacer.arg_pos is None
    assert arg_replacer.get_old_value([1, 2, 3], dict(d=4)) is None
    assert arg_replacer.get_old_value([1, 2, 3], dict(d=4), 5) == 5

    assert arg_replacer.get_old_value([], dict(a=1, d=4)) == 1

# Generated at 2022-06-22 04:30:35.690692
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    decompressor = GzipDecompressor()
    assert isinstance(decompressor.flush(), bytes)

# Generated at 2022-06-22 04:30:41.813329
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    a_string = b"H\x99VH\xf9\x99V"
    decompressor = GzipDecompressor()
    decompressed = decompressor.decompress(a_string)
    tail = decompressor.unconsumed_tail
    assert not tail, "GzipDecompressor test failed: tail not empty"
    decompressed = decompressor.decompress(tail)
    tail = decompressor.unconsumed_tail
    assert not tail, "GzipDecompressor test failed: tail not empty"
    decompressed = decompressor.flush()
    tail = decompressor.unconsumed_tail
    assert not tail, "GzipDecompressor test failed: tail not empty"


# Generated at 2022-06-22 04:30:44.019044
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1



# Generated at 2022-06-22 04:30:50.269548
# Unit test for function import_object
def test_import_object():
    import sys
    import tornado.escape
    try:
        import_object('tornado.escape') is tornado.escape
        import_object('tornado.escape.utf8') is tornado.escape.utf8
        import_object('tornado') is tornado
        import_object('tornado.missing_module')
    except ImportError:
        pass



# Generated at 2022-06-22 04:30:53.471244
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    def get_dict():
        return ObjectDict({"a": 1, "b": 2})
    a, b = get_dict()
    assert a
    assert a + b == 3



# Generated at 2022-06-22 04:30:55.844012
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.abcd = "abcd"
    obj["abcd"] = "abcd"

# Generated at 2022-06-22 04:31:01.903262
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    e = TimeoutError("message")
    e = TimeoutError("format", 10)
    e = TimeoutError("format", 10, "ValueError")


_DATETIME_TO_EPOCH = datetime.datetime(1970, 1, 1)



# Generated at 2022-06-22 04:31:13.548644
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    # Implementation detail:  argspec functions return an empty
    # string for *args and **kwargs, so make sure they're included
    # in the returned list.

    def f(x, y):
        pass

    ar = ArgReplacer(f, "x")
    assert ar.arg_pos == 0
    assert ar.get_old_value((1, 2), {}) == 1
    assert ar.get_old_value((1, 2), {}, default=3) == 1
    assert ar.get_old_value((1,), {"y": 2}) == 1
    assert ar.get_old_value((), {"x": 2, "y": 3}) == 2
    assert ar.get_old_value((), {"y": 2}) == None

# Generated at 2022-06-22 04:31:29.794320
# Unit test for function exec_in
def test_exec_in():
    d = {'foo': 1, 'bar': 2}
    loc = d.copy()
    assert exec_in('foo += 1; bar += 1', d, loc) == None
    assert d == {'foo': 2, 'bar': 3}
    assert loc == {'foo': 2, 'bar': 3}



# Generated at 2022-06-22 04:31:35.048141
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    od = ObjectDict({'a': 'b'})  # type: typing.Union[None, ObjectDict]
    try:
        od.a
    except Exception as e:
        assert isinstance(e, AttributeError)
    try:
        _ = od.c
    except Exception as e:
        assert isinstance(e, AttributeError)


# Generated at 2022-06-22 04:31:47.110431
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f1(a, b, c):
        pass

    def f2(a=None):
        pass

    def f3(a, *v):
        pass

    def f4(a, *v, **kw):
        pass

    def f5(*v, **kw):
        pass

    def f6(a, **kw):
        pass

    def f7(a, b, **kw):
        pass

    ra = ArgReplacer(f1, "c")
    assert ra.get_old_value(("a", "b", "c"), {}) == "c"
    assert ra.get_old_value(("a", "b"), {"c": "d"}) == "d"
    assert ra.get_old_value(("a", "b"), {}) is None
    assert ra.get_old

# Generated at 2022-06-22 04:31:58.287615
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[MyConfigurable]
            return MyConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return lambda *args, **kwargs: None

        def initialize(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            pass

    test = MyConfigurable()

    test.initialize()

    test.initialize(1)

    test.initialize(2, 3)

    test.initialize(a=1)



# Generated at 2022-06-22 04:32:10.460678
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def inner_fun(abc, cde=None, **kwargs):
        print("abc=%s, cde=%s, kwargs=%r" % (abc, cde, kwargs))  # noqa
    def outer_fun(*args, **kwargs):
        print("args=%r, kwargs=%r" % (args, kwargs))  # noqa
        inner_fun(*args, **kwargs)
    _, args, kwargs = ArgReplacer(outer_fun, 'abc')\
        .replace("abc_value_1",\
            ['abc_value_0', 'cde_value_0'],\
            {'cde':'cde_value_1'}
        )

# Generated at 2022-06-22 04:32:16.478125
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import io
    import gzip
    import zlib

    data = b"".join([l.encode('ascii') for l in [
        'foo', 'bar', 'baz', 'qux', 'quux', 'corge', 'grault', 'garply',
        'waldo', 'fred', 'plugh', 'xyzzy', 'thud',
    ]])

    # Remove dates and OS types from the gzip header
    def mywrite(self, data):
        if not self.writeheader_done:
            self.fileobj.write(b"\0\0\0\0")
            self.fileobj.write(struct.pack("<L", zlib.crc32(b"") & 0xffffffff))
            self.fileobj.write(b"\x02\0")

# Generated at 2022-06-22 04:32:19.436826
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun(a: str, b: int, c: int = 10) -> None:
        print(a, b, c)

    argreplacer = ArgReplacer(fun, 'b')
    old_value, args, kwargs = argreplacer.replace(11, ('a', 22), {})
    print(old_value, args, kwargs)


# test_ArgReplacer_replace()

# Generated at 2022-06-22 04:32:28.778784
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=10, d=20):
        return a + b + c + d

    # named arguments
    old_value_a = ArgReplacer(f, 'a').get_old_value((), {'a': 1, 'b': 2, 'c': 3, 'd': 4})
    old_value_b = ArgReplacer(f, 'b').get_old_value((), {'a': 1, 'b': 2, 'c': 3, 'd': 4})
    old_value_c = ArgReplacer(f, 'c').get_old_value((), {'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-22 04:32:39.937355
# Unit test for function re_unescape
def test_re_unescape():
    escaped = "\\+*?()[]{}|.^$"
    unescaped = r"+*?()[]{}|.^$"
    assert re_unescape(re.escape(unescaped)) == unescaped
    # Escaped and unescaped are considered equal, because the set of
    # characters that need to be escaped to produce an identical string
    # is a superset of the set of characters which cannot be escaped.
    assert re_unescape(escaped) == unescaped
    # Some characters can be escaped more than once, so
    # we could get a longer string back than we started with.
    assert len(escaped) < len(re_unescape(escaped * 2))
    # A string containing the digit 3 is considered invalid.
    # (The pattern r"\d\d" is the same as

# Generated at 2022-06-22 04:32:51.327477
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def _raise_exc_info(
        exc_info,  # type: Tuple[Optional[type], Optional[BaseException], Optional[TracebackType]]
    ):
        return raise_exc_info(exc_info)

    import sys
    from traceback import format_stack
    from types import TracebackType

    try:
        raise IOError("test")
    except IOError:
        exc_info = sys.exc_info()

        tb = format_stack()
        assert len(tb) > 3
        assert '_raise_exc_info' not in tb[-3]  # should be a clean stack

        _raise_exc_info(exc_info)



# Generated at 2022-06-22 04:33:09.927139
# Unit test for function raise_exc_info
def test_raise_exc_info():
    class CustomException(Exception):
        pass

    try:
        raise CustomException("test")
    except CustomException as e:
        exc_info = (None, e, None)
        try:
            raise_exc_info(exc_info)
        except CustomException as e2:
            assert e2.args == ("test",)
        else:
            assert False, "should have re-raised"
    else:
        assert False, "should have raised"



# Generated at 2022-06-22 04:33:18.235581
# Unit test for constructor of class Configurable
def test_Configurable():
    assert issubclass(Configurable, object)
    assert Configurable.configurable_base is Configurable.configurable_base.__func__
    assert Configurable.configurable_default is Configurable.configurable_default.__func__
    assert Configurable.configure is Configurable.configure.__func__
    assert Configurable.configured_class is Configurable.configured_class.__func__
    assert Configurable._save_configuration is Configurable._save_configuration.__func__
    assert Configurable._restore_configuration is Configurable._restore_configuration.__func__



# Generated at 2022-06-22 04:33:28.226543
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ClassA(Configurable):
        def configurable_base(self):
            return self
        def configurable_default(self):
            return self

    def test_class():
        assert ClassA().__class__ == ClassA
    test_class()
    save = ClassA._save_configuration()
    # We test here that configurable_base is returning the right class.
    # In case of errors, we will get a ValueError from configure
    ClassA.configure(ClassA)
    ClassA._restore_configuration(save)
    save = ClassA._save_configuration()
    # We test here that configure with a string argument is working.
    # In case of errors, we will get a ValueError from configure
    ClassA.configure('tests.util_test:test_class')
    ClassA._restore_

# Generated at 2022-06-22 04:33:31.823401
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 24 * 60 * 60



# Generated at 2022-06-22 04:33:36.945986
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=5)) == 5.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=-5)) == -5.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(days=-1)) == -86400.0



# Generated at 2022-06-22 04:33:42.624631
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import tempfile
    import inspect


# Generated at 2022-06-22 04:33:53.456424
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(x, y, z=3):
        return x, y, z
    r = ArgReplacer(foo, 'x')
    assert r.replace(4, (1, 2), {'z': 3}) == (1, [4, 2], {'z': 3})
    assert r.replace(5, (1, 2), {'x': 3}) == (3, [1, 2], {'x': 5})
    assert r.replace(6, (1, 2), {}) == (None, [1, 2], {'x': 6})

    r = ArgReplacer(foo, 'z')
    assert r.replace(4, (1, 2), {'x': 3}) == (3, [1, 2], {'z': 4, 'x': 3})

# Generated at 2022-06-22 04:34:06.505773
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None

    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Foo

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

        def initialize(self, arg1, arg2=None, arg3=3, **kwargs):
            # type: (str, Optional[str], int, **Any) -> None
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.kwargs = kwargs

    a = Foo("foo", "bar")
    assert a.arg1 == "foo"
    assert a.arg2 == "bar"
    assert a.arg

# Generated at 2022-06-22 04:34:17.593097
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fn(a, b, *args, **kwargs):
        pass
    replacer = ArgReplacer(fn, "a")
    assert replacer.get_old_value(("a_value",),{},) == "a_value"
    # Be careful, if the argument which is being replaced is not present, it returns the default value
    # But the default value is None here
    assert replacer.get_old_value(("b_value",),{},) is None
    assert replacer.get_old_value(("b_value",),{"a":"a_value"},) == "a_value"
    assert replacer.get_old_value(("b_value",),{"a":"another_value"},) == "another_value"

# Generated at 2022-06-22 04:34:22.500081
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Testable(Configurable):
        def _initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    t = Testable(123, foo='bar')
    assert t.args == (123,)
    assert t.kwargs == {'foo':'bar'}



# Generated at 2022-06-22 04:34:38.718264
# Unit test for function errno_from_exception
def test_errno_from_exception():
    errno = 500
    try:
        raise KeyError(errno)
    except Exception as e:
        err = errno_from_exception(e)
        assert errno == err



# Generated at 2022-06-22 04:34:45.068237
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    try:
        # This doesn't actually raise an exception since it happens
        # in the same process.
        raise TimeoutError()
    except TimeoutError:
        pass
    except:
        assert False, "TimeoutError raised wrong type of exception"

# Aliases to support backwards-compatibility
gen_TimeoutError = TimeoutError
IOloop_TimeoutError = TimeoutError



# Generated at 2022-06-22 04:34:52.095370
# Unit test for function import_object
def test_import_object():
    try:
        import email
        import email.encoders
    except ImportError:  # pragma: nocover # email module is missing in some environments
        pass
    else:
        import_object('email.encoders')
        from email import encoders
        assert encoders == email.encoders
        assert import_object('email') == email
        assert import_object('email.encoders') == email.encoders
        try:
            import_object('email.missing_module')
        except ImportError:
            pass
        else:  # pragma: nocover
            raise Exception('expected import to fail')



# Generated at 2022-06-22 04:35:00.875865
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None

    class C(Configurable):
        def initialize(self, x):
            # type: (int) -> None
            self.x = x
        configurable_base = classmethod(lambda cls: C)
        configurable_default = classmethod(lambda cls: C)

    C.configure("tests.util.C")
    with mock.patch("tests.util.C") as MockC:
        MockC.configure.return_value = None
        c = C(123)
    MockC.assert_called_with(123)

    C.configure("tests.util.C")
    with mock.patch("tests.util.C") as MockC:
        MockC.configure.return_value = None
        c = C()
    MockC.assert_called_with()




# Generated at 2022-06-22 04:35:12.471080
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # type: ignore
    class D(object):
        pass
    # Test initialization from dict
    a = ObjectDict({"x": 1, "y": 2})
    assert isinstance(a, ObjectDict)
    assert isinstance(a, dict)
    assert a["x"] == 1
    assert a["y"] == 2
    # Test initialization from keywords
    a = ObjectDict(x=1, y=2)
    assert isinstance(a, ObjectDict)
    assert isinstance(a, dict)
    assert a["x"] == 1
    assert a["y"] == 2
    # Test initialization from object
    a = ObjectDict(D())
    assert isinstance(a, ObjectDict)
    assert isinstance(a, dict)
    # Test setting keys
    a["x"] = 10
    assert a

# Generated at 2022-06-22 04:35:17.065976
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    o = ObjectDict(a=1, b=2)
    assert o.a == 1
    assert o.b == 2



# Generated at 2022-06-22 04:35:24.011808
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # This test does not use unittest.testcase.assertRaisesRegex, because that
    # method is not available in Python 2.6, which we still support.
    with GzipDecompressor() as d:
        d.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
                     b'\x48\xcd\xc9\xc9\x57\x28\xcf\x2f\xca\x49\xe1\x02\x00'
                     b'\x21\xf2\x38\xe0\x00\x00\x00',
                     max_length=16)

# Generated at 2022-06-22 04:35:35.302397
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b=None, c=None):
        pass
    assert ArgReplacer(f, "b").get_old_value((1,), {}) is None
    assert ArgReplacer(f, "b").get_old_value((1,), {}, "d") == "d"
    assert ArgReplacer(f, "c").get_old_value((1,), {"c": "e"}) == "e"
    assert ArgReplacer(f, "b").get_old_value((1,), {"b": "y"}) == "y"
    assert ArgReplacer(f, "a").get_old_value((1,), {}) == 1
    assert ArgReplacer(f, "a").get_old_value((1,), {"a": "x"}) == 1

# Generated at 2022-06-22 04:35:46.835776
# Unit test for function re_unescape
def test_re_unescape():
    # These are all valid escaped strings, and should be passed through
    # unchanged
    valid_in = ["\\1", "\\A", "\\Z", "\\b", "\\B", "\\d", "\\D", "\\s", "\\S", "\\w", "\\W", "\\t", "\\r", "\\n", "\\f", "\\a", "\\G", "\\b",
                "\\B", "\\\\", "\\", "\9", "\8", "\7", "\6", "\5", "\4", "\3", "\2", "\1", "\0", "\$", "\^", "\[", "\]", "\.", "\*", "\+",
                "\?", "\(", "\)", "\|", "\{"]
    for i in valid_in:
        assert i == re_unescape(i)
    valid_

# Generated at 2022-06-22 04:35:59.135352
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"a\+b") == "a+b"
    assert re_unescape(r"a\*b") == "a*b"
    assert re_unescape(r"a\?b") == "a?b"
    assert re_unescape(r"a\|b") == "a|b"
    assert re_unescape(r"a\(b") == "a(b"
    assert re_unescape(r"a\)b") == "a)b"
    assert re_unescape(r"a\[b") == "a[b"
    assert re_unescape(r"a\]b") == "a]b"
    assert re_unescape(r"a\{b") == "a{b"

# Generated at 2022-06-22 04:36:30.693614
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=1)
    assert d.a == 1
    d.a = 2
    assert d['a'] == 2



# Generated at 2022-06-22 04:36:42.577014
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    from tornado.ioloop import IOLoop

    class C(Configurable):
        def initialize(self, **kwargs):
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C1

    class C1(C):
        pass

    class C2(C):
        pass

    class Error(Exception):
        pass

    # Default implementation is default class
    c = C()
    assert isinstance(c, C1)
    assert not c.kwargs

    # Keyword arguments go to constructor
    c = C(foo=123)
    assert isinstance(c, C1)
    assert c.kwargs == {"foo": 123}

    # Can override default class with configure
   

# Generated at 2022-06-22 04:36:51.596790
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        @classmethod
        def configurable_base(self):
            return Base

        @classmethod
        def configurable_default(self):
            return Default

    class Default(Base):
        pass

    class Alternate(Base):
        pass

    assert Base()
    assert isinstance(Base(), Base)
    assert not isinstance(Base(), Alternate)

    assert isinstance(Alternate(), Base)
    assert isinstance(Alternate(), Alternate)

    assert Base.configured_class() is Default
    assert Alternate.configured_class() is Default
    Base.configure(Alternate)
    assert Base.configured_class() is Alternate
    assert Alternate.configured_class() is Alternate

    Base.configure(None)
    assert Base.configured_class() is Default
    assert Alternate.configured

# Generated at 2022-06-22 04:36:57.555351
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(Exception()) == None
    try:
        raise IOError(0, "foo")
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise OSError(42, "x")
    except OSError as e:
        assert errno_from_exception(e) == 42


# Generated at 2022-06-22 04:37:07.093689
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class A(object):
        @staticmethod
        def func(a, b, c=True):
            pass

    # Replace a positional argument
    a = ArgReplacer(A.func, "a")
    old_value = a.get_old_value((1, 2, 3), {"b": 2})
    assert old_value == 1
    old_value = a.replace(10, (1, 2, 3), {"b": 2})[0]
    assert old_value == 1
    assert a.get_old_value((1, 2, 3), {"b": 2}) == 10
    # Replace a keyword argument
    b = ArgReplacer(A.func, "b")
    old_value = b.get_old_value((1,), {"b": 2})
    assert old_value == 2

# Generated at 2022-06-22 04:37:08.378774
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    suite = doctests()
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)

# Generated at 2022-06-22 04:37:10.854193
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fun(a, b, c):
        pass
    replacer = ArgReplacer(fun, 'a')
    assert replacer.get_old_value((1, 2, 3), {}) == 1



# Generated at 2022-06-22 04:37:23.385755
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def my_func(a, b, c, d):
        pass
    r = ArgReplacer(my_func, "c")
    assert r.get_old_value((1, 2, 3, 4), {}) == 3
    assert r.get_old_value((1, 2), dict(c=3, d=4)) == 3
    assert r.get_old_value((1, 2), dict(d=4)) is None
    assert r.get_old_value((1, 2, 3, 4), {}, "foo") == 3
    assert r.get_old_value((1, 2), dict(c=3, d=4), "foo") == 3
    assert r.get_old_value((1, 2), dict(d=4), "foo") == "foo"
   

# Generated at 2022-06-22 04:37:27.691843
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    @add_metaclass(Configurable)
    class ConcreteBase(object):
        @classmethod
        def configurable_base(cls):
            return ConcreteBase

        @classmethod
        def configurable_default(cls):
            return ConcreteBaseDefault

        def initialize(self, *args, **kwargs):
            pass
    class ConcreteBaseDefault(ConcreteBase):
        pass
    class ConcreteOverride(ConcreteBase):
        def __init__(self, a):
            old_init(self, a)
        def initialize(self):
            pass

    ConcreteBase.configure(None)
    old_init = ConcreteBaseDefault.__init__
    ConcreteBaseDefault.__init__ = lambda self, a: None
    x = ConcreteBase()

# Generated at 2022-06-22 04:37:38.902026
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # type: () -> None
    d = GzipDecompressor()
    data = (b"hello" * 100000)
    compressed = zlib.compress(data)
    assert len(data) == 500000
    assert len(compressed) < 5000
    assert d.decompress(compressed) == data
    assert d.flush() == b""
    assert d.unconsumed_tail == b""


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).
#
# Note that it is necessary to re-

# Generated at 2022-06-22 04:38:48.343349
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(x=1, y=None):
        pass
    
    a = ArgReplacer(func, 'y')
    assert a.replace(0, (), {'x': 1, 'y': 2}) == (2, (), {'x': 1, 'y': 0})
    assert a.replace(0, (), {'x': 1}) == (None, (), {'x': 1, 'y': 0})
    assert a.replace(0, (1, 2), {'x': 1, 'y': 2}) == (2, (1, 0), {'x': 1})
    assert a.replace(0, (1, 2), {'x': 1}) == (None, (1, 0), {'x': 1})
    a = ArgReplacer(func, 'x')

# Generated at 2022-06-22 04:38:58.323361
# Unit test for function errno_from_exception
def test_errno_from_exception():
    def test_errno(e):
        try:
            raise e
        except Exception as err:
            return errno_from_exception(err)

    assert test_errno((6,)) == 6
    assert test_errno(OSError(6)) == 6
    assert test_errno(IOError(6)) == 6

    try:
        raise ValueError("test")
    except ValueError as err:
        assert errno_from_exception(err) is None
    try:
        raise Exception("test")
    except Exception as err:
        assert errno_from_exception(err) is None
    try:
        raise Exception("test", 6)
    except Exception as err:
        assert errno_from_exception(err) == 6

# Generated at 2022-06-22 04:39:03.495790
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_function(test_string, test_int, test_optional_arg=None):
        pass
    test_args = ArgReplacer(test_function, "test_int")
    test_args.replace(0, ("Foobar", 1), dict(test_optional_arg="Barfoo"))
    return True



# Generated at 2022-06-22 04:39:04.682167
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():

    obj = ObjectDict()
    obj.abc = 123
    assert obj['abc'] == 123



# Generated at 2022-06-22 04:39:16.208273
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, "Test")
    except Exception as e:
        assert errno_from_exception(e) == 5

    try:
        raise IOError(9, "Test")
    except Exception as e:
        assert errno_from_exception(e) == 9

    try:
        raise TypeError()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise ValueError
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None


_PLACEHOLDER = object()



# Generated at 2022-06-22 04:39:18.390624
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    try:
        gzipper = GzipDecompressor()
    except:
        import traceback
        traceback.print_exc()


# Generated at 2022-06-22 04:39:27.203205
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # pragma: no cover
    d = ObjectDict((("one", 1), ("two", 2), ("three", 3)))
    assert d.one == 1
    assert d.three != d.two
    d.two = "dos"
    d.four = 4
    assert d["two"] == "dos"
    assert d.get("two") == "dos"
    assert hasattr(d, "four")
    assert not hasattr(d, "five")



# Generated at 2022-06-22 04:39:32.975079
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import zlib

    # test data
    text = b"any string"
    compressed = zlib.compress(text)
    output = zlib.decompress(compressed)
    assert output == text

    # now test with our method
    gzip_decompressor = GzipDecompressor()
    output2 = gzip_decompressor.decompress(compressed)
    assert output2 == output


# Generated at 2022-06-22 04:39:39.324866
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()  # type: ignore
    except Exception as e:
        assert isinstance(e, TimeoutError)  # type: ignore

try:
    import thread

    # The identifier of the current thread
    thread_ident = thread.get_ident
except ImportError:
    import _thread
    # The identifier of the current thread
    thread_ident = _thread.get_ident

import functools



# Generated at 2022-06-22 04:39:49.682950
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fn1(a, b=None, c=None):
        pass

    def fn2(a, b, c=None):
        pass

    def fn3(a, b=None, c=None, *d):
        pass

    def fn4(a, b, c=None, *d):
        pass

    def fn5(a, b, c, **d):
        pass

    def fn6(a, b, c=None, **d):
        pass

    def test(name, *args, **kwargs):
        fn = eval("fn" + name)
        r = ArgReplacer(fn, "b")
        return r.get_old_value(args, kwargs)

    assert test("1") == None
    assert test("1", 123) == None