

# Generated at 2022-06-22 04:30:17.418574
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    failure_count, test_count = doctest.testmod()
    assert test_count > 0
    assert failure_count == 0



# Generated at 2022-06-22 04:30:18.939781
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__(): pass

ObjectDict.__setattr__ = test_ObjectDict___setattr__


# Generated at 2022-06-22 04:30:23.496191
# Unit test for function import_object
def test_import_object():
    try:
        import tornado.testing
        import_object('tornado.testing') is tornado.testing
        assert True
    except ImportError as e:
        assert False



# Generated at 2022-06-22 04:30:28.318865
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    _ObjectDict = ObjectDict()
    assert hasattr(_ObjectDict, "__setattr__")
    assert not hasattr(_ObjectDict, "__dict__")
    try:
        _ObjectDict.__setattr__("a", 1)
    except AttributeError:
        pass
    else:
        raise Exception("AttributeError not raised")



# Generated at 2022-06-22 04:30:39.777036
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class MyException(Exception):
        def __init__(self, msg: str, errno: Optional[int]) -> None:
            Exception.__init__(self, msg)
            self.errno = errno
    class MyException2(Exception):
        def __init__(self, errno: Optional[int]) -> None:
            Exception.__init__(self, [errno])
    class MyException3(Exception):
        def __init__(self) -> None:
            Exception.__init__(self)
    try:
        raise MyException("error", 1)
    except BaseException as e:
        assert errno_from_exception(e) == 1
    try:
        raise MyException2(1)
    except BaseException as e:
        assert errno_from_exception(e) == 1
   

# Generated at 2022-06-22 04:30:52.950009
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.httpclient import AsyncHTTPClient

    def test_configuration():
        # Methods to test classes and methods of class Configurable
        # which are used for configuring classes
        class SomeClass(Configurable):
            @classmethod
            def configurable_base(cls):
                return SomeClass

            @classmethod
            def configurable_default(cls):
                return RealSomeClass

            def initialize(self, a, b):
                self.a = a
                self.b = b

        class RealSomeClass(SomeClass):
            def __init__(self, a, b, *args, **kwargs):
                super().__init__(a, b, *args, **kwargs)

        SomeClass.configure(None, c=1)

# Generated at 2022-06-22 04:31:01.631410
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from typing import List

    class A(Configurable):
        def __init__(self):
            pass

        def __str__(self):
            return "A"

        def configurable_default(cls):
            return A

        def configurable_base(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert str(a) == "A"
    assert a.configured_class() == A

    class B(A):
        def __init__(self):
            pass

        def __str__(self):
            return "B"

        def configurable_default(cls):
            return B

        def initialize(self, *args, **kwargs):
            pass

    b = B()
    assert str(b) == "B"

# Generated at 2022-06-22 04:31:08.104203
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import sys
    import unittest

    class ConfigurableTestCase(unittest.TestCase):
        def test_configurable(self):
            class Base(Configurable):
                def configurable_base(self):
                    return Base

                def configurable_default(self):
                    return DefaultImpl

                def initialize(self, n, **kwargs):
                    self.n = n
                    self.kwargs = kwargs

            class DefaultImpl(Base):
                def initialize(self, n, **kwargs):
                    super(DefaultImpl, self).initialize(n, **kwargs)
                    self.impl = "default"

            class CustomImpl(Base):
                def initialize(self, n, **kwargs):
                    super(CustomImpl, self).initialize(n, **kwargs)
                    self.impl = "custom"

           

# Generated at 2022-06-22 04:31:20.278097
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    from io import BytesIO
    from gzip import GzipFile
    import random
    import string
    import unittest
    for _ in range(1000):
        s = ''.join(random.choice(string.ascii_letters) for i in range(100)).encode()
        gzip_file = BytesIO()
        gz_file = GzipFile(mode='wb', compresslevel=5, fileobj=gzip_file)
        gz_file.write(s)
        gz_file.close()
        gzip_file.seek(0)
        gzipper = GzipDecompressor()
        self.assertEqual(s, gzipper.decompress(gzip_file.read()))
    gzipper = GzipDecompressor()

# Generated at 2022-06-22 04:31:28.348936
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():

    # This file was generated from a string that contains all characters
    # with the exception of null byte
    f = open(os.path.join(os.path.dirname(__file__), "all_except_null.gz"), 'rb')
    x = f.read()
    U = GzipDecompressor().decompress(x)

    # This file was generated from a string that contains all characters
    # with the exception of null byte
    f = open(os.path.join(os.path.dirname(__file__), "all_except_null"), 'rb')
    x = f.read()

    assert U == x


# Generated at 2022-06-22 04:31:52.963728
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def foo():
        raise IndexError()

    def bar():
        foo()

    try:
        bar()
    except:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-22 04:32:02.185022
# Unit test for constructor of class Configurable
def test_Configurable():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C1

        def initialize(self, foo1, foo2, bar=None):
            assert foo1 == "foo1"
            assert foo2 == "foo2"
            assert bar == "bar"

    class C1(C):
        pass

    class C2(C):
        pass

    C().configure(C2, bar="bar")
    c = C("foo1", "foo2")
    assert isinstance(c, C2)

    c2 = C1("foo1", "foo2")
    assert isinstance(c2, C1)



# Generated at 2022-06-22 04:32:10.165533
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    assert isinstance(TimeoutError(), TimeoutError)  # type: ignore
    # check that args are preserved
    assert TimeoutError(*(0,)).args == (0,)
    # check that repr works
    assert repr(TimeoutError(*(0,))) == "TimeoutError(0,)"


try:
    import concurrent.futures

    _FUTURES_TIMEOUT_ERROR = concurrent.futures.TimeoutError
except ImportError:  # pragma: no cover
    _FUTURES_TIMEOUT_ERROR = None



# Generated at 2022-06-22 04:32:13.486449
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError("exception message")
    except ValueError:
        exc_info = ()  # type: Tuple[None, None, None]
        raise_exc_info(exc_info)
    assert False, "Expected a ValueError"

test_raise_exc_info()
del test_raise_exc_info



# Generated at 2022-06-22 04:32:25.986115
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Foo(Configurable):
        def __init__(self, a, b=0, **kwargs):
            self.a = a
            self.b = b
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Bar

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert Foo is Foo.configurable_base()
    assert Bar is Foo.configurable_default()
    assert Foo is Foo().__class__
    assert isinstance(Foo(), Foo)
    assert not isinstance(Foo(), Bar)
    assert not isinstance(Foo(), Baz)
    assert Bar is Foo.configured_

# Generated at 2022-06-22 04:32:37.511864
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.gen import coroutine

    class S(Configurable):
        @classmethod
        def configurable_base(cls):
            return S

        @classmethod
        def configurable_default(cls):
            return S_impl

        def initialize(self, x, y, z):
            self.xyz = x, y, z

    class S_impl(S):
        @coroutine
        def initialize(self, x, y, z):
            self.xyz = x, y, z

    @coroutine
    def f():
        s = S(1, 2, 3)
        assert s.xyz == (1, 2, 3)
        s = yield S(4, 5, 6)
        assert s.xyz == (4, 5, 6)

    S.configure(None)
    i

# Generated at 2022-06-22 04:32:39.484519
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    dec = GzipDecompressor()
    by = dec.decompress(b'z')



# Generated at 2022-06-22 04:32:52.215004
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import time
    d = GzipDecompressor()
    input_data = (
        b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6d\x6f\xa3\x36\x10\xfd'
        b'\xf7\x57\x08\x7f\xef\xaf\x60\x18\xc0\x60\x1f\x04\x18\x0c\x80\x00'
        b'\x33\x04\x08\xed\x99\x83\x36\x00\x0c\x00\x1a\x00\x00\x00'
    )

# Generated at 2022-06-22 04:33:00.675160
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class C:
        def foo(a, b=None):
            pass

    arg_replacer = ArgReplacer(C().foo, "b")
    assert arg_replacer.arg_pos == 1
    assert arg_replacer.name == "b"

    old_val, args, kwargs = arg_replacer.replace("value", ("a",), {})
    assert old_val is None
    assert args == ("a", "value")
    assert kwargs == {}

    old_val, args, kwargs = arg_replacer.replace("value", ("a",), {"b": "old value"})
    assert old_val == "old value"
    assert args == ("a",)
    assert kwargs == {"b": "value"}



# Generated at 2022-06-22 04:33:04.093829
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    assert ObjectDict().__getattr__('name') == AttributeError('name')


# Generated at 2022-06-22 04:33:31.000599
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    class DummyBase(Configurable):
        def configurable_base(self):
            return DummyBase

        def configurable_default(self):
            return DummyImpl

        def initialize(self, *args, **kwargs):
            return

    class DummyImpl(DummyBase):
        pass

    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            return

    # You can't instantiate a Configurable directly.
    with pytest.raises(TypeError):
        A()

    # If you configure something else as the default, you get that.
    A.configure(DummyImpl)
    assert isinstance(A(), DummyImpl)

# Generated at 2022-06-22 04:33:37.244857
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import gzip

    value = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6d\x6f\xdb\x36\x10\xfe' \
            b'\xe7\x52\x28\xcf\x2f\xca\x49\xe1\x02\x00\x0b\xf3\x01\x06\x00\x00\x00'
    gzip_decompressor = GzipDecompressor()
    output = gzip_decompressor.decompress(value)
    gzip_file = gzip.GzipFile(fileobj=bytes_buffer(value))
    assert output == gzip_file.read()
    assert gzip_decompressor.un

# Generated at 2022-06-22 04:33:50.011681
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    from tornado.tcpserver import TCPServer
    from tornado.ioloop import IOLoop

    class TestConfigurable(Configurable):
        def configurable_base(cls):
            return TestConfigurable

        def configurable_default(cls):
            return TCPServer

    TestConfigurable.configure(TCPServer)

    saved_loop = IOLoop.current()
    loop = IOLoop()
    AsyncIOMainLoop().install()
    loop.make_current()

    try:
        @asyncio.coroutine
        def f():
            server = TCPServer()
            yield from server

    finally:
        loop.clear_current()
        IOLoop.clear_current()

# Generated at 2022-06-22 04:33:56.487256
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # type: () -> None
    """Unit test for method flush of class GzipDecompressor.
    """
    gzipDecompressor = GzipDecompressor()
    assert gzipDecompressor.flush() == b''
    value = b''
    assert gzipDecompressor.decompress(value) == b''
    value = b'a'
    assert gzipDecompressor.decompress(value) == b'a'
    assert gzipDecompressor.flush() == b''
    value = b'b'
    assert gzipDecompressor.decompress(value) == b'b'
    assert gzipDecompressor.flush() == b''
    value = b'\x00\x00\x00\x00\x00'
    assert gzipDecompressor.decompress(value)

# Generated at 2022-06-22 04:34:06.593589
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    from tornado import gen
    import tornado.testing as tt
    from tornado.util import ObjectDict
    import unittest
    import typing
    @gen.coroutine
    def func(x:bool):
        pass
    func = tt.async_test(func)
    test = unittest.TestCase()
    test.assertRaises(unittest.SkipTest, func, True)
    # the line below is at fault, find a way to suppress the exception
    foo = ObjectDict()
    foo.bar = 10
    test.assertEqual(foo.bar, 10)
foo = ObjectDict()
foo.bar = 10



# Generated at 2022-06-22 04:34:10.316496
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def inner():
        try:
            raise TypeError('hello')
        except Exception:
            raise_exc_info(sys.exc_info())

    try:
        inner()
    except TypeError as e:
        assert 'hello' in str(e)



# Generated at 2022-06-22 04:34:22.502062
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f1(a, b, c):
        pass

    def f2(a, b, c=2):
        pass

    def f3(a, b, c=2, *args):
        pass

    def f4(a, b, c=2, **kwargs):
        pass

    def f5(a, b, c=2, *args, **kwargs):
        pass

    f_list = [
        f1,
        f2,
        f3,
        f4,
        f5,
    ]
    for f in f_list:
        ar = ArgReplacer(f, "c")
        assert f.__name__ == ar.get_old_value(getargspec(f).args, {}, "")

# Generated at 2022-06-22 04:34:28.065494
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def t(self, name, value):
        self[name] = value
    tests = [
        (1, 2)
    ]
    for i in tests:
        ObjectDict().__setattr__(*i)
    for i in tests:
        t(*i)


# Generated at 2022-06-22 04:34:37.400106
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    obj = GzipDecompressor()
    obj.flush()
    assert True


# Aliases for some common Exception classes.
# Keep them lowercase, like the built-in exceptions.
# Aliases are based on PEP8 and Python 3 docs:
#   https://www.python.org/dev/peps/pep-0008/#prescriptive-naming-conventions
#   https://docs.python.org/3/library/exceptions.html
#
# Many are not included because they are not used internally by Tornado.
# Several of these aliases, including HTTPError and HTTPException are
# not actually used within Tornado, but can be useful to users.



# Generated at 2022-06-22 04:34:44.200671
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
    
        def initialize(self, *args, **kwargs):
            pass
    
        
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
    
        
        @classmethod
        def configurable_default(cls):
            return TestConfigurable
    
    # Call function
    #TODO:
    #test = TestConfigurable()


# Generated at 2022-06-22 04:35:20.390568
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\w") == "w"
    assert re_unescape(r"\W") == "W"
    assert re_unescape(r"\d") == "d"
    assert re_unescape(r"\D") == "D"
    assert re_unescape(r"\s") == "s"
    assert re_unescape(r"\S") == "S"
    with pytest.raises(ValueError):
        re_unescape(r"\u")
    with pytest.raises(ValueError):
        re_unescape(r"\a")



# Generated at 2022-06-22 04:35:23.239198
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.x = 3
    assert a['x'] == 3
    assert a.x == 3



# Generated at 2022-06-22 04:35:26.228436
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    c1 = Configurable.configure("tornado.util")
    c2 = Configurable()
    c3 = Configurable("", _initialize())



# Generated at 2022-06-22 04:35:37.722089
# Unit test for function exec_in
def test_exec_in():
    g = {'x': 1}
    l = {'y': 2}
    exec_in("y+=1; x+=1", g, l)
    assert g == {'x': 2}
    assert l == {'y': 3}


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.

# Generated at 2022-06-22 04:35:46.835813
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=3600)) == 3600
    assert timedelta_to_seconds(datetime.timedelta(seconds=3660)) == 3660
    assert timedelta_to_seconds(datetime.timedelta(days=2)) == 172800
    assert timedelta_to_seconds(datetime.timedelta(days=2, seconds=3660)) == 186460

if not hasattr(datetime.timedelta, "total_seconds"):
    datetime.timedelta.total_seconds = timedelta_to_seconds



# Generated at 2022-06-22 04:35:59.135442
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    ar = ArgReplacer(f, "b")
    assert ar.arg_pos == 1
    assert ar.get_old_value([1, 2, 3], {}) == 2
    assert ar.get_old_value([1, 2, 3], {}, default=4) == 2
    assert ar.get_old_value([1], {}, default=4) == 4
    assert ar.replace(4, [1, 2, 3], {}) == (2, [1, 4, 3], {})
    assert ar.replace(4, [1, 2], {"c": 3}) == (2, [1, 4], {"c": 3})

# Generated at 2022-06-22 04:36:02.077340
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(5, "error message")
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 5



# Generated at 2022-06-22 04:36:14.232738
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(re.escape("abc123")) == "abc123"
    assert re_unescape(re.escape("abc[123]")) == "abc[123]"
    assert re_unescape(re.escape("abc.123")) == "abc.123"
    assert re_unescape(re.escape("abc\\123")) == "abc\\123"
    assert re_unescape(re.escape("abc\n123")) == "abc\n123"
    assert re_unescape(re.escape("abc\n\t123")) == "abc\n\t123"
    assert re_unescape(r"\d") == r"\d"
    assert re_unescape(r"\D") == r"\D"
    assert re_unescape(r"\t") == "\t"
    assert re_un

# Generated at 2022-06-22 04:36:26.850000
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush(): # type: () -> None
    result = b""
    def _flush(
        data: bytes,
        result: bytes,
        obj: GzipDecompressor
    ) -> bytes:
        obj.decompress(data)
        result += obj.flush()
        return result


# Generated at 2022-06-22 04:36:37.196149
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    instance = ArgReplacer(func, "b")
    assert instance.get_old_value(("a","b","c"), {}) == "b"
    assert instance.get_old_value(("a","b","c"), {"b": "b1"}) == "b"
    assert instance.get_old_value(("a","b","c"), {"b": "b1"}, default="b2") == "b"
    assert instance.get_old_value(("a","b","c"), {"a": "a1"}, default="b2") == "b2"
    assert instance.get_old_value(("a","b","c"), {"c": "c1"}, default="b2") == "b2"

# Generated at 2022-06-22 04:37:44.124805
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass

# Alias for old name
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError


# Aliases for exception types that have moved.
# These aliases ensure that old code will not break but also
# that applications cannot accidentally catch unspecced exceptions.

# Generated at 2022-06-22 04:37:55.741649
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Foo(Configurable):
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b

        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Foo

        def initialize(self, *args, **kwargs):
            self.a = kwargs.get("a", 2)
            self.b = kwargs.get("b", 3)
    # Test the 'default' configuration
    a = Foo()
    assert a.a == 2
    assert a.b == 3
    # Test the 'custom' configuration
    Foo.configure("tests.util.Foo2")
    b = Foo()
    assert b.a

# Generated at 2022-06-22 04:38:06.087686
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from nose.tools import assert_raises

    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

    class Impl(Base):
        pass

    class Impl2(Base):
        pass

    Base.configure(Impl)
    assert_is(Base(), Impl())

    cls_impl = Impl()
    cls_impl2 = Impl2()
    instance = cls_impl(cls_impl2)
    instance2 = cls_impl(cls_impl2)
    assert_true(isinstance(instance, Base))
    assert_true(isinstance(instance, Impl))
    assert_true(isinstance(instance.cls_impl, Impl))

# Generated at 2022-06-22 04:38:09.754168
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.a = 5
    assert obj.a == 5
    obj.b = b'hi'
    assert obj.b == b'hi'


# Generated at 2022-06-22 04:38:20.654464
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    Configurable = Configurable
    class TestConfigurable(Configurable):
        """A configurable class for :func:`test_Configurable_initialize`
        """

        def configurable_base(self):
            # type: () -> TestConfigurable
            return TestConfigurable

        def configurable_default(self):
            # type: () -> TestConfigurable
            return TestConfigurable

        def initialize(self, **kwargs):
            # type: (Any) -> None
            """Initialize a `TestConfigurable` instance.

            This is just a shim to the real initialization, which is tested
            by :func:`test_Configurable_initialize`.
            """
            super(TestConfigurable, self).initialize(**kwargs)


# Generated at 2022-06-22 04:38:22.446607
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import pytest
    with pytest.raises(NotImplementedError):
        Configurable().initialize()


# Generated at 2022-06-22 04:38:34.597153
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    class TestConfigurable(Configurable):
        def configurable_base(cls):
            return cls

        def configurable_default(cls):
            return cls

    class Implementation(TestConfigurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # Tests for the default behaviour (configured_class = configurable_default)
    instance = TestConfigurable()
    assert isinstance(instance, TestConfigurable)

    instance = TestConfigurable(foo=5)
    assert isinstance(instance, TestConfigurable)
    assert instance.kwargs == {"foo": 5}

    # Tests for a configured class
    TestConfigurable.configure(Implementation)
    instance = TestConfigurable()

# Generated at 2022-06-22 04:38:39.557408
# Unit test for function exec_in
def test_exec_in():
    x = 5
    exec_in(
        "assert x == 6",
        {"x": 6},
        {"x": 5},
    )
    exec_in(
        "assert x == 6",
        {"x": 5},
        {"x": 5},
    )
    exec_in(
        "assert x == 5",
        {"x": 5},
    )



# Generated at 2022-06-22 04:38:48.017420
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return self

    class B(A):
        pass

    class C(A):
        def __init__(self, **kwargs):
            # type: (Any) -> None
            super(B, self).__init__(**kwargs)

    C().configure(B)
    assert isinstance(A(), B)



# Generated at 2022-06-22 04:38:57.422382
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Check that exception with errno attribute
    try:
        raise Exception("message", 123)
    except Exception as e:
        assert errno_from_exception(e) == 123

    # Check that exception with errno in args
    try:
        raise Exception(123)
    except Exception as e:
        assert errno_from_exception(e) == 123

    # Check that exception without errno
    try:
        raise Exception("message")
    except Exception as e:
        assert errno_from_exception(e) == None

    # Check that exception raised with no args
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) == None

