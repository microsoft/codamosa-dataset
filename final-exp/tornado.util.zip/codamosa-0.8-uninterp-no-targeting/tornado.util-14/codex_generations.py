

# Generated at 2022-06-22 04:30:29.168841
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        raise Exception("import_object should have failed")



# Generated at 2022-06-22 04:30:40.185046
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # pytype: disable=attribute-error
    # The attribute `func_closure` is not supported by pytype
    def f1(first, second=None):
        return (first, second)

    def f2(first, second=None, *args, **kwargs):
        return (first, second, args, kwargs)

    def f3(first, second, third=None, fourth=None, **kwargs):
        return (first, second, third, fourth, kwargs)

    def f4(first, second, third, fourth=None, **kwargs):
        return (first, second, third, fourth, kwargs)

    def f5(first, second, third, fourth=None, *args, **kwargs):
        return (first, second, third, fourth, args, kwargs)

    # test for

# Generated at 2022-06-22 04:30:53.323495
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c="foo"):
        pass
    ar = ArgReplacer(f, "b")
    v = ar.get_old_value((1, 2, 3), {"d": 4})
    assert v == 2
    v = ar.get_old_value((1, 2), {"b": 3, "c": 4})
    assert v == 3
    v = ar.get_old_value((1, 2), {"c": 4})
    assert v is None
    v = ar.get_old_value((1, 2), {"c": 4}, default=55)
    assert v == 55
    v = ar.replace(25, (1, 2, 3), {"d": 4})
    assert v == (2, (1, 25, 3), {"d": 4})

# Generated at 2022-06-22 04:30:57.875404
# Unit test for function raise_exc_info
def test_raise_exc_info():     # pragma: no branch
    try:
        raise Exception("bar")
    except Exception as e:
        # Capture the exception so that it's not in the chain.
        exc_info = (type(e), e, e.__traceback__)
    raise_exc_info(exc_info)


# Generated at 2022-06-22 04:31:05.090424
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def test_GzipDecompressor_flush(self):
        data = b"abc"
        mock_decompressobj = Mock()
        self.decompress = mock_decompressobj
        self.decompress.flush.return_value = b"ab"

        ret = self.flush()

        mock_decompressobj.flush.assert_called_once_with()
        self.assertEqual(ret, b"ab")


# Generated at 2022-06-22 04:31:10.357342
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=500000)) == 1.5
    # Test negative values.
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1.5)) == -1.5
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1, microseconds=-500000)) == -1.5
    # Test negative microseconds are added to seconds.
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=-500000)) == 0.5
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1, microseconds=500000)) == -0.5

# Generated at 2022-06-22 04:31:13.969173
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
  GzipDecompressor.__init__()
  GzipDecompressor.decompress()
  x = GzipDecompressor.flush()
  return x


# Generated at 2022-06-22 04:31:24.539944
# Unit test for function exec_in
def test_exec_in():
    def test():
        a = 1
        b = 2
        exec_in('c = a + b', locals())
        return c
    assert test() == 3
    # Test that globals are used if locals are not provided
    def test2():
        a = 1
        b = 2
        exec_in('c = a + b', globals())
        return c
    assert test2() == 3
    # Test that globals and locals can be used together
    def test3():
        a = 1
        b = 2
        c = 3
        exec_in('d = a + b + c', globals(), locals())
        return d
    assert test3() == 6
    # Test that the exec_in can take a code object
    def test4():
        a = 1
        b = 2

# Generated at 2022-06-22 04:31:34.889529
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    p = GzipDecompressor()
    content1=b'\x1f\x8b\x08\x08m\xf0U\x02\xff\xcb\xccM\xcdM\x01\x04\x00\x1b\x93\xfb\xf9\x05\x00\x8e\xe6\x17\x05\x00\x00\x00'
    content2=b'\x03\x00\x1b\x93\xfb\xf9\x05\x00i\x01\x03\x00\xdf\xcb\xeb\x7f\x00\x00\x00'
    content3=b'\x07\x00\x00\x00'
    assert p.decompress(content1)

# Generated at 2022-06-22 04:31:38.897842
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def some_func(a=1,b=2,c=3,**d):
        return a,b,c,d

    assert ArgReplacer(some_func,'b').get_old_value((1,2,3),{'t':9})==2


# Generated at 2022-06-22 04:31:53.454058
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()

if __debug__:
    # In the optimized mode, we don't even define the _assert_type_str
    # function.  It is only used for doctests and has no effect.
    def _assert_type_str(obj, typ, msg=None, module=None):
        # type: (Any, Any, Optional[str], Optional[Any]) -> None
        """Assert that obj is an instance of type typ, with a useful message."""
        assert isinstance(obj, typ), "%s (%s) is not an instance of %s" % (
            msg or "object",
            _type_name(obj, module),
            _type_name(typ, module),
        )



# Generated at 2022-06-22 04:32:01.794551
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 42
    assert d['foo'] == 42 and d.foo == 42
    d.foo = "bar"
    assert d['foo'] == "bar" and d.foo == "bar"
    d.foo = None
    assert d['foo'] is None and d.foo is None
    d['foo'] = None
    assert d['foo'] is None and d.foo is None
    d.foo = 123.456
    assert d['foo'] == 123.456 and d.foo == 123.456
    d[1] = 1
    d[0] = 0
    assert d[0] == 0 and d[1] == 1



# Generated at 2022-06-22 04:32:07.758783
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    try:
        raise TimeoutError(5)
    except TimeoutError as e:
        assert str(e) == '5'


try:
    import _thread as thread
except ImportError:
    import _dummy_thread as thread  # type: ignore



# Generated at 2022-06-22 04:32:15.121926
# Unit test for constructor of class Configurable
def test_Configurable():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return CDefault

        def initialize(self):
            self.foo = 'foo'

    class CSub1(C):
        pass

    class CSub2(C):
        pass

    class CSub2Sub(CSub2):
        pass

    class CDefault(C):
        pass

    class CDefaultSub(C):
        pass

    def check(cls, args, kwargs, result):
        # type: (...) -> None
        configured = cls(*args, **kwargs)
        assert isinstance(configured, result)
        assert configured.foo == 'foo'


# Generated at 2022-06-22 04:32:16.731589
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError('reason')



# Generated at 2022-06-22 04:32:18.868313
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(x, y, z):
        pass
    r = ArgReplacer(f, "y")
    assert r.get_old_value((1, 2, 3), {}, 4) == 2
    assert r.get_old_value((1,), {"y": 2}, 4) == 2


# Generated at 2022-06-22 04:32:27.304981
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def f():
        # type: () -> None
        raise Exception()

    def g():
        # type: () -> typing.NoReturn
        try:
            f()
        except Exception as e:
            # Python 2 does not propagate None for the second value, so
            # make sure raise_exc_info still works in that case.
            raise_exc_info((e.__class__, None, e.__traceback__))

    context = unittest.mock.patch("tornado.util.sys")
    with context as sys:
        sys.version_info = (3,)
        with pytest.raises(Exception):
            g()



# Generated at 2022-06-22 04:32:30.625705
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    if str(TimeoutError(5)) != "5 seconds" or str(TimeoutError(0)) != "0 seconds":
        raise Exception("Unexpected string for TimeoutError")



# Generated at 2022-06-22 04:32:39.439124
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # type: () -> None
    class MyException(Exception):
        def __init__(self, value):
            # type: (Any) -> None
            self.value = value

    e0 = MyException(0)
    e1 = MyException((1,))
    e2 = MyException({})
    e3 = MyException((2, 3))
    assert errno_from_exception(e0) == 0
    assert errno_from_exception(e1) == 1
    assert errno_from_exception(e2) == None
    assert errno_from_exception(e3) == 2



# Generated at 2022-06-22 04:32:44.856261
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError
    except TimeoutError:
        pass

# Formerly, this was separate from TimeoutError but they were equivalent
gen.TimeoutError = TimeoutError
ioloop.TimeoutError = TimeoutError



# Generated at 2022-06-22 04:32:56.748502
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=2, seconds=10)) == 172810.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=10)) == 10.0



# Generated at 2022-06-22 04:33:07.327065
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(None)
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(0)
    except Exception as e:
        assert errno_from_exception(e) == 0
    try:
        from socket import error as socket_error
        raise socket_error(0)
    except socket_error as e:
        assert errno_from_exception(e) == 0
    try:
        raise socket_error(None, "message")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-22 04:33:10.462718
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 1
    assert isinstance(d, dict)
    assert d['foo'] == 1
    assert d.foo == 1
    d['bar'] = 2
    assert d.bar == 2


# Generated at 2022-06-22 04:33:14.745447
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0



# Generated at 2022-06-22 04:33:16.661344
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def __init__(self):
            pass
    A.configure(None, x=2)

# Generated at 2022-06-22 04:33:21.047387
# Unit test for function import_object
def test_import_object():
    assert import_object("os") is os
    assert import_object("os.path") is os.path
    assert import_object("") is None



# Generated at 2022-06-22 04:33:22.804928
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    assert obj.__getattr__("__getattr__") == obj["__getattr__"]



# Generated at 2022-06-22 04:33:27.674119
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    d = GzipDecompressor()
    data = (b'\x1f\x8b\x08\x08\xc5Pi\x02\xff\x03\x00\x8d\xc9\xccM\x02\x00'
            b'\x84\xbezZ\x1b\x00\x00\x00')
    assert d.decompress(data) == b'Hello World!'



# Generated at 2022-06-22 04:33:35.179069
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test1(foo=1):
        return foo
    bar = 10
    _, args, kwargs = ArgReplacer("foo").replace(bar, (), {})
    assert test1(*args, **kwargs) == bar
    def test2(foo=1, bar=2):
        return foo, bar
    baz = 10
    _, args, kwargs = ArgReplacer("bar").replace(baz, (), {"foo": 1})
    assert test2(*args, **kwargs) == (1, baz)
    def test3(foo=1, bar=2):
        return foo, bar
    baz = 10
    _, args, kwargs = ArgReplacer("bar").replace(baz, (1,), {})
    assert test3(*args, **kwargs) == (1, baz)

# Generated at 2022-06-22 04:33:41.965631
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b=1, c=2, d=3):
        pass

    r = ArgReplacer(foo, 'b')
    assert r.get_old_value((), {}) is None
    assert r.get_old_value((), {'b': 42}) == 42
    assert r.get_old_value((0,), {}) == 1
    assert r.get_old_value((0,), {'b': 42}) == 1
    assert r.get_old_value((0,), {'c': 42}) == 1
    assert r.replace(123, (), {}) == (None, [123], {})
    assert r.replace(123, (), {'b': 1}) == (1, [123], {})

# Generated at 2022-06-22 04:33:53.321446
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    try:
        raise AttributeError("")
    except:
        try:
            raise AttributeError("")
        except:
            try:
                raise AttributeError("")
            except:
                try:
                    raise AttributeError("")
                except:
                    try:
                        raise AttributeError("")
                    except:
                        try:
                            raise AttributeError("")
                        except:
                            try:
                                raise AttributeError("")
                            except:
                                pass


# Generated at 2022-06-22 04:34:04.233859
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def _initialize(self):
            print('_initialize in Class A')

    class B(A):
        pass

    class C(A):
        def _initialize(self):
            print('_initialize in Class C')

    a = A()
    b = B()
    c = C()
    a.configure('A')
    b.configure('B')
    c.configure('C')
    a.initialize()
    b.initialize()
    c.initialize()

if __name__ == '__main__':
    test_Configurable_initialize()


# Generated at 2022-06-22 04:34:05.073951
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # type: ignore
    m = ObjectDict()
    m.foo = 1
    assert m.foo == 1



# Generated at 2022-06-22 04:34:16.741665
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import os
    from tornado import gen
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.httpserver import HTTPServer
    from tornado.httpclient import AsyncHTTPClient
    from tornado.netutil import bind_sockets
    from tornado import stack_context
    from tornado.tcpserver import TCPServer
    from tornado.testing import AsyncHTTPTestCase, get_unused_port
    from tornado.web import Application, RequestHandler

    # A configurable HTTPServer that can use either an epoll IOLoop or
    # a SelectorIOLoop.
    class Server(Configurable):
        @classmethod
        def configurable_base(cls):
            return Server

        @classmethod
        def configurable_default(cls):
            return TCPServer


# Generated at 2022-06-22 04:34:28.155376
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    decompressor = GzipDecompressor()
    output = decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
                                     b'\x4b\xca\xcf\x2f\x4a\x2d\x2e\x49\x2c'
                                     b'\x49\xe9\x02\x00\x22\x8e\xbd\x0b\x04'
                                     b'\x00\x00\x00')
    assert output == b'hello world'
    assert decompressor.flush() == b''

# make GzipDecompressor a static class method, make it take an optional parameter

# Generated at 2022-06-22 04:34:30.184868
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    od = ObjectDict()
    od['toto'] = 'tutu'
    assert od.toto == 'tutu'

# Generated at 2022-06-22 04:34:34.763814
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    compressed_data = zlib.compress(b"Some data to compress")
    uncompressed_data = decompressor.decompress(compressed_data)
    assert b"Some data to compress" == uncompressed_data



# Generated at 2022-06-22 04:34:45.068989
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f1(posarg, namedarg=1):
        pass
    posarg_replacer = ArgReplacer(f1, 'posarg')
    namedarg_replacer = ArgReplacer(f1, 'namedarg')
    nv1 = 2
    nv2 = 3
    args = (2, 1)
    kwargs = {}
    r1 = posarg_replacer.replace(nv1, args, kwargs)
    r2 = namedarg_replacer.replace(nv2, args, kwargs)
    assert r1 == (2, (nv1, 1), {})
    assert r2 == (1, (nv1, 1), {'namedarg': nv2})

# Generated at 2022-06-22 04:34:53.332818
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError
    except OSError as e:
        assert errno_from_exception(e) is None
    try:
        raise OSError(1)
    except OSError as e:
        assert errno_from_exception(e) == 1
    try:
        raise OSError("error message")
    except OSError as e:
        assert errno_from_exception(e) == "error message"
    try:
        raise OSError(1, "error message")
    except OSError as e:
        assert errno_from_exception(e) == (1, "error message")

# Generated at 2022-06-22 04:35:01.936885
# Unit test for function import_object
def test_import_object():
    from unittest import mock

    test = mock.Mock()
    mocked_import = mock.Mock(return_value=test)
    with mock.patch("importlib.__import__", mocked_import):
        assert import_object("test") == test

    mocked_import.side_effect = Exception()
    with mock.patch("importlib.__import__", mocked_import):
        try:
            import_object("test")
        except ImportError:
            pass

    mocked_import.side_effect = None
    with mock.patch("importlib.__import__", mocked_import):
        assert import_object("test") == test


# Generated at 2022-06-22 04:35:16.963686
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Super(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Super

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Sub

    class Sub(Super):
        def _initialize(self):
            # type: () -> None
            self.foo = 42

    s = Super()
    assert isinstance(s, Sub)
    assert s.foo == 42

    class Sub2(Super):
        def _initialize(self):
            # type: () -> None
            self.foo = 43

    Super.configure(Sub2)
    s = Super()
    assert isinstance(s, Sub2)
    assert s.foo

# Generated at 2022-06-22 04:35:18.260431
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    o = Configurable()
    o.initialize()

# Generated at 2022-06-22 04:35:27.992421
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def raise_exception(exception_type):
        # type: (Type[BaseException]) -> None
        try:
            raise exception_type("Excption type test.")
        except BaseException:
            # *_exc_info function will return a tuple of (type, value, traceback).
            # Stack frame is build before the exception is raised.
            raise_exc_info(sys.exc_info())

    raise_exception(KeyError)
    raise_exception(TypeError)
    raise_exception(ValueError)


_DAYNAMES = [
    "Mon",
    "Tue",
    "Wed",
    "Thu",
    "Fri",
    "Sat",
    "Sun",
]

# Generated at 2022-06-22 04:35:37.376314
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    def f(arg1, arg2=None, arg3=None):
        pass

    arg_replacer = ArgReplacer(f, "arg2")
    assert arg_replacer.get_old_value((None,), {}) is None
    assert arg_replacer.get_old_value((None, None), {}) == None
    assert arg_replacer.get_old_value((None, None), {}, default=5) == 5
    assert arg_replacer.get_old_value((None,), {"arg2": "not None"}) == "not None"



# Generated at 2022-06-22 04:35:44.064220
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is a complete gzip file, with header and checksum
    # and everything.  Only the data is compressed.
    gzip_file = (
        b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6c\x6f"
        b"\x63\x61\x6c\x68\x6f\x73\x74\x00\xed\xd3\xb1\x09"
        b"\x00\x00\x00"
    )
    body = (
        b"I am the very model of a modern major general.  "
        b"I've information vegetable, animal, and mineral, "
        b"I know the kings of England, and I quote the fights "
    )
   

# Generated at 2022-06-22 04:35:51.381573
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This construct works on cpython but not pypy,
    # because pypy accepts only the zlib module constants.
    # GzipDecompressor(wbits=16+zlib.MAX_WBITS)
    pass

# Constants from the zlib module (for note see above test)
_WBITS = zlib.MAX_WBITS | 16

_DEFLATED = 8



# Generated at 2022-06-22 04:35:54.242039
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c):  # type: ignore
        pass

    assert ArgReplacer(func, "b").arg_pos == 1
    assert ArgReplacer(func, "d") is None



# Generated at 2022-06-22 04:35:57.192715
# Unit test for function import_object
def test_import_object():
    import sys
    import_object("os.path")
    import_object("os.missing_module")
    import_object("os.path.missing_module")



# Generated at 2022-06-22 04:36:09.957665
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This test comes from the original decompressobj.
    compressor = zlib.compressobj(9, zlib.DEFLATED, -zlib.MAX_WBITS,
                                  zlib.DEF_MEM_LEVEL, 0)
    compressed = compressor.compress('abcdefgh' * 1024)
    compressed += compressor.flush()

    # Use the decompressor with max_length to simulate incremental data
    dec = GzipDecompressor()
    for i in range(0, len(compressed), 30):
        assert dec.decompress(compressed[i:i+30], 30) == b'abcdefgh' * 32

    # Finish up
    assert dec.unconsumed_tail == b""
    assert dec.flush() == b""

    # Make sure that we don't have any errors
    assert not dec.un

# Generated at 2022-06-22 04:36:19.969683
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gz = GzipDecompressor()
    gz.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00')
    gz.decompress(b'\x03\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-22 04:36:34.753460
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    # Ensure that examples from the docs can be compiled and execute without error.
    from tornado.concurrent import chain_future, Future

    def f2(s):
        # type: (str) -> str
        return s

    try:
        from tornado.gen import coroutine
    except ImportError:
        # Skip this test on older Pythons without the decorator.
        return
    from tornado.ioloop import IOLoop

    @coroutine
    def f():
        # type: () -> str
        return "test"

    @coroutine
    def f3():
        # type: () -> str
        return (yield f())

    @coroutine
    def f4():
        # type: () -> str
        return (yield chain_future(f(), f2))


# Generated at 2022-06-22 04:36:43.260368
# Unit test for function re_unescape
def test_re_unescape():
    # Test normal case
    assert re_unescape("a\\.b") == "a.b"
    # Test exception
    try:
        re_unescape("a\\db")
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError not raised")
    # Test null character
    assert re_unescape("a\\0b") == "a\0b"
    # Test special characters
    assert re_unescape("a\\tb") == "a\tb"



# Generated at 2022-06-22 04:36:49.983250
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except IOError as e:
        errno = errno_from_exception(e)
        assert errno is None

    try:
        raise IOError(errno=1)
    except IOError as e:
        errno = errno_from_exception(e)
        assert errno == 1

    try:
        raise IOError(1)
    except IOError as e:
        errno = errno_from_exception(e)
        assert errno == 1



# Generated at 2022-06-22 04:37:00.658350
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun(a, b, c=3, d=4):
        return a, b, c, d
    args = (1, 2)
    kwargs = {'d': 10}
    arg1 = ArgReplacer(fun, 'c')
    assert arg1.get_old_value(args, kwargs) == 3
    assert arg1.replace(20, args, kwargs) == (3, (1, 2), {'d': 10})
    arg2 = ArgReplacer(fun, 'b')
    assert arg2.get_old_value(args, kwargs) == 2
    assert arg2.replace(20, args, kwargs) == (2, (1, 20), {'d': 10})
    arg3 = ArgReplacer(fun, 'z')
    assert arg3.get_

# Generated at 2022-06-22 04:37:07.118433
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=2, microseconds=3)) == 86400 + 2 + 0.000003
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=2, microseconds=3)) == -(86400 + 2 + 0.000003)



# Generated at 2022-06-22 04:37:18.940953
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def f(pos1, pos2, kw1=None, kw2=None):
        # type: (str, str, Optional[str], Optional[str]) -> None
        pass

    @ArgReplacer(f, "pos1")
    def g(pos1, pos2, kw1=None, kw2=None):
        # type: (str, str, Optional[str], Optional[str]) -> None
        pass

    a = ArgReplacer(g, "pos2")
    assert a.get_old_value(("a", "b"), {}) == "b"
    assert a.get_old_value(("a",), {"pos2": "b"}) == "b"
    assert a.get_old_value(("a",), {}) is None
    assert a

# Generated at 2022-06-22 04:37:26.739480
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():  # pragma: nocover
    import datetime
    now = datetime.datetime.utcnow()
    assert timedelta_to_seconds(now - now) == 0
    assert timedelta_to_seconds(
        datetime.timedelta(days=2, hours=8, minutes=5, seconds=3, microseconds=12)
    ) == timedelta_to_seconds(datetime.timedelta(seconds=183512))
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400

from functools import wraps
from inspect import getargspec



# Generated at 2022-06-22 04:37:35.211544
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    """
    >>> def test(x):
    ...     a = ArgReplacer(test, "x")
    ...     return a.get_old_value((1, 2, x), {})
    >>> test(3)
    3
    >>> test("four")
    'four'
    >>> a = ArgReplacer(test, "x")
    >>> a.get_old_value((1, 2), {"x": "five"})
    'five'
    >>> a.get_old_value((1, 2), {}, default=6)
    6
    """
    pass



# Generated at 2022-06-22 04:37:38.695158
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod(doctest.__dict__.get("__all__", ()), extraglobs={"types": types})



# Generated at 2022-06-22 04:37:49.057586
# Unit test for function import_object
def test_import_object():
    def test_string():
        import tornado.escape
        assert import_object('tornado.escape') is tornado.escape
    def test_module():
        import tornado.escape
        assert import_object('tornado.escape') is tornado.escape
    def test_object():
        import tornado.escape
        assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    def test_root():
        import tornado
        assert import_object('tornado') is tornado
    def test_missing():
        import tornado
        import pytest
        try:
            import_object('tornado.missing_module')
        except ImportError:
            pass
        else:
            pytest.fail('expected ImportError')
    test_string()
    test_module()
    test_object()
    test_root()
    test

# Generated at 2022-06-22 04:38:21.250114
# Unit test for constructor of class Configurable
def test_Configurable():
    class Category(str, Configurable):
        def configurable_base(self):
            return Category

        def configurable_default(self):
            return Category('default')

    class InCategory(Configurable):
        def configurable_base(self):
            return InCategory

        def configurable_default(self):
            return InCategory()

    # Check Configurable without any configuration
    assert isinstance(Category('a'), Category)
    assert Category('a') == 'a'
    assert isinstance(InCategory(), InCategory)

    # Check Configurable with configuration
    Category.configure(None)
    assert isinstance(Category('a'), Category)
    assert Category('a') == 'default'
    assert isinstance(InCategory(), InCategory)

    # Check Configurable without any configuration

# Generated at 2022-06-22 04:38:33.607022
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def wrapped(*args, **kwargs):
        pass
    replacer = ArgReplacer(wrapped, "arg1")

    def test(func, *args, **kwargs):
        return func(*args, **kwargs)

    old_value, args, kwargs = replacer.replace("replace_value",
                                               (1, 2, 3), {"arg1": "arg1_kw", 'arg3':'arg3_kw'})
    assert old_value == "arg1_kw"
    assert args == (1, 2, 3)
    assert kwargs == {"arg1": "replace_value", 'arg3':'arg3_kw'}

    args, kwargs = replacer.replace("replace_value", [1, 2, 3], {})

# Generated at 2022-06-22 04:38:35.626005
# Unit test for function exec_in
def test_exec_in():
    d = dict(a=1)
    exec_in('b = a+1', d)
    assert d['b'] == 2



# Generated at 2022-06-22 04:38:48.016744
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is a modified version of the example at
    # http://stackoverflow.com/questions/1838699/how-can-i-decompress-a-gzip-stream-with-zlib
    # If the zlib module is not compiled with support for gzip,
    # this example will generate a error
    decompressobj = GzipDecompressor()
    compressed_data = (
        b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff\x06\x00BC\x02\x00\x1b\x00\x03"
        b"\x00\x00\x00\x00\x00\x00\x00\x00"
    )

# Generated at 2022-06-22 04:38:51.403853
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    a = GzipDecompressor()
    a.flush()



# Generated at 2022-06-22 04:38:53.610498
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    err = TimeoutError()
    assert err.args == ()
    err = TimeoutError("A message")
    assert err.args == ("A message",)



# Generated at 2022-06-22 04:39:00.673429
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class TestException(BaseException):
        pass

    try:
        raise TestException()
    except TestException as e:
        errno = errno_from_exception(e)
        print("Exception without errno: {}".format(errno))
        assert errno == None

    try:
        raise TestException("TestException")
    except TestException as e:
        errno = errno_from_exception(e)
        print("Exception with str: {}".format(errno))
        assert errno == "TestException"

    try:
        raise TestException("TestException", 111)
    except TestException as e:
        errno = errno_from_exception(e)
        print("Exception with str and errno: {}".format(errno))
        assert errno == "TestException"


# Generated at 2022-06-22 04:39:12.093216
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a,b,c=1,*d):
        pass
    f1 = ArgReplacer(f,'a')
    f2 = ArgReplacer(f,'b')
    f3 = ArgReplacer(f,'c')
    f4 = ArgReplacer(f,'d')
    f5 = ArgReplacer(f,'e')
    assert f1.get_old_value((1,2,3),{},None) == 1
    assert f2.get_old_value((1,2,3),{},None) == 2
    assert f3.get_old_value((1,2,3),{},None) == 3
    assert f4.get_old_value((1,2,3),{},None) == None

# Generated at 2022-06-22 04:39:23.898541
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    class Dummy:
        def foo(self, a, b, c = 3, d = 4):
            pass
    argReplacer = ArgReplacer(Dummy.foo, "c")
    for arg in argReplacer._getargnames(Dummy.foo):
        print(arg)

    def _get_old_value(args, kwargs, replace_arg, replace_arg_val, expect_val):
        old_val = argReplacer.get_old_value(args, kwargs, replace_arg_val)
        assert(old_val == expect_val)

    _get_old_value((1, 2, 3, ), {}, "c", 5, 3)
    _get_old_value((1, 2, ), {'c':3}, "c", 5, 3)
    _get_old_value

# Generated at 2022-06-22 04:39:34.244019
# Unit test for constructor of class Configurable
def test_Configurable():
    try:
        Configurable.configure("NoSuchClass", x=1)
    except ValueError:
        pass
    else:
        raise Exception("expected error from nonexistent impl class")
    try:
        Configurable.configure("tests.util_test.new_dummy_class", x=1)
    except ValueError:
        pass
    else:
        raise Exception("expected error from non-Configurable impl class")

    assert issubclass(Configurable.configured_class(), Configurable)
    assert Configurable().__class__ is Configurable.configured_class()
    assert Configurable.configured_class().__impl_kwargs == {}
    assert Configurable.configured_class().__impl_kwargs is not None

