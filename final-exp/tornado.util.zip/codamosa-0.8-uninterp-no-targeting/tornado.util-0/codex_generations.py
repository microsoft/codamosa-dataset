

# Generated at 2022-06-22 04:30:20.214044
# Unit test for constructor of class Configurable
def test_Configurable():
    @add_metaclass(Configurable)
    class TestConfigurable(object):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestImpl

        def initialize(self, foo):
            self.foo = foo

    class TestImpl(TestConfigurable):
        pass

    assert isinstance(TestConfigurable(), TestImpl)
    assert TestConfigurable(foo="foo").foo == "foo"
    assert TestConfigurable(foo="bar").foo == "bar"

    class TestImpl2(TestConfigurable):
        pass

    TestConfigurable.configure(TestImpl2)
    assert isinstance(TestConfigurable(), TestImpl2)
    assert TestConfigurable(foo="foo").foo == "foo"
    assert TestConfig

# Generated at 2022-06-22 04:30:23.444521
# Unit test for function exec_in
def test_exec_in():
    loc = {}
    exec_in('foo = 123', {}, loc)
    assert loc['foo'] == 123



# Generated at 2022-06-22 04:30:34.446490
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    from tornado.testing import AsyncTestCase, gen_test
    import tornado.util
    import tornado.web
    import tornado.testing
    import gzip
    import re
    import time
    import datetime
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    import tornado.httpclient
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.gen
    import tornado.locks
    import tornado.platform.asyncio
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.tcpclient
    import tornado.tc

# Generated at 2022-06-22 04:30:38.834192
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(3, "message")
    except IOError as e:
        test = errno_from_exception(e)
        assert test is 3
    try:
        raise IOError
    except IOError as e:
        test = errno_from_exception(e)
        assert test is None



# Generated at 2022-06-22 04:30:39.726583
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod(__import__("tornado.util"))

# Generated at 2022-06-22 04:30:52.857781
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    g = GzipDecompressor()
    if not hasattr(zlib, "compressobj"):
        return
    compressor = zlib.compressobj(6, zlib.DEFLATED, 16 + zlib.MAX_WBITS,
                                  zlib.DEF_MEM_LEVEL, 0)
    input = b'test'
    compressed = compressor.compress(input)
    compressed += compressor.flush()
    assert g.decompress(compressed) == input
    assert g.unconsumed_tail == b''

    compress = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff'
    compress += b'\x06\x00BC\x02\xfftest'

# Generated at 2022-06-22 04:30:55.481498
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError(123)
    except Exception:
        exc_info = sys.exc_info()
    raise_exc_info(exc_info)

# Fake __spec__ attribute so that mypy doesn't complain.

# Generated at 2022-06-22 04:31:03.665990
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Check the class method _restore_configuration
    _restore_configuration = Configurable._restore_configuration
    def mock_restore_configuration(saved):
        _restore_configuration(saved)
    Configurable._restore_configuration = mock_restore_configuration
    # Check the class method _save_configuration
    _save_configuration = Configurable._save_configuration
    def mock_save_configuration():
        mock_save_configuration.call_count += 1
        return _save_configuration()
    mock_save_configuration.call_count = 0
    Configurable._save_configuration = mock_save_configuration
    # Check the class method configure
    configure = Configurable.configure

# Generated at 2022-06-22 04:31:15.956977
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError('value')
    except ValueError as e:
        exc_info = (type(e), e, e.__traceback__)
        raise_exc_info(exc_info)

# Fake sigpipe for write errors.
# This is needed on jython (http://bugs.jython.org/issue1202)
# and may be needed on pypy (https://bitbucket.org/pypy/pypy/issues/1362/
# cpython-compatible-oserror-errno-32-broken).
try:
    import signal

    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
except (ImportError, ValueError):
    pass


# Shortcut versions of the functions in the _websocket module

# Generated at 2022-06-22 04:31:18.401720
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gzipDecompressor = GzipDecompressor()
    gzipDecompressor.decompress("Hello")
    gzipDecompressor.flush()

# Generated at 2022-06-22 04:31:35.325059
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(x, y, z, w=4):
        # type: (int, int, int, int) -> None
        pass

    old_value, args, kwargs = ArgReplacer("z", f).replace(3, (1, 2), {})
    assert old_value == None
    assert args == (1, 2, 3)
    assert kwargs == {}

    old_value, args, kwargs = ArgReplacer("z", f).replace(3, (1, 2, 5), {})
    assert old_value == 5
    assert args == (1, 2, 3)
    assert kwargs == {}

    old_value, args, kwargs = ArgReplacer("w", f).replace(3, (1, 2, 5), {})
    assert old_

# Generated at 2022-06-22 04:31:42.135606
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def myfunc(str_arg: str) -> None:
        print(str_arg)
    replacer = ArgReplacer(myfunc, "str_arg")
    old_value = replacer.get_old_value(("test",), {})
    assert old_value == "test"
    old_value = replacer.get_old_value(("test1",), {"str_arg":"test"})
    assert old_value == "test"
test_ArgReplacer_get_old_value()


# Generated at 2022-06-22 04:31:52.153381
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def gzip_decompress(data: str, decompressors: List[GzipDecompressor]) -> str:
        """
        returns decompressed string
        """
        if not data:
            return ""
        comp = decompressors[0]
        decompressed = comp.decompress(data)
        if comp.unconsumed_tail:
            # Copy the decompressor so we can decompress again from this point.
            decompressors[0] = GzipDecompressor()
            decompressors[0].decompress(comp.unconsumed_tail)
            if decompressors[0].unconsumed_tail:
                raise ValueError('unconsumed tail in new decompressor')
        return decompressed
    d=GzipDecompressor()
    d.decompress(b"m")
    d.flush()

# Generated at 2022-06-22 04:31:57.899631
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(positional, keyword=None):
        pass
    d = ArgReplacer(f, "positional")
    assert d.get_old_value(("foo",), {}, None) == "foo"
    assert d.get_old_value((), {"positional": "foo"}, None) == "foo"
    assert d.get_old_value((), {"other": "foo"}, None) == None
    assert d.get_old_value((), {}, "default") == "default"

    d = ArgReplacer(f, "keyword")
    assert d.get_old_value(("foo",), {"keyword": "foo"}, None) == "foo"
    assert d.get_old_value(("foo",), {"other": "foo"}, None) == None

# Generated at 2022-06-22 04:32:04.209406
# Unit test for function import_object
def test_import_object():
    assert import_object("time") is time

    # import_object should import attributes, not just modules
    assert import_object("time.time") is time.time

    with ExpectLog("tornado.util", "No module named time.array"):
        import_object("time.array")



# Generated at 2022-06-22 04:32:13.112453
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):
        pass

    class Impl(Foo):
        pass

    Foo.configure(Impl)

    assert isinstance(Foo(), Impl)
    assert issubclass(Foo.configured_class(), Foo)

    class OtherImpl(Foo):
        pass

    assert Foo.configured_class() is not OtherImpl
    Foo.configure(OtherImpl)
    assert Foo.configured_class() is OtherImpl

    class Bar(Configurable):
        pass

    class BarImpl(Bar):
        pass
    Bar.configure(BarImpl)

    assert Foo.configured_class() is OtherImpl
    assert Bar.configured_class() is BarImpl

    saved = Foo._save_configuration()

# Generated at 2022-06-22 04:32:25.584516
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    """Tests for `~GzipDecompressor.flush`.
    """
    compressor = GzipDecompressor()
    assert compressor.flush() == b""

    compressor.decompress(b"blah")
    assert compressor.flush() == b""

    compressor = GzipDecompressor()
    compressor.decompress(b"\x1f\x8b\x08\x08\x13\x7a\x7a\x70\x00\x03hello\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00")
    assert compressor.flush() == b"hello"

    compressor = GzipDecompressor()

# Generated at 2022-06-22 04:32:37.468378
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    d = ObjectDict((("a", 1), ("b", 2)))
    # Make sure dicts aren't modified by ObjectDict (copying is ok)
    assert d.a == 1
    assert d.b == 2
    assert len(d) == 2
    d.new = 30
    assert len(d) == 3
    assert d["new"] == 30
    assert d.new == 30
    assert d.a == 1
    d["newnew"] = "something"
    assert d.newnew == "something"
    d.newnewnew = []
    assert d.newnewnew == []

# DictProxy is a wrapper around a dictionary that exposes its items as
# attributes.  This is generally not safe to use with untrusted users
# (it allows arbitrary attribute access and setting) but it

# Generated at 2022-06-22 04:32:41.495354
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError
    except TimeoutError:
        pass
# End unit test for constructor of class TimeoutError

# Alias for backward compatibility.
gen_TimeoutError = TimeoutError


# Generated at 2022-06-22 04:32:43.050385
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    failure_count, _ = doctest.testmod()
    if failure_count:
        raise Exception("Failed %d doctests" % failure_count)



# Generated at 2022-06-22 04:32:52.786556
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    pass


# Generated at 2022-06-22 04:33:00.509689
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=1.0)) == 0.001
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1.0)) == 0.000001


if sys.version_info >= (3, 2):
    timedelta_to_seconds = datetime.timedelta.total_seconds


# Generated at 2022-06-22 04:33:13.459953
# Unit test for function re_unescape
def test_re_unescape():
    for s, expected in [
        (r"abc", "abc"),
        (r"abc\def", "abc\\def"),
        (r"abc\d\ef", "abc\\d\\ef"),
        (r"abc\d\ef", "abc\\d\\ef"),
        (r"abc\d\ef\g", "abc\\d\\ef\\g"),
        (r"abc\d\ef\g\\", "abc\\d\\ef\\g\\\\"),
        (r"abc\d\ef\g\\", "abc\\d\\ef\\g\\\\"),
        (r"abc\d\ef\g\\h", "abc\\d\\ef\\g\\\\h"),
    ]:
        assert re_unescape(s) == expected

# Generated at 2022-06-22 04:33:16.001429
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        os.chdir('/nonexisting')
    except Exception as e:
        pass
    assert errno_from_exception(e) == 2



# Generated at 2022-06-22 04:33:22.924515
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = GzipDecompressor()
    value = b"a" * 10000
    gzip_decompressor.decompress(value, 10000)
    gzip_decompressor.flush()
    print("test_GzipDecompressor_decompress is called.")
test_GzipDecompressor_decompress()


# Generated at 2022-06-22 04:33:27.009249
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    test = doctests()
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(test)
    runner = unittest.TextTestRunner()
    result = runner.run(suite)
    assert result.wasSuccessful(), result.failures + result.errors


if not hasattr(subprocess, '_args_from_interpreter_flags'):
    # _args_from_interpreter_flags was added to CPython in 3.7. It's
    # not present in PyPy 3.5 and 3.6, and should never be used on
    # Python 2.
    def _args_from_interpreter_flags():
        return []

    subprocess._args_from_interpre

# Generated at 2022-06-22 04:33:36.681239
# Unit test for function re_unescape
def test_re_unescape():
    # unit tests for re_unescape
    # re_unescape should return identity on valid regexes
    assert re_unescape("foo") == "foo"
    assert re_unescape("foo bar baz") == "foo bar baz"
    assert re_unescape("foo\\+\\*\\.\\{\\(\\)\\[\\]") == "foo+*\\.{()[]"
    # unescape should not convert extended ASCII characters
    assert re_unescape("foo\\x80bar") == "foo\\x80bar"
    # It should not unescape non-escaped characters
    assert re_unescape("\\\\") == "\\\\"
    # It should not unescape alphanum
    assert re_unescape("\\a") == "\\a"

# Generated at 2022-06-22 04:33:49.242372
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    dec = GzipDecompressor()
    assert dec.decompress(b"\x1f\x8b") == b""

# Copyright 2009 Jeffrey Finkelstein
# Copyright 2008 L. C. Rees.  All rights reserved.
#
# This file is part of the Biopython distribution and governed by your
# choice of the "Biopython License Agreement" or the "BSD 3-Clause License".
# Please see the LICENSE file that should have been included as part of this
# package.
"""This module provides functions for converting from and to strings
of DNA or RNA, including encoding and decoding ambiguous
nucleotides.

If you want to turn a ``Seq`` object into a string of letters, use
``str(my_seq)``.

.. versionadded:: 1.78
"""

# Standard nucleotide letter codes
IUP

# Generated at 2022-06-22 04:33:51.626805
# Unit test for function exec_in
def test_exec_in():
    glob, loc = {}, {}
    exec_in("x = 1", glob, loc)
    assert glob["x"] == 1
    assert loc["x"] == 1



# Generated at 2022-06-22 04:33:53.320855
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    assert isinstance(ObjectDict().__getattr__(name="foo"), AttributeError)



# Generated at 2022-06-22 04:34:11.936917
# Unit test for function re_unescape
def test_re_unescape():
    # Simple one for test coverage
    assert re_unescape(r"\\a") == r"\a"
    assert re_unescape(r"\\\.") == r"\."

    # Some complex cases to verify correct behavior
    assert re_unescape(r"\x") == r"x"
    assert re_unescape(r"\d") == r"d"
    assert re_unescape(r"\D") == r"D"
    assert re_unescape(r"\s") == r"s"
    assert re_unescape(r"\S") == r"S"
    assert re_unescape(r"\w") == r"w"
    assert re_unescape(r"\W") == r"W"
    assert re_unescape(r"\b") == r"b"


# Generated at 2022-06-22 04:34:14.127525
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decomp = GzipDecompressor()
    processed = decomp.decompress(zlib.compress(b"Hello, world!"))
    assert processed == b"Hello, world!"
    assert decomp.flush() == b""
    assert decomp.unconsumed_tail == b""

# Common exception classes used in Tornado code
# (prefixed with _ to minimize collisions)

# Generated at 2022-06-22 04:34:17.547751
# Unit test for function import_object
def test_import_object():
    assert import_object("sys") is sys
    assert import_object("os.path") is os.path
    assert import_object("os.missing_module")



# Generated at 2022-06-22 04:34:29.268757
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest

    class ForInitialize(Configurable):
        def __init__(self, *args, **kwargs):
            self.initialize(*args, **kwargs)
            self.initialized = True
            super(ForInitialize, self).__init__(*args, **kwargs)

        def configurable_base(self):
            return ForInitialize

        def configurable_default(self):
            return ForInitialize

        def initialize(self, a, b=1):
            self.a = a
            self.b = b

    class ForInitializeTest(unittest.TestCase):
        def test_initialize(self):
            a = ForInitialize(2, b=3)
            self.assertTrue(a.initialized)
            self.assertEqual(a.a, 2)

# Generated at 2022-06-22 04:34:33.096863
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("test")
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)


# Fake byte literal for python3.2

# Generated at 2022-06-22 04:34:44.560513
# Unit test for constructor of class Configurable
def test_Configurable():
    configs = []

    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Default

    class Default(Base):
        def initialize(self, name):
            configs.append(("Default", name))
            Base.initialize(self, name)

    class Impl1(Base):
        def initialize(self, name, x):
            configs.append(("Impl1", name, x))
            Base.initialize(self, name)

    class Impl2(Base):
        def initialize(self, name, x, y):
            configs.append(("Impl2", name, x, y))
            Base.initialize(self, name)


# Generated at 2022-06-22 04:34:52.972086
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_base = Configurable.configurable_base
    configurable_default = Configurable.configurable_default
    configure = Configurable.configure
    configured_class = Configurable.configured_class

    @add_metaclass(Configurable)
    class _Test_Configurable(object):
        pass

    class Test_Configurable(_Test_Configurable):
        @staticmethod
        def init():
            configure(Test_Configurable_Impl, arg_1=1, arg_2=2)
            inst = Test_Configurable()
            assert isinstance(inst, Test_Configurable)
            assert isinstance(inst, Test_Configurable_Impl)
            assert inst.name == "Test_Configurable_Impl"
            assert inst.arg_1 == 1
            assert inst.arg_2 == 2
        init = staticmethod

# Generated at 2022-06-22 04:35:00.594459
# Unit test for function exec_in
def test_exec_in():
    x = 1
    assert x == 1
    exec_in("x = x + 2", globals())
    assert x == 3
    exec_in("x = x + 2", globals())
    assert x == 5


# Fake byte literal support:  In python 3, one can use the b"..." syntax
# to create a byte literal.  In python 2 this is not supported (the b is
# taken literally).  This function creates those literals for python 2
# code.  The b"..." should be used in places where the value is intended
# to represent raw bytes, and should be passed to functions like
# httpclient.HTTPConnection.write() and used in places where strings
# and bytes should be kept separate (such as in http headers).

# Generated at 2022-06-22 04:35:12.471273
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b = 1, *c, d, **e):
        pass
    replacer = ArgReplacer(f, 'b')
    assert replacer.get_old_value((2, 3, 'a', 'b', 'c'), {'d': 1, 'e': 2}) == 1
    assert replacer.get_old_value((2, 3, 'a', 'b', 'c'), {'d': 1, 'e': 2}, default = 4) == 1
    assert replacer.get_old_value((2, ), {'d': 1, 'e': 2, 'b': 5}) == 5
    assert replacer.get_old_value((2, ), {'d': 1, 'e': 2, 'b': 5}, default = 4) == 5

# Generated at 2022-06-22 04:35:19.188414
# Unit test for function import_object
def test_import_object():
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    with pytest.raises(ImportError):
        import_object("tornado.missing_module")



# Generated at 2022-06-22 04:35:51.590742
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return None

        def __init__(self):
            raise Exception("should not reach here")

    a = A()
    assert a.__class__ == A
    assert type(a) == A
    assert isinstance(a, A)
    assert not isinstance(a, Configurable)

    class B(Configurable):
        @classmethod
        def configurable_base(cls):
            return B

        @classmethod
        def configurable_default(cls):
            return None

        def __init__(self):
            raise Exception("should not reach here")

    B.configure(impl=A)

    b = B()
   

# Generated at 2022-06-22 04:36:01.070434
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestableConfigurable(Configurable):
        def configurable_base(cls):
            return TestableConfigurable

        def configurable_default(cls):
            return TestableConfigurable

        def initialize(self, arg):
            self.arg = arg

    TestableConfigurable.configure(None)
    tc1 = TestableConfigurable(7)
    assert tc1.arg == 7

    @classmethod
    def initialize(cls, arg):
        cls.arg = arg

    TestableConfigurable.initialize = initialize
    TestableConfigurable.configure("tornado.util.Configurable")
    tc2 = TestableConfigurable(9)
    assert tc2.arg == 9



# Generated at 2022-06-22 04:36:02.449162
# Unit test for function import_object
def test_import_object():
    import_object('unittest.case').TestCase()


# Generated at 2022-06-22 04:36:14.796758
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado import gen
    from tornado.ioloop import IOLoop

    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Concurrent

        @classmethod
        def _save_configuration(cls):
            pass

        @classmethod
        def _restore_configuration(cls, saved):
            pass

        def initialize(self, value):
            self.value = value

    class Concurrent(Base):
        def do_thing(self, cb):
            cb()

    class Synchronous(Base):
        @gen.coroutine
        def do_thing(self):
            yield gen.moment

    def asynchronous_run(callback):
        IOLoop.current().add

# Generated at 2022-06-22 04:36:18.690686
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=3600)) == 3600.0
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001


# Generated at 2022-06-22 04:36:31.850602
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c=3, d=4):
        pass
    r = ArgReplacer(func, "d")
    assert r.get_old_value((1, 2), {}) == 4
    assert r.replace(5, (1, 2), {}) == (4, (1, 2), {})

    r = ArgReplacer(func, "c")
    assert r.get_old_value((1, 2), {}) == 3
    assert r.replace(5, (1, 2), {}) == (3, (1, 2, 5), {})

    r = ArgReplacer(func, "b")
    assert r.get_old_value((1, 2), {}) == 2
    assert r.replace(5, (1, 2), {}) == (2, (1, 5), {})



# Generated at 2022-06-22 04:36:37.276694
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test(a, b, c=0, *args, **kwargs):
        pass
    # args
    assert ArgReplacer(test, "a").arg_pos == 0
    assert ArgReplacer(test, "d").arg_pos is None
    # kwargs
    assert ArgReplacer(test, "c").arg_pos is None
    assert ArgReplacer(test, "d").arg_pos is None



# Generated at 2022-06-22 04:36:43.612348
# Unit test for function errno_from_exception
def test_errno_from_exception():
    e1 = Exception()
    assert errno_from_exception(e1) is None
    e2 = Exception(2)
    assert errno_from_exception(e2) == 2
    e3 = Exception("foo")
    assert errno_from_exception(e3) == "foo"



# Generated at 2022-06-22 04:36:45.744555
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError("Arthur")


# Exception raised when an IOLoop is closed.

# Generated at 2022-06-22 04:36:48.376062
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d['x'] == 1
    assert d.x == 1
    assert d.y == AttributeError



# Generated at 2022-06-22 04:37:24.969567
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    expectError(ImportError, "import_object('tornado.missing_module')")
test_import_object()

# Aliases to make the signatures match.
_basestring = basestring_type
_unicode = unicode_type
_bytes = bytes_type


# Types we can recognize as serializable or natively JSON-serializable.
# This is far from complete (especially with respect to date/datetime
# handling), but it works for our needs at the moment.

# Generated at 2022-06-22 04:37:28.829429
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    decompressor.decompress(bytes([255, 216, 0, 0]))
    decompressor.decompress(bytes([0, 1, 2]))
    bytes(decompressor)



# Generated at 2022-06-22 04:37:40.562499
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
        @staticmethod
        def func1(x):
            pass
        assert ArgReplacer(func=func1, name='x').get_old_value(args=[1], kwargs={}) == 1
        assert ArgReplacer(func=func1, name='x').get_old_value(args=[], kwargs={'x': 1}) == 1
        assert ArgReplacer(func=func1, name='x').get_old_value(args=[], kwargs={}) == None
        assert ArgReplacer(func=func1, name='x').get_old_value(args=[], kwargs={}, default=3) == 3
        @staticmethod
        def func2(x, y):
            pass

# Generated at 2022-06-22 04:37:50.242938
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    for c in b"hello there world this is a test":
        # All gzip compressions on this string should produce
        # different compressed bytes, so we can test each one
        # separately.
        gz = zlib.compressobj(c, zlib.DEFLATED, 31, 8,
                              zlib.Z_DEFAULT_STRATEGY)
        compressed = gz.compress(b'hello there world this is a test')
        compressed += gz.flush()
        gzd = GzipDecompressor()
        assert gzd.decompress(compressed) == b'hello there world this is a test'
        assert gzd.unconsumed_tail == b''
        assert gzd.flush() == b''
        assert gzd.flush() == b''  # second call is a no-op

# Generated at 2022-06-22 04:38:00.539088
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    z = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
    test_string = b"Hello, world!"
    compressed_string = z.compress(test_string) + z.flush()
    decompressor = GzipDecompressor()
    result = decompressor.decompress(compressed_string)
    assert result == test_string

# Alias for the name that was historically used in Tornado.
gzip_decompressor = GzipDecompressor


# See http://bugs.python.org/issue13761#msg155198
_UNSET_REASON = '__unset__'


# Generated at 2022-06-22 04:38:11.457658
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c):
        pass

    r = ArgReplacer(func, "c")
    assert r.arg_pos == 2
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2), {"c": 3}) == 3
    assert r.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert r.get_old_value((1, 2), {"d": 3}, default=4) == 4
    assert r.replace(4, (1, 2, 3), {}) == (3, (1, 2, 4), {})
    assert r.replace(4, (1, 2), {"c": 3}) == (3, (1, 2), {"c": 4})



# Generated at 2022-06-22 04:38:21.917733
# Unit test for function import_object
def test_import_object():
    from tornado.escape import native_str, utf8
    assert import_object("tornado.escape") is native_str
    assert import_object("tornado.escape") is utf8
    assert import_object("tornado.escape.utf8") is utf8
    assert import_object("tornado.escape") is native_str
    assert import_object("tornado.escape") is utf8
    assert import_object("tornado.escape").utf8 is utf8
    assert import_object("tornado.escape") is native_str
    assert import_object("tornado.escape") is utf8
    assert import_object("tornado.missing_module")

# Match type for email addresses

# Generated at 2022-06-22 04:38:34.284323
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gzipDecompressor = GzipDecompressor()
    f = open('tornado/test/gzip_test_file', 'rb')
    chunks = []
    decompressed_chunks = []
    unconsumed_tail = b""
    while True:
        chunk = f.read(1024)
        if not chunk: break
        chunks.append(chunk)
        decompressed_chunk, unconsumed_tail = gzipDecompressor.decompress(chunk,
                                                                           1024)
        decompressed_chunks.append(decompressed_chunk)
    last_chunk = gzipDecompressor.flush()
    decompressed_chunks.append(last_chunk)
    f.close()

# Generated at 2022-06-22 04:38:39.934459
# Unit test for function re_unescape
def test_re_unescape():
    # Test that the function fails on things it shouldn't unescape
    with pytest.raises(ValueError):
        re_unescape("\d")
    # Test that the function unescapes things it should
    assert re_unescape("spam") == "spam"
    assert re_unescape("\s\p\a\m") == "spam"

# Generated at 2022-06-22 04:38:51.218749
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d, e=0, f=0, *args, **kwargs):
        pass

    def f1(g, h=0, *args, **kwargs):
        pass

    def f2(*args, **kwargs):
        pass

    def f3(j):
        pass

    def f4(j, *args):
        pass

    def f5(j=0, *args):
        pass

    ar = ArgReplacer(f, "a")
    assert ar.name == "a"
    assert ar.arg_pos == 0
    assert ar.get_old_value((1, 2, 3, 4, 5), {}) == 1
    assert ar.replace(9, (1, 2, 3), {}) == (1, (9, 2, 3), {})

   

# Generated at 2022-06-22 04:39:50.124158
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except IOError as e:
        assert(errno_from_exception(e) is None)

    try:
        raise IOError(1)
    except IOError as e:
        assert(errno_from_exception(e) == 1)

    try:
        raise IOError("error")
    except IOError as e:
        assert(errno_from_exception(e) == "error")

