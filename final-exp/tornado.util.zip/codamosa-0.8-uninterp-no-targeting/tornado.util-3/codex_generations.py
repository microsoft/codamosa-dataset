

# Generated at 2022-06-22 04:30:29.212856
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(foo=1, bar=2)
    assert d['foo'] == 1
    assert d.foo == 1
    assert d.bar == 2
    assert d['bar'] == 2
    d.new_attr = 3
    assert d.new_attr == 3
    assert d['new_attr'] == 3

_NEG_INF = float("-inf")
_POS_INF = float("inf")
_NAN = float("nan")

_INF_NEG_OR_NAN = re.compile(r"(-?inf(inity)?|nan)", re.I)
_INF_OR_NAN = re.compile(r"(inf(inity)?|nan)", re.I)

_RE_TYPE = type(re.compile(""))



# Generated at 2022-06-22 04:30:39.154767
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    class TestObjectDict(ObjectDict):
        def __init__(self, *args):
            super().__init__(*args) # Test that this happens before setting the attribute to None
            self.attr = None

    def test_attr(obj):
        obj.attr = 1
        assert obj.attr == 1
        assert obj['attr'] == 1

    obj = TestObjectDict()
    test_attr(obj)

    # tests that an attribute can be initialized in __init__
    # this is important since the __init__ of ObjectDict is
    # called after the __setattr__
    assert obj.attr is None

    obj = TestObjectDict({'attr': 2})
    test_attr(obj)



# Generated at 2022-06-22 04:30:40.781725
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    # This is not useful as a doctest because it tests a function that
    # generates doctests.  But if it fails you should probably fix the
    # real doctests too.
    doctests().run(unittest.TestCase())



# Generated at 2022-06-22 04:30:54.051061
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test(a, b, c=None, d=None):  # type: ignore
        pass
    replacer = ArgReplacer(test, "d")
    assert replacer.get_old_value((), {}, None) is None
    old, args, kw = replacer.replace(123, (1, 2), dict(c="foo"))
    assert old is None
    assert args == (1, 2)
    assert kw == dict(c="foo", d=123)
    old, args, kw = replacer.replace(234, (1, 2, 3), dict(c="foo"))
    assert old == 3
    assert args == (1, 2, 234)
    assert kw == dict(c="foo")
    replacer = ArgReplacer(test, "c")
    old, args, kw = repl

# Generated at 2022-06-22 04:30:59.027563
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    dec=GzipDecompressor()
    assert dec.unconsumed_tail == b""
    dec.decompress(b"z")
    assert dec.unconsumed_tail == b"z"
    dec.decompress(b"z")
    assert dec.unconsumed_tail == b"z"
    assert dec.flush() == b""
    assert dec.unconsumed_tail == b""



# Generated at 2022-06-22 04:31:04.959390
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def __init__(self, *args: Any, **kwargs: Any):
            pass

        def initialize(self, *args: Any, **kwargs: Any):
            pass

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A
            pass
    A.configure(None, test=123)
    A.configure("tornado.util", test=123)

    a = A()
    assert isinstance(a, A)

    #assert False, "Pass"


# Generated at 2022-06-22 04:31:08.465957
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a_dict = ObjectDict(foo=42)
    assert a_dict.foo == 42
    assert a_dict['foo'] == 42
    with pytest.raises(AttributeError):
        a_dict.bar

# Generated at 2022-06-22 04:31:16.468273
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    a = ArgReplacer('test_ArgReplacer_replace', 'x')
    def f(*args, **kwargs):
        return a.replace('new', args, kwargs)
    old_value, args, kwargs = f(1, x=2, y=3)
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {'y': 3, 'x': 'new'}



# Generated at 2022-06-22 04:31:24.618372
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():  # type: ignore
    gzip_decompressor = GzipDecompressor()
    gzip_decompressor.decompress(b"")


# This is ugly, but it lets us test with both the real (C speed) version
# and the python version
try:
    from tornado.platform.auto import _GzipDecompressor
except ImportError:  # pragma: no cover
    _GzipDecompressor = None  # type: ignore

if _GzipDecompressor is not None:
    _GzipDecompressorImpl = _GzipDecompressor
else:
    _GzipDecompressorImpl = GzipDecompressor



# Generated at 2022-06-22 04:31:34.188958
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=0):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1,), {}) is None
    assert arg_replacer.get_old_value((1,), {'b': 2}) == 2
    assert arg_replacer.get_old_value((1,), {'b': 2}, 3) == 2
    assert arg_replacer.get_old_value((1,), {}, 3) == 3
    assert arg_replacer.get_old_value((1,2), {}) == 2
    assert arg_replacer.get_old_value((1,2), {'b': 3}) == 2


# Generated at 2022-06-22 04:31:47.859586
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.x = 10
    d['y'] = 20
    assert isinstance(d, ObjectDict)
    assert d.x == 10
    assert d['y'] == 20
    assert d.z == None


# backwards compatibility

# Generated at 2022-06-22 04:31:54.373518
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=1, b=2)
    assert d.a == 1
    assert d.b == 2
    assert d["a"] == 1
    assert d["b"] == 2
    d.c = 3
    assert d.c == 3
    assert d["c"] == 3
    with pytest.raises(AttributeError):
        d.d
    with pytest.raises(KeyError):
        d["d"]
    d.d = 4
    assert d.d == 4
    assert d["d"] == 4
    del d.c
    with pytest.raises(AttributeError):
        d.c
    with pytest.raises(KeyError):
        d["c"]
    assert d.d == 4
    assert d["d"] == 4
    del d.d

# Generated at 2022-06-22 04:32:02.215284
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    d = GzipDecompressor()
    uncompressed = d.decompress(gzip_decompress_payload)
    assert uncompressed == gzip_decompress_content
    tail = gzip_decompress_tail_odd
    t_1 = d.decompress(tail)
    t_2 = d.unconsumed_tail
    assert t_1 == b""
    assert t_2 == tail
    t_3 = d.decompress(tail,2)
    t_4 = d.unconsumed_tail
    assert t_3 == b""
    assert t_4 == tail

# Generated at 2022-06-22 04:32:12.722557
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    """Unit test for method flush of class GzipDecompressor
    """
    import tornado.testing
    class TestGzipDecompressor(tornado.testing.AsyncTestCase):
        def test_gzip_decompressor(self):
            gz_decompressor = GzipDecompressor()
            # Test with an empty input
            self.assertEqual(gz_decompressor.decompress(b''), b'')
            self.assertEqual(gz_decompressor.unconsumed_tail, b'')
            # Test with a non-empty input
            self.assertEqual(gz_decompressor.decompress(b'foo'), b'foo')
            self.assertEqual(gz_decompressor.unconsumed_tail, b'')

# Generated at 2022-06-22 04:32:25.261543
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    # Ignore PendingDeprecationWarnings from the docs themselves;
    # it's important that deprecated functions produce those warnings
    # and we want the unit tests to fail if they don't.
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=PendingDeprecationWarning)
        failure_count, test_count = doctest.testmod(
            verbose=False, optionflags=doctest.ELLIPSIS
        )
    assert test_count > 0
    assert failure_count == 0


# In order to write tests that are both python 2.7 and 3.x compatible,
# run the 2to3 conversion on all our files.  (This is a little ugly
# but so is everything about 2to3.)
_SIX_TEST_MOD

# Generated at 2022-06-22 04:32:37.468118
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2), {}) == 2
    assert r.get_old_value((1, 2), {}, default=3) == 2
    assert r.get_old_value((1,), {}) is None
    assert r.get_old_value((1,), {}, default=3) == 3
    assert r.get_old_value((1,), {"b": 2}) == 2
    assert r.get_old_value((1,), {"b": 2}, default=3) == 2
    assert r.replace(3, (1, 2), {}) == (2, (1, 3), {})

# Generated at 2022-06-22 04:32:50.042763
# Unit test for constructor of class Configurable
def test_Configurable():
    class Int(Configurable):
        def configurable_base(self):
            return Int

        def configurable_default(self):
            return Int32

        def initialize(self):
            pass

    class Int32(Int):
        pass

    class Int64(Int):
        pass

    Int.configure(Int32)
    assert Int() is not Int()
    assert Int() is not int()
    assert isinstance(Int(), Int32)
    assert isinstance(Int(), Int)
    assert not isinstance(Int(), Int64)
    Int.configure(Int64)
    assert isinstance(Int(), Int64)
    Int.configure(None)
    assert isinstance(Int(), Int32)
    Int.configure(Int32, a=1)
    Int.configure(Int64, b=2)


# Generated at 2022-06-22 04:32:54.125719
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_fn(a, b=None, c="default"):
        pass

    arg_replacer = ArgReplacer(test_fn, "b")

    # get_old_value
    # - passed positionally
    test_args = ("test",)
    test_kwargs = {}
    assert arg_replacer.get_old_value(test_args, test_kwargs) == "test"
    # - passed as keyword arg
    test_args = ()
    test_kwargs = {"b": "test"}
    assert arg_replacer.get_old_value(test_args, test_kwargs) == "test"
    # - arg not passed
    assert arg_replacer.get_old_value((), {}) == None
    # - arg not passed, with default
    assert arg_replacer.get_

# Generated at 2022-06-22 04:32:59.809934
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # test that timedelta_to_seconds() returns the same as
    # datetime.timedelta.total_seconds() for all timedeltas that can
    # be represented by a 32-bit signed integer number of seconds
    assert timedelta_to_seconds(datetime.timedelta(seconds=2**31-1)) == 2**31-1
    assert timedelta_to_seconds(datetime.timedelta(seconds=-2**31)) == -2**31
    assert timedelta_to_seconds(datetime.timedelta(seconds=2**31)) == 2**31



# Generated at 2022-06-22 04:33:12.057140
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        1/0
    except ZeroDivisionError:
        excinfo = sys.exc_info()
    to = TimeoutError("foo")
    assert to.args == ("foo",)
    assert to.__context__ is None
    to = TimeoutError("foo", excinfo)
    assert to.args == ("foo",)
    assert to.__context__ is excinfo[1]
    assert to.__cause__ is None


# Generated at 2022-06-22 04:33:23.470123
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()  # type: ignore
    obj.b = 2
    b = obj.b  # type: int



# Generated at 2022-06-22 04:33:31.895699
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import logging
    import unittest
    import tornado.ioloop

    class GzipDecompressorTest(unittest.TestCase):
        def test_flush(self):
            # create a dummy gzip file
            f = open("gzip_file.dat", "wb")
            try:
                f.write(b"\x1f\x8b\x08\x08\x16\x12\x8b\x5c\x00\x03test data\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00")
            finally:
                f.close()
            g = GzipDecompressor()
            f = open("gzip_file.dat", "rb")

# Generated at 2022-06-22 04:33:32.912713
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()
# Test the tracer imports since they're optional

# Generated at 2022-06-22 04:33:37.538644
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=600)) == 600
    assert timedelta_to_seconds(datetime.timedelta(minutes=60)) == 3600
    assert timedelta_to_seconds(datetime.timedelta(days=3)) == 259200
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1)) == -1



# Generated at 2022-06-22 04:33:50.318819
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

        def __init__(self):
            raise TypeError("do not instantiate directly")

        def method(self):
            return "Base"

    class SubBase(Base):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return SubBase

        def method(self):
            return "SubBase"

    class Impl1(Base):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Impl1

        def method(self):
            return "Impl1"

    class Impl2(Base):
        def configurable_base(self):
            return Base


# Generated at 2022-06-22 04:34:02.893923
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.httpclient import HTTPRequest
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import TCPServer
    from tornado.platform.auto import Waker
    from tornado.tcpserver import TCPServer, ssl_options_to_context
    import tornado.util
    import os
    import socket
    import unittest
    import ssl

    class ConfiguredClass(tornado.util.Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfiguredClass
        @classmethod
        def configurable_default(cls):
            return DefaultImpl
        def initialize(self):
            self.initialized = True
    class SubConfiguredClass(ConfiguredClass):
        pass

# Generated at 2022-06-22 04:34:04.005130
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    assert TimeoutError("hello")



# Generated at 2022-06-22 04:34:15.213868
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(0)) == 0.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=-1)) == -86401
    assert timedelta_to_seconds(datetime.timedelta(microseconds=-1)) == -1e-06
    assert timedelta_to_seconds(datetime.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=1)) == 90061
    assert timedelta_to_seconds(datetime.timedelta(
        days=-1, hours=-1, minutes=-1, seconds=-1, microseconds=-1)) == -90061



# Generated at 2022-06-22 04:34:26.176743
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfig(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyConfig

        @classmethod
        def configurable_default(cls):
            return MyConfig

        def initialize(self, some_param=None, **kwargs):
            self.some_param = some_param
            self.kwargs = kwargs

    a = MyConfig()

    MyConfig.configure(some_param="some_val")
    b = MyConfig()

    assert a.some_param is None
    assert not a.kwargs
    assert b.some_param == "some_val"
    assert b.kwargs == {}
    # Unit test for method save_configuration of class Configurable

# Generated at 2022-06-22 04:34:31.926456
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.attr = 'value'
    assert d['attr'] == 'value'
    assert d.attr == 'value'
    d2 = ObjectDict(attr='value')
    assert d2.attr == 'value'
    d3 = ObjectDict((('attr', 'value'),))
    assert d3.attr == 'value'



# Generated at 2022-06-22 04:34:47.705359
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict([('a', 'b'), ('c', 'd')])
    assert d.a == 'b'
    assert d.c == 'd'
    try:
        d.e
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-22 04:34:54.351722
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is just a type comment.

    gzipper = GzipDecompressor()
    gzipper.decompress(b'\x1f\x8b')
    assert gzipper.unconsumed_tail == b''



# Generated at 2022-06-22 04:35:06.114833
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a, b, c):
        return a, b, c
    arg = ArgReplacer(test, "a")
    assert arg.name == "a"
    assert arg.arg_pos is not None
    assert arg.arg_pos == 0
    assert arg.get_old_value((1, 2, 3), {}) == 1
    assert arg.get_old_value((1, 2, 3), {}, 2) == 1
    assert arg.get_old_value((1, 2, 3), {"c": 3}) == 1
    assert arg.get_old_value((1, 2, 3), {"c": 3}, default=4) == 1
    assert arg.get_old_value((1,), {"c": 3}, default=4) == 4

# Generated at 2022-06-22 04:35:15.551417
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is a test string for the decompressor
    testdata = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff"\
        b"math.random()\nmath.random()*100\n"
    c = GzipDecompressor()
    d = c.decompress(testdata)
    assert c.unconsumed_tail == b""
    d += c.flush()
    assert d == b"math.random()\nmath.random()*100\n"


_DEFAULT_CA_CERTS = "/etc/ssl/certs/ca-certificates.crt"

# Generated at 2022-06-22 04:35:26.922155
# Unit test for function import_object
def test_import_object():
    from tempfile import mkdtemp
    import os
    import shutil
    import sys
    from datetime import datetime

    def write_file(name, contents):
        directory = os.path.dirname(name)
        if not os.path.isdir(directory):
            os.makedirs(directory)
        # Write file with a timestamp so python doesn't decide it's up to date
        # and not reload it
        with open(name, "w") as f:
            f.write(contents % datetime.now())

    def read_file(name):
        with open(name, "r") as f:
            return f.read()

    def test_import_file():
        if not hasattr(import_object, "test_import_file"):
            raise Exception("cache not cleared")
        import_object

# Generated at 2022-06-22 04:35:36.917271
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    stream = zlib.compressobj(6, zlib.DEFLATED, 16 + zlib.MAX_WBITS)
    test_data = "0123456789" * 1000
    cdata = stream.compress(test_data)
    cdata += stream.flush()
    gz = GzipDecompressor()
    data = gz.decompress(cdata)
    assert data == test_data, "decompress returned %d bytes; data was %d" % (
        len(data), len(test_data)
    )
    data = gz.flush()
    assert data == "", "flush returned %d bytes" % (len(data))



# Generated at 2022-06-22 04:35:50.048817
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class Tester(object):
        def __init__(self, x, y):
            pass
    tester = ArgReplacer(Tester, "x")
    assert tester.arg_pos == 0
    assert tester.get_old_value((5, 6), {}) == 5
    assert tester.get_old_value((5, 6), {"x": 7}) == 7
    assert tester.get_old_value((5, 6), {"y": 7}) == None
    assert tester.replace(8, (9, 10), {}) == (9, (8, 10), {})
    assert tester.replace(11, (9, 10), {"x": 12}) == (12, (9, 10), {"x": 11})

# Generated at 2022-06-22 04:35:55.593911
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import inspect, unittest
    import tornado.concurrent
    TSM = inspect.getfullargspec(tornado.concurrent.TracebackFuture.initialize)
    CSM = inspect.getfullargspec(Configurable.initialize)
    clsmeths = set(CSM.args) - set(TSM.args)
    assert clsmeths == {'self'}, clsmeths



# Generated at 2022-06-22 04:36:02.572707
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=500000)) == 1.5
    assert (
        timedelta_to_seconds(datetime.timedelta(days=1, seconds=1, microseconds=500000)) == 86401.5
    )



# Generated at 2022-06-22 04:36:10.690118
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(re_unescape(r'\+-\*')) == r'+-*'
    assert re_unescape(r'abc\ def') == r'abc def'

# Generated at 2022-06-22 04:37:09.997425
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(x, y, z, a=4, b=5):
        assert False, "should not get here"

    r1 = ArgReplacer(f, "x")
    assert r1.arg_pos == 0
    assert r1.get_old_value((1, 2, 3), dict(z=6), 7) == 1
    assert r1.get_old_value((1,), dict(y=2, z=3, a=6), 7) == 1
    assert r1.get_old_value((), dict(x=1, y=2, z=3, a=6), 7) == 1

    assert r1.replace(9, (1, 2, 3), dict(z=6)) == (1, (9, 2, 3), dict(z=6))

# Generated at 2022-06-22 04:37:11.517397
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    if zlib is None:
        assert GzipDecompressor()



# Generated at 2022-06-22 04:37:23.756609
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado.util import GzipDecompressor
    decompressor = GzipDecompressor()

    decompressor.decompress('\x1f\x8b\x08\x08kljl\x02\xff\xcbH\xcd\xc9\xc9W\x08\xcf/\xcaI\x01\x00\xe1\x02\x18\x00\x00\x00')
    decompressor.flush()
    decompressor.decompress('\x1f\x8b\x08\x08kljl\x02\xff\xcbH\xcd\xc9\xc9W\x08\xcf/\xcaI\x01\x00\xe1\x02\x18\x00\x00\x00')
    decompressor.flush()
    decomp

# Generated at 2022-06-22 04:37:29.563148
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import unittest
    import http

    class DummyGzipDecompressor(GzipDecompressor):
        def __init__(self):
            super(DummyGzipDecompressor, self).__init__()
            self.chunks = []  # type: List[bytes]

        def decompress(self, value: bytes, max_length: int = 0) -> bytes:
            self.chunks.append(value)
            return super(DummyGzipDecompressor, self).decompress(value, max_length)

        def flush(self) -> bytes:
            return super(DummyGzipDecompressor, self).flush()

    # The tests are from RFC 1952 and from http_util_test.py.

# Generated at 2022-06-22 04:37:41.091832
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import sys
    # doctest performs a recursive import of the modules it tests,
    # which can cause infinite recursion if this function is called
    # while the package is in sys.modules.
    # Instead, we use the actual file (i.e. /path/to/tornado/util.py)
    # so that relative imports will work.
    # See https://github.com/python/mypy/issues/4168 for more details.
    __import__(__name__)
    module = sys.modules[__name__]
    globs = module.__dict__.copy()
    globs.update({"does_not_exist": "foo"})
    doctest.testmod(module, optionflags=doctest.ELLIPSIS, globs=globs)




# Generated at 2022-06-22 04:37:45.255707
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 1e-06
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=1)) == 1e-03
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60.0
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0

# Generated at 2022-06-22 04:37:54.506196
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise ValueError
    except ValueError as e:
        assert e.args == ()
        assert errno_from_exception(e) is None
    try:
        raise ValueError(1)
    except ValueError as e:
        assert e.args == (1,)
        assert errno_from_exception(e) == 1
    try:
        raise ValueError(1, 2)
    except ValueError as e:
        assert e.args == (1, 2)
        assert errno_from_exception(e) == 1



# Generated at 2022-06-22 04:37:58.733092
# Unit test for function import_object
def test_import_object():
    import unittest
    import tornado.escape
    from tornado.testing import AsyncTestCase, gen_test

    class ImportObjectTest(AsyncTestCase):
        @gen_test
        def test_import_object(self):
            self.assertEqual(import_object('sys'), sys)
            self.assertEqual(import_object('tornado.escape'),
                             tornado.escape)
            self.assertEqual(import_object('tornado.escape.utf8'),
                             tornado.escape.utf8)
            with self.assertRaises(ImportError):
                import_object('tornado.missing_module')

    unittest.main()



# Generated at 2022-06-22 04:38:04.794296
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise RuntimeError
    except:
        assert errno_from_exception(sys.exc_info()[1]) is None
    try:
        raise RuntimeError(42, "nope")
    except:
        assert errno_from_exception(sys.exc_info()[1]) == 42
    try:
        raise RuntimeError("nope")
    except:
        assert errno_from_exception(sys.exc_info()[1]) == "nope"



# Generated at 2022-06-22 04:38:16.657724
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape('a\\.b') == 'a.b'
    assert re_unescape('a\\x20b') == 'a b'
    assert re_unescape('a\\(b') == 'a(b'
    assert re_unescape('\\(a\\)b') == '(a)b'
    assert re_unescape('a[b]') == 'a[b]'
    assert re_unescape('a.]b') == 'a.]b'
    assert re_unescape('a]b') == 'a]b'
    assert re_unescape('a\\]b') == 'a]b'
    assert re_unescape('a[\\w]+b') == 'a[\\w]+b'
    assert re_unescape('a[\\\\w]+b') == 'a[\\\\w]+b'

# Generated at 2022-06-22 04:38:37.752333
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    c = Configurable()
    # Check that Configurable is abstract
    assert isinstance(c, Configurable) == False



# Generated at 2022-06-22 04:38:43.973083
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(self, a, b=6, c=9):
        return a
    replacer = ArgReplacer(f, 'b')
    assert(replacer.get_old_value((1, 2), {'c': 3}) == 2)


# Generated at 2022-06-22 04:38:52.474629
# Unit test for constructor of class Configurable

# Generated at 2022-06-22 04:39:03.885767
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ExampleClass(Configurable):
        @classmethod
        def configurable_base(cls) -> Type[Configurable]:
            return ExampleClass

        @classmethod
        def configurable_default(cls) -> Type[Configurable]:
            return ExampleClass
    # Create an instance of ExampleClass
    example1 = ExampleClass()
    # Check the class of instance created
    assert isinstance(example1, ExampleClass)
    assert not isinstance(example1, Configurable)
    # Change the implementation class of ExampleClass to ExampleClass
    ExampleClass.configure(None)
    # Create an instance of ExampleClass
    example2 = ExampleClass()
    # Check the class of instance created
    assert isinstance(example2, ExampleClass)
    assert not isinstance(example2, Configurable)
    # Change the implementation class of ExampleClass to Config

# Generated at 2022-06-22 04:39:07.057750
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    n = 10
    d = ObjectDict()
    for i in range(n):
        d.__setattr__(str(i), i)

# Generated at 2022-06-22 04:39:11.935558
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    def test_ObjectDict___getattr__():
        d = ObjectDict(asdf=12)
        assert d.asdf == 12
        print('TEST PASSED')
    test_ObjectDict___getattr__()



# Generated at 2022-06-22 04:39:23.757825
# Unit test for function import_object
def test_import_object():
    # self.assertEqual(import_object('os'), os)
    # self.assertEqual(import_object('os.path'), os.path)
    # self.assertRaises(ImportError, import_object, 'missing_module')
    # self.assertRaises(ImportError, import_object, 'os.missing_module')
    import sys
    import os
    assert import_object('sys') is sys
    assert import_object('sys.path') is sys.path
    # try: import_object('missing_module')
    # except Exception: pass
    # else: assert False, "missing_module should be missing"
    # try: import_object('sys.missing_module')
    # except Exception: pass
    # else: assert False, "sys.missing_module should be missing"

# Generated at 2022-06-22 04:39:25.389092
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=None, b=None)
    assert d.a is None
    assert d.b is None
    d.c = None
    assert d.c is None



# Generated at 2022-06-22 04:39:30.428372
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

    class B(A):
        def initialize(self, foo):
            self.foo = foo

    class C(A):
        def initialize(self, bar):
            self.bar = bar

    assert A.configured_class() is B
    assert B.configured_class() is B
    assert C.configured_class() is C
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    assert A().foo == B().foo == C().foo
    a = A(foo=123)
    b = B(foo=456)
    assert a.foo

# Generated at 2022-06-22 04:39:31.800357
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()