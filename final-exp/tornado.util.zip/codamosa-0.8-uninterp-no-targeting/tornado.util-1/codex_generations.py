

# Generated at 2022-06-22 04:30:13.374054
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(x, y, z, w=1, **kwargs):
        # type: (Any, Any, Any, int, Any) -> Any
        pass
    kwargs={"a":1,"b":2}
    print(getfullargspec(foo).args)
    arg_replacer = ArgReplacer(foo,"y")
    # return (old_value, args, kwargs)
    print(arg_replacer.replace(3,[1,2,3],kwargs))


# Generated at 2022-06-22 04:30:23.545185
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Base(Configurable):
        def configurable_base(self):
            return self.__class__

        def configurable_default(self):
            return self.__class__

        def _initialize(self):
            pass

    class A(Base):
        def initialize(self):
            pass

    class B(Base):
        def initialize(self, arg):
            pass

        @classmethod
        def configurable_base(cls):
            return Base

    # Make sure the classes' initialize() methods can be called
    # with the appropriate arguments.
    A()
    B(42)

    # Make sure we can configure them appropriately.
    Base.configure(None)
    Base.configure(A)
    Base.configure(B, arg=42)

    # And that the wrong arguments will raise a TypeError.

# Generated at 2022-06-22 04:30:26.914148
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def foo():
        raise ValueError()

    try:
        foo()
    except:
        raise_exc_info(sys.exc_info())


# Trimmed down version of six.reraise, for Python 2.4 compatibility.

# Generated at 2022-06-22 04:30:27.927728
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    assert doctest.testmod().failed == 0

# Generated at 2022-06-22 04:30:39.154421
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompress = GzipDecompressor().decompress
    assert b"foo" == decompress(b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff"
                              b"\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00")
    assert b"foo" == decompress(
        b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\xab"
        b"\xaeH\xc9\xc8,V\x00\x05\x00\x00\x00")



# Generated at 2022-06-22 04:30:47.381668
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c=3):
        pass
    arg_replacer = ArgReplacer(foo, 'a')
    assert arg_replacer.get_old_value((1, 2), {}) == 1
    assert arg_replacer.get_old_value((), {'a': 1, 'b': 2}) == 1
    assert arg_replacer.get_old_value((), {}) == None



# Generated at 2022-06-22 04:30:56.596540
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    from tornado.testing import AsyncTestCase, gen_test
    import unittest
    from unittest import mock

    @classmethod
    def setUpClass(cls) -> None:
        super().setUpClass()
        cls.obj = ObjectDict()

    def test_ObjectDict___setattr__(self) -> None:
        # []
        # code
        self.obj.name = "name"
        # assert
        self.assertEqual(self.obj.name, "name")

    @classmethod
    def tearDownClass(cls) -> None:
        super().tearDownClass()
        del cls.obj


# Generated at 2022-06-22 04:30:59.987278
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()


# A very slightly better repr than the default
_repr = repr



# Generated at 2022-06-22 04:31:04.592626
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def function_that_raises():
        # type: () -> None
        raise ZeroDivisionError()

    try:
        function_that_raises()
    except:
        raise_exc_info(sys.exc_info())


# fake exception used in all the raise_exc_info tests below

# Generated at 2022-06-22 04:31:16.943066
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gzipped_Js = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\xcb[\xcb\xccXX\xd2\x2c\xcd\xc9\xc9W(I-.\xcf/\xcaI\x01\x04\x00\x00'
    gz = GzipDecompressor()
    assert gz.decompress(gzipped_Js) == b'function test() {\n    console.log("test");\n}\n'
    assert gz.unconsumed_tail == b''
    assert gz.flush() == b''
    assert gz.decompressobj is None
    # There is a bug in python3.7 which give dismatch result.
    # assert gz

# Generated at 2022-06-22 04:31:35.481562
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gzip_decompressor = GzipDecompressor()

    assert not gzip_decompressor.unconsumed_tail


# Generated at 2022-06-22 04:31:37.300313
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    r = ObjectDict(a = 1, b = 2)
    assert r.a == 1
    assert r.b == 2


# Generated at 2022-06-22 04:31:39.320657
# Unit test for function exec_in
def test_exec_in():
    a = 1
    exec_in('assert a == 1', locals(), locals())



# Generated at 2022-06-22 04:31:43.425341
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Base(Configurable):
        class Impl1(Configurable):
            def initialize(self):
                self.init_args = (self.__class__, Base.configured_class())
        class Impl2(Configurable): pass

        @classmethod
        def configurable_base(cls): return Base
        @classmethod
        def configurable_default(cls): return Base.Impl1

    # Default class
    assert Base().init_args == (Base.Impl1, Base.Impl1)

    # Set the class globally
    Base.configure(Base.Impl2)
    assert Base().init_args == (Base.Impl2, Base.Impl2)

    # Reset to default
    Base.configure(None)

# Generated at 2022-06-22 04:31:46.479658
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    try:
        raise TimeoutError()
    except TimeoutError:
        pass



# Generated at 2022-06-22 04:31:48.485153
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gd = GzipDecompressor()
    gd.flush()
test_GzipDecompressor_flush()



# Generated at 2022-06-22 04:31:51.577590
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 04:31:57.413802
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b=None, c=None, d=None):
        return a, b, c, d

    r = ArgReplacer(foo, "d")
    print(r.get_old_value((1,), {}, 1))
    print(r.replace(4, (1,), {}))
    r = ArgReplacer(foo, "b")
    print(r.get_old_value((1,), {}))
    print(r.replace(2, (1,), {}))
    print(r.replace(2, (1,), {"b": 3}))
    r = ArgReplacer(foo, "a")
    print(r.get_old_value((1,), {}))
    print(r.replace(2, (1,), {}))

# Generated at 2022-06-22 04:32:07.319888
# Unit test for function exec_in
def test_exec_in():

    def check_exec_in(source, expected):
        # type: (str, Optional[Any]) -> None
        d = {}  # type: Dict[str, Any]
        exec_in(source, d)
        assert d["result"] == expected

    check_exec_in("result = 6 * 7", 42)
    check_exec_in("result = 'foo' + 'bar'", "foobar")
    check_exec_in("result = ['foo', 'bar', 'baz']", ["foo", "bar", "baz"])
    check_exec_in('result = {"foo": "bar"}', {"foo": "bar"})



# Generated at 2022-06-22 04:32:08.542756
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    assert ArgReplacer(test_ArgReplacer_get_old_value,"name").get_old_value((), {"name":1})==1


# Generated at 2022-06-22 04:32:25.947413
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d['key'] = 'value'
    # tests for AttributeError for a non-existing attribute
    try:
        d.non_existing_attr
        assert True
    except AttributeError:
        pass
    # tests for AttributeError for a non-existing attribute
    try:
        d.non_existing_attr = 'some value'
        assert True
    except AttributeError:
        pass
    # tests the default value of a non-existing attribute (return None)
    assert d.not_existing_attrbute is None
test_ObjectDict___getattr__()

# Generated at 2022-06-22 04:32:33.121678
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):

        def configurable_base(cls):
            return MyConfigurable

        def configurable_default(cls):
            return MyConfigurable
        #
    #
    class Implementation(MyConfigurable):
        pass
    #
    MyConfigurable.configure(Implementation)
    instance = MyConfigurable()
    assert isinstance(instance, Implementation)
    assert not isinstance(instance, MyConfigurable)

# Generated at 2022-06-22 04:32:41.632006
# Unit test for constructor of class Configurable
def test_Configurable():
    class CConfig(Configurable):
        __impl_class = None  # type: Optional[Type[CConfig]]

        @classmethod
        def configurable_base(cls):
            return CConfig

        @classmethod
        def configurable_default(cls):
            return CConfigImplementation

    class CConfigImplementation(CConfig):
        def initialize(self):
            pass

    CConfig.configure(None)
    assert isinstance(CConfig(), CConfig)
    assert isinstance(CConfig(), CConfigImplementation)



# Generated at 2022-06-22 04:32:46.294376
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError as e:
        assert str(e)  # check that the exception has a string representation


# Alias for backwards compatibility.
gen_TimeoutError = TimeoutError



# Generated at 2022-06-22 04:32:47.302342
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    GzipDecompressor().flush()



# Generated at 2022-06-22 04:32:53.503376
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b=None, *c):
        pass
    ar = ArgReplacer(func, 'b')
    old_value, args, kwargs = ar.replace(1, (2,), dict(b=3))
    old_value, args, kwargs = ar.replace(1, (2,), dict())
    old_value, args, kwargs = ar.replace(1, (2,3,4), dict())



# Generated at 2022-06-22 04:32:56.564118
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=50, c=10):
        pass
    argrep = ArgReplacer(func, 'b')
    assert argrep.get_old_value((1,), {}, None) == 50
    assert argrep.get_old_value((1,), {'b':100}, None) == 100



# Generated at 2022-06-22 04:33:09.035799
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c): pass
    replacer = ArgReplacer(foo, "b")
    old_value, args, kwargs = replacer.replace("b2", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "b2", 3)
    assert kwargs == {}
    old_value, args, kwargs = replacer.replace("b3", (1,), {"c": 3})
    assert old_value is None
    assert args == (1,)
    assert kwargs == {"b": "b3", "c": 3}
    # named arguments not altered
    old_value, args, kwargs = replacer.replace("b3", (1, 2, 3), {"c": 3})
    assert args == (1, 2, 3)

# Generated at 2022-06-22 04:33:18.577055
# Unit test for function import_object
def test_import_object():
    from tornado import escape, web
    assert import_object("tornado.web") is web
    assert import_object("tornado.web.RequestHandler") is web.RequestHandler
    assert import_object("tornado.escape") is escape
    assert import_object("tornado.escape") is escape
    assert import_object("tornado.escape.utf8") is escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected import error"
    try:
        import_object("missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected import error"



# Generated at 2022-06-22 04:33:28.581698
# Unit test for function re_unescape
def test_re_unescape():
    # Some corner cases which don't match the above pattern
    assert re_unescape("") == ""
    assert re_unescape("\\0") == r"\0"
    assert re_unescape("\\d") == r"\d"
    assert re_unescape("\\1") == r"\1"
    # As long as the pattern matches and replacement succeeds, we're good
    assert re_unescape("a\\z") == "a"
    assert re_unescape("a\\A") == "aA"
    assert re_unescape("a\\1") == "a"
    assert re_unescape("a\\49") == "a1"
    assert re_unescape("a\\x41") == "aA"
    assert re_unescape("a\\u1234") == "a"
    assert re_unescape

# Generated at 2022-06-22 04:33:47.168592
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(42, "foo")
    except IOError as e:
        assert errno_from_exception(e) == 42
    try:
        raise IOError("foo")
    except IOError as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-22 04:33:51.627297
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(Exception()) == None
    try:
        raise Exception(0)
    except Exception as err:
        assert errno_from_exception(err) == 0

    try:
        raise Exception((0,))
    except Exception as err:
        assert errno_from_exception(err) == 0



# Generated at 2022-06-22 04:33:54.384749
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzipDecompressor = GzipDecompressor()
    ret_val = gzipDecompressor.decompress( "zlib decompress" )
    print (ret_val)
    


# Generated at 2022-06-22 04:34:07.092466
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    @ArgReplacer
    def func_test(test):
        return test
    assert func_test.get_old_value((1,), {}) == 1
    assert func_test.get_old_value((1,), {'test': 2}) == 1
    assert func_test.get_old_value((1,), {'test': 2}, 3) == 1
    # argument by keyword
    assert func_test.get_old_value((), {'test': 2}) == 2
    assert func_test.get_old_value((), {'test': 2}, 1) == 2
    # not pass any test argument
    assert func_test.get_old_value((), {}) == None
    assert func_test.get_old_value((), {}, 1) == 1

# Generated at 2022-06-22 04:34:09.639740
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    o = ObjectDict()  # type: ObjectDict
    o.a = 1
    assert o["a"] == 1
    assert o.a == 1



# Generated at 2022-06-22 04:34:14.109200
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    replacer = ArgReplacer(func, "name")
    old_value = replacer.get_old_value(("foo", "bar"), {}, default="baz")
    assert old_value == "bar"

# Generated at 2022-06-22 04:34:17.873751
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    ob = GzipDecompressor()
    ob.decompress(b'bytes')
    ob.decompress(b'bytes', 0)
    ob.decompress(b'bytes', 1)


# Generated at 2022-06-22 04:34:29.571296
# Unit test for constructor of class Configurable
def test_Configurable():
    class _C(Configurable):
        @classmethod
        def configurable_base(cls):
            return _C

        @classmethod
        def configurable_default(cls):
            return _D1

        def initialize(self):
            self.foo = 42

    class _D1(Configurable):
        @classmethod
        def configurable_base(cls):
            return _C

        def initialize(self):
            self.bar = 1

    class _D2(Configurable):
        @classmethod
        def configurable_base(cls):
            return _C

        def initialize(self):
            self.bar = 2

    c = _C()
    assert isinstance(c, _C)
    assert not isinstance(c, _D1)
    assert c.foo == 42

# Generated at 2022-06-22 04:34:35.225449
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(x, y, z):
        pass
    ar = ArgReplacer(foo, "y")
    assert ar.get_old_value((1, 2, 3), {}) == 2
    # There may be a better way to do this test
    #assert ar.get_old_value((1,), {"y": 2, "z": 3}) == 2



# Generated at 2022-06-22 04:34:39.033548
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()  # type: ignore

# Alias for backward compatibility
# https://www.python.org/dev/peps/pep-0565/
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-22 04:34:57.897758
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=500000)) == 1.5
    # timedelta_to_seconds should be a drop-in replacement for
    # timedelta.total_seconds except in one case:
    # timedelta(0).total_seconds() == 0.0 (which seems special-cased)
    # whereas timedelta_to_seconds(datetime.timedelta(0)) == None
    # (which is consistent with the behavior of the other components).
    assert timedelta_to_seconds(datetime.timedelta(0)) is None
    assert timed

# Generated at 2022-06-22 04:34:59.341423
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.b = 1
    assert a['b'] == 1



# Generated at 2022-06-22 04:35:03.813827
# Unit test for function import_object
def test_import_object():
    _ = import_object
    assert _('sys') is sys
    assert _('os.path') is os.path
    assert _('os.missing_module')



# Generated at 2022-06-22 04:35:12.975027
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    D = ObjectDict(["one", "two"], [1, 2])
    assert D["one"] == 1
    assert D.two == 2
    assert D["two"] == 2
    assert hasattr(D, "one")
    assert not hasattr(D, "three")
    with pytest.raises(AttributeError):
        D.three
    D.four = 4
    assert D["four"] == 4
    assert D.four == 4
    with pytest.raises(AttributeError):
        del D.one
    del D["two"]
    with pytest.raises(AttributeError):
        D.two
    with pytest.raises(AttributeError):
        D["two"]



# Generated at 2022-06-22 04:35:20.342583
# Unit test for function re_unescape
def test_re_unescape():
    TO_ESCAPE = "\\.^$*+?{}[]()|:-"
    assert re_unescape(re.escape(TO_ESCAPE)) == TO_ESCAPE
    assert re_unescape('[a-z]') == '[a-z]'
    assert re_unescape(r'\d') == r'\d'



# Generated at 2022-06-22 04:35:25.531975
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.x = 'x'
    assert d.x == 'x'  # type: ignore
    assert d['x'] == 'x'
    assert 'x' in d
    assert getattr(d, 'x') == 'x'
    assert d.get('x') == 'x'
    with pytest.raises(AttributeError):
        d.y
    with pytest.raises(AttributeError):
        getattr(d, 'y')  # type: ignore



# Generated at 2022-06-22 04:35:36.916914
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.x = 1
    assert d['x'] == 1
    assert d.x == 1
    assert hasattr(d, 'x')
    d.y = 2
    assert d['y'] == 2
    assert d.y == 2
    assert hasattr(d, 'y')
    d['z'] = 3
    assert d['z'] == 3
    assert d.z == 3
    assert hasattr(d, 'z')
    del d.z
    assert not hasattr(d, 'z')


# Dummy class used when no type information is available.
# By analogy to typing.Any, typing.NoReturn can also be used.
#typing.NoReturn = object
NoReturn = object


# _NO_SUCH_ATTRIBUTE may be returned as the result of a __

# Generated at 2022-06-22 04:35:41.228764
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Test(Configurable):
        def configurable_base(self):
            return Test

        def configurable_default(self):
            return Test
    test = Test()
    assert isinstance(test, Test)
    assert test.__dict__['initialize'] == Test._initialize


# Generated at 2022-06-22 04:35:54.157132
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    if __name__ == "__main__":

        def add_number(number: int, number2: int) -> int:
            return number + number2

        def minus_number(number: int, number2: int) -> int:
            return number - number2

        def main():
            number = 1
            number2 = 2
            old_value, args, kwargs = ArgReplacer(add_number, "number").replace(
                2, (number, number2), {}
            )
            assert add_number(*args, **kwargs) == 4
            assert old_value == number
            old_value, args, kwargs = ArgReplacer(minus_number, "number").replace(
                2, (number, number2), {}
            )
            assert minus_number(*args, **kwargs) == 0
            assert old

# Generated at 2022-06-22 04:35:58.141541
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    o = ObjectDict(a=1, b=2)
    assert o.a == 1
    assert o.b == 2
    assert o.x is None
    o.x = 3
    assert o.x == 3



# Generated at 2022-06-22 04:36:17.387076
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    compress = zlib.compressobj(9, zlib.DEFLATED, 16 + zlib.MAX_WBITS,
                                zlib.DEF_MEM_LEVEL, 0)
    compressed = compress.compress(b"this is a test")
    compressed += compress.flush()
    assert len(compressed) > 20
    gzipper = GzipDecompressor()
    decompressed = gzipper.decompress(compressed)
    assert decompressed == b"this is a test"
    assert not gzipper.unconsumed_tail
    assert not gzipper.flush()


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__"
# cause problems with other tools.  u() can be applied to ascii

# Generated at 2022-06-22 04:36:30.737576
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # This is an auto-generated Django model fixture.
    # You'll have to do the following manually to clean this up:
    #   * Rearrange models' order
    #   * Make sure each model has one field with primary_key=True
    #   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior.
    #   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
    # Feel free to rename the models, but don't rename db_table values or field names.
    from django.db import models

    class Firstconfigurable(Configurable):

        class Meta:
            app_label = 'myapp'
            managed = False
            db_table = 'firstconfigurables'

        def configurable_base(self):
            return Firstconfigurable

# Generated at 2022-06-22 04:36:42.235150
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConfigurableTestImpl(Configurable):
        class impl1:
            pass

        class impl2:
            pass

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls.impl1

    assert ConfigurableTestImpl._Configurable__impl_class is None
    assert ConfigurableTestImpl._Configurable__impl_kwargs is None

    instance = ConfigurableTestImpl()  # type: ignore
    assert isinstance(instance, ConfigurableTestImpl.impl1)

    ConfigurableTestImpl.configure(ConfigurableTestImpl.impl2)
    instance = ConfigurableTestImpl()  # type: ignore
    assert isinstance(instance, ConfigurableTestImpl.impl2)



# Generated at 2022-06-22 04:36:43.927771
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.a = 'foo'
    d['a']
    d.a



# Generated at 2022-06-22 04:36:47.107969
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    obj = ObjectDict()
    obj.a = 20
    assert obj.a == 20
    assert obj["a"] == 20



# Generated at 2022-06-22 04:36:54.969521
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Most of the testing is done in the httpclient tests.
    gzip_decompressor = GzipDecompressor()
    gzip_decompressor.decompress(b'\x1f\x8b...')
    assert gzip_decompressor.unconsumed_tail is None
    assert gzip_decompressor.flush() == b''
    assert gzip_decompressor.unconsumed_tail is None



# Generated at 2022-06-22 04:37:01.070862
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def raise_error(message):
        try:
            raise Exception(message)
        except Exception as e:
            raise_exc_info((type(e), e, None))

    class MyException(Exception):
        pass

    try:
        raise_error("test message")
    except Exception:
        pass

    try:
        raise MyException("test message")  # type: ignore
    except MyException:
        pass

    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass


# Generated at 2022-06-22 04:37:10.935268
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    data = b"\x1f\x8b\x08\x08\xa9\x90\x69\x5a\x00\x03foo\x02\x00\x8b\xbcR\xc8\xcf\x07\x00\xb5UH\x10\x86\xef\x02\x00\x00\x00"
    gzip_decompressor = GzipDecompressor()
    try:
        decompressed_data = gzip_decompressor.decompress(data)
        print(decompressed_data)
    except zlib.error as e:
        print('Error: ' + e.message)
    else:
        print('Successfully decoded')

# Generated at 2022-06-22 04:37:21.148504
# Unit test for function exec_in
def test_exec_in():
    def test_exec_in_nested():
        x = 5
        globals = locals = {}
        exec_in('assert x == 5', globals)

    x = 5
    globals = locals = {}
    exec_in("assert x == 5", globals, locals)
    test_exec_in_nested()
    try:
        exec_in("assert x == 6", globals, locals)
        assert False
    except AssertionError:
        pass
    try:
        exec_in("assert y == 6", globals, locals)
        assert False
    except NameError:
        pass



# Generated at 2022-06-22 04:37:23.265584
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-22 04:37:43.430660
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # See twinterp/tests/unit/util_tests.py
    pass

# Generated at 2022-06-22 04:37:54.670647
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a: int, b: str = 'b', *args: Any, **kwargs: Any) -> None:
        print(a, b, args, kwargs)

    arg_replacer = ArgReplacer(func, 'b')
    assert 'b' == arg_replacer.get_old_value((1,), {}, None)  # Sufficient number of positional args
    assert 'b' == arg_replacer.get_old_value((1,), {})  # Default value for keyword argument
    assert 'b' == arg_replacer.get_old_value((1, 'b'), {})  # Keyword arg passed by position
    assert 'b' == arg_replacer.get_old_value((1,), {'b': 'b'})  # Keyword arg passed by name

# Generated at 2022-06-22 04:37:57.682659
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(0)) == 0.0
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0



# Generated at 2022-06-22 04:38:08.829275
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    foo = ObjectDict()
    foo.x = 'abc'
    assert foo.x == 'abc'
    foo.y = 'def'
    assert foo['y'] == 'def'
    assert foo.get('z', None) is None
    assert list(foo) == ['x', 'y']
    del foo.y
    assert list(foo) == ['x']
    foo.z = 'ghi'
    assert sorted(foo.values()) == ['abc', 'ghi']
    foo.update({'w': 1, 'x': 2})
    assert foo.w == 1
    assert foo.x == 2
    assert foo.get('w') == 1
    assert foo.get('missing') is None
    assert len(foo) == 3

# Generated at 2022-06-22 04:38:16.577474
# Unit test for constructor of class Configurable
def test_Configurable():
    # After configuration, instances of `Configurable` can be
    # constructed normally.
    Configurable.configure(None)
    Configurable()
    # After restoring the default configuration, we can't construct
    # instances.
    Configurable.restore_configuration()
    try:
        Configurable()
        assert False, "constructing base class should fail"
    except NotImplementedError:
        pass


# <https://docs.python.org/2/library/functions.html#property>

# Generated at 2022-06-22 04:38:18.018066
# Unit test for function exec_in
def test_exec_in():
    globals = dict(x=1)
    exec_in("assert x == 1", globals)



# Generated at 2022-06-22 04:38:30.168192
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Bar

    class Bar(Foo):
        initialized = False

        def initialize(self):
            self.initialized = True

    assert issubclass(Foo.configured_class(), Foo)
    assert Foo.configured_class() is Bar
    foo = Foo()
    assert isinstance(foo, Foo)
    assert isinstance(foo, Bar)
    assert foo.initialized

    # Test configure
    try:
        Foo.configure("tests.core.Foo")
        assert False  # configure should raise ValueError
    except ValueError:
        pass
    Foo.configure("tests.core.Bar")
    assert Foo.configured_

# Generated at 2022-06-22 04:38:32.640192
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise_exc_info((None, ValueError(), None))
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-22 04:38:40.447941
# Unit test for function exec_in
def test_exec_in():
    a = 1
    loc = {}
    exec_in('assert a == 1', {'a': a}, loc)
    exec_in('assert a == 2', {'a': 2}, loc)
    exec_in('assert a == 3', {'a': 3}, loc)
    exec_in('assert a == 1', {'a': 1}, loc)

    loc = {'a': 1}
    exec_in('assert a == 1', {'a': 3}, loc)
    exec_in('assert a == 2', {'a': 2}, loc)
    exec_in('assert a == 3', {'a': 3}, loc)
    exec_in('assert a == 1', {'a': 1}, loc)

    exec_in('assert a == 4', {'a': 4}, None)

# Generated at 2022-06-22 04:38:42.569596
# Unit test for function exec_in