

# Generated at 2022-06-22 04:30:23.051729
# Unit test for function import_object
def test_import_object():
    import inspect
    import os
    # one level
    import_object('unittest')
    import_object('os.path')
    # two levels
    if os.name == 'posix':
        import_object('os.path.expanduser')
    # three levels
    import_object('unittest.util.strclass')
    import_object('unittest.util.safe_repr')
    # built-in modules have a non-None value True for attribute __file__
    assert inspect.getmodule(import_object('unittest')).__file__
    assert inspect.getmodule(import_object('os.path')).__file__
    if os.name == 'posix' :
        assert inspect.getmodule(import_object('os.path.expanduser')).__file__

# Generated at 2022-06-22 04:30:28.974056
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return BaseImpl

    class BaseImpl(Base):
        pass

    class Sub(Base):
        pass

    class SubImpl(Sub):
        pass

    assert Base.configured_class() is BaseImpl
    assert Base().__class__ is BaseImpl
    assert Sub.configured_class() is BaseImpl
    assert Sub().__class__ is BaseImpl
    Sub.configure(SubImpl)
    assert Sub.configured_class() is SubImpl
    assert Sub().__class__ is SubImpl

# Generated at 2022-06-22 04:30:36.547462
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(Exception(0)) == 0
    assert errno_from_exception(Exception((0,))) == 0
    assert errno_from_exception(Exception((0, "message"))) == 0
    assert errno_from_exception(Exception()) is None
    try:
        raise Exception(0, "message")
    except Exception as e:
        assert errno_from_exception(e) == 0



# Generated at 2022-06-22 04:30:49.521297
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return None

        def __init__(self, a, b, c=10, *args, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.args = args
            self.kwargs = kwargs
            self.d = self.kwargs.pop('d', 15)
            self.called = True
            super(A, self).__init__()

    class B(A):
        pass

    class C(A):
        @classmethod
        def configurable_default(cls):
            return A

    A.configure(None)
    assert A().called
   

# Generated at 2022-06-22 04:30:58.429693
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class ErrorWithoutErrno(OSError):
        pass
    err = ErrorWithoutErrno()
    assert errno_from_exception(err) is err.errno
    errno = errno_from_exception(OSError(5, "hello"))
    assert errno == 5
    errno = errno_from_exception(OSError())
    assert errno is None
    errno = errno_from_exception(OSError([5]))
    assert errno == 5
    errno = errno_from_exception(OSError(Exception("inner", 5)))
    assert errno == 5
    errno = errno_from_exception(OSError(Exception(5, "inner")))
    assert errno == 5

# Generated at 2022-06-22 04:31:10.204429
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # The function to be tested
    def function_to_test(arg1, arg2, arg3):
        pass
    # Initialise arg replacer
    arg_replacer = ArgReplacer(function_to_test, 'arg2')
    # Initialise arg1,arg2,arg3
    arg1 = 1
    arg2 = 2
    arg3 = 3
    # Call get_old_value with *args and **kwargs
    arg2_value = arg_replacer.get_old_value((arg1,arg2,arg3), {})
    print("arg2_value: ", arg2_value)
    print("Does the old value of argument arg2 is equal to the value assigned to arg2 in the test ? ", arg2 == arg2_value)

# Generated at 2022-06-22 04:31:13.888348
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return A

    assert isinstance(A(), A)


_global_config = collections.defaultdict(dict)  # type: Dict[type, Dict[str, Any]]
_config_stacks = collections.defaultdict(list)  # type: Dict[type, List[Tuple[Type[Configurable], Dict[str, Any]]]]



# Generated at 2022-06-22 04:31:19.105506
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        # TestConfigurable.configurable_base = lambda one: one
        # TestConfigurable.configurable_default = lambda one: one
        # TestConfigurable._initialize = lambda self, **kwargs: None

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self, **kwargs) -> None:
            raise NotImplementedError()

        def __init__(self):
            raise NotImplementedError()

    test_configurable1 = TestConfigurable()
    assert isinstance(test_configurable1, TestConfigurable) # pass
    test_configurable2 = TestConfigurable()

# Generated at 2022-06-22 04:31:19.724554
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    ...



# Generated at 2022-06-22 04:31:29.833663
# Unit test for function re_unescape
def test_re_unescape():
    test_cases = (
        ("\\.", "."),
        ("\\(", "("),
        ("a\\|b", "a|b"),
        ("a\\*b", "a*b"),
        ("a\\+b", "a+b"),
        (r"\\", "\\"),
        (r"\\a", "\\a"),
        (r"\\b", "\\b"),
        (r"\a", "\a"),
        (r"\b", "\b"),
        (r"\d", "\\d"),
        (r"\D", "\\D"),
        (r"\\.", r"\."),
    )
    for test_case in test_cases:
        assert re_unescape(test_case[0]) == test_case[1]



# Generated at 2022-06-22 04:31:47.302950
# Unit test for function errno_from_exception
def test_errno_from_exception():
    with pytest.raises(ValueError):
        errno_from_exception(ValueError())
    with pytest.raises(TypeError) as ex:
        errno_from_exception(OSError())
    assert errno_from_exception(OSError(2, "test_me")) == 2



# Generated at 2022-06-22 04:31:58.988238
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from functools import partial
    from collections import namedtuple
    from requests import Request, Session

    Configurable = namedtuple('Configurable', 'configurable_base,configurable_default')
    configurable_base = partial(Configurable, Configurable)
    configurable_default = partial(Configurable, Configurable)

    class Session(Configurable):
        configurable_base = configurable_base
        configurable_default = configurable_default

    class Request(Configurable):
        configurable_base = configurable_base
        configurable_default = configurable_default

    s = Session()
    assert isinstance(s, Session)

    Session.configure(Request)
    r = Session()
    assert isinstance(r, Request)


# Generated at 2022-06-22 04:32:08.286602
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError as e:
        assert str(e) == "Timeout"
    else:
        assert False


# Workaround for http://bugs.python.org/issue6643
try:
    # Only present in Python 2.6
    import multiprocessing
except ImportError:
    pass
else:
    if hasattr(multiprocessing, "reduction"):
        multiprocessing.reduction.DummyResourceWithFinalizer()



# Generated at 2022-06-22 04:32:10.454686
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    raise unittest.SkipTest()



# Generated at 2022-06-22 04:32:12.004347
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict()
    x.foo = "bar"
    x.foo == "bar"



# Generated at 2022-06-22 04:32:17.010315
# Unit test for function doctests
def test_doctests():
    # type: () -> unittest.TestSuite
    import sys

    import tornado.util

    return doctest.DocTestSuite(tornado.util)


if __name__ == "__main__":
    unittest.main()



# Generated at 2022-06-22 04:32:27.078015
# Unit test for constructor of class Configurable
def test_Configurable():
    class Derived(Configurable):
        @classmethod
        def configurable_base(cls):
            return Derived

        @classmethod
        def configurable_default(cls):
            return Derived

        def initialize(self, **kwargs):
            pass

    class Subclass(Derived):
        @classmethod
        def configurable_base(cls):
            return Derived

        def initialize(self, **kwargs):
            super().initialize(**kwargs)

    impl_kwargs = {"foo": "bar", "baz": "bat"}
    Derived.configure(impl=Subclass, **impl_kwargs)
    config_instance = Derived()
    # Derived should have unused kwargs stripped before passing to Subclass.
    assert config_instance.__class__ is Subclass
    assert config

# Generated at 2022-06-22 04:32:38.194580
# Unit test for constructor of class Configurable
def test_Configurable():
    class Loop(Configurable):
        def configurable_base(Loop):
            return Loop
        def configurable_default(Loop):
            return Loop
        def initialize(Loop, impl, *args, **kwargs):
            pass
    _loop_class = Loop._save_configuration()

# Generated at 2022-06-22 04:32:51.166161
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def testFunc(var1, var2):
        return 1

    # var2 to be replaced
    e = ArgReplacer(testFunc, "var2")
    assert e.get_old_value((1, 2), {}) == 2

    # var1 to be replaced
    e = ArgReplacer(testFunc, "var1")
    assert e.get_old_value((1, 2), {}) == 1

    # attr2 to be replaced
    e = ArgReplacer(testFunc, "attr2")
    assert e.get_old_value((1, 2), {}) is None

    # attr1 to be replaced
    e = ArgReplacer(testFunc, "attr1")
    assert e.get_old_value((1, 2), {}) is None



# Generated at 2022-06-22 04:33:00.031624
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    decomp = GzipDecompressor()
    input1 = b"x\x9cK\xcb\xcf\x07\x00\x02\xab\x1c\xac_H\x14\x85\xf0H\xa6\xb4\x0cH\x10\xd4I\x0c\xca\xcf/\x08\xcd\x9c\xc9X\n\x85\xf0H\xa6\xb4x\x10\xb0K\r"
    input2 = b"\x0e\x80\x00\xba=\x7f"
    result1 = decomp.decompress(input1)
    result2 = decomp.decompress(input2)
    result3 = decomp.flush()

# Generated at 2022-06-22 04:33:16.476062
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import pytest
    import py
    import tornado
    if py.path.local(".").join("tornado-e72410b").check():
        pytest.skip("TODO: Add unit test for Configurable.__new__ of tornado-e72410b.")
    else:
        raise NotImplementedError(
            "TODO: Add unit test for Configurable.__new__ of tornado-"
            + tornado.version + "."
        )

# Generated at 2022-06-22 04:33:17.692203
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    suite = doctests()
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)



# Generated at 2022-06-22 04:33:20.885627
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.a = 1
    assert obj["a"] == 1

# Generated at 2022-06-22 04:33:27.412678
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    """ Tests the method initialize of class Configurable.
    """
    # Test initilize method
    args = "Sparrow"
    kwargs = {"age": 2}
    bird = Animal(args, **kwargs)
    assert bird.name == args
    assert bird.age == kwargs["age"]
    assert bird.legs == 4


# Generated at 2022-06-22 04:33:37.134580
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        def initialize(self, value):
            self.value = value

        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Impl1

    class Impl1(Base):
        pass

    class Impl2(Base):
        pass

    class Impl2B(Impl2):
        pass

    assert Base().value == 0
    assert Impl1().value == 0
    assert Impl2().value == 0
    assert Impl2B().value == 0
    assert isinstance(Impl1(), Base)
    assert isinstance(Impl2(), Base)
    assert isinstance(Impl2B(), Base)
    Base.configure(None)
    assert Base().value == 0
    Base.configure(Impl2)

# Generated at 2022-06-22 04:33:37.953288
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    print(True)


# Generated at 2022-06-22 04:33:42.549095
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    import sys
    import traceback
    try:
        raise TimeoutError()
    except TimeoutError:
        traceback.print_exc()  # pragma: no cover



# Generated at 2022-06-22 04:33:45.712898
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    dict1 = ObjectDict()
    dict1.a = 3
    assert dict1.a == 3



# Generated at 2022-06-22 04:33:50.705696
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"x") == "x"
    assert re_unescape(r"\x") == "x"
    assert re_unescape(r"\n") == "\n"
    assert re_unescape(r"\^") == "^"
    with pytest.raises(ValueError):
        re_unescape(r"\d")



# Generated at 2022-06-22 04:33:52.782176
# Unit test for function import_object
def test_import_object():
    try:
        import_object("tornado.test.util")
    except ImportError:
        pass

# fake byte literal for python 2.5

# Generated at 2022-06-22 04:34:13.563626
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass

if typing.TYPE_CHECKING:
    # These names are exported in the tornado module package.
    from . import gen
    from . import ioloop
gen.TimeoutError = TimeoutError
ioloop.TimeoutError = TimeoutError

# alias for backwards compatibility with 4.4
Timeout = TimeoutError

# Various tools for manipulating byte strings.  We don't just use the
# str type because the chr, ord, and unichr built-ins do not accept
# Unicode arguments.  We don't use the array type because it doesn't
# support append or extend.
if bytes is str:
    # Python 2
    def _null_byte_string() -> bytes:
        return "\0"

# Generated at 2022-06-22 04:34:20.737585
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) == None
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1
    # The following works because Exception is a subclass of IOError
    try:
        raise IOError(1, 'foo')
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-22 04:34:23.860079
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class TestConfigurable(Configurable):
        x = 0

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        def initialize(self):
            # type: () -> None
            self.x = 1

    t = TestConfigurable()
    assert t.x == 1



# Generated at 2022-06-22 04:34:35.691255
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1.5)) == 0.0000015
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1, microseconds=1)) == 86401.000001
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=0, microseconds=1)) == 86400.000001

# In Python 3.2+, datetime.timedelta has a total

# Generated at 2022-06-22 04:34:46.807104
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def _(a: int, b: str, c: float, d: str = "d") -> None:  # type: ignore
        pass
    assert ArgReplacer(_, name=None).get_old_value([1, 2, 3], {'b': 2, 'c': 3}, None) is None
    assert ArgReplacer(_, name="d").get_old_value([1, 2, 3], {'b': 2, 'c': 3}, None) is None
    assert ArgReplacer(_, name="c").get_old_value([1, 2, 3], {'b': 2, 'c': 3}, None) == 3
    assert ArgReplacer(_, name="b").get_old_value([1, 2, 3], {'b': 2, 'c': 3}, None) == 2

# Generated at 2022-06-22 04:34:59.970109
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo
        def configurable_default(self):
            return Foo
        def initialize(self, a, b):
            self.a = a
            self.b = b
    class Bar(Foo):
        def initialize(self, a, b, c):
            # super(Bar, self).initialize(a, b)
            self.a = a
            self.b = b
            self.c = c

    assert issubclass(Bar, Foo)
    assert not issubclass(Foo, Bar)

    f = Foo(1, 2)
    assert isinstance(f, Foo)
    assert f.a == 1
    assert f.b == 2

    b = Bar(1, 2, 3)

# Generated at 2022-06-22 04:35:12.277755
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, keyword=1):
        ''' A test function used in testing class ArgReplacer
        '''
        return a + b

    assert ArgReplacer.replace('X', args=(1, 2), kwargs={'keyword' : 1}) == (1, ('X', 2), {'keyword' : 1})
    assert ArgReplacer.replace('X', args=(1, 2), kwargs={}) == (None, ('X', 2), {'keyword' : 1})
    assert ArgReplacer.replace('X', args=(1,), kwargs={'keyword' : 2}) == (2, ('X',), {'keyword' : 2})

# Generated at 2022-06-22 04:35:18.738478
# Unit test for function exec_in
def test_exec_in():  # type: ignore
    fn = "tornado.test.util_test.test_exec_in"
    try:
        exec_in("a = 6", {})
        assert False, "empty locals should not allow assignments"
    except TypeError:
        pass
    a = 5
    exec_in("a = 6", globals())
    assert a == 6
    exec("a = 7", globals())
    assert a == 7
    exec_in("a = 8", globals())
    assert a == 8
    exec("a = 9", globals(), locals())
    assert a == 9
    exec_in("a = 10", globals(), locals())
    assert a == 10
    exec_in('assert a == 10, a', globals(), locals())

# Generated at 2022-06-22 04:35:23.263734
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(attr1=1, attr2=2)
    assert d["attr1"] == d.attr1 == 1
    assert d.attr2 == 2
    d.attr3 = 3
    assert d.attr3 == d["attr3"] == 3
    d["attr3"] = 4
    assert d.attr3 == d["attr3"] == 4



# Generated at 2022-06-22 04:35:25.544618
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gzip_decompressor = GzipDecompressor()
    assert gzip_decompressor is not None



# Generated at 2022-06-22 04:35:41.704996
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    TimeoutError()


TimeoutError.__module__ = "tornado.util"

# Backwards compatibility for code that may have imported it from
# gen_py.
gen = sys.modules["tornado.gen"]
gen.TimeoutError = TimeoutError

# Alias for backwards compatibility (it changed to TimeoutError in 4.0)
Timeout = TimeoutError

# Other aliases for backwards compatibility
ConcurrentTestCase = unittest.concurrentTestCase
SkipTest = unittest.SkipTest
_Null = unittest.TestCase._Null



# Generated at 2022-06-22 04:35:51.231953
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def test_GzipDecompressor_flush():
        # Test flush
        dec = GzipDecompressor()
        data = dec.decompress(gzip_example_1)
        assert(len(data) > 0)
        assert(dec.unconsumed_tail)
        data += dec.flush()
        assert(not dec.unconsumed_tail)
        assert(dec.decompress(b"") == b"")
        assert(data == gzip_example_1_uncompressed)



# Generated at 2022-06-22 04:35:57.951533
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    decompressed_data = decompressor.decompress(
        b"\x1f\x8b\x08\x08\x9b\x9c\xc3\x5a\x00\x03\x6e\x6f\x6b\x6e\x6f\x77\x6e\x2f"
        b"\x6b\x61\x72\x6c\x85\xc1\x0e\x86\xe0\xf7\x0c\x04\x00\x00\x00"
    )
    assert decompressor.unconsumed_tail == b""
    assert decompressor.flush() == b""

# Generated at 2022-06-22 04:36:02.572711
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    from pytest import raises
    with raises(ImportError): import_object('tornado.missing_module')



# Generated at 2022-06-22 04:36:03.116247
# Unit test for function doctests
def test_doctests():
    return doctests()



# Generated at 2022-06-22 04:36:03.767089
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 04:36:15.489004
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Constructing with no arguments should work
    g = GzipDecompressor()
    # Try with a real compressed file
    test_filename = os.path.join(os.path.dirname(__file__), 'test_gzip.txt.gz')
    with open(test_filename, 'rb') as f:
        data = f.read()
    g = GzipDecompressor()
    uncompressed_data = g.decompress(data)
    assert g.unconsumed_tail == b''
    assert g.flush() == b''

# Alias for compatibility with older versions
GzipDecompressionReader = GzipDecompressor

# When importing the following modules, we need to ensure that they can be
# safely imported from a subinterpreter.  (They may have C modules that can't
# be safely unloaded,

# Generated at 2022-06-22 04:36:21.260478
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    # test doctests that don't require any external state
    for module in (enum, functools, logging, traceback, types, warnings):
        test = doctests()
        test.addTest(doctest.DocTestSuite(module))
        unittest.TextTestRunner().run(test)
    # test tornado.concurrent doctests
    import tornado.concurrent
    if concurrent.futures is not None:
        # don't run if we don't have concurrent.futures (python < 3.2)
        test = doctests()
        test.addTest(doctest.DocTestSuite(tornado.concurrent))
        unittest.TextTestRunner().run(test)


if __name__ == "__main__":
    test_doctests()

# Generated at 2022-06-22 04:36:28.250932
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=3661)) == 3661
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
# Unit testing for the function re_unescape

# Generated at 2022-06-22 04:36:32.766765
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    o = ObjectDict()  # type: ObjectDict
    o.a = 3
    o.b = "hello"
    assert o["a"] == 3
    assert o.a == 3
    assert o["b"] == "hello"
    assert o.b == "hello"
    assert list(o.items()) == [("a", 3), ("b", "hello")]



# Generated at 2022-06-22 04:36:42.577172
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.a = 1


# Generated at 2022-06-22 04:36:51.567343
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import zlib
    gzip_header = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
    compressed_data = b'H\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00n\x94\x1b\x0b\x00\x00\x00'
    gzip_footer = b'\xae\x1c\x03\x00'
    data = gzip_header + compressed_data + gzip_footer
    
    decompressor = GzipDecompressor()
    assert decompressor.decompress(data) == b'hello world'
    assert decompressor.decompress(b'') == b''
    assert decompressor.unconsumed_

# Generated at 2022-06-22 04:36:58.253910
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    def func(foo):
        # type: (Any) -> None
        pass
    arg_replacer = ArgReplacer(func, 'foo')
    assert arg_replacer.get_old_value((1,), {}, 2) == 1
    assert arg_replacer.get_old_value((), {'foo': 1}, 2) == 1
    assert arg_replacer.get_old_value((), {}, 2) == 2



# Generated at 2022-06-22 04:37:09.996654
# Unit test for constructor of class Configurable
def test_Configurable():
    class Test(Configurable):
        def configurable_base(self):
            return Test

        def configurable_default(self):
            return TestImpl

        def initialize(self):
            pass

    class TestImpl(Test):
        pass

    # Test normal use
    Configurable.configure(TestImpl)
    inst = Test()
    assert isinstance(inst, TestImpl)

    # Test configure-time args
    Test.configure(TestImpl, testarg=42)
    inst = Test()
    assert isinstance(inst, TestImpl)
    assert inst.testarg == 42

    # Test fallback to default
    Configurable.configure(None)
    inst = Test()
    assert isinstance(inst, TestImpl)

    # Test reconfiguration
    Configurable.configure(TestImpl)
    inst = Test()

# Generated at 2022-06-22 04:37:17.456088
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(errno.EACCES, os.strerror(errno.EACCES))
    except Exception as e:
        assert errno_from_exception(e) == errno.EACCES

    try:
        raise Exception("error message")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-22 04:37:21.191574
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(1, "error message")
    except Exception as e:
        print(errno_from_exception(e))
        try:
            raise IOError
        except Exception as e:
            print(errno_from_exception(e))



# Generated at 2022-06-22 04:37:26.680075
# Unit test for function re_unescape
def test_re_unescape():
    try:
        re_unescape(".*")
    except ValueError:
        pass
    else:
        raise Exception("Did not raise")
    assert re_unescape("\\.\\*") == ".*"
    assert re_unescape("\\\\") == "\\"
    assert re_unescape("\\a") == "\a"
    assert re_unescape("\\d\\b\\Z\\t\\r\\n\\f\\v") == "\d\b\Z\t\r\n\f\v"



# Generated at 2022-06-22 04:37:28.437788
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 24 * 60 * 60



# Generated at 2022-06-22 04:37:38.366382
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b=2):
        print(a,b)
    a = 1
    b = 2
    res = ArgReplacer(test_func,'b').replace(a,(b,),{})
    print(res)

    c = 1
    d = 2
    res = ArgReplacer(test_func,'b').replace(c,(d,),{'b':3})
    print(res)

    e = 1
    res = ArgReplacer(test_func,'b').replace(e,(2,),{'b':3,'a':4})
    print(res)

# test_ArgReplacer_replace()



# Generated at 2022-06-22 04:37:43.153646
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def _initialize(self):
            pass

    a = A()
    assert(a.__class__.__name__ == 'A')


# Generated at 2022-06-22 04:38:03.698609
# Unit test for function import_object
def test_import_object():
    import gzip

    import tornado.escape
    # import_object is a general tool; if it imports *everything* we can't
    # test it directly.  On the other hand, we don't want to import every
    # module on every invocation of the test suite.  The solution is to
    # create a gzip module and make sure import_object can import it.
    sys = import_object("sys")
    modules = dict(sys.modules)
    try:
        sys.modules["gzip"] = gzip
        assert import_object("gzip") is gzip
        modname = gzip.__name__
        assert import_object(modname) is gzip
        assert import_object("%s.%s" % (modname, modname)) is gzip
    finally:
        sys.modules.clear()
        sys.modules

# Generated at 2022-06-22 04:38:15.374734
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test(self, a, b, c=None, *args, **kwargs):
        pass

    arg_replacer = ArgReplacer(test, "c")
    assert arg_replacer.arg_pos == 3
    assert arg_replacer.get_old_value((self, "a", "b", "d"), {}) == "d"
    assert arg_replacer.get_old_value(("a", "b", "d"), {}) is None
    assert arg_replacer.get_old_value((), dict(c="d")) == "d"
    assert arg_replacer.get_old_value(("a", "b"), dict(c="d")) is None
    assert arg_replacer.replace("f", (), dict(c="d")) == ("d", (), dict(c="f"))
    assert arg_

# Generated at 2022-06-22 04:38:19.858169
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decomp = GzipDecompressor()
    assert decomp.decompress(b"") == b""
    assert decomp.unconsumed_tail == b""
    assert decomp.decompress(b"x\\x9cKLJ\\xd2\\xef\\x02\\x00\\x0b\\x91") == b"asdf"
    assert decomp.unconsumed_tail == b""
    assert decomp.flush() == b""
    assert decomp.unconsumed_tail == b""
    # my file is "asdf\n", which is compressed to
    # 'x\x9cKLJ\xd2\xef\x02\x00\x0b\x91'
    decomp = GzipDecompressor()

# Generated at 2022-06-22 04:38:23.353978
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict(q=3, w=4)
    d.x = 5
    d.y = 6
    assert (d["q"] + d.w) * d.x + d.y == 42



# Generated at 2022-06-22 04:38:27.248140
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.name = 'name'
    name = obj.name

# Generated at 2022-06-22 04:38:29.737691
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    try:
        raise TimeoutError("test")
    except TimeoutError as e:
        assert str(e) == "test"



# Generated at 2022-06-22 04:38:33.834256
# Unit test for method __new__ of class Configurable

# Generated at 2022-06-22 04:38:40.103038
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=1)) == 1.000001
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1, microseconds=1)) == 86401.000001



# Generated at 2022-06-22 04:38:50.938640
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(42, "Nothing")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise IOError("Nothing")
    except Exception as e:
        assert errno_from_exception(e) == "Nothing"
    try:
        raise TypeError
    except Exception as e:
        type_e = e
    assert errno_from_exception(type_e) is None
    try:
        raise OSError
    except Exception as e:
        o_e = e
    assert errno_from_exception(o_e) is None



# Generated at 2022-06-22 04:39:02.151883
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("\s\S\w\W\d\D\b\B\a\A\\\t") == "\\s\\S\\w\\W\\d\\D\\b\\B\\a\\A\\\\\\t"
    assert re_unescape("\t\n\v\f\r") == "\\t\\n\\v\\f\\r"
    assert re_unescape("\0\1\2\3\4\5\6\7\8\9") == "\\0\\1\\2\\3\\4\\5\\6\\7\\8\\9"
    assert re_unescape("-*?+.") == "\\-\\*\\?\\+\\."
    assert re_unescape(r"\x00-\x7f") == "\\x00-\\x7f"

# Generated at 2022-06-22 04:39:23.121969
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    import sys
    if sys.version_info >= (3, 5):
        from importlib import reload  # python3.4 delayed the import until here
    else:
        from imp import reload
    # Reloading tornado doesn't really work because some decorators
    # (particularly gen.coroutine) touch global variables at import
    # time.  But we can at least verify that the module was reloaded.
    tornado2 = import_object("tornado")
    reload(tornado)
    assert import_object("tornado") is not tornado2
    assert import_object("tornado") is tornado

# Generated at 2022-06-22 04:39:28.832200
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gzip_decompressor = GzipDecompressor()
    gzip_decompressor.decompress(value=b'\x3c!DOCTYPE html\x3e')
    assert gzip_decompressor.flush() == b'<!DOCTYPE html>'
test_GzipDecompressor_flush()



# Generated at 2022-06-22 04:39:35.496940
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("foo\\\\bar") == "foo\\bar"
    assert re_unescape("foo\\x20bar") == "foo bar"
    assert re_unescape("foo\\0bar") == "foo\x00bar"
    assert re_unescape("foo\\dbar") == "foo\x0cbar"
    assert re_unescape("foo\\\\x20bar") == "foo\\ bar"
    assert re_unescape("foo\\[a-z]bar") == "foo[a-z]bar"
    assert re_unescape("foo[\\\\-\\]]bar") == "foo[-]bar"
    assert re_unescape("foo[\\-\\\\]bar") == "foo[-\\]bar"

# Generated at 2022-06-22 04:39:40.086543
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    class TestClass(object):
        def __init__(self, x, y, z=3, *args, **kwargs):
            self.x = x
            self.y = y
            self.z = z
            self.args = args
            self.kwargs = kwargs

    def test_function(x, y, z=3, *args, **kwargs):
        pass

    assert ArgReplacer(TestClass, "x").arg_pos is 0
    assert ArgReplacer(TestClass, "y").arg_pos is 1
    assert ArgReplacer(TestClass, "z").arg_pos is None

    c = TestClass(1, 2)
    assert c.x == 1
    assert c.y == 2
    assert c.z == 3
    assert c.args == ()

# Generated at 2022-06-22 04:39:41.688825
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    assert "" == str(e)



# Generated at 2022-06-22 04:39:50.947599
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def _test_ArgReplacer0(x: int, y: str, z: int) -> None:
        pass
    ctor = ArgReplacer(_test_ArgReplacer0, "y")
    assert ctor.get_old_value((1, "2", 3), {}) is None
    assert ctor.get_old_value((1, "2", 3), {}, None) is None
    assert ctor.get_old_value((1, "2", 3), {}, None) is None
    assert ctor.get_old_value((), {"y": "a"}, None) == "a"
    assert ctor.get_old_value((1,), {"y": "a"}, None) == "a"
    assert ctor.get_old_value((1, "2", 3), {"y": "a"}, None)