

# Generated at 2022-06-22 04:30:22.789123
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Gzip header + data + checksum
    gzip_string = (b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
                   b'1234567890\x02\x00!\x9ch\x04\x00\x00\x00')
    compressed_data = gzip_string[10:-8]
    gzip_decompressor = GzipDecompressor()
    decompressed_data = gzip_decompressor.decompress(compressed_data)

    assert gzip_decompressor.unconsumed_tail == b""
    assert decompressed_data == b'1234567890'

    # Decompress the rest of the data

# Generated at 2022-06-22 04:30:30.370098
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\n\t\v\b\r\f\\\*\?\^\$\.\+\(\)\|\[\]\{\}") == (
        "\n\t\v\b\r\f\\*?^$.+()|[]{"
    )
    with pytest.raises(ValueError):
        re_unescape(r"\d")
    with pytest.raises(ValueError):
        re_unescape(r"\1")
    with pytest.raises(ValueError):
        re_unescape(r"\t1")



# Generated at 2022-06-22 04:30:40.231945
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from _pytest.monkeypatch import MonkeyPatch
    mock_init = Mock()

    class TestConfigurable(Configurable):
        def initialize(self) -> None:
            mock_init()
    monkey_patch = MonkeyPatch()
    monkey_patch.setitem(locals(), "TestConfigurable", TestConfigurable)

    # TestConfigurable class is an implementation of Configurable class
    # and override `initialize` method
    assert TestConfigurable.initialize is mock_init

    # TestConfigurable class is directly instantiated with no parameters
    try:
        TestConfigurable()
        mock_init.assert_called()
    except TypeError:
        pytest.fail("Unexpected TypeError")



# Generated at 2022-06-22 04:30:46.087454
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    try:
        # Unit test for method __setattr__ of class ObjectDict
        a = ObjectDict()
        a.b = 2
        assert a['b'] == 2
        a[1] = 1
        assert a[1] == 1
    except AssertionError:
        raise AssertionError



# Generated at 2022-06-22 04:30:57.591616
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Foo(object):
        pass

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

        def initialize(self, a):
            # type: (int) -> None
            self.a = a

    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, Foo)
    assert a.a is None
    a = A(1)
    assert a.a == 1
    a = A(a=2)
    assert a.a == 2


# Generated at 2022-06-22 04:31:00.881629
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():

    obj = ObjectDict({"a": 1, "b": 2})
    obj.a = 3
    obj.c = 4

# Generated at 2022-06-22 04:31:07.669123
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=1)) == 0.001
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=1)) == 90061.000001



# Generated at 2022-06-22 04:31:19.869108
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(x, y, z=1):
        return x, y, z
    def func2(y, z=1, x=2):
        return x, y, z
    def func3(y, z, *args):
        return y, z, args

    test = ArgReplacer(func1, "y")
    assert test.get_old_value((1, 2,), {}) == 2
    assert test.get_old_value((), {"y": 3}) == 3
    assert test.get_old_value((), {"y": 3}, default=None) == 3
    assert test.get_old_value((), {}, default=None) is None
    assert test.get_old_value((1,), {}, default=None) is None

    test = ArgReplacer(func2, "y")


# Generated at 2022-06-22 04:31:29.985805
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(bar, baz=1):
        return bar, baz

    ar = ArgReplacer(foo, 'bar')
    r = ar.replace("new_bar", (1,), {'baz': 1})
    assert r == (1, ("new_bar",), {'baz': 1})
    assert foo('new_bar') == ("new_bar", 1)

    def foo(bar, baz=1):
        return bar, baz

    ar = ArgReplacer(foo, 'baz')
    r = ar.replace("new_baz", (1,), {'baz': 1})
    assert r == (1, (1,), {'baz': "new_baz"})
    assert foo(1, "new_baz") == (1, "new_baz")



# Generated at 2022-06-22 04:31:40.817497
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import inspect
    import functools
    def f(x, y, z=1):
        return x, y, z
    # Get the signature of f and create an instance of ArgReplacer
    args, varargs, keywords, defaults = inspect.getargspec(f)
    # pylint: disable=protected-access
    def _getargnames(func):
        return inspect.getargspec(func)[0]
    args = [x for x in _getargnames(f) if x != "self"]
    replacer = ArgReplacer(functools.partial(f, 1), args[1])
    assert replacer.get_old_value((1, 2, 1), {}) == 2
    assert replacer.get_old_value((1, 2, 1), {}, default=0) == 2

# Generated at 2022-06-22 04:31:54.867901
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    e = TimeoutError('foo')
    assert str(e) == 'foo'
    assert repr(e) == "'foo'"
    assert e.args == ('foo',)

# Alias for compatibility with 3rd-party code
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-22 04:32:04.978847
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fake_method(first, second=None, third=None):
        pass
    arg_replacer = ArgReplacer(fake_method, 'second')

    assert(arg_replacer.replace('new_value',('first',),{'third':'third_value'})) == (None, ('first',), {'second': 'new_value', 'third': 'third_value'})
    assert(arg_replacer.replace('new_value',('first',),{})) == (None, ('first',), {'second': 'new_value'})
    assert(arg_replacer.replace('new_value',('first','old_value'),{'third':'third_value'})) == ('old_value', ('first', 'new_value'), {'third': 'third_value'})

# Generated at 2022-06-22 04:32:13.564281
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def add(a, b):
        return a + b
    def test(a, b, c):
        return a + b + c
    a = ArgReplacer(add, 'a')
    b = ArgReplacer(add, 'b')
    c = ArgReplacer(test, 'c')
    print(a.get_old_value((4,5),{}))
    print(b.get_old_value((4,5),{}))
    print(c.get_old_value((4,5),{},0))

    print(a.get_old_value((4,5),{'a':3}))
    print(b.get_old_value((4,5),{'b':3}))
    print(c.get_old_value((4,5),{'c':3}))

# Generated at 2022-06-22 04:32:17.752795
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    od = ObjectDict()
    assert hasattr(od, "__getattr__") is True

# Generated at 2022-06-22 04:32:22.823465
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    TimeoutError()
    TimeoutError("foo")
    TimeoutError("foo", "bar")
    TimeoutError("foo", "bar", "baz")
    TimeoutError("foo", "bar", "baz", x=1, y=2)



# Generated at 2022-06-22 04:32:33.811534
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("foo") == "foo"
    assert re_unescape("\\f") == "\f"
    assert re_unescape("\\n") == "\n"
    assert re_unescape("\\r") == "\r"
    assert re_unescape("\\t") == "\t"
    assert re_unescape("\\a") == "\a"
    assert re_unescape("\\b") == "\b"
    assert re_unescape("\\\\") == "\\"
    assert re_unescape("\\(") == "("
    assert re_unescape("\\)") == ")"
    assert re_unescape("\\[") == "["
    assert re_unescape("\\]") == "]"
    assert re_unescape("\\.") == "."

# Generated at 2022-06-22 04:32:37.698579
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass


# backwards compatibility
gen_TimeoutError = TimeoutError  # type: Any
ioloop_TimeoutError = TimeoutError  # type: Any



# Generated at 2022-06-22 04:32:50.487161
# Unit test for function re_unescape
def test_re_unescape():
    def _test_re_unescape(s: str, expected: str) -> None:
        actual = re_unescape(s)
        if actual != expected:
            raise AssertionError(
                "re_unescape(%r) == %r != %r" % (s, actual, expected)
            )

    _test_re_unescape("\\a\\b\\f\\n\\r\\t\\v\\\\\\'\\\"", "\a\b\f\n\r\t\v\\\'\"")
    _test_re_unescape("\\x00\\x01\\x02\\x03\\x04\\x05\\x06\\x07", "\x00\x01\x02\x03\x04\x05\x06\x07")

# Generated at 2022-06-22 04:32:59.095977
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("abc") == "abc"
    assert re_unescape("abc\\.def") == "abc.def"
    assert re_unescape("abc\\tdef") == "abctdef"
    assert re_unescape("abc\\edef") == "abcedef"
    assert re_unescape("abc\\ndef") == "abcndef"
    assert re_unescape("abc\\(def") == "abc(def"
    assert re_unescape("abc\\\\def") == "abc\\def"
    assert re_unescape("abc\\\ndef") == "abc\ndef"
    assert re_unescape(r"abc\\\def") == r"abc\def"
    assert re_unescape("abc\\\x00def") == "abc\x00def"
    assert re_unescape

# Generated at 2022-06-22 04:33:01.410810
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    assert isinstance(ObjectDict().__getattr__("two"), AttributeError)

# Generated at 2022-06-22 04:33:18.828308
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(x, y=2):
        pass

    ar = ArgReplacer(func, "x")
    assert ar.get_old_value((1,), {}) == 1
    old, args, kwargs = ar.replace(2, (1,), {})
    assert old == 1
    assert args == (2,)
    assert kwargs == {}
    old, args, kwargs = ar.replace(3, (), {"x": 1})
    assert old == 1
    assert args == ()
    assert kwargs == {"x": 3}
    old, args, kwargs = ar.replace(4, (), {"y": 1})
    assert old is None
    assert args == ()
    assert kwargs == {"y": 1, "x": 4}



# Generated at 2022-06-22 04:33:27.483470
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    class Foo(ObjectDict):
        pass
    foo = Foo()
    foo.abc = 123
    assert foo["abc"] == 123


# mapping of typecode -> struct format
_struct_I = "i"
_struct_f = "f"
_struct_H = "H"
_struct_Q = "Q"

if bytes is not str:
    # Python 3.2 deprecated str, so we can't use it as part of a format
    # string.
    _struct_I = "i"
    _struct_f = "f"
    _struct_Q = "Q"
    _struct_H = "H"



# Generated at 2022-06-22 04:33:31.278566
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict(a=1, b=2)
    assert d.a == 1
    assert d.b == 2
    try:
        d.c
        raise AssertionError("d.c didn't raise AttributeError")
    except AttributeError as err:
        print(err)



# Generated at 2022-06-22 04:33:37.465123
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    try:
        1 / 0
    except:
        err = TimeoutError()
        assert err.args[0] == "Timed out"
        err = TimeoutError("foo")
        assert err.args[0] == "foo"
        err = TimeoutError(args="foo")
        assert err.args[0] == "foo"


# Two separate aliases for this type returned by `.execute()` and
# `.IOLoop.run_sync()`.
Future = typing.Future



# Generated at 2022-06-22 04:33:50.186626
# Unit test for constructor of class GzipDecompressor

# Generated at 2022-06-22 04:33:56.488055
# Unit test for constructor of class GzipDecompressor

# Generated at 2022-06-22 04:34:02.849152
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    compressed = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff"
    decompressor = GzipDecompressor()
    decompressed = decompressor.decompress(compressed)
    assert decompressor.unconsumed_tail is decompressor.flush()
    assert decompressed == b""


# Generated at 2022-06-22 04:34:14.157354
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Demo(object):
        def __init__(self):
            self.name = 'demo'

        def demo_func(self, arg1, arg2=None, arg3=None):
            return arg1, arg2, arg3

    demo_obj = Demo()
    demo_func = demo_obj.demo_func

    arg1 = 'abc'
    arg2 = 'def'
    arg3 = 'ghi'
    arg4 = 'jkl'
    arg5 = 'mno'
    arg6 = 'pqr'

    old_value, args, kwargs = ArgReplacer(demo_func, 'arg1').replace(arg2, args=(arg1,), kwargs={})
    assert old_value == arg1
    assert args == (arg2,)

# Generated at 2022-06-22 04:34:20.587212
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    e = TimeoutError(r"aa\"bb\nc")
    assert str(e) == r"aa\"bb\nc"
    assert e.args == (r"aa\"bb\nc",)


# Other Tornado modules use this function as well (e.g. tornado/escape.py)
_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 04:34:32.846653
# Unit test for constructor of class Configurable
def test_Configurable():
    class MyConf(Configurable):
        def configurable_base(self):
            return MyConf

        def configurable_default(self):
            return MyConfImpl

        def initialize(self):
            pass

    class MyConfImpl(MyConf):
        pass

    MyConf.configure("tornado.util.MyConfImpl")
    assert MyConf.configured_class() is MyConfImpl
    MyConf.configure("tornado.util.MyConfImpl2")
    assert MyConf.configured_class() is MyConfImpl
    MyConf.configure("tornado.util.MyConfImpl")
    assert MyConf.configured_class() is MyConfImpl
    MyConf.configure(None)
    assert MyConf.configured_class() is MyConfImpl

# Generated at 2022-06-22 04:34:45.190468
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    class Foo(ObjectDict):
        pass

    foo = Foo()
    test = foo.new_attr = True
    assert test == foo['new_attr']



# Generated at 2022-06-22 04:34:53.449837
# Unit test for function errno_from_exception
def test_errno_from_exception():

    class MyException(Exception):
        """Dummy exception class."""
        pass

    try:
        raise MyException(None)
    except MyException as e:
        errno = errno_from_exception(e)
    assert errno is None

    try:
        raise MyException(1)
    except MyException as e:
        errno = errno_from_exception(e)
    assert errno is 1

    try:
        raise MyException(1, "error")
    except MyException as e:
        errno = errno_from_exception(e)
    assert errno is 1

    try:
        raise MyException((1, "error"))
    except MyException as e:
        errno = errno_from_exception(e)
    assert errno is 1


_FILEID_

# Generated at 2022-06-22 04:34:59.771346
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise IOError(22, 'errno 22')
    except IOError as e:
        assert e.errno == 22
    try:
        raise IOError('error')
    except IOError as e:
        assert errno_from_exception(e) == 'error'
    try:
        raise ValueError
    except ValueError as e:
        assert errno_from_exception(e) == None


# Generated at 2022-06-22 04:35:01.531442
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass

# Generated at 2022-06-22 04:35:07.624449
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    replacer = ArgReplacer(test_ArgReplacer_replace, 'new_value')
    old_value, args, kwargs = replacer.replace('newly value', ('a', 'b'), {'new_value': 'old value'})
    assert old_value == 'old value'
    assert args == ('a', 'b')
    assert kwargs == {'new_value': 'newly value'}



# Generated at 2022-06-22 04:35:13.132203
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1.5)) == 86401.5



# Generated at 2022-06-22 04:35:25.813099
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def inner(exc_info, caller_is_raising):
        if not caller_is_raising:
            raise_exc_info(exc_info)  # type: ignore
    def outer():
        try:
            raise ValueError()
        except ValueError:
            inner(sys.exc_info(), caller_is_raising=False)
        try:
            raise_exc_info(sys.exc_info())
        except ValueError:
            pass
    outer()


# Fake bytes() builtins for projects like pyflakes that have
# problems with "from __future__ import unicode_literals"
if bytes is str:

    def bytes(source: typing.Union[str, "bytes"], encoding: str = "ascii", errors: str = "strict") -> "bytes":
        if isinstance(source, str):
            return

# Generated at 2022-06-22 04:35:37.222465
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    # Test the special case of an empty input
    assert decompressor.decompress(b"") == b""
    assert decompressor.unconsumed_tail == b""
    # Test the case of an incomplete header
    assert decompressor.decompress(b"\x1f") == b""
    assert decompressor.unconsumed_tail == b"\x1f"
    # Test the case of a complete header, but no data
    assert decompressor.decompress(b"\x1f\x8b") == b""
    assert decompressor.unconsumed_tail == b"\x1f\x8b"
    # Test the case of a complete header and some data

# Generated at 2022-06-22 04:35:44.022197
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=1, b=2)
    assert d.a == 1
    assert d.b == 2

# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u(...) can be
# applied to ascii strings that include \u escapes (but they must not
# contain non-ascii characters).
if str is unicode_type:
    def u(s: str) -> str:
        return s

    bytes_literals = []  # type: List[str]
else:
    def u(s: str) -> str:  # noqa: F811
        return s

    # This is a trick to keep our sanity with

# Generated at 2022-06-22 04:35:54.375838
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    test_string = b'a string'
    # zlib.compress returns a bytes object containing compressed data
    test_string_gz = zlib.compress(test_string)
    gd = GzipDecompressor()
    # Following two calls should be equivalent
    assert gd.decompress(test_string_gz) == test_string
    assert gd.decompress(test_string_gz, 0) == test_string
    # Flush method should return empty bytes
    assert not gd.flush()


# Aliases for functions that are different pre-Python 3.5.
if typing.TYPE_CHECKING:
    from typing import AnyStr



# Generated at 2022-06-22 04:36:11.607386
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(x, y):
        pass
    f = ArgReplacer(func, 'x')
    assert f.get_old_value((1,), {'y': 2}, 'default') == 1
    assert f.get_old_value((), {'x': 1, 'y': 2}, 'default') == 1
    assert f.get_old_value((), {'y': 2}, 'default') == 'default'


# Generated at 2022-06-22 04:36:23.753217
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    def t(name, td, expected):
        actual = timedelta_to_seconds(td)
        assert actual == expected, ("%s: %r != %r" % (name, actual, expected))

    t("zero", datetime.timedelta(), 0.0)
    t("seconds", datetime.timedelta(seconds=1), 1.0)
    t("minutes", datetime.timedelta(minutes=1), 60.0)
    t("hours", datetime.timedelta(hours=1), 3600.0)
    t("days", datetime.timedelta(days=1), 86400.0)
    t("days, seconds", datetime.timedelta(days=1, seconds=1), 86401.0)

# Generated at 2022-06-22 04:36:34.799286
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def func(a, b, c = 1, d = 2, *args, **kwargs):
        # type: (str, int, int, int, Any, Any) -> None
        pass

    # The argument to replace is passed positionally
    old_value, args, kwargs = ArgReplacer(func, "b").replace(
        new_value = 2,
        args = (1, 3),
        kwargs = {"d": 4, "e": "a"},
    )
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {"d": 4, "e": "a"}

    # The argument to replace is passed by keyword

# Generated at 2022-06-22 04:36:47.297522
# Unit test for function exec_in
def test_exec_in():
    code = "a = 'foo'"
    glob = {}
    exec_in(code, glob)
    assert glob['a'] == 'foo'
    code = "a = b = 'bar'"
    glob = {}
    loc = {}
    exec_in(code, glob, loc)
    assert loc['a'] == loc['b'] == 'bar'
    assert 'a' not in glob


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).

# Generated at 2022-06-22 04:36:53.631606
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def method(arg1, arg2):
        pass
    replacer = ArgReplacer(method, "arg1")
    assert replacer.get_old_value(("old", "arg2"), dict()) == "old"
    assert replacer.get_old_value(("old", "arg2"), dict(), "default") == "old"
    assert replacer.get_old_value((), dict(), "default") == "default"
    assert replacer.get_old_value(("old", "arg2"), {"arg2": "value2"}) == "old"
    replacer = ArgReplacer(method, "arg2")
    assert replacer.get_old_value(("arg1", "old"), dict()) == "old"
    assert replacer.get_old_value(("arg1", "old"), dict(), "default")

# Generated at 2022-06-22 04:36:56.919799
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(0, 5)) == 5.0
    assert timedelta_to_seconds(datetime.timedelta(1, 0)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(0, 0, 1000)) == 0.001
    assert timedelta_to_seconds(datetime.timedelta(0, 0, 1)) == 0.000001



# Generated at 2022-06-22 04:37:06.524733
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class MyInterface:
        __metaclass__ = Configurable

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[MyInterface]
            return MyInterface

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[MyInterface]
            return MyClass

        def initialize(self):
            # type: () -> None
            self.initialized = True

    class MyClass(MyInterface):
        pass

    class MyAlternative(MyInterface):
        pass

    m = MyInterface()
    assert isinstance(m, MyInterface)
    assert isinstance(m, MyClass)
    assert not isinstance(m, MyAlternative)
    assert m.initialized
    assert m.__class__ is MyClass
    m2 = My

# Generated at 2022-06-22 04:37:18.281988
# Unit test for constructor of class Configurable
def test_Configurable():
    # Save original configuration, since we're modifying it.
    saved = Configurable.configurable_base()
    @add_metaclass(Configurable)
    class Foo(object):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self, a=None):
            pass

    class Unrelated(object):
        pass

    assert Foo.configured_class() is Foo

    Foo.configure("tornado.test.util_test.Unrelated")
    assert Foo.configured_class() is Unrelated
    Foo.configure(None)
    assert Foo.configured_class() is Foo

    # Test that the original configuration is restored.

# Generated at 2022-06-22 04:37:26.768111
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    import inspect
    from functools import partial
    class SomeClass:
        def __init__(self, foo, bar="default_bar"):
            pass
    @ArgReplacer.decorate("foo")
    def decorated_method_1(self, foo, bar="default_bar"):
        return foo, bar
    @ArgReplacer.decorate("bar")
    def decorated_method_2(self, foo, bar="default_bar"):
        return foo, bar
    @ArgReplacer.decorate("foo")
    @ArgReplacer.decorate("bar")
    def decorated_method_3(self, foo, bar="default_bar"):
        return foo, bar
    # test when argument is passed by position

# Generated at 2022-06-22 04:37:30.805764
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()

# Use this at the end of a generator to return a value without stopping
# the generator.  This is needed in order to combine `return` and
# `yield` in a Python 2 generator.
#
# This function is present in Python 3, but not Python 2.

# Generated at 2022-06-22 04:38:00.008875
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # type: () -> None
    try:
        raise IOError(123)
    except BaseException as e:
        assert errno_from_exception(e) == 123

    try:
        raise IOError()
    except BaseException as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError("test")
    except BaseException as e:
        assert errno_from_exception(e) == "test"



# Generated at 2022-06-22 04:38:10.759933
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\d") == r"d"

# Generated at 2022-06-22 04:38:17.739219
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    assert isinstance(decompressor, GzipDecompressor)


# Aliases for CPython exceptions that may or may not be available on
# other Pythons.
try:
    import _thread as thread  # type: ignore
except ImportError:
    class _NoThreadNamespace(object):
        pass

    thread = _NoThreadNamespace()  # type: Any

try:
    thread.error
except AttributeError:
    thread.error = ValueError



# Generated at 2022-06-22 04:38:29.869614
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import types
    import sys
    import inspect
    target_dir = 'trunk'
    target_module = 'tornado.util'
    # Unit: tornado.util:Configurable
    target_class = 'Configurable'
    target_method = 'initialize'
    # open the target module
    module_object = sys.modules.get(target_module, None)
    if module_object is None:
        file_object, path_name, description = imp.find_module(target_module, [target_dir])
        try:
            module_object = imp.load_module(target_module, file_object, path_name, description)
        finally:
            if file_object:
                file_object.close()
    #

# Generated at 2022-06-22 04:38:40.784201
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # test replacement by position
    def f1(a, b, c=1):
        return a, b, c
    assert ArgReplacer("b").replace(2, (0,), {}) == (None, (0, 2), {})
    assert ArgReplacer("b").replace(2, (0, 1), {}) == (1, (0, 2), {})
    assert ArgReplacer("b").replace(2, (0, 1, 2, 3), {}) == (1, (0, 2, 2, 3), {})
    # test replacement by keyword
    assert ArgReplacer("b").replace(2, (), {"b": 1}) == (1, (), {"b": 2})
    assert ArgReplacer("b").replace(2, (0,), {"b": 1}) == (1, (0,), {"b": 2})

# Generated at 2022-06-22 04:38:51.285193
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"") == r""
    assert re_unescape(r"\a") == r"\a"
    assert re_unescape(r"\2") == r"\2"
    assert re_unescape(r"\w") == r"\w"
    assert re_unescape(r"a\b") == r"a\b"
    assert re_unescape(r"\A") == r"A"
    assert re_unescape(r"\W") == r"\W"
    assert re_unescape(r"\\") == r"\\"
    assert re_unescape(r"\Qa\\\E") == r"a\\"
    assert re_unescape(r"\1") == r"\1"

# Generated at 2022-06-22 04:38:55.311874
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    od = ObjectDict(a=1)
    assert 1 == od.a
    assert 'a' == getattr(od, 'a')
    od.a = 2
    assert 2 == od.a
    with pytest.raises(AttributeError):
        getattr(od, 'b')
    with pytest.raises(AttributeError):
        od.b



# Generated at 2022-06-22 04:38:57.138864
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    suite = doctests()
    runner = unittest.TextTestRunner()
    runner.run(suite)

# Generated at 2022-06-22 04:39:09.065124
# Unit test for constructor of class Configurable
def test_Configurable():
    class Implementation1(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableTestBase

        @classmethod
        def configurable_default(cls):
            return Implementation1

    class Implementation2(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableTestBase

        @classmethod
        def configurable_default(cls):
            return Implementation2

    # This is the class that's actually constructed
    class ConfigurableTestBase(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableTestBase

        @classmethod
        def configurable_default(cls):
            return Implementation1

        # This is a separate method so the test can override it.
        def get_value(self):
            return self

# Generated at 2022-06-22 04:39:20.925603
# Unit test for function re_unescape
def test_re_unescape():
    # Make sure it doesn't unescape anything that was not escaped
    # by re.escape
    assert re_unescape(r"\n") == r"\n"
    assert re_unescape(r"\\") == r"\\"
    assert re_unescape(r"\a") == r"\a"

    # re.escape escapes everything but alphanumeric characters, so
    # that should be unescaped.
    assert re_unescape(r"\\x") == r"x"
    assert re_unescape(r"\?") == "?"
    assert re_unescape(r"\\(a)") == r"(a)"
    assert re_unescape(r"\\_") == "_"

    # "\\\\x" means "\\" followed by "x", so it should be unescaped.
    assert re