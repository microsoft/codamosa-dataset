

# Generated at 2022-06-22 04:30:29.603633
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_function_1(x, y=0, z=20):
        return x, y, z
    def test_function_2(x=40, y=0, z=20):
        return x, y, z
    def test_function_3(x=40, y=0, z=20):
        return x, y, z
    replacer_1 = ArgReplacer(test_function_1, "y")
    replacer_2 = ArgReplacer(test_function_1, "z")
    replacer_3 = ArgReplacer(test_function_2, "x")
    replacer_4 = ArgReplacer(test_function_2, "y")
    replacer_5 = ArgReplacer(test_function_2, "z")

# Generated at 2022-06-22 04:30:38.894493
# Unit test for function re_unescape
def test_re_unescape():
    def check(s: str) -> None:
        assert re_unescape(re.escape(s)) == s

    check(r"\a\b\c\d\e\f\g\h\i\j\k\l\m\n\o\p\q\r\s\t\u\v\w\x\y\z\A\B\C\D\E\F\G\H\I\J\K\L\M\N\O\P\Q\R\S\T\U\V\W\X\Y\Z\0\1\2\3\4\5\6\7\8\9")



# Generated at 2022-06-22 04:30:46.315937
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # Input data
    mData = b'text'
    # Creating an object of GzipDecompressor
    gdObj = GzipDecompressor()
    # Calling method flush no data is passed
    data1 = gdObj.flush()
    # Calling method flush with data
    data2 = gdObj.flush(mData)
    assert not data1, "Should be none"
    assert data2 == b'text', "Should be same"


# Generated at 2022-06-22 04:30:57.632155
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass
    except:
        assert False, "Unexpected exception"

# These aliases are for backwards compatibility.
TimeoutException = TimeoutError
gen.TimeoutError = TimeoutError
gen.TimeoutException = gen.TimeoutError

# Not all versions of Python support PEP 476, the ssl.match_hostname
# function, or the ssl.CertificateError exception.
#
# If support is missing, either because the version of Python is too
# old or because the ssl module was compiled without SSLv3 support,
# we'll use a bundled copy.
#
# We use a copy rather than a backport to avoid having to include
# a version number in the name (backports are named with the version
# of Python they're intended for, which would be redundant with
#

# Generated at 2022-06-22 04:31:00.881774
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    assert str(e) == str(__import__("tornado").gen.TimeoutError())



# Generated at 2022-06-22 04:31:05.660127
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(0)) == 0
    assert timedelta_to_seconds(datetime.timedelta(1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=0.9)) == 0.9
    assert timedelta_to_seconds(datetime.timedelta(seconds=0.1)) == 0.1



# Generated at 2022-06-22 04:31:17.987000
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    assert str(e) == "Timed out"
    e = TimeoutError("foo")
    assert str(e) == "foo"


# Optional aliases for interfaces in other modules
if not typing.TYPE_CHECKING:
    try:
        from typing import Awaitable  # noqa: F401
    except ImportError:
        pass
    try:
        from typing import Final  # noqa: F401
    except ImportError:
        pass
    try:
        from typing import Protocol  # noqa: F401
    except ImportError:
        pass
    try:
        from typing import TypeVar  # noqa: F401
    except ImportError:
        pass

# Constants from the struct module
# Struct docstring hint: "H" is "unsigned short, native endian"
STRUCT_

# Generated at 2022-06-22 04:31:27.778814
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # When you need to test out a method of a class
    # You can create a test function for this.
    # Use the function name test_<ClassName>_<methodName>

    def fun(*args, **kwargs):
        return args, kwargs

    # Creates the object of class ArgReplacer
    # And passes the object of fun as first argument to this object
    # and the name of the argument you need to search in the function
    # as the second argument to this object
    arg_replacer = ArgReplacer(fun, "arg")

    # grab the old value of argument "arg" in function fun
    # if the default value is not given
    arg = arg_replacer.get_old_value(("a", "b"), {"arg": "c"})


# Generated at 2022-06-22 04:31:38.812640
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class dummytype(object):
        pass

    def dummy_func_1(a,b,*args,**kwargs):
        return a,b,args,kwargs

    def dummy_func_2(a,b,c=None,**kwargs):
        return a,b,c,kwargs

    def dummy_func_3(a,b,*args,**kwargs):
        return a,b,args,kwargs

    def test_case(dummy_func):
        arg_replacer = ArgReplacer(dummy_func, 'b')
        a = dummytype()
        b = dummytype()
        c = dummytype()
        args = (a, b, c)
        kwargs = {'b': b}
        # Test case 1: a=a, b=(b,)*N, c=

# Generated at 2022-06-22 04:31:50.022893
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def testGetOldValue(args, kwargs, name, default=None, expected=None):
        ar = ArgReplacer(testGetOldValue, name)
        result = ar.get_old_value(args, kwargs, default)
        if result != expected:
            raise AssertionError('Expected %s got %s' % (expected, result))

    # Simple success cases
    testGetOldValue((1, 2, 3), {'foo': 'bar'}, 'foo', 'baz', 'bar')
    testGetOldValue((1, 'foo', 3), {'foo': 'bar'}, 'foo', 'baz', 'foo')
    testGetOldValue((1, 'bar', 3), {}, 'foo', 'baz', 'baz')

    # Failure cases; should return default

# Generated at 2022-06-22 04:31:58.757082
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    failures, _ = doctest.testmod()
    assert failures == 0

# Generated at 2022-06-22 04:32:05.773973
# Unit test for constructor of class Configurable
def test_Configurable():
    class C(Configurable):
        def initialize(self):
            self.initialized = True

        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

    assert C.configured_class() is C
    c = C()
    assert c.initialized
    assert isinstance(c, C)
    assert c.__class__ is C

    class D(C):
        pass

    D.configure("tornado.testing.C")
    assert D.configured_class() is C
    d = D()
    assert d.initialized
    assert isinstance(d, D)
    assert isinstance(d, C)
    assert d.__class__ is C

    # Save/restore state
    saved = D._save_

# Generated at 2022-06-22 04:32:13.988148
# Unit test for constructor of class Configurable
def test_Configurable():
    class C(Configurable):
        def __init__(self, arg):
            self.arg = arg

        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

    class D(C):
        pass

    C.configure(D)
    c = C(42)
    assert isinstance(c, C)
    assert isinstance(c, D)
    assert c.arg == 42

    # reset configuration
    C.configure(None)
    c = C('test')
    assert isinstance(c, C)
    assert not isinstance(c, D)
    assert c.arg == 'test'

    # Test saving and restoring configuration
    C.configure(D)
    saved = C._save_config

# Generated at 2022-06-22 04:32:21.725739
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict(a=1)
    x.a = 2
    assert x["a"] == 2
    assert x.a == 2
    x.b = 3
    assert x["b"] == 3
    assert x.b == 3
    assert hasattr(x, "b")
    x["c"] = 4
    assert x["c"] == 4
    assert x.c == 4
    assert "c" in x



# Generated at 2022-06-22 04:32:24.183328
# Unit test for function doctests
def test_doctests():
    suite = doctests()
    runner = unittest.TextTestRunner(verbosity=1)
    runner.run(suite)



# Generated at 2022-06-22 04:32:26.936071
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    od = ObjectDict({'x': 'X'})
    assert od.x == 'X', "Instance method __getattr__() failed"
    assert od.x != 'y', "Instance method __getattr__() failed"

# Generated at 2022-06-22 04:32:31.980813
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1, hours=1)) == 1 * 24 + 1
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 1e-6
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1



# Generated at 2022-06-22 04:32:44.682570
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fn1(a, b = 5):
        pass
    def fn2(a):
        pass
    def fn3(a, b = 5, c = 3):
        pass
    def fn4(a = 5, b = 5, c = 3):
        pass
    def fn5(a, b, c):
        pass
    assert ArgReplacer(fn1, 'a').get_old_value((1,), {}, None) == 1
    assert ArgReplacer(fn1, 'a').get_old_value((1,), {}) == 1
    assert ArgReplacer(fn1, 'a').get_old_value((), {'a':3}, None) == 3
    assert ArgReplacer(fn1, 'a').get_old_value((), {'a':3}) == 3

# Generated at 2022-06-22 04:32:54.525180
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c="test_ArgReplacer_replace"):
        return a, b, c

    # Verify replacing a positional argument
    old_value, args, kwargs = ArgReplacer("a").replace("new value", (1,2,3), {})
    assert args == ("new value", 2, 3)
    assert kwargs == {}
    assert old_value is 1

    old_value, args, kwargs = ArgReplacer("a").replace("new value", (1,2), {})
    assert args == ("new value", 2)
    assert kwargs == {}
    assert old_value is 1

    old_value, args, kwargs = ArgReplacer("a").replace("new value", (1,), {})
    assert args == ("new value",)

# Generated at 2022-06-22 04:33:05.962589
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("abcd") == "abcd"
    assert re_unescape("a\\.b\\*c\\(d\\)") == "a.b*c(d)"
    assert re_unescape("\\d\\s\\\\n\\t\\D\\S") == "\\d\\s\\\\n\\t\\D\\S"
    assert re_unescape("\\w") == "\\w"
    assert re_unescape("\\\\") == "\\"
    assert re_unescape("\\u1234") == "\\u1234"
    assert re_unescape("\\U00010123") == "\\U00010123"
    assert re_unescape("\\N{LATIN SMALL LETTER A WITH GRAVE}") == "\\N{LATIN SMALL LETTER A WITH GRAVE}"
   

# Generated at 2022-06-22 04:33:13.659753
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    _ = GzipDecompressor()

# Generated at 2022-06-22 04:33:23.129265
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None

    class D(ObjectDict):
        def __init__(self):
            # type: () -> None
            ObjectDict.__init__(self, foo=5, bar=6)

        def test(self):
            # type: () -> int
            return self.foo
    d = D()
    assert d.foo == 5
    assert d.bar == 6
    assert d.test() == 5
    try:
        d.missing
        assert False, "expected AttributeError"
    except AttributeError:
        pass
    try:
        d.foo = 7
        assert False, "expected TypeError"
    except TypeError:
        pass



# Generated at 2022-06-22 04:33:26.671526
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzipper = GzipDecompressor()
    result = gzipper.decompress('hello')
    assert result == b''


# Generated at 2022-06-22 04:33:34.643216
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import zlib
    ''
    import gzip
    if zlib.decompressobj().decompress(gzip.compress(b'hello world')) == b'hello world':
        return
    # This implementation is based on zlib.decompressobj, but it
    # understands gzip headers.  Note that we're using the deprecated
    # GzipFile interface to zlib to avoid the performance overhead of
    # the higher-level file interface.
    from io import BytesIO
    from gzip import FNAME
    f = gzip.GzipFile(mode='wb', fileobj=BytesIO())
    f.write(b'hello world')
    f.close()
    out = f.fileobj.getvalue()
    # Strip the first 10 bytes of the header and the 8 bytes of the
    # checksum at the end

# Generated at 2022-06-22 04:33:45.116271
# Unit test for function exec_in
def test_exec_in():
    exec_in("def foo(): return 6*7", globals())
    assert foo() == 42
test_exec_in()


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have different semantics.  u() can be applied to ascii
# strings that include \u escapes (but they must not contain literal
# non-ascii characters).
#
# Note that this function is for synthetic unicode literals that contain
# non-ASCII characters.  To test whether a string is unicode without
# introducing a synthetic string, use isinstance(val, unicode_type).

# Generated at 2022-06-22 04:33:48.170458
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    od = ObjectDict()
    od['name'] = 'value'

    assert od['name'] == 'value'
    assert od.name == 'value'

# Generated at 2022-06-22 04:33:58.003458
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def method(a, b=2, c=3):
        pass
    argReplacer = ArgReplacer(method, "c")
    assert argReplacer.get_old_value((1,), {}, None) is None
    assert argReplacer.get_old_value((1,), {"c": 3}, None) == 3
    assert argReplacer.get_old_value((1, 2, 3), {}, None) == 3
    assert argReplacer.get_old_value((1, 2, 3), {"c": 3}, None) == 3
    assert argReplacer.get_old_value((1,), {"b": 2}, None) is None
    
    

# Generated at 2022-06-22 04:33:58.722377
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 04:34:01.191464
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    x = ObjectDict()
    x['hello'] = 'world'

    assert x['hello'] == x.hello

# Generated at 2022-06-22 04:34:13.253597
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a,b='default_b'):
        return a,b
    my_ArgReplacer = ArgReplacer(foo,'b')
    foo_new = my_ArgReplacer.replace('new_b',('a_pos_arg',),{})
    assert foo_new == ('a_pos_arg','new_b'), "Positional argument error"
    # The value of the added argument can be retrieved and the new
    # value is the same if the argument is passed by keyword
    foo_new = my_ArgReplacer.replace('new_b',(),{'a':'a_key_arg'})
    assert foo_new == ('new_b',), "Keyword argument error"
    # The value of the added argument can be retrieved and the new
    # value is the same if the argument is omitted

# Generated at 2022-06-22 04:34:22.900239
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.a = 10
    assert d["a"] == 10
    d["b"] = 12
    assert d.b == 12



# Generated at 2022-06-22 04:34:34.931670
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=1, d=2):
        return a, b, c, d

    args = ArgReplacer(func, "c")
    old_value, new_args, new_kwargs = args.replace(2, (1, 2), {'b': 2, 'd': 3})
    assert old_value == 1
    assert new_args == (1, 2)
    assert new_kwargs == {'b': 2, 'd': 3}

    old_value, new_args, new_kwargs = args.replace(3, (1, 2), {'b': 2, 'd': 3, 'c': 4})
    assert old_value == 4
    assert new_args == (1, 2)

# Generated at 2022-06-22 04:34:39.417324
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def reraise_test():
        try:
            raise AssertionError("foo")
        except AssertionError:
            exc_info = sys.exc_info()
        raise_exc_info(exc_info)
    with pytest.raises(AssertionError):
        reraise_test()



# Generated at 2022-06-22 04:34:45.425747
# Unit test for function re_unescape
def test_re_unescape():
    # unit test for re_unescape
    assert re_unescape(r"\s\w\d") == "\\s\\w\\d"

    # Can't unescape strings containing "\d".
    try:
        re_unescape(r"\d")
        raise AssertionError("did not get expected ValueError")
    except ValueError:
        pass



# Generated at 2022-06-22 04:34:53.638209
# Unit test for constructor of class Configurable
def test_Configurable():

    class TestException(Exception):
        pass

    class Base(Configurable):

        def configurable_base(self):  # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):  # type: () -> Type[Configurable]
            return BaseImpl

        def initialize(self, *args, **kwargs):  # type: (Any, Any) -> None
            pass

    class BaseImpl(Base):
        pass

    class Sub(BaseImpl):

        def configurable_base(self):  # type: () -> Type[Configurable]
            return Sub

        @classmethod
        def configurable_default(cls):  # type: () -> Type[Configurable]
            return SubImpl


# Generated at 2022-06-22 04:35:04.970210
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    @gen.coroutine
    def wrapped(*args, **kwargs):
        return

    # A decorator that takes two arguments
    def my_decorator(decorator_arg_1: str, decorator_arg_2: int) -> Callable:
        def wrapper(func: Callable) -> Callable:
            def wrapped_function(*args, **kwargs):
                # Get old value of the keyword argument 'keyword_arg_1' of the wrapped function
                old_value = ArgReplacer(func, "keyword_arg_1").get_old_value(args, kwargs, default="default_value")
                @gen.coroutine
                def wrapped_coroutine():
                    return func(*args, **kwargs)

                return wrapped_coroutine()

            return wrapped_function

        return wrapper

    # Use the decor

# Generated at 2022-06-22 04:35:14.725044
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    decompressor = GzipDecompressor()
    data = decompressor.decompress(b"x\x9cK\xcb\xcf\x07\x00\x02\x82\x01E")
    data += decompressor.flush()
    assert data == b'{"foo": 1}'
    data = decompressor.decompress(b"x\x9cK\xcb\xcf\x07\x00\x02\x82\x01E")
    data += decompressor.decompress(b"")
    assert data == b'{"foo": 1}'



# Generated at 2022-06-22 04:35:20.404745
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    baseClass = Configurable
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(None)
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(None)
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(None)
    baseClass.configure(Configurable)
    baseClass.configure(Configurable)
    baseClass.configure(None)

# Generated at 2022-06-22 04:35:26.325651
# Unit test for function exec_in
def test_exec_in():
    g = dict(a=1, b=2)
    l = dict(c=3)
    exec_in("a=5", g, l)
    exec_in("b=6", g, l)
    exec_in("c=7", g, l)
    assert l["a"] == 5
    assert l["b"] == 6
    assert l["c"] == 7

# Fake byte literal for testing (in python 2 we use b"", but in python 3
# we have to skip the leading "b" or it's a syntax error)
_TEST_BYTES = b"foo" if str is unicode_type else "foo"



# Generated at 2022-06-22 04:35:27.566169
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.name = 1
    a.name



# Generated at 2022-06-22 04:35:42.414219
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):
        pass

    class Bar(Foo):
        pass

    class SubFoo(Foo):
        pass

    class SubBar(Bar):
        pass

    Foo.configure(SubFoo)
    assert Foo()  # type: ignore
    assert Bar()  # type: ignore
    assert SubFoo()  # type: ignore
    assert SubBar()  # type: ignore

    Foo.configure(SubBar)
    assert Foo()  # type: ignore
    assert Bar()  # type: ignore
    assert SubFoo()  # type: ignore
    assert SubBar()  # type: ignore



# Generated at 2022-06-22 04:35:55.492314
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    global args, kwargs
    args = ('arg0', 'arg1')
    kwargs = {'kwarg0': 0, 'kwarg1': 1}
    def test_func(*args, **kwargs):
        pass

    ar = ArgReplacer(test_func, 'kwarg0')
    assert ar.get_old_value(args, kwargs) == 0
    assert ar.get_old_value(args, kwargs, default=None) == 0
    assert ar.get_old_value(args, {}, default=None) is None
    assert ar.replace(2, args, kwargs) == (0, ('arg0', 'arg1'), {'kwarg0': 2, 'kwarg1': 1})

# Generated at 2022-06-22 04:35:59.814135
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # common case works
    GzipDecompressor().decompress(b"1")
    # invalid gzip header
    GzipDecompressor().decompress(b"x")
    # not enough data
    GzipDecompressor().decompress(b"")



# Generated at 2022-06-22 04:36:11.988296
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        def initialize(self):
            self.name = "A"

    class B(A):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    class C(A):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            self.name = "C"

    class D(B, C):
        pass

    # Check that the classes work normally
    a = A()
    assert a.name == "A"
    b = B()
    assert b.name == "A"
    c = C()

# Generated at 2022-06-22 04:36:24.271409
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    class BaseConfigurable(Configurable):

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

    class Impl(BaseConfigurable):

        def initialize(self):
            pass

    class FailingInitialize(BaseConfigurable):

        def initialize(self):
            raise Exception()

    class FailingClassMethod(BaseConfigurable):

        @classmethod
        def configurable_base(cls):
            raise Exception()

    class BrokenConfigurable(Configurable):

        @classmethod
        def configurable_base(cls):
            return cls

    class UnimplementedConfigurable(Configurable):
        pass


# Generated at 2022-06-22 04:36:32.198832
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # pragma: nocover
    # type: () -> None
    if not hasattr(ObjectDict, '__slots__'):
        # For some reason, ObjectDict.__init__ has to be defined
        # in order to not break this test.
        # The actual problem is that the __init__() method of ObjectDict
        # throws an exception, and the exception is not defined in the class
        # definition.
        ObjectDict.__init__ = lambda x: x
        obj = ObjectDict()
        obj.__init__()



# Generated at 2022-06-22 04:36:36.982897
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def foo(a, b, c=None, *args, **kwargs):
        pass

    ar = ArgReplacer(foo, "c")
    old_val, a, kw = ar.replace(42, (1,), {"b": 2})
    assert old_val is None
    assert (a, kw) == ((1,), {"b": 2, "c": 42})


_ARG_DEFAULT = object()



# Generated at 2022-06-22 04:36:43.345750
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class NewConfigurable(Configurable):
        def configurable_base(self):
            return 'configurable_base'
        def configurable_default(self):
            return 'configurable_default'
    new_configurable = NewConfigurable()
    assert new_configurable == 'configurable_default'


# Generated at 2022-06-22 04:36:47.637595
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest

    class A(Configurable):
        def __init__(self, *args, **kwargs):
            raise AssertionError("__init__ should never be called")

        def initialize(self, *args, **kwargs):
            pass

    A()



# Generated at 2022-06-22 04:36:52.565569
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # python2 do not support method testing
    if not isinstance(ObjectDict__setattr__, Callable):
        pass
    else:
        # 'NoneType' object has no attribute '__getitem__'
        # Type error
        assert_raises(AttributeError, ObjectDict__setattr__, None, str, Any)
        # Type error
        assert_raises(AttributeError, ObjectDict__setattr__, None, str, Any)
        # Type error
        assert_raises(AttributeError, ObjectDict__setattr__, None, str, Any)

# Generated at 2022-06-22 04:37:15.736518
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    def check(d, key, value):
        # type: (ObjectDict, str, str) -> None
        assert d[key] == value
        assert d.a == value
        assert d.b == value
    d = ObjectDict(a="foo", b="bar")
    check(d, "a", "foo")
    check(d, "b", "bar")

_TIMEOUT_REGEX = re.compile(r"^([\d\.]+)([smhd]?)$")
_UNIT_SUFFIXES = {"s": 1, "m": 60, "h": 60 * 60, "d": 24 * 60 * 60}



# Generated at 2022-06-22 04:37:18.983474
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def test_func(exc_info: Tuple[Optional[type],
                                  Optional[BaseException],
                                  Optional[TracebackType]]) -> typing.NoReturn:
        raise_exc_info(exc_info)


# Generated at 2022-06-22 04:37:20.840271
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(1)) == 24 * 60 * 60



# Generated at 2022-06-22 04:37:25.700066
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    test_data = b'''
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffff
    '''
    decompressor = GzipDecompressor()
    decompressed = decompressor.decompress(test_data)
    print(decompressor.flush())
    print(decompressed)
    print(decompressor.unconsumed_tail)
   

# Generated at 2022-06-22 04:37:28.868827
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    failures, tests = doctest.testmod()
    if failures:
        raise Exception("%d doctest failures" % failures)



# Generated at 2022-06-22 04:37:32.830382
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError(1)
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)



# Generated at 2022-06-22 04:37:43.222826
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Base(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return Base

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return DefaultImpl

        def initialize(self, a, b='c', **kwargs):
            # type: (str, str, Any) -> None
            self.a = a
            self.b = b
            self.kwargs = kwargs

        def __repr__(self):
            # type: () -> str
            return '%s(%r, %r, %r)' % (self.__class__, self.a, self.b, self.kwargs)

        def method(self):
            # type: () -> str
            return 'Base'

# Generated at 2022-06-22 04:37:44.348211
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()



# Generated at 2022-06-22 04:37:50.242997
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    data = decompressor.decompress(b"V\x8b\xad\xcbH\xc9\xc8W(\xcf/\xcaI\x01\x00s\xfa\xa4\xa4\xe9\x00\x00\x00")
    expected = b"test"
    assert data == expected

# Generated at 2022-06-22 04:38:01.981484
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            global Impl
            class Impl(Base):
                _args = None

                def initialize(self, *args):
                    self._args = args

                def get_args(self):
                    return self._args

            return Impl

    assert Base().get_args() == ()
    assert Base(1, 2, 3).get_args() == (1, 2, 3)

    class Sub(Base):
        def test_method(self):
            return "foo"

    assert isinstance(Sub(), Base)
    assert not isinstance(Sub(), Sub)
    assert Sub().test_method() == "foo"

    assert isinstance(Sub(), Base)

# Generated at 2022-06-22 04:38:38.436166
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(re.escape(r'\xab\u1234\u20ac\U0010ffff\cF')) == (
        r'\xab\u1234\u20ac\U0010ffff\cF'
    )
    # The following cannot be escaped with re.escape, so it is an error
    # to unescape them.
    with pytest.raises(ValueError):
        re_unescape(r'\a')
    # parentheses are not escaped by re.escape()
    assert re_unescape(r'\(') == r'('
    with pytest.raises(ValueError):
        re_unescape(r'\(')

# For backwards compatibility with older versions of Tornado (and other
# libraries), we define these as functions that simply return their
# arguments.  In Tornado 4

# Generated at 2022-06-22 04:38:45.066672
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    dict = ObjectDict()
    dict.a = "a"
    assert dict.a == "a"
    assert dict["a"] == "a"

# Deprecated alias.
ObjectDict.iteritems = lambda self: self.items()  # type: ignore


# Generated at 2022-06-22 04:38:47.484775
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = GzipDecompressor()
    result = gzip_decompressor.decompress(b'\xff')
    assert result == b''

# Generated at 2022-06-22 04:38:54.888679
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def _initialize(self, a, b):
            self.a = a
            self.b = b

    a = A("abc", 123)
    print(a.a)
    print(a.b)


# Generated at 2022-06-22 04:38:58.953602
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        errno_from_exception(e) == None
    try:
        raise Exception(1,2,3)
    except Exception as e:
        errno_from_exception(e) == 1
    try:
        raise Exception(1)
    except Exception as e:
        errno_from_exception(e) == 1



# Generated at 2022-06-22 04:39:11.509494
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConfigurableImpl(Configurable):
        __impl_class = None  # type: Optional[Type[Configurable]]
        __impl_kwargs = None  # type: Dict[str, Any]
        def __init__(self, *args, **kwargs):
            print('in __init__ of ConfigurableImpl: args = %r, kwargs = %r' % (args, kwargs))
            init_kwargs = {}  # type: Dict[str, Any]
            if self.__class__ is ConfigurableImpl:
                impl = self.__class__.configured_class()
                if ConfigurableImpl.__impl_kwargs:
                    init_kwargs.update(ConfigurableImpl.__impl_kwargs)
            else:
                impl = self.__class__

# Generated at 2022-06-22 04:39:16.434155
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=1)) == 0.001
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60.0
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600.0

# In addition to total_seconds(), two new methods were added to the timedelta
# class in 2.7, seconds and microseconds.  These could be emulated in prior
#

# Generated at 2022-06-22 04:39:20.424578
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(x, y, z):
        pass

    replacer = ArgReplacer(foo, 'z')
    print(replacer.get_old_value((1, 2), {}, None))

# Generated at 2022-06-22 04:39:23.756488
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    x = ObjectDict()
    x.a = 2
    y = ObjectDict()
    y.a = 3
    assert y.a == 3



# Generated at 2022-06-22 04:39:25.409821
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400

