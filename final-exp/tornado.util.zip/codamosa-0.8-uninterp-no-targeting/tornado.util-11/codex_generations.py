

# Generated at 2022-06-22 04:30:17.808372
# Unit test for function exec_in
def test_exec_in():
    # Sigh, python2.6 globals() returns a dict proxy we have to work around.
    if "__builtins__" not in globals():
        # python2.7
        exec_in("def f(): pass", globals())
        f()
    else:
        # python2.6
        glob = {}
        exec_in("def f(): pass", glob)

# Generated at 2022-06-22 04:30:29.423198
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    def _test_init(impl):
        # type: (Type[Configurable]) -> None
        configurable_base().configure(impl)

        # Test that the instance is a subclass of the implementation.
        instance = configurable_base()
        assert isinstance(instance, impl)

        # Test that initialize is an alias to __init__
        assert instance.initialize is instance.__init__

    class Impl(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return configurable_base()

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return self

        def initialize(self):
            # type: () -> None
            pass


# Generated at 2022-06-22 04:30:32.104066
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    from datetime import timedelta

    assert timedelta_to_seconds(timedelta(days=1, seconds=1)) == 86401



# Generated at 2022-06-22 04:30:40.654353
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # Just checks that flush() works
    decompressor = GzipDecompressor()
    compressed_data = (b'\x1f\x8b\x08\x00i\xad6\x06\xff\x6c\xce\xc1\x0a\x84\x20\x0cK'
                       b'\xda\xc2\x03\x00\xad\xed\xb1\x89\t\x00\x00\x00')
    decompressor.decompress(compressed_data)
    result = decompressor.flush()
    assert result == b'foo'



# Generated at 2022-06-22 04:30:51.399531
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c):
        return "do some test"
    
    # get_old_value will return the old value, if the argument is present; otherwise, it will return the given default value
    replacer = ArgReplacer(test_func, "b")
    assert replacer.get_old_value( ["test", "test1", "test3"], {"b": "test"}, default="test2" ) == "test1"
    assert replacer.get_old_value( ["test", "test1", "test3"], default="test2" ) == "test2"
    

# Generated at 2022-06-22 04:30:55.171172
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    self = GzipDecompressor()
    # val = GzipDecompressor.flush()
    self.decompressobj = zlib.decompressobj(16 + zlib.MAX_WBITS)
    return self.decompressobj.flush()


# Generated at 2022-06-22 04:31:03.512800
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():

    # Case 1 -- both positional and keyword arguments
    def test1(a, b, c=1, d=2):
        pass

    # Case 2 -- both positional and keyword varargs
    def test2(*args, **kwargs):
        pass

    # Case 3 -- just positional arguments
    def test3(a, b, c):
        pass

    # Case 4 -- just keyword arguments
    def test4(**kwargs):
        pass

    # Case 5 -- just positional varargs
    def test5(*args):
        pass

    # Case 6 -- just keyword varargs
    def test6(**kwargs):
        pass

    # Case 7 -- neither positional nor keyword arguments
    def test7():
        pass

    # Case 8 -- positional varargs and keyword varargs
    def test8(*args, **kwargs):
        pass

    #

# Generated at 2022-06-22 04:31:04.048703
# Unit test for function doctests
def test_doctests():
    doctests()



# Generated at 2022-06-22 04:31:06.851485
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):
        pass

    A.configure(None)
    a = A()
    assert isinstance(a, A)
    assert A.configured_class() == A
    b = A()
    assert isinstance(b, A)
    assert a is b

# Generated at 2022-06-22 04:31:10.310253
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=0.5)) == 43200
    assert timedelta_to_seconds(datetime.timedelta(days=1.1)) == 94608
    assert timedelta_to_seconds(datetime.timedelta(hours=15.3)) == 54980
    assert timedelta_to_seconds(datetime.timedelta(seconds=50)) == 50
    assert timedelta_to_seconds(datetime.timedelta(microseconds=5000)) == 0.005



# Generated at 2022-06-22 04:31:22.298725
# Unit test for function timedelta_to_seconds

# Generated at 2022-06-22 04:31:26.534587
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=1)) == 0.001
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001
    assert timedelta_to_seconds(
        datetime.timedelta(days=1, seconds=1, microseconds=1)
    ) == 86401.000001
    assert timedelta_to_seconds(
        datetime.timedelta(days=-1, seconds=-1, microseconds=-1)
    ) == -86401.000001



# Generated at 2022-06-22 04:31:34.844351
# Unit test for function errno_from_exception
def test_errno_from_exception():
    ex = Exception()
    assert errno_from_exception(ex) is None
    ex = Exception(2)
    assert errno_from_exception(ex) == 2
    # ex.errno is not set if not specified
    ex = OSError()
    assert errno_from_exception(ex) is None
    # errno of 0 is valid, 1 is not.
    ex = OSError(0)
    assert errno_from_exception(ex) == 0
    ex = OSError(1)
    assert errno_from_exception(ex) == 1



# Generated at 2022-06-22 04:31:38.813219
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d["foo"] = 1
    assert d.foo == 1
    assert d["foo"] == 1
    d.bar = 2
    assert d["bar"] == 2
    assert d.bar == 2



# Generated at 2022-06-22 04:31:42.136450
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict({"a":1, "b":2})
    assert o.a == 1
    assert o.b == 2
    try:
        assert o.c == 3
    except AttributeError as e:
        pass


# Generated at 2022-06-22 04:31:51.185941
# Unit test for function import_object
def test_import_object():
    # Test the happy path.
    obj = import_object("os")
    assert obj is os

    obj = import_object("os.path")
    assert obj is os.path

    obj = import_object("os.path.abspath")
    assert obj is os.path.abspath

    # Test exception handling.
    try:
        import_object("os.path.nonexistent")
    except ImportError:
        pass
    else:
        assert False, "Expected ImportError"

    try:
        import_object("nonexistent")
    except ImportError:
        pass
    else:
        assert False, "Expected ImportError"



# Generated at 2022-06-22 04:31:53.608902
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    failure_count, test_count = doctest.testmod()
    assert failure_count == 0
    assert test_count > 0

# Generated at 2022-06-22 04:31:58.373242
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class _A(Configurable):
        _attr = None  # type: Any

        def initialize(self, attr):
            # type: (Any) -> None
            self._attr = attr

    a = _A("blabla")
    assert a._attr == "blabla"

# Generated at 2022-06-22 04:32:10.586771
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(arg1):
        return arg1
    def func2(arg1, arg2):
        return arg1, arg2
    def func3(arg1, arg2, arg3):
        return arg1, arg2, arg3
    def func4(arg1, arg2, arg3, arg4):
        return arg1, arg2, arg3, arg4
    # Test get_old_value method
    ar1 = ArgumentReplacer(func1, arg1)
    ar2 = ArgumentReplacer(func2, arg2)
    ar3 = ArgumentReplacer(func3, arg3)
    ar4 = ArgumentReplacer(func4, arg4)

# Generated at 2022-06-22 04:32:11.988978
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.foo = 1
    assert d.foo == 1
    assert d['foo'] == 1

# Generated at 2022-06-22 04:32:33.261584
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    fargs = [1,2]
    fkwargs = {'k1': 'a', 'k2': 'b'}
    areplacer = ArgReplacer(lambda x, k1, k2: None, 'x')
    ne = 3
    oe, fargs, fkwargs = areplacer.replace(ne, fargs, fkwargs)
    assert oe is None
    assert fargs == [1,2]
    assert fkwargs == {'k1': 'a', 'k2': 'b'}
    oe, fargs, fkwargs = areplacer.replace(ne, fargs, fkwargs)
    assert oe is None
    assert fargs == [1,2]

# Generated at 2022-06-22 04:32:46.241262
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from collections import OrderedDict, namedtuple
    from inspect import isclass, isfunction

    # Basic test for instantiating an object with two subclasses
    class Foo(Configurable):
        def configurable_base(self):
            return Foo

        def configurable_default(self):
            return SubFoo1

        def initialize(self, a=None, b=None):
            self.a, self.b = a, b

    class SubFoo1(Foo):
        pass

    class SubFoo2(Foo):
        pass

    f1 = Foo(a='A', b='B')
    assert isinstance(f1, Foo)
    assert isinstance(f1, SubFoo1)
    assert not isinstance(f1, SubFoo2)
    assert f1.a == 'A' and f

# Generated at 2022-06-22 04:32:50.043448
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # Arrange
    gzip_decompressor = GzipDecompressor()
    max_length = 0
    value=""

    # Act
    output = gzip_decompressor.decompress(value, max_length)

    # Assert
    assert output != None

# Generated at 2022-06-22 04:32:54.426135
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(1, 2, 3)) == 86400 + 2 + 3e-6


# Only available in Python 3.3+

# Generated at 2022-06-22 04:33:01.164881
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # type: () -> None
    msg = 'foo'
    exc = TimeoutError(msg)
    assert str(exc) == msg
    assert "foo" in str(exc)


# The name of this variable is only to make it a unique name in the module
# There is no official alias for TimeoutError anymore
TimeoutError = TimeoutError  # type: Union[Type[TimeoutError], Type[TimeoutError]]
TimeoutError.__module__ = 'tornado.util'
TimeoutError.__qualname__ = 'TimeoutError'
TimeoutError.__doc__ = (
    'Exception raised by `.with_timeout` and `.IOLoop.run_sync`.\n\n'
    '.. deprecated:: 5.0\n'
    '   Renamed to `tornado.util.TimeoutError`\n'
)
TimeoutError.__

# Generated at 2022-06-22 04:33:14.028305
# Unit test for function import_object
def test_import_object():
    import sys
    import unittest
    sys.modules["assert"] = None
    assert import_object('assert') is unittest.assert_
    del sys.modules["assert"]


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).
if str is unicode_type:
    def u(s: str) -> str:
        return s


elif str is bytes:
    def u(s: str) -> str:
        return s.decode("unicode_escape")


# Generated at 2022-06-22 04:33:21.840435
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado import gen
    from tornado.testing import AsyncTestCase

    class TestGzipDecompressor(AsyncTestCase):
        @gen.coroutine
        def test_flush(self):
            value = b'\x1f\x8b\x08\x00\x00\x00\x00\x00'
            decompressor = GzipDecompressor()
            data = decompressor.decompress(value, max_length=10)
            self.assertEqual(b'', decompressor.unconsumed_tail)
            self.assertEqual(b'', data)
            self.assertRaises(IOError, decompressor.flush)
            value1 = b'\x00\x03\x00\x03\x00\x00\x00\x00'
            data1 = decompressor.dec

# Generated at 2022-06-22 04:33:32.950431
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("abc") == "abc"
    assert re_unescape("\\a\\b\\c") == "abc"
    assert re_unescape(r"\\0\n\r\\") == "\0\n\r\\"
    assert re_unescape(re.escape("abc")) == "abc"
    assert re_unescape(re.escape(re.escape("abc"))) == "abc"
    assert re_unescape(re.escape("\\0\n\r\\")) == "\\0\n\r\\"
    with pytest.raises(ValueError):
        re_unescape(re.escape("\0\n\r\\"))

# Generated at 2022-06-22 04:33:36.125110
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d["attr"] = "value"
    assert d.attr == "value"
    assert d["attr"] == "value"
    # method __getattr__ raises AttributeError
    try:
        d.no_such_attr
        assert False  # pragma: no cover
    except AttributeError:
        pass



# Generated at 2022-06-22 04:33:37.210865
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()
    TimeoutError("foo")



# Generated at 2022-06-22 04:33:56.517406
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import zlib

    # Create a test file with both zlib and gzip headers
    c = zlib.compressobj()
    body = b"hello"
    compressed = c.compress(body) + c.flush()
    gz_hdr = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff"
    f = gz_hdr + compressed + body

    # Read it with GzipDecompressor
    g = GzipDecompressor()
    assert g.decompress(f) == (compressed + body)
    assert g.flush() == body

# common regular expressions
_TYPE_SIGS = r"(?:(?:\([^\)]*\)\s*|[^{])*?)"

# Generated at 2022-06-22 04:34:01.368483
# Unit test for function exec_in
def test_exec_in():
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'b': 200, 'd': 400, 'e': 500}
    exec_in('a = 15', globals, locals)
    assert globals['a'] == 1
    assert locals['a'] == 15



# Generated at 2022-06-22 04:34:04.348724
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from inspect import signature
    assert signature(Configurable.__new__).parameters['cls'].annotation == typing.Type['Configurable']

# Generated at 2022-06-22 04:34:06.326972
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ArgsKwargs(Configurable):
        pass
test_Configurable___new__()


# Generated at 2022-06-22 04:34:18.112559
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    """Check if the replacement of argument is done correctly"""

    def func(arg_one, arg_two):
        pass

    def func_one(arg_one, arg_two=()):
        pass

    def func_two(arg_one, *args, **kwargs):
        pass

    arg_replacer = ArgReplacer(func, "arg_one")
    arg_replacer.replace(None, (1, 2), {})
    assert arg_replacer.get_old_value((1, 2), {}) == 1

    arg_replacer = ArgReplacer(func_one, "arg_two")
    arg_replacer.replace((), (1,), {})
    assert arg_replacer.get_old_value((1,), {}) == ()


# Generated at 2022-06-22 04:34:20.482752
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    od = ObjectDict()
    od["a"] = 1
    print(od.a)
    print(od.b)


# Generated at 2022-06-22 04:34:32.775536
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return B

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        def initialize(self):
            # type: () -> None
            pass

    class C(A):
        def initialize(self):
            # type: () -> None
            pass

    assert A()
    assert isinstance(A(), A)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    assert isinstance(B(), A)

# Generated at 2022-06-22 04:34:44.240407
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import binascii
    def test_decompressor(input_value: bytes, expected_output: bytes,
                          max_length: int) -> None:
        d = GzipDecompressor()
        output = d.decompress(input_value, max_length)
        assert output == expected_output
        assert d.unconsumed_tail == b""
        output += d.flush()
        assert output == expected_output
    test_decompressor(binascii.a2b_hex(b"1f8b080000000000000bcb4bcc4db57db16e170099a4bad608000000"),
                      b"123456789", 9)

# Generated at 2022-06-22 04:34:52.726274
# Unit test for function re_unescape
def test_re_unescape():
    # type: () -> None
    def check(s: str) -> None:
        assert re_unescape(re.escape(s)) == s
        try:
            re_unescape(s)
            assert False, "expected ValueError"
        except ValueError:
            pass

    check("a")
    check("ab")
    check("a\nb")
    check("a\\nb")
    check(r"a\\")
    check(r"a\\\b")
    check(r"\a\\\b")
    check(r"a\t")
    check(r"a\+")
    check(r"a\$")
    check(r"a\(")
    check(r"a\)")
    check(r"a\[]")
    check(r"a\*")
    check

# Generated at 2022-06-22 04:35:01.494972
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from unittest import mock

    class ConfigurableSub(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableSub

        @classmethod
        def configurable_default(cls):
            return ConfigurableSub

    class ConfigurableSubImpl(ConfigurableSub):
        @classmethod
        def configurable_base(cls):
            return ConfigurableSub

        @classmethod
        def configurable_default(cls):
            return ConfigurableSubSub

    class ConfigurableSubSub(ConfigurableSub):
        pass

    # An exception class to use in the next case
    class InitError(Exception):
        pass

    class ConfigurableSubImpl2(ConfigurableSub):
        @classmethod
        def configurable_base(cls):
            return ConfigurableSub


# Generated at 2022-06-22 04:35:23.630849
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    data = b'hello world'
    compressed = zlib.compress(data)
    assert zlib.decompress(compressed, 42) == data
    d = GzipDecompressor()
    part1 = d.decompress(compressed[:5])
    part2 = d.decompress(compressed[5:10])
    part3 = d.decompress(compressed[10:])
    assert part1 == part2 == part3 == data
    assert d.unconsumed_tail == b''



# Generated at 2022-06-22 04:35:35.072190
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=None, c=None, *args, **kwargs):
        pass
    args = (1, 2, 3, 4, 5)
    kwargs = {"d": 6}
    arg = ArgReplacer(func, "a")
    assert arg.get_old_value(args, kwargs) == 1
    arg = ArgReplacer(func, "b")
    assert arg.get_old_value(args, kwargs) is None
    arg = ArgReplacer(func, "c")
    assert arg.get_old_value(args, kwargs) is None
    arg = ArgReplacer(func, "d")
    assert arg.get_old_value(args, kwargs) is None
    
    kwargs = {"b": 6}

# Generated at 2022-06-22 04:35:46.738822
# Unit test for constructor of class Configurable
def test_Configurable():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return D

        def initialize(self):
            pass

    class D(C):
        def initialize(self):
            pass

    assert issubclass(C.configured_class(), C)
    assert issubclass(D.configured_class(), C)
    assert C.configured_class() is D
    assert D.configured_class() is D

    C.configure("tornado.util.Configurable")
    assert C.configured_class().__name__ == "Configurable"
    assert issubclass(C.configured_class(), C)
    assert issubclass(D.configured_class(), C)
    assert C

# Generated at 2022-06-22 04:35:58.236109
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    o = ArgReplacer(lambda a, b: True, "a")
    old_value, args, kwargs = o.replace("new_value", (1, 2), {})
    assert old_value == 1
    assert args == ("new_value", 2)
    assert kwargs == {}

    old_value, args, kwargs = o.replace("new_value", (), {"a": 1})
    assert old_value == 1
    assert args == ()
    assert kwargs == {"a": "new_value"}

    old_value, args, kwargs = o.replace("new_value", (), {})
    assert old_value is None
    assert args == ()
    assert kwargs == {"a": "new_value"}



# Generated at 2022-06-22 04:36:02.957498
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(5)) == 432000
    assert timedelta_to_seconds(datetime.timedelta(0, 1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(1, 1, 42, 100, 1000)) == 86401.0421



# Generated at 2022-06-22 04:36:08.738832
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    class TestObjectDict(ObjectDict):
        pass
    od = TestObjectDict()
    od.attr = 1
    od['attr'] = 2
    assert od.attr == 2
    assert od['attr'] == 2


# Generated at 2022-06-22 04:36:18.561761
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    G = GzipDecompressor()
    assert G.decompress(b"") == b""
    assert G.decompress(b"\x1f\x8b") == b""
    assert G.decompress(b"\x8b\x1f") == b""
    assert G.decompress(b"\x1f\x8b\x08\x08") == b""
    assert G.decompress(b"\x1f\x8b\x08\x08JOTA\x03\x03\x00\x00\x00\x00\x00\x00\x00\t\x00\x03\xf3\n\x00\x00\x00\x00") == b""

# Generated at 2022-06-22 04:36:31.775948
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from inspect import getfullargspec
    import operator 
    # pos args
    @ArgReplacer(sum, 'start')
    def sum_replacer(a, start=0):
        return a

    assert sum_replacer(1, start=2) == 1
    assert sum_replacer(1, start=3) == 2
    # kwargs
    @ArgReplacer(sum, 'start')
    def sum_replacer2(a, **kwargs):
        return a

    assert sum_replacer2(1, start=2) == 1
    assert sum_replacer2(1, start=3) == 2


# TODO: this is only used in tests and shouldn't be public

# Generated at 2022-06-22 04:36:40.019249
# Unit test for function import_object
def test_import_object():
    from .testing import AsyncTestCase
    from tornado.ioloop import IOLoop

    class TestModule(object):
        pass

    module = TestModule()
    module.attr = IOLoop
    for name in ("attr", "tornado.ioloop.IOLoop"):
        imported = import_object(name)
        assert imported is IOLoop

    try:
        import_object("tornado.nothing")
        self.fail("expected ImportError")
    except ImportError:
        pass

    import_object("tests.import_test")  # defined above



# Generated at 2022-06-22 04:36:50.573507
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from unittest.mock import patch
    from inspect import getfullargspec, signature

    # this is a bit hacky, and might be fragile because it depends on what
    # python does rather than what the interface guarantees
    def check_configurable_init():
        py_initialize_sig = getfullargspec(Configurable.initialize.__func__)
        py_initialize_kwargs = py_initialize_sig.args[1:]
        py_initialize_defaults = py_initialize_sig.defaults or tuple()
        py_initialize_kwdefaults = py_initialize_sig.kwonlydefaults or {}

        def mock_initialize(self, *args, **kwargs):
            pass


# Generated at 2022-06-22 04:37:34.503124
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3, strerror='err')
    except Exception as e:
        assert errno_from_exception(e) == 3


_DEFAULT = object()

# Get stack frame and function name for logging

# Generated at 2022-06-22 04:37:41.180858
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, 'input/output error')
    except OSError as e:
        assert errno_from_exception(e) == 5
        assert e.errno == 5
        e = OSError(5, 'input/output error')
        assert errno_from_exception(e) == 5
        e = OSError()
        assert errno_from_exception(e) is None


# Generated at 2022-06-22 04:37:43.044658
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d['name'] = 'abc'
    assert d.name == 'abc'

# Generated at 2022-06-22 04:37:44.093280
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(1, 2, 3)) == 86400 + 2 + 3e-6



# Generated at 2022-06-22 04:37:47.450607
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d=ObjectDict()
    d['hung']='Mặt trời mọc'
    assert d['hung']==d.hung


# Generated at 2022-06-22 04:37:56.423253
# Unit test for function re_unescape
def test_re_unescape():
    # We don't need to test every possible input here; we just need
    # to verify that the simple types we want to use this
    # function with work as expected.
    for s, expected in [
        ("", ""),
        ("\\a", "a"),
        ("\\\\", "\\"),
        ("\\*", "*"),
        ("\\(", "("),
        ("\\?", "?"),
        ("\\x5e", "^"),
        ("\\x20", " "),
        ("\\x", "x"),
        ("\\1", "1"),
        ("\\\\", "\\"),
    ]:
        assert re_unescape(s) == expected



# Generated at 2022-06-22 04:38:02.503923
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def do_replace(self, name, new_value):
        arg_replacer = ArgReplacer(self, name)
        old_value = arg_replacer.get_old_value(self.args, self.kwargs)
        self.args, self.kwargs = arg_replacer.replace(new_value, self.args, self.kwargs)
        return old_value
    return do_replace


# Generated at 2022-06-22 04:38:13.703591
# Unit test for function errno_from_exception
def test_errno_from_exception():
    from errno import EPERM, EACCES, EAGAIN

    assert errno_from_exception(Exception(EPERM)) == EPERM
    assert errno_from_exception(Exception((EPERM, "msg"))) == EPERM
    assert errno_from_exception(IOError(EPERM, "msg")) == EPERM
    assert errno_from_exception(IOError(EACCES, "msg")) == EACCES
    assert errno_from_exception(Exception()) is None
    assert errno_from_exception(Exception((EAGAIN,))) == EAGAIN
    assert errno_from_exception(Exception(None)) is None
    assert errno_from_exception(Exception((None,))) is None

# Generated at 2022-06-22 04:38:24.170988
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from unittest import mock

    # Configurable's __init__ calls initialize.
    # This can only happen after a lot of work has been done
    # to set up __impl_class and __impl_kwargs, but if initialize
    # is going to be called, that should have been done.
    # This unit test relies on the fact that Configurable's
    # __new__ is declared before initialize in the class def;
    # otherwise it would go into an infinite loop.

    class Foo(Configurable):
        _initialized = False

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self, a, b, c=None):
            self._initialized = True

# Generated at 2022-06-22 04:38:30.126771
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    def helper(obj):
        # type: (ObjectDict) -> None
        obj.foo = "hello"
        obj.bar = 123
    o = ObjectDict()
    helper(o)
    assert o.foo == "hello"
    assert o.bar == 123



# Generated at 2022-06-22 04:38:59.782345
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyClass(Configurable):
        configurable_base = staticmethod(lambda: MyClass)
        configurable_default = staticmethod(lambda: MyImpl)

        @classmethod
        def create(cls, *args, **kwargs):
            # type: (*Any, **Any) -> MyClass
            instance = cls(*args, **kwargs)
            return instance

        def _initialize(self, **kwargs):
            self.initialized_with = kwargs


    class MyImpl(MyClass):
        pass


    conf = MyImpl.create(a=1, b=2)
    assert conf.initialized_with == {"a": 1, "b": 2}



# Generated at 2022-06-22 04:39:05.895103
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return C

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            raise NotImplementedError()

    class D(C):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return D

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return

    C.configure(None)
    D.configure(None)

    C._initialize()
    # make sure calling the _initialize method of a base class doesn't
    #

# Generated at 2022-06-22 04:39:06.788584
# Unit test for function exec_in
def test_exec_in():
    exec_in("foo = 42", {})



# Generated at 2022-06-22 04:39:12.759426
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # type: ignore
    assert TimeoutError("test_message")
    assert TimeoutError("test_message", object())
    assert TimeoutError("test_message", object(), object())

# Alias to make migration easier.  We'll eventually move toward
# uniformly using this exception, but it's not there yet.
Timeout = TimeoutError


# Generated at 2022-06-22 04:39:18.138913
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    rep = ArgReplacer(f, "b")
    assert rep.replace(42, (1, 2, 3), {}) == (2, (1, 42, 3), {})
    assert rep.replace(42, (1, 2, 3), {'b': 100}) == (2, (1, 2, 3), {'b': 42})


# Generated at 2022-06-22 04:39:23.262060
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        try:
            raise TypeError()
        except TypeError:
            raise_exc_info(sys.exc_info())
    except:
        pass
    else:
        raise Exception("should have raised an exception")



# Generated at 2022-06-22 04:39:32.440313
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.test.util_test import DummyConfigurable

    class DummyClass_1(DummyConfigurable):
        pass

    class DummyClass_2(DummyConfigurable):
        pass

    c = DummyClass_2()
    if not isinstance(c, DummyClass_1):
        raise ValueError

    DummyClass_2.configure(DummyClass_1)
    c = DummyClass_2()
    if not isinstance(c, DummyClass_1):
        raise ValueError

    c = DummyClass_1()
    if not isinstance(c, DummyClass_1):
        raise ValueError



# Generated at 2022-06-22 04:39:38.025027
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    class MockSelf(ObjectDict):
        """Mock object for self in __setattr__"""

    self = MockSelf()
    self['a'] = 1
    assert self['a'] == 1

    self.a = 2
    assert self.a == 2

    self.b = self.a
    assert self.b == 2



# Generated at 2022-06-22 04:39:42.289774
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=1):
        pass

    replacer = ArgReplacer(func, "c")

    (x, y, z) = replacer.get_old_value((1, 2),{})
    assert z==1



# Generated at 2022-06-22 04:39:44.606600
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b):
        pass
    ar = ArgReplacer(f, "a")
    return ar.replace(1, (2,), {})