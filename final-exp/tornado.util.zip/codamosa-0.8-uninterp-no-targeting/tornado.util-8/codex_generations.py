

# Generated at 2022-06-22 04:30:13.235531
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def __init__(self):
            self.got_kwargs = False
            self.got_args = False
            
        def initialize(self, *args, **kwargs):
            self.got_kwargs = True
            self.got_args = True
            
    a = A()
    assert a.got_kwargs == True
    assert a.got_args == True
    assert isinstance(a, A)


# Generated at 2022-06-22 04:30:16.806216
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-22 04:30:28.408942
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class ConfigurableClass(Configurable):
        @classmethod
        def configurable_base(cls):
        # type: () -> Type[Configurable]
            return ConfigurableClass

        @classmethod
        def configurable_default(cls):
        # type: () -> Type[Configurable]
            return ConfigurableClass

        def initialize(self, *args, **kwargs):
        # type: (Any, Any) -> None
            self.args = args
            self.kwargs = kwargs

    # Check that initialize is called
    cf = ConfigurableClass()
    assert cf.args == ()
    assert cf.kwargs == {}

    # Check that configure works
    class Subclass(ConfigurableClass):
        pass
    ConfigurableClass.configure(Subclass)
    assert ConfigurableClass

# Generated at 2022-06-22 04:30:39.807386
# Unit test for function import_object
def test_import_object():
    from tornado.escape import utf8
    assert import_object("tornado.escape") is import_object("tornado.escape")
    assert import_object("tornado.escape") is import_object("tornado.escape")
    assert import_object("tornado.escape") == import_object("tornado.escape")
    assert import_object("tornado.escape.utf8") == utf8
    assert import_object("tornado.escape") is import_object("tornado")
    try:
        import_object("tornado.missing_module")
        assert False, "did not get expected exception"
    except ImportError as e:
        assert str(e).startswith("No module named")

_BYTE_MASK = 0x7f
_UTF8_REPLACEMENT = 0xfffd



# Generated at 2022-06-22 04:30:42.533911
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 24 * 3600.0



# Generated at 2022-06-22 04:30:45.423495
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    assert isinstance(TimeoutError("hello"), TimeoutError)
    assert str(TimeoutError("hello")) == "hello"



# Generated at 2022-06-22 04:30:51.788604
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # type: () -> None
    gzipper = GzipDecompressor()
    uncompressed = b"Good morning, Dr. Chandra. This is Hal.\nI am ready for my first lesson today."
    compressed = zlib.compress(uncompressed)
    assert gzipper.decompress(compressed) == uncompressed


# Dummy class for contextvars

# Generated at 2022-06-22 04:31:02.624908
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        try:
            assert False
        except:
            raise_exc_info(sys.exc_info())
    except AssertionError:
        pass


try:
    from traceback import StackSummary

    _get_stack_summary = StackSummary.StackSummary.extract
except ImportError:
    StackSummary = None

    if typing.TYPE_CHECKING:
        # For mypy
        def _get_stack_summary(
            f: Any,  # type: Any
        ) -> Any:
            # type: (...) -> Any
            pass
else:

    def _get_stack_summary(f):
        return StackSummary.extract(f, limit=1, lookup_lines=True)



# Generated at 2022-06-22 04:31:14.476190
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=1, b=2)
    assert d['a'] == 1
    assert d.a == 1
    assert d.b == 2
    d.c = 3
    assert d['c'] == 3
    try:
        d.d
        assert False
    except AttributeError:
        pass

_COMMON_DOC_FLAGS = (
    """
    .. versionchanged:: 4.0
       Has no effect on Tornado itself but is provided for compatibility
       with ``asyncio``.
    """ +
    _COMMON_DOC_FLAGS
)


# Generated at 2022-06-22 04:31:24.890538
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado.testing import LogTrapTestCase, AsyncTestCase
    from tornado.escape import utf8
    from tornado.util import GzipDecompressor
    
    class _GzipDecompressorTest(LogTrapTestCase, AsyncTestCase):
        def test_flush(self):
            decompressor = GzipDecompressor()
            self.assertEqual(decompressor.decompress(b'\x1f\x8b\x08\x00'), b'')
            self.assertEqual(decompressor.flush(), b'')
            decompressor = GzipDecompressor()
            self.assertEqual(decompressor.decompress(b'\x1f\x8b\x00\x00'), b'')
            self.assertEqual(decompressor.flush(), b'')

# Generated at 2022-06-22 04:31:35.703624
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import inspect
    import logging
    orig = logging.getLogger("tornado.test").handle

# Generated at 2022-06-22 04:31:47.522033
# Unit test for function errno_from_exception
def test_errno_from_exception():
    """Test of tornado.util.errno_from_exception()"""
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(5)
    except Exception as e:
        assert errno_from_exception(e) == 5
    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(5)
    except IOError as e:
        assert errno_from_exception(e) == 5
    try:
        raise IOError('error test')
    except IOError as e:
        assert errno_from_exception(e) == 0



# Generated at 2022-06-22 04:31:53.544566
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import random
    import string
    def test_function(a, b, c):
        return a, b, c

    args = [1, 2, 3]
    def rand_string():
        return ''.join(random.choice(string.ascii_uppercase) for _ in range(5))
    kwargs = {rand_string(): rand_string() for _ in range(5)}
    for arg_name in ('a', 'b', 'c'):
        replacer = ArgReplacer(test_function, arg_name)
        old_value = replacer.get_old_value(args, kwargs)
        assert old_value == args[replacer.arg_pos]



# Generated at 2022-06-22 04:31:59.373234
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f():
        pass

    ra = ArgReplacer(f, 'self')
    self.assertEqual(ra.name, 'self')
    self.assertEqual(ra.arg_pos, None)

    def f2(self, a):
        pass

    ra = ArgReplacer(f2, 'self')
    self.assertEqual(ra.name, 'self')
    self.assertEqual(ra.arg_pos, 0)

    def f3(a, self):
        pass

    ra = ArgReplacer(f3, 'self')
    self.assertEqual(ra.name, 'self')
    self.assertEqual(ra.arg_pos, 1)

    def f4(a, self, b):
        pass

    ra = ArgReplacer(f4, 'self')
    self

# Generated at 2022-06-22 04:32:11.884842
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b=3):
        pass

    arg_replacer = ArgReplacer(f, 'a')
    old_value, args, kwargs = arg_replacer.replace(10, (1,), {"b": 4})
    assert old_value == 1
    assert args == (10, )
    assert kwargs == {"b": 4}

    old_value, args, kwargs = arg_replacer.replace(10, (), {"a": 1})
    assert old_value == 1
    assert args == ()
    assert kwargs == {"a": 10}

    old_value, args, kwargs = arg_replacer.replace(10, (), {})
    assert old_value is None
    assert args == ()
    assert kwargs == {"a": 10}



# Generated at 2022-06-22 04:32:18.655144
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class MyException(Exception):
        def __init__(self, args):
            self.args = args

    try:
        raise MyException([1])
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise MyException([])
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-22 04:32:23.687762
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Base(Configurable):
        # type: (...) -> Any
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

        def initialize(self, name, *args, **kwargs):
            self.name = name



# Generated at 2022-06-22 04:32:33.306124
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_fn(arg1, arg2, arg3=None):
        pass
    arg_replacer = ArgReplacer(test_fn, "arg1")
    assert arg_replacer.get_old_value((1, 2), {}) == 1
    arg_replacer = ArgReplacer(test_fn, "arg3")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {"arg2": 3}) is None
    assert arg_replacer.get_old_value((1, 2), {"arg3": 3}) == 3

# Generated at 2022-06-22 04:32:37.553923
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # [test_ObjectDict___setattr__]
    a = ObjectDict()
    # It is possible to create new attributes
    a.new_attr = 5
    assert a.new_attr == 5
    # [test_ObjectDict___setattr__]



# Generated at 2022-06-22 04:32:39.144652
# Unit test for function import_object
def test_import_object():
    import_object('os').path is os.path



# Generated at 2022-06-22 04:32:55.219888
# Unit test for function exec_in
def test_exec_in():
    # We may be using exec as a keyword
    exec = exec_in
    ns = {}
    exec("x = 6", ns)
    assert ns["x"] == 6

test_exec_in()  # type: ignore



# Generated at 2022-06-22 04:33:00.763952
# Unit test for function raise_exc_info
def test_raise_exc_info():  # pragma: nocover
    def f():
        try:
            do_test()
        except Exception as e:
            return e
        else:
            return None
    def do_test():
        raise ValueError("should get this one")

    e = f()
    assert isinstance(e, ValueError)
    e = f()
    assert isinstance(e, ValueError)
    try:
        raise ValueError("testing")
    except:
        e = f()
    assert isinstance(e, ValueError)
    e = f()
    assert isinstance(e, ValueError)



# Generated at 2022-06-22 04:33:06.918939
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    m = ObjectDict()
    m.firstname = "Mike"
    assert m.firstname == "Mike"
    m["lastname"] = "Smith"
    assert m.lastname == "Smith"

    try:
        m.lastname2
        assert False, "Should not be here"
    except AttributeError:
        pass



# Generated at 2022-06-22 04:33:14.160975
# Unit test for function raise_exc_info
def test_raise_exc_info():
    exc_info = (None, TypeError('test'), None)
    def inner():
        raise_exc_info(exc_info)
    # TODO: figure out how to typecheck a function that doesn't return
    #inlineCallbacks(inner)()
    try:
        inner()
        assert(False)
    except TypeError as e:
        assert(str(e) == 'test')


# Fake byte literal for python 2.5

# Generated at 2022-06-22 04:33:22.010363
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import json, logging
    import tornado.escape
    import tornado.log
    from functools import wraps
    from types import MethodType

    class DefaultClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return DefaultClass

        @classmethod
        def configurable_default(cls):
            return DefaultClass.ConfiguredDefault

        def _initialize(self):
            pass

        class ConfiguredDefault(Configurable):
            @classmethod
            def configurable_base(cls):
                return DefaultClass

            @classmethod
            def configurable_default(cls):
                pass

            def _initialize(self):
                pass

    class OtherClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return OtherClass


# Generated at 2022-06-22 04:33:33.415062
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Impl(object):
        initialized_with = None  # type: Dict[str, Any]

        def __init__(self, **kwargs):
            self.initialized_with = kwargs

    class Base(Configurable):
        def initialize(self, **kwargs):
            self.initialized_with = kwargs

        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Impl

    # no configuration, returns default class
    x = Base()
    assert isinstance(x, Impl)
    assert x.initialized_with == {}

    # configure and construct with keyword arguments
    Base.configure(Impl, x=1)
    x = Base()
    assert isinstance(x, Impl)

# Generated at 2022-06-22 04:33:43.499663
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test1(a, b, c, d=1, e=2, f=3):  # type: ignore
        pass

    ar = ArgReplacer(test1, "d")
    assert ar.replace("new_d", (1, 2, 3), {}) == ((1, 2, 3), {'e': 2, 'f': 3, 'd': 'new_d'})
    assert ar.replace("new_d", (1, 2, 3), {'e': 2, 'f': 3, 'd': 'old_d'}) == ('old_d', (1, 2, 3), {'e': 2, 'f': 3, 'd': 'new_d'})


# Generated at 2022-06-22 04:33:48.999367
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()

# deprecated alias for TimeoutError
# .. versionadded:: 4.0
gen_TimeoutError = TimeoutError
TimeoutError = gen_TimeoutError

# deprecated alias for TimeoutError
# .. versionadded:: 4.0
ioloop_TimeoutError = TimeoutError
TimeoutError = ioloop_TimeoutError



# Generated at 2022-06-22 04:33:51.740876
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    """
    def __getattr__(self, name: str) -> Any
    """
    pass


# Generated at 2022-06-22 04:33:56.092916
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c=3, *d, **e):
        pass
    arg_replacer = ArgReplacer(foo, "d")
    assert arg_replacer.get_old_value([1, 2, 3, 4], {}) == (4,)
    arg_replacer = ArgReplacer(foo, "e")
    assert arg_replacer.get_old_value([1, 2, 3, 4], {'e': 5}) == 5
    arg_replacer = ArgReplacer(foo, "f")
    assert arg_replacer.get_old_value([1, 2, 3, 4], {}) == None

# Generated at 2022-06-22 04:34:06.416615
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.x = "ABC"
    assert obj["x"] == "ABC"
    obj.obj_attr = None
    assert obj.obj_attr is None


# Generated at 2022-06-22 04:34:08.870417
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    td = datetime.timedelta(days=1, seconds=1, microseconds=1)
    assert timedelta_to_seconds(td) == 86401.000001

# Generated at 2022-06-22 04:34:21.192713
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # ArgReplacer correctly finds the parameter in kwargs
    def func(a, b, c=5, d=6, e=7):
        return (a, b, c, d, e)
    m = ArgReplacer(func, "a")
    assert m.get_old_value([0, 0], {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}) == 1
    assert m.get_old_value([0, 0], {"b": 2, "c": 3, "d": 4, "e": 5}) == 0

    # ArgReplacer correctly finds the parameter in args
    def func(a, b, c=5, d=6, e=7):
        return (a, b, c, d, e)

# Generated at 2022-06-22 04:34:23.676378
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, "ENFILE")
    except OSError as e:
        assert errno_from_exception(e) == 5



# Generated at 2022-06-22 04:34:35.648536
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=3, d=4):
        pass

    a = ArgReplacer(f, "c")

    #     def test_get_old_value(self, args, kwargs, default, result):
    #         assert a.get_old_value(args, kwargs, default) == result
    #     yield test_get_old_value, (1, 2, 3, 4), {}, None, 3
    #     yield test_get_old_value, (1, 2), {}, None, None
    #     yield test_get_old_value, (1, 2), {"c": 5}, None, 5

    def test_replace(args, kwargs, new_value, expected_old_value, expected_args, expected_kwargs):
        old_value, args, kwargs

# Generated at 2022-06-22 04:34:39.502404
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=59)) == 59.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=1)) == 1.000001



# Generated at 2022-06-22 04:34:43.226006
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError
    except Exception as ex:
        assert ex.args is None
        assert str(ex) == 'Timeout'



# Generated at 2022-06-22 04:34:48.487407
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None, d=None):
        pass
    f_replacer = ArgReplacer(f, 'b')
    args = ['A', 'B', 'C']
    kwargs = {'d': 'D'}
    old_value, args, kwargs = f_replacer.replace('new_b', args, kwargs)
    assert old_value == 'B'
    assert args == ['A', 'new_b', 'C']
    assert kwargs == {'d': 'D'}

# Generated at 2022-06-22 04:34:51.379927
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()

# Generated at 2022-06-22 04:34:52.423748
# Unit test for function doctests
def test_doctests():
    pass

# Generated at 2022-06-22 04:35:15.521514
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    """Test get_old_value method of ArgReplacer class
    """
    
    arg_replacer = ArgReplacer(lambda x, y=None, *args, **kwargs : None, "y")
    assert arg_replacer.get_old_value((1,), dict(), None) == None
    
    arg_replacer = ArgReplacer(lambda x, y=None, *args, **kwargs : None, "y")
    assert arg_replacer.get_old_value((1,), dict(y=5), None) == 5
    
    arg_replacer = ArgReplacer(lambda x, y=None, *args, **kwargs : None, "y")
    assert arg_replacer.get_old_value((1,), dict(y=5), 1) == 5


# Generated at 2022-06-22 04:35:26.964154
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

        def __init__(self, foo, bar):
            # type: (str, int) -> None
            self.foo = foo
            self.bar = bar

    class B(A):
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[B]
            return B

        def __init__(self, foo, bar):
            # type: (str, int) -> None
            super(B, self).__init__(foo, bar)


# Generated at 2022-06-22 04:35:28.547987
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    assert ObjectDict().__setattr__('test', 'test') == None
    return



# Generated at 2022-06-22 04:35:40.390329
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    d = ObjectDict()
    d.hello = "world"
    assert d["hello"] == "world"

    d["hello"] = "universe"
    assert d.hello == "universe"

    def test_setattr_exception(name: Optional[str] = None) -> None:
        # type: () -> None
        object().__setattr__(name, None)
        try:
            d.__setattr__(name, None)
            assert False
        except AttributeError:
            pass
        try:
            d[name] = None
            assert False
        except KeyError:
            pass

    test_setattr_exception(None)
    test_setattr_exception(1)
    test_setattr_exception(())
    test_setattr_

# Generated at 2022-06-22 04:35:49.838273
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        try:
            raise Exception()
        except:
            exc_info = sys.exc_info()
    finally:
        # Clear the traceback reference from our stack frame to
        # minimize circular references that slow down GC.
        exc_info = (None, None, None)
    try:
        raise_exc_info(exc_info)
    except Exception:
        pass
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass



# Generated at 2022-06-22 04:35:51.778897
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a = ObjectDict()
    a.x = 'a'
    print(a.x)

# Generated at 2022-06-22 04:35:55.921188
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    suite = doctests()
    # Skipping test_escape.py because it does not work on all Python versions
    suite.addTests(unittest.defaultTestLoader.loadTestsFromName(__name__))
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)

# Generated at 2022-06-22 04:36:08.948355
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import inspect
    import warnings
    import pytest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.select import SelectIOLoop

    class MyLoop(Configurable):
        def __init__(self):
            # type: () -> None
            self.initialized = True

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return MyLoop

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return SelectIOLoop

    def test_configurable_class(cls, subclass, impl=None, **kwargs):
        # type: (Type[Configurable], Optional[Type[Configurable]], Any) -> None
        saved = cls._save_config

# Generated at 2022-06-22 04:36:09.814961
# Unit test for function exec_in
def test_exec_in():
    scope = {}
    exec_in("x = 42", scope)
    assert scope["x"] == 42



# Generated at 2022-06-22 04:36:15.562686
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import binascii
    import zlib
    data = b'\x1f\x8b\x08\x08\xc3\x6b\x0e\x51\x00\x03\x73\x6b\x6f\x6c\x73\x74\x72\x65\x61\x6d\x74\x72\x61\x73' \
           b'\x68\x2e\x6c\x6f\x67\x00\xa3\xaf\xc1\x0c\x00\x00\x00'
    g = GzipDecompressor()
    r = g.decompress(data)
    assert r == b'skolstreamtramtrash.log'
    r = g.flush()

# Generated at 2022-06-22 04:36:41.351455
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.foo = 1
    if d.foo != 1:
        raise AssertionError("%r" % d.foo)
    try:
        d.bar
    except AttributeError as e:
        pass
    else:
        raise AssertionError("")



# Generated at 2022-06-22 04:36:50.761921
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError('timeout')
    except TimeoutError as e:
        assert "timeout" in str(e)  # type: ignore
    else:
        assert False, 'TimeoutError not raised'


TimeoutError = TimeoutError  # type: ignore

# Inheritance diagram:
#
#     object
#       |
#      Exception
#       |
#   TimeoutError
#
# Aliased for backwards compatibility.
# https://www.python.org/dev/peps/pep-0484/#runtime-or-type-checking
gen_exc = TimeoutError
TimeoutError = TimeoutError

Configurable = object  # type: ignore

type_gen = None  # type: Optional[Type]  # Set by `tornado.gen`
type_type = type  # type: Type[Any]

# Generated at 2022-06-22 04:36:55.821633
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    exc = TimeoutError()
    assert exc.args == ()
    exc = TimeoutError('timeout after 42')
    assert exc.args == ('timeout after 42',)


# Backwards compatibility aliases.
Timeout = TimeoutError
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-22 04:36:59.085009
# Unit test for function exec_in
def test_exec_in():
    d = {'a': 1}
    b = {'b': 2}

    exec_in("assert a == 1; b = 3", d, b)
    assert d == {'a': 1}
    assert b == {'b': 2, 'b': 3}



# Generated at 2022-06-22 04:37:10.267951
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyConfigurable

        @classmethod
        def configurable_default(cls):
            return MyConfigurableImplementation

        def _initialize(self):
            pass

    class MyConfigurableImplementation(MyConfigurable):
        def _initialize(self, foo, bar='baz'):
            self.foo = foo
            self.bar = bar

    MyConfigurable.configure(None)
    # Positional argument
    MyConfigurable(123).foo == 123
    # Keyword argument
    MyConfigurable(foo=456).foo == 456
    # Keyword argument with default
    MyConfigurable(foo=456).bar == 'baz'



# Generated at 2022-06-22 04:37:11.433842
# Unit test for function import_object
def test_import_object():
    assert import_object("os") is os



# Generated at 2022-06-22 04:37:21.149690
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise socket.error(errno.EIO, "I/O error")
    except socket.error as e:
        assert(errno_from_exception(e) == errno.EIO)
    try:
        raise socket.error("I/O error")
    except socket.error as e:
        assert(errno_from_exception(e) == "I/O error")
    try:
        raise socket.error
    except socket.error as e:
        assert(errno_from_exception(e) == None)


# Generated at 2022-06-22 04:37:30.249715
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class SomeExc(Exception):
        pass

    class SomeExc1(Exception):

        def __init__(self, msg: str, errno: int) -> None:
            self.msg = msg
            self.errno = errno

    class SomeExc2(Exception):

        def __init__(self, msg: str) -> None:
            self.msg = msg

    class SomeExc3(Exception):

        def __init__(self, errno: int) -> None:
            self.errno = errno

    class SomeExc4(Exception):
        pass

    assert errno_from_exception(Exception()) is None
    assert errno_from_exception(SomeExc()) is None
    assert errno_from_exception(SomeExc1("msg", None)) == None

# Generated at 2022-06-22 04:37:34.877986
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    try:
        raise TimeoutError()
    except TimeoutError:
        pass


from concurrent.futures import Future as _Future
  # type: ignore

from tornado import gen
from tornado import stack_context



# Generated at 2022-06-22 04:37:44.670680
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    #
    # This function's type annotation must use comments instead of
    # real annotations because typing.NoReturn does not exist in
    # python 3.5's typing module. The formatting is funky because this
    # is apparently what flake8 wants.
    try:
        try:
            raise Exception("foo")
        except Exception:
            raise_exc_info(sys.exc_info())
    except Exception as e:
        assert e.args[0] == "foo"


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
#

# Generated at 2022-06-22 04:38:14.788762
# Unit test for function exec_in
def test_exec_in():  # type: ignore
    def check_exec_in():  # type: ignore
        x = 1  # noqa
        exec_in('x = 2', globals())
        assert x == 2
    check_exec_in()



# Generated at 2022-06-22 04:38:20.729322
# Unit test for function exec_in
def test_exec_in():
    # Execute a statement
    d = dict(a=1)
    exec_in('b = a + 1', d)
    assert d['b'] == 2
    # Execute a function
    exec_in('def f():\n return a + 1', d)
    assert d['f']() == 2
    # Execute a class
    exec_in('class Dummy(object):\n pass', d)
    assert d['Dummy'] is not None



# Generated at 2022-06-22 04:38:23.608071
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(0, "fake error")
    except IOError as e:
        errno = errno_from_exception(e)
        assert bool(errno)



# Generated at 2022-06-22 04:38:29.434536
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def __init__(self, *args: Any, **kwargs: Any) -> None: pass

    test_configurable = TestConfigurable()
    test_configurable.initialize(1, 2, 3, 4)



# Generated at 2022-06-22 04:38:30.813050
# Unit test for function import_object
def test_import_object():
    import_object('tornado.test.util_test')



# Generated at 2022-06-22 04:38:34.376482
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        try:
            1 / 0
        except:
            raise_exc_info(sys.exc_info())
    except ZeroDivisionError:
        pass
    else:
        assert False, "did not re-raise exception"



# Generated at 2022-06-22 04:38:37.542259
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    pass

    def __delattr__(self, name: str) -> None:
        try:
            del self[name]
        except KeyError:
            raise AttributeError(name)



# Generated at 2022-06-22 04:38:49.597536
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    d = GzipDecompressor()
    assert b"" == d.decompress(b"\x1f\x8b")
    assert b"foo" == d.decompress(b"\x08\x00\x00\x00\x00\x00\x00\x00\x03\x00f")
    assert b"foo" == d.flush()

    d = GzipDecompressor()
    assert b"foo" == d.decompress(b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x03\x00f")
    assert b"foo" == d.flush()

    d = GzipDecompressor()

# Generated at 2022-06-22 04:38:51.924735
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(4, 5.3)) == 345.3



# Generated at 2022-06-22 04:38:58.338070
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    g = GzipDecompressor()
    if(bytes("") != g.decompress(bytes(""))):
        assert False
    g = GzipDecompressor()
    if(bytes("") != g.decompress(bytes(""),max_length=1)):
        assert False
    g = GzipDecompressor()
    if(bytes("") != g.flush()):
        assert False
    return True

