

# Generated at 2022-06-22 04:30:13.017154
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    # One day
    assert timedelta_to_seconds(datetime.timedelta(1)) == 86400
    # One microsecond
    assert timedelta_to_seconds(datetime.timedelta(0, 0, 1)) == 0.000001


if not hasattr(datetime.timedelta, "total_seconds"):  # type: ignore
    timedelta_to_seconds = timedelta_to_seconds



# Generated at 2022-06-22 04:30:22.732371
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(re.escape("a1_")) == "a1_"
    assert re_unescape(re.escape("a_1")) == "a_1"
    assert re_unescape(re.escape("a|1")) == "a|1"
    assert re_unescape(re.escape("a1|")) == "a1|"
    assert re_unescape(re.escape("a1+")) == "a1+"
    assert re_unescape(re.escape("a1?")) == "a1?"
    assert re_unescape(re.escape("a1$")) == "a1$"
    assert re_unescape(re.escape("a1^")) == "a1^"
    assert re_unescape(re.escape("a1.")) == "a1."

# Generated at 2022-06-22 04:30:33.779200
# Unit test for function exec_in
def test_exec_in():
    def test_scope():
        locals()
    d1 = dict(a=1)
    exec_in("b=2", d1)
    assert d1["b"] == 2
    exec_in("c=a", d1)
    assert d1["c"] == 1
    d2 = {}
    exec_in("d=1", globals(), d2)
    assert d2["d"] == 1
    exec_in("e=1; f=e+1", globals(), d2)
    assert d2["e"] == 1 and d2["f"] == 2
    exec_in("import sys", d2)
    # The code module is available in the global namespace
    assert d2["sys"] is sys
    exec_in("h=len('hi')", d2)
    assert d2["h"] == 2

# Generated at 2022-06-22 04:30:37.510794
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():

    try:
        z_Var_a = {}
        z_Var_a.__setattr__("z_Var_b", 0)
        z_Var_a.__getattr__("z_Var_b")
    except Exception:
        pass


# Generated at 2022-06-22 04:30:50.322001
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    compress = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
    compress.write(b'1234567890')
    result = compress.flush()

    decompress = GzipDecompressor()
    assert decompress.decompress(result) == b'1234567890'
    assert decompress.unconsumed_tail == b''
    assert decompress.flush() == b''


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).

# Generated at 2022-06-22 04:30:59.993697
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("test") == "test"
    assert re_unescape("\\.test") == "\\.test"
    assert re_unescape("test\\*") == "test\\*"
    assert re_unescape("test\\*(a)\\\\\\?") == "test\\*(a)\\\\\\?"
    assert re_unescape(r"\\\d") == r"\\\d"
    assert re_unescape(r"\\\D") == r"\\\D"
    assert re_unescape(r"\\\s") == r"\\\s"
    assert re_unescape(r"\\\S") == r"\\\S"
    assert re_unescape(r"\\\w") == r"\\\w"
    assert re_unescape(r"\\\W") == r

# Generated at 2022-06-22 04:31:05.732788
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-22 04:31:18.118552
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(*args, **kwargs):
        print(args, kwargs)
    old, new = 1, 2
    a = ArgReplacer(func, 'arg')
    assert a.replace(new, (old, ), {}) == (old, (new, ), {})
    old, new = 2, 1
    b = ArgReplacer(func, 'arg')
    assert b.replace(new, (), {'arg': old}) == (old, (), {'arg': new})
    old, new = 3, 4
    c = ArgReplacer(func, 'arg')
    assert c.replace(new, (1, 2), {'arg': old}) == (old, (1, 2), {'arg': new})
    old, new = 4, 3
    d = ArgReplacer(func, 'arg')
    assert d

# Generated at 2022-06-22 04:31:20.380610
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    foo = ObjectDict({'foo': 'bar'})
    if foo.foo != 'bar':
        assert False


# Generated at 2022-06-22 04:31:25.271665
# Unit test for constructor of class Configurable
def test_Configurable():
    class MyInterface(Configurable):
        pass

    class MyBaseImpl(MyInterface):
        def __init__(self, arg1, arg2, arg3):
            self.initialize(arg1, arg2, arg3)

        def initialize(self, arg1, arg2, arg3):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3

        @classmethod
        def configurable_base(cls):
            return MyInterface

        @classmethod
        def configurable_default(cls):
            return MyBaseImpl

    MyInterface.configure("tests.util.MyBaseImpl", arg2=5)
    my_interface = MyInterface(arg1=1, arg3=3)
    assert my_interface.arg1 == 1

# Generated at 2022-06-22 04:31:37.377977
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # test the decompress method of class GzipDecompressor
    import zlib
    decompressor = GzipDecompressor()
    gzip_txt = zlib.compress(b'Hello, world!')
    assert decompressor.decompress(gzip_txt) == b'Hello, world!'



# Generated at 2022-06-22 04:31:44.845229
# Unit test for function raise_exc_info

# Generated at 2022-06-22 04:31:53.570540
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gzip_decompressor = GzipDecompressor()
    assert gzip_decompressor
    # test a case when the uncompressed data is larger than the compressed data
    obj = "foo"
    comp_obj = zlib.compress(obj.encode("utf-8"))
    uncomp_obj = gzip_decompressor.decompress(comp_obj)
    assert uncomp_obj == obj.encode("utf-8")
    # test a case when the compressed data is larger than the uncompressed data
    obj = "Hello World"
    comp_obj = zlib.compress(obj.encode("utf-8"))
    uncomp_obj = gzip_decompressor.decompress(comp_obj)
    assert uncomp_obj == obj.encode("utf-8")
    # test a case when there are some uncons

# Generated at 2022-06-22 04:32:03.114707
# Unit test for constructor of class Configurable

# Generated at 2022-06-22 04:32:06.680408
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def test_equal(expected, actual):
        assert expected == actual, "expected %s, but got %s" % (expected, actual)
    dict_ = ObjectDict()
    dict_.x = 1
    expected = 1
    actual = dict_.x
    test_equal(expected, actual)
    dict_.x = 2
    actual = dict_.x
    test_equal(expected, actual)


# Generated at 2022-06-22 04:32:12.855120
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    """
    >>> TimeoutError()
    Traceback (most recent call last):
    ...
    TypeError: __init__() missing 1 required positional argument: 'reason'
    >>> TimeoutError('some reason')
    Traceback (most recent call last):
    ...
    TypeError: __init__() takes 1 positional argument but 2 were given
    """
    e = TimeoutError('some reason')
    assert str(e) == 'some reason', repr(str(e))

# Create aliases for consistency
gen_TimeoutError = TimeoutError



# Generated at 2022-06-22 04:32:25.341345
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    assert ObjectDict()
    assert ObjectDict().__class__ is ObjectDict
    assert ObjectDict(a=1).a == 1
    assert ObjectDict(a=1, b=2).b == 2
    assert ObjectDict(**dict(a=1, b=2)).b == 2
    assert ObjectDict(a=1, b=2, c=3).items() == [('a', 1), ('b', 2), ('c', 3)]

    o = ObjectDict(a=1, b=2, c=3)
    assert not hasattr(o, 'd')
    o.d = 4
    assert o.d == 4
    assert o['d'] == 4
    del o.d
    assert not hasattr(o, 'd')


# Generated at 2022-06-22 04:32:37.470236
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    replacer_a = ArgReplacer(func, "a")
    replacer_b = ArgReplacer(func, "b")
    replacer_c = ArgReplacer(func, "c")


    def test_1(actual, expected):
        assert actual == expected, f"assert failed with actual value of {actual} and expected value of {expected}"

    def test_2(actual, expected):
        assert actual == expected, f"assert failed with actual value of {actual} and expected value of {expected}"


    old_value, args, kwargs = replacer_b.replace(1, (2, 3), {})
    test_1(old_value, 3)
    test_1((args, kwargs), ((2, 1), {}))
    old

# Generated at 2022-06-22 04:32:43.482880
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d['a'] = 1
    assert d.a == 1  # type: ignore
    assert not hasattr(d, 'b')  # type: ignore
    with assert_raises(AttributeError):
        d.b  # type: ignore


# Generated at 2022-06-22 04:32:47.757174
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    def f(**kwargs: Any) -> None:  # type: ignore
        f.d = ObjectDict(kwargs)

    f(a=1, b=2)
    assert f.d.a == 1
    assert f.d.b == 2



# Generated at 2022-06-22 04:33:08.549306
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=5, d=10):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    result = arg_replacer.get_old_value((1, 2), {'d': 3})
    assert result == 5
    result = arg_replacer.get_old_value((1, 2), {'d': 3}, 10)
    assert result == 5
    result = arg_replacer.get_old_value((1, 2), {'d': 3}, 1)
    assert result == 5
    result = arg_replacer.get_old_value((1, 2), {'d': 3}, 20)
    assert result == 5
    result = arg_replacer.get_old_value((1, 2), {}, 10)
    assert result == 10
    result = arg

# Generated at 2022-06-22 04:33:18.788669
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=3, d=4, *args, **kwargs):
        return a, b, c, d, args, kwargs

    replacer = ArgReplacer(test_func, "d")
    assert(replacer.get_old_value((1, 2), {}) == 4)
    assert(replacer.get_old_value((1, 2), {}, 0) == 0)
    assert(replacer.get_old_value((1, 2), {"d": 5}) == 5)

    # Test replacements
    assert(replacer.replace(9, (1, 2), {}) == (4, (1, 2), {"d": 9}))

# Generated at 2022-06-22 04:33:29.207551
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\ ") == " "
    assert re_unescape(r"\a") == "a"
    assert re_unescape(r"\A") == "A"
    assert re_unescape(r"\Z") == "Z"
    assert re_unescape(r"\\") == "\\"
    assert re.match(re_unescape(r"a\+b\\c\(de\)\.\|\?\*\Z"), "a+b\\c(de).|?*Z")
    assert re_unescape(r"\d") == r"\d"
    assert re_unescape(r"\\d") == "\\d"
    with pytest.raises(ValueError):
        re_unescape(r"\d")

# Generated at 2022-06-22 04:33:36.207407
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    f = lambda x: x
    replacer = ArgReplacer(f, 'x')
    assert replacer.get_old_value(((1,), {}), default=2) == 1
    assert replacer.get_old_value(((), {}), default=2) == 2
    assert replacer.get_old_value(((), {'x': 1}), default=2) == 1
    assert replacer.get_old_value(((1,2,3), {}), default=2) == 1
    assert replacer.get_old_value(((), {'x': 1}), default=2) == 1
    assert replacer.get_old_value(((), {'y': 1}), default=2) == 2
    assert replacer.get_old_value(((), {}), default=2) == 2


# Generated at 2022-06-22 04:33:42.115183
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    assert ArgReplacer(lambda: None, "foo").arg_pos is None
    assert ArgReplacer(lambda foo: None, "foo").arg_pos == 0
    assert ArgReplacer(lambda bar, foo: None, "foo").arg_pos == 1
    assert ArgReplacer(lambda foo, bar=None: None, "foo").arg_pos == 0
    assert ArgReplacer(lambda foo=None, bar=None: None, "foo").arg_pos is None
    # Keyword-only args in python 3
    assert ArgReplacer(lambda *, foo=None: None, "foo").arg_pos is None
    assert ArgReplacer(lambda *args, foo=None: None, "foo").arg_pos is None
    assert ArgReplacer(lambda *args, bar, foo=None: None, "foo").arg_pos == 1
   

# Generated at 2022-06-22 04:33:45.765819
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.test = True
    assert(obj.test == True)
test_ObjectDict___getattr__()

# Generated at 2022-06-22 04:33:57.269846
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self, a, b=42, *, c=42, **kwargs):
            pass

    class Impl1(Base):

        def _initialize(self, a, b, c, d, **kwargs):
            pass

    class Impl2(Base):

        def _initialize(self, a, b, c, e, **kwargs):
            pass

    with Base.configure("tornado.test.util.Impl2", **{"e": 1}):
        o = Base(1, 2, d=3)  # type: ignore

# Generated at 2022-06-22 04:34:08.472597
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    with open(os.devnull, "rb") as f:
        f.write(GzipDecompressor().decompress(
            b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\xf3\x48\xcd\xc9\xc9"
            b"\xe7\x02\x00\x49\x18\xcf\x08\x00\x00\x00"))



# Generated at 2022-06-22 04:34:20.738692
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.escape import utf8, native_str
    @gen_test
    def _f():
        import io
        import gzip
        # Test data taken from reading gzipped files in the wild.
        #   - encoding == 'utf-8'
        with io.BytesIO(utf8(
            '\x1f\x8b\x08\x08\x1d\xab\x96\xdf\x02\xff\xcd\xcb\xccN\x05\x00+I-.\x1b\x00\x03\x00')) as gz_file:
            gz = gzip.GzipFile(fileobj=gz_file)
            data = native_str(gz.read())

# Generated at 2022-06-22 04:34:31.335874
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class TestErrnoException(Exception):

        def __init__(self, e, *args, **kwargs):
            self.errno = e
            Exception.__init__(self, e, *args, **kwargs)

    # Test an exception that has errno as the argument
    assert errno_from_exception(TestErrnoException(42)) == 42

    # Test an exception that has errno as an attribute
    assert errno_from_exception(
        TestErrnoException(42, "test")) == 42

    # Test an exception that has no errno
    class TestNoErrnoException(Exception):
        pass

    assert errno_from_exception(
        TestNoErrnoException()) is None



# Generated at 2022-06-22 04:34:48.021885
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        async def test_flush(self):
            decompressor = GzipDecompressor()
            with open(__file__, "rb") as file:
                while True:
                    block = await file.read(1024)
                    if not block:
                        break
                    decompressor.decompress(block)

            self.assertEqual(decompressor.flush(), b"")

    gzip_decompressor_flush_test = TestCase()
    gzip_decompressor_flush_test.test_flush()



# Generated at 2022-06-22 04:35:00.032792
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(10)) == 10 * 24 * 3600


# TimeoutError did not exist before 3.3.
contextlib.suppress(AttributeError, message="'module' object has no attribute 'TimeoutError'").__enter__()  # type: ignore

if not hasattr(contextlib, "nullcontext"):
    # The contextlib.nullcontext() method was added in Python 3.7.
    # Copied from the Python 3.7.2 standard library.
    @contextlib.contextmanager
    def nullcontext(enter_result: Any = None) -> Iterator[Any]:
        yield enter_result

    contextlib.nullcontext = nullcontext


# TODO: replace these with the (more efficient) implementations from the
# concurrent.futures source

# Generated at 2022-06-22 04:35:09.422919
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer._getargnames(func) == ['a', 'b', 'c']
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 3}, default=4) == 1
    assert arg_replacer.get_old_value((), {'a': 1}, default=4) == 1
    assert arg_replacer.get_old_value((), {'d': 1}, default=4) == 4

# Generated at 2022-06-22 04:35:17.518984
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=2)) == 2.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=2, microseconds=1)) == 2.000001

# Python 2.6 requires simplejson, not the stdlib json module.
if sys.version_info < (2, 7):
    import simplejson as json
else:
    import json

if sys.version_info >= (3,):
    import io
    import urllib.parse
    import urllib.request

    from urllib.parse import urlparse
    import builtins
    exec_in = getattr(builtins, "exec")

    _U = typing.TypeVar("_U", bound=type(u""))  # noqa: F8

# Generated at 2022-06-22 04:35:27.387518
# Unit test for constructor of class Configurable
def test_Configurable():
    # pylint: disable=too-many-lines

    # This test is not run by the unit testing framework because it is
    # important enough to test directly in the interactive interpreter.
    # This test is a bit long because it needs to test multiple levels
    # of configuration, to make sure the recursive configuration
    # works.

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return ADefault

        def initialize(self, a_arg):
            # type: (str) -> None
            self.a_arg = a_arg

    class ADefault(A):
        def initialize(self, a_arg):
            # type: (str) -> None
            self.a_default_arg = a_

# Generated at 2022-06-22 04:35:39.057904
# Unit test for constructor of class Configurable
def test_Configurable():
    sub = Configurable()

    class SubConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return SubConfigurable

        @classmethod
        def configurable_default(cls):
            return sub

    # We do not need to test the Configurable class because it is abstract
    # with two unimplemented methods
    try:
        sub.configurable_base()
        raise AssertionError("sub.configurable_base() failed")
    except NotImplementedError:
        pass

    try:
        sub.configurable_default()
        raise AssertionError("sub.configurable_default() failed")
    except NotImplementedError:
        pass

    assert isinstance(sub, Configurable)
    assert not isinstance(sub, SubConfigurable)

# Generated at 2022-06-22 04:35:46.584695
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(days=10)) == 10 * 24 * 3600
    assert timedelta_to_seconds(datetime.timedelta(days=-10)) == -10 * 24 * 3600



# Generated at 2022-06-22 04:35:50.475099
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    dict_ = ObjectDict()  # type: ObjectDict
    dict_.abc = 123
    assert dict_.abc == 123



# Generated at 2022-06-22 04:35:54.268938
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()



# Generated at 2022-06-22 04:36:07.344216
# Unit test for method __new__ of class Configurable

# Generated at 2022-06-22 04:36:25.489914
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    # This test is in this file because of circular dependencies.
    from .httpserver import HTTPRequest

    def method(self, a, b, c=None):
        pass

    r = ArgReplacer(method, "a")
    assert r.get_old_value((0, 1, 2), {}) == 0
    assert r.get_old_value((), {"b": 1, "a": 0, "c": 2}) == 0
    assert r.get_old_value((), {"b": 1, "c": 2}) is None
    assert r.get_old_value((), {}, 1) == 1
    for new_v in (0, "1", object()):
        old_v, args, kwargs = r.replace(new_v, (1, 2), {"c": 3})

# Generated at 2022-06-22 04:36:30.304931
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, *args, **kwargs):
        pass

    AR = ArgReplacer(f, "b")
    assert AR.arg_pos == 1
    assert AR.get_old_value((1, 2, 3, 4), {}) == 2



# Generated at 2022-06-22 04:36:34.675629
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.httpclient import HTTPRequest
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Configurable

    request = HTTPRequest('http://www.google.com')
    Foo(request)


# Generated at 2022-06-22 04:36:47.253810
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class DefaultTestConfigurable(Configurable):
        def configurable_base(self):
            return self
        def configurable_default(self):
            return self
    obj = DefaultTestConfigurable()
    assert isinstance(obj, DefaultTestConfigurable)

    # We can specify an alternative
    class Impl(DefaultTestConfigurable):
        pass
    DefaultTestConfigurable.configure(Impl)
    obj2 = DefaultTestConfigurable()
    assert isinstance(obj2, Impl)

    # And we can specify None to use the default
    DefaultTestConfigurable.configure(None)
    obj3 = DefaultTestConfigurable()
    assert isinstance(obj3, DefaultTestConfigurable)

    # But not anything else
    with pytest.raises(ValueError):
        DefaultTestConfigurable.configure(object())


# Generated at 2022-06-22 04:36:50.278227
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    """Unit test for method __setattr__ of class ObjectDict.
    """
    item = ObjectDict()  # type: ObjectDict[str, Any]
    item.a = 1
    assert item.a == 1



# Generated at 2022-06-22 04:37:00.698306
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        def __init(self):
            pass
    A.configure(None)
    assert A.configured_class() == A
    a = A()
    assert isinstance(a, A)
    class B(A):
        def __init__(self):
            pass
    A.configure(B)
    assert A.configured_class() == B
    a = A()
    assert isinstance(a, B)
    b = B()
    assert isinstance(b, B)
    class C(A):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    A.configure(C)
    assert A.configured_class() == C



# Generated at 2022-06-22 04:37:07.201250
# Unit test for function errno_from_exception
def test_errno_from_exception():

    try:
        raise Exception()
    except Exception as e:
        errno = errno_from_exception(e)
    assert errno is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        errno = errno_from_exception(e)
    assert errno == 1

    try:
        raise Exception(errno=1)
    except Exception as e:
        errno = errno_from_exception(e)
    assert errno == 1



# Generated at 2022-06-22 04:37:08.623861
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    test_runner = unittest.TextTestRunner(stream=IOLoop.current().io_loop.handle)
    test_runner.run(doctests())



# Generated at 2022-06-22 04:37:12.481937
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError()
    except ValueError:
        info = sys.exc_info()
        assert info[0] == ValueError
        raise_exc_info(info)
    assert False, "should have raised ValueError"

# Generated at 2022-06-22 04:37:17.880979
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=3.8)) == 3.8
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=-5.295e8)) == -52950000



# Generated at 2022-06-22 04:37:43.431256
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError("message")
    except Exception as e:
        assert e.args == ("message",)

TimeoutError.__module__ = "tornado.util"



# Generated at 2022-06-22 04:37:49.057808
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    d = ObjectDict()
    d.a = 1
    assert d['a'] == 1
    assert d.a == 1
    assert hasattr(d, 'b') is False
    d['b'] = 2
    assert d['b'] == 2
    assert d.b == 2
    assert hasattr(d, 'b') is True



# Generated at 2022-06-22 04:37:54.302844
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    assert issubclass(TimeoutError, Exception)
    try:
        TimeoutError()
    except Exception:
        pass


# compatibility aliases
TimeoutError = TimeoutError  # type: Type[TimeoutError]
TimeoutError = TimeoutError  # type: Type[TimeoutError]
TimeoutError = TimeoutError  # type: Type[TimeoutError]



# Generated at 2022-06-22 04:38:03.085767
# Unit test for function exec_in
def test_exec_in():
    f_globals = {"x": 1}
    exec_in('assert x == 1', f_globals)
    exec_in('assert y == 2', f_globals, {'y': 2})
    exec_in('assert x == 3 and y == 3', f_globals, {'x': 3, 'y': 3})
execute_asserts_re = re.compile(
    r'\b(?:assert|raise)\b|^\s*(?:return|break|continue)\b'
)
exec_in_re = re.compile(
    r'\b(?:exec)\b'
)


# Generated at 2022-06-22 04:38:06.011843
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    assert decompressor.decompress(b'hello') == b'hello'
    assert decompressor.flush() == b''
    assert decompressor.unconsumed_tail == b''


# Generated at 2022-06-22 04:38:09.332434
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    # This line of code is my test
    d.x = 1
    assert d['x'] == d.x



# Generated at 2022-06-22 04:38:11.353223
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # pragma: no cover
    try:
        raise TimeoutError()
    except Exception:
        pass



# Generated at 2022-06-22 04:38:13.400399
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(
        datetime.timedelta(days=1, hours=2, minutes=3, seconds=4, microseconds=5)
    ) == 93784.00005



# Generated at 2022-06-22 04:38:23.784552
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_function(a, b):
        pass
    replaced_arg = ArgReplacer(test_function, "a")
    old_arg, new_args, new_kwargs = replaced_arg.replace("new_a", (1, 2), {"b": 3})
    assert new_args == ("new_a", 2)
    assert new_kwargs == {"b": 3}
    assert old_arg == 1
    
    old_arg, new_args, new_kwargs = replaced_arg.replace("new_a", (1, 2, 3), {"b": 3})
    assert new_args == (1, 2, 3)
    assert new_kwargs == {"b": 3, "a": "new_a"}
    assert old_arg is None
    # Reversed
    old_arg, new_args, new

# Generated at 2022-06-22 04:38:33.788694
# Unit test for function errno_from_exception
def test_errno_from_exception():
    orig_errno = 13
    try:
        raise IOError
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError("Some err message")
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(orig_errno)
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == orig_errno
        assert isinstance(e, IOError)
        assert e.args[0] == errno



# Generated at 2022-06-22 04:39:09.000479
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    import inspect
    def func1(a, b, c=3, d=4, *args):
        pass
    def func2(a, b, e, *args, **kwargs):
        pass

# Generated at 2022-06-22 04:39:10.687867
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado._multipart import _parse_content_disposition


# Generated at 2022-06-22 04:39:12.715066
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj['b'] = 1
    assert obj.b == 1



# Generated at 2022-06-22 04:39:24.529350
# Unit test for function doctests
def test_doctests():
    # type: () -> None

    def check_doctest(module: ModuleType) -> None:
        # Get the test suite for the doctests in the given module.
        doctests = doctest.DocTestSuite(module)
        # Turn the tests into a list and iterate over them,
        # so that they are actually run.
        for test in list(doctests):
            # This is a hack, but can't think of a better way to
            # handle doctests with no examples (or all ignored
            # examples).
            if isinstance(test, doctest.DocTestCase):
                if not test.examples:
                    continue
            # Run the test.
            test.runTest()

    check_doctest(util)
    check_doctest(platform.version_info)



# Generated at 2022-06-22 04:39:35.946564
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    x = ObjectDict()
    x.a = 42
    x.b = 'foo'


# The `__repr__` method is only supported in newer versions of
# Python, so we fall back to `__str__` if it doesn't exist.
# In addition, use the same format for instances and subclasses,
# so `str(Exception('foo'))` works the same in Python 2 and
# Python 3 (though it still fails in Python 3 if Exception
# is a subclass rather than a direct class).
#
# This formatter also handles unicode strings on both
# Python 2 (where they are the default) and Python 3
# (where plain strings are the default and unicode
# strings must be marked specially).
# Type ignored because this is only used in a @classmethod

# Generated at 2022-06-22 04:39:41.354279
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    g = GzipDecompressor()
    g.decompress(b'x\x9c\xcbH\xcd\xc9\xc9W\x08\xcf/\xcaIQ\x04\x00\x1d\xf2\x03\x00\x00')
    assert g.flush() == b'foo'


# Generated at 2022-06-22 04:39:48.945201
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o.a = 1
    assert o.a == 1
    o.a = 2
    assert o.a == 2
    assert o['a'] == 2
    o['a'] = 3
    assert o['a'] == 3
    assert o.a == 3
    # Make sure that __getattr__ doesn't interfere with __getitem__'s
    # behavior, since __getitem__ is needed for pickle to work.
    try:
        o[object()] = None
        assert False, "did not raise error"
    except TypeError:
        pass

