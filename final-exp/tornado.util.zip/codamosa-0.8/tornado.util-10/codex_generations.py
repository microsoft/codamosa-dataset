

# Generated at 2022-06-12 14:16:38.721381
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b=1, c=2):
        assert a == 1
        assert b == 2
        assert c == 3
    assert ArgReplacer(f, "b").replace(2, (1,), {}) == (1, (1,), {})
    assert ArgReplacer(f, "c").replace(3, (1,), {}) == (2, (1,), {})
    assert ArgReplacer(f, "a").replace(10, (1,), {}) == (1, (10,), {})
    assert ArgReplacer(f, "b").replace(20, (1,), {}) == (None, (1,), {"b": 20})

# Generated at 2022-06-12 14:16:41.361237
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import_object('tornado.escape') is tornado.escape
    import_object('tornado.escape.utf8') is tornado.escape.utf8
    import_object('tornado') is tornado
    import_object('tornado.missing_module')


# Generated at 2022-06-12 14:16:42.526346
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-12 14:16:51.353615
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import inspect
    class WithArgs(internals.Configurable):
        @classmethod
        def configurable_base(cls):
            return WithArgs
        @classmethod
        def configurable_default(cls):
            return WithArgs
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    WithArgs.configure(WithArgs, a='a', b='b', c='c')
    @typing.no_type_check
    class TestWithArgs(unittest.TestCase):
        def test_1(self):
            with_args = WithArgs() # type: ignore
            self.assertEqual(with_args.a, 'a')

# Generated at 2022-06-12 14:16:53.736997
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConfigurableTest(Configurable):
        pass
    ConfigurableTest.configure(ConfigurableTest)
    ins = ConfigurableTest()
    assert ins is not None

# Generated at 2022-06-12 14:17:00.024203
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import typing
    import unittest
    import unittest.mock

    mock_super_new = unittest.mock.MagicMock()
    mock_super_new.side_effect = lambda *args, **kwargs: args[0]
    mock_initialize = unittest.mock.MagicMock()
    class ConfigurableSubclass(Configurable):
        configurable_base = lambda: ConfigurableSubclass
        configurable_default = lambda: ConfigurableSubclass
        initialize = mock_initialize

        @classmethod
        def configured_class(cls):
            return ConfigurableSubclass

    mock_super_new.side_effect = lambda *args, **kwargs: args[0]

# Generated at 2022-06-12 14:17:06.881615
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class AsyncHTTPClient(Configurable):
        configurable_default = object
        configurable_base = object

    class AsyncHTTPClientSubclass(AsyncHTTPClient):
        pass

    old_client = AsyncHTTPClient.configured_class()

    AsyncHTTPClient.configure("tornado.test.util.AsyncHTTPClientSubclass")
    assert AsyncHTTPClient.configured_class() is AsyncHTTPClientSubclass

    c = AsyncHTTPClient()
    assert isinstance(c, AsyncHTTPClientSubclass)

    AsyncHTTPClient.configure(None)
    assert AsyncHTTPClient.configured_class() is old_client


# Generated at 2022-06-12 14:17:08.397717
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def initialize(self, *args, **kwargs):
            pass
    assert Foo()


# Generated at 2022-06-12 14:17:14.723236
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c, d=None):
        pass

    replacer = ArgReplacer(test_func, 'b')
    # The arguments aren't passed as positional arguments
    assert replacer.get_old_value((1, 2, 3), {'b': 2, 'd': 3}) == 2
    # The argument is passed as positional argument while the keyword
    # argument is specified
    assert replacer.get_old_value((1, 2, 3), {'d': 3}) == 2
    # The argument is passed as positional argument while the keyword
    # argument isn't specified
    assert replacer.get_old_value((1, 2, 3), {}) == 2
    # The argument is not passed at all
    assert replacer.get_old_value((1, 3), {}) == None
    # Try another

# Generated at 2022-06-12 14:17:16.934444
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import _io



# Generated at 2022-06-12 14:17:32.284351
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a):
        pass
    a = ArgReplacer(func, "a")
    old, args, kwargs = a.replace(1, (2, ), {})
    assert old == 2
    assert args == (1, )
    assert kwargs == {}
    def func(a, b, c, d=5):
        pass
    a = ArgReplacer(func, "d")
    old_a, args, kwargs = a.replace(7, (0, ), {})
    assert old_a == 5
    assert args == (0, )
    assert kwargs == {"d": 7}
    old_a, args, kwargs = a.replace(8, (0, ), {"d": 6})
    assert old_a == 6
    assert args == (0, )
    assert k

# Generated at 2022-06-12 14:17:42.695728
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():

    class DummyConfigurable(Configurable):
        # Testing the API for Configurable
        @classmethod
        def configurable_base(cls):
            return DummyConfigurable

        @classmethod
        def configurable_default(cls):
            return DummyConfigurable

        def _initialize(self, mandatory: str, optional: str = "default") -> None:
            self.initialized = True
            self.mandatory = mandatory
            self.optional = optional

    DummyConfigurable.configure(DummyConfigurable)
    obj = DummyConfigurable("mandatory")
    assert(obj.initialized == True)
    assert(obj.mandatory == "mandatory")
    assert(obj.optional == "default")

    obj = DummyConfigurable("mandatory", "overridden")
    assert(obj.initialized == True)
   

# Generated at 2022-06-12 14:17:45.214233
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()  # type: ObjectDict
    o['1'] = 1
    assert o.__getattr__('1') == 1


# Generated at 2022-06-12 14:17:55.162665
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def testfunc(a, b=None):
        pass
    func = ArgReplacer(testfunc, "b")
    old_value, args, kwargs = func.replace("new", (1,), {})
    assert old_value is None
    assert args == (1,)
    assert kwargs == {"b": "new"}
    old_value, args, kwargs = func.replace("new", (1, 2), {})
    assert old_value is 2
    assert args == (1, "new")
    assert kwargs == {}
    old_value, args, kwargs = func.replace("new", (), {})
    assert old_value is None
    assert args == ()
    assert kwargs == {"b": "new"}

# Generated at 2022-06-12 14:18:02.579158
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) is e.errno # type: ignore

    try:
        raise IOError(5)
    except Exception as e:
        assert errno_from_exception(e) == 5

    try:
        raise IOError("something happened")
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise TypeError()
    except Exception as e:
        assert errno_from_exception(e) is None


# Generated at 2022-06-12 14:18:10.559110
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class Base(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return Base

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, foo):
            self.foo = foo

    class Sub(Base):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return Sub

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, bar, **kwargs):
            kwargs["foo"] = "foo"
            super().initialize(**kwargs)
            self

# Generated at 2022-06-12 14:18:12.590358
# Unit test for function import_object
def test_import_object():
    _object = import_object("unittest.TestCase")
    assert _object == unittest.TestCase


# Generated at 2022-06-12 14:18:21.103834
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    global result
    result = 0
    def _initialize(self):
        global result
        result += 1
        
    def configure(impl, **kwargs):
        global result
        result += 1
    Configurable.configurable_base = classmethod(lambda cls: cls)
    Configurable.configurable_default = lambda cls: cls
    Configurable.initialize = _initialize
    Configurable.configure = configure
    Configurable(2, 3)
    print(result)
    #expected: 2


# Generated at 2022-06-12 14:18:29.122928
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    def f(a, b, c): pass

    r = ArgReplacer(f, 'b')
    assert(r.get_old_value((1, 2, 3), {}) == 2)
    assert(r.get_old_value((1,), {'b': 2}) == 2)
    assert(r.get_old_value(tuple(), {'b': 2}) == 2)
    assert(r.get_old_value((1,), dict()) == None)


# Generated at 2022-06-12 14:18:38.727109
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b=1, c=2):
        pass

    def bar(a, b, c=2, d=3):
        pass

    def baz(b, c=1, *args, **kwargs):
        pass

    for func in foo, bar, baz:
        for name in "a", "c":
            ar = ArgReplacer(func, name)
            assert ar.get_old_value((), {}) is None
            assert ar.get_old_value((1,), {}) == 1
            assert ar.get_old_value((None,), {name: 1}) == 1
            assert ar.get_old_value((1,), {name: 1}) == 1
            assert ar.replace(10, (1,), {}) == (1, (10,), {})
            assert ar

# Generated at 2022-06-12 14:18:53.637107
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test the behaviour of class Configurable

    # Test method __new__ of class Configurable
    # Tests the creation of an instance of class Configurable
    # This method is supposed to be overwritten.
    # Instances of class Configurable shall not be created.
    # TypeError
    with pytest.raises(TypeError):
        Configurable()

# Generated at 2022-06-12 14:18:59.555702
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Test with a value
    try:
        raise OSError(9, 'This is my errno.')
    except OSError as e:
        assert errno_from_exception(e) == 9
    # Test without a value
    try:
        raise OSError('This is a bad errno.')
    except OSError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-12 14:19:09.130385
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # Normal use
    def f(a, b):
        pass

    inp_args = (1, 2)
    inp_kwargs = {"c": 3, "d": 4}
    arg_replacer = ArgReplacer(f, "b")
    old_value, out_args, out_kwargs = arg_replacer.replace(
        "b2", inp_args, inp_kwargs
    )
    assert old_value == 2
    assert out_args == (1, "b2")
    assert out_kwargs == {"c": 3, "d": 4}

    # Replacement is done in-place
    inp_args = (1, "b3")
    inp_kwargs = {"c": 3, "d": 4}

# Generated at 2022-06-12 14:19:18.697508
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    class T(object):
        def t(self, a, b, c):
            pass
    t = T()
    a = ArgReplacer(t.t, "b")
    assert a.get_old_value(args=(1, 2, 3), kwargs={}) == 2
    assert a.get_old_value(args=(1, 2), kwargs={"c": 3}) == 2
    assert a.get_old_value(args=(1, 2, 3), kwargs={}, default=4) == 2
    assert a.get_old_value(args=(1,), kwargs={"c": 3}, default=4) == 4


# Generated at 2022-06-12 14:19:22.009242
# Unit test for method __new__ of class Configurable

# Generated at 2022-06-12 14:19:31.292374
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def testFunc(a, b):
        pass
    arg_replacer = ArgReplacer(testFunc, 'a')
    old_value = arg_replacer.get_old_value((1, 2), {})
    assert old_value == 1
    old_value = arg_replacer.get_old_value((1, 2), {'b': 'b_value'})
    assert old_value == 1
    old_value = arg_replacer.get_old_value((1, 2), {'a': 'a_value'})
    assert old_value == 1
    old_value = arg_replacer.get_old_value((), {'a': 'a_value'})
    assert old_value == 'a_value'

# Generated at 2022-06-12 14:19:41.653862
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import logging

    import tornado.log
    import tornado.simple_httpclient

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return cls

        def initialize(self, **kwargs):
            # type: (**Any) -> None
            self.kwargs = kwargs

    a = A()
    # type: ignore
    assert a.__class__ is A
    assert a.kwargs == {}

    A.configure(None, a=1)
    a = A()
    # type: ignore
    assert a.__class__ is A
    assert a.kwargs == {"a": 1}


# Generated at 2022-06-12 14:19:45.711832
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c, d=None, e=None, g=None):
        pass

    def g(a, c=None, b=None, d=None):
        pass

    def h(a, b, c, d=None, e=None, g=None, **kwargs):
        pass

    def k(a, b, c, d=None, e=None, g=None, *args):
        pass

    test = partial(ArgReplacer, f, "b")
    assert test.get_old_value((1, 2, 3), {}) == 2
    assert test.get_old_value((1,), {"b": 2, "e": 3}) == 2
    test = partial(ArgReplacer, g, "b")

# Generated at 2022-06-12 14:19:56.747765
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo
        @classmethod
        def configurable_default(cls):
            return cls
    class Bar(Foo):
        def initialize(self):
            pass
    assert type(Foo())() == Bar
    Foo.configure(None)
    assert type(Foo())() == Foo

# Inheritance diagram for class Configurable
#
# +------------+
# | Configurable |
# +------------+
# | +configurable_base() [classmethod]
# | +configurable_default() [classmethod]
# | +initialize(...)
# | +configure() [classmethod]
# | +configured_class() [classmethod]
# | +_save_config

# Generated at 2022-06-12 14:19:58.547611
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Unit test for method __new__ of class Configurable
    # TODO
    pass

# Generated at 2022-06-12 14:20:13.897545
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    old_value = 5
    args = [old_value]
    kwargs = {}
    default = 99
    arg_replacer = ArgReplacer(test_ArgReplacer_get_old_value, 'args')
    assert arg_replacer.get_old_value(args, kwargs, default) == old_value
    assert arg_replacer.get_old_value([], kwargs, default) == default


# Generated at 2022-06-12 14:20:22.685771
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    class MyConfig(Configurable):

        @classmethod
        def configurable_base(cls):
            return MyConfig

        @classmethod
        def configurable_default(cls):
            return MyConfigImpl

        def __new__(cls, *args, **kwargs):
            return super(MyConfig, cls).__new__(cls, *args, **kwargs)

        def initialize(self, *args, **kwargs):
            pass

    class MyConfigImpl(MyConfig):
        pass

    class MyParent(object):

        def __new__(cls, *args, **kwargs):
            return super(MyParent, cls).__new__(cls, *args, **kwargs)

        def initialize(self, *args, **kwargs):
            pass


# Generated at 2022-06-12 14:20:33.284440
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_function(a, b, c, d=None, e=None):
        pass

    def test_class(a, b, c, d=None, e=None):
        pass

    for test_obj in [test_function, test_class]:
        kwargs = {"a": 1, "d": 3, "e": 4}
        assert ArgReplacer(test_obj, "a").get_old_value((1, 2, 3), kwargs) == 1
        assert ArgReplacer(test_obj, "b").get_old_value((1, 2, 3), kwargs) == 2
        assert ArgReplacer(test_obj, "c").get_old_value((1, 2, 3), kwargs) == 3
        assert ArgReplacer(test_obj, "d").get_old_value

# Generated at 2022-06-12 14:20:44.132264
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c = 'c', d = 'd', *args, **kwargs):
        return (a, b, c, d, args, kwargs)

    def func_replacer(replacer, new_value, *args, **kwargs):
        old_value, args_new, kwargs_new = replacer.replace(new_value, args, kwargs)
        return (old_value, func(*args_new, **kwargs_new))

    assert func_replacer(ArgReplacer(func, 'b'), 'b2', 'a1', 'b1') == (
        'b1', ('a1', 'b2', 'c', 'd', (), {}))

# Generated at 2022-06-12 14:20:51.897687
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(foo, bar, other=None):
        pass

    def func_call(**kwargs):
        return func(1, 2, other=3, **kwargs)

    r = ArgReplacer(func_call, "foo")
    def test_replace(expected_rv, expected_args, expected_kwargs, **kwargs):
        rv = r.replace(10, args, kwargs)
        assert rv == expected_rv, "expected %s, got %s" % (expected_rv, rv)
        assert args == expected_args, \
            "expected %s, got %s" % (expected_args, args)
        assert kwargs == expected_kwargs, \
            "expected %s, got %s" % (expected_kwargs, kwargs)


# Generated at 2022-06-12 14:21:02.932727
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # configurable_base 为 ConfigurableSubclass1
    # configurable_default 为 ConfigurableSubclass2

    # 默认实现 class
    c = ConfigurableSubclass1()
    # c 的实际类型为 ConfigurableSubclass2
    assert isinstance(c, ConfigurableSubclass1)
    assert isinstance(c, ConfigurableSubclass2)

    # 修改配置实现 class
    ConfigurableSubclass1.configure(ConfigurableSubclass3)
    # 虽然类的类型仍然是 ConfigurableSubclass1，但由于 __new__ 方法的重写，实

# Generated at 2022-06-12 14:21:06.119712
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    r = ArgReplacer(function, 'name')
    assert r.replace("John", ["Steve", "Bill"],{}) == (None, ["John", "Bill"], {})


# Generated at 2022-06-12 14:21:16.326400
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d=0):
        pass
    arg1, args, kwargs = ArgReplacer(foo, "b").replace(1, (2, 2, 2, 2), {"d": 4})
    assert(arg1 == 2)
    assert(args == (2, 1, 2, 2))
    assert(kwargs == {"d": 4})
    arg2, args, kwargs = ArgReplacer(foo, "d").replace(1, (2, 2, 2, 2), {"d": 4})
    assert(arg2 == 4)
    assert(args == (2, 2, 2, 2))
    assert(kwargs == {"d": 1})


# Generated at 2022-06-12 14:21:27.164456
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    ar = ArgReplacer(f, "a")
    assert ar.get_old_value((1,2,3), {}, None) == 1
    ar = ArgReplacer(f, "b")
    assert ar.get_old_value((1,2,3), {}, None) == 2
    ar = ArgReplacer(f, "c")
    assert ar.get_old_value((1,2,3), {}, None) == 3
    ar = ArgReplacer(f, "b")
    assert ar.get_old_value((1,2), {"c": 3}, None) == 2
    assert ar.get_old_value((1,2), {}, None) is None

# Generated at 2022-06-12 14:21:28.451722
# Unit test for function import_object
def test_import_object():
    assert import_object('unittest') is unittest
test_import_object()



# Generated at 2022-06-12 14:22:05.113793
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import io

    class SubClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return Configurable
        @classmethod
        def configurable_default(cls):
            return None
    SubClass.configure(io.StringIO)
    value1 = SubClass('test')
    assert value1.write('test') == 4
    assert value1.read() == 'test'
    value2 = SubClass('')
    assert value2.write('test') == 4
    assert value2.read() == 'test'
    assert value2.getvalue() == 'test'
    assert isinstance(value2, io.StringIO)



# Generated at 2022-06-12 14:22:14.617903
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b=None, *args, **kwargs):
        pass
    
    assert ArgReplacer(foo, 'b').get_old_value((1,), {}, default=None) is None
    assert ArgReplacer(foo, 'b').get_old_value((1,2), {}, default=None) == 2
    assert ArgReplacer(foo, 'b').get_old_value((1,), {'b': 2}, default=None) == 2
    assert ArgReplacer(foo, 'a').get_old_value((1,), {}, default=None) == 1
    assert ArgReplacer(foo, 'a').get_old_value((1,2), {}, default=None) == 1

# Generated at 2022-06-12 14:22:25.302737
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Foo:
        def __init__(self, a, b, c=None):
            pass
    r = ArgReplacer(Foo, 'c')
    old_value, args, kwargs = r.replace('new_value', (1, 2), {'b': 4})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'b': 4, 'c': 'new_value'}
    old_value, args, kwargs = r.replace('new_value', (1, 2, 3), {'b': 4})
    assert old_value == 3
    assert args == (1, 2, 'new_value')
    assert kwargs == {'b': 4}



# Generated at 2022-06-12 14:22:34.551712
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import tornado.ioloop

    # See http://www.voidspace.org.uk/python/mock/examples.html#multiple-calls-with-different-signatures
    class MockConfigurable(Configurable):
        _selected = None

        @classmethod
        def configurable_base(cls):
            return MockConfigurable

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self, foo, bar=""):
            self.foo = foo
            self.bar = bar
            self._selected = (foo, bar)

    MockConfigurable.configure("tornado.ioloop.IOLoop")

    x = MockConfigurable("x")
    y = MockConfigurable("y", bar="y")
    z = MockConfigurable("z")

# Generated at 2022-06-12 14:22:38.877186
# Unit test for function import_object
def test_import_object():
    import inspect
    import_object("inspect") == inspect
    import_object("inspect.isfunction") == inspect.isfunction
    assert import_object("inspect.missing_attribute") == None



# Generated at 2022-06-12 14:22:44.129427
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, *args, c, **kwargs): return a, b, args, c, kwargs
    obj = ArgReplacer(func, "b")
    assert obj.get_old_value(('a', 'b', 'c', 'd'), {'c': 'C', 'd': 'D'}) == 'b'

# Generated at 2022-06-12 14:22:51.008031
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b):
        pass
    args = (1, 2)
    replace = ArgReplacer(f, 'a')
    a, b, c = replace.replace(3, args, {})
    assert (a, b, c) == (1, (3, 2), {})


_global_dict = None   # type: Optional[Dict[str, Any]]



# Generated at 2022-06-12 14:23:00.127230
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        pass
    with pytest.raises(NotImplementedError):
        A.configurable_base()
    with pytest.raises(NotImplementedError):
        A.configurable_default()
    with pytest.raises(NotImplementedError):
        A()
    with pytest.raises(ValueError):
        A.configure(tornado.ioloop.IOLoop)
    
    class B(Configurable):
        @classmethod
        def configurable_base(self):
            return B
        @classmethod
        def configurable_default(self):
            return B
        def _initialize(self):
            pass
    class C(B):
        pass

# Generated at 2022-06-12 14:23:09.625907
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    arg_replacer = ArgReplacer(lambda a, b, c=5, d=7: None, "d")
    assert arg_replacer.replace(10, (1, 2), dict(c=3)) == (7, (1, 2), dict(c=3, d=10))
    assert arg_replacer.replace(9, (1, 2, 3), dict(d=8, e=11)) == (
        8,
        (1, 2, 3),
        dict(d=9, e=11),
    )
    assert arg_replacer.replace(8, (1, 2, 3, 6), dict(c=3, d=6)) == (
        6,
        (1, 2, 3, 8),
        dict(c=3),
    )
    #

# Generated at 2022-06-12 14:23:13.712098
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a, b):
        pass

    replacer = ArgReplacer(test, "a")
    assert replacer.get_old_value((1, 2),{}) == 1, "failed"
    assert replacer.get_old_value((),{"a":1}) == 1, "failed"


# Generated at 2022-06-12 14:25:11.230654
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.foo = 1
    assert d.foo == d['foo']



# Generated at 2022-06-12 14:25:21.359118
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConfigurableImpl(Configurable):
        def configurable_base(self):
            return Configurable
    class ConfigurableImpl1(Configurable):
        def configurable_base(self):
            return Configurable
    class ConfigurableImpl2(Configurable):
        def configurable_base(self):
            return Configurable
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return Configurable
        def configurable_default(self):
            return ConfigurableImpl
        def _initialize(self, *args, **kwargs):
            pass
    empty_kwargs = dict()
    TestConfigurable.configure(ConfigurableImpl1)
    TestConfigurable.configure(ConfigurableImpl2, **empty_kwargs)
    assert TestConfigurable.configured_class() == ConfigurableImpl2

# Generated at 2022-06-12 14:25:29.440840
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import io
    import io
    import io
    import io
    import io
    import io
    class TestConfigurable_configurable_base(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable_configurable_base
        @classmethod
        def configurable_default(cls):
            return TestConfigurable_configurable_default
    class TestConfigurable_configurable_default(TestConfigurable_configurable_base):
        def initialize(self):
            pass
    def test_new1():
        class TestConfigurable_configurable_base_subclass(TestConfigurable_configurable_base):
            pass
        obj = TestConfigurable_configurable_base_subclass()
        assert isinstance(obj, TestConfigurable_configurable_base_subclass)
        assert isinstance

# Generated at 2022-06-12 14:25:37.402628
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def function(arg1, arg2='default_value'):
        return arg1, arg2
    
    @st.cache(suppress_st_warning=True,allow_output_mutation=True)
    def test_function():
        arg_replacer=ArgReplacer(function,'arg2')
        old_value=arg_replacer.get_old_value(('arg1_value',),{})
        assert old_value=='default_value'
        old_value=arg_replacer.get_old_value(('arg1_value',),{'arg2':'overridden_value'})
        assert old_value=='overridden_value'

    test_function()


# Generated at 2022-06-12 14:25:40.300489
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # assert isinstance(Configurable.__new__.__self__, type)
    print(repr(Configurable.__new__.__self__))



# Generated at 2022-06-12 14:25:40.933978
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-12 14:25:49.199683
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    a = ArgReplacer(lambda:None, "a")
    assert a.replace("hello", ("a", "b"), {}) == (None, ("a", "b"), {"a": "hello"})
    assert a.replace("hello", ("a", "b"), {"a": 1}) == (1, ("a", "b"), {"a": "hello"})
    assert a.replace("hello", ("b", "a"), {"a": 1}) == (1, ("b", "hello"), {})
    assert a.replace("hello", ["b", "a"], {"a": 1}) == (1, ["b", "hello"], {})
    assert a.replace("hello", ("b", ), {"a": 1}) == (1, ("b", ), {"a": "hello"})
    assert a.replace("hello", ["b"], {"a": 1})

# Generated at 2022-06-12 14:25:59.361994
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(a, b):
        # type: (int, int) -> None
        pass

    replacer = ArgReplacer(f, "a")
    old_value, args, kwargs = replacer.replace(42, (1, 2), {})
    assert old_value == 1
    assert args == (42, 2)
    assert kwargs == {}

    replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = replacer.replace(42, (1, 2), {})
    assert old_value == 2
    assert args == (1, 42)
    assert kwargs == {}

    replacer = ArgReplacer(f, "b")

# Generated at 2022-06-12 14:26:07.679488
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.httpclient import HTTPRequest, HTTPError, HTTPResponse
    from tornado.httputil import url_concat
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.log
    import tornado.queues
    import tornado.simple_httpclient
    import tornado.tcpclient
    import tornado.tcpserver
    import tornado.testing
    from typing import Callable, Dict, List, Optional, cast, Type

    class MyConfigurable(Configurable):
        pass

    class MyConfigurableImpl(MyConfigurable):
        pass


    def test():
        # type: () -> None
        MyConfigurable.configure("tornado.testing.MyConfigurableImpl")
        instance1 = MyConfigurable()
        assert isinstance(instance1, MyConfigurableImpl)


# Generated at 2022-06-12 14:26:16.947306
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b=None): pass
    arg_replacer = ArgReplacer(f, 'b')
    # Test replace when the named argument is passed by position
    args = (1, 2)
    kwargs = {}
    _, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert args[0] == 1
    assert args[1] == 5
    assert not kwargs
    # Test replace when the named argument is passed by keyword
    args = (1,)
    kwargs = {'b': 2}
    _, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert args == (1,)
    assert kwargs == {'b': 5}
    # Test replace when the named argument is not given
    args