

# Generated at 2022-06-12 14:16:45.503530
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import pytest
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    import tornado.testing
    import tornado.httpclient
    import tornado.web
    import tornado.template
    import tornado.options
    import tornado.httpserver
    import asyncio
    import itertools
    import sys
    import tornado.netutil
    import tornado.platform.epoll
    import time
    import functools
    import collections
    import tornado.queues

    class ConfigurableTestCase(tornado.testing.AsyncTestCase):
        def test_construct(self):

            class B(Configurable):
                def configurable_base(self):
                    return B

                def configurable_default(self):
                    return B1


# Generated at 2022-06-12 14:16:47.254996
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    assert issubclass(Configurable, object)
    assert isinstance(Configurable, object)



# Generated at 2022-06-12 14:16:53.112350
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(x=1):
        pass
    a = ArgReplacer(f, "x")
    assert a.get_old_value([1], {}) == 1
    assert a.get_old_value([], {"x":2}) == 2
    assert a.get_old_value([], {}) == 1
    assert a.get_old_value([], {}, 99) == 99

# Generated at 2022-06-12 14:17:02.077112
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # Test that errno_from_exception returns the errno attribute
    errno = 22
    err = OSError()
    err.errno = errno
    assert errno_from_exception(err) == errno
    # Test that errno_from_exception returns the errno in args otherwise
    err = OSError(errno)
    assert errno_from_exception(err) == errno
    # Test that errno_from_exception returns None if there is no errno
    err = OSError()
    assert errno_from_exception(err) is None
    err = OSError(None)
    assert errno_from_exception(err) is None
    err = OSError("No errno")
    assert errno_from_exception(err)

# Generated at 2022-06-12 14:17:05.640582
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():  # pragma: no cover
    def foo(a, b, *args, **kwargs):  # type: ignore
        pass
    assert ArgReplacer(foo, "a").arg_pos == 0
    assert ArgReplacer(foo, "c").arg_pos is None



# Generated at 2022-06-12 14:17:10.496388
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class Super(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            pass

        def configurable_default(self):
            # type: () -> Type[Configurable]
            pass

        def _initialize(self):
            # type: () -> None
            pass
    assert Super.initialize is Super._initialize

# Generated at 2022-06-12 14:17:18.862663
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(arg1, arg2 = 5, arg3 = 'default'):
        pass
    r = ArgReplacer(func, 'arg2')
    # Test case when the argument is passed by position
    assert r.get_old_value(['arg1_val', 6, 'arg3_val'], None) == 6
    assert r.get_old_value(['arg1_val', 6, 'arg3_val'], None, 10) == 6
    assert r.get_old_value(['arg1_val', 'arg3_val'], None) == 5
    assert r.get_old_value(['arg1_val', 'arg3_val'], None, 10) == 10
    # Test case when the argument is passed by keyword

# Generated at 2022-06-12 14:17:26.896963
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class SubConfigurable(Configurable):
        def configurable_base(self):
            return SubConfigurable
        def configurable_default(self):
            return SubConfigurable
        def initialize(self, *args, **kwargs):
            pass
    # 
    class SubSubConfigurable(SubConfigurable):
        def configurable_base(self):
            return SubConfigurable
        def configurable_default(self):
            return SubConfigurable
        def initialize(self, *args, **kwargs):
            pass
    # 
    class SubConfigurable2(Configurable):
        def configurable_base(self):
            return SubConfigurable2
        def configurable_default(self):
            return SubConfigurable2
        def initialize(self, *args, **kwargs):
            pass
    # 

# Generated at 2022-06-12 14:17:37.008909
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ParamsTest(Configurable):
        def __new__(cls, *args: Any, **kwargs: Any) -> Any:
            base = cls.configurable_base()
            init_kwargs = {}  # type: Dict[str, Any]
            if cls is base:
                impl = cls.configured_class()
                if base.__impl_kwargs:
                    init_kwargs.update(base.__impl_kwargs)
            else:
                impl = cls
            init_kwargs.update(kwargs)
            if impl.configurable_base() is not base:
                # The impl class is itself configurable, so recurse.
                return impl(*args, **init_kwargs)
            instance = super(Configurable, cls).__new__(impl)
            # initialize vs

# Generated at 2022-06-12 14:17:44.558016
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import random
    from unittest.mock import patch
    from unittest import TestCase

    class SubClass(Configurable):
        def initialize(self):
            pass

    SubClass.configure(SubClass)

    mock = patch(
        "tornado.util.Configurable.initialize",
        return_value=None
    )

    res = mock.start()

    # Call function initialize with an instance of Configurable,
    # the patched method must be called
    instance = SubClass()
    instance.initialize()
    assert res.called

    # Call function initialize with an instance of SubClass,
    # the patched method must be called
    instance = SubClass()
    instance.initialize()
    assert res.called

    mock.stop()



# Generated at 2022-06-12 14:18:02.640920
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(s: str, t: str = "test"):
        return s, t

    arg = ArgReplacer(func, "s")
    func_args = ("arg",)
    func_kwargs = {}
    old_value = arg.get_old_value(func_args, func_kwargs)
    assert "arg" == old_value

    arg = ArgReplacer(func, "t")
    func_args = ("arg",)
    func_kwargs = {}
    old_value = arg.get_old_value(func_args, func_kwargs)
    assert "test" == old_value

    arg = ArgReplacer(func, "t")
    func_args = ("arg",)
    func_kwargs = {"t": "test0"}
    old_value = arg.get_old_

# Generated at 2022-06-12 14:18:10.593638
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Check get_old_value from the ArgReplacer
    # Check with the argument name that exists in keyword argument
    def func1(a,b,c=1,d=4,*args,**kwargs):
        return a,b,c,d,args,kwargs
    arg_replacer = ArgReplacer(func1,'c')
    old_value = arg_replacer.get_old_value(args=(1,2),kwargs=dict(d=3,e=4))
    # assert the old value of 'c' parameter is 1
    assert old_value == 1
    # Check with the argument name that exists in positional argument
    def func2(a,b,c=1,d=4,*args,**kwargs):
        return a,b,c,d,args,kwargs
    arg_replacer

# Generated at 2022-06-12 14:18:18.326808
# Unit test for function import_object
def test_import_object():
    import unittest
    class T1(unittest.TestCase):
        def test_import_object(self):
            import tornado.escape
            self.assertEqual(import_object('tornado.escape'), tornado.escape)
            self.assertEqual(import_object('tornado'), tornado)
            self.assertRaises(ImportError, import_object, 'tornado.missing_module')
    try:
        unittest.main()
    except SystemExit:
        pass  # Expected


# Generated at 2022-06-12 14:18:27.332387
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import asyncio

    class ConfigurableSubclass(Configurable):

        @classmethod
        def configurable_base(cls):
            return ConfigurableSubclass

        @classmethod
        def configurable_default(cls):
            return DefaultImpl

    class DefaultImpl(ConfigurableSubclass):

        def __init__(self, **kwargs):
            pass

    class GoodImpl(ConfigurableSubclass):

        def __init__(self, **kwargs):
            pass

    class BadImpl(ConfigurableSubclass):

        def __init__(self, **kwargs):
            pass

    assert isinstance(ConfigurableSubclass(), DefaultImpl)
    ConfigurableSubclass.configure(GoodImpl)
    assert isinstance(ConfigurableSubclass(), GoodImpl)
    with pytest.raises(ValueError):
        ConfigurableSubclass

# Generated at 2022-06-12 14:18:36.959750
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import_object = tornado.util.import_object
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self, a: Any, b: Any) -> None:
            self.a = a
            self.b = b

    class B(A):
        def initialize(self, a: Any, b: Any, c: Any) -> None:
            super(B, self).initialize(a, b)
            self.c = c

    A.configure(None)
    assert isinstance(A(1, 2), B)
    assert A(1, 2).a == 1
    assert A(1, 2).b == 2


# Generated at 2022-06-12 14:18:41.860276
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import inspect

    # This is a class that calls the initialize method in an explicit
    # way.
    class DummyClass(Configurable):
        def initialize(self):
            super().initialize()
            self.foo = 10

    obj = DummyClass()
    # If the object is callable and has the attributes foo, then
    # initialize has been called with the super() call.
    assert hasattr(obj, "foo")
    assert obj.foo == 10
    # Also, there is no attribute __init__ in the object, since initialize
    # has been used instead.
    assert not inspect.isfunction(obj.__init__)



# Generated at 2022-06-12 14:18:53.533116
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return A

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    class E(A):
        def initialize(self):
            # type: () -> None
            pass

    class F(object):
        pass
    A.configure(D)
    assert A()._initialize() is None
    assert B()._initialize() is None
    assert C()._initialize() is None
    assert isinstance(D(), D)
    assert isinstance(E(), E)

# Generated at 2022-06-12 14:18:54.429761
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass

# Generated at 2022-06-12 14:19:02.035403
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"

# Aliases that used to be here.  These are deprecated and will be removed in
# a future release; please use the names that have replaced them.
sleep = typing.cast(Callable[[float], None], time.sleep)

# Generated at 2022-06-12 14:19:12.266403
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=5, d=6):
        pass

    # Replace b
    ra = ArgReplacer(foo, 'b')
    assert ra.get_old_value((), {}) == None
    assert ra.get_old_value((), {'b':1}, 10) == 1
    assert ra.get_old_value((), {'c':1}, 10) == 10
    assert ra.get_old_value((), {'b':1, 'c':2}, 10) == 1
    assert ra.get_old_value((1,), {}) == 1
    assert ra.get_old_value((1,), {'b':2}) == 1
    assert ra.get_old_value((1,), {'c':2}) == 1

# Generated at 2022-06-12 14:19:30.931805
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b=0, *args, **kwargs):
        return a
    x = ArgReplacer(f, 'a')
    x.replace(1, (2,), {'b': 3})
    assert x.replace(1, (2,), {'b': 3}) == (2, (1,), {'b': 3})
    x = ArgReplacer(f, 'b')
    x.replace(1, (2,), {'b': 3})
    assert x.replace(1, (2,), {'b': 3}) == (3, (2,), {'b': 1})
    assert x.replace(1, (2,), {}) == (None, (2,), {'b': 1})


# We use a different name here because the old name is captured in
# inner scopes

# Generated at 2022-06-12 14:19:37.781747
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(cls):
            return A

        def configurable_default(cls):
            return A

    class B(A):
        pass

    class C(A):
        pass

    A.configure(None)

    a, b, c = A(), B(), C()

    assert isinstance(a, A) and isinstance(b, B) and isinstance(c, C)



# Generated at 2022-06-12 14:19:44.714469
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(x, y):
        pass
    a = ArgReplacer(func, 'x')
    assert a.get_old_value(('before', 'before'), {}) == 'before'
    assert a.replace('after', ('before', 'before'), {}) == ('before', ('after', 'before'), {})
    assert a.replace('after', ('before', 'before'), {'y':False}) == ('before', ('after', 'before'), {'y':False})
    assert a.replace('after', ('before',), {'y':False}) == (None, ('before',), {'y':False, 'x':'after'})



# Generated at 2022-06-12 14:19:56.595860
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_default(self):
            return (object)
        def configurable_base(self):
            return (object)
        def initialize(self, *args, **kwargs):
            return (object)
    class Bar(Foo):
            def initialize(self, *args, **kwargs):
                return (object)
            def configurable_base(self):
                return (object)
            def configurable_default(self):
                return (object)
    test = Foo()
    test2 = Bar()
    # test.configurable_base()
    # test.configurable_default()
    # test.initialize()
    # test2.configurable_base()
    # test2.configurable_default()
    # test2.initialize()


# Generated at 2022-06-12 14:20:06.554032
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=1, e=2, f=3):
        return a, b, c, d, e, f

    arg_replacer = ArgReplacer(func, 'a')
    # replace argument positionally
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (2, [1, 3, 4], {})
    # replace argument by keyword
    assert arg_replacer.replace(1, [2], {'e':5}) == (None, [2], {'e': 5, 'a': 1})
    # add argument by keyword
    assert arg_replacer.replace(1, [2], {}) == (None, [2], {'a': 1})

    arg_replacer = ArgReplacer(func, 'e')
    # add argument by keyword

# Generated at 2022-06-12 14:20:16.764145
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    """
    Test the method initialize of class Configurable
    """
    class TestConfigurable(Configurable):
        __impl_class = None
        __impl_kwargs = None

        def __new__(cls, *args, **kwargs):
            pass

        @classmethod
        def configurable_base():
            return TestConfigurable

        @classmethod
        def configurable_default():
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            return

        def _initialize(self, *args, **kwargs):
            return

    test_configurable = TestConfigurable()
    assert(test_configurable.initialize() == None)
    assert(test_configurable._initialize() == None)



# Generated at 2022-06-12 14:20:22.711399
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # See https://github.com/tornadoweb/tornado/issues/1671
    class ExceptionWithErrno(Exception):
        def __init__(self, errno: int) -> None:
            super().__init__()
            self.errno = errno

    class ExceptionWithoutErrno(Exception):
        pass

    e1 = ExceptionWithErrno(42)
    assert errno_from_exception(e1) == 42

    e2 = ExceptionWithoutErrno()
    assert errno_from_exception(e2) is None

    e3 = Exception()
    assert errno_from_exception(e3) is None



# Generated at 2022-06-12 14:20:27.821982
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    od = ObjectDict(a=1)
    assert od.a == od["a"]
    assert getattr(od, "a") == od["a"]
    with pytest.raises(AttributeError):
        od.b
    with pytest.raises(AttributeError):
        getattr(od, "b")



# Generated at 2022-06-12 14:20:36.071370
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(value, another=42):
        pass
    wrapper = ArgReplacer(func, "value")
    assert wrapper.get_old_value((1, ), {}) == 1
    assert wrapper.get_old_value((1, ), {}, default=3) == 1
    assert wrapper.get_old_value((), {"value": 10}) == 10
    assert wrapper.get_old_value((), {}, default=3) == 3
    assert wrapper.get_old_value((), {"value": 10}, default=3) == 10
    # Test with a keyword arg passed positionally
    assert wrapper.get_old_value((1,), {"value": 3}) == 1



# Generated at 2022-06-12 14:20:47.256732
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None

    class TestClass(object):
        def __init__(self, foo, bar):
            # type: (str, str) -> None
            self.foo = foo
            self.bar = bar

    class ConfigurableTest(Configurable):

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ConfigurableTest

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestClass

        def initialize(self, foo, bar):
            # type: (str, str) -> None
            self._initialize(foo, bar=bar)

    ct = ConfigurableTest(foo="foo", bar="bar")
    assert isinstance(ct, TestClass)
    assert c

# Generated at 2022-06-12 14:21:15.802766
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    class C(Configurable):
        def initialize(self):
            self.val = 1

        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

    C.configure(None)
    c = C()
    assert not c._initialize
    assert (c.val == 1)
    assert (type(c) == C)
    assert (issubclass(C, C))
    assert (issubclass(type(c), C))

    C.configure(C)
    c = C()
    assert not c._initialize
    assert (c.val == 1)
    assert (type(c) == C)
    assert (issubclass(C, C))

# Generated at 2022-06-12 14:21:26.753973
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    with patch('tornado.util.Configurable.configurable_base') as mocked_base:
        with patch('tornado.util.Configurable.configurable_default') as mocked_default:
            with patch('tornado.util.Configurable._initialize') as mocked_method:
                with patch('tornado.util.Configurable.configured_class') as mocked_class:
                    with patch('tornado.util.Configurable.configure') as mocked_configure:
                        with patch('tornado.util.Configurable._restore_configuration') as mocked_restore:
                            with patch('tornado.util.Configurable._save_configuration') as mocked_save:
                                with patch('tornado.util.Configurable.__impl_kwargs') as mocked_impl:
                                    obj = ParameterizedTestCase.get_class

# Generated at 2022-06-12 14:21:35.449182
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import collections.abc
    global pdb
    import pdb
    class MyBase(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyBase
        @classmethod
        def configurable_default(cls):
            return MyImpl
    class MyBase2(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyBase2
        @classmethod
        def configurable_default(cls):
            return MyImpl2
    class MyImpl(MyBase):
        def __init__(self, arg):
            self.arg = arg
    class MyImpl2(MyBase2):
        def __init__(self, arg):
            self.arg = arg
    obj = MyBase(123)
    assert isinstance(obj, MyBase)

# Generated at 2022-06-12 14:21:42.155050
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A

    class B(A):
        def initialize(self):
            self.x = 1

    a = A()
    b = B()
    assert(a.x == None)
    assert(b.x == 1)



# Generated at 2022-06-12 14:21:49.629782
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    _test_ArgReplacer_replace(1, {'a': 2}, 1, {'a': 2})
    _test_ArgReplacer_replace(1, {'a': 2}, 3, {'a': 2})
    _test_ArgReplacer_replace(1, {'a': 2}, 1, {'a': 2, 'b': 3})
    _test_ArgReplacer_replace(1, {'a': 2}, 3, {'a': 2, 'b': 3})
    _test_ArgReplacer_replace(1, {'a': 2}, 1, {'a': 2, 'b': 3})
    _test_ArgReplacer_replace(1, {'a': 2}, 3, {'a': 2, 'b': 3})

# Generated at 2022-06-12 14:21:52.860746
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.a = 1
    obj.b = 2
    assert obj.a == 1
    assert obj.b == 2
    try:
        obj.c = 3
    except Exception:
        pass

# Generated at 2022-06-12 14:22:01.441281
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():

    def func(a, b, c, d = 0, e = 1, f = 2):
        return a, b, c, d, e, f

    replacer = ArgReplacer(func, "d")
    old_value, args, kwargs = replacer.replace(1, (0, 1, 2), {})
    assert old_value == 0
    assert args == (0, 1, 2)
    assert kwargs == {'d': 1}

    replacer = ArgReplacer(func, "f")
    old_value, args, kwargs = replacer.replace(3, (0, 1, 2), {})
    assert old_value == 2
    assert args == (0, 1, 2)
    assert kwargs == {'f': 3}


# Generated at 2022-06-12 14:22:09.522889
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class B(Configurable):
        @classmethod
        def configurable_base(cls):
            return B

        @classmethod
        def configurable_default(cls):
            return D

    B.configure("tornado.concurrent.Future")
    b = B()
    assert isinstance(b, Future)
    assert B()._delegate_class == concurrent.futures.Future
    B.configure("tornado.concurrent.TracebackFuture")
    assert B()._delegate_class == concurrent.futures.TracebackFuture
    B.configure("tornado.concurrent.Future")
    assert B()._delegate_class == concurrent.futures.Future



# Generated at 2022-06-12 14:22:16.760798
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    """
    >>> def f(x, y): pass
    >>> a = ArgReplacer(f, 'x')
    >>> a.get_old_value((5, 6), {})
    5
    >>> a.get_old_value((), {'y': 5})
    >>> a.get_old_value((), {'x': 5})
    5
    >>> a.get_old_value((), {'x': 5}, default=6)
    5
    """



# Generated at 2022-06-12 14:22:28.175349
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):

        @classmethod
        def configurable_base(cls) -> Type[Configurable]:
            return Base

        @classmethod
        def configurable_default(cls) -> Type[Configurable]:
            return MyClass

        def initialize(self, x, y=None, z=None):
            self._x = x
            self._y = y
            self._z = z

    class MyClass(Base):
        pass

    class MySubclass(MyClass):
        pass

    class MyUnrelatedClass(Configurable):

        @classmethod
        def configurable_base(cls) -> Type[Configurable]:
            return MyUnrelatedClass

        @classmethod
        def configurable_default(cls) -> Type[Configurable]:
            raise NotImplementedError()

    Base.configure

# Generated at 2022-06-12 14:23:10.829122
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        def configurable_base(cls):
            return TestConfigurable
        def configurable_default(cls):
            return None
        @classmethod
        def configure(cls, base, **kwargs):
            Configurable.configure(base, **kwargs)
        @classmethod
        def configured_class(cls):
            return Configurable.configured_class()
        @classmethod
        def _save_configuration(cls):
            return Configurable._save_configuration()
        @classmethod
        def _restore_configuration(cls, saved):
            return Configurable._restore_configuration(saved)
        def _initialize(self):
            pass
        initialize = _initialize
    # Check error on Configurable not subclassed right

# Generated at 2022-06-12 14:23:13.163055
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Test(Configurable):
        def initialize(self):
            pass

    assert Test.configured_class() == Test



# Generated at 2022-06-12 14:23:22.758315
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    #type: () -> None
    class C1(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
        def _initialize(self, a):
            self.a = a
    c1 = C1("woof")
    assert c1.a == "woof"
    class C2(C1):
        def _initialize(self, a, b):
            super(C2, self)._initialize(a)
            self.b = b
        @classmethod
        def configurable_base(cls):
            return C1
        @classmethod
        def configurable_default(cls):
            return cls
    saved = C2._save_configuration()
   

# Generated at 2022-06-12 14:23:30.649554
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b):
        pass
    f_args = ArgReplacer(f, 'a')
    assert f_args.get_old_value((1,2), {}) == 1
    assert f_args.get_old_value((1,2), {'a': 3}) == 1
    assert f_args.get_old_value((), {'a': 3}) == 3
    assert f_args.get_old_value((1,), {}) == 1
    f_kwargs = ArgReplacer(f, 'b')
    assert f_kwargs.get_old_value((), {'b': 3}) == 3
    assert f_kwargs.get_old_value((1,), {}) == None
    assert f_kwargs.get_old_value((), {}) == None
    assert f_kw

# Generated at 2022-06-12 14:23:39.775080
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def dummy_func(arg1, arg2, kwarg1=1, kwarg2=2, kwarg3=3):
        pass

    # Case 1. basic
    arg_replace = ArgReplacer(dummy_func, 'arg1')
    assert arg_replace.get_old_value(args=('old_value1', 'arg2_value'), kwargs={'kwarg1':1, 'kwarg2':2}) == 'old_value1'

    # Case 2. No kwargs
    arg_replace = ArgReplacer(dummy_func, 'arg2')
    assert arg_replace.get_old_value(args=('arg1_value', 'old_value2'), kwargs={}) == 'old_value2'

    # Case 3. No args, No kwargs:
    arg

# Generated at 2022-06-12 14:23:46.184079
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class ConfigurableSubClass(Configurable):
        # type: (...) -> None

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ConfigurableSubClass

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return ConfigurableSubClass

        def _initialize(self):
            # type: () -> None
            pass

    inst = ConfigurableSubClass()  # type: Configurable
    inst.initialize()

# Generated at 2022-06-12 14:23:56.180284
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def __init__(self):
            pass
    class B(A):
        pass
    class C(A):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return B
    A.configure('tornado.test.test_util.test_Configurable___new__.<locals>.B')
    C()._initialize()
    A.configure('tornado.test.test_util.test_Configurable___new__.<locals>.C')
    try:
        C()._initialize()
    except AttributeError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-12 14:24:04.316965
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.locks import Event
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test

    class DummyObj(Configurable):
        @classmethod
        def configurable_base(cls):
            return DummyObj

        @classmethod
        def configurable_default(cls):
            return DummyObj

        def initialize(self, name=None):
            self.name = name

    x = DummyObj(name="foo")
    assert x.name == "foo"

    DummyObj.configure("tornado.test.test_util.DummyObj")

# Generated at 2022-06-12 14:24:12.614547
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import inspect
    import sys
    import typing

    class Base(Configurable):
        pass

    class A(Configurable):
        pass

    class B(Configurable):
        pass

    class A_Sub(A):
        pass

    class Sub(Configurable):
        pass

    class Subsub(Configurable):
        pass

    class SubSub(Sub):
        pass

    class Subsubsub(Subsub):
        pass

    class A1(A):
        pass

    class A2(A):
        pass

    class A3(A):
        pass

    class B1(B):
        pass

    def test_instantiate(cls, *args, **kwargs):
        # type: (Type[Configurable], Any, Any) -> Configurable

        # Save current configuration
        saved

# Generated at 2022-06-12 14:24:24.488637
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # assert Configurable.__new__ != object.__new__
    class A(Configurable):
        pass
    # set class A.configure
    A.configure = lambda *args, **kwargs: None
    # set class A.configurable_base
    A.configurable_base = lambda: A
    # set class A.configurable_default
    A.configurable_default = lambda: A
    # set class A.configured_class
    A.configured_class = lambda: A
    # set class A.initialize
    A.initialize = lambda *args, **kwargs: None
    # set class A._save_configuration
    A._save_configuration = lambda: (None, {})
    # set class A._restore_configuration

# Generated at 2022-06-12 14:25:40.352850
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # get_old_value is the first method of class ArgReplacer
    # The only argument of get_old_value is name(str)
    assert len(inspect.getfullargspec(ArgReplacer.get_old_value)[0]) == 3
    # The first argument of get_old_value is self(ArgReplacer)
    assert inspect.getfullargspec(ArgReplacer.get_old_value)[0][0] == 'self'
    # The second argument of get_old_value is name(str)
    assert (inspect.getfullargspec(ArgReplacer.get_old_value)[0][1]) == 'name'
    # The default value of the third argument is None
    assert (inspect.getfullargspec(ArgReplacer.get_old_value)[3]) == (None,)
    # The return

# Generated at 2022-06-12 14:25:44.342305
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"
    try:
        raise Exception(1, "error")
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-12 14:25:54.645056
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    @coroutine
    def test_get_old_value(self):
        def run_test(wrapped, args, kwargs, expected):
            old_value = wrapped.get_old_value(args, kwargs)
            self.assertEqual(expected, old_value)

        run_test(ArgReplacer(run_test, "args"), (), {}, ())
        run_test(ArgReplacer(run_test, "kwargs"), (), {}, {})
        run_test(ArgReplacer(run_test, "expected"), (), {}, None)
        run_test(ArgReplacer(run_test, "wrapped"), (), {}, None)
        run_test(ArgReplacer(run_test, "not_here"), (), {}, None)


# Generated at 2022-06-12 14:25:59.742360
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():

    od = ObjectDict()
    od[1] = "a"
    od['1'] = "b"
    od.update({'2': 'c', "3": 'd'})
    assert od.__getattr__('1') == od['1']
    assert od.__getattr__(1) == od[1]
    assert od.__getattr__('2') == od['2']
    try:
        od.__getattr__('4')
    except AttributeError:
        pass
    except Exception:
        assert False
    else:
        assert False
    od.__setattr__('1', 'c')
    assert od.__getattr__('1') == 'c'
test_ObjectDict___getattr__()

# Generated at 2022-06-12 14:26:07.886996
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f0(a, b):
        pass
    def f1(a, b=1, *c, **d):
        pass
    def f2(a=1, b=2, *c, **d):
        pass
    def f3(a=1, b=2, *, c, d=3, **e):
        pass
    def f4(a, b, *, c, d=3, **e):
        pass

    for func in [f0, f1, f2, f3, f4]:
        old, args, kwargs = ArgReplacer(func, 'a').replace(99, (1, 2), {})
        assert old == 1
        assert args == (99, 2)
        assert kwargs == {}


# Generated at 2022-06-12 14:26:17.219393
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():

    class A(object):
        pass

    def test_func(a, b=None, c=1, **kwargs):
        """Test function that recieves arguments.

        Args:
            a: Test argument A
            b: Test argument B
            c: Test argument C
        """
        pass

    rep_a = ArgReplacer(test_func, "a")
    assert rep_a.get_old_value((1,), {}) == 1
    assert rep_a.get_old_value((1,), {"a": "a"}) == 1
    assert rep_a.get_old_value((), {"a": 1}) == 1
    assert rep_a.replace(A(), (1,), {}) == (1, (A(),), {})

# Generated at 2022-06-12 14:26:24.501744
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test case 1
    try:
        Configurable()
        assert False
    except NotImplementedError:
        pass
    # Test case 2
    try:
        Configurable.configured_class()
        assert False
    except ValueError:
        pass
    # Test case 3
    try:
        Configurable._restore_configuration((None, {}))
        assert False
    except TypeError:
        pass
    # Test case 4
    try:
        Configurable.configure('abc')
        assert False
    except ValueError:
        pass
    # Test case 5
    try:
        Configurable.configure(Configurable)
        assert False
    except ValueError:
        pass

test_Configurable___new__()

