

# Generated at 2022-06-12 14:16:35.638500
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    def func(arg1, arg2, kwarg=None):
        return arg1, arg2, kwarg

    # arg1 is passed by position, kwarg by keyword
    arg_replacer = ArgReplacer(func, 'arg1')
    # The old value of arg1 should be 'value1'
    assert arg_replacer.get_old_value(['value1', 'value2'], {}) == 'value1'

    # kwarg is passed by keyword
    arg_replacer = ArgReplacer(func, 'kwarg')
    # The old value of kwarg should be 'value3'
    assert arg_replacer.get_old_value(['value1', 'value2'],
                                      {'kwarg': 'value3'}) == 'value3'

    # The arg is omitted, default value

# Generated at 2022-06-12 14:16:45.791709
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from unittest.mock import MagicMock, patch

    cls = Configurable

    @patch('tornado.util.Configurable.__new__')
    def test_configurable_base(mock_new):
        mock_result = MagicMock()
        mock_new.return_value = mock_result
        mock_base = MagicMock()
        mock_class = MagicMock()
        with patch('tornado.util.Configurable.configurable_base', return_value=mock_base):
            instance = cls.__new__(mock_class)
            assert mock_base.mock_calls == [mock_call()]
            assert instance is mock_result
            assert mock_new.mock_calls == [mock_call(mock_class)]


# Generated at 2022-06-12 14:16:54.094730
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import abc


    class I(Configurable, metaclass=abc.ABCMeta):
        @classmethod
        def configurable_base(cls):
            return I


        @classmethod
        def configurable_default(cls):
            return 1


    class IA(I):
        def __init__(self, a):
            self.a = a


    class IB(I):
        def __init__(self, b):
            self.b = b


    class IC(I):
        @property
        def c(self):
            return self._c


        def __init__(self, c):
            self._c = c


    class J(Configurable, metaclass=abc.ABCMeta):
        @classmethod
        def configurable_base(cls):
            return J




# Generated at 2022-06-12 14:17:00.303474
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class concrete(Configurable):
        def __init__(self):
            raise AssertionError("Not reached")

    concrete()

    class config_base(Configurable):
        @classmethod
        def configurable_base(cls):
            return config_base

        @classmethod
        def configurable_default(cls):
            return concrete

    class config_impl1(Configurable):
        @classmethod
        def configurable_base(cls):
            return config_base

        @classmethod
        def configurable_default(cls):
            return concrete

    class config_impl2(Configurable):
        @classmethod
        def configurable_base(cls):
            return config_base

        @classmethod
        def configurable_default(cls):
            return concrete


# Generated at 2022-06-12 14:17:08.398113
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=2, *args, **kwargs):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2), {'a': 3}) == 2
    assert arg_replacer.get_old_value((1,), {'a': 3}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 3}) == 2
    assert arg_replacer.get_old_value((1, 2, 3, 4), {'a': 3}) == 2
    assert arg_replacer.get_old_value((1,), {'a': 3, 'b': 5}) == 5

# Generated at 2022-06-12 14:17:12.237448
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def _initialize(self, x):
            self.x = x

    a = A()

    assert(a.x == 1)
    return
    # Unit test for class Configurable

# Generated at 2022-06-12 14:17:20.377668
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c): pass
    # 'b' is passed positionally
    assert ArgReplacer(test_func,'b').replace('d', ('a','b','c'),{'a':1}) == ('b', ('a','d','c'),{'a':1})
    # 'b' is passed by keyword
    assert ArgReplacer(test_func,'b').replace('d', ('a','c'),{'a':1,'b':'b'}) == ('b', ('a','c'),{'a':1,'b':'d'})
    # 'b' is not passed at all
    assert ArgReplacer(test_func,'b').replace('d', ('a','c'),{'a':1}) == (None, ('a','c'),{'a':1,'b':'d'})



# Generated at 2022-06-12 14:17:21.963026
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.httpclient import AsyncHTTPClient
    client = AsyncHTTPClient() # type: ignore

# Generated at 2022-06-12 14:17:30.036676
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c):
        pass

    arg_replacer = ArgReplacer(foo, "b")
    old_value, args, kwargs = arg_replacer.replace(7, (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, 7, 3)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace(8, (1, 2, 3), {"b": 4})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {"b": 8}

    old_value, args, kwargs = arg_replacer.replace(9, (1, 2), {})
    assert old_value is None
    assert args == (1, 2)


# Generated at 2022-06-12 14:17:41.510398
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def testfunc(arg0, arg1, arg2):
        pass
    def testfunc2(arg0, arg1, kwarg2=None):
        pass        
    argReplacer = ArgReplacer(testfunc, 'arg1')
    assert argReplacer.get_old_value((1, 2), {}) == 2
    assert argReplacer.get_old_value((1,), {'arg1': 2}) == 2
    assert argReplacer.get_old_value((1,), {'arg1': 2}, default=0) == 2
    assert argReplacer.get_old_value((1, 2, 3), {'arg2': 3}, default=0) == 2
    assert argReplacer.get_old_value((1, 2, 3), {'arg2': 3}) == 2
    assert argReplacer

# Generated at 2022-06-12 14:18:03.416368
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass

    replacer0 = ArgReplacer(f, "a")
    if replacer0.get_old_value((4, 2, 3), {"b": 2, "c": 3}) != 4:
        print(replacer0.get_old_value((4, 2, 3), {"b": 2, "c": 3}))
    replacer1 = ArgReplacer(f, "c")
    if replacer1.get_old_value((4, 2, 3), {"b": 2, "c": 3}) != 3:
        print(replacer1.get_old_value((4, 2, 3), {"b": 2, "c": 3}))


# Generated at 2022-06-12 14:18:04.692112
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    c = Configurable()
    assert c.initialize() is None



# Generated at 2022-06-12 14:18:11.423059
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3):
        return a, b, c
    arg_replacer = ArgReplacer(func, "c")
    old_value = arg_replacer.get_old_value((1, 2, 4), {})
    assert old_value == 4
    old_value = arg_replacer.get_old_value((1, 2, 1), {})
    assert old_value == 1
    old_value = arg_replacer.get_old_value((1, 2), {"c":3})
    assert old_value == 3
    old_value = arg_replacer.get_old_value((1,), {"b":2, "c": 8})
    assert old_value == 8

# Generated at 2022-06-12 14:18:16.737934
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(foo="f"):
        return foo

    replacer = ArgReplacer(func, "foo")
    # replace a positional argument
    old_value, args, kwargs = replacer.replace("b", ("a",), {})
    assert old_value == "a"
    assert args == ("b",)
    assert kwargs == {}
    # replace a keyword argument
    old_value, args, kwargs = replacer.replace("b", (), {"foo": "c"})
    assert old_value == "c"
    assert args == ()
    assert kwargs == {"foo": "b"}
    # replace an omitted argument
    old_value, args, kwargs = replacer.replace("b", (), {})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-12 14:18:18.625687
# Unit test for function import_object
def test_import_object():
    assert not import_object('test.test_util.test_import_object').__name__



# Generated at 2022-06-12 14:18:23.531027
# Unit test for function import_object
def test_import_object():
    assert import_object("urllib") is urllib
    assert import_object("urllib.parse") is urllib.parse
    assert import_object("urllib.error") is urllib.error
    assert import_object("urllib.parse.parse_qs") is urllib.parse.parse_qs



# Generated at 2022-06-12 14:18:30.675059
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError(1)
    except:
        raise_exc_info(sys.exc_info())
    try:
        raise ValueError(2)
    except:
        raise_exc_info((None, None, None))
    try:
        raise ValueError(3)
    except:
        raise_exc_info((None, TypeError('x'), None))



# Generated at 2022-06-12 14:18:34.721548
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import tornado.gen
    # Type inference fails here (mypy bug)
    # x = tornado.gen.IOLoop.initialize  # Type: ignore
    # Let's just check that the method is there:
    isinstance(tornado.gen.IOLoop.initialize, collections_abc.Callable)



# Generated at 2022-06-12 14:18:41.598620
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b=1):
        pass

    r = ArgReplacer(func, "b")
    assert r.get_old_value((1,), {}) == 1


# PeriodicCallback and HTTPCallback were moved to ioloop.py.  Import them
# here for backward compatibility.
from tornado.ioloop import PeriodicCallback, HTTPCallback  # type: ignore

# XXX Remove this in 3.1
import_object("tornado.platform.twisted")
import_object("tornado.platform.caresresolver")
import_object("tornado.platform.twisted")
import_object("tornado.platform.caresresolver")

# Generated at 2022-06-12 14:18:46.144802
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    cls = Configurable
    assert cls.configure is not None
    assert cls.configured_class is not None
    assert cls.configurable_base is not None
    assert cls.configurable_default is not None
    assert cls._initialize is not None


# Generated at 2022-06-12 14:19:03.501765
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # This is not a complete test, but it at least shows that the
    # Configurable metaclass allows subclassing to work properly
    class A(Configurable):
        __impl_class = None  # type: Optional[Type[A]]
        __impl_kwargs = None  # type: Dict[str, Any]

        def __init__(self) -> None:
            super().__init__()
            self.x = 1

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

    a = A()
    assert a.x == 1


# Generated at 2022-06-12 14:19:14.059050
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.ioloop import IOLoop

    # save the configuration provided by the `ioloop` decorator
    saved_configuration = IOLoop._save_configuration()

    class MyIOLoop(IOLoop):
        @classmethod
        def _hello(cls):
            assert isinstance(cls, type)
            return 'hello'

        def _initialize(self):
            assert isinstance(self, IOLoop)

    # Test the IOLoop decorator
    @IOLoop.configurable
    class MyAwesomeIOLoop(MyIOLoop):
        @classmethod
        def configurable_base(cls):
            return MyIOLoop

        @classmethod
        def configurable_default(cls):
            return MyAwesomeIOLoop

    # Test the hello method
    assert MyAwesomeIOL

# Generated at 2022-06-12 14:19:25.047708
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f1(a, b):
        pass
    def f2(a, b, c=0, d=1):
        pass
    def f3(*args, **kwargs):
        pass
    def f4(b=1, a=0):
        pass

    assert ArgReplacer(f1, 'a').get_old_value((1,2), {}) == 1
    assert ArgReplacer(f1, 'b').get_old_value((1,2), {}) == 2
    assert ArgReplacer(f1, 'a').get_old_value((1,), {'b':2}) == 1
    assert ArgReplacer(f1, 'b').get_old_value((1,), {'b':2}) == 2

# Generated at 2022-06-12 14:19:31.572514
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b):
        pass
    args=(1,2)
    kwargs={'a':3,'b':4}
    arg = ArgReplacer(foo,'a')
    assert arg.get_old_value(args,kwargs) == 1
    arg = ArgReplacer(foo,'b')
    assert arg.get_old_value(args,kwargs) == 4
    arg = ArgReplacer(foo,'c')
    assert arg.get_old_value(args,kwargs) is None
    assert arg.get_old_value(args,kwargs,default=5) == 5

# Generated at 2022-06-12 14:19:37.315718
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def _initialize(self, **kwargs):
            pass

    instance = TestConfigurable()
    assert type(instance) == TestConfigurable



# Generated at 2022-06-12 14:19:40.031750
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class Foo(Configurable):
        def initialize(self):
            pass

    obj = Foo()
    assert isinstance(obj, Foo)



# Generated at 2022-06-12 14:19:46.193524
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls): return cls

        @classmethod
        def configurable_default(cls): return cls

    class TestSubclass1(TestConfigurable):
        def initialize(self, foo):
            self.foo = foo

    class TestSubclass2(TestConfigurable):
        def initialize(self):
            self.foo = "default"

    TestConfigurable.configure(None)
    assert isinstance(TestConfigurable(), TestConfigurable)
    assert TestConfigurable().foo == "default"

    TestConfigurable.configure(TestSubclass1, foo="bar")
    assert isinstance(TestConfigurable(), TestSubclass1)
    assert TestConfigurable().foo == "bar"


# Generated at 2022-06-12 14:19:56.352531
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_args = [1,2,3]
    test_kwargs = {'key1': 4, 'key2': 5, 'key3': 6}
    argreplacer = ArgReplacer(test_func_1, 'key2')
    print(argreplacer.get_old_value(test_args, test_kwargs)) # Should be 5
    print(argreplacer.replace('hello', test_args, test_kwargs)) # Should be (5, [1,2,3], {'key1': 4, 'key2': 'hello', 'key3': 6})
    print(argreplacer.get_old_value(test_args, test_kwargs)) # Should be 'hello', note the modification in the previous command


# Generated at 2022-06-12 14:19:59.465960
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def fn() -> typing.NoReturn:
        raise ValueError
    try:
        fn()
    except Exception as e:
        raise_exc_info(e.__traceback__.exc_info()[1:])



# Generated at 2022-06-12 14:20:08.755452
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class TestFunc:
        def f(self, a: int, b: int):
            pass
    LFunc = TestFunc.f
    def test():
        t = TestFunc()
        t.f(1, 2)
    tmpl = "old_value = %s, args = %s, kwargs = %s"
    # replace both
    old_value, args, kwargs = ArgReplacer(LFunc, "a").replace(100, (1, 2), {})
    assert tmpl % (1, (100, 2), {}) == tmpl % (old_value, args, kwargs)

    old_value, args, kwargs = ArgReplacer(LFunc, "b").replace(200, (1, 2), {})

# Generated at 2022-06-12 14:20:41.219729
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import typing
    import weakref
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado import gen
    class MockConfigurable(Configurable):
        _initialized = False
        def initialize(self):
            self._initialized = True
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return MockConfigurable
    class ConfigurableTest(AsyncTestCase):
        def test_configurable(self):
            # Test that a configurable class with no arguments
            # uses the configured class
            instance = MockConfigurable()
            self.assertTrue(instance._initialized)
            # Test that the configured class remains after restarting
            # the IOLoop.


# Generated at 2022-06-12 14:20:47.324954
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(x, y, z):
        pass
    r = ArgReplacer(foo, 'z')
    result = r.replace(3, ('x', 'y'), dict(z=2))
    assert result == (2, ('x', 'y'), dict(z=3))
    result = r.replace(3, ('x', 'y', 'z1'), dict())
    assert result == (None, ('x', 'y', 3), dict())



# Generated at 2022-06-12 14:20:57.910052
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    @add_metaclass(Configurable)
    class TestConfigurable(object):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestA

    class TestA(TestConfigurable):
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def initialize(self, x, y):
            self.x = x
            self.y = y

    class TestB(TestConfigurable):
        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z
        def initialize(self, x, y, z):
            self.x = x
            self.y = y


# Generated at 2022-06-12 14:21:09.772923
# Unit test for method initialize of class Configurable
def test_Configurable_initialize(): # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A
        def initialize(self, **kwargs):
            # type: (Any) -> None
            pass
        def __init__(self, **kwargs):
            # type: (Any) -> None
            raise Exception('should not get here')
    assert isinstance(A(), A)
    assert not hasattr(A(), '__init__')
    assert hasattr(A(), 'initialize')

# Generated at 2022-06-12 14:21:21.562267
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def add(a, b):
        return a + b
    
    def test_a(arg_replacer):
        '''
        Test for replacing value in *args.
        '''
        a = 3
        b = 4
        old_value, args, kwargs = arg_replacer.replace(new_value=10, args=(a, b), kwargs={})
        assert old_value == a
        assert add(10, b) == add(*args) 
    
    def test_b(arg_replacer):
        '''
        Test adding value to **kwargs.
        '''
        a = 3
        old_value, args, kwargs = arg_replacer.replace(new_value=10, args=(), kwargs={'b': a})
        assert old_value is None
       

# Generated at 2022-06-12 14:21:31.120899
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():

    def foo(a, b, c):
        return a, b, c

    def foo_kwargs(a, b, c, **kwargs):
        return a, b, c, kwargs

    def foo_varargs(*args):
        return args

    def foo_both(a, b, c, *args, **kwargs):
        return a, b, c, args, kwargs

    # Arg found by name, args is empty.
    def test1(a, b, c):
        r = ArgReplacer(foo, "c")
        q, b, c = r.replace(None, (), {"b": b, "c": c})
        assert q == c

    # Arg found by position, kwargs is empty.

# Generated at 2022-06-12 14:21:41.594089
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(22, b"errno")
    except BaseException as e:
        errno = errno_from_exception(e)
        assert errno == 22
    try:
        raise Exception(b"errno")
    except BaseException as e:
        errno = errno_from_exception(e)
        assert errno == "errno"
    try:
        raise Exception()
    except BaseException as e:
        errno = errno_from_exception(e)
        assert errno is None
test_errno_from_exception()



# Generated at 2022-06-12 14:21:47.128647
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import os
    def get_old_value_test(a, b, c=0, d=0):
        return os.stat(a)
    arg = ArgReplacer(get_old_value_test, "a")
    old_value = arg.get_old_value(["/tmp/test.txt", 1, 2], {})
    # old value must be exist
    assert isinstance(old_value.st_size, int)
    assert old_value.st_size > 0



# Generated at 2022-06-12 14:21:56.493249
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    default = {"key": "value"}
    def test_function(arg1, arg2, kwarg1=None, kwarg2=None):
        print(arg1, arg2, kwarg1, kwarg2)

    arg_replacer1 = ArgReplacer(test_function, "arg1")
    arg_replacer2 = ArgReplacer(test_function, "arg2")
    arg_replacer3 = ArgReplacer(test_function, "kwarg1")
    arg_replacer4 = ArgReplacer(test_function, "kwarg2")
    arg_replacer5 = ArgReplacer(test_function, "default_key")

    old_value1 = arg_replacer1.get_old_value(("value",), {}, default)

# Generated at 2022-06-12 14:22:02.903226
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    """Unit test for `ArgReplacer` class."""
    def f():
        pass

    class f(object):

        def __init__(self):
            pass

    assert ArgReplacer(f, "a").arg_pos is None
    assert ArgReplacer(f, "self").arg_pos is None
    assert ArgReplacer(f, "nonexistent_arg").arg_pos is None

    def f(a):
        pass

    def f(a, b):
        pass

    def f(a, b, c):
        pass

    def f(a, b, c, d):
        pass

    assert ArgReplacer(f, "a").arg_pos == 0
    assert ArgReplacer(f, "b").arg_pos == 1
    assert ArgReplacer(f, "c").arg_pos == 2


# Generated at 2022-06-12 14:22:44.250503
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():

    def func(a, b, c, d=4, *args, **kwargs):
        pass

    replacer = ArgReplacer(func, "c")
    old_value, args, kwargs = replacer.replace(3, (1, 2), {"d": 4, "e": 5})
    assert (args, kwargs) == ((1, 2, 3), {"d": 4, "e": 5})
    assert old_value is None

    old_value, args, kwargs = replacer.replace(6, (1, 2, 5), {"d": 4, "e": 5})
    assert (args, kwargs) == ((1, 2, 6), {"d": 4, "e": 5})
    assert old_value == 5



# Generated at 2022-06-12 14:22:55.526749
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # Even though it's a method, we can call ArgReplacer._getargnames
    # directly because we're using new-style classes
    assert ArgReplacer._getargnames(lambda x, y: None) == ("x", "y")

    # The _getargnames method is not guaranteed to work for cython, so
    # we need to test it explicitly
    def f(x, y, z=1):
        pass
    assert ArgReplacer._getargnames(f) == ("x", "y", "z")

    def g(a, b):
        pass
    assert ArgReplacer._getargnames(g) == ("a", "b")

    def h(a=1, b=2):
        pass
    assert ArgReplacer._getargnames(h) == ("a", "b")



# Generated at 2022-06-12 14:23:03.638559
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import unittest
    from unittest import mock


    real_object = object()


    class MockConfigurable1(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return MockConfigurable1

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return MockConfigurable1

        def initialize(self):
            # type: () -> None
            pass


    class MockConfigurable2(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return MockConfigurable1


# Generated at 2022-06-12 14:23:14.090771
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    old_impl_class = Configurable.__impl_class
    old_impl_kwargs = Configurable.__impl_kwargs


# Generated at 2022-06-12 14:23:24.217295
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a,b,c=1):
        pass
    replacer = ArgReplacer(f,'b')
    assert replacer.get_old_value((10,20,30),{},default=None)==20
    assert replacer.get_old_value((10,),{'b':20},default=None)==20

    def f(**kwargs):
        pass
    replacer = ArgReplacer(f,'b')
    assert replacer.get_old_value((),{'b':20},default=None)==20
    assert replacer.get_old_value((),{},default=None)==None

    def f(a,b,c=1):
        pass
    replacer = ArgReplacer(f,'c')

# Generated at 2022-06-12 14:23:31.518710
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from types import FunctionType as function_type
    from types import MethodType as method_type

    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C1

    class C1(C):
        pass

    class C2(C):
        def __init__(self, a: int, b: int) -> None:
            self.a = a
            self.b = b

    C.configure(C2, b=2)

    with raises(TypeError):
        C(1)

    with raises(TypeError):
        C1(1)
    with raises(TypeError):
        C1(1, 2)

    assert C()
    assert C().a == 1

# Generated at 2022-06-12 14:23:34.456805
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            pass
    a = A()
    assert isinstance(a, A)
    assert isinstance(a, Configurable)


# Generated at 2022-06-12 14:23:42.547935
# Unit test for function import_object
def test_import_object():
    # Set to True when a test fails
    failed = False
    import inspect
    import argparse
    import tornado.escape
    import tornado.httpserver
    try:
        m = import_object("tornado.escape")
        assert(inspect.getfile(m) == inspect.getfile(tornado.escape))
    except Exception as e:
        print('Exception:', type(e), ':', e)
        failed = True
    try:
        m = import_object("tornado.escape.utf8")
        assert(inspect.getfile(m) == inspect.getfile(tornado.escape.utf8))
    except Exception as e:
        print('Exception:', type(e), ':', e)
        failed = True

# Generated at 2022-06-12 14:23:53.297426
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import typing
    import unittest
    from types import FunctionType
    from types import MethodType
    from types import ModuleType
    from types import TracebackType
    from typing import Any
    from typing import Dict
    from typing import Optional
    from typing import Type
    from typing import Union
    import unittest
    class Foo(Configurable):
        def configurable_base(self):
            pass
        def configurable_default(self):
            pass
    assert isinstance(Foo.configurable_base, MethodType)
    assert isinstance(Foo.configurable_default, MethodType)
    assert isinstance(Foo.configure, MethodType)
    assert isinstance(Foo.configured_class, MethodType)
    assert isinstance(Foo._save_configuration, MethodType)

# Generated at 2022-06-12 14:23:59.237558
# Unit test for function import_object
def test_import_object():
    from tornado.escape import utf8
    assert import_object('tornado.escape.utf8') is utf8
    assert import_object('tornado.escape') is utf8.__module__
    assert import_object('tornado.escape') is import_object('tornado.escape')

    try:
        import_object('tornado.missing_module')
        assert False, "import_object should fail with missing module"
    except ImportError:
        pass



# Generated at 2022-06-12 14:24:58.728307
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    self = Configurable()  # type: Configurable
    # This function is too simple.
    pass

# Generated at 2022-06-12 14:25:08.082913
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func1(arg1, arg2, arg3=1, arg4=2):
        pass

    def test_func2(arg1, arg2, arg3=1, arg4=2, *args, **kwargs):
        pass

    def test_func3(arg1, arg2, arg3=1, arg4=2, *args):
        pass

    def test_func4(arg1, arg2, arg3=1, arg4=2, **kwargs):
        pass

    def test_func5(*args, **kwargs):
        pass

    def test_func6():
        pass

    def test_func7(arg1):
        pass

    def test_func8(arg1, arg2, **kwargs):
        pass


# Generated at 2022-06-12 14:25:16.195841
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def args(*args, **kwargs):
        return args, kwargs
    assert ArgReplacer(args, "arg_0").replace("new_0", (1, 2), {}) == (1, ("new_0", 2), {})
    assert ArgReplacer(args, "arg_1").replace("new_1", (1, 2), {}) == (2, (1, "new_1"), {})
    assert ArgReplacer(args, "arg_2").replace("new_2", (1, 2), {}) == (None, (1, 2), {"arg_2": "new_2"})



# Generated at 2022-06-12 14:25:25.445367
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, *args, **kwargs):
        pass

    # Positional/required parameter
    assert ArgReplacer(f, "a").arg_pos == 0
    # Positional/defaulted parameter
    assert ArgReplacer(f, "c").arg_pos == 2
    # Keyword-only parameter
    assert ArgReplacer(f, "b").arg_pos is None

    # With decorators
    def f(a, b=None, *args, **kwargs):
        pass

    def g(func):
        return func

    def h(func):
        return func

    f = g(h(f))
    assert ArgReplacer(f, "a").arg_pos == 0
    assert ArgReplacer(f, "b").arg_pos == 1



# Generated at 2022-06-12 14:25:30.124808
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test1(a, b, c):
        print(a, b, c)
        return a, b, c
    args = (1,2)
    kwargs = {'c':3}
    arg_replacer = ArgReplacer(test1, 'c')
    print(arg_replacer.replace(4, args, kwargs))
#test_ArgReplacer_replace()


# Generated at 2022-06-12 14:25:37.835501
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConcreteConfigurable(Configurable):
        def __init__(self, a, b, c, **kwargs):
            super(ConcreteConfigurable, self).__init__(a, b, c=c, **kwargs)

        def configurable_base(self):
            return ConcreteConfigurable

        def configurable_default(self):
            return ConcreteConfigurable

    cc = ConcreteConfigurable(1, 2, 3, d=4)
    assert cc.a == 1, cc.a
    assert cc.b == 2, cc.d
    assert cc.c == 3, cc.c
    assert cc.d == 4, cc.d



# Generated at 2022-06-12 14:25:47.520205
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class JavaClass(object):
        """Java Class"""

        def __init__(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            self.args = args
            self.kwargs = kwargs

    class PythonClass(Configurable):
        """Python Class"""

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return PythonClass

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return JavaClass

        def initialize(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            self.args = args
            self.kwargs = kwargs


# Generated at 2022-06-12 14:25:57.446557
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    from tornado.web import RequestHandler
    from tornado.web import Application
    from tornado.ioloop import IOLoop
    import os

    class MainHandler(RequestHandler):
        def get(self):
            print("get handler")
        
        def post(self):
            print("post handler")
    
    class MyHandler(RequestHandler):
        def initialize(self, arg1):
            self.arg1 = arg1

        def prepare(self):
            self.arg1 = 3
            print(self.arg1)
    
    app = Application([('/', MainHandler), ('/my', MyHandler, dict(arg1=5))])
    app.listen(8888)

    print(os.getpid())
    IOLoop.current().start()



# Generated at 2022-06-12 14:26:06.645270
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from contextlib import contextmanager
    from unittest.mock import patch, ANY

    @contextmanager
    def mock_configurable(base_class, default_class):
        class DummyConfigurable(base_class):
            def configurable_base(self):
                return base_class

            def configurable_default(self):
                return default_class

            def initialize(self, value):
                self.value = value

        with patch.object(base_class, 'configurable_base', return_value=base_class), \
                patch.object(base_class, 'configurable_default', return_value=default_class):
            yield DummyConfigurable

    with mock_configurable(Configurable, None):
        with pytest.raises(NotImplementedError):
            Configurable().configurable_base()


# Generated at 2022-06-12 14:26:13.139418
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        class W(Configurable):
            @classmethod
            def configurable_base(cls):
                 return cls
            @classmethod
            def configurable_default(cls):
                return cls
            def initialize(self):
                pass
            def fun(self):
                return True
            def __init__(self):
                # This method is not allowed
                pass
        w = W()
        w.fun()
    except Exception as e:
        print(e)
        print(traceback.format_exc())