

# Generated at 2022-06-12 14:16:47.003813
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(100)
    except:
        assert errno_from_exception(sys.exc_info()[1]) == 100

    try:
        raise IOError
    except:
        assert errno_from_exception(sys.exc_info()[1]) == None



# Generated at 2022-06-12 14:16:54.958712
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from typing import Any, Sequence, Dict

    class Test_ArgReplacer():

        def __init__(self, x, y) -> None:
            self.argreplacer = ArgReplacer(self.foo, 'y')


        def foo(self, a, y, z=0) -> None:
            pass


        def call_foo(self, *args: Sequence[Any], **kwargs: Dict[str, Any]) -> None:
            self.foo(*args, **kwargs)


        def call_call_foo(self, new_y: Any, *args: Sequence[Any], **kwargs: Dict[str, Any]) -> None:
            old_value, args, kwargs = self.argreplacer.replace(new_y, args, kwargs)

# Generated at 2022-06-12 14:17:04.081011
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo
        @classmethod
        def configurable_default(cls):
            return Foo

    class Bar(Foo):
        pass
    # Also test that it's picklable
    pickle.loads(pickle.dumps(Foo))
    # Configure from a subclass.
    Foo.configure(Bar, a=1)
    assert Foo()._initialize.__self__ is Bar
    assert Foo(a=2)._initialize.__self__ is Bar

    # Configure from a string
    Foo.configure("tornado.util.Foo")
    assert Foo()._initialize.__self__ is Foo

    # Configure from a string with keyword args

# Generated at 2022-06-12 14:17:11.654797
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # It should get a argument by position.
    def kwargs_func1(a='a', b='b'):
        pass
    arg_replacer = ArgReplacer(kwargs_func1, 'a')
    assert arg_replacer.get_old_value(('x',), {'b':'y'}) == 'x'
    # It should get a argument by keyword.
    def kwargs_func2(a='a', b='b'):
        pass
    arg_replacer = ArgReplacer(kwargs_func2, 'b')
    assert arg_replacer.get_old_value(('x',), {'b':'y'}) == 'y'
    # It should return default when the argument is not present.

# Generated at 2022-06-12 14:17:16.893437
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):

        @classmethod
        def configurable_base(cls):
            return MyConfigurable

        @classmethod
        def configurable_default(cls):
            return MyImpl

        def __init__(self):
            pass

        def initialize(self):
            pass

    class MyImpl(MyConfigurable):
        pass

    x = MyConfigurable()
    assert isinstance(x, MyImpl)



# Generated at 2022-06-12 14:17:23.613031
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test(self, a1, a2, a3, a4,a5):
        print(a1,a2,a3,a4,a5)
    test1 = ArgReplacer(test,'a1')
    print(test1.replace(10,('a1','a2','a3','a4','a5'),{}))
    test2 = ArgReplacer(test,'a3')
    print(test2.replace(33,('a1','a2','a3','a4','a5'),{}))
    print(test2.replace(44,('a1','a2','a4','a5'),{'a3':'a3'}))

# Generated at 2022-06-12 14:17:29.104122
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def check(args, kwargs, name, expected, default=None):
        actual = ArgReplacer(lambda *a, **k: None, name).get_old_value(args, kwargs, default)
        self.assertEqual(expected, actual)

    # A few different argument permutations
    check((1, 2, 3), {}, "a", None)
    check((1, 2, 3), {}, "b", None)
    check((1, 2, 3, 4), {}, "c", None)
    check((1, 2, 3, 4), {}, "b", 2)
    check((1, 2, 3), {"c": 4}, "a", None)
    check((1, 2, 3), {"c": 4}, "b", 2)

# Generated at 2022-06-12 14:17:38.114508
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    '''
    It should call initialize of the class instance before returning.
    '''
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
        @classmethod
        def configure(cls, impl, **kwargs):
            pass
        @classmethod
        def configured_class(cls):
            return cls
        def _initialize(self):
            self.initialized = True
    f = Foo()
    assert f.initialized



# Generated at 2022-06-12 14:17:40.636611
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise TypeError("foo")
    except TypeError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)



# Generated at 2022-06-12 14:17:45.857876
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> Any
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Foo

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Foo

    Foo.configure(None)
    foo = Foo()
    assert foo.initialize() is None



# Generated at 2022-06-12 14:17:54.983996
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class StringMatcher(Configurable):
        def configurable_base(self):
            pass

        def configurable_default(self):
            pass
    StringMatcher.configure("str")



# Generated at 2022-06-12 14:18:04.940110
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def _func1(a1, a2, a3, a4):
        pass

    def _func2(a1, a2, a3, a4, a5=1, a6=2):
        pass

    def _func3(a1, a2, a3, a4, a5=1, a6=2, *vargs):
        pass

    def _func4(a1, a2, a3, a4, a5=1, a6=2, **kwargs):
        pass

    def _func5(a1, a2, a3, a4, *vargs, **kwargs):
        pass

    def _func6(a1, a2, a3, a4, a5=1, a6=2, *vargs, **kwargs):
        pass


# Generated at 2022-06-12 14:18:11.631605
# Unit test for method __new__ of class Configurable

# Generated at 2022-06-12 14:18:16.919919
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from datetime import timedelta
    from functools import partial
    from inspect import getfullargspec
    from typing import List, Union, Callable, Tuple, Optional

    def foo(x: Union[int, bytes, bytearray], y: int, \
            z: bytes = b'hi', *, a: Callable = lambda x: x):
        # type: (...) -> Tuple[int, int, bytes, str]
        """Dummy Function"""
        return x, y, z, a("hi")

    # initialize the class ArgReplacer
    arg_replacer = ArgReplacer(foo, 'a')

    # function to test method replace of class ArgReplacer
    def test_replace(**kwargs):
        # type: (...) -> List[Optional[Union[int, float, str]]]
        x, y

# Generated at 2022-06-12 14:18:22.113761
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(x, y, z):
        """Test function for ArgReplacer"""
        pass

    argreplacer = ArgReplacer(foo, "y")
    assert argreplacer.get_old_value((1, 2, 3), {}) == 2
    assert argreplacer.replace(10, (1, 2, 3), {})[0] == 2
    assert argreplacer.replace(10, (1, 2, 3), {})[1] == (1, 10, 3)
    assert argreplacer.replace(10, (1,), {"z":3})[1] == (1,)
    assert argreplacer.replace(10, (), {"z":3})[1] == ()
    assert argreplacer.replace(
        10, (), {"z":3})[2] == {"z": 3, "y": 10}




# Generated at 2022-06-12 14:18:29.006309
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Configurable_test(Configurable):
        def __init__(self, *args, **kwargs):
            # type: (List[str], Dict[str, Any]) -> None
            self.args = args
            self.kwargs = kwargs
            Configurable.initialize(self, *args, **kwargs)
        def configurable_base(cls):
            # type: () -> Type[Configurable_test]
            return cls
        def configurable_default(cls):
            # type: () -> Type[Configurable_test]
            return cls
        def _initialize(self, *args, **kwargs):
            # type: (List[str], Dict[str, Any]) -> None
            self.initialized = True
    c = Configurable_test("foo", bar="baz")
   

# Generated at 2022-06-12 14:18:37.867844
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return object

        def _initialize(self):
            pass

    class Derived(Base):
        pass

    assert Base is Base.configured_class()
    assert object is Base.configured_default()
    assert Base is Derived.configured_class()
    assert object is Derived.configurable_default()
    assert Base is Base.configurable_base()
    assert not isinstance(Derived(), Base)

    Base.configure('tornado.testing.unittest_backport.TestCase')
    assert isinstance(Derived(), TestCase)

    saved = Base._save_configuration()

# Generated at 2022-06-12 14:18:44.750907
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=5, e=6):
        pass

    a = ArgReplacer(func, "d")
    old_value, args, kwargs = a.replace(7, (1, 2, 3), {})
    assert (old_value, args, kwargs) == (5, (1, 2, 3), {"d": 7})

    a = ArgReplacer(func, "f")
    old_value, args, kwargs = a.replace(7, (1, 2, 3, 4), {"e": 5})
    assert (old_value, args, kwargs) == (None, (1, 2, 3, 4), {"e": 5, "f": 7})

    a = ArgReplacer(func, "b")
    old_value, args, kwargs = a

# Generated at 2022-06-12 14:18:49.508644
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(foo, bar=None): pass
    argrepl = ArgReplacer(func, 'foo')
    old_value, args, kwargs = argrepl.replace('baz', ('bar',), {})
    assert old_value == 'bar'
    assert args == ('baz',)
    assert kwargs == {}

# Generated at 2022-06-12 14:19:00.928397
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import python_inline

    # __new__(cls, *args, **kwargs)
    # Configurable
    class C(python_inline._class_inline._Configurable):
        def configurable_base(self):
            return C
        def configurable_default(self):
            return None
        def _initialize(self):
            pass
        def initialize(self):
            pass
    assert C.__new__(C, *(int(),), **{}) is None
    # Configurable
    class D(python_inline._class_inline._Configurable):
        def configurable_base(self):
            return D
        def configurable_default(self):
            return C
        def _initialize(self):
            pass
        def initialize(self):
            pass

# Generated at 2022-06-12 14:19:29.491893
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo

        def configurable_default(self):
            return Foo

    class Bar(Foo):
        def __init__(self, bar):
            self.bar = bar

        def initialize(self, bar):
            self.bar = bar

        def get_bar(self):
            return self.bar

    # Test that Foo can be instantiated.
    foo = Foo()
    assert isinstance(foo, Foo)
    assert isinstance(foo, Configurable)

    # Test that Bar can be instantiated.
    Bar.configure(None)
    bar = Bar(42)
    assert isinstance(bar, Bar)
    assert isinstance(bar, Foo)
    assert isinstance(bar, Configurable)

# Generated at 2022-06-12 14:19:40.401849
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=9, e=5):
        return a, b, c, d, e

    a = ArgReplacer(func, 'e')
    old_value = a.get_old_value((0, 1, 2), {'d':3})
    assert old_value == 5
    old_value, args, kwargs = a.replace(4, (0, 1, 2), {'d':3})
    assert old_value == 5
    assert args == (0, 1, 2)
    assert kwargs == {'d':3, 'e':4}
    old_value = a.get_old_value((0, 1, 2), {'d':3})
    assert old_value == 4

# Generated at 2022-06-12 14:19:47.248084
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Configurable is a baseclass and we want to test the class method
    # __new__ of a subclass. So, we create a subclass and mock class
    # and instance methods of the superclass.
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    import unittest.mock

# Generated at 2022-06-12 14:19:57.610307
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c, d=5):
        return a, b, c, d
    ar = ArgReplacer(func, "b")
    assert ar.get_old_value((1, 2, 3), {}) == 2
    assert ar.get_old_value((1, 2, 3), {}, default=7) == 2
    assert ar.get_old_value((1, 2, 3), {"b": 7}) == 7
    assert ar.get_old_value((1, 2, 3), {"b": 7}, default='not used') == 7
    assert ar.get_old_value((1, 2, 3), {"c": 7}) is None
    assert ar.get_old_value((1, 2, 3), {"c": 7}, default=8) == 8

# Generated at 2022-06-12 14:20:06.474335
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """
    >>> def test_func(req, arg):
    ...   [req, arg]
    >>> a = ArgReplacer(test_func, "req")
    >>> a.replace("req_0", ("arg0",), {})[1][1:]
    ['req_0', 'arg0']
    >>> a.replace("req_1", ("arg0",), {'req': 'req_0'})[1][1:]
    ['req_1', 'arg0']
    >>> a.replace("req_2", (), {'req': 'req_0', 'arg': 'arg0'})[1][1:]
    ['req_2', 'arg0']
    """
    pass



# Generated at 2022-06-12 14:20:11.416746
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a = 2):
        return a
    a = ArgReplacer(foo, 'a')
    ans = a.replace(4, (1,), {})
    print(ans)
if __name__ == '__main__':
    test_ArgReplacer_replace()
    test_get_callback()

# Generated at 2022-06-12 14:20:20.825649
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def get_port(host, port=80):
        pass
    a = ArgReplacer(get_port, 'port')
    assert a.get_old_value(('127.0.0.1', ), {}, 80) == 80
    assert a.get_old_value(('127.0.0.1', ), {'port': 8888}, 80) == 8888
    # Unit test for method replace of class ArgReplacer
    def test_ArgReplacer_replace():
        def get_port(host, port=80):
            pass
        a = ArgReplacer(get_port, 'port')
        assert a.replace(8888, ('127.0.0.1', ), {}) == (80, ('127.0.0.1', ), {'port': 8888})


# Generated at 2022-06-12 14:20:22.280107
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        pass
    a = A()
    print(a)



# Generated at 2022-06-12 14:20:32.798221
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    #
    # Test the method __new__ of class Configurable, in module tornado.util
    #
    # This test was added because changeset bca5b4a4d4c1 introduced
    # the method __new__
    #
    # We cannot test __new__ alone, but we can test the class
    # that uses __new__ to construct itself
    #
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self, **kwargs):
            # a simple initialization
            self.bar = kwargs.get('bar', 0)

    #
    # test class instantiation through __new__
    #
    foo = Foo(bar=1)


# Generated at 2022-06-12 14:20:33.877853
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(5, "hello")
    except BaseException as e:
        assert errno_from_exception(e) == 5



# Generated at 2022-06-12 14:21:09.162092
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

        def initialize(self, a: int, b: int) -> None:
            self.a = a
            self.b = b

    C.configure(impl=None, hello="world")
    o = C(1, 2)
    assert o.a == 1
    assert o.b == 2

if False:
    Configurable = typing.Any



# Generated at 2022-06-12 14:21:14.314685
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(21, 'test')
    except IOError as e:
        assert errno_from_exception(e) == 21

    try:
        raise IOError('test')
    except IOError as e:
        assert errno_from_exception(e) == None



# Generated at 2022-06-12 14:21:25.292337
# Unit test for method get_old_value of class ArgReplacer

# Generated at 2022-06-12 14:21:33.577464
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class a(Configurable):
        @classmethod
        def configurable_base(cls):
            return a

        @classmethod
        def configurable_default(cls):
            return b

        def _initialize(self):
            self.initialized = True

    class b(a):
        def _initialize(self):
            self.initialized = True

    class c(a):
        def _initialize(self):
            self.initialized = True

    assert isinstance(a(), a)
    assert isinstance(a(), b)
    assert isinstance(a(), c)
    assert a().initialized == True

    a.configure(impl = b)
    assert a().initialized == True

    a.configure(impl = c)
    assert a().initialized == True

    a.configure("tornado.util.b")

# Generated at 2022-06-12 14:21:44.379873
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=1, *d, **e):
        pass
    assert not hasattr(f, "func_code")
    def g(a, b, c=1, *d, **e):
        pass
    assert hasattr(g, "func_code")
    replacer = ArgReplacer(f, "d")
    old_value, args, kwargs = replacer.replace(3, (1, 2), {})
    assert old_value == ()
    assert args == (1, 2)
    assert kwargs == {"d": 3}
    old_value, args, kwargs = replacer.replace(4, (1, 2), {"d": 3})
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {"d": 4}

# Generated at 2022-06-12 14:21:53.351711
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def replace(args, kwargs):
        replacer = ArgReplacer(replace, "a")
        return replacer.replace(100, args, kwargs)

    assert ((100,)    , {}, {},) == replace(())
    assert ((100, 2)  , {}, {},) == replace((2,))
    assert ((100, 2)  , {}, {'a': 3},) == replace((2,), a=3)
    assert (None, {}, {'a': 100},) == replace({}, a=100)
    assert ((1, 100), {}, {},) == replace((1,), a=100)
    assert ((100, 2), {'a': 3}, {},) == replace((2,), {'a': 3})

# Generated at 2022-06-12 14:22:00.937402
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def get_v(name, *args, **kwargs):
        arg_replacer = ArgReplacer(get_v, name)
        return arg_replacer.get_old_value(*args, **kwargs)

    assert get_v('a') == None
    assert get_v('a', '') == ''
    assert get_v('a', a=1) == 1
    assert get_v('a', a=1, b=2) == 1
    assert get_v('b', 1, b=2) == 2
    assert get_v('b', 1, 2, b=3) == 2
    assert get_v('b', 1, 2, 3) == 3


# Generated at 2022-06-12 14:22:08.874093
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(*args: Any, **kwargs: Any) -> None:
        pass
    def another_test_func(first_arg: Any, second_arg: Any, **kwargs: Any) -> Any:
        pass
    # Test case 1: ArgReplacer is not instantiated with a proper func
    try:
        ar = ArgReplacer(1, "first_arg")
    except TypeError:
        # Test Case 1: Passed
        pass
    # Test Case 2: Test func is func(*args, **kwargs)
    ar = ArgReplacer(test_func, "first_arg")
    first_arg = "new_arg"
    old_value, new_args, new_kwargs = ar.replace(first_arg, [], {})
    assert old_value is None
    assert new_args == []


# Generated at 2022-06-12 14:22:13.849075
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    args = ("aa",)
    kwargs = {"bb": "bb"}
    new_value = "cc"
    old_value, args, kwargs = ArgReplacer.replace(new_value, args, kwargs)
    assert args == ("cc",)
    assert kwargs == {"bb": "bb"}
    assert old_value == "aa"



# Generated at 2022-06-12 14:22:19.499451
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a,b,c):
        pass
    argr = ArgReplacer(foo, 'a')
    assert argr.get_old_value((1,2,3),{} ) == 1
    assert argr.get_old_value((1,2,3),{'a': 4} ) == 1


# Generated at 2022-06-12 14:23:25.913288
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    #
    #Test ArgReplacer.replace()
    #
    class A:
        @classmethod
        def test(cls, a, b=1, c=2, d=3, **kwargs):
            pass
    class B:
        @classmethod
        def test(cls, a, b=1, c=2, d=3, **kwargs):
            pass
    A.test(0, d=4)
    class C:
        @classmethod
        def test(cls, a, b=1, c=2, d=3, **kwargs):
            pass
    a = A()
    b = B()

# Generated at 2022-06-12 14:23:32.529371
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import sys
    
    if sys.version_info[0] >= 3:
        from unittest import mock
    else:
        import mock
    class Testable(Configurable):
        def configurable_base(self):
            
            return self.__class__
        
        def configurable_default(self):
            
            return self.__class__
        
        def initialize(self):
            return
    

# Generated at 2022-06-12 14:23:38.331581
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c, d=1, e=2):
        pass

    # The value of parameter with name d
    assert ArgReplacer(foo, 'd').get_old_value(args=1, kwargs=2, default=3) == 1

    # The value of parameter with name z
    assert ArgReplacer(foo, 'z').get_old_value(args=1, kwargs=2, default=3) == 3


# Generated at 2022-06-12 14:23:45.060691
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b=0, c=1):
        pass
    replacer = ArgReplacer(foo, 'a')
    old_value, args, kwargs = replacer.replace(10, (1,), dict(c=2))
    assert old_value == 1
    assert args == (10,)
    assert kwargs == dict(c=2)
    old_value, args, kwargs = replacer.replace(10, (), dict(a=11))
    assert old_value == 11
    assert args == ()
    assert kwargs == dict(a=10)
    old_value, args, kwargs = replacer.replace(10, (1, 2), dict(a=11))
    assert old_value == 1
    assert args == (10, 2)

# Generated at 2022-06-12 14:23:56.040834
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    import functools

    @functools.wraps
    def replace_pos(func: Any, name: str = "i", new_value: Any = None):
        replacer = ArgReplacer(func, name)
        old_value, args, kwargs = replacer.replace(new_value, args, kwargs)
        return old_value, func(*args, **kwargs)

    @functools.wraps
    def replace_kw(func: Any, name: str = "i", new_value: Any = None):
        replacer = ArgReplacer(func, name)
        old_value, args, kwargs = replacer.replace(new_value, args, kwargs)
        return old_value, func(*args, **kwargs)


# Generated at 2022-06-12 14:24:04.253148
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c):
        pass

    def bar(a, b, c, d=None):
        pass

    rep = ArgReplacer(foo, "c")
    assert rep.get_old_value((1, 2, 3), {}) == 3
    assert rep.get_old_value((1, 2, 3), {"c": 4}) == 3
    assert rep.get_old_value((1, 2), {}) is None
    assert rep.get_old_value((1, 2), {"c": 4}) == 4

    rep = ArgReplacer(bar, "d")
    assert rep.get_old_value((1, 2, 3), {}) is None
    assert rep.get_old_value((1, 2, 3), {"d": 4}) == 4

# Generated at 2022-06-12 14:24:07.725342
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(arg1, arg2, arg3='default'):
        pass
    replacer = ArgReplacer(func, 'arg2')
    value = replacer.get_old_value(('a','b','c'),{})
    assert value == 'b'


# Generated at 2022-06-12 14:24:13.938121
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    '''
    Test the method get_old_value of class ArgReplacer
    '''
    arg_replacer = ArgReplacer(func=lambda x, y, z: None, name='x')  # yapf: disable
    assert arg_replacer.get_old_value(args=(1, 2, 3), kwargs={}) == 1

    arg_replacer = ArgReplacer(func=lambda x, y, z: None, name='x')  # yapf: disable
    assert arg_replacer.get_old_value(args=(1,), kwargs={'x': 3}) == 3

    arg_replacer = ArgReplacer(func=lambda x, y, z: None, name='x')  # yapf: disable

# Generated at 2022-06-12 14:24:25.257334
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from _pytest.monkeypatch import MonkeyPatch

    class TestConfigurableBase(Configurable):
        def configurable_base(self):
            return TestConfigurableBase

        def configurable_default(self):
            return TestConfigurableDefault

    class TestConfigurableDefault(TestConfigurableBase):
        pass

    class TestConfigurableAlternative(TestConfigurableBase):
        pass

    with MonkeyPatch._context_manager(Configurable, 'configured_class',
                                      lambda cls: TestConfigurableDefault):
        t1 = TestConfigurableBase()
        assert isinstance(t1, TestConfigurableBase)
        assert isinstance(t1, TestConfigurableDefault)
        assert isinstance(t1, TestConfigurableAlternative) is False

    TestConfigurableBase.configure(TestConfigurableAlternative)
    t2 = TestConfigurableBase()


# Generated at 2022-06-12 14:24:35.564359
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b=0, c=1): pass
    fn, args, kwargs = ArgReplacer('b', foo).replace(2, (1,), {'c': 3})
    assert fn == 0 and args == (1, ) and kwargs == {'b': 2, 'c': 3}
    fn, args, kwargs = ArgReplacer('b', foo).replace(2, (1, 1), {'c': 3})
    assert fn == 1 and args == (1, 2) and kwargs == {'c': 3}
    fn, args, kwargs = ArgReplacer('c', foo).replace(2, (1,), {'c': 3})
    assert fn == 3 and args == (1, ) and kwargs == {'c': 2}
    # New key
    fn,

# Generated at 2022-06-12 14:25:45.818869
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {"c": 5}
    old_value, args, kwargs = ArgReplacer(func, "c").replace(5, args, kwargs)
    assert old_value == 5
    assert args == (1, 2, 5)
    assert kwargs == {}
    kwargs = {"c": 5}
    _, args, kwargs = ArgReplacer(func, "b").replace(10, args, kwargs)
    assert args == (1, 2, 3)
    assert kwargs == {"c": 5, "b": 10}



# Generated at 2022-06-12 14:25:53.821374
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Test(object):
        pass
    inst = Test()
    inst_id = id(inst)
    def func(arg1, arg2, arg3):
        return
    kwargs = {'arg3': inst}
    old_value, args, kwargs = ArgReplacer(func, arg3).replace('new value', ['arg1', 'arg2'], kwargs)
    assert old_value == inst
    assert kwargs['arg3'] == 'new value'
    assert id(kwargs['arg3']) != inst_id
    return
test_ArgReplacer_replace()


# Generated at 2022-06-12 14:26:03.823839
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # 1. Test when position is not None and args has enough length
    def func(arg1, arg2, arg3):
        pass
    replacer = ArgReplacer(func, "arg2")
    assert replacer.get_old_value(["1", "2", "3"], {}, "default") == "2"
    # 2. Test when position is None and arg is in kwargs
    replacer = ArgReplacer(func, "arg3")
    assert replacer.get_old_value(["1", "2", "3"], {}, "default") == "3"
    # 3. Test when position is None and arg is not in kwargs
    replacer = ArgReplacer(func, "arg4")

# Generated at 2022-06-12 14:26:12.620924
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-12 14:26:21.314601
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    def func(a: int, b: int, c: int, d: int) -> None:
        pass
    replacer = ArgReplacer(func, "b")
    assert replacer.get_old_value((1, 2, 3, 4), {}, -1) == 2
    assert replacer.get_old_value((1, 2), {"c": 3, "d": 4}, -1) == 2
    assert replacer.get_old_value((1, 2), {"c": 3}, -1) == 2
    assert replacer.get_old_value((1,), {"b": 2, "c": 3, "d": 4}, -1) == 2
    assert replacer.get_old_value((1,), {"c": 3, "d": 4}, -1) == -1



# Generated at 2022-06-12 14:26:24.773073
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fn(a: int, b: str, c: int) -> int:
        return a + c
    argreplacer = ArgReplacer(fn, "b")
    old_value = argreplacer.get_old_value(args=[2, "one", 3], kwargs={})
    assert old_value == "one"
