

# Generated at 2022-06-12 14:16:41.999829
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj: ObjectDict = ObjectDict()
    obj.a = ObjectDict()
    obj.a.b = ObjectDict()
    obj.a.b.c = ObjectDict()

    assert obj.a.b.c == None

# Generated at 2022-06-12 14:16:50.899884
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Unit test for method get_old_value of class ArgReplacer
    def test_func(a, b, c):
        return a + b + c

    replacer = ArgReplacer(test_func, 'a')
    old_value = replacer.get_old_value((10, 20, 30), {})
    assert(old_value==10)
    old_value = replacer.get_old_value((10, 20, 30), {'a':100})
    assert(old_value==10)
    old_value = replacer.get_old_value((10, 20, 30), {'c':100})
    assert(old_value==10)
    old_value = replacer.get_old_value((10, 20, 30), {'c':100, 'a':100})

# Generated at 2022-06-12 14:16:59.868941
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test(old_arg, *args, **kwargs):
        old_value, args, kwargs = ArgReplacer('old_arg').replace('new_arg', args, kwargs)
        return old_value, args, kwargs
    assert test('old_arg') == ('old_arg', (), {})
    assert test('old_arg', 'arg1') == ('old_arg', ('arg1',), {})
    assert test('old_arg', 'arg1', 'arg2') == ('old_arg', ('arg1', 'arg2'), {})
    assert test('old_arg', 'arg1', old_arg = 'old_arg') == ('old_arg', ('arg1',), {'old_arg': 'new_arg'})

# Generated at 2022-06-12 14:17:08.119736
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f1(a1, a2, a3):
        return a1, a2, a3
    arg_replacer = ArgReplacer(f1,"a1")
    try:
        assert arg_replacer.get_old_value((1,2,3),{},999) == 1
    except TypeError:
        pass

    arg_replacer = ArgReplacer(f1,"a2")
    try:
        assert arg_replacer.get_old_value((1,2,3),{},999) == 2
    except TypeError:
        pass

    arg_replacer = ArgReplacer(f1,"a3")
    try:
        assert arg_replacer.get_old_value((1,2,3),{},999) == 3
    except TypeError:
        pass

    arg_replacer

# Generated at 2022-06-12 14:17:14.561340
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-12 14:17:16.858305
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass

# Generated at 2022-06-12 14:17:23.595413
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class TestClass:
        def __init__(self, a, b, c = "default c"):
            pass
    replacer = ArgReplacer(TestClass, "b")
    old_value, args, kwargs = replacer.replace("new b", ("a", "b"), {"c": "c"})
    assert old_value == "b"
    assert args == ("a", "new b")
    assert kwargs == {"c": "c"}
        
    old_value, args, kwargs = replacer.replace("new b", ("a",), {"b": "b", "c": "c"})
    assert old_value == "b"
    assert args == ("a",)
    assert kwargs == {"b": "new b", "c": "c"}



# Generated at 2022-06-12 14:17:31.006134
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return C

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return DefaultImpl

        def _initialize(self):
            # type: (...) -> None
            pass

    class DefaultImpl(C):
        pass

    class Impl(C):
        pass

    C.configure(Impl)
    c = C()
    assert isinstance(c, Impl)

    C.configure(None)
    c = C()
    assert isinstance(c, DefaultImpl)



# Generated at 2022-06-12 14:17:41.954720
# Unit test for function import_object
def test_import_object():
    import importlib
    importlib.reload = lambda obj: None
    del tornado.util.import_object
    reload(tornado.util)
    importlib.reload = reload
    tornado.util.import_object("tornado.util")


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).
_unicode_prefix_re = re.compile(r"u[\'\"]")
_unicode_escape_re = re.compile(r"[\'\"]")

# Generated at 2022-06-12 14:17:52.378286
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C(Configurable):

        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C1

        def initialize(self, *args, **kwargs):
            pass

    class C1(C):
        pass

    class C2(C):
        pass

    c = C()
    assert isinstance(c, C1)
    assert not isinstance(c, C2)
    c = C(foo=1)
    assert isinstance(c, C1)
    assert not isinstance(c, C2)

    C.configure(C2)
    c = C()
    assert isinstance(c, C2)
    assert not isinstance(c, C1)
    c = C(foo=1)


# Generated at 2022-06-12 14:18:10.376489
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Base]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Base]
            return cls

        def initialize(self):
            # type: () -> None
            pass

    class Subclass(Base):
        pass

    class SubSubclass(Subclass):
        pass

    # Base is configurable; Subclass is not.
    assert issubclass(Base, Configurable)
    assert not issubclass(Subclass, Configurable)

    # Base is its own base.
    assert Base.configurable_base() is Base

    # Subclass inherits base from Base (inheritance of
    #

# Generated at 2022-06-12 14:18:14.976949
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        return a, b, c

    (old_value, args, kwargs) = ArgReplacer('c', func).replace(
        'C', (1, 2), {'b': 'B'})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'b': 'B', 'c': 'C'}
    (old_value, args, kwargs) = ArgReplacer('b', func).replace(
        'B', (1, 2), {'b': 'B'})
    assert old_value == 'B'
    assert args == (1, 'B', 2)
    assert kwargs == {}



# Generated at 2022-06-12 14:18:17.882646
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(*args, **kwargs):
        pass
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2}
    replacer = ArgReplacer(foo, 'a')
    assert replacer.replace(4, args, kwargs) == (1, (1, 2, 3), {'a': 4, 'b': 2})



# Generated at 2022-06-12 14:18:22.012236
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_function(arg1: int, arg2: str, kwarg1: str = "test"):
        pass
    argument_replacer = ArgReplacer(test_function, "arg2")
    assert argument_replacer.get_old_value((1, "test"), {}) == "test"
    assert argument_replacer.get_old_value((1, "test"), {"arg2": "test_2"}) == "test_2"
    assert argument_replacer.get_old_value((1,), {"arg2": "test_2"}) == "test_2"


# Generated at 2022-06-12 14:18:30.517218
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a,b = None,c = 2):
        pass
    
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1,), {"b" : 1}, 3) == 2
    assert arg_replacer.get_old_value((1,), {"b" : 3}) == None
    assert arg_replacer.get_old_value((1,5), {}) == 5


# Generated at 2022-06-12 14:18:38.777714
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import asyncio
    import functools
    import pytest
    import warnings

    # Make sure calling initialize() is the same as calling __init__()
    class Foo(Configurable):

        def __init__(self):
            self.__init___called = True

        def initialize(self):
            super(Foo, self).initialize()
            self._initialize()

    f = Foo()
    assert f.__init___called
    assert hasattr(f, "_initialize")

    # Tests that configure works if the default is a subclass of the thing
    # being configured (as is the case with HTTPClient).
    class A(Configurable):

        def initialize(self):
            self.args = 'a'

    class B(A):

        def initialize(self):
            self.args = 'b'


# Generated at 2022-06-12 14:18:48.849576
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=5):
        pass
    arg = ArgReplacer(func, "d")
    assert arg.get_old_value((1, 2, 3), {}) == 5
    assert arg.get_old_value((1, 2, 3, 4), {}) == 4
    assert arg.get_old_value((1, 2, 3), {"d": 4}) == 4
    assert arg.get_old_value((1, 2, 3), {}) == 5
    assert arg.replace(6, (1, 2, 3), {}) == (5, (1, 2, 3), {"d": 6})
    assert arg.replace(6, (1, 2, 3, 4), {}) == (
        4,
        (1, 2, 3, 6),
        {},
    )




# Generated at 2022-06-12 14:19:00.450704
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a):
        pass
    
    arg_replacer = ArgReplacer(func, 'a')
    
    assert(arg_replacer.get_old_value((4,), {}, 0) == 4)
    assert(arg_replacer.get_old_value((3,), {'a': 4}, 0) == 4)
    assert(arg_replacer.get_old_value((), {'a': 4}, 0) == 4)
    
    def func(a, b=5):
        pass
    
    arg_replacer = ArgReplacer(func, 'b')
    
    assert(arg_replacer.get_old_value((4,), {}, 0) == 5)

# Generated at 2022-06-12 14:19:01.824446
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """ Tests for method __new__ of class Configurable """
    pass



# Generated at 2022-06-12 14:19:08.729221
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        return

    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((3, 4, 5), {}) == 3

    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((3, 4, 5), {}) == 4

    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((3, 4, 5), {'b': 6}) == 6


# Generated at 2022-06-12 14:19:31.899337
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):
        def configurable_base(self):
            return MyConfigurable

        def configurable_default(self):
            return MyDefault

        def initialize(self):
            pass

    class MyDefault(MyConfigurable):
        def initialize(self):
            self.args = [1, 2, 3]

    assert MyConfigurable().args == [1, 2, 3]

    class MyOtherDefault(MyConfigurable):
        def initialize(self):
            self.args = [4, 5, 6]
    MyConfigurable.configure(MyOtherDefault)
    assert MyConfigurable().args == [4, 5, 6]

    MyConfigurable.configure(MyOtherDefault, arg=123)
    assert MyConfigurable().args == [4, 5, 6]
    assert MyConfigurable().arg == 123

# Generated at 2022-06-12 14:19:42.239448
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """Test function for method replace of class ArgReplacer."""
    def f(a, b, c):
        return a, b, c
    obj = ArgReplacer(f, "b")
    assert obj.replace("new", [10,13,42], {}) == (13, [10,"new",42], {})
    assert obj.replace("new", [10,13,42], {"c":"d"}) == (13, [10,"new",42], {"c":"d"})
    assert obj.replace("new", [10], {"b":13, "c":"d"}) == (13, [10], {"b":"new", "c":"d"})
    assert obj.replace("new", [10], {}) == (None, [10], {"b":"new"})



# Generated at 2022-06-12 14:19:46.425024
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer(): 
    def test(a, b):
        pass
    r = ArgReplacer(test, "a")
    assert r.get_old_value((1, 2), {}) == 1
    assert r.get_old_value((1, 2), {}, default=3) == 1
    assert r.get_old_value((1, 2), {'a': 10}) == 10
    assert r.get_old_value((1, 2), {'a': 10}, default=3) == 10
    assert r.get_old_value((1, 2), {'b': 20}) == None
    assert r.get_old_value((1, 2), {'b': 20}, default=3) == 3
    assert r.get_old_value((), {'a': 10}) == 10

# Generated at 2022-06-12 14:19:56.821147
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c=5):
        pass

    get_old_value = ArgReplacer(foo, "a").get_old_value
    assert get_old_value((1, 2, 3), {}) == 1
    assert get_old_value((1,), {"b": 2}) == 1
    assert get_old_value((1,), {"b": 2, "c": 3}) == 1
    assert get_old_value((1,), {"c": 3}) == 1
    assert get_old_value((), {"a": 2, "c": 3}) == 2
    assert get_old_value((), {"c": 3}) is None
    assert get_old_value((), {"c": 3}, default=5) == 5


# Generated at 2022-06-12 14:20:06.781357
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(22, "unit test exception")
    except Exception as e:
        print("test_errno_from_exception exc: ", e)
        errno_val = errno_from_exception(e)
        print("errno_val: ", errno_val)
        assert errno_val == 22
        try:
            raise Exception("unit test exception2")
        except Exception as e2:
            print("test_errno_from_exception2 exc2: ", e2)
            errno_val2 = errno_from_exception(e2)
            print("errno_val2: ", errno_val2)
            assert errno_val2 == None
test_errno_from_exception()
# unit test for function errno_from_exception end


# Generated at 2022-06-12 14:20:17.755307
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b=None):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1,), {}, 0) == 0
    assert arg_replacer.get_old_value((1,), {"b": 2}, 0) == 2
    assert arg_replacer.get_old_value((1, 2), {}, 0) == 2
    assert arg_replacer.get_old_value((1, 2), {"b": 3}, 0) == 2
    assert arg_replacer.replace(4, (1, 2), {"b": 3}) == (2, (1, 4), {"b": 3})

# Generated at 2022-06-12 14:20:25.248768
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Base(Configurable):
        def __init__(self, foo, bar, baz, **kwargs):
            super(Base, self).__init__(foo, bar, baz, **kwargs)

        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Base

    # inherit the default initialize
    class SubBase(Base):
        pass

    SubBase.configure(None)

    class Override(Base):
        def __init__(self, foo, bar, baz, **kwargs):
            super(Override, self).__init__(foo, bar, baz, **kwargs)
            Override.initialized = True

    Override.configure(Override)


# Generated at 2022-06-12 14:20:35.592741
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """
    :return:
    """
    def test_arg_value_pos(a, b):
        print(a, b)
    def test_arg_value_kw(c, d):
        print(c, d)
    def test_arg_value_poskw(e, f=3):
        print(e, f)
    def test_arg_value_kwpos(g, h):
        print(g, h)

    # Test replace arg by position
    old_value, args, kwargs = ArgReplacer(test_arg_value_pos, 'a').replace(2, (1, 2), {})
    print(old_value)
    assert old_value == 1


# Generated at 2022-06-12 14:20:46.752298
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def function_with_args(a,b,c):
        pass
    def function_with_kwargs(d=5,e=6,f=7):
        pass
    pos_replacer=ArgReplacer(function_with_args,"b")
    assert(pos_replacer.get_old_value((1,2,3),{})==2)
    assert(pos_replacer.get_old_value((1,2),{}) is None)
    kw_replacer=ArgReplacer(function_with_kwargs,"e")
    assert(kw_replacer.get_old_value((),{"e":9})==9)
    assert(kw_replacer.get_old_value((),{}) is None)

# Generated at 2022-06-12 14:20:57.200711
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c, d=0, e=1): pass
    tester = ArgReplacer(f, 'b')
    assert tester.get_old_value((1, 2, 3), {'d': 4, 'e': 5}) == 2
    assert tester.get_old_value((1, 2, 3), {'d': 4, 'e': 5}, default=7) == 2
    assert tester.get_old_value((1,), {'b': 2, 'd': 4, 'e': 5}) == 2
    assert tester.get_old_value((1,), {'d': 4, 'e': 5}, default=7) == 7
    assert tester.get_old_value((1,), {'d': 4, 'e': 5}) == 2
    assert tester.get

# Generated at 2022-06-12 14:21:33.164960
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func1(a, b, c):
        pass
    assert ArgReplacer(func1,'b').replace(13, (1, 2, 3), {}) == (2, (1, 13, 3), {})
    assert ArgReplacer(func1,'c').replace(13, (1, 2, 3), {}) == (3, (1, 2, 13), {})
    assert ArgReplacer(func1,'a').replace(13, (1, 2, 3), {}) == (1, (13, 2, 3), {})
    def func2(a, b=2, c=3):
        pass
    assert ArgReplacer(func2,'b').replace(13, (1, 2, 3), {}) == (2, (1,), {'b':13})
    assert ArgReplacer(func2,'c').replace

# Generated at 2022-06-12 14:21:44.065136
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Test(Configurable):
        def __init__(self, arg):
            # type: (str) -> None
            self.arg = arg
        def initialize(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            self.arg = args[0]

    class TestImpl(Test):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Test]
            return Test
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Test]
            return TestImpl
        def __init__(self, arg):
            # type: (str) -> None
            super(TestImpl, self).__init__(arg)

# Generated at 2022-06-12 14:21:52.779981
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, d=None):
        pass

    co = f.__code__
    # test number of args
    assert len(co.co_varnames) == 4
    assert co.co_argcount == 2
    assert co.co_flags & inspect.CO_VARARGS == 0
    assert co.co_flags & inspect.CO_VARKEYWORDS == 0
    ar = ArgReplacer(f, "b")
    assert ar.arg_pos == 1
    assert ar.get_old_value([1], {"b": 2}) == 2
    assert ar.get_old_value([1], {}) == None
    assert ar.get_old_value([1], {"b": 2}, 3) == 2
    assert ar.get_old_value([1], {}, 3)

# Generated at 2022-06-12 14:21:56.409948
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C(Configurable):
        def configurable_base(self):
            return C
        def configurable_default(self):
            return C
    C.configure(None)
    c = C()
    assert isinstance(c, C)


# Generated at 2022-06-12 14:22:04.633968
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class X(Configurable):
        @classmethod
        def configurable_base(cls):
            return X
        @classmethod
        def configurable_default(cls):
            return X
        def initialize(self, x):
            self.x = x
    x = X(1)
    assert x.x == 1
    y = X(x=2)
    assert y.x == 2
    assert issubclass(X, X)
    assert not issubclass(X, object)
    assert not issubclass(object, X)
    X.configure(None)
    assert X.configured_class() is X
    X.configure(X)
    assert X.configured_class() is X

# Generated at 2022-06-12 14:22:10.772339
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def __init__(self, a):
            print("in __init__ of class A")
            self.a = a
            #call of method initialize
            self.initialize()

        def configurable_base(self):
            return Configurable

        def configurable_default(self):
            return A

    # First call of method __new__ of class Configurable
    x = Configurable()
    # Second call of method __new__ of class Configurable
    y = A("test")
    print("test object is x =", x)
    print("test object is y =", y)
    print("test object is y.a =", y.a)

# Generated at 2022-06-12 14:22:21.953872
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Create a function named 'f' with two arguments: 'a' and 'b'.
    f = lambda a, b: a + b

    arg_replacer = ArgReplacer(f, 'a')
    old_value, args, kwargs = arg_replacer.replace(10, (5, ), {})
    assert args == (10, ), args
    assert kwargs == {}, kwargs
    assert old_value == 5, old_value

    f = lambda a, b=3: a + b

    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(10, (5, ), {})
    assert args == (5, ), args
    assert kwargs == {'b': 10}, kwargs

# Generated at 2022-06-12 14:22:31.956367
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.testing import AsyncTestCase, gen_test

    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurableImpl

        def initialize(self, name):
            self._name = name

    class TestConfigurableImpl(TestConfigurable):
        def __init__(self, name):
            super(TestConfigurableImpl, self).__init__()
            self._name = name

    class TestAsyncConfigurable(AsyncTestCase):
        def test_functionality(self):
            self.assertIsInstance(TestConfigurable("name"), TestConfigurableImpl)
            self.assertEqual(TestConfigurable("name")._name, "name")

    TestAsyncConfigurable().run

# Generated at 2022-06-12 14:22:43.466158
# Unit test for function errno_from_exception
def test_errno_from_exception():

    # Test Exception with errno
    assert errno_from_exception(Exception('errno')) == 'errno'

    # Test Exception with error
    class CustomException(Exception):
        def __init__(self, error):
            self.error = error
    e = CustomException('error')
    assert errno_from_exception(e) == 'error'

    # Test Exception with errno and error
    class CustomException(Exception):
        def __init__(self, errno, error):
            self.errno = errno
            self.error = error
    e = CustomException('errno', 'error')
    assert errno_from_exception(e) == 'errno'

    # Test Exception with no errno nor error
    class CustomException(Exception):
        def __init__(self):
            pass


# Generated at 2022-06-12 14:22:51.682483
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(tornado.util.Configurable):
        def _initialize(self, **kwargs):
            super(A,self)._initialize()
            self.a = kwargs.get('a',1)
    a = A(a=2)
    assert(a.a==2)
    A.configure(None,a=3)
    a = A()
    assert(a.a==1)
    A.configure(A,a=4)
    a = A()
    assert(a.a==4)



# Generated at 2022-06-12 14:23:49.834808
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import_object = import_object
    base = Configurable
    Configurable = Configurable
    TestConfigurable = Configurable.configurable_base()
    args = tuple()  # type: Tuple[Any, ...]
    kwargs = {}  # type: Dict[str, Any]
    impl = TestConfigurable.configured_class()
    init_kwargs = {}  # type: Dict[str, Any]
    base = Configurable.configurable_base()
    impl = Configurable.configurable_default()
    instance = super(Configurable, type).__new__(impl)
    instance.initialize()
    cls = Configurable
    impl = str
    base = Configurable.configurable_base()
    impl = typing.cast(Type[Configurable], import_object(impl))
    cls = Config

# Generated at 2022-06-12 14:23:59.706741
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import pytest
    #
    # Test subclassing code
    #

    # Test the simplest case: a unique class hierarchy with a single
    # concrete class.
    class BaseTest(Configurable):

        @classmethod
        def configurable_base(cls):
            return BaseTest

        @classmethod
        def configurable_default(cls):
            return ConcreteTest

        def initialize(self):
            self.initialized = True

    class ConcreteTest(BaseTest):
        pass

    t = BaseTest()
    assert isinstance(t, BaseTest)
    assert isinstance(t, ConcreteTest)
    assert t.initialized

    # If we configure the base class with a different subclass, we
    # get an instance of that instead.
    class SubTest(BaseTest):
        pass


# Generated at 2022-06-12 14:24:00.247436
# Unit test for method __new__ of class Configurable
def test_Configurable___new__(): pass

# Generated at 2022-06-12 14:24:02.889491
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import doctest
    import tornado.test.util
    return doctest.DocTestSuite(tornado.test.util)



# Generated at 2022-06-12 14:24:04.441530
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # __new__ of Configurable is tested by IOLoop and Resolver tests
    pass



# Generated at 2022-06-12 14:24:06.543968
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    new_class = Configurable.initialize(1, 2, 3, 4)
    assert new_class is not None



# Generated at 2022-06-12 14:24:12.771806
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(0, "Error", "MyData")
    except OSError as e:
        assert e.errno == 0
        err = errno_from_exception(e)
        assert err == 0
        assert e.args[0] == 0
        assert e.args[1] == "Error"
        assert e.args[2] == "MyData"

    try:
        raise OSError(0, "Error")
    except OSError as e:
        assert e.errno == 0
        err = errno_from_exception(e)
        assert err == 0
        assert e.args[0] == 0
        assert e.args[1] == "Error"


# Generated at 2022-06-12 14:24:24.637490
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg1 = ArgReplacer(f, 'a')
    arg2 = ArgReplacer(f, 'b')
    arg3 = ArgReplacer(f, 'c')
    arg4 = ArgReplacer(f, 'd')
    old_value, new_args, new_kwargs = arg1.replace(-1, (11, 22, 33), {})
    assert old_value == 11
    assert new_args == (-1, 22, 33)
    assert new_kwargs == {}
    old_value, new_args, new_kwargs = arg2.replace(-2, (11, 22, 33), {})
    assert old_value == 22
    assert new_args == (11, 22, 33)
    assert new_kwargs == {'b': -2}

# Generated at 2022-06-12 14:24:35.275982
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    import inspect
    import functools
    # function with one positional parameter and two keyword parameters
    def f(x, y=None, z=None):
        pass
    arg_replacer = ArgReplacer(f, "x")
    assert arg_replacer.arg_pos is not None
    assert inspect.getfullargspec(arg_replacer.get_old_value).args == [
        "self",
        "args",
        "kwargs",
        "default",
    ]
    assert arg_replacer.get_old_value((1,), {}) == 1
    assert arg_replacer.get_old_value((1,), {}, default=3) == 1
    assert arg_replacer.get_old_value(tuple(), {}) is None
    assert arg_replacer

# Generated at 2022-06-12 14:24:43.929658
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class _Base(object):
        pass
    class _Impl(_Base):
        pass
    class _Sub1(_Impl):
        pass
    class _Sub2(_Impl):
        pass
    class _Sub3(_Sub2):
        pass
    class _Impl2(_Base):
        pass
    class _Sub22(_Impl2):
        pass
    class _Configurable(_Base, Configurable):
        @classmethod
        def configurable_base(cls):
            return _Configurable
        @classmethod
        def configurable_default(cls):
            return _Impl
    _Configurable.configure(_Impl2)
    assert _Configurable()
    assert isinstance(_Configurable(), _Impl2)
    assert issubclass(_Impl2, _Base)
    _Configurable.configure(_Sub1)
    assert _

# Generated at 2022-06-12 14:25:57.090703
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def function(arg1, arg2, arg3, **kwargs):
        pass
    argReplacer = ArgReplacer(function, "arg1")
    assert argReplacer.get_old_value(
        ["abc", "def", "ghi"], {"arg3": "jkl"}) is None
    assert argReplacer.get_old_value(
        ["abc", "def", "ghi"], {"arg1": "jkl"}) == "jkl"
    assert argReplacer.get_old_value(
        ["abc", "def", "ghi"], {"arg1": "jkl"}, default=123) == "jkl"
    assert argReplacer.get_old_value(
        ["abc", "def", "ghi"], {"arg3": "jkl"}, default=123) == 123

# Generated at 2022-06-12 14:26:06.438343
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(a, b, c):
        """A test function for ArgReplacer"""
        pass

    def func2(a, b, **kwargs):
        """A test function for ArgReplacer"""
        pass

    def func3(a, b, c=3, **kwargs):
        """A test function for ArgReplacer"""
        pass

    def func4(a, b, c=3, d=4, **kwargs):
        """A test function for ArgReplacer"""
        pass

    ArgReplacer1 = ArgReplacer(func1, "b")
    ArgReplacer2 = ArgReplacer(func2, "c")
    ArgReplacer3 = ArgReplacer(func2, "d")
    ArgReplacer4 = ArgReplacer(func3, "c")
    ArgReplacer5 = ArgReplacer

# Generated at 2022-06-12 14:26:08.781211
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    instance = Configurable.__new__(Configurable, *[], **{})
    assert isinstance(instance, Configurable)


# Generated at 2022-06-12 14:26:17.985962
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.httpclient import HTTPRequest, HTTPResponse
    from tornado.httpserver import HTTPServer
    from tornado.httputil import HTTPHeaders
    from tornado.iostream import SSLIOStream
    from tornado import ioloop, stack_context
    from tornado.netutil import TCPServer, Resolver
    from tornado.platform.auto import Waker
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.socks5 import SOCKSProxyConnection
    from tornado.tcpserver import TCPServer
    from tornado.testing import bind_unused_port
    from tornado.util import Configurable, configure
    import socket
    import time
    import unittest
    from typing import Sequence
    from typing import Type
    from typing import Union
    from unittest.mock import MagicMock