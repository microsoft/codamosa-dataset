

# Generated at 2022-06-12 14:16:37.186798
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Testable(Configurable):
        @classmethod
        def configurable_base(cls):
            return Testable

        @classmethod
        def configurable_default(cls):
            return Testable

        def __init__(self, arg: int) -> None:
            self.arg = arg

    Testable.configure(None)
    assert isinstance(Testable(1), Testable)
    assert Testable(1).arg == 1



# Generated at 2022-06-12 14:16:46.952100
# Unit test for function errno_from_exception
def test_errno_from_exception():

    def errno_test(errno, fn):
        try:
            fn()
        except Exception as e:
            return errno_from_exception(e)
        else:
            raise AssertionError("%s did not raise an Exception" % fn)

    assert errno_test(2, lambda: os.stat("nonexistent_file"))
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    assert errno_test(3, lambda: os.stat("this_file_exists.txt"))
    class MyException(Exception):
        pass

    assert errno_test(4, lambda: os.stat("this_file_exists.txt"))

# Generated at 2022-06-12 14:16:52.020026
# Unit test for function import_object
def test_import_object():
    test_objects = ["os", "os.path", "tornado.escape", "tornado.escape.utf8"]
    for obj in test_objects:
        import_object(obj)

    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected an error"



# Generated at 2022-06-12 14:17:01.015139
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    
    # Define a dummy function
    def f(a, b=2, c=3):
        print(f"a={a}, b={b}, c={c}")
    # Call the function normally
    try:
        f(1, 2, 3)
        f(1, c=3)
        f(c=3, b=2, a=1)
    except TypeError:
        pass
    # Use the replacer
    replacer = ArgReplacer(f, 'a')
    old_value, args, kwargs = replacer.replace(4, (1,), {})
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    
    

# Generated at 2022-06-12 14:17:08.891225
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class_ = Configurable
    name = 'TornadoAsyncMock'
    bases = (object,)
    dct = {
            'configurable_base': lambda cls: cls,
            'configurable_default': classmethod(lambda cls: cls),
            'configure': classmethod(lambda cls, impl, **kwargs: None),
            'configured_class': classmethod(lambda cls: cls),
            '_save_configuration': classmethod(lambda cls: None),
            '_restore_configuration': classmethod(lambda cls, saved: None),
            'initialize': lambda self, *args, **kwargs: None,
    }
    cls_dict = dict(dct)
    instance = object()
    
    # Here's the real test

# Generated at 2022-06-12 14:17:14.299428
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    from tornado.test.util import raise_exc_info

    class TestConfigurable(Configurable):
        # type: ignore
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        # type: ignore
        def initialize(self):
            # type: () -> None
            pass

    # Re-instantiate the class to get coverage in
    # _Configurable__new_impl.
    TestConfigurable()



# Generated at 2022-06-12 14:17:19.770462
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(x, y, z=3):
        return x + y + z

    ar = ArgReplacer(func, "z")
    assert ar.get_old_value((1, 2), {}) == 3

    def assert_args(new_value, args, kwargs):
        _, args_, kwargs_ = ar.replace(new_value, args, kwargs)
        assert args_ == args
        assert kwargs_ == kwargs

    assert_args(0, (1, 2), {})
    assert_args(0, (1, 2), {"z": 3})
    assert_args(0, (1, 2, 3), {})
    assert_args(0, (1, 2, 3), {"z": 3})

# Generated at 2022-06-12 14:17:21.116196
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class_method = Configurable.initialize
    pass



# Generated at 2022-06-12 14:17:26.799833
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
        raise Exception('Expected exception not raised')
    except ImportError:
        pass
    try:
        import_object('tornado.escape.missing_module')
        raise Exception('Expected exception not raised')
    except ImportError:
        pass

# fake sleep function used in testing

# Generated at 2022-06-12 14:17:31.394519
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b=None):
        pass
    assert ArgReplacer(f, "b").get_old_value((1,), {}) is None
    assert ArgReplacer(f, "b").get_old_value((1,), {}, None) is None
    assert ArgReplacer(f, "b").get_old_value((1,), {"b": "new_value"}) == "new_value"


# Generated at 2022-06-12 14:17:50.561748
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=1, d=2, e=3):
        return None
    assert ArgReplacer(func, "a").get_old_value([1, 2, 3, 4], {}) == 1
    assert ArgReplacer(func, "c").get_old_value([1, 2, 3, 4], {}) == 3
    assert ArgReplacer(func, "d").get_old_value([1, 2, 3, 4], {}) == 2
    assert ArgReplacer(func, "e").get_old_value([1, 2, 3, 4], {}) == 3
    assert ArgReplacer(func, "not_there").get_old_value([1, 2, 3, 4], {}) is None

# Generated at 2022-06-12 14:17:53.308957
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(*args,**kwargs):
        pass
    replacer = ArgReplacer(test,"args")
    args = ["this"]
    kwargs = {"args":"that"}
    old_value = replacer.get_old_value(args,kwargs)
    assert old_value == "that"



# Generated at 2022-06-12 14:17:56.295000
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(2)
    except Exception as e:
        assert errno_from_exception(e) == 2

    try:
        raise Exception((2, "foo"))
    except Exception as e:
        assert errno_from_exception(e) == 2



# Generated at 2022-06-12 14:18:05.567333
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d=1):
        pass
    arg_replacer = ArgReplacer(func=foo, name='d')
    assert arg_replacer.replace(new_value=10, args=(1, 2, 3, 4), kwargs={}) == (4, (1, 2, 3, 10), {})
    assert arg_replacer.replace(new_value=10, args=(1, 2, 3), kwargs={'d':4}) == (4, (1, 2, 3), {'d':10})
    assert arg_replacer.replace(new_value=10, args=(1, 2, 3), kwargs={}) == (None, (1, 2, 3), {'d':10})


# Generated at 2022-06-12 14:18:09.850505
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func = lambda x, y, a, b=1, c=2: None
    a, r = ArgReplacer(func, "b"), ArgReplacer(func, "d")
    assert r.get_old_value((1, 2, 3, 4, 5), {}) is None
    assert r.get_old_value((1, 2, 3, 4, 5), {"d":6}) == 6
    assert a.get_old_value((1,2, 3, 4, 5), {}) == 1
    assert a.get_old_value((1, 2, 3, 4, 5), {"b":7}) == 7
    assert a.get_old_value((1, 2, 3, 4), {}) == 1
    assert a.get_old_value((1, 2, 3), {"b":7}) == 7



# Generated at 2022-06-12 14:18:19.355001
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.ioloop import IOLoop
    class A(Configurable):
        def initialize(self, x):
            pass
    class B(Configurable):
        def initialize(self, x):
            pass
    class C(Configurable):
        def initialize(self, x):
            pass
    A.configure("tests.base_tests.B")
    assert isinstance(A(1), B)
    A.configure("tests.base_tests.C")
    assert isinstance(A(1), C)
    assert_raises(ValueError, A.configure, "tests.base_tests.IOLoop")


# Generated at 2022-06-12 14:18:22.459610
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    """Unit test for method initialize of class Configurable"""
    abc = ABC()
    abc.initialize(1,2,3)
    return abc


# Generated at 2022-06-12 14:18:28.766186
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    old_value, args, kwargs = ArgReplacer(
        str,
        "old"
    ).get_old_value(
        (1, 2, 3),
        {
            "string":"asdf"
        }
    )
    assert old_value is None



# Generated at 2022-06-12 14:18:36.641301
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestConfigurableImpl
    class TestConfigurableImpl(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass
    c = TestConfigurable(*[], **{})
    assert isinstance(c, TestConfigurableImpl)
    assert isinstance(c, TestConfigurable)
    assert repr(c).startswith("<test_tornado_util.TestConfigurableImpl")
    assert repr(c).endswith(">")



# Generated at 2022-06-12 14:18:43.941899
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Foo

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Foo

    class Bar(Foo):
        def initialize(self, name, **kwargs):
            # type: (str, Any) -> None
            self.name = name

    class Baz(Foo):
        def initialize(self, name, strength):
            # type: (str, int) -> None
            self.name = name
            self.strength = strength

    Foo.configure(Bar, name="default")
    f = Foo()
    assert isinstance(f, Foo)

# Generated at 2022-06-12 14:19:03.703402
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    cls = Configurable

    class ConfigurableSubclass(Configurable):
        def configurable_base(self):
            return ConfigurableSubclass

        def configurable_default(self):
            return DefaultConfigurableClass

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class DefaultConfigurableClass(ConfigurableSubclass):
        pass

    class AlternateConfigurableClass(ConfigurableSubclass):
        pass

    class TestConfigurable(unittest.TestCase):
        def test_constructor(self):
            cls.configure(AlternateConfigurableClass)
            instance = ConfigurableSubclass()
            self.assertIsInstance(instance, ConfigurableSubclass)
            self.assertIsInstance(instance, AlternateConfigurableClass)
           

# Generated at 2022-06-12 14:19:14.329393
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.iostream import IOStream
    # IOStream is a Configurable subclass
    assert isinstance(IOStream(), IOStream)
    # Configurable.__new__ returns IOStream
    assert isinstance(IOStream.configured_class(), IOStream)
    assert IOStream._save_configuration() == (None, None)
    IOStream.configure('tornado.test.test_util.test_Configurable___new__.TestImpl')
    assert IOStream._save_configuration()[0].__name__ == 'TestImpl'
    saved = IOStream._save_configuration()
    IOStream.configure('tornado.test.test_util.test_Configurable___new__.TestImpl2', a = 1)
    assert IOStream._save_configuration() == (TestImpl2, {'a': 1})
    #

# Generated at 2022-06-12 14:19:25.246834
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    class MyClass(object):
        def my_method(self, a, b):
            pass
    arg_replacer = ArgReplacer(MyClass.my_method, 'a')
    cls_a = MyClass()
    assert arg_replacer.get_old_value((0, 1), {}, 'c') == 0
    assert arg_replacer.get_old_value((0, 1), None, 'c') == 0
    assert arg_replacer.get_old_value((0,), {'b': 1}, 'c') == 0
    assert arg_replacer.get_old_value((), {'a': 0, 'b': 1}, 'c') == 0
    assert arg_replacer.get_old_value((), {}, 'c') == 'c'

# Generated at 2022-06-12 14:19:36.106315
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyClass(object):
        def __init__(self):
            self.args = []
            self.kwargs = dict()

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class SubClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return SubClass

        @classmethod
        def configurable_default(cls):
            return MyClass

    SubClass.configure(None)
    sub_class = SubClass(1, 2, arg3=3, arg4=4)
    assert isinstance(sub_class, SubClass)
    assert sub_class.args == (1, 2)
    assert sub_class.kwargs == {'arg3': 3, 'arg4': 4}




# Generated at 2022-06-12 14:19:44.962732
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from inspect import getfullargspec
    class Foo(object):
        def __init__(self):
            self.value = None
        def hello(self, a, b, c):
            a = ArgReplacer(self.hello, 'a')
            old_value, (p1, p2, p3), kwargs = a.replace('goodbye', (2, 3, 4), {})
            self.value = (old_value, (p1, p2, p3), kwargs)
    f = Foo()
    f.hello(1, 2, 3)
    assert f.value == (1, (2, 3, 4), {})
    f.hello(1, b=2, c=3)
    assert f.value == (1, (2, 3, 4), {})

# Generated at 2022-06-12 14:19:53.262253
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    replacer = ArgReplacer(test_ArgReplacer_replace, "new_value")
    assert replacer.replace(5, [None], {}) == (None, [5], {})
    assert replacer.replace(5, [], dict(new_value=None)) == (None, [], dict(new_value=5))
    assert replacer.replace(5, [None], dict(new_value=None)) == (None, [5], dict(new_value=5))

# Generated at 2022-06-12 14:20:00.408066
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import StringIO
    import sys
    import threading
    import time
    import weakref
    import platform
    import tests.test_util
    import textwrap
    import warnings
    from tornado import gen, httpserver, netutil, process, stack_context, web, ioloop
    from tornado.escape import utf8
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado import simple_httpclient, httputil
    from tornado.test.util import unittest
    from tornado.test.util import ObjectDict
    from tornado import util
    from functools import partial
    from contextlib import contextmanager
    from tornado.httpclient import HTTPError
    from tornado.locks import Event
    from tornado.testing import AsyncHTTPTestCase, ExpectLog, gen_test

# Generated at 2022-06-12 14:20:03.192330
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(13, 'Permission denied')
    except IOError as e:
        assert errno_from_exception(e) == 13


# Generated at 2022-06-12 14:20:10.587562
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from pytest import raises

    class FakeEpollMixin(object):
        pass

    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return NoopImpl

    class Impl(Base):
        def initialize(self, arg=None):
            self.arg = arg

    class NoopImpl(Base):
        def initialize(self):
            pass

    class EpollImpl(Impl, FakeEpollMixin):
        pass

    class SubImpl(Impl):
        pass

    assert Base().__class__ is NoopImpl

    Base.configure(Impl)
    assert Base().__class__ is Impl

    assert Base(arg=1).arg == 1

    assert Base().__class__ is Impl
    saved

# Generated at 2022-06-12 14:20:17.710032
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest

    class TestClass(Configurable):
        pass

    TestClass.configure(None)

    class TestClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestClass

        @classmethod
        def configurable_default(cls):
            return TestClass

    TestClass.configure(None)
    TestClass.configure(None, one=1, two=2)
    TestClass(three=3)  # type: ignore



# Generated at 2022-06-12 14:20:39.542336
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # This test uses a private, undocumented class ArgReplacer and this
    # test must not be run as part of the normal test suite.
    # https://github.com/tornadoweb/tornado/issues/3035

    def wrapped1(self, baz):
        return self + baz

    def wrapped2(self, baz, *args, **kwargs):
        return self + baz + sum(args) + sum(kwargs.values())

    def wrapped3(self, baz, bar=0, *args, **kwargs):
        return self + baz + bar + sum(args) + sum(kwargs.values())

    def wrapped4(self, baz, *args, bar=0, **kwargs):
        return self + baz + bar + sum(args) + sum(kwargs.values())


# Generated at 2022-06-12 14:20:47.975116
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=0):
        pass
    a = ArgReplacer(f, 'c')
    assert a.get_old_value((1, 2), {'a': 1}, default=3) == 3


__all__ = [
    "Configurable",
    "ObjectDict",
    "PY3",
    "exec_in",
    "import_object",
    "basestring_type",
    "bytes_type",
    "unicode_type",
    "native_str",
    "raise_exc_info",
    "errno_from_exception",
    "re_unescape",
    "ArgReplacer",
]

# Generated at 2022-06-12 14:20:54.018596
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b = None, c = None):
        pass
    arg_replacer = ArgReplacer(test_func, 'a')
    test_func_args = (1,)
    test_func_kwargs = {'c': 2, 'b': 3}
    assert arg_replacer.get_old_value(test_func_args, test_func_kwargs) == 1
    assert arg_replacer.get_old_value(test_func_args, test_func_kwargs, default = 4) == 1
    assert arg_replacer.get_old_value(test_func_args, test_func_kwargs, default = 4) != 2
    assert arg_replacer.get_old_value(test_func_args, test_func_kwargs, default = 4) != 3

# Generated at 2022-06-12 14:21:05.629615
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class ClassA(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ClassA

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return ClassA

    with pytest.raises(NotImplementedError):
        Configurable.configurable_base()
    with pytest.raises(NotImplementedError):
        Configurable.configurable_default()

    assert issubclass(ClassA, Configurable)
    assert ClassA.configurable_base() == ClassA
    assert ClassA.configurable_default() == ClassA

    with pytest.raises(NotImplementedError):
        Configurable.configure(42) 

# Generated at 2022-06-12 14:21:17.055664
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_args_kwargs(a, b, c, d=1, e=2):
        return a+b+c+d+e
    new_value = 5
    test_a = 4
    test_b = 6
    test_d = 7
    test_e = 8
    ac = ArgReplacer(func=test_args_kwargs, name='c')
    old_value = ac.get_old_value((test_a,test_b,test_e,test_d),kwargs={})
    new_value, args, kwargs = ac.replace(new_value,(test_a,test_b,test_e,test_d),kwargs={})
    test_args_kwargs(*args, **kwargs)
    assert new_value == old_value

# Generated at 2022-06-12 14:21:21.812077
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class C(Configurable):
        def __init__(self, a, b):
            # type: (...) -> None
            assert a == 1
            assert b == 2

    c = C(1, 2)
    assert isinstance(c, C)


# Generated at 2022-06-12 14:21:31.309216
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    arg_replacer = ArgReplacer(
        func=lambda x, y='', z='a': x + y + z, 
        name='y'
    )

    old_value = arg_replacer.get_old_value([1,], {}, None)
    assert old_value is None
    
    old_value = arg_replacer.get_old_value([1,2], {}, None)
    assert old_value is None

    old_value = arg_replacer.get_old_value([1,2], {'y':3}, None)
    assert old_value == 3

    old_value = arg_replacer.get_old_value([1,2], {'y':3,'z':4}, None)
    assert old_value == 3

    old_value = arg_replacer.get_old

# Generated at 2022-06-12 14:21:39.791103
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(arg1, arg2, arg3 = 1):
        pass

    args = ['arg1', 'arg2']
    kwargs = {'arg3': 5}
    arg_replacer = ArgReplacer(test_func, 'arg3')
    if arg_replacer.get_old_value(args, kwargs) != 5:
        raise ValueError('Test failed!')

    arg_replacer2 = ArgReplacer(test_func, 'arg1')
    if arg_replacer2.get_old_value(args, kwargs) != 'arg1':
        raise ValueError('Test failed!')


# Generated at 2022-06-12 14:21:42.856779
# Unit test for function errno_from_exception
def test_errno_from_exception():
    err_type = OSError
    err_inst = IOError
    assert errno_from_exception(err_type) == errno_from_exception(err_inst)



# Generated at 2022-06-12 14:21:43.507814
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass

# Generated at 2022-06-12 14:22:24.513183
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self, a, b=1, **kwargs):
            self.a = a
            self.b = b
            self.kwargs = kwargs

    class B(A):
        pass

    a = A(a=1)
    assert isinstance(a, A)
    assert not isinstance(a, B)
    assert a.a == 1
    assert a.b == 1
    assert a.kwargs == {}

    A.configure(B)
    a = A(a=1)
    assert isinstance(a, A)
    assert isinstance(a, B)
    assert a.a

# Generated at 2022-06-12 14:22:33.904710
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class Example(object):
        def __init__(self, *args, **kwargs):
            pass

    class ExampleSubclass(Example):
        pass

    class ExampleConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ExampleConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Example

        def initialize(self, *args, **kwargs):
            pass

    def check_example_configurable_instance(inst):
        # type: (Example) -> None
        assert isinstance(inst, Example)
        assert not isinstance(inst, ExampleSubclass)

    ec = ExampleConfigurable()
    check_example_

# Generated at 2022-06-12 14:22:39.755046
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class Foo(Configurable):
        def configurable_base(self):
            return Foo

        def configurable_default(self):
            return Bar

        def initialize(self, teststr):
            self.teststr = teststr

    class Bar(Foo):
        def initialize(self, teststr):
            super(Bar, self).initialize(teststr)
            self.teststr2 = teststr + "2"

    f = Foo("foo")
    assert isinstance(f, Foo)
    assert isinstance(f, Bar)
    assert f.teststr == "foo"

    # Make sure initialization arguments are passed to the child class
    class Baz(Foo):
        def initialize(self, foo, teststr):
            super(Baz, self).initialize(teststr)

# Generated at 2022-06-12 14:22:47.874174
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(*args, **kwargs):
        return args, kwargs

    old_args = ("first", "second", "third")
    old_kwargs = {"first": "first_kwarg"}
    new_kwarg = "new_kwarg"

    new_arg_replacer = ArgReplacer(test_func, 'first')
    # Replace argument positionally
    old_value_pos, new_args, new_kwargs = new_arg_replacer.replace("first", old_args, {})
    assert old_value_pos == "first"
    assert new_args == ("first", "second", "third")
    assert new_kwargs == {}

    # Replace argument with keyword

# Generated at 2022-06-12 14:22:54.752284
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func_arg_pos(a = 1, b = 2, c = 3, d = 4):
        return a, b, c, d

    replacer = ArgReplacer(func_arg_pos, 'b')
    old_value = replacer.get_old_value((), {'a': 10, 'b': 20, 'c': 30, 'd': 40},)
    assert old_value == 20



# Generated at 2022-06-12 14:23:03.154024
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import sys


    @decorator
    def dont_run_in_this_version():
        pass


    if sys.version_info < (3, 7):
        tornado_is_instance_type = tornado.web.Application.__instancecheck__


        def _instancecheck(cls, instance):
            return instance.__class__ == cls.__impl_class
    else:
        # On Python 3.7, we can use isinstance normally.
        tornado_is_instance_type = tornado.web.Application.__instancecheck__
        _instancecheck = tornado_is_instance_type

    class BaseClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return BaseClass

        @classmethod
        def configurable_default(cls):
            return DefaultImpl


# Generated at 2022-06-12 14:23:13.674429
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f1(a, b, *args):
        return a + b

    def f2(a, b, **kwargs):
        return a + b

    def f3(a, b, c, *args, **kwargs):
        return a + b + c

    def f4(a: int, b: int, *args) -> int:
        return a + b

    # Test for function f1
    a = ArgReplacer(func=f1, name='a')
    assert a.replace(new_value=2, args=(10,20), kwargs={}) == (10, (2, 20), {})
    assert a.replace(new_value=2, args=(10,20,30), kwargs={}) == \
        (10, (2, 20, 30), {})
    assert a.replace

# Generated at 2022-06-12 14:23:14.174326
# Unit test for method __new__ of class Configurable
def test_Configurable___new__(): pass

# Generated at 2022-06-12 14:23:20.461884
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Example(Configurable):
        def configurable_base(cls):
            return assert_type(cls, Example)
        def configurable_default(cls):
            return assert_type(cls, Example)
        def initialize(self, *args: Any, **kwargs: Any) -> None:
            pass

    Example.configure(Example)
    assert_type(Example(), Example)
    Example.configure(None)
    assert_type(Example(), Example)



# Generated at 2022-06-12 14:23:29.251145
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, *args, **kwargs):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    print(type(func))
    print(type(arg_replacer))
    print("Old value of arg 'b' : ", arg_replacer.get_old_value((1, 2, 3), {}))
    print("Old value of arg 'b' : ", arg_replacer.get_old_value((1, 2), {}))
    print("Old value of arg 'a' : ", arg_replacer.get_old_value((1, 2), {'a': 4}))
    print("Old value of arg 'c' : ", arg_replacer.get_old_value((1, 2), {'c': 4}))


# Generated at 2022-06-12 14:24:13.800569
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        __impl_class = None  # type: Optional[Type[Configurable]]
        __impl_kwargs = None  # type: Dict[str, Any]

        def __new__(cls, *args, **kwargs):
            # Weird return type to test mypy
            return super(A, cls).__new__(cls, *args, **kwargs)

        def __init__(self, args, **kwargs):
            self.args = args
            self.kw = kwargs
            self.init_args = args
            self.init_kw = kwargs

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return cls


# Generated at 2022-06-12 14:24:25.171613
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyConfigurable

        @classmethod
        def configurable_default(cls):
            return MyConfigurable

        def _initialize(self, **kwargs):
            self.kwargs = kwargs

    MyConfigurable.configure(None, foo="foo")
    assert MyConfigurable().kwargs == {"foo": "foo"}
    MyConfigurable.configure(None, foo="foo2")
    assert MyConfigurable().kwargs == {"foo": "foo2"}
    MyConfigurable.configure(None, bar="bar")
    assert MyConfigurable().kwargs == {"foo": "foo2", "bar": "bar"}
    MyConfigurable.configure("test_util.test_Configurable_initialize")

# Generated at 2022-06-12 14:24:35.563876
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass

    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(
        1, args=(0, 2, 3), kwargs={"c": 4}
    )
    assert old_value == 2
    assert args == (0, 1, 3)
    assert kwargs == {"c": 4}

    old_value, args, kwargs = arg_replacer.replace(
        1, args=(0, 3), kwargs={"b": 2, "c": 4}
    )
    assert old_value == 2
    assert args == (0, 3)
    assert kwargs == {"b": 1, "c": 4}

    old_value, args, kwargs = arg_

# Generated at 2022-06-12 14:24:44.122521
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def testfunc(a, b=1):
        # type: (Any, Any) -> Any
        pass
    ar = ArgReplacer(testfunc, "a")
    old_value, args, kwargs = ar.replace("new value", (1,), {})
    assert old_value == 1
    assert args == ("new value",)
    assert kwargs == {}
    ar = ArgReplacer(testfunc, "b")
    old_value, args, kwargs = ar.replace("new value", (1,), {})
    assert old_value == 1
    assert args == (1,)
    assert kwargs == {"b": "new value"}
    old_value, args, kwargs = ar.replace("new value", (), {"b": 1})
    assert old_value == 1
    assert args == ()

# Generated at 2022-06-12 14:24:50.709926
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    l = [1,2,3,4,5]
    # basic test
    replacer = ArgReplacer(test_ArgReplacer_get_old_value, 'new_value')
    old_value = replacer.get_old_value(l, {'new_value': 2}, 3)
    assert old_value == 2
    # test with no kwargs
    old_value = replacer.get_old_value(l, {}, 3)
    assert old_value == 3
    # test when the new value is not in the kwargs
    replacer = ArgReplacer(test_ArgReplacer_get_old_value, 'old_value')
    old_value = replacer.get_old_value(l, {'new_value': 2}, 3)
    assert old_value == 3

# Unit test

# Generated at 2022-06-12 14:24:57.898255
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class E(Exception):
        pass
    try:
        raise E(42, "foo", "bar")
    except E as e:
        assert errno_from_exception(e) == 42

    class E(Exception):
        def __init__(self, errno):
            self.errno = errno
    try:
        raise E(42)
    except E as e:
        assert errno_from_exception(e) == 42

    try:
        raise E(None)
    except E as e:
        assert errno_from_exception(e) == 42



# Generated at 2022-06-12 14:25:07.289041
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    class Test(Configurable):
        @classmethod
        def configurable_base(cls):
            return Test
        @classmethod
        def configurable_default(cls):
            return Test
        def initialize(self):
            self.initialized = True
    class Impl(Test):
        pass
    class KWArg(Test):
        def initialize(self, kw):
            self.kw = kw
    assert not hasattr(Test(), 'initialized')
    assert isinstance(Impl(), Impl)
    assert Impl().initialized
    assert KWArg(kw='foo').kw == 'foo'
    try:
        Impl(kw='bar')
        assert False
    except TypeError:
        pass
    try:
        Test(kw='bar')
        assert False
    except TypeError:
        pass


# Generated at 2022-06-12 14:25:17.565427
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(x, y, z):
        pass

    arg_replacer = ArgReplacer(func, 'x')
    assert arg_replacer.get_old_value((1, 2, 3), {'y': 2, 'z': 3}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'y': 2, 'z': 3}, 'default') == 1
    assert arg_replacer.get_old_value((1, 2), {'y': 2, 'z': 3}, 'default') == 1
    assert arg_replacer.get_old_value((1, 2), {'y': 2, 'z': 3}, 'default') == 1
    assert arg_replacer.get_old_value((1, 2, 3), {}, 'default') == 1
    assert arg_repl

# Generated at 2022-06-12 14:25:24.279699
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        # In this case e will have errno attribute (per errno.h)
        raise IOError()
    except IOError as e:
        errno = errno_from_exception(e)
        assert errno is not None
    try:
        # In this case e will not have errno attribute and args[0]
        # will be the errno code
        raise IOError(22, 'Invalid argument')
    except IOError as e:
        errno = errno_from_exception(e)
        assert errno == 22



# Generated at 2022-06-12 14:25:33.221244
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.escape import utf8
    from tornado.util import Configurable

    class Test(Configurable):
        @classmethod
        def configurable_base(cls):
            return Test

        @classmethod
        def configurable_default(cls):
            return A

        @classmethod
        def configure(cls, impl, **kwargs):
            super(Test, cls).configure(impl, **kwargs)
            if impl is None:
                impl = A
            cls._impl = impl

        def initialize(self):
            self.initialize_called = True

    class A(Test):
        pass

    class B(Test):
        pass

    self = AsyncTestCase()

    self.assertTrue(isinstance(Test(), A))
