

# Generated at 2022-06-12 14:16:42.431328
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from typing import cast; from six import with_metaclass
    class Base(with_metaclass(ConfigurableMetaclass, object)):
        def configurable_base(self):
            return self.__class__
        def configurable_default(self):
            return self.__class__
    class Impl(Base):
        def initialize(self, *a, **kw):
            self.a = a
            self.kw = kw
    base = Base()
    sub = type('Sub', (Base,), {'configurable_default': lambda: Impl})
    assert isinstance(Impl(), Base)
    assert not isinstance(Impl(), sub)
    assert isinstance(sub(), Base)
    assert isinstance(sub(), sub)
    assert not isinstance(sub(), Impl)
    assert cast(Impl, sub()).__class__

# Generated at 2022-06-12 14:16:44.423429
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        pass
    x = TestConfigurable()
    assert x is not None


# Generated at 2022-06-12 14:16:47.306250
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    # We can't actually call this function, but we can make sure
    # mypy understands the types.
    class MyError(Exception):
        pass

    def f():
        # type: () -> typing.NoReturn
        try:
            raise MyError()
        except:
            raise_exc_info(sys.exc_info())



# Generated at 2022-06-12 14:16:57.091491
# Unit test for function import_object
def test_import_object():
    class test_class():
        a=1
    # import_object imports by name
    assert(import_object('tornado.util') is tornado.util)
    assert(import_object('tornado.util.import_object').__name__ ==
          import_object.__name__)
    # When importing by name, returns new copy
    import_object.a = 1
    assert(import_object.a == 1)
    import_object('tornado.util.import_object').a = 2
    assert(import_object.a == 2)
    import_object.a = 1
    assert(import_object.a == 1)
    # When importing by name, requires full name

# Generated at 2022-06-12 14:17:06.038347
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_method(arg1, arg2, arg3):
        print(arg1)
        print(arg2)
        print(arg3)
    new_args = [3,4,5]
    old = ArgReplacer.replace(new_args[0], (1,2,3), {'arg2':'2','arg3':'3'})
    assert old[0] == 1
    assert old[1] == (3,2,3)
    assert old[2] == {'arg2':'2','arg3':'3'}
    old = ArgReplacer.replace(new_args[1], (1,2,3), {'arg2':'2','arg3':'3'})
    assert old[0] == 2
    assert old[1] == (1,4,3)

# Generated at 2022-06-12 14:17:09.356517
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test that the __init__ function is not called when the Configurable class
    # is created.
    class Test(Configurable):
        def configurable_base(self):
            return Test
        def configurable_default(self):
            return Test
        def initialize(self):
            pass
    # The initialize method should not be called
    t = Test()



# Generated at 2022-06-12 14:17:12.167103
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError
    except:
        raise_exc_info(sys.exc_info())
test_raise_exc_info()


# Fake enumerated type used for bitfields

# Generated at 2022-06-12 14:17:17.600748
# Unit test for function import_object
def test_import_object():
    # Testing for the __future__ import syntax requires a function
    # scope, so this test lives in a function.
    if hasattr(typing, 'TYPE_CHECKING'):
        import tornado.testing
        import tornado.test.util
        import tornado.test.util as test_util
        assert import_object('tornado.testing') is tornado.testing
        assert import_object('tornado.testing.util') is tornado.testing.util
        assert import_object('tornado.testing.util') is test_util



# Generated at 2022-06-12 14:17:21.350384
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import tornado.util
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    assert import_object('tornado.util') is tornado.util



# Generated at 2022-06-12 14:17:26.320963
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import tornado.web
    class Application(tornado.web.Application):
        def __init__(self, *args, **kwargs):
            print('Appliction.__init__ called')
            super().__init__(*args, **kwargs)
        def initialize(self, *args, **kwargs):
            print('Appliction.initialize called')
            super().initialize(*args, **kwargs)
    Application([], debug=True)
test_Configurable_initialize()


# Generated at 2022-06-12 14:17:43.064552
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class _C(Configurable):
        pass

    _C.configure(None)
    assert isinstance(_C(), _C)

    _C.configure("tests.util_test.DummyClass")
    assert isinstance(_C(), DummyClass)

    _C.configure(None)
    assert isinstance(_C(), _C)

    class _C2(_C):
        pass

    _C2.configure("tests.util_test.DummyClass2")
    assert isinstance(_C2(), DummyClass2)
    assert isinstance(_C(), DummyClass)

    _C.configure(None)
    assert isinstance(_C2(), DummyClass2)
    assert isinstance(_C(), _C)

    _C2.configure(None)

# Generated at 2022-06-12 14:17:53.486316
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def test_new(self):
        r = self.TestClass()
        self.assertIsInstance(r, self.TestImpl)
        self.assertEqual(r.initialize_called, set(["TestClass"]))
        self.assertEqual(r.init_called, set(["TestImpl"]))
    def test_new_args(self):
        r = self.TestClass(1, 2, foo=3)
        self.assertIsInstance(r, self.TestImpl)
        self.assertEqual(r.initialize_called, set(["TestClass"]))
        self.assertEqual(r.init_args, (1, 2))
        self.assertEqual(r.init_kwargs, {"foo": 3})
    def test_new_args_default(self):
        self.assertEqual

# Generated at 2022-06-12 14:17:55.698247
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    assert A()._initialize == A._initialize


# Generated at 2022-06-12 14:18:00.606458
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Top(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Top

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Middle1

        def initialize(self):
            # type: () -> None
            pass

    class Middle1(Top):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Top

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Bottom

        def initialize(self):
            # type: () -> None
            pass


# Generated at 2022-06-12 14:18:09.488095
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.httpclient import SimpleAsyncHTTPClient as HTTPClient

    # Check that the default settings work, and also that settings can be
    # changed globally.

    TestConf = Configurable("TestConf", {"x": "hello"}, {"x": "world"})

    class TestConf1(TestConf):
        pass

    class TestConf2(TestConf):
        pass

    class TestConf3(TestConf):
        pass

    TestConf.configure(TestConf1)
    assert isinstance(TestConf(), TestConf1)

    TestConf.configure(TestConf2, x="jupyter")
    assert isinstance(TestConf(), TestConf2)
    assert TestConf().x == "jupyter"


# Generated at 2022-06-12 14:18:11.132151
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def demo_func(*args, **kwargs):
        pass
    arg_replacer = ArgReplacer(demo_func, 'kwargs')
    arg_replacer.replace(1, (0,), {'kwargs': 0})


# Generated at 2022-06-12 14:18:18.301446
# Unit test for function import_object
def test_import_object():
    assert import_object("os.path") is os.path
    assert import_object("os") is os
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    try:
        import_object("tornado.escape.nonexistent")
        assert False, "should have raised ImportError"
    except ImportError:
        pass



# Generated at 2022-06-12 14:18:22.590842
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import tornado.util
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.util') is tornado.util
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8


# Generated at 2022-06-12 14:18:34.680949
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def _test(args, kwargs, name, new_value):
        before_args_id = id(args)
        before_kwargs_id = id(kwargs)
        before_value = kwargs.get(name)
        old_value, args, kwargs = ArgReplacer(lambda: None,
                                              name).replace(new_value,
                                                            args,
                                                            kwargs)
        after_args_id = id(args)
        after_kwargs_id = id(kwargs)
        after_value = kwargs.get(name)
        assert after_value == new_value
        assert old_value == before_value
        if before_args_id == after_args_id:
            assert args[0] == new_value
        else:
            assert args

# Generated at 2022-06-12 14:18:40.996902
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    """ Validate that raise_exc_info works as intended. """
    try:
        raise ValueError("Normal throw")
    except ValueError:
        exc_info = sys.exc_info()
        try:
            raise_exc_info(exc_info)
        except ValueError:
            _, exc_value, _ = sys.exc_info()
            assert str(exc_value) == "Normal throw"

    try:
        raise ValueError("Throw with traceback")
    except ValueError:
        exc_info = sys.exc_info()
        try:
            raise_exc_info(exc_info)
        except ValueError:
            _, exc_value, exc_tb = sys.exc_info()
            assert str(exc_value) == "Throw with traceback"

# Generated at 2022-06-12 14:18:48.989961
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = Configurable()
    instance = base.__new__(base)
    assert isinstance(instance, Configurable)



# Generated at 2022-06-12 14:18:55.918753
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        return (a, b, c)
    old_value, new_args, new_kwargs = ArgReplacer(func, 'b').replace(3, (1,2), {'c':4})
    print(old_value)
    print(new_args)
    print(new_kwargs)

test_ArgReplacer_replace()


# Generated at 2022-06-12 14:18:59.287044
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def initialize(self, x):
            self.x = x
    c = TestConfigurable(x=10)
    assert c.x == 10
test_Configurable_initialize()

# Generated at 2022-06-12 14:19:08.907965
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():  # pragma: nocover
    def f(x, y, z=3):
        pass

    r = ArgReplacer(f, "z")

    assert r.replace("new", (1, 2), {}) == (3, (1, 2), {})
    assert r.replace("new", (1, 2, 3), {}) == (3, (1, 2, "new"), {})
    assert r.replace("new", (), {"z": 5}) == (5, (), {"z": "new"})
    assert r.replace("new", (), {}) == (None, (), {"z": "new"})
    assert r.replace("new", (), {"z": 5, "w": 6}) == (
        5,
        (),
        {"z": "new", "w": 6},
    )



# Generated at 2022-06-12 14:19:20.181321
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    __tracebackhide__ = True
    import unittest
    import mock
    import tornado.escape
    import tornado.netutil
    import tornado.ioloop
    import tornado.web
    import tornado.websocket
    import tornado.test.util
    import tornado.test.web_test


    Configurable.configure("tornado.escape")
    self.assertIs(tornado.escape, Configurable())
    self.assertIs(tornado.escape.json_encode, Configurable.json_encode)
    self.assertIs(tornado.escape.json_encode, tornado.escape.configured_class().json_encode)
    self.assertNotIn("escape", sys.modules)

# Generated at 2022-06-12 14:19:30.068842
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Test replacement of positional arguments
    def foo(x, y, z):
        pass
    a = ArgReplacer(foo, "y")
    old_y, args, kwargs = a.replace(0, [1, 2, 3], {})
    assert old_y == 2
    assert args == [1, 0, 3]
    assert kwargs == {}
    # Test replacement of keyword arguments
    def foo(x, y, z):
        pass
    a = ArgReplacer(foo, "y")
    old_y, args, kwargs = a.replace(0, [1], {"y": 2, "z": 3})
    assert old_y == 2
    assert args == [1]
    assert kwargs == {"y": 0, "z": 3}
    # Test adding keyword arguments

# Generated at 2022-06-12 14:19:41.129530
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    try:
        Configurable()
        assert False
    except NotImplementedError:
        pass

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

    assert A.configured_class() is A

    class A2(Configurable):
        def __new__(cls, *args, **kwargs):
            return A.__new__(cls, *args, **kwargs)

    class A3(Configurable):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-12 14:19:47.011107
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    testClass = ArgReplacer(test_ArgReplacer_replace, 'name')
    name1=testClass.replace('new_value', [3,4,5,6], {'name':'old_value'})
    assert name1 == ('old_value', [3,4,5, 'new_value'], {'name': 'new_value'})
    name2=testClass.get_old_value([3,4,5,6], {'name':'old_value'})
    assert name2 == 'old_value'
    name3=testClass.replace('new_value', [3,4,5,6], {'names':'old_value'})
    assert name3 == (None, [3,4,5,6], {'names':'old_value', 'name':'new_value'})


# Generated at 2022-06-12 14:19:56.353102
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class TestClass(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TestClass

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestClass

    TestClass.configure(TestClass)
    assert TestClass()  # __new__ of TestClass
    TestClass.configure(None)
    assert TestClass()  # __new__ of TestClass
    TestClass.configure(TestClass)
    assert TestClass()  # __new__ of TestClass



# Generated at 2022-06-12 14:20:03.192114
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
        def initialize(self, x, y):
            self.x = x
            self.y = y
    C.configure(None)
    c = C(x=1, y=2)
    assert c.x == 1
    assert c.y == 2
# Unit tests for method configure of class Configurable

# Generated at 2022-06-12 14:20:25.830196
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class TestArgReplacer(ArgReplacer):
        def __init__(self, func, name):
            super(TestArgReplacer, self).__init__(func, name)

    def f(a, b, c=None, d=None):
        pass

    a = TestArgReplacer(f, 'a')
    new_value = 1
    assert a.replace(new_value, (2, 3), {'c':4, 'd':5}) == (2, (1, 3), {'c':4, 'd':5})
    new_value = 2
    assert a.replace(new_value, (1, 3), {'c':4, 'd':5}) == (1, (2, 3), {'c':4, 'd':5})
    new_value = 3

# Generated at 2022-06-12 14:20:30.914915
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado import ioloop, httpclient, testing
    import unittest
    import weakref

    # This is a configurable class for testing purposes.
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return OriginalFoo

        def initialize(self):
            self.initialized = True
            self.f()

        def f(self):
            pass

    class OriginalFoo(Foo):
        pass

    class OverrideFoo(Foo):
        pass

    class OverrideFoo2(Foo):
        pass

    class ConfigurableTest(unittest.TestCase):
        def test_configurable(self):
            Foo.configure(OriginalFoo)
            self.assertIs

# Generated at 2022-06-12 14:20:41.565808
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class TestArgs(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # 1. The arg to replace is passed positionally.
    tr = ArgReplacer(TestArgs, "args")
    assert tr.arg_pos == 0

    args = ("a", )
    kwargs = {"b": 2}

    old_value, new_args, new_kwargs = tr.replace("args1", args, kwargs)
    assert old_value == "a"
    assert new_args == ("args1", )
    assert new_kwargs == {"b": 2}

    # 2. The arg to replace is either omitted or passed by keyword.
    tr = ArgReplacer(TestArgs, "b")
    assert tr.arg_pos

# Generated at 2022-06-12 14:20:50.437381
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    x_args = ("a", "b", "c")
    x_kwargs = {"a": 1, "b": 2, "c": 3, "d": 4}
    _, y_args, y_kwargs = ArgReplacer(test_ArgReplacer_replace, "d").replace("f", x_args, x_kwargs)
    assert y_args == ("a", "b", "c")
    assert y_kwargs == {"a": 1, "b": 2, "c": 3, "d": "f"}
    _, y_args, y_kwargs = ArgReplacer(test_ArgReplacer_replace, "c").replace("f", x_args, x_kwargs)
    assert y_args == ("a", "b", "f")

# Generated at 2022-06-12 14:20:55.909261
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=1):
        return 0
    ar = ArgReplacer(func, 'b')
    assert ar.get_old_value((2,), {}, 0) == 1
    assert ar.get_old_value((2,), {'b': 2}, 0) == 2
    assert ar.get_old_value((2,), {'a': 2}, 0) == 0


# Generated at 2022-06-12 14:21:07.569635
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func1 = lambda x: x
    assert ArgReplacer(func1, 'x').get_old_value((1,), {}, 2) == 1
    func2 = lambda x, y: x
    assert ArgReplacer(func2, 'y').get_old_value((1, 2), {}, 3) == 2
    func3 = lambda x, y=10: x
    assert ArgReplacer(func3, 'x').get_old_value((1,), {}, 2) == 1
    assert ArgReplacer(func3, 'y').get_old_value((1,), {}, 2) == 10
    assert ArgReplacer(func3, 'y').get_old_value((1,), {'y':3}, 2) == 3

# Generated at 2022-06-12 14:21:19.102809
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock

    class FakeConfigurable(Configurable):
        __impl_class = None  # type: Optional[Type[Configurable]]
        __impl_kwargs = None  # type: Dict[str, Any]

        @classmethod
        def configurable_base(cls):
            return cls  # type: ignore

        @classmethod
        def configurable_default(cls):
            return FakeConfigurable  # type: ignore

        def initialize(self, *args: Any, **kwargs: Any):
            pass

    with unittest.mock.patch('tornado.util.Configurable.configured_class', FakeConfigurable):
        with unittest.mock.patch('tornado.util.Configurable.__impl_class', FakeConfigurable):
            import_

# Generated at 2022-06-12 14:21:29.629800
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun(arg1, arg2=2, arg3=3):
        pass
    replacer1 = ArgReplacer(fun, "arg1")
    _, args, kwargs = replacer1.replace(6, (1,), dict(arg2=7))
    assert args == (6,), args
    assert kwargs == dict(arg2=7), kwargs
    _, args, kwargs = replacer1.replace(6, (1,), dict(arg1=7))
    assert args == (1,), args
    assert kwargs == dict(arg1=6), kwargs
    _, args, kwargs = replacer1.replace(6, (1,), dict())
    assert args == (1,), args
    assert kwargs == dict(arg1=6), kwargs

# Generated at 2022-06-12 14:21:36.868404
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
  def arg_replace_test(new_value, args, kwargs):
    replacer = ArgReplacer(arg_replace_test, 'a')
    
    old_value, args, kwargs = replacer.replace(new_value, args, kwargs)

    assert(args[0] == new_value)

  arg_replace_test(1, (2,), {})
  arg_replace_test(1, (), {'a': 2})
  arg_replace_test(1, (2,), {'a': 2})



# Generated at 2022-06-12 14:21:41.792345
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # parameter num is passed positionally
    def foo(num, str):
        pass

    a = ArgReplacer(foo, "num")
    assert a.get_old_value((1, "str"), {}) == 1
    # parameter num is not passed
    assert a.get_old_value(("str",), {}) is None
    # parameter num is passed by keyword
    assert a.get_old_value(("str",), {"num": 1}) == 1
    # parameter num has a default value
    def foo(num=0, str=""):
        pass

    a = ArgReplacer(foo, "num")
    assert a.get_old_value(("str",), {}) == 0

# Generated at 2022-06-12 14:22:25.214794
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fn1(a=1):
        pass
    def fn2(a,b=1):
        pass
    # Test 1:
    arg = ArgReplacer(fn1, "a")
    old_value = arg.get_old_value((), {})
    assert old_value == 1
    # Test 2:
    old_value = arg.get_old_value((), {"a":2})
    assert old_value == 2
    # Test 3:
    old_value = arg.get_old_value((3,), {})
    assert old_value == 3
    # Test 4:
    arg = ArgReplacer(fn2, "a")
    old_value = arg.get_old_value((), {"a":2})
    assert old_value == 2
    # Test 5:

# Generated at 2022-06-12 14:22:29.888330
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(123)
    except IOError as e:
        assert errno_from_exception(e) == 123

    class FakeException(Exception):
        pass

    try:
        raise FakeException("foo")
    except FakeException as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-12 14:22:37.433915
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

    class B(A):
        def initialize(self):
            # type: () -> None
            pass

    class C(A):
        def initialize(self):
            # type: () -> None
            pass

    object_a = A()
    object_b = B()
    object_c = C()
    assert isinstance(object_a, A)
    assert isinstance(object_b, B)
    assert isinstance(object_c, C)
    assert not isinstance(object_a, B)

# Generated at 2022-06-12 14:22:41.555137
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from abc import ABCMeta

    class ConfigurableClass (metaclass=ABCMeta):
        def __new__(cls, *args, **kwargs):
            pass

    class ExtendedConfigurableClass (ConfigurableClass):
        pass

    instance = ExtendedConfigurableClass()


# Generated at 2022-06-12 14:22:48.658844
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a: int, b: int, c: int = 1) -> int:
        return a+b

    test_arg = ArgReplacer(test_func, 'b')
    assert test_arg.replace(3, (1,2,), {}) == (2, (1,3,), {})
    assert test_arg.replace(3, (1,2,), {'c': 2}) == (2, (1,3,), {'c': 2})
    assert test_arg.replace(3, (1,), {'b': 2, 'c': 3}) == (2, (1,), {'b': 3, 'c': 3})

# Generated at 2022-06-12 14:22:50.539171
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    func = get_old_value
    replacer = ArgReplacer(func, 'name')
    old_value = replacer.get_old_value([],{'name':'value'})
    assert old_value == 'value'


# Generated at 2022-06-12 14:22:57.090717
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

    class Impl(Base):
        def initialize(self, a=None, b=None, c=None, d=None):
            print("Impl initialization")
            Base.initialize(self, a=a, b=b, c=c, d=d)

    Base.configure(Impl, b=2, d=4)
    instance = Base()
    raise NotImplementedError()

# Generated at 2022-06-12 14:23:01.874769
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Cls1(Configurable):
        pass
    with pytest.raises(NotImplementedError):
        t = Cls1()
    class Cls2(Configurable):
        @classmethod
        def configurable_base(cls):
            return Cls1
        @classmethod
        def configurable_default(cls):
            return Cls1
    t = Cls2()
    assert t


# Generated at 2022-06-12 14:23:12.385151
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Test what happens in Configurable.__new__ when we subclass
    # Configurable
    class BaseFoo(Configurable):
        def __init__(self):
            # type: () -> None
            self.value = 'b'

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

    class SubFoo(BaseFoo):
        def __init__(self):
            # type: () -> None
            self.value = 's'

    assert isinstance(BaseFoo(), SubFoo)
    assert isinstance(BaseFoo(), BaseFoo)

# Generated at 2022-06-12 14:23:15.499259
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    """
    #--[[ Test for Configurable.initialize ]]--#
    """
    import_object('tornado.util')

    #--[[ TEST ]]--#
    class Dummy(Configurable):
        pass

    Dummy.configure("tornado.util")



# Generated at 2022-06-12 14:24:25.585008
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class BaseClass(Configurable):
        def configurable_base():
            return "BaseClass"

        def configurable_default():
            return "BaseClassDefault"

    base_instance = BaseClass()
    assert isinstance(base_instance, BaseClass)
    assert isinstance(base_instance, BaseClass.configured_class())
    assert isinstance(base_instance, BaseClass.configurable_default())

    class SubClass1(BaseClass):
        def configurable_base():
            return "BaseClass"

        def configurable_default():
            return "SubClass1Default"

    base_instance = SubClass1()
    assert isinstance(base_instance, SubClass1)
    assert isinstance(base_instance, BaseClass)
    assert isinstance(base_instance, SubClass1.configured_class())

# Generated at 2022-06-12 14:24:35.886860
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class MyClass(object):
        def foo(self, x, y, z=None):
            return x, y, z, self

    MyClass = functools.partialmethod(MyClass, "bar")
    arg_replacer = ArgReplacer(MyClass.__wrapped__, "x")

    # Note: This test case is not comprehensive, but it does at
    # least exercise the code paths that differ from the 3-argument
    # version of ArgReplacer.replace
    assert arg_replacer.replace(1, (2,), {}) == (2, (1,), {})
    assert arg_replacer.replace(
        1, (2,), {"z": 3}
    ) == (2, (1,), {"z": 3})

# Generated at 2022-06-12 14:24:43.041734
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def myfn(first, second = None):
        print(first, second)
    ar = ArgReplacer(myfn, 'second')
    old, a2, k2 = ar.replace('second value', ('first value',), {})
    assert old == None
    assert a2 == ('first value',)
    assert k2 == {}
    old, a2, k2 = ar.replace('new second value', ('first value',), {'second': 'second value'})
    assert old == 'second value'
    assert a2 == ('first value',)
    assert k2 == {}
#Unit test for method get_old_value of class ArgReplacer

# Generated at 2022-06-12 14:24:45.394312
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Sub(Configurable):
        def initialize(self, *args, **kwargs):
            super().initialize(*args, **kwargs)

    instance = Sub()
    assert instance.initialize is not None



# Generated at 2022-06-12 14:24:53.121282
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test1(a, b=None):
        pass
    obj = ArgReplacer(test1, "b")
    assert obj.get_old_value((0, ), {}, None) == None
    assert obj.get_old_value((1, 2), {}, None) == 2
    assert obj.get_old_value((1, ), {"b":2}, None) == 2
    def test2(a, b):
        pass
    obj = ArgReplacer(test2, "b")
    assert obj.get_old_value((0, 1), {}, None) == 1
    assert obj.get_old_value((1, ), {"b":2}, None) == 2


# Generated at 2022-06-12 14:24:57.939310
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b):
        return a, b
    r = ArgReplacer(f, 'b')
    args, kwargs = r.replace(4, (1, 2), {})
    assert args == (1, 4)
    args, kwargs = r.replace(4, (1,), {'b': 2})
    assert kwargs == {'b': 4}

# Generated at 2022-06-12 14:25:07.334418
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    replacer = ArgReplacer(foo, "c")
    t = replacer.replace(42, (1, 2, 3), {})
    assert t == (3, (1, 2, 42), {})
    t = replacer.replace(42, (1, 2), {"c": 3})
    assert t == (3, (1, 2), {"c": 42})
    t = replacer.replace(42, (1,), {"b": 2, "c": 3})
    assert t == (3, (1,), {"b": 2, "c": 42})
    t = replacer.replace(42, (), {"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-12 14:25:17.662461
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A:
        pass
    a = A()
    class B(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return cls
        def initialize(self, *args, **kwargs):
            pass
    assert B() == B()
    assert isinstance(B(), B)
    assert B().__class__ == B
    #
    assert A().__class__ == A
    assert A().__class__ == A
    assert A().__class__ == A
    assert A().__class__ == A
    #
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

# Generated at 2022-06-12 14:25:22.026146
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def get_site_prefs(a: str, b: str, c: str) -> str:
        return a + b + c

    replacer = ArgReplacer(get_site_prefs, "b")
    assert replacer.get_old_value(['a', 'b', 'c'], {}) == 'b'


# Generated at 2022-06-12 14:25:27.449930
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Test(Configurable):
        pass

    Test.configure("object")

    config = Configurable._save_configuration()

    class Test(Configurable):
        def initialize(self, i, *args):
            self.i = i
            self.args = args

    Test.configure("object")

    test = Test(1, 2, 3, 4)

    assert test.i == 1
    assert test.args == (2, 3, 4)

    Configurable._restore_configuration(config)

