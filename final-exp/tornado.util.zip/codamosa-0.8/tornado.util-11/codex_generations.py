

# Generated at 2022-06-12 14:16:57.210962
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=None):
        return a + b + c

    new_d = 4
    arg_replacer = ArgReplacer(f, 'd')

    assert arg_replacer.get_old_value((1, 2), {}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {}) == None
    assert arg_replacer.get_old_value((1, 2, 3, 4), {}) == 4
    assert arg_replacer.get_old_value((1, 2, 3, 4), {'d':None}) == 4
    assert arg_replacer.get_old_value((1, 2, 3, 4), {'d':4}) == 4

# Generated at 2022-06-12 14:17:06.545412
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def wrapped_method(a: str, b: str, c: str = "", d: str = "") -> None:
        pass
    arg_replacer = ArgReplacer(wrapped_method, "c")
    assert arg_replacer.replace("x", ("a", "b",), {"c": "c", "d": "d"}) == (
        "c",
        ("a", "b",),
        {"c": "x", "d": "d"},
    )
    assert arg_replacer.replace("x", ("a", "b", "c",), {"d": "d"}) == (
        "c",
        ("a", "b", "x",),
        {"d": "d"},
    )

# Generated at 2022-06-12 14:17:11.316277
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.web.client import SimpleAsyncHTTPClient
    from tornado.ioloop import IOLoop
    import tornado.util
    import datetime
    assert isinstance(IOLoop(), IOLoop)
    assert isinstance(SimpleAsyncHTTPClient(), SimpleAsyncHTTPClient)
    if tornado.util.is_finalizing():
        raise tornado.web.HTTPError(404)
    if datetime.datetime.now().second % 2 == 0:
        raise tornado.web.HTTPError(404)

# Generated at 2022-06-12 14:17:16.797094
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # type: () -> None
    try:
        raise IOError(2, "test")
    except Exception as e:
        matched = errno_from_exception(e)
        assert matched == 2
        assert e.errno == 2
    try:
        raise IOError("test")
    except Exception as e:
        matched = errno_from_exception(e)
        assert matched is None
        assert e.errno is None
    try:
        raise IOError(2)
    except Exception as e:
        matched = errno_from_exception(e)
        assert matched == 2
        assert e.errno == 2
    try:
        raise IOError()
    except Exception as e:
        matched = errno_from_exception(e)
        assert matched is None

# Generated at 2022-06-12 14:17:22.220133
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=0, e=0, f=0):
        pass

    arg_replacer = ArgReplacer(func, 'c')
    old_value = arg_replacer.get_old_value((1, 2, 3, 4, 5, 6), {}, default='abc')
    old_value1 = arg_replacer.get_old_value((1, 2, 3), {'d':4, 'e':5}, default='abc')
    assert old_value == 3
    assert old_value1 == 3

# Generated at 2022-06-12 14:17:22.965313
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass


# Generated at 2022-06-12 14:17:30.240186
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_with_args(a, b, c, d):
        return (a, b, c, d)
    replacer = ArgReplacer(func_with_args, 'd')
    old_value, args, kwargs = replacer.replace(100, (1, 2, 3), {'d': 4})
    assert (old_value, args, kwargs) == (None, (1, 2, 3, 100), {})
    old_value, args, kwargs = replacer.replace(100, (1, 2, 3, 4), {})
    assert (old_value, args, kwargs) == (4, [1, 2, 3, 100], {})

# Generated at 2022-06-12 14:17:41.551709
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import_object = import_object
    Configurable = Configurable
    class Base(Configurable):
        pass
    class Class1(Base):
        pass
    class Class1_1(Base):
        pass
    class Class2(Base):
        pass
    class Class2_1(Base):
        pass
    class Class3(Base):
        pass
    def test_initialize_1():
        x = Class1('foo')
        assert x.initialize_args == ('foo',)

    def test_initialize_2():
        x = Class1(foo='foo')
        assert x.initialize_args == ()
        assert x.initialize_kwargs == {'foo': 'foo'}

    def test_configure_1():
        Class1.configure(Class2)
        x = Class1()
       

# Generated at 2022-06-12 14:17:42.858341
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    Configurable.configure(Configurable)



# Generated at 2022-06-12 14:17:52.293346
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class _ConfigurableTest(Configurable):
        def __init__(self):
            raise NotImplementedError()

    class _ConfigurableSubclassTest(_ConfigurableTest):
        def __init__(self):
            raise NotImplementedError()

    test = _ConfigurableTest()
    assert type(test) == _ConfigurableTest
    test = _ConfigurableSubclassTest()
    assert type(test) == _ConfigurableSubclassTest


# A thread pool, used for bulk operations on all IOLoops.
global_thread_pool = ThreadPoolExecutor(16)


# Fake thread object.  Can't get the ident of a ThreadPoolExecutor's
# threads, so we fake it.

# Generated at 2022-06-12 14:18:09.885629
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        __impl_class = None  # type: Optional[Type[Configurable]]
        __impl_kwargs = None  # type: Dict[str, Any]

        def __new__(cls, *args: Any, **kwargs: Any) -> Any:
            base = cls.configurable_base()
            init_kwargs = {}  # type: Dict[str, Any]
            if cls is base:
                impl = cls.configured_class()
                if base.__impl_kwargs:
                    init_kwargs.update(base.__impl_kwargs)
            else:
                impl = cls
            init_kwargs.update(kwargs)

# Generated at 2022-06-12 14:18:14.259689
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(x, y):
        return x + y
    arg_replacer = ArgReplacer(func=test_func, name='x')
    print(arg_replacer)
    print(arg_replacer.name)
    print(arg_replacer.arg_pos)
    # old_value will be 2
    # args will be (10, y)
    # kwargs will be {}
    # return value will be (2, (10, y), {})
    test_args = (2, 3)
    test_kwargs = {}
    print(arg_replacer.replace(new_value=10, args=test_args, kwargs=test_kwargs))

# Generated at 2022-06-12 14:18:14.985002
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():...

# Generated at 2022-06-12 14:18:23.364441
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    Configurable.configure(None)
    class SubConfigurable(Configurable):
        pass
    configurable0 = SubConfigurable()
    assert isinstance(configurable0, SubConfigurable)
    assert isinstance(configurable0, Configurable)
    SubConfigurable.configure(lambda: 5)
    configurable1 = SubConfigurable()
    configurable1a = SubConfigurable()
    assert configurable1a == 5
    SubConfigurable.configure(int)
    configurable2 = SubConfigurable()
    assert configurable2 == 0


# Generated at 2022-06-12 14:18:26.575751
# Unit test for function import_object
def test_import_object():
    assert import_object('mako.template').Template is not None
    assert import_object('nonexistent_module')



# Generated at 2022-06-12 14:18:36.481310
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import sys

    import tornado.ioloop

    class BaseConfigurable(Configurable):
        """Configurable base class for testing.

        Subclasses must define `._test_arg_name` and `._test_kwarg_name`,
        which must match the arguments to their constructors.

        """

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            """Returns the default class to use when none is configured."""
            return cls

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            """Returns the base class of a configurable hierarchy."""
            return BaseConfigurable


# Generated at 2022-06-12 14:18:38.647006
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    obj = ObjectDict()
    obj.t = 1
    assert obj.t == 1
    assert obj['t'] == 1
    assert 't' in obj



# Generated at 2022-06-12 14:18:39.765842
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    #assert isinstance(o.a,  AttributeError)


# Generated at 2022-06-12 14:18:42.834568
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class TestConfigurable(Configurable):
        def __init__(self):
            raise RuntimeError("initialize() must be used")

        def initialize(self):
            pass

    TestConfigurable()



# Generated at 2022-06-12 14:18:45.566868
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConfigurableTest(Configurable):
        def initialize(self):
            self.a = 1
            pass  # type: ignore
        @classmethod
        def configurable_base(cls):
            return ConfigurableTest
        @classmethod
        def configurable_default(cls):
            pass  # type: ignore
    assert ConfigurableTest().a == 1


# Generated at 2022-06-12 14:19:11.303031
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func1(a,b):
        return a,b
    def func2(a,b,c=None):
        return a,b,c
    def func3(a,b,**kwargs):
        return a,b,kwargs
    def func4(a,b,c=None,d=None,**kwargs):
        return a,b,c,d,kwargs
    def func5(*args,**kwargs):
        return args, kwargs

    assert ArgReplacer(func1, 'b').replace(2,(1,),{}) == (1, (1, 2), {})
    assert ArgReplacer(func1, 'b').replace(2,(1,1),{}) == (1, (1, 1, 2), {})

# Generated at 2022-06-12 14:19:13.667815
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import inspect

    class A:
        pass

    a = A()
    # no exception should be raised
    print(a)



# Generated at 2022-06-12 14:19:24.642520
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Configurable_subclass(Configurable):
        __impl_class = None
        __impl_kwargs = None

        @classmethod
        def configurable_base(cls):
            return Configurable_subclass

        @classmethod
        def configurable_default(cls):
            return Configurable_subclass

    # Interface is used by default
    impl = Configurable_subclass()
    assert isinstance(impl, Configurable_subclass)
    # ValueError is raised for invalid impl
    impl = Configurable_subclass.configure(object())
    assert impl is None
    # impl is used after being configured
    impl = Configurable_subclass.configure(Configurable_subclass)
    assert isinstance(impl, Configurable_subclass)
    # Utility function returns previously-configured impl
    assert Configurable_sub

# Generated at 2022-06-12 14:19:32.795890
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class DummyClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return object

    try:
        dummy = DummyClass()
    except:
        dummy = None
    assert type(dummy) == object

    class DummyClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return object

    assert DummyClass._Configurable__impl_class is None
    assert DummyClass._Configurable__impl_kwargs is None


try:
    import typing
except ImportError:
    pass
else:
    from typing import Any, Callable, Dict, List, Mapping

# Generated at 2022-06-12 14:19:33.494319
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass



# Generated at 2022-06-12 14:19:43.636686
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    """Unit test for method initialize of class Configurable

    This test is only for tornado.util.Configurable.
    """
    from unittest.mock import call

    from .httpserver import HTTPServer
    from .platform.asyncio import AsyncIOMainLoop
    from .iostream import BaseIOStream
    from .tcpserver import TCPServer

    assert (
        HTTPServer.__dict__["initialize"] is not HTTPServer.__dict__["__init__"]
    )
    assert HTTPServer.__dict__["initialize"] is not Configurable.initialize

    assert (
        AsyncIOMainLoop.__dict__["initialize"] is not AsyncIOMainLoop.__dict__["__init__"]
    )

# Generated at 2022-06-12 14:19:56.312470
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    if sys.version_info < (3, 5):

        class NullConfigurable(Configurable):
            @classmethod
            def configurable_base(cls):
                return cls

            @classmethod
            def configurable_default(cls):
                return cls

            def initialize(self, x=None, y=None):
                self.x = x
                self.y = y

        ins = NullConfigurable(x=1, y=2)
        assert ins.x == 1 and ins.y == 2
        ins = NullConfigurable()
        assert ins.x is None and ins.y is None
        ins = NullConfigurable(y=1)
        assert ins.x is None and ins.y == 1
    else:
        # TODO: test the initialize function in Python 3.6.3
        pass

#

# Generated at 2022-06-12 14:20:05.943509
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        # raise exception with errno set
        raise IOError(5, "err")
    except IOError as e:
        assert errno_from_exception(e) == 5
    try:
        # raise exception without errno
        raise IOError
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        # raise exception with errno set to None
        raise IOError(None, "err")
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        # raise exception with errno set to 0
        raise IOError(0, "err")
    except IOError as e:
        assert errno_from_exception(e) == 0



# Generated at 2022-06-12 14:20:16.531223
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock

    class Test(Configurable):
        @classmethod
        def configurable_base(cls):
            return Test

        @classmethod
        def configurable_default(cls):
            return Test

        def initialize(self, some_arg=None):
            pass

    assert Test().__class__ is Test

    class OtherTest(Test):
        def initialize(self, some_arg=None):
            pass

    assert OtherTest().__class__ is OtherTest

    Test.configure(OtherTest, some_arg="hello")

    assert Test().__class__ is OtherTest
    assert OtherTest().__class__ is OtherTest

    # make sure the configure() method is robust against
    # version changes in Configurable

# Generated at 2022-06-12 14:20:22.611315
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def testFunc(a: Any, b: Any, c: Any) -> Any:
        pass

    args = (1, 2, 3)
    kwargs = {'c': 6, 'd': 4}
    argReplacer = ArgReplacer(testFunc, 'c')
    old_value, args, kwargs = argReplacer.replace(9, args, kwargs)
    assert (old_value == 6)
    assert (args == (1, 2, 9))
    assert (kwargs == {'c': 9, 'd': 4})



# Generated at 2022-06-12 14:21:11.180037
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(foo,bar):
        return None
    replacer = ArgReplacer(func,'foo')
    assert replacer.get_old_value((1,2),{'bar':2}, default=None) == 1
    assert replacer.get_old_value((2,3),{'foo':3}, default=None) == 2
    assert replacer.get_old_value((1,2),{'foo':3}, default=None) == 3


# Generated at 2022-06-12 14:21:22.812741
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    import tornado.web

    class MyRequestHandler(tornado.web.RequestHandler):
        pass

    class MyApplication(tornado.web.Application):
        pass

    class MyApplication1(MyApplication):
        pass

    class BaseConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return BaseConfigurable

        @classmethod
        def configurable_default(cls):
            return MyApplication

    class SubConfigurable(BaseConfigurable):
        @classmethod
        def configurable_base(cls):
            return BaseConfigurable

        @classmethod
        def configurable_default(cls):
            return MyApplication1

    class TestConfigurable(unittest.TestCase):
        def test_configurable(self):
            app = BaseConfigurable()


# Generated at 2022-06-12 14:21:26.009263
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    class TestClassA:
        def __init__(self) -> None:
            pass
    a = TestClassA()
    a.b = 'abc'
    print(a.b)


# Generated at 2022-06-12 14:21:32.523384
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import tornado.httpserver
    import tornado.ioloop
    saved = tornado.httpserver.HTTPServer._save_configuration()
    try:
        tornado.httpserver.HTTPServer.configure('tornado.test.httpserver_new.HTTPServer')
        assert tornado.httpserver.HTTPServer is tornado.test.httpserver_new.HTTPServer
        assert tornado.httpserver.HTTPServer().initialize().__class__ is tornado.test.httpserver_new.HTTPServer
    finally:
        tornado.httpserver.HTTPServer._restore_configuration(saved)


# Generated at 2022-06-12 14:21:37.667518
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        _x = None
        def initialize(self, x):
            self._x = x

    class Bar(Foo):
        def initialize(self):
            super().initialize(42)
    f = Foo(1)
    assert f._x == 1
    b = Bar()
    assert b._x == 42



# Generated at 2022-06-12 14:21:38.759883
# Unit test for function import_object
def test_import_object():
    test_modules = ['tornado']
    for module in test_modules:
        print("Module " + module + " imported!")
    return True


# Generated at 2022-06-12 14:21:47.762466
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=1, *args):
        pass

    args = ('a', 'b')
    kwargs = {'b': 2, 'c': 3}

    arg_replacer = ArgReplacer(func, 'a')
    assert(arg_replacer.get_old_value(args, kwargs, default=None) == 'a')

    arg_replacer = ArgReplacer(func, 'b')
    assert(arg_replacer.get_old_value(args, kwargs, default=None) == 2)

    arg_replacer = ArgReplacer(func, 'c')
    assert(arg_replacer.get_old_value(args, kwargs, default=None) == 3)

    arg_replacer = ArgReplacer(func, 'd')

# Generated at 2022-06-12 14:21:52.738379
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class _Configurable(Configurable):
        def initialize(self):
            pass
        @classmethod
        def configurable_base(cls):
            return _Configurable
        @classmethod
        def configurable_default(cls):
            return _Configurable
    # Instantiate _Configurable
    _Configurable()

_can_use_ipv6 = None  # type: Optional[bool]


# Generated at 2022-06-12 14:21:57.629950
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Should not throw an error
    Configurable.configure('test')
    Configurable.configure(None)
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return None
    Base.configure(None)
    Base.configure('test')


# Generated at 2022-06-12 14:22:05.785411
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Issue #5823: initialize method of Configurable subclass should not
    # be called multiple times, in particular when the Configurable
    # subclass is used as the base class of another subclass.
    class A(Configurable):
        initialized = False

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a=0, b=1):
            if A.initialized:
                raise Exception("initialize called more than once")
            A.initialized = True
            self.a = a
            self.b = b

    class B(A):
        pass

    b = B()
    assert not A.initialized  # should not be called yet
    assert b.a == 0
    assert b.b == 1




# Generated at 2022-06-12 14:22:59.775671
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-12 14:23:04.825702
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError as e:
        assert str(e) == 'No module named missing_module'
    else:
        raise AssertionError("Did not get expected exception")


# Generated at 2022-06-12 14:23:08.669794
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """
    Test the __new__ method of class Configurable
    """
    cls = Configurable
    cls.__impl_class = None # type: ignore
    cls.__impl_kwargs = None # type: ignore
    cls.configurable_base = lambda: Configurable
    cls.configurable_default = lambda: Configurable
    cls.configure(object)
    assert isinstance(Configurable(), object)
    assert not isinstance(Configurable(), Configurable)
    cls.configure(None)
    assert isinstance(Configurable(), Configurable)
    assert not isinstance(Configurable(), object)


# This is a variant that doesn't require Configurable to be a new-style class

# Generated at 2022-06-12 14:23:16.911486
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():

    def func1(x, y, z, *args, **kwargs):
        pass

    assert ArgReplacer(func1, 'x').replace(100, (), {}) == (None, [100], {})
    assert ArgReplacer(func1, 'x').replace(100, (101,), {}) == (101, [100], {})
    assert ArgReplacer(func1, 'x').replace(100, (101,), {'x': 102}) == (101, [100], {'x': 102})
    assert ArgReplacer(func1, 'x').replace(100, (101,), {'y': 102}) == (None, [100, 101], {'y': 102})

# Generated at 2022-06-12 14:23:27.051060
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a=2, b=3, c=4, d=5):
        return(a, b, c, d)
    result = ArgReplacer(func, name='b').replace(11, (3, 4), {'a': 12})
    assert result == (3, (3, 4), {'a': 12, 'b': 11})
    result = ArgReplacer(func, name='b').replace(11, args=(3, 4), kwargs={'a': 12})
    assert result == (3, (3, 4), {'a': 12, 'b': 11})
    result = ArgReplacer(func, name='b').replace(11, args=(3, 4), kwargs={})
    assert result == (None, (3, 4), {'b': 11})



# Generated at 2022-06-12 14:23:35.838753
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    kwarg_name = 'kwarg'

    def func(a, b, c, kwarg = None):
        pass

    replacer = ArgReplacer(func, kwarg_name)

    new_value = 'new_value'
    old_value = 'old_value'
    new_value, args, kwargs = replacer.replace(new_value, [1, 2, 3], {kwarg_name: old_value})
    assert new_value is old_value
    assert kwargs[kwarg_name] is new_value
    assert args == [1, 2, 3]

    old_value, args, kwargs = replacer.replace(new_value, [1, 2, 3], {kwarg_name: old_value})
    assert old_value is new_value
    assert kw

# Generated at 2022-06-12 14:23:43.459406
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    print('TESTING ' + __name__)
    _Configurable_configurable_base = Configurable.configurable_base
    _Configurable_configurable_default = Configurable.configurable_default
    _Configurable_configured_class = Configurable.configured_class
    _Configurable_configure = Configurable.configure
    _Configurable_initialize = Configurable.initialize

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self):
            pass

    class B(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return

# Generated at 2022-06-12 14:23:46.673188
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import inspect
    ret = inspect.signature(Configurable.initialize)
    assert (inspect.Parameter.VAR_KEYWORD, 'kwargs') == ret.parameters['kwargs'].kind


# Generated at 2022-06-12 14:23:55.893052
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado


_BYTES_TYPE = bytes
_UTF8_TYPE = str
_UNICODE_TYPE = str
_BASESTRING_TYPE = str

# Do not use these directly; they are deprecated aliases for
# non-public types.
BytesType = _BYTES_TYPE
UTF8Type = _UTF8_TYPE
UnicodeType = _UNICODE_TYPE
BasestringType = _BASESTRING_TYPE



# Generated at 2022-06-12 14:24:01.331142
# Unit test for function import_object
def test_import_object():
    """
    It should test the import_object function
    """
    import unittest

    class TestImportObject(unittest.TestCase):
        def test_import_object(self):
            import tornado
            self.assertIs(
                import_object("tornado.testing.util"),
                tornado.testing.util,
                "Importing 'tornado.testing.util' should be equal to tornado.testing.util",
            )

    unittest.main()



# Generated at 2022-06-12 14:24:46.947442
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-12 14:24:56.601018
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class ConfigurableTest1(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[ConfigurableTest1]
            return ConfigurableTest1

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[ConfigurableTest1]
            return ConfigurableTest1

    class ConfigurableTest2(ConfigurableTest1):
        def initialize(self, *args, **kwargs):
            # type: (Any, Any) -> None
            self.test_args = args
            self.test_kwargs = kwargs

    arg1 = object()
    arg2 = object()
    arg3 = object()
    kwarg1 = object()
    kwarg2 = object()
    kwarg3 = object

# Generated at 2022-06-12 14:25:05.991913
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def method1(a: int, b: int, c: int = 3) -> int:
        return a + b + c

    def method2(a: int, b: int, c: int = 3, d: int = 4) -> int:
        return a + b + c + d

    # Test for method1 with default value and no default value
    arg1 = ArgReplacer(method1, 'a')
    assert arg1.get_old_value((1, 2), {}) == 1
    assert arg1.get_old_value((1, 2), {'c': 1}) == 1
    assert arg1.get_old_value((), {'a': 1, 'b': 2, 'c': 1}) == 1

    arg2 = ArgReplacer(method1, 'c')
    assert arg2.get_old_value

# Generated at 2022-06-12 14:25:11.233447
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(-1, "test")
    except IOError as e:
        assert errno_from_exception(e) == -1

    try:
        # Avoid "unpacked non-iterable None" error (see #10253).
        raise IOError(None, None)  # type: ignore
    except IOError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-12 14:25:21.360609
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None, *args):
        return (old_a, old_b, old_c, old_d)

    assert ArgReplacer(func, 'a').get_old_value((1, 2, 3), {}) == 1
    assert ArgReplacer(func, 'a').get_old_value((1, 2, 3), {'d': 'd'}) == 1
    assert ArgReplacer(func, 'a').get_old_value((1, 2, 3), {'a': 'a'}) == 1
    assert ArgReplacer(func, 'b').get_old_value((1, 2, 3), {}) == 2
    assert ArgReplacer(func, 'b').get_old_value((1, 2, 3), {'d': 'd'}) == 2
   

# Generated at 2022-06-12 14:25:29.440850
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestConfigurable
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.initialized_by = TestConfigurable
            super().initialize(*args, **kwargs)
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def _initialize(self, *args, **kwargs):
            self.expected_args = args
            self.expected_kwargs = kwargs
            super()._initialize(*args, **kwargs)

# Generated at 2022-06-12 14:25:37.450892
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=10, c=20):
        pass

    arg_replacer = ArgReplacer(func, "c")
    # Test for case when argument c is passed by key
    assert arg_replacer.get_old_value((1,), {"b":2, "c":3}, None) == 3
    assert arg_replacer.get_old_value((1,), {"b":2}, None) == None
    # Test for case when argument c is passed by position
    assert arg_replacer.get_old_value((1,2,3), {}, None) == 3
    assert arg_replacer.get_old_value((1,2), {}, None) == None


# Generated at 2022-06-12 14:25:44.142180
# Unit test for function errno_from_exception
def test_errno_from_exception():

    class MyException(Exception):
        pass

    e1 = MyException()
    assert errno_from_exception(e1) is None

    class MyException2(Exception):
        def __init__(self, errno):
            super(MyException2, self).__init__()
            self.args = (errno,)
            self.errno = errno

    e2 = MyException2(42)
    assert errno_from_exception(e2) == 42



# Generated at 2022-06-12 14:25:49.773816
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(3)
    except IOError as e:
        assert errno_from_exception(e) == 3
    try:
        raise IOError((3, "a"))
    except IOError as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-12 14:25:55.256340
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, name):
            self.name = name

    configurable = TestConfigurable(name='test')
    assert configurable.name == 'test'

