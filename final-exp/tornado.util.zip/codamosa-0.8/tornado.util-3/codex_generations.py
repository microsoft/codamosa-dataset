

# Generated at 2022-06-12 14:16:45.137936
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():

    def foo(a, b, c):
        pass

    old_value, args, kwargs = ArgReplacer(foo, 'b').replace(1, (2, 3, 4), {'c': 4})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 4}

    old_value, args, kwargs = ArgReplacer(foo, 'd').replace(1, (2, 3, 4), {'c': 4})
    assert old_value == None
    assert args == (2, 3, 4)
    assert kwargs == {'c': 4, 'd': 1}


# Generated at 2022-06-12 14:16:53.532964
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
        assert False
    except ImportError:
        pass


_BYTE_MASK = (1 << 8) - 1
_UNSIGNED_CHAR_MASK = (1 << (8 * array.array('B').itemsize)) - 1
_UNSIGNED_SHORT_MASK = (1 << (8 * array.array('H').itemsize)) - 1

_UNSIGNED_LONGLONG_MASK = (1 << (8 * array.array('L').itemsize)) - 1

# Generated at 2022-06-12 14:16:59.894973
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func1(a, b):
        pass
    def func2(a, c):
        pass
    def func3(a, d):
        pass
    def func4(a, b):
        pass
    def func5(b, a):
        pass
    def func6(b):
        pass
    def func7(a, b, c, d):
        pass
    def func8(a, b, *args, **kwargs):
        pass
    def func9(a, b, *args, c, **kwargs):
        pass
    def func10(a, b, *, c, **kwargs):
        pass
    def func11(a, b, c=1, d=2):
        pass
    def func12(a, b, **kwargs):
        pass

# Generated at 2022-06-12 14:17:01.482208
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    with pytest.raises(NotImplementedError):
        Configurable.configurable_base()
    with pytest.raises(NotImplementedError):
        Configurable.configurable_default()



# Generated at 2022-06-12 14:17:09.105052
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class Foo(Configurable):  # type: ignore
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Foo

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return FooImpl

        @classmethod
        def configure(cls, impl, **kwargs):
            # type: (Union[None, str, Type[Configurable]], Any) -> None
            super(Foo, cls).configure(impl, **kwargs)

        def _initialize(self):
            # type: () -> None
            self.args = []  # type: List[Any]
            self.kwargs = {}  # type: Dict[str, Any]

        initialize

# Generated at 2022-06-12 14:17:15.080817
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=1, *args, **kwargs):
        return a, b, c, d, args, kwargs

    def func1(a, b, c, d=1):
        return a, b, c, d

    def func2(a, b, c, d=1, e=2, f=3):
        return a, b, c, d, e, f

    s = ArgReplacer(func, "d")
    assert s.replace(10, (1, 2, 3), {"d": 4}) == (4, (1, 2, 3), {"d": 10})
    assert s.replace(10, (1, 2, 3), {"d": 4, "x": 5}) == (4, (1, 2, 3), {"d": 10, "x": 5})


# Generated at 2022-06-12 14:17:19.013805
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    # AttributeError
    with pytest.raises(AttributeError):
        d.foo

    # KeyError
    with pytest.raises(AttributeError):
        d['foo']

# Generated at 2022-06-12 14:17:27.017282
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import pytest
    from unittest import mock
    from unittest.mock import call
    from functools import partial

    from .process import Subprocess as _Subprocess
    from .util import Configurable
    def _test_configurable_base(this, cls):
        if cls is Configurable:
            return cls
        else:
            return this.configurable_base()

    def _test_configurable_default(this, cls):
        return cls

    def __init__(*args, **kwargs):
        pass

    def initialize(*args, **kwargs):
        pass


# Generated at 2022-06-12 14:17:37.159598
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class Test:
        def func1(v0, v1, v2=None, v3=None, *args, **kwargs):
            pass

    r = ArgReplacer(Test.func1, "v2")
    assert r.arg_pos is None
    assert r.get_old_value([1, 2], {"v3": 4, "v4": 5}) is None
    assert r.replace(6, [1, 2], {"v3": 4, "v4": 5}) == (None, [1, 2], {"v2": 6, "v3": 4, "v4": 5})
    r = ArgReplacer(Test.func1, "v0")
    assert r.arg_pos == 0
    assert r.get_old_value([1, 2], {"v3": 4, "v4": 5})

# Generated at 2022-06-12 14:17:41.779777
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):
        def configurable_base(self):
            return MyConfigurable
        def configurable_default(self):
            return None
        def initialize(self):
            pass

    MyConfigurable.configure(None)
    assert MyConfigurable.__impl_class is None
    assert MyConfigurable.__impl_kwargs is None

    instance = MyConfigurable()
    assert isinstance(instance, MyConfigurable)
    assert instance is not None
test_Configurable___new__()

_UNSET = object()



# Generated at 2022-06-12 14:17:51.797219
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    a = Configurable()
    assert a.initialize is a._initialize


# Generated at 2022-06-12 14:17:55.178444
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class StaticClass(Configurable):
        @classmethod
        def configurable_base(cls):
            raise NotImplementedError()

        @classmethod
        def configurable_default(cls):
            raise NotImplementedError()

        def initialize(self):
            raise NotImplementedError()

    assert StaticClass.__new__.__qualname__ == Configurable.__new__.__qualname__



# Generated at 2022-06-12 14:18:02.676349
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    #def f(self, s, a, b, c=None, d=None):
    #    pass
    #_replacer = ArgReplacer(f, 'b')
    #print(_replacer.replace(4, (1,2,3,4), dict(self=1, c=1)))
    def f(a, b, c=None, d=None):
        pass
    _replacer = ArgReplacer(f, 'b')
    print(_replacer.replace(4, (1,2,3,4), dict(c=1)))


# Generated at 2022-06-12 14:18:05.605785
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b):
        return a, b
    assert (3, 1) == f(3, 1)
    assert (3, 2) == ArgReplacer(f, 'b').replace(2, (3, 1), {})

# Generated at 2022-06-12 14:18:12.299113
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    #
    # This function's type annotation must use comments instead of
    # real annotations because typing.NoReturn does not exist in
    # python 3.5's typing module.
    with pytest.raises(TypeError, match="raise_exc_info called with no exception"):
        raise_exc_info((None, None, None))
    with pytest.raises(ValueError, match="foobar"):
        try:
            raise ValueError("foobar")
        except ValueError:
            raise_exc_info(sys.exc_info())



# Generated at 2022-06-12 14:18:16.926568
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d['x'] = 1
    assert d.x == 1

    assert ObjectDict(x=1).x == 1

    d.y = 2
    assert d['y'] == 2
    assert d.y == 2


# Generated at 2022-06-12 14:18:22.113736
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    class MockFunction(object):
        def __init__(self, a, b):
            pass
    arg0 = ArgReplacer(MockFunction, "a")
    assert arg0.get_old_value(("a", "b"), {}) == "a"
    arg1 = ArgReplacer(MockFunction, "b")
    assert arg1.get_old_value(("a", "b"), {}) == "b"
    arg2 = ArgReplacer(MockFunction, "c")
    assert arg2.get_old_value(("a", "b"), {}) is None
    arg3 = ArgReplacer(MockFunction, "a")
    assert arg3.get_old_value(("a", "b"), {}, default="c") == "a"

# Generated at 2022-06-12 14:18:34.212793
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    def _initialize(self, **kwargs):
        self.__dict__.update(kwargs)

    class ConfigTest(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigTest

        @classmethod
        def configurable_default(cls):
            return ConfigTest

        initialize = _initialize

    ConfigTest.configure(None, a=1, b=2)
    assert isinstance(ConfigTest(), ConfigTest)
    assert ConfigTest(c=3, d=4).d == 4
    assert ConfigTest().b == 2
    assert ConfigTest().a == 1
    # Test that _initialize is called even with no arguments
    ConfigTest.configure(None)
    assert ConfigTest().a == 1



# Generated at 2022-06-12 14:18:42.621236
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c, d=10):
        pass
    replacer = ArgReplacer(f, 'c')
    assert (replacer.replace(20, (1,2,3,4), {'e':5}) == (3, (1,2,20,4), {'e':5}))
    assert (replacer.replace(20, (1,2,3,4), {'c':6, 'e':5}) == (6, (1,2,20,4), {'e':5}))
    assert (replacer.replace(20, (1,2,3), {'d':4, 'e':5}) == (None, (1,2,20), {'d':4, 'e':5}))

# Generated at 2022-06-12 14:18:54.824676
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def testfunc(a, b=1, *, c=2):
        pass

    assert ArgReplacer(testfunc, "b").get_old_value((), {}) == 1
    assert (
        ArgReplacer(testfunc, "b").get_old_value(tuple(), {}, default=3) == 3
    )
    assert ArgReplacer(testfunc, "b").get_old_value((), dict(b=10)) == 10
    assert ArgReplacer(testfunc, "c").get_old_value((), {}) == 2
    assert ArgReplacer(testfunc, "c").get_old_value(tuple(), dict()) == 2
    assert (
        ArgReplacer(testfunc, "c").get_old_value(tuple(), dict(), default=3) == 3
    )
    assert ArgRepl

# Generated at 2022-06-12 14:19:14.461391
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a,b,c,d,e=1,f=2,g=3):
        print("{} {} {} {} {} {} {}".format(a,b,c,d,e,f,g))

    args = (1,2,3,4)
    kwargs = {'e': 5, 'f': 6, 'g': 7}
    arg_replacer_obj = ArgReplacer(test_func, 'c')
    assert arg_replacer_obj.get_old_value(args, kwargs) == 3
    assert arg_replacer_obj.get_old_value(args, {}) == None
    assert arg_replacer_obj.get_old_value(args, {}, default=0) == 0
    return True


# Generated at 2022-06-12 14:19:20.224922
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            pass
        def configurable_default(self):
            pass
    x = TestConfigurable()
    assert isinstance(x, TestConfigurable)
    assert not hasattr(x, '_TestConfigurable__impl_class')
    assert not hasattr(x, '_TestConfigurable__impl_kwargs')



# Generated at 2022-06-12 14:19:29.171185
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    f = ArgReplacer(func, 'a')
    assert f.replace('new', (1,2,3),{'c': 3}) == (1, ('new', 2, 3), {'c':3})
    assert f.replace(5, (1,2,3),{'c': 3, 'b':2}) == (1, (5, 2, 3), {'c':3, 'b':2})
    # assert f.replace(5, (1,2,3),{'c': 3, 'b':2}) == (None, (5, 2, 3), {'c':3, 'b':2, 'a': 5})


# Generated at 2022-06-12 14:19:38.328217
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def method(a, b=0):
        return a, b
    arg = ArgReplacer(method, 'a')
    old_value, argv, kwarg = arg.replace(1, (2, ), {'b': 5})
    assert old_value == 2
    assert argv == (1, )
    assert kwarg == {'b': 5}
    arg = ArgReplacer(method, 'b')
    old_value, argv, kwarg = arg.replace(3, (2, ), {'b': 5})
    assert old_value == 5
    assert argv == (2, )
    assert kwarg == {'b': 3}



# Generated at 2022-06-12 14:19:45.919667
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=4, e=5):
        pass
    ar = ArgReplacer(f, "a")
    assert ar.arg_pos == 0
    assert ar.get_old_value((1, 2, 3, 4, 5), {}) == 1
    assert ar.get_old_value((2, 3), {}, default=0) == 0
    assert ar.replace(10, (1, 2, 3), {}) == (1, (10, 2, 3), {})
    assert ar.replace(10, (2, 3), {"a": 1}) == (1, (2, 3), {"a": 10})
    assert ar.replace(10, (2, 3), {}) == (None, (2, 3), {"a": 10})

# Generated at 2022-06-12 14:19:56.784555
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        raise ValueError("test exception")
    except Exception as e:
        #print("type(e) = ", type(e))
        #print("dir(e) = ", dir(e))
        #print("e.args = ", e.args)
        #print("e.errno = ", e.errno)
        #print("e.strerror = ", e.strerror)
        assert type(e) == ValueError
        assert dir(e) == ['args', 'with_traceback']
        assert e.args == ("test exception",)
        assert e.errno is None
        assert e.strerror is None
    try:
        raise ValueError("test exception", "another exception")
    except Exception as e:
        assert type(e) == ValueError

# Generated at 2022-06-12 14:20:06.745315
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=4):
        return a, b, c, d

    def g(a, b, *args, c=3, d=4, **kwargs):
        return a, b, args, c, d, kwargs

    def h(a, b, *args, c, d=4, **kwargs):
        return a, b, args, c, d, kwargs

    def i(a, b, *, c, d=4, **kwargs):
        return a, b, c, d, kwargs


# Generated at 2022-06-12 14:20:13.899010
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fun(a, b, *, c):
        return a, b, c
    argreplacer = ArgReplacer(fun, 'a')
    assert argreplacer.get_old_value((1,2,3), {}, None) == 1
    assert argreplacer.get_old_value((), {'a':23}, None) == 23
    assert argreplacer.get_old_value((), {}, 'matrix') == 'matrix'


# Generated at 2022-06-12 14:20:21.531559
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(x, y=None):
        pass

    r = ArgReplacer(foo, "y")
    assert r.get_old_value(("asdf",), {}) is None
    assert r.get_old_value(("asdf",), {"y": "qwer"}) == "qwer"
    assert r.get_old_value(("asdf",), {"y": None}) is None
    assert r.get_old_value(("asdf",), {"y": False}) is False

    def no_args():
        pass


    with pytest.raises(ValueError):
        ArgReplacer(no_args, "y")



# Generated at 2022-06-12 14:20:25.159427
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class _ConfigurableSubclass(Configurable):
        def configurable_base(self):
            # type: () -> Type[_ConfigurableSubclass]
            return _ConfigurableSubclass

        def configurable_default(self):
            # type: () -> Type[_ConfigurableSubclass]
            raise NotImplementedError()

    _ConfigurableSubclass.configure(None)



# Generated at 2022-06-12 14:20:50.904168
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    def p(self, *args: Any, **kwargs: Any) -> None:
        pass

    import functools
    functools.update_wrapper(p, Configurable.__new__, updated=())

    class TestC(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

        def initialize(self, *args: Any, **kwargs: Any) -> None:
            pass

    TestC.configure(None)
    t = TestC(1, 2)
    assert isinstance(t, TestC)
    assert t.initialize.__self__ is t


# Generated at 2022-06-12 14:21:01.978170
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a,b,c,d=1,e=2):
        pass
    args = [1,2]
    kwargs = {'c':3,'e':5}
    assert ArgReplacer(f, 'a').get_old_value(args, kwargs, default=None) == 1
    assert ArgReplacer(f, 'b').get_old_value(args, kwargs, default=None) == 2
    assert ArgReplacer(f, 'c').get_old_value(args, kwargs, default=None) == 3
    assert ArgReplacer(f, 'd').get_old_value(args, kwargs, default=None) == 1
    assert ArgReplacer(f, 'e').get_old_value(args, kwargs, default=None) == 5

# Generated at 2022-06-12 14:21:13.871566
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
	def fake_func():
		a = 1
		b = 2
		c = 3
		d = 4
		e = 5
		f = 6
		g = 7
		h = 8
		i = 9
		j = 10
		k = 11
		l = 12
		m = 13
		n = 14
		o = 15
		p = 16
		q = 17
		r = 18
		s = 19
		t = 20
		u = 21
		v = 22
		w = 23
		x = 24
		y = 25
		z = 26


# Generated at 2022-06-12 14:21:24.884529
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest
    import typing
    import sys
    from tornado.log import gen_log

    class BaseClass(Configurable):
        def __init__(self):
            raise Exception("Configurable instances should not be "
                            "initialized directly.  Instead use the "
                            "instance() method on the Configurable subclass.")
        def initialize(self):
            pass
        @classmethod
        def configurable_base(cls):
            return BaseClass
        @classmethod
        def configurable_default(cls):
            return DefClass1

    class DefClass1(BaseClass):
        pass

    class DefClass2(BaseClass):
        pass


# Generated at 2022-06-12 14:21:33.349271
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import sys  # we have to use the real import to get sys.exc_info
    import traceback
    import unittest

    test_exception = ValueError("test")
    test_exc_info = (type(test_exception), test_exception, sys.exc_info()[2])

    def _reraise(exc_info=None):
        # After Python 3.3, sys.exc_info is thread-aware.  However,
        # the traceback module doesn't yet respect sys.exc_info, so
        # we have to pass it the right thing (either the current
        # exception, or the exception in the given exc_info).
        if exc_info is None:
            raise_exc_info(sys.exc_info())
        else:
            raise_exc_info(exc_info)


# Generated at 2022-06-12 14:21:44.180364
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-12 14:21:52.983594
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def __init__(self, a: str) -> None:
            self.a = a

    A.configure(None)
    assert A('a1').a == 'a1'

    class B(A):
        def __init__(self, a: str, b: str) -> None:
            super(B, self).__init__(a)
            self.b = b

    B.configure(None)

    assert B('a2', 'b2').a == 'a2'
    assert B('a2', 'b2').b == 'b2'


# Generated at 2022-06-12 14:21:55.529277
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Subclass(Configurable):
        def initialize(self, x, y):
            pass

    assert Subclass.configurable_base() is Subclass
    assert Subclass.configurable_default() is Subclass



# Generated at 2022-06-12 14:21:59.929252
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    @ArgReplacer('a')
    def test(a=None):
        pass
    assert test.get_old_value((1,), {}, default=2) == 1
    assert test.get_old_value((), {'a': 1}, default=2) == 1
    assert test.get_old_value((), {}, default=2) == 2

# Generated at 2022-06-12 14:22:04.819803
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class C:
        def __init__(self, a1, a2, kw, *args):
            pass

    r = ArgReplacer(C, "a2")
    _, a, k = r.replace(23, (1, 2, 3), dict(kw=4, kw2=5))
    assert a == (1, 23, 3)
    assert k == dict(kw=4, kw2=5)



# Generated at 2022-06-12 14:22:29.119707
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a,b): return a + b

    argReplacer = ArgReplacer(func, 'b')
    assert argReplacer.get_old_value((1,2), {}) == 2
    assert argReplacer.get_old_value((1,), {'b':2}) == 2
    assert argReplacer.get_old_value((), {'a':1, 'b':2}) == 2
    assert argReplacer.get_old_value((), {'a':1}) == None


# Generated at 2022-06-12 14:22:36.937480
# Unit test for method __new__ of class Configurable

# Generated at 2022-06-12 14:22:41.967898
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a, b, c):
        replacer = ArgReplacer(test, 'a')
        return replacer.get_old_value((a, b, c), {})
    assert test(1, 2, 3) == 1
    assert test(a=1, b=2, c=3) == 1



# Generated at 2022-06-12 14:22:46.407376
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo
        @classmethod
        def configurable_default(cls):
            return Foo
        def initialize(self, a):
            self.a = a

    Foo.configure("tests.func.test_util.Foo")
    assert isinstance(Foo(1), Foo)



# Generated at 2022-06-12 14:22:56.774027
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class arg(object):
        pass
    old_args=[5,5,5,5,5]
    old_kwargs={'x':arg()}
    my_args = list(old_args)
    my_kwargs = old_kwargs.copy()
    old_value, my_args, my_kwargs = ArgReplacer(lambda x: x, 'x').replace(arg(), my_args, my_kwargs)
    print(old_value, my_args, my_kwargs)
    old_value, my_args, my_kwargs = ArgReplacer(lambda x: x, 'x').replace(arg(), my_args, my_kwargs)
    print(old_value, my_args, my_kwargs)



# Generated at 2022-06-12 14:23:04.400768
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    """Unit test for constructor of class ArgReplacer"""
    def func1(a, b, c, d=1, e=2, f=3):  # type: ignore
        pass

    def func2(a, b, c, *args):  # type: ignore
        pass

    def func3(a, b, c, **kw):  # type: ignore
        pass

    def func4(a, b, c, *args, **kw):  # type: ignore
        pass

    def func5(a, b, c, d=1, e=2, f=3, *args, **kw):  # type: ignore
        pass


# Generated at 2022-06-12 14:23:13.788182
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b):
        return a, b
    args = (1, 2)
    kwargs = {'b': 3}
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(4, args, kwargs)
    assert old_value == 3
    assert args == (1, 4)
    assert kwargs == {'b': 4}
    old_value, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert old_value == 4
    assert args == (1, 5)
    assert kwargs == {'b': 5}

# Generated at 2022-06-12 14:23:17.315032
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestClass(Configurable):
        def configurable_base(self):
            return TestClass

        def configurable_default(self):
            return TestClass

        def initialize(self, **kwargs):
            pass

    t = TestClass()
    assert(t.__class__ is TestClass)

# Generated at 2022-06-12 14:23:26.411082
# Unit test for function import_object
def test_import_object():
    try:
        import sys  # noqa
        import_object('sys') is sys
    except:
        pass

# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.
_UTF8_TYPES = (bytes, type(None))  # Types acceptable as UTF-8



# Generated at 2022-06-12 14:23:34.958363
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(x, y):
        print(x, y)

    args = [1, 2]
    kwargs = {}
    print("-------INPUT PARAMETERS-------")
    print("args:", args, " type:", type(args))
    print("kwargs:", kwargs, " type:", type(kwargs))
    ar = ArgReplacer(func, "y")
    kwargs = ar.replace(300, args, kwargs)
    print("-------OUTPUT PARAMETERS-------")
    print("args:", args, " type:", type(args))
    print("kwargs:", kwargs, " type:", type(kwargs))
    print("--------------------------------")

    args = [1]
    kwargs = {}
    print("-------INPUT PARAMETERS-------")

# Generated at 2022-06-12 14:24:14.714085
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
        import sys
        import unittest
        import types

        class TestConfigurable(Configurable):
            _impl = None  # type: Optional[Type[TestConfigurable]]

            @classmethod
            def configurable_base(cls):
                # type: () -> Type[TestConfigurable]
                return TestConfigurable

            @classmethod
            def configurable_default(cls):
                # type: () -> Type[TestConfigurable]
                return TestConfigurableImpl

            def initialize(self, x):
                self.x = x

        def configurable_base_test():
            assert issubclass(TestConfigurableImpl, TestConfigurable)
            # Check for override in subclass
            assert TestConfigurableImpl.configurable_base() is TestConfigurable


# Generated at 2022-06-12 14:24:25.857432
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # Check that the ArgReplacer constructor works with functions,
    # methods, and callables objects.
    def f1(a, b):
        pass

    class C1(object):
        def f2(self, a, b):
            pass

        def __call__(self, a, b):
            pass

    C1().f2(1, 2)
    C1()(1, 2)
    for f in [f1, C1().f2, C1()]:
        assert ArgReplacer(f, "a").arg_pos == 0
        assert ArgReplacer(f, "b").arg_pos == 1
        # get_old_value returns the default value if the arg is not present
        assert ArgReplacer(f, "c").get_old_value([1, 2], {}) is None
        assert ArgRepl

# Generated at 2022-06-12 14:24:36.238438
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=None):
        return

    ar = ArgReplacer(func, 'a')

    assert ar.get_old_value((1,), {}, None) == 1
    assert ar.get_old_value((1,), {}, 2.5) == 1

    def func(a, b, *args, **kwargs):
        return

    ar = ArgReplacer(func, 'b')
    assert ar.get_old_value((1,2, 3), {"b":4}, 2.5) == 2
    
    def func(a, b, *args, c=0, **kwargs):
        return

    ar = ArgReplacer(func, 'b')
    assert ar.get_old_value((1,2), {"c":0}, 2.5) == 2
    assert ar.get_

# Generated at 2022-06-12 14:24:44.569921
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def my_function(a, b, not_the_arg, the_arg, lot_of_args, the_arg2=None):
        pass

    r = ArgReplacer(my_function, "the_arg2")
    assert r.arg_pos is None
    assert r.get_old_value((1, 2, 3, 4, 5), {}) is None
    assert r.get_old_value((1, 2, 3, 4, 5), {}, 7) == 7
    assert r.get_old_value((1, 2, 3, 4, 5), {"the_arg2": 6}) == 6
    assert r.get_old_value((1,), {"the_arg2": 6}) == 6

    r = ArgReplacer(my_function, "lot_of_args")

# Generated at 2022-06-12 14:24:53.039119
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    import types
    import inspect
    import unittest

    class Test_Configurable(Configurable):
        def configurable_base(self):
            # type: () -> Test_Configurable
            return Test_Configurable
        def configurable_default(self):
            # type: () -> Test_Configurable
            return Test_Configurable

    assert inspect.isclass(Test_Configurable)
    assert isinstance(Test_Configurable, type)

    assert type(Test_Configurable) == types.TypeType

    assert callable(Test_Configurable.configurable_base)
    assert callable(Test_Configurable.configurable_default)
    assert callable(Test_Configurable.configure)
    assert callable(Test_Configurable.configured_class)

# Generated at 2022-06-12 14:24:56.515804
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Test(Configurable):
        pass
    import unittest
    Test.configure(None)
    a = Test()
    Test.configure(Test,a=1)
    b = Test()
    assert a.a == b.a == 1



# Generated at 2022-06-12 14:25:05.864109
# Unit test for function errno_from_exception
def test_errno_from_exception():

    class TestException(Exception):
        pass

    def no_args():
        raise TestException()

    def one_arg():
        raise TestException("test")

    def errno_arg():
        class TestErrnoException(Exception):
            def __init__(self, errno, desc):
                super(TestErrnoException, self).__init__(desc)
                self.errno = errno

        raise TestErrnoException(42, "test")

    def errno_arg_tuple():
        class TestErrnoException(Exception):
            def __init__(self, errno, desc):
                super(TestErrnoException, self).__init__(errno, desc)
                self.errno = errno

        raise TestErrnoException(42, "test")

    assert errno_from

# Generated at 2022-06-12 14:25:12.862157
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import sys
    import unittest
    import unittest.mock
    try:
        import asyncio
    except ImportError:
        asyncio = None
    class ConfigurablePerson(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurablePerson
        @classmethod
        def configurable_default(cls):
            return Person
    class Person(ConfigurablePerson):
        def __init__(self, name, employer=None):
            self.name = name
            self.employer = employer
    class Engineer(Person):
        def __init__(self, name, employer=None, tool=None):
            super(Engineer, self).__init__(name, employer=employer)
            self.tool = tool

# Generated at 2022-06-12 14:25:22.815343
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def args(a, b, c):
        pass
    assert ArgReplacer(args, "a").replace(6, (1, 2, 3), {}) == (1, (6, 2, 3), {})
    assert ArgReplacer(args, "b").replace(6, (1, 2, 3), {}) == (2, (1, 6, 3), {})
    assert ArgReplacer(args, "c").replace(6, (1, 2, 3), {}) == (3, (1, 2, 6), {})
    assert ArgReplacer(args, "d").replace(6, (1, 2, 3), {}) == (None, (1, 2, 3), {"d": 6})

    def kwargs(a=3, b=4, c=5):
        pass

# Generated at 2022-06-12 14:25:32.225557
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import inspect
    # Some functions to test with
    def no_args():
        pass

    def three_args(a, b, c):
        pass

    def two_args(a, b):
        pass

    def one_arg_with_default(a, b=25):
        pass

    def one_arg_with_default_2(a, b="hi"):
        pass

    def one_arg_with_default_3(a, b=[]):
        pass

    def with_varargs(a, *args):
        pass

    def with_kwargs(a, **kwargs):
        pass

    def with_varargs_kwargs(a, *args, **kwargs):
        pass

    def with_kwargs_varargs(a, **kwargs):
        pass

    # Raise exception when wrong