

# Generated at 2022-06-12 14:16:41.373177
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # A mock class for Configurable
    class A(Configurable):

        def __init__(*args, **kwargs):
            pass

        def configurable_base(cls):
            return A

        def configurable_default(cls):
            return A

# Generated at 2022-06-12 14:16:46.149694
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # unit test for ArgReplacer.replace()
    # Instance method of ArgReplacer
    def method(self, arg, kwarg=None):
        pass
    arg_replacer = ArgReplacer(method, "self")
    arg_replacer.replace(None, (1, 2), {"kwarg": 3}) == (1, (None, 2), {"kwarg": 3})



# Generated at 2022-06-12 14:16:54.339960
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    x = A(a=1,b=2)  # type: ignore
    assert x.a == 1
    assert x.b == 2
    class B(A):
        pass
    y = B(a=1,b=2)  # type: ignore
    assert y.a == 1
    assert y.b == 2
    class C(B):
        def initialize(self, a: int, b: int) -> None:
            self.a = a
            self.b = b
    z = C(a=1,b=2)
    assert z.a == 1
    assert z.b == 2

# Generated at 2022-06-12 14:16:57.211231
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def x(y, z=1):
        pass
    arg_replacer = ArgReplacer(x, 'y')
    assert arg_replacer.get_old_value((2,), {}) == 2


# Generated at 2022-06-12 14:17:06.217792
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    args = (1,2)
    kwargs = {'kwarg':'kwarg_val'}
    replacer = ArgReplacer(test_ArgReplacer_get_old_value, 'kwarg')
    assert replacer.get_old_value(args,kwargs,None) == 'kwarg_val'
    assert replacer.get_old_value(args,kwargs,1) == 'kwarg_val'
    replacer_2 = ArgReplacer(test_ArgReplacer_get_old_value, 'no_kwarg')
    assert replacer_2.get_old_value(args,kwargs,None) is None
    assert replacer_2.get_old_value(args,kwargs,1) == 1


# Generated at 2022-06-12 14:17:15.699028
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None):
        pass
    obj = ArgReplacer(func, "c")
    a = ("one", "two", "three", "four")
    b = {"c": "five", "d": "six"}
    c = obj.get_old_value(a, b)
    assert c == "five"
    c = obj.get_old_value(a, b, "seven")
    assert c == "seven"
    d = {"e": "eight", "c": "nine"}
    c = obj.get_old_value(a, d)
    assert c == "nine"
    c = obj.get_old_value(a, d, "seven")
    assert c == "nine"


# Generated at 2022-06-12 14:17:18.322274
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ZeroDivisionError() # type: ignore
    except ZeroDivisionError:
        tb = None  # type: Optional[TracebackType]
        raise_exc_info((None, None, None)) # type: ignore



# Generated at 2022-06-12 14:17:24.361115
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-12 14:17:25.746093
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o.a = 1
    o["a"]


# Generated at 2022-06-12 14:17:27.643020
# Unit test for function import_object
def test_import_object():
    import_object("os")
    import_object("os.path")

# Fake byte literal for 2to3

# Generated at 2022-06-12 14:17:42.944939
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return 1

        def configurable_default(self):
            return 2

    t = TestConfigurable()
    assert t == 1

    t.initialize(2, 1, 3)

if __name__ == "__main__":
    test_Configurable_initialize()

if typing.TYPE_CHECKING:
    TYPE_1 = TypeVar("TYPE_1")
    TYPE_2 = TypeVar("TYPE_2")



# Generated at 2022-06-12 14:17:53.365563
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None, **kwargs):
        pass

    test_args = ("A", "B")
    test_kwargs = {"c": "C", "d": "D"}

    arg_replacer = ArgReplacer(test_func, "c")
    assert arg_replacer.get_old_value(test_args, test_kwargs) == "C"

    args, kwargs = test_args, test_kwargs
    old_value, args, kwargs = arg_replacer.replace("C1", args, kwargs)
    assert old_value == "C"
    assert args == ("A", "B")
    assert kwargs == {"c": "C1", "d": "D"}

    test_args = ("A", "B", "C1")


# Generated at 2022-06-12 14:17:59.734328
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class LastName(Configurable):
        @classmethod
        def configurable_base(cls):
            return LastName

        @classmethod
        def configurable_default(cls) -> str:
            return "Smith"

    assert LastName.configured_class() == "Smith"
    LastName.configure("Jones")
    assert LastName.configured_class() == "Jones"

    def get_last_name():
        return LastName().strip()
    assert get_last_name() == "Jones"
    LastName.configure(None)
    assert get_last_name() == "Smith"
    LastName.configure("Thompson")
    assert get_last_name() == "Thompson"



# Generated at 2022-06-12 14:18:03.234455
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def dummy_func(one, two, three, four=4):
        pass
    assert ArgReplacer(dummy_func, 'four').get_old_value((1,2,3), {}) == 4

# Generated at 2022-06-12 14:18:08.622245
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3):
        pass
    ar = ArgReplacer(func, 'c')
    # The arg to replace is passed positionally
    old_value = ar.get_old_value((1, 2, 4), {}, None)
    assert old_value == 4
    # The arg to replace is either omitted or passed by keyword.
    old_value = ar.get_old_value((1, 2), {}, None)
    assert old_value == None
    old_value = ar.get_old_value((1, 2), {'c': 5}, None)
    assert old_value == 5


# Generated at 2022-06-12 14:18:13.010253
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a: str, b: int, c: Any = None) -> None:
        """Intentionally empty function for testing arg replacer."""
        pass

    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.arg_pos == 1

    try:
        arg_replacer = ArgReplacer(arg_replacer, "d")
        raise Exception("constructing ArgReplacer with bad argument should have failed")
    except ValueError:
        pass  # expected



# Generated at 2022-06-12 14:18:24.253890
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import _io

    class Test(Configurable):
        @classmethod
        def configurable_base(cls):
            return Test

        @classmethod
        def configurable_default(cls):
            return TestImpl

        def initialize(self):
            pass

    class TestImpl(Test):
        pass

    assert isinstance(Test(), TestImpl)
    Test.configure(TestImpl2)

    class TestImpl2(Test):
        pass

    assert isinstance(Test(), TestImpl2)
    Test.configure(None)
    assert isinstance(Test(), TestImpl)
    Test.configure("_io.StringIO")
    assert isinstance(Test(), _io.StringIO)
    assert Test().__class__.__name__ == "StringIO"


# The unittest module got a significant overhaul
# in

# Generated at 2022-06-12 14:18:35.161183
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    test_cases = [
        ({"a": 1}, (("a", 1), ([], {"a": 1}))),
        ((1,), ((1,), ([1], {}))),
        ((1, "a"), ((1, "a"), ([1, "a"], {}))),
        ((1, "a", "b"), ((1, "a", "b"), ([1, "a", "b"], {}))),
        ((1, 2, "a", "b"), ((1, 2, "a", "b"), ([1, 2, "a", "b"], {}))),
        ((1, 2, "a", "b", "c"), ((1, 2, "a", "b", "c"), ([1, 2, "a", "b", "c"], {}))),
    ]


# Generated at 2022-06-12 14:18:40.356597
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.concurrent import Future
    import_object("tornado.accumulator")
    class test_(Configurable):
        def initialize(self, *args, **kwargs):
            pass
        @classmethod
        def configurable_base(cls):
            from tornado.accumulator import Accumulator
            return Accumulator
        @classmethod
        def configurable_default(cls):
            return Future
    test_().initialize(1, 2, 3)


# Generated at 2022-06-12 14:18:51.506384
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import tornado.escape
    import tornado.escape.native_str
    import tornado.escape.xhtml_escape
    import tornado.escape.utf8
    import tornado.escape.url_escape
    # Test for 'import_object' function
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
        raise AssertionError("Expected an exception")
    except ImportError as e:
        assert str(e) == "No module named missing_module"
    # Test for 'Configurable' class
    assert issubclass(tornado.escape.native_str.NativeString, Configurable)

# Generated at 2022-06-12 14:19:08.642898
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def inner():
        # type: () -> typing.NoReturn
        raise_exc_info(sys.exc_info())
    # This can't be wrapped in a try/except because we want the
    # exception to propagate to the caller.
    inner()  # type: ignore


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__"
# complicate things too much.  u() can be applied to ascii strings that
# include \u escapes (but they must not contain literal non-ascii
# characters).

# Generated at 2022-06-12 14:19:19.396209
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    r = ArgReplacer(func, 'b')
    assert r.replace(100, (1, 2, 3), {}) == (2, (1, 100, 3), {})
    assert r.replace(100, (1, 2), {'c': 3}) == (2, (1, 100), {'c': 3})
    assert r.replace(100, (1,), {'b': 2, 'c': 3}) == (2, (1,), {'b': 100, 'c': 3})
    assert r.replace(100, (), {'a': 1, 'b': 2, 'c': 3}) == (None, (), {'a': 1, 'b': 100, 'c': 3})


# Generated at 2022-06-12 14:19:29.451168
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    '''
    2 testcases included:
    1) test method replace when the arg to be replaced is passed with position
    2) test method replace when the arg to be replaced is passed with keyword
    '''
    def foo(x, y):
        return x + y
    arg_name = 'x'
    replacer = ArgReplacer(foo, arg_name)
    # case 1) test method replace when the arg to be replaced is passed with position
    # CASE1-1) test method replace when the arg to be replaced is passed with position, kwargs is empty
    new_value = 10
    old_value, args, kwargs = replacer.replace(new_value, [0, 1], {})
    assert old_value == 0
    assert args == [10, 1]
    assert kwargs == {}
    # CASE1

# Generated at 2022-06-12 14:19:40.401740
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def foo(a, b, c="c"):
        # type: (int, str, Any) -> bool
        return a > 5 and b == "b"
    replacer = ArgReplacer(foo, "b")
    assert replacer.get_old_value((1, "b"), {}) == "b"
    assert replacer.get_old_value((1, "z"), {}) == None
    assert replacer.get_old_value((1,), {"b": "b"}) == "b"
    assert replacer.get_old_value((1,), {"b": "z"}) == "z"
    assert replacer.get_old_value((), {"a": 1, "b": "b"}) == "b"
    old_value, args, kwargs = repl

# Generated at 2022-06-12 14:19:42.797468
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class _C(Configurable):
        def configurable_base(self):
            return _C

        def configurable_default(self):
            return _C

    # _C().classmethod()
    _C.configure("", )
    pass



# Generated at 2022-06-12 14:19:45.663206
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def _initialize(self, **kwargs):
            pass
    return TestConfigurable



# Generated at 2022-06-12 14:19:46.109476
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass


# Generated at 2022-06-12 14:19:54.068193
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo_bar(a, b, c, d):
        pass

    ar = ArgReplacer(foo_bar, "c")
    old_value, args, kwargs = ar.replace(8, (1, 2, 3, 4), {"d": 5})
    assert old_value == 3
    assert args == (1, 2, 8, 4)
    assert kwargs == {"d": 5}
    assert ar.get_old_value((1, 2, 3, 4), {"d": 5}) == 3



# Generated at 2022-06-12 14:19:58.989930
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a,b,c,d):  # type: ignore
        return a,b,c,d
    test_case = ArgReplacer(test, "c")
    a,b,c,d = test_case.get_old_value([1,2,3,4],[])
    assert [a,b,c,d] == [1,2,3,4]

# Generated at 2022-06-12 14:20:08.341853
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def testfunc(arg1, arg2):
        print(arg1, arg2)

    repl = ArgReplacer(testfunc, "arg2")
    assert repl.arg_pos is None, "ArgReplacer should fill in arg_pos"
    print("Entering test set arg2 to 'test' and arg1 to 'arg1'")
    old, args, kwargs = repl.replace("test", ("arg1",), {})
    assert old is None and args == ("arg1",) and kwargs == {"arg2": "test"}, "ArgReplacer didn't work"

    print("Entering test set arg2 to 'test' and arg1 to 'arg1'")
    old, args, kwargs = repl.replace("test", ["arg1", "arg2"], {})

# Generated at 2022-06-12 14:20:33.492602
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Foo(Configurable):
        __impl_class = None  # type: Optional[Type[Configurable]]
        __impl_kwargs = None  # type: Optional[Dict[str, Any]]

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

        def _initialize(self):
            # type: () -> None
            pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert isinstance(Foo(), Foo)

    Foo.configure(Baz)
    assert isinstance(Foo(), Baz)

# Generated at 2022-06-12 14:20:44.376119
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # This is a complete test of Configurable, from scratch, so
    # these need to be careful to avoid the real imported classes.
    class Foo0(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo0

        @classmethod
        def configurable_default(cls):
            return Foo1

    class Foo1(Foo0):
        def initialize(self, arg1, arg2="default", **kwargs):
            super(Foo1, self).initialize(**kwargs)
            self.arg1 = arg1
            self.arg2 = arg2

        def get_args(self):
            return self.arg1, self.arg2


# Generated at 2022-06-12 14:20:51.598661
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    import weakref
    import types

    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

        def _initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    c = C(1, 2, foo=3)
    assert isinstance(c, C)
    assert c.args == (1, 2)
    assert c.kwargs == {"foo": 3}



# Generated at 2022-06-12 14:20:55.139933
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class T(Configurable):
        def configurable_base(self):
            return T
        def configurable_default(self):
            return T
    def _():
        t = T()
    _()
    # a test failed



# Generated at 2022-06-12 14:21:01.696611
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except IOError as e:
        assert errno_from_exception(e) is e.errno
    try:
        raise IOError(123)
    except IOError as e:
        assert errno_from_exception(e) == 123
    try:
        raise TypeError
    except TypeError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-12 14:21:11.953896
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C(Configurable):
        pass
    C.configure(C)
    assert C.configured_class() is C
    assert isinstance(C(), C), isinstance(C(), C).__class__

    class D(C):
        pass
    assert D.configured_class() is C
    assert isinstance(D(), C), isinstance(D(), C).__class__

    class E(C):
        pass
    D.configure(E)
    assert D.configured_class() is E
    assert isinstance(D(), E), isinstance(D(), E).__class__
    assert isinstance(E(), E), isinstance(E(), E).__class__
    assert C.configured_class() is C



# Generated at 2022-06-12 14:21:23.482741
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=3, d=4):
        pass

    replacer = ArgReplacer(f, 'c')
    old_value, args, kwargs = replacer.replace("new_value", (1, 2), {})
    print(old_value, args, kwargs)
    assert (old_value, args, kwargs) == (3, (1, 2), {})
    #
    replacer = ArgReplacer(f, 'c')
    old_value, args, kwargs = replacer.replace("new_value", (1, 2, 3), {})
    print(old_value, args, kwargs)
    assert (old_value, args, kwargs) == (3, (1, 2, 'new_value'), {})
    #

# Generated at 2022-06-12 14:21:29.446052
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        try:
            raise_exc_info(sys.exc_info())
        except ValueError:
            pass
        else:
            raise AssertionError("Failed to re-raise ValueError")
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass
    else:
        raise AssertionError("Failed to raise TypeError")



# Generated at 2022-06-12 14:21:32.129232
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    fn = lambda x, y, z=3: x+y+z
    arg = ArgReplacer(fn, 'y')
    assert arg.get_old_value((1,2), {'x':3}) == 2


# Generated at 2022-06-12 14:21:42.858790
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return Configurable

        @classmethod
        def configurable_default(cls):
            return C

        def initialize(self, a, b=1, c=2):
            self.a = a
            self.b = b
            self.c = c

    try:
        C(1)
        assert False
    except TypeError as e:
        assert "b" in str(e)

    try:
        C(1, 1, 1, 1)
        assert False
    except TypeError as e:
        assert "unexpected" in str(e).lower()

    c = C(1, 2, 3)
    assert c.a == 1
    assert c.b == 2
    assert c.c == 3




# Generated at 2022-06-12 14:21:59.896789
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    x = ObjectDict()
    x["a"] = 1
    assert(x.a == 1)



# Generated at 2022-06-12 14:22:02.236197
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
  # Test Configurable.__new__
  assert 1 == 1


_WITH_TIMEOUT_ERRNO = (errno.EAGAIN, errno.EWOULDBLOCK, errno.EINTR)



# Generated at 2022-06-12 14:22:07.691285
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(42, "the meaning")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception("the meaning")
    except Exception as e:
        assert errno_from_exception(e) == "the meaning"



# Generated at 2022-06-12 14:22:18.531036
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    print('Test the method get_old_value of class ArgReplacer:')
    a1 = ArgReplacer(test_ArgReplacer_get_old_value, 'name')
    print(a1.get_old_value(args=tuple(), kwargs={'name':'x', 'a':'y'}))
    print(a1.get_old_value(args=tuple(), kwargs={'x':'x', 'a':'y'}))
    print(a1.get_old_value(args=tuple(), kwargs={'x':'x', 'a':'y'}, default=['a', 'b']))
    a2 = ArgReplacer(test_ArgReplacer_get_old_value, 'a')

# Generated at 2022-06-12 14:22:20.945422
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # This function tests the __new__ method of the Configurable class.
    t = Configurable()
    return t



# Generated at 2022-06-12 14:22:27.242931
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo
        @classmethod
        def configurable_default(cls):
            return FooImpl
    class FooImpl(Foo):
        def initialize(self, x, y):
            pass
    Foo.configure(None)
    x = Foo(1, 2)
    assert isinstance(x, FooImpl)
    # Unit test for method __repr__ of class Configurable

# Generated at 2022-06-12 14:22:35.873955
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    '''
    Test of basic functionality of __new__ that uses the other methods
    for testing.
    '''
    # This test is not exhaustive but does have basic test of functionality
    class TestClass(Configurable):
        def configurable_base(self):
            return TestClass

        def configurable_default(self):
            return DefaultImpl

        def initialize(self, x, y, z=1):
            self.args = (x, y, z)

        def __str__(self):
            return "TestClass(%s)" % (str(self.args),)

    class DefaultImpl(TestClass):
        def initialize(self, x, y, z=12):
            self.args = (x, y, z)


# Generated at 2022-06-12 14:22:46.056383
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, 42) == 42
    assert r.replace(1, (1, 2), {}) == (None, (1, 2), {"c": 1})

    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.replace(1, (1, 2, 3), {}) == (3, (1, 2, 1), {})

    assert r.get_old_value((1, 2), {"c": 3}) == 3

# Generated at 2022-06-12 14:22:57.341633
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self, a: int, b: int = 1, c: int = 2) -> None:
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert issubclass(A, Configurable)
    assert issubclass(B, Configurable)
    assert issubclass(C, Configurable)
    assert A.configurable_base() is A
    assert A.configurable_default() is B
    assert B.configurable_base() is A
    assert B.configurable_default() is B
    assert C.configurable_base() is A
    assert C.configurable

# Generated at 2022-06-12 14:23:04.720994
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(a, b=5, c="hello"):
        pass
    arg_a = ArgReplacer(func1, "a")
    arg_b = ArgReplacer(func1, "b")
    arg_c = ArgReplacer(func1, "c")
    assert arg_a.get_old_value((4,), {}, None) == 4
    assert arg_a.get_old_value((4, 5, "hello"), {}) == 4
    assert arg_a.get_old_value((4, 5, "hello"), {"c": "hi"}) == 4
    assert arg_a.get_old_value((4, 5, "hello"), {"c": "hi"}, "bye") == 4
    assert arg_b.get_old_value((4,), {}, 1) == 5
    assert arg

# Generated at 2022-06-12 14:23:58.577021
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import unittest.mock._CallList
    # Test for correct execution of the method
    class Mock:
        def __new__(self):
            return None
    class Mock_class:
        pass
    mock_param1 = Mock()
    mock_param2 = mock_param3 = mock_param4 = None  # type: Optional[None]
    mock_param5 = {}
    mock_param6 = []
    mock_param7 = unittest.mock._CallList(((1, 2), (3, 4)))
    mock_param8 = Configurable()
    mock_param9 = mock_param10 = None  # type: Optional[Type[Configurable]]
    mock_param11 = []
    mock_param12 = {}
    mock_param13 = Mock_class()
    mock

# Generated at 2022-06-12 14:24:08.091055
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c=3, d=4, e=5, f=6):
        pass
    arg_replacer = ArgReplacer(foo, "c")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 5}) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) == 3
    assert arg_replacer.get_old_value((1, 2), {"b": 4, "c": 5}) == 5
    assert arg_replacer.get_old_value((1, 2), {"c": 5}) == 5
    assert arg_replacer.get_old_value((1, 2), {}) == 3


# Generated at 2022-06-12 14:24:08.965321
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-12 14:24:13.126980
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise MyException(42, "answer")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise MyException(errno=42)
    except Exception as e:
        assert errno_from_exception(e) == 42


# Generated at 2022-06-12 14:24:22.390951
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import_object = None
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyConfigurable

        @classmethod
        def configurable_default(cls):
            return MyConfigurableImpl

        @classmethod
        def configure(cls, impl, **kwargs):
            print("in configure")
            super().configure(impl, **kwargs)

        def _initialize(self):
            print("in initialize")

    class MyConfigurableImpl:
        pass

    mc = MyConfigurable()
    print(mc)



# Generated at 2022-06-12 14:24:27.150507
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConfigurableTest(Configurable):
        def __init__(self,*args,**kwargs):
            super().initialize(*args,**kwargs)
        def configurable_base(self):
            pass
        def configurable_default(self):
            pass
    configurable_test = ConfigurableTest()
    # failed with: method initialize of class Configurable
    assert (configurable_test is not None)



# Generated at 2022-06-12 14:24:30.788597
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    def f() -> None:
        # type: () -> None
        pass
    od = ObjectDict()
    od.foo = f
    f_obj = od.foo
    assert f_obj == f



# Generated at 2022-06-12 14:24:40.872482
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=3, d=4):
        pass

    # The following tuple contains the function object that to be tested and
    # the corresponding expected arguments

# Generated at 2022-06-12 14:24:48.897093
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # this is a test of a private method
    # pylint: disable=protected-access
    class MyFunc(object):
        """Empty class to provide an object to test with."""

        def __init__(self):
            pass

    def my_func():
        """Dummy function to test with."""
        return None

    def my_func_args(*args):
        """Dummy function to test with."""
        return args

    def my_func_kwargs(**kwargs):
        """Dummy function to test with."""
        return kwargs

    def my_func_args_kwargs(*args, **kwargs):
        """Dummy function to test with."""
        return args, kwargs

    def my_func_mult_args(a, b):
        """Dummy function to test with."""

# Generated at 2022-06-12 14:24:58.062488
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c, *, kwarg):
        pass
    arg_replacer = ArgReplacer(test_func, "a")
    args = (1, 2, 3)
    kwargs = {"kwarg": 4}
    old_value = arg_replacer.get_old_value(args, kwargs)
    assert old_value == 1
    old_value = arg_replacer.get_old_value(args, kwargs, default=5)
    assert old_value == 1
    arg_replacer = ArgReplacer(test_func, "kwarg")
    old_value = arg_replacer.get_old_value(args, kwargs)
    assert old_value == 4

# Generated at 2022-06-12 14:26:00.274133
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from tornado import gen
    from tornado.concurrent import Future
    def func1(a,b,c=2,d=4,**kwargs):
        pass

    carrier = ArgReplacer(func1, "c")
    old_value, args, kwargs = carrier.replace(5, (1,2), {"d":3})
    assert old_value == 2
    assert args == (1,2)
    assert kwargs == {"c": 5, "d": 3}

    carrier = ArgReplacer(func1, "d")
    old_value, args, kwargs = carrier.replace(6, (1,2), {"d":3})
    assert old_value == 3
    assert args == (1,2)
    assert kwargs == {"d": 6}


# Generated at 2022-06-12 14:26:06.815445
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConfigurableTest(Configurable):
        def configurable_base(cls): return ConfigurableTest

        def configurable_default(cls): return ConfigurableTest

        def initialize(self, some_param=None, some_other_param=None):
            self.some_param = some_param
            self.some_other_param = some_other_param

    ConfigurableTest.configure(None, some_param='foo')
    t = ConfigurableTest(some_other_param="bar")
    assert t.some_param == 'foo'
    assert t.some_other_param == 'bar'



# Generated at 2022-06-12 14:26:16.065104
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import mock
    import unittest
    import types

    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyConfigurable

        @classmethod
        def configurable_default(cls):
            return MyConfigurable

    class Test(unittest.TestCase):
        def test_initialize(self):
            obj = MyConfigurable()
            self.assertTrue(isinstance(obj, MyConfigurable))
            self.assertTrue(obj.initialize.__func__ is not MyConfigurable.initialize.__func__)

    case = unittest.TestLoader().loadTestsFromTestCase(Test)
    suite = unittest.TestSuite([case])
    mock.patch('unittest.TestResult').start()

    runner = unittest.Text