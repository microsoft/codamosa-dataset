

# Generated at 2022-06-12 14:16:54.059753
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # This function's type annotation must use comments instead of
    # real annotations because typing.NoReturn does not exist in
    # python 3.5's typing module. The formatting is funky because this
    # is apparently what flake8 wants.
    # type: () -> typing.NoReturn
    try:
        raise_exc_info((None, ValueError(), None))
    except ValueError:
        pass
    try:
        raise_exc_info((None, TypeError(), None))
    except ValueError:
        raise ValueError("ValueError should have been raised")
    except TypeError:
        pass
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass
    try:
        raise_exc_info(None)  # type: ignore
    except TypeError:
        pass



# Generated at 2022-06-12 14:17:03.135212
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, arg1, arg2, arg3=None, arg4=None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.arg4 = arg4

        def get_configurable_base(self):
            return A

        def get_configurable_default(self):
            return A


    class B(A):
        pass


    class C(A):
        pass


    assert issubclass(A, Configurable)
    assert issubclass(B, Configurable)
    assert issubclass(C, Configurable)

   

# Generated at 2022-06-12 14:17:07.818491
# Unit test for function errno_from_exception
def test_errno_from_exception():
    exc = IOError()
    assert exc.errno is None
    assert exc.args == tuple()
    exc.errno = 42
    assert errno_from_exception(exc) == 42

    exc = IOError(42)
    assert exc.errno is None
    assert exc.args == (42,)
    exc.errno = 42
    assert errno_from_exception(exc) == 42



# Generated at 2022-06-12 14:17:12.932295
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestClass(Configurable):
        # Override of method configurable_base of class Configurable
        def configurable_base(self):
            return TestClass

        # Override of method configurable_default of class Configurable
        def configurable_default(self):
            return TestClass

    obj = TestClass()
    print(obj)


test_Configurable_initialize()

# Generated at 2022-06-12 14:17:17.562310
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Test(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
        def _initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    c = Test(1, 2, 3, foo=1, bar=2)
    assert c.args == (1, 2, 3)
    assert c.kwargs == {'foo': 1, 'bar': 2}
    logger.info('test_Configurable_initialize passed')


# Generated at 2022-06-12 14:17:22.102879
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C:
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    a = C()
    b = C(1, 2, x=3)
    assert a.args == ()
    assert a.kwargs == {}
    assert b.args == (1, 2)
    assert b.kwargs == {"x": 3}


# Generated at 2022-06-12 14:17:30.215894
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-12 14:17:41.552653
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(first, second=None):
        pass
    # check if we get old_value with keyword argument
    replacer = ArgReplacer(foo, 'second')
    old_value, args, kwargs = replacer.replace(None, (1,), {'second': 'hello'})
    assert old_value == 'hello'
    assert args == (1,) and kwargs == {'second': None}
    # check if we get old_value with pos argument
    old_value, args, kwargs = replacer.replace(None, (1, 'hello'), {})
    assert old_value == 'hello'
    assert args == (1, None) and kwargs == {}
    # check if default value is None with missing argument

# Generated at 2022-06-12 14:17:49.592014
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    from unittest import mock

    with mock.patch("tornado.util.raise_exc_info", wraps=raise_exc_info):
        try:
            raise ValueError()
        except ValueError:
            exc_info = None
            raise_exc_info(exc_info)

        exc_info = (None, None, None)
        try:
            raise_exc_info(exc_info)
            assert False, "should have raised"
        except TypeError as e:
            assert e.args[0] == "raise_exc_info called with no exception"



# Generated at 2022-06-12 14:17:55.313771
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Base(Configurable):

        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Default

        def initialize(self, value, test=0):
            self.value = value
            self.test = test

    class Default(Base):

        def initialize(self, value, test=0):
            super(Default, self).initialize(value, test)

    class Subclass(Base):
        pass

    class Other(Configurable):

        def configurable_base(self):
            return Other

        def configurable_default(self):
            return OtherDefault

        def initialize(self, value, test=0):
            self.value = value
            self.test = test


# Generated at 2022-06-12 14:18:11.058202
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

        def initialize(self, arg1, arg2=None):
            self.args = arg1, arg2

    c1 = C(1)
    assert isinstance(c1, C)
    assert c1.args == (1, None)

    C.configure(None, arg2=2)
    c2 = C(1)
    assert isinstance(c2, C)
    assert c2.args == (1, 2)

    # Test that configuration persists across subclasses.
    class D(C):
        pass

    C.configure("foobar")
    assert D.configured_class() is C.configured

# Generated at 2022-06-12 14:18:18.175628
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(42, "test")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception(errno=42)
    except Exception as e:
        assert errno_from_exception(e) == 42



# Generated at 2022-06-12 14:18:25.683387
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Set up
    a = ArgReplacer(foo, "x")
    # Test
    args_tuple = ()
    args_list = [0]
    kwargs = {}
    
    assert a.replace(1, args_tuple, kwargs) == (None, [1], {})
    assert a.replace(2, args_list, kwargs) == (0, [2], {})
    
    kwargs = {"x": 3}
    assert a.replace(4, args_tuple, kwargs) == (3, [], {"x": 4})
    assert a.replace(5, args_list, kwargs) == (5, [2], {"x": 3})

# Generated at 2022-06-12 14:18:35.945242
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(a=1, b=2):
        pass

    ar = ArgReplacer(f, 'a')
    assert ar.replace(3, (), {}) == (1, [], {'a': 3})
    assert ar.replace(3, (4,), {}) == (4, [3], {})
    assert ar.replace(3, (), {'b': 5}) == (1, [], {'a': 3, 'b': 5})
    assert ar.replace(3, (), {'a': 6, 'b': 5}) == (6, [], {'a': 3, 'b': 5})
    assert ar.replace(3, (7,), {'a': 6, 'b': 5}) == (7, [3], {'a': 6, 'b': 5})

   

# Generated at 2022-06-12 14:18:43.459666
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import inspect
    import os
    import re
    import select
    import socket
    import threading
    import unittest
    import zlib


    class Echo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Echo


        @classmethod
        def configurable_default(cls):
            return ThreadedEchoServer


        def initialize(self):
            pass


    class ThreadedEchoServer(Echo):
        def initialize(self):
            self.listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            self.listen_sock.setblocking(0)
            self.listen_sock.bind(('127.0.0.1', 0))

# Generated at 2022-06-12 14:18:55.351720
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fn(a, b=None, **c):
        return a, b, c

    assert ArgReplacer(fn, "a").get_old_value(("b", "c"), {}) == "b"
    assert ArgReplacer(fn, "b").get_old_value(("b", "c"), {}) == None
    assert ArgReplacer(fn, "b").get_old_value((), {"b": "c"}) == "c"
    assert ArgReplacer(fn, "b").get_old_value(("b",), {"b": "c"}) == "c"
    assert ArgReplacer(fn, "b").get_old_value(("b",), {}) == None
    assert ArgReplacer(fn, "b").get_old_value(("b",), {"b": "c"}, "d")

# Generated at 2022-06-12 14:18:56.289189
# Unit test for function import_object
def test_import_object():
    import_object('errno')



# Generated at 2022-06-12 14:18:58.551156
# Unit test for function import_object
def test_import_object():
    import_object('socket')
    import_object('tornado.test.test_util.test_import_object')



# Generated at 2022-06-12 14:19:08.115448
# Unit test for function import_object
def test_import_object():
    __test__ = {
        "import_object": (
            "test_import_object",
            "test_import_object2",
            "test_import_object3",
        ),
    }

    def test_import_object():  # type: ignore
        test_import_object2()
        test_import_object3()

    def test_import_object2():  # type: ignore
        import importlib

        module = import_object("typing")
        assert module is typing
        assert import_object("sys") is sys

        # import_object should work after importlib.reload
        importlib.reload(module)
        assert import_object("typing") is typing

    def test_import_object3():  # type: ignore
        from tornado import ioloop


# Generated at 2022-06-12 14:19:14.565332
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=1):
        pass
    arg_name = 'c'
    args = (2, 3, 4, 5)
    kwargs = {}
    arg_default = 9
    replacer = ArgReplacer(func, arg_name)
    old_value = replacer.get_old_value(args, kwargs, arg_default)
    assert old_value == 4

# Generated at 2022-06-12 14:19:31.836305
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    a = 1
    b = 2
    c = 3
    x = 4
    y = 5
    z = 6
#    print('triggered test')
    def func(a,b,c,x=4,y=5,z=6):
        pass
    arg_replacer = ArgReplacer(func, name='a')
    old_value, args, kwargs= arg_replacer.replace(7, (a,b,c),{'x':x,'y':y,'z':z})
    assert old_value == a
    assert args == (7,b,c)
    assert kwargs == {'x':x, 'y':y, 'z':z}

# Generated at 2022-06-12 14:19:40.767014
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    def _test_Configurable_initialize(impl):
        assert isinstance(impl, Configurable)
        assert not hasattr(impl, "initialize")

    # This is a vanilla invocation (the first in the file), and
    # __impl_class should not be set yet
    _test_Configurable_initialize(Configurable())
    # A second invocation should not change anything
    _test_Configurable_initialize(Configurable())

    # This is a recursive invocation of the classmethod, but
    # __impl_class will have been set at the previous step
    _test_Configurable_initialize(Configurable.configured_class()())



# Generated at 2022-06-12 14:19:41.475787
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    assert True

# Generated at 2022-06-12 14:19:43.087760
# Unit test for function import_object
def test_import_object():
    from tornado.escape import utf8
    assert import_object("tornado.escape.utf8") is utf8
    assert import_object("tornado.escape") is utf8.__module__



# Generated at 2022-06-12 14:19:44.154082
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a: int, b: str, c: int = 0, d: int = 0) -> None:
        pass



# Generated at 2022-06-12 14:19:51.088635
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(1)
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 1
    try:
        raise Exception((1,))
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 1



# Generated at 2022-06-12 14:19:59.520891
# Unit test for method __new__ of class Configurable
def test_Configurable___new__(): 
    class Configurable:
        def __new__(cls, *args, **kwargs): 
            instance = super().__new__(cls)
            instance.initialize(*args, **kwargs)
            return instance

        def _initialize(self): 
            pass

        initialize = _initialize  # type: Callable[..., None]

        @classmethod
        def configure(cls, impl, **kwargs): 
            raise NotImplementedError()

        @classmethod
        def configured_class(cls): 
            raise NotImplementedError()

        @classmethod
        def _save_configuration(cls): 
            raise NotImplementedError()

        @classmethod
        def _restore_configuration(cls, saved): 
            raise NotImplementedError()


# Generated at 2022-06-12 14:20:08.755496
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Test(object):
        def fn(self, a, b=None, c=None):
            pass
    t = Test()
    r = ArgReplacer(t.fn, "b")
    # positional
    old, args, kwargs = r.replace("new", ("a", ), {})
    assert old == "new"
    assert args == ("a", )
    assert kwargs == {}
    # named - replacement
    old, args, kwargs = r.replace("new2", (), {"b": "old"})
    assert old == "old"
    assert args == ()
    assert kwargs == {"b": "new2"}
    # named - addition
    old, args, kwargs = r.replace("new3", (), {"d": "old2"})
    assert old is None
    assert args

# Generated at 2022-06-12 14:20:18.358217
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    @ArgReplacer("string")
    def function(string: str, number: int) -> Tuple[str, int]:
        return string, number
    assert function.get_old_value(("hello", 10), {}) == "hello"
    assert function.get_old_value(("hello", 10), {'number': 10}) == 'hello'
    assert function.get_old_value(("hello",), {'number': 10}) == "hello"
    assert function.get_old_value(("hello",), {}) == "hello"
    assert function.get_old_value((), {'string': "hello", 'number': 10}) == 'hello'


# Generated at 2022-06-12 14:20:23.483257
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    args = [10, 20, 30]
    kwargs = {"name": "My name"}
    obj = ArgReplacer(test_ArgReplacer_get_old_value, "name")
    returned_value = obj.get_old_value(args, kwargs)
    if returned_value == kwargs.get("name"):
        print("get_old_value: Passed")
    else:
        print("get_old_value: Failed")


# Generated at 2022-06-12 14:20:47.599692
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(configurable):
            return configurable
        def configurable_default(configurable):
            return configurable

    class B(A):
        def initialize(self, foo):
            self.foo = foo

    class C(A):
        def initialize(self, foo, bar):
            self.foo = foo
            self.bar = bar

    A.configure(None)
    A.configure(B)

    b = A("foo")
    assert isinstance(b, B)
    assert b.foo == "foo"

    A.configure(C)
    c = A("foo")
    assert isinstance(c, C)
    assert c.foo == "foo"
    assert c.bar is None

    A.configure(C, bar="blah")

# Generated at 2022-06-12 14:20:58.527213
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):

        def __init__(self):
            # type: () -> None
            raise Exception("Not called")

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

    class Impl1(Base):

        def initialize(self):
            # type: () -> None
            pass

    assert isinstance(Impl1(), Impl1)
    assert not isinstance(Impl1(), Base)
    assert Base()  # type: ignore

    class Impl2(Base):

        def initialize(self):
            # type: () -> None
            pass


# Generated at 2022-06-12 14:21:10.061024
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func1(arg1):
        pass
    def func2(arg1, arg2):
        pass
    def func3(arg1, arg2 = 0):
        pass
    def func4(arg1 = False, arg2 = True):
        pass
    def func5(arg1, arg2, arg3 = False, arg4 = True):
        pass
    def func6(arg1, arg2, arg3 = False, arg4 = True, *args):
        pass
    def func7(arg1, arg2, arg3 = False, arg4 = True, **kwargs):
        pass
    def func8(arg1, arg2, arg3 = False, arg4 = True, *args, **kwargs):
        pass


# Generated at 2022-06-12 14:21:16.140406
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():

    def _ObjectDict___getattr__(name):
        d = ObjectDict()
        d["attr"] = 1
        assert d.attr == 1
        del d.attr
        try:
            d.attr
        except AttributeError:
            pass
        else:
            assert 0

    _ObjectDict___getattr__("attr")

# Generated at 2022-06-12 14:21:26.203498
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b):
        pass
    assert ArgReplacer(f, 'b').get_old_value((1, 2), {}) == 2
    assert ArgReplacer(f, 'b').get_old_value((1,), {'b' : 2}) == 2
    assert ArgReplacer(f, 'b').get_old_value((), {'b' : 2}) == 2
    assert ArgReplacer(f, 'c').get_old_value((), {'c' : 2}) == 2
    assert ArgReplacer(f, 'c').get_old_value((), {}, 3) == 3
    assert ArgReplacer(f, 'c').get_old_value((), None, 3) == 3


# Generated at 2022-06-12 14:21:34.625729
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b=None):
        print('Executing f(a, b=None)')
        return a + b

    class TestClass(object):
        def __init__(self):
            self.replacer = ArgReplacer(f, "b")

        def test_replace_positional_arg_of_function(self):
            old_b, args, kwargs = self.replacer.replace(1, (2,), {})
            assert old_b == None
            assert args == (2,)
            assert kwargs == {'b': 1}

            old_b, args, kwargs = self.replacer.replace(1, (2,), {'b':3})
            assert old_b == 3
            assert args == (2,)
            assert kwargs == {'b': 1}



# Generated at 2022-06-12 14:21:38.118213
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import socket
    with mock.patch('socket.socket') as mock_socket:
        result = socket.socket()
        mock_socket.assert_called_with()


# Generated at 2022-06-12 14:21:47.354702
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def __init__(self):
            super(TestConfigurable, self).__init__()

        def initialize(self):
            pass

    t = TestConfigurable()
    assert(t.__dict__ == {})

    class Test1(TestConfigurable):
        def initialize(self):
            pass

    t = Test1()
    assert(t.__dict__ == {})

    class Test2(TestConfigurable):
        def __init__(self):
            super(Test2, self).initialize()

    t = Test2()
    assert(t.__dict__ == {})



# Generated at 2022-06-12 14:21:56.736689
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b=None, *args, **kwargs):
        pass

    ar = ArgReplacer(foo, 'b')
    assert ar.get_old_value((1,), {}, None) is None
    assert ar.get_old_value((1,), {'b': 2}, None) == 2
    assert ar.get_old_value((1,), {'b': 2, 'c': 2}, None) == 2
    assert ar.get_old_value((1, 2), {'c': 2}, None) == 2
    assert ar.get_old_value((), {'c': 2}, None) is None
    assert ar.get_old_value((1,), {'b': 2, 'c': 2}, 3) == 2

# Generated at 2022-06-12 14:22:04.928571
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from functools import partial
    from inspect import signature
    from pytest import raises
    def test_func(a, b=1, *, c):
        pass
    arg1 = signature(test_func).parameters["a"]
    arg2 = signature(test_func).parameters["b"]
    arg3 = signature(test_func).parameters["c"]
    new_value = 42
    test_args = (1, 2, 3)
    test_kwargs = {"c": 4}

    replacer = ArgReplacer(test_func, "a")
    old_a, args, kwargs = replacer.replace(new_value, test_args, test_kwargs)
    assert args[0] == new_value
    assert kwargs["c"] == 4
    assert old_a == 1

    repl

# Generated at 2022-06-12 14:22:31.590436
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    _impl_class = Configurable.__impl_class
    _impl_kwargs = Configurable.__impl_kwargs
    

# Generated at 2022-06-12 14:22:43.069910
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ParentConf(Configurable):
        @classmethod
        def configurable_base(cls):
            return ParentConf

        @classmethod
        def configurable_default(cls):
            return Object

        def initialize(self, *args, **kwargs):
            pass

    class Object(ParentConf):
        pass

    class OtherObject(ParentConf):
        pass

    a = Object({'name': 'abc'})
    b = OtherObject({'name': 'def'})

    ParentConf.configure(Object)
    ParentConf.configure(OtherObject, a=1, b=2)

    # Test for the class attribute __impl_class
    assert ParentConf.__impl_class is Object
    assert a.__class__ is Object
    assert b.__class__ is OtherObject

    # Test for the class attribute __

# Generated at 2022-06-12 14:22:54.082295
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfig(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyConfig

        @classmethod
        def configurable_default(cls):
            return MyConfig

    def initialize(self, **kwargs):
        super(MyConfig, self).initialize(**kwargs)
        self.kwargs = kwargs

    MyConfig.initialize = initialize
    MyConfig.configure("tornado.test.test_util.MyConfig", myarg="test")
    config = MyConfig()
    assert config.kwargs["myarg"] == "test"
    MyConfig.configure("tornado.test.test_util.MyConfig")
    config = MyConfig(myarg="test")
    assert config.kwargs["myarg"] == "test"



# Generated at 2022-06-12 14:22:58.093651
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(*args, **kwargs):
        pass
    arg_replacer = ArgReplacer(test_func, 'args')
    assert arg_replacer.get_old_value((), {}) == None
    assert arg_replacer.get_old_value((1,), {}) == 1
    assert arg_replacer.get_old_value((), {'args': 1}) == 1
    assert arg_replacer.get_old_value((1,), {'args': 2}) == 1


# Generated at 2022-06-12 14:23:01.913177
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a,b):
        pass
    rep = ArgReplacer(test,"a")
    assert rep.get_old_value((1,2),{}) == 1
    assert rep.get_old_value((),{"a":2}) == 2
    assert rep.get_old_value((),{"b":2}) == None

# Generated at 2022-06-12 14:23:12.467513
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base():
            # type: () -> Type[A]
            # Cannot use regular type annotation (A) because A is not
            # defined until the end of the class definition block.
            return A
        def configurable_default():
            # type: () -> Type[A]
            return B
        def __init__(self, x):
            # type: (int) -> None
            self.x = x
    class B(A):
        def initialize(self, x):
            # type: (int) -> None
            self.x = x*2

    A.configure(B)
    assert A(42).x == 84
    assert isinstance(A(42), B)
    assert A(21).x == 42

    A.configure(None)

# Generated at 2022-06-12 14:23:21.928683
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class SomeConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return SomeConfigurable

        @classmethod
        def configurable_default(cls):
            return SomeConfigurable

        def _initialize(self):
            self.initialized = True

    SomeConfigurable.configure(SomeConfigurable)
    assert isinstance(SomeConfigurable(), SomeConfigurable)
    assert isinstance(SomeConfigurable(), SomeConfigurable.configured_class())

    assert isinstance(SomeConfigurable(), SomeConfigurable)
    assert isinstance(SomeConfigurable(initialized="test"), SomeConfigurable)
    assert SomeConfigurable().initialized == True
    assert SomeConfigurable(initialized="test").initialized == "test"

    class A(SomeConfigurable):
        pass

    class B(SomeConfigurable):
        pass

   

# Generated at 2022-06-12 14:23:29.146599
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class MyException(BaseException):
        def __init__(self, msg: str, errno: int):
            super().__init__(msg)
            self.errno = errno

    assert errno_from_exception(MyException("test", 42)) == 42
    assert (
        errno_from_exception(
            MyException("test", None)  # type: ignore
        )
        is None
    )
    assert errno_from_exception(Exception("test", 42)) == 42
    assert (
        errno_from_exception(
            Exception("test")  # type: ignore
        )
        is None
    )



# Generated at 2022-06-12 14:23:35.879219
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_function(a, b, c, d=None, e=None, f=None):
        pass

    test_object = ArgReplacer(test_function, 'f')
    old_value_1 = test_object.get_old_value((1,2,3,4), {})
    assert(old_value_1 == None)

    old_value_2 = test_object.get_old_value((1, 2, 3, 4), {'f' : 'test_f'})
    assert(old_value_2 == 'test_f')



# Generated at 2022-06-12 14:23:41.194978
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b):
        pass
    a = ArgReplacer(func, 'a')
    assert a.replace(1, (2, 3), {}) == (2, [1, 3], {})
    assert a.replace(1, (2,), {'b': 3}) == (2, [1], {'b': 3})
    assert a.replace(
        1, (), {'b': 3}) == (None, (), {'a': 1, 'b': 3})


# Generated at 2022-06-12 14:24:17.258972
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(a, b, c=3, d=4):
        pass
    ArgReplacer(func1, "d").get_old_value([1, 2], {})

# Generated at 2022-06-12 14:24:27.455458
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest
    import types
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestConfigurable
    class TestConfigurable_Subclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            super(TestConfigurable_Subclass, self).initialize(*args, **kwargs)
            self.args=args
            self.kwargs=kwargs

    class TestConfigurable_Subclass_Subclass(TestConfigurable_Subclass):
        pass

    def check_test_configurable_initialize(test_method):
        # check a class configurable
        TestConfigurable.configure(None)

        # test a subclass of configurable
       

# Generated at 2022-06-12 14:24:38.088212
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Foo(Configurable):
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Foo
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Bar
    class Bar(Foo):
        pass
    class Baz(Foo):
        pass
    Foo.configure(Bar)
    assert isinstance(Foo(), Bar)
    assert isinstance(Foo(), Foo)
    Foo.configure(Baz)
    assert isinstance(Foo(), Baz)
    assert isinstance(Foo(), Foo)
    Foo.configure(None)
    assert isinstance(Foo(), Bar)
    assert isinstance(Foo(), Foo)
    Foo.configure(Bar, x=1)


# Generated at 2022-06-12 14:24:45.455748
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun(a,b=2,c=3):
        pass
    a = ArgReplacer(fun,'a')
    m = a.replace(3,(4,5),{})
    assert m==(4,(3,5),{})
    n = a.replace(3,(4,5),{'b':2})
    assert n==(4,(3,5),{'b':2})
    q = a.replace(3,(4,5),{'b':2,'c':3})
    assert q==(4,(3,5),{'b':2,'c':3})
    o = a.replace(3,(4,5),{'a':2,'b':2,'c':3})

# Generated at 2022-06-12 14:24:54.282739
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    x = ArgReplacer(lambda a, b: None, "a")
    assert x.get_old_value(("hi", "there"), {}) == "hi"
    assert x.get_old_value(("hi", "there"), {}, 42) == "hi"
    assert x.get_old_value(("hi", "there"), {}, None) == "hi"
    assert x.get_old_value(("hi", "there"), {"a": 42}) == 42
    assert x.get_old_value(("hi", "there"), {"a": 42}, "arg") == 42
    assert x.get_old_value(("hi", "there"), {"b": 42}) is None
    assert x.get_old_value(("hi", "there"), {"b": 42}, "arg") == "arg"

# Generated at 2022-06-12 14:25:03.424016
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

        def initialize(self, a, b=None, *args, **kwargs):
            # type: (Any, Any, Any, Any) -> None
            pass

    class B(A):
        pass

    class C(B):
        pass

    A(1, 2, 3, 4)
    A(1, 2, 3, keyword=4)
    A(a=1, b=2)
    B(1, 2, 3, 4)

# Generated at 2022-06-12 14:25:11.409329
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None

    class C(Configurable):
        def __init__(self):
            pass

        def configurable_base(self):
            pass

        def configurable_default(self):
            pass

    class D(C):
        def initialize(self):
            pass

    class E(D):
        def initialize(self):
            pass

    class F(C):
        def initialize(self):
            pass

    c = C()
    d = D()
    e = E()
    f = F()
    import sys

    assert c.initialize is C._initialize
    assert d.initialize is D.initialize
    assert e.initialize is E.initialize
    assert f.initialize is F.initialize



# Generated at 2022-06-12 14:25:21.517894
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConfigurableSubclass(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableSubclass

        @classmethod
        def configurable_default(cls):
            return ConfigurableSubclass

        def initialize(self, var_1, var_2):
            self.var_1 = var_1
            self.var_2 = var_2

        def __eq__(self, other):
            if isinstance(other, ConfigurableSubclass):
                return self.var_1 == other.var_1 and self.var_2 == other.var_2
            return False

        def __hash__(self):
            return hash(self.var_1) ^ 42


# Generated at 2022-06-12 14:25:27.336078
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConcreteClass(Configurable):
        def configurable_base(self):
            return Configurable
        def configurable_default(self):
            return ConcreteClass
    c = ConcreteClass.configure()
    assert c == ConcreteClass
    assert c.configured_class() == ConcreteClass
    assert isinstance(c, ConcreteClass)
    class Subclass(ConcreteClass):
        def configurable_default(self):
            return Subclass
    c = Subclass.configure()
    assert isinstance(c, Subclass)



# Generated at 2022-06-12 14:25:34.294390
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    #valid cases
    def func1(a,b,c=1):
        pass
    inst = ArgReplacer(func1, 'b')
    assert inst.get_old_value((1,2,'3',), {}) == 2
    assert inst.get_old_value((1,2,'3',), {'a': None, 'b': None}) == 2

    #invalid cases
    with pytest.raises(IndexError):
        inst.get_old_value((1,), {})
    assert inst.get_old_value(('1',), {}) == None
