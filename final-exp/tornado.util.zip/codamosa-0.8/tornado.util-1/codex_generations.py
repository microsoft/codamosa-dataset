

# Generated at 2022-06-12 14:16:41.730819
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(
        first: Any,
        second: Any,
        third: Any,
        fourth: Any = None,
        fifth: Any = None,
        *args: Any,
        **kwargs: Any
    ):
        pass

    assert ArgReplacer(func, "fourth").get_old_value((1, 2, 3), {}) is None
    assert ArgReplacer(func, "fourth").get_old_value((1, 2, 3), {}, default=123) == 123
    assert ArgReplacer(func, "fourth").get_old_value((1, 2, 3), {"fourth": 456}) == 456

    assert ArgReplacer(func, "fifth").get_old_value((1, 2, 3), {}) is None

# Generated at 2022-06-12 14:16:43.328593
# Unit test for function import_object
def test_import_object():
    import doctest
    doctest.run_docstring_examples(import_object, globals())



# Generated at 2022-06-12 14:16:49.594754
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(x,y,z):
        pass
    def pytest_funcarg__replacer(request):
        return ArgReplacer(foo, "y")
    def test_replace(replacer):
        args = (1,2,3)
        kwargs = dict(x=10,y=20,z=30)
        new_value = 9
        old_value, args, kwargs = replacer.replace(new_value, args, kwargs)
        assert new_value == args[1]




# Generated at 2022-06-12 14:16:55.559788
# Unit test for function import_object
def test_import_object():
    from tornado import escape, util
    # This is a super-non-robust test, but it does exercise the code
    # and catch obvious errors.
    assert import_object("tornado.util") is util
    assert import_object("tornado.util.import_object") is import_object
    assert import_object("tornado.escape") is escape
    assert import_object("tornado.escape.utf8") is escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        raise Exception("fail")



# Generated at 2022-06-12 14:17:06.217491
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        __impl_class = None #type: Optional[Type[Configurable]]
        __impl_kwargs = None #type: Dict[str, Any]
        def __new__(cls,*args,**kwargs):
            return super(A,cls).__new__(cls,*args,**kwargs)
        def configurable_base(self):
            # type: () -> Type[Configurable]
            raise NotImplementedError()
        def configurable_default(self):
            # type: () -> Type[Configurable]
            raise NotImplementedError()
        def _initialize(self, *args, **kwargs):
            # type: () -> None
            pass
        def initialize(self,*args,**kwargs):
            # type: () -> None
            self

# Generated at 2022-06-12 14:17:13.118769
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(5, "EIO", os.strerror(5))
    except IOError as e:
        assert errno_from_exception(e) == 5
    try:
        raise IOError("EIO")
    except IOError as e:
        assert errno_from_exception(e) == "EIO"
    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-12 14:17:17.090674
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        def configurable_base(cls):
            return Configurable

        def configurable_default(cls):
            return None
    class Bar(Foo):
        pass

    # "Foo" is not configurable.
    # And "Bar" is not instantiated.
    # It should raise "NotImplementedError" exception.
    with pytest.raises(NotImplementedError):
        Foo()

    with pytest.raises(NotImplementedError):
        Foo.configure(None)



# Generated at 2022-06-12 14:17:25.208751
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():

    class A(Configurable):
        pass

    with pytest.raises(NotImplementedError):
        A.configurable_base()

    with pytest.raises(NotImplementedError):
        A.configurable_default()


if sys.version_info < (3, 5):

    def _raise_exc_info(exc_info):
        # type: (Tuple[Optional[Type[BaseException]], Optional[BaseException], Optional[TracebackType]]) -> typing.NoReturn
        """Re-raise an exception (with original traceback) from an exc_info tuple.

        The argument is a ``(type, value, traceback)`` tuple as returned
        by `sys.exc_info`.
        """
        # This function's type annotation must use comments instead of
        # real annotations because typing.NoReturn does not exist

# Generated at 2022-06-12 14:17:28.999151
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # Aliases for types that are spelled differently in different Python
    # versions. bytes_type is deprecated and no longer used in Tornado
    # itself but is left in case anyone outside Tornado is using it.
    bytes_type = bytes
    unicode_type = str
    basestring_type = str



# Generated at 2022-06-12 14:17:40.335578
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    '''
    Test case for method get_old_value of class ArgReplacer
    
    Parameters:
    -----------
    @param
        func: A method object
    @param
        name: Name of the arg to be replaced
    @param
        default: default value to be returned if arg not found
    
    Raises:
    -------
    @raises
        TypeError: If argument passed is not a valid function
           
    Returns:
    --------
    @return 
        The original value of the arg if it is present in the function
        else returns the default value
    '''
    # Test case 1

# Generated at 2022-06-12 14:17:55.380213
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    mock_kwargs = dict(name='kobe', num=24, nba=dict(team='lakers'))
    mock_args = (1, 2, 3, 4)
    mock_arg_replacer = ArgReplacer(func=mock_kwargs.get, name='team')
    assert mock_arg_replacer.get_old_value(
        args=mock_args, kwargs=mock_kwargs) == 'lakers'
    assert mock_arg_replacer.get_old_value(
        args=mock_args, kwargs=mock_kwargs, default=None) == None


# Generated at 2022-06-12 14:18:05.383383
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    BaseConfigurable = Configurable

    class BaseConfigurable(Configurable):
        def configurable_base(self):
            pass
        def configurable_default(self):
            pass
    BaseConfigurable()
    S1 = BaseConfigurable
    class S1(BaseConfigurable):
        pass
    class S2(S1):
        pass
    class S3(S1):
        pass

    S2()
    S1.configure(S3)
    S1.configured_class().configure(S2)
    S1()
    _saved_conf1 = S1._save_configuration()
    class S2(S1):
        def initialize(self, s=3):
            self.s = s
        def configurable_base(self):
            pass

# Generated at 2022-06-12 14:18:12.360738
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(a, b, c):
        pass

    argreplacer1 = ArgReplacer(func1, "b")
    assert argreplacer1.get_old_value((1, 2, 3), {}) == 2
    assert argreplacer1.get_old_value((1, 2, 3), {}, default=100) == 2
    assert argreplacer1.get_old_value((1, 2, 3), {"b": 100}) == 2
    assert argreplacer1.get_old_value((1, 3), {"b": 2}) == 2
    assert argreplacer1.get_old_value((1, 3), {}, default=100) == 100
    assert argreplacer1.get_old_value((1, 3), {"b": 100}) == 100

# Generated at 2022-06-12 14:18:23.047530
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import inspect

    class bar(Configurable):
        def configurable_base(cls):
            return bar

        def configurable_default(cls):
            return bar

        def __new__(cls, *args, **kwargs):
            base = cls.configurable_base()
            impl = cls.configured_class()
            instance = super(Configurable, cls).__new__(impl)
            instance.initialize(*args, **kwargs)
            return instance

        def initialize(self, *args, **kwargs):
            pass

    assert inspect.signature(bar.__new__).parameters == signature(bar).parameters
    assert inspect.signature(bar.initialize).parameters == signature(bar).parameters



# Generated at 2022-06-12 14:18:34.081236
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():

    def f(a, b, c):
        pass

    r = ArgReplacer(f, 'a')
    assert r.replace(None, (1,2,3), {}) == (1, [None, 2, 3], {})
    assert r.replace(None, (1,), {'b':4, 'c':5}) == (1, [None], {'b':4, 'c':5})
    assert r.replace(None, (), {'a':6, 'b':4, 'c':5}) == (6, [], {'a':None, 'b':4, 'c':5})
    assert r.replace(None, (), {}) == (None, [], {'a':None})

# Generated at 2022-06-12 14:18:42.620769
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Method __new__ must be tested in the same function, because it depends
    # on the test context.
    # type: () -> None
    class Test(Configurable):  # type: ignore
        def __init__(self):
            # type: () -> None
            pass

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Test]
            return Test

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Test]
            return Test

    # constructor works as normal with no config
    Test()
    # configure a subclass that does some initialization
    impl_called = [False]


# Generated at 2022-06-12 14:18:54.824679
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_replace_pos(args: Tuple[Any], kwargs: Dict[str, Any], pos: int,
                         value: Any, expected_pos: int, expected_kwargs: Dict[str, Any],
                         expected_result: Any) -> None:
        arg_replacer = ArgReplacer(test_replace_pos, "pos")

        old_value, args, kwargs = arg_replacer.replace(value, args, kwargs)
        assert old_value == expected_result
        assert args[expected_pos] == expected_result
        assert len(args) == 3
        assert kwargs == expected_kwargs

    # test cases
    test_replace_pos((1, 2, 3), {}, 1, 10, 1, {}, 2)

# Generated at 2022-06-12 14:18:56.798056
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d['x'] = 42
    assert d.x == 42
    assert d['x'] == 42



# Generated at 2022-06-12 14:18:59.863177
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    with pytest.raises(NotImplementedError):
        Configurable.configurable_base()
    with pytest.raises(NotImplementedError):
        Configurable.configurable_default()


# Generated at 2022-06-12 14:19:09.346923
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Class1(object):
        def pass_decorator(self, i):
            return i + 1

        def pass_args(self, i, j):
            return i + j

        def pass_kwargs(self, i, j=0):
            return i + j

        def pass_args_and_kwargs(self, i, j, k=0):
            return i + j + k

    class Class2(Class1):
        def pass_decorator(self, i):
            return i + 2

        def pass_args(self, i, j):
            return i + 2 * j

    def decorator(wrapped_func):
        def wrapper(obj, i):
            return wrapped_func(obj, i) + 1

        return wrapper


# Generated at 2022-06-12 14:19:26.728484
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    """Test the function get_old_value of class ArgReplacer.

    The test is implemented by calling the function get_old_value() 
    with more parameters than the function requires and checking if the 
    parameters are passed properly to the function.
    """
    def func(x, y=2) -> int:
        return x + y
    # Test the case when the parameter to replace is passed by positons
    param_replacer = ArgReplacer(func, 'x')
    assert param_replacer.get_old_value((1, ), {}, None) == 1
    # Test the case when the parameter to replace is passed by keyword
    param_replacer = ArgReplacer(func, 'y')
    assert param_replacer.get_old_value((), {'y': 3}, None) == 3
    # Test the case when the

# Generated at 2022-06-12 14:19:38.123379
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None


if hasattr(os, "sendfile"):  # type: ignore

    def sendfile(
        sock: socket.socket,
        file: typing.IO[bytes],
        offset: int,
        count: int,
    ) -> int:
        """A version of `sendfile` that calls `send` when the underlying
        system call gets interrupted.
        """
        total_sent = 0
        while total_sent < count:
            try:
                sent = os.sendfile(sock.fileno(), file.fileno(), offset, count)
                offset += sent
                total_sent += sent
            except OSError as e:
                err = errno_from_exception(e)
               

# Generated at 2022-06-12 14:19:44.658087
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def old_func(a, b, c=3, d=4):
        pass
    arg = ArgReplacer(old_func, 'b')
    assert arg.get_old_value((1, 2, 3), {'d': 4}) == 2
    assert arg.get_old_value((1, 2, 3), {'d': 4}, 5) == 2
    assert arg.get_old_value((1,), {'b': 2, 'd': 4}) == 2
    assert arg.get_old_value((1,), {'d': 4}, 5) == 5



# Generated at 2022-06-12 14:19:49.012888
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class MyClass(object):
        @staticmethod
        def my_method(arg1, arg2='', arg3=None):
            return
    def test_func(arg1, arg2='', arg3=None):
        return
    replacer = ArgReplacer(MyClass.my_method, "arg2")
    old_value, args, kwargs = replacer.replace("new", ("arg1", "old", "arg3"), {})
    assert old_value == "old"
    assert args == ("arg1", "new", "arg3")
    assert kwargs == {}
    return
test_ArgReplacer_replace()


# Generated at 2022-06-12 14:19:58.535929
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
	def test_get_old_value_1(default):
		replacer = ArgReplacer(replace_host, "host")
		return replacer.get_old_value((), {}, default)
	def test_get_old_value_2(default):
		replacer = ArgReplacer(replace_host, "host")
		return replacer.get_old_value(("a",), {}, default)
	def test_get_old_value_3(default):
		replacer = ArgReplacer(replace_host, "host")
		return replacer.get_old_value((), {"host": "a"}, default)
	def test_get_old_value_4(default):
		replacer = ArgReplacer(replace_host, "host")
		return replacer.get_old_

# Generated at 2022-06-12 14:20:05.985283
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    """Tests a method of a class Configurable.
    """
    import tornado.escape
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.auto
    import tornado.web

    class IndexHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    def make_app():
        return tornado.web.Application([(r"/", IndexHandler)])

    app = make_app()
    app.listen(8888)
    tornado.ioloop.IOLoop.current().start()



# Generated at 2022-06-12 14:20:16.577918
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    if not sys.platform.startswith("win"):
        raise unittest.SkipTest("Non-Windows platforms only")

    class MyConfigurable(Configurable):

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

    MyConfigurable.configure("tornado.netutil")
    # Test that __new__ returns a valid object
    # (i.e. does not use cls as the class to instantiate)
    with ExpectLog(gen_log, ".*MyConfigurable.*", required=False):
        obj = MyConfigurable()

# Generated at 2022-06-12 14:20:23.724266
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import os
    import unittest
    import shutil
    import logging
    import sys

    import tornado
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import tornado.tcpclient
    import tornado.tcpserver
    import tornado.iostream
    import tornado.stack_context
    from tornado.httputil import _DEFAULT_CA_CERTS



# Generated at 2022-06-12 14:20:33.702226
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(x, y, z):
        pass
    arg_replacer = ArgReplacer(func, 'y')
    assert arg_replacer.get_old_value([], {}) is None
    assert arg_replacer.get_old_value([1,2,3], {}) == 2
    assert arg_replacer.get_old_value([1,2,3], {'y': 10}) == 2
    assert arg_replacer.replace(5, [1,2,3], {}) == (2, [1,5,3], {})
    assert arg_replacer.replace(5, [1,2,3], {'y': 10}) == (2, [1,5,3], {'y': 10})



# Generated at 2022-06-12 14:20:44.649010
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        return a+b+c
    def f2(a, b, c):
        return a+b+c
    def f3(*a,**b):
        return b    

    d = ArgReplacer(f,"b")
    assert d.get_old_value([1,2,3],{},"") == 2
    assert d.get_old_value([1],{},"") == ""
    assert d.get_old_value([],{},"") == ""
    assert d.get_old_value([1,2],{"c":3},"") == 2
    assert d.get_old_value([],[],"") == ""
    

    d2 = ArgReplacer(f2,"d")
    assert d2.get_old_value([1,2,3],{},"")

# Generated at 2022-06-12 14:21:06.866694
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Abc(Configurable):
        @staticmethod
        def configurable_base():
            return Abc

        @staticmethod
        def configurable_default():
            return Aaa

        @staticmethod
        def initialize():
            pass

    test = Abc()
    assert_true(isinstance(test, Aaa))
    assert_false(isinstance(test, Abc))



# Generated at 2022-06-12 14:21:18.328538
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_function(a, b, c=None, d=None):
        pass

    inst = ArgReplacer(test_function, 'c')
    assert inst.get_old_value((1, 2), {'d': 4}) == None
    assert inst.get_old_value((1, 2, 3), {'d': 4}) == 3
    assert inst.get_old_value((1, 2, 3), {'d': 4}, 42) == 3
    assert inst.get_old_value((1, 2), {'d': 4, 'c': 5}) == 5
    assert inst.get_old_value((1, 2, 3), {'d': 4, 'c': 5}) == 5
    assert inst.get_old_value((1, 2, 3), {'d': 4, 'c': 5}, 42)

# Generated at 2022-06-12 14:21:26.251182
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    arg_replacer = ArgReplacer(lambda x, y, z=0: None, 'z')
    assert arg_replacer.replace(1, (10, 11), {'p': 97}) == (0, (10, 11), {'p': 97, 'z': 1})
    assert arg_replacer.replace(2, (10, 11), {'z': 8}) == (8, (10, 11), {'z': 2})
    assert arg_replacer.replace(3, (10, 11), {}) == (None, (10, 11), {'z': 3})



# Generated at 2022-06-12 14:21:34.582106
# Unit test for function errno_from_exception
def test_errno_from_exception():
    _errno_exceptions = (
        (
            "socket.error",
            [
                ("socket.error", socket.error),
                ("IOError", IOError),
            ],
        ),
        (
            "socket.gaierror",
            [
                ("socket.gaierror", socket.gaierror),
            ],
        ),
    )
    for exc_name, exc_types in _errno_exceptions:
        for name, exc_type in exc_types:
            e = exc_type()
            eq_(errno_from_exception(e), None)
            for errno in range(256):
                e = exc_type(errno)
                eq_(errno_from_exception(e), errno)
                e = exc_type((errno,))

# Generated at 2022-06-12 14:21:45.265693
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base
        @classmethod
        def configurable_default(cls):
            return None
        def initialize(self, **kwargs):
            pass
        def __init__(self, **kwargs):
            raise TypeError("Don't call __init__!")

    class Subclass1(Base):
        @classmethod
        def configurable_base(cls):
            return Base
        @classmethod
        def configurable_default(cls):
            return None
        def initialize(self, **kwargs):
            pass
        def __init__(self, **kwargs):
            raise TypeError("Don't call __init__!")


# Generated at 2022-06-12 14:21:54.132364
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3):
        pass
    replacer = ArgReplacer(f, 'b')
    assert replacer.get_old_value((1, 2, 3), {}) == 2
    assert replacer.get_old_value((1, 2), dict(b=3)) == 2
    assert replacer.get_old_value((1, 2, 3), dict(b=4)) ==2
    assert replacer.get_old_value((1,), dict(b=4)) ==4
    assert replacer.get_old_value((1, 2), dict(c=3)) ==2
    assert replacer.get_old_value((), dict(b=4)) ==4
    assert replacer.get_old_value((), dict()) == None


# Generated at 2022-06-12 14:22:02.778418
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConfigurableImpl(Configurable):
        """
        """
        # Type annotations on this class are mostly done with comments
        # because they need to refer to Configurable, which isn't defined
        # until after the class definition block. These can use regular
        # annotations when our minimum python version is 3.7.
        #
        # There may be a clever way to use generics here to get more
        # precise types (i.e. for a particular Configurable subclass T,
        # all the types are subclasses of T, not just Configurable).
        __impl_class = None # type: Optional[Type[Configurable]]
        __impl_kwargs = None # type: Dict[str, Any]

        def __new__(cls, *args, **kwargs):
            # type: (Any, Any) -> Any
            base = cls

# Generated at 2022-06-12 14:22:04.705621
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    """Unit test for method initialize of class Configurable
    """
    c = Configurable()
    assert c.initialize() == None



# Generated at 2022-06-12 14:22:10.584836
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import typing
    class C1(Configurable):
        @classmethod
        def configurable_base(cls):
            return C1

        @classmethod
        def configurable_default(cls):
            return C2

    class C2(C1):
        def _initialize(self):
            print(1)

    C1.configure(C2)
    print(isinstance(C1(), Configurable))
    print(isinstance(C1(), C1))
    print(isinstance(C1(), C2))
    print(type(C1()) == C2)

    c = C1()
    print(c.initialize())



# Generated at 2022-06-12 14:22:14.366214
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class DummyConfigurable(Configurable):
        def initialize(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            pass

    dummy_configurable = DummyConfigurable()



# Generated at 2022-06-12 14:22:43.069822
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a1, a2, a3=None, a4=None, a5 = '', a6 = []): pass
    ra = ArgReplacer(func, 'a1')
    print(ra.replace(1, (5,6,7), {'a4':8}))
    ra = ArgReplacer(func, 'a2')
    print(ra.replace(2, (5,6,7), {'a4':8}))
    ra = ArgReplacer(func, 'a3')
    print(ra.replace(3, (5,6,7), {'a4':8}))
    ra = ArgReplacer(func, 'a4')
    print(ra.replace(4, (5,6,7), {'a4':8}))

# Generated at 2022-06-12 14:22:54.082379
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def replace_arg(a,b=2):
        return a

    def test_function(a,b=2):
        return a+b

    arg_rep = ArgReplacer(replace_arg,'b')
    result = arg_rep.replace(1,(1,),{})
    assert result == (2,(1,),{})
    arg_rep = ArgReplacer(replace_arg,'b')
    result = arg_rep.replace(1,(1,),{'b':3})
    assert result == (3,(1,),{'b':1})
    arg_rep = ArgReplacer(test_function,'a')
    result = arg_rep.replace(1,(1,),{})
    assert result == (1,(1,),{'a':1})
    arg_rep = ArgRepl

# Generated at 2022-06-12 14:23:02.652504
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import unittest
    import tornado.ioloop

    class IOLoopTest(tornado.ioloop.IOLoop):
        pass

    class ConfigurableTest(Configurable):

        def configurable_base(self):
            # type: () -> Type[Configurable]
            return ConfigurableTest

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return IOLoopTest

    s = ConfigurableTest.configured_class.__name__
    i = IOLoopTest.__name__
    assert s == i, f"Expected {i}, got {s}"

    class IOLoopTest1(tornado.ioloop.IOLoop):
        pass

    ConfigurableTest.configure(IOLoopTest1)

# Generated at 2022-06-12 14:23:05.877229
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_method(a,b,**kwargs):
        pass
    print(ArgReplacer(test_method,'c').get_old_value)

test_ArgReplacer_get_old_value()



# Generated at 2022-06-12 14:23:15.441931
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from pytype import module


# Generated at 2022-06-12 14:23:16.008370
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-12 14:23:25.205592
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def testFunc(inp, out=None):
        raise NotImplementedError

    arg_replacer = ArgReplacer(testFunc, 'inp')
    assert arg_replacer.arg_pos == 0
    assert arg_replacer.get_old_value(('old',), {}, None) == 'old'

    arg_replacer = ArgReplacer(testFunc, 'out')
    assert arg_replacer.arg_pos is None
    assert arg_replacer.get_old_value(('inp',), {}, None) is None
    assert arg_replacer.get_old_value(('inp',), {'out': 'old'}, None) == 'old'


# Generated at 2022-06-12 14:23:32.136082
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurableImpl

        def test_func(self):
            return "global"

    class TestConfigurableImpl(TestConfigurable):
        def test_func(self):
            return "impl"

    class TestConfigurableOtherImpl(TestConfigurable):
        def test_func(self):
            return "other_impl"

    c = TestConfigurable()
    assert c.test_func() == "impl"

    TestConfigurable.configure(TestConfigurableOtherImpl)
    assert c.test_func() == "other_impl"

    TestConfigurable.configure(None)

# Generated at 2022-06-12 14:23:40.113444
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # If errno is set
    _errno = get_errno()
    try:
        raise socket.error(_errno, os.strerror(_errno))
    except socket.error as e:
        assert errno_from_exception(e) == _errno

    # If errno is not set
    try:
        raise socket.error
    except socket.error as e:
        assert errno_from_exception(e) == None

    # If e.args[0] is not errno
    try:
        raise socket.error("whoops")
    except socket.error as e:
        assert errno_from_exception(e) == "whoops"



# Generated at 2022-06-12 14:23:40.851977
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-12 14:24:18.946213
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b=1, c=2):
        pass
    Arg_Replacer = ArgReplacer(test_func,'b')
    assert Arg_Replacer.get_old_value((1,),{}), 1
    assert Arg_Replacer.get_old_value((1,),{'c':3}), 1


# Generated at 2022-06-12 14:24:28.288709
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    args = [1,2,3]
    kwargs = {'a':4}
    def func(pos, key, *pargs, **pkwargs):
        pass
    it = ArgReplacer(func, 'key')
    assert it.arg_pos is not None and it.arg_pos == 1
    assert it.name == 'key'
    assert it.get_old_value(args,{},None) == None
    assert it.get_old_value(args,kwargs,None) == 4
    assert it.replace(5, args, kwargs) == (4, args, kwargs)
    assert it.replace(6, args, {}) == (None, args, {'key':6})
    it = ArgReplacer(func, 'pos')

# Generated at 2022-06-12 14:24:39.197576
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import json
    import logging
    import pickle
    import unittest
    import zlib
    from tornado.ioloop import IOLoop
    class Foo(Configurable):
        initialized = False
        @classmethod
        def configurable_base(cls):
            return Foo
        @classmethod
        def configurable_default(cls):
            return Foo
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.initialized = True
        def method(self):
            """Method documentation"""
            return 'Foo'
    class Bar(Foo):
        def method(self):
            return 'Bar'
    class Baz(Foo):
        def method(self):
            return 'Baz'

# Generated at 2022-06-12 14:24:47.470693
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # pylint: disable=W0212,E1003
    class A(Configurable):
        # pylint: disable=E0239,W0221
        @classmethod
        def configurable_base(self):
            return A

        @classmethod
        def configurable_default(self):
            return B

        def initialize(self, **kwargs):
            self.kwargs = kwargs

    class B(A):
        def initialize(self, **kwargs):
            pass

    class C(A):
        def initialize(self, **kwargs):
            pass

    A.configure(C)
    a = A(foo=object())
    assert isinstance(a, C)
    assert a.kwargs == {"foo": a.kwargs["foo"]}



# Generated at 2022-06-12 14:24:57.104038
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():

    def function1(a, b, c=5):
        return a+b+c

    def function2(b, c=5, **kwargs):
        return b+c

    a1 = ArgReplacer(function1, 'a')
    b1 = ArgReplacer(function1, 'b')
    c1 = ArgReplacer(function1, 'c')
    b2 = ArgReplacer(function2, 'b')
    c2 = ArgReplacer(function2, 'c')
    assert a1.replace(1, [2, 3], {'c': 5}) == (2, [1, 3], {'c': 5})
    assert b1.replace(1, [2, 3], {'c': 5}) == (3, [2, 1], {'c': 5})

# Generated at 2022-06-12 14:25:06.538914
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f1(a, b, c=3, d=4):
        pass
    def f2(a, b, *args, c=3, d=4, **kwargs):
        pass
    def f3(a, b, *args, c=3, d, **kwargs):
        pass
    def f4(a, b, *args, c=3, d=4, **kwargs):
        pass
    def f5(a, b, *args, c, d=4, **kwargs):
        pass
    def f6(a, b, *args, c=3, d, **kwargs):
        pass
    def f7(a, b, c=3, d=4, **kwargs):
        pass
    def f8(a, b, c, d=4):
        pass


# Generated at 2022-06-12 14:25:10.419382
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
        class Example(Configurable):

            def initialize(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs

        e = Example(1, 2, foo=3, bar=4)
        assert e.args == (1, 2)
        assert e.kwargs == dict(foo=3, bar=4)



# Generated at 2022-06-12 14:25:20.557914
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Foo

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Foo

        def _initialize(self, **kwargs):
            # type: (**Any) -> None
            self.kwargs = kwargs

    class Bar(Foo):
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Bar

        def _initialize(self):
            # type: () -> None
            super(Bar, self)._initialize()


# Generated at 2022-06-12 14:25:28.860031
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def initialize(self):
            pass

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return None

    class Impl(Base):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return None

    def test_impl(impl, expected_class, expected_type_class, test_args=True, test_kwargs=True):
        kwargs = {"x": 1, "y": 2}
        args = [10, 20]
        Base.configure(impl, **kwargs)

# Generated at 2022-06-12 14:25:30.797748
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Concrete(Configurable):
        def initialize(self):
            self.param = True
    assert Concrete().param
