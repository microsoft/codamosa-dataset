

# Generated at 2022-06-12 14:16:46.906096
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, *args, **kwargs):
        pass
    replacer = ArgReplacer(func, "a")
    old, args, kwargs = replacer.replace(1, (4, 5, 6), dict(b=2))
    assert old == 4
    assert args == (1, 5, 6)
    assert kwargs == dict(b=2)
    old, args, kwargs = replacer.replace(1, (), dict(a=2, b=3))
    assert old == 2
    assert args == ()
    assert kwargs == dict(a=1, b=3)
    old, args, kwargs = replacer.replace(1, (), dict(b=2))
    assert old is None
    assert args == ()

# Generated at 2022-06-12 14:16:48.197789
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        pass


# Generated at 2022-06-12 14:16:51.371058
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """Unit test for ArgReplacer.replace"""
    d = {'name': 'test'}
    a = ArgReplacer(test_ArgReplacer_replace, 'test')
    (v, args, kwargs) = a.replace('test', ('a', 'b'), d)
    assert 'test' == v
    assert ('a', 'b') == args
    assert {'name': 'test', 'test': 'test'} == kwargs


# Generated at 2022-06-12 14:16:58.223289
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class C(Configurable):
        def initialize(self, x, y=None, *args, **kwargs):
            pass

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

    C(1)
    C(1, 2)
    C(1, 2, 3, 4)
    C(1, 2, 3, 4, foo="bar")
    with pytest.raises(TypeError):
        C()
    with pytest.raises(TypeError):
        C(1, 2, foo="bar")

# Generated at 2022-06-12 14:16:59.425900
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl_class = Configurable()
    assert impl_class is not None



# Generated at 2022-06-12 14:17:07.768120
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # setUp
    import time
    import timeit
    import unittest
    import urllib.request
    import datetime
    import decimal
    import collections
    import math
    import os
    import random
    import shutil
    import string
    import weakref
    import functools
    import operator
    import logging
    import pickle
    import sys
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
   

# Generated at 2022-06-12 14:17:17.157683
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(x=0, y=1, z=2):
        pass
    f1 = ArgReplacer(f, "y").replace(5, [], {})
    assert f1[1] == [] and f1[2] == {'y': 5}
    f2 = ArgReplacer(f, "y").replace(5, [1], {})
    assert f2[1] == [1, 5] and f2[2] == {}
    f3 = ArgReplacer(f, "y").replace(6, [1], {'x' : 2, 'y' : 3})
    assert f3[1] == [1, 6] and f3[2] == {'x' : 2}
    f4 = ArgReplacer(f, "y").replace(6, [1], {'x' : 2})

# Generated at 2022-06-12 14:17:21.192866
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.x = 1
    assert(d.x == 1)
    assert(d['x'] == 1)
    try:
        d.y
        assert(False)
    except AttributeError:
        pass
    try:
        d['y']
        assert(False)
    except KeyError:
        pass

# Generated at 2022-06-12 14:17:28.531270
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # pylint: disable=too-many-branches
    from unittest import mock
    from tornado.locks import Condition

    class Example(Configurable):
        def __init__(self, *args, **kwargs):
            raise Exception("should not be called")

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return Example

        @classmethod
        def configurable_default(cls):
            return cls

    example = Example(dict(foo=1), bar="baz")
    assert isinstance(example, Example)
    assert example.args == (dict(foo=1),)
    assert example.kwargs == dict(bar="baz")

    Example.configure

# Generated at 2022-06-12 14:17:39.647437
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import tornado.options
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.signal
    import tornado.process
    import tornado.web
    import tornado.websocket

    def configure(cls, impl, **kwargs):
        # type: (Union[None, str, Type[Configurable]], Any) -> None
        """Sets the class to use when the base class is instantiated.

        Keyword arguments will be saved and added to the arguments passed
        to the constructor.  This can be used to set global defaults for
        some parameters.
        """
        base = cls.configurable_

# Generated at 2022-06-12 14:17:53.078443
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):
        def initialize(self):
            pass

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            raise Exception("should not be reached")

    A.configure(None)
    instance = A()
    return



# Generated at 2022-06-12 14:17:57.270871
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    A.configure(None)
    assert A.configured_class() == A
    a = A()
    assert isinstance(a, A)

_LOCAL_CACHE = threading.local()  # type: threading.local



# Generated at 2022-06-12 14:18:06.526291
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def handler(a, b=None, c=1):
        pass

    replacer = ArgReplacer(handler, 'b')
    a = (1, 2)
    kw = {'a': 1, 'c': 1}
    _, a, kw = replacer.replace('3', a, kw)
    assert a == (1, '3')
    assert kw == {'a': 1, 'c': 1}

    kw_arg = replacer.get_old_value(a, kw)
    assert kw_arg == '3'

    _, a, kw = replacer.replace('4', a, kw)
    assert a == (1, '4')
    assert kw == {'a': 1, 'c': 1}



# Generated at 2022-06-12 14:18:13.502364
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class C:
        def f(self, x, y, z):
            pass

    c = C()
    ar = ArgReplacer(c.f, "y")
    assert ar.get_old_value((1, 2, 3), {}) == 2
    assert ar.get_old_value((1, 2, 3), {}, default=5) == 2
    assert ar.get_old_value((1,), {"y": 4}) == 4
    assert ar.get_old_value((1,), {"z": 4}, default=5) == 5
    assert ar.replace(4, (1,), {"z": 5}) == (2, (1, 4), {"z": 5})
    assert ar.replace(4, (1, 2, 3), {}) == (2, (1, 4, 3), {})

# Generated at 2022-06-12 14:18:24.638605
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class C(Configurable):
        @classmethod
        def initialize(cls):
            pass
    # create instance of a class
    c = C()
    assert isinstance(isinstance(c, C), typing.Callable)
    # assert isinstance(c.initialize(), typing.Callable)

    # test configure
    import tornado.platform.posix

    class C(Configurable):
        @classmethod
        def initialize(cls):
            pass

    # C.configure(None)
    C.configure(tornado.platform.posix.EPollIOLoop)
    # assert isinstance(C, tornado.platform.posix.EPollIOLoop)

    # test configure_class
    import tornado.platform.select


# Generated at 2022-06-12 14:18:34.930743
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a: Optional[str] = None, b: Optional[int] = None, c: Optional[float] = None):
        pass
    arg = ArgReplacer(func, 'a')
    assert arg.replace(123, [], {'b':2, 'c':3.0}) == (None, [123], {'b':2, 'c':3.0})
    assert arg.replace(123, [0], {'b':2, 'c':3.0}) == (0, [123], {'b':2, 'c':3.0})
    assert arg.replace(123, [0,1], {'b':2, 'c':3.0}) == (0, [123,1], {'b':2, 'c':3.0})


# Generated at 2022-06-12 14:18:41.005052
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class MyClass:
        def f(self, a: str, b: str) -> str:
            return "%s, %s" % (a,b)
    c = MyClass()
    ar = ArgReplacer(MyClass.f, "b")
    assert ar.replace("b1", [], {"a": "a1", "b": "b2"}) == ("b2", [], {"a": "a1", "b": "b1"})
    assert ar.replace("b2", [], {"a": "a1"}) == (None, [], {"a": "a1", "b": "b2"})
    assert ar.replace("b2", ["a1"], {}) == (None, ["a1"], {"b": "b2"})

# Generated at 2022-06-12 14:18:48.624381
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.httputil import HTTPHeaders
    from tornado.util import Configurable
    class ConfigurableHTTPHeaders(Configurable):
        @classmethod
        def configurable_base(cls):
            return HTTPHeaders
        @classmethod
        def configurable_default(cls):
            return HTTPHeaders
    ConfigurableHTTPHeaders.configure(None)
    a = ConfigurableHTTPHeaders()
    ConfigurableHTTPHeaders.__init__(a)
    assert a == HTTPHeaders()


# Generated at 2022-06-12 14:18:50.355025
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    c = Configurable()
    assert c.initialize() == None

# Generated at 2022-06-12 14:19:01.612639
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun(a, b, c, d: str = "d") -> Tuple[str, str]:
        return a, b

    def TestArgReplacer(name: str, args: Sequence[Any], kwargs: Dict[str, Any]) -> Tuple[Any, Sequence[Any], Dict[str, Any]]:
        argr = ArgReplacer(fun, name)
        print("args before", args)
        print("kwargs before", kwargs)
        old_value, args, kwargs = argr.replace("***", args, kwargs)
        print("args after", args)
        print("kwargs after", kwargs)
        return old_value, args, kwargs


# Generated at 2022-06-12 14:19:17.120860
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # unit test for method replace of class ArgReplacer
    def test_func_signature(a, b, c=None, d=5): pass  # pylint: disable=unused-variable
    arg_replacer = ArgReplacer(test_func_signature, "c")
    old_value, args, kwargs = arg_replacer.replace(10, (1, 2), {"b": 2, "d": 10})
    assert old_value is None and args == (1, 2) and kwargs == {"b": 2, "c": 10, "d": 10}



# Generated at 2022-06-12 14:19:18.360286
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    assert True

# Generated at 2022-06-12 14:19:19.455229
# Unit test for function import_object
def test_import_object():
    import_object('functools')



# Generated at 2022-06-12 14:19:22.443489
# Unit test for function import_object
def test_import_object():
    assert import_object("os") is os
    assert import_object("tornado.escape") is escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is escape.utf8
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("types.TracebackType") is TracebackType
    assert import_object("types.TracebackType") is types.TracebackType



# Generated at 2022-06-12 14:19:31.606531
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    class Configurable1(Configurable):
        @classmethod
        def configurable_base(cls):
            return Configurable1
        @classmethod
        def configurable_default(cls):
            return Configurable1
        def initialize(self, *args, **kwargs):
            print('*args = {0}, **kwargs = {1}'.format(args, kwargs))
    p1 = Configurable1(1, 2, foo = 'foo')
    p2 = Configurable1(1, 2, foo = 'foo', bar = 'bar')
    assert p1 is p2
    class Configurable2(Configurable):
        @classmethod
        def configurable_base(cls):
            return Configurable2
        @classmethod
        def configurable_default(cls):
            return

# Generated at 2022-06-12 14:19:36.053504
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    x = ObjectDict()  # type: ObjectDict
    x.foo = 1  # type: int
    assert x.foo == 1  # type: ignore

    try:
        x.bar
    except AttributeError:
        pass



# Generated at 2022-06-12 14:19:44.929777
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a: int, b: int, c: int) -> None:
        pass

    r = ArgReplacer(f, "c")

    test_old_value = r.get_old_value((1, 2, 3), {})
    assert test_old_value == 3, "get_old_value returns 3"

    test_old_value = r.get_old_value((1, 2, 3), {}, default=10)
    assert test_old_value == 3, "get_old_value returns 3"

    test_old_value = r.get_old_value((1, 2), {})
    assert test_old_value is None, "get_old_value returns None"

    test_old_value = r.get_old_value((1, 2), {}, default=10)
    assert test

# Generated at 2022-06-12 14:19:46.366946
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass

# Generated at 2022-06-12 14:19:51.687940
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class X(Configurable):
        def configurable_base(self):
            # type: () -> Type[X]
            return X

        def configurable_default(self):
            # type: () -> Type[X]
            return X

    x1 = X()
    x2 = X(abc=123)



# Generated at 2022-06-12 14:19:55.637846
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c=None):
        pass

    assert ArgReplacer(foo, "a").arg_pos == 0
    assert ArgReplacer(foo, "b").arg_pos == 1
    assert ArgReplacer(foo, "c").arg_pos is None



# Generated at 2022-06-12 14:20:15.180622
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # doctest: +NORMALIZE_WHITESPACE
    """Tests for ObjectDict.

    ObjectDict allows attribute access to dictionary values:
    >>> d = ObjectDict(a=1, b=2)
    >>> d['c'] = 3
    >>> d.b
    2
    >>> d.c
    3
    >>> d['c']
    3
    >>> d.d
    Traceback (most recent call last):
        ...
    AttributeError: d
    """



# Generated at 2022-06-12 14:20:22.823183
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """Tests the __new__ method of Configurable.

    """
    class ConfigurableTest(Configurable):
        def initialize(self):
            pass

        @classmethod
        def configurable_base(cls):
            return ConfigurableTest

        @classmethod
        def configurable_default(cls):
            return ConfigurableTest

    # Test with default configuration
    obj = ConfigurableTest()
    assert(isinstance(obj, ConfigurableTest) == True)

    # Test with custom configuration
    class CustomConfigurableTest(ConfigurableTest):
        pass

    ConfigurableTest.configure(CustomConfigurableTest)
    obj = ConfigurableTest()
    assert(isinstance(obj, ConfigurableTest) == False)



# Generated at 2022-06-12 14:20:33.451376
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def testfunc(a,b,c):
        pass
    replacer=ArgReplacer(testfunc,"a")
    assert replacer.get_old_value((1,2,3),{},default=None)==1
    assert replacer.get_old_value((1,2,3),{"a":6},default=None)==1
    assert replacer.get_old_value((),{},default=None)==None
    assert replacer.get_old_value((1,2),{},default=None)==None
    replacer=ArgReplacer(testfunc,"b")
    assert replacer.get_old_value((1,2,3),{},default=None)==2
    assert replacer.get_old_value((1,2,3),{"b":6},default=None)==2
   

# Generated at 2022-06-12 14:20:44.326365
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

        def initialize(self):
            pass

    b = Base()
    assert b.initialize.__func__.__name__ == "initialize"
    assert b.initialize.__func__.__self__ is b
    assert b.__class__ is Base

    class MyImpl(Base):
        def initialize(self):
            pass

    Base.configure(MyImpl)
    b = Base()
    assert b.initialize.__func__.__name__ == "initialize"
    assert b.initialize.__func__.__self__ is b
    assert b.__class__ is MyImpl

    # can't configure to a non-subclass

# Generated at 2022-06-12 14:20:52.003267
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-12 14:21:03.072818
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1():
        pass


    def func2(arg1, arg2):
        pass


    def func3(arg1, arg2, kwarg=3):
        pass


    def func4(arg1, arg2, kwarg=3, *args, **kwargs):
        pass

    # no args
    try:
        ArgReplacer(func1, "arg1").get_old_value((), {}, None)
        raise Exception("should have raised ValueError")
    except ValueError:
        pass
    try:
        ArgReplacer(func1, "arg1").get_old_value((), {"arg1": 2}, None)
        raise Exception("should have raised ValueError")
    except ValueError:
        pass

    # 1 arg

# Generated at 2022-06-12 14:21:15.037392
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from functools import (
        partial,
    )

    from unittest.mock import (
        Mock,
        patch,
    )

    from tornado.testing import (
        gen_test,
        AsyncTestCase,
    )

    from nbserverproxy.configurable import (
        Configurable,
        _Configurable__impl_class,
        _Configurable__impl_kwargs,
    )

    class MockConfigurable(Configurable):
        """Mock configurable class."""

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configure(cls, impl, **kwargs):
            # type: (Union[None, str, Type[Configurable]], Any) -> None
            super().configure(impl, **kwargs)


# Generated at 2022-06-12 14:21:24.779795
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c, d=None):  # pragma: no cover
        pass
    assert ArgReplacer(foo, "b").get_old_value((1,2,3), {}) == 2
    assert ArgReplacer(foo, "b").replace(42, (1,2,3), {}) == (2, (1,42,3), {})
    assert ArgReplacer(foo, "d").get_old_value((1,2,3), {'d':4}) == 4
    assert ArgReplacer(foo, "d").replace(42, (1,2,3), {}) == (None, (1,2,3), {'d': 42})



# Generated at 2022-06-12 14:21:32.791548
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    args1 = (1, 2, 3, 4, 5)
    kwargs1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    def test_replace(m, n, *args, **kwargs):
        pass
    replacer = ArgReplacer(test_replace, 'm')
    old_value, args2, kwargs2 = replacer.replace(100, args1, kwargs1)
    assert old_value == 1
    for arg1, arg2 in zip(args1, args2):
        assert arg1 == arg2
    for kwarg in kwargs1.keys():
        assert kwargs1[kwarg] == kwargs2[kwarg]



# Generated at 2022-06-12 14:21:43.670984
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=1, **kwargs):
        pass

    repl = ArgReplacer(test_func, 'a')
    assert repl.get_old_value((2, 3,), {}) == 2
    assert repl.get_old_value((1, 2,), {'a': 3}) == 3
    assert repl.get_old_value((), {'a': 1}) == 1
    assert repl.get_old_value((), {'a': 1}, 2) == 1
    assert repl.get_old_value((), {}) == None
    assert repl.get_old_value((), {}, 2) == 2

    repl2 = ArgReplacer(test_func, 'c')
    assert repl2.get_old_value((1, 2,), {}) == 1

# Generated at 2022-06-12 14:22:05.677403
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def function_sig(a, b, c=1, d=2, e=3): pass
    ar = ArgReplacer(function_sig, 'c')
    assert ar.get_old_value((10, 20), {}) == 1
    assert ar.get_old_value((10, 20), {'c': 33}) == 33
    assert ar.get_old_value((10, 20), {'e': 10, 'z': 11}, 100) == 100
    # Now, lets replace the value of 'c' and make sure the correct args/kwargs
    # are returned
    old, args, kwargs = ar.replace(33, (10, 20), {'e': 10, 'z': 11})
    assert old == 1
    assert args == (10, 20)

# Generated at 2022-06-12 14:22:15.625703
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from .ioloop import TestIOLoop, IOLoop

    class ConfigurableClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableClass

        @classmethod
        def configurable_default(cls):
            return TestIOLoop

        def initialize(self, *args, **kwargs):
            pass

    # should default to TestIOLoop
    assert isinstance(ConfigurableClass(), TestIOLoop)

    # should be reconfigurable to IOLoop
    saved_class = ConfigurableClass._save_configuration()

    try:
        ConfigurableClass.configure(IOLoop)
        assert isinstance(ConfigurableClass(), IOLoop)
    finally:
        ConfigurableClass._restore_configuration(saved_class)

    # should be usable as a decor

# Generated at 2022-06-12 14:22:26.742778
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=True):
        pass

    p = ArgReplacer(f, "c")
    assert p.arg_pos == 2
    assert p.get_old_value((), {}) is None
    assert p.get_old_value((), {}, 42) == 42
    assert p.get_old_value((), {"c": 42}) == 42
    assert p.get_old_value(("a", "b", "foo"), {}) == "foo"
    assert p.get_old_value(("a", "b", 42), {}) == 42
    assert p.get_old_value(("a", "b", None), {"c": 42}) is None

    assert p.replace(123, (), {}) == (None, [], {"c": 123})

# Generated at 2022-06-12 14:22:35.527807
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(bar, baz):
           pass

    new_value, args, kwargs = ArgReplacer(foo, 'bar').replace('new bar', ('old bar',), {'baz': 'boo!'})
    assert new_value == 'old bar' and args == ('new bar',) and kwargs == {'baz': 'boo!'}

    new_value, args, kwargs = ArgReplacer(foo, 'bar').replace('new bar', (), {'bar': 'old bar', 'baz': 'boo!'})
    assert new_value == 'old bar' and args == () and kwargs == {'baz': 'boo!', 'bar': 'new bar'}


# Generated at 2022-06-12 14:22:45.916282
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    def func(a, b, c, d, e=1, f=2, g=3):
        pass

    arg_replacer = ArgReplacer(func, "e")
    assert arg_replacer.get_old_value([1, 2, 3, 4], {}) is None
    assert arg_replacer.get_old_value([1, 2, 3, 4], {}, default="") == ""
    assert arg_replacer.get_old_value([1, 2, 3, 4], {}, default=None) is None
    assert arg_replacer.get_old_value([1, 2, 3, 4], {"e": 7}) == 7
    assert arg_replacer.get_old_value([1, 2, 3, 4], {"e": 7}, default="") == 7
    assert arg_replacer.get_

# Generated at 2022-06-12 14:22:56.129319
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import pytest

    class Foo(Configurable):
        def configurable_base(self):
            # type: () -> Configurable
            return Foo

        def configurable_default(self):
            # type: () -> Configurable
            return Foo

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert isinstance(Foo(), Foo)
    assert type(Foo()) is Foo

    Foo.configure(Bar)
    assert type(Foo()) is Bar

    Foo.configure(Baz)
    assert type(Foo()) is Baz

    with pytest.raises(ValueError):
        Foo.configure(int)



# Generated at 2022-06-12 14:23:04.036180
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def replace(name, func, *args, **kwargs):
        return ArgReplacer(func, name).replace(*args, **kwargs)

    def add(a, b, c=1):
        pass

    assert replace("b", add, 2, 3, 4) == (3, (2, 2, 4), {})
    assert replace("b", add, 2, b=3, c=4) == (3, (2,), {"b": 2, "c": 4})
    assert replace("c", add, 2, b=3, c=4) == (4, (2,), {"b": 3, "c": 2})
    assert replace("d", add, 2, b=3) == (None, (2,), {"b": 3, "d": 2})


# Generated at 2022-06-12 14:23:14.412411
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, x=1, y=2, z=3):
        pass
    arg_replacer = ArgReplacer(func, 'x')
    old_value, args, kwargs = arg_replacer.replace(4, (1, 2, 3), {})
    assert(old_value == 1)
    assert(args == (1, 2, 3))
    assert(kwargs == {'x': 4})
    old_value, args, kwargs = arg_replacer.replace(4, (), {'y': 5, 'z': 6})
    assert(old_value == 1)
    assert(args == ())
    assert(kwargs == {'y': 5, 'z': 6, 'x': 4})


_UNSET = object()  # Sentinel object



# Generated at 2022-06-12 14:23:20.793785
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    """Test for method initialize of class Configurable"""

    def _initialize(self):
        _initialize.called = True
    Configurable._initialize = _initialize

    class TestClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestClass

        @classmethod
        def configurable_default(cls):
            return TestClass

    _initialize.called = False
    test = TestClass()
    assert _initialize.called



# Generated at 2022-06-12 14:23:29.442392
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from unittest import mock
    from .testing import AsyncHTTPTestCase

    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return impl1

        def initialize(self, x: int = 0, y: int = 0) -> None:
            self.x = x
            self.y = y

    class impl1:
        def initialize(self, x: int = 0, y: int = 0) -> None:
            self.x = x + 1
            self.y = y + 1

    class impl2:
        def initialize(self, x: int = 0, y: int = 0) -> None:
            self.x = x + 2
            self.y = y + 2

    impl1

# Generated at 2022-06-12 14:23:58.975338
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import pytest

# Generated at 2022-06-12 14:24:08.491482
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(bar, baz):
        pass
    replacer1 = ArgReplacer(foo, 'bar')
    assert replacer1.replace('new_bar', ('old_bar',), dict())[0] == 'old_bar'
    assert replacer1.replace('new_bar', (), dict(bar='old_bar'))[0] == 'old_bar'
    assert replacer1.replace('new_bar', (), {})[0] == None

    #test if the input args and kwargs changed
    args = ('old_bar',)
    kwargs = dict()
    replacer1.replace('new_bar', args, kwargs)
    assert args == ('new_bar',)
    assert kwargs == dict()

    replacer2 = ArgReplacer(foo, 'baz')
    assert replacer

# Generated at 2022-06-12 14:24:10.001177
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.iostream import IOStream
    Stream = Configurable('tornado.iostream.IOStream', IOStream)



# Generated at 2022-06-12 14:24:13.754982
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def my_function(arg1, arg2, arg3, arg4):
        return (arg1, arg2, arg3, arg4)

    arg_replacer = ArgReplacer(my_function, "arg1")
    args = ("old_value", "arg2", "arg3", "arg4")
    kwargs = {"arg1": "old_value"}
    old_value, new_args, new_kwargs = arg_replacer.replace(
        "new_value", args, kwargs)
    assert old_value == "old_value"
    assert new_args == ("new_value", "arg2", "arg3", "arg4")
    assert new_kwargs == {"arg1": "new_value"}



# Generated at 2022-06-12 14:24:19.971014
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(this):
            return A
        def configurable_default():
            return A
        def initialize(this, d=3):
            this.d = d
    a = A(2)
    assert(a.d == 2)
    A.configure(None,d=4)
    a = A()
    assert(a.d == 4)

# Generated at 2022-06-12 14:24:28.678028
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return impla

        def _initialize(self):
            return None

    class B(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return impla

        def _initialize(self):
            return None

    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return B

        @classmethod
        def configurable_default(cls):
            return impla

        def _initialize(self):
            return None


# Generated at 2022-06-12 14:24:36.370091
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            return

    a = A()
    assert(isinstance(a, A))
    assert not hasattr(a, 'init')


# Generated at 2022-06-12 14:24:39.114582
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, 'Random OS Error')
    except Exception as e:
        assert errno_from_exception(e) == 5



# Generated at 2022-06-12 14:24:46.002256
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.ioloop import IOLoop

    class ConfigurableTest(Configurable):
        def configurable_base(self):
            return ConfigurableTest
        def configurable_default(self):
            return object
        def initialize(self, write_to: int) -> None:
            self.write_to = write_to

    ConfigurableTest.configure(None, write_to=42)
    assert ConfigurableTest().write_to == 42
    assert isinstance(ConfigurableTest(), object)
    assert not isinstance(ConfigurableTest(), ConfigurableTest)

    class Subclass(ConfigurableTest):
        pass
    Subclass.configure(None, write_to=123)
    assert Subclass().write_to == 123

    # Configuration is inherited when subclass is not configured.
    #
    # (This behavior was chosen somewhat arbitrarily and

# Generated at 2022-06-12 14:24:48.252605
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    class test:
        var1 = 1
        var2 = 0

    t = test()
    a = ArgReplacer(t.__init__, 'var1')
    _, var1 = a.get_old_value((), t.__dict__)
    assert var1 == 1



# Generated at 2022-06-12 14:25:18.504249
# Unit test for function import_object
def test_import_object():
    import_object('inspect.getfullargspec')


# Generated at 2022-06-12 14:25:22.386103
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=4, d=5, *args, **kwargs):
        return None
    
    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.get_old_value([1, 2, 3], {}, None) == 2

# Generated at 2022-06-12 14:25:22.933086
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    ...

# Generated at 2022-06-12 14:25:25.809384
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            print('initialize')
            pass
    a=A()
    assert a is not None

# Generated at 2022-06-12 14:25:32.306246
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return D

    class D(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return D

    D.configure("t.io.D")
    # call __new__ of class D, in this case the __new__ method of class C is called
    C("c")



# Generated at 2022-06-12 14:25:38.278336
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    argreplacer = ArgReplacer(func, "b")
    old_value, args, kargs = argreplacer.replace("new_b", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "new_b", 3)
    assert kargs == {}
    assert argreplacer.get_old_value(args, kargs) == 2

    old_value, args, kargs = argreplacer.replace("new_b", (1, 2), {"c": 3})
    assert old_value == 2
    assert args == (1, "new_b")
    assert kargs == {"c": 3}
    assert argreplacer.get_old_value(args, kargs) == 2

    old_value, args,

# Generated at 2022-06-12 14:25:47.839501
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    func = lambda a, b: (a, b)

    replacer = ArgReplacer(func, "a")
    old_value, args, kwargs = replacer.replace(5, (1, 2), {})
    assert old_value == 1
    assert args == (5, 2)
    assert kwargs == {}

    replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = replacer.replace(5, (1, 2), {})
    assert old_value == 2
    assert args == (1, 2)
    assert kwargs == {"b": 5}

    replacer = ArgReplacer(func, "a")
    old_value, args, kwargs = replacer.replace(5, (1,), {"b": 2})
    assert old_value == 1

# Generated at 2022-06-12 14:25:54.371488
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # Tests for method __getattr__ of class ObjectDict
    class mydict(ObjectDict):
        pass
    a = mydict()
    a.info = "Czech"
    assert a["info"] == "Czech"
    assert a.info == "Czech"
    assert str(a)
    assert repr(a)
    try:
        a.quam
        raise RuntimeError
    except AttributeError:
        pass


# Generated at 2022-06-12 14:26:04.339743
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass

    def func2(a, b, c=None, *args, **kwargs):
        pass

    replacer = ArgReplacer(func, 'b')
    old_value = replacer.get_old_value((1, 2, 3), {})
    assert old_value == 2

    replacer = ArgReplacer(func, 'c')
    old_value = replacer.get_old_value((1, 2, 3), {})
    assert old_value == 3

    replacer = ArgReplacer(func, 'c')
    old_value = replacer.get_old_value((1, 2), {'c': 3})
    assert old_value == 3

    replacer = ArgReplacer(func, 'c')

# Generated at 2022-06-12 14:26:13.522987
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest.mock as mock

    class ConfigurableClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableClass

        @classmethod
        def configurable_default(cls):
            return ConfigurableClass

    def initialize(self, *args: Any, **kwargs: Any) -> None:
        self.args = args
        self.kwargs = kwargs
        initialize.was_called = True

    ConfigurableClass.initialize = initialize
    initialize.was_called = False

    # Test none-configured
    obj1 = ConfigurableClass(1, 2, x=3, y=4)
    assert initialize.was_called
    assert obj1.args == (1, 2)
    assert obj1.kwargs == {"x": 3, "y": 4}