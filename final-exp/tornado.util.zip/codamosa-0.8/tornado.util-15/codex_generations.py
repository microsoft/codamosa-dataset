

# Generated at 2022-06-12 14:16:40.503415
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return C

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return D

        def initialize(self, a=None, b=None):
            self.initialize_called = True
            self.args = (a, b)

    class D(C):
        pass

    # Test that initialize is called
    instance = C(1, 2)
    assert instance.initialize_called
    assert instance.args == (1, 2)

    # Test that calling a subclass directly calls initialize
    instance = D(3, 4)
    assert instance.initialize_called

# Generated at 2022-06-12 14:16:46.286599
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def __init__(self, a: int, b: Any = None, **kwargs: Any) -> None:
            pass
    TestConfigurable.initialize(1)
    TestConfigurable.initialize(1, b=2)
    TestConfigurable.initialize(1, x=3)
    TestConfigurable.initialize(1, b=2, x=3)
    TestConfigurable.initialize(a=2, x=3)


# Generated at 2022-06-12 14:16:52.153629
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Child(Configurable):
        """TODO: Child needs a docstring"""

        def initialize(self) -> None:
            pass

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Child

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Child

    Child.configure(None)
    assert Child._initialize() is None
    assert Child()._initialize() is None



# Generated at 2022-06-12 14:16:58.708386
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import types
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('types') is types
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        print("import_object didn't fail as expected")


_BYTES_TYPE = bytes  # type: Type[Any]
_UNICODE_TYPE = str  # type: Type[Any]



# Generated at 2022-06-12 14:17:07.172592
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from unittest import mock

    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return D

        def _initialize(self, foo, bar):
            pass

        def _initialize_from_config(self, foo, bar):
            pass

    class D(C):
        def _initialize(self, foo, bar, baz):
            pass

        def _initialize_from_config(self, foo, bar, baz):
            pass

    with mock.patch("tornado.util.import_object") as mock_import:
        C.configure("fun.module")
        mock_import.assert_called_with("fun.module")
        mock_import.return_value = None

# Generated at 2022-06-12 14:17:16.776733
# Unit test for function import_object
def test_import_object():
    try:
        import tornado.test.util_test  # noqa: F401
    except ImportError:
        raise unittest.SkipTest("tornado.test.util_test not available")
    try:
        import_object("tornado.test.util_test")
    except ImportError:
        raise unittest.SkipTest("tornado.test.util_test not available")
    from tornado.test.util_test import UnimportableClass, importable_func
    assert import_object("tornado.test.util_test.UnimportableClass") is UnimportableClass
    assert import_object("tornado.test.util_test.importable_func") is importable_func
    assert import_object("tornado.test.util_test.UNEXISTENT") is None

# Generated at 2022-06-12 14:17:25.131841
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class E(Exception):
        pass

    try:
        raise E()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise E("message")
    except Exception as e:
        assert errno_from_exception(e) == "message"

    try:
        raise E("message", "foo")
    except Exception as e:
        assert errno_from_exception(e) == ("message", "foo")

    try:
        raise E("message", "foo", "bar")
    except Exception as e:
        assert errno_from_exception(e) == ("message", "foo", "bar")

    try:
        raise E("message", "foo", "bar", "baz")
    except Exception as e:
        assert errno_from_

# Generated at 2022-06-12 14:17:30.106289
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestClass(Configurable):
        def configurable_base(self):
            return TestClass
        def configurable_default(self):
            return TestClass
    TestClass.configure('abc')
    TestClass.configured_class()
    assert isinstance(TestClass(), TestClass)
    assert isinstance(TestClass(123), TestClass)
    assert isinstance(TestClass(123, xxx=5), TestClass)

# Generated at 2022-06-12 14:17:41.556873
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_fun(a, b, *args, c=None, **kwargs):
        pass
    # return None if the parameter does not exist
    assert ArgReplacer(test_fun, 'd').get_old_value([1,2,3], dict(), 'default') == 'default'
    assert ArgReplacer(test_fun, 'd').get_old_value([1,2,3], dict()) == None
    # return the value of the parameter if it exists
    args = [1,2,3]
    kwargs = dict()
    kwargs['c'] = 'c'
    assert ArgReplacer(test_fun, 'c').get_old_value(args, kwargs, 'default') == 'c'

# Generated at 2022-06-12 14:17:42.156324
# Unit test for function import_object
def test_import_object(): pass



# Generated at 2022-06-12 14:18:04.939882
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        pass

    class Impl1(Base):
        pass

    class Impl2(Base):
        pass

    Base.configure(Impl1)
    c = Base()
    assert isinstance(c, Impl1)

    Base.configure(Impl2)
    c = Base()
    assert isinstance(c, Impl2)

    # Make sure configure doesn't mess up init args
    c1 = Base(foo=1)
    c2 = Base(foo=2)
    assert c1.foo == 1
    assert c2.foo == 2

    # configure shouldn't break instance creation
    # after configure is called
    c1 = Base(foo=1)
    Base.configure(Impl1)
    c2 = Base(foo=2)
    assert c1.foo == 1
    assert c

# Generated at 2022-06-12 14:18:07.208558
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Test(Configurable):

        @classmethod
        def configurable_base(cls):
            return Test

        @classmethod
        def configurable_default(cls):
            return Test

        def initialize(self, *args, **kwargs):
            pass

    test = Test()
    assert isinstance(test, Test)



# Generated at 2022-06-12 14:18:11.406039
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4, *args, **kwargs):
        pass

    arg = ArgReplacer(func, 'c')
    args = (1, 2, 3)
    kwargs = {'d': 4}
    old_value = arg.get_old_value(args, kwargs)
    assert old_value==3
    new_value = 100
    args, kwargs = arg.replace(new_value, args, kwargs)
    old_value = arg.get_old_value(args, kwargs)
    assert old_value==100
    assert (1, 2, 100, 4) == args
    assert {'d': 4} == kwargs



# Generated at 2022-06-12 14:18:23.247033
# Unit test for function raise_exc_info
def test_raise_exc_info():
    raise_exc_info(1,2,3)
    raise_exc_info(1,2)
    raise_exc_info(1,None,3)
    raise_exc_info(1,None)
    raise_exc_info(None,2,3)
    raise_exc_info(None,2)
    raise_exc_info(None,None,3)
    raise_exc_info(None,None)


# Generated at 2022-06-12 14:18:26.122211
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    assert Configurable.__new__.__code__.co_argcount == 2


# Generated at 2022-06-12 14:18:29.633189
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(3, "No such process")
    except Exception as e:
        errno = errno_from_exception(e)
        assert(errno == 3)



# Generated at 2022-06-12 14:18:36.087173
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    test_dict = {
        "key1" : True,
        "key2" : None,
        "key3" : [1, 2, 3],
        "key4" : "value"
    }
    obj_dict = ObjectDict(test_dict)

    assert obj_dict.key1 == test_dict["key1"]
    assert not obj_dict.key2
    assert obj_dict.key3 == test_dict["key3"]
    assert obj_dict.key4 == test_dict["key4"]


# Generated at 2022-06-12 14:18:39.748390
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    _Configurable___new__()
    _Configurable_configured_class()
    _Configurable_configure()
    _Configurable_save_configuration()
    _Configurable_restore_configuration()
    _Configurable_initialize()
    raise ValueError("Test failed")

# Generated at 2022-06-12 14:18:44.231684
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(x, y):
        return x+y
    def g(x, y=2):
        return x+y
    def h(x=1, y=2):
        return x+y

    assert ArgReplacer(f, 'x').get_old_value((1,2), {}) == 1
    assert ArgReplacer(f, 'y').get_old_value((1,2), {}) == 2
    assert ArgReplacer(f, 'x').get_old_value((1,), {'y':2}) == 1
    assert ArgReplacer(f, 'y').get_old_value((1,), {'y':2}) == 2
    assert ArgReplacer(g, 'x').get_old_value((1,), {}) == 1
    assert ArgReplacer(g, 'y').get_

# Generated at 2022-06-12 14:18:55.979639
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class ConfigurableSubclass(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Configurable
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return ConfigurableSubclass
        def initialize(self):
            # type: () -> None
            pass

    ConfigurableSubclass.configure(None)
    assert(isinstance(ConfigurableSubclass(), ConfigurableSubclass))
    # Check that initialize was called.
    # (It's possible that someone could implement initialize without calling
    # super().initialize, so we have to do something here).
    x = ConfigurableSubclass()
    del x

    # Manually mangle the private name to see whether it

# Generated at 2022-06-12 14:19:11.302472
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    a = ArgReplacer(func, "a")
    assert a.replace(1, (2, 3, 4), {}) == (2, (1, 3, 4), {})
    assert a.replace(1, (2,), {"b": 3, "c": 4}) == (2, (2,), {"b": 3, "c": 4})
    assert a.replace(1, (), {"c": 4, "a": 2, "b": 3}) == (2, (), {"c": 4, "a": 1, "b": 3})



# Generated at 2022-06-12 14:19:22.155125
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b=10, *args, **kwargs):
        pass

    ar = ArgReplacer(func, "b")
    assert ar.get_old_value((1,), {}) == 10
    assert ar.get_old_value((1,), {"b": 20}) == 20
    assert ar.get_old_value((1,), {"b": 20, "args": (1,)}) == 20
    assert ar.get_old_value((1, 2), {}) == 2
    assert ar.get_old_value((), {"b": 20}) == 20
    assert ar.get_old_value((1,), {"b": 20, "args": (3,)}) == 20
    assert ar.get_old_value((1,), {"b": 20, "c": 3, "args": ()}) == 20

   

# Generated at 2022-06-12 14:19:22.880332
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass

# Generated at 2022-06-12 14:19:31.867429
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None

    class TestConfigurable(Configurable):

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        def __init__(self, value):
            # type: (Any) -> None
            self.value = value

    # Test default implementation
    assert isinstance(TestConfigurable(1), TestConfigurable)

    # Test wrapping class
    class WrappedTest(TestConfigurable):
        pass

    assert isinstance(WrappedTest(1), WrappedTest)

    # Test configured class
    class SubClass(TestConfigurable):
        pass


# Generated at 2022-06-12 14:19:36.310565
# Unit test for function raise_exc_info
def test_raise_exc_info(): # type () -> typing.NoReturn
    # type () -> typing.NoReturn
    try:
        raise NameError
    except NameError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)
    raise Exception("did not re-raise")



# Generated at 2022-06-12 14:19:45.079815
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_ArgReplacer_replace(a, b, c=1, **kwargs):
        pass
    arg0 = ArgReplacer(test_ArgReplacer_replace, "a")
    print(arg0.replace(1, (2,), {}))
    arg1 = ArgReplacer(test_ArgReplacer_replace, "b")
    print(arg1.replace(2, (1,), {}))
    arg2 = ArgReplacer(test_ArgReplacer_replace, "c")
    print(arg2.replace(3, (1,), {}))
    # def print_kwargs(**kwargs):
    #     print(kwargs)
    # print_kwargs(**{'a': 1, 'b': 2, 'c': 3, 'd': 4})


# Generated at 2022-06-12 14:19:56.672103
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    '''
    This unit test is for method initialize of class Configurable.
    '''

    class ConfigurableClass(Configurable):
        '''
        configurable base class
        '''
        def __init__(self):
            self.a = 0

        def configurable_base(self):
            return ConfigurableClass

        def configurable_default(self):
            return ConfigurableClass

    def setUpModule():
        '''
        set up module
        '''
        global configurable_class
        configurable_class = ConfigurableClass()

    def tearDown():
        '''
        tear down
        '''
        global configurable_class
        configurable_class = None

    def test_initialize():
        '''
        test initialize()
        '''
        assert configurable_class.a == 0

#

# Generated at 2022-06-12 14:20:06.634359
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(x, y, z):
        pass

    a = ArgReplacer(foo, "y")
    assert a.get_old_value((1, 2, 3), {}) == 2
    assert a.get_old_value((1,), {"y": 2}) == 2
    assert a.get_old_value((1,), {"z": 3}, 4) == 4
    assert a.get_old_value((1,), {}, 4) == 4

    assert a.replace(5, (1, 2, 3), {}) == (2, (1, 5, 3), {})
    assert a.replace(5, (1,), {"y": 2}) == (2, (1, 5), {})
    assert a.replace(5, (1,), {}, 4) == (None, (1, 5), {})

# Generated at 2022-06-12 14:20:14.118103
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConfigurableImpl(Configurable):
        def initialize(self, x, y):
            self.x = x
            self.y = y

        @classmethod
        def configurable_base(cls):
            return ConfigurableImpl

        @classmethod
        def configurable_default(cls):
            return ConfigurableImpl

    ConfigurableImpl.configure(None)
    impl = ConfigurableImpl(x=42, y="hello")
    assert impl.x == 42
    assert impl.y == "hello"



# Generated at 2022-06-12 14:20:22.892079
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    global Configurable
    # Execution of class Configurable.__new__ method
    if cls is base:
        impl = cls.configured_class()
        if base.__impl_kwargs:
            init_kwargs.update(base.__impl_kwargs)
    else:
        impl = cls
    init_kwargs.update(kwargs)
    if impl.configurable_base() is not base:
        # The impl class is itself configurable, so recurse.
        return impl(*args, **init_kwargs)
    instance = super(Configurable, cls).__new__(impl)
    # initialize vs __init__ chosen for compatibility with AsyncHTTPClient
    # singleton magic.  If we get rid of that we can switch to __init__
    # here too.

# Generated at 2022-06-12 14:20:35.718658
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(n: str) -> str:
        return n
    args = ['a']
    kwargs = {}
    print(args, kwargs)
    argreplacer = ArgReplacer(f, 'n')
    print(argreplacer.get_old_value(args, kwargs))
    new_val = 'b'
    print(argreplacer.replace(new_val, args, kwargs))
test_ArgReplacer_replace()


# Generated at 2022-06-12 14:20:46.836091
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    #
    # Just a sanity check; the specific errors are tested in
    # `test.core_test.ExceptionTestCase.test_exc_info`
    try:
        raise Exception("hello")
    except:
        raise_exc_info(sys.exc_info())


# Fake byte literal support:  In python 2.6+, you can say b"foo" to
# get a byte literal (str in 2.x, bytes in 3.x).  There's no way to do
# that in a way that supports 2.5, though, so we need a function
# wrapper to convert our string literals.  b() should only be applied
# to literal latin1 strings.  Once we drop support for 2.5, we can
# remove this function and just use byte literals.

# Generated at 2022-06-12 14:20:56.940003
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        def __init__(self):
            print('Foo')

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return Foo

        def initialize(self, *args, **kwargs):
            pass

    assert isinstance(Foo(), Foo)

    type_Foo = type('Foo', (Foo,), {})

    class Bar(type_Foo):
        def __init__(self):
            print('Bar')

    assert isinstance(Bar(), Bar)
    assert not isinstance(Foo(), Bar)
    assert not isinstance(Bar(), Foo)

    assert isinstance(Foo.configure(Bar), Bar)



# Generated at 2022-06-12 14:21:07.518031
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(a, b=None, *args, **kwargs):
        # type: (int, Optional[int], Any, Any) -> None
        pass

    argreplacer = ArgReplacer(f, 'a')
    old_value, args, kwargs = argreplacer.replace(10, (5,), {})
    assert old_value == 5
    assert args[0] == 10

    argreplacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = argreplacer.replace(10, (5,), {})
    assert old_value is None
    assert kwargs['b'] == 10

# Generated at 2022-06-12 14:21:08.163416
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass

# Generated at 2022-06-12 14:21:19.701333
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest

    class Test(Configurable):
        @classmethod
        def configurable_base(cls):
            return Test

        @classmethod
        def configurable_default(cls):
            return Test

        def _initialize(self):
            self.x = 1

        def print(self):
            print(self.x)


    # Test basic functionality
    t = Test()
    t.print()
    Test.configure(None, x=2)
    t = Test()
    t.print()


    # Test from_dict
    class Test2(Test):
        pass


    class Test3(Test2):
        @classmethod
        def configurable_base(cls):
            return Test3


        @classmethod
        def configurable_default(cls):
            return Test

# Generated at 2022-06-12 14:21:29.894087
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from typing import List
    from collections import defaultdict
    from tornado.queues import Queue
    import random
    import string
    import sys

    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Bar

        def initialize(self, alpha, bravo, **other_kwargs):
            self.alpha = alpha
            self.bravo = bravo
            self.other_kwargs = other_kwargs

    class Bar(Foo):
        def __init__(self, alpha, bravo, **other_kwargs):
            self.alpha = alpha
            self.bravo = bravo
            self.other_kwargs = other_kwargs


# Generated at 2022-06-12 14:21:35.491784
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(7, 'argument')
    except IOError as e:
        assert e.errno == 7
        assert errno_from_exception(e) == 7

    try:
        raise TypeError
    except TypeError as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 'argument')
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-12 14:21:39.807424
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, x: int) -> None:
            self.x = x

    a = A(x=1)
    assert a.x == 1
    A.configure(None)
    a = A(x=2)
    assert a.x == 2


def_type = (
    TypeVar("def_type", bound=Type[Any])
)  # type: TypeVar[Type['def_type'], Any]



# Generated at 2022-06-12 14:21:48.452109
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return FooImpl

        def initialize(self):
            pass

    class FooImpl(Foo):
        pass

    class Bar(Foo):
        _instance_count = 0

        def initialize(self):
            Bar._instance_count += 1

    class BarImpl(Bar):
        _instance_count = 0

        def initialize(self):
            BarImpl._instance_count += 1

    @classmethod
    def reset():
        Bar.configure(None)
        Bar._instance_count = 0
        BarImpl._instance_count = 0

    @typing.overload
    def test():
        ...


# Generated at 2022-06-12 14:22:09.731758
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    # Mocks.
    class ConfigurableMock(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableMock

        @classmethod
        def configurable_default(cls):
            return ConfigurableMock

        def _initialize(self, *args, **kwargs):
            pass

    @functools.wraps(Configurable.configure)
    def configure(impl, **kwargs):
        raise NotImplementedError("Class ConfigurableMock has no configure method.")

    ConfigurableMock.configure = configure

    class ConfigurableMockImpl(ConfigurableMock):
        pass

    class ConfigurableMockImplA(ConfigurableMock):
        pass

    class ConfigurableMockImplB(ConfigurableMock):
        pass

   

# Generated at 2022-06-12 14:22:16.248302
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f1(a, b=1, c=2):
        pass
    ar = ArgReplacer(f1, "b")
    assert ar.get_old_value((2,), {}, None) == 1
    assert ar.get_old_value((2, 3), {}) == 3
    assert ar.get_old_value((2,), {"b": 3}, None) == 3
    assert ar.get_old_value((), {"b": 3}, None) == 3



# Generated at 2022-06-12 14:22:27.342270
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    import logging

    class TestConfigurable(Configurable):
        def configurable_base(cls):
            # type: () -> TestConfigurable
            return TestConfigurable

        def configurable_default(cls):
            # type: () -> TestConfigurable
            return cls

        def _initialize(
            self, logger: Optional[logging.Logger] = None, name: Optional[str] = None
        ) -> None:
            self.logger = logger
            self.name = name

        def __init__(self):
            raise Exception("TestConfigurable.__init__ should not be called")

    class TestSubclass(TestConfigurable):
        def configurable_base(cls):
            # type: () -> TestConfigurable
            return TestConfigurable


# Generated at 2022-06-12 14:22:28.520169
# Unit test for function import_object
def test_import_object():
    import tornado
    assert import_object('tornado.escape') is tornado.escape
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape



# Generated at 2022-06-12 14:22:33.393322
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class TheBase(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TheBase
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TheImpl
    class TheImpl(TheBase):
        def initialize(self):
            # type: () -> None
            self.x = 'value'
    assert TheBase().x == 'value'
    TheBase.__impl_class = None
    TheBase.configure(None)
    assert TheBase().x == 'value'
    class TheDummyImpl(TheBase):
        def initialize(self):
            # type: () -> None
            self.x = 'value2'

# Generated at 2022-06-12 14:22:44.981165
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a):
        pass

    ar = ArgReplacer(func, 'a')
    
    assert ar.get_old_value(('a',), {}) == 'a'
    assert ar.get_old_value(('a',), {'a': 'b'}) == 'a'
    assert ar.get_old_value(('a',), {'a': 'b'}, 'c') == 'a'
    assert ar.get_old_value(('a',), {'c': 'b'}, 'c') == 'c'

    assert ar.replace('b', ('a',), {}) == ('a', ('b',), {})
    assert ar.replace('b', ('a',), {'a': 'a'}) == ('a', ('b',), {})

# Generated at 2022-06-12 14:22:48.596642
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class TestException(Exception):
        pass

    class BadException(Exception):
        pass

    class TestErrnoException(Exception):
        def __init__(self, errno: int, *args: Any) -> None:
            self.errno = errno
            Exception.__init__(self, *args)

    assert errno_from_exception(TestException()) is None
    assert errno_from_exception(BadException(123)) == 123
    assert errno_from_exception(TestErrnoException(126)) == 126
    try:
        raise Exception()
    except Exception:
        assert errno_from_exception(sys.exc_info()[1]) is None



# Generated at 2022-06-12 14:22:58.818918
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test_func(a, b=None):
        pass
    ar = ArgReplacer(test_func, "a")
    assert ar.name == "a"
    assert ar.arg_pos == 0
    ar = ArgReplacer(test_func, "b")
    assert ar.name == "b"
    assert ar.arg_pos is None
    assert ar.get_old_value((1, 2, 3), {}) is None
    assert ar.get_old_value((1, 2, 3), {"b": 4}) == 4
    assert ar.get_old_value((), {"b": 4}) == 4
    assert ar.get_old_value((), {"b": 4}, 5) == 4
    assert ar.get_old_value((), {}, 5) == 5
    old_value, args, kwargs

# Generated at 2022-06-12 14:23:07.970211
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(_a, _b, c, d, *args, **kwargs):
        pass
    r = ArgReplacer(func, "d")
    assert r.get_old_value((1, 2, 3, 4), {}) == 4
    assert r.get_old_value((1, 2, 3), {"d": 4}) is None
    assert r.get_old_value((1, 2, 3), {"d": 4}, 5) is None
    assert r.replace(5, (1, 2, 3, 4), {}) == (
        4,
        (1, 2, 3, 5),
        {},
    )
    assert r.replace(5, (1, 2, 3), {"d": 4}) == (
        4,
        (1, 2, 3),
        {"d": 5},
    )

# Generated at 2022-06-12 14:23:16.567394
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(arg_replacer_obj, a: int, b: int = 0) -> None:
        print(a, b)

    old_arg = ArgReplacer(func, 'a')
    print(*old_arg.replace(10, (20,), {}))
    print(*old_arg.replace(10, (1, 2), {}))
    print(*old_arg.replace(10, (1,), {'b': 2}))
    print(*old_arg.replace(10, (), {'a': 2, 'b': 3}))
    print(*old_arg.replace(10, (), {}))
    # The following is just to test the type of the output.
    old_value, args, kwargs = old_arg.replace(10, (), {})
    assert isinstance(old_value, type(None))

# Generated at 2022-06-12 14:23:41.973148
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class A(object):
        def f1(self, a1, a2, a3):
            pass
        def f2(self, a1, a2=None, a3=None):
            pass
        def f3(self, a1=None, a3=None):
            pass
    def test(a, b):
        assert a == b
    def test_tuple(a, b):
        assert a[0] == b[0] and a[1] == b[1] and a[2] == b[2]
    arg_replacer = ArgReplacer(A.f1, 'a2')
    test(arg_replacer.replace(5, (1, 2, 3), {}), (5, 1, 3))

# Generated at 2022-06-12 14:23:51.358176
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b=2):
            self.a = a
            self.b = b
    A.configure(None)
    a = A(1)
    assert a.a == 1
    assert a.b == 2
    A.configure(None, b=3)
    a = A(1)
    assert a.a == 1
    assert a.b == 3
    A.configure(A, b=4)
    a = A(1)
    assert a.a == 1
    assert a.b == 4


# Generated at 2022-06-12 14:24:00.932552
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    fargs = (1, 2, 3)
    fkwargs = {'c': 3}
    rp = ArgReplacer(f, 'c')
    new_value = 9
    old_value = rp.replace(new_value, fargs, fkwargs)[0]
    assert old_value == 3
    assert fargs == (1, 2, new_value)
    assert fkwargs == {'c': new_value}

    fkwargs = {'d': 3}
    rp = ArgReplacer(f, 'd')
    new_value = 9
    old_value = rp.replace(new_value, fargs, fkwargs)[0]
    assert old_value is None

# Generated at 2022-06-12 14:24:04.236526
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: (Any) -> Any
    d = ObjectDict()
    d.x = "test x"
    assert d.x == "test x"
    assert d["x"] == "test x"


# Generated at 2022-06-12 14:24:12.549937
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Subclass(Configurable):
        pass

    class SubSubClass(Subclass):
        pass

    impl_class = SubSubClass.configured_class()
    assert impl_class is SubSubClass

    Subclass.configure(impl_class, arg2=2, arg3=3)
    impl_class = SubSubClass.configured_class()
    assert impl_class is SubSubClass
    instance = impl_class(arg1=1, arg2=2)
    assert instance.arg1 == 1
    assert instance.arg2 == 2
    assert instance.arg3 == 3

    Subclass.configure(None)
    impl_class = SubSubClass.configured_class()
    assert impl_class is SubSubClass
    instance = impl_class(arg1=1, arg2=2)

# Generated at 2022-06-12 14:24:17.509024
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def __init__(self, x: int) -> None:
            super().__init__()
            self.x = x
        def initialize(self, x: int) -> None:
            self.x = x
    a = A(1)
    assert a.x == 1



# Generated at 2022-06-12 14:24:26.855008
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import tornado.httputil

    def hello_world(*args, **kwargs):
        pass

    arg_replacer = ArgReplacer(hello_world, "max_buffer_size")

    old_value = arg_replacer.get_old_value((1,), {}, 1024)
    assert old_value is None

    old_value = arg_replacer.get_old_value(tuple(), {'max_buffer_size': '2048'}, 1024)
    assert old_value == '2048'

    old_value = arg_replacer.get_old_value((2,), {'max_buffer_size': '2048'}, 1024)
    assert old_value == 2



# Generated at 2022-06-12 14:24:37.411597
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(arg1, arg2, arg3, **kwargs):
        pass
    replacer = ArgReplacer(func, 'arg1')
    old_value, args, kwargs = replacer.replace('new_value', ('default', 'value'), {})
    assert old_value == 'default'
    assert args == ('new_value', 'value')
    assert kwargs == {}
    def func(arg1, arg2, arg3, **kwargs):
        pass
    replacer = ArgReplacer(func, 'arg1')
    old_value, args, kwargs = replacer.replace('new_value', ('default', 'value'), {'arg1': 'value2'})
    assert old_value == 'value2'
    assert args == ('new_value', 'value')

# Generated at 2022-06-12 14:24:42.936185
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    global args, kwargs
    args = (1, 2, 3)
    kwargs = {"a":1, "b":2}
    replacer = ArgReplacer(test_ArgReplacer_get_old_value, "b")
    assert replacer.get_old_value(args, kwargs) == 2
    assert replacer.get_old_value(args, kwargs, 0) == 2
    assert replacer.get_old_value(args, {}, 0) == 0

# Generated at 2022-06-12 14:24:45.757125
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(cls):
            return Foo

        def configurable_default(cls):
            return Foo

        def _initialize(self):
            pass

    a = Foo()
    b = Foo()
    assert a is not b


# Functions to be used as assertCb in unit tests

# Generated at 2022-06-12 14:25:22.476855
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock
    my_args = {'a': 'b', 'c': 'd'}
    mocked_obj = unittest.mock.MagicMock()
    mocked_obj.configurable_base.return_value = Configurable
    mocked_obj.configured_class.return_value = Configurable
    mocked_obj.initialize.return_value = mocked_obj
    with unittest.mock.patch('typing.cast', unittest.mock.Mock(return_value=Configurable)):
        with unittest.mock.patch('sys.modules', {}):
            Configurable.configure(None, **my_args)
            r = Configurable.__new__(mocked_obj, *my_args.values())
            mocked_obj.config

# Generated at 2022-06-12 14:25:31.810054
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """Unittest for method replace of class ArgReplacer"""
    
    def foo(a, b):
        return a+b

    replacer = ArgReplacer(foo, 'a')

    args, kwargs = (), {}
    old_value, args, kwargs = replacer.replace(0, args, kwargs)
    assert old_value == None
    assert args == ()
    assert kwargs == {"a": 0}

    args, kwargs = (), {"a": 10}
    old_value, args, kwargs = replacer.replace(0, args, kwargs)
    assert old_value == 10
    assert args == ()
    assert kwargs == {"a": 0}

    args, kwargs = (100,), {}

# Generated at 2022-06-12 14:25:37.453764
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c = 10, d = 20):
        pass
    foo_arg_replacer = ArgReplacer(foo, "c")

    # Test the get_old_value method
    old_val = foo_arg_replacer.get_old_value((1, 2), dict(d=40))
    assert old_val == 10
    old_val = foo_arg_replacer.get_old_value((1, 2), dict(c=10, d=40))
    assert old_val == 10
    old_val = foo_arg_replacer.get_old_value((1, 2), dict(c=10, d=40), 1000)
    assert old_val == 10

    # Test the replace method

# Generated at 2022-06-12 14:25:47.278184
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def args_function(a, b=1, c=2, *d, **e):
        pass

    def kwargs_function(a, b=1, c=2, *d, **e):
        pass

    replacer = ArgReplacer(args_function, 'a')
    assert replacer.get_old_value((), {}) is None
    assert replacer.get_old_value([], {}) is None
    assert replacer.get_old_value((0,), {}) == 0
    assert replacer.get_old_value([0], {}) == 0
    assert replacer.get_old_value((1,), {}) == 1
    assert replacer.get_old_value([1], {}) == 1
    assert replacer.get_old_value((0, 1, 2), {}) == 0

# Generated at 2022-06-12 14:25:54.232808
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class Foo(Configurable):
        def initialize(self, bar):
            # type: (str) -> None
            self.bar = bar
        configurable_base = classmethod(lambda cls: Foo)
        configurable_default = classmethod(lambda cls: Foo)

    Foo.configure("tornado.tests.util.FooImpl")
    foo = Foo("spam")
    assert isinstance(foo, FooImpl)
    assert foo.bar == "spam"



# Generated at 2022-06-12 14:26:00.975968
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b=1):
        pass

    replacer = ArgReplacer(foo, 'b')
    assert replacer.replace(2, (3,), {'b': 1}) == (1, (3,), {})
    assert replacer.replace(2, (3,), {'b': 1, 'c': 3}) == (1, (3,), {'c': 3})
    assert replacer.replace(2, (3,), {}) == (None, (3,), {'b': 2})


# Generated at 2022-06-12 14:26:08.494763
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-12 14:26:17.705352
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():  # pragma: no cover
    @typing.overload
    def foo(x: int, y: int, z: int) -> None:
        pass

    @typing.overload  # noqa: F811
    def foo(x: str, y: int, z: int) -> None:
        pass

    @typing.overload  # noqa: F811
    def foo(x: int, y: int, z: str) -> None:
        pass

    @typing.overload  # noqa: F811
    def foo(x: str, y: int, z: str) -> None:
        pass

    @typing.overload  # noqa: F811
    def foo(x: int, y: str, z: int) -> None:
        pass


# Generated at 2022-06-12 14:26:21.991196
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from typing import Any

    class DummyClass(Configurable):
        def initialize(self, *args, **kwargs):
            pass

        @classmethod
        def configurable_base(self):
            pass

        @classmethod
        def configurable_default(self):
            pass

    dummy = DummyClass()
    dummy.initialize(1, 2, 3, 4, 5)

