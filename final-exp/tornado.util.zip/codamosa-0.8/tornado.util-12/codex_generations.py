

# Generated at 2022-06-12 14:16:48.072224
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def _test(self, name, new_value, args, kwargs, expected_result):
        arg_replacer = ArgReplacer(self, name)
        actual_result = arg_replacer.replace(new_value, args, kwargs)
        if expected_result is not None:
            expected_result = (None,) + expected_result
        assert actual_result == expected_result

    def test_arg_replacer_replace():
        _test(test_arg_replacer_replace, "a", 1, [0], dict(), ([1], dict()))
        _test(test_arg_replacer_replace, "a", 1, [0, 2], dict(), ([1, 2], dict()))

# Generated at 2022-06-12 14:16:53.638645
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_base_class_type = type("configurable_base_class_type", (Configurable, ), dict(
        configurable_base = lambda self: self.__class__,
        configurable_default = lambda self: self.__class__
    ))

    Configurable.configure(configurable_base_class_type)

    configurable_base_class_type_instance = configurable_base_class_type()
    assert isinstance(configurable_base_class_type_instance, configurable_base_class_type)


# Generated at 2022-06-12 14:16:58.684652
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class BaseConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return BaseConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return DefaultImpl

    class DefaultImpl(BaseConfigurable):
        def initialize(self):
            # type: () -> None
            pass

    class Impl1(BaseConfigurable):
        def initialize(self):
            # type: () -> None
            pass



# Generated at 2022-06-12 14:17:03.134410
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func_with_four_args(a,b,c,d):
        pass
    empty_arg_replacer = ArgReplacer(func = func_with_four_args, name = "a")
    assert empty_arg_replacer.get_old_value(args = (3,4,5,6), kwargs = {}, default = -1) == 3


# Generated at 2022-06-12 14:17:11.253248
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        # Initialize initialized
        def __init__(self, a, b=None):
            # type: (str, Optional[str]) -> None
            self.args = (a, b)
            self.kwargs = {}  # type: Dict[str, Any]

    class SubBase(Base):
        @classmethod
        def configurable_base(cls):
            return SubBase

        @classmethod
        def configurable_default(cls):
            return SubImpl


# Generated at 2022-06-12 14:17:18.568076
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    args = ['a','b','c','d','e','f','g']
    kwargs = {
        1:'b',
        'd':'d',
        'f':'f',
        'g':'g'
    }
    new_value = 'A'
    ar = ArgReplacer(test_ArgReplacer_get_old_value, 'g')
    res = ar.replace(new_value, args, kwargs)
    if res[0] == 'g' and args == ['a','b','c','d','e','f','A']:
        print("test method get_old_value: OK")
    else:
        print("test method get_old_value: Failed")

# Generated at 2022-06-12 14:17:26.629146
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ExampleConfigurable(Configurable):
        """Example class with a configurable constructor."""

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ExampleConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return ExampleConfigurableImplementation

        def initialize(self, x, y, z=0):
            # type: (int, int, int) -> None
            self.sum = x + y + z

    class ExampleConfigurableImplementation(ExampleConfigurable):
        pass

    e = ExampleConfigurable(1, 2, 3)
    assert isinstance(e, ExampleConfigurable)
    assert isinstance(e, ExampleConfigurableImplementation)
    assert e.sum == 6

    ExampleConfig

# Generated at 2022-06-12 14:17:28.739167
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    foo = ObjectDict(foobar=42)
    foo.testing = True
    try:
        foo.nothing
    except AttributeError:
        pass


# Generated at 2022-06-12 14:17:32.838646
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.platform.asyncio import AsyncIOLoop

    AsyncIOLoop.configure('tornado.platform.asyncio.AsyncIOLoop')
    loop = AsyncIOLoop()
    assert isinstance(loop, AsyncIOLoop)



# Generated at 2022-06-12 14:17:41.589757
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls) -> Type[Configurable]:
            return Foo
        @classmethod
        def configurable_default(cls) -> Type[Configurable]:
            return Bar
        def initialize(self) -> None:
            pass

    class Bar(Foo):
        def initialize(self) -> None:
            pass

    Foo.configure(Bar)
    assert isinstance(Foo(), Bar)
    assert isinstance(Foo(), Foo)

# Generated at 2022-06-12 14:17:53.445340
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(42, "numeric exception")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == None



# Generated at 2022-06-12 14:18:00.488085
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    import unittest
    import warnings

    class CustomException(Exception):
        pass

    class A(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, *args: Any, **kwargs: Any):
            # type: (...) -> None
            if len(args) > 1:
                raise TypeError(
                    "initialize() takes at most 1 positional argument "
                    "(%d given)" % len(args)
                )
            self.args = args
            self.kwargs = kwargs

    class B(A):
        pass


# Generated at 2022-06-12 14:18:02.766219
# Unit test for function import_object
def test_import_object():
    # silence pyflakes warning
    __import__('tornado.test.util_test')



# Generated at 2022-06-12 14:18:08.285326
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(object):
        pass

    assert isinstance(Base(), Base)

    class Test(Configurable):
        @classmethod
        def configurable_base(cls):
            return Test

        @classmethod
        def configurable_default(cls):
            return Base

    class Test2(Test):
        pass

    assert isinstance(Test(), Base)
    assert isinstance(Test2(), Base)

    Test.configure(Test2)
    assert isinstance(Test(), Test2)
    assert isinstance(Test2(), Test2)

    assert Test2.configured_class() is Test2

    Test.configure(None)
    assert isinstance(Test(), Base)
    assert isinstance(Test2(), Test2)



# Generated at 2022-06-12 14:18:13.865183
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=10):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value(0, 0) == 10
    assert arg_replacer.get_old_value([1, 1] , {}) == 10
    assert arg_replacer.get_old_value([1, 1] , {} , 99) == 99
    assert arg_replacer.get_old_value([1, 1] , {'c': 99} , 88) == 99
    assert arg_replacer.get_old_value([1, 1] , {'c': 99} ) == 99

# Generated at 2022-06-12 14:18:19.354400
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self):
            pass

    obj = MyConfigurable()
    assert isinstance(obj, MyConfigurable)



# Generated at 2022-06-12 14:18:27.854496
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        __impl_class = None
        __impl_kwargs = {'a':1, 'b':2}
        def __new__(cls,*args,**kwargs):
            return super().__new__(cls,*args,**kwargs)
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
        def initialize(self,*args,**kwargs):
            super().initialize(*args,**kwargs)
    save = TestConfigurable._save_configuration()
    obj = TestConfigurable()
    TestConfigurable.config

# Generated at 2022-06-12 14:18:31.983138
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test_func(arg1, arg2, arg3, arg4):
        pass

    arg_replacer = ArgReplacer(test_func, "arg1")
    assert arg_replacer.get_old_value([1, 2, 3, 4], {}) == 1



# Generated at 2022-06-12 14:18:39.655512
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    def _test(cls):
        # type: (Type[Configurable]) -> None
        instance = cls()
        assert isinstance(instance, cls)
        assert isinstance(instance, cls.configurable_default())

    @Configurable
    class ConfigA(Configurable):
        def __init__(self, *args, **kwargs):
            # type: (Any, Any) -> None
            pass  # pragma: no cover

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ConfigA

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return ImplA


# Generated at 2022-06-12 14:18:45.898952
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest2
    class Configurable(object):
        def initialize(self, a=None, b=None, c=None):
            print(a, b, c)

    class Impl(Configurable):
        def initialize(self, *args, **kwargs):
            super(Impl, self).initialize(*args, **kwargs)

    class SubImpl(Impl):
        def initialize(self, foo=None, bar=None, **kwargs):
            super(SubImpl, self).initialize(foo, bar, **kwargs)

    class TestConfigurable(unittest2.TestCase):
        def test_initialize(self):
            Configurable.configure(Impl, a=1, b=2)
            self.assertEqual(Impl.initialize(Impl(), c=3), None)
            self.assertE

# Generated at 2022-06-12 14:19:08.161637
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(x, y, w=3, z=4):
        return y
    r = ArgReplacer(func, "y")
    old, args, kwargs = r.replace("new", [1, 2, 3, 4], {})
    assert old == 2
    assert args == [1, "new", 3, 4]
    assert kwargs == {}
    old, args, kwargs = r.replace("new", [1, 2], {"z": 5})
    assert old == 2
    assert args == [1, "new"]
    assert kwargs == {"z": 5}
    old, args, kwargs = r.replace("new", [1, 2], {"y": 5})
    assert old == 5
    assert args == [1, 2]
    assert kwargs == {"y": "new"}

# Generated at 2022-06-12 14:19:19.293885
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def _test(new_value, old_value, arg_pos, args, kwargs):
        replacer = ArgReplacer(None, "foo")
        replacer.arg_pos = arg_pos
        found_old_value, found_args, found_kwargs = replacer.replace(new_value, args, kwargs)
        assert found_old_value == old_value
        if isinstance(args, tuple):
            assert found_args == args
        else:
            assert found_args == tuple(args)
        assert found_kwargs == kwargs
    _test(1, None, 0, (0,), {})
    _test(1, 2, 0, (2,), {})
    _test(1, None, None, (1, 2), {"foo": 3})

# Generated at 2022-06-12 14:19:29.373176
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from unittest import mock
    from abc import ABCMeta
    from typing import Generic, TypeVar, List, Callable
    from types import TracebackType
    from ._util import AsyncMock
    from .web import Application
    from .httputil import _WebSocketProtocol
    from .concurrent import Future, TracebackFuture
    T = TypeVar("T")
    U = TypeVar("U")
    V = TypeVar("V")
    S = TypeVar("S")
    class _Application(Generic[T], Application, configurable_default = Application):
        pass
    class _WSProtocol(Generic[T, U, V], _WebSocketProtocol, configurable_default = _WebSocketProtocol):
        pass
    class _Future(Generic[T], Future[T], configurable_default = Future):
        pass
   

# Generated at 2022-06-12 14:19:35.618436
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Verifies that __new__ is called when class is instantiated
    class MyClass(Configurable):
        # pylint: disable=unused-argument
        def __new__(cls, *args, **kwargs):
            return super(MyClass, cls).__new__(cls)
        def __init__(self, *args, **kwargs):  # type: ignore
            self._init_args = (args, kwargs)
        def initialize(self, *args, **kwargs):  # type: ignore
            self._init_args = (args, kwargs)

    MyClass.configure(None)
    c = MyClass()
    c = MyClass(1, 2)
    c = MyClass(key1=1, key2=2)

# Generated at 2022-06-12 14:19:43.032557
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    from tornado import ioloop
    import signal

    class MyIOloop(ioloop.IOLoop):
        def initialize(self):
            self.initialized = 1
            super(MyIOloop, self).initialize()

    ioloop.IOLoop.clear_instance()
    ioloop.IOLoop.configure(MyIOloop)
    loop = ioloop.IOLoop.current()
    assert loop.initialized == 1
    assert isinstance(loop, MyIOloop)
    loop.close()



# Generated at 2022-06-12 14:19:48.320777
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A

    a=A()
    print(a)


if __name__ == '__main__':
    test_Configurable___new__()

# Generated at 2022-06-12 14:19:52.375811
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    try:
        c = Configurable()
        assert c is not None
    except NotImplementedError as e:
        assert 'initialize' in str(e)
        assert '__init__' in str(e)
        pass


# Generated at 2022-06-12 14:19:52.853141
# Unit test for method initialize of class Configurable
def test_Configurable_initialize(): pass

# Generated at 2022-06-12 14:20:01.899509
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """Unit test for method replace of class ArgReplacer"""

    def test_func_1arg(arg: Any) -> None:
        pass

    assert ArgReplacer(test_func_1arg, "arg").replace(1, (), {}) == (
        None,
        [1],
        {},
    )
    assert ArgReplacer(test_func_1arg, "arg").replace(1, (2,), {}) == (
        2,
        [1],
        {},
    )
    assert ArgReplacer(test_func_1arg, "arg").replace(1, (), {"arg": 3}) == (
        3,
        [],
        {"arg": 1},
    )

# Generated at 2022-06-12 14:20:07.377949
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        e.errno = 42
    assert errno_from_exception(e) == 42

    try:
        raise Exception(42, "foo")
    except Exception as e:
        pass
    assert errno_from_exception(e) == 42

    try:
        raise Exception("foo")
    except Exception as e:
        pass
    assert errno_from_exception(e) is None



# Generated at 2022-06-12 14:20:39.592554
# Unit test for function import_object
def test_import_object():
    from tornado.escape import to_unicode
    assert to_unicode is import_object("tornado.escape.to_unicode")
    assert to_unicode is import_object("tornado.escape.to_unicode")

# Fake unittest.skip decorator to retain compatibility with Python 2.6.

# Generated at 2022-06-12 14:20:49.176851
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun(a1, a2, a3, a4):
        pass
    arg_rep = ArgReplacer(fun, 'a2')
    assert arg_rep.replace(5, (1, 2, 3, 4), {'a5': 5}) == (2, (1, 5, 3, 4), {'a5': 5})
    assert arg_rep.replace(5, (1, 2, 3, 4), {}) == (2, (1, 5, 3, 4), {'a2': 5})
    assert arg_rep.replace(5, (1, 3, 4), {'a2': 2}) == (2, (1, 5, 4), {'a2': 5})

# Generated at 2022-06-12 14:21:00.004040
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # See also module @gen_test, which also defines a method initialize...
    from tornado.ioloop import IOLoop

    @gen.coroutine
    def f():
        return 1

    class T(Configurable):
        def configure(cls, impl, **kwargs):
            # type: (Union[None, str, Type[Configurable]], Any) -> None
            base = IOLoop.configurable_base()
            if isinstance(impl, str):
                impl = import_object(impl)
            if impl is not None and not issubclass(impl, base):
                raise ValueError("Invalid subclass of " + repr(base))
            base.__impl_class = impl
            base.__impl_kwargs = kwargs


# Generated at 2022-06-12 14:21:02.831193
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return None
    assert isinstance(Foo.initialize, types.MethodType)



# Generated at 2022-06-12 14:21:10.614931
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class BaseImpl(Configurable):
        @classmethod
        def configurable_base(cls):
            return BaseImpl

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return BaseImpl

        def __init__(self):
            pass

    BaseImpl.configure(None)
    assert BaseImpl().__class__ is BaseImpl
    BaseImpl.configure("tornado.util.Configurable")
    assert BaseImpl().__class__.__name__ == "Configurable"



# Generated at 2022-06-12 14:21:22.234840
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from . import util
    from .util import Configurable
    class ABC(Configurable):
        def configurable_base(self):
            return ABC
        def configurable_default(self):
            return ABC
        def initialize(self):
            self.a = 1
            self.b = 2
            self.c = 3
    abc = ABC()
    assert abc.configurable_base() is ABC
    assert abc.configurable_default() is ABC
    assert isinstance(abc, ABC)
    assert isinstance(abc, Configurable)
    assert abc.a == 1
    assert abc.b == 2
    assert abc.c == 3
    class ABC_Impl(ABC):
        def initialize(self):
            self.x = 4
            self.y = 5
            self.z

# Generated at 2022-06-12 14:21:28.821031
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def testMethod(arg1, arg2, arg3=3, arg4=4):
        pass
    replacer = ArgReplacer(testMethod, 'arg3')

    def test(args, kwargs, expected):
        assert replacer.get_old_value(args, kwargs) == expected

    test([1, 2, 'test'], {'arg4': 'test'}, 'test')
    test([1, 2], {'arg4': 'test'}, 3)


# Generated at 2022-06-12 14:21:32.869862
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def old_func(a, b, c=None):
        pass

    arg = ArgReplacer(old_func, 'a')
    ret = arg.get_old_value((None, None), dict())
    if ret is None:
        pass  # Passes
    else:
        assert False, "Should not reach here."



# Generated at 2022-06-12 14:21:43.713182
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from typing import TypeVar

    T = TypeVar('T', bound='TestConfigurable')

    class TestConfigurable(Configurable):
        __impl_class = None

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def _initialize(self, a, b, c=0):
            self.a = a
            self.b = b
            self.c = c

    instance = TestConfigurable(1, 2)
    assert instance.a == 1
    assert instance.b == 2
    assert instance.c == 0

    instance = TestConfigurable(1, 2, 3)
    assert instance.a == 1
    assert instance.b == 2
    assert instance.c == 3

    TestConfig

# Generated at 2022-06-12 14:21:50.445049
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import unittest
    import types
    import functools

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self):
            self.x = "A"

    class B(A):
        def initialize(self):
            self.x = "B"

    class C(A):
        def initialize(self):
            self.x = "C"

    class D(Configurable):
        @classmethod
        def configurable_base(cls):
            return D

        @classmethod
        def configurable_default(cls):
            return D

        def initialize(self):
            pass


# Generated at 2022-06-12 14:22:27.843613
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConfigurableTestCreate(Configurable):
        def __init__(self, name: str, **kwargs: Any) -> None:
            self.name = name
        def configurable_base(self):
            return ConfigurableTestCreate
        def configurable_default(self):
            return ConfigurableTestCreate
    ConfigurableTestCreate.configure(ConfigurableTestCreate, name="test")
    c = ConfigurableTestCreate()
    assert c.name == "test"



# Generated at 2022-06-12 14:22:36.062783
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Unit test for Configurable.__new__.
    # This is not a typical case, as Configurable is typically used as a
    # mixin class, but it exercises the full logic.
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self):
            pass

    class Derived(Base):
        @classmethod
        def configurable_base(cls):
            return Derived

        @classmethod
        def configurable_default(cls):
            return DerivedImpl

    class DerivedImpl(Derived):
        def initialize(self):
            pass

    assert isinstance(Base(), BaseImpl)

# Generated at 2022-06-12 14:22:46.160377
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def get_arg1(arg1):
        return arg1

    r = ArgReplacer(get_arg1, "arg1")
    assert r.get_old_value(("x",), {}) == "x"
    assert r.get_old_value(("x",), {}, default=1) == "x"
    assert r.get_old_value((), {"arg1": "y"}) == "y"
    assert r.get_old_value((), {"arg1": "y"}, default=1) == "y"
    assert r.get_old_value((), {}) is None
    assert r.get_old_value((), {}, default=1) == 1

    def no_arg1():
        pass

    r = ArgReplacer(no_arg1, "arg1")
    old, args,

# Generated at 2022-06-12 14:22:53.500178
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "something")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("something else")
    except Exception as e:
        assert errno_from_exception(e) == "something else"



# Generated at 2022-06-12 14:23:02.137511
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class ErrnoExceptionEintr(OSError):
        """Example exception with errno EINTR"""
        errno = errno.EINTR
    class ErrnoExceptionEio(OSError):
        """Example exception with errno EIO"""
        errno = errno.EIO
    class MyException(Exception):
        """Example exception without errno"""
        pass
    class MyExceptionArgs(Exception):
        """Example exception without args"""
        pass

    try:
        raise ErrnoExceptionEintr
    except OSError as e:
        assert errno_from_exception(e) == errno.EINTR
    try:
        raise ErrnoExceptionEio("error message")
    except OSError as e:
        assert errno_from_exception(e) == errno.EIO

# Generated at 2022-06-12 14:23:10.477567
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class A:
        def __init__(self, a: int, b: int = 5) -> None:
            self.A = a
            self.B = b

    import inspect
    kwargs = {
        'b': 10,
    }
    new_value = 20
    arg_replacer = ArgReplacer(A, 'b')
    old_value, args, kwargs = arg_replacer.replace(new_value, [10], kwargs)

    assert(old_value == kwargs['b'])
    assert(args == [10])
    assert(kwargs['b'] == new_value)



# Generated at 2022-06-12 14:23:11.812301
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    assert issubclass(Configurable, object)

# Generated at 2022-06-12 14:23:16.090560
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    i = 3
    x = Configurable()
    x = Configurable.configured_class()
    x = Configurable.configure(Configurable)
    x = Configurable.configurable_base()
    x = Configurable.configurable_default()
    x = Configurable._save_configuration()
    x = Configurable._restore_configuration(x)
    x = x._initialize()
    x = x.initialize(i)



# Generated at 2022-06-12 14:23:25.582689
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(foo, bar, baz=None):
        pass

    args = (1, 2, 3)
    kwargs = {'foo': 1, 'bar': 2, 'baz': 3}
    arg_replacer = ArgReplacer(func, 'bar')
    assert arg_replacer.get_old_value(args, kwargs, default=None) is None
    assert arg_replacer.get_old_value(args, kwargs) is None
    assert arg_replacer.get_old_value(args, kwargs, kwargs['bar']) == 2
    assert arg_replacer.get_old_value(args, kwargs, 'bar') == 'bar'



# Generated at 2022-06-12 14:23:27.982644
# Unit test for function import_object
def test_import_object():
    obj = import_object('tests.test_util.test_import_object')
    assert obj is test_import_object, repr(obj)
if typing.TYPE_CHECKING:
    test_import_object()



# Generated at 2022-06-12 14:24:36.883529
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyClass

        @classmethod
        def configurable_default(cls):
            raise NotImplementedError()

    assert issubclass(MyClass, Configurable)
    assert MyClass.configurable_base() is MyClass

    a = MyClass()



# Generated at 2022-06-12 14:24:44.456818
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """
    >>> test_ArgReplacer_replace()
    [1, 2, {'value':3, 'a':3, 'b':2}, {'value':3, 'b':2}]
    """
    def test_fun(a, b=2, *, value=3):
        return a, b, value

    @ArgReplacer_wrapper
    def test_fun_replacer(self,new_value, a=1, b=2, *, value=3):
        old_value = self.get_old_value(args, kwargs)
        self.replace(new_value, args, kwargs)
        print(args)
        print(kwargs)

    test_fun_replacer('a', 4)



# Generated at 2022-06-12 14:24:48.106891
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    class ConcreteConfigurable(Configurable):
        def initialize(self):
            pass

        @classmethod
        def configurable_base(cls):
            return ConcreteConfigurable

        @classmethod
        def configurable_default(cls):
            return ConcreteConfigurable

    assert isinstance(ConcreteConfigurable(), ConcreteConfigurable)



# Generated at 2022-06-12 14:24:57.357378
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=4):
        pass
    args = (1, 2, 3)
    kwargs = {"d": 5}
    replacer = ArgReplacer(func, "d")
    # test when positional arg is present
    assert replacer.get_old_value(args, kwargs) == 3
    # test when positional arg is not present
    assert replacer.get_old_value(args[:-1], kwargs) == kwargs["d"]
    # test when positional arg is not present and default value is none
    assert replacer.get_old_value(args[:-1], kwargs, default=None) == kwargs["d"]
    # test when positional arg and keyword arg is not present
    assert replacer.get_old_value(args[:-1], {})

# Generated at 2022-06-12 14:25:06.751252
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestDefault

        def initialize(self, *args, **kwargs):
            pass

    class TestDefault(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert(isinstance(TestConfigurable(), TestConfigurable))

    class TestImpl(TestConfigurable):
        pass

    TestConfigurable.configure(TestImpl)
    assert(isinstance(TestConfigurable(), TestImpl))

    # Test singleton semantics
    a = TestConfigurable()
    b = TestConfigurable()
    assert(a is b)

    # Test base class overr

# Generated at 2022-06-12 14:25:16.643538
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    assert 1 == ArgReplacer(lambda x: None, "x").get_old_value((1,), {})
    assert 2 == ArgReplacer(lambda x, y: None, "y").get_old_value((1, 2), {})
    assert 3 == ArgReplacer(lambda x, y: None, "x").get_old_value((), dict(x=3))

# This is the set of classes we expect to find in stack frames that
# are not caused by user code.  The listed classes will appear in the
# traceback of a stack dump, but the code in these classes is not the
# code that is running in the stack frame.

# Generated at 2022-06-12 14:25:21.296291
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c, d=True):
        pass

    replacer = ArgReplacer(f, 'b')
    assert replacer.get_old_value((1, 2, 3), {}) is 2
    assert replacer.get_old_value((1, 2, 3), {'b': 'four'}) is 2



# Generated at 2022-06-12 14:25:29.380862
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from unittest import TestCase
    from tornado.test.util import unittest
    import unittest as unt
    import functools
    class A(Configurable):
        __impl_class = None  # type: Type[A]
        __impl_kwargs = None  # type: Dict[str, Any]
        def initialize(self, extra1=None, extra2=None):
            # type: (Optional[str], Optional[int]) -> None
            self.extra1 = extra1
            self.extra2 = extra2
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

# Generated at 2022-06-12 14:25:38.511662
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a: str) -> int:
        return len(a)
    arg = ArgReplacer(f, "a")
    old_value, args, kwargs = arg.replace("ab", ("cd", ), {})
    assert old_value == "cd"
    assert args == ("ab", )
    assert kwargs == {}

    old_value, args, kwargs = arg.replace("xy", (), {"a": "qw"})
    assert old_value == "qw"
    assert args == ()
    assert kwargs == {"a": "xy"}

    old_value, args, kwargs = arg.replace("cd", (), {"b": "qw"})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-12 14:25:47.963968
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class GoodConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
        def initialize(self, a):
            self.a = a
    gc = GoodConfigurable(1)
    assert(gc.a == 1)
    gc = GoodConfigurable(a=1)
    assert(gc.a == 1)

# Collect all the Configurable subclasses in the namespace.