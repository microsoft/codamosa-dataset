

# Generated at 2022-06-12 14:16:47.209504
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c): pass
    rep = ArgReplacer(foo, 'b')
    old, args, kwargs = rep.replace('B', ('A',), {})
    assert old is None
    assert args == ('A', 'B')
    assert kwargs == {}
    old, args, kwargs = rep.replace('B', ('A', 'b'), {})
    assert old == 'b'
    assert args == ('A', 'B')
    assert kwargs == {}
    old, args, kwargs = rep.replace('B', ('A',), {'b': 'b'})
    assert old == 'b'
    assert args == ('A',)
    assert kwargs == {'b': 'B'}

# Generated at 2022-06-12 14:16:48.493315
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    ___new__(cls, *args, **kwargs)



# Generated at 2022-06-12 14:16:50.069207
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    """Tests method ``get_old_value`` of class ``ArgReplacer``"""

    


# Generated at 2022-06-12 14:16:59.269033
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.queues import Queue, LifoQueue
    from tornado.locks import Semaphore
    import logging
    import os
    import shutil
    import tempfile

    def _check_log_lines(lines, expected_lines):
        # lines should have some garbage from other tests,
        # so this checks that all of the expected lines are in lines
        # in order with no other intervening lines.
        # It also checks that all of lines are expected lines,
        # since the garbage is usually just a couple of lines.
        assert expected_lines == [lines[i] for i in range(len(lines)) if lines[i] in expected_lines], (expected_lines, lines)


# Generated at 2022-06-12 14:17:04.738855
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import warnings
    from tornado.ioloop import IOLoop
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        IOLoop(0)
        # Verify some things
        assert len(w) == 2
        assert issubclass(w[-1].category, RuntimeWarning)
        assert "initialized" in str(w[-1].message)



# Generated at 2022-06-12 14:17:15.127837
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=4, *t, **kw):
        pass
    ar = ArgReplacer(f, "c")
    assert ar.get_old_value((1, 2), {}) is None
    assert ar.get_old_value((1, 2), {}, 2) is 2
    assert ar.get_old_value((1, 2), {}, c=2) is 2
    assert ar.get_old_value((1, 2, 4), {}) is 4
    assert ar.get_old_value((1, 2, 3), {}, 4) is 3
    assert ar.get_old_value((1, 2, 3), {}, c=4) is 3



# Generated at 2022-06-12 14:17:21.965313
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a,b=3,c=5):
        pass
    
    replacer = ArgReplacer(f, 'c')
    print(replacer.get_old_value((1,),{'b':2}))
    print(replacer.get_old_value((1,),{}))
    print(replacer.get_old_value((1,2),{'b':2,'c':4}))
    print(replacer.get_old_value((1,2),{'b':2}))
    print(replacer.get_old_value((1,2),{'b':2},1))
    
test_ArgReplacer_get_old_value()


# Generated at 2022-06-12 14:17:30.072615
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Dummy(Configurable):
        @classmethod
        def configurable_base(cls):
            return Dummy

        @classmethod
        def configurable_default(cls):
            return DummySub

        def initialize(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    class DummySub(Dummy):
        pass

    @gen_test
    def test_init():
        Dummy.configure("tornado.options")
        d = Dummy(test="test")
        self.assertEqual(d.kwargs, {"test": "test"})
        d = Dummy(test="test", n=1)

# Generated at 2022-06-12 14:17:41.552137
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import tornado

    # TODO: finish test
    class Impl(Configurable):
        def configurable_base(self):
            return Configurable

        def configurable_default(self):
            return Impl

        def initialize(self, *args, **kwargs):
            super().initialize(*args, **kwargs)

    # Create a new Impl object
    Impl()

    # Create a new Configurable object
    Configurable()

    # Create a new Impl object with a particular configuration
    # Configurable.configure(tornado.httpserver.HTTPServer)
    # impl_obj = Configurable()
    # assert isinstance(impl_obj, tornado.httpserver.HTTPServer)
    # assert impl_obj.__dict__["_Configurable__impl_class"] ==
    # tornado.httpserver.HTTPServer



# Generated at 2022-06-12 14:17:52.039654
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class TestClass(object):
        def __init__(self, x, y, *args, **kwargs):
            self.x = x
            self.y = y
            self.args = args
            self.kwargs = kwargs
    def func(x, y, *args, **kwargs):
        return TestClass(x, y, *args, **kwargs)

    tc = TestClass(1, 2, 3, 4)
    assert tc.x == 1
    assert tc.y == 2
    assert tc.args == (3, 4)
    assert tc.kwargs == {}

    arg_replacer = ArgReplacer(func, "x")
    _, args, kwargs = arg_replacer.replace(5, [1, 2, 3, 4], {})

# Generated at 2022-06-12 14:18:03.141784
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import doctest
    import tornado.util
    failure_count, test_count = doctest.testmod(tornado.util)
    assert test_count > 0
    assert failure_count == 0

# Generated at 2022-06-12 14:18:10.952960
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Configurable(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @classmethod
        def configure(cls, impl, **kwargs):
            cls.__impl_class = impl
            cls.__impl_kwargs = kwargs

        @classmethod
        def configured_class(cls):
            return cls.__impl_class

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

    class Impl1(Configurable):
        def __init__(self, a, b):
            super(Impl1, self).__init__(a, b)

    Impl1.configure(Impl1)

# Generated at 2022-06-12 14:18:22.883356
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Bar

        def initialize(self, *args, **kwargs):
            pass


    class Bar(Foo):
        def initialize(self, *args, **kwargs):
            pass


    class Baz(Foo):
        def initialize(self, *args, **kwargs):
            pass


    # default implementation
    Foo.configure(None)
    foo = Foo()
    assert isinstance(foo, Bar)

    # actual implementation
    Foo.configure(Baz)
    foo = Foo()
    assert isinstance(foo, Baz)

    # string implementation

# Generated at 2022-06-12 14:18:25.470926
# Unit test for function import_object
def test_import_object():
    assert import_object('tornado.util') is util



# Generated at 2022-06-12 14:18:33.548861
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class _ConfigurableImpl(Configurable):
        def configurable_base(self):
            return _ConfigurableImpl
        def configurable_default(self):
            return _ConfigurableImpl
    class _ConfigurableImpl1(_ConfigurableImpl):
        def initialize(self, a=1):
            pass 
    _ConfigurableImpl.configure('_ConfigurableImpl1')
    c = _ConfigurableImpl()
    assert isinstance(c, _ConfigurableImpl)
    assert isinstance(c, _ConfigurableImpl1)
    assert c.a == 1



# Generated at 2022-06-12 14:18:42.494329
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, default="default", *, key):
        return [a, b, default, key]

    wrapper = ArgReplacer(test_func, "default")
    normal_position = ["a", "b"]
    normal_kwargs = {"key": "key"}
    keyword_position = ["a"]
    keyword_kwargs = {"b": "b", "default": "normal", "key": "key"}
    position_keyword_position = ["a"]
    position_keyword_kwargs = {"b": "b", "key": "key"}
    position_keyword_star_position = ["a"]
    position_keyword_star_kwargs = {"b": "b", "key": "key", "star": "star"}
    star_position = ["a"]

# Generated at 2022-06-12 14:18:54.509611
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class InstrumentedConfigurable(Configurable):
        _initialize_calls = 0

        @classmethod
        def configurable_base(cls):
            return InstrumentedConfigurable
        @classmethod
        def configurable_default(cls):
            return InstrumentedConfigurable
        def _initialize(self):
            super(InstrumentedConfigurable, self)._initialize()
            InstrumentedConfigurable._initialize_calls += 1
            self.args = self._args
            self.kwargs = self._kwargs
    c = InstrumentedConfigurable(foo='bar', baz=123)
    assert isinstance(c, InstrumentedConfigurable)

# Generated at 2022-06-12 14:18:58.083906
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try: import_object('tornado.missing_module')
    except: pass
    else: raise Exception("Did not see ImportError")



# Generated at 2022-06-12 14:19:05.175325
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return MyConfigurableImpl

        def initialize(self, hello):
            self.hello = hello

    class MyConfigurableImpl(MyConfigurable):
        def initialize(self, hello):
            self.hello = hello + "!"

    MyConfigurable.configure(MyConfigurableImpl)
    configurable = MyConfigurable("hello")
    assert configurable.hello == "hello!"

# Generated at 2022-06-12 14:19:15.800692
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Impl1(Configurable):
        @classmethod
        def configurable_base(cls):
            return Impl1

        @classmethod
        def configurable_default(cls):
            return Impl1

    class Impl2(Configurable):
        @classmethod
        def configurable_base(cls):
            return Impl2

        @classmethod
        def configurable_default(cls):
            return Impl2

    class SubImpl(Impl2):
        pass

    def make_sub():
        class SubSubImpl(Impl2):
            pass

        return SubSubImpl

    # Configurable.__new__ doesn't use __init__ (asyncio compat)
    Impl1.configure(None)
    Impl2.configure(None)  # type: ignore
    i1 = Impl1()
    i2 = Impl

# Generated at 2022-06-12 14:19:42.968678
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Verifies that __new__ of Configurable returns an instance of configured_class
    class ConcreteClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConcreteClass

        @classmethod
        def configurable_default(cls):
            return ConcreteClass

    class Implementation(ConcreteClass):
        def __init__(self):
            pass

    assert isinstance(ConcreteClass(), ConcreteClass)

    ConcreteClass.configure(Implementation)
    assert isinstance(ConcreteClass(), Implementation)



# Generated at 2022-06-12 14:19:48.775899
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Test ArgReplacer.replace
    args = list("abc")
    kwargs = dict(a=1, b=2)
    repl = ArgReplacer("c", "c")
    old, args2, kwargs2 = repl.replace("d", args, kwargs)
    assert args == ["a", "b", "c"]
    assert args2 == ["a", "b", "d"]
    assert kwargs == dict(a=1, b=2)
    assert kwargs2 == dict(a=1, b=2)
    assert old == "c"
    args = list("abc")
    kwargs = dict(a=1, b=2)
    old, args2, kwargs2 = repl.replace("e", args, kwargs)

# Generated at 2022-06-12 14:19:58.418226
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    class B(A):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return B

        def initialize(self):
            pass

    a = A()
    b = B()
    # A() will produce an instance of A
    assert isinstance(a, A)
    assert not isinstance(a, B)
    # B() will produce an instance of B
    assert not isinstance(b, A)
    assert isinstance(b, B)
    # Configure A to return C instead of A
    class C(A):
        def configurable_base(self):
            return A

# Generated at 2022-06-12 14:20:04.170891
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            pass

        def configurable_default(self):
            pass

        def initialize(self):
            pass

    foo = Foo()
    assert isinstance(foo, Foo)
    assert foo.initialize.__func__ is Foo.initialize
    assert foo.initialize.__func__ is not Configurable.initialize



# Generated at 2022-06-12 14:20:11.211092
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None

    class C(Configurable):
        def initialize(self, a, b=1):
            # type: (int, int) -> None
            self.a = a
            self.b = b

    c = C(2, b=3)
    assert c.a == 2
    assert c.b == 3

    C.configure(None)
    assert isinstance(C(4, b=5), C)
    assert C(4, b=5).a == 4
    assert C(4, b=5).b == 5
    assert isinstance(C(), C)
    assert C().a == 1
    assert C().b == 1

    import_object("email.parser")
    C.configure("email.parser")
    assert C(6, b=7).a == 6

# Generated at 2022-06-12 14:20:20.750567
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

        def initialize(self):
            print("Base.initialize called")

    class BaseImpl(Base):
        def __init__(self):
            print("BaseImpl.__init__ called")

    class Derived(Base):
        @classmethod
        def configurable_default(cls):
            return DerivedImpl

        def __init__(self):
            print("Derived.__init__ called")

    class DerivedImpl(Derived):
        def __init__(self):
            print("DerivedImpl.__init__ called")

    Base.configure(DerivedImpl)
    obj = Base()



# Generated at 2022-06-12 14:20:24.331355
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo

        def configurable_default(self):
            return Foo

        def initialize(self):
            pass

    class Bar(Foo):
        def initialize(self):
            pass

    Foo.configure(Foo)
    b = Bar()
    assert isinstance(b, Foo)



# Generated at 2022-06-12 14:20:28.360993
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    old_value, args, kwargs = ArgReplacer(lambda a, b, c=4: None, 'c').replace(5, (), {})
    assert old_value is None
    assert args == ()
    assert kwargs == {'c': 5}
    old_value, args, kwargs = ArgReplacer(lambda a, b, c=4: None, 'c').replace(5, (1,2,), {})
    assert old_value == 4
    assert args == (1, 2, 5)
    assert kwargs == {}



# Generated at 2022-06-12 14:20:32.756079
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo
        def configurable_default(self):
            return Foo
        def initialize(self):
            pass
    Foo.configure(None)
    foo = Foo()
    assert foo.initialize is foo._initialize


# Generated at 2022-06-12 14:20:43.578336
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f1(a,b,c):
        return a,b,c
    def f2(a,b,c=1):
        return a,b,c

    ar = ArgReplacer(f1,"a")
    print(ar.replace(1, (2,3,4), {}))
    print(ar.replace(1, (2,3), {"c":4}))
    print(ar.replace(1, (2,3), {"c":4,"d":5}))
    print(ar.replace(1, (), {"c":4,"d":5,"a":6}))

    ar = ArgReplacer(f2,"a")
    print(ar.replace(1, (2,3), {}))
    print(ar.replace(1, (2,3), {"c":4}))

# Generated at 2022-06-12 14:21:01.931632
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    x = Configurable()
    x.initialize()


# Generated at 2022-06-12 14:21:06.510299
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c=None):
        pass

    rep = ArgReplacer(foo, "a")

    old_value = rep.get_old_value((1, 2, 3), {})
    assert old_value == 1, old_value


# Generated at 2022-06-12 14:21:17.794356
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    def _initialize(self, **kwargs) -> None:
        self.initialize = self._initialize
        self.__dict__.update(kwargs)

    def _save_configuration(cls):
        return (cls.__impl_class, cls.__impl_kwargs)

    def _restore_configuration(cls, saved):
        cls.__impl_class = saved[0]
        cls.__impl_kwargs = saved[1]

    class C(Configurable):
        def configurable_base(self):
            return _test_case
        def configurable_default(self):
            return _test_case

    _test_case = C

    C.__impl_class = None
    C.__impl_kwargs = {}
    C.__init__ = _initialize


# Generated at 2022-06-12 14:21:28.486767
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class C(Configurable):
        @classmethod
        def configurable_base(cls): return C

        @classmethod
        def configurable_default(cls): return C1

        def initialize(self, **kwargs): pass
        
    class C1(C): pass
    class C2(C): pass
    class C3(C1): pass

    c = C()
    assert type(c) is C1
    assert C.configured_class() is C1
    assert C.configured_class() is C1

    C.configure(C2, debug=True)
    assert C.configure_kwargs == {'debug': True}
    assert C.configured_class() is C2
    c = C()
    assert type(c) is C2

# Generated at 2022-06-12 14:21:34.544825
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    test_case = [
        {
            'name': 'test_case_1',
            'params': {},
            'expect': {
                'exception': TypeError,
                'message': 'object of type \'.Test_Configurable\' '
                           'has no len()',
            },
        },
    ]
    for item in test_case:
        with pytest.raises(item.get('expect').get('exception')) as excinfo:
            Configurable.__new__(Configuration)
        assert str(excinfo.value) == item.get('expect').get('message'),    \
            item.get('name')


# Generated at 2022-06-12 14:21:45.228777
# Unit test for method __new__ of class Configurable
def test_Configurable___new__(): # noqa: N802
    import tornado.httpclient
    from tornado.util import Configurable
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest

    class MyHTTPClient(AsyncHTTPClient, Configurable):
        @classmethod
        def configurable_base(cls):
            return AsyncHTTPClient

        @classmethod
        def configurable_default(cls):
            return AsyncHTTPClient

    AsyncHTTPClient.configure(MyHTTPClient)
    try:
        client = AsyncHTTPClient()
        assert isinstance(client, AsyncHTTPClient)
        assert isinstance(client, MyHTTPClient)
        req = HTTPRequest("http://www.google.com/")
        client.fetch(req)
    finally:
        AsyncHTTPClient.configure(None)


# Generated at 2022-06-12 14:21:50.845164
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import pytest
    from tornado.util import Configurable
    # case: If a configurable class sets its impl class, the class is returned
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo
        @classmethod
        def configurable_default(cls):
            return Bar
    class Bar(Foo):
        def _initialize(self):
            pass
    Foo.configure(Bar)
    assert type(Foo()) is Bar



# Generated at 2022-06-12 14:21:54.643690
# Unit test for function import_object
def test_import_object(): # noqa: F811
    assert import_object("tornado") is tornado
    assert import_object("tornado.testing") is tornado.testing
    assert import_object("tornado.version") is tornado.version
    assert import_object("tornado.version.__doc__") is tornado.version.__doc__



# Generated at 2022-06-12 14:22:00.901943
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestBase(Configurable):
        def __init__(self, arg1, arg2, arg3=None):
            pass

        @classmethod
        def configurable_base(cls):
            return TestBase

        @classmethod
        def configurable_default(cls):
            return TestBase

    impl1 = TestBase("value1", "value2")

    TestBase.configure("tornado.test.test_util.TestImpl1")

    impl2 = TestBase("value3", "value4", arg3="value5")



# Generated at 2022-06-12 14:22:08.842484
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from inspect import isfunction
    from inspect import signature

    def func(a, b, c=0, *, d, e="hello"):
        pass

    def func_no_keywords(a, b, c=0):
        pass

    def func_no_args(a=0, b=0):
        pass

    def func_no_args_no_keywords():
        pass

    def func_unspecified(a, b, *args, c=0, d=1, **kwargs):
        pass

    assert isfunction(func)
    assert isfunction(func_no_keywords)
    assert isfunction(func_no_args)
    assert isfunction(func_no_args_no_keywords)
    assert isfunction(func_unspecified)

    arg_spec = signature(func)

# Generated at 2022-06-12 14:23:16.755664
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest.mock as mock

    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.auto import AutoInstaller

    class DummyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return DummyConfigurable

        @classmethod
        def configurable_default(cls):
            return DummyConfigurableImpl

        def initialize(self):
            pass

    class DummyConfigurableImpl(DummyConfigurable):
        pass

    class SecondDummyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return SecondDummyConfigurable

        @classmethod
        def configurable_default(cls):
            return SecondDummyImpl

        def initialize(self):
            pass


# Generated at 2022-06-12 14:23:26.892075
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a,b,c):
        return a,b,c
    def test1(a,b,c,d):
        return a,b,c,d
    def test2(a,b,c,d=None,e=0):
        return a,b,c,d,e
    def test3(a=None,b=None,c=0):
        return a,b,c
    def test4(a=None,b=None,c=0,d=None):
        return a,b,c,d
    a = None
    assert ArgReplacer(test,'a').get_old_value((1,2,3),{}) == 1
    assert ArgReplacer(test,'b').get_old_value((1,2,3),{}) == 2

# Generated at 2022-06-12 14:23:32.759627
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
        def func(a, b, c, d, e, f=None, g=None, h=None):
            return 111
        print(func(1,2,3,4,5))
        print(ArgReplacer(func, 'f').replace(1, (1,2,3,4,5), {}))
        print(ArgReplacer(func, 'd').replace(1, (1,2,3,4,5), {}))
        print(ArgReplacer(func, 'h').replace(1, (1,2,3,4,5), {}))

# Generated at 2022-06-12 14:23:37.890675
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def bike(name):
        return "I drive a motorbike called " + name

    def car(name):
        return "I drive a car called " + name

    print(ArgReplacer(bike, "name").replace("toy", ( None, ), {}))
    print(ArgReplacer(car, "name").replace("toy", ( None, ), {}))


test_ArgReplacer_replace()

# Generated at 2022-06-12 14:23:43.839778
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    @ArgReplacer        
    def foo(a: str, b: int, c:bool, d: str=None, e: int=1, f: bool=False, *args: str, **kwargs: Any) -> None:
        pass
    args = ("foo", 1, True)
    kwargs = {"d": "foo"}
    names = ["a", "b", "c", "d", "e", "f"]
    for name in names:
        for arg_pos in [None]:
            for default in [None, 100]:
                replacer = ArgReplacer(foo, name)
                replacer.arg_pos = arg_pos
                old_value = replacer.get_old_value(args, kwargs, default=default)
                assert old_value == getattr(foo, name)
                #replace arg

# Generated at 2022-06-12 14:23:54.961125
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import inspect

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def _initialize(self, a=4):
            self.a = a
    class B(A):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def _initialize(self, a, b):
            super(B, self)._initialize(a)
            self.b = b
    class C(B):
        @classmethod
        def configurable_default(cls):
            return C


# Generated at 2022-06-12 14:24:03.577853
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(a, b):
        pass
    def func2(a, b, c):
        pass
    def func3(a, b, c, d=1):
        pass

    ret1 = ArgReplacer(func1, "a").get_old_value((1, 2), {})
    ret2 = ArgReplacer(func1, "a").get_old_value((1, 2), {}, default=None)
    ret3 = ArgReplacer(func1, "a").get_old_value((1, 2, 3), {})
    ret4 = ArgReplacer(func1, "a").get_old_value((1, 2, 3), {}, default=None)

    ret5 = ArgReplacer(func2, "a").get_old_value((1, 2), {})
    ret6 = Arg

# Generated at 2022-06-12 14:24:11.162338
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def myfunc(a, b = 1, c = 3):
        pass
    arg_replacer = ArgReplacer(myfunc, "a")
    assert arg_replacer.get_old_value((1, 2, 3), {'b':1, 'a':2}, default = None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b':1, 'c':3}, default = None) == None
    arg_replacer = ArgReplacer(myfunc, "d")
    assert arg_replacer.get_old_value((1, 2, 3), {'b':1, 'c':3}, default = None) == None

# Generated at 2022-06-12 14:24:23.146888
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class SomeObject(Configurable):
        def configurable_base(cls):
            return cls
        def configurable_default(cls):
            return cls
        def initialize(self):
            self.initialized = True

    o = SomeObject()
    assert o.initialized

    SomeObject.configure(SomeObject)
    o = SomeObject()
    assert o.initialized

    class SomeOtherObject(SomeObject):
        def initialize(self):
            self.initialized = False

    o = SomeOtherObject()
    assert not o.initialized

    SomeOtherObject.configure(None)
    o = SomeOtherObject()
    assert o.initialized

    SomeOtherObject.configure(SomeOtherObject, initialized=False)
    o = SomeOtherObject()
    assert not o.initialized


# Generated at 2022-06-12 14:24:28.046398
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.ioloop import Configurable
    import pytest
    impl = Configurable.configurable_default()
    Configurable.configure(impl)
    instance = Configurable()
    assert isinstance(instance, impl)
    impl2 = type("impl2", (impl,), {})
    with pytest.raises(ValueError):
        Configurable.configure(impl2)
        instance = Configurable()
    assert issubclass(impl2, impl)



# Generated at 2022-06-12 14:25:46.047468
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test(a, b, c=0, d=0):
        print("a: %r, b: %r, c: %r, d: %r" % (a, b, c, d))

    replacer = ArgReplacer(test, "c")
    pos_args = (1, 2)
    kwargs = {"d": 3}

    print("Before:", pos_args, kwargs)
    old_value, new_pos_args, new_kwargs = replacer.replace(100, pos_args, kwargs)
    print("After:", new_pos_args, new_kwargs)
    test(*new_pos_args, **new_kwargs)



# Generated at 2022-06-12 14:25:56.177385
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    import json
    from sys import version_info
    from typing import Any, Callable, Sequence, Union
    import warnings
    import pytest
    from tornado.util import ArgReplacer

    def test_func_func_code()-> Callable:
        def func(a: int, b: int, c: int) -> Any:
            pass
        func.func_code = getattr(func, 'func_code') # type: ignore

        return func

    def test_func() -> Callable:
        def func(a: int, b: int, c: int) -> Any:
            pass
        return func

    if version_info[0] == 2: #type: ignore
        # Python 2.x
        test_func = test_func_func_code()

# Generated at 2022-06-12 14:26:05.810464
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from tornado.platform.auto import Waker

    class IOStream(Configurable):
        @classmethod
        def configurable_base(cls):
            return IOStream

        @classmethod
        def configurable_default(cls):
            return IOStream

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    IOStream._configure_mock = IOStream.configure

    def mock_configure(impl, **kwargs):
        # the code in this method is duplicated from configure, but
        # trying to call the parent method causes a stack overflow
        base = cls.configurable_base()
        if isinstance(impl, str):
            impl = typing.cast(Type[Configurable], import_object(impl))
       

# Generated at 2022-06-12 14:26:11.395169
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(bar=None):
        return bar
    new_value = 'value'
    args = tuple()
    kwargs = {'bar': 'bar'}
    argument_replacer = ArgReplacer(foo,'bar')
    result = argument_replacer.replace(new_value,args,kwargs)
    assert result[0] == 'bar' and new_value in result[1] and new_value in result[2]

# Generated at 2022-06-12 14:26:19.241580
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
        class TempException(Exception):
            pass
        try:
            raise TempException
        except:
            f = ArgReplacer(lambda x, y: 42, "x")
            new_value = f.replace("new_value", (1,), {})
            # new_value is (None, (<class '__main__.TempException'>,), {'x': 'new_value'})
            # (...) is a tuple of multiple elements
            # {..} is a dictionary
            # *args is a tuple of non-keyword arguments
            # **kwargs is a dictionary of keyword arguments
            assert new_value == (1, (TempException,), {'x': 'new_value'})


# Generated at 2022-06-12 14:26:26.781451
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=1, **kwargs):
        pass
    argreplacer = ArgReplacer(foo, 'b')
    assert argreplacer.replace(new_value=2, args=[1], kwargs={'c': 3}) == (None, [1, 2], {'c': 3})
    assert argreplacer.replace(new_value=2, args=[1, 3], kwargs={'d': 4}) == (3, [1, 2], {'d': 4})
    assert argreplacer.replace(new_value=2, args=[1, 3], kwargs={'b': 4}) == (4, [1, 3], {'b': 2})