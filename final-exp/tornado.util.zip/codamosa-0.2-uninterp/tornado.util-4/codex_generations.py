

# Generated at 2022-06-18 10:59:51.549231
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a):
            self.a = a

    a = A(a=1)
    assert a.a == 1
    assert isinstance(a, A)



# Generated at 2022-06-18 10:59:53.923149
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("test")
    except:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:00:04.926959
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {'c': 4})
    assert old_value == 2
    assert args == (1, 'new_value', 3)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {'c': 4})
    assert old_value == 2
    assert args == (1, 'new_value')
    assert kwargs == {'c': 4}

# Generated at 2022-06-18 11:00:17.798937
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2), {}) == 2
    assert arg_replacer.get_old_value((1, 2), {}, default=4) == 2
    assert arg_replacer.get_old_value((1,), {}) == None
    assert arg_replacer.get_old_value((1,), {}, default=4) == 4

# Generated at 2022-06-18 11:00:22.419855
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1, "error")
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-18 11:00:29.539299
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    Base.configure(None)
    Sub.configure

# Generated at 2022-06-18 11:00:32.736328
# Unit test for function import_object
def test_import_object():
    import_object('tornado.escape')
    import_object('tornado.escape.utf8')
    import_object('tornado')
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "import_object should raise ImportError"


# Generated at 2022-06-18 11:00:38.868038
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1,), {}, default=4) == 4
    assert arg_replacer.get_old_value((1,), {"b": 2}) == 2
    assert arg_replacer.get_old_value((1,), {"b": 2}, default=4) == 2
    assert arg_replacer.get_old_value((1,), {"c": 3}, default=4) == 4


# Generated at 2022-06-18 11:00:49.024504
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=None, d=None):
        pass
    ar = ArgReplacer(f, 'c')
    assert ar.get_old_value((1, 2), {'d': 4}) == None
    assert ar.get_old_value((1, 2), {'d': 4}, default=3) == 3
    assert ar.get_old_value((1, 2), {'c': 3, 'd': 4}) == 3
    assert ar.get_old_value((1, 2, 3), {'d': 4}) == 3
    assert ar.get_old_value((1, 2, 3), {'c': 4, 'd': 5}) == 4
    assert ar.get_old_value((1, 2, 3), {'c': 4, 'd': 5}, default=6) == 4

# Generated at 2022-06-18 11:00:59.857357
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = replacer.replace('new_b', ('a', 'b', 'c'), {})
    assert old_value == 'b'
    assert args == ('a', 'new_b', 'c')
    assert kwargs == {}
    old_value, args, kwargs = replacer.replace('new_b', ('a', 'b'), {})
    assert old_value == 'b'
    assert args == ('a', 'new_b')
    assert kwargs == {}
    old_value, args, kwargs = replacer.replace('new_b', ('a',), {})
    assert old_value == None
    assert args == ('a',)
   

# Generated at 2022-06-18 11:01:28.484392
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self):
            pass
    a = A()
    assert isinstance(a, A)
    assert a.initialize == a._initialize
    assert A.initialize == A._initialize


# Generated at 2022-06-18 11:01:37.183265
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        def initialize(self):
            pass

    class C(A):
        def initialize(self):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)


# Generated at 2022-06-18 11:01:44.040373
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {"c": 3}
    replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4, 3)
    assert kwargs == {"c": 3}



# Generated at 2022-06-18 11:01:55.837293
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    assert isinstance(D(), D)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    assert isinstance(D(), D)

    A.configure(D)
    assert isinstance

# Generated at 2022-06-18 11:02:03.613353
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1,), {"b": 2}) == 2
    assert arg_replacer.get_old_value((1,), {"b": 2, "c": 3}) == 2
    assert arg_replacer.get_old_value((1,), {"c": 3}) is None
    assert arg_replacer.get_old_value((1,), {"c": 3}, default=4) == 4


# Generated at 2022-06-18 11:02:15.180498
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A

# Generated at 2022-06-18 11:02:23.903258
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == None


# Generated at 2022-06-18 11:02:35.036866
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value is None
    assert args == ()
    assert kwargs

# Generated at 2022-06-18 11:02:46.949955
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, x):
            # type: (Any) -> None
            self.x = x

    class B(A):
        def initialize(self, x, y):
            # type: (Any, Any) -> None
            self.y = y
            super(B, self).initialize(x)

    class C(A):
        def initialize(self, x, z):
            # type: (Any, Any) -> None
            self.z = z

# Generated at 2022-06-18 11:02:52.313594
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value is None
    assert args == ()
    assert kw

# Generated at 2022-06-18 11:03:12.502951
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Default

    class Default(Base):
        pass

    class Impl(Base):
        pass

    Base.configure(Impl)
    assert Base() is not None
    assert isinstance(Base(), Impl)

    Base.configure(None)
    assert Base() is not None
    assert isinstance(Base(), Default)

    Base.configure("tornado.util.Configurable")
    assert Base() is not None
    assert isinstance(Base(), Configurable)


# Generated at 2022-06-18 11:03:24.029640
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=4):
        pass
    ar = ArgReplacer(f, "c")
    assert ar.get_old_value((1, 2), {}) == 3
    assert ar.get_old_value((1, 2), {}, 5) == 3
    assert ar.get_old_value((1, 2), {"c": 6}) == 6
    assert ar.get_old_value((1, 2), {"c": 6}, 5) == 6
    assert ar.get_old_value((1, 2), {"d": 6}, 5) == 5
    assert ar.get_old_value((1, 2, 3), {}) == 3
    assert ar.get_old_value((1, 2, 3), {"c": 6}) == 3

# Generated at 2022-06-18 11:03:34.231344
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, arg):
            self.arg = arg

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, arg):
            self.arg = arg

    Base.configure(None)
    assert isinstance(Base(), BaseImpl)
    assert isinstance(Sub(), SubImpl)

    Base.configure(BaseImpl)
    assert isinstance(Base(), BaseImpl)

# Generated at 2022-06-18 11:03:42.971395
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, a):
            # type: (Any) -> None
            self.a = a

    class B(A):
        def initialize(self, b):
            # type: (Any) -> None
            self.b = b

    class C(A):
        def initialize(self, c):
            # type: (Any) -> None
            self.c = c

    A.configure(B)
    a = A(1)
    assert isinstance(a, B)


# Generated at 2022-06-18 11:03:49.881164
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
   

# Generated at 2022-06-18 11:03:59.725827
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    TestConfigurable.configure(None)
    assert TestConfigurable().args == ()
    assert TestConfigurable().kwargs == {}
    assert TestConfigurable(1, 2, foo=3).args == (1, 2)
    assert TestConfigurable(1, 2, foo=3).kwargs == {"foo": 3}

    TestConfigurable.configure(None, foo=42)
    assert TestConfigurable().args == ()

# Generated at 2022-06-18 11:04:10.943879
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=4, e=5):
        pass

    arg_replacer = ArgReplacer(func, 'd')
    old_value, args, kwargs = arg_replacer.replace(6, (1, 2, 3), {'e': 7})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {'e': 7, 'd': 6}

    old_value, args, kwargs = arg_replacer.replace(6, (1, 2, 3, 8), {'e': 7})
    assert old_value == 8
    assert args == (1, 2, 3, 6)
    assert kwargs == {'e': 7}



# Generated at 2022-06-18 11:04:18.494978
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None):
        pass

    arg_replacer = ArgReplacer(test_func, "b")
    old_value, args, kwargs = arg_replacer.replace(
        "new_b", ("a", "old_b"), {"c": "c"}
    )
    assert old_value == "old_b"
    assert args == ("a", "new_b")
    assert kwargs == {"c": "c"}

    old_value, args, kwargs = arg_replacer.replace(
        "new_b", ("a",), {"b": "old_b", "c": "c"}
    )
    assert old_value == "old_b"
    assert args == ("a",)

# Generated at 2022-06-18 11:04:25.974536
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "new_value", 3)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace("new_value", (1,), {"b": 2, "c": 3})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"b": "new_value", "c": 3}
    old_value, args, kwargs = arg_replacer.replace("new_value", (), {"b": 2, "c": 3})

# Generated at 2022-06-18 11:04:33.117473
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base
        def configurable_default(self):
            return Base
    class Impl(Base):
        pass
    Base.configure(Impl)
    assert isinstance(Base(), Impl)
    assert isinstance(Base(), Base)
    assert not isinstance(Base(), type)
    assert Base.configured_class() is Impl
    assert Base.configured_class() is Impl
    assert Base.configured_class() is Impl
    assert Base.configured_class() is Impl
    assert Base.configured_class() is Impl
    assert Base.configured_class() is Impl
    assert Base.configured_class() is Impl
    assert Base.configured_class() is Impl
    assert Base.configured_class() is Impl
    assert Base.config

# Generated at 2022-06-18 11:05:01.268247
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None):
        pass
    a = ArgReplacer(foo, "b")
    assert a.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert a.replace(1, (2,), {"b": 3, "c": 4}) == (3, (2,), {"b": 1, "c": 4})
    assert a.replace(1, (), {"b": 3, "c": 4}) == (3, (), {"b": 1, "c": 4})
    assert a.replace(1, (), {"c": 4}) == (None, (), {"b": 1, "c": 4})



# Generated at 2022-06-18 11:05:12.706808
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'d': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'d': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'b': 5})
    assert old_value == 5
    assert args == (2, 3, 4)
    assert kwargs == {'b': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old

# Generated at 2022-06-18 11:05:17.620864
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    TestConfigurable()


# Generated at 2022-06-18 11:05:28.358365
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}
    replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4, 3)
    assert kwargs == {'a': 1, 'b': 2, 'c': 3}
    old_value, args, kwargs = replacer.replace(5, args, kwargs)
    assert old_value == 4
    assert args == (1, 5, 3)
    assert kwargs == {'a': 1, 'b': 2, 'c': 3}
    old

# Generated at 2022-06-18 11:05:37.499881
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), A)

# Generated at 2022-06-18 11:05:49.323659
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 5}, default=4)

# Generated at 2022-06-18 11:05:58.935518
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)


# Generated at 2022-06-18 11:06:08.906674
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) is None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, None) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, 5) == 4


# Generated at 2022-06-18 11:06:16.124234
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.replace(1, (2, 3), {}) == (None, (2, 3), {'c': 1})
    assert arg_replacer.replace(1, (2, 3), {'c': 4}) == (4, (2, 3), {'c': 1})
    assert arg_replacer.replace(1, (2, 3), {'d': 4}) == (None, (2, 3), {'d': 4, 'c': 1})



# Generated at 2022-06-18 11:06:22.692530
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:07:10.374586
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    A.configure(None, c=3)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3

    A.configure(None, c=4)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 4

    A.configure(None, b=5, c=6)
    a = A(1, 2)
    assert a.a == 1


# Generated at 2022-06-18 11:07:21.348986
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 5})
    assert old_value == 2
    assert args == (1, 3)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'a': 4, 'c': 5})

# Generated at 2022-06-18 11:07:32.117717
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, *args, **kwargs):
            # type: (Any, Any) -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

   

# Generated at 2022-06-18 11:07:36.363377
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise IOError("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:07:40.817881
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

        def initialize(self, *args, **kwargs):
            pass

    class Impl(Base):
        pass

    Base.configure(Impl)
    assert isinstance(Base(), Impl)



# Generated at 2022-06-18 11:07:45.200647
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:07:51.902488
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    TestConfigurable.configure(None)
    c = TestConfigurable(1, 2, a=3, b=4)
    assert c.args == (1, 2)
    assert c.kwargs == {'a': 3, 'b': 4}
    TestConfigurable.configure(None, a=5, b=6)
    c = TestConfigurable(1, 2, a=3, b=4)
    assert c.args == (1, 2)

# Generated at 2022-06-18 11:08:03.471873
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}, 5) == 1

# Generated at 2022-06-18 11:08:13.624327
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass

    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4
   

# Generated at 2022-06-18 11:08:23.015194
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)
    assert not isinstance(a, C)

    A.configure(B)
    a = A()
    assert isinstance(a, A)
    assert isinstance(a, B)
    assert not isinstance(a, C)

    A.configure(C)
    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)
   