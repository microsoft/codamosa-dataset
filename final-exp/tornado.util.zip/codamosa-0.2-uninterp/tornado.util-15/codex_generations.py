

# Generated at 2022-06-18 11:00:00.895824
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:00:05.244702
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:00:18.216862
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    TestConfigurable.configure(None)
    c = TestConfigurable(1, 2, 3, foo=4, bar=5)
    assert c.args == (1, 2, 3)
    assert c.kwargs == {'foo': 4, 'bar': 5}
    TestConfigurable.configure(None, foo=6, bar=7)
    c = TestConfigurable(1, 2, 3, foo=4, bar=5)
    assert c.args == (1, 2, 3)
    assert c.kw

# Generated at 2022-06-18 11:00:22.384314
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
        assert False, "expected ImportError"
    except ImportError:
        pass



# Generated at 2022-06-18 11:00:29.510304
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, *args, **kwargs):
            # type: (Any, Any) -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)

    A.config

# Generated at 2022-06-18 11:00:36.297401
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock
    import typing
    import functools
    import sys
    import os
    import io
    import contextlib
    import types
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc

# Generated at 2022-06-18 11:00:43.462026
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}, None) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5


# Generated at 2022-06-18 11:00:55.705242
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'c': 3}
    replacer = ArgReplacer(f, 'b')
    old_value, new_args, new_kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert new_args == (1, 4, 3)
    assert new_kwargs == {'c': 3}
    old_value, new_args, new_kwargs = replacer.replace(5, args, {})
    assert old_value is None
    assert new_args == (1, 2, 3)
    assert new_kwargs == {'b': 5, 'c': 3}

# Generated at 2022-06-18 11:00:59.131639
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:01:04.126150
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    test_configurable = TestConfigurable()
    assert isinstance(test_configurable, TestConfigurable)



# Generated at 2022-06-18 11:01:23.301172
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, "error")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:01:33.586254
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 5}, default=4)

# Generated at 2022-06-18 11:01:43.112718
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {"b": 3, "c": 4}) == (3, (2,), {"b": 1, "c": 4})
    assert arg_replacer.replace(1, (), {"b": 3, "c": 4}) == (3, (), {"b": 1, "c": 4})
    assert arg_replacer.replace(1, (), {"c": 4}) == (None, (), {"b": 1, "c": 4})



# Generated at 2022-06-18 11:01:54.893736
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        def initialize(self):
            pass

    class C(A):
        def initialize(self):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)


# Generated at 2022-06-18 11:02:04.074964
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base
        def configurable_default(self):
            return Base
    class Impl(Base):
        def initialize(self, a, b):
            self.a = a
            self.b = b
    Base.configure(Impl)
    assert isinstance(Base(), Impl)
    assert Base().a == Base().b == None
    assert Base(1, 2).a == 1
    assert Base(1, 2).b == 2
    Base.configure(None)
    assert isinstance(Base(), Base)
    assert Base().a == Base().b == None
    assert Base(1, 2).a == 1
    assert Base(1, 2).b == 2
    class Impl2(Base):
        def initialize(self, a, b):
            self

# Generated at 2022-06-18 11:02:15.617606
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A

# Generated at 2022-06-18 11:02:23.692053
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:02:29.534168
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)



# Generated at 2022-06-18 11:02:38.055135
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, default=5) == 2
    assert arg_replacer.get_old_value((1, 2), {"b": 4}) == 4
    assert arg_replacer.get_old_value((1, 2), {"b": 4}, default=5) == 4
    assert arg_replacer.get_old_value((1, 2), {}, default=5) == 5


# Generated at 2022-06-18 11:02:48.740938
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:03:06.161935
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self):
            pass

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self):
            pass

    class SubSub(Sub):
        @classmethod
        def configurable_base(cls):
            return SubSub

        @classmethod
        def configurable_default(cls):
            return SubSubImpl


# Generated at 2022-06-18 11:03:15.180018
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {'b': 3, 'c': 4}) == (3, (2,), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {'b': 3, 'c': 4}) == (3, (), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {}) == (None, (), {'b': 1})



# Generated at 2022-06-18 11:03:24.115810
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1,), {'b': 2, 'c': 4}) == 2
    assert arg_replacer.get_old_value((1,), {'c': 4}) == None
    assert arg_replacer.get_old_value((1,), {'c': 4}, default=5) == 5


# Generated at 2022-06-18 11:03:31.295451
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {}, None) == None
    assert arg_replacer.get_old_value((1, 2), {}, 'default') == 'default'


# Generated at 2022-06-18 11:03:41.418836
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock
    import sys
    import os
    import io
    import types
    import tempfile
    import functools
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc

# Generated at 2022-06-18 11:03:53.541518
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1,), {'b': 4}, 5) == 4
    assert arg_replacer.get_old_value((1,), {}, 5) == 5


# Generated at 2022-06-18 11:04:01.135768
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception((1,))
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception([1])
    except Exception as e:
        assert errno_from_exception(e) == [1]



# Generated at 2022-06-18 11:04:12.887563
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'b': 2, 'c': 3}
    replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4, 3)
    assert kwargs == {'c': 3}
    replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = replacer.replace(5, args, kwargs)
    assert old_value == 3
    assert args == (1, 4, 3)
    assert kwargs == {'c': 5}
    replacer = ArgReplacer(func, 'a')

# Generated at 2022-06-18 11:04:19.981992
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, "test")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception((1, "test"))
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception({})
    except Exception as e:
        assert errno_from_exception(e) is None


# Generated at 2022-06-18 11:04:28.234165
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_torn

# Generated at 2022-06-18 11:04:44.523729
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 5})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 5})

# Generated at 2022-06-18 11:04:54.694591
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:05:02.617100
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        pass
    r = ArgReplacer(f, "c")
    assert r.replace("foo", (1, 2), {}) == (None, (1, 2), {"c": "foo"})
    assert r.replace("foo", (1, 2), {"c": "bar"}) == ("bar", (1, 2), {"c": "foo"})
    assert r.replace("foo", (1, 2, "bar"), {}) == ("bar", (1, 2, "foo"), {})
    assert r.replace("foo", (1, 2, "bar"), {"c": "baz"}) == (
        "baz",
        (1, 2, "foo"),
        {},
    )

# Generated at 2022-06-18 11:05:11.817610
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    replacer = ArgReplacer(f, "b")
    assert replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert replacer.replace(1, (2,), {"c": 4}) == (None, (2,), {"b": 1, "c": 4})
    assert replacer.replace(1, (), {"b": 3, "c": 4}) == (3, (), {"b": 1, "c": 4})



# Generated at 2022-06-18 11:05:20.303073
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, 'new_value', 3)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1,), {'b': 2, 'c': 3})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {'b': 'new_value', 'c': 3}
    old_value, args, kwargs = arg_replacer.replace('new_value', (), {'c': 3})
   

# Generated at 2022-06-18 11:05:30.918094
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)
    A.configure(None)
    assert isinstance(A(), A)

# Generated at 2022-06-18 11:05:39.169328
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'c': 4, 'b': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:05:44.631789
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            self.initialize(*args, **kwargs)
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    instance = TestConfigurableSubclass(1, 2, 3, foo=4, bar=5)
    assert instance.args == (1, 2, 3)
    assert instance.kwargs == {"foo": 4, "bar": 5}


# Generated at 2022-06-18 11:05:56.522695
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        def initialize(self):
            # type: () -> None
            pass

    class C(A):
        def initialize(self):
            # type: () -> None
            pass

    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)
    assert not isinstance(a, C)

    A.configure(B)
    a = A()
    assert isinstance(a, A)


# Generated at 2022-06-18 11:06:06.962069
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from unittest import mock
    from tornado.util import Configurable

    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Default

    class Default(Base):
        def initialize(self):
            self.initialized = True

    class Impl(Base):
        def initialize(self):
            self.initialized = True

    class TestConfigurable(unittest.TestCase):
        def test_configure(self):
            Base.configure(Impl)
            self.assertIs(Base.configured_class(), Impl)
            self.assertIs(Base().__class__, Impl)
            Base.configure(None)

# Generated at 2022-06-18 11:06:32.181408
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            super(TestConfigurable, self).__init__(*args, **kwargs)
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
        def initialize(self, *args, **kwargs):
            super(TestConfigurable, self).initialize(*args, **kwargs)
    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            super(TestConfigurableSubclass, self).initialize(*args, **kwargs)
    instance = TestConfigurableSubclass()
    assert isinstance(instance, TestConfigurableSubclass)
    assert isinstance(instance, TestConfigurable)

# Generated at 2022-06-18 11:06:36.075032
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:06:47.299629
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    A.configure(C)
    assert not isinstance(A(), B)
    assert isinstance(A(), C)
    A.configure(None)
    assert isinstance(A(), A)



# Generated at 2022-06-18 11:06:50.002229
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:07:00.890923
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value is None

# Generated at 2022-06-18 11:07:10.399840
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2), {})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {"c": "new_value"}
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2), {"c": "old_value"})
    assert old_value == "old_value"
    assert args == (1, 2)
    assert kwargs == {"c": "new_value"}

# Generated at 2022-06-18 11:07:17.107190
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-18 11:07:27.182560
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.config

# Generated at 2022-06-18 11:07:33.312346
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConfigurableTest(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableTest

        @classmethod
        def configurable_default(cls):
            return ConfigurableTest

        def initialize(self):
            pass

    class ConfigurableTestImpl(ConfigurableTest):
        def initialize(self):
            pass

    ConfigurableTest.configure(ConfigurableTestImpl)
    assert isinstance(ConfigurableTest(), ConfigurableTestImpl)



# Generated at 2022-06-18 11:07:44.798618
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a):
            self.a = a

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert A(1).a == 1
    assert isinstance(A(1), B)
    assert not isinstance(A(1), C)

    A.configure(C)
    assert A(2).a == 2
    assert not isinstance(A(2), B)
    assert isinstance(A(2), C)

    A.configure(None)
    assert A(3).a == 3
    assert not isinstance(A(3), B)
    assert not isinstance(A(3), C)

    A.configure("tornado.util.Configurable")
    assert A(4).a

# Generated at 2022-06-18 11:08:23.436718
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2), {"d": 4})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {"d": 4, "c": "new_value"}
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2, 3), {"d": 4})
    assert old_value == 3
    assert args == (1, 2, "new_value")
    assert kwargs == {"d": 4}

# Generated at 2022-06-18 11:08:29.572216
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import unittest

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(E):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(H):
        pass


# Generated at 2022-06-18 11:08:39.570473
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    arg_replacer = ArgReplacer(foo, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'a': 2, 'b': 3, 'c': 4})
    assert old

# Generated at 2022-06-18 11:08:45.490203
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:08:55.094840
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)
    A.configure(None)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)



# Generated at 2022-06-18 11:09:01.284277
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2, 3)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"



# Generated at 2022-06-18 11:09:07.422367
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(TestConfigurable)
    assert TestConfigurable.configured_class() == TestConfigurable



# Generated at 2022-06-18 11:09:18.397624
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.auto
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.auto
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.auto

# Generated at 2022-06-18 11:09:19.537285
# Unit test for function import_object
def test_import_object():
    import_object('tornado.test.util_test')



# Generated at 2022-06-18 11:09:30.078164
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c):
        pass
    arg_replacer = ArgReplacer(test_func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, None) == None
