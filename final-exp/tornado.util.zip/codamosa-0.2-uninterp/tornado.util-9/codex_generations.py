

# Generated at 2022-06-18 10:59:55.248195
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass

    arg_replacer = ArgReplacer(test_func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1,), {"b": 2}) == 2
    assert arg_replacer.get_old_value((1,), {"c": 2}) is None
    assert arg_replacer.get_old_value((1,), {"c": 2}, default=3) == 3


# Generated at 2022-06-18 11:00:07.228052
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'c': 4, 'b': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4, 'b': 3})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:00:19.669365
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {})
    assert old_value is None

# Generated at 2022-06-18 11:00:23.979863
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f():
        try:
            raise ValueError()
        except:
            raise_exc_info(sys.exc_info())
    try:
        f()
    except ValueError:
        pass
    else:
        raise Exception("did not re-raise")



# Generated at 2022-06-18 11:00:30.943506
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A

# Generated at 2022-06-18 11:00:37.575838
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, *args, **kwargs):
            pass
    class B(A):
        def initialize(self, *args, **kwargs):
            pass
    class C(A):
        def initialize(self, *args, **kwargs):
            pass
    class D(C):
        def initialize(self, *args, **kwargs):
            pass
    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)
    assert isinstance(D(), B)
    A.configure(C)
    assert isinstance(A(), C)

# Generated at 2022-06-18 11:00:40.921749
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, a, b):
            self.a = a
            self.b = b

    TestConfigurable.configure(None, c=3)
    x = TestConfigurable(1, b=2)
    assert x.a == 1
    assert x.b == 2
    assert x.c == 3



# Generated at 2022-06-18 11:00:52.537692
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}, 5) == 1

# Generated at 2022-06-18 11:00:58.407020
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:01:08.236303
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 2
    assert r.get_old_value((1,), {}) == None
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((), {"b": 2}) == 2
    assert r.get_old_value((), {"b": 2}, default=4) == 2

# Generated at 2022-06-18 11:01:30.560756
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

    class B(A):
        def initialize(self):
            pass

    class C(A):
        def initialize(self):
            pass

    A.configure(B)
    assert isinstance(A(), B)

    A.configure(C)
    assert isinstance(A(), C)

    A.configure(None)
    assert isinstance(A(), A)

    A.configure(B, foo=1)
    assert isinstance(A(), B)
    assert A.configured_class() is B
    assert A.configured_class().__impl_kwargs == {"foo": 1}

    A.configure(C, foo=2)

# Generated at 2022-06-18 11:01:34.630354
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 2}, default=4) == 2
    assert r.get_old_value((), {"b": 2}, default=4) == 2
    assert r.get_old_value((), {}, default=4) == 4

    assert r.replace(4, (1, 2, 3), {}) == (2, (1, 4, 3), {})

# Generated at 2022-06-18 11:01:45.301824
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.foo = 1
    assert d.foo == 1
    assert d['foo'] == 1
    assert getattr(d, 'foo') == 1
    assert d.bar is None
    assert d['bar'] is None
    assert getattr(d, 'bar') is None
    assert d.get('bar') is None
    assert d.get('bar', 2) == 2
    assert d.get('foo', 2) == 1
    assert d.get('foo') == 1
    assert d.foo == 1
    d.foo = 0
    assert d.foo == 0
    d['foo'] += 1
    assert d.foo == 1
    d.foo += 1
    assert d.foo == 2
    d.bar = []
    d.bar.append(42)
    assert d.bar

# Generated at 2022-06-18 11:01:57.145010
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(A(), A)
    assert not isinstance(A(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(A(), A)
    assert not isinstance(A(), B)

   

# Generated at 2022-06-18 11:01:59.664163
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError("foo")
    except:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:02:04.292285
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, a, b):
            self.a = a
            self.b = b
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2


# Generated at 2022-06-18 11:02:15.792907
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Impl(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Impl

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Impl

    class SubImpl(Impl):
        pass

    class SubSubImpl(SubImpl):
        pass

    # Test that the default implementation is used when nothing is configured.
    assert isinstance(Impl(), Impl)
    assert isinstance(SubImpl(), SubImpl)
    assert isinstance(SubSubImpl(), SubSubImpl)

    # Test that the configured implementation is used.
    Impl.configure(SubImpl)
    assert isinstance(Impl(), SubImpl)
    assert isinstance(SubImpl(), SubImpl)


# Generated at 2022-06-18 11:02:18.349386
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise Exception("foo")
    except Exception:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:02:24.878748
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    tc = TestConfigurable(1, 2, 3, foo=4, bar=5)
    assert tc.args == (1, 2, 3)
    assert tc.kwargs == {"foo": 4, "bar": 5}



# Generated at 2022-06-18 11:02:35.524679
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:02:53.356594
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 1
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 1
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, default=5) == 1
    assert arg_replacer.get_old_value((1, 2), {}) == 1
    assert arg_replacer.get_old_value((1, 2), {}, default=5) == 1
    assert arg_replacer.get_old_value((1,), {'c': 4}) == 1
    assert arg_replacer.get_old

# Generated at 2022-06-18 11:03:04.226367
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2, 3), {'d': 4})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {'d': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2, 3), {})
    assert old_value is None
    assert args == (1, 2, 3)
    assert kwargs == {'d': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {})
    assert old_value is None

# Generated at 2022-06-18 11:03:08.728162
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d["x"] == 1
    assert getattr(d, "x") == 1
    assert d.y == AttributeError
    assert d["y"] == KeyError
    assert getattr(d, "y") == AttributeError



# Generated at 2022-06-18 11:03:19.856648
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)


# Generated at 2022-06-18 11:03:28.673793
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {'c': 2})
    assert old_value == 2
    assert args == (1, 2)
    assert kwargs == {'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {'d': 2})
    assert old_value is None
   

# Generated at 2022-06-18 11:03:37.079391
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, 4) == 3
    assert arg_replacer.get_old_value((1, 2), {}, 4) == 4


# Generated at 2022-06-18 11:03:41.802155
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2, 3)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"



# Generated at 2022-06-18 11:03:53.928689
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from tornado.util import Configurable
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
        def initialize(self):
            pass
    class B(A):
        def initialize(self):
            pass
    class C(A):
        def initialize(self):
            pass
    class D(C):
        def initialize(self):
            pass
    class E(C):
        def initialize(self):
            pass
    class F(E):
        def initialize(self):
            pass
    class G(E):
        def initialize(self):
            pass
    class H(G):
        def initialize(self):
            pass

# Generated at 2022-06-18 11:04:01.981668
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 2
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((), {"b": 2}, default=4) == 2
    assert r.get_old_value((), {}, default=4) == 4


# Generated at 2022-06-18 11:04:09.076916
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:04:28.814330
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, "")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception("")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:04:39.774775
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock
    import typing
    import functools
    import inspect
    import sys
    import types
    import builtins

    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurableImpl

        def initialize(self, *args, **kwargs):
            pass

    class TestConfigurableImpl(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass

    class TestConfigurableSubclass(TestConfigurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurableSubclass

        @classmethod
        def configurable_default(cls):
            return Test

# Generated at 2022-06-18 11:04:45.094998
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:04:55.295822
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    assert isinstance(B(), B)
    assert not isinstance(B(), C)
    assert isinstance(C(), C)
    assert not isinstance(C(), B)

    A.configure(C)


# Generated at 2022-06-18 11:05:03.011744
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a=None, b=None):
            self.a = a
            self.b = b

    A.configure(None, b=1)
    a = A(a=2)
    assert a.a == 2
    assert a.b == 1
    assert A().a is None
    assert A().b == 1

    class B(A):
        pass

    B.configure(None, b=2)
    assert A().b == 1
    assert B().b == 2

    # Test that the configuration is not shared between base and
    # subclasses.

# Generated at 2022-06-18 11:05:10.318989
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:05:19.667440
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    assert isinstance(B(), B)
    assert not isinstance(B(), C)
    assert isinstance(C(), C)
    assert not isinstance(C(), B)

    A.configure(C)

# Generated at 2022-06-18 11:05:30.284667
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class TestConfigurable(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return TestConfigurable

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            # type: (Any, Any) -> None
            pass

    TestConfigurable.configure(None)
    TestConfigurable.configure(None, a=1)
    TestConfigurable.configure(None, a=1, b=2)
    TestConfigurable.configure(None, a=1, b=2, c=3)
    TestConfigurable.configure(None, a=1, b=2, c=3, d=4)
   

# Generated at 2022-06-18 11:05:38.725841
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d["x"] == 1
    assert not hasattr(d, "y")
    assert "y" not in d
    d.y = 2
    assert d.y == 2
    assert d["y"] == 2
    assert hasattr(d, "y")
    assert "y" in d
    del d.y
    assert not hasattr(d, "y")
    assert "y" not in d
    d["z"] = 3
    assert d.z == 3
    assert d["z"] == 3
    assert hasattr(d, "z")
    assert "z" in d
    del d["z"]
    assert not hasattr(d, "z")
    assert "z"

# Generated at 2022-06-18 11:05:51.382834
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 4
    assert r.get_old_value((1, 2), {"b": 3}) == 3
    assert r.get_old_value((1, 2), {"b": 3}, default=4) == 3
    assert r.get_old_value((1, 2), {"c": 3}, default=4) == 4
    assert r.get_old_value((1,), {"b": 3, "c": 4}) == 3
    assert r

# Generated at 2022-06-18 11:06:07.294232
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {"b": 3}) == (3, (2,), {"b": 1})
    assert arg_replacer.replace(1, (), {"b": 3}) == (3, (), {"b": 1})
    assert arg_replacer.replace(1, (), {}) == (None, (), {"b": 1})



# Generated at 2022-06-18 11:06:16.348487
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.arg_pos == 1
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {"b": 2}) == 2
    assert r.get_old_value((1,), {"b": 2}, default=4) == 2
    assert r.get_old_value((1,), {}) is None
    assert r.get_old_value((1,), {}, default=4) == 4

    old_value, args, kwargs = r.replace(4, (1, 2, 3), {})
    assert old

# Generated at 2022-06-18 11:06:22.917227
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A

# Generated at 2022-06-18 11:06:33.432671
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=4) == 2

# Generated at 2022-06-18 11:06:44.471060
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2), {"c": 4}) == 4
    assert r.replace(5, (1, 2), {}) == (None, (1, 2), {"c": 5})
    assert r.replace(6, (1, 2), {"c": 4}) == (4, (1, 2), {"c": 6})
    assert r.replace(7, (1, 2, 3), {}) == (3, (1, 2, 7), {})

# Generated at 2022-06-18 11:06:52.581495
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None, d=None):
        pass
    args = (1, 2)
    kwargs = {'d': 4}
    replacer = ArgReplacer(foo, 'c')
    old_value, args, kwargs = replacer.replace(3, args, kwargs)
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'c': 3, 'd': 4}
    old_value, args, kwargs = replacer.replace(None, args, kwargs)
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {'d': 4}
    replacer = ArgReplacer(foo, 'b')
    old_value, args, kwargs = replacer

# Generated at 2022-06-18 11:07:04.570846
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c):
        pass
    arg_replacer = ArgReplacer(foo, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4
   

# Generated at 2022-06-18 11:07:12.442640
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b, c=3):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3

    A.configure(None, c=4)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 4

    A.configure(None, c=5, d=6)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a

# Generated at 2022-06-18 11:07:23.430580
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, arg):
            self.arg = arg

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, arg):
            self.arg = arg

    # The default implementation is used if nothing is configured.
    assert isinstance(Base(), BaseImpl)
    assert isinstance(Sub(), SubImpl)

    # The configured class is used instead of the default.

# Generated at 2022-06-18 11:07:29.333490
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:07:54.410814
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 6}, 5) == 6
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 6}) == 6
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 6}, 5) == 6
    assert arg_replacer.get_old_value((1, 2, 3, 7), {}, 5) == 7

# Generated at 2022-06-18 11:08:01.615882
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "Expected an import error"



# Generated at 2022-06-18 11:08:11.770636
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    old_value, args, kwargs = arg_replacer.replace("new_value", ("a", "b", "c"), {})
    assert old_value == "b"
    assert args == ("a", "new_value", "c")
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace("new_value", ("a", "b"), {})
    assert old_value == "b"
    assert args == ("a", "new_value")
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace("new_value", ("a",), {})

# Generated at 2022-06-18 11:08:20.237285
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    replacer = ArgReplacer(foo, "b")
    assert replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert replacer.replace(1, (2,), {"b": 3, "c": 4}) == (3, (2,), {"b": 1, "c": 4})
    assert replacer.replace(1, (), {"b": 3, "c": 4}) == (3, (), {"b": 1, "c": 4})
    assert replacer.replace(1, (), {"c": 4}) == (None, (), {"b": 1, "c": 4})



# Generated at 2022-06-18 11:08:25.440406
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    class TestConfigurableSubclass(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert isinstance(TestConfigurable(), TestConfigurableSubclass)



# Generated at 2022-06-18 11:08:37.026904
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(3, (1, 2, 3), {}) == (2, (1, 3, 3), {})
    assert arg_replacer.replace(3, (1, 2), {'c': 3}) == (2, (1, 3), {'c': 3})
    assert arg_replacer.replace(3, (1,), {'b': 2, 'c': 3}) == (2, (1,), {'b': 3, 'c': 3})
    assert arg_replacer.replace(3, (), {'a': 1, 'b': 2, 'c': 3}) == (2, (), {'a': 1, 'b': 3, 'c': 3})
   

# Generated at 2022-06-18 11:08:47.521537
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        def initialize(self):
            pass

    class C(A):
        def initialize(self):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    assert isinstance(B(), B)
    assert not isinstance(B(), C)
    assert isinstance(C(), C)
    assert not isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)

# Generated at 2022-06-18 11:08:54.062467
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(5, "error")
    except IOError as e:
        assert errno_from_exception(e) == 5
    try:
        raise IOError("error")
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:09:05.086676
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)

# Generated at 2022-06-18 11:09:16.642968
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, d=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {"c": 3}) == 3
    assert r.get_old_value((1, 2), {"c": 3}, 4) == 3
    assert r.get_old_value((1, 2), {"d": 3}, 4) == 4
    assert r.replace(5, (1, 2), {}) == (None, (1, 2), {"c": 5})
    assert r.replace(5, (1, 2), {"c": 6}) == (6, (1, 2), {"c": 5})