

# Generated at 2022-06-18 10:59:55.390358
# Unit test for function import_object
def test_import_object():
    import_object('tornado.escape')
    import_object('tornado.escape.utf8')
    import_object('tornado')
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass

# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.

# Generated at 2022-06-18 10:59:58.355494
# Unit test for function import_object
def test_import_object():
    import_object('tornado.test.util_test')



# Generated at 2022-06-18 11:00:07.271574
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 4}) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3, 'd': 4}) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 3, 'd': 4}, default=5) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 4}, default=5) == 5


# Generated at 2022-06-18 11:00:19.763517
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

    TestConfigurable.configure(None)
    assert TestConfigurable().__class__ == TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert TestConfigurable().__class__ == TestConfigurableSubclass

    class TestConfigurableSubclass2(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass2)
    assert TestConfigurable().__class__ == TestConfigurableSubclass2


# Generated at 2022-06-18 11:00:30.286387
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 1
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2), {'a': 4}) == 1
    assert arg_replacer.get_

# Generated at 2022-06-18 11:00:36.947143
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Default

        def initialize(self, *args, **kwargs):
            pass

    class Default(Base):
        pass

    class Subclass(Base):
        pass

    class SubSubclass(Subclass):
        pass

    assert Base() is not None
    assert isinstance(Base(), Default)
    assert isinstance(Base(), Base)
    assert not isinstance(Base(), Subclass)
    assert not isinstance(Base(), SubSubclass)

    Base.configure(Subclass)
    assert Base() is not None
    assert isinstance(Base(), Subclass)
    assert isinstance(Base(), Base)

# Generated at 2022-06-18 11:00:41.857898
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c=1):
            self.a = a
            self.b = b
            self.c = c

    class B(A):
        pass

    class C(A):
        def initialize(self, a, b, c=2):
            super(C, self).initialize(a, b, c=c)

    class D(A):
        def initialize(self, a, b, c=3):
            super(D, self).initialize(a, b, c=c)

    class E(A):
        def initialize(self, a, b, c=4):
            super(E, self).initialize(a, b, c=c)


# Generated at 2022-06-18 11:00:46.596673
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
        assert False
    except ImportError:
        pass



# Generated at 2022-06-18 11:00:58.613364
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1,), {'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((), {'c': 3}, default=4) == 4

# Generated at 2022-06-18 11:01:03.431850
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
        assert False
    except ImportError:
        pass



# Generated at 2022-06-18 11:01:34.892541
# Unit test for function import_object
def test_import_object():
    # Test import_object with a module
    assert import_object("sys") is sys
    # Test import_object with a module and attribute
    assert import_object("sys.version_info") is sys.version_info
    # Test import_object with a module, attribute, and attribute
    assert import_object("sys.version_info.major") == sys.version_info.major
    # Test import_object with a non-existent module
    try:
        import_object("nonexistent_module")
        assert False, "import_object should have raised ImportError"
    except ImportError:
        pass
    # Test import_object with a non-existent module and attribute
    try:
        import_object("sys.nonexistent_attribute")
        assert False, "import_object should have raised ImportError"
    except ImportError:
        pass

# Generated at 2022-06-18 11:01:45.709914
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, a, b, c):
            # type: (Any, Any, Any) -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)
    A.configure(None)


# Generated at 2022-06-18 11:01:57.491498
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {"c": 3}) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert arg_replacer.get_old_value((1, 2), {"d": 3}, default=4) == 4
    assert arg_replacer.get_old_value((1, 2), {"d": 3}) is None


# Generated at 2022-06-18 11:02:05.584395
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c):
        pass

    r = ArgReplacer(func, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 5}) == 5
    assert r.get_old_value((1,), {"b": 5}, default=4) == 5
    assert r.get_old_value((1,), {"c": 5}) == None
    assert r.get_old_value((1,), {"c": 5}, default=4) == 4

# Generated at 2022-06-18 11:02:16.804239
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    class B(A):
        def initialize(self):
            pass
    class C(A):
        def initialize(self):
            pass
    A.configure(B)
    assert isinstance(A(), B)
    A.configure(C)
    assert isinstance(A(), C)
    A.configure(None)
    assert isinstance(A(), A)
    A.configure(B, x=1)
    assert isinstance(A(), B)
    assert A.configured_class() is B
    assert A.configured_class().__impl_kwargs == {'x': 1}
    A.configure(C, x=2)

# Generated at 2022-06-18 11:02:25.132059
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)



# Generated at 2022-06-18 11:02:35.550939
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    A.configure(None, c=1)
    a = A(2, 3)
    assert a.a == 2
    assert a.b == 3
    assert a.c == 1

    A.configure(None, c=2)
    a = A(2, 3)
    assert a.a == 2
    assert a.b == 3
    assert a.c == 2

    A.configure(None, c=3)

# Generated at 2022-06-18 11:02:47.280780
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b=1):
            self.a = a
            self.b = b

    A.configure(None, b=2)
    a = A(3)
    assert a.a == 3
    assert a.b == 2

    A.configure(None, b=4)
    a = A(5)
    assert a.a == 5
    assert a.b == 4

    A.configure(None)
    a = A(6, b=7)
    assert a.a == 6
    assert a.b == 7

    A.configure(None, b=8)


# Generated at 2022-06-18 11:02:58.094904
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    class B(A):
        def configurable_base(self):
            return B
        def configurable_default(self):
            return B
    class C(A):
        def configurable_base(self):
            return C
        def configurable_default(self):
            return C
    class D(B, C):
        def configurable_base(self):
            return D
        def configurable_default(self):
            return D
    class E(D):
        def configurable_base(self):
            return E
        def configurable_default(self):
            return E
    class F(E):
        def configurable_base(self):
            return F


# Generated at 2022-06-18 11:03:08.211019
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.select import SelectIOLoop
    from tornado.platform.twisted import TwistedIOLoop
    from tornado.platform.auto import Waker
    from tornado.platform.auto import _configured_class
    from tornado.platform.auto import _save_configuration
    from tornado.platform.auto import _restore_configuration
    from tornado.platform.auto import _set_configuration
    from tornado.platform.auto import _reset_configuration
    from tornado.platform.auto import _test_configuration
    from tornado.platform.auto import _test_configuration_for_test
    from tornado.platform.auto import _test_file
    from tornado.platform.auto import _test_file_for_test


# Generated at 2022-06-18 11:03:29.383610
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    A.configure(C)
    assert isinstance(A(), C)



# Generated at 2022-06-18 11:03:39.882742
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'c': 4, 'b': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:03:46.535671
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(5, "error")
    except IOError as e:
        assert errno_from_exception(e) == 5
    try:
        raise IOError("error")
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:03:57.500219
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    old_value, args, kwargs = arg_replacer.replace(
        "new_value", (1, 2, 3), {"c": 4}
    )
    assert old_value == 2
    assert args == (1, "new_value", 3)
    assert kwargs == {"c": 4}

    old_value, args, kwargs = arg_replacer.replace(
        "new_value", (1,), {"b": 2, "c": 4}
    )
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"b": "new_value", "c": 4}

    old_value, args, k

# Generated at 2022-06-18 11:04:02.150708
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    a = A(1, 2, 3, foo=4, bar=5)
    assert a.args == (1, 2, 3)
    assert a.kwargs == {"foo": 4, "bar": 5}


# Generated at 2022-06-18 11:04:13.452896
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2), {}) == 2
    assert arg_replacer.get_old_value((1, 2), {}, default=4) == 2
    assert arg_replacer.get_old_value((1,), {}) == None
    assert arg_replacer.get_old_value((1,), {}, default=4) == 4

# Generated at 2022-06-18 11:04:20.122157
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:04:24.775281
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2, 3)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"



# Generated at 2022-06-18 11:04:32.342570
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception((1,))
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception((1, 2))
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception({})
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:04:42.574917
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception((1,))
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception((1, 2))
    except Exception as e:
        assert errno_from_exception(e) == 1


# Generated at 2022-06-18 11:05:21.459094
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:05:31.684237
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {"c": 4, "b": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:05:36.152777
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    TestConfigurable()



# Generated at 2022-06-18 11:05:47.504849
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3
    class B(A):
        def initialize(self, a, b, c, d):
            super(B, self).initialize(a, b, c)
            self.d = d
        @classmethod
        def configurable_base(cls):
            return A

# Generated at 2022-06-18 11:05:57.443821
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, **kwargs):
            pass

    class B(A):
        def initialize(self, **kwargs):
            pass

    class C(A):
        def initialize(self, **kwargs):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:06:08.140023
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, a, b, c=3):
            self.a = a
            self.b = b
            self.c = c
    A.configure(None, c=4)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 4
    a = A(1, 2, c=5)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 5
    class B(A):
        def initialize(self, a, b, c=3):
            self.a = a
            self.b = b
            self.c = c

# Generated at 2022-06-18 11:06:17.022467
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(2, (1, 3, 4), {})
    assert old_value == 3
    assert args == (1, 2, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(2, (1,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (1,)
    assert kwargs == {'b': 2, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(2, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:06:23.765413
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance

# Generated at 2022-06-18 11:06:34.665533
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(foo, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
   

# Generated at 2022-06-18 11:06:45.637445
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:07:56.441664
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfigurable(Configurable):
        def configurable_base(self):
            return MyConfigurable

        def configurable_default(self):
            return MyConfigurable

        def initialize(self, *args, **kwargs):
            pass

    # test that the initialize method is called
    class MyConfigurableImpl(MyConfigurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    MyConfigurable.configure(MyConfigurableImpl)
    obj = MyConfigurable(1, 2, foo=3, bar=4)
    assert obj.args == (1, 2)
    assert obj.kwargs == {"foo": 3, "bar": 4}



# Generated at 2022-06-18 11:08:06.846171
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    class B(A):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    class C(A):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    A.configure(B)
    assert isinstance(A(1, 2), B)
    assert isinstance(A(1, 2), A)
    assert not isinstance(A(1, 2), C)
    assert A(1, 2).a == 1
    assert A(1, 2).b == 2

    A.configure(C)

# Generated at 2022-06-18 11:08:17.413279
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Impl

        def initialize(self):
            # type: () -> None
            pass

    class Impl(Base):
        pass

    class SubImpl(Impl):
        pass

    class SubBase(Base):
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return SubImpl

    class SubSubImpl(SubImpl):
        pass

    assert isinstance(Base(), Impl)
    assert isinstance(SubBase(), Impl)
    Base.configure

# Generated at 2022-06-18 11:08:25.721138
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, default=5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=5) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, default=5) == 2

# Generated at 2022-06-18 11:08:36.634927
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 10}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 10}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 10}, default=100) == 100
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 10}, default=100) == 1


# Generated at 2022-06-18 11:08:47.021002
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.config

# Generated at 2022-06-18 11:08:58.264074
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value is None
    assert args

# Generated at 2022-06-18 11:09:10.558949
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {"c": 3}) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert arg_replacer.get_old_value((1, 2), {"d": 3}, default=4) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}) == 3

# Generated at 2022-06-18 11:09:21.083377
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    arg_replacer = ArgReplacer(foo, 'a')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value is None
    assert args == ()
    assert kw

# Generated at 2022-06-18 11:09:31.113688
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def __init__(self, a: int, b: int = 0) -> None:
            self.a = a
            self.b = b

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    A.configure(None)
    assert A(1).a == 1
    assert A(1).b == 0
    assert A(1, b=2).a == 1
    assert A(1, b=2).b == 2

    class B(A):
        def __init__(self, a: int, b: int = 0, c: int = 0) -> None:
            super(B, self).__init__(a, b)
            self.c = c

