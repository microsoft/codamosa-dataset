

# Generated at 2022-06-18 10:59:57.942942
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def initialize(self, a, b, c=None):
            pass
    assert Foo.configure.__doc__ == Configurable.configure.__doc__
    assert Foo.configured_class.__doc__ == Configurable.configured_class.__doc__
    assert Foo.configurable_base.__doc__ == Configurable.configurable_base.__doc__
    assert Foo.configurable_default.__doc__ == Configurable.configurable_default.__doc__
    assert Foo.initialize.__doc__ == Configurable.initialize.__doc__
    assert Foo.initialize.__func__ is Configurable.initialize.__func__
    assert Foo.initialize.__name__ == Configurable.initialize.__name__
    assert Foo.initialize.__qualname__ == Configurable

# Generated at 2022-06-18 11:00:03.099840
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self):
            pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert isinstance(TestConfigurable(), TestConfigurableSubclass)



# Generated at 2022-06-18 11:00:14.877597
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 2
    assert args == (1, 3)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 2

# Generated at 2022-06-18 11:00:24.682634
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.auto
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.curl
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.winscoket
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.auto

# Generated at 2022-06-18 11:00:33.957492
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.arg_pos is None
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2), {"c": 4}) == 4
    assert r.replace(5, (1, 2), {}) == (None, (1, 2), {"c": 5})
    assert r.replace(5, (1, 2), {"c": 6}) == (6, (1, 2), {"c": 5})

# Generated at 2022-06-18 11:00:39.639235
# Unit test for function import_object
def test_import_object():
    import_object('os')
    import_object('os.path')
    import_object('os.path.join')
    import_object('os.path.join.__doc__')
    import_object('os.path.join.__doc__.__doc__')
    import_object('os.path.join.__doc__.__doc__.__doc__')
    import_object('os.path.join.__doc__.__doc__.__doc__.__doc__')
    import_object('os.path.join.__doc__.__doc__.__doc__.__doc__.__doc__')
    import_object('os.path.join.__doc__.__doc__.__doc__.__doc__.__doc__.__doc__')

# Generated at 2022-06-18 11:00:43.960998
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
        assert False
    except ImportError:
        pass



# Generated at 2022-06-18 11:00:56.320955
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:01:03.302544
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, default=3) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 4}) == 4
    assert arg_replacer.get_old_value((1, 2), {"c": 4}, default=3) == 4
    assert arg_replacer.get_old_value((1, 2), {"d": 4}) is None
    assert arg_replacer.get_old_value((1, 2), {"d": 4}, default=3) == 3


# Generated at 2022-06-18 11:01:12.845622
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base
        def configurable_default(self):
            return Base
    class Impl(Base):
        def initialize(self):
            pass
    Base.configure(Impl)
    assert isinstance(Base(), Impl)
    assert isinstance(Base(), Base)
    Base.configure(None)
    assert isinstance(Base(), Base)
    class Impl2(Base):
        def initialize(self):
            pass
    Base.configure(Impl2)
    assert isinstance(Base(), Impl2)
    assert isinstance(Base(), Base)
    Base.configure(None)
    assert isinstance(Base(), Base)
    class Impl3(Base):
        def initialize(self):
            pass
    Base.configure(Impl3)

# Generated at 2022-06-18 11:01:31.885002
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value is None
    assert args

# Generated at 2022-06-18 11:01:41.763162
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, a, b=None):
            self.a = a
            self.b = b
    a = A(1)
    assert a.a == 1
    assert a.b is None
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    A.configure(None, b=3)
    a = A(1)
    assert a.a == 1
    assert a.b == 3
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    A.configure(None)
    a = A(1)

# Generated at 2022-06-18 11:01:50.702042
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, default=5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, default=5) == 5


# Generated at 2022-06-18 11:01:55.937982
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:01:57.089154
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError()
    except:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:02:05.332608
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:02:16.508276
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert A().__class__ is B
    assert B().__class__ is B
    assert C().__class__ is B

    A.configure(C)
    assert A().__class__ is C
    assert B().__class__ is B
    assert C().__class__ is C

    A.configure(None)
    assert A().__class__ is A
    assert B().__class__ is B
    assert C().__class__ is C

    A.config

# Generated at 2022-06-18 11:02:25.444249
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=4, e=5):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {}, default=9) == 3
    assert r.get_old_value((1, 2), {}, default=9) == 9
    assert r.get_old_value((1, 2), {"c": 3}) == 3
    assert r.get_old_value((1, 2), {"c": 3}, default=9) == 3
    assert r.get_old_value((1, 2), {"e": 6}, default=9) == 9


# Generated at 2022-06-18 11:02:28.278040
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 5}) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 6, 'd': 5}) == 6
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=7) == 7


# Generated at 2022-06-18 11:02:31.044367
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:03:12.116930
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d["x"] == 1
    assert getattr(d, "x") == 1
    assert d.y == AttributeError
    assert d["y"] == KeyError
    assert getattr(d, "y") == AttributeError



# Generated at 2022-06-18 11:03:23.633124
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) is None
   

# Generated at 2022-06-18 11:03:32.631447
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, "error")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError(1, "error")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError(1, "error")
    except Exception as e:
        e.errno = 2
        assert errno_from_exception(e) == 2



# Generated at 2022-06-18 11:03:42.257336
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace(4, args, kwargs)
    assert old_value == 3
    assert args == (1, 2, 4)
    assert kwargs == {'a': 1, 'b': 2, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert old_value == 4
    assert args == (1, 2, 5)

# Generated at 2022-06-18 11:03:51.890845
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 5


# Generated at 2022-06-18 11:04:00.901512
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_stream
    from tornado.platform.asyncio import to_tornado_stream
    from tornado.platform.asyncio import to_tornado_yieldable
    from tornado.platform.asyncio import to_asyncio_yieldable

# Generated at 2022-06-18 11:04:12.652195
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d=1, e=2):
        pass
    arg_replacer = ArgReplacer(foo, 'd')
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2, 3), {'e': 4})
    assert old_value == 1
    assert args == (1, 2, 3)
    assert kwargs == {'e': 4, 'd': 3}
    old_value, args, kwargs = arg_replacer.replace(5, (1, 2, 3), {'d': 4, 'e': 4})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {'e': 4, 'd': 5}
    old_value, args, kwargs = arg

# Generated at 2022-06-18 11:04:19.833751
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4



# Generated at 2022-06-18 11:04:28.148768
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return BaseImpl

        def initialize(self):
            # type: () -> None
            pass

    class BaseImpl(Base):
        pass

    class Subclass(Base):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Subclass

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return SubclassImpl

    class SubclassImpl(Subclass):
        pass

   

# Generated at 2022-06-18 11:04:38.816726
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=4, e=5):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    assert arg_replacer.replace(6, (1, 2, 3), {}) == (4, (1, 2, 3), {'d': 6})
    assert arg_replacer.replace(6, (1, 2, 3), {'d': 4}) == (4, (1, 2, 3), {'d': 6})
    assert arg_replacer.replace(6, (1, 2, 3), {'d': 4, 'e': 5}) == (4, (1, 2, 3), {'d': 6, 'e': 5})

# Generated at 2022-06-18 11:05:16.538924
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:05:27.561695
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable.configurable_base() == TestConfigurable
    assert TestConfigurable.configurable_default() == TestConfigurable
    assert TestConfigurable.configure(None) is None
    assert TestConfigurable.configure(None, **{'a': 1}) is None
    assert TestConfigurable.configure(None, **{'a': 1}) is None

# Generated at 2022-06-18 11:05:36.953648
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'c': 4, 'b': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:05:41.236362
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-18 11:05:54.138686
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    replacer = ArgReplacer(func, "c")
    assert replacer.get_old_value((1, 2), {}) == 3
    assert replacer.get_old_value((1, 2), {}, 5) == 5
    assert replacer.get_old_value((1, 2), {"c": 6}) == 6
    assert replacer.get_old_value((1, 2), {"c": 6}, 5) == 6
    assert replacer.get_old_value((1, 2, 3), {}) == 3
    assert replacer.get_old_value((1, 2, 3), {}, 5) == 3
    assert replacer.get_old_value((1, 2, 3), {"c": 6}) == 6
    assert replacer

# Generated at 2022-06-18 11:06:00.999490
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.replace(1, (1, 2), {}) == (None, (1, 2), {'c': 1})
    assert arg_replacer.replace(1, (1, 2), {'c': 2}) == (2, (1, 2), {'c': 1})
    assert arg_replacer.replace(1, (1, 2, 3), {}) == (3, (1, 2, 1), {})
    assert arg_replacer.replace(1, (1, 2, 3), {'c': 2}) == (3, (1, 2, 1), {'c': 1})

# Generated at 2022-06-18 11:06:11.665731
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 5})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 5})

# Generated at 2022-06-18 11:06:18.399959
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, x, y):
            self.x = x
            self.y = y

    class B(A):
        def initialize(self, x, y, z):
            super(B, self).initialize(x, y)
            self.z = z

    A.configure(B, z=1)
    a = A(2, 3)
    assert isinstance(a, B)
    assert a.x == 2
    assert a.y == 3
    assert a.z == 1



# Generated at 2022-06-18 11:06:26.640038
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'b': 5, 'c': 6})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {'b': 5, 'c': 6}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'a': 5, 'c': 6})
    assert old_value == 5
    assert args == (2, 3, 4)
    assert kwargs == {'a': 1, 'c': 6}
    old_value, args, kwargs = arg_replacer

# Generated at 2022-06-18 11:06:37.063068
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def initialize(self, *args, **kwargs):
            pass
    assert TestConfigurable.configurable_base() is TestConfigurable
    assert TestConfigurable.configurable_default() is TestConfigurable
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configure(None) is None
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configure("tornado.util.Configurable") is None
    assert TestConfigurable.configured_class() is Configurable
    assert TestConfigurable.configure(TestConfigurable) is None
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configure(None, foo="bar") is None
    assert TestConfigurable.configured_

# Generated at 2022-06-18 11:07:50.703753
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

    TestConfigurable.configure(None)
    assert isinstance(TestConfigurable(), TestConfigurable)

    class TestConfigurableSubclass(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert isinstance(TestConfigurable(), TestConfigurableSubclass)

    class TestConfigurableSubclass2(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass2)

# Generated at 2022-06-18 11:08:02.075260
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 5}) == 5
    assert arg_replacer.get_old_value((1, 2), {"c": 5}, default=6) == 5
    assert arg_replacer.get_old_value((1, 2), {"d": 5}, default=6) == 6
    assert arg_replacer.get_old_value((1, 2, 5), {}) == 5
    assert arg_replacer.get_old_value((1, 2, 5), {"c": 6}) == 5

# Generated at 2022-06-18 11:08:12.229527
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4, 'b': 4, 'c': 4}) == 1

# Generated at 2022-06-18 11:08:21.745322
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)

# Generated at 2022-06-18 11:08:31.150502
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(foo, 'c')
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2), {'d': 4})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'d': 4, 'c': 3}
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2, 4), {'d': 4})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {'d': 4}



# Generated at 2022-06-18 11:08:35.236891
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.a = 1
    assert d.a == 1
    assert d['a'] == 1
    assert d.b == None
    assert d['b'] == None
    assert d.c == None
    assert d['c'] == None


# Generated at 2022-06-18 11:08:41.622257
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Foo

    f = Foo(1, 2, c=3)
    assert f.a == 1
    assert f.b == 2
    assert f.c == 3



# Generated at 2022-06-18 11:08:48.492433
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d["x"] == 1
    d["y"] = 2
    assert d.y == 2
    assert d["y"] == 2
    d.y = 3
    assert d.y == 3
    assert d["y"] == 3
    assert "z" not in d
    try:
        d.z
    except AttributeError:
        pass
    else:
        raise Exception("Expected AttributeError")



# Generated at 2022-06-18 11:08:59.673077
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        def initialize(self):
            pass

    class C(A):
        def initialize(self):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)


# Generated at 2022-06-18 11:09:10.643193
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            super(TestConfigurableSubclass, self).initialize(*args, **kwargs)
            self.args = args
            self.kwargs = kwargs

    TestConfigurable.configure(TestConfigurableSubclass)
    obj = TestConfigurable(1, 2, a=3, b=4)
    assert obj.args == (1, 2)
    assert obj.kwargs == {"a": 3, "b": 4}

