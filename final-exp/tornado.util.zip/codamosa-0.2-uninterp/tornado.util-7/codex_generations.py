

# Generated at 2022-06-18 10:59:55.792352
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert isinstance(TestConfigurable(), TestConfigurable)

    class TestConfigurableSubclass(TestConfigurable):
        pass

    assert isinstance(TestConfigurableSubclass(), TestConfigurableSubclass)

    class TestConfigurableSubclass2(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass2)
    assert isinstance(TestConfigurable(), TestConfigurableSubclass2)
    assert isinstance(TestConfigurableSubclass(), TestConfigurableSubclass)

   

# Generated at 2022-06-18 10:59:59.840603
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            pass
    A.configure(None)
    a = A()
    assert a.initialize() is None



# Generated at 2022-06-18 11:00:11.185060
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)

# Generated at 2022-06-18 11:00:20.079048
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class TestConfigurable(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return TestConfigurable

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return TestConfigurable

    class TestConfigurableImpl(TestConfigurable):
        def initialize(self, *args, **kwargs):
            # type: (Any, Any) -> None
            pass

    TestConfigurable.configure(TestConfigurableImpl)
    TestConfigurable()



# Generated at 2022-06-18 11:00:27.562047
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            super(TestConfigurable, self).__init__(*args, **kwargs)
            self.args = args
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

    TestConfigurable.configure(None)
    assert TestConfigurable(1, 2, 3, foo=4, bar=5).args == (1, 2, 3)
    assert TestConfigurable(1, 2, 3, foo=4, bar=5).kwargs == {"foo": 4, "bar": 5}



# Generated at 2022-06-18 11:00:30.423111
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:00:37.049577
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=4, e=5):
        pass

    r = ArgReplacer(f, "d")
    assert r.get_old_value((1, 2, 3), {}) == 4
    assert r.get_old_value((1, 2, 3), {}, default=6) == 6
    assert r.get_old_value((1, 2, 3), {"d": 7}) == 7
    assert r.get_old_value((1, 2, 3), {"e": 7}) == 4
    assert r.get_old_value((1, 2, 3), {"d": 7}, default=6) == 7
    assert r.get_old_value((1, 2, 3), {"e": 7}, default=6) == 6

    r = ArgReplacer(f, "e")
   

# Generated at 2022-06-18 11:00:46.739770
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3})
    assert old_value == 3
    assert args == ()
    assert kwargs == {"b": 1}
    old

# Generated at 2022-06-18 11:00:48.883999
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:00:59.823421
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock

    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurableImpl

    class TestConfigurableImpl(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass

    class TestConfigurableSubclass(TestConfigurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurableSubclass

        @classmethod
        def configurable_default(cls):
            return TestConfigurableSubclassImpl

    class TestConfigurableSubclassImpl(TestConfigurableSubclass):
        def initialize(self, *args, **kwargs):
            pass


# Generated at 2022-06-18 11:01:15.129192
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:01:21.847694
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 4
    assert r.get_old_value((1, 2), {"b": 3}) == 3
    assert r.get_old_value((1, 2), {"b": 3}, default=4) == 3
    assert r.get_old_value((1,), {"b": 3}, default=4) == 3
    assert r.get_old_value((1,), {}, default=4) == 4


# Generated at 2022-06-18 11:01:32.393293
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value is None
    assert args == (2,)
    assert kwargs == {"c": 4, "b": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:01:38.610458
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    tc = TestConfigurable(1, 2, 3, foo=4, bar=5)
    assert tc.args == (1, 2, 3)
    assert tc.kwargs == {"foo": 4, "bar": 5}



# Generated at 2022-06-18 11:01:46.112705
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:01:57.890443
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c):
        pass

    r = ArgReplacer(func, "b")
    assert r.arg_pos == 1
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1,), {"b": 2}) == 2
    assert r.get_old_value((1,), {"c": 3}) is None
    assert r.get_old_value((1,), {"c": 3}, default=4) == 4
    assert r.replace(4, (1, 2, 3), {}) == (2, (1, 4, 3), {})
    assert r.replace(4, (1,), {"b": 2}) == (2, (1,), {"b": 4})

# Generated at 2022-06-18 11:02:05.805415
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:02:10.559541
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=4, e=5):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    assert arg_replacer.get_old_value((1, 2, 3), {'e': 6}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'e': 6}, default=7) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'e': 6}, default=7) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'e': 6}, default=7) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'e': 6}, default=7) == 4
    assert arg_repl

# Generated at 2022-06-18 11:02:20.975728
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)
    assert not isinstance(a, C)

    A.configure(B)
    b = A()
    assert isinstance(b, A)
    assert isinstance(b, B)
    assert not isinstance(b, C)

    A.configure(C)
    c = A()
    assert isinstance(c, A)
    assert not isinstance

# Generated at 2022-06-18 11:02:25.418066
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a):
            self.a = a

    class B(A):
        def initialize(self, b):
            self.b = b

    class C(A):
        def initialize(self, c):
            self.c = c

    class D(A):
        def initialize(self, d):
            self.d = d

    class E(A):
        def initialize(self, e):
            self.e = e

    class F(A):
        def initialize(self, f):
            self.f = f


# Generated at 2022-06-18 11:02:45.888460
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {}) is None
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 5}) == 5
    assert r.get_old_value((1,), {"b": 5}, default=4) == 5

    assert r.replace(6, (1, 2, 3), {}) == (2, (1, 6, 3), {})

# Generated at 2022-06-18 11:02:56.653323
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class TestConfigurableSubclass(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)

    obj = TestConfigurable(1, 2, foo=3, bar=4)
    assert obj.__class__ is TestConfigurableSubclass
    assert obj.args == (1, 2)
    assert obj.kwargs == {"foo": 3, "bar": 4}

    obj = TestConfigurableSubclass(5, 6, foo=7, bar=8)
    assert obj.__class__ is Test

# Generated at 2022-06-18 11:03:06.664378
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (2, (1, 3, 4), {})
    assert arg_replacer.replace(1, (2, 3, 4), {'a': 5}) == (5, (2, 3, 4), {'a': 1})
    assert arg_replacer.replace(1, (2, 3), {'a': 5}) == (5, (2, 3), {'a': 1})
    assert arg_replacer.replace(1, (2, 3), {}) == (None, (2, 3), {'a': 1})

# Generated at 2022-06-18 11:03:12.459068
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'c': 3}
    replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 3
    assert args == (1, 2, 4)
    assert kwargs == {'c': 4}


# Generated at 2022-06-18 11:03:18.569006
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:03:28.104817
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    args = (1, 2, 3)
    kwargs = {'b': 2, 'c': 3}
    assert arg_replacer.get_old_value(args, kwargs) == 1
    assert arg_replacer.get_old_value(args, kwargs, default=4) == 1
    assert arg_replacer.get_old_value(args, kwargs, default=5) == 1
    assert arg_replacer.get_old_value(args, kwargs, default=6) == 1
    assert arg_replacer.get_old_value(args, kwargs, default=7) == 1

# Generated at 2022-06-18 11:03:39.470797
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        def initialize(self, *args, **kwargs):
            pass

    class C(A):
        def initialize(self, *args, **kwargs):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
   

# Generated at 2022-06-18 11:03:51.634220
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    A.configure(None)
    assert A() is not None
    assert A.configured_class() is A
    assert A.configure(None) is None
    assert A.configure(A) is None
    assert A.configure(A, a=1) is None
    assert A.configure(A, b=2) is None
    assert A.configure(A, a=1, b=2) is None
    assert A.configure(A, b=2, a=1) is None

# Generated at 2022-06-18 11:03:57.583167
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=5) == 5


# Generated at 2022-06-18 11:04:08.821126
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)
    assert a.__class__ is A

    class B(A):
        pass

    b = B()
    assert isinstance(b, B)
    assert b.__class__ is B

    A.configure(B)
    a = A()
    assert isinstance(a, A)
    assert a.__class__ is B

    A.configure(None)
    a = A()
    assert isinstance(a, A)
    assert a.__class__ is A

    A.configure("tornado.util.Configurable")

# Generated at 2022-06-18 11:04:32.229752
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def initialize(self, *args, **kwargs):
            pass
    assert TestConfigurable.configured_class() is TestConfigurable
    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    TestConfigurable.configure("tornado.util.Configurable")
    assert TestConfigurable.configured_class() is Configurable
    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    TestConfigurable.configure(Configurable)
    assert TestConfigurable.configured_class() is Configurable
    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    TestConfigurable.configure("tornado.util.Configurable")

# Generated at 2022-06-18 11:04:42.574325
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {"c": 3}) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3


# Generated at 2022-06-18 11:04:52.542739
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.foo = 42
    assert d.foo == 42
    assert d['foo'] == 42
    assert d.bar is None
    assert d['bar'] is None
    d['bar'] = 24
    assert d.bar == 24
    assert d['bar'] == 24
    d.bar = None
    assert d.bar is None
    assert d['bar'] is None
    assert 'foo' in d
    assert hasattr(d, 'foo')
    assert 'bar' in d
    assert hasattr(d, 'bar')
    assert 'baz' not in d
    assert not hasattr(d, 'baz')
    try:
        d.baz
    except AttributeError:
        pass

# Generated at 2022-06-18 11:05:01.110845
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace(5, (1, 2), {'d': 6})
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {'d': 6}
    old_value, args, kwargs = arg_replacer.replace(5, (1, 2, 3), {'d': 6})
    assert old_value == 3
    assert args == (1, 2, 5)
    assert kwargs == {'d': 6}
    old_value, args, kwargs = arg_replacer.replace(5, (1, 2), {})
    assert old_value

# Generated at 2022-06-18 11:05:10.165969
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c is None
    a = A(1, 2, c=3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-18 11:05:12.705558
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            pass
    a = A()
    assert isinstance(a, A)


# Generated at 2022-06-18 11:05:20.828707
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c
    A.configure(None, c=1)
    a = A(2, 3)
    assert a.a == 2
    assert a.b == 3
    assert a.c == 1
    a = A(2, 3, 4)
    assert a.a == 2
    assert a.b == 3
    assert a.c == 4
    A.configure(None, c=5)
    a = A(2, 3)
    assert a.a == 2
    assert a.b == 3
    assert a.c

# Generated at 2022-06-18 11:05:31.154730
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:05:33.166121
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

    class Impl(Base):
        pass

    Base.configure(Impl)
    assert Base() is not None



# Generated at 2022-06-18 11:05:39.228080
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(f, 'd')
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5


# Generated at 2022-06-18 11:05:57.052130
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c, d=4, e=5):
        pass

    arg_replacer = ArgReplacer(f, "d")
    old_value, args, kwargs = arg_replacer.replace(6, (1, 2, 3), {"e": 7})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {"e": 7, "d": 6}

    old_value, args, kwargs = arg_replacer.replace(6, (1, 2, 3, 8), {"e": 7})
    assert old_value == 8
    assert args == (1, 2, 3, 6)
    assert kwargs == {"e": 7}



# Generated at 2022-06-18 11:06:07.561989
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, 5) == 2
    assert arg_replacer.get_old_value((1,), {'b': 2, 'c': 4}) == 2

# Generated at 2022-06-18 11:06:16.548922
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=4):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3, 4), {}) == 2
    assert r.get_old_value((1, 2, 3, 4), {}, default=5) == 2
    assert r.get_old_value((1, 2), {}, default=5) == 2
    assert r.get_old_value((1, 2), {}) == 2
    assert r.get_old_value((1, 2), {}, default=5) == 2
    assert r.get_old_value((1,), {}, default=5) == 5
    assert r.get_old_value((), {"b": 2}, default=5) == 2
    assert r.get_

# Generated at 2022-06-18 11:06:23.222335
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=1, d=2):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 3}) == 1
    assert arg_replacer.get_old_value((1, 2), {'d': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1, 2), {'d': 3}, default=None) == 1
    assert arg_replacer.get_old_value((1, 2), {'d': 3}, default=5) == 1
    assert arg_replacer.get_old_value((1, 2), {'d': 3}, default=6) == 1

# Generated at 2022-06-18 11:06:33.845735
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Default

        def initialize(self, value):
            self.value = value

    class Default(Base):
        pass

    class Impl(Base):
        pass

    class TestConfigurable(AsyncTestCase):
        @gen_test
        def test_configurable(self):
            Base.configure(Impl)
            self.assertEqual(Base().value, "default")
            self.assertEqual(Impl().value, "default")
            Base.configure(None)
            self.assertEqual(Base().value, "default")

# Generated at 2022-06-18 11:06:44.867736
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:06:52.820679
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 5})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 5})
    assert old_

# Generated at 2022-06-18 11:06:59.734752
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(
        "new_value", (1, 2, 3), {"c": 4}
    )
    assert old_value == 2
    assert args == (1, "new_value", 3)
    assert kwargs == {"c": 4}



# Generated at 2022-06-18 11:07:05.720267
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    A.configure(None)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:07:10.427467
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:07:33.506040
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            super(TestConfigurable, self).__init__(*args, **kwargs)

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

    TestConfigurable.configure(None)
    assert TestConfigurable().__class__ == TestConfigurable



# Generated at 2022-06-18 11:07:44.894104
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c, d=1, e=2):
        pass
    arg_replacer = ArgReplacer(f, "d")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"e": 5}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 4, "e": 5}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"e": 5}, default=6) == 6
    arg_replacer = ArgReplacer(f, "e")
    assert arg_

# Generated at 2022-06-18 11:07:51.253858
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    assert isinstance(A(), A)
    assert isinstance(A(), Configurable)

    class B(A):
        pass

    assert isinstance(B(), B)
    assert isinstance(B(), A)
    assert isinstance(B(), Configurable)

    class C(A):
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return B



# Generated at 2022-06-18 11:08:02.753319
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # Test that the default implementation is used
    c = TestConfigurable()
    assert isinstance(c, TestConfigurable)
    assert c.args == ()
    assert c.kwargs == {}

    # Test that the default implementation can be overridden
    class TestConfigurableImpl(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableImpl)
    c = TestConfigurable()
    assert isinstance(c, TestConfigurableImpl)
    assert c.args

# Generated at 2022-06-18 11:08:12.229179
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        pass

    class TestConfigurableSubclass2(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert isinstance(TestConfigurable(), TestConfigurableSubclass)

    TestConfigurable.configure(TestConfigurableSubclass2)
    assert isinstance(TestConfigurable(), TestConfigurableSubclass2)

    TestConfigurable.configure(None)
    assert isinstance(TestConfigurable(), TestConfigurable)



# Generated at 2022-06-18 11:08:21.693837
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'a')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value is None
    assert args == ()
    assert kw

# Generated at 2022-06-18 11:08:32.625703
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
        def initialize(self):
            pass
    class B(A):
        pass
    class C(A):
        pass
    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)
    A.config

# Generated at 2022-06-18 11:08:37.106037
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    class Bar(Foo):
        pass

    assert Foo(1, 2).a == 1
    assert Foo(1, 2).b == 2
    assert Bar(1, 2).a == 1
    assert Bar(1, 2).b == 2



# Generated at 2022-06-18 11:08:44.101788
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) is None
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}, None) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}, 5) == 4


# Generated at 2022-06-18 11:08:54.949018
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:09:34.207205
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

    TestConfigurable.configure(None)
    assert TestConfigurable().args == ()
    assert TestConfigurable().kwargs == {}
    assert TestConfigurable(1, 2, foo=3).args == (1, 2)
    assert TestConfigurable(1, 2, foo=3).kwargs == {"foo": 3}

    class TestConfigurableSubclass(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert isinstance