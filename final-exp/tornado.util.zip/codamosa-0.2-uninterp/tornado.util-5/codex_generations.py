

# Generated at 2022-06-18 10:59:55.753217
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.twisted import TwistedIOLoop
    from tornado.platform.select import SelectIOLoop
    from tornado.platform.auto import AutoIOLoop
    from tornado.platform.epoll import EPollIOLoop
    from tornado.platform.kqueue import KQueueIOLoop
    from tornado.platform.poll import PollIOLoop
    from tornado.platform.windows import WindowsIOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.twisted import TwistedIOLoop
    from tornado.platform.select import SelectIOLoop
    from tornado.platform.auto import AutoIOLoop
    from tornado.platform.epoll import EPollIOLoop

# Generated at 2022-06-18 11:00:01.984450
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)

# Generated at 2022-06-18 11:00:09.477612
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1, "test")
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception("test")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:00:14.372731
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f():
        try:
            raise ValueError()
        except:
            raise_exc_info(sys.exc_info())
    try:
        f()
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"



# Generated at 2022-06-18 11:00:24.307339
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            pass
    class B(A):
        def initialize(self):
            pass
    class C(A):
        def initialize(self):
            pass
    class D(C):
        def initialize(self):
            pass
    class E(A):
        def initialize(self):
            pass
    A.configure(B)
    A.configure(C)
    A.configure(D)
    A.configure(E)
    assert A().__class__ == B
    assert A().__class__ == C
    assert A().__class__ == D
    assert A().__class__ == E
    assert A().__class__ == B
    assert A().__class__ == C
    assert A().__class__ == D
    assert A().__class__

# Generated at 2022-06-18 11:00:29.715240
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:36.483311
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    Base.configure(BaseImpl)
    Sub.configure(SubImpl)

# Generated at 2022-06-18 11:00:41.409191
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call

    class TestConfigurable(Configurable):
        def __new__(cls, *args, **kwargs):
            return super().__new__(cls)

        def initialize(self, *args, **kwargs):
            pass

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

    class TestConfigurableSubclass(TestConfigurable):
        pass

    class TestConfigurableSubclass2(TestConfigurable):
        pass


# Generated at 2022-06-18 11:00:53.087862
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    replacer = ArgReplacer(func, "c")
    old_value, args, kwargs = replacer.replace(1, (1, 2), {})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {"c": 1}
    old_value, args, kwargs = replacer.replace(1, (1, 2), {"c": 2})
    assert old_value == 2
    assert args == (1, 2)
    assert kwargs == {"c": 1}
    old_value, args, kwargs = replacer.replace(1, (1, 2, 3), {})
    assert old_value == 3
    assert args == (1, 2, 1)

# Generated at 2022-06-18 11:01:01.868749
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=4) == 2
    assert arg_replacer.get_old_value((1, 3), {'c': 3}) == None
    assert arg_replacer.get_old_value((1, 3), {'c': 3}, default=4) == 4
    assert arg_replacer.get_old_value((1, 3), {'b': 2, 'c': 3}) == 2

# Generated at 2022-06-18 11:01:18.042141
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    ar = ArgReplacer(func, "b")
    assert ar.get_old_value((1, 2, 3, 4), {}) == 2
    assert ar.get_old_value((1, 2, 3, 4), {}, default=5) == 2
    assert ar.get_old_value((1, 2, 3, 4), {"b": 5}) == 5
    assert ar.get_old_value((1, 2, 3, 4), {"b": 5}, default=6) == 5
    assert ar.get_old_value((1, 2, 3, 4), {"c": 5}) == 2
    assert ar.get_old_value((1, 2, 3, 4), {"c": 5}, default=6) == 2

# Generated at 2022-06-18 11:01:30.069968
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, *args, **kwargs):
            # type: (Any, Any) -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
   

# Generated at 2022-06-18 11:01:36.950663
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    ar = ArgReplacer(f, "b")
    assert ar.get_old_value((1, 2, 3), {}) == 2
    assert ar.get_old_value((1, 2, 3), {}, default=4) == 2
    assert ar.get_old_value((1, 2, 3), {"b": 5}) == 5
    assert ar.get_old_value((1, 2, 3), {"b": 5}, default=4) == 5
    assert ar.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4


# Generated at 2022-06-18 11:01:49.037221
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.replace("new_b", ("a", "b", "c"), {}) == ("b", ("a", "new_b", "c"), {})
    assert arg_replacer.replace("new_b", ("a", "b"), {"c": "c"}) == ("b", ("a", "new_b"), {"c": "c"})
    assert arg_replacer.replace("new_b", ("a",), {"b": "b", "c": "c"}) == ("b", ("a",), {"b": "new_b", "c": "c"})

# Generated at 2022-06-18 11:01:59.894591
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {"c": 4, "b": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:02:11.110940
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c=3):
            self.a = a
            self.b = b
            self.c = c

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B, c=4)
    assert isinstance(A(1, 2), B)
    assert A(1, 2).a == 1
    assert A(1, 2).b == 2
    assert A(1, 2).c == 4
    assert isinstance(A(1, 2, c=5), B)
    assert A(1, 2, c=5).a == 1
    assert A(1, 2, c=5).b == 2
    assert A(1, 2, c=5).c == 5

# Generated at 2022-06-18 11:02:15.697563
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        def initialize(self):
            # type: () -> None
            pass

    TestConfigurable.configure(None)
    assert isinstance(TestConfigurable(), TestConfigurable)

    class TestConfigurableSubclass(TestConfigurable):
        pass

    assert isinstance(TestConfigurableSubclass(), TestConfigurableSubclass)


# Generated at 2022-06-18 11:02:25.238793
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None, d=None):
        pass
    args = (1, 2)
    kwargs = {'d': 4}
    arg_replacer = ArgReplacer(test_func, 'c')
    old_value, args, kwargs = arg_replacer.replace(3, args, kwargs)
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'c': 3, 'd': 4}
    old_value, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {'c': 5, 'd': 4}
    old_value, args, kwargs = arg

# Generated at 2022-06-18 11:02:35.585874
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4, "b": 3})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"c": 4, "b": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"c": 4, "b": 3})
    assert old_value == 3
    assert args

# Generated at 2022-06-18 11:02:47.321938
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None):
        pass
    r = ArgReplacer(f, "b")
    assert r.arg_pos == 1
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {"b": 2}) == 2
    assert r.get_old_value((1,), {"b": 2}, default=4) == 2
    assert r.get_old_value((1,), {}) is None
    assert r.get_old_value((1,), {}, default=4) == 4

# Generated at 2022-06-18 11:03:00.362255
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:03:05.209190
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
    TestConfigurable.configure(None)
    test_configurable = TestConfigurable()
    test_configurable.initialize()


# Generated at 2022-06-18 11:03:09.133111
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:03:20.249193
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self):
            pass
    class B(A):
        def initialize(self):
            pass
    class C(A):
        def initialize(self):
            pass
    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A

# Generated at 2022-06-18 11:03:25.757274
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    A.configure(None, c=3)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-18 11:03:31.890938
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}
    arg_replacer = ArgReplacer(foo, 'b')
    old_value, args, kwargs = arg_replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4, 3)
    assert kwargs == {'a': 1, 'b': 2, 'c': 3}
    old_value, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert old_value == 4
    assert args == (1, 5, 3)

# Generated at 2022-06-18 11:03:39.154834
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    class TestConfigurableSubclass(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert isinstance(TestConfigurable(1, 2), TestConfigurableSubclass)
    assert isinstance(TestConfigurable(1, 2, 3), TestConfigurableSubclass)



# Generated at 2022-06-18 11:03:46.259303
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:03:57.378265
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

        def initialize(self):
            pass

    class BaseImpl(Base):
        pass

    class Subclass(Base):
        pass

    class SubclassImpl(Subclass):
        pass

    # Test that the default implementation is used when nothing is configured.
    assert isinstance(Base(), BaseImpl)
    assert isinstance(Subclass(), SubclassImpl)

    # Test that the configured class is used.
    Base.configure(BaseImpl)
    assert isinstance(Base(), BaseImpl)
    assert isinstance(Subclass(), SubclassImpl)

    # Test that the configured class is used for subclasses.

# Generated at 2022-06-18 11:04:04.684130
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:04:19.168198
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:04:23.618422
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d["foo"] = "bar"
    assert d.foo == "bar"
    assert d["foo"] == "bar"
    assert d.bar is None
    assert d["bar"] is None
    d.bar = "foo"
    assert d.bar == "foo"
    assert d["bar"] == "foo"



# Generated at 2022-06-18 11:04:31.436603
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    a = A()
    assert isinstance(a, A)

    class B(A):
        pass

    b = B()
    assert isinstance(b, B)

    class C(A):
        def initialize(self):
            pass

    c = C()
    assert isinstance(c, C)

    class D(A):
        def configurable_default(self):
            return C

    d = D()
    assert isinstance(d, C)

    A.configure(B)
    e = A()
    assert isinstance(e, B)

    A.configure(C)
    f = A()
   

# Generated at 2022-06-18 11:04:42.328017
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None):
        pass
    replacer = ArgReplacer(func, 'c')
    assert replacer.get_old_value((1, 2), {'d': 4}) == None
    assert replacer.get_old_value((1, 2), {'c': 3, 'd': 4}) == 3
    assert replacer.get_old_value((1, 2, 3), {'d': 4}) == 3
    assert replacer.get_old_value((1, 2, 3), {'c': 3, 'd': 4}) == 3
    assert replacer.get_old_value((1, 2), {'c': 3, 'd': 4}, default=5) == 3

# Generated at 2022-06-18 11:04:52.319530
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'b': 2, 'c': 3}
    replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4, 3)
    assert kwargs == {'c': 3}
    replacer = ArgReplacer(f, 'd')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value is None
    assert args == (1, 4, 3)
    assert kwargs == {'c': 3, 'd': 4}



# Generated at 2022-06-18 11:04:54.995750
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)



# Generated at 2022-06-18 11:05:02.815474
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, default=5) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, default=5) == 2
    assert arg_replacer.get_old_value((1,), {'b': 2, 'c': 4}) == 2

# Generated at 2022-06-18 11:05:15.155506
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)

# Generated at 2022-06-18 11:05:25.116798
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d["x"] == 1
    assert getattr(d, "x") == 1
    assert d.y is None
    assert d["y"] is None
    assert getattr(d, "y") is None
    assert not hasattr(d, "z")
    assert "z" not in d
    assert d.z is None
    assert d["z"] is None
    assert getattr(d, "z") is None
    d.z = 1
    assert hasattr(d, "z")
    assert "z" in d
    assert d.z == 1
    assert d["z"] == 1
    assert getattr(d, "z") == 1
    del d.z

# Generated at 2022-06-18 11:05:35.047419
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=4):
        pass
    arg_replacer = ArgReplacer(func, "d")
    assert arg_replacer.replace(5, (1, 2, 3), {}) == (4, (1, 2, 3), {})
    assert arg_replacer.replace(5, (1, 2, 3), {"d": 6}) == (6, (1, 2, 3), {"d": 5})
    assert arg_replacer.replace(5, (1, 2, 3, 7), {}) == (7, (1, 2, 3, 5), {})
    assert arg_replacer.replace(5, (1, 2, 3, 7), {"d": 6}) == (7, (1, 2, 3, 5), {})

# Generated at 2022-06-18 11:05:49.058637
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:05:58.774522
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

    class Impl(Base):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    Base.configure(Impl, b=2)
    assert Base(1).a == 1
    assert Base(1).b == 2
    assert Base(1, b=3).b == 3
    assert Base(1, b=3).a == 1
    assert Base().__class__ is Impl

    Base.configure(None)
    assert Base().__class__ is Base
    assert Base(1).a == 1
    assert Base(1).b == 2

    Base.configure(Impl, b=3)

# Generated at 2022-06-18 11:06:09.809165
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable.configure.__doc__ == Configurable.configure.__doc__
    assert TestConfigurable.configurable_base.__doc__ == Configurable.configurable_base.__doc__
    assert TestConfigurable.configurable_default.__doc__ == Configurable.configurable_default.__doc__
    assert TestConfigurable.configured_class.__doc__ == Configurable.configured_class.__doc__

# Generated at 2022-06-18 11:06:16.549955
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 5}, None) == 5
    assert arg_replacer.get_old_value((1, 2), {'c': 5}, 6) == 5
    assert arg_replacer.get_old_value((1, 2), {}, 6) == 6


# Generated at 2022-06-18 11:06:23.221831
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1, 2), {'b': 4}) == 4
    assert arg_replacer.get_old_value((1, 2), {'b': 4}, 5) == 4

# Generated at 2022-06-18 11:06:26.353194
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f():
        try:
            raise ValueError()
        except:
            raise_exc_info(sys.exc_info())
    try:
        f()
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"



# Generated at 2022-06-18 11:06:33.933514
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception((1, 2))
    except Exception as e:
        assert errno_from_exception(e) == (1, 2)



# Generated at 2022-06-18 11:06:44.910326
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable.configurable_base() == TestConfigurable
    assert TestConfigurable.configurable_default() == TestConfigurable
    assert TestConfigurable.configure(None) is None
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable.configurable_base() == TestConfigurable
    assert TestConfigurable.configurable_default() == TestConfigurable
    assert TestConfigurable.config

# Generated at 2022-06-18 11:06:52.859176
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1,), {}, 5) == 5
    assert arg_replacer.get_old_value((1,), {"b": 4}, 5) == 4


# Generated at 2022-06-18 11:07:04.879063
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {'b': 2})
    assert old_value == None
    assert args == (1, 2)
    assert kwargs == {'b': 2, 'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2, 3), {'b': 2})
    assert old_value == 3
    assert args == (1, 2, 1)
    assert kwargs == {'b': 2}

# Generated at 2022-06-18 11:07:33.120624
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, x, y):
            self.x = x
            self.y = y
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    a = A(1, 2)
    assert a.x == 1
    assert a.y == 2


# Generated at 2022-06-18 11:07:44.589792
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo
        def configurable_default(self):
            return Foo
        def initialize(self, *args, **kwargs):
            pass
    assert Foo.configured_class() is Foo
    Foo.configure(None)
    assert Foo.configured_class() is Foo
    Foo.configure(Foo)
    assert Foo.configured_class() is Foo
    Foo.configure(None, a=1)
    assert Foo.configured_class() is Foo
    Foo.configure(Foo, a=1)
    assert Foo.configured_class() is Foo
    Foo.configure(None, a=1, b=2)
    assert Foo.configured_class() is Foo

# Generated at 2022-06-18 11:07:50.906827
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2, 3)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"

    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError(1, "error")
    except Exception as e:
        assert errno_from_ex

# Generated at 2022-06-18 11:08:02.328561
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)
    assert not isinstance(a, C)

    A.configure(B)
    a = A()
    assert isinstance(a, A)
    assert isinstance(a, B)

# Generated at 2022-06-18 11:08:06.717138
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b=None):
            self.a = a
            self.b = b

    a = A(1, b=2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:08:17.358344
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, default=5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}, default=5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}) is None


# Generated at 2022-06-18 11:08:25.692517
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "new_value", 3)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace("new_value", (1,), {"b": 2})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"b": "new_value"}
    old_value, args, kwargs = arg_replacer.replace("new_value", (), {"b": 2})
    assert old_value == 2
    assert args == ()


# Generated at 2022-06-18 11:08:33.519271
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:08:43.156310
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}

    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:08:54.333042
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        pass
    args = (1, 2)
    kwargs = {'c': 3}
    replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4)
    assert kwargs == {'c': 3}
    old_value, args, kwargs = replacer.replace(5, args, kwargs)
    assert old_value == 4
    assert args == (1, 5)
    assert kwargs == {'c': 3}
    old_value, args, kwargs = replacer.replace(6, args, kwargs)
    assert old_value == 5
    assert args

# Generated at 2022-06-18 11:09:30.119681
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    c = TestConfigurable(1, 2, foo=3, bar=4)
    assert c.args == (1, 2)
    assert c.kwargs == {"foo": 3, "bar": 4}

