

# Generated at 2022-06-18 11:00:00.495042
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

        def initialize(self):
            pass

    C.configure(None)
    c = C()
    assert isinstance(c, C)

    class D(C):
        pass

    C.configure(D)
    c = C()
    assert isinstance(c, D)

    class E(C):
        def initialize(self, foo):
            self.foo = foo

    C.configure(E, foo=1)
    c = C()
    assert isinstance(c, E)
    assert c.foo == 1


# Generated at 2022-06-18 11:00:04.827442
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:00:17.676890
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    TestConfigurable.configure(TestConfigurable)
    TestConfigurable.configure(TestConfigurable, a=1)
    TestConfigurable.configure(TestConfigurable, a=1, b=2)
    TestConfigurable.configure(TestConfigurable, b=2, a=1)
    TestConfigurable.configure(TestConfigurable, b=2)
    TestConfigurable.configure(TestConfigurable, a=1)
    TestConfigurable.configure(None)
    TestConfigurable.configure(TestConfigurable)

# Generated at 2022-06-18 11:00:25.988810
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)

# Generated at 2022-06-18 11:00:34.782493
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'c': 'new_value'}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {'c': 'old_value'})
    assert old_value == 'old_value'
    assert args == (1, 2)
    assert kwargs == {'c': 'new_value'}

# Generated at 2022-06-18 11:00:43.168169
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, None) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5


# Generated at 2022-06-18 11:00:49.708623
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    assert A().__class__ is B

    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)
    assert A().__class__ is C

   

# Generated at 2022-06-18 11:00:56.564343
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2, 3)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        e = Exception()
        e.errno = 1
        raise e
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-18 11:01:07.023244
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B, b=1)
    assert isinstance(A(1), B)
    assert A(1).b == 1
    assert A(1, b=2).b == 2
    assert A(1, b=2).a == 1
    assert isinstance(A(1, b=2), B)
    A.configure(C, b=3)

# Generated at 2022-06-18 11:01:15.930240
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=5) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=5) == 1

# Generated at 2022-06-18 11:01:31.194936
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {'b': 3}) == (3, (2,), {'b': 1})
    assert arg_replacer.replace(1, (), {'b': 3}) == (3, (), {'b': 1})
    assert arg_replacer.replace(1, (), {}) == (None, (), {'b': 1})



# Generated at 2022-06-18 11:01:35.051391
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d['x'] == 1
    with pytest.raises(AttributeError):
        d.y
    with pytest.raises(KeyError):
        d['y']


# Generated at 2022-06-18 11:01:45.870891
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1,2), {}, None) == None
    assert arg_replacer.get_old_value((1,2), {'c':3}, None) == 3
    assert arg_replacer.get_old_value((1,2), {'c':3}, 4) == 3
    assert arg_replacer.get_old_value((1,2), {'c':3}, 4) == 3
    assert arg_replacer.get_old_value((1,2), {'c':3}, 4) == 3
    assert arg_replacer.get_old_value((1,2), {'c':3}, 4) == 3
    assert arg

# Generated at 2022-06-18 11:01:57.693173
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None):
        pass
    replacer = ArgReplacer(test_func, 'b')
    old_value, args, kwargs = replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value

# Generated at 2022-06-18 11:02:05.688413
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 5}) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=6) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=6) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 5}, default=6) == 5
    assert arg_replacer.get_old_value((1, 2), {'c': 5}) == 5

# Generated at 2022-06-18 11:02:11.657921
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:02:21.974445
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d):
        pass
    arg_replacer = ArgReplacer(foo, 'c')
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2, 4, 5), {'d': 6})
    assert old_value == 4
    assert args == (1, 2, 3, 5)
    assert kwargs == {'d': 6}
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2), {'c': 4, 'd': 6})
    assert old_value == 4
    assert args == (1, 2)
    assert kwargs == {'c': 3, 'd': 6}

# Generated at 2022-06-18 11:02:33.309150
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}, 5) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 5
    assert arg_replacer.get_old_value((1, 2), {'a': 4}) == 1
    assert arg

# Generated at 2022-06-18 11:02:41.679305
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:02:46.949522
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:03:00.486666
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 5}, default=4) == 5
    assert r.replace(6, (1, 2, 3), {}) == (2, (1, 6, 3), {})
    assert r.replace(6, (1,), {"b": 5}) == (5, (1,), {"b": 6})

# Generated at 2022-06-18 11:03:10.827084
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 5}) == 5
    assert r.get_old_value((1,), {"b": 5}, default=4) == 5
    assert r.replace(6, (1, 2, 3), {}) == (2, (1, 6, 3), {})

# Generated at 2022-06-18 11:03:22.292942
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, 5) == 2
    assert arg_replacer.get_old_value((1,), {'b': 2, 'c': 4}) == 2

# Generated at 2022-06-18 11:03:29.966865
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, d=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2), {"c": 4}) == 4
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {"c": 4}) == 3
    assert r.replace(5, (1, 2), {}) == (None, (1, 2), {"c": 5})

# Generated at 2022-06-18 11:03:40.419091
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4
   

# Generated at 2022-06-18 11:03:44.102094
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj['a'] == 1
    assert obj.b == AttributeError
    assert obj['b'] == KeyError


# Generated at 2022-06-18 11:03:55.736232
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base
        def configurable_default(self):
            return Base
    class Impl(Base):
        def initialize(self):
            pass
    Base.configure(Impl)
    assert isinstance(Base(), Impl)
    assert Base().__class__ == Impl
    assert Base().__class__ == Base.configured_class()
    assert Base().__class__ == Base.configured_class()
    assert Base().__class__ == Base.configured_class()
    assert Base().__class__ == Base.configured_class()
    assert Base().__class__ == Base.configured_class()
    assert Base().__class__ == Base.configured_class()
    assert Base().__class__ == Base.configured_class()
    assert Base().__

# Generated at 2022-06-18 11:04:05.132601
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock

    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        pass

    class TestConfigurableSubclassSubclass(TestConfigurableSubclass):
        pass

    def test_configurable_base():
        assert TestConfigurable.configurable_base() is TestConfigurable
        assert TestConfigurableSubclass.configurable_base() is TestConfigurable

# Generated at 2022-06-18 11:04:15.267486
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}, default=None) == 1
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}, default=0) == 1
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}, default=4) == 1
    assert arg_replacer.get_old_value((1,2,3), {'b':2}, default=None) == 1

# Generated at 2022-06-18 11:04:24.044106
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def initialize(self, a, b=None):
            self.a = a
            self.b = b

        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Foo

    f = Foo(1)
    assert f.a == 1
    assert f.b is None
    f = Foo(1, b=2)
    assert f.a == 1
    assert f.b == 2
    f = Foo(b=2, a=1)
    assert f.a == 1
    assert f.b == 2



# Generated at 2022-06-18 11:04:41.049715
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        return a, b, c
    r = ArgReplacer(f, "b")
    assert r.replace(1, (2, 3), {}) == (3, (2, 1), {})
    assert r.replace(1, (2,), {"b": 3}) == (3, (2,), {"b": 1})
    assert r.replace(1, (), {"b": 3}) == (3, (), {"b": 1})
    assert r.replace(1, (), {}) == (None, (), {"b": 1})



# Generated at 2022-06-18 11:04:52.192497
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value is None

# Generated at 2022-06-18 11:04:58.713693
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, 4) == 3
    assert arg_replacer.get_old_value((1, 2), {}, 4) == 4


# Generated at 2022-06-18 11:05:09.258450
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b=1):
            self.a = a
            self.b = b
    a = A(2)
    assert a.a == 2
    assert a.b == 1
    a = A(2, b=3)
    assert a.a == 2
    assert a.b == 3
    A.configure(None, b=4)
    a = A(2)
    assert a.a == 2
    assert a.b == 4
    a = A(2, b=3)
    assert a.a == 2
    assert a.b == 3
    A.configure(None)
    a = A(2)
    assert a.a == 2
    assert a.b == 1
    a = A(2, b=3)

# Generated at 2022-06-18 11:05:19.014450
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A

# Generated at 2022-06-18 11:05:23.020718
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    f = Foo(a=1, b=2)
    assert f.a == 1
    assert f.b == 2



# Generated at 2022-06-18 11:05:33.158679
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'b': 5, 'c': 6})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {'b': 5, 'c': 6}
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'b': 5, 'c': 6})
    assert old_value == 5
    assert args == (2, 3, 4)
    assert kwargs == {'b': 1, 'c': 6}

# Generated at 2022-06-18 11:05:39.645931
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    TestConfigurable.configure(None)
    c = TestConfigurable(1, 2, 3, a=4, b=5)
    assert c.args == (1, 2, 3)
    assert c.kwargs == {"a": 4, "b": 5}


# Generated at 2022-06-18 11:05:43.452626
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:05:56.199572
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    old_value, args, kwargs = arg_replacer.replace('new_c', (1, 2), {'d': 4})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'d': 4, 'c': 'new_c'}
    old_value, args, kwargs = arg_replacer.replace('new_c', (1, 2, 3), {'d': 4})
    assert old_value == 3
    assert args == (1, 2, 'new_c')
    assert kwargs == {'d': 4}
    old_value, args, kwargs = arg_

# Generated at 2022-06-18 11:06:15.963363
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(42, 'foo')
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:06:22.305441
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 5})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 5})
    assert old_

# Generated at 2022-06-18 11:06:32.384247
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4
   

# Generated at 2022-06-18 11:06:40.497701
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception((1, 2))
    except Exception as e:
        assert errno_from_exception(e) == (1, 2)



# Generated at 2022-06-18 11:06:50.304384
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {}, default=4) == 3
    assert r.get_old_value((1, 2), {"c": 3}) == 3
    assert r.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert r.get_old_value((1, 2), {"c": 3, "d": 4}) == 3
    assert r.get_old

# Generated at 2022-06-18 11:07:01.253830
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, "default") == "default"
    assert arg_replacer.get_old_value((1, 2), {"c": "foo"}) == "foo"
    assert arg_replacer.get_old_value((1, 2), {"c": "foo"}, "default") == "foo"
    assert arg_replacer.get_old_value((1, 2), {"d": "foo"}) is None

# Generated at 2022-06-18 11:07:10.649886
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 4
    assert r.get_old_value((1, 2), {"b": 3}) == 3
    assert r.get_old_value((1, 2), {"b": 3}, default=4) == 3
    assert r.get_old_value((1, 2), {"c": 3}, default=4) == 4


# Generated at 2022-06-18 11:07:21.641840
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def initialize(self, *args, **kwargs):
            pass
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestConfigurable
    TestConfigurable.configure(None)
    TestConfigurable.configure(TestConfigurable)
    TestConfigurable.configure(TestConfigurable, a=1)
    TestConfigurable.configure(TestConfigurable, b=2)
    TestConfigurable.configure(TestConfigurable, a=3, b=4)
    TestConfigurable.configure(TestConfigurable, b=5, a=6)
    TestConfigurable.configure(TestConfigurable, a=7, b=8)
    TestConfigurable.configure

# Generated at 2022-06-18 11:07:32.408494
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import create_autospec
    from unittest.mock import MagicMock
    from unittest.mock import call
    from unittest.mock import DEFAULT
    from unittest.mock import ANY
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 11:07:38.446649
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}, default=None) == 5


# Generated at 2022-06-18 11:08:00.686786
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj["a"] == 1
    assert obj.b == AttributeError
    assert obj["b"] == KeyError


# Generated at 2022-06-18 11:08:11.166946
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(B):
        pass

    class F(C):
        pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(D(), C)
    assert isinstance(E(), C)
    assert not isinstance(A(), F)
    assert not isinstance(B(), F)
    assert not isinstance(D(), F)
    assert not isinstance(E(), F)

    B.configure(F)
   

# Generated at 2022-06-18 11:08:20.667255
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()  # type: ObjectDict
    d.x = 1
    assert d.x == 1
    assert d['x'] == 1
    assert getattr(d, 'x') == 1
    assert d.get('x') == 1
    assert d.get('y') is None
    assert d.get('y', 2) == 2
    assert 'x' in d
    assert 'y' not in d
    assert list(d.keys()) == ['x']
    assert list(d.values()) == [1]
    assert list(d.items()) == [('x', 1)]
    d2 = ObjectDict(a=1, b=2)  # type: ObjectDict
    assert d2.a == 1
    assert d2.b == 2

# Generated at 2022-06-18 11:08:31.326141
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        return a, b, c

    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'c': 4, 'b': 1}

    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:08:36.446523
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    TestConfigurable()



# Generated at 2022-06-18 11:08:45.314545
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2), {}, None) == 2
    assert arg_replacer.get_old_value((1,), {'b': 2}, None) == 2
    assert arg_replacer.get_old_value((1,), {}, None) == None
    assert arg_replacer.get_old_value((1,), {}, 'default') == 'default'


# Generated at 2022-06-18 11:08:56.293490
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = replacer.replace(1, (), {'c': 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:09:07.818618
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, None) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1,), {'b': 4}, 5) == 4
    assert arg_replacer.get_old_value((1,), {}, 5) == 5

# Generated at 2022-06-18 11:09:15.957002
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 3}) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, 4) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 3}, 4) == 4


# Generated at 2022-06-18 11:09:27.444872
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(foo, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'d': 4})
    assert old_value is None
    assert args == (2, 3)
    assert kwargs == {'d': 4, 'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'d': 4})
    assert old_value == 4
    assert args == (2, 3, 1)
    assert kwargs == {'d': 4}