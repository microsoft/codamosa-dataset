

# Generated at 2022-06-18 10:59:55.399342
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-18 11:00:07.001603
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, arg1, arg2, kwarg1=None, kwarg2=None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.kwarg1 = kwarg1
            self.kwarg2 = kwarg2

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    a = A(1, 2, kwarg1=3, kwarg2=4)
    assert a.arg1 == 1
    assert a.arg2 == 2
    assert a.kwarg1 == 3
    assert a.kwarg2 == 4



# Generated at 2022-06-18 11:00:19.456483
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.config

# Generated at 2022-06-18 11:00:30.069855
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'c': 4, 'b': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3

# Generated at 2022-06-18 11:00:33.769832
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:39.583694
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=4):
        pass
    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) == 3
    assert r.get_old_value((1, 2), {}, 5) == 3
    assert r.get_old_value((1, 2), {"c": 6}) == 6
    assert r.get_old_value((1, 2), {"c": 6}, 5) == 6
    assert r.get_old_value((1, 2), {"d": 6}) == 3
    assert r.get_old_value((1, 2), {"d": 6}, 5) == 5
    assert r.get_old_value((1, 2, 7), {}) == 7

# Generated at 2022-06-18 11:00:50.922785
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 2
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((), {"b": 2}, default=4) == 2
    assert r.get_old_value((), {}, default=4) == 4


# Generated at 2022-06-18 11:00:59.050979
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=4):
        pass
    ar = ArgReplacer(f, 'c')
    assert ar.get_old_value((1, 2), {}) == 3
    assert ar.get_old_value((1, 2), {'c': 5}) == 5
    assert ar.get_old_value((1, 2), {'c': 5}, default=6) == 5
    assert ar.get_old_value((1, 2), {'d': 5}, default=6) == 6
    assert ar.get_old_value((1, 2), {'d': 5}) == 3


# Generated at 2022-06-18 11:01:00.816446
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("foo")
    except ValueError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:01:11.187105
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

        def initialize(self, value):
            self.value = value

    class BaseImpl(Base):
        pass

    class SubBase(Base):
        @classmethod
        def configurable_base(cls):
            return SubBase

        @classmethod
        def configurable_default(cls):
            return SubBaseImpl

    class SubBaseImpl(SubBase):
        pass

    class SubSubBase(SubBase):
        @classmethod
        def configurable_base(cls):
            return SubSubBase


# Generated at 2022-06-18 11:01:31.638531
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def __init__(self, a):
            self.a = a
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    A.configure(A)
    a = A(1)
    assert a.a == 1
    class B(A):
        def __init__(self, b):
            self.b = b
        def configurable_base(self):
            return A
        def configurable_default(self):
            return B
    B.configure(B)
    b = B(2)
    assert b.a == 1
    assert b.b == 2
    class C(A):
        def __init__(self, c):
            self.c = c

# Generated at 2022-06-18 11:01:40.464851
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, d=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2), {"c": 4}) == 4
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {"c": 4}) == 3
    assert r.get_old_value((1, 2, 3, 4), {}) == 3
    assert r.get_old_value((1, 2, 3, 4), {"c": 5}) == 3
    assert r.get_old_

# Generated at 2022-06-18 11:01:53.079410
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class C(Configurable):
        def configurable_base(self):
            return C
        def configurable_default(self):
            return C
    C.configure(None)
    c = C()
    assert isinstance(c, C)
    assert c.initialize() == None
    assert c.initialize(1, 2, 3) == None
    assert c.initialize(a=1, b=2, c=3) == None
    assert c.initialize(1, 2, 3, a=1, b=2, c=3) == None
    assert c.initialize(a=1, b=2, c=3, d=4) == None
    assert c.initialize(1, 2, 3, a=1, b=2, c=3, d=4) == None

# Generated at 2022-06-18 11:02:02.883421
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable().__class__ is TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert TestConfigurable.configured_class() is TestConfigurableSubclass
    assert TestConfigurable().__class__ is TestConfigurableSubclass

    TestConfigurable.configure(TestConfigurable)
    assert TestConfigurable.configured_

# Generated at 2022-06-18 11:02:14.399730
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, "default") == "default"
    assert arg_replacer.get_old_value((1, 2), {"c": "old"}) == "old"
    assert arg_replacer.get_old_value((1, 2), {"c": "old"}, "default") == "old"
    assert arg_replacer.get_old_value((1, 2, "old"), {}) == "old"
    assert arg_replacer.get_old_value((1, 2, "old"), {}, "default") == "old"
   

# Generated at 2022-06-18 11:02:18.394804
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def f():
        # type: () -> None
        try:
            raise ValueError()
        except:
            raise_exc_info(sys.exc_info())

    try:
        f()
    except ValueError:
        pass



# Generated at 2022-06-18 11:02:26.690192
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, 4) == 3
    assert arg_replacer.get_old_value((1, 2), {}, 4) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, None) == 3

# Generated at 2022-06-18 11:02:29.582946
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("foo")
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)
    assert False, "didn't raise"



# Generated at 2022-06-18 11:02:38.082633
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), A)
    assert not isinstance(A(), C)
    assert isinstance(B(), B)
    assert not isinstance(B(), A)
    assert not isinstance(B(), C)
    assert isinstance(C(), C)
    assert not isinstance(C(), A)

# Generated at 2022-06-18 11:02:44.239596
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    A.configure(None)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:03:06.365869
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo

        def configurable_default(self):
            return Foo

        def initialize(self, *args, **kwargs):
            pass

    Foo.configure(None)
    assert Foo.configured_class() == Foo
    assert Foo.configure.__func__ is Configurable.configure.__func__
    assert Foo.configurable_base.__func__ is Configurable.configurable_base.__func__
    assert Foo.configurable_default.__func__ is Configurable.configurable_default.__func__
    assert Foo.initialize.__func__ is Foo._initialize.__func__



# Generated at 2022-06-18 11:03:11.794951
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
    class TestConfigurableImpl(TestConfigurable):
        def initialize(self):
            pass
    TestConfigurable.configure(TestConfigurableImpl)
    TestConfigurable()
    TestConfigurable.configure(None)
    TestConfigurable()


# Generated at 2022-06-18 11:03:23.360258
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, 'new_value', 3)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {'c': 3})
    assert old_value == 2
    assert args == (1, 2)
    assert kwargs == {'c': 3}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1,), {'b': 2, 'c': 3})
    assert old

# Generated at 2022-06-18 11:03:32.927843
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self):
            pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    class E(D):
        pass
    A.configure(B)
    C.configure(D)
    assert isinstance(A(), A)
    assert isinstance(A(), B)
    assert isinstance(C(), C)
    assert isinstance(C(), D)
    assert isinstance(E(), E)
    assert isinstance(E(), D)
    assert isinstance(E(), C)
    assert isinstance(E(), A)
    assert isinstance(E(), B)



# Generated at 2022-06-18 11:03:34.668040
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d['a'] = 1
    assert d.a == 1
    assert d['a'] == 1
    with pytest.raises(AttributeError):
        d.b
    with pytest.raises(KeyError):
        d['b']


# Generated at 2022-06-18 11:03:39.809861
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, a, b):
            self.a = a
            self.b = b
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert isinstance(a, A)

# Generated at 2022-06-18 11:03:51.956307
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=4, e=5):
        pass

    r = ArgReplacer(f, "d")
    assert r.get_old_value((1, 2, 3), {}) == 4
    assert r.get_old_value((1, 2, 3), {}, default=6) == 6
    assert r.get_old_value((1, 2, 3), {"d": 7}) == 7
    assert r.get_old_value((1, 2, 3, 8), {}) == 8
    assert r.get_old_value((1, 2, 3, 8), {"d": 7}) == 8
    assert r.get_old_value((1, 2, 3, 8), {"e": 7}) == 8

# Generated at 2022-06-18 11:04:00.930635
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c, d=4, e=5):
        pass
    r = ArgReplacer(f, "d")
    assert r.replace(6, (1, 2, 3), {}) == (4, (1, 2, 3), {"d": 6})
    assert r.replace(6, (1, 2, 3), {"d": 7}) == (7, (1, 2, 3), {"d": 6})
    assert r.replace(6, (1, 2, 3), {"e": 7}) == (None, (1, 2, 3), {"d": 6, "e": 7})
    assert r.replace(6, (1, 2, 3, 8), {"e": 7}) == (8, (1, 2, 3, 6), {"e": 7})

# Generated at 2022-06-18 11:04:12.642491
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.foo = 1
    assert d.foo == 1
    assert d['foo'] == 1
    assert d.bar is None
    assert d['bar'] is None
    assert d.get('bar') is None
    assert d.get('bar', 2) == 2
    assert d.bar == 2
    assert d['bar'] == 2
    assert d.get('foo') == 1
    assert d.get('foo', 2) == 1
    assert d.foo == 1
    assert d['foo'] == 1
    d.clear()
    assert d.foo is None
    assert d['foo'] is None
    assert d.get('foo') is None
    assert d.get('foo', 2) == 2
    assert d.foo == 2
    assert d['foo'] == 2

# Generated at 2022-06-18 11:04:18.495469
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (2, (1, 3, 4), {})
    assert arg_replacer.replace(1, (2, 3, 4), {'a': 5}) == (5, (2, 3, 4), {'a': 1})
    assert arg_replacer.replace(1, (2, 3, 4), {'b': 5}) == (None, (2, 3, 4), {'b': 5, 'a': 1})


# Generated at 2022-06-18 11:04:52.152468
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self):
            self.initialized = True

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self):
            self.initialized = True

    class SubImpl2(Sub):
        def initialize(self):
            self.initialized = True

    # Unconfigured, should use default
    b = Base()
    assert isinstance(b, BaseImpl)
    assert b.initialized

    #

# Generated at 2022-06-18 11:05:00.827604
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {"c": 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {"c": 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 5})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 5}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 5})
    assert old_

# Generated at 2022-06-18 11:05:06.823104
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configure.__func__ is Configurable.configure.__func__



# Generated at 2022-06-18 11:05:15.728704
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ConfigurableSubclass(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableSubclass

        @classmethod
        def configurable_default(cls):
            return ConfigurableSubclass

    class ConfigurableSubclassImpl(ConfigurableSubclass):
        def initialize(self, arg):
            self.arg = arg

    ConfigurableSubclass.configure(ConfigurableSubclassImpl)
    instance = ConfigurableSubclass("foo")
    assert isinstance(instance, ConfigurableSubclassImpl)
    assert instance.arg == "foo"



# Generated at 2022-06-18 11:05:25.664714
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    replacer = ArgReplacer(test_func, "c")
    assert replacer.get_old_value((1, 2), {}) is None
    assert replacer.get_old_value((1, 2), {"c": 3}) == 3
    assert replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert replacer.get_old_value((1, 2), {}, default=4) == 4
    assert replacer.get_old_value((1, 2, 3), {}) == 3
    assert replacer.get_old_value((1, 2, 3), {"c": 4})

# Generated at 2022-06-18 11:05:35.555024
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception((1,))
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception([1])
    except Exception as e:
        assert errno_from_exception(e) == [1]
    try:
        raise Exception({1: 2})
    except Exception as e:
        assert errno_from_exception(e)

# Generated at 2022-06-18 11:05:45.755614
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass

    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}

    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args

# Generated at 2022-06-18 11:05:56.812764
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {'b': 'b'})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'b': 'b', 'c': 'new_value'}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {'b': 'b'})
    assert old_value == 3
    assert args == (1, 2, 'new_value')
    assert kwargs == {'b': 'b'}



# Generated at 2022-06-18 11:06:07.293344
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable.configure.__doc__ == Configurable.configure.__doc__
    assert TestConfigurable.configurable_base.__doc__ == Configurable.configurable_base.__doc__
    assert TestConfigurable.configurable_default.__doc__ == Configurable.configurable_default.__doc__
    assert TestConfigurable.configured_class.__doc__ == Configurable.configured_class.__doc__

# Generated at 2022-06-18 11:06:16.350151
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)
    A.configure(None)
    assert isinstance(A(), A)

# Generated at 2022-06-18 11:07:11.892848
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'c': 4, 'b': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:07:23.299883
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, default=5) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, default=5) == 2
    assert arg_replacer.get_old_value((1,), {'b': 2, 'c': 4}) == 2

# Generated at 2022-06-18 11:07:28.829964
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:07:37.081310
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    Base.configure(BaseImpl)
    Sub.configure(SubImpl)

# Generated at 2022-06-18 11:07:46.911825
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, a):
            # type: (Any) -> None
            self.a = a

    class B(A):
        def initialize(self, b, **kwargs):
            # type: (Any, Any) -> None
            super(B, self).initialize(**kwargs)
            self.b = b


# Generated at 2022-06-18 11:07:56.187324
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

        def initialize(self):
            pass

    class Subclass(Base):
        def initialize(self):
            pass

    Base.configure(Subclass)
    assert isinstance(Base(), Base)
    assert isinstance(Base(), Subclass)
    assert not isinstance(Base(), Configurable)
    assert not isinstance(Base(), object)

    Base.configure(None)
    assert isinstance(Base(), Base)
    assert not isinstance(Base(), Subclass)
    assert not isinstance(Base(), Configurable)
    assert not isinstance(Base(), object)

    class Subclass2(Base):
        def initialize(self):
            pass


# Generated at 2022-06-18 11:08:06.626106
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(foo, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {})
    assert old_value == None
    assert args == (2, 3)
    assert kwargs == {'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 4
    assert args == (2, 3)
    assert kwargs == {'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4, 'd': 5})
    assert old_value == 4


# Generated at 2022-06-18 11:08:17.312898
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.replace(10, (1, 2, 3), {}) == (2, (1, 10, 3), {})
    assert arg_replacer.replace(10, (1, 2, 3), {"b": 20}) == (20, (1, 2, 3), {"b": 10})
    assert arg_replacer.replace(10, (1, 2), {}) == (None, (1, 2), {"b": 10})
    assert arg_replacer.replace(10, (1, 2), {"b": 20}) == (20, (1, 2), {"b": 10})

# Generated at 2022-06-18 11:08:25.662881
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    Base.configure(None)
    Sub.configure(None)


# Generated at 2022-06-18 11:08:37.263513
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 2
    assert r.get_old_value((1,), {}) == None
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((), {"b": 2}) == 2
    assert r.get_old_value((), {"b": 2}, default=4) == 2