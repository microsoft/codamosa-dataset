

# Generated at 2022-06-18 10:59:50.829955
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 4}) == None
    assert arg_replacer.get_old_value((1, 2), {'d': 4}, default=3) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}, default=3) == 3


# Generated at 2022-06-18 10:59:59.233577
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    A.configure(C)
    assert isinstance(A(), C)
    A.configure(None)
    assert isinstance(A(), A)
    A.configure(B)
    assert isinstance(A(), B)
    A.configure(None)
    assert isinstance(A(), A)
    A.configure(B)
    assert isinstance(A(), B)
    A.configure(C)
    assert isinstance(A(), C)


# Generated at 2022-06-18 11:00:09.860386
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 2}, default=4) == 2
    assert r.get_old_value((), {"b": 2}, default=4) == 2
    assert r.get_old_value((), {}, default=4) == 4
    assert r.replace(4, (1, 2, 3), {}) == (2, (1, 4, 3), {})

# Generated at 2022-06-18 11:00:21.654615
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=None) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=5) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 3}, default=None) == 1

# Generated at 2022-06-18 11:00:27.567267
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:35.772429
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    obj = ObjectDict()
    obj.foo = 'bar'
    assert obj.foo == 'bar'
    assert obj['foo'] == 'bar'
    assert getattr(obj, 'foo') == 'bar'
    assert obj.get('foo') == 'bar'
    assert obj.get('bar') is None
    assert obj.get('bar', 'baz') == 'baz'
    assert 'foo' in obj
    assert 'bar' not in obj
    assert list(obj) == ['foo']
    assert list(obj.keys()) == ['foo']
    assert list(obj.values()) == ['bar']
    assert list(obj.items()) == [('foo', 'bar')]
    assert obj.pop('foo') == 'bar'
    assert 'foo' not in obj
    obj

# Generated at 2022-06-18 11:00:45.236414
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:00:57.418188
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 2, 'c': 3})

# Generated at 2022-06-18 11:01:07.697437
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "new_value", 3)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace("new_value", (1,), {"b": 2})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"b": "new_value"}

    old_value, args, kwargs = arg_replacer.replace("new_value", (1,), {})
    assert old_value is None

# Generated at 2022-06-18 11:01:16.497002
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        def initialize(self, *args, **kwargs):
            pass

    class C(A):
        def initialize(self, *args, **kwargs):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
   

# Generated at 2022-06-18 11:01:37.959065
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'d': 4})
    assert old_value == None
    assert args == (2, 3)
    assert kwargs == {'d': 4, 'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'d': 4})
    assert old_value == 4
    assert args == (2, 3, 1)
    assert kwargs == {'d': 4}

# Generated at 2022-06-18 11:01:50.435858
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, d=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2), {"c": 4}) == 4
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {"c": 4}) == 3
    assert r.replace(5, (1, 2), {}) == (None, (1, 2), {"c": 5})

# Generated at 2022-06-18 11:02:01.111876
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return BaseImpl

        def initialize(self, *args, **kwargs):
            # type: (Any, Any) -> None
            self.args = args
            self.kwargs = kwargs

    class BaseImpl(Base):
        pass

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Sub


# Generated at 2022-06-18 11:02:11.753002
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self, x):
            # type: (Any) -> None
            self.x = x

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(1), B)
    assert isinstance(B(1), B)
    assert isinstance(C(1), B)
    assert A(1).x == 1
    assert B(1).x == 1

# Generated at 2022-06-18 11:02:22.060868
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance

# Generated at 2022-06-18 11:02:33.478269
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.arg_pos == 1
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1,), {"b": 2}) == 2
    assert r.get_old_value((), {"b": 2}) == 2
    assert r.get_old_value((), {"b": 2}, default=3) == 2
    assert r.get_old_value((), {}, default=3) == 3
    assert r.get_old_value((1,), {}, default=3) == 3
    assert r.get_old_value((1, 2, 3), {}) == 2

# Generated at 2022-06-18 11:02:46.186297
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}) == 1
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}, default=4) == 1
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}, default=5) == 1
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}, default=6) == 1

# Generated at 2022-06-18 11:02:52.287042
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:03:02.103227
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) == 3
    assert arg_replacer.get_old_value((1, 2), {}, default=5) == 5
    assert arg_replacer.get_old_value((1, 2), {"c": 6}) == 6
    assert arg_replacer.get_old_value((1, 2), {"c": 6}, default=5) == 6
    assert arg_replacer.get_old_value((1, 2), {"d": 6}) == 3
    assert arg_replacer.get_old_value((1, 2), {"d": 6}, default=5) == 5

# Generated at 2022-06-18 11:03:12.415285
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3

# Generated at 2022-06-18 11:03:28.947786
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)

    A.configure(None)
    assert isinstance(A(), A)
    assert not isinstance(A(), B)
    assert not isinstance(A(), C)

    A.configure(B, foo="bar")

# Generated at 2022-06-18 11:03:36.667483
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, "test")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception("test")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:03:44.697795
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestConfigurableImpl

        def initialize(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            pass

    class TestConfigurableImpl(TestConfigurable):
        pass

    class TestConfigurableSubclass(TestConfigurable):
        pass

    class TestConfigurableSubclassImpl(TestConfigurableSubclass):
        pass

    # Test that the default implementation is used when no configuration
    # is set.

# Generated at 2022-06-18 11:03:55.053968
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 5}) == 5
    assert arg_replacer.get_old_value((1, 2), {'c': 5}, default=6) == 5
    assert arg_replacer.get_old_value((1, 2), {}, default=6) == 6
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=6) == 6


# Generated at 2022-06-18 11:04:03.839600
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

    TestConfigurable.configure(None)
    assert TestConfigurable(1, 2, 3).a == 1
    assert TestConfigurable(1, 2, 3).b == 2
    assert TestConfigurable(1, 2, 3).c == 3
    assert TestConfigurable(1, 2).a == 1
    assert TestConfigurable(1, 2).b == 2
    assert TestConfigurable(1, 2).c is None


# Generated at 2022-06-18 11:04:14.302742
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d['x'] == 1
    assert getattr(d, 'x') == 1
    assert d.y == None
    assert d['y'] == None
    assert getattr(d, 'y') == None
    assert d.y == None
    assert d['y'] == None
    assert getattr(d, 'y') == None
    assert d.z == None
    assert d['z'] == None
    assert getattr(d, 'z') == None
    assert d.z == None
    assert d['z'] == None
    assert getattr(d, 'z') == None
    assert d.z == None
    assert d['z'] == None

# Generated at 2022-06-18 11:04:21.280004
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, default=5) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, default=5) == 2
    assert arg_replacer.get_old_value((1,), {'b': 2, 'c': 4}) == 2

# Generated at 2022-06-18 11:04:27.274607
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert not isinstance(B(), C)
    assert not isinstance(C(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:04:37.965182
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, "default") == "default"
    assert arg_replacer.get_old_value((1, 2), {"c": "value"}) == "value"
    assert arg_replacer.get_old_value((1, 2), {"c": "value"}, "default") == "value"
    assert arg_replacer.get_old_value((1, 2), {"d": "value"}) is None
    assert arg_replacer.get_old_value((1, 2), {"d": "value"}, "default") == "default"


# Generated at 2022-06-18 11:04:42.914020
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    A.configure(None)
    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3


# Generated at 2022-06-18 11:04:54.995715
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:04:59.695983
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-18 11:05:03.609008
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj["a"] == 1
    try:
        obj.b
        assert False
    except AttributeError:
        pass
    try:
        obj["b"]
        assert False
    except KeyError:
        pass


# Generated at 2022-06-18 11:05:15.992885
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.select import SelectIOLoop
    from tornado.platform.twisted import TwistedIOLoop
    from tornado.platform.auto import AutoIOLoop
    from tornado.platform.caresresolver import CaresResolver
    from tornado.platform.twisted import TwistedResolver
    from tornado.platform.auto import AutoResolver
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.select import SelectIOLoop
    from tornado.platform.twisted import TwistedIOLoop
    from tornado.platform.auto import AutoIOLoop
    from tornado.platform.caresresolver import CaresResolver
    from tornado.platform.twisted import TwistedResolver

# Generated at 2022-06-18 11:05:26.074942
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance

# Generated at 2022-06-18 11:05:31.323481
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, *args, **kwargs):
            pass
    a = A()
    assert isinstance(a, A)
    assert isinstance(a, Configurable)
    assert not isinstance(a, type)



# Generated at 2022-06-18 11:05:36.763448
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self):
            pass

    class B(A):
        def initialize(self):
            pass

    class C(A):
        def initialize(self):
            pass

    A.configure(C)
    assert isinstance(A(), C)



# Generated at 2022-06-18 11:05:48.614789
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    old_value, args, kwargs = arg_replacer.replace(2, (1,), {"c": 3})
    assert old_value == 1
    assert args == (1, 2)
    assert kwargs == {"c": 3}
    old_value, args, kwargs = arg_replacer.replace(2, (1, 3), {})
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(2, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == ()
    assert kwargs

# Generated at 2022-06-18 11:05:58.460893
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)



# Generated at 2022-06-18 11:06:09.489408
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c is None
    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3
    a = A(1, 2, c=3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3
    a = A(1, 2, c=3, d=4)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3
    assert not hasattr

# Generated at 2022-06-18 11:06:34.708846
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 11:06:41.135348
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:06:48.731212
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        def initialize(self, *args, **kwargs):
            pass

    class C(A):
        def initialize(self, *args, **kwargs):
            pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:06:58.853265
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    # Test that the initialize method is called
    class TestConfigurableImpl(TestConfigurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    TestConfigurable.configure(TestConfigurableImpl)
    impl = TestConfigurable()
    assert impl.args == ()
    assert impl.kwargs == {}

    impl = TestConfigurable(1, 2, a=3, b=4)
    assert impl.args == (1, 2)

# Generated at 2022-06-18 11:07:05.347879
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:07:10.750458
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4, 3)
    assert kwargs == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-18 11:07:21.767358
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=4):
        pass
    ar = ArgReplacer(f, "c")
    assert ar.get_old_value((1, 2), {}) == 3
    assert ar.get_old_value((1, 2), {}, 5) == 3
    assert ar.get_old_value((1, 2), {"c": 6}) == 6
    assert ar.get_old_value((1, 2), {"c": 6}, 5) == 6
    assert ar.get_old_value((1, 2), {"d": 6}) == 3
    assert ar.get_old_value((1, 2), {"d": 6}, 5) == 5
    ar = ArgReplacer(f, "d")
    assert ar.get_old_value((1, 2), {}) == 4

# Generated at 2022-06-18 11:07:32.608936
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value is None
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:07:43.914362
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'c': 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {'c': 4, 'b': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:07:50.158146
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert TestConfigurable.configured_class() == TestConfigurableSubclass

    class TestConfigurableSubclass2(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(TestConfigurableSubclass2)
    assert Test

# Generated at 2022-06-18 11:08:31.513222
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(f, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, default=3) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 4}) == 4
    assert arg_replacer.get_old_value((1, 2), {"c": 4, "d": 5}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 5}) == 3
    assert arg_replacer.get_

# Generated at 2022-06-18 11:08:40.440808
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(errno=1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1, 2, errno=1)
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-18 11:08:51.964375
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.config

# Generated at 2022-06-18 11:09:01.661307
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {'b': 3, 'c': 4}) == (3, (2,), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {'b': 3, 'c': 4}) == (3, (), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {}) == (None, (), {'b': 1})


# Generated at 2022-06-18 11:09:13.864276
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=3, d=4):
        pass

    arg_replacer = ArgReplacer(foo, "c")
    old_value, args, kwargs = arg_replacer.replace(5, (1, 2), {})
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {"c": 5}

    old_value, args, kwargs = arg_replacer.replace(5, (1, 2), {"c": 6})
    assert old_value == 6
    assert args == (1, 2)
    assert kwargs == {"c": 5}

    old_value, args, kwargs = arg_replacer.replace(5, (1, 2), {"d": 6})
    assert old_value is None

# Generated at 2022-06-18 11:09:24.190251
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, "default") == "default"
    assert arg_replacer.get_old_value((1, 2), {"c": "value"}) == "value"
    assert arg_replacer.get_old_value((1, 2), {"c": "value"}, "default") == "value"
    assert arg_replacer.get_old_value((1, 2), {"d": "value"}) is None
    assert arg_replacer.get_old_value((1, 2), {"d": "value"}, "default") == "default"


# Generated at 2022-06-18 11:09:33.569586
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, *args, **kwargs):
            pass
    class B(A):
        def initialize(self, *args, **kwargs):
            pass
    class C(A):
        def initialize(self, *args, **kwargs):
            pass
    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
   