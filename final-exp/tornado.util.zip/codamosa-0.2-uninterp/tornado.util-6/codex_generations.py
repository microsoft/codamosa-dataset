

# Generated at 2022-06-18 10:59:50.881658
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:01.194018
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {'b': 3, 'c': 4}) == (3, (2,), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {'b': 3, 'c': 4}) == (3, (), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {}) == (None, (), {'b': 1})



# Generated at 2022-06-18 11:00:13.103348
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, foo):
            # type: (str) -> None
            self.foo = foo

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Sub

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return SubImpl


# Generated at 2022-06-18 11:00:19.624605
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:27.455399
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)

# Generated at 2022-06-18 11:00:35.740782
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=4, e=5):
        pass

    r = ArgReplacer(f, "d")
    assert r.get_old_value((1, 2, 3), {}) == 4
    assert r.get_old_value((1, 2, 3), {}, default=6) == 6
    assert r.get_old_value((1, 2, 3), {"d": 7}) == 7
    assert r.get_old_value((1, 2, 3), {"e": 7}) == 4
    assert r.get_old_value((1, 2, 3), {"d": 7}, default=6) == 7
    assert r.get_old_value((1, 2, 3), {"e": 7}, default=6) == 6

    r = ArgReplacer(f, "e")
   

# Generated at 2022-06-18 11:00:40.738634
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a):
            self.a = a
    class B(A):
        def initialize(self, b):
            self.b = b
    class C(A):
        def initialize(self, c):
            self.c = c
    class D(B, C):
        def initialize(self, d):
            self.d = d
    class E(D):
        def initialize(self, e):
            self.e = e
    class F(E):
        def initialize(self, f):
            self.f = f
    class G(F):
        def initialize(self, g):
            self.g = g
    class H(G):
        def initialize(self, h):
            self.h = h

# Generated at 2022-06-18 11:00:48.879471
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 5}, None) == 5
    assert arg_replacer.get_old_value((1, 2), {'c': 5}, 6) == 5
    assert arg_replacer.get_old_value((1, 2), {}, 6) == 6


# Generated at 2022-06-18 11:00:59.786939
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1,), {'b': 4}, 5) == 4
    assert arg_replacer.get_old_value((1,), {}, 5) == 5


# Generated at 2022-06-18 11:01:09.840354
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
        def initialize(self):
            pass
    class B(A):
        def initialize(self):
            pass
    class C(A):
        def initialize(self):
            pass
    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), A)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)


# Generated at 2022-06-18 11:01:36.562885
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj['a'] == 1
    assert getattr(obj, 'a') == 1
    assert obj.get('a') == 1
    assert obj.get('b') is None
    assert obj.get('b', 2) == 2
    assert 'a' in obj
    assert 'b' not in obj
    assert list(obj) == ['a']
    assert list(obj.keys()) == ['a']
    assert list(obj.values()) == [1]
    assert list(obj.items()) == [('a', 1)]
    assert obj.pop('a') == 1
    assert 'a' not in obj
    obj.update(a=2)
    assert obj.a == 2
    assert obj

# Generated at 2022-06-18 11:01:43.152433
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:01:49.140905
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:01:54.406477
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass

    TestConfigurableSubclass()



# Generated at 2022-06-18 11:02:03.718133
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:02:14.537251
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert not isinstance(A(), B)
    assert not isinstance(A(), C)



# Generated at 2022-06-18 11:02:18.908501
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)



# Generated at 2022-06-18 11:02:27.022459
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.replace(1, (1, 2), {'d': 4}) == (None, (1, 2), {'d': 4, 'c': 1})
    assert arg_replacer.replace(1, (1, 2, 3), {'d': 4}) == (3, (1, 2, 1), {'d': 4})
    assert arg_replacer.replace(1, (1, 2, 3, 4), {'d': 4}) == (3, (1, 2, 1, 4), {'d': 4})

# Generated at 2022-06-18 11:02:33.433814
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-18 11:02:46.186473
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2, 3), {'d': 4})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {'d': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2, 3), {})
    assert old_value is None
    assert args == (1, 2, 3)
    assert kwargs == {'d': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {'c': 3})
    assert old

# Generated at 2022-06-18 11:03:32.493381
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj['a'] == 1
    assert getattr(obj, 'a') == 1
    assert obj.get('a') == 1
    assert obj.get('b') is None
    assert obj.get('b', 2) == 2
    assert 'a' in obj
    assert 'b' not in obj
    assert list(obj) == ['a']
    assert obj.pop('a') == 1
    assert 'a' not in obj
    obj.update(a=1, b=2)
    assert obj.a == 1
    assert obj.b == 2
    assert obj == {'a': 1, 'b': 2}

# Generated at 2022-06-18 11:03:38.654715
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(TestConfigurable)
    TestConfigurable()
    TestConfigurable.configure(None)
    TestConfigurable()



# Generated at 2022-06-18 11:03:51.156114
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {'d': 3})
    assert old_value == None
    assert args == (1, 2)
    assert kwargs == {'d': 3, 'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2, 3), {'d': 3})
    assert old_value == 3
    assert args == (1, 2, 1)
    assert kwargs == {'d': 3}

# Generated at 2022-06-18 11:03:59.484062
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception((1,))
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception([1])
    except Exception as e:
        assert errno_from_exception(e) == [1]



# Generated at 2022-06-18 11:04:10.993942
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
        def initialize(self, *args, **kwargs):
            pass
    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configurable_base() is TestConfigurable
    assert TestConfigurable.configurable_default() is TestConfigurable
    assert TestConfigurable._save_configuration() == (None, {})
    TestConfigurable._restore_configuration((None, {}))
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configurable_base() is TestConfigurable
    assert TestConfigurable.configurable_default() is TestConfigurable

# Generated at 2022-06-18 11:04:18.531174
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 5}) == 5
    assert r.get_old_value((1,), {"b": 5}, default=6) == 5
    assert r.get_old_value((1,), {"c": 5}, default=6) == 6

    assert r.replace(7, (1, 2, 3), {}) == (2, (1, 7, 3), {})

# Generated at 2022-06-18 11:04:25.993987
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
   

# Generated at 2022-06-18 11:04:35.970345
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=1, c=2):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1,), {}, None) == 1
    assert arg_replacer.get_old_value((1,), {}, 2) == 1
    assert arg_replacer.get_old_value((1,), {}, 3) == 1
    assert arg_replacer.get_old_value((1,), {"b": 2}, None) == 2
    assert arg_replacer.get_old_value((1,), {"b": 2}, 3) == 2
    assert arg_replacer.get_old_value((1,), {"b": 2}, 4) == 2

# Generated at 2022-06-18 11:04:44.474447
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B, b=1)
    assert isinstance(A(1), B)
    assert A(1).b == 1
    assert A(1, b=2).b == 2
    assert A(1, b=2).a == 1
    assert A(1, b=2).a == 1
    assert A(1).a == 1
    assert A(1).b == 1


# Generated at 2022-06-18 11:04:54.649280
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    class B(A):
        pass
    class C(A):
        pass
    A.configure(B)
    assert isinstance(A(), B)
    A.configure(C)
    assert isinstance(A(), C)
    A.configure(None)
    assert isinstance(A(), A)
    A.configure(B, foo="bar")
    assert isinstance(A(), B)
    assert A().foo == "bar"
    A.configure(C, foo="baz")
    assert isinstance(A(), C)
    assert A().foo == "baz"

# Generated at 2022-06-18 11:06:15.472208
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

    class TestConfigurableImpl(TestConfigurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    TestConfigurable.configure(TestConfigurableImpl)
    instance = TestConfigurable(1, 2, 3, a=4, b=5, c=6)
    assert instance.args == (1, 2, 3)
    assert instance.kwargs == {"a": 4, "b": 5, "c": 6}



# Generated at 2022-06-18 11:06:21.601291
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=0) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, default=0) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}, default=0) == 0
   

# Generated at 2022-06-18 11:06:31.108864
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, default=3) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}) == 3
    assert arg_replacer.get_old_value((1, 2, 3, 4), {}) == 3

# Generated at 2022-06-18 11:06:41.964092
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4, "b": 3})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"c": 4, "b": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"c": 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:06:51.319779
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    arg_replacer = ArgReplacer(foo, 'a')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 2
    assert args == (1, 3)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'a': 4})
    assert old_value == 4

# Generated at 2022-06-18 11:07:02.451127
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A

# Generated at 2022-06-18 11:07:08.156593
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:07:14.867459
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock
    import io
    import sys
    import typing
    import functools
    import contextlib
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver


# Generated at 2022-06-18 11:07:25.768804
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {'b': 3}) == (3, (2,), {'b': 1})
    assert arg_replacer.replace(1, (), {'b': 3}) == (3, (), {'b': 1})
    assert arg_replacer.replace(1, (2, 3, 4), {'c': 5}) == (3, (2, 1, 4), {'c': 5})
    assert arg_replacer.replace(1, (), {}) == (None, (), {'b': 1})




# Generated at 2022-06-18 11:07:35.532306
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    a = A()
    assert isinstance(a, A)

    class B(A):
        pass

    b = B()
    assert isinstance(b, B)

    class C(A):
        pass

    A.configure(C)
    c = A()
    assert isinstance(c, C)

    A.configure(None)
    d = A()
    assert isinstance(d, A)

    A.configure(B)
    e = A()
    assert isinstance(e, B)

    A.configure(C, foo="bar")
   

# Generated at 2022-06-18 11:08:31.282331
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, "test")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(1)
    except Exception as e:
        assert errno_from_exception(e) == 1


# Generated at 2022-06-18 11:08:39.614504
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    r = ArgReplacer(f, "b")
    assert r.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert r.replace(1, (2,), {"b": 3, "c": 4}) == (3, (2,), {"b": 1, "c": 4})
    assert r.replace(1, (), {"b": 3, "c": 4}) == (3, (), {"b": 1, "c": 4})
    assert r.replace(1, (), {"c": 4}) == (None, (), {"b": 1, "c": 4})



# Generated at 2022-06-18 11:08:50.840683
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(foo, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
   

# Generated at 2022-06-18 11:09:01.384339
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_

# Generated at 2022-06-18 11:09:13.494449
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:09:18.822182
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def __init__(self, *args, **kwargs):
            super(A, self).__init__(*args, **kwargs)

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:09:27.606794
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, 4) == 3
    assert arg_replacer.get_old_value((1, 2), {}, 4) == 4


# Generated at 2022-06-18 11:09:35.244007
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c, d=4):
        pass
    arg_replacer = ArgReplacer(test_func, "d")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 6}) == 6
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 6}, 5) == 6
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 6}, 5) == 6