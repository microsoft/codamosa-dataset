

# Generated at 2022-06-18 11:00:06.911773
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(f, "c")
    assert arg_replacer.get_old_value((1, 2), {}) == 3
    assert arg_replacer.get_old_value((1, 2), {}, default=5) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 6}) == 6
    assert arg_replacer.get_old_value((1, 2), {"c": 6}, default=5) == 6
    assert arg_replacer.get_old_value((1, 2), {"d": 6}) == 3
    assert arg_replacer.get_old_value((1, 2), {"d": 6}, default=5) == 5

# Generated at 2022-06-18 11:00:19.411981
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(2, (1, 3, 4), {}) == (3, (1, 2, 4), {})
    assert arg_replacer.replace(2, (1,), {'b': 3}) == (3, (1,), {'b': 2})
    assert arg_replacer.replace(2, (), {'b': 3}) == (3, (), {'b': 2})
    assert arg_replacer.replace(2, (), {}) == (None, (), {'b': 2})
    assert arg_replacer.replace(2, (1, 3, 4), {'b': 5}) == (5, (1, 2, 4), {'b': 5})
   

# Generated at 2022-06-18 11:00:23.318870
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:00:30.355955
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    class B(A):
        pass

    class C(A):
        def initialize(self, a, b, c, d):
            super(C, self).initialize(a, b, c)
            self.d = d

    class D(A):
        def initialize(self, a, b, c, d=None):
            super(D, self).initialize(a, b, c)
            self.d = d

    class E(A):
        def initialize(self, a, b, c, d=None, e=None):
            super(E, self).initialize(a, b, c)
            self.d = d
           

# Generated at 2022-06-18 11:00:36.998661
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:00:39.546984
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:00:50.876090
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None, d=None):
        pass
    args = (1, 2)
    kwargs = {'d': 4}
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace(3, args, kwargs)
    assert old_value == None
    assert args == (1, 2)
    assert kwargs == {'c': 3, 'd': 4}
    old_value, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {'c': 5, 'd': 4}
    args = (1, 2, 3)

# Generated at 2022-06-18 11:01:00.504451
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2), {'b': 4}) == 4
    assert arg_replacer.get_old_value((1, 2), {'b': 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2), {}, 5) == 5

# Generated at 2022-06-18 11:01:10.815203
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'d': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'d': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'d': 5})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {'d': 5, 'c': 3}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'d': 5})

# Generated at 2022-06-18 11:01:18.893632
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        return a, b, c
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, 'new_value', 3)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1,), {'b': 2, 'c': 3})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {'b': 'new_value', 'c': 3}

# Generated at 2022-06-18 11:01:35.011798
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_

# Generated at 2022-06-18 11:01:43.644872
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.replace(1, (2, 3), {}) == (3, (2, 1), {})
    assert arg_replacer.replace(1, (2,), {"b": 3}) == (3, (2,), {"b": 1})
    assert arg_replacer.replace(1, (), {"b": 3}) == (3, (), {"b": 1})
    assert arg_replacer.replace(1, (), {}) == (None, (), {"b": 1})



# Generated at 2022-06-18 11:01:55.493803
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, default=5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=5) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 2
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, default=5) == 2

# Generated at 2022-06-18 11:02:02.450225
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    TestConfigurable.configure(None)
    c = TestConfigurable(1, 2, foo=3, bar=4)
    assert c.args == (1, 2)
    assert c.kwargs == {"foo": 3, "bar": 4}



# Generated at 2022-06-18 11:02:13.797893
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3

# Generated at 2022-06-18 11:02:23.686314
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=1, d=2):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2), {})
    assert old_value == 1
    assert args == (1, 2)
    assert kwargs == {'c': 3}
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2), {'c': 4})
    assert old_value == 4
    assert args == (1, 2)
    assert kwargs == {'c': 3}
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2), {'d': 4})
    assert old_value == None
   

# Generated at 2022-06-18 11:02:27.049006
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    TestConfigurable()



# Generated at 2022-06-18 11:02:34.694354
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError
    except:
        raise_exc_info(sys.exc_info())
    # This is a no-op, but it should not raise an exception
    raise_exc_info((None, None, None))
    # This is a no-op, but it should not raise an exception
    raise_exc_info((None, None, None))
    # This should raise a TypeError
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError not raised")



# Generated at 2022-06-18 11:02:44.388793
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(func, "d")
    assert arg_replacer.get_old_value((1, 2, 3), {}) is None
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5


# Generated at 2022-06-18 11:02:54.515750
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    a = A()
    assert isinstance(a, A)
    assert a.__class__ is A

    class B(A):
        pass

    A.configure(B)
    a = A()
    assert isinstance(a, A)
    assert a.__class__ is B

    class C(A):
        pass

    A.configure(C)
    a = A()
    assert isinstance(a, A)
    assert a.__class__ is C

    A.configure(None)
    a = A()
    assert isinstance(a, A)


# Generated at 2022-06-18 11:03:07.040723
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)


# Generated at 2022-06-18 11:03:09.531734
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:03:20.767301
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    A.configure(None, c=3)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3
    a = A(1, 2, c=4)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 4
    A.configure(None, c=5)
    a = A(1, 2)
    assert a.a == 1

# Generated at 2022-06-18 11:03:29.216699
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            self.initialize(*args, **kwargs)
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestConfigurable
    TestConfigurable.configure(None)
    assert TestConfigurable(1, 2, foo=3, bar=4).args == (1, 2)
    assert TestConfigurable(1, 2, foo=3, bar=4).kwargs == {"foo": 3, "bar": 4}

# Generated at 2022-06-18 11:03:39.392807
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(0)
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise IOError(0, "message")
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise IOError(errno=0)
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise IOError(errno=0, strerror="message")
    except IOError as e:
        assert errno_from_exception(e) == 0



# Generated at 2022-06-18 11:03:51.584264
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c, d=4, e=5):
        pass
    arg_replacer = ArgReplacer(test_func, 'd')
    old_value, args, kwargs = arg_replacer.replace(6, (1, 2, 3), {'e': 7})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {'d': 6, 'e': 7}
    old_value, args, kwargs = arg_replacer.replace(6, (1, 2, 3, 4), {'e': 7})
    assert old_value == 4
    assert args == (1, 2, 3, 6)
    assert kwargs == {'e': 7}
    old_value, args, kwargs = arg_repl

# Generated at 2022-06-18 11:04:00.686093
# Unit test for function import_object
def test_import_object():
    import sys
    import_object('sys')
    import_object('sys.stdout')
    import_object('tornado.escape')
    import_object('tornado.escape.utf8')
    import_object('tornado')
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        raise Exception('import_object did not fail as expected')

# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support

# Generated at 2022-06-18 11:04:12.399029
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    args = (1, 2, 3)
    kwargs = {"c": 4}
    old_value, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert old_value == 2
    assert args == (1, 5, 3)
    assert kwargs == {"c": 4}
    old_value, args, kwargs = arg_replacer.replace(6, args, kwargs)
    assert old_value == 5
    assert args == (1, 6, 3)
    assert kwargs == {"c": 4}
    old_value, args, kwargs = arg_replacer.replace(7, args, kwargs)

# Generated at 2022-06-18 11:04:17.242436
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    test_configurable = TestConfigurable()
    assert isinstance(test_configurable, TestConfigurable)
    assert test_configurable.initialize.__func__ is TestConfigurable.initialize.__func__



# Generated at 2022-06-18 11:04:22.499364
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    A.configure(None, c=3)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-18 11:04:40.954791
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2, 3)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception((1,))
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception([1])
    except Exception as e:
        assert errno_from_exception(e) == [1]



# Generated at 2022-06-18 11:04:49.074792
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, "error")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:04:58.602806
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(A(), A)
    assert not isinstance(A(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(A(), A)
    assert not isinstance(A(), B)

   

# Generated at 2022-06-18 11:05:09.107360
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    class B(A):
        def initialize(self):
            self.b = 1
    class C(A):
        def initialize(self):
            self.c = 1
    class D(A):
        def initialize(self):
            self.d = 1
    class E(A):
        def initialize(self):
            self.e = 1
    class F(A):
        def initialize(self):
            self.f = 1
    class G(A):
        def initialize(self):
            self.g = 1
    class H(A):
        def initialize(self):
            self.h = 1
    class I(A):
        def initialize(self):
            self

# Generated at 2022-06-18 11:05:12.792477
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.foo = 'bar'
    assert d.foo == 'bar'
    assert d['foo'] == 'bar'
    assert d.bar == None
    assert d['bar'] == None


# Generated at 2022-06-18 11:05:16.813036
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo

        def configurable_default(self):
            return Foo

        def initialize(self, *args, **kwargs):
            pass

    Foo.configure(None)
    Foo()



# Generated at 2022-06-18 11:05:27.069740
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a=None, b=None):
            self.a = a
            self.b = b
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    a = A(a=1, b=2)
    assert a.a == 1
    assert a.b == 2
    A.configure(None, a=3)
    a = A(b=4)
    assert a.a == 3
    assert a.b == 4
    A.configure(None)
    a = A(a=5, b=6)
    assert a.a == 5
    assert a.b == 6


# Generated at 2022-06-18 11:05:35.596484
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception((1,))
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception([1])
    except Exception as e:
        assert errno_from_exception(e) == [1]



# Generated at 2022-06-18 11:05:45.914202
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import unittest.mock
    import typing
    import functools
    import inspect
    import sys
    import os
    import io
    import contextlib
    import builtins
    import types
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib

# Generated at 2022-06-18 11:05:57.163245
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {})
    assert old_value is None
    assert args == (2, 3)
    assert kwargs == {'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 4
    assert args == (2, 3)
    assert kwargs == {'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 4

# Generated at 2022-06-18 11:06:19.269439
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {'d': 4})
    assert old_value == None
    assert args == (1, 2)
    assert kwargs == {'d': 4, 'c': 'new_value'}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {'d': 4})
    assert old_value == 3
    assert args == (1, 2, 'new_value')
    assert kwargs == {'d': 4}
    old_value, args, kwargs = arg_replacer.replace

# Generated at 2022-06-18 11:06:28.078038
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
   

# Generated at 2022-06-18 11:06:33.477606
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
        assert False, "expected ImportError"
    except ImportError:
        pass



# Generated at 2022-06-18 11:06:43.763006
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {'b': 3, 'c': 4}) == (3, (2,), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {'b': 3, 'c': 4}) == (3, (), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {}) == (None, (), {'b': 1})



# Generated at 2022-06-18 11:06:47.966052
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    o = ObjectDict()
    o.a = 1
    assert o.a == 1
    assert o['a'] == 1
    try:
        o.b
    except AttributeError:
        pass
    else:
        raise Exception("Expected AttributeError")



# Generated at 2022-06-18 11:06:52.194509
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2, 3)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"



# Generated at 2022-06-18 11:07:04.139427
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    TestConfigurable.configure(None)
    assert TestConfigurable(1, 2).a == 1
    assert TestConfigurable(1, 2).b == 2
    assert TestConfigurable(1, 2).c is None
    assert TestConfigurable(1, 2, 3).a == 1
    assert TestConfigurable(1, 2, 3).b == 2
    assert TestConfigurable(1, 2, 3).c == 3

# Generated at 2022-06-18 11:07:12.203607
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1,), {'b': 4}, 5) == 4
    assert arg_replacer.get_old_value((1,), {}, 5) == 5


# Generated at 2022-06-18 11:07:20.489434
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    instance = TestConfigurableSubclass(1, 2, a=3, b=4)
    assert instance.args == (1, 2)
    assert instance.kwargs == {"a": 3, "b": 4}



# Generated at 2022-06-18 11:07:31.195123
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d["x"] == 1
    assert d.y == None
    assert d["y"] == None
    d["y"] = 2
    assert d.y == 2
    assert d["y"] == 2
    d.z = None
    assert d.z == None
    assert d["z"] == None
    d["z"] = 3
    assert d.z == 3
    assert d["z"] == 3
    assert d.get("z") == 3
    assert d.get("w") == None
    assert d.get("w", 4) == 4
    assert d.get("w", default=4) == 4
    assert d.get("z", default=4) == 3
    assert d

# Generated at 2022-06-18 11:08:11.850442
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'c': 3}
    replacer = ArgReplacer(f, 'c')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 3
    assert args == (1, 2, 4)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = replacer.replace(5, args, kwargs)
    assert old_value == 4
    assert args == (1, 2, 5)
    assert kwargs == {'c': 5}



# Generated at 2022-06-18 11:08:16.679989
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self):
            pass

    TestConfigurable.configure(None)
    assert isinstance(TestConfigurable(), TestConfigurable)



# Generated at 2022-06-18 11:08:25.230852
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}
    replacer = ArgReplacer(func, 'a')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 1
    assert args == (4, 2, 3)
    assert kwargs == {'a': 4, 'b': 2, 'c': 3}
    replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = replacer.replace(5, args, kwargs)
    assert old_value == 2
    assert args == (4, 2, 3)

# Generated at 2022-06-18 11:08:36.805449
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        return a, b, c
    args = (1, 2, 3)
    kwargs = {}
    replacer = ArgReplacer(f, 'b')
    old_value, new_args, new_kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert new_args == (1, 4, 3)
    assert new_kwargs == {}
    old_value, new_args, new_kwargs = replacer.replace(5, args, {'b': 6})
    assert old_value == 6
    assert new_args == (1, 2, 3)
    assert new_kwargs == {'b': 5}

# Generated at 2022-06-18 11:08:41.434438
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-18 11:08:52.547172
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None):
        pass
    ar = ArgReplacer(foo, 'b')
    assert ar.replace(1, (2, 3), {}) == (3, (2, 1), {})
    assert ar.replace(1, (2,), {'b': 3}) == (3, (2,), {'b': 1})
    assert ar.replace(1, (), {'b': 3}) == (3, (), {'b': 1})
    assert ar.replace(1, (), {}) == (None, (), {'b': 1})
    ar = ArgReplacer(foo, 'c')
    assert ar.replace(1, (2, 3), {}) == (None, (2, 3), {'c': 1})

# Generated at 2022-06-18 11:09:03.616598
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Default

        def initialize(self):
            pass

    class Default(Base):
        pass

    class Impl1(Base):
        pass

    class Impl2(Base):
        pass

    Base.configure(None)
    assert isinstance(Base(), Default)
    assert not isinstance(Base(), Impl1)
    assert not isinstance(Base(), Impl2)

    Base.configure(Default)
    assert isinstance(Base(), Default)
    assert not isinstance(Base(), Impl1)
    assert not isinstance(Base(), Impl2)

    Base.configure(Impl1)
    assert not isinstance(Base(), Default)

# Generated at 2022-06-18 11:09:14.986716
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(test_func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 5}) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=6) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 5, 'd': 6}) == 5
    assert arg_replacer.get_old_value((1, 2), {'c': 5, 'd': 6}, default=7) == 5
    assert arg_replacer.get_old_value((1, 2), {'d': 6}) == 3
    assert arg_replacer.get_old_

# Generated at 2022-06-18 11:09:19.578196
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
        def initialize(self, *args, **kwargs):
            pass
    tc = TestConfigurable()
    assert tc.initialize() == None


# Generated at 2022-06-18 11:09:30.456137
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)
