

# Generated at 2022-06-18 10:59:50.880139
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {'b': 3, 'c': 4}) == (3, (2,), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {'a': 2, 'b': 3, 'c': 4}) == (3, (), {'a': 2, 'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {}) == (None, (), {'b': 1})



# Generated at 2022-06-18 10:59:52.841251
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:00:03.548998
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c, d=4):
        pass
    arg_replacer = ArgReplacer(test_func, "d")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 6}) == 6
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 6}, default=5) == 6
    assert arg_replacer.get_old_value((1, 2, 3), {"e": 6}) == 4

# Generated at 2022-06-18 11:00:15.883804
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2), {'d': 4})
    assert old_value == None
    assert args == (1, 2)
    assert kwargs == {'d': 4, 'c': 3}
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2, 4), {'d': 4})
    assert old_value == 4
    assert args == (1, 2, 3)
    assert kwargs == {'d': 4}

# Generated at 2022-06-18 11:00:24.088726
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}, 5) == 1


# Generated at 2022-06-18 11:00:31.083457
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)

    class B(A):
        pass

    b = B()
    assert isinstance(b, B)

    class C(A):
        pass

    A.configure(C)
    c = A()
    assert isinstance(c, C)
    assert not isinstance(c, A)

    A.configure(B)
    b2 = A()
    assert isinstance(b2, B)
    assert not isinstance(b2, A)

# Generated at 2022-06-18 11:00:34.520044
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
        raise Exception("expected ImportError")
    except ImportError:
        pass



# Generated at 2022-06-18 11:00:39.308355
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f():
        try:
            raise ValueError()
        except:
            raise_exc_info(sys.exc_info())
    try:
        f()
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"



# Generated at 2022-06-18 11:00:43.313203
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        def initialize(self, *args, **kwargs):
            pass

    class C(A):
        def initialize(self, *args, **kwargs):
            pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)



# Generated at 2022-06-18 11:00:55.501370
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 2}, default=4) == 2
    assert r.get_old_value((), {"b": 2}, default=4) == 2
    assert r.get_old_value((), {}, default=4) == 4

    assert r.replace(4, (1, 2, 3), {}) == (2, (1, 4, 3), {})

# Generated at 2022-06-18 11:01:11.595797
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass

    replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = replacer.replace("new", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "new", 3)
    assert kwargs == {}

    replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = replacer.replace("new", (1,), {"b": 2})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"b": "new"}

    replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = replacer.replace("new", (1,), {})
    assert old_

# Generated at 2022-06-18 11:01:19.480428
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self):
            pass

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self):
            pass

    # Test that the default implementation is used if none is configured.
    assert isinstance(Base(), BaseImpl)
    assert isinstance(Sub(), SubImpl)

    # Test that the configured implementation is used.
    Base.configure(BaseImpl)

# Generated at 2022-06-18 11:01:28.132632
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configure.__func__ is Configurable.configure.__func__



# Generated at 2022-06-18 11:01:36.924608
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args

# Generated at 2022-06-18 11:01:49.038152
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    Base.configure(None)
    assert isinstance(Base(1, 2), BaseImpl)

# Generated at 2022-06-18 11:01:59.893435
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {})
    assert old_value == None
    assert args == (1, 2)
    assert kwargs == {'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {'c': 2})
    assert old_value == 2
    assert args == (1, 2)
    assert kwargs == {'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2, 3), {})
    assert old_value == 3

# Generated at 2022-06-18 11:02:11.122946
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("foo")
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)
    assert False, "didn't raise"

# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.

# Generated at 2022-06-18 11:02:13.393060
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("test")
    except:
        raise_exc_info(sys.exc_info())

# Generated at 2022-06-18 11:02:22.774775
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "a")
    args = (1, 2, 3)
    kwargs = {}
    assert arg_replacer.get_old_value(args, kwargs) == 1
    assert arg_replacer.get_old_value(args, kwargs, default=4) == 1
    assert arg_replacer.get_old_value((), {}, default=4) == 4
    assert arg_replacer.get_old_value((), {"a": 5}, default=4) == 5
    assert arg_replacer.get_old_value((), {"b": 5}, default=4) == 4


# Generated at 2022-06-18 11:02:26.427340
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:02:46.775068
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    args = (1, 2, 3)
    kwargs = {}
    old_value, args, kwargs = arg_replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4, 3)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(5, args, kwargs)
    assert old_value == 4
    assert args == (1, 4, 3)
    assert kwargs == {'b': 5}
    old_value, args, kwargs = arg_replacer.replace(6, args, kwargs)
    assert old_value == 5
   

# Generated at 2022-06-18 11:02:52.163995
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:02:57.089894
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

        def initialize(self, *args, **kwargs):
            pass

    class Impl(Base):
        pass

    Base.configure(Impl)
    assert isinstance(Base(), Impl)



# Generated at 2022-06-18 11:03:07.040502
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.replace(5, (1, 2), {}) == (3, (1, 2), {})
    assert arg_replacer.replace(5, (1, 2), {'c': 6}) == (6, (1, 2), {'c': 5})
    assert arg_replacer.replace(5, (1, 2, 7), {}) == (7, (1, 2, 5), {})
    assert arg_replacer.replace(5, (1, 2, 7), {'c': 6}) == (7, (1, 2, 5), {'c': 6})

# Generated at 2022-06-18 11:03:09.690259
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(error_number=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:03:17.578490
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'd')
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'d': 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5


# Generated at 2022-06-18 11:03:27.783776
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    # Test that initialize is called
    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    instance = TestConfigurableSubclass(1, 2, x=3, y=4)
    assert instance.args == (1, 2)
    assert instance.kwargs == {"x": 3, "y": 4}

    # Test that initialize is called when configured

# Generated at 2022-06-18 11:03:32.876852
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj['a'] == 1
    try:
        obj.b
        assert False
    except AttributeError:
        pass
    try:
        obj['b']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-18 11:03:42.426149
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self):
            pass

    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for method __new__ of class Configurable
    # Test for

# Generated at 2022-06-18 11:03:49.123859
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:03:59.098880
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:04:04.489485
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 5}, default=4) == 5
    assert r.get_old_value((1, 2, 3), {"b": 5}, default=4) == 2
    assert r.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4

# Generated at 2022-06-18 11:04:14.227771
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 5}, default=4) == 4


# Generated at 2022-06-18 11:04:17.667235
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            pass
    assert A.initialize is Configurable.initialize
    assert A().initialize is Configurable.initialize
    assert A()._initialize is Configurable._initialize
    assert A().initialize is not A()._initialize
    assert A().initialize is not A().initialize



# Generated at 2022-06-18 11:04:24.227965
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    replacer = ArgReplacer(func, 'b')
    assert replacer.get_old_value((1, 2, 3), {}) == 2
    assert replacer.get_old_value((1, 2, 3), {'b': 4}) == 2
    assert replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert replacer.get_old_value((1, 2, 3), {'c': 4}) == None
    assert replacer.get_old_value((1, 2, 3), {'c': 4}, 5) == 5


# Generated at 2022-06-18 11:04:31.960591
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)

    class B(A):
        pass

    b = B()
    assert isinstance(b, B)

    class C(A):
        def initialize(self, *args, **kwargs):
            pass

    c = C()
    assert isinstance(c, C)

    class D(A):
        def configurable_base(self):
            return D

        def configurable_default(self):
            return D

        def initialize(self, *args, **kwargs):
            pass

    d = D()

# Generated at 2022-06-18 11:04:34.626994
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            pass
    a = A()
    assert isinstance(a, A)


# Generated at 2022-06-18 11:04:43.803422
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=3, d=4):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) == 3
    assert r.get_old_value((1, 2), {}, 5) == 5
    assert r.get_old_value((1, 2, 6), {}) == 6
    assert r.get_old_value((1, 2, 6), {}, 5) == 6
    assert r.get_old_value((1, 2), {"c": 7}) == 7
    assert r.get_old_value((1, 2), {"c": 7}, 5) == 7
    assert r.get_old_value((1, 2, 6), {"c": 7}) == 6

# Generated at 2022-06-18 11:04:51.761684
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d['x'] == 1
    assert d.y is None
    assert d['y'] is None
    assert d.get('y') is None
    assert d.get('y', 2) == 2
    assert d.y == 2
    d.y = 3
    assert d.y == 3
    assert d['y'] == 3
    d['y'] = 4
    assert d.y == 4
    assert d['y'] == 4
    d.z
    assert False

# Generated at 2022-06-18 11:04:58.025311
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
    class B(A):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    A.configure(B, b=1)
    x = A(2, c=3)
    assert x.a == 2
    assert x.b == 1
    assert x.c == 3


# Generated at 2022-06-18 11:05:07.439009
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError()
    except ValueError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:05:12.220777
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:05:20.563935
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value(('a', 'b'), {}) == None
    assert arg_replacer.get_old_value(('a', 'b'), {'c': 'c'}) == 'c'
    assert arg_replacer.get_old_value(('a', 'b'), {'c': 'c', 'd': 'd'}) == 'c'
    assert arg_replacer.get_old_value(('a', 'b', 'c'), {}) == 'c'
    assert arg_replacer.get_old_value(('a', 'b', 'c'), {'c': 'c'}) == 'c'
    assert arg_replacer.get_

# Generated at 2022-06-18 11:05:31.152786
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    replacer = ArgReplacer(f, "b")
    assert replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert replacer.replace(1, (2,), {"b": 3, "c": 4}) == (3, (2,), {"b": 1, "c": 4})
    assert replacer.replace(1, (), {"b": 3, "c": 4}) == (3, (), {"b": 1, "c": 4})
    assert replacer.replace(1, (2,), {}) == (None, (2,), {"b": 1})
    assert replacer.replace(1, (), {}) == (None, (), {"b": 1})



# Generated at 2022-06-18 11:05:39.343082
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)
    assert not isinstance(a, C)

    A.configure(B)
    a = A()
    assert isinstance(a, A)
    assert isinstance(a, B)
    assert not isinstance(a, C)

    A.configure(C)
    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)
   

# Generated at 2022-06-18 11:05:45.381757
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c):
        pass
    arg_replacer = ArgReplacer(test_func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}

# Generated at 2022-06-18 11:05:56.903943
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo
        def configurable_default(self):
            return Foo
        def initialize(self):
            pass
    class Bar(Foo):
        def initialize(self):
            pass
    class Baz(Foo):
        def initialize(self):
            pass
    Foo.configure(Bar)
    assert isinstance(Foo(), Bar)
    assert isinstance(Bar(), Bar)
    assert isinstance(Baz(), Foo)
    Foo.configure(Baz)
    assert isinstance(Foo(), Baz)
    assert isinstance(Bar(), Bar)
    assert isinstance(Baz(), Baz)
    Foo.configure(None)
    assert isinstance(Foo(), Foo)
    assert isinstance(Bar(), Bar)
    assert isinstance

# Generated at 2022-06-18 11:06:01.591814
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    TestConfigurable()



# Generated at 2022-06-18 11:06:05.064651
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)
    assert False, "Did not raise"



# Generated at 2022-06-18 11:06:15.013781
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    arg_replacer = ArgReplacer(foo, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {})
    assert old_value is None
    assert args == (2,)


# Generated at 2022-06-18 11:06:29.020714
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d.foo = 1
    assert d.foo == 1
    assert d['foo'] == 1
    assert d.bar is None
    assert d['bar'] is None
    assert d.get('bar') is None
    assert d.get('bar', 2) == 2
    assert d.bar == 2
    d.bar = 3
    assert d.bar == 3
    assert d['bar'] == 3
    d['bar'] = 4
    assert d.bar == 4
    assert d['bar'] == 4
    d.update(dict(bar=5, baz=6))
    assert d.bar == 5
    assert d['bar'] == 5
    assert d.baz == 6
    assert d['baz'] == 6
    assert d.get('bar')

# Generated at 2022-06-18 11:06:39.657333
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(A(), A)
    assert not isinstance(A(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(A(), A)
    assert not isinstance(A(), B)

    A.configure(None)
    assert isinstance(A(), B)
    assert isinstance(A(), A)
    assert not isinstance(A(), C)

   

# Generated at 2022-06-18 11:06:49.907553
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass

    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}

    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:07:00.800413
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self):
            pass
    class B(A):
        def initialize(self):
            pass
    class C(A):
        def initialize(self):
            pass
    A.configure(B)
    assert isinstance(A(), B)
    A.configure(C)
    assert isinstance(A(), C)
    A.configure(None)
    assert isinstance(A(), A)
    A.configure(B, x=1)
    assert isinstance(A(), B)
    assert A().x == 1
    A.configure(C, x=2)
    assert isinstance(A(), C)
    assert A().x == 2


# Generated at 2022-06-18 11:07:05.471994
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:07:14.006517
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            # type: (Any, Any) -> None
            self.args = args
            self.kwargs = kwargs

    instance = TestConfigurableSubclass(1, 2, 3, foo=4, bar=5)
    assert instance.args == (1, 2, 3)
    assert instance.kwargs == {"foo": 4, "bar": 5}




# Generated at 2022-06-18 11:07:24.848930
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    assert A.configured_class() is A
    A.configure(None)
    assert A.configured_class() is A
    A.configure(A)
    assert A.configured_class() is A
    A.configure(None, foo=1)
    assert A.configured_class() is A
    assert A.__impl_kwargs == {"foo": 1}
    A.configure(A, foo=2)
    assert A.configured_class() is A
    assert A.__impl_kwargs == {"foo": 2}
    A.configure(None)
   

# Generated at 2022-06-18 11:07:33.908603
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b=None, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    assert arg_replacer.get_old_value((1,), {}) is None
    assert arg_replacer.get_old_value((1,), {"b": 2}) == 2
    assert arg_replacer.get_old_value((1,), {"b": 2}, default=3) == 2
    assert arg_replacer.get_old_value((1,), {"c": 2}) is None
    assert arg_replacer.get_old_value((1,), {"c": 2}, default=3) == 3


# Generated at 2022-06-18 11:07:44.922991
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(1)
    except Exception as e:
        assert errno_from_exception(e) == 1


# Generated at 2022-06-18 11:07:51.279427
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable.configure.__doc__ == Configurable.configure.__doc__
    assert TestConfigurable.configured_class.__doc__ == Configurable.configured_class.__doc__
    assert TestConfigurable.configurable_base.__doc__ == Configurable.configurable_base.__doc__
    assert TestConfigurable.configurable_default.__doc__ == Configurable.configurable_default.__doc__
    assert TestConfigurable.initialize.__doc__ == Configurable.initialize.__doc__
    assert Test

# Generated at 2022-06-18 11:08:08.081240
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c):
        pass
    arg_replacer = ArgReplacer(foo, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1,), {'b': 4}) == 4
    assert arg_replacer.get_old_value((1,), {'b': 4}, 5) == 4
    assert arg_replacer.get_

# Generated at 2022-06-18 11:08:11.207816
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise Exception("foo")
    except Exception:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:08:15.518381
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base
        def configurable_default(self):
            return Base
    class Impl(Base):
        def initialize(self, *args, **kwargs):
            pass
    Base.configure(Impl)
    assert Base() is not None



# Generated at 2022-06-18 11:08:24.384441
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, "c")
    args = (1, 2)
    kwargs = {"d": 5}
    assert arg_replacer.get_old_value(args, kwargs) == 3
    assert arg_replacer.get_old_value(args, kwargs, default=6) == 3
    assert arg_replacer.get_old_value(args, {}) == 3
    assert arg_replacer.get_old_value(args, {}, default=6) == 6
    assert arg_replacer.get_old_value((), {}, default=6) == 6
    assert arg_replacer.get_old_value((), {}, default=6) == 6
    assert arg_repl

# Generated at 2022-06-18 11:08:35.964145
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1,2), {'d': 5}) == 3
    assert arg_replacer.get_old_value((1,2), {'d': 5}, default=6) == 3
    assert arg_replacer.get_old_value((1,2), {'d': 5}, default=6) == 3
    assert arg_replacer.get_old_value((1,2), {'d': 5}, default=6) == 3
    assert arg_replacer.get_old_value((1,2), {'d': 5}, default=6) == 3

# Generated at 2022-06-18 11:08:46.288891
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d=None):
        pass
    arg_replacer = ArgReplacer(foo, 'c')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {})
    assert old_value == 3
    assert args == (1, 2, 'new_value')
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {'c': 3})
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {'c': 'new_value'}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {})
    assert old

# Generated at 2022-06-18 11:08:57.417860
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert not isinstance(A(), B)
    A.configure(None)
    assert isinstance(A(), A)

# Generated at 2022-06-18 11:09:00.579765
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)



# Generated at 2022-06-18 11:09:12.777143
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass

    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}

    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:09:14.818738
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("foo")
    except ValueError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-18 11:09:31.113520
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5
    assert arg_replacer.get_old_value((1,), {'b': 4}, 5) == 4
    assert arg_replacer.get_old_value((1,), {}, 5) == 5


# Generated at 2022-06-18 11:09:34.277385
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, None) == 3


# Generated at 2022-06-18 11:09:44.763938
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A