

# Generated at 2022-06-18 10:59:58.562702
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = replacer.replace("new", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "new", 3)
    assert kwargs == {}
    old_value, args, kwargs = replacer.replace("new", (1,), {"b": 2, "c": 3})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"b": "new", "c": 3}
    old_value, args, kwargs = replacer.replace("new", (1,), {"c": 3})
    assert old_value is None
    assert args == (1,)
    assert k

# Generated at 2022-06-18 11:00:09.100719
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 5})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 5})
    assert old_

# Generated at 2022-06-18 11:00:16.263851
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:18.515207
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, a, b):
            self.a = a
            self.b = b
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2


# Generated at 2022-06-18 11:00:23.743779
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj["a"] == 1
    try:
        obj.b
        assert False
    except AttributeError:
        pass
    try:
        obj["b"]
        assert False
    except KeyError:
        pass



# Generated at 2022-06-18 11:00:33.097466
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.foo = 1
    assert d.foo == 1
    assert d['foo'] == 1
    assert getattr(d, 'foo') == 1
    assert d.bar is None
    d.bar = 2
    assert d.bar == 2
    assert d['bar'] == 2
    assert getattr(d, 'bar') == 2
    d = ObjectDict({'foo': 1})
    assert d.foo == 1
    assert d['foo'] == 1
    assert getattr(d, 'foo') == 1
    assert d.bar is None
    d.bar = 2
    assert d.bar == 2
    assert d['bar'] == 2
    assert getattr(d, 'bar') == 2
    d = ObjectDict(foo=1)
    assert d.foo == 1
   

# Generated at 2022-06-18 11:00:36.757878
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:00:43.634629
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    replacer = ArgReplacer(func, "b")
    assert replacer.replace(1, (2, 3), {}) == (3, (2, 1), {})
    assert replacer.replace(1, (2,), {"b": 3}) == (3, (2,), {"b": 1})
    assert replacer.replace(1, (), {"b": 3}) == (3, (), {"b": 1})
    assert replacer.replace(1, (), {}) == (None, (), {"b": 1})



# Generated at 2022-06-18 11:00:50.769071
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:01:00.425543
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2), {'d': 4})
    assert old_value == None
    assert args == (1, 2)
    assert kwargs == {'d': 4, 'c': 'new_value'}
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {'d': 4})
    assert old_value == 3
    assert args == (1, 2, 'new_value')
    assert kwargs == {'d': 4}
    old_value, args, kwargs = arg_replacer.replace

# Generated at 2022-06-18 11:01:15.393966
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, "c")
    assert arg_replacer.replace(1, (2, 3), {}) == (None, (2, 3), {"c": 1})
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (4, (2, 3, 1), {})
    assert arg_replacer.replace(1, (2, 3), {"c": 4}) == (4, (2, 3), {"c": 1})



# Generated at 2022-06-18 11:01:21.979153
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d["foo"] = "bar"
    assert d.foo == "bar"
    assert d["foo"] == "bar"
    assert d.bar is None
    assert d["bar"] is None
    assert d.get("bar") is None
    assert d.get("bar", "baz") == "baz"
    assert d.get("foo") == "bar"
    assert d.get("foo", "baz") == "bar"
    assert d.get("foo", "baz") == "bar"
    d.bar = "baz"
    assert d.bar == "baz"
    assert d["bar"] == "baz"
    assert d.foo == "bar"
    assert d["foo"] == "bar"
    assert d.get

# Generated at 2022-06-18 11:01:32.434700
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a):
            self.a = a
    class B(A):
        def initialize(self, b):
            self.b = b
    class C(A):
        def initialize(self, c):
            self.c = c
    class D(B, C):
        def initialize(self, d):
            self.d = d
    class E(D):
        def initialize(self, e):
            self.e = e
    class F(E):
        def initialize(self, f):
            self.f = f
    class G(F):
        def initialize(self, g):
            self.g = g
    class H(G):
        def initialize(self, h):
            self.h = h

# Generated at 2022-06-18 11:01:42.460385
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {"c": 4, "b": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:01:54.305783
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace(5, (1, 2), {})
    assert old_value == 3
    assert args == (1, 2)
    assert kwargs == {'c': 5, 'd': 4}
    old_value, args, kwargs = arg_replacer.replace(5, (1, 2, 3), {})
    assert old_value == 3
    assert args == (1, 2, 5)
    assert kwargs == {'d': 4}
    old_value, args, kwargs = arg_replacer.replace(5, (1, 2), {'c': 3})
    assert old_

# Generated at 2022-06-18 11:02:03.693842
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configured_class() is TestConfigurable.configurable_default()
    assert TestConfigurable.configured_class() is TestConfigurable.configurable_base()

    class TestConfigurableSubclass(TestConfigurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurableSubclass

    TestConfigurableSubclass.configure(None)
    assert TestConfigurableSubclass.config

# Generated at 2022-06-18 11:02:15.269252
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}

    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:02:21.332899
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:02:25.759900
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable._save_configuration() == (None, {})
    TestConfigurable.configure(None, a=1, b=2)
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable._save_configuration() == (None, {"a": 1, "b": 2})
    TestConfigurable.configure(TestConfigurable, a=3, b=4)
   

# Generated at 2022-06-18 11:02:32.022003
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(22, "22")
    except Exception as e:
        assert errno_from_exception(e) == 22

    try:
        raise Exception("22")
    except Exception as e:
        assert errno_from_exception(e) == "22"

    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:02:52.151148
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    A.configure(None, c=3)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3

    class B(A):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    B.configure(None, d=4)
    b = B(1, 2, 3)
    assert b.a == 1
    assert b.b == 2
    assert b.c == 3
   

# Generated at 2022-06-18 11:02:58.093970
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    A.configure(None, c=3)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-18 11:03:08.223146
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
    assert old_value == 3


# Generated at 2022-06-18 11:03:16.667872
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, default=3) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}) == 3


# Generated at 2022-06-18 11:03:22.808930
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj['a'] == 1
    try:
        obj.b
        assert False
    except AttributeError:
        pass
    try:
        obj['b']
        assert False
    except KeyError:
        pass



# Generated at 2022-06-18 11:03:27.306640
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    ar = ArgReplacer(f, "b")
    assert ar.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert ar.replace(1, (2,), {"c": 4}) == (None, (2,), {"b": 1, "c": 4})



# Generated at 2022-06-18 11:03:38.567038
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        def initialize(self):
            pass

    class C(A):
        def initialize(self):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)


# Generated at 2022-06-18 11:03:51.166068
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace('new_value', (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, 'new_value', 3)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace('new_value', (1,), {'b': 2})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {'b': 'new_value'}

    old_value, args, kwargs = arg_replacer.replace('new_value', (), {'b': 2})
    assert old_value == 2


# Generated at 2022-06-18 11:04:00.449524
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self):
            pass

    TestConfigurable.configure(None)
    assert isinstance(TestConfigurable(), TestConfigurable)

    class TestConfigurableSubclass(TestConfigurable):
        pass

    assert isinstance(TestConfigurableSubclass(), TestConfigurableSubclass)

    class TestConfigurableSubclass2(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass2)
    assert isinstance(TestConfigurable(), TestConfigurableSubclass2)
    assert isinstance(TestConfigurableSubclass(), TestConfigurableSubclass)

    TestConfigurableSubclass.config

# Generated at 2022-06-18 11:04:12.146378
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.arg_pos == 1
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1, 2), {}, default=4) == 4
    assert r.get_old_value((1, 2), {"b": 3}) == 3
    assert r.get_old_value((1, 2), {"b": 3}, default=4) == 3
    assert r.get_old_value((1, 2), {"c": 3}, default=4) == 4

# Generated at 2022-06-18 11:04:41.333366
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4



# Generated at 2022-06-18 11:04:52.153178
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self):
            # type: () -> None
            pass

    class SubBase(Base):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return SubBase

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return SubBaseImpl


# Generated at 2022-06-18 11:04:58.337878
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, "error")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-18 11:05:04.140019
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(foo, 'c')
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2), {'d': 3})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'d': 3, 'c': 1}
    old_value, args, kwargs = arg_replacer.replace(1, (1, 2, 3), {'d': 3})
    assert old_value == 3
    assert args == (1, 2, 1)
    assert kwargs == {'d': 3}



# Generated at 2022-06-18 11:05:16.167260
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest

    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    class TestConfigurableSubclass(TestConfigurable):
        pass

    class TestConfigurableSubclass2(TestConfigurable):
        pass

    class TestConfigurableSubclassSubclass(TestConfigurableSubclass):
        pass

    class TestConfigurableSubclassSubclass2(TestConfigurableSubclass):
        pass

    class TestConfigurableSubclassSubclass3(TestConfigurableSubclass2):
        pass

    class TestConfigurableSubclassSubclass4(TestConfigurableSubclass2):
        pass


# Generated at 2022-06-18 11:05:26.381036
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {"b": 2, "c": 3}) == 2
    assert r.get_old_value((1,), {"c": 3}, default=4) == 4
    assert r.get_old_value((1, 2, 3), {"b": 4}) == 2
    assert r.get_old_value((1, 2, 3), {"b": 4}, default=5) == 2

# Generated at 2022-06-18 11:05:36.087550
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import tornado.ioloop
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver

# Generated at 2022-06-18 11:05:42.512991
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c, d=1, e=2):
        pass
    arg_replacer = ArgReplacer(func, "d")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=0) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 10}) == 10
    assert arg_replacer.get_old_value((1, 2, 3), {"d": 10}, default=0) == 10
    assert arg_replacer.get_old_value((1, 2, 3), {"e": 20}) == 1

# Generated at 2022-06-18 11:05:55.380278
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {'c': 5})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 5})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 5}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'c': 5})
    assert old_

# Generated at 2022-06-18 11:06:01.907219
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    class TestConfigurableImpl(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(TestConfigurableImpl)
    assert isinstance(TestConfigurable(), TestConfigurableImpl)



# Generated at 2022-06-18 11:07:04.569979
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub

        @classmethod
        def configurable_default(cls):
            return SubImpl

    class SubImpl(Sub):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    # Test that the default implementation is used when none is configured.

# Generated at 2022-06-18 11:07:12.442573
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 5}) == 5
    assert arg_replacer.get_old_value((1, 2), {'c': 5}, default=6) == 5
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=6) == 6
    assert arg_replacer.get_old_value((1, 2, 5), {}) == 5
    assert arg_replacer.get_old_value((1, 2, 5), {'c': 6}) == 5
    assert arg

# Generated at 2022-06-18 11:07:18.515170
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable



# Generated at 2022-06-18 11:07:28.584898
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    replacer = ArgReplacer(foo, "b")
    old_value, args, kwargs = replacer.replace("new", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "new", 3)
    assert kwargs == {}
    old_value, args, kwargs = replacer.replace("new", (1,), {"b": 2})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"b": "new"}
    old_value, args, kwargs = replacer.replace("new", (1,), {})
    assert old_value is None
    assert args == (1,)
    assert kwargs == {"b": "new"}



# Generated at 2022-06-18 11:07:36.956109
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)

# Generated at 2022-06-18 11:07:46.806533
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, default=None) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, default=5) == 4


# Generated at 2022-06-18 11:07:49.652341
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    try:
        obj.b
    except AttributeError:
        pass
    else:
        raise Exception("AttributeError not raised")


# Generated at 2022-06-18 11:08:00.482051
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Default

        def initialize(self, a, b):
            # type: (Any, Any) -> None
            self.a = a
            self.b = b

    class Default(Base):
        pass

    class Impl(Base):
        pass

    Base.configure(None)
    assert Base().__class__ is Default
    assert Base(1, 2).a == 1
    assert Base(1, 2).b == 2

    Base.configure(Impl)
    assert Base().__class__ is Impl


# Generated at 2022-06-18 11:08:05.095002
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3


# Generated at 2022-06-18 11:08:12.571722
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            self.initialize(*args, **kwargs)
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    c = TestConfigurable(1, 2, 3, foo=4, bar=5)
    assert c.args == (1, 2, 3)
    assert c.kwargs == dict(foo=4, bar=5)


# Generated at 2022-06-18 11:08:49.155004
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:09:00.354445
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfigurable(Configurable):
        def configurable_base(self):
            return MyConfigurable

        def configurable_default(self):
            return MyConfigurable

        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    MyConfigurable.configure(None)
    assert MyConfigurable(1, 2).a == 1
    assert MyConfigurable(1, 2).b == 2
    assert MyConfigurable(1, 2).c is None
    assert MyConfigurable(1, 2, c=3).c == 3

    MyConfigurable.configure(None, c=4)
    assert MyConfigurable(1, 2).c == 4
    assert MyConfigurable(1, 2, c=3).c == 3


# Generated at 2022-06-18 11:09:04.741550
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super(MyConfigurable, self).__init__()

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return MyConfigurable

        @classmethod
        def configurable_default(cls):
            return MyConfigurable

    MyConfigurable.configure(None)
    assert MyConfigurable(1, 2, foo=3, bar=4).args == (1, 2)

# Generated at 2022-06-18 11:09:15.995627
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c, d):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.replace(3, (1, 2, 4, 5), {}) == (4, (1, 2, 3, 5), {})
    assert arg_replacer.replace(3, (1, 2), {'c': 4, 'd': 5}) == (4, (1, 2), {'c': 3, 'd': 5})
    assert arg_replacer.replace(3, (1, 2), {'d': 5}) == (None, (1, 2), {'c': 3, 'd': 5})

# Generated at 2022-06-18 11:09:27.477267
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel

    from tornado.util import Configurable

    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    class TestConfigurableSubclass(TestConfigurable):
        pass

    class TestConfigurableSubclass2(TestConfigurable):
        pass

    class TestConfigurableSubclassSubclass(TestConfigurableSubclass):
        pass


# Generated at 2022-06-18 11:09:35.152289
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == None
    assert args == (2,)
    assert kwargs == {"c": 4, "b": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"c": 4, "b": 3})
    assert old_value == 3
    assert args == ()

# Generated at 2022-06-18 11:09:44.789734
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5,