

# Generated at 2022-06-18 10:59:58.509624
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:09.057576
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Default

    class Default(Base):
        pass

    class Impl(Base):
        pass

    Base.configure(Impl)
    assert Base() is not None
    assert isinstance(Base(), Impl)
    assert not isinstance(Base(), Default)
    assert Base.configured_class() is Impl

    # Test that the configuration is not inherited by subclasses.
    class Subclass(Base):
        pass

    assert Subclass.configured_class() is Default
    assert Subclass() is not None

# Generated at 2022-06-18 11:00:16.202303
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:27.817511
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2), {"c": 4}) == 4
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {"c": 4}) == 3
    assert r.replace(5, (1, 2), {}) == (None, (1, 2), {"c": 5})

# Generated at 2022-06-18 11:00:35.741033
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d=4):
        pass
    arg_replacer = ArgReplacer(foo, "d")
    assert arg_replacer.replace(5, (1, 2, 3), {}) == (4, (1, 2, 3), {})
    assert arg_replacer.replace(5, (1, 2, 3), {"d": 6}) == (6, (1, 2, 3), {"d": 5})
    assert arg_replacer.replace(5, (1, 2, 3, 7), {}) == (7, (1, 2, 3, 5), {})
    assert arg_replacer.replace(5, (1, 2, 3, 7), {"d": 6}) == (7, (1, 2, 3, 5), {})



# Generated at 2022-06-18 11:00:38.586756
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)



# Generated at 2022-06-18 11:00:48.734819
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=None, d=None):
        pass
    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2), {"c": 4}) == 4
    assert r.get_old_value((1, 2), {"c": 4, "d": 5}) == 4
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {"c": 4}) == 3
    assert r.get_old_value((1, 2, 3), {"d": 5}) == 3
    assert r.get_

# Generated at 2022-06-18 11:00:54.560337
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:00:59.684673
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:01:09.715314
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        def initialize(self):
            # type: () -> None
            pass

    class C(A):
        def initialize(self):
            # type: () -> None
            pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    assert not isinstance(B(), A)
    assert not isinstance(C(), A)
    assert not isinstance(A(), B)


# Generated at 2022-06-18 11:01:35.935082
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) == 3
    assert arg_replacer.get_old_value((1, 2), {}, 5) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 6}) == 6
    assert arg_replacer.get_old_value((1, 2), {"c": 6}, 5) == 6
    assert arg_replacer.get_old_value((1, 2), {"d": 6}) == 3
    assert arg_replacer.get_old_value((1, 2), {"d": 6}, 5) == 5

# Generated at 2022-06-18 11:01:47.675049
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    arg_replacer = ArgReplacer(foo, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value is None
    assert args == (2,)
    assert kwargs == {"c": 4, "b": 1}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3

# Generated at 2022-06-18 11:01:58.695202
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, 'b')
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {'c': 4})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {'b': 3, 'c': 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {'b': 1, 'c': 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {'b': 3, 'c': 4})
   

# Generated at 2022-06-18 11:02:06.276449
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 2, 'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1, 2), {'b': 2, 'c': 3}, default=4) == 1
    assert arg_replacer.get_old_value((1, 2), {'b': 2, 'c': 3}, default=4) == 1

# Generated at 2022-06-18 11:02:17.123313
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(1, (2, 3), {'c': 4}) == (3, (2, 1), {'c': 4})
    assert arg_replacer.replace(1, (2, 3), {}) == (3, (2, 1), {})
    assert arg_replacer.replace(1, (2,), {'c': 4}) == (None, (2,), {'b': 1, 'c': 4})
    assert arg_replacer.replace(1, (), {'c': 4}) == (None, (), {'b': 1, 'c': 4})

# Generated at 2022-06-18 11:02:25.343243
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c):
        pass
    arg_replacer = ArgReplacer(foo, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, default=5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4, 'a': 5}) == 1


# Generated at 2022-06-18 11:02:31.620076
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        def initialize(self, *args, **kwargs):
            pass

    A.configure(B)
    assert isinstance(A(), B)



# Generated at 2022-06-18 11:02:38.888419
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return BaseImpl

    class BaseImpl(Base):
        def initialize(self, foo):
            # type: (str) -> None
            self.foo = foo

    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Sub

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return SubImpl


# Generated at 2022-06-18 11:02:49.425306
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a, b, c):
        pass
    arg_replacer = ArgReplacer(test_func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, default=5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}, default=5)

# Generated at 2022-06-18 11:03:00.112488
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    # Test that the initialize method is called
    class TestConfigurableSubclass(TestConfigurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    instance = TestConfigurableSubclass(1, 2, 3, a=4, b=5, c=6)
    assert instance.args == (1, 2, 3)
    assert instance.kwargs == {"a": 4, "b": 5, "c": 6}

    # Test that the initialize method is called

# Generated at 2022-06-18 11:03:20.508517
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 5}, default=4)

# Generated at 2022-06-18 11:03:25.327850
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    test_configurable = TestConfigurable()
    assert isinstance(test_configurable, TestConfigurable)



# Generated at 2022-06-18 11:03:32.781866
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, None) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}, 5) == 5


# Generated at 2022-06-18 11:03:37.409268
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return TestConfigurable
    tc = TestConfigurable()
    assert tc.initialize() == None


# Generated at 2022-06-18 11:03:50.754474
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    class B(A):
        def initialize(self, a, b, c):
            super(B, self).initialize(a, b)
            self.c = c

    class C(A):
        pass

    A.configure(B, b=2)
    assert isinstance(A(1), B)
    assert A(1).a == 1
    assert A(1).b == 2
    assert A(1).c == 1

    A.configure(C)

# Generated at 2022-06-18 11:03:59.651206
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 5}) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=6) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 7}, default=6) == 7
    assert arg_replacer.get_old_value((1, 2), {'e': 7}, default=6) == 6
    assert arg_replacer.get_old_value((1, 2), {'e': 7}) is None


# Generated at 2022-06-18 11:04:11.204723
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    assert isinstance(a, A)

    A.configure(B)
    a = A()
    assert isinstance(a, B)

    A.configure(C)
    a = A()
    assert isinstance(a, C)

    A.configure(None)
    a = A()
    assert isinstance(a, A)

    A.configure(B)
    a = A()
    assert isinstance(a, B)

    A.configure(None)
   

# Generated at 2022-06-18 11:04:17.116340
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}, None) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, None) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 5


# Generated at 2022-06-18 11:04:21.034394
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:04:29.122330
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "a")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 2
    assert args == (1, 3, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"c": 4})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value is None
    assert args == ()

# Generated at 2022-06-18 11:04:58.067468
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configured_class() is TestConfigurable

    class TestConfigurableSubclass(TestConfigurable):
        pass

    TestConfigurable.configure(TestConfigurableSubclass)
    assert TestConfigurable.configured_class() == TestConfigurableSubclass
    assert TestConfig

# Generated at 2022-06-18 11:05:07.647911
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'b': 2, 'c': 3}
    replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert args == (1, 4, 3)
    assert kwargs == {'c': 3}
    replacer = ArgReplacer(func, 'd')
    old_value, args, kwargs = replacer.replace(4, args, kwargs)
    assert old_value is None
    assert args == (1, 4, 3)
    assert kwargs == {'c': 3, 'd': 4}



# Generated at 2022-06-18 11:05:17.450679
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}, 5) == 1


# Generated at 2022-06-18 11:05:22.524916
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:05:32.667807
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 3
    assert args == (2, 1, 4)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}
    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})
    assert old_value is None
    assert args

# Generated at 2022-06-18 11:05:37.813996
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c is None



# Generated at 2022-06-18 11:05:49.738048
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {'d': 5}) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=6) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=7) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=8) == 3
    assert arg_replacer.get_old_value((1, 2), {'d': 5}, default=9) == 3

# Generated at 2022-06-18 11:05:59.175442
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {'b': 4}, 5) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {'a': 4}, 5) == 1
    assert arg_replacer.get_old_value((1, 2), {'a': 4}) == 1
    assert arg

# Generated at 2022-06-18 11:06:08.429932
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    replacer = ArgReplacer(func, 'b')
    assert replacer.get_old_value((1, 2, 3), {}) == 2
    assert replacer.get_old_value((1,), {'b': 2}) == 2
    assert replacer.get_old_value((1,), {'b': 2, 'c': 3}) == 2
    assert replacer.get_old_value((1,), {'c': 3}) == None
    assert replacer.get_old_value((1,), {'c': 3}, default=4) == 4


# Generated at 2022-06-18 11:06:17.234982
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=4, e=5):
        pass

    r = ArgReplacer(f, "d")
    assert r.get_old_value((1, 2, 3), {}) == 4
    assert r.get_old_value((1, 2, 3), {}, default=6) == 6
    assert r.get_old_value((1, 2, 3), {"d": 7}) == 7
    assert r.get_old_value((1, 2, 3), {"e": 7}) == 4
    assert r.get_old_value((1, 2, 3), {"d": 7}, default=6) == 7
    assert r.get_old_value((1, 2, 3), {"e": 7}, default=6) == 6

    r = ArgReplacer(f, "e")
   

# Generated at 2022-06-18 11:07:05.222173
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) == 3
    assert arg_replacer.get_old_value((1, 2), {}, default=5) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 6}) == 6
    assert arg_replacer.get_old_value((1, 2), {"c": 6}, default=5) == 6
    assert arg_replacer.get_old_value((1, 2), {"d": 6}) == 3
    assert arg_replacer.get_old_value((1, 2), {"d": 6}, default=5) == 5

# Generated at 2022-06-18 11:07:12.466564
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 5
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) is None


# Generated at 2022-06-18 11:07:17.853137
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self):
            pass

    TestConfigurable.configure(None)
    TestConfigurable()



# Generated at 2022-06-18 11:07:27.910612
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(test_func, "c")
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2), {})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {"c": "new_value"}
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2), {"c": "old_value"})
    assert old_value == "old_value"
    assert args == (1, 2)
    assert kwargs == {"c": "new_value"}

# Generated at 2022-06-18 11:07:36.591169
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base
        @classmethod
        def configurable_default(cls):
            return BaseImpl
    class BaseImpl(Base):
        def initialize(self):
            self.initialized = True
    class Sub(Base):
        @classmethod
        def configurable_base(cls):
            return Sub
        @classmethod
        def configurable_default(cls):
            return SubImpl
    class SubImpl(Sub):
        def initialize(self):
            self.initialized = True
    class SubImpl2(Sub):
        def initialize(self):
            self.initialized = True
    class SubSub(Sub):
        @classmethod
        def configurable_base(cls):
            return SubSub

# Generated at 2022-06-18 11:07:43.564795
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable.configure.__doc__ == Configurable.configure.__doc__



# Generated at 2022-06-18 11:07:48.658058
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, default=3) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}) == 3


# Generated at 2022-06-18 11:07:54.264333
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, 'a')
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}) == 1
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, default=5) == 1
    assert arg_replacer.get_old_value((1, 2), {'c': 4}) == 1
    assert arg_replacer.get_old_value((1, 2), {'c': 4}, default=5) == 1
    assert arg_replacer.get_old_value((1, 2), {'b': 3, 'c': 4}) == 1

# Generated at 2022-06-18 11:08:05.557956
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)
    assert not isinstance(a, C)

    A.configure(B)
    b = A()
    assert isinstance(b, A)
    assert isinstance(b, B)

# Generated at 2022-06-18 11:08:11.350159
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() == TestConfigurable



# Generated at 2022-06-18 11:08:58.214508
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}) == 1
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}, default=4) == 1
    assert arg_replacer.get_old_value((1,2,3), {'c':3}, default=4) == 4
    assert arg_replacer.get_old_value((1,2,3), {'b':2, 'c':3}, default=4) == 1

# Generated at 2022-06-18 11:09:10.474190
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.arg_pos == 1
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {}, default=4) == 4
    assert r.get_old_value((1,), {"b": 5}) == 5
    assert r.get_old_value((1,), {"b": 5}, default=4) == 5
    assert r.replace(5, (1, 2, 3), {}) == (2, (1, 5, 3), {})

# Generated at 2022-06-18 11:09:15.226890
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b):
            self.a = a
            self.b = b

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:09:19.771063
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2, 3)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-18 11:09:28.547824
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    t = TestConfigurable(1, 2, 3, a=4, b=5, c=6)
    assert t.args == (1, 2, 3)
    assert t.kwargs == dict(a=4, b=5, c=6)



# Generated at 2022-06-18 11:09:35.854593
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2), {'b': 2})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'b': 2, 'c': 3}
    old_value, args, kwargs = arg_replacer.replace(3, (1, 2, 3), {'b': 2})
    assert old_value == 3
    assert args == (1, 2, 3)
    assert kwargs == {'b': 2}