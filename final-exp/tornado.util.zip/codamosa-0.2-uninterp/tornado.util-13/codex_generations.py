

# Generated at 2022-06-18 10:59:59.247313
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2, 3), {})
    assert old_value == 2
    assert args == (1, "new_value", 3)
    assert kwargs == {}
    old_value, args, kwargs = arg_replacer.replace("new_value", (1,), {"b": 2})
    assert old_value == 2
    assert args == (1,)
    assert kwargs == {"b": "new_value"}
    old_value, args, kwargs = arg_replacer.replace("new_value", (), {"b": 2})
    assert old_value == 2
    assert args == ()


# Generated at 2022-06-18 11:00:09.860831
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def configurable_base(self):
            return TestConfigurable

        def configurable_default(self):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    # Test that the initialize method is called
    class TestConfigurable2(TestConfigurable):
        def initialize(self, *args, **kwargs):
            super(TestConfigurable2, self).initialize(*args, **kwargs)
            self.args = args
            self.kwargs = kwargs

    test_configurable2 = TestConfigurable2(1, 2, 3, a=4, b=5, c=6)
    assert test_configurable2.args == (1, 2, 3)

# Generated at 2022-06-18 11:00:21.656491
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c is None

    A.configure(None, c=3)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 3

    A.configure(None, c=4)
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    assert a.c == 4

# Generated at 2022-06-18 11:00:27.567964
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:00:35.804815
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c=None, d=None):
        pass

    r = ArgReplacer(func, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=42) == 42
    assert r.get_old_value((1, 2), {"c": 3}) == 3
    assert r.get_old_value((1, 2), {"d": 4}) is None
    assert r.get_old_value((1, 2), {"c": 3, "d": 4}) == 3

    assert r.replace(42, (1, 2), {}) == (None, (1, 2), {"c": 42})

# Generated at 2022-06-18 11:00:45.245919
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.get_old_value((1, 2, 3), {}, default=4) == 2
    assert r.get_old_value((1,), {"b": 2, "c": 3}) == 2
    assert r.get_old_value((1,), {"c": 3}, default=4) == 4
    assert r.replace(4, (1, 2, 3), {}) == (2, (1, 4, 3), {})
    assert r.replace(4, (1,), {"b": 2, "c": 3}) == (2, (1,), {"b": 4, "c": 3})
    assert r

# Generated at 2022-06-18 11:00:52.435260
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-18 11:01:01.462804
# Unit test for function import_object
def test_import_object():
    import_object('tornado.escape')
    import_object('tornado.escape.utf8')
    import_object('tornado')
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass

# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.

# Generated at 2022-06-18 11:01:08.235072
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return Base

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return Base

    class Impl(Base):
        def initialize(self):
            # type: () -> None
            pass

    Base.configure(Impl)
    assert isinstance(Base(), Base)
    assert isinstance(Base(), Impl)



# Generated at 2022-06-18 11:01:14.864262
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    replacer = ArgReplacer(f, 'b')
    assert replacer.get_old_value((1, 2, 3), {}) == 2
    assert replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert replacer.get_old_value((1,), {'b': 2, 'c': 3}) == 2
    assert replacer.get_old_value((1,), {'c': 3}, default=4) == 4


# Generated at 2022-06-18 11:01:33.009157
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        def initialize(self, *args, **kwargs):
            pass

    class C(A):
        def initialize(self, *args, **kwargs):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), A)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)

# Generated at 2022-06-18 11:01:43.202131
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Foo

        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    Foo.configure(None, c=3)
    f = Foo(1, 2)
    assert f.a == 1
    assert f.b == 2
    assert f.c == 3

    Foo.configure(None, c=4)
    f = Foo(1, 2)
    assert f.a == 1
    assert f.b == 2
    assert f.c == 4

    Foo.configure(None, c=5)

# Generated at 2022-06-18 11:01:52.055727
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {"c": 3}) == 3
    assert arg_replacer.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert arg_replacer.get_old_value((1, 2), {"d": 3}, default=4) == 4


# Generated at 2022-06-18 11:02:02.051177
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    class B(A):
        def initialize(self):
            pass

    class C(A):
        def initialize(self):
            pass

    A.configure(B)
    assert isinstance(A(), B)
    A.configure(C)
    assert isinstance(A(), C)
    A.configure(None)
    assert isinstance(A(), A)
    A.configure(B, foo=1)
    assert isinstance(A(foo=2), B)
    assert A(foo=2).foo == 2
    A.configure(C, foo=3, bar=4)

# Generated at 2022-06-18 11:02:13.192659
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

        def initialize(self):
            pass

    class Subclass(Base):
        pass

    class Subclass2(Base):
        pass

    assert isinstance(Base(), Base)
    assert isinstance(Subclass(), Base)
    assert isinstance(Subclass2(), Base)

    Base.configure(Subclass2)
    assert isinstance(Base(), Base)
    assert isinstance(Subclass(), Base)
    assert isinstance(Subclass2(), Base)

    Base.configure(Subclass)
    assert isinstance(Base(), Base)
    assert isinstance(Subclass(), Base)
    assert isinstance(Subclass2(), Base)

    Base.configure(None)
   

# Generated at 2022-06-18 11:02:23.213626
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)

    A.config

# Generated at 2022-06-18 11:02:34.415795
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        pass
    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 4}, default=5) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}) is None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 4}, default=5) == 5
   

# Generated at 2022-06-18 11:02:43.796938
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) == None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, 4) == 3
    assert arg_replacer.get_old_value((1, 2), {}, 4) == 4


# Generated at 2022-06-18 11:02:53.929185
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    assert isinstance(D(), D)

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    assert isinstance(D(), D)

    A.configure(C)

# Generated at 2022-06-18 11:03:03.373327
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b=2, *args, **kwargs):
            self.a = a
            self.b = b
            self.args = args
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    a = A(1, b=3, c=4, d=5)
    assert a.a == 1
    assert a.b == 3
    assert a.args == ()
    assert a.kwargs == {"c": 4, "d": 5}



# Generated at 2022-06-18 11:03:23.225345
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class C(Configurable):
        def __init__(self, a, b, c=None):
            pass

        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

    C.configure(None)
    C(1, 2)
    C(1, 2, 3)
    C(a=1, b=2)
    C(a=1, b=2, c=3)
    C(1, b=2)
    C(1, b=2, c=3)
    C(1, 2, c=3)
    C(1, c=3, b=2)
    C(c=3, b=2, a=1)

# Generated at 2022-06-18 11:03:32.928767
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(1, "error")
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(1)
    except IOError as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError(1, "error")
    except IOError as e:
        assert errno_from_ex

# Generated at 2022-06-18 11:03:42.426436
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    class B(A):
        pass

    class C(A):
        def initialize(self, a, b, c=None):
            super(C, self).initialize(a, b, c=c)
            self.d = a + b


# Generated at 2022-06-18 11:03:54.435487
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)


# Generated at 2022-06-18 11:04:02.267715
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {}, default=3) == 3
    assert r.get_old_value((1, 2), {"c": 4}) == 4
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {"c": 4}) == 3
    assert r.replace(5, (1, 2), {}) == (None, (1, 2), {"c": 5})

# Generated at 2022-06-18 11:04:13.496567
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert not isinstance(A(), C)
    assert isinstance(B(), B)
    assert not isinstance(B(), C)
    assert isinstance(C(), C)
    assert not isinstance(C(), B)

    A.configure(C)


# Generated at 2022-06-18 11:04:19.232465
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    r = ArgReplacer(f, "b")
    assert r.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert r.replace(1, (2,), {"b": 3, "c": 4}) == (3, (2,), {"b": 1, "c": 4})
    assert r.replace(1, (), {"b": 3, "c": 4}) == (3, (), {"b": 1, "c": 4})
    assert r.replace(1, (), {}) == (None, (), {"b": 1})



# Generated at 2022-06-18 11:04:23.391436
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.a = 1
    assert obj.a == 1
    assert obj['a'] == 1
    try:
        obj.b
        assert False
    except AttributeError:
        pass
    try:
        obj['b']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-18 11:04:31.276956
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(A(), A)
    assert not isinstance(A(), C)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(A(), A)
    assert not isinstance(A(), B)
    A.configure(None)
    assert isinstance(A(), A)
    assert not isinstance(A(), B)
    assert not isinstance(A(), C)


# Generated at 2022-06-18 11:04:38.319776
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-18 11:04:55.984325
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=4, e=5):
        pass

    r = ArgReplacer(f, "d")
    assert r.get_old_value((1, 2, 3), {}) == 4
    assert r.get_old_value((1, 2, 3), {}, default=6) == 6
    assert r.get_old_value((1, 2, 3), {"d": 7}) == 7
    assert r.get_old_value((1, 2, 3, 8), {}) == 8
    assert r.get_old_value((1, 2, 3, 8), {"d": 7}) == 8
    assert r.get_old_value((1, 2, 3, 8, 9), {"d": 7}) == 8

# Generated at 2022-06-18 11:05:02.771732
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(foo, "b")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {"c": 4})
    assert old_value == 3
    assert args == (2, 1)
    assert kwargs == {"c": 4}

    old_value, args, kwargs = arg_replacer.replace(1, (2,), {"b": 3, "c": 4})
    assert old_value == 3
    assert args == (2,)
    assert kwargs == {"b": 1, "c": 4}

    old_value, args, kwargs = arg_replacer.replace(1, (), {"b": 3, "c": 4})

# Generated at 2022-06-18 11:05:11.251765
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    a = A(1, 2, 3, foo=4, bar=5)
    assert a.args == (1, 2, 3)
    assert a.kwargs == {"foo": 4, "bar": 5}



# Generated at 2022-06-18 11:05:20.000329
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:05:30.650429
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.twisted import TwistedIOLoop
    from tornado.platform.select import SelectIOLoop
    from tornado.platform.auto import AutoIOLoop
    from tornado.platform.caresresolver import CaresResolver
    from tornado.platform.twisted import TwistedResolver
    from tornado.platform.asyncio import AsyncIOResolver
    from tornado.platform.select import SelectResolver
    from tornado.platform.auto import AutoResolver
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.twisted import TwistedIOLoop
    from tornado.platform.select import SelectIOLoop
    from tornado.platform.auto import AutoIOLoop

# Generated at 2022-06-18 11:05:32.755122
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            pass
    a = A()
    assert isinstance(a, A)


# Generated at 2022-06-18 11:05:37.629271
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, d=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {"c": 3}) == 3
    assert r.get_old_value((1, 2), {"c": 3}, default=4) == 3
    assert r.get_old_value((1, 2), {"d": 3}, default=4) == 4
    assert r.replace(5, (1, 2), {}) == (None, (1, 2), {"c": 5})
    assert r.replace(5, (1, 2), {"c": 6}) == (6, (1, 2), {"c": 5})

# Generated at 2022-06-18 11:05:49.411946
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.replace(1, (2, 3, 4), {}) == (3, (2, 1, 4), {})
    assert arg_replacer.replace(1, (2,), {"b": 3, "c": 4}) == (3, (2,), {"b": 1, "c": 4})
    assert arg_replacer.replace(1, (), {"b": 3, "c": 4}) == (3, (), {"b": 1, "c": 4})
    assert arg_replacer.replace(1, (2, 3), {"c": 4}) == (None, (2, 1), {"c": 4})

# Generated at 2022-06-18 11:05:54.000151
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    a = A()
    assert isinstance(a, A)



# Generated at 2022-06-18 11:06:00.912238
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {})
    assert old_value is None
    assert args == (2, 3)
    assert kwargs == {"c": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3), {"c": 4})
    assert old_value == 4
    assert args == (2, 3)
    assert kwargs == {"c": 1}
    old_value, args, kwargs = arg_replacer.replace(1, (2, 3, 4), {})
    assert old_value == 4

# Generated at 2022-06-18 11:06:21.470883
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:06:23.708031
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b):
            self.a = a
            self.b = b

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2



# Generated at 2022-06-18 11:06:34.620644
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass
    args = (1, 2, 3)
    kwargs = {'b': 2, 'c': 3}
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.replace(4, args, kwargs) == (2, (1, 4, 3), {'c': 3})
    assert arg_replacer.replace(4, args, kwargs) == (2, (1, 4, 3), {'c': 3})
    assert arg_replacer.replace(5, args, kwargs) == (2, (1, 5, 3), {'c': 3})
    assert arg_replacer.replace(6, args, kwargs) == (2, (1, 6, 3), {'c': 3})
   

# Generated at 2022-06-18 11:06:45.595081
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, a, b=1):
            self.a = a
            self.b = b
    class B(A):
        def initialize(self, a, b=2):
            self.a = a
            self.b = b
    class C(A):
        def initialize(self, a, b=3):
            self.a = a
            self.b = b
    A.configure(C)
    assert isinstance(A(1), C)
    assert A(1).b == 3
    assert A(1, b=4).b == 4
    assert isinstance(B(1), B)
    assert B(1).b == 2
    assert B(1, b=4).b == 4
    A.configure(B)

# Generated at 2022-06-18 11:06:53.204312
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, *args, **kwargs):
            pass

    assert isinstance(A(), A)
    assert isinstance(A(), Configurable)

    class B(A):
        pass

    assert isinstance(B(), B)
    assert isinstance(B(), A)
    assert isinstance(B(), Configurable)

    class C(A):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

    assert isinstance(C(), C)
    assert not isinstance(C(), A)
    assert isinstance

# Generated at 2022-06-18 11:07:05.222786
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass
    ar = ArgReplacer(func, "c")
    assert ar.get_old_value((1, 2), {}) == 3
    assert ar.get_old_value((1, 2), {}, 5) == 5
    assert ar.get_old_value((1, 2), {"c": 6}) == 6
    assert ar.get_old_value((1, 2), {"c": 6}, 5) == 6
    assert ar.get_old_value((1, 2), {"d": 6}) == 3
    assert ar.get_old_value((1, 2), {"d": 6}, 5) == 5
    assert ar.get_old_value((1, 2, 3), {}) == 3

# Generated at 2022-06-18 11:07:09.456319
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-18 11:07:15.654143
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)
    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(C(), C)



# Generated at 2022-06-18 11:07:26.403188
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, 'c')
    assert arg_replacer.get_old_value((1, 2), {}, None) is None
    assert arg_replacer.get_old_value((1, 2), {'c': 3}, None) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {}, None) == 3
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, None) == 4
    assert arg_replacer.get_old_value((1, 2, 3), {'c': 4}, 5) == 4
    assert arg_replacer.get_old_value((1, 2), {}, 5) == 5
    assert arg_repl

# Generated at 2022-06-18 11:07:30.368779
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Base

    class Impl(Base):
        pass

    Base.configure(Impl)
    assert isinstance(Base(), Impl)
    assert isinstance(Base(), Base)



# Generated at 2022-06-18 11:08:54.462653
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=None):
        pass
    arg_replacer = ArgReplacer(f, "c")
    assert arg_replacer.get_old_value((1, 2), {}) is None
    assert arg_replacer.get_old_value((1, 2), {}, "default") == "default"
    assert arg_replacer.get_old_value((1, 2), {"c": "foo"}) == "foo"
    assert arg_replacer.get_old_value((1, 2), {"c": "foo"}, "default") == "foo"
    assert arg_replacer.get_old_value((1, 2), {"d": "bar"}) is None
    assert arg_replacer.get_old_value((1, 2), {"d": "bar"}, "default") == "default"


# Generated at 2022-06-18 11:09:05.573924
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=None, d=None):
        pass
    arg_replacer = ArgReplacer(func, "c")
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2), {"d": 4})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {"d": 4, "c": "new_value"}
    old_value, args, kwargs = arg_replacer.replace("new_value", (1, 2, 3), {"d": 4})
    assert old_value == 3
    assert args == (1, 2, "new_value")
    assert kwargs == {"d": 4}

# Generated at 2022-06-18 11:09:17.320681
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(C(), B)
    assert isinstance(C(), C)

    A.configure(C)
    assert isinstance(A(), C)
    assert isinstance(B(), B)
    assert isinstance(C(), C)

    A.configure(None)
    assert isinstance(A(), A)
    assert isinstance(B(), B)

# Generated at 2022-06-18 11:09:22.520657
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return A
        def initialize(self, a, b):
            self.a = a
            self.b = b
    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2


# Generated at 2022-06-18 11:09:32.353318
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.get_old_value((1, 2, 3), {}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"b": 5}, default=4) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}) == None
    assert arg_replacer.get_old_value((1, 2, 3), {"c": 5}, default=4) == 4
   