

# Generated at 2022-06-24 09:22:36.651587
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import unittest
    doctests()  # to ensure the module-level variables get initialized



# Generated at 2022-06-24 09:22:43.974236
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(arg1, arg2, kwarg=None):
        pass
    arg1 = 1
    arg2 = 2
    kwarg = 3
    args = [arg1, arg2]
    kwargs = {'kwarg': kwarg}
    replacer = ArgReplacer(func, 'arg1')
    old_value, new_args, new_kwargs = replacer.replace('arg3', args, kwargs)
    assert arg1 == old_value
    assert new_args[0] == 'arg3'
    assert new_args[1] == arg2
    assert new_kwargs['kwarg'] == kwarg
    assert new_kwargs['arg1'] == 'arg3'


# Generated at 2022-06-24 09:22:47.956603
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict(foo='bar')
    obj.foo == 'bar'
    obj['foo'] == 'bar'


GZIP_HEADER = b"\x1f\x8b\x08"

# self.request is set by Application.__call__, always
_ARG_DEFAULT = object()



# Generated at 2022-06-24 09:22:50.152384
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    config = Configurable()
    assert config.configurable_base() is config
    assert config.configurable_default() is config



# Generated at 2022-06-24 09:22:51.621639
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.b = '1'
    assert a.b == '1'



# Generated at 2022-06-24 09:22:56.464454
# Unit test for function import_object
def test_import_object():
    assert import_object("os") is os
    assert import_object("os.path") is os.path
    assert import_object(".") is __import__(".")
    assert import_object(".base64") is __import__(".base64")
    with pytest.raises(ImportError):
        assert import_object("nonexistent_module")
    with pytest.raises(ImportError):
        assert import_object("os.nonexistent_module")



# Generated at 2022-06-24 09:23:02.422597
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    # rst expectations are not well-supported on windows
    # https://bugs.python.org/issue27091
    if sys.platform != "win32":
        return doctests()
    else:
        return unittest.SkipTest(
            "doctest expectations are not well-supported on windows"
        )

# Generated at 2022-06-24 09:23:05.890615
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    test_dict = ObjectDict()
    test_dict.test = "test"
    assert test_dict.test == "test"
    assert test_dict["test"] == "test"


# Generated at 2022-06-24 09:23:12.449076
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict({"a": 1, "b": 2})
    assert x.a == 1
    assert x["a"] == 1
    assert x.b == 2
    assert x["b"] == 2
    x.c = 3
    assert x["c"] == 3
    x.a = 4
    assert x.a == 4
    assert x["a"] == 4
    x["a"] = 5
    assert x.a == 5
    assert x["a"] == 5



# Generated at 2022-06-24 09:23:21.893570
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    obj = ArgReplacer(int,[1,2,3,4,5,6,7,8,9])
    assert obj.get_old_value([1,2,3,4,5,6,7,8,9]) is None
    assert obj.get_old_value([1,2,3,4,5,6,7,8,9],default = 0) == 0
    assert obj.get_old_value([1,2,3,4,5,6,7,8,9],kwargs = {'base':3}) is None
    assert obj.get_old_value([1,2,3,4,5,6,7,8,9],kwargs = {'base':3},default = 2) == 2

# Generated at 2022-06-24 09:23:33.454485
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    m = ObjectDict(a=1)
    assert isinstance(m, dict)
    assert m["a"] == 1
    m.b = 2
    assert m["b"] == 2
    m["c"] = 3
    assert m.c == 3


# Generated at 2022-06-24 09:23:37.006362
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict()
    x.hello = "world"
    assert x["hello"] == "world"
    assert x.hello == "world"
    assert x.hello == "world"



# Generated at 2022-06-24 09:23:40.508815
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(['asdf', 'asdf'])
    d['asdf']
    d.asdf
    d = ObjectDict(['asdf'])
    d['asdf']



# Generated at 2022-06-24 09:23:43.837838
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    E = Configurable()
    with pytest.raises(NotImplementedError):
        E.configurable_base()
    with pytest.raises(NotImplementedError):
        E.configurable_default()
    E.initialize()


# Generated at 2022-06-24 09:23:49.525843
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b):
        return a, b

    a = ArgReplacer(func, "a")
    retval = a.replace("foo", ("bar",), {})
    assert retval == ("bar", ("foo",), {})

    b = ArgReplacer(func, "b")
    retval = b.replace("foo", (), {})
    assert retval == (None, (), {"b": "foo"})

    retval = b.replace("foo", (), {"b": "bar"})
    assert retval == ("bar", (), {"b": "foo"})



# Generated at 2022-06-24 09:23:53.901786
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    od = ObjectDict()
    od.foo = 'bar'
    od.moo = 'cow'
    assert getattr(od, 'foo') == 'bar'
    assert getattr(od, 'moo') == 'cow'
    assert list(od.keys()) == ['foo', 'moo']
    assert list(od.items()) == [('foo', 'bar'), ('moo', 'cow')]



# Generated at 2022-06-24 09:23:56.891795
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj['xx'] = 0
    # Access dict by attribute
    obj.xx


# Generated at 2022-06-24 09:23:58.381331
# Unit test for function exec_in
def test_exec_in():
    exec_in('a = b', dict(b='foo'))



# Generated at 2022-06-24 09:24:00.655097
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import StringIO
    gzipper = GzipDecompressor()
    f = StringIO.StringIO()
    f.write('Hello')
    decompressed_data = gzipper.decompress(f.getvalue())
    assert (decompressed_data=='Hello')

# Generated at 2022-06-24 09:24:12.289727
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict(a=1, b=2)
    assert x.a == 1
    assert x.b == 2
    assert x["a"] == 1
    assert x["b"] == 2
    assert "a" in x
    assert "b" in x
    assert "c" not in x
    try:
        x.c
    except AttributeError:
        pass
    else:
        assert False, "Expected AttributeError"

    x.c = 3
    assert x.c == 3
    assert x["c"] == 3

    y = ObjectDict([("a", 1), ("b", 2)])
    assert y.a == 1
    assert y.b == 2

    z = ObjectDict({"a": 1, "b": 2})
    assert z.a == 1

# Generated at 2022-06-24 09:24:14.180258
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise Exception()
    except:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-24 09:24:15.035366
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    pass

# Usage example for class GzipDecompressor

# Generated at 2022-06-24 09:24:20.256601
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.netutil import TCPServer
    from tornado.options import options

    if sys.version_info < (3, 7):
        # type: ignore
        # python3.6 does not support recursive generics
        def test_interface(T):  # type type: ignore
            class M(T): pass
            assert issubclass(M, T)
            assert isinstance(M(), T)
            return M

        def test_interface_with_args(T):  # type type: ignore
            class M(T): pass
            assert issubclass(M, T)
            assert isinstance(M(1), T)
            return M


# Generated at 2022-06-24 09:24:23.655520
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    from datetime import timedelta
    assert timedelta_to_seconds(timedelta(1)) == 86400
    assert timedelta_to_seconds(timedelta(microseconds=1)) == 0.000001

_DEFAULT_SIGN = object()


# Generated at 2022-06-24 09:24:24.878886
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0



# Generated at 2022-06-24 09:24:33.263038
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "Expected an import error"


# Aliases for types that are spelled differently in different Python
# versions.  These are deprecated aliases for all names.
# New code should prefer the native spelling, which is the default
# in typing annotations and indicated in the docs with a + sign.

# Generated at 2022-06-24 09:24:35.232516
# Unit test for function import_object
def test_import_object():
    import_object('sys')
    return import_object



# Generated at 2022-06-24 09:24:40.830904
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(x=5,y=5):
        return x+y
    args = (3,4)
    kwargs = {'x':2}
    repl = ArgReplacer(foo, 'x')
    assert repl.replace('abc', args, kwargs) == (2, (3,4), {'x':'abc','y':5})



# Generated at 2022-06-24 09:24:42.687522
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict()
    obj.key = "value"
    assert obj.key == "value"



# Generated at 2022-06-24 09:24:45.899207
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError("")
    except TimeoutError:
        pass


# Aliases for backwards-compatibility
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:24:49.605352
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Check for non-string
    gzip_decompressor = GzipDecompressor()
    try:
        gzip_decompressor.decompress(None)
    except TypeError:
        pass



# Generated at 2022-06-24 09:24:57.775729
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401
    assert timedelta_to_seconds(datetime.timedelta(days=-1)) == -86400
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=-1)) == -86401



# Generated at 2022-06-24 09:25:08.836885
# Unit test for constructor of class Configurable

# Generated at 2022-06-24 09:25:17.836681
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(bar, baz):
        print(bar, baz)
    r = ArgReplacer(foo, 'bar')
    assert r.get_old_value((1, 2), {}) == 1
    assert r.get_old_value((1, 2), {}, 3) == 1
    assert r.get_old_value((), {'bar': 1}) == 1
    assert r.get_old_value((), {'bar': 1}, 3) == 1
    assert r.get_old_value((), {}, 3) == 3
    assert r.replace(2, (1, 3), {}) == (1, (2, 3), {})
    assert r.replace(2, (1,), {'bar': 1}) == (1, (2,), {})

# Generated at 2022-06-24 09:25:26.073171
# Unit test for method decompress of class GzipDecompressor

# Generated at 2022-06-24 09:25:36.062609
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(x, y=0, z=0):
        pass

    rep1 = ArgReplacer(func, "y")
    old, new_args, new_kwargs = rep1.replace(1, (0,), {})
    assert old == 0 and new_args == (0, 1) and new_kwargs == {}

    rep2 = ArgReplacer(func, "z")
    old, new_args, new_kwargs = rep2.replace(1, (0,), {})
    assert old == 0 and new_args == (0,) and new_kwargs == {"z": 1}

    rep3 = ArgReplacer(func, "w")
    old, new_args, new_kwargs = rep3.replace(1, (0,), {})
    assert old is None and new_args == (0,)

# Generated at 2022-06-24 09:25:46.094209
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def my_func(a, b, c):
        pass
    arg_replacer = ArgReplacer(my_func, "b")
    old_b, args, kwargs = arg_replacer.replace("new_b", [1, 2, 3], {})
    assert old_b == 2
    assert args == [1, "new_b", 3]
    assert kwargs == {}

    old_b, args, kwargs = arg_replacer.replace(
        "new_b", [1, 2], {"c": 3, "b": 4}
    )
    assert old_b == 4
    assert args == [1, 2]
    assert kwargs == {"c": 3, "b": "new_b"}



# Generated at 2022-06-24 09:25:48.624697
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 42
    assert d.foo == 42
    assert d["foo"] == 42
    assert object.__getattribute__(d, "foo") == 42



# Generated at 2022-06-24 09:25:57.301364
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class MyClass(object):
        def __init__(self, a, b, c, d=None, e=None):
            pass

    # Replace a positional argument
    r = ArgReplacer(MyClass, "b")
    assert r.replace(6, (1, 2, 3), {}) == (2, (1, 6, 3), {})
    # Pass the argument by keyword
    assert r.replace(6, (1,), {"b": 2, "c": 3}) == (2, (1,), {"b": 6, "c": 3})
    # Pass a different argument by keyword
    assert r.replace(6, (1, 2, 3), {"c": 3}) == (2, (1, 2, 3), {"b": 6, "c": 3})
    # Replace an omitted argument

# Generated at 2022-06-24 09:26:08.154453
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Unit test for method initialize of class Configurable
    class Dummy(Configurable):
        def configurable_base(cls) -> typing.Type[Configurable]:
            return super(Dummy, cls).configurable_base()

        def configurable_default(cls) -> typing.Type[Configurable]:
            return super(Dummy, cls).configurable_default()

    assert Dummy.configured_class() is None

    Dummy.configure("threading")
    assert Dummy.configured_class().__name__ == "ThreadingImpl"

    Dummy.configure(None)
    assert Dummy.configured_class() is None

    Dummy.configure(threading)
    assert Dummy.configured_class() is threading


# Generated at 2022-06-24 09:26:10.771286
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("foo")
    except ValueError:
        raise_exc_info(sys.exc_info())
    assert False, "Did not raise"  # pragma: nocover



# Generated at 2022-06-24 09:26:12.956186
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f1():
        raise IndexError()
    try:
        f1()
    except:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-24 09:26:21.652508
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import mock
    import time
    import tornado.ioloop
    from tornado import testing
    from tornado.concurrent import Future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.auto import AutoIOLoop
    from tornado.platform.select import SelectIOLoop
    from tornado.web import Application
    from tornado.iostream import IOStream
    from tornado.websocket import WebSocketHandler
    # Testing the Configurable class directly, rather than through
    # inheritance, since we want to test base/impl correlation.
    class FakeIOLoop(Configurable):
        def __init__(self, impl, **kwargs):
            pass
        def initialize(self, impl, **kwargs):
            pass
        @classmethod
        def configurable_base(cls):
            return FakeIOLoop

# Generated at 2022-06-24 09:26:24.911074
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class AbstractClass(Configurable):
        def configurable_base(self):
            return AbstractClass

        def configurable_default(self):
            return AbstractClass

        def _initialize(self):
            pass

        initialize = _initialize


# Generated at 2022-06-24 09:26:26.933351
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    obj = GzipDecompressor()
    obj.decompressobj.flush()
    obj.flush()


# Generated at 2022-06-24 09:26:31.290947
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    a = typing.cast(ObjectDict, ObjectDict(a=1, b=2))
    a.a == 1
    a.b == 2
    a["a"] == 1
    a["b"] == 2

    a.new = 3
    a["new"] == 3
    a.new == 3



# Generated at 2022-06-24 09:26:34.340297
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():

    obj = ObjectDict({"a":1})
    assert obj.a == 1
    assert obj.b == AttributeError(name="b")

    obj.a = 2
    assert obj.a == 2


# Generated at 2022-06-24 09:26:42.152775
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    args = (1, 2, 3)
    kwargs = {'a': 4}
    # success case
    arg_replacer = ArgReplacer(lambda x,y,z:None, 'y')
    old_value, new_args, new_kwargs = arg_replacer.replace(4, args, kwargs)
    assert old_value == 2
    assert new_args == (1, 4, 3)
    assert new_kwargs == {'a': 4}
    # failure case
    arg_replacer = ArgReplacer(lambda x,y,z:None, 'b')
    old_value, new_args, new_kwargs = arg_replacer.replace(4, args, kwargs)
    assert old_value is None
    assert new_args == (1, 2, 3)

# Generated at 2022-06-24 09:26:51.925973
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # type: () -> None
    class SomeCustomException(Exception):
        pass

    def tests(err, e_type, e_custom_type = None, e_args = None):
        # type: (int, str, Optional[Type[BaseException]], Optional[Sequence[Any]],) -> None
        """Performs a test on a type of exception"""
        e = e_type(errno=err)
        assert errno_from_exception(e) == err

        e = e_type(err)
        assert errno_from_exception(e) == err

        # No argument error
        e = e_type()
        assert errno_from_exception(e) is None

        # Exception without a errno

# Generated at 2022-06-24 09:26:54.343663
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    attr = 'attr'
    value = 'value'
    obj = ObjectDict()
    obj[attr] = value
    obj.__getattr__(attr)


# Generated at 2022-06-24 09:26:59.512798
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    # This test is a little tricky because we can't assume that
    # non-ASCII characters can be printed to the terminal.
    # Save and restore stdout encoding so that the failure message
    # is meaningful.
    old_stdout_encoding = sys.stdout.encoding
    if old_stdout_encoding is None:
        old_stdout_encoding = "utf-8"
    # On python 2, doctest compares results to expected outputs as
    # unicode objects, and doesn't allow non-ascii bytestrings
    # through.  On python 3, it compares as bytestrings, and
    # non-ascii characters are not allowed.

# Generated at 2022-06-24 09:27:02.528004
# Unit test for function raise_exc_info
def test_raise_exc_info():  # type: () -> None
    try:
        raise ValueError("foo")
    except ValueError as e:
        tb = e.__traceback__
        raise_exc_info((ValueError, e, tb))
    assert False, "failed to raise"



# Generated at 2022-06-24 09:27:05.401274
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import unittest
    import doctest

    suite = doctests()
    # I don't know why this is necessary, but doctest.testmod
    # doesn't work with the output capture here.
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)



# Generated at 2022-06-24 09:27:08.157887
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # regression test for pre-2.7
    # timedelta.total_seconds() was added in 2.7.
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86461.0



# Generated at 2022-06-24 09:27:09.297310
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Issue #1135
    GzipDecompressor().flush()



# Generated at 2022-06-24 09:27:12.102509
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    delta = datetime.timedelta(days=1, seconds=2, microseconds=3)
    assert timedelta_to_seconds(delta) == 86400 + 2 + 3e-6



# Generated at 2022-06-24 09:27:12.867007
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    pass



# Generated at 2022-06-24 09:27:17.279328
# Unit test for function errno_from_exception
def test_errno_from_exception():
    import errno
    try:
        raise socket.error(errno.EIO, "Broken")
    except Exception as e:
        assert errno_from_exception(e) == errno.EIO



# Generated at 2022-06-24 09:27:27.763621
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict({'a': 'b'})  # type: ObjectDict
    assert d.a == 'b'
    d.x = 1
    assert d.x == 1
    with pytest.raises(AttributeError):
        d.y  # type: ignore  # https://github.com/python/mypy/issues/1927

# Declare typing.NamedTuple instead of class ObjectDict to support
# calling getattr on the result.
_StackContext = typing.NamedTuple('_StackContext', [
    ('method_name', str),
    ('context_dict', Optional[ObjectDict]),
    ('keywords', Optional[Mapping[str, Any]]),
])
_NullContext = _StackContext(None, None, None)  # type: _StackContext

# Traceback representing the

# Generated at 2022-06-24 09:27:34.343670
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class MyClass(Configurable):
        pass

    class TestClass(MyClass):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[MyClass]
            return MyClass

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[TestClass]
            return TestClass

        def __init__(self):
            # MyClass.__init__(self)
            self.foo = 1

    assert isinstance(MyClass(), MyClass)
    assert isinstance(MyClass(), TestClass)
    assert MyClass().foo == 1
    assert TestClass.configured_class() is TestClass
    assert TestClass.configured_class() is TestClass
    #

# Generated at 2022-06-24 09:27:44.724246
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func1(a, b, unused_c=None, *d, **e):
        pass

    def func2(a, b, c=None, *d, **e):
        pass

    args = (1, 2, 4)
    kwargs = dict(unused_c=3, e=5)
    replacer = ArgReplacer(func1, "c")
    assert replacer.get_old_value(args, kwargs, 42) == 42
    assert replacer.replace("foo", args, kwargs) == (
        None,
        (1, 2, "foo", 4, 5),
        dict(),
    )

    replacer = ArgReplacer(func2, "c")
    assert replacer.get_old_value(args, kwargs, 42) == 42
    assert replacer

# Generated at 2022-06-24 09:27:47.557559
# Unit test for function exec_in
def test_exec_in():
    a = 5
    ns = dict(a=100)
    exec_in("a = a + 1", globals(), ns)
    assert ns['a'] == 101
    assert a == 5


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__"
# break when this code is run under 2to3.

# Generated at 2022-06-24 09:27:56.728221
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Base(Configurable):
        pass

    class Impl1(Base):
        pass

    class Impl2(Base):
        pass

    Base.configure(None)
    assert isinstance(Base(), Base)
    assert isinstance(Base(), Impl1)

    Base.configure("tests.util.Impl2")
    assert isinstance(Base(), Base)
    assert isinstance(Base(), Impl2)
    assert not isinstance(Base(), Impl1)

    Base.configure(Impl1)
    assert isinstance(Base(), Base)
    assert isinstance(Base(), Impl1)
    assert not isinstance(Base(), Impl2)

    Base.configure(Impl1, foo="bar")
    assert isinstance(Base(), Base)
    assert isinstance(Base(), Impl1)

# Generated at 2022-06-24 09:28:05.350224
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'test_gzip.txt'), 'rb') as f:
        chunk_size = 1024 * 1024
        gzip_compressor = zlib.compressobj(9, zlib.DEFLATED, 16 + zlib.MAX_WBITS, zlib.DEF_MEM_LEVEL, 0)
        chunk = f.read(chunk_size)
        gzip_text = b""
        while chunk:
            gzip_text += gzip_compressor.compress(chunk)
            chunk = f.read(chunk_size)
        gzip_text += gzip_compressor.flush()
    gzip_decompressor = GzipDecompressor()

# Generated at 2022-06-24 09:28:10.833289
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict(foo='bar')
    assert d.foo == 'bar'
    assert d['foo'] == 'bar'
    try:
        d.bar
    except AttributeError:
        pass
    else:
        assert False, "did not raise AttributeError"
    try:
        d['bar']
    except KeyError:
        pass
    else:
        assert False, "did not raise KeyError"



# Generated at 2022-06-24 09:28:12.020279
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    assert ObjectDict().__setattr__('name_1', 1) == None



# Generated at 2022-06-24 09:28:13.755234
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError("message")
    assert str(e) == "message"
    assert repr(e) == "<TimeoutError: message>"



# Generated at 2022-06-24 09:28:21.848935
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, d=None):
        pass

    r = ArgReplacer(f, "c")
    assert r.arg_pos == 2  # positional args
    assert r.get_old_value((1, 2, 3), {}) == 3
    assert r.get_old_value((1, 2, 3), {}, None) == 3
    assert r.get_old_value((1, 2, 3), {}, 4) == 3
    assert r.get_old_value((1, 2, 3), {}, c=4) == 3
    assert r.replace(4, (1, 2, 3), {}) == (3, (1, 2, 4), {})
    assert r.replace(4, (1, 2), {}) == (None, (1, 2), {"c": 4})

# Generated at 2022-06-24 09:28:24.275910
# Unit test for function exec_in
def test_exec_in():
    d = dict()
    exec_in('foo = 123', d)
    assert 'foo' in d
    assert d['foo'] == 123


# Generated at 2022-06-24 09:28:34.413376
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # type: () -> None
    data = b"x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1a\x04\xc5\x04\x00\x00\x00"
    gzip_decompressor = GzipDecompressor()
    assert gzip_decompressor.decompress(data) == b"Hello world"
    assert gzip_decompressor.unconsumed_tail == b""
    assert gzip_decompressor.flush() == b""
    assert gzip_decompressor.unconsumed_tail == b""

    gzip_decompressor = GzipDecompressor()

# Generated at 2022-06-24 09:28:38.858869
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None):
        return a, b, c
    arg_replacer = ArgReplacer(f, "c")
    assert arg_replacer.replace(3, (1, 2), {}) == (None, (1, 2), {"c": 3})
    assert arg_replacer.replace(3, (1, 2), {"c": 4}) == (4, (1, 2), {"c": 3})



# Generated at 2022-06-24 09:28:43.344438
# Unit test for function doctests
def test_doctests():
    # type: () -> unittest.TestSuite
    import doctest
    import os.path
    import tornado.util
    return doctest.DocFileSuite(
        os.path.join(os.path.dirname(tornado.util.__file__), "util.py"),
        module_relative=False)

# Generated at 2022-06-24 09:28:48.229383
# Unit test for function re_unescape
def test_re_unescape():
    # type: () -> None
    assert re_unescape("hello") == "hello"
    assert re_unescape("hello\\.world") == "hello.world"
    assert re_unescape("hello\\\\world") == "hello\\world"
    assert re_unescape("hello\\/world") == "hello/world"
    assert re_unescape("hello\\|world") == "hello|world"
    assert re_unescape("hello\\[world") == "hello[world"
    assert re_unescape("hello\\]world") == "hello]world"
    assert re_unescape("hello\\(world") == "hello(world"
    assert re_unescape("hello\\)world") == "hello)world"
    assert re_unescape("hello\\^world") == "hello^world"

# Generated at 2022-06-24 09:28:50.440225
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1



# Generated at 2022-06-24 09:28:53.622823
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(*args, **kwargs):
        pass
    assert ArgReplacer(foo, "bar").replace(2, (), {"baz": 1}) == (None, (), {"baz": 1, "bar": 2})



# Generated at 2022-06-24 09:28:59.472849
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError(1, 2, foo="bar")
    assert e.args == (1, 2)
    assert e.kwargs == {"foo": "bar"}

# Alias for backwards compatibility
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError


# Generated at 2022-06-24 09:29:09.019875
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1)) == -1.0
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60.0
    assert timedelta_to_seconds(datetime.timedelta(minutes=-1)) == -60.0
    assert timedelta_to_seconds(datetime.timedelta(1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(-1)) == -86400.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=0.001)) == 0.001

# Generated at 2022-06-24 09:29:17.249592
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # type: () -> None
    # Ensure that Exception.__init__ is called,
    # so the stack trace is produced at construction time
    try:
        1 / 0
    except ZeroDivisionError:
        e = TimeoutError('foo', cause=sys.exc_info())
        assert str(e) == 'foo'
        assert e.__cause__ is not None
        assert isinstance(e.__cause__, ZeroDivisionError)
        assert e.__traceback__ is not None



# Generated at 2022-06-24 09:29:25.958205
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import zlib
    gd = GzipDecompressor()
    data = gd.decompress(b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00+,Q\x04\x00\x11\xe0')
    assert gd.unconsumed_tail != ''
    assert gd.flush() == ''
    assert gd.unconsumed_tail == ''
    gd = GzipDecompressor()
    data = gd.decompress(
        b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00+,Q\x04\x00\x11\xe0', 0
    )
    assert gd.unconsumed

# Generated at 2022-06-24 09:29:37.379259
# Unit test for function exec_in
def test_exec_in():
    glob = {}
    loc = {}
    exec_in("def foo(a, b): return a+b", glob)
    exec_in(b"print('abc')", glob, loc)
    exec_in(u"x = u'ü'", glob, loc)
    glob["foo"](10, 20)
    glob["x"]
    assert "__builtins__" not in glob
    assert "__builtins__" in loc
test_exec_in()


# Fake byte literal support:  In python 2.6+, you can say b"foo" at the top
# level of a module to get a byte literal (str in 2.x, bytes in 3.x).
# There's no way to do this in a way that supports 2.5, though, so we need
# a function wrapper to convert our string literals in that case.

# Generated at 2022-06-24 09:29:46.258172
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class MyException(Exception):
        # This exception type should trigger the Exception portion
        # of errno_from_exception
        pass

    err = MyException()
    assert errno_from_exception(err) is None

    err = MyException(3)
    assert errno_from_exception(err) == 3

    err = IOError()
    assert errno_from_exception(err) is None

    err = IOError(4)
    assert errno_from_exception(err) == 4



# Generated at 2022-06-24 09:29:52.093075
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    x = ObjectDict(foo=42)
    assert x['foo'] == 42
    assert x.foo == 42
    assert getattr(x, 'foo') == 42
    x.foo = 37
    assert x['foo'] == 37
    x['bar'] = 10
    assert x.bar == 10



# Generated at 2022-06-24 09:30:02.276878
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    def test_factory(*args,**kwargs):
        return args,kwargs

    class TestClass(Configurable):

        initialize=test_factory

        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

    tcls = TestClass(1,2,3,kwarg=4)
    assert tcls == ((1,2,3), {'kwarg':4})
    assert TestClass.configure('tornado') is None
    # TODO: monkey patching fails...
    # @patch('tornado.util.Configurable.configure')
    # def test_Configurable_new_patch(self, mock_method):
    #     tcls = TestClass(1,2,3,kw

# Generated at 2022-06-24 09:30:08.671316
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def p(a, b, c):
        print(a)
        print(b)
        print(c)

    a = ArgReplacer(p,"b")
    l = list(range(3))
    d = {"a":0, "b":1, "c":2}
    a.replace(0,l,d)
    assert d["b"] == 0



# Generated at 2022-06-24 09:30:16.554345
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    print(Configurable.configurable_base())
    print(Configurable.configurable_default())
    print(Configurable.configured_class())
    print(Configurable.configure)
    print(Configurable.configured_class())
    print(Configurable.__impl_class)
    print(Configurable.__impl_kwargs)
    print(Configurable._save_configuration())
    print(Configurable._restore_configuration(Configurable._save_configuration()))
    pass


# Generated at 2022-06-24 09:30:21.690680
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    import sys
    try:
        raise TimeoutError()
    except TimeoutError as e:
        assert e.args == ()
    try:
        raise TimeoutError(1)
    except TimeoutError as e:
        assert e.args == (1,)
    assert isinstance(TimeoutError(1, 2j), TimeoutError)



# Generated at 2022-06-24 09:30:32.102354
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c):
        pass
    # test args replacement
    old_value, args, kwargs = ArgReplacer("a", f).replace("new_value", ("a", "b", "c"), {})
    assert old_value == "a"
    assert args == ("new_value", "b", "c")
    assert kwargs == {}
    # test kwargs replacement
    old_value, args, kwargs = ArgReplacer("a", f).replace("new_value", ("a", "b", "c"), {"a": "a"})
    assert old_value == "a"
    assert args == ("a", "b", "c")
    assert kwargs == {"a": "new_value"}
    # test new value added as an arg when not found
    old_value, args

# Generated at 2022-06-24 09:30:35.422968
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ZeroDivisionError("foo")
    except ZeroDivisionError:
        raise_exc_info(sys.exc_info())

# Generated at 2022-06-24 09:30:39.049734
# Unit test for function exec_in
def test_exec_in():
    exec_in("assert 1 == 2, 'one does not equal two'", {})  # noqa: F821
    exec_in("assert 1 == 2, 'one does not equal two'", {})  # noqa: F821



# Generated at 2022-06-24 09:30:41.019408
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(
        days=1, seconds=1, microseconds=1, milliseconds=1, minutes=1, hours=1, weeks=1)) == 694861.001001



# Generated at 2022-06-24 09:30:43.295753
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip=GzipDecompressor()
    gzip.decompress(b'aGz')


# Generated at 2022-06-24 09:30:45.436480
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from unittest import main
    from tornado.util import doctests

    main(module=__name__, defaultTest="doctests")


if __name__ == "__main__":
    test_doctests()

# Generated at 2022-06-24 09:30:53.496782
# Unit test for constructor of class GzipDecompressor

# Generated at 2022-06-24 09:31:01.742281
# Unit test for constructor of class Configurable
def test_Configurable():
    assert Configurable.configured_class() is None
    assert Configurable.configurable_default() is None
    assert Configurable.configurable_base() is Configurable

    class A(Configurable):
        b = None  # type: Optional[int]

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, b):
            self.b = b
    assert A.configurable_base() is A
    assert A.configurable_default() is A
    assert A.configured_class() is A
    assert A.configurable_default() is A
    assert A(1).b == 1


# Generated at 2022-06-24 09:31:06.914411
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import gzip

    compressor = gzip.GzipFile(mode="rb", fileobj=None, compresslevel=6)

    # Compress some text into a buffer
    compressor.write(b"TEST")
    compressor.write(b"ONE")
    compressor.write(b"TWO")
    compressor.write(b"THREE")
    compressor.write(b"FOUR")
    compressor.write(b"FIVE")
    buf = compressor.compress(b"SIX")
    buf += compressor.compress(b"SEVEN")
    buf += compressor.flush(zlib.Z_SYNC_FLUSH)
    buf += compressor.compress(b"EIGHT")
    buf += compressor.flush()

    # Try to decompress the contents of the buffer
    decompressor = GzipDecompressor()

# Generated at 2022-06-24 09:31:10.913459
# Unit test for function exec_in
def test_exec_in():
    loc = {}
    glob = {}
    exec_in('foo = 6', glob)
    assert glob['foo'] == 6
    exec_in('bar = 7', glob, loc)
    assert loc['bar'] == 7


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).
if bytes is str:
    def u(s: Any) -> str:
        return s

    bytes_type = str
else:
    def u(s: str) -> str:
        return s



# Generated at 2022-06-24 09:31:20.155960
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):
        def initialize(self):
            pass

        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            raise NotImplementedError()

    class FooImpl(Foo):
        @classmethod
        def configurable_default(cls):
            return FooImpl

    # Check that a subclass can be instantiated
    FooImpl()

    # Check that we can override the default at runtime with another subclass
    class FooImpl2(Foo):
        @classmethod
        def configurable_default(cls):
            return FooImpl2

    Foo.configure(FooImpl2)
    FooImpl2()
    Foo.configure(FooImpl)
    FooImpl()

    # Check that we can override the default

# Generated at 2022-06-24 09:31:23.023627
# Unit test for function re_unescape
def test_re_unescape():
    r = re_unescape(r"foo\+bar")
    assert r == "foo+bar", r

    # The following cannot be unescaped.
    # re_unescape(r"foo\)")
    # re_unescape(r"foo\[bar")
    # re_unescape(r"foo\*bar")



# Generated at 2022-06-24 09:31:29.099201
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():

    class TestClass(util.Configurable):

        @classmethod
        def configurable_base(cls):
            return TestClass

        @classmethod
        def configurable_default(cls):
            return TestClass

        def initialize(self):
            pass

    try:
        TestClass().initialize
    except Exception:
        raise AssertionError

    try:
        TestClass.configure(TestClass)
        TestClass.configure(TestClass, arg=2)
        TestClass.configure(impl=TestClass, arg=1)
    except Exception as e:
        raise AssertionError from e


# Generated at 2022-06-24 09:31:37.826301
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.platform.auto import set_close_exec

    class Dummy(Configurable):

        def configurable_base(self):
            return Dummy

        def configurable_default(self):
            return Dummy

        def initialize(self):
            pass


    class Derived(Dummy):
        def initialize(self):
            pass


    set_close_exec(0)
    try:
        assert isinstance(Dummy(), Dummy)
        assert isinstance(Derived(), Dummy)
        Dummy.configure(Derived)
        assert isinstance(Dummy(), Dummy)
        assert isinstance(Derived(), Dummy)
        Dummy.configure(None)
        assert isinstance(Dummy(), Dummy)
        assert isinstance(Derived(), Dummy)
    finally:
        set_close

# Generated at 2022-06-24 09:31:47.753910
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        def test(self):
            decompressor = GzipDecompressor()
            data = decompressor.decompress(b'')
            self.assertEqual(data, b'')
            self.assertNotEqual(decompressor.unconsumed_tail, b'')
            cleanup_result = decompressor.flush()
            self.assertEqual(cleanup_result, b'')
            self.assertEqual(decompressor.unconsumed_tail, b'')

    test_case = TestCase()
    test_case.run()

# Generated at 2022-06-24 09:31:50.153573
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj_dict = ObjectDict({'foo': 'bar'})
    assert obj_dict.foo == 'bar'



# Generated at 2022-06-24 09:31:58.277570
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class MyConfigurable(Configurable):
        def configurable_base(self):
            return MyConfigurable

        def configurable_default(self):
            return MyImpl

        def initialize(self):
            pass

    class MyImpl(MyConfigurable):
        pass

    instance = MyConfigurable()
    assert isinstance(instance, MyImpl)
    MyConfigurable.configure(None)
    assert isinstance(MyConfigurable(), MyImpl)
    MyConfigurable.configure("tornado.util.MyImpl")
    assert isinstance(MyConfigurable(), MyImpl)
    assert MyConfigurable._save_configuration() == (MyImpl, {})
    MyConfigurable.configure("tornado.util.MyImpl", foo=1)

# Generated at 2022-06-24 09:32:00.947359
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.key = 1
    assert obj.key == 1
    assert dict(obj) == {'key': 1}



# Generated at 2022-06-24 09:32:08.172935
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f():
        pass

    r = ArgReplacer(f, "foo")

    def g(a, b, c, foo):
        pass

    r = ArgReplacer(g, "foo")
    assert r.get_old_value((1, 2, 3, 4), {}) == 4
    assert r.get_old_value((1, 2, 3), {"foo": 5}) == 5
    assert r.get_old_value((1, 2, 3), {"foo": 5}, "default") == 5
    assert r.get_old_value((1, 2, 3), {}, "default") == "default"

    # If the default is not provided and the argument is not present,
    # an exception is raised

# Generated at 2022-06-24 09:32:18.223199
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return B

        def initialize(self):
            # type: () -> None
            self.initialized = True

    class B(A):
        pass

    class C(A):
        pass

    A.configure(B)
    a = A()
    assert isinstance(a, B)
    assert a.initialized

    A.configure(C)
    a = A()
    assert isinstance(a, C)
    assert a.initialized

    # Test the corner case of configuring an implementation class that is


# Generated at 2022-06-24 09:32:28.640192
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(0)
    except Exception as e:
        assert errno_from_exception(e) == 0

    try:
        raise Exception(42)
    except Exception as e:
        assert errno_from_exception(e) == 42

    errno = errno_from_exception(Exception())
    assert errno is None

    errno = errno_from_exception(Exception(0))
    assert errno == 0

    errno = errno_from_exception(Exception(42))
    assert errno == 42



# Generated at 2022-06-24 09:32:33.134439
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict()
    x.abc = 1
    x['abc'] = 2
    assert x.abc == 2
    assert x['abc'] == 2
    del x.abc
    assert hasattr(x, 'abc')
    del x['abc']
    assert not hasattr(x, 'abc')

