

# Generated at 2022-06-24 09:22:41.487093
# Unit test for function exec_in
def test_exec_in():
    globs = dict(x=1, y=2)
    exec_in("z = x + y", globs)
    assert globs['z'] == 3


# Fake byte literal for non-ASCII chars; unknown on Python 3.2 and
# earlier (but works fine, since the \x prefix is ignored).
if bytes is str:
    def u(s: str) -> bytes:
        # type: ignore
        return s.encode("ascii")

    def b(s: str) -> bytes:
        # type: ignore
        return s

    bytes_type = bytes
else:
    def u(s: str) -> bytes:
        return s.encode("ascii")

    def b(s: str) -> bytes:
        return s.encode("latin1")

    bytes_type = bytes


# Generated at 2022-06-24 09:22:44.321066
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise Exception("boom")
    except Exception:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-24 09:22:53.296008
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from unittest import mock
    from tornado.util import Configurable

    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C
            pass
        @classmethod
        def configurable_default(cls):
            return Implementation
            pass

    class Implementation(C):
        pass

    with mock.patch.object(Implementation, '__init__') as init:
        obj = C(1, mock.sentinel.arg, x=2)
        assert obj.__class__ == Implementation
        init.assert_called_once_with(1, mock.sentinel.arg, x=2)
    def run(self):
        C.configure(None)

    run(None)

# Generated at 2022-06-24 09:22:59.762081
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=2)) == 86462.0
    assert timedelta_to_seconds(datetime.timedelta(days=0, seconds=2)) == 2.0
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=-2)) == -86462.0



# Generated at 2022-06-24 09:23:11.049789
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a=None, b=None):
        pass
    new_value = "new"
    old_value = "old"
    # test 1: the pos argument exist
    replacer = ArgReplacer(f, "a")
    old_value, args, kwargs = replacer.replace(new_value, (old_value,), {})
    assert old_value == "old"
    assert args == ("new",)
    assert kwargs == {}

    # test 2: the keyword argument does not exist
    replacer = ArgReplacer(f, "c")
    old_value, args, kwargs = replacer.replace(new_value, (), {})
    assert old_value is None
    assert args == ()
    assert kwargs == {"c": "new"}

    # test 3: the keyword argument

# Generated at 2022-06-24 09:23:17.697688
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c):
        pass
    f = ArgReplacer(foo, "a")
    assert f.arg_pos == 0
    f = ArgReplacer(foo, "b")
    assert f.arg_pos == 1
    f = ArgReplacer(foo, "c")
    assert f.arg_pos == 2
    f = ArgReplacer(foo, "d")
    assert f.arg_pos is None



# Generated at 2022-06-24 09:23:20.848174
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    assert issubclass(Configurable, object)
    assert not hasattr(Configurable, '__init__')
    assert Configurable().initialize
    assert Configurable()._initialize
    assert Configurable.configurable_default
    assert Configurable.configurable_base


# Generated at 2022-06-24 09:23:24.144107
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o["key"] = "value"
    try:
        o.key
    except AttributeError:
        assert True


# Generated at 2022-06-24 09:23:34.388674
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    assert decompressor.decompress(b'') == b''
    # GzipDecompressor decompresses gzip data, so we must use base64 to
    # decode the test data.
    import base64

# Generated at 2022-06-24 09:23:44.987783
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from io import StringIO
    from contextlib import contextmanager

    # Clear all globals because they can mess with test_configurable_skip
    if len(globals()) > 1:
        raise Exception("globals() is too long at the start of " "Configurable tests")

    config = {}
    proto_configs = []

    def _mock_import_object(name):
        if name == "foo.BaseImpl":
            return config["BaseImpl"]
        elif name == "foo.AlphaImpl":
            return config["AlphaImpl"]
        elif name == "foo.BetaImpl":
            return config["BetaImpl"]
        else:
            raise ImportError("No module named %s" % name)

    def _mock_import_string(name):
        return _mock_import_object(name)


# Generated at 2022-06-24 09:23:45.570326
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    pass

# Generated at 2022-06-24 09:23:51.802539
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f():
        try:
            return 1 / 0
        except ZeroDivisionError:
            return sys.exc_info()

    def g():
        try:
            return f()
        except TypeError:
            return sys.exc_info()

    exc_info = f()
    try:
        raise_exc_info(exc_info)
    except ZeroDivisionError:
        pass
    exc_info = g()
    with pytest.raises(TypeError):
        raise_exc_info(exc_info)



# Generated at 2022-06-24 09:24:03.079560
# Unit test for function exec_in
def test_exec_in():
    code = "foo = 'x'"
    glob = {}  # type: Dict[str, Any]
    exec_in(code, glob)
    assert glob['foo'] == 'x'


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.
if bytes is str:
    def b(s: str) -> bytes:
        return s.encode("latin1")

    buffer_types

# Generated at 2022-06-24 09:24:04.954760
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()  # type: tornado.util.TimeoutError



# Generated at 2022-06-24 09:24:13.507074
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class ConfigurableTest(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ConfigurableTest

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return ConfigurableTest

        def initialize(self, x: int, y: int) -> None:
            self.x = x
            self.y = y

    c = ConfigurableTest(1, 2)
    assert c.x == 1
    assert c.y == 2



# Generated at 2022-06-24 09:24:18.860036
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def __init__(self, arg):
            assert isinstance(self, C)
            self.arg = arg

    class B(A):
        def initialize(self, arg):
            self.arg = arg

    class C(A):
        pass

    # Verifies that we can construct instances of both subclasses
    # of A before A.configure is called.
    # Test passing args to __init__
    A(1)
    B(2)
    # Test that _save_configuration and _restore_configuration work.
    saved = A._save_configuration()

# Generated at 2022-06-24 09:24:23.133784
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()

    def test():
        a: Any
        a = d
        assert isinstance(a, ObjectDict)
        a = d.abc
        assert isinstance(a, Exception)
        a = d.abc = 1
        assert isinstance(a, None)

    test()



# Generated at 2022-06-24 09:24:26.080162
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("foo\\.bar\\*baz") == "foo.bar*baz"
    assert re_unescape("foo.bar*baz") == "foo.bar*baz"
    with pytest.raises(ValueError):
        re_unescape("foo\\\\bar")
    with pytest.raises(ValueError):
        re_unescape("foo\\dbar")



# Generated at 2022-06-24 09:24:31.435882
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("hello world") == "hello world"
    assert re_unescape("\\.\\[\\\\\\]") == ".[\\]"
    assert re_unescape("\\a\\b\\f\\n\\r\\t\\v\\x01") == "\a\b\f\n\r\t\v\x01"
    assert re_unescape("\\x00\\01\\02\\11\\77\\100\\177") == "\x00\x01\x02\x09\x3f\x40\x7f"
    assert re_unescape("\\400\\777") == "\x00\x00\xdf\xbf"
    assert re_unescape("\\400\\7777") == "\x00\x00\xdf\xbf\x7f"

# Generated at 2022-06-24 09:24:32.578849
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("\\d") == "\\d"



# Generated at 2022-06-24 09:24:34.839603
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 09:24:45.322782
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    fh = open(__file__, "rb")
    fh.read(20)  # skip the first 20 bytes
    compressor = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS + 16)
    data = fh.read()
    compressed_data = compressor.compress(data)
    compressed_data += compressor.flush()
    fh.close()

    gzip_decompressor = GzipDecompressor()
    decompressed_data = gzip_decompressor.decompress(compressed_data)
    assert decompressed_data == data
    # this will raise an exception if it was not handled properly
    with pytest.raises(zlib.error):
        gzip_decompressor.flush()



# Generated at 2022-06-24 09:24:48.683820
# Unit test for function import_object
def test_import_object():
    import_object("unittest.mock") # should not error
    import_object("unittest.missing_module") # should error
test_import_object()



# Generated at 2022-06-24 09:24:50.949712
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class DummyClass(Configurable):
        def __init__(self): pass
    dummy_object = DummyClass()

# Generated at 2022-06-24 09:24:54.186637
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    try:
        obj = ObjectDict()
        obj.abc = 123
        assert obj['abc'] == 123
    except Exception as e:
        print(e, 'unexpected exception')



# Generated at 2022-06-24 09:25:06.177667
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun1(arg1):
        pass
    def fun2(arg1, arg2):
        pass
    def fun3(arg1, arg2, arg3):
        pass

    def test(fun, name, args, kwargs, new_value, expected_args, expected_kwargs, expected_old_value):
        """Tests replace method of ArgReplacer using function fun, arg_name, args and kwargs.
        The method is expected to return old_value, new_args and new_kwargs. expected_args, expected_kwargs and expected_old_value
        are the values to be returned by the test"""
        obj = ArgReplacer(fun, name)
        res = obj.replace(new_value, args, kwargs)
        assert res[1] == expected_args and res[2] == expected_

# Generated at 2022-06-24 09:25:13.718070
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    x = ObjectDict()
    x.a = 1
    # -*- test: test with x.a; expect: 1; -*-
    # -*- test: test with x['a']; expect: 1; -*-
    # -*- test: test with x['b']; type: Exception; -*-
    # -*- test: test with x.b; type: Exception; -*-
    # -*- test: test with x.a = 5; expect: None; -*-
    if False:
        pass
    if False:
        pass



# Generated at 2022-06-24 09:25:16.371219
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict
    print(hasattr(obj, '__getattr__'))
    print(obj.__getattr__)
    print(obj.__getattr__.__doc__)


# Generated at 2022-06-24 09:25:21.397598
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    # https://github.com/python/mypy/issues/4539
    TimeoutError()
    TimeoutError(None)
    if isinstance(TimeoutError() + '', unicode_type):
        # Python 2
        TimeoutError('foo')
    else:
        # Python 3
        TimeoutError('foo'.encode('utf-8'))
    TimeoutError(u'bar')



# Generated at 2022-06-24 09:25:26.741644
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return B
        def initialize(self, s):
            pass

    class B(A):
        def initialize(self, s):
            pass

    # tests that the constructor of a configurable class returns an
    # instance of the configured type, and that the keyword arguments
    # are passed to the constructor
    assert isinstance(A(s=5), B)

    # tests that a TypeError is raised if the configured class is not
    # a subclass of the configurable base class
    A.configure("tornado.util.Configurable")
    try:
        A(s=5)
        assert False
    except TypeError:
        pass

    # tests

# Generated at 2022-06-24 09:25:34.842650
# Unit test for function raise_exc_info
def test_raise_exc_info():
    import sys
    import traceback

    try:
        raise ValueError("msg")
    except ValueError:
        e = sys.exc_info()
        tb = traceback.extract_tb(e[2])
        raise_exc_info(e)
        assert False, "should not reach this line"
    except:
        e2 = sys.exc_info()
        tb2 = traceback.extract_tb(e2[2])
        del tb2[-1]
        assert tb == tb2


# fake exception class used in docstrings
_DOCTEST_EXCEPTION = Exception



# Generated at 2022-06-24 09:25:45.321774
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\s\S\d\D\w\W\b\B\a\A\Z\z\G\b\B\b\B\f\n\r\t\v\1") == " sSdDwWbBaAZzG\b\b\f\n\r\t\v\1"
    assert re_unescape(r"\cJ\0\\") == "cJ\0\\"
    assert re_unescape(r"\123") == "S"
    assert re_unescape(r"\x01") == "\x01"
    with pytest.raises(ValueError):
        # string contains 'd', which cannot be unescaped
        re_unescape(r"\d")



# Generated at 2022-06-24 09:25:47.427010
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    """Unit tests for function doctests."""
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 09:25:55.470768
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    d = GzipDecompressor()
    # Empty string is a valid gzipped data
    assert d.decompress(b"") == b""
    assert d.unconsumed_tail == b""
    assert d.flush() == b""

    c = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
    # Compress a long data
    data0 = bytes((x % 256) for x in range(2000))
    data1 = c.compress(data0)
    data2 = c.flush()
    assert data0 == d.decompress(data1 + data2)
    assert d.unconsumed_tail == b""
    assert d.flush() == b""

    # Test truncated data.
    # decompressobj.eof is not reliable

# Generated at 2022-06-24 09:26:06.711334
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # type: () -> None
    data = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x04\x03\x67\x7a\x2d\x50\xca\xcf\x2f\xca\x49\x01\x00\x9d\x57\x5f\xa0\x06\x00\x00\x00'
    decompressor = GzipDecompressor()
    assert decompressor.decompress(data) == b'\x67\x7a\x2d\x50', 'test decompress'
    assert decompressor.flush() == b'', 'test flush'


# Generated at 2022-06-24 09:26:14.939426
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        pass
    assert isinstance(A(), A)

    class B(A):
        pass
    assert isinstance(B(), B)

    class C(A):
        pass
    C.configure("tests.util_test.C")
    assert isinstance(C(), C)

    class D(A):
        pass
    D.configure("tests.util_test.D")
    assert isinstance(D(), D)
    assert isinstance(C(), C)

    assert isinstance(B(), B)

    # Restore configuration
    C.configure(None)
    D.configure(None)
    assert isinstance(C(), C)
    assert isinstance(B(), B)



# Generated at 2022-06-24 09:26:22.914384
# Unit test for function raise_exc_info
def test_raise_exc_info():
    import sys
    import unittest

    class _TestHandler(unittest.TestCase):
        def test_raise_exc_info(self):
            try:
                raise ValueError("test")
            except:
                # ... and re-raise it
                raise_exc_info(sys.exc_info())
            self.fail("should never get here")

    raise_exc_info = test_raise_exc_info
    raise_exc_info.__doc__ = None  # silence pyflakes


_UTF8_TYPES = (bytes, type(None))  # type: Tuple[type, ...]



# Generated at 2022-06-24 09:26:29.494568
# Unit test for function re_unescape
def test_re_unescape():
    # From http://docs.python.org/2/library/re.html#re.escape
    re_unescape(r"fob\(o\).*?bar\[1\]")
    re_unescape(r"fob(o).*?bar[1]")
    with pytest.raises(ValueError):
        re_unescape(r"fob\\(o\\).*?bar\\[1\\]")
    with pytest.raises(ValueError):
        re_unescape(r"fob\a.b")



# Generated at 2022-06-24 09:26:38.645134
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    try:
        TimeoutError  # type: ignore
    except NameError:
        raise NameError("TimeoutError: can't instantiate")

# Alias IOLoop.TimeoutError to Gen.TimeoutError
# so that either name can be imported
# and the other will be available as well.
# When compatibility with Python 2 is dropped,
# the second import will fail.
from tornado.ioloop import TimeoutError as IOLoopTimeoutError
TimeoutError = IOLoopTimeoutError
TimeoutError.__module__ = 'tornado.gen'


# Generated at 2022-06-24 09:26:42.316148
# Unit test for method initialize of class Configurable

# Generated at 2022-06-24 09:26:50.392993
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds(): assert all(
    timedelta_to_seconds(datetime.timedelta(0)) == 0,
    timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1,
    timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5,
    timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 1e-6,
    timedelta_to_seconds(datetime.timedelta(days=1, hours=1, minutes=1, seconds=1.123456)) == 90061.123456
)



# Generated at 2022-06-24 09:27:00.090161
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from .platform.testing import async_test_engine
    decompressor = GzipDecompressor()
    assert decompressor.flush() == b''
    decompressor.decompress(b'x\x9cK\xcb\xcf\x07\r\x00\x04\x00\x1b')
    assert decompressor.flush() == b'foo'
    decompressor = GzipDecompressor()
    decompressor.decompress(b'x\x9cK\xcb\xcf\x07\r\x00\x04\x00\x1b')
    assert decompressor.flush() == b'foo'

# Generated at 2022-06-24 09:27:05.616256
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b):
        return None
    args = (1, 2)
    kwargs = {"b": 2}
    arg_replacer = ArgReplacer(func, "a")
    arg_replacer.replace(3, args, kwargs)
    assert (3, 2) == args and {"b": 2} == kwargs
    arg_replacer = ArgReplacer(func, "b")
    arg_replacer.replace(4, args, kwargs)
    assert (1, 2) == args and {"b": 4} == kwargs
    arg_replacer = ArgReplacer(func, "c")
    arg_replacer.replace(5, args, kwargs)
    assert (1, 2) == args and {"b": 4, "c": 5} == kwargs

#

# Generated at 2022-06-24 09:27:08.882643
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    error = TimeoutError("msg")
    assert error.__str__() == "msg"


# Define aliases for these names that were changed in Tornado 6.0
TimeoutError = TimeoutError
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:27:20.240926
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    import itertools

    class C1(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return C1

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return C1

        def initialize(self, a, b, c=None):
            # type: (int, int, Optional[float]) -> None
            self.a = a
            self.b = b
            self.c = c

    # Test the base class and a subclass.
    for cls in (C1, type("C2", (C1,), {})):
        c = cls(42, b=5, c=6.5)
        assert c.a

# Generated at 2022-06-24 09:27:25.918394
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, "Input/output error")
    except OSError as e:
        assert errno_from_exception(e) == 5
        #
        # If the exception was instantiated with no errno there
        # should be a tuple error.
        e = OSError()
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:27:29.437871
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    obj = GzipDecompressor()
    obj.decompressobj = mock.MagicMock()
    obj.decompressobj.flush.return_value = b'bar'
    assert obj.flush() == b'bar'
    obj.decompressobj.flush.assert_called_once_with()

# Generated at 2022-06-24 09:27:32.621016
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    dictlike = ObjectDict()  # type: ObjectDict

    dictlike["foo"] = 1
    dictlike["bar"] = 2
    
    assert dictlike["foo"] == 1
    assert dictlike["bar"] == 2

    assert dictlike.bar == 2
    assert dictlike.foo == 1



# Generated at 2022-06-24 09:27:44.599939
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(0)
    except Exception as e:
        assert errno_from_exception(e) == 0
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(0)
    except Exception as e:
        assert errno_from_exception(e) == 0
    try:
        raise OSError(0)
    except Exception as e:
        assert errno_from_exception(e) == 0


if hasattr(os, "errno"):

    def set_close_exec(fd: int) -> None:
        """Sets the close-on-exec flag on the given file descriptor."""

# Generated at 2022-06-24 09:27:49.083832
# Unit test for function exec_in
def test_exec_in():
    x = 5
    d = {"x": 10}
    exec_in("assert x == 10", d)
    exec_in("assert y == 5", d, {"y": 5})



# Generated at 2022-06-24 09:27:51.455808
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    assert d.empty is None
    d.empty = True
    assert d.empty == True
    assert d['empty'] == True



# Generated at 2022-06-24 09:27:58.727259
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import functools
    import math
    import operator

    def _test(cls, sname, name):
        if isinstance(sname, (list, tuple)):
            impl, impl_kwargs = sname
            for k, v in impl_kwargs.items():
                impl.configure(**{k: v})

            impl_kwargs = None
            if isinstance(impl, str):
                impl = import_object(impl)
        else:
            impl_kwargs = None
            impl = import_object(sname)

        cls.configure(impl)
        assert cls.configured_class() is impl, (cls, impl)
        obj = cls()

# Generated at 2022-06-24 09:28:09.110233
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def args_kwargs_demo(a, *args, b, **kwargs):
        pass

    def args_demo(a, *args, **kwargs):
        pass

    def kwargs_demo(a,  **kwargs):
        pass

    def only_args_demo(a, b, c):
        pass

    ar = ArgReplacer(args_kwargs_demo, 'b')  # type: ignore
    assert ar.get_old_value((1,), {'b':2, 'c':3}) == 2
    assert ar.get_old_value((1,), {'c':3}, default=None) is None
    assert ar.get_old_value((1,), {}) == {}

# Generated at 2022-06-24 09:28:16.714896
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import io
    import gzip
    import random

    test_data = io.BytesIO(b"".join(
        b"%d\n" % random.randrange(0, 100) for i in range(1000)))

    for compress in [False, True]:
        for max_length in [1000, 1001, 1010]:
            test_data.seek(0)
            if compress:
                comp_obj = gzip.GzipFile(fileobj=test_data)
                test_gzipped = comp_obj.read()
                comp_obj.close()
            else:
                test_gzipped = test_data.read()  # type: ignore

            # Verify that we can decompress multiple times using the
            # same decompressor, as long as max_length is chosen correctly
            # (the gzip file is 1010 bytes

# Generated at 2022-06-24 09:28:24.743031
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
  from io import BytesIO
  from .options import options
  from .platform.filesystem import _W_OK, _R_OK
  import os

  test_dir = os.getenv("TEST_DIR") or os.path.dirname(__file__)
  with open(os.path.join(test_dir, "test_file"), "rb") as f:
    test_file = f.read()
  with open(os.path.join(test_dir, "test_file.gz"), "rb") as f:
    test_file_gz = f.read()
  gz = GzipDecompressor()
  f = BytesIO(test_file_gz)
  f.seek(10)
  assert gz.decompress(f.read(50)) == test_file[10:60]


# Generated at 2022-06-24 09:28:31.712997
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # pragma: nocover
    import unittest
    try:
        raise TimeoutError()
    except unittest.case.SkipTest:
        pass


from tornado import gen  # noqa: E402


from tornado.httputil import _parse_proxy  # noqa: E402
from tornado import ioloop  # noqa: E402

gen.TimeoutError = TimeoutError  # type: ignore
ioloop.TimeoutError = TimeoutError  # type: ignore

from typing import IO  # noqa: E402



# Generated at 2022-06-24 09:28:33.159387
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()
    TimeoutError("test")



# Generated at 2022-06-24 09:28:34.804614
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    assert(isinstance(GzipDecompressor().decompress(b''), bytes))

# Generated at 2022-06-24 09:28:38.320997
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict(foo=True, bar=1, baz="asdf")
    assert obj.foo == True
    assert obj["foo"] == True
    assert obj.bar == 1
    assert obj.baz == "asdf"
    with pytest.raises(AttributeError):
        assert obj.nonexistent == False



# Generated at 2022-06-24 09:28:42.230411
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    cd = GzipDecompressor()
    cd.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\xc1\xd0\xff\xff\xff\xff\xff\x01'
            b'c\x01\xff\xff\xff')
    assert cd.unconsumed_tail == b'\x01c\x01\xff\xff\xff'



# Generated at 2022-06-24 09:28:51.802921
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    test_value = bytearray([31, 139, 8, 0, 0, 0, 0, 0, 0, 3, 61, 115, 32, 47, 64, 9, 0, 255, 255, 255, 255, 255, 38, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255])
    test_decompressor = GzipDecompressor()
    test_decompressor.decompress(test_value)

# Generated at 2022-06-24 09:28:56.878202
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    assert ObjectDict(title='Simon', name='Simon').__getattr__('title') == 'Simon'
    assert ObjectDict(title='Simon', name='Simon').__getattr__('name') == 'Simon'
    try:
        ObjectDict(title='Simon', name='Simon').__getattr__('author')
        assert False
    except AttributeError:
        assert True
    try:
        ObjectDict(title='Simon', name='Simon').__getattr__('date')
        assert False
    except AttributeError:
        assert True
test_ObjectDict___getattr__()

# Generated at 2022-06-24 09:29:03.454412
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c, d=4, e=5):
        pass
    r = ArgReplacer(foo, 'd')
    assert r.arg_pos == 3
    assert r.get_old_value((1, 2, 3), dict(e=6)) == 4
    assert r.get_old_value((1, 2, 3), dict(e=6), 7) == 4
    assert r.get_old_value((1, 2, 3), dict()) == 5
    assert r.get_old_value((1, 2, 3), dict(), 7) == 7
    r = ArgReplacer(foo, 'b')
    assert r.arg_pos == 1
    assert r.get_old_value((1, 2, 3), dict()) == 2

# Generated at 2022-06-24 09:29:09.816183
# Unit test for function exec_in
def test_exec_in():
    loc = {}
    exec_in('a = 1', {}, loc)
    assert loc['a'] == 1
    def do_exec(code):
        exec_in(code, {}, loc)
    do_exec('b = 1')
    assert loc['b'] == 1


# Fake byte literal for test_utf8
_TEST_UTF8 = b"\xf0\x9f\x98\x82"
if str is not bytes:
    _TEST_UTF8 = _TEST_UTF8.decode("utf-8")



# Generated at 2022-06-24 09:29:21.271785
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass


try:
    import thread
except ImportError:
    import _thread as thread

try:
    import threading
except ImportError:
    threading = None  # type: ignore

try:
    import subprocess
except ImportError:
    # Python < 2.4 doesn't have the subprocess module, which is needed for
    # `ArgumentParser`.
    subprocess = None  # type: ignore

# True if we are running on Google App Engine.
# App Engine always sets this variable, and it's always set in the
# production environment (not the development environment).
#
# Note that although global variables are normally deleted when a module is
# reloaded, imports are cached and reloaded from cache, so this variable
# is actually persistent across reloads.

# Generated at 2022-06-24 09:29:28.632563
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = GzipDecompressor()
    
    # test 1
    import gzip
    from io import BytesIO
    value = bytes("test_value", "utf-8")
    buffer = BytesIO()
    gzip_file = gzip.GzipFile(mode = 'wb',  fileobj = buffer)
    gzip_file.write(value)
    gzip_file.close()
    bytes_value = buffer.getvalue()
    
    assert gzip_decompressor.decompress(bytes_value) == bytes("test_value", "utf-8")

    # test 2
    gzip_decompressor.decompress(bytes_value)
    assert gzip_decompressor.unconsumed_tail == b""

    # test 3
    assert gzip_decompressor

# Generated at 2022-06-24 09:29:33.111232
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError(None)
    TimeoutError('foo')
    TimeoutError('foo', None)


# Aliases to match the old location of this class.
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:29:40.538495
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    x = ZeroDivisionError()
    y = None # type: Optional[type]
    z = None  # type: Optional[TracebackType]

    def f():
        # type: () -> typing.NoReturn
        raise_exc_info((y, x, z))

    try:
        f()
    except ZeroDivisionError:
        pass
    else:
        assert False, "raise_exc_info did not re-raise the exception"
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass
    else:
        assert False, "raise_exc_info did not raise a TypeError"



# Generated at 2022-06-24 09:29:49.112527
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    objdict = ObjectDict({})
    assert hasattr(objdict, "asdf") is False
    assert hasattr(objdict, "__getattr__") is True

    objdict.asdf = "a value"
    assert objdict.asdf == "a value"
    assert objdict["asdf"] == "a value"
    objdict.asdf = "another value"
    assert objdict.asdf == "another value"
    assert objdict["asdf"] == "another value"
    assert objdict.qwer == AttributeError("qwer")



# Generated at 2022-06-24 09:30:00.658028
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import io
    import gzip
    for i in range(0, 256):
        s = bytes([i]) * 100000
        c = GzipDecompressor()
        # Try with builtin module
        t = gzip.compress(s)
        u = c.decompress(t)
        assert u == s
        # Try with IO stream
        tio = io.BytesIO()
        cio = gzip.GzipFile(fileobj=tio, mode="wb")
        cio.write(s)
        cio.close()
        t = tio.getvalue()
        c = GzipDecompressor()
        uio = io.BytesIO(t)
        dio = gzip.GzipFile(fileobj=uio, mode="rb")
        u = dio.read()
        u

# Generated at 2022-06-24 09:30:05.639058
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import unittest2
    import doctest

    suite = doctests()  # type: ignore
    runner = unittest2.TextTestRunner(verbosity=2)
    runner.run(suite)



# Generated at 2022-06-24 09:30:11.249796
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(42, "message")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"



# Generated at 2022-06-24 09:30:21.600757
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(days=1, microseconds=1)) == 86400.000001
    # Test that the result is a float
    assert isinstance(timedelta_to_seconds(datetime.timedelta(days=1)), float)
    assert timedelta_to_seconds(datetime.timedelta(days=-1)) == -86400
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1)) == -1



# Generated at 2022-06-24 09:30:23.872074
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict(foo='bar')
    obj['foo'] = 'baz'
    assert obj.foo == 'baz'



# Generated at 2022-06-24 09:30:33.868986
# Unit test for constructor of class Configurable
def test_Configurable():
    from tornado import gen
    from tornado import iostream

    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestIOStream

        def initialize(self):
            pass

    class TestIOStream(iostream.IOStream):
        def initialize(self):
            pass

    class TestFutures(TestConfigurable):
        @classmethod
        def configurable_base(cls):
            return TestFutures

        @classmethod
        def configurable_default(cls):
            return gen.Future

    TestFutures.configure(None)
    assert TestFutures.configured_class() is gen.Future

# Generated at 2022-06-24 09:30:37.810107
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    '''
    GzipDecompressor.flush()
    '''
    obj = GzipDecompressor()
    # TODO: use real data
    value = ''
    value = obj.decompress(value)
    assert value == None


# Generated at 2022-06-24 09:30:39.238461
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError('foo')


# Make sure timeouts are never negative

# Generated at 2022-06-24 09:30:47.200982
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # test for function GzipDecompressor.flush()
    decompressor = GzipDecompressor()
    assert decompressor.flush() == b''
    decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x04\x03\xb3\xd7\x01\x00\x00\x00\x01\x00\x00\x00\x03\x00\x00\x00')
    assert decompressor.flush() == b''
    decompressor.decompress(b'\x00\x00\x00\x00\x00')
    assert decompressor.flush() == b'test'



# Generated at 2022-06-24 09:30:58.700093
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[C]
            return C

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[C]
            return C

        def __init__(self, foo, name=None):
            # type: (int, Optional[str]) -> None
            self.foo = foo
            self.name = name

    C.configure(1, name="one")
    c1 = C(0)
    assert c1.foo == 1
    assert c1.name == "one"

    c2 = C(2)
    assert c2.foo == 2
    assert c2.name == "one"


# Generated at 2022-06-24 09:31:06.866298
# Unit test for function exec_in
def test_exec_in():
    glob = {"x": 1}
    loc = {"y": 2}
    exec_in('assert x == 1 and y == 2', glob, loc)
    exec_in('z = 3', glob, loc)
    exec_in('assert z == 3', glob, loc)
    try:
        exec_in('assert x == 1 and y == 2', {})
        assert False
    except AssertionError:
        pass
    try:
        exec_in('assert x == 1 and y == 2', glob)
        assert False
    except NameError:
        pass



# Generated at 2022-06-24 09:31:10.845264
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass


# These are imported here instead of at the top because they import parts
# of the standard library that may not be present on all platforms.
from typing import AnyStr  # noqa: E402
from concurrent.futures import Future as _FuturesFuture  # noqa: E402
from typing import TYPE_CHECKING  # noqa: E402

# TODO: drop this once we only support Python 3.6+
_tornado_ESCAPE_RE = re.compile(rb"([\x00-\x20\"\\])")

# Generated at 2022-06-24 09:31:20.085465
# Unit test for function re_unescape
def test_re_unescape():
    # Some strings that `re.escape` should escape
    assert re_unescape(r"\w\W\b\B\s\S\d\D^$") == "wWbBsSdD^$"
    assert re_unescape(r"\\") == "\\"
    assert re_unescape(r"\[a\]") == "[a]"
    assert re_unescape(r"\(a\)") == "(a)"

    # Some strings that `re.escape` should not escape
    assert re_unescape(r"\a") == "a"
    assert re_unescape(r"\#") == "#"
    assert re_unescape(r"\ ") == " "
    assert re_unescape(r"\,") == ","

    # Some malformed strings

# Generated at 2022-06-24 09:31:29.853458
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(Exception(1))
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(Exception(None))
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        exc = IOError()
        exc.errno = 1
        raise exc
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-24 09:31:39.626729
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, replace='old', c=None):
        pass
    arg_rep = ArgReplacer(f, 'replace')
    # set as positional argument
    args = ('x',)
    kwargs = {'c': 3}
    old_value, args, kwargs = arg_rep.replace('new', args, kwargs)
    assert old_value == 'old'
    assert args == ('x', 'new',)
    assert kwargs == {'c': 3}
    # old value is not set and replace is set by keyword
    args = ('x',)
    kwargs = {'replace': 'new', 'c': 3}
    old_value, args, kwargs = arg_rep.replace(None, args, kwargs)
    assert old_value == 'new'

# Generated at 2022-06-24 09:31:40.587294
# Unit test for function import_object
def test_import_object():
    assert import_object('tornado')



# Generated at 2022-06-24 09:31:52.019083
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    a: typing.Dict[str, int] = {'x': 1}
    b: ObjectDict = ObjectDict(a)
    assert b.x == 1
    assert b.y == None  # noqa: E711
    b.y = 2
    assert b['y'] == 2
    assert hasattr(b, 'y')
    assert b.get('y') == 2
    assert 'y' in b
    b.z = 3
    assert b.z == 3
    del b.z
    assert 'z' not in b
    assert len(b) == 2
    assert list(b) == ['x', 'y']
    assert list(b.keys()) == ['x', 'y']
    assert list(b.values()) == [1, 2]

# Generated at 2022-06-24 09:31:58.002262
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj_dict = ObjectDict()
    obj_dict.attr1 = 1
    obj_dict.attr2 = 2
    obj_dict.attr3 = 3
    assert obj_dict.get("attr1") == 1
    assert obj_dict.get("attr2") == 2
    assert obj_dict.get("attr3") == 3
    assert obj_dict.get("attr4") is None


# Generated at 2022-06-24 09:32:08.016151
# Unit test for function exec_in
def test_exec_in():
    # First we test execution using Python code objects.
    # This is basically how tornado.gen does it.
    # These tests are very simple because we're basically just
    # testing that compile/exec are doing what we want them
    # to.
    glob = {'x' : 10}
    loc = {}
    exec_in(compile('x = 1', '', 'exec'), glob, loc)
    assert glob['x'] == 10
    assert loc['x'] == 1
    exec_in(compile('x = 2', '', 'exec'), glob, loc)
    assert glob['x'] == 10
    assert loc['x'] == 2
    # Some people might be tempted to write code that uses the
    # compile/exec functions in a way that doesn't close over glob
    # and loc.  For example, you might be tempted to do this

# Generated at 2022-06-24 09:32:16.183581
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gz_decompressor = GzipDecompressor()
    # max_length = 0, test the default value works
    gz_decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\x0b\xec\xb1\xb1\x02\x00\x9d\x91\x11\xbc\x00\x00\x00')
    # test if the max_length > the input data
    gz_decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\x0b', max_length=100)
    gz_decompressor.decomp

# Generated at 2022-06-24 09:32:27.370600
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def get_args_kwargs(method, *args, **kwargs):
        p = ArgReplacer(method, "a")
        return p.replace(*args, **kwargs)
    def method(a, b):
        pass
    old_value, args, kwargs = get_args_kwargs(method, 12, 13)
    assert old_value == 12
    assert args == (13, 13)
    assert not kwargs
    old_value, args, kwargs = get_args_kwargs(method, a=12, b=13)
    assert old_value == 12
    assert not args
    assert kwargs == {"a": 13, "b": 13}
    # Test that old_value is None when the argument is not present.
    old_value, args, kwargs = get_args_kw

# Generated at 2022-06-24 09:32:36.206423
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    byte_str = decompressor.decompress(b'\x00\x01\x02\x03\x04')
    assert byte_str == b'\x00\x01\x02\x03\x04'
    byte_str = decompressor.decompress(b'\x00\x01\x02\x03\x04', 5)
    assert byte_str == b'\x00\x01\x02\x03\x04'
    decompressor.decompress(b'\x00\x01\x02\x03\x04', 3)
    assert decompressor.unconsumed_tail == b'\x04'
