

# Generated at 2022-06-24 09:22:42.694764
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c): return a, b, c
    r = ArgReplacer(func, "b")
    arg_tuple = (1, 2, 3)
    kwarg_dict = {"a": 4, "b": 5, "c": 6}
    assert r.replace(10, arg_tuple, kwarg_dict) == (2, (1, 10, 3), kwarg_dict)
    assert r.replace(10, (1,), kwarg_dict) == (None, (1, 10), kwarg_dict)
    assert r.replace(10, (1, 2), kwarg_dict) == (2, (1, 10, 3), kwarg_dict)

# Generated at 2022-06-24 09:22:43.479451
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    _ = ObjectDict()


# Generated at 2022-06-24 09:22:49.898333
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):

        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Bar

        def initialize(self, a, b):
            pass

    class Bar(Foo):

        def initialize(self, a, b, c, d=4):
            pass

    Foo.configure(Bar, d=1)
    foo = Foo(0, 1)
    assert isinstance(foo, Bar)
    assert foo.d == 1



# Generated at 2022-06-24 09:22:51.746299
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1, hours=1, minutes=1, seconds=1)) == 90061.0



# Generated at 2022-06-24 09:22:57.966700
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass

# The exception "argument" is deprecated in python 3 so we don't need to
# test that


# Previously, these were aliases for `TimeoutError`.  Applications that
# were using `TimeoutError` were fine (it's an alias for `TimeoutError`
# internally), but applications that were using `gen.TimeoutError` or
# `ioloop.TimeoutError` without importing `util` would see a
# `NameError` when constructing the exception, so now we also alias
# `TimeoutError` under those two names.

# We can't make these aliases in a loop because that doesn't work with
# metaclasses, so we do it manually here.



# Generated at 2022-06-24 09:23:06.969649
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError # type: ignore
    except Exception as e:
        assert errno_from_exception(e) == 0
    try:
        raise IOError(5)
    except Exception as e:
        assert errno_from_exception(e) == 5
    try:
        raise IOError((1, "hi"))
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise IOError(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-24 09:23:08.680930
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.b = 1



# Generated at 2022-06-24 09:23:12.408260
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    assert repr(e) == "TimeoutError()"
    e = TimeoutError("abc")
    assert repr(e) == "TimeoutError('abc')"


# Alias for TimeoutError, deprecated in Tornado 5.0.
Timeout = TimeoutError



# Generated at 2022-06-24 09:23:19.293755
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d=4, e=5, f=6):
        pass

    ar1 = ArgReplacer(foo, "b")
    mul= ar1.replace(9, (0,1,2,3,4,5,6), {})
    assert mul[0] == 1
    assert mul[1] == (0,9,2,3,4,5,6)
    assert mul[2] == {'d': 4, 'e': 5, 'f': 6}

# Generated at 2022-06-24 09:23:31.472299
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # Test with a regular function
    def foo(bar, baz=None):
        pass

    arg_replacer = ArgReplacer(foo, "bar")
    assert arg_replacer.get_old_value([1], dict()) == 1
    assert arg_replacer.get_old_value([1], dict(bar=2)) == 1
    assert arg_replacer.get_old_value([], dict(bar=2)) == 2
    assert arg_replacer.get_old_value([], dict(baz=1)) is None
    assert arg_replacer.get_old_value([], dict(baz=1), default=10) == 10

    # Test with a method
    class Foo(object):
        def bar(self, baz=None):
            pass


# Generated at 2022-06-24 09:23:42.183312
# Unit test for constructor of class Configurable
def test_Configurable():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurableImpl

        def initialize(self):
            pass

    class TestConfigurableImpl(TestConfigurable):
        def initialize(self):
            pass

    assert TestConfigurable.configured_class() is TestConfigurableImpl
    assert TestConfigurable().__class__ is TestConfigurableImpl
    TestConfigurable.configure(None)
    assert TestConfigurable.configured_class() is TestConfigurableImpl
    assert TestConfigurable().__class__ is TestConfigurableImpl
    TestConfigurable.configure(TestConfigurable)
    assert TestConfigurable.configured_class() is TestConfigurable
    assert TestConfigurable().__class

# Generated at 2022-06-24 09:23:49.162147
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b):
        pass
    rep = ArgReplacer(f, "a")
    assert rep.get_old_value((1, 2), {}) == 1
    assert rep.get_old_value((1,), {"b": 2}) == 1
    assert rep.get_old_value((1,), {"a": 2}) == 2
    assert rep.get_old_value(args=(1,), kwargs={}) == 1
    assert rep.get_old_value((), {"a": 1}) == 1
    assert rep.get_old_value((), {"b": 1}) is None
    assert rep.get_old_value((), {}, default=2) == 2
    assert rep.get_old_value((1,), {"b": 2}, default=3) == 1

# Generated at 2022-06-24 09:23:55.809551
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class A(Configurable):
        __impl_class = None  # type: Optional[Type[Configurable]]
        __impl_kwargs = None  # type: Dict[str, Any]

        def __init__(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            ...
        def configurable_base(self):
            # type: () -> Type[Configurable]
            pass

        def configurable_default(self):
            # type: () -> Type[Configurable]
            pass
    class B(A):
        __impl_class = None  # type: Optional[Type[Configurable]]
        __impl_kwargs = None  # type: Dict[str, Any]


# Generated at 2022-06-24 09:24:05.043426
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def dummy_func(a, b, c = "c", *args, **kwargs): pass
    arg_replacer = ArgReplacer(dummy_func, "a")
    assert arg_replacer.get_old_value((1,2), {}) == 1
    assert arg_replacer.get_old_value((1,2,3), {}) == 1
    assert arg_replacer.get_old_value((1,), {'a': 2}) == 2

    assert arg_replacer.get_old_value((1,2), {'a': 3}) == 3
    assert arg_replacer.get_old_value((1,2), {'a': 3}, default = "default") == 3
    assert arg_replacer.get_old_value((1,2), {}, default = "default") == "default"

# Generated at 2022-06-24 09:24:08.294213
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\_\+\?") == r"_+?"

# Generated at 2022-06-24 09:24:13.378632
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    with open("test_GzipDecompressor_flush.txt", "wb") as f:
        f.write(array.array('B', [0x1f, 0x8b, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x63, 0x60, 0x60, 0x60, 0x00, 0x03, 0x62, 0x64, 0x64, 0x64, 0x64]))
    with open("test_GzipDecompressor_flush.txt", "rb") as f:
        gz_input = f.read()
    a = GzipDecompressor()
    a.decompress(gz_input)
    b = a.flush()
    assert b == b"bbbb"


# Generated at 2022-06-24 09:24:21.284835
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import inspect
    import tornado.httpclient

    test_obj = tornado.httpclient.HTTPClient()
    method_name = "fetch"
    test_method = getattr(test_obj, method_name)
    arg_replacer = ArgReplacer(test_method, name='callback')
    assert arg_replacer.get_old_value([], {}) is None
    assert arg_replacer.get_old_value([], {'callback': None}) is None
    assert arg_replacer.get_old_value([], {'callback': lambda: None}) is None
    assert arg_replacer.get_old_value([], {'callback': None}, default=None) is None
    assert arg_replacer.get_old_value([], {'callback': lambda: None}, default=None) is None
    assert arg_repl

# Generated at 2022-06-24 09:24:27.852202
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def method_with_1_argument(argument):
        pass
    def method_with_2_argument(argument1, argument2):
        pass
    def method_with_2_keyword_argument(argument1, argument2=None):
        pass
    def method_with_mixed_arguments(argument1, argument2, argument3, argument4=None):
        pass
    arg_replacer = ArgReplacer(method_with_1_argument, 'argument')
    assert arg_replacer.get_old_value((), {}, None) == None
    assert arg_replacer.get_old_value((1,), {}, None) == 1
    assert arg_replacer.get_old_value((), {'argument':None}, None) == None

# Generated at 2022-06-24 09:24:34.818822
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(seconds=2.5)) == 2.5
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60
    assert timedelta_to_seconds(datetime.timedelta(minutes=1.5)) == 90
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 24 * 3600



# Generated at 2022-06-24 09:24:44.879825
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # pragma: nocover
    # type: () -> None
    """Unit test for constructor of class TimeoutError"""
    try:
        raise TimeoutError("abc")
    except TimeoutError as e:
        assert str(e) == "abc", e
    try:
        raise TimeoutError("abc", "def")
    except TimeoutError as e:
        assert str(e) == "abc, def", e
    try:
        raise TimeoutError("abc", "def", "ghi")
    except TimeoutError as e:
        assert str(e) == "abc, def, ghi", e


# A marker for unpickleable arguments to a `.Callback` or `.WaitCallback`.
NO_RESULT = object()



# Generated at 2022-06-24 09:24:53.684828
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # type: () -> None
    try:
        raise OSError(0, "test_errno_from_exception")
    except OSError as e:
        assert 0 == errno_from_exception(e)
    try:
        raise OSError("error message only")
    except OSError as e:
        assert None == errno_from_exception(e)
    try:
        raise OSError()
    except OSError as e:
        assert None == errno_from_exception(e)



# Generated at 2022-06-24 09:25:05.600152
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    d = GzipDecompressor()
    data = d.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
                        b'\x4a\x4d\x4e\x55\x48\x2d\x2a\x2e\x49\x48'
                        b'\x2a\x4a\x2d\x54\x55\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    assert data == b'Hello world!'



# Generated at 2022-06-24 09:25:16.103788
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=None, d=None):
        pass
    r = ArgReplacer(f, "d")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {"c": 3}) is None
    assert r.get_old_value((1, 2), {"d": 4}) == 4
    assert r.get_old_value((1, 2), {"c": 3, "d": 4}) == 4
    assert r.get_old_value((1, 2), {"q": 3, "d": 4}) == 4
    assert r.get_old_value((1, 2), {"d": 4}, None) == 4

# Generated at 2022-06-24 09:25:18.778676
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    try:
        d.y
        assert False, 'Should assert'
    except AttributeError:
        pass


# Generated at 2022-06-24 09:25:24.468651
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\n\t\v\a\b\f\r\\") == "\n\t\v\a\b\f\r\\"
    assert re_unescape(r"\d") == "\\d"
    assert re_unescape(r"\000\001\007") == "\\000\\001\\007"
    assert re_unescape(r"\u001f\u0020") == "\\u001f\\u0020"
    assert re_unescape(r"\U0000000\U0000001F\U00000020") == "\\U0000000\\U0000001F\\U00000020"
    assert re_unescape(r"\n\t\v\a\b\f\r\\") == "\n\t\v\a\b\f\r\\"
   

# Generated at 2022-06-24 09:25:35.418595
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    def _test_single_chunk(self, test_string: str, chunk_size: int,
                           flush: bool):
        test_string = test_string.encode('utf8')
        compressed = zlib.compress(test_string)
        d = GzipDecompressor()
        result = []  # type: List[bytes]
        for i in range(0, len(compressed), chunk_size):
            result.append(d.decompress(compressed[i:i + chunk_size],
                                       1024 * 1024))
        result.append(d.flush() if flush else b'')
        self.assertEqual(b''.join(result), test_string)
        self.assertEqual(d.unconsumed_tail, b'')


# Generated at 2022-06-24 09:25:38.111787
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        test_raise_exc_info2()
    except ZeroDivisionError:
        pass
    else:
        raise Exception("did not raise")



# Generated at 2022-06-24 09:25:48.997340
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a: int, b: int) -> int:
        return a + b

    def g(b: int, c: int, a: int = 0) -> int:
        return a + b + c

    assert ArgReplacer(f, "a").get_old_value((1, 2), {}) == 1
    assert ArgReplacer(f, "b").get_old_value((1, 2), {}) == 2
    assert ArgReplacer(g, "a").get_old_value((1, 2), {}) is None
    assert ArgReplacer(g, "a").get_old_value((1, 2), {}, default="foo") == "foo"

    assert ArgReplacer(g, "b").get_old_value((1, 2), {}) == 1

# Generated at 2022-06-24 09:25:51.063534
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise KeyError('foo')
    except KeyError as e:
        raise_exc_info(e.__traceback__)  #type: ignore


# Generated at 2022-06-24 09:25:59.737475
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    """
    >>> data = open("tests/helloworld.gz", "rb").read()
    >>> decompressor = GzipDecompressor()
    >>> decompressor.decompress(data, 1024)
    b'Hello world!\\n'
    >>> len(decompressor.unconsumed_tail)
    53
    >>> decompressor.flush()
    b''
    """


if typing.TYPE_CHECKING:
    from typing import Generator


# Generated at 2022-06-24 09:26:04.563050
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c):
        pass
    a = ArgReplacer(foo, 'a')
    b = ArgReplacer(foo, 'b')
    c = ArgReplacer(foo, 'c')
    assert a.get_old_value((1,2,3), {}, 0) == 1
    assert b.get_old_value((1,2,3), {}, 0) == 2
    assert c.get_old_value((1,2,3), {}, 0) == 3
    assert a.get_old_value((1,), {}, 0) is 0


# Generated at 2022-06-24 09:26:13.489437
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, 'os error 5')
    except OSError as e:
        err = errno_from_exception(e)
        assert err==5
        assert e.errno==5
        assert e.filename=='os error 5'

    try:
        raise OSError('os error 1')
    except OSError as e:
        err = errno_from_exception(e)
        assert err=='os error 1'
        assert e.args==('os error 1',)

    try:
        raise OSError()
    except OSError as e:
        err = errno_from_exception(e)
        assert err==None
        assert e.args==()


# Generated at 2022-06-24 09:26:18.339628
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    assert import_object('tornado.concurrent.futures.ThreadPoolExecutor')
    try:
        import_object('tornado.missing_module')
    except ImportError as e:
        assert "No module named missing_module" == str(e)



# Generated at 2022-06-24 09:26:28.625519
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    dict_Data = {'a':1,'b':2}
    obj_dict = ObjectDict(dict_Data)
    assert(obj_dict.a==1)
    assert(obj_dict.b==2)
    obj_dict = ObjectDict(a=1,b=2)
    assert(obj_dict.a==1)
    assert(obj_dict.b==2)
    obj_dict = ObjectDict()
    obj_dict.a = 1
    obj_dict.b = 2
    assert(obj_dict['a']==1)
    assert(obj_dict['b']==2)


# Generated at 2022-06-24 09:26:30.426176
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    obj = GzipDecompressor()
    # call obj.decompress(value, max_length=0)



# Generated at 2022-06-24 09:26:36.817137
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # The following function has three arguments.
    def f(a, b, c):
        pass
    replacer = ArgReplacer(f, 'b')
    # Test the case that the argument is passed positionally
    old_value = replacer.get_old_value((1, 2, 3), {})
    assert old_value == 2
    # Test the case that the argument is passed as a keyword argument
    old_value = replacer.get_old_value((1,), {'b': 3})
    assert old_value == 3
    # Test the case that the argument is passed neither positionally nor
    # as a keyword argument
    old_value = replacer.get_old_value((1,), {})
    assert old_value is None


# Generated at 2022-06-24 09:26:45.725171
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b):
        pass
    assert ArgReplacer(func, "a").get_old_value((1, 2), dict()) == 1
    assert ArgReplacer(func, "b").get_old_value((1, 2), dict()) == 2
    assert ArgReplacer(func, "b").get_old_value((1, 2), dict(), 3) == 2
    assert ArgReplacer(func, "c").get_old_value((1, 2), dict(), 3) == 3
    assert ArgReplacer(func, "c").get_old_value((1, 2), dict()) is None


# Generated at 2022-06-24 09:26:50.606583
# Unit test for constructor of class Configurable
def test_Configurable():
    class DummyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return DummyConfigurable

        @classmethod
        def configurable_default(cls):
            return DummyConfigurableImpl

        def initialize(self):
            self.impl = DummyConfigurable.configured_class().__name__

    class DummyConfigurableImpl(DummyConfigurable):
        def initialize(self):
            super(DummyConfigurableImpl, self).initialize()
            self.impl += "_Impl"

    class DummyConfigurableSubclass(DummyConfigurable):
        pass

    class DummyConfigurableImplSubclass(DummyConfigurableImpl):
        pass

    assert issubclass(DummyConfigurableImpl, DummyConfigurable)

# Generated at 2022-06-24 09:26:51.180632
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()

# Generated at 2022-06-24 09:26:59.326882
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\\.") == "."
    assert re_unescape(r"\ab") == "ab"
    assert re_unescape(r"\A") == "A"
    assert re_unescape(r"\\") == "\\"
    assert re_unescape(r"\Z") == "Z"
    assert re_unescape(r"\07") == "\x07"
    assert re_unescape(r"\125") == "U"
    assert re_unescape(r"\400") == "\x00"
    with pytest.raises(ValueError):
        assert re_unescape("\\d")



# Generated at 2022-06-24 09:27:02.141767
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj["obj.foo"] = "bar"
    assert obj.obj.foo == "bar"
    try:
        obj.foo
        assert False
    except AttributeError:
        pass

# Generated at 2022-06-24 09:27:11.100652
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def __init__(self, a: int = 3, b: int = 4, c: int = 5) -> None:
            self.a = a
            self.b = b
            self.c = c

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

    class B(A):
        def initialize(self, a: int = 1, b: int = 2, d: int = 6) -> None:
            self.a = a
            self.b = b
            self.d = d

    class C(A):
        def initialize(self, _e: int = 7) -> None:
            self.e = _e

    A.configure(B)

# Generated at 2022-06-24 09:27:12.816678
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    test=ObjectDict({'name':1})
    #print(test.name)
    return



# Generated at 2022-06-24 09:27:25.127084
# Unit test for function re_unescape
def test_re_unescape():
    from tornado import gen
    import functools
    import re
    import sys

    @gen.coroutine
    def _test_re_unescape():
        assert re_unescape(r"\.") == "."
        assert re_unescape(r"\n") == "\n"
        assert re_unescape(r"\r") == "\r"
        assert re_unescape(r"\b") == "\x08"
        assert re_unescape(r"\a") == "\x07"
        assert re_unescape(r"\f") == "\x0c"
        assert re_unescape(r"\t") == "\t"
        assert re_unescape(r"\v") == "\x0b"
        assert re_unescape(r"\\") == "\\"
        assert re_un

# Generated at 2022-06-24 09:27:26.815093
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    foo = ObjectDict()
    foo.bar = 42
    assert foo["bar"] == 42



# Generated at 2022-06-24 09:27:27.681911
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    GzipDecompressor().flush()


# Generated at 2022-06-24 09:27:31.070392
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        def test_doctests(self):
            for test in doctests():
                yield test.runTest()

    TestCase().test_doctests()

# Generated at 2022-06-24 09:27:41.068446
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Verify that GzipDecompressor understands the undocumented
    # magic argument to zlib.decompressobj (tested on cpython).
    # This is how we know that it understands gzip headers.
    d = GzipDecompressor()
    d.decompress(b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff"
                 b"\xf3H\xcd\xc9\xc9W(\xcf/\xcaIQ\x04\x00"
                 b"\xb2\x80\x94\x00\x00\x00")



# Generated at 2022-06-24 09:27:43.976013
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # type: ignore
    x = ObjectDict(a=1)
    assert x["a"] == 1
    assert x.a == 1
    assert x.b == None
    x.b = 2
    assert x["b"] == 2
    assert x.b == 2



# Generated at 2022-06-24 09:27:54.735160
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c=3, d=4):
        pass

    r = ArgReplacer(func, "c")
    assert r.get_old_value((), {}) == 3
    assert r.get_old_value((), {"c": 5}) == 5
    assert r.get_old_value((), {"c": 5}, default=6) == 5
    assert r.get_old_value((), {"d": 5}, default=6) == 6
    assert r.get_old_value((7,), {"d": 5}) == 7
    assert r.get_old_value(("foo",), {"d": 5}) == "foo"
    assert r.replace(8, (), {}) == (3, (), {"c": 8})

# Generated at 2022-06-24 09:27:56.709190
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    obj = GzipDecompressor()
    assert obj.flush() is not None

# Generated at 2022-06-24 09:28:05.351026
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None

    def f(x, y, z):
        # type: (int, int, int) -> int
        return x * y * z

    def test_replace(pos, kw, new_value, expected_args, expected_kwargs):
        # type: (int, Dict[str, int], int, List[int], Dict[str, int]) -> None
        old, args, kwargs = ArgReplacer(f, "y").replace(new_value, (pos,), kw)
        assert args == expected_args
        assert kwargs == expected_kwargs
        assert old == 42

    test_replace(42, {}, 43, (42, 43, 42), {})
    test_replace(42, {"y": 42}, 43, (42,), {"y": 43})
   

# Generated at 2022-06-24 09:28:14.710517
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():  # noqa: F811
    # type: () -> None
    test_input = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xecK\x8f\x93\x0c\x0c\x8e\xcf\x0c\x04\x0c\x92\xe4\xf3q\x18\x06\xc0\x80\x02\x00\xe5\xde\x93\xbdu\x00\x00\x00"
    decompressor = GzipDecompressor()
    assert decompressor.decompress(test_input) == b"Hello World!"
    assert decompressor.flush() == b""
    assert decompressor.unconsumed_tail == b""


# Generated at 2022-06-24 09:28:25.800337
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a=0, b=0, c=0):
        pass
    arg_replacer = ArgReplacer(test_func, "c")
    res1 = arg_replacer.replace(3, [0, 1], {"b": 2})
    assert res1 == (0, [0, 1], {'b': 2, 'c': 3}), res1

    res2 = arg_replacer.replace(3, [0, 1], {"a": 1, "c": 0})
    assert res2 == (0, [0, 1], {'a': 1, 'c': 3}), res2
    res3 = arg_replacer.replace(3, [0, 1, 2, 3], {"a": 1})

# Generated at 2022-06-24 09:28:29.043713
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\+\?\*\^\$\[\]\(\)\|") == "+?*^$[]()|"
    with pytest.raises(ValueError):
        re_unescape(r"\d")



# Generated at 2022-06-24 09:28:38.425185
# Unit test for function errno_from_exception
def test_errno_from_exception():
    '''
    assert errno_from_exception(Exception) == None
    @add 
    assert errno_from_exception(Exception(1)) == 1
    assert errno_from_exception(Exception((1,))) == 1
    '''
    assert errno_from_exception(Exception()) == None
    assert errno_from_exception(Exception(1)) == 1
    assert errno_from_exception(Exception((1,))) == 1
    class MyException(Exception):
        pass
    assert errno_from_exception(MyException(1)) == None
    class MyException(Exception):
        def __init__(self, value):
            self.errno = value
    assert errno_from_exception(MyException(1)) == 1



# Generated at 2022-06-24 09:28:49.584849
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            pass

    # In these tests we'll be using the initial implementation 'A'
    # class.  We'll change the implementation class to 'B' in some
    # tests, but this isn't allowed in real code.
    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    # Test classes are in their own scope, so we use their fully
    # qualified names.
    A.configure('tornado.tests.test_util.A')
    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, B)

    # Test an override.
   

# Generated at 2022-06-24 09:28:57.590386
# Unit test for function import_object
def test_import_object():
    assert import_object("functools") is functools
    assert import_object("random") is random
    assert import_object("tornado.escape") is escape
    assert import_object("tornado.escape.utf8") is escape.utf8
    assert import_object("tornado.util") is util
    assert import_object("tornado.util.import_object") is import_object
    assert import_object("tornado.util.import_object").__name__ == "import_object"



# Generated at 2022-06-24 09:29:07.604692
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    from tornado.concurrent import _ObjectDict_subclass__getattr__
    from tornado.testing import gen_test
    from tornado.testing import AsyncTestCase
    from tornado.typing import Any
    import unittest

    # A class for testing subclassing
    class OD(ObjectDict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.__dict__["test_dict"] = 1

    class TestObjectDict(AsyncTestCase):
        @gen_test
        async def test_subclass_override(self):
            # Subclass's __getattr__ method should not be overridden
            assert OD.__getattr__ is not ObjectDict.__getattr__
            d = OD(a=1, b=2)
           

# Generated at 2022-06-24 09:29:19.273966
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    from unittest import mock

    class ConfigurableStub(Configurable):

        @classmethod
        def configurable_base(cls):
            return ConfigurableStub

        @classmethod
        def configurable_default(cls):
            return ConfigurableStub

    class ConfigurableSubStub(ConfigurableStub):

        def __init__(self, **kw):
            super(ConfigurableSubStub, self).__init__(**kw)

        def initialize(self, **kw):
            pass
    print("Start test_Configurable___new__")
    ConfigurableStub.configure(ConfigurableSubStub, some_key="some_value")
    assert isinstance(ConfigurableStub(), ConfigurableSubStub)
    print("End test_Configurable___new__")
    return un

# Generated at 2022-06-24 09:29:27.394603
# Unit test for function raise_exc_info
def test_raise_exc_info():
    import types, sys, unittest
    from typing import Optional, List, Type

    def raise_and_catch(exception):
        # type: (BaseException) -> Optional[Tuple[Type, BaseException, types.TracebackType]]
        try:
            raise exception
        except:  # noqa
            return sys.exc_info()

    class Error(Exception):
        pass

    class ErrorWithArg(Exception):
        def __init__(self, message):
            # type: (str) -> None
            self.message = message

    def test_no_arg():
        # type: () -> None
        err = Error()
        exc_info = raise_and_catch(err)
        assert exc_info[1] is err
        raised = [False]


# Generated at 2022-06-24 09:29:32.319972
# Unit test for function import_object
def test_import_object():
    import_object('unittest') # assert isinstance(import_object('unittest'), type)
    import_object('unittest.case.TestCase') # assert issubclass(import_object('unittest.case.TestCase'), unittest.TestCase)



# Generated at 2022-06-24 09:29:35.901842
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\_\W") == "_W"
    try:
        re_unescape(r"\d")
    except ValueError:
        pass
    else:
        raise Exception("expected ValueError")



# Generated at 2022-06-24 09:29:40.554231
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    c = GzipDecompressor()
    data = c.decompress(b"\x1f\x8b\x08\x00")
    assert data == b""
    data = c.decompress(b"\x00\x00\x00\x00\x00\x00\x00\x00")
    assert data == b""
    data = c.decompress(b"\x02\xff" + b"\x00" * 5 + b"hello world")
    assert data == b"hello world"
    data = c.flush()
    assert data == b""



# Generated at 2022-06-24 09:29:43.946845
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import unittest
    suite = doctests()
    unittest.TextTestRunner(verbosity=1).run(suite)

# Generated at 2022-06-24 09:29:49.029198
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    try:
        import unittest
        # unittest2 for python2.6
    except ImportError:
        import unittest2 as unittest

    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite())
    return suite



# Generated at 2022-06-24 09:29:54.105592
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError(1, 2, foo='bar')  # type: ignore


# Formerly aliases; these should be removed soon to cut down on
# confusion.
TimeoutError = TimeoutError
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:30:01.522267
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    assert Configurable.__new__
    Configurable.configure("tornado.tests.util_test.ConfiguredClass1")
    assert isinstance(Configurable(), ConfiguredClass1)
    assert not isinstance(Configurable(), ConfiguredClass2)

    Configurable.configure("tornado.tests.util_test.ConfiguredClass2")
    assert not isinstance(Configurable(), ConfiguredClass1)
    assert isinstance(Configurable(), ConfiguredClass2)

    Configurable.configure(None)
    assert isinstance(Configurable(), Configurable)



# Generated at 2022-06-24 09:30:12.619793
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"foo\!bar") == "foo!bar"
    assert re_unescape(re.escape(r"foo!bar")) == "foo!bar"
    for s in r",./;\'[]\-=":
        assert re_unescape(re.escape(s)) == s
    for s in r"\!\$\^\&\*\(\)":
        assert re_unescape(s) == s
    for s in re.escape(r"\x00\x01\x02\x03\x04\x05\x06\x07"):
        assert re_unescape(s) == s
    for s in re.escape(r"\x0e\x0f\x10\x11\x12\x13\x14\x15"):
        assert re

# Generated at 2022-06-24 09:30:19.963848
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import zlib
    obj = zlib.decompressobj(16 + zlib.MAX_WBITS)
    raw = open('/home/sooda/Web/tornado-demo/tornado-demo/tests/data/gzip_test.txt', 'rb').read()
    d = obj.decompress(raw)
    print(d)
    try:
        d = obj.flush()
    except Exception as e:
        print('Error:', e)

# Generated at 2022-06-24 09:30:21.532354
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:30:22.902462
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    ObjectDict()  # type: ObjectDict



# Generated at 2022-06-24 09:30:33.041770
# Unit test for function import_object
def test_import_object():
    import sys
    import_object('sys')
    import_object('sys.stderr')
    try:
        import_object('waldo')
    except ImportError as e:
        assert str(e) == "No module named waldo"
    else:
        assert False, "should have raised"
    try:
        import_object('sys.waldo')
    except ImportError as e:
        assert str(e) == "No module named waldo"
    else:
        assert False, "should have raised"
test_import_object()

# fake Unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that

# Generated at 2022-06-24 09:30:34.640230
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    GzipDecompressor()



# Generated at 2022-06-24 09:30:36.643417
# Unit test for function doctests
def test_doctests():
    # type: () -> unittest.TestSuite
    import doctest

    return doctest.DocTestSuite()

# Generated at 2022-06-24 09:30:45.972746
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    class Foo(object):
        def __init__(self, a, b, *args, **kwargs):
            pass

    def foo(a, b, *args, **kwargs):
        pass

    def bar(a, b, *args, **kwargs):
        pass

    bar.func_code = foo.func_code
    is_cython = True
    if hasattr(bar, "func_code"):
        is_cython = False

    replacer = ArgReplacer(Foo, "a")
    assert replacer.name == "a"
    assert replacer.arg_pos == 1

    assert replacer.get_old_value((1, 2), {}) == 2
    assert replacer.get_old_value((1, 2), {}, None) is None

# Generated at 2022-06-24 09:30:47.340994
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=2, microseconds=3)) == 1 * 86400 + 2 + 3 * 10 ** -6



# Generated at 2022-06-24 09:30:50.203338
# Unit test for function exec_in
def test_exec_in():
    glob = {}
    exec_in("x=6", glob)
    assert glob["x"] == 6
    locals = {}
    exec_in("y=7", glob, locals)
    assert locals["y"] == 7
    exec_in('raise ValueError("test_exec_in")', glob, locals)
test_exec_in()



# Generated at 2022-06-24 09:30:52.073197
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    o = ObjectDict(dict())
    o.a = 2
    o['a'] == 2


# Generated at 2022-06-24 09:30:59.024214
# Unit test for function import_object
def test_import_object():
    assert import_object("os") is os
    assert import_object("os.path") is os.path
    assert import_object("os.path") is os.path
    assert import_object("os.path") is os.path
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-24 09:31:10.696063
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __str__(self):
            return "%s(x=%r, y=%r)" % (self.__class__.__name__, self.x, self.y)

    class B(A):
        def __init__(self, x, y):
            super(B, self).__init__(x, y)
            self.x += 1

    class C(A):
        def __init__(self, x, y):
            super(C, self).__init__(x, y)


# Generated at 2022-06-24 09:31:14.342630
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def inner_function(err):
        raise_exc_info(err)  # type: ignore
    try:
        raise Exception()
    except Exception:
        inner_function(sys.exc_info())  # type: ignore


# Generated at 2022-06-24 09:31:23.348890
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("a\\.b") == "a.b"
    assert re_unescape("a\\.b\\.c") == "a.b.c"
    assert re_unescape("a\\\\b") == "a\\b"
    assert re_unescape("a\\ab") == "a\ab"
    assert re_unescape(".\\*") == ".*"
    assert re_unescape("\\\\d") == "\\d"
    # The following cases raise ValueErrors since they could not have
    # been produced by re.escape
    for s in ["\\a", "\\d", "abc\\", "\\"]:
        with pytest.raises(ValueError):
            re_unescape(s)



# Generated at 2022-06-24 09:31:30.588297
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def fn1(a=None, b=None, c=None):
        pass

    def fn2(a, b, c=None):
        pass

    def fn3(a, b, c, *args, **kwargs):
        pass

    arg = ArgReplacer(fn1, "a")
    arg.replace(1, (), {})
    assert arg.get_old_value((), {}) is None
    assert arg.get_old_value((), {"a": 123}) == 123
    assert arg.get_old_value((123,), {}) == 123
    assert arg.get_old_value((123,), {"a": 456}) == 123

    # Test that default argument values are not affected.
    # (Recent versions of CPython raise a TypeError with message
    # "takes 0 positional arguments but 1 was given

# Generated at 2022-06-24 09:31:33.805951
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    test_gzip_decompressor = GzipDecompressor()
    test_gzip_decompressor.decompress(b'a')
    assert b'a' == test_gzip_decompressor.flush()


# Generated at 2022-06-24 09:31:40.586289
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    """
    >>> test_GzipDecompressor()
    """
    import io
    import gzip
    gz_data = gzip.GzipFile(mode="rb", fileobj=io.BytesIO(sample_gzip_data))
    chunk_size = 30
    decompressor = GzipDecompressor()
    while True:
        chunk = gz_data.read(chunk_size)
        if chunk:
            decompressed = decompressor.decompress(chunk, 1024)
            assert decompressed == sample_excerpt
        else:
            extra = decompressor.unconsumed_tail
            assert not extra
            assert decompressor.flush() == b"hello world"
            break

# Sample gzip data generated by the gzip module.

# Generated at 2022-06-24 09:31:45.511300
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    """
    >>> decompressor = GzipDecompressor()
    >>> decompressor.decompress(b'\\x1f\\x8b\\x08\\x00\\x00\\x00\\x00\\x00\\x02\\xff')
    b''
    """



# Generated at 2022-06-24 09:31:54.910499
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Some random data, compressed with gzip -9.
    compressed = (
        b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1b\xe5\xe8\x1c\x00\x00\x00"
    )
    decompressor = GzipDecompressor()
    data = decompressor.decompress(compressed)
    assert not decompressor.unconsumed_tail
    data += decompressor.flush()
    assert data == b"asdf"

# Deprecated alias for GzipDecompressor.
# Not named `decompressobj` to avoid conflicts with zlib.
GzipFile

# Generated at 2022-06-24 09:32:04.502519
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import unittest

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

    class B(A):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return B

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return B

    A.configure(A)
    B.configure(B)

    # Test 1
    test_a = A(test_arg=1)

# Generated at 2022-06-24 09:32:09.854605
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c='c', *, d='d'):
        pass
    def bar(a, b, c='c', d='d', **kwargs):
        pass
    def baz(a, b, c='c', *args, **kwargs):
        pass
    def qux(a, b, c='c', d='d', *args, **kwargs):
        pass


# Generated at 2022-06-24 09:32:18.267952
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    d = GzipDecompressor()
    return b"".join([d.decompress(x) for x in [
        b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x8b\xca\x48\x05\x00\x00\x00",
        b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    ]])


try:
    import _websocket
except ImportError:
    _websocket = None



# Generated at 2022-06-24 09:32:23.925798
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b=3):
        pass
    arg = ArgReplacer(foo, 'a')
    assert arg.get_old_value((1,), {}) == 1
    assert arg.get_old_value((), {'a': 5}) == 5
    assert arg.get_old_value((), {'b': 5}, default=6) == 6


# Generated at 2022-06-24 09:32:28.529403
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    """Test the method __setattr__ of class ObjectDict."""
    obj = ObjectDict()
    obj.bar = 'hello'
    obj['bar'] = 'world'
    obj.__setattr__('bar', 'hello')  # pragma: no cover



# Generated at 2022-06-24 09:32:32.721271
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"1\.\*2\+3") == "1.*2+3"
    with pytest.raises(ValueError, match="cannot unescape"):
        re_unescape(r"1\d2")

