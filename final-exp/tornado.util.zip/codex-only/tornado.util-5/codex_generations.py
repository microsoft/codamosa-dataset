

# Generated at 2022-06-24 09:22:34.573321
# Unit test for constructor of class Configurable
def test_Configurable():
    class ConfigurableSubclass(Configurable):
        pass

    class Impl(ConfigurableSubclass):
        pass

    assert isinstance(ConfigurableSubclass(), Impl)
    assert isinstance(ConfigurableSubclass(), ConfigurableSubclass)



# Generated at 2022-06-24 09:22:44.996838
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        # py2
        import types

        class Derived(Exception):
            pass

        TimeoutError = types.ClassType("TimeoutError", (Derived,),
                                       {"__init__": TimeoutError.__init__})
    except Exception:
        # py3
        class Derived(Exception):
            pass

        TimeoutError = type("TimeoutError", (Derived,),
                            {"__init__": TimeoutError.__init__})
    try:
        raise TimeoutError()
    except TimeoutError:
        pass
    try:
        raise TimeoutError("foo")
    except TimeoutError:
        pass


TimeoutError.__module__ = "tornado.util"
TimeoutError.__init__.__func__.__qualname__ = "TimeoutError.__init__"



# Generated at 2022-06-24 09:22:54.524221
# Unit test for function re_unescape

# Generated at 2022-06-24 09:23:03.850499
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def initialize(self, *args: Any, **kwargs: Any) -> None:
            super().initialize(*args, **kwargs)
            self.args = args
            self.kwargs = kwargs

    # Create an instance of TestConfigurable with given arguments.
    obj = TestConfigurable(1, 2, 3, x=4, y=5, z=6)

    # assert obj.args == (1, 2, 3)
    # assert obj.kwargs == {'x': 4, 'y': 5, 'z': 6}



# Generated at 2022-06-24 09:23:13.980213
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from tornado.util import raise_exc_info

    try:
        raise ValueError(1)
    except Exception:
        frame_info = sys.exc_info()[2].tb_frame.f_locals
        if "frame_info" in frame_info:
            del frame_info["frame_info"]
    try:
        raise ValueError(2)
    except Exception:
        exc_info = sys.exc_info()

    try:
        raise_exc_info(exc_info)
    except ValueError as e:
        assert e.args[0] == 2

    suite = doctests()  # type: ignore
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.wasSuccessful(), "doctests failed"




# Generated at 2022-06-24 09:23:20.413113
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(a):
        return a
    arg_replacer = ArgReplacer(test_func, 'a')
    assert(arg_replacer.get_old_value((), {}) == None)
    assert(arg_replacer.get_old_value((1,), {}) == 1)
    assert(arg_replacer.get_old_value((), {'a':2}) == 2)
    assert(arg_replacer.get_old_value((1,), {'a':2}) == 1)


# Generated at 2022-06-24 09:23:32.119922
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 0
    try:
        raise IOError(1)
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 1
    try:
        raise IOError("foo")
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == "foo"
    try:
        raise IOError(1, "foo")
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 1
    try:
        raise Exception()
    except Exception as e:
        errno = errno_from_exception(e)

# Generated at 2022-06-24 09:23:42.832119
# Unit test for constructor of class Configurable
def test_Configurable():
    stack = [None]

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self):
            stack.append(self.__class__)

    class B(A):
        def initialize(self):
            stack.append(self.__class__)
            super(B, self).initialize()

    class C(A):
        def initialize(self):
            stack.append(self.__class__)
            super(C, self).initialize()

    A()
    assert stack == [None, B, A]
    stack.pop()
    stack.pop()

    A.configure(impl=C)
    A()

# Generated at 2022-06-24 09:23:46.807729
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import gzip
    data = b"blah"
    with gzip.GzipFile(mode="w", fileobj=BytesIO()) as f:
        f.write(data)
    with gzip.GzipFile(mode="r", fileobj=BytesIO(f.getvalue())) as g:
        assert g.read() == data



# Generated at 2022-06-24 09:23:52.299718
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    a = [1,2,3]
    b = {'a': 1, 'c': 3}
    def func(x, y, z):
        # type: (int, int, int) -> None
        return
    arg_replacer = ArgReplacer(func, 'y')
    assert arg_replacer.replace(6, a, b) == (2, [1,6,3], {'a':1, 'c':3})
    print('pass')

if __name__ == '__main__':
    test_ArgReplacer_replace()

# Generated at 2022-06-24 09:23:53.517814
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    Configurable.configure(None)
    assert Configurable(a=1).a == 1


# Generated at 2022-06-24 09:23:54.081532
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    pass

# Generated at 2022-06-24 09:23:59.067114
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(33, "error")
    except Exception as e:
        assert errno_from_exception(e) == 33

    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:24:02.891409
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    try:
        gzip_decompressor = tornado.util.GzipDecompressor()
        gzip_decompressor.flush()
        err = False
    except TypeError:
        err = True


# Generated at 2022-06-24 09:24:14.311694
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    def to_test(bytesto, string):
        got = GzipDecompressor().decompress(bytesto)
        utils.expect_eq(got, string)

    to_test(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6d\x6f\xdb\x30\x10\xbd\xf7\x57\xe8\xef\x02\x00\x0a\xbc\x8e\x94\x0a\x00\x00\x00', b'')

# Generated at 2022-06-24 09:24:14.878699
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    pass

# Generated at 2022-06-24 09:24:20.704472
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1)) == -1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=0.1)) == 0.1
    assert timedelta_to_seconds(datetime.timedelta(seconds=-0.1)) == -0.1
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 1 / 10 ** 6



# Generated at 2022-06-24 09:24:29.030511
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()  # type: ignore
    TimeoutError("foo")  # type: ignore


# import here to avoid import loop
from tornado.log import gen_log
from . import _crc32c

# crc32c casts to unsigned int or long depending on platform,
# so its return type is ambiguous. On Windows, we need to use
# ctypes to get the correct return type to match the type
# of the return type of zlib.crc32.
if os.name == 'nt':
    from ctypes import c_uint
    crc32_func_type = Callable[[bytes, c_uint], c_uint]
else:
    crc32_func_type = Callable[[bytes, int], int]



# Generated at 2022-06-24 09:24:35.448755
# Unit test for function re_unescape
def test_re_unescape():
    for x in [
        "",
        "a",
        "abc",
        "0",
        ".",
        "\\",
        "\\\\",
        "\\a",
        "\\abc",
        "\\0",
        "\\.",
    ]:
        assert x == re_unescape(re.escape(x))
    with pytest.raises(ValueError):
        re_unescape(r"\d")
    with pytest.raises(ValueError):
        re_unescape(r"\D")
    with pytest.raises(ValueError):
        re_unescape(r"a\b")
    with pytest.raises(ValueError):
        re_unescape(r"a\B")


# Generated at 2022-06-24 09:24:47.050072
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b):
    # type: (int, int) -> None
        pass

    def func2(a, b=2):
        # type: (int, int) -> None
        pass

    def func3(a, b=2, c=3):
        # type: (int, int, int) -> None
        pass

    def func4(a, b, c=3, d=4):
        # type: (int, int, int, int) -> None
        pass

    def func5(
        a,  # type: int
        b,  # type: int
        c,  # type: int
        d,  # type: int
        e,  # type: int
    ):
        # type: (...) -> None
        pass


# Generated at 2022-06-24 09:24:49.630358
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()
    d['name'] = "liuxb"
    assert d.name == "liuxb"
    assert d['name'] == "liuxb"
    assert d.get('name') == "liuxb"
    assert d.get('phone', '1234567') == "1234567"



# Generated at 2022-06-24 09:25:01.924427
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    a = ArgReplacer(lambda self, x, y, z=3: None, "y")
    assert a.get_old_value((1, 2, 3), {}) == 2
    assert a.get_old_value((1,), {"y": 2}) == 2
    assert a.get_old_value((1, 2, 3), {"y": 4}) == 2
    assert a.get_old_value((1, 2), {"z": 4}) == None
    assert a.get_old_value((), {"y": 4}) == 4
    assert a.replace(8, (1, 2, 3), {}) == (2, (1, 8, 3), {})
    assert a.replace(8, (1, 2), {"z": 4}) == (None, (1, 8), {"z": 4})

# Generated at 2022-06-24 09:25:06.739498
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def test_exception():
        x = 1/0
    def test_raise_exc_info():
        try:
            test_exception()
        except Exception:
            raise_exc_info(sys.exc_info())
    test_raise_exc_info()
# End of function test_raise_exc_info



# Generated at 2022-06-24 09:25:11.344752
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def _test(unconsumed_tail):
        gzipdecompressor = GzipDecompressor()
        gzipdecompressor.decompressobj = Mock({'flush':unconsumed_tail})
        assert gzipdecompressor.flush() == unconsumed_tail

    _test(None)

# Generated at 2022-06-24 09:25:19.740551
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    timeout_error = TimeoutError()
    timeout_error = TimeoutError('message')
    timeout_error = TimeoutError('message', 'argument')
    timeout_error = TimeoutError('message', 'argument', cause='argument')
    assert isinstance(timeout_error, TimeoutError)


# Generated at 2022-06-24 09:25:24.930213
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzipdecompressor = GzipDecompressor()
    a = "hello world"  # type: str
    b = gzipdecompressor.decompress(a)
    assert b == b"6b5d41b8f594b7afb187a0724ca9f2e2"


# Generated at 2022-06-24 09:25:33.424289
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a: int, b: int, c: int) -> None:
        pass

    a = ArgReplacer(foo, 'a')
    old_value, args, kwargs = a.replace(1, (), {})
    assert kwargs['a'] == 1
    assert old_value is None
    old_value, args, kwargs = a.replace(2, (3,), {})
    assert not kwargs
    assert args[0] == 2
    assert old_value == 3



# Generated at 2022-06-24 09:25:44.643241
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(x, y, z=10):
        return x, y, z

    in_args = (1, 2)
    in_kwargs = {
        'z': None
    }
    arg_replacer = ArgReplacer(f, 'x')
    old_value_x, in_args, in_kwargs = arg_replacer.replace(3, in_args, in_kwargs)
    assert old_value_x == 1
    assert in_args == (3, 2)
    assert in_kwargs == {'z': None}

    old_value_y, in_args, in_kwargs = arg_replacer.replace(4, in_args, in_kwargs)
    assert old_value_y == 2

    old_value_z, in_args, in_kwargs = arg_

# Generated at 2022-06-24 09:25:53.698770
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        pass

    a = A()
    assert isinstance(a, A)
    assert a.__class__.__name__ == "A"

    class B(Configurable):
        def configurable_base(self):
            return A

    class B_impl(B):
        def initialize(self, x, y):
            self.x = x
            self.y = y

    B.configure(B_impl, x="a", y="b")
    b = B()
    assert isinstance(b, B)
    assert b.__class__.__name__ == "B_impl"
    assert b.x == "a"
    assert b.y == "b"

    b2 = B(x="c", y="d")
    assert b2

# Generated at 2022-06-24 09:25:59.406964
# Unit test for function import_object
def test_import_object():
    assert import_object("os.path") is os.path
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
        raise Exception("did not get expected ImportError")
    except ImportError:
        pass


_MODE_CLOSED = 0
_MODE_STREAMING = 1
_MODE_DICT = 2



# Generated at 2022-06-24 09:26:04.229216
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, "Hello")
    except OSError as e:
        assert errno_from_exception(e) == 5
    try:
        raise ValueError()
    except ValueError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:26:08.245822
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import zlib
    decompressor = GzipDecompressor()
    data = zlib.compress(b"some data")
    assert decompressor.decompress(data) == b"some data"
    assert decompressor.decompress(b"") == b""

# Generated at 2022-06-24 09:26:13.007137
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def a(b,c,d=5,e=6,*f,**g):
        return b,c,d,e,f,g
    
    def b(c,d,*e,**f):
        return c,d,e,f
    
    def c(d=7, e=8):
        return d,e
    
    def d(e=9):
        return e
    
    def e(f):
        return f
    
    def f():
        return
    
    arg = ArgReplacer(a, 'd')
    assert arg.get_old_value(a(1,2), {}) == 5
    assert arg.get_old_value(a(1,2,3), {}) == 3

# Generated at 2022-06-24 09:26:22.914300
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Try with a complete gzip file
    data = open("tornado/test/gzip_file", "rb").read()
    d = GzipDecompressor()
    assert d.decompress(data) == b"hello\n"
    assert b"" == d.unconsumed_tail
    assert b"" == d.flush()
    # Try with a incomplete gzip file
    d = GzipDecompressor()
    assert d.decompress(data[:-5]) == b"hello\n"
    assert d.unconsumed_tail == data[-5:]
    assert b"" == d.flush()
    # Try with a complete but broken gzip file
    d = GzipDecompressor()

# Generated at 2022-06-24 09:26:31.526927
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c, d=4):
        pass

    r = ArgReplacer(foo, "d")
    assert r.get_old_value((1, 2, 3), {}) == 4
    assert r.replace(5, (1, 2, 3), {}) == (4, (1, 2, 3), {"d": 5})
    assert r.replace(5, (1, 2, 3), {"d": 6}) == (6, (1, 2, 3), {"d": 5})
    # Also works with kwargs-only
    r = ArgReplacer(foo, "a")
    assert r.get_old_value((), {}) is None
    assert r.replace(1, (), {}) == (None, (), {"a": 1})
    assert r.replace(1, (), {"a": 2})

# Generated at 2022-06-24 09:26:37.508863
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import io, gzip
    data = b"some compressed data"
    with io.BytesIO() as uncomp_f, gzip.GzipFile(mode='wb', fileobj=uncomp_f) as comp_f:
        comp_f.write(data)
        comp_f.close()
        compressed_data = uncomp_f.getvalue()
    uncomp = GzipDecompressor().decompress(compressed_data)
    assert uncomp == data

# Deprecated alias of GzipDecompressor.

# Generated at 2022-06-24 09:26:43.516302
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import sys
    import textwrap

    failures, _ = doctest.testmod(sys.modules[__name__], verbose=False)
    assert failures == 0
# Define a main function for basic testing.  Some globals are defined here
# so that they will be available in the interpreter session after running
# this file as a script.

# Generated at 2022-06-24 09:26:45.568034
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # noqa A001
    e = TimeoutError()
    assert str(e) == str(Exception())



# Generated at 2022-06-24 09:26:51.347594
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c):
        pass
    ar = ArgReplacer(foo, 'b')
    assert ar.get_old_value((1,2,3), {'a':1, 'c':3}, default=None) == 2
    assert ar.replace(2, (1,3,3), {'a':1, 'c':3}) == (3, (1,2,3), {'a':1, 'c':3})



# Generated at 2022-06-24 09:26:54.160511
# Unit test for function doctests
def test_doctests():
    import doctest
    import unittest

    suite = doctests()
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)


# Mapping from possible separators in a cookie to the separator character
# used when constructing the dict.
_cookie_separator_map = {";": ";", "&": "&", ",": ","}



# Generated at 2022-06-24 09:26:57.269960
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=2)) == 172800.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=2)) == 2.0



# Generated at 2022-06-24 09:26:58.891717
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b=1): pass
    arg_replacer = ArgReplacer(func, 'b')
    assert arg_replacer.get_old_value((), {}) == 1


# Generated at 2022-06-24 09:27:04.492563
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(123, 'msg')
    except IOError as e:
        assert e.errno == 123
        assert errno_from_exception(e) == 123
    try:
        raise IOError()
    except IOError as e:
        assert e.errno is None
        assert errno_from_exception(e) is None
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:27:07.652460
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    od = ObjectDict({"a": 1})
    assert od.a == 1
    for i in range(10):
        try:
            getattr(od, i)
            assert False
        except AttributeError:
            pass

# Generated at 2022-06-24 09:27:10.064107
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict(x=1)
    assert d.x == 1
    try:
        d.y
        assert False, d.y
    except AttributeError:
        pass



# Generated at 2022-06-24 09:27:21.883638
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1.5)) == 86401.5
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, hours=23, minutes=59, seconds=0.000001)) == 86380.000001



# Generated at 2022-06-24 09:27:27.193980
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"


# Generated at 2022-06-24 09:27:28.139593
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        pass
    
    

# Generated at 2022-06-24 09:27:29.514493
# Unit test for function re_unescape
def test_re_unescape():
    _re_unescape_pattern  # silence flake8 warning
    _re_unescape_replacement  # silence flake8 warning



# Generated at 2022-06-24 09:27:35.591478
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def testfunc(a,b):
        pass
    print("正确的参数处理：")
    ar = ArgReplacer(testfunc, 'a')
    args = (1, 2)
    kwargs = {}
    old_value, args, kwargs = ar.replace(3, args, kwargs)
    assert args == (3, 2)
    assert kwargs == {}
    assert old_value == 1
    args = (1,)
    old_value, args, kwargs = ar.replace(3, args, kwargs)
    assert args == (3,)
    assert kwargs == {}
    assert old_value == 1
    args = ()
    kwargs = {'b':2}
    old_value, args, kwargs = ar

# Generated at 2022-06-24 09:27:45.189731
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # type: () -> None
    decompressor = GzipDecompressor()
    uncompressed_data = b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n"
    compressed_data = b"1f8b080000000000000bcb4bcc4db57cb401000000"
    uncompressed_data_output = decompressor.decompress(
        zlib.decompress(bytearray.fromhex(compressed_data)))
    assert uncompressed_data_output == uncompressed_data
    assert_equal(decompressor.flush(), b'')
    with pytest.raises(Exception):
        decompressor.flush()
        decompressor.decompress(b'')


# Generated at 2022-06-24 09:27:51.024954
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError("")
    except TimeoutError:
        pass


# Alias for backwards compatibility (also used by pytype)
gen_TimeoutError = TimeoutError


# Backwards compatibility aliases.
Timeout = TimeoutError
gen_Timeout = gen_TimeoutError

_TO_UNICODE_TYPES = (bytes, type(None))



# Generated at 2022-06-24 09:27:53.996989
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    import datetime

    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.2)) == 1.2



# Generated at 2022-06-24 09:28:00.117454
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    name = 'query'
    def query_categories_with_consumer(query, consumer, **kwargs):
        pass
    index = ArgReplacer(query_categories_with_consumer, name)
    query = 'query1'
    kwargs = {'consumer': 'consumer1'}
    old_value, new_args, new_kwargs = index.replace(query, [], kwargs)
    assert old_value is None, print(old_value)
    assert new_args == [query], print(new_args)
    assert new_kwargs == kwargs, print(new_kwargs)
    query2 = 'query2'
    kwargs = {'consumer': 'consumer1', name: query}

# Generated at 2022-06-24 09:28:10.981221
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"foo\$") == r"foo$"
    assert re_unescape(r"foo\{}") == r"foo{}"

# Generated at 2022-06-24 09:28:18.957927
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    configurable_base = Configurable.configurable_base
    configurable_default = Configurable.configurable_default
    configured_class = Configurable.configured_class
    configure = Configurable.configure

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A1

    class A1(A):
        pass

    class A2(A):
        pass

    assert configurable_base() == A
    assert configurable_default() == A1
    assert configured_class() == A1
    assert A()

    configure(A2)
    assert configurable_base() == A
   

# Generated at 2022-06-24 09:28:29.280867
# Unit test for constructor of class Configurable
def test_Configurable():
    class SubclassWithKwargs(Configurable):
        def configurable_base(self):
            return SubclassWithKwargs

        def configurable_default(self):
            return DefaultImpl

        def initialize(self, foo=None, bar=None):  # type: ignore
            self.foo, self.bar = foo, bar

    class DefaultImpl(SubclassWithKwargs):
        def initialize(self, foo=None, bar=None):  # type: ignore
            SubclassWithKwargs.initialize(self, foo, bar)

    class Subclass(Configurable):
        def configurable_base(self):
            return Subclass

        def configurable_default(self):
            return SubclassWithKwargs

        def initialize(self, bar=None, baz=None):  # type: ignore
            self.bar

# Generated at 2022-06-24 09:28:33.108122
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass

# These aliases are for backwards-compatibility
# The new alias test_TimeoutError ensures these are defined
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:28:41.806767
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c, d):
        pass
    old_value = ArgReplacer(f, name='d').get_old_value(args=(1, 2, 3), kwargs={})
    assert old_value == None
    old_value = ArgReplacer(f, name='d').get_old_value(args=(1, 2, 3), kwargs={'d':4})
    assert old_value == 4
    old_value = ArgReplacer(f, name='d').get_old_value(args=(1, 2, 3, 4), kwargs={})
    assert old_value == 4
    old_value = ArgReplacer(f, name='d').get_old_value(args=(1, 2, 3, 4), kwargs={'d':5})
    assert old_value == 4

# Generated at 2022-06-24 09:28:52.475903
# Unit test for function import_object
def test_import_object():
    class TestImportObject(unittest.TestCase):
        def test_import_object(self):
            import tornado.escape
            import tornado.util
            self.assertTrue(
                import_object('tornado.escape') is tornado.escape,
                'import_object should match original object',
            )
            self.assertTrue(
                import_object('tornado.util') is tornado.util,
                'import_object should match original object',
            )
            self.assertTrue(
                import_object('tornado.escape.utf8') is tornado.escape.utf8,
                'import_object should import and match object',
            )
            self.assertRaises(
                ImportError,
                import_object,
                'tornado.missing_module',
            )

# This regex is used in a number of places when

# Generated at 2022-06-24 09:28:58.937606
# Unit test for function doctests
def test_doctests():
    # type: () -> bool
    # doctests are named 'tornado.util.doctests'. This test is named
    # 'tornado.util_test.test_doctests' for historical reasons
    # (it used to be a different function named test_doctests)
    return doctests().runTest(doctests(), raise_on_error=True)



# Generated at 2022-06-24 09:29:05.902127
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(1, 'error_msg')
    except Exception as e:
        assert errno_from_exception(e) == 1
    try:
        raise IOError('error_msg')
    except Exception as e:
        assert errno_from_exception(e) == 'error_msg'
    try:
        raise ValueError(1, 'error_msg')
    except Exception as e:
        assert errno_from_exception(e) == 1
test_errno_from_exception()



# Generated at 2022-06-24 09:29:08.062884
# Unit test for function exec_in
def test_exec_in():
    y = 5

    def foo():
        x = 1
        exec_in("assert y == 5", globals(), locals())
        exec_in("x = y + 2", globals(), locals())
        return x

    assert foo() == 7



# Generated at 2022-06-24 09:29:14.361959
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise TypeError()
    except TypeError:
        exc_info = sys.exc_info()
    # TODO: on Python 3, test exc_info[2] is None vs. not None
    with pytest.raises(TypeError):
        raise_exc_info(exc_info)


_BYTES_TYPES = (bytes, bytearray)



# Generated at 2022-06-24 09:29:24.210186
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 1e-06
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=1)) == 1e-03
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401

# Generated at 2022-06-24 09:29:32.128373
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import unittest
    import sys

    suite = doctests()

    # If '-v' is in sys.argv, the output from the doctests will be
    # printed even if the tests all pass.
    runner = unittest.TextTestRunner(verbosity=2)
    if not runner.run(suite).wasSuccessful():
        sys.exit(1)

# Generated at 2022-06-24 09:29:40.481527
# Unit test for function import_object
def test_import_object():
    assert import_object("time") is time
    assert import_object("os.path") is os.path
    assert import_object("os") is os
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado.test.test_util") is tornado.test.test_util

    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        raise Error("import_object did not fail on missing module")

    try:
        import_object("missing_module")
    except ImportError:
        pass
    else:
        raise Error("import_object did not fail on missing module")



# Generated at 2022-06-24 09:29:47.324686
# Unit test for function import_object
def test_import_object():
    from io import BytesIO
    from tornado.htpclient import HTTPResponse

    import_object("tornado.util").import_object("io.BytesIO") is BytesIO
    import_object("tornado.util").import_object("tornado.httputil.HTTPResponse") is HTTPResponse
    import_object("tornado.util").import_object("sys") is sys



# Generated at 2022-06-24 09:29:56.824607
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    data = b"\x1f\x8b\x08\x08\x1b\x60\xe7\x5a\x00\x03t\x00\xf3\xc4\xd1\x0d\x00\x00\x00"
    decompressor = GzipDecompressor()
    assert decompressor.decompress(data) == b"Test"
    assert decompressor.flush() == b""

# Python 3 removes the 'long' type, so int is used instead.
integer_types = (int,)
try:
    integer_types += (long,) # type: ignore
except NameError:
    pass



# Generated at 2022-06-24 09:30:06.306235
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return FooImpl

        def initialize(
            self,
            bar=None,  # type: Optional[str]
            baz=None,  # type: Optional[int]
        ):
            # type: (...) -> None
            pass

    class FooImpl(Foo):
        pass

    assert Foo().initialize is Foo._initialize  # type: ignore
    Foo.configure(None)
    assert Foo().initialize is Foo._initialize  # type: ignore
    Foo.configure("tornado.test.test_util.FooImpl")
    assert Foo().initialize is not Foo._initialize  # type: ignore

# Generated at 2022-06-24 09:30:10.478847
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(x, y=10):
        print(x)
        print(y)
    args = (1, )
    kwargs = {}
    replacer = ArgReplacer(f, 'y')
    assert replacer.get_old_value(args, kwargs) == 10



# Generated at 2022-06-24 09:30:13.945613
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    """
    from typing import Union
    from tornado.util import ObjectDict

    def test_objdict(value: Union[Dict[str, str], ObjectDict[str]]):
        assert value.hello == 'world'
    """
    test_objdict(ObjectDict(hello='world'))



# Generated at 2022-06-24 09:30:24.941811
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 'bar'
    d.unicode_value = 'föo'
    assert d['foo'] == 'bar'
    assert d.foo == 'bar'
    assert d['unicode_value'] == 'föo'
    assert d.unicode_value == 'föo'
    assert d.missing is None
    d.none = None
    assert d.none is None
    assert list(d.keys()) == ['foo', 'unicode_value', 'missing', 'none']
    assert list(d.values()) == ['bar', 'föo', None, None]
    assert 'foo' in d
    assert 'missing' not in d
    assert len(d) == 4
    d2 = ObjectDict(foo=1)
    assert d2['foo']

# Generated at 2022-06-24 09:30:33.472898
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Prepare a short gzip stream
    short_data = b"xxxxhello worldxxxx"
    compressed = zlib.compress(short_data)
    header = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff"
    fake_stream = header + compressed + b"\x03\x00" + zlib.crc32(short_data)

    # Read the stream using GzipDecompressor
    d = GzipDecompressor()
    result = d.decompress(fake_stream, 15)
    result += d.flush()

    # Check result
    assert result == short_data



# Generated at 2022-06-24 09:30:40.351144
# Unit test for function exec_in
def test_exec_in():
    loc = {}
    glo = {}
    exec_in('x=123; y="hello"', glo, loc)
    assert loc["x"] == 123
    assert loc["y"] == "hello"
    loc = {}
    glo = {}
    exec_in('z="hi"; m=456', glo, loc)
    assert glo["z"] == "hi"
    assert glo["m"] == 456

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 09:30:43.458568
# Unit test for function doctests
def test_doctests():
    # type: () -> unittest.TestSuite
    return doctests()


# Python 3.2 changed the name of Exception.message to Exception.args
# The @add_metaclass line below permits our code to be compatible
# with both versions.

# Generated at 2022-06-24 09:30:49.630732
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gz = GzipDecompressor()
    gz2 = GzipDecompressor()
    assert not gz.unconsumed_tail
    assert not gz2.unconsumed_tail
    assert gz.decompress(b"\x1f\x8b\x08\x00") == b""
    assert not gz2.decompress(b"\x1f\x8b\x08\x00", 1)
    assert gz2.decompress(b"\x1f\x8b\x08\x00", 2) == b""
    assert gz2.unconsumed_tail == b"\x08\x00"



# Generated at 2022-06-24 09:30:56.161020
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b, c, d=None, e=None):
        pass

    # Same type test is missing
    # assert foo(*res) == foo(1, 2, 3, 4, 5)
    args, kwargs = (), {} # type: Tuple[Any], Dict[str, Any]
    args = (1, 2, 3)
    args, kwargs = (1, 2, 3), {}
    res = ArgReplacer(foo, "d").replace(4, args, kwargs)
    assert res == (None, (1, 2, 3), {"d": 4})
    res = ArgReplacer(foo, "c").replace(5, args, kwargs)
    assert res == (3, (1, 2, 5), {})
    args, kwargs = (), {} # type: T

# Generated at 2022-06-24 09:30:57.782404
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    print(GzipDecompressor.decompress)


# Generated at 2022-06-24 09:31:00.465922
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = GzipDecompressor()
    gzip_decompressor.decompress()
    return gzip_decompressor


# Generated at 2022-06-24 09:31:08.551886
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A:
        pass

    class B(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return C

        def _initialize(self):
            pass

    class C(B):
        pass

    assert isinstance(B(), C)
    assert isinstance(B(), B)
    assert not isinstance(B(), A)
    B.configure(C)
    assert isinstance(B(), C)
    assert isinstance(B(), B)
    assert not isinstance(B(), A)



# Generated at 2022-06-24 09:31:15.402407
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(foo=1)
    assert isinstance(d, dict)
    assert isinstance(d, ObjectDict)
    assert d['foo'] == 1
    assert d.foo == 1
    d.foo = 2
    assert d['foo'] == 2
    d['foo'] = 1
    assert d.foo == 1

    # Test that __repr__ works even without foo.
    del d.foo
    assert d == ObjectDict()



# Generated at 2022-06-24 09:31:16.280529
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(1)) == 24 * 60 * 60



# Generated at 2022-06-24 09:31:24.885285
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):
        def initialize(self, **kwargs):
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return Foo

    assert Foo().kwargs == {}
    Foo.configure(None, one=1, two=2)
    assert Foo().kwargs == {"one": 1, "two": 2}
    Foo.configure(None, three=3)
    assert Foo().kwargs == {"one": 1, "two": 2, "three": 3}
    assert Foo.configured_class() is Foo



# Generated at 2022-06-24 09:31:26.766128
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()
    TimeoutError("foo")
    TimeoutError("foo", None)
    TimeoutError("foo", []).args



# Generated at 2022-06-24 09:31:35.083970
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c):
        return a, b, c

    args = (1, 2, 3)
    expected_result = (1, 2, 3)
    actual_result = ArgReplacer(func, "a").get_old_value(args, {})
    assert actual_result == expected_result

    args = (1, 2, 3)
    expected_result = 1
    actual_result = ArgReplacer(func, "a").get_old_value(args, {})
    assert actual_result == expected_result

    args = (1, 2, 3)
    expected_result = 3
    actual_result = ArgReplacer(func, "c").get_old_value(args, {})
    assert actual_result == expected_result

    args = (1, 2, 3)
    kwargs

# Generated at 2022-06-24 09:31:40.456142
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    """Test method flush of class GzipDecompressor.
    """
    decompressor = util.GzipDecompressor()
    data = b"some compressed data"
    gzipped_data = zlib.compress(data)
    assert decompressor.decompress(gzipped_data) == data
    assert decompressor.unconsumed_tail == b""
    assert decompressor.flush() == b""



# Generated at 2022-06-24 09:31:45.817661
# Unit test for function re_unescape
def test_re_unescape():
    # Don't use assertRaises here because it's a GeneratorContextManager
    # and doesn't support __exit__.
    try:
        re_unescape(r"\d")
    except ValueError:
        pass
    else:
        assert 0, "should have raised ValueError"



# Generated at 2022-06-24 09:31:48.233283
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.setattr_test = 42
    assert obj['setattr_test'] == 42


# Generated at 2022-06-24 09:31:54.374462
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    ObjectDict()

# For backwards compatibility.  This can be removed in a future version
# of Tornado
TimeoutError = TimeoutError

_ARGSPEC_PARAMS = typing.cast(
    Tuple[
        str,                  # args
        Optional[str],        # varargs
        Optional[str],        # varkw
        Optional[Sequence[str]],  # defaults
    ],
    getfullargspec(typing.cast(Callable[[], None], lambda: 0))[0:4],
)



# Generated at 2022-06-24 09:32:00.824069
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(name, arg_with_default="A"):
        print (name, arg_with_default)

    assert ArgReplacer(func, "name").get_old_value(("John",), {}, "default") == "John"
    assert ArgReplacer(func, "arg_with_default").get_old_value(("John",), {}, "default") == "A"
    assert ArgReplacer(func, "missing").get_old_value(("John",), {}, "default") == "default"
    assert ArgReplacer(func, "missing").get_old_value(("John",), {}, "default") == "default"
    
    

# Generated at 2022-06-24 09:32:04.830728
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    args = [1, 2, 3]
    kwargs = {"x": "abc", "y": "def"}
    old_value, args, kwargs = ArgReplacer("fake", "y").replace("xyz", args, kwargs)
    assert old_value == "def"
    assert args == [1, 2, 3]
    assert kwargs == {"x": "abc", "y": "xyz"}

# Generated at 2022-06-24 09:32:13.322178
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=0)) == 0.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1)) == -1.0
    assert timedelta_to_seconds(datetime.timedelta(microseconds=999)) == 0.0
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1e6)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0



# Generated at 2022-06-24 09:32:15.000115
# Unit test for function import_object
def test_import_object():
    import_object.__test__ = False  # type: ignore
    import_object('unittest').TestCase  # type: ignore



# Generated at 2022-06-24 09:32:26.106745
# Unit test for function import_object
def test_import_object():
    import sys

# Generated at 2022-06-24 09:32:36.355918
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    import functools

    def test_func(a, b, c, d=1):
        # type: (object, object, object, object) -> None
        pass

    assert ArgReplacer(test_func, "b").replace(
        2, (0, 1, 2, 3), {}
    ) == (1, (0, 2, 2, 3), {})

    assert ArgReplacer(test_func, "b").replace(
        2, (0, 1), {"c": 2, "d": 3}
    ) == (1, (), {"c": 2, "b": 2, "d": 3})
