

# Generated at 2022-06-24 09:22:34.438190
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # noqa
    def test_obj_attrs(d: typing.Union[Mapping[str, Any], object]) -> None:
        """test values of obj.attr and obj['attr']"""
        for attr, value in d.items():
            assert getattr(d, attr) == value
            assert d[attr] == value
    test_obj_attrs(ObjectDict())
    test_obj_attrs(ObjectDict(x=True, y=False))



# Generated at 2022-06-24 09:22:42.913073
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import zlib
    # Method decompress of class GzipDecompressor has 2 parameters (self, value, max_length)
    # Argument value has type str
    # Argument value has type bytes
    value = b""
    # Argument max_length has type int
    max_length = 0
    # Return type of method decompress of class GzipDecompressor is bytes
    gzipDecompressor = GzipDecompressor()
    assert (type(gzipDecompressor.decompress(value, max_length)) == bytes)
    # Test method decompress of class GzipDecompressor
    # Test 1

# Generated at 2022-06-24 09:22:51.382549
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(x: int, y: int, z: int = 3) -> Optional[tuple]:
        return x , y, z
    replacer = ArgReplacer(f, 'y')
    result = replacer.get_old_value(args=(1, 2, 3), kwargs={})
    assert result == 2
    old_value, args, kwargs = replacer.replace(5, args=(1, 2, 3), kwargs={})
    assert old_value == 2
    assert args == (1, 5, 3)
    assert kwargs == {}
    old_value, args, kwargs = replacer.replace(5, args=(1, 3), kwargs={})
    assert old_value == 3
    assert args == (1, 3)
    assert kw

# Generated at 2022-06-24 09:22:58.296416
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    import functools

    def _test_arg_replacer(regtest: "TestCase", arg_spec: Tuple[str, ...]) -> None:
        def _test_variant(regtest: "TestCase", *args):
            _test_arg_replacer(regtest, args)
        _test_variant(regtest, 'x', 'y')
        _test_variant(regtest, 'x', 'y', 'z')
        _test_variant(regtest, 'x', 'y', 'z', 't')

    def _test_arg_replacer_1(regtest: "TestCase", arg_spec: Tuple[str, ...]) -> None:
        def f(x, y, z, t=4):
            pass

# Generated at 2022-06-24 09:23:04.654689
# Unit test for function re_unescape
def test_re_unescape():

    _re_unescape_tests = (
        # input, expected output
        ("", ""),
        ("a", "a"),
        ("\\a", "a"),
        ("\\b", "\b"),
        ("\\", "\\"),
        ("\\\\", "\\"),
        ("\\\\a", "\\a"),
        ("a\\\\\\\\", "a\\\\"),
        ("a\\\\a", "a\\a"),
        ("\\\\\\a", "\\\\a"),
        ("\\[", "["),
        ("$", "$"),
        ("a$", "a$"),
    )

    for input, output in _re_unescape_tests:
        assert re_unescape(input) == output


# Generated at 2022-06-24 09:23:11.431833
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        x = TimeoutError("test")
    except TypeError:
        raise Exception("TimeoutError does not accept string constructor")

TimeoutError = TimeoutError  # type: Any  # flake8: noqa

# Alias for compatibility with older versions of Tornado
gen_TimeoutError = TimeoutError  # type: Any  # flake8: noqa
ioloop_TimeoutError = TimeoutError  # type: Any  # flake8: noqa



# Generated at 2022-06-24 09:23:15.816851
# Unit test for function raise_exc_info
def test_raise_exc_info():
    class MyException(Exception):
        pass
    try:
        raise MyException("foo")
    except Exception:
        exc_info = sys.exc_info()
        with raises(MyException):
            raise_exc_info(exc_info)



# Generated at 2022-06-24 09:23:23.771925
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a,b,c,d,e=1,f=2,g=3):
        return 0
    arg = ArgReplacer(func, 'f')
    assert arg.get_old_value((1,2,3,4), {'d':1, 'e':2, 'g':3}) == 2
    assert arg.get_old_value((1,2,3,4), {'f':'a', 'd':1, 'e':2, 'g':3}) == 'a'
    assert arg.get_old_value((1,2,3,4), {}) == None
    assert arg.get_old_value((1,2,3,4), {'d':1, 'e':2, 'g':3}, default=5) == 2

# Generated at 2022-06-24 09:23:25.684635
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    dec = GzipDecompressor
    f = dec.flush()
    return f
# Test decorator

# Generated at 2022-06-24 09:23:35.257824
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import binascii
    import gzip
    import io
    import zlib

    gz = GzipDecompressor()

    for i in range(1, 100):
        s = io.BytesIO()
        g = gzip.GzipFile(fileobj=s, mode="w")
        g.write(b'x' * i)
        g.close()
        buf = s.getvalue()

        # Decompress the gzip stream twice. First time should
        # complete without error. Second time should fail cleanly.
        for attempt in (1, 2):
            s = io.BytesIO(buf)
            d = GzipDecompressor()
            s.read(10)  # skip the gzip header
            unprocessed = buf[10:]
            while unprocessed:
                decompressed = d.dec

# Generated at 2022-06-24 09:23:45.679779
# Unit test for function exec_in
def test_exec_in():
    # (code, globals, locals): (str, Dict, Dict) -> Dict
    def check_exec(code: str, globals: Dict[str, Any], locals: Dict[str, Any]) -> Dict:
        exec_in(code, globals, locals)
        return locals

    exec("foo = 'bar'", {})
    assert check_exec("foo = 'bar'", {}, {})["foo"] == "bar"
    assert check_exec("foo = 123", {}, {})["foo"] == 123

    # globals and locals can be None
    assert check_exec("foo = 'bar'", None, None)["foo"] == "bar"

    # locals can be omitted
    assert check_exec("foo = 'bar'", {}, None)["foo"] == "bar"

    # locals can

# Generated at 2022-06-24 09:23:51.280670
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # pragma: no cover
    from unittest import TestCase
    from unittest.mock import Mock
    from io import StringIO
    import sys

    class TestObjectDict(TestCase):
        def test_constructor(self):
            obj = ObjectDict()
            self.assertIsInstance(obj, ObjectDict)
            self.assertIsInstance(obj, dict)
            self.assertEqual(obj, {})

    sys.stdout = StringIO()
    try:
        unittest.main()
    finally:
        sys.stdout = sys.__stdout__



# Generated at 2022-06-24 09:23:58.284160
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\\a\b\c") == r"\a\b\c"
    assert re_unescape(r"\\x7f") == r"\x7f"
    assert re_unescape(r"\\xff") == r"\xff"
    assert re_unescape(r"\\100") == r"\100"



# Generated at 2022-06-24 09:24:06.730050
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    f = lambda a, b=0: None
    r = ArgReplacer(f, "a")
    assert r.replace(42, (1,), dict(b=2)) == (1, (42,), dict(b=2))
    assert r.replace(42, (), dict(b=2, a=1)) == (1, (), dict(b=2, a=42))
    assert r.replace(42, (1, 2), dict()) == (1, (42, 2), dict(a=42))
    assert r.replace(42, (1, 2, 3), dict(b=2)) == (1, (42, 2, 3), dict(b=2, a=42))
    r = ArgReplacer(f, "b")

# Generated at 2022-06-24 09:24:14.181160
# Unit test for function exec_in
def test_exec_in():
    orig_stdout = sys.stdout
    try:
        glob = {}
        loc = {}
        exec_in("print(42)", glob)
        assert glob["print"]
        with output_to_bytesio() as buf:
            sys.stdout = buf
            exec_in("print(42)", glob, loc)
            assert glob["print"] is loc["print"]
            assert b"42" in buf.getvalue()
    finally:
        sys.stdout = orig_stdout



# Generated at 2022-06-24 09:24:16.696822
# Unit test for function import_object
def test_import_object():
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
        assert False
    except ImportError:
        pass



# Generated at 2022-06-24 09:24:27.613374
# Unit test for function exec_in
def test_exec_in():
    g = {}
    l = {}
    exec_in('x = 1', g)
    assert g == dict(x=1)
    exec_in('x = 1', g, l)
    assert g == dict(x=1)
    assert l == dict(x=1)
    exec_in('x = 1; y = 2', g, l)
    assert g == dict(x=1)
    assert l == dict(x=1, y=2)


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal

# Generated at 2022-06-24 09:24:35.198190
# Unit test for constructor of class Configurable
def test_Configurable():
    # Can't use the test decorators because we need to access the class
    # object.
    class _ConfigurableTestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):  # type: ignore
            return _ConfigurableTestConfigurable

        @classmethod
        def configurable_default(cls):  # type: ignore
            return _ConfigurableTestImpl

    class _ConfigurableTestImpl(Configurable):
        def __init__(self, foo, bar, **kwargs):
            # type: (str, int, **Any) -> None
            self.foo = foo
            self.bar = bar

    instance = _ConfigurableTestConfigurable(foo='spam', bar=1)
    assert isinstance(instance, _ConfigurableTestImpl)
    assert instance.foo == 'spam'

# Generated at 2022-06-24 09:24:37.397604
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import zlib
    assert zlib.decompressobj(16 + zlib.MAX_WBITS).flush() is not None



# Generated at 2022-06-24 09:24:49.149566
# Unit test for constructor of class Configurable
def test_Configurable():
    class X(Configurable):
        @classmethod
        def configurable_base(cls):
            return X

        @classmethod
        def configurable_default(cls):
            return X

        def __init__(self, a, b=2, c=3):
            self.a, self.b, self.c = a, b, c

    X.configure(None)
    assert X(4).a == 4
    assert X(4).b == 2
    assert X(4).c == 3
    assert X(4, 5).a == 4
    assert X(4, 5).b == 5
    assert X(4, 5).c == 3
    assert X(4, 5, 6).a == 4
    assert X(4, 5, 6).b == 5

# Generated at 2022-06-24 09:24:53.639722
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    import string
    import random
    msg = "".join([random.choice(string.ascii_letters) for _ in range(4000)])
    try:
        raise TimeoutError(msg)
    except TimeoutError as e:
        assert msg == str(e)



# Generated at 2022-06-24 09:25:05.600011
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.ioloop import IOLoop

    class TestConfig(Configurable):

        def configure_test(self, name, age):
            # type: (str, int) -> None
            self.name = name
            self.age = age

        def test_method(self):
            # type: () -> None
            pass

    class TestConfigImpl1(TestConfig):

        def initialize(self):
            # type: () -> None
            pass

    class TestConfigImpl2(TestConfig):

        def initialize(self, age, name):
            # type: (int, str) -> None
            pass

    class IOLoopConfig(Configurable):

        def configurable_base(self):
            # type: () -> Type[Configurable]
            return IOLoop


# Generated at 2022-06-24 09:25:07.671499
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None

    class MyConfigurable(Configurable):
        pass

    MyConfigurable.configure(None)



# Generated at 2022-06-24 09:25:10.736874
# Unit test for function doctests
def test_doctests():
    suite = doctests()
    runner = unittest.TextTestRunner(stream=io.StringIO())
    result = runner.run(suite)
    assert result.testsRun == suite.countTestCases()
    assert result.wasSuccessful()



# Generated at 2022-06-24 09:25:13.179684
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.name = "Bogdan"
    print(obj.name)
    
test_ObjectDict___setattr__()


# Generated at 2022-06-24 09:25:20.732111
# Unit test for constructor of class Configurable
def test_Configurable():
    class Bar(Configurable):
        pass

    class Foo(Bar):
        @classmethod
        def configurable_base(cls):
            return Bar

        @classmethod
        def configurable_default(cls):
            return impl

    class impl(Foo):
        def initialize(self, v):
            self.value = v

    Foo.configure(impl)
    assert Foo(42).value == 42
    assert Foo.configured_class() is impl

    class impl2(Foo):
        pass

    Foo.configure(impl2)
    assert isinstance(Foo(42), impl2)
    assert Foo.configured_class() is impl2



# Generated at 2022-06-24 09:25:23.941532
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a = ObjectDict(dict({"a": 1, "b": 2}))
    assert a.a == 1
    assert a.b == 2
    assert a.c is None


# Generated at 2022-06-24 09:25:30.148107
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def positional(arg1, arg2):
        return arg1, arg2

    def kwarg(arg1, arg2=None):
        return arg1, arg2

    def vararg(*args):
        return args

    def kwonlyarg(arg1, *, arg2=None):
        return arg1, arg2

    def kwonlyarg_default(arg1=None, *, arg2=None):
        return arg1, arg2

    def positional_positional(arg1, arg2, arg3):
        return arg1, arg2, arg3

    if PY3:
        def pos_kw_only(arg1, arg2, *, arg3=None):
            return arg1, arg2, arg3

        def kw_only_positional(*, arg1, arg2):
            return arg

# Generated at 2022-06-24 09:25:33.425026
# Unit test for function exec_in
def test_exec_in():
    # type: () -> None
    glob = {'foo': 1}
    exec_in('bar = foo+1', glob)
    assert glob['bar'] == 2



# Generated at 2022-06-24 09:25:43.529769
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class SomeClass(Configurable):  # type: ignore
        def initialize(self, arg1, arg2, arg3=None):
            self.args = (arg1, arg2, arg3)
    SomeClass.configure(None)

    obj = SomeClass(1, 2, 3)
    assert obj.args == (1, 2, 3), obj.args
    assert isinstance(obj, SomeClass), obj

    obj = SomeClass(1, 2)
    assert obj.args == (1, 2, None), obj.args
    assert isinstance(obj, SomeClass), obj

    with pytest.raises(TypeError):
        SomeClass(1, 2, 3, 4)



# Generated at 2022-06-24 09:25:52.860029
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import io
    import gzip
    import unittest
    from tornado.util import GzipDecompressor
    class TestGzipDecompressor_flush(unittest.TestCase):
        def setUp(self):
            self.gzip_file = io.BytesIO()
            with gzip.GzipFile(fileobj=self.gzip_file, mode='w') as f:
                f.write(b'x' * 1000000)
            self.gzip_file.seek(0)
            self.gzip_decompressor = GzipDecompressor()

        def test_GzipDecompressor_flush(self):
            data = b""
            while 1:
                chunk = self.gzip_file.read(1024)
                if chunk:
                    data += self.gzip_decompressor.decomp

# Generated at 2022-06-24 09:26:01.467418
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"a\b") == r"a\b"
    assert re_unescape(r"a\\b") == r"a\b"
    assert re_unescape(r"a\\\b") == r"a\\b"
    assert re_unescape(r"a\\\\\b") == r"a\\\b"
    assert re_unescape(r"\$foo") == r"$foo"
    assert re_unescape(r"\\$foo") == r"\$foo"
    assert re_unescape(r"\*") == r"\*"
    assert re_unescape(r"\\*") == r"\*"
    raises(ValueError, lambda: re_unescape(r"\a"))

# Generated at 2022-06-24 09:26:06.013169
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    TIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    t1 = '2008-09-03 00:00:00'
    t2 = '2008-09-02 00:00:00'
    import datetime
    t3 = datetime.datetime.strptime(t1,TIME_FORMAT)
    t4 = datetime.datetime.strptime(t2,TIME_FORMAT)
    delta = t3 - t4
    seconds = timedelta_to_seconds(delta)
    assert seconds == 86400.0

# test_timedelta_to_seconds()



# Generated at 2022-06-24 09:26:14.737227
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Test a variety of inputs (under-filled, filled exactly, overfilled)
    for input_size in range(0, 7):
        # The exact size is arbitrary, but "is not None" is a useful test
        data = b"hello"
        decompressor = GzipDecompressor()
        output_size = 0
        while output_size == 0:
            # Attempt to decompress the input data, and then check whether
            # the output has any data.
            result = decompressor.decompress(data[:input_size])
            if result is not None:
                output_size = len(result)
            # Ensure that the remaining data is empty.
            assert decompressor.unconsumed_tail == b""
            input_size += 1
        # Ensure that we have enough input bytes to decompress all of the
        # output bytes.

# Generated at 2022-06-24 09:26:23.840774
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # This has errno set, so it should return it
    try:
        raise OSError(11, "OSError")
    except OSError as e:
        errno = errno_from_exception(e)
        assert errno == 11

    # This was instantiated without an errno, so it should be None
    try:
        raise OSError(11)
    except OSError as e:
        errno = errno_from_exception(e)
        assert errno is None

    # This was instantiated without an errno, so it should be None
    try:
        raise ValueError
    except ValueError as e:
        errno = errno_from_exception(e)
        assert errno is None



# Generated at 2022-06-24 09:26:26.794640
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class TestClass:
        def __init__(self, foo, bar, baz):
            self.foo = foo
            self.bar = bar
            self.baz = baz

    instance = TestClass(foo=1, bar=2, baz=3)
    print(instance.foo)
    replacer = ArgReplacer(TestClass, 'foo')
    replacer.replace(42, (1, 2, 3), {})
    print(instance.foo)



# Generated at 2022-06-24 09:26:29.868989
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    my_decompressor = GzipDecompressor()
    # test if max_length is None
    my_decompressor.decompress(b'hello,world!')


# Generated at 2022-06-24 09:26:34.471940
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    data = "test_test_test"
    compress_value = zlib.compress(data)
    gzip_decompressor = GzipDecompressor()
    decompress_value = gzip_decompressor.decompress(compress_value,100)
    assert data == decompress_value
    assert decompress_value == gzip_decompressor.flush()



# Generated at 2022-06-24 09:26:38.176073
# Unit test for function import_object
def test_import_object():
    assert import_object("time") is time
    assert import_object("os.path") is os.path
    assert import_object("os") is os
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8



# Generated at 2022-06-24 09:26:45.618530
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def _raise_exc_info(exc, val, tb):
        # type: (Optional[type], Optional[BaseException], Optional[TracebackType]) -> None
        raise_exc_info((exc, val, tb))

    try:
        raise IndexError
    except IndexError:
        exc_info = sys.exc_info()
        _raise_exc_info(*exc_info)


# Fake parser is used by doctests

# Generated at 2022-06-24 09:26:52.069001
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado.escape import utf8
    from tornado.testing import gen_test, AsyncTestCase
    # __main__.GzipDecompressor
    class MockDecompressobj(object):
        def __init__(self):
            pass
        def decompress(self, value: bytes, max_length: int = 0) -> bytes:
            pass
        @property
        def unconsumed_tail(self) -> bytes:
            return b''
        def flush(self):
            return b'flush'
    # __main__.test_GzipDecompressor_flush
    class MockGzipDecompressor(object):
        def __init__(self):
            self.decompressobj = MockDecompressobj()
        def decompress(self, value: bytes, max_length: int = 0) -> bytes:
            pass

# Generated at 2022-06-24 09:27:01.323678
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    compressor = GzipDecompressor()
    # case 1
    raw_data = open("./test.gz", "rb").read()
    decompressed_data = compressor.decompress(raw_data)
    assert decompressed_data == b"12345678901234567890123456789012345678901234567890\n"
    # case 2
    raw_data = open("./test.gz", "rb").read(50)
    decompressed_data = compressor.decompress(raw_data)
    assert decompressed_data == b"1234567890123456789012345678"
    # case 3
    raw_data = open("./test.gz", "rb").read(20)
    decompressed_data = compressor.decompress(raw_data)
   

# Generated at 2022-06-24 09:27:03.505733
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        x = 1 / 0
    except Exception as e:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-24 09:27:07.918969
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c):
        pass
    ar = ArgReplacer(f, "a")
    assert ar.get_old_value((1, 2, 3), {}) == 1
    assert ar.get_old_value((), {"a": 1}) == 1
    assert ar.get_old_value((), {}) is None
    assert ar.get_old_value((), {}, default=5) == 5
    assert ar.get_old_value((1, 2, 3), {}, default=5) == 1
    assert ar.get_old_value((), {"a": 1}, default=5) == 1

# Generated at 2022-06-24 09:27:18.774980
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    TimeoutError()


# Alias for backward-compatibility. This can be removed in a future version.
Timeout = TimeoutError

try:
    # The concurrent.futures module was added in Python 3.2;
    # prior to that there was no official module.
    import concurrent.futures as futures  # type: ignore
except ImportError:
    try:
        import futures  # type: ignore
    except ImportError:
        futures = None

if futures is not None:
    # Define a simple, synchronous Executor for use in `with_timeout`.
    _synchronous_executor = futures.ThreadPoolExecutor(max_workers=1)

    def _synchronous_future(f):
        # type: (Callable) -> futures.Future
        return _synchron

# Generated at 2022-06-24 09:27:28.890156
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r'\ ') == r' '
    assert re_unescape(r'\a') == r'a'
    assert re_unescape(r'\Z') == r'Z'
    assert re_unescape(r'\a\Z') == r'aZ'
    assert re_unescape(r'\\') == r'\\'
    assert re_unescape(r'\a\\') == r'a\\'
    assert re_unescape(r'\\\a') == r'\a'
    assert re_unescape(r'\\\\') == r'\\'
    assert re_unescape(r'\\a') == r'\\a'
    assert re_unescape(r'\\\a') == r'\\\a'

# Generated at 2022-06-24 09:27:32.555751
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict((('a', 1), ('b', 2), ('c', 3)))
    assert d.a == 1
    assert d.b == 2
    assert d.c == 3
    with pytest.raises(AttributeError):
        d.d
    with pytest.warns(DeprecationWarning):
        d.a = 4
    assert d.a == 4



# Generated at 2022-06-24 09:27:44.642417
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1)) == -1.0
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60.0
    assert timedelta_to_seconds(datetime.timedelta(minutes=-1)) == -60.0
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600.0
    assert timedelta_to_seconds(datetime.timedelta(hours=-1)) == -3600.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0

# Generated at 2022-06-24 09:27:55.289471
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    from typing import Callable
    from tornado.testing import AsyncTestCase
    from tornado.platform.asyncio import AsyncIOMainLoop

    class TestCase(AsyncTestCase):
        def test(self):
            async def test():
                await self.decompressor(self.decompress, self.data)
            AsyncIOMainLoop().install()
            self.run_until_complete(test())


# Generated at 2022-06-24 09:28:04.628037
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Try with one chunk
    gzip_decompressor = GzipDecompressor()
    assert gzip_decompressor.decompress(b'x\x9cK\xcb\xcf\x07\x00\x02\x04\x00\x00\x00\x04') == b'foo '
    assert gzip_decompressor.flush() == b'bar'
    assert gzip_decompressor.unconsumed_tail == b''

    # Try with two chunks
    gzip_decompressor = GzipDecompressor()
    assert gzip_decompressor.decompress(b'x\x9cK\xcb\xcf\x07\x00') == b''
    assert gzip_decompressor.flush() == b''

# Generated at 2022-06-24 09:28:13.552072
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return BaseImpl

        def initialize(self):
            pass

    class BaseImpl(Base):
        pass

    class SubBase(Base):
        def configurable_default(self):
            return SubBaseImpl

    class SubBaseImpl(SubBase):
        pass


# Generated at 2022-06-24 09:28:17.023612
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.b = 10
    assert a == {'b':10}
    assert a.b == 10

ObjectDict.__setattr__ = test_ObjectDict___setattr__


# Generated at 2022-06-24 09:28:24.896872
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError('')


# Types for typing.  (These are only used in typing, no runtime dependency.)
# Classes imported from other modules
if typing.TYPE_CHECKING:
    from typing import Dict  # noqa: F401
    from typing import List  # noqa: F401
    from typing import Type  # noqa: F401
    from typing import Union  # noqa: F401
    from typing import Callable  # noqa: F401
    from typing import Sequence  # noqa: F401
else:
    Type = object



# Generated at 2022-06-24 09:28:30.954937
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def inner_test(x):
        try:
            if x:
                raise ValueError(x)
            else:
                raise TypeError(x)
        except:
            raise_exc_info(sys.exc_info())

    inner_test(True)
    inner_test(False)
    success = False
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        success = True
    assert success



# Generated at 2022-06-24 09:28:39.836017
# Unit test for function re_unescape
def test_re_unescape():
    # Unescape test
    assert re_unescape("foo\\.bar") == "foo.bar"
    assert re_unescape("foo\\\\bar") == "foo\\bar"
    assert re_unescape("foo\\xFFbar") == "foo\xFFbar"
    assert re_unescape("foo\\\xFFbar") == "foo\\xFFbar"
    assert re_unescape("foo\\\uFFFfbar") == "foo\\\uFFFfbar"
    assert re_unescape("foo\\\U00010000bar") == "foo\\\U00010000bar"

    # Errors
    with pytest.raises(ValueError):
        re_unescape("foo\\dbar")
    with pytest.raises(ValueError):
        re_unescape("foo\\\dbar")


# Python 3

# Generated at 2022-06-24 09:28:50.546672
# Unit test for function re_unescape
def test_re_unescape():
    r"""Test function re_unescape"""
    if hasattr(re, "escape"):

        def check(s):
            # type: (str) -> None
            s2 = re.escape(s)
            s3 = re_unescape(s2)
            assert s3 == s

        check("foo")
        check("foo bar")
        check("foo\\bar")
        check("foo[bar]")
        check("foo.bar")
        check("foo?bar")
        check("foo*bar")
        check("foo+bar")
        check("foo|bar")
        check("foo(bar)")
        check("foo{bar}")
        check("foo$bar")
        check("foo^bar")
        check("foo\\bar")

    # Nasty cases

# Generated at 2022-06-24 09:28:58.055038
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(errno.ENOENT, os.strerror(errno.ENOENT))
    except OSError as e:
        assert e.errno == errno_from_exception(e)
        assert e.errno == e.args[0]
    try:
        raise OSError()
    except OSError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:29:00.924462
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a = ObjectDict()
    a.test = 'test'
    assert a.test == 'test'
test_ObjectDict___getattr__()

# Generated at 2022-06-24 09:29:08.084026
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise OSError()
    except OSError as e:
        assert errno_from_exception(e) is None

    try:
        raise OSError(42)
    except OSError as e:
        assert errno_from_exception(e) == 42



# Generated at 2022-06-24 09:29:11.035921
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-24 09:29:19.011067
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def __setattr__(self, name, value):
        self[name] = value
    assert __setattr__(ObjectDict(), 'name', 5) is None
    assert __setattr__(ObjectDict(), 5, 5) is None
    assert __setattr__(ObjectDict(), 5, 'name') is None
    assert __setattr__(ObjectDict(), 'name', 'name') is None
    assert __setattr__(ObjectDict(), 'name', 'name') is None
    assert __setattr__(ObjectDict(), 'name', 5) is None


# Generated at 2022-06-24 09:29:20.776078
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0



# Generated at 2022-06-24 09:29:22.107736
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 09:29:25.511155
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a, b, c):
        pass
    arg = ArgReplacer(foo, "a")
    args = [1]
    kwargs = {'b': 2, 'c':3}
    old_value = arg.get_old_value(args, kwargs)
    assert old_value == 1

# Generated at 2022-06-24 09:29:28.398531
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0



# Generated at 2022-06-24 09:29:39.103699
# Unit test for function import_object
def test_import_object():
    import tornado
    assert import_object('tornado') is tornado
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    # Do it again to make sure the cache doesn't affect results
    assert import_object('tornado') is tornado
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    # Invalid name
    try:
        import_object('tornado.missing_module')
        assert False, "expected exception"
    except ImportError:
        pass


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__"
# aren't

# Generated at 2022-06-24 09:29:42.189394
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.a = 4
    assert a.a == 4
    assert a["a"] == 4

# Generated at 2022-06-24 09:29:44.665076
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    TimeoutError("test")  # type: ignore



# Generated at 2022-06-24 09:29:52.653739
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"foo\\+bar\*baz") == "foo+bar*baz"
    assert re_unescape(r"\?\*\.\(\)\|\+\[\]\{\}\\") == "?*.()|+[]{}\\"
    with pytest.raises(ValueError):
        re_unescape(r"\d")
    with pytest.raises(ValueError):
        re_unescape(r"\r\n")
    with pytest.raises(ValueError):
        re_unescape(r"\Z")
    with pytest.raises(ValueError):
        re_unescape(r"\a")



# Generated at 2022-06-24 09:30:02.672345
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from concurrent.futures import ThreadPoolExecutor
    from tornado.concurrent import run_on_executor, Future

    class Executor(Configurable):
        @classmethod
        def configurable_base(cls):
            return Executor

        @classmethod
        def configurable_default(cls):
            return ThreadPoolExecutor

        @classmethod
        def configure(cls, impl, **kwargs):
            return super(Executor, cls).configure(impl, **kwargs)

        @run_on_executor
        def submit(self, func, *args, **kwargs):
            return ThreadPoolExecutor.submit(func, *args, **kwargs)

        def shutdown(self, wait=True):
            return ThreadPoolExecutor.shutdown(self, wait)

    executor = Executor()


# Generated at 2022-06-24 09:30:11.837212
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        def configurable_base(cls):
            return A

        def configurable_default(cls):
            return A1

    class A1:
        pass

    class A2:
        pass

    a = A()
    assert isinstance(a, A)
    assert isinstance(a, A1)
    assert not isinstance(a, A2)

    A.configure("tornado.util.A2")
    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, A1)
    assert isinstance(a, A2)



# Generated at 2022-06-24 09:30:19.533493
# Unit test for function errno_from_exception
def test_errno_from_exception():
    exc_example = Exception()
    exc_example.errno = 3
    errno = errno_from_exception(exc_example)
    assert errno == 3

    exc_example_2 = Exception(-1)
    errno_2 = errno_from_exception(exc_example_2)
    assert errno_2 == -1

    exc_example_3 = Exception()
    errno_3 = errno_from_exception(exc_example_3)
    assert errno_3 == None


# Generated at 2022-06-24 09:30:24.639738
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=2.5)) == 2.5 * 3600 * 24
    assert timedelta_to_seconds(datetime.timedelta()) == 0
    assert timedelta_to_seconds(datetime.timedelta(days=-2.5)) == -2.5 * 3600 * 24

# Generated at 2022-06-24 09:30:31.398228
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise ValueError
    except ValueError as e:
        assert errno_from_exception(e) is None

    try:
        raise ValueError(22)
    except ValueError as e:
        assert errno_from_exception(e) == 22

    try:
        e = ValueError()
        e.errno = 22  # type: ignore
        raise e
    except ValueError as e:
        assert errno_from_exception(e) == 22



# Generated at 2022-06-24 09:30:38.892605
# Unit test for function exec_in
def test_exec_in():
    globs = {"x": 1}
    locs = {}
    def fn(x: int) -> int:
        assert x == 1
        exec_in("assert x == 2", globs, locs)
        return x
    fn(2)
    def fn(x: int) -> int:
        assert x == 1
        exec_in("assert x == 2", globs)
        return x
    fn(2)



# Generated at 2022-06-24 09:30:44.378737
# Unit test for function import_object
def test_import_object():
    import sys
    import importlib
    import tornado

    # Reload the module to make sure it's not already loaded
    if 'tornado' in sys.modules:
        importlib.reload(tornado)

    assert import_object('tornado') is tornado
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert sys.modules['tornado'] is tornado



# Generated at 2022-06-24 09:30:49.078872
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(*(1, 2))
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-24 09:30:59.615669
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("aaa") == "aaa"
    assert re_unescape("aaa") == "aaa"
    assert re_unescape("\\.foo") == ".foo"
    assert re_unescape("\\\\\\.foo") == "\\.foo"
    assert re_unescape("\a\a\a") == "\\x07\\x07\\x07"

    with pytest.raises(ValueError):
        re_unescape("\\d")

    # Invalid escape sequences were removed from Python 3's re module,
    # but we still allow them for backward compatibility.
    assert re_unescape("\\") == "\\"
    assert re_unescape("\\8") == "\\8"
    assert re_unescape("\\9") == "\\9"

# Generated at 2022-06-24 09:31:07.444994
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    data = b"".join(
        [
            b"\x1f\x8b\x08\x08m\xf5O\x00\x03hello\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00",
            b"\x00",
        ]
    )
    decompressor = GzipDecompressor()
    assert decompressor.decompress(data) == b"hello"
    assert decompressor.unconsumed_tail == b""
    assert decompressor.flush() == b""



# Generated at 2022-06-24 09:31:17.894539
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        def initialize(self):
            pass

        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return BaseImpl

    class BaseImpl(Base):
        pass

    class Impl(BaseImpl):
        pass

    @class_property
    def global_configured_class(cls):
        return cls.configured_class()

    assert issubclass(Base(), Base)
    assert issubclass(BaseImpl(), Base)
    assert not issubclass(Base, BaseImpl)
    assert isinstance(Base(), Base)
    assert isinstance(BaseImpl(), Base)

    assert global_configured_class is BaseImpl
    assert not issubclass(global_configured_class, Impl)

    Base

# Generated at 2022-06-24 09:31:21.069523
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    if typing.TYPE_CHECKING:
        # Instances are not allowed to have attributes.
        def method(self: ObjectDict, name: str, value: Any) -> None: pass
        method(None, 'a', 'a')



# Generated at 2022-06-24 09:31:31.965279
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):  # type: ignore
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return A

        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A

        def initialize(self):
            # type: () -> None
            pass

    class B(A):
        def initialize(self):
            # type: () -> None
            pass

    class C(B):
        pass

    A.configure(B)
    assert isinstance(A(), B)
    assert isinstance(A(), A)
    assert not isinstance(A(), C)
    A.configure(None)
    assert isinstance(A(), A)
    A.configure(C)

# Generated at 2022-06-24 09:31:36.971408
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(*args,**kwargs):
        pass
    arg_replacer_obj = ArgReplacer(func,'name')
    assert arg_replacer_obj.get_old_value((1,2,3),{'name':'test'}) == 'test'
    assert arg_replacer_obj.get_old_value((1,2,3),{}) == None


# Generated at 2022-06-24 09:31:45.511430
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    m = GzipDecompressor()
    
    s = b'5'
    assert m.decompress(s) == b''
    
    s = b'5'
    assert m.unconsumed_tail == b'5'
    
    m = GzipDecompressor()
    s = b'a' * 1000
    assert m.decompress(s) == b''
    
    s = b'b' * 1000
    assert m.unconsumed_tail == (b'a' * 1000) + (b'b' * 1000)


# Generated at 2022-06-24 09:31:52.525813
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    with open("test/test_gzip.gz", "rb") as gz:
        data = gz.read()
        gz.seek(0)
        gz = GzipDecompressor()
        max_chunks = 10
        while True:
            chunk = gz.decompress(data, 1000)
            if chunk:
                assert max_chunks > 0
                max_chunks -= 1
            else:
                break
    assert gz.unconsumed_tail == b""
    assert gz.flush() == b""


# Generated at 2022-06-24 09:32:01.679451
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    data = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6d\x6f\xdb\x36\x10\xfd' \
        b'\xef\x7b\x7d\xaf\x02\x00\xa0\xce\x4f\x4d\x05\x00\x00\x00'
    out = decompressor.decompress(data)
    assert out == b'hello'
    out = decompressor.flush()
    assert out == b''


# Generated at 2022-06-24 09:32:03.214809
# Unit test for function exec_in
def test_exec_in():
    def test_dict_type():
        assert type(exec_in("x, y=1, 2", {})) == dict
        assert exec_in("1", {}) == 1
    assert test_dict_type() == None



# Generated at 2022-06-24 09:32:12.053091
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():

    class f:
        """Our test function with a few different signatures."""

        def __init__(self, arg1: int, arg2: str = None, arg3: Any = None) -> None:
            pass

    # Test for arg2
    ar = ArgReplacer(f, "arg2")
    (ov, a, k) = ar.replace(2, (1,), {})
    assert ov is None
    assert a == (1,)
    assert "arg2" in k
    assert k["arg2"] == 2
    (ov, a, k) = ar.replace(2, (1, "old"), {})
    assert ov == "old"
    assert a == (1, 2)
    assert "arg2" not in k

# Generated at 2022-06-24 09:32:15.655449
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    compressed = b'1a'
    max_length = 0
    decompressed = decompressor.decompress(compressed, max_length)
    assert decompressed == b'1a'

# Generated at 2022-06-24 09:32:26.833928
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class MyBase(Configurable):
        @classmethod
        def configurable_base(self):
            # type: () -> Type[MyBase]
            return MyBase

        @classmethod
        def configurable_default(self):
            # type: () -> Type[MyBase]
            return MyBaseImpl

        def _initialize(self):
            pass

        pass

    class MyBaseImpl(MyBase):
        pass

    class MySubBase1(MyBase):
        pass

    class MySubBase2(MySubBase1):
        pass

    class MySubImpl1(MySubBase1):
        pass

    # MyBase and MySubBase1 are configurable
    assert isinstance(MyBase(), Configurable)
    assert isinstance(MySubBase1(), Configurable)

# Generated at 2022-06-24 09:32:28.203087
# Unit test for function exec_in
def test_exec_in():
    exec_in("1", None)



# Generated at 2022-06-24 09:32:37.356983
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=30)) == 30
    assert timedelta_to_seconds(datetime.timedelta(seconds=60)) == 60
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(days=3)) == 259200
    assert timedelta_to_seconds(datetime.timedelta(days=30)) == 2592000
    assert timedelta_to_seconds(datetime.timedelta(days=365)) == 31536000