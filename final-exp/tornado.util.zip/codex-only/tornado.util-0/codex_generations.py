

# Generated at 2022-06-24 09:22:42.454407
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    compressed = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6c\x6c+\xcf\xcfL\x2b\xc9\x4c\x4f\x4f\xe4\x02\x00\x9d\x1c\x93\x13\x00\x00\x00"
    decompressor = GzipDecompressor()
    assert b"hello world" == decompressor.decompress(compressed)
    assert b"" == decompressor.flush()
    # Check that it works with the .z attribute
    assert b"hello world" == zlib.decompress(compressed, 16 + zlib.MAX_WBITS)

# Shortcut since this is used so often


# Generated at 2022-06-24 09:22:50.601236
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(hours=1) + datetime.timedelta(
        microseconds=1
    )) == 3600 + 1e-06
test_timedelta_to_seconds()

# Do a best-effort import of the standard library version, which was
# introduced in python 2.7, and will always be present in python 3.
try:
    from datetime import timedelta

    if hasattr(timedelta, "total_seconds"):
        # type: ignore
        timedelta_to_seconds = timedelta.total_seconds  # type: ignore
except ImportError:
    pass



# Generated at 2022-06-24 09:22:57.966849
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls): return A

        @classmethod
        def configurable_default(cls): return B

        def initialize(self, x: int, y: int = 1):
            self.x = x
            self.y = y

        def __init__(self, *args: Any, **kwargs: Any) -> None:
            raise NotImplementedError("use initialize")

    class B(Configurable):
        @classmethod
        def configurable_base(cls): return B

        @classmethod
        def configurable_default(cls): return A

        def initialize(self, x: int, y: int = 2):
            self.x = x
            self.y = y


# Generated at 2022-06-24 09:23:00.073895
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict()
    x.hello = "world"
    assert x["hello"] == "world"



# Generated at 2022-06-24 09:23:02.635221
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    assert isinstance(d, dict)
    assert isinstance(d, ObjectDict)



# Generated at 2022-06-24 09:23:08.940584
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception(*(1, 2))
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-24 09:23:12.714975
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=2, microseconds=3)) == 86401.000003


# Generated at 2022-06-24 09:23:16.565844
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from tornado.test.util import unittest

    suite = doctests()
    if not suite.countTestCases():
        raise unittest.SkipTest("no doctests found")
    unittest.TextTestRunner().run(suite)

# Stub for humanize_duration to allow building the documentation when
# the i18n extensions are not compiled.

# Generated at 2022-06-24 09:23:19.889467
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(1)
    except Exception as e:
        assert e.errno == 1
        assert errno_from_exception(e) == 1


_DEFAULT = object()

# Mapping of HTTP status codes to phrases



# Generated at 2022-06-24 09:23:22.001896
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=1)
    assert d.a == 1
    d.b = 2
    assert d['b'] == 2



# Generated at 2022-06-24 09:23:29.314433
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(22, "errno_from_exception")
    except Exception as e:
        assert errno_from_exception(e) == 22

    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:23:31.265188
# Unit test for function exec_in
def test_exec_in():
    exec_in("x = 6", {"x": 3})
    assert x == 6



# Generated at 2022-06-24 09:23:40.885754
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    trg = GzipDecompressor()
    res = trg.flush()
    assert res is None, f'Expected:{None}, Actual:{res}'

    # ~ trg = GzipDecompressor()
    # ~ trg.decompressobj = zlib.decompressobj()
    # ~ res = trg.flush()
    # ~ assert res is None, f'Expected:{None}, Actual:{res}'


# These constants are no longer defined in zlib; they are only used as
# arguments to decompressobj, which is passed a magic value instead
# that is interpreted as an argument to the zlib library.
ZLIB_DEFLATED = -15
MAX_WBITS = 15

# Generated at 2022-06-24 09:23:50.184193
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"abc\d") == "abc\d"
    assert re_unescape(r"abc\x00xyz") == "abc\u0000xyz"
    assert re_unescape(r"abc\\xyz") == "abc\\xyz"
    assert re_unescape(r"abc\&\*") == "abc&*"
    assert re_unescape(r"abc\xFF") == "abc\u00ff"
    assert re_unescape(r"\*") == "*"
    assert re_unescape(r"\\d") == "\\d"
    assert re_unescape(r"\\\d") == "\\\\d"
    assert re_unescape(r"\\\\\d") == "\\\\\\d"
    assert re_unescape(r"\7")

# Generated at 2022-06-24 09:23:56.124200
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = dict(a=1)
    y = ObjectDict(a=1)

# Make sure both names are available
TimeoutError = TimeoutError
tornado.gen.TimeoutError = TimeoutError

# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).
u = lambda s: s



# Generated at 2022-06-24 09:24:05.229827
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()
    TimeoutError(1)


# Alias for compatibility with tornado.gen.TimeoutError.
Timeout = TimeoutError

# Alias for compatibility with tornado.ioloop.TimeoutError.
IOLoopTimeoutError = TimeoutError

# Note: with_metaclass is a Six feature, but we don't use it in
# Python 3 code and we only use it in a few places in Python 2 code.
# This lets us avoid the dependency on Six.
_PY3 = sys.version_info[0] == 3

if _PY3:
    import io
    import urllib.parse as _urlparse
    import urllib.request as _urlrequest
    import urllib.response as _urlresponse
    import urllib.error as _urlerror
    import socketserver
    import _thread

# Generated at 2022-06-24 09:24:15.984105
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class C(Configurable):
        pass
    class D(C):
        pass
    class E(C):
        pass
    class F(D):
        pass

    C.configure("tornado.test.C")

# Generated at 2022-06-24 09:24:20.417177
# Unit test for function exec_in
def test_exec_in():
    ns = {'x': 1}
    exec_in('assert x == 1', ns)
    exec_in('x = 2', ns)
    assert ns['x'] == 2



# Generated at 2022-06-24 09:24:22.004712
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a = ObjectDict()
    a["d"] = 1
    assert a.d == 1


# Generated at 2022-06-24 09:24:26.745786
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0

    assert timedelta_to_seconds(datetime.timedelta(seconds=1, minutes=2, hours=3, days=4)) == 290561.0

    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001



# Generated at 2022-06-24 09:24:30.256328
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b):
        return a + b
    arg_replacer = ArgReplacer(func, 'a')
    assert arg_replacer.get_old_value((1,2),{}) == 1
    assert arg_replacer.get_old_value((1,2,3),{},4) == 1
    assert arg_replacer.get_old_value((1,),{'a':2}) == 2

# Generated at 2022-06-24 09:24:35.082181
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    # A test function to check if a class is templated with a particular type
    # Use @typing_extensions.runtime to check
    obj = ObjectDict()
    obj['a'] = 1
    1 == obj['a']
    obj.a = 2
    2 == obj['a']
    obj.a = obj
    obj == obj.a
    obj.b = obj
    obj == obj.b


# Generated at 2022-06-24 09:24:41.458570
# Unit test for function exec_in
def test_exec_in():
    exec_in("a = 123", {})  # type: ignore
    exec_in("a = 123", {}, {})
    exec_in("a = 123", {}, dict(a=1))
    exec_in("a = 123", {}, dict(a=1))
    exec_in("b = 123", {})  # type: ignore
    exec_in("b = 123", {}, dict(b=1))



# Generated at 2022-06-24 09:24:52.288356
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is a copy of a valid gzip file
    value = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xed\xbd\x07\x60\x18\x05\xb8\x0e\xf1\x77\x08\x03\x80\x88\xf2\x02\x00\xd1\x05\x0f\x00\x00\x00'
    d = GzipDecompressor()
    result = d.decompress(value)
    assert result == b"hello"
    assert d.flush() == b""
    assert d.unconsumed_tail == b""



# Generated at 2022-06-24 09:25:00.186934
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b=None):
        pass
    a = ArgReplacer(f, 'a')
    old_value, args, kwargs = a.replace(0, (), {'a':1})
    assert old_value == 1
    assert args == ()
    assert kwargs == {'a':0}
    old_value, args, kwargs = a.replace(0, (1,), {})
    assert old_value == 1
    assert args == (0,)
    assert kwargs == {}



# Generated at 2022-06-24 09:25:03.685905
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=2, seconds=60)) == 172860



# Generated at 2022-06-24 09:25:12.293825
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ChildConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return ChildConfigurable
        @classmethod
        def configurable_default(cls):
            return ChildConfigurable
        def initialize(self, arg1, arg2, arg3, kwarg1=None, kwarg2=None, kwarg3=None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.kwarg1 = kwarg1
            self.kwarg2 = kwarg2
            self.kwarg3 = kwarg3
    ChildConfigurable.configure(None, kwarg1='kwarg_default1', kwarg2='kwarg_default2')

# Generated at 2022-06-24 09:25:16.398815
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError()
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 0

    try:
        raise IOError(3)
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 3



# Generated at 2022-06-24 09:25:24.997385
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import types

    import nose.tools as nt

    class  Base(Configurable):
        def configurable_base(cls):
            return Base

        def configurable_default(cls):
            pass

        def initialize(self):
            pass

    class Sub1(Base):
        pass

    class Sub2(Base):
        pass

    def do_test(cls, *args, **kwargs):
        nt.ok_(isinstance(cls(*args, **kwargs), cls))

    do_test(Base)
    do_test(Sub1)
    do_test(Sub2)

    Base.configure(Sub1)
    do_test(Base)
    do_test(Sub1)
    do_test(Sub2)

    Base.configure(Sub2)

# Generated at 2022-06-24 09:25:32.473458
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(100)
    except Exception as e:
        assert errno_from_exception(e) == 100

    try:
        exc = Exception()
        exc.errno = 101
        raise exc
    except Exception as e:
        assert errno_from_exception(e) == 101

    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:25:43.483163
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    # test that the configurable class is initialized properly
    class Base(config_class(Configurable)):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Default

        def initialize(self):
            pass

    class Default(Base):
        pass

    class Impl1(Base):
        pass

    class Impl2(Base):
        pass

    # Use the abstract base class on its own and make sure we get the
    # default implementation.
    i = Base()
    assert isinstance(i, Default)

    # Configure the class to use a different implementation
    Base.configure(Impl1)
    i = Base()
    assert isinstance(i, Impl1)

    # Configure the class

# Generated at 2022-06-24 09:25:52.821520
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception("a")
    except Exception as e:
        assert errno_from_exception(e) == "a"

    try:
        raise Exception("a", 1)
    except Exception as e:
        assert errno_from_exception(e) == "a"

    try:
        raise Exception("a", 1, "b")
    except Exception as e:
        assert errno_from_exception(e) == "a"


# Generated at 2022-06-24 09:26:01.479168
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> inlineCallbacks
    from .testing import gen_test
    d = ObjectDict()
    d['x'] = 42
    d.y = 43
    assert d.x == 42
    assert d['y'] == 43
    with pytest.raises(AttributeError):
        d.z
    @gen_test
    def getattr_async():
        # type: () -> Coroutine[Any, Any, None]
        with pytest.raises(RuntimeError):
            yield d.x
    yield getattr_async()


# class ObjectDictAliases:
#     """Makes a dictionary behave like an object, with attribute-style access.
#     """

#     @classmethod
#     def __getattr__(self, name: str) -> Any:
#         try:
#            

# Generated at 2022-06-24 09:26:09.259549
# Unit test for function import_object
def test_import_object():
    import types
    import datetime
    assert import_object("types") is types
    assert import_object("datetime") is datetime
    assert import_object("datetime.datetime") is datetime.datetime
    try:
        import_object("missing_module.missing_attr")
        assert False, "import_object should fail with missing module/attribute"
    except ImportError:
        pass

_FileNotFoundError = getattr(__import__("os"), "FileNotFoundError", IOError)

_DEFAULT_UPSTREAM_TIMEOUT = 30.0



# Generated at 2022-06-24 09:26:12.007268
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.k = 1
    assert a.k == 1
#
#

# Generated at 2022-06-24 09:26:16.588714
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict({"a": 1})
    assert d.a == 1
    assert d["a"] == 1
    try:
        d.b
        assert False, "should have raised"
    except AttributeError:
        pass
    try:
        d.b = 2
        assert False, "should have raised"
    except KeyError:
        pass



# Generated at 2022-06-24 09:26:27.340306
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    args = [1, 2, 3]
    kwargs = {'one':1, 'two':2}
    names = ('a', 'b', 'c')
    def f(*args):
        return args[0], args[-1]
    def f2(*args, **kwargs):
        return kwargs.get('one'), kwargs.get('two')    
    
    new_value = 4
    
    old_value, args, kwargs = ArgReplacer(f, 'a').replace(new_value, args, kwargs)
    
    assert old_value == 1
    assert args == [4, 2, 3]
    assert kwargs == {'one':1, 'two':2}    
    

# Generated at 2022-06-24 09:26:29.331689
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    pair = ("a", 1)
    pairs = (pair, ("b", 2))
    d = ObjectDict(pairs)
    assert d.a == 1 and d.b == 2
    for (k, v) in pairs:
        assert d[k] == v



# Generated at 2022-06-24 09:26:37.222052
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # There is an inconsistency in how zlib handles flush().  If flush() is
    # called when there is no pending input or output, the zlib module raises
    # a zlib.error, while if flush() is called when there is pending input but
    # no pending output, it returns b"".  GzipDecompressor.flush() should also
    # return an empty bytes object in the latter case.
    o = GzipDecompressor()
    data = b"x" * 1000 + b"YZ"
    assert b"YZ" == o.flush() + o.decompress(data)
GzipDecompressor.flush.__test__ = False  # type: ignore



# Generated at 2022-06-24 09:26:43.574466
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    o = ObjectDict(a=1)
    o.b = 2
    assert o.a == 1
    assert o.b == 2
    assert o["a"] == 1
    assert o["b"] == 2
    assert "a" in o
    assert "c" not in o
    del o.b
    assert "b" not in o
    o.a = 3
    assert o.a == 3



# Generated at 2022-06-24 09:26:48.585503
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f1(a):
        pass

    assert ArgReplacer(f1, 'a').replace(7, (), {})[0] is None
    assert ArgReplacer(f1, 'a').replace(7, (1,), {})[0] == 1
    assert ArgReplacer(f1, 'a').replace(7, (), {'a': 2})[0] == 2
    assert ArgReplacer(f1, 'a').replace(7, (1,), {'a': 2})[0] == 1

    def f2(a, *args):
        pass

    assert ArgReplacer(f2, 'a').replace(7, (), {})[0] is None
    assert ArgReplacer(f2, 'a').replace(7, (1,), {})[0] == 1

# Generated at 2022-06-24 09:26:54.897305
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # pylint: disable=missing-docstring,too-few-public-methods
    class Dummy(Configurable):
        @classmethod
        def configurable_base(cls):
            return Dummy

        @classmethod
        def configurable_default(cls):
            return Dummy

    class N(Dummy):
        def _initialize(self):
            pass

    N().initialize()


# This is used to store the current AsyncIOMainLoop implementation.  We
# keep the reference here to avoid circular imports between
# asyncio_events.py and ioloop.py
_current_io_loop_impl = None  # type: Optional[Type[Configurable]]

if hasattr(select, "epoll"):
    from tornado.platform.epoll import EPollIOLoop
    _current_

# Generated at 2022-06-24 09:26:59.319128
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c=None):
        return a, b, c

    arg_replacer = ArgReplacer(foo, "b")
    old_value, args, kwargs = arg_replacer.replace("new_value", ("a", "b", "c"), {})
    assert (old_value, args, kwargs) == ("b", ("a", "new_value", "c"), {})

    old_value, args, kwargs = arg_replacer.replace("new_value", ("a",), {})
    assert (old_value, args, kwargs) == (None, ("a",), {"b": "new_value"})



# Generated at 2022-06-24 09:27:04.706490
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c=None, d=None):
        pass

    ra = ArgReplacer(func, "a")
    rb = ArgReplacer(func, "b")
    rc = ArgReplacer(func, "c")
    rd = ArgReplacer(func, "d")

    def test(func_name, *args, **kwargs):
        func = locals()[func_name]
        for r in (ra, rb, rc, rd):
            old, args, kwargs = r.replace(r.name, args, kwargs)
            assert old is None, (func_name, r.name, old, args, kwargs)
            old = r.get_old_value(args, kwargs)

# Generated at 2022-06-24 09:27:13.075195
# Unit test for function exec_in
def test_exec_in():
    test_globals = {}
    test_locals = {}
    exec_in("x = 6", test_globals, test_locals)
    exec_in("x = 7; y = 8", test_globals, test_locals)
    assert test_locals['x'] == 7 and test_locals['y'] == 8
    assert test_locals is not test_globals  # another sanity check


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__"
# aren't compatible with "from __future__ import unicode_literals".
# u() can be applied to ascii strings that include \u escapes (but they
# must not contain literal non-ascii characters).

# Generated at 2022-06-24 09:27:18.618052
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(OSError(1)) == 1
    assert errno_from_exception(Exception()) is None
    assert errno_from_exception(Exception(1)) == 1
    assert errno_from_exception(Exception(1, 2)) == 1



# Generated at 2022-06-24 09:27:28.770619
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gd = GzipDecompressor()
    print('test_GzipDecompressor_decompress')

# Generated at 2022-06-24 09:27:33.391980
# Unit test for function raise_exc_info
def test_raise_exc_info():
    class Exc(Exception):
        pass
    try:
        raise Exc
    except:
        # This is unusual, but raise_exc_info is also used in
        # error handlers in user code, which could get the
        # exc_info quadruple.
        raise_exc_info((None, None, None))
        raise_exc_info((None, None, None))
        raise_exc_info((None, Exc(), None))
    try:
        raise_exc_info((None, None, None))
        assert False
    except:
        pass



# Generated at 2022-06-24 09:27:44.642709
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    g = GzipDecompressor()
    g.decompress(b'\x1f\x8b')  # gzip header
    ret = g.decompress(b'\x08\x00\x03\xad\xcf\x7b\x07\x00\x02\xab\x4e\x6d')
    assert ret == b'yow!'
    assert g.decompress(b'') == b''
    assert g.decompress(b'\x00\x00\xff\xff') == b''
    assert g.decompress(b'\x03\x00\x04\x00\x00\x00\x00\x00') == b'\x00\x00\x00\x00'
    # no more data
    assert g.flush

# Generated at 2022-06-24 09:27:54.976244
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def test_ObjectDict___setattr___impl(d: ObjectDict) -> None:
        d.x = 1
    objDict1 = ObjectDict({'a': 1, 'b': 2})
    test_ObjectDict___setattr___impl(objDict1)


# Dict alias used for compatibility with external extensions.
# See tornado.util for the previous version of this file.
_Dict = Dict

# Dict aliases used for compatibility with external extensions.
# See tornado.util for the previous version of this file.
_Xheaders = Dict[str, Any]

# Dict alias used for compatibility with external extensions.
# See tornado.util for the previous version of this file.
_HTTPHeaders = Dict[str, str]



# Generated at 2022-06-24 09:28:01.956679
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    decompressor = GzipDecompressor()
    with open("/tmp/test.gz", "rb") as f:
        # Read by block, keep in mind some of the data maybe left
        # in "unconsumed_tail"
        while True:
            block = f.read(1024)
            if not block:
                break
            data = decompressor.decompress(block)
            # Process data
            pass
        data = decompressor.flush()
        # Process data
        pass



# Generated at 2022-06-24 09:28:11.016211
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    c = GzipDecompressor()
    compressed = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00u\x8aM\xccJ\xc9K\xd1\xfb\x9f\x02\x00\xef\x8f\x13\x11\x00\x00\x00'
    assert c.decompress(compressed) == b"hello world"
    assert c.decompress(b"") == b""
    assert c.unconsumed_tail == b""
    assert c.flush() == b""


# Generated at 2022-06-24 09:28:15.826764
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    # This function's type annotation must use comments instead of
    # real annotations because typing.NoReturn does not exist in
    # python 3.5's typing module. The formatting is funky because this
    # is apparently what flake8 wants.
    def f():
        # type: () -> typing.NoReturn
        raise ValueError()

    try:
        f()
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)



# Generated at 2022-06-24 09:28:18.129535
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    """Test method __setattr__ of class ObjectDict."""
    o = ObjectDict()
    o.a = 1  # type: ignore



# Generated at 2022-06-24 09:28:19.943547
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo1(a,b,c):
        pass
    ar = ArgReplacer(foo1,'b')
    print(ar.replace(100, [1,2,3], {"a":4,"b":5}))



# Generated at 2022-06-24 09:28:25.189085
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    f = timedelta_to_seconds
    assert f(datetime.timedelta(seconds=1)) == 1
    assert f(datetime.timedelta(seconds=1.5)) == 1.5
    assert f(datetime.timedelta(days=1, seconds=2, microseconds=3000)) == 86400 + 2 + 3e-6



# Generated at 2022-06-24 09:28:29.794093
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class My_Base_Class(Configurable):
        def configurable_base(cls):
            return cls
        def configurable_default(cls):
            return cls
    class Test_Class(My_Base_Class):
        def initialize(self):
            pass
    My_Base_Class.configure(Test_Class)

# Generated at 2022-06-24 09:28:33.207740
# Unit test for function exec_in
def test_exec_in():
    # type: () -> None
    x = object()
    loc = {"x": None}
    exec_in("x = y", {"y": x}, loc)
    assert loc["x"] is x
    assert "x" not in globals()



# Generated at 2022-06-24 09:28:41.183750
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():  # pragma: no cover
    # example taken from http://stackoverflow.com/questions/1838699/how-can-i-decompress-a-gzip-stream-with-zlib
    # This example is a http response, we only test the head information.
    data = (
        b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
        b'\x4a\xcd\x0c\x2f\xcc\x49\x51\x08\xcf\x2f\xca\x49\x51\x04\x00'
        b'\xe7\x02\x00\x00\x00'
    )
    c = GzipDecompressor()
    assert c.dec

# Generated at 2022-06-24 09:28:51.800813
# Unit test for function import_object
def test_import_object():
    from tornado.escape import native_str
    from tornado.escape import utf8
    # import_object should import the top-level module.
    assert import_object('os') is os
    # import_object should import modules from the top-level module
    assert import_object('os.path') is os.path
    assert import_object('os.path.join') is os.path.join    
    # import_object should import objects from the top-level module
    assert import_object('tornado.escape.native_str') is native_str
    assert import_object('tornado.escape.utf8') is utf8
    # import_object should raise an ImportError when the object cannot be found
    try:
        import_object('tornado.escape.no_such_object')
        assert False
    except ImportError:
        pass

# Generated at 2022-06-24 09:28:57.926531
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    f = GzipDecompressor()
    print("GzipDecompressor test begin!")
    # 准备编码的数据
    a = "我的测试数据我的测试数据我的测试数据我的测试数据我的测试数据我的测试数据我的测试数据我的测试数据我的测试数据我的测试数据我的测试数据我的测试数据"
    # test,

# Generated at 2022-06-24 09:29:07.887422
# Unit test for constructor of class Configurable
def test_Configurable():
    class Dummy(Configurable):
        def __init__(self, name=None, **kwargs):
            if name is None:
                raise Exception("__init__ should not be called directly")
            self.name = name
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return Dummy

        @classmethod
        def configurable_default(cls):
            return DummyImpl

    class DummyImpl(Dummy):
        def initialize(self):
            pass

    class SubDummy(Dummy):
        @classmethod
        def configurable_default(cls):
            return SubDummyImpl

    class SubDummyImpl(DummyImpl):
        pass

    assert issubclass(SubDummy, Dummy), SubDummy

# Generated at 2022-06-24 09:29:12.273160
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    decompressor = GzipDecompressor()
    decompressor.decompress(b"\x78\x9c\x03\x00\x00\x00\x00\x01")
    decompressor.flush()



# Generated at 2022-06-24 09:29:14.769935
# Unit test for function doctests
def test_doctests():
    import doctest

    failure_count, test_count = doctest.testmod()
    assert test_count > 0
    assert failure_count == 0


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-24 09:29:23.522294
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c=3, d=4):
        pass

    r = ArgReplacer(func, "c")
    assert r.get_old_value(tuple(), {}) == 3
    assert r.get_old_value(tuple(), {}, None) is None
    assert r.get_old_value((1, 2), {}) == 3
    assert r.get_old_value((1, 2, 5), {}) == 5
    assert r.get_old_value((1, 2), {"c": 6}) == 6
    assert r.get_old_value((1, 2, 5), {"c": 6}) == 5

    # when replacing a positional arg, the original args tuple
    # should be copied to a list so it can be modified
    args = (1, 2, 5)
    _, args

# Generated at 2022-06-24 09:29:35.902522
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest.mock

    def mock_configurable_class(
        configurable_base_closure, configurable_default, initialize
    ):
        class _Configurable(Configurable):
            @classmethod
            def configurable_base(cls):
                return configurable_base_closure()

            @classmethod
            def configurable_default(cls):
                return configurable_default

            initialize = initialize

        return _Configurable

    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # Default case
    TestConfigurable

# Generated at 2022-06-24 09:29:47.369867
# Unit test for function exec_in
def test_exec_in():
    glob = {'foo': 1}
    loc = {'bar': 2}
    exec_in("assert foo == 1; assert bar == 2", glob, loc)
    exec_in('result = foo + bar; assert locals()["result"] == 3', glob, loc)
    assert 'result' not in glob
    try:
        exec_in('assert False', glob, loc)
        assert False
    except AssertionError:
        pass
    try:
        exec_in('assert bar == 2; assert False', glob, loc)
        assert False
    except AssertionError:
        pass
    try:
        exec_in('raise ValueError("xyz")', glob, loc)
        assert False
    except ValueError as e:
        assert str(e) == "xyz"
    else:
        assert False


#

# Generated at 2022-06-24 09:29:53.519971
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    raw_val = b"Uncompressed"
    compressed_val = zlib.compress(raw_val)
    decompressed_val = zlib.decompress(compressed_val)
    gz = GzipDecompressor()
    decompressed_val_ = gz.decompress(compressed_val)
    assert decompressed_val ==decompressed_val_


# Generated at 2022-06-24 09:30:02.009489
# Unit test for function exec_in
def test_exec_in():
    g = {'foo': 1}
    l = {'bar': 2}
    exec_in('foo = bar', g, l)
    assert g['foo'] == 2
    exec_in('baz = 1', g)
    assert g['baz'] == 1
    exec_in('baz = 2', None, l)
    assert l['baz'] == 2
    exec_in('baz = 3')
    assert g['baz'] == 1
    assert l['baz'] == 2
    try:
        exec_in('foo()', g, l)
        assert False, 'should not reach here'
    except NameError:
        pass



# Generated at 2022-06-24 09:30:07.130000
# Unit test for function exec_in
def test_exec_in():
    def test_function():
        pass
    _globals = dict(a=1, test_function=test_function)
    exec_in("b = a + 1", _globals)
    assert _globals["b"] == 2
    test_function()



# Generated at 2022-06-24 09:30:15.464987
# Unit test for function exec_in
def test_exec_in():
    globals = {'foo': 'bar'}
    locals = {'bar': 'baz'}
    exec_in('foo = baz', globals, locals)
    assert globals['foo'] == 'bar'
    assert locals['foo'] == 'baz'
    exec_in('bar = foo', globals, locals)
    assert locals['bar'] == 'baz'
    assert globals['bar'] == 'foo'
    exec_in('bar = quux', globals, locals)
    assert locals['bar'] == 'quux'
    exec_in('def foo(bar=bar): return bar', globals, locals)
    assert locals['foo']('baz') == 'quux'
    locals['bar'] = 'baz'
    exec_in('foobar = foo', globals, locals)

# Generated at 2022-06-24 09:30:25.814849
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    d = GzipDecompressor()
    def decompressed_data(s: bytes) -> bytes:
        return d.decompress(s) + d.flush()
    assert decompressed_data(b"x\x9cK\xcb\xcf\x07\x00\x02\x82\x01\n") == b"asdfqwer"
    # partial decompression of the above
    assert decompressed_data(b"x\x9cK\xcb") == b""
    assert decompressed_data(b"\xcf\x07\x00\x02\x82\x01\n") == b"asdfqwer"
    # test flush() with no argument
    d = GzipDecompressor()

# Generated at 2022-06-24 09:30:27.817375
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 09:30:30.244301
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    dec = GzipDecompressor()
    test_string = 'hello'
    compress_data = zlib.compress(test_string.encode())
    decompress_data = dec.decompress(compress_data)
    assert decompress_data == test_string.encode()



# Generated at 2022-06-24 09:30:31.956460
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d1 = ObjectDict(foo=1, bar=1)
    assert d1.foo == d1['foo']
    d1.foo = 2
    assert d1.foo == 2



# Generated at 2022-06-24 09:30:39.901867
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise TypeError("Test exc")
    except:
        exc_info = sys.exc_info()
    with pytest.raises(TypeError, match="Test exc"):
        raise_exc_info(exc_info)


# Wrap a file-like object with a reader that decompresses gzip data
# when read. If the file-like object is compressed with the "gzip"
# module, the uncompressed data will be available in the "unused_data"
# attribute.

# Generated at 2022-06-24 09:30:41.624211
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod(verbose=False)

# Generated at 2022-06-24 09:30:49.369707
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    import sys

    def t(a, b, c=None, d=None):
        pass

    t(1, 2, d=4)
    r = ArgReplacer(t, "d")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((), {"d": 1}) == 1
    assert r.get_old_value((1, 2), {"d": 4}) == 4
    assert r.replace(5, (1, 2), {"d": 4}) == (4, (1, 2), {"d": 5})
    assert r.replace(5, (1, 2, None, None), {}) == (None, (1, 2, None, 5), {})

# Generated at 2022-06-24 09:30:59.726634
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is the full sequence from the docs
    decompressor = GzipDecompressor()

    first = decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff')
    assert first == b''
    second = decompressor.decompress(b'\x06\x00BC\x02\xff\x8b\x00\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1b\x04\x8e\xa0\x0f\x00\x00\x00')
    assert second == b'hello'
    third = decompressor.flush()
    assert third == b', world!\n'
    assert decompressor.uncons

# Generated at 2022-06-24 09:31:10.942223
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    test = GzipDecompressor()
    with open('/home/lxg/codedata/python/tornado-4.2.1/tornado-4.2.1/tornado/test/test_util.py', 'rb') as f:
        test_data = f.read()
    test_data_gzipped = zlib.compress(test_data)
    #print(test.decompress(test_data))
    #print(test_data)
    #print(test_data_gzipped)
    #print(test.decompress(test_data_gzipped))
    assert test.decompress(test_data) == test_data
    assert test.decompress(test_data_gzipped) == test_data
    assert test.decompress(test_data_gzipped, 1000)

# Generated at 2022-06-24 09:31:15.617116
# Unit test for function raise_exc_info
def test_raise_exc_info():

    class MyException(Exception):
        pass

    def f():
        raise MyException()

    try:
        f()
    except MyException:
        typ, value, tb = sys.exc_info()
        assert isinstance(value, MyException)
        raise_exc_info(exc_info())
    return True



# Generated at 2022-06-24 09:31:22.997066
# Unit test for function raise_exc_info
def test_raise_exc_info():  # pragma: no cover
    from unittest import TestCase, main

    class A(Exception):
        pass

    class B(Exception):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(object):
        def __init__(self, msg):
            self.msg = msg

        def __str__(self):
            return self.msg

    class TestCase(TestCase):
        def test_raise_exc_info(self):
            # check raise_exc_info with a variety of exception types
            # and methods of raising them
            try:
                raise A()
            except:
                raise_exc_info(sys.exc_info())

            try:
                raise A()
            except:
                x = sys.exc_info()
            raise_exc

# Generated at 2022-06-24 09:31:30.342628
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(1, "No file")
        assert False
    except OSError as e:
        assert errno_from_exception(e) == 1
    try:
        raise e
        assert False
    except Exception as ex:
        assert errno_from_exception(ex) == 1
    try:
        raise OSError()
        assert False
    except OSError as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(2, "No file")
        assert False
    except IOError as e:
        assert errno_from_exception(e) == 2
    try:
        raise e
        assert False
    except Exception as ex:
        assert errno_from_exception(ex) == 2


# Generated at 2022-06-24 09:31:33.256626
# Unit test for function exec_in
def test_exec_in():
    a = object()
    b = object()
    g = {'a': a}
    exec_in("assert a is b", g, g)
    exec_in("assert a is not b", g)



# Generated at 2022-06-24 09:31:44.007145
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None

    class C(Configurable):
        pass

    assert C.configured_class() is C
    assert C.configurable_base() is C
    assert C.configurable_default() is C
    assert None is C.configurable_base().__impl_class
    assert {} == C.configurable_base().__impl_kwargs

    with patch("warnings.warn") as warn:
        C.configure("x.y.z")
        warn.assert_called_with("Implicitly replacing C with x.y.z")
        assert "x.y.z" == C.configurable_base().__impl_class

    with patch("warnings.warn") as warn:
        C.configure("x.y.z", spam="eggs")

# Generated at 2022-06-24 09:31:48.796907
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\a\b\f\n\r\t\v\\\*\?\.\]\+\^\$\(\)\<\>\{\)") == "abfnrtv\\*?.]+^$()<>{)"
    assert re_unescape(r"\\ab") == "\\ab"
    assert re_unescape(r"\\\d\\\D") == "\\d\\D"  # can't unescape \d \D
    assert re_unescape(r"\x00\xff\u0100") == "\x00\xff\u0100"
    assert re_unescape(r"\X00\Xff\u0100") == "X00Xff\u0100"  # can't unescape \X

# Generated at 2022-06-24 09:31:52.358679
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    assert TimeoutError("foo")  # type: ignore


# Aliases for backwards compatibility
TimeoutError.TimeoutError = TimeoutError
TimeoutError.TimeoutException = TimeoutError
TimeoutError.Timeout = TimeoutError
TimeoutError.ToJSONMixin = object



# Generated at 2022-06-24 09:31:59.505489
# Unit test for function exec_in
def test_exec_in():
    loc = {}
    glob = {}
    exec_in("x = 42", glob, loc)
    assert glob['x'] == 42
    assert loc['x'] == 42


_SIMPLE_TYPES = int, float, str, bytes, type(None)
_COMPOUND_TYPES = list, tuple, dict, set, frozenset
_RECURSIVE_TYPES = typing.Union[list, tuple, Dict[Any, Any], set, frozenset]



# Generated at 2022-06-24 09:32:03.142722
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=3600)) == 3600.0
    assert timedelta_to_seconds(datetime.timedelta(days=3, hours=5)) == 3 * 24 * 3600 + 5 * 3600
    assert timedelta_to_seconds(datetime.timedelta(seconds=0.8)) == 0.8

# Generated at 2022-06-24 09:32:09.808729
# Unit test for function import_object
def test_import_object():
    #import tornado.test.util
    import tornado.test
    assert import_object("tornado.test.util") is tornado.test.util
    assert import_object("tornado.test.util.import_object") is import_object
    assert import_object("tornado.test") is tornado.test
    try:
        import_object("tornado.test.nonexistent_module")
        assert False, "import_object should have failed"
    except ImportError:
        pass




# Generated at 2022-06-24 09:32:17.949608
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    if hasattr(datetime.timedelta, "total_seconds"):
        # This is a dummy class to make mypy happy. The real datetime.timedelta
        # has total_seconds, so some_timedelta.__class__.total_seconds
        # has the right type.
        class timedelta:
            pass
        timedelta.total_seconds = timedelta_to_seconds
        assert timedelta(42).total_seconds() == 42
        assert timedelta(seconds=42).total_seconds() == 42
        assert timedelta(days=1, seconds=42).total_seconds() == 86442

# Generated at 2022-06-24 09:32:30.029655
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class X(Configurable):
        def configurable_base(self):
            return X
        def configurable_default(self):
            return X
    def new_initialize_func():
        return X.initialize
    X.initialize = new_initialize_func
    X.initialize()

if sys.platform == "win32":
    _timer = time.clock
else:
    _timer = time.time


# Truncate time.clock() to the nearest microsecond
# Using time.clock is preferable to time.time on Windows
# because time.clock has microsecond granularity (and
# Python's time.time has only millisecond granularity on
# Windows).  See
# http://docs.python.org/library/time.html#time.clock on
# Windows.
# On other platforms, time.time has micro

# Generated at 2022-06-24 09:32:38.050025
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyClass

        @classmethod
        def configurable_default(cls):
            return MyClass

        def initialize(self, foo=None, bar=None):
            self.foo = foo
            self.bar = bar

    MyClass.configure("tornado.test.test_util.MyClass")
    obj = MyClass()
    assert obj.foo is None
    assert obj.bar is None
    obj = MyClass(foo=1)
    assert obj.foo == 1
    assert obj.bar is None
    obj = MyClass(bar=2)
    assert obj.foo is None
    assert obj.bar == 2
    obj = MyClass(foo=3, bar=4)
    assert obj.foo == 3