

# Generated at 2022-06-24 09:22:37.794286
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert isinstance(timedelta_to_seconds(datetime.timedelta(days=1)), float)
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0



# Generated at 2022-06-24 09:22:42.695496
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class Error(Exception):
        def __init__(self, errno: int) -> None:
            Exception.__init__(self, errno)
            self.errno = errno

    assert errno_from_exception(Error(0)) == 0
    # It should work with other types of exceptions
    assert errno_from_exception(ValueError(0)) is None
    assert errno_from_exception(ValueError()) is None
    assert errno_from_exception(Exception()) is None



# Generated at 2022-06-24 09:22:51.728789
# Unit test for function import_object
def test_import_object():
    import inspect
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    assert import_object('.escape') is tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('..escape') is tornado.escape
    assert import_object('...escape') is tornado.escape
    assert import_object('.') is inspect.currentframe().f_back.f_locals['__package__']
    assert import_object('') is inspect.currentframe().f_back.f_locals['__package__']

# Generated at 2022-06-24 09:22:58.674453
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(arg):
        return arg

    argRep = ArgReplacer(func, 'arg')
    print(argRep.arg_pos)

    name, args, kwargs = argRep.replace(1, args = (2, ), kwargs = {})
    print(name)
    print(args)
    print(kwargs)
# test_ArgReplacer_replace()

# Generated at 2022-06-24 09:23:00.667271
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1



# Generated at 2022-06-24 09:23:11.760713
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    """Unit test for function timedelta_to_seconds"""
    import time
    from datetime import timedelta
    from datetime import datetime
    from nose.tools import assert_equal
    assert_equal(timedelta_to_seconds(timedelta(seconds=1)), 1.0)
    assert_equal(timedelta_to_seconds(timedelta(seconds=1.5)), 1.5)
    assert_equal(timedelta_to_seconds(timedelta(seconds=-1.5)), -1.5)
    assert_equal(timedelta_to_seconds(timedelta(minutes=1)), 60)
    assert_equal(timedelta_to_seconds(timedelta(hours=-1)), -3600)

# Generated at 2022-06-24 09:23:12.956620
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 09:23:17.306216
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 24 * 60 * 60
# End unit test for function timedelta_to_seconds



# Generated at 2022-06-24 09:23:21.827913
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception("test")
    except Exception as e:
        assert errno_from_exception(e) == "test"
    try:
        raise Exception(1, "test")
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-24 09:23:27.033385
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=1)) == 1.000001



# Generated at 2022-06-24 09:23:30.857965
# Unit test for function exec_in
def test_exec_in():
    glob = dict(x=1)
    exec_in('y = x+1', glob)
    assert glob['y'] == 2
    exec_in('z = y+1', glob)
    assert glob['z'] == 3


# Generated at 2022-06-24 09:23:38.813297
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():  # type: ignore
    def test_func(*args, **kwargs):
        pass

    def test_func_with_defaults(a, b=1, c=2, d=3):
        pass

    e = ArgReplacer(test_func, "a")
    a = ArgReplacer(test_func_with_defaults, "a")
    b = ArgReplacer(test_func_with_defaults, "b")
    c = ArgReplacer(test_func_with_defaults, "c")
    d = ArgReplacer(test_func_with_defaults, "d")
    bad = ArgReplacer(test_func, "bad")

    assert e.get_old_value((1, 2, 3), {"a": 5, "b": 6}) == 5


# Generated at 2022-06-24 09:23:43.689344
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.test = 1
    assert obj.test == 1
    obj['test'] = 2
    assert obj.test == 2
    assert obj == {'test': 2}

# Generated at 2022-06-24 09:23:49.697943
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # test with positional argument passed
    assert (None, (1, 2, 3), {}) == ArgReplacer(None, "a").replace(3, (1, 2, 3), {})

    # test with positional argument missing
    assert None == ArgReplacer(None, "a").replace(3, (), {})[0]

    # test with keyword argument
    assert (None, (), {}) == ArgReplacer(None, "a").replace(1, (), {"a": None})

    # test with keyword argument missing
    assert None == ArgReplacer(None, "a").replace(1, (), {})[0]

# Generated at 2022-06-24 09:23:56.212303
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(arg1, arg2, arg3):
        pass
    arg_replacer = ArgReplacer(func, "arg1")
    assert arg_replacer.get_old_value(
        tuple(), dict(), default=None) == None
    assert arg_replacer.get_old_value(
        ("arg1_value", "arg2_value", "arg3_value"), dict(), default=None) == "arg1_value"
    assert arg_replacer.get_old_value(
        ("arg1_value", "arg2_value", "arg3_value"), {"arg1": "arg1_value_1"}, default=None) == "arg1_value"

# Generated at 2022-06-24 09:23:59.574797
# Unit test for function import_object
def test_import_object():
    import_object('unittest')
    # try a module and a function
    import_object('tornado.web')  # type: ignore
    import_object('tornado.util.import_object')  # type: ignore



# Generated at 2022-06-24 09:24:06.270304
# Unit test for function import_object
def test_import_object():
    assert import_object('string') is string
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
    except ImportError:
        pass
    else:
        assert False, "import_object should fail on missing modules"



# Generated at 2022-06-24 09:24:15.134146
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # type: () -> None
    try:
        raise IOError(0, "custom message")
    except IOError as e:
        assert errno_from_exception(e) == 0

    try:
        raise IOError(42, "custom message")
    except IOError as e:
        assert errno_from_exception(e) == 42

    try:
        raise IOError("custom message")
    except IOError as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError()
    except IOError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:24:23.866323
# Unit test for function import_object
def test_import_object():
    import unittest
    import tornado.escape
    import tornado.web
    paths = [
        ('tornado.escape', tornado.escape),
        ('tornado.escape.utf8', tornado.escape.utf8),
        ('tornado', tornado),
        ('tornado.web.RequestHandler', tornado.web.RequestHandler),
    ]
    for (path, expected) in paths:
        # __import__ is global, so clear the cache before each test
        tornado.util._import_object_cache.clear()
        assert import_object(path) is expected
    assert_raises(ImportError, import_object, 'tornado.missing_module')



# Generated at 2022-06-24 09:24:27.345086
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        def _initialize(self):
            print("_initialize OK")
            super(TestConfigurable, self)._initialize()
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestConfigurable
    TestConfigurable().initialize()

# Generated at 2022-06-24 09:24:36.327665
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(foo, bar="baz"):
        pass
    replacer = ArgReplacer(func, "bar")
    assert replacer.replace("test", (), {}) == (None, (), {'bar': 'test'})
    assert replacer.replace("test", (), dict(foo=None)) == (None, (), {'foo': None, 'bar': 'test'})
    assert replacer.replace("test", (), dict(bar="old")) == ("old", (), {'bar': 'test'})
    assert replacer.replace("test", (), dict(bar="old", foo=None)) == ("old", (), {'bar': 'test', 'foo': None})
    assert replacer.replace("test", (None,), {}) == (None, (None,), {'bar': 'test'})

# Generated at 2022-06-24 09:24:38.338015
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    s = ObjectDict()
    s.x = 10
    assert s["x"] == 10



# Generated at 2022-06-24 09:24:50.197275
# Unit test for constructor of class Configurable
def test_Configurable():
    """Test that Configurable classes can be instantiated, etc.

    Assumes that the configure() classmethod works, which is tested
    in the test modules for the subclasses.
    """
    class MockConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return MockConfigurable

        @classmethod
        def configurable_default(cls):
            return MockImpl

        def initialize(self, foo=None):
            super(MockConfigurable, self).initialize()
            self.foo = foo

    class MockImpl(MockConfigurable):
        def initialize(self, foo=None):
            super(MockImpl, self).initialize(foo=foo)

    MockConfigurable.configure(None, foo="bar")
    assert isinstance(MockConfigurable(), MockImpl)

# Generated at 2022-06-24 09:24:55.136591
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Test(object):
        @staticmethod
        def test_replace(first, second, third=None, fourth="fourth"):
            pass

    def test_method(replacer, new_value, old_value, args, kwargs):
        result = replacer.replace(new_value, args, kwargs)
        assert result[0] == old_value
        assert result[1][0] == "first"
        assert result[1][1] == "second"
        assert result[2]["third"] == "third"
        assert result[2]["fourth"] == "fourth"

    replacer = ArgReplacer(Test.test_replace, "second")
    test_method(replacer, "second_new", "second", ("first", "second"), {})

# Generated at 2022-06-24 09:25:06.830937
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    compressed_value = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xcbH\xcd\xc9\xc9W\x08\xcf/\xcaI\x01\x00j\x99\x19\x06\x00\x00\x00'
    decompressed_value = decompressor.decompress(compressed_value)
    assert decompressed_value == b'Test!\n'
    decompressed_value = decompressor.decompress(compressed_value)
    assert decompressed_value == b''
    decompressed_value = decompressor.flush()
    assert decompressed_value == b''
    # flush() should be callable only once.


# Generated at 2022-06-24 09:25:11.789236
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gz = GzipDecompressor()
    d = gz.decompress(b"asdf")
    assert d == b""
    d = gz.decompress(b"qwer")
    assert d == b""
    d = gz.flush()
    assert d == b"asdfqwer"


# Generated at 2022-06-24 09:25:20.075680
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():  # pragma: no cover
    def f(a, b):
        return a, b

    assert ArgReplacer(f, "a").get_old_value(("a", "b"), {}) == "a"
    assert ArgReplacer(f, "a").get_old_value(("a", "b", "c"), {}) == "a"
    assert ArgReplacer(f, "a").get_old_value(("a", "b", "c"), {"d": "d"}) == "a"
    assert ArgReplacer(f, "a").get_old_value(("a",), {"b": "b"}) == "a"
    assert ArgReplacer(f, "a").get_old_value(("a",), {"a": "a", "b": "b"}) == "a"
    assert ArgRepl

# Generated at 2022-06-24 09:25:25.135998
# Unit test for constructor of class Configurable
def test_Configurable():
    config = {"impl": None, "kwargs": {}}

    class C(Configurable):
        def initialize(self, a, b):
            self.a = a
            self.b = b

        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C_Default

    class C_Default(C):
        pass

    class C_Foo(C):
        pass

    assert type(C(1, 2)) is C_Default
    assert type(C(3, 4)) is C_Default
    assert type(C(5, 6)) is C_Default

    C.configure("tornado.util.C_Foo", foo=42)
    assert type(C(7, 8)) is C_Foo

# Generated at 2022-06-24 09:25:27.281669
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    test_obj = ObjectDict()


# Generated at 2022-06-24 09:25:35.932270
# Unit test for function import_object
def test_import_object():
    from tornado.escape import native_str
    test_str = native_str('escape')
    assert import_object(test_str).native_str is native_str
    test_str = native_str('tornado.escape')
    assert import_object(test_str).native_str is native_str
    test_str = native_str('escape.utf8')
    assert import_object(test_str).utf8 is tornado.escape.utf8
    test_str = native_str('tornado')
    assert import_object(test_str) is tornado

    test_str = native_str('missing_module')
    with pytest.raises(ImportError):
        import_object(test_str)



# Generated at 2022-06-24 09:25:39.638416
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def raise_error():
        try:
            raise TypeError("")
        except:
            raise_exc_info(sys.exc_info())
    try:
        raise_error()
    except Exception:
        pass



# Generated at 2022-06-24 09:25:48.129629
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=30)) == 30.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=60)) == 60.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=120)) == 120.0
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60.0
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 60 * 60.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 24 * 60 * 60.0

# Generated at 2022-06-24 09:25:55.870243
# Unit test for constructor of class Configurable
def test_Configurable():
    __impl_class = None  # type: Optional[Type[Configurable]]
    __impl_kwargs = None  # type: Dict[str, Any]
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return D

        def initialize(self, a, b=4):
            assert a == 1
            assert b == 2

        def test(self):
            return self.a + self.b

    class D(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return E

        def initialize(self, a, b=3):
            assert a == 1

# Generated at 2022-06-24 09:26:07.879519
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class DummyConfigurable(Configurable):
        def initialize(self, a, b, c=None, **kwargs):
            self.a = a
            self.b = b
            self.c = c
            self.kwargs = kwargs

    # Check default construction
    C = DummyConfigurable.configured_class()
    instance = C(1, 2, foo="foo")
    assert isinstance(instance, C)
    assert instance.a == 1
    assert instance.b == 2
    assert instance.c is None
    assert instance.kwargs == {"foo": "foo"}

    # Check custom class
    DummyConfigurable.configure("tornado.util.Configurable", bar="bar")
    C = DummyConfigurable.configured_class()
    assert issubclass(C, Configurable)
    instance

# Generated at 2022-06-24 09:26:14.310993
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import types

    assert(import_object("tornado.escape") is tornado.escape)
    assert(import_object("tornado.escape.utf8") is tornado.escape.utf8)
    assert(import_object("tornado") is tornado)
    try:
        import_object("tornado.missing_module")
        assert False
    except ImportError:
        pass

    # import_object should accept module objects as well as strings
    assert(import_object(types) is types)
    assert(import_object(types.ModuleType) is types.ModuleType)



# Generated at 2022-06-24 09:26:16.408382
# Unit test for function raise_exc_info
def test_raise_exc_info():  # type: ignore
    try:
        1 / 0
    except ZeroDivisionError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-24 09:26:21.477774
# Unit test for function exec_in
def test_exec_in():
    def run_expr(expr):
        ns = dict(globals())
        ns.update(locals())
        return eval(expr, ns)

    exec_in('x = 1', locals())
    assert run_expr('x') == 1
    ns = {}
    exec_in('y = 2', ns)
    assert ns['y'] == 2



# Generated at 2022-06-24 09:26:29.576730
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    # Test for a bug in raise_exc_info: one argument is 'None', and
    # we need to avoid mistakenly raising "None", i.e. None.with_traceback().
    #
    # The backslash is because linebreaks in doctests trigger an error.
    try:
        a = 1  # noqa: F841
    except:  # noqa: E722
        exc_info = sys.exc_info()
        list(exc_info)  # eliminate one reference to traceback
    # Buggy code was raising TypeError here; code without the bug raises
    # NameError.
    1/0  # noqa: F821


# Generated at 2022-06-24 09:26:32.496351
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass

# Alias for backward compatability.
gen_TimeoutError = TimeoutError


# Interface for the various asynchronous queue classes.

# Generated at 2022-06-24 09:26:40.853313
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f1(a, b):
        pass

    def f2(a, b, *args):
        pass

    def f3(a, b, **kwargs):
        pass

    def f4(a, b, *args, **kwargs):
        pass

    def f5(a, b=None):
        pass

    def f6(a, b=None, *args):
        pass

    def f7(a, b=None, **kwargs):
        pass

    def f8(a, b=None, *args, **kwargs):
        pass


    assert ArgReplacer(f1, "a").get_old_value((1, 2), {}) == 1
    assert ArgReplacer(f1, "b").get_old_value((1, 2), {}) == 2

    assert ArgRepl

# Generated at 2022-06-24 09:26:51.283720
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # function without arguments
    def func1():
        pass

    # function with one positional argument
    def func2(a):
        pass

    # function with one keyword argument
    def func3(a=None):
        pass

    # function with positional and keyword arguments
    # note that the order of the arguments in kwargs is undefined
    def func4(a, b=None, c=None):
        pass

    # function with variable argument list
    def func5(a, *args):
        pass

    # function with keyword argument list
    def func6(a, **kwargs):
        pass

    # function with variable argument list and keyword argument list
    def func7(a, *args, **kwargs):
        pass


# Generated at 2022-06-24 09:26:56.418865
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """Test ArgReplacer.replace()
    """
    from pprint import pprint
    from functools import partial
    from inspect import getfullargspec

    # Define a function
    def foo(a, b, d, e="e", f="f"):
        """Test function
        """
        return f"foo called with {a}, {b}, {d}, {e}, {f}"

    # Create an ArgReplacer instance with function foo
    arg_replacer = ArgReplacer(func=foo, name="d")

    # Verify getfullargspec of foo
    expected = "ArgSpec(args=['a', 'b', 'd', 'e', 'f'], varargs=None, keywords=None, defaults=('e', 'f'))"
    actual = pprint(getfullargspec(foo))
    assert actual

# Generated at 2022-06-24 09:26:57.487234
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(1)) == 86400.0



# Generated at 2022-06-24 09:27:02.277238
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"

    try:
        raise Exception("error", "message")
    except Exception as e:
        assert errno_from_exception(e) == "error"
# end unit test



# Generated at 2022-06-24 09:27:03.422949
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    raise unittest.SkipTest()



# Generated at 2022-06-24 09:27:09.283583
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    def check(td, seconds):
        assert timedelta_to_seconds(td) == seconds
    check(datetime.timedelta(weeks=50, days=1, hours=1, minutes=1, seconds=1,
                             microseconds=1),
          2505760061.000002)
    check(datetime.timedelta(weeks=0, days=0, hours=24*7*2, minutes=0, seconds=0,
                             microseconds=0),
          24*60*60*7*2)
    check(datetime.timedelta(weeks=0, days=0, hours=0, minutes=0, seconds=0,
                             microseconds=1),
          0.000001)

# Generated at 2022-06-24 09:27:20.788085
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class ConfigurableBase(Configurable):
        def __init__(self):
            # type: () -> None
            raise TypeError("can't instantiate abstract class")

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ConfigurableBase

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return ConfigurableBase

    class A(ConfigurableBase):
        pass

    class B(ConfigurableBase):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(D):
        pass

    class F(E):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)

# Generated at 2022-06-24 09:27:30.293237
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import unittest

    class DocTestWrapper(unittest.TestCase):
        def __init__(self, test):
            # type: (doctest.DocTest) -> None
            self.test = test
            self.__name__ = test.name  # type: ignore

        def runTest(self):
            # type: () -> None
            optionflags = (
                doctest.ELLIPSIS | doctest.REPORT_ONLY_FIRST_FAILURE
            )  # type: doctest.NORMALIZE_WHITESPACE
            runner = doctest.DocTestRunner(optionflags=optionflags)
            # We have to fake out the doctest runner to think it's running in
            # a module rather than the __main__ module
            runner.module

# Generated at 2022-06-24 09:27:36.072311
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=1, e=2):  # pragma: no cover
        pass
    assert ArgReplacer(f, "b").replace(123, (1, 2, 3), {}) == (2, (1, 123, 3), {})
    assert (
        ArgReplacer(f, "d").replace(123, (1, 2, 3), {}) == (1, (1, 2, 3), {"d": 123})
    )
    assert (
        ArgReplacer(f, "d").replace(123, (1, 2, 3), {"d": 4}) == (4, (1, 2, 3), {"d": 123})
    )

# Generated at 2022-06-24 09:27:46.679595
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    c = GzipDecompressor()
    data = c.decompress(zlib.compress(b"hello"))
    assert data == b"hello"
    assert c.flush() == b""
    assert c.unconsumed_tail == b""
    data = c.decompress(zlib.compress(b"world"))
    assert data == b""
    assert c.unconsumed_tail == zlib.compress(b"world")
    data = c.decompress(b"", 1024)
    assert data == b"world"
    assert c.unconsumed_tail == b""
    data = c.decompress(zlib.compress(b"foo"), 1024)
    assert data == b""
    assert c.unconsumed_tail == zlib.compress(b"foo")
    data

# Generated at 2022-06-24 09:27:49.037555
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    obj = GzipDecompressor()
    assert obj


# Generated at 2022-06-24 09:27:57.248961
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    e = TimeoutError()
    assert str(e) == ""

    e = TimeoutError("foo")
    assert str(e) == "foo"

# Backwards compatibility aliases
gen_log = gen_log.gen_log
import tornado.gen
tornado.gen.TimeoutError = TimeoutError

# Backwards compatibility aliases
import tornado.ioloop
tornado.ioloop.TimeoutError = TimeoutError

try:
    import typing_extensions  # type: ignore
except ImportError:
    pass
else:
    typing.TYPE_CHECKING = True
    # Avoid circular imports.
    from tornado.platform import asyncio as asyncio_


# Generated at 2022-06-24 09:28:01.425823
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def foo():
        try:
            raise ValueError(1)
        except ValueError as e:
            raise_exc_info((None, e, None))
    try:
        foo()
        assert False, "should have raised exception"
    except ValueError as e:
        assert e.args == (1,)



# Generated at 2022-06-24 09:28:07.418225
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-24 09:28:14.568535
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.x = 5
    assert d.x == 5
    assert d['x'] == 5

    d.y = 5
    assert d.y == 5
    assert d['y'] == 5

    d['z'] = 5
    assert d.z == 5
    assert d['z'] == 5

    d[1] = 5
    assert d[1] == 5
    assert d.get(1) == 5

    d[None] = 5
    assert d[None] == 5
    assert d.get(None) == 5

    d[5] = '5'
    assert d[5] == '5'
    assert d.get(5) == '5'



# Generated at 2022-06-24 09:28:25.659629
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=None):
        pass

    arg = ArgReplacer(f, "d")
    assert arg.get_old_value((1, 2, 3), {}) is None
    assert arg.get_old_value((), {"d": 42}) == 42
    assert arg.get_old_value((1, 2, 3), {"d": 42}) == 42
    assert arg.get_old_value((1, 2, 3), {"d": 42, "e": 37}) == 42
    assert arg.replace(37, (1, 2, 3), {}) == (None, (1, 2, 3), {"d": 37})
    assert arg.replace(37, (1, 2, 3), {"d": 42}) == (42, (1, 2, 3), {"d": 37})

# Generated at 2022-06-24 09:28:32.081947
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    assert GzipDecompressor().decompress(b"\x1f\x8b\x08\x00\x00\x00\x00\x00") == b""
    gz = GzipDecompressor()
    gz.decompress(b"\x1f\x8b\x08\x00\x00\x00\x00\x00")
    assert gz.decompress(b"\x00\x03\x00\x00\x00\x00\x00") == b""

# Generated at 2022-06-24 09:28:36.019000
# Unit test for function import_object
def test_import_object():
    import sys
    import tornado.escape
    tornado.escape.utf8
    tornado

    try:
        import_object("tornado.missing_module")
    except Exception as e:
        assert isinstance(e, ImportError)
    else:
        raise Exception("import_object should have failed")



# Generated at 2022-06-24 09:28:37.576203
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """
    Tests success case of Configurable.__new__
    """
    pass



# Generated at 2022-06-24 09:28:41.795615
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def testfunc() -> None:
        try:
            raise ValueError()
        except ValueError:
            raise_exc_info(sys.exc_info())

    try:
        testfunc()
    except ValueError:
        pass
    else:
        assert 0, "raise_exc_info didn't actually raise"



# Generated at 2022-06-24 09:28:52.475958
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import mock

    class ConfigurableTest(unittest.TestCase):
        def test_configurable_base(self):
            # In the absence of inheritance, configurable_base() should
            # return the class itself.
            class FooConfigurable(Configurable):
                @classmethod
                def configurable_base(cls):
                    return cls
            self.assertEqual(FooConfigurable.configurable_base(), FooConfigurable)

        def test_configured_class(self):
            # Test the configured class can be provided with configure and
            # configured_class can return it.
            class FooConfigurable(Configurable):
                @classmethod
                def configurable_base(cls):
                    return cls
                @classmethod
                def configurable_default(cls):
                    return object
           

# Generated at 2022-06-24 09:29:04.202899
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import struct
    import zlib
    compressor = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
    compressor.write(b"hello")
    compressor.write(b"world")
    compressed_data = compressor.flush()
    header = b"\x1f\x8b"  # magic header for gzip stream
    timestamp = struct.pack("<L", 0)  # zero the modification timestamp
    uncompressed_size = struct.pack("<L", 0)  # zero the uncompressed size
    crc = zlib.crc32(b"helloworld")
    compressed_size = struct.pack("<L", len(compressed_data))

# Generated at 2022-06-24 09:29:10.093261
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def foo(x):
        # type: (Any) -> None
        raise Exception(x)
    try:
        foo(None)
    except Exception as e:
        raise_exc_info(sys.exc_info())
    try:
        foo(None)
    except Exception as e:
        try:
            raise_exc_info(sys.exc_info())
        except TypeError:
            pass
        else:
            assert False, "no exception"
        assert issubclass(e.__class__, Exception)



# Generated at 2022-06-24 09:29:19.099364
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    compressed = b"".join(
        [
            b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff",
            b"K\xca\xcf\x07\x00\x1b\x85\xe0\xa6\xa0\x0c\x00\x00\x00",
        ]
    )
    data = decompressor.decompress(compressed)
    data += decompressor.flush()
    assert data == b"testing"



# Generated at 2022-06-24 09:29:27.308292
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return ASingle

        def __init__(self, a):
            # type: (Any) -> None
            self.a = a

        initialize = __init__

    class ASingle(A):
        pass

    class B(A):
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[B]
            return BDouble

        def __init__(self, b):
            # type: (Any) -> None
            self.b = b

        initialize = __init__



# Generated at 2022-06-24 09:29:37.379470
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    import inspect

    @ArgReplacer(inspect.stack, "context")
    def f(a, b, c):
        pass

    a = ArgReplacer(f, "a")
    assert a.arg_pos == 0
    b = ArgReplacer(f, "b")
    assert b.arg_pos == 1
    c = ArgReplacer(f, "c")
    assert c.arg_pos == 2
    z = ArgReplacer(f, "z")
    assert z.arg_pos is None
    assert a.name == "a"
    assert b.name == "b"
    assert c.name == "c"
    assert z.name == "z"



# Generated at 2022-06-24 09:29:41.164735
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class ConfigurableTest(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ConfigurableTest

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return cls

    a = ConfigurableTest()
    # Test that isinstance works properly
    assert isinstance(a, ConfigurableTest)
    assert isinstance(a, Configurable)



# Generated at 2022-06-24 09:29:51.558123
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def decompress(data):
        """Decompress a gzipped string, checking for various error
        conditions.
        """
        d = GzipDecompressor()
        result = []  # type: List[bytes]
        while data:
            decompressed = d.decompress(data)
            if decompressed:
                result.append(decompressed)
            data = d.unconsumed_tail
        result.append(d.flush())
        return b"".join(result)

    # Test our implementation against zlib.decompress
    data = os.urandom(128 * 1000)
    comp = zlib.compress(data)
    assert decompress(comp) == data
    assert decompress(comp[:100]) == data[:100]

# Generated at 2022-06-24 09:29:55.736770
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gzipper = GzipDecompressor()
    gzipped_data = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00;\x13\xef\x02\x00\x00\x00'
    uncompressed_data = b'javascript data'
    assert gzipper.decompress(gzipped_data) == uncompressed_data



# Generated at 2022-06-24 09:30:02.706413
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    # Test that __init__ of subclass is called
    class ObjectDict(dict):
        def __init__(self, *args, **kwargs):
            super(ObjectDict, self).__init__(*args, **kwargs)
            self.called = True
    d = ObjectDict()
    assert d.called
    # Test that __init__ of subclass is called for subclasses of
    # ObjectDict
    class MyObjectDict(ObjectDict):
        pass
    d = MyObjectDict()
    assert d.called


# Generated at 2022-06-24 09:30:13.430476
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    #
    # Tests for setattr
    #
    # Ensure setattr adds to the object dictionary
    expect = ObjectDict()
    # check until 26 to test that there is no infinite loop
    for i in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
              19, 20, 21, 22, 23, 24, 25, 26):
        expect[i] = i
    assert_equal(expect['1'], 1)
    assert_equal(expect['2'], 2)
    assert_equal(expect['3'], 3)
    assert_equal(expect['4'], 4)
    assert_equal(expect['5'], 5)
    assert_equal(expect['6'], 6)
   

# Generated at 2022-06-24 09:30:14.990597
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # No coverage for the method __new__
    pass



# Generated at 2022-06-24 09:30:17.359874
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    GzipDecompressor = GzipDecompressor()
    GzipDecompressor.decompress = GzipDecompressor.decompress

# Generated at 2022-06-24 09:30:26.849790
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def argtest(a, b, c, d=object()):
        # type: (int, Any, Any, Any) -> None
        pass
    ar = ArgReplacer(argtest, "b")
    assert ar.get_old_value((1, 2, 3), {}) is None
    assert ar.get_old_value((1, 2, 3), {}, object()) is object()
    assert ar.get_old_value((1, 2, 3), {"b": 4}) is 4
    assert ar.get_old_value((1, 2, 3), {"c": 3}) is None
    assert ar.get_old_value((1, 2, 3), {}, 4) is 4

# Generated at 2022-06-24 09:30:30.993756
# Unit test for function exec_in
def test_exec_in():
    x = 1
    exec_in('y = x + 1', locals())
    assert y == 2
    exec_in('y = x + 1', {'x': 5})
    assert y == 2
    exec_in('y = z + 1', {'z': 5})
    assert y == 6



# Generated at 2022-06-24 09:30:42.806707
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b):
        return a, b
    argreplacer = ArgReplacer(foo, 'a')
    args = (1, 2)
    kwargs = {}
    old_value, args, kwargs = argreplacer.replace(10, args, kwargs)
    assert old_value == 1
    assert args == (10, 2)
    assert kwargs == {}
    old_value, args, kwargs = argreplacer.replace(20, args, kwargs)
    assert old_value == 10
    assert args == (20, 2)
    assert kwargs == {}
    def foo(a, b=2):
        return a, b
    argreplacer = ArgReplacer(foo, 'b')
    args = (1,)
    kwargs = {}
    old_

# Generated at 2022-06-24 09:30:45.409654
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def foo(a=None, b=None, c=None):
        pass
    obj = ArgReplacer(foo, "a")
    assert obj.replace("new_value", "old_value", b=1, c=1) == ("old_value", ["new_value"], {'b': 1, 'c': 1})

# Generated at 2022-06-24 09:30:53.468003
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError
    except OSError as e:
        assert errno_from_exception(e) == errno.EPERM
    try:
        raise OSError("error")
    except OSError as e:
        assert errno_from_exception(e) == "error"
    try:
        raise OSError("error", 1)
    except OSError as e:
        assert errno_from_exception(e) == "error"
    try:
        raise OSError("error", 1)
    except OSError as e:
        assert errno_from_exception(e) == "error"
    try:
        raise OSError(1)
    except OSError as e:
        assert errno_from_

# Generated at 2022-06-24 09:30:54.754837
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # IOLoop.current()
    Unicode = str
    pass

# Generated at 2022-06-24 09:30:58.269802
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConfigurableImpl(Configurable):
        def initialize(self):
            self.initialize = MagicMock()
            self.initialize()

    verifyClass(Testable, ConfigurableImpl)

    actual = ConfigurableImpl()
    assert_that(actual.initialize, called())



# Generated at 2022-06-24 09:31:09.738027
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=1, b=2)
    assert isinstance(d, dict)
    assert d["a"] == 1
    assert d["b"] == 2
    assert d.a == 1
    assert d.b == 2

# Aliases for StringIO, cStringIO are broken in Python 3.
try:
    import StringIO as py3_stringio  # type: ignore
except ImportError:
    StringIO = None  # type: Optional[Any]  # noqa: F821
else:
    StringIO = py3_stringio.StringIO  # type: Any  # noqa: F821
try:
    import cStringIO as py3_cstringio  # type: ignore
except ImportError:
    cStringIO = None  # type: Optional[Any]  # noqa: F

# Generated at 2022-06-24 09:31:19.265618
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    from tornado.testing import AsyncTestCase
    class TestGzipDecompressor_decompress(AsyncTestCase):
        def test_decompress(self):
            for zlib_method in (False, True):
                for use_gzip in (False, True):
                    for i in range(50):
                        yield self._test_decompress(zlib_method, use_gzip, i)
        def _test_decompress(self, zlib_method: bool, use_gzip: bool, seed: int) -> None:
            import random
            import zlib
            import gzip
            random.seed(seed)
            compressor = zlib.compressobj(6, zlib.DEFLATED, -zlib.MAX_WBITS,
                                          zlib.DEF_MEM_LEVEL, 0)

# Generated at 2022-06-24 09:31:25.598100
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # pragma: nocover
    def fn_raises_TimeoutError() -> None:
        raise TimeoutError()

    assert "TimeoutError" in fn_raises_TimeoutError.__qualname__


# Alias for backwards compatibility
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError

try:
    import threading
except ImportError:
    import dummy_threading as threading



# Generated at 2022-06-24 09:31:35.164664
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, arg):
            self.arg = arg

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    assert str(A(1)) == '<A at 0x%x, arg=1>' % id(A(1))
    assert str(A.configured_class()(1)) == '<A at 0x%x, arg=1>' % id(A(1))
    assert str(A.configured_class().configured_class()(1)) == '<A at 0x%x, arg=1>' % id(A(1))

# Generated at 2022-06-24 09:31:46.538046
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_with_args_by_pos(arg1, arg2, arg3):
        return arg1, arg2, arg3

    def func_with_args_by_name(arg1, arg2, arg3):
        return arg1, arg2, arg3

    def func_with_args_by_pos_and_by_name(arg1, arg2, arg3):
        return arg1, arg2, arg3

    def func_with_args_by_name_and_default_value(arg1, arg2="arg2", arg3="arg3"):
        return arg1, arg2, arg3

    def func_with_args_by_pos_and_by_name_and_default_value(
        arg1, arg2="arg2", arg3="arg3"
    ):
        return arg

# Generated at 2022-06-24 09:31:52.359548
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    zero = datetime.timedelta(0)
    assert timedelta_to_seconds(zero) == 0.0

    one_second = datetime.timedelta(seconds=1)
    assert timedelta_to_seconds(one_second) == 1.0

    one_day = datetime.timedelta(days=1)
    assert timedelta_to_seconds(one_day) == 86400.0



# Generated at 2022-06-24 09:31:54.166507
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzipDecompressor = GzipDecompressor()

# Generated at 2022-06-24 09:31:56.126142
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.xxx = 123
    d['xxx'] = 123



# Generated at 2022-06-24 09:31:59.504643
# Unit test for function exec_in
def test_exec_in():
    x = 1
    loc = {"x": 2, "y": 3}
    def f():
        assert x == 1
        assert y == 3
    exec_in(f.__code__, {}, loc)
test_exec_in()



# Generated at 2022-06-24 09:32:09.599112
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import tornado.concurrent
    import tornado.curl_httpclient
    import tornado.database
    import tornado.escape
    import tornado.gen
    import tornado.httpclient
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.locale
    import tornado.locks
    import tornado.log
    import tornado.netutil
    import tornado.options
    import tornado.process
    import tornado.queue
    import tornado.simple_httpclient
    import tornado.tcpclient
    import tornado.tcpserver
    import tornado.test.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.simple_httpclient
    import tornado.tcpclient
    import tornado.tc

# Generated at 2022-06-24 09:32:13.400337
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    dict_obj = ObjectDict(a=1, b=2)
    assert dict_obj.a == 1
    assert dict_obj['a'] == 1
    dict_obj = ObjectDict([('a', 1), ('b', 2)])
    assert dict_obj.a == 1
    assert dict_obj['a'] == 1



# Generated at 2022-06-24 09:32:18.778690
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(22, "Invalid argument")
    except Exception as e:
        assert e.errno == 22
        assert errno_from_exception(e) == 22

    try:
        raise Exception("Invalid argument")
    except Exception as e:
        assert e.errno != 0
        assert errno_from_exception(e) == 0



# Generated at 2022-06-24 09:32:20.526019
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass



# Generated at 2022-06-24 09:32:32.679270
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Implementation(object):
        def __init__(self, a, b=None, **kwargs):
            self.a = a
            self.b = b
            self.kwargs = kwargs

        def __repr__(self):
            return "<Implementation %s %s %s>" % (self.a, self.b, self.kwargs)

    class Interface(Configurable):
        def configurable_base(self):
            # type: () -> Type[Interface]
            return Interface

        def configurable_default(self):
            # type: () -> Type[Implementation]
            return Implementation

    # Assert that the implementation is the implementation (it's a trichotomy!)
    assert isinstance(Interface(a=1), Implementation)

    # Assert that the configured and default implementations are

# Generated at 2022-06-24 09:32:34.858952
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj["var"] = {"name": "var", "value": "value"}
    assert obj.var.name == "var"
