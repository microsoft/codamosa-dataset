

# Generated at 2022-06-24 09:22:42.660628
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Test case, in which the argument `x` is passed as a keyword argument.
    class TestClass(object):
        def foo(self, x='x'):
            pass
    foo_replacer = ArgReplacer(TestClass.foo, 'x')
    old_value, args, kwargs = foo_replacer.replace('y', (), {'x': 'x'})
    assert old_value == 'x'
    assert args == ()
    assert kwargs == {'x': 'y'}

    # Test case, in which the argument `x` is passed as a positional argument.
    class TestClass(object):
        def bar(self, x):
            pass
    bar_replacer = ArgReplacer(TestClass.bar, 'x')
    old_value, args, kwargs = bar_replacer.replace

# Generated at 2022-06-24 09:22:44.609717
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    td = datetime.timedelta(days=1, seconds=2, microseconds=3)
    assert timedelta_to_seconds(td) == 86400.000003



# Generated at 2022-06-24 09:22:45.396184
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    o = ObjectDict()
    o.x = 1
    assert o['x'] == 1


# Generated at 2022-06-24 09:22:46.615559
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    v = ObjectDict()
    v.x = 5



# Generated at 2022-06-24 09:22:48.803507
# Unit test for function import_object
def test_import_object():
    assert import_object("os") is os
    assert import_object("os.path") is os.path
    assert import_object("time.time") is time.time



# Generated at 2022-06-24 09:22:54.064393
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable

        @classmethod
        def configurable_default(cls):
            return TestConfigurable

        def initialize(self, *args, **kwargs):
            pass

    class TestConfigurableChild(TestConfigurable):
        def initialize(self, *args, **kwargs):
            pass


# Generated at 2022-06-24 09:23:06.293686
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    data = zlib.compress(b"Hello world")
    compressed = data[:5] + b"==="  # break the compressor stream
    gzip_decompressor = GzipDecompressor()
    # decompress() method of class GzipDecompressor
    un_data_1 = gzip_decompressor.decompress(compressed)
    # flush() method of class GzipDecompressor
    un_data_2 = gzip_decompressor.flush()
    assert un_data_1 + un_data_2 == b"Hello world"

# Determine what functions and methods should have parameters wrapped in
# `_NullArgument` objects.
#
# An argument is nullable if it is ever possible for it to have the value
# None.  This happens if its default value is None or if it is in the list

# Generated at 2022-06-24 09:23:09.104127
# Unit test for function import_object
def test_import_object():
    import_object('os')
    import_object('os.path')
    import_object('os.path.join')


# Generated at 2022-06-24 09:23:16.995832
# Unit test for function re_unescape
def test_re_unescape():
    assert _re_unescape_pattern.sub(_re_unescape_replacement, r"\a\b\c") == r"abc"
    assert _re_unescape_pattern.sub(_re_unescape_replacement, r"\1\2\3") == r"123"

    with pytest.raises(ValueError):
        _re_unescape_pattern.sub(_re_unescape_replacement, r"\a\b\c")



# Generated at 2022-06-24 09:23:22.735479
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(pos1, pos2, keyword=3):
        return pos1, pos2, keyword

    arg = ArgReplacer(func, "pos1")
    old = arg.get_old_value(("pos1", "pos2"), {})
    assert(old == "pos1")
    old = arg.get_old_value(("pos2", "pos1"), {})
    assert(old == "pos1")
    arg = ArgReplacer(func, "keyword")
    old = arg.get_old_value(("pos1", "pos2"), {})
    assert(old == 3)
    try:
        old = arg.get_old_value(("pos2", "pos1"), {})
    except:
        print("Exception: get_old_value of keyword argument requires value passed in")

# Generated at 2022-06-24 09:23:31.315856
# Unit test for constructor of class Configurable
def test_Configurable():  # type: ignore
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

        def __init__(self):
            self.initialized = True

    c = C()
    assert c.initialized

    # use classmethod @classmethod
    class D(C):
        pass

    x = D()
    assert x.initialized
    assert isinstance(x, C)
    assert not isinstance(x, D)
    D.configure(None)
    assert D.configured_class() is C
    D.configure(D)
    y = D()
    assert y.initialized
    assert isinstance(y, D)
    assert not isinstance(y, C)

# Generated at 2022-06-24 09:23:34.356194
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)
    assert False  # Should never reach this line



# Generated at 2022-06-24 09:23:35.366044
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    pass


# Generated at 2022-06-24 09:23:45.756696
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # this is a valid gzip file
    s = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6d\x54\x59\x50\x49\x2d\x2e\x2e"
    decompressor = GzipDecompressor()
    data = decompressor.decompress(s, 16)
    assert not decompressor.unconsumed_tail
    assert not decompressor.flush()
    assert data == b"MYPID----"
    # this is a valid gzip file with a single-byte tail

# Generated at 2022-06-24 09:23:47.719175
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import zlib
    x = zlib.compress(b"test")
    y = GzipDecompressor().decompress(x)
    assert y == b"test"



# Generated at 2022-06-24 09:23:54.581302
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from types import MethodType

    def test_shim_for_MethodType(self):
        pass

    # For now, the only way to get a MethodType object that is not
    # bound to a class instance is to use this trick.
    #
    # See also:
    #
    # - the discussion in
    #   https://github.com/python/cpython/pull/6618/
    # - the special-case handling in the mypy PR
    #   https://github.com/python/mypy/pull/5699
    test_instance_method = MethodType(test_shim_for_MethodType, None)

    class C(Configurable):
        pass

    assert C.configure.__name__ == "configure"
    assert C.configure.__self__ == C

# Generated at 2022-06-24 09:23:57.511476
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(OSError(22, "mock error")) == 22
    assert errno_from_exception(OSError()) is None



# Generated at 2022-06-24 09:23:59.122587
# Unit test for function exec_in
def test_exec_in():
    def f():
        x = 0
        exec_in(
            "x += 1",
            {"x": x},
            loc={},
        )
        assert x == 1

    f()
test_exec_in()



# Generated at 2022-06-24 09:24:11.274268
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta()) == 0.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5625)) == 1.5625
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5, microseconds=1)) == 1.5000001
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, days=1, microseconds=1)) == 90036001.0



# Generated at 2022-06-24 09:24:18.421444
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(None, "", "")
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception("", "", "")
    except Exception as e:
        assert errno_from_exception(e) is ""

    try:
        raise Exception("1", "", "")
    except Exception as e:
        assert errno_from_exception(e) == "1"

    try:
        raise IOError(1, "")
    except IOError as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-24 09:24:23.099055
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo(a, b=None, c=None):
        pass

    # replace b
    a = ArgReplacer(foo, "b")
    assert a.replace(100, (1,), {}) == (None, (1,), {"b": 100})
    assert a.replace(100, (1,), {"b": 200}) == (200, (1,), {"b": 100})

    # replace c
    a = ArgReplacer(foo, "c")
    assert a.replace(100, (1,), {}) == (None, (1,), {"c": 100})
    assert a.replace(100, (1,), {"c": 200}) == (200, (1,), {"c": 100})

    # replace a
    a = ArgReplacer(foo, "a")

# Generated at 2022-06-24 09:24:29.449353
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c, d):
        pass

    r = ArgReplacer(func, "c")
    assert r.arg_pos == 2
    assert r.get_old_value(("a", "b", "c", "d"), {}) == "c"
    assert r.get_old_value(("a",), {"c": "c", "d": "d"}) == "c"
    assert r.get_old_value(("a",), {"d": "d"}) is None
    assert r.get_old_value(("a", "b", "c", "d"), {}, "e") == "c"
    assert r.get_old_value(("a",), {"c": "c", "d": "d"}, "e") == "c"
    assert r.get_old_value

# Generated at 2022-06-24 09:24:31.214578
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    """Test if none of the physical lines of code or branches will not be executed."""
    assert GzipDecompressor().flush()==b''


# Generated at 2022-06-24 09:24:37.749439
# Unit test for function re_unescape
def test_re_unescape():
    """Unit tests for re_unescape function"""
    assert re_unescape(r"foo") == "foo"
    assert re_unescape(r"foo\\") == "foo\\"
    assert re_unescape(r"foo\\x") == "foo\\x"
    assert re_unescape(r"foo\\0") == "foo\\0"
    assert re_unescape(r"foo\\00") == "foo\\00"
    with pytest.raises(ValueError):
        assert re_unescape(r"foo\x")
    with pytest.raises(ValueError):
        assert re_unescape(r"foo\d")
    with pytest.raises(ValueError):
        assert re_unescape(r"foo\\x")



# Generated at 2022-06-24 09:24:49.407671
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # pragma: no cover
    msg = None  # type: Optional[str]
    try:
        raise TimeoutError(msg)
    except TimeoutError as e:
        assert str(e) == 'Operation timed out'

    msg = 'testing'
    try:
        raise TimeoutError(msg)
    except TimeoutError as e:
        assert str(e) == msg


# Alias exception classes to allow them to be imported from
# `tornado.util`.
TimeoutError = TimeoutError

# Alias these public classes so they can be imported from tornado.util
_TimeoutError = TimeoutError
_Configurable = Configurable

# Replace binary to string in `escape.utf8()` (Python 3 native string
# type) in tests to keep backwards compatibility.

# Generated at 2022-06-24 09:25:01.731311
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import random
    from functools import wraps

    def foo(a, b, *args, **kwargs):
        # type: (int, int, *Any, **Any) -> None
        pass

    num_testcase = 100
    for _ in range(num_testcase):
        # Generate random parameters to pass to foo
        def create_random_parameter(lower, upper):
            return random.randint(lower, upper)

        a = create_random_parameter(0, 100)
        b = create_random_parameter(0, 100)
        c = create_random_parameter(0, 100)

        # Call foo with the randomly generated parameters
        foo(a, b, c)

        # Check if get_old_value returns the expected parameter

# Generated at 2022-06-24 09:25:08.295969
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    with open("GzipDecompressor.py", "rb") as f:
        with gzip.GzipFile("GzipDecompressor.py", "rb") as gz:
            r1 = f.read()
            r2 = gz.read()
    decompressor = GzipDecompressor()
    d1 = decompressor.decompress(r2)
    d2 = decompressor.flush()
    assert r1 == d1 + d2
    assert decompressor.unconsumed_tail == b""



# Generated at 2022-06-24 09:25:14.370843
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def print_obj(obj: Any) -> None:
        print(obj.get("a"))
        print(obj.get("b"))

    # Test case 1
    obj = ObjectDict()
    obj.a = 1
    obj.b = 2
    print_obj(obj)

    # Test case 2
    obj2 = ObjectDict()
    obj2["a"] = 1
    obj2["b"] = 2
    print_obj(obj2)

del test_ObjectDict___setattr__



# Generated at 2022-06-24 09:25:19.581414
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_file_path = './test_gzip_file'
    with open(gzip_file_path, 'rb') as gzip_file:
        gzip_data = gzip_file.read()
    gzip_decompressor = GzipDecompressor()
    gzip_decompressor.decompress(gzip_data)
    assert gzip_decompressor.flush() == b'a test string\n'
test_GzipDecompressor_decompress()


# Generated at 2022-06-24 09:25:24.862196
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b, c=1, d=2):
        return a + b + c + d
    
    a = ArgReplacer(f, "a")
    assert a.get_old_value((4, 5), {"b":2, "c":3, "d":3}, 0) == 4
    assert a.get_old_value((4, 5), {"b":2, "c":3, "d":3}) == 4
    assert a.get_old_value((4,), {"b":2, "c":3, "d":3}) == 4
    assert a.get_old_value((4, 5), {"b":2}, 0) == 4
    assert a.get_old_value((4, 5), {}, 0) == 4


# Generated at 2022-06-24 09:25:28.696356
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj_dict = ObjectDict()
    obj_dict.test = "test"
    assert(obj_dict.test == "test")
    assert(obj_dict["test"] == "test")


# Generated at 2022-06-24 09:25:30.418014
# Unit test for function exec_in
def test_exec_in():
    a = 4
    exec_in('b = a+1', globals(), None)
    assert b == 5



# Generated at 2022-06-24 09:25:40.653762
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Concrete(Configurable):
        __impl_class = None

        @classmethod
        def configurable_base(cls):
            return Concrete


# Generated at 2022-06-24 09:25:48.245056
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"

    try:
        raise Exception("error", 2)
    except Exception as e:
        assert errno_from_exception(e) == ("error", 2)

    try:
        raise Exception(errno=3)
    except Exception as e:
        assert errno_from_exception(e) == 3

    try:
        raise Exception(1, "error", 3)
    except Exception as e:
        assert errno_from_exception(e) == (1, "error", 3)



# Generated at 2022-06-24 09:25:49.296921
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is just a type comment.
    d = None  # type: GzipDecompressor


# Fake classes for testing

# Generated at 2022-06-24 09:25:57.986366
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    from datetime import timedelta
    assert timedelta_to_seconds(timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(timedelta(seconds=1, microseconds=1)) == 1.000001
    assert timedelta_to_seconds(timedelta(minutes=1)) == 60
    # Truncates to milliseconds on python 2.6, which is okay by us:
    assert timedelta_to_seconds(timedelta(seconds=1, microseconds=100)) == 1.0001
    assert timedelta_to_seconds(timedelta(days=1)) == 86400


# Monotonic clock, if available:
try:
    _monotonic = time.monotonic
except AttributeError:  # pragma: no cover
    _monotonic = time.time

_time_

# Generated at 2022-06-24 09:26:08.866162
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def c(s):
        return bytearray(s, 'utf-8')

    decompressor = GzipDecompressor()
    assert decompressor.decompress(c('\x1f\x8b')) == b''
    assert decompressor.decompress(c('\x08')) == b''
    assert decompressor.decompress(c('\x00')) == b''
    assert decompressor.decompress(c('\x03\x00\x00\x00')) == b''
    assert decompressor.decompress(c('abcd')) == b''
    assert decompressor.decompress(c('\x00\xff\xff\xff')) == b''

    assert decompressor.flush() == b'abc'


# Generated at 2022-06-24 09:26:12.007466
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def __setattr__(self, name: str, value: Any) -> None:
        self[name] = value



# Generated at 2022-06-24 09:26:14.973085
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyTestClass(Configurable):
        def configurable_base(self):
            return MyTestClass

        def configurable_default(self):
            return MyTestClass

        def initialize(self,*args,**kwargs):
            print(args[0])


# Generated at 2022-06-24 09:26:20.462088
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # type: ignore
    x = ObjectDict(a=1, b=2)
    assert isinstance(x, dict)
    assert hasattr(x, 'a')
    assert hasattr(x, 'b')
    assert not hasattr(x, 'c')
    assert x['a'] == 1
    assert x['b'] == 2
    with pytest.raises(AttributeError):
        x['c']



# Generated at 2022-06-24 09:26:29.812944
# Unit test for function exec_in
def test_exec_in():
    globals = dict(a=1)
    exec_in('assert a == 1', globals)
    exec_in('assert b == 1', globals, dict(b=1))
    with pytest.raises(AssertionError):
        exec_in('assert a == 2', globals)
    with pytest.raises(AssertionError):
        exec_in('assert b == 2', globals, dict(b=1))
    # Tuple, compiled code, and keyword arguments all work as well
    exec_in(('assert a == 1', 'assert b == 2'), dict(a=1), dict(b=2))
    exec_in(compile('assert a == 3', '<string>', 'exec'), dict(a=3))

# Generated at 2022-06-24 09:26:31.672476
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict(a = 1)
    assert obj.a == 1


# Generated at 2022-06-24 09:26:35.976474
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"a\b") == "a\b"
    assert re_unescape(r"a\\b") == "a\\b"
    with pytest.raises(ValueError):
        re_unescape(r"a\d")

# Generated at 2022-06-24 09:26:41.527668
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def fn(a, b, c=3, d=4):
        pass

    assert ArgReplacer(fn, "a").arg_pos == 0
    assert ArgReplacer(fn, "b").arg_pos == 1
    assert ArgReplacer(fn, "c").arg_pos is None
    assert ArgReplacer(fn, "d").arg_pos is None

    assert ArgReplacer(fn, "a").get_old_value([1, 2], {}) == 1
    assert ArgReplacer(fn, "b").get_old_value([1, 2], {}) == 2
    assert ArgReplacer(fn, "c").get_old_value([1, 2], {}) == 3
    assert ArgReplacer(fn, "d").get_old_value([1, 2], {}) is None

# Generated at 2022-06-24 09:26:48.514722
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    data = (b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xed\xcf\x41\x0a\xc2\x30"
            b"\x0c\x84\xe1\xa2\x08\x00\xff\xff\x12\xfe\x02\x00\x1b\x00\x03\x00"
            b"\x00\x00\x00\x00\x00\x00\x00")
    gz = GzipDecompressor()
    assert gz.decompress(data) == b"hello"
    assert gz.flush() == b""


# Generated at 2022-06-24 09:26:59.076333
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    """
    Tests method __getattr__ of class ObjectDict
    """

    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import ObjectDict

    class ObjectDictTest(AsyncTestCase):
        def test_actual_attribute_works(self) -> None:
            # type: () -> None
            """
            Tests actual attribute works.
            """
            obj = ObjectDict()  # type: ObjectDict
            obj.foo = 1
            self.assertEqual(1, obj.foo)

        @gen_test
        def test_dict_key_in_ObjectDict(self) -> None:
            # type: () -> None
            """
            Tests dict key in ObjectDict
            """
            obj = ObjectDict()  # type: ObjectD

# Generated at 2022-06-24 09:27:08.026226
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        class B(Configurable):
            def initialize(self, foo):
                self.foo = foo

            @classmethod
            def configurable_base(cls):
                return A

            @classmethod
            def configurable_default(cls):
                return A.B

        class B1(Configurable):
            @classmethod
            def configurable_base(cls):
                return A.B

            @classmethod
            def configurable_default(cls):
                return A.B1

        class B2(Configurable):
            @classmethod
            def configurable_base(cls):
                return A.B

            @classmethod
            def configurable_default(cls):
                return A.B2

    # Test simple substitution

# Generated at 2022-06-24 09:27:15.324609
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import unittest
    
    
    class A(Configurable):
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Configurable
        
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return None
        
        def initialize(self):
            # type: () -> None
            self.initialized = True
    
    
    class B(Configurable):
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Configurable
        
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return A
        
        def initialize(self):
            # type: () -> None
            self.initialized = True

# Generated at 2022-06-24 09:27:26.510580
# Unit test for method replace of class ArgReplacer

# Generated at 2022-06-24 09:27:30.365110
# Unit test for function doctests
def test_doctests():
    from tornado.testing import AsyncTestCase, LogTrapTestCase

    class _TestDocTests(AsyncTestCase, LogTrapTestCase):
        def test_doctests(self):
            tests = doctests()
            for test in tests:
                if isinstance(test, doctest.DocTestCase):
                    test.globs["io_loop"] = self.io_loop
                    test.globs["self"] = self
            runner = unittest.TextTestRunner(verbosity=2)
            runner.run(tests)

    return _TestDocTests



# Generated at 2022-06-24 09:27:41.533665
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"foo") == r"foo"
    assert re_unescape(r"\*") == r"*"
    assert re_unescape(r"a\+b") == r"a+b"
    assert re_unescape(r"a\?b") == r"a?b"
    assert re_unescape(r"a\\b") == r"a\b"
    assert re_unescape(r"a\{b") == r"a{b"
    assert re_unescape(r"a\}b") == r"a}b"
    assert re_unescape(r"a\[b") == r"a[b"
    assert re_unescape(r"a\]b") == r"a]b"

# Generated at 2022-06-24 09:27:48.068849
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(1, "error")
    except Exception as e:
        assert isinstance(e, OSError)
        assert errno_from_exception(e) == 1
    try:
        raise OSError(2)
    except Exception as e:
        assert isinstance(e, OSError)
        assert errno_from_exception(e) == 2
    try:
        raise OSError()
    except Exception as e:
        assert isinstance(e, OSError)
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:27:54.003570
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This test is derived from the zlib module's test_zlib.py file.
    # It is included here to ensure compatibility with all possible
    # implementations of the zlib library.
    import tempfile
    from functools import partial

    def compressobj(*args, **kwargs):
        # The zlib module's compressobj doesn't understand unicode
        # strings in Python 3.
        kwargs['wbits'] = zlib.MAX_WBITS | 16
        return zlib.compressobj(*args, **kwargs)

    if zlib.decompressobj().unused_data != b"":
        raise ValueError("the zlib module is misconfigured")
    if zlib.decompressobj().unconsumed_tail != b"":
        raise ValueError("the zlib module is misconfigured")


# Generated at 2022-06-24 09:28:00.470488
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    from tornado.testing import gen_test

    @gen_test
    def test_ObjectDict___getattr__(self) -> None:
        # type: ignore
        """Tests for ObjectDict.__getattr__"""
        obj = ObjectDict()
        obj.test = 1

        self.assertEqual(obj.test, 1)

        with self.assertRaises(AttributeError):
            obj.undefined



# Generated at 2022-06-24 09:28:06.596585
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def f():
        # type: () -> None
        try:
            raise ValueError()
        except:
            raise_exc_info(sys.exc_info())

    try:
        f()
    except ValueError:
        pass
    else:  # pragma: no cover
        raise AssertionError("ValueError not raised")



# Generated at 2022-06-24 09:28:09.173552
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    try:
        obj = ObjectDict({'key': 'value'})
        assert obj.key == 'value'
    except Exception as e:
        print(e)
        assert False
test_ObjectDict___getattr__()


# Generated at 2022-06-24 09:28:20.686097
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c, d=3, **kwargs): pass
    R = ArgReplacer(f, "b")
    assert "b" in R._getargnames(f)
    assert R.arg_pos == 1
    assert R.get_old_value((1, 2, 3, 4), {}) == 2
    assert R.get_old_value((1, 2, 3), {}) == 2
    assert R.get_old_value((1, 2, 3), {"b": 4}) == 4
    assert R.get_old_value((1, 2, 3), {"b": 4, "e": 5}, default=42) == 4
    assert R.get_old_value((1,), {"b": 4}) == 4
    assert R.get_old_value((1,), {}, default=42)

# Generated at 2022-06-24 09:28:26.229824
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    compressor = zlib.compressobj(9, zlib.DEFLATED,
                                  zlib.MAX_WBITS | 16,
                                  zlib.DEF_MEM_LEVEL, 0)
    compressed = compressor.compress("ABC")
    compressed += compressor.flush()
    decompressor = GzipDecompressor()
    assert decompressor.decompress(compressed) == "ABC"



# Generated at 2022-06-24 09:28:32.856409
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()  # type: Any
    assert e.__class__ is TimeoutError


import tornado.gen
import tornado.ioloop

tornado.ioloop.TimeoutError = TimeoutError
tornado.gen.TimeoutError = TimeoutError

try:
    import concurrent.futures
except ImportError:
    concurrent_futures = None  # type: ignore
else:
    concurrent_futures = concurrent.futures  # type: ignore  # noqa: E305



# Generated at 2022-06-24 09:28:39.138021
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    demo_string = b"Hello, World"
    demo_dict = {b"Hello, World": b"Hello, World"}
    # Check the return type
    assert isinstance(decompressor.decompress(demo_string), bytes)
    # Check if the demo dict passes
    assert decompressor.decompress(demo_dict) == b"Hello, World"
    # Check if the demo string passes
    assert decompressor.decompress(demo_string) == b"Hello, World"

# Generated at 2022-06-24 09:28:42.580601
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    bs = b'x\x9c+\xcfO\xcaI\xcc\xcf_H\xceK\xce,\x00\x16\x06R\x1a\x00\x00\x00'
    gd = GzipDecompressor()
    print(gd.decompress(bs))
    print(gd.unconsumed_tail)
    print(gd.flush())

# Generated at 2022-06-24 09:28:45.255603
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    od = ObjectDict()
    od["attr"] = "value"
    assert isinstance(od.attr, str)



# Generated at 2022-06-24 09:28:54.607493
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a: int, b: int = 5, c: int = 10) -> float:
        return a + b + c

    arg_b = ArgReplacer(func, "b")
    assert arg_b.get_old_value((1,), {}, None) is None
    assert arg_b.get_old_value((1,), {"b": 2}, None) == 2
    assert arg_b.get_old_value((1, 2), {}, None) == 2
    assert arg_b.get_old_value((1, 2, 3), {}, None) == 2
    assert arg_b.get_old_value((1, 2, 3, 4), {}, None) == 2

# Generated at 2022-06-24 09:29:06.304414
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl = object()
    class A(Configurable):
        def configurable_base(self):
            return A1
        def configurable_default(self):
            return impl
    class A1(A):
        pass
    class B(A):
        def configurable_base(self):
            return B1
        def configurable_default(self):
            return int
    class B1(B):
        pass
    A.configure(object())
    A.configure(None)
    assert A1.configured_class() is impl
    B.configure(str)
    assert B1.configured_class() is str
    A.configure(B1)
    assert A1.configured_class() is B1
    assert B1.configured_class() is str
    # Check that a configurable subclass

# Generated at 2022-06-24 09:29:17.028410
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    import tornado.util
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.util') is tornado.util
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    import tornado.testing
    assert type(import_object('tornado.testing.AsyncTestCase')) == type
    import_object('tornado.testing.AyncTestCase')
    # test missing module
    try:
        import_object('tornado.missing_module')
    except ImportError as e:
        pass


_DEFAULT_ENV = None  # type: Optional[Mapping[str, str]]


# Generated at 2022-06-24 09:29:21.359543
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    with raises(ImportError):
        import_object("tornado.missing_module")



# Generated at 2022-06-24 09:29:31.822146
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    global called
    called = 0

    def f(a):
        global called
        called += 1
        return a

    arg = ArgReplacer(f, "a")
    assert arg.get_old_value((1,), {}) == 1
    assert arg.get_old_value((), {"a": 2}) == 2
    assert arg.get_old_value((), {}, 3) == 3
    assert arg.get_old_value((), {"b": 4}, 3) == 3
    assert arg.replace(5, (1,), {}) == (1, (5,), {})
    assert arg.replace(6, (), {"a": 2}) == (2, (), {"a": 6})
    assert arg.replace(7, (), {}, 3) == (None, (), {"a": 7})

# Generated at 2022-06-24 09:29:36.964054
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def testargspair(arg = None, kwarg = None):
        return arg, kwarg

    def testargs(arg = None):
        return arg

    a = ArgReplacer(testargspair, "arg")
    b = ArgReplacer(testargs, "arg")

    assert a.get_old_value([4, 5], {"arg": 1, "kwarg": 2}) == 1
    assert a.get_old_value([4, 5], {"kwarg": 2}) == None
    assert a.get_old_value([4, 5], {"kwarg": 2}, 2) == 2

    assert b.get_old_value([4, 5], {"arg": 1}) == 1

# Generated at 2022-06-24 09:29:48.720150
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(Exception()) == None
    assert errno_from_exception(Exception(1)) == 1
    assert errno_from_exception(Exception(1, 2)) == 1
    from socket import error, herror, gaierror, timeout
    for exc in [error(), herror(), gaierror(), timeout()]:
        assert errno_from_exception(exc) == exc.errno


if hasattr(os, "strerror"):
    def os_strerror(errno: Optional[int]) -> str:
        if errno is None:
            return "Unknown error"

# Generated at 2022-06-24 09:30:00.370504
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    old_value, args, kwargs= ArgReplacer('a','b').replace(3,('c',),{'a':1,'d':4})
    assert old_value==1
    assert args==('c',)
    assert kwargs=={'b':3,'d':4,'a':1}
    old_value, args, kwargs = ArgReplacer('a','b').replace(3,(2,),{'a':1,'d':4})
    assert old_value==1
    assert args==(2,)
    assert kwargs=={'d':4,'a':3}
    old_value, args, kwargs = ArgReplacer('a','b').replace(3,(2,3),{'a':1,'d':4})
    assert old_value==3

# Generated at 2022-06-24 09:30:04.092773
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()  # type: ignore
    except TimeoutError:
        pass


# Exceptions that may be raised
# by `.Configurable.configure` implementations

# Generated at 2022-06-24 09:30:06.834511
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gz = GzipDecompressor()
    value = gz.flush()


# Generated at 2022-06-24 09:30:15.351280
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from inspect import signature  # type: ignore
    c = Configurable()
    sig = signature(c.initialize)  # type: ignore
    assert len(sig.parameters) == 1
    assert sig.parameters["self"].kind == Parameter.POSITIONAL_OR_KEYWORD
    # Unit test for method configurable_base of class Configurable
    def test_Configurable_configurable_base():
        c = Configurable()
        assert c.configurable_base() is Configurable
        # Unit test for method configurable_default of class Configurable
    def test_Configurable_configurable_default():
        c = Configurable()
        assert c.configurable_default() is Configurable
        # Unit test for method configure of class Configurable
    def test_Configurable_configure():
        c = Configurable()
       

# Generated at 2022-06-24 09:30:17.749258
# Unit test for function exec_in
def test_exec_in():
    globals()["test_exec_in"] = None
    exec_in(b'print("Hello World")', globals(), locals())


# Generated at 2022-06-24 09:30:19.528031
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gzip_decompressor = GzipDecompressor()



# Generated at 2022-06-24 09:30:28.229701
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c=3, d=4):
        pass
    args = (1, 2)
    kw = dict(d=40, e=50)
    myreplacer = ArgReplacer(func, 'c')
    assert myreplacer.arg_pos == 2
    assert myreplacer.get_old_value(args, kw, 99) == 99
    assert myreplacer.get_old_value(args, kw) == 99
    assert myreplacer.replace(300, args, kw) == (3, (1, 2), dict(d=40, e=50, c=300))


# Generated at 2022-06-24 09:30:33.162890
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=3)
    assert d.a == 3, "ObjectDict failed to assign key-value pair"
    assert d["a"] == 3, "ObjectDict failed to assign key-value pair"
    try:
        d.b + 3  # type: ignore
        assert False, "ObjectDict failed to raise AttributeError"
    except AttributeError:
        pass



# Generated at 2022-06-24 09:30:37.601193
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gz_data = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xec\xfd\x06\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    gz_decomp = GzipDecompressor()
    assert gz_decomp.decompress(gz_data) == b''
    assert gz_decomp.flush() == b'\xec\xfd\x06'



# Generated at 2022-06-24 09:30:45.525415
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(*args, **kwargs):
        pass
    args = (1, 2, 3)
    kwargs = {'x':5}
    r = ArgReplacer(func, 'y')
    print(r.get_old_value(args, kwargs))
    r = ArgReplacer(func, 'x')
    print(r.get_old_value(args, kwargs))
    r = ArgReplacer(func, 'a')
    print(r.get_old_value(args, kwargs))
    r = ArgReplacer(func, 'b')
    print(r.get_old_value(args, kwargs))

# Generated at 2022-06-24 09:30:49.395360
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def f():
        # type: () -> None
        raise ValueError()

    try:
        f()
    except:
        raise_exc_info(sys.exc_info())


_non_explode_args = {"skip_keys": set(), "property_name": None}



# Generated at 2022-06-24 09:30:52.298861
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    x = ObjectDict()
    x.key = 'value'
    assert x['key'] == 'value'



# Generated at 2022-06-24 09:30:53.365964
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def foo():
        raise_exc_info(BaseException("test"))  # type: ignore
    assert_raises(BaseException, foo)



# Generated at 2022-06-24 09:30:58.305720
# Unit test for function exec_in
def test_exec_in():
    glob = {'a': 1, 'b': 2}
    loc = {'b': 200, 'c': 300}
    exec_in("assert a == 1", glob, loc)
    exec_in("assert b == 200", glob, loc)
    exec_in("assert c == 300", glob, loc)
    try:
        exec_in("assert d == 400", glob, loc)
        assert False
    except AssertionError:
        pass
    try:
        exec_in("assert d == 400", glob)
        assert False
    except AssertionError:
        pass
    exec_in("assert d == 400", glob, {'d': 400})



# Generated at 2022-06-24 09:30:58.914945
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass

# Generated at 2022-06-24 09:31:00.546073
# Unit test for function import_object
def test_import_object():
    import_object("tornado.util").import_object("tornado.escape")



# Generated at 2022-06-24 09:31:06.450944
# Unit test for function import_object
def test_import_object():
    from tornado.escape import utf8
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is utf8
    assert import_object("tornado") is tornado
    # This doesn't implicitly load tornado.escape
    assert import_object("escape") is not tornado.escape
    assert import_object("tornado.missing_module")



# Generated at 2022-06-24 09:31:12.637439
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # type: () -> None
    def test_function(arg):
        # type: (Any) -> None
        pass
    replacer = ArgReplacer(test_function, "arg")
    assert replacer.get_old_value(args=(1,), kwargs={}, default=2) == 1
    assert replacer.get_old_value(args=(), kwargs={}, default=2) == 2



# Generated at 2022-06-24 09:31:14.506390
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    assert obj.a is None
    assert obj.b == 0


# Generated at 2022-06-24 09:31:22.321498
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer(): # type: () -> None
    def func(a, b, c=10, d=20): # type: ignore
        pass

    replacer = ArgReplacer(func, "c")

    assert replacer.arg_pos == 2

    assert replacer.get_old_value((1, 2, 3, 4), {}) == 3
    assert replacer.get_old_value((1, 2, 3, 4), {}, default=None) == 3
    assert replacer.get_old_value((1, 2, 3), {}) == 3
    assert replacer.get_old_value((1, 2, 3), {}, default=None) == 3
    assert replacer.get_old_value((1, 2), {}) == 10
    assert replacer.get_old_value((1, 2), {}, default=None) == 10


# Generated at 2022-06-24 09:31:25.848377
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    x = ObjectDict()
    x.foo = 42
    assert x["foo"] == 42

    x.foo = 23
    assert x["foo"] != 23  # hasattr(x, "foo") != True
    assert x["foo"] == 23  # x.get("foo") == 23



# Generated at 2022-06-24 09:31:29.547075
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    m = ObjectDict()
    m.foo = 'bar'
    m.test()

# TypedDict is only available on Python 3.8+
if not hasattr(typing, 'TypedDict'):
    typing.TypedDict = None


# Generated at 2022-06-24 09:31:37.826562
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"foo\+bar\(baz\)") == r"foo+bar(baz)"
    assert re_unescape(r"foo\dbar") == r"foo\dbar"
    assert re_unescape(r"foo\\bar\(baz\)") == r"foo\bar(baz)"
    assert re_unescape(r"foo\\\+bar\(baz\)") == r"foo\+bar(baz)"
    assert re_unescape(r"foo\\\\bar\(baz\)") == r"foo\\bar(baz)"
    with pytest.raises(ValueError):
        # Characters other than `\` cannot be unescaped
        re_unescape(r"foo\bar")



# Generated at 2022-06-24 09:31:49.625636
# Unit test for constructor of class Configurable
def test_Configurable():
    configurable_base_called = False
    configurable_default_called = False

    def configurable_base():
        # type: () -> Type[Configurable]
        nonlocal configurable_base_called
        configurable_base_called = True
        return ConfigurableForTest

    def configurable_default():
        # type: () -> Type[Configurable]
        nonlocal configurable_default_called
        configurable_default_called = True
        return ImplementationForTest

    class ConfigurableForTest(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return configurable_base()

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return configurable_default()


# Generated at 2022-06-24 09:31:55.219637
# Unit test for function exec_in
def test_exec_in():
    x = 1
    try:
        exec_in("y=1", locals())
        assert False, "didn't raise"
    except NameError:
        pass
    exec_in("y=2", locals(), locals())
    assert y == 2
    exec_in("z=3", locals(), {})
    assert z == 3
    exec_in("z=4", {}, locals())
    assert z == 4
    exec_in('exec("z=5")', {}, locals())
    assert z == 5


# Generated at 2022-06-24 09:32:02.098365
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, x: int) -> None:
            self.x = x

    a = A(1)  # type: A
    assert(a.x == 1)

    try:
        A(x=2)
    except TypeError:
        pass
    else:
        raise Exception("shouldn't reach here")



# Generated at 2022-06-24 09:32:07.375832
# Unit test for function exec_in
def test_exec_in():
    glob = {}
    loc = {}
    exec_in('foo = 6', glob)
    assert glob['foo'] == 6
    exec_in('bar = 7', glob, loc)
    assert glob['bar'] == 7
    assert loc['bar'] == 7
    glob = {}
    loc = {}
    exec_in('foo = "asdf"', glob)
    assert glob['foo'] == "asdf"
    exec_in('bar = "zxcv"', glob, loc)
    assert glob['bar'] == "zxcv"
    assert loc['bar'] == "zxcv"


_BYTES_RE = re.compile(r"b(['\"])")



# Generated at 2022-06-24 09:32:17.292969
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(x, y, z):
        return x, y, z
    replacer = ArgReplacer(foo, "y")
    assert replacer.get_old_value((1, 2, 3), {}) == 2
    assert replacer.get_old_value((1,), {"y": 2}) == 2
    assert replacer.get_old_value((1, 2, 3), {"z": 4}) == 2
    assert replacer.get_old_value((1,), {"y": 2, "z": 4}) == 2
    replacer = ArgReplacer(foo, "z")
    assert replacer.get_old_value((1, 2, 3), {}) == 3
    assert replacer.get_old_value((1, 4), {"z": 4}) == 4

# Generated at 2022-06-24 09:32:21.396339
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass

# The following aliases are used by the deprecated HTTPConnection class
Timeout = TimeoutError
timeout_error = TimeoutError

_non_word_re = re.compile(r"[^\w]")



# Generated at 2022-06-24 09:32:33.335488
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import io
    import zlib

    # NOTE: This is repeated from _websocket_impl because it's not
    # possible in general to import _websocket_impl from the _websocket
    # module due to circular dependencies.
    def _make_mask_generator() -> Callable[[], int]:
        get_random = random.SystemRandom().getrandbits
        while True:
            yield get_random(32)

    # unit test code