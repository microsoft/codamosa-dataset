

# Generated at 2022-06-24 09:22:34.315614
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.x = 42
    assert d.x == 42
    assert d['x'] == 42

# Dummy value for parameter defaults.
_UNSET = object()


# Generated at 2022-06-24 09:22:37.919336
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        errno_from_exception(Exception)
    except TypeError as e:
        assert str(e) == "errno_from_exception() missing 1 required positional argument: 'e'", str(e)



# Generated at 2022-06-24 09:22:46.309405
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = GzipDecompressor()
    text = b'hello world'
    input_string = text
    while True:
        try:
            input_string = gzip_decompressor.unconsumed_tail + input_string
            (decompressed, consumed) = gzip_decompressor.decompress(
                input_string, 32 * 1024)
            input_string = input_string[consumed:]
        except zlib.error:
            # Zlib won't accept any more input.  Copy any remaining input
            # to the unconsumed_tail for next time.
            gzip_decompressor.decompressobj.unconsumed_tail = input_string
            break
    output = gzip_decompressor.flush()
    assert text == output


# Generated at 2022-06-24 09:22:50.461364
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.test_ObjectDict___getattr___test_var_0 = 0
    obj.test_ObjectDict___getattr___test_var_1 = 0
    obj.test_ObjectDict___getattr___test_var_2 = 0
    obj.test_ObjectDict___getattr___test_var_3 = 0
    # Set obj.test_ObjectDict___getattr___test_var_0 to 0
    # Set obj.test_ObjectDict___getattr___test_var_1 to 0
    # Set obj.test_ObjectDict___getattr___test_var_2 to 0
    # Set obj.test_ObjectDict___getattr___test_var_3 to 0
    obj.test_ObjectDict___getattr___test_

# Generated at 2022-06-24 09:22:53.210194
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def function(arg1, **kwargs):
        return arg1

    assert ArgReplacer(function, 'arg1').get_old_value((5,), {}, default=None) == 5



# Generated at 2022-06-24 09:22:58.207138
# Unit test for function re_unescape
def test_re_unescape():
    # make sure we cover all characters
    for c in range(256):
        assert re_unescape(re.escape(chr(c))) == chr(c)

    with pytest.raises(ValueError):
        re_unescape(re.escape("\x01"))



# Generated at 2022-06-24 09:23:02.573745
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    dict_obj = ObjectDict()
    dict_obj['test'] = 5
    assert dict_obj.test == 5
    assert list(dict_obj) == ['test']
    del dict_obj.test
    assert 'test' not in dict_obj
    dict_obj.test = 'str'
    assert dict_obj['test'] == 'str'
    try:
        dict_obj.test2
    except AttributeError:
        pass  # The correct behavior
    else:
        raise AssertionError('dict_obj.test2 should raise AttributeError')



# Generated at 2022-06-24 09:23:05.324665
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    testDict = ObjectDict()
    isinstance(testDict.name, AttributeError)
    isinstance(testDict["name"], KeyError)



# Generated at 2022-06-24 09:23:16.715311
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fff(a1, a2, a3):
        """
        a1 - arg1
        a2 - arg2
        a3 - arg3
        """
        return a1 + a2 + a3

    ar = ArgReplacer(fff, "a1")
    assert ar.replace(11, (2, 3, 4), {}) == (2, (11, 3, 4), {})
    assert ar.replace(11, (2,), {"a2": 3, "a3": 4}) == (2, (11,), {"a2": 3, "a3": 4})
    assert ar.replace(11, (), {"a1": 2, "a2": 3, "a3": 4}) == (2, (), {"a1": 11, "a2": 3, "a3": 4})
    assert ar.replace

# Generated at 2022-06-24 09:23:18.080463
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d.key = 100
    assert 'key' in d.keys()
    assert d.key == d['key']
    assert d.key == 100

# Generated at 2022-06-24 09:23:26.088738
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    replacer = ArgReplacer(lambda x, y=2: None, 'y')
    assert replacer.replace(1, (), {}) == (2, (), {'y': 1})
    assert replacer.replace(1, (1,), {}) == (None, (1, 1), {})
    assert replacer.replace(1, (1,), {'y': 2}) == (2, (1, 1), {'y': 1})



# Generated at 2022-06-24 09:23:29.314383
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    ObjectDict()
    d = ObjectDict()
    d.foo = "foo"
    assert d.foo == "foo"
    assert d["foo"] == "foo"



# Generated at 2022-06-24 09:23:40.020896
# Unit test for function errno_from_exception
def test_errno_from_exception():
    from errno import EIO
    try:
        raise IOError(EIO, "blah")
    except Exception as e:
        assert errno_from_exception(e) == EIO
    try:
        try:
            raise IOError(EIO, "blah")
        except:
            raise Exception(*sys.exc_info())
    except Exception as e:
        assert errno_from_exception(e) == EIO
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(EIO)
    except Exception as e:
        assert errno_from_exception(e) == EIO



# Generated at 2022-06-24 09:23:44.918379
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0


if hasattr(datetime.timedelta, "total_seconds"):
    timedelta_to_seconds = datetime.timedelta.total_seconds



# Generated at 2022-06-24 09:23:46.408926
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-24 09:23:49.205977
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    obj = GzipDecompressor()
    if hasattr(obj, 'decompress'):
        obj.decompress('value', max_length=0)


# Backwards-compatible aliases
TimeoutError = TimeoutError
GzipDecompressor = GzipDecompressor



# Generated at 2022-06-24 09:23:55.835125
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Inefficient, but simple
    class Impl(Configurable):
        @classmethod
        def configurable_base(cls):
            return Configurable

        @classmethod
        def configurable_default(cls):
            return Impl

        def initialize(self):
            self.initialize_args = ()
            self.initialize_kwargs = {}

    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Impl

        def initialize(self):
            self.initialize_args = ()
            self.initialize_kwargs = {}

    class SubBase(Base):
        pass

    class SubSubBase(SubBase):
        pass

    # impl -> Impl
    x = Configurable()
   

# Generated at 2022-06-24 09:23:57.956784
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, minutes=1)) == 61.0



# Generated at 2022-06-24 09:24:02.831459
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c, d=4):
        pass

    assert ArgReplacer(func, "a").arg_pos == 0
    assert ArgReplacer(func, "d").arg_pos is None

    def func(b, a=4):
        pass

    assert ArgReplacer(func, "a").arg_pos is None
    assert ArgReplacer(func, "b").arg_pos == 0



# Generated at 2022-06-24 09:24:06.316131
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    s = ObjectDict()
    s.haha = 'hoho'
    assert s['haha'] == 'hoho'
test_ObjectDict___setattr__()


# Generated at 2022-06-24 09:24:08.445751
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # type: ignore
    d = ObjectDict()
    d["foo"] = 42
    assert d.foo == 42



# Generated at 2022-06-24 09:24:17.334355
# Unit test for function exec_in
def test_exec_in():
    def f(x):  # pylint: disable=unused-variable
        print(a)
        print(b)
    g = {}
    l = {}
    exec_in('a = 1\nb = 2', g, l)
    f(None)
    f_code = f.__code__
    f_defaults = f.__defaults__
    f_closure = f.__closure__
    exec_in(f_code, {}, {'a': 'one', 'b': 'two'})
    assert f_code is f.__code__
    assert f_defaults is f.__defaults__
    assert f_closure is f.__closure__



# Generated at 2022-06-24 09:24:25.867582
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert 0 == timedelta_to_seconds(datetime.timedelta(0))
    assert 0.1 == timedelta_to_seconds(datetime.timedelta(microseconds=10 ** 5))
    assert 1 == timedelta_to_seconds(datetime.timedelta(seconds=1))
    assert 60 == timedelta_to_seconds(datetime.timedelta(minutes=1))
    assert 3600 == timedelta_to_seconds(datetime.timedelta(hours=1))
    assert 86400 == timedelta_to_seconds(datetime.timedelta(days=1))



# Generated at 2022-06-24 09:24:33.971720
# Unit test for function exec_in
def test_exec_in():
    from typing import Any, Callable
    assert eval('(lambda: x)')()  # type: ignore[eval-used]  # noqa: F821
    exec_in('x=5', dict(__name__='__main__'))
    assert eval('(lambda: x)')() == 5  # type: ignore[eval-used]  # noqa: F821
    exec_in('x=6', dict(__name__='__main__'))
    assert eval('(lambda: x)')() == 6  # type: ignore[eval-used]  # noqa: F821
    exec_in('def f(): return 7', dict(__name__='__main__'))
    assert eval('(lambda: f())')() == 7  # type: ignore[eval-used]  # noqa: F821

# Generated at 2022-06-24 09:24:45.166475
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest.mock as mock

    # Mock the __new__ of Configurable class
    orig = Configurable.__new__
    Configurable.__new__ = mock.Mock(side_effect=orig)
    # Create the subclasses of Configurable
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def initialize(self, a, b, c=3):
            self.args = (a, b, c)

    class B(A):
        pass

    class C(A):
        pass

    # initialize
    A.configure(C)
    a = A(1, 2)
    assert a.args == (1, 2, 3)  # type:

# Generated at 2022-06-24 09:24:57.159109
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    err = TimeoutError("message")
    assert str(err) == "message"


# Inject our TimeoutError class into the __builtins__ so that `raise Timeout`
# statements will work on Python 3.
_BUILTINS = vars(typing._normalize_ctx(typing.get_type_hints(int)).__dict__["__builtins__"])
_BUILTINS[TimeoutError.__name__] = TimeoutError


try:
    import typing_extensions  # type: ignore
except ImportError:
    pass
else:
    # Python 3.5+
    import typing as typing_orig

    Union[
        Exception,
        TimeoutError,
    ]  # timeouts can raise either Timeout or concurrent.futures.TimeoutError
    typing_orig.TYPE_CHECKING 

# Generated at 2022-06-24 09:25:07.672079
# Unit test for function re_unescape
def test_re_unescape():
    # Does not raise ValueError
    re_unescape("1234")
    re_unescape("a-z")
    re_unescape("a\\.b")
    # Raises ValueError
    with pytest.raises(ValueError):
        re_unescape("\\d")
    with pytest.raises(ValueError):
        re_unescape("\\")
    with pytest.raises(ValueError):
        re_unescape("\\x")
    with pytest.raises(ValueError):
        re_unescape("\\1234")
    with pytest.raises(ValueError):
        re_unescape("\\a")
    with pytest.raises(ValueError):
        re_unescape("\\")



# Generated at 2022-06-24 09:25:13.226803
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    tests = doctest.DocTestSuite()
    runner = unittest.TextTestRunner()
    runner.run(tests)


# We can use the built-in json module without fear of side effects because
# the only features we use were present in Python 2.6.
_json_decode = json.JSONDecoder().decode



# Generated at 2022-06-24 09:25:20.964637
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c):
        return None
    args = ('a', 'b', 'c')
    kwargs = dict()
    t = ArgReplacer(test_func, 'b')
    assert(t.replace("x", args, kwargs) == ('b', ('a', 'x', 'c'), {}))
    assert(t.replace("x", args, kwargs) == ('b', ('a', 'x', 'c'), {}))
    kwargs = dict(b="x")
    assert(t.replace("y", args, kwargs) == ("x", ('a', 'y', 'c'), {'b': 'y'}))

# Generated at 2022-06-24 09:25:26.990249
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    assert decompressor.decompress(b'hello') == b'hello'
    assert decompressor.flush() == b''

    text = b'aaaaaaaaaabbbbbbbbbbcccccccccc'
    compressed = zlib.compress(text)
    assert decompressor.decompress(compressed) == text
    assert decompressor.flush() == b''



# Generated at 2022-06-24 09:25:36.438503
# Unit test for function import_object
def test_import_object():
    assert import_object('os.path') is os.path
    import sys
    assert import_object('sys.stdout') is sys.stdout
    assert import_object('sys') is sys
    assert import_object('tornado.util') is util
    try:
        import_object('sys.stdout.foobar')
        assert False, "should have raised exception"
    except AttributeError:
        pass
    try:
        import_object('tornado.util.foobar')
        assert False, "should have raised exception"
    except ImportError:
        pass


# Unfortunately, traceback.format_exc() returns text encoded in the
# default file encoding, which may not be utf-8 on some systems
# (particularly Windows).  This wrapper ensures we get a usable traceback
# for logging.

# Generated at 2022-06-24 09:25:47.159705
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1, microseconds=1)) == 86401.000001
    assert timedelta_to_seconds(datetime.timedelta(days=0, seconds=1, microseconds=1)) == 1.000001
    assert timedelta_to_seconds(datetime.timedelta(days=0, seconds=0, microseconds=1)) == 0.000001
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=0, microseconds=1)) == -86400.999999

# Generated at 2022-06-24 09:25:50.882912
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    value = zlib.compress(b'1234567890' * 1000)
    decompressor = GzipDecompressor()
    assert decompressor.decompress(value, 100) != b''
    assert decompressor.decompress(value, 100) != b''
    assert decompressor.flush() != b''


# Generated at 2022-06-24 09:25:53.004800
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class Foo(Configurable):
        pass
    Foo.configure(None)
    Foo.initialize()


# Generated at 2022-06-24 09:25:54.013985
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    assert doctests()  # silence pyflakes



# Generated at 2022-06-24 09:25:57.652332
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self):
            print("A")

    class B(A):
        def initialize(self):
            print("B")

    class C(A):
        pass

    class D(B):
        pass

    class E(Configurable):
        def initialize(self):
            print("E")

    assert B().__class__ is B
    assert C().__class__ is C
    assert D().__class__ is D
    assert E().__class__ is E



# Generated at 2022-06-24 09:26:01.709144
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    a = ObjectDict()
    a.b = 1
    c = ObjectDict()
    c.d = 2
    assert a.b == 1
    assert c.d == 2



# Generated at 2022-06-24 09:26:10.062842
# Unit test for function errno_from_exception
def test_errno_from_exception():
    if hasattr(errno, "ERRNO"):
        assert 1 == errno_from_exception(OSError(1, "error 1"))
        # Exception(errno,strerror) is a 2-tuple
        assert 1 == errno_from_exception(OSError((1, "error 1")))
        assert 1 == errno_from_exception(OSError(1))
        assert None == errno_from_exception(Exception())
        assert None == errno_from_exception(Exception("error 1"))


# Fake socket() return value for tests
FAKE_SOCKET = object()



# Generated at 2022-06-24 09:26:15.206120
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(Exception()) is None
    try:
        raise Exception(42, "The Answer")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("The Answer")
    except Exception as e:
        args = e.args
        class FakeException(Exception):
            pass
        e.__class__ = FakeException
        assert errno_from_exception(e) == args[0]



# Generated at 2022-06-24 09:26:22.432818
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Unit test for method replace of class ArgReplacer
    def func(a: str):
        return a
    f = ArgReplacer(func, "a")
    x = f.replace("world", ("hello",), {})
    assert x == ("hello", ("world",), {})
    x = f.replace("world", (), {"a": "hello"})
    assert x == ("hello", (), {"a": "world"})
    x = f.replace("world", (), {})
    assert x == (None, (), {"a": "world"})



# Generated at 2022-06-24 09:26:31.207710
# Unit test for constructor of class Configurable
def test_Configurable():
    # Test the subclassable class

    class Foo(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Foo

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Bar

    class Bar(Foo):
        def initialize(self, a):
            self.a = a

        def __eq__(self, other):
            return (type(self) == type(other) and self.a == other.a)

    # Test that you can't instantiate Foo
    # (but Bar can be instantiated)
    with ExpectLog(gen_log, ".*should use .* instead"):
        Foo()

    # Test that the default implementation is Bar
    a = Foo()
   

# Generated at 2022-06-24 09:26:35.395794
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    ArgReplacer(test_ArgReplacer_get_old_value, name='test').get_old_value((),{'test': 1})
    #assert ArgReplacer(test_ArgReplacer_get_old_value, name='test').get_old_value((2,), {'test': 1}) == (2,)





# Generated at 2022-06-24 09:26:39.528816
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gz = GzipDecompressor()
    s = b'hello world'
    gz_s = zlib.compress(s)
    assert gz.decompress(gz_s) == s
    assert gz.flush() == b''
    assert gz.decompress(b'invalid') == b''
    assert gz.flush() == b''



# Generated at 2022-06-24 09:26:48.782430
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\$") == "$"
    assert re_unescape(r"\$\+\*\?\-\\\[\]\^\(\)") == r"$+*?\-\[]^()"
    assert re_unescape(r"\x00\x01\x02\x03\x04\x05\x06\x07") == r"\x00\x01\x02\x03\x04\x05\x06\x07"
    assert re_unescape(r"\\\d") == r"\\d"



# Generated at 2022-06-24 09:26:59.286635
# Unit test for function import_object
def test_import_object():
    import_object("tornado.util")


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.
if bytes == str:

    def b(s: str) -> bytes:
        return s.encode("latin1")

    buffers = lambda arg: arg

else:

    def b(s: str) -> bytes:
        return s.encode("latin1")


# Generated at 2022-06-24 09:27:07.610102
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # Create a test case
    gzip_compressor = zlib.compressobj(zlib.Z_BEST_COMPRESSION, zlib.DEFLATED, 16 + zlib.MAX_WBITS)
    gzip_compressed = gzip_compressor.compress(b"some data to compress")
    gzip_compressed += gzip_compressor.flush()
    gzip_decompressor = GzipDecompressor()
    assert gzip_decompressor.decompress(gzip_compressed) == b"some data to compress"
    assert gzip_decompressor.flush() == b""


# Deprecated aliases
TimeoutError = TimeoutError
GzipDecompressor = GzipDecompressor



# Generated at 2022-06-24 09:27:08.802751
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()
    TimeoutError  # Silence pyflakes



# Generated at 2022-06-24 09:27:15.838822
# Unit test for function re_unescape
def test_re_unescape():
    assert re.escape("a") == r"a"
    assert re_unescape(re.escape("a")) == "a"

    assert re.escape(".") == r"\."
    assert re_unescape(re.escape(".")) == "."

    assert re.escape("a") == re.escape("a")
    assert re.escape(".") == re.escape(".")
    assert re.escape("a") != re.escape(".")

    assert re_unescape(re.escape("a")) == re_unescape(re.escape("a"))
    assert re_unescape(re.escape(".")) == re_unescape(re.escape("."))
    assert re_unescape(re.escape("a")) != re_unescape(re.escape("."))

    assert re.escape("a") != r"\a"

# Generated at 2022-06-24 09:27:26.859471
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\2") == r"\2"
    assert re_unescape(r"ab\(cd\)ef") == r"ab(cd)ef"
    assert re_unescape(r"\\\*") == r"\*"
    assert re_unescape(r"\d") == r"\d"
    # The following examples are taken from the "regular expression HOWTO":
    # http://docs.python.org/3.3/howto/regex.html#id16
    assert re_unescape(r"\w\s\W\S\d\D") == r"\w\s\W\S\d\D"

# Generated at 2022-06-24 09:27:29.220122
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    """Unit test for method __setattr__ of class ObjectDict"""
    obj = ObjectDict()
    obj.name = 'Monica'
    assert obj['name'] == 'Monica'

# Generated at 2022-06-24 09:27:30.613620
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    suite = doctests()
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)

# Generated at 2022-06-24 09:27:35.653310
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        def configurable_base(self):
            return Base

        def configurable_default(self):
            return Default

        def _initialize(self, a=0, b=1):
            self.a, self.b = a, b

    class Default(Base):
        def test(self):
            return "default"

    class Impl1(Base):
        def test(self):
            return "impl1"

    class Impl2(Base):
        def test(self):
            return "impl2"

    Base.configure(None)
    base = Base()
    assert base.a == 0 and base.b == 1
    assert base.test() == "default"
    assert isinstance(base, Base)
    assert isinstance(base, Default)

# Generated at 2022-06-24 09:27:36.380142
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    pass



# Generated at 2022-06-24 09:27:38.605901
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def foo(x: float) -> typing.NoReturn:
        raise_exc_info((TypeError, TypeError("hi"), None))
    try:
        foo(5)
    except TypeError as e:
        assert e.args == ("hi",)



# Generated at 2022-06-24 09:27:48.805943
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def a_func(a,b,c=3,d=4):
        pass

    arg_replacer = ArgReplacer(a_func,"c")
    old_value,args,kwargs = arg_replacer.replace(1,(1,2),dict(d=5))
    assert args == (1,2)
    assert kwargs == dict(c=1,d=5)
    assert old_value == 3

    old_value,args,kwargs = arg_replacer.replace(1,(1,2,5),dict(d=5))
    assert args == (1,2,1)
    assert kwargs == dict(d=5)
    assert old_value == 5



# Generated at 2022-06-24 09:27:57.099306
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    d = GzipDecompressor()
    # Feed it a gzip header and check that it accepts the full header
    # without returning any data.
    out = d.decompress(
        b"\x1f\x8b\x08\x08\x00\x00\x00\x00\x00\xff\x06\x00BC\x02\xff"
    )
    assert out == b""
    assert d.unconsumed_tail == b""
    # Complete the stream; there is no data but we do get the checksum.
    out += d.flush()
    assert out == b"\x00\x00\xe8\x1f\r\n\x00\x00\x00"
    assert d.unconsumed_tail == b""



# Generated at 2022-06-24 09:28:04.048219
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    v = decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xffKTW\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1b\xf0\xf5k\x06\x00\x00\x00')
    assert v == b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'

# Generated at 2022-06-24 09:28:06.070382
# Unit test for function exec_in
def test_exec_in():
    glob = {}
    exec_in("x = 6", glob)
    assert glob['x'] == 6



# Generated at 2022-06-24 09:28:13.961947
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Concrete(Configurable):
        # Unit test for method __new__ of class Configurable
        def test_Configurable___new__():
            class Concrete(Configurable):
                @classmethod
                def configurable_base(cls):
                    return Concrete

                @classmethod
                def configurable_default(cls):
                    return ConcreteSubclass

                def initialize(self):
                    pass

            assert isinstance(Concrete(), Concrete)
            assert isinstance(Concrete(), ConcreteSubclass)
            assert not isinstance(Concrete(), ConcreteSubclass2)

            concrete = Concrete()
            Concrete.configure(ConcreteSubclass2)
            assert issubclass(type(concrete), ConcreteSubclass)

            concrete2 = Concrete()

# Generated at 2022-06-24 09:28:16.897109
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    a = ObjectDict()
    assert isinstance(a, dict)
    a.foo = 'bar'
    assert a.foo == 'bar'
    assert a['foo'] == 'bar'
    assert 'foo' in a
    a['baz'] = True
    assert a.baz
    assert hasattr(a, 'baz')



# Generated at 2022-06-24 09:28:27.859947
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        @classmethod
        def configurable_base(self):
            return A

        @classmethod
        def configurable_default(self):
            return B

    class B(A):
        def initialize(self, value):
            self.value = value

    class C(A):
        def initialize(self, value):
            self.value = value

    class D(B):
        def initialize(self, value):
            self.value = value + '_D'

    A.configure(B)
    assert isinstance(A(), B)
    A.configure(C)
    assert isinstance(A(), C)
    assert A().value is None
    assert A(value=1).value == 1
    A.configure('test_utils.test_Configurable.D')

# Generated at 2022-06-24 09:28:30.849890
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import tornado.test.test_doctest
    tornado.test.test_doctest.run_doctest(__name__)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:28:33.160584
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    print(ArgReplacer.replace('this', [4, 5, 6], {'a':1, 'b':2}))


# Generated at 2022-06-24 09:28:37.388656
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=1):
        pass

    get_old_value = ArgReplacer(func, 'b').get_old_value
    assert get_old_value((1, 2, 3), {}, default=None) == 2
    assert get_old_value((1,), {'b':2, 'c':3}, default=None) == 2
    assert get_old_value((1,), {'c':3}, default=None) == None


# This is the same as tornado.escape.url_escape function, but different from urllib.quote function

# Generated at 2022-06-24 09:28:44.378216
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, "Input/output error")
    except OSError as e:
        assert errno_from_exception(e) == 5
        assert str(e) == "Input/output error".format(e.errno)
    try:
        raise OSError(errno.EACCES, "Permission denied")
    except OSError as e:
        assert errno_from_exception(e) == errno.EACCES
        assert str(e) == "Permission denied".format(e.errno)
    try:
        raise OSError()
    except OSError as e:
        assert errno_from_exception(e) is None
        assert str(e) == "OSError"

# Generated at 2022-06-24 09:28:51.549261
# Unit test for function exec_in
def test_exec_in():
    a = None  # type: Optional[str]
    b = None  # type: Optional[str]
    c = None  # type: Optional[str]
    exec_in("a = 'a'", globals())
    assert a == 'a'
    exec_in("b = 'b'", globals(), locals())
    assert b == 'b'

    exec_in("c = 'c'", {'print': print}, {'print': print})
    assert c == 'c'
    pass



# Generated at 2022-06-24 09:29:03.284630
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Aaa(Configurable):
        @classmethod
        def configurable_base(cls):
            return Aaa

        @classmethod
        def configurable_default(cls):
            return Aaa

        def initialize(self, *args, **kwargs):
            print("Aaa.initialize", args, kwargs)

        def __init__(self, *args, **kwargs):
            raise Exception("called")
            pass

    class Bbb(Aaa):
        def initialize(self, *args, **kwargs):
            print("Bbb.initialize", args, kwargs)

    # By default, Aaa is its own configured class.
    aaa = Aaa()
    assert isinstance(aaa, Aaa)
    # Bbb's __init__ would fail.
    bbb = Bbb()


# Generated at 2022-06-24 09:29:10.249755
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
   def test_function(one, two, three=3):
         return one, two, three

   arg = ArgReplacer(test_function, 'three')
   old_value, args, kwargs = arg.replace(99, (1, 2), {})
   assert old_value == 3
   assert args == (1, 2)
   assert kwargs == {'three': 99}

   old_value, args, kwargs = arg.replace(99, (1, 2, 3), {})
   assert old_value == 3
   assert args == (1, 2, 99)
   assert kwargs == {}



# Generated at 2022-06-24 09:29:15.832997
# Unit test for function raise_exc_info
def test_raise_exc_info():  # type: () -> None
    def test_it():
        # type: () -> typing.NoReturn
        raise_exc_info((None, RuntimeError("foo"), None))

    try:
        test_it()
    except RuntimeError:
        pass
    else:
        assert False



# Generated at 2022-06-24 09:29:18.956918
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("exception")
    except Exception as e:  # noqa: F841
        # See comments above the function definition
        raise_exc_info(True)



# Generated at 2022-06-24 09:29:27.218182
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(x, y=None):
        return x, y

    args, kwargs = (), {}
    assert ArgReplacer(f, "y").replace("y", args, kwargs) == (None, (), {"y": "y"})
    assert ArgReplacer(f, "x").replace("x", args, kwargs) == (None, ("x",), {})
    assert ArgReplacer(f, "y").replace("y", (1,), kwargs) == (None, (1,), {"y": "y"})
    assert ArgReplacer(f, "y").replace("y", ("x",), kwargs) == (None, ("x",), {"y": "y"})

# Generated at 2022-06-24 09:29:32.956302
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError()
    except OSError as e:
        assert errno_from_exception(e) is None
    try:
        raise OSError(22, "mock error msg")
    except OSError as e:
        assert errno_from_exception(e) == 22



# Generated at 2022-06-24 09:29:38.749758
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict(a=1, b=2)
    assert d.a == 1
    assert d.b == 2
    try:
        d.c
    except AttributeError:
        pass
    else:
        raise Exception("Expected AttributeError")


# DictMixin is deprecated and will be removed in Tornado 6.0
# This backwards-compatible alias will be maintained through Tornado 5.0.
DictMixin = ObjectDict



# Generated at 2022-06-24 09:29:50.490410
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, things=None):
        return a, b, things

    a = ArgReplacer(f, "b")

    assert a.replace("value", ("a",), {}) == (None, ("a", "value"), {})
    assert a.replace("value", ("a",), {"b": "old", "things": "old"}) == ("old", ("a", "value"), {"things": "old"})
    assert a.replace("value", ("a", "old"), {"things": "old"}) == ("old", ("a", "value"), {"things": "old"})

    # Test that we don't mutate the input args
    args = ("a", "old")
    kwargs = {"things": "old"}
    a.replace("value", args, kwargs)

# Generated at 2022-06-24 09:29:56.178282
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import unittest

    tests = doctests()
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(tests)


# Have one source of truth for the default port used when none is specified
_DEFAULT_PORT = 8888



# Generated at 2022-06-24 09:29:59.271773
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import zlib
    decompressobj = zlib.decompressobj(16 + zlib.MAX_WBITS)
    GzipDecompressor().decompressobj.unused_data



# Generated at 2022-06-24 09:30:06.030449
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
    try:
        try:
            raise_exc_info(exc_info)
        except ValueError:
            pass
        else:
            raise AssertionError("did not propagate ValueError")
    finally:
        # Clear exc_info to avoid reference cycles that would prevent
        # garbage collection
        exc_info = (None, None, None)



# Generated at 2022-06-24 09:30:14.111989
# Unit test for function exec_in
def test_exec_in():
    # We do this slightly non-standard way to avoid 2to3
    global test_exec_in_target
    test_exec_in_target = {}
    exec_in("target = {'foo': 6}", globals())
    assert test_exec_in_target["foo"] == 6


# Fake unicode literal support:  Python 3.2 doesn't have the u"" marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).
_stringlike = (bytes, str)



# Generated at 2022-06-24 09:30:20.249437
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass


# Make sure concurrent.futures.TimeoutError is an alias for tornado.gen.TimeoutError
# concurrent.futures is only available in Python 3
try:
    import concurrent.futures  # type: ignore
    concurrent.futures.TimeoutError = TimeoutError
except ImportError:
    pass



# Generated at 2022-06-24 09:30:25.688136
# Unit test for function import_object
def test_import_object():
    assert __name__ == import_object(__name__).__name__
    import logging
    assert logging == import_object('logging')
    assert logging.warn == import_object('logging.warn')
    try:
        import_object('tornado.i_dont_exist')
    except ImportError:
        pass
    else:
        assert False, "expected ImportError"



# Generated at 2022-06-24 09:30:35.092078
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b):
        pass
    r = ArgReplacer(func, "b")
    assert r.get_old_value((1, 2), {}) == 2
    assert r.get_old_value((1,), {"b": 2}) == 2
    assert r.get_old_value((), {"b": 2}) == 2
    assert r.get_old_value((1,), {"c": 2}) is None
    assert r.get_old_value((1,), {"b": 2}, default=1234) == 2
    assert r.get_old_value((1,), {"c": 2}, default=1234) == 1234
    assert r.replace(3, (1, 2), {}) == (2, (1, 3), {})

# Generated at 2022-06-24 09:30:38.273701
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict(a = 0)
    assert o.a == 0
    try:
        o.b
    except AttributeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-24 09:30:41.847758
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.a = 1
    assert d['a'] == 1
    d['b'] = 2
    assert d.b == 2
    assert d.c == AttributeError()
test_ObjectDict___setattr__()


# Generated at 2022-06-24 09:30:50.504736
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import tornado.testing
    import zlib
    #data = b'x\x9c+\xcf\xcfM\xcdO\xc9\xccS\x05\x00\x8d\x06\x92\xb3'
    data = b"x\x9c+\xcf\xcfM\xcdO\xc9\xccS\x05\x00\x8d\x06\x92\xb3"
    decompressor = tornado.util.GzipDecompressor()
    decompressor_stream = zlib.decompressobj(zlib.MAX_WBITS + 16)
    data = decompressor_stream.decompress(data)
    data = decompressor.flush()
    assert data == b"string"


# Generated at 2022-06-24 09:31:00.088221
# Unit test for function exec_in
def test_exec_in():
    import types

    scope = {}
    exec_in('foo = 1', scope)
    assert scope["foo"] == 1

    exec_in('bar = lambda x: x + 1', scope)
    assert isinstance(scope["bar"], types.FunctionType)
    assert scope["bar"](5) == 6

    exec_in('baz = 1; qux = 2', scope)
    assert scope["baz"] == 1
    assert scope["qux"] == 2


# Fake byte literal support:  In python 2.6+, you can say b"foo" to
# get a byte literal (str in 2.x, bytes in 3.x).  There's no way to
# do this in a way that supports 2.5, though, so we need a function
# wrapper to convert our string literals.  b() should only be applied
# to

# Generated at 2022-06-24 09:31:02.619506
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    o = ObjectDict()
    o.a = 1
    assert o['a'] ==1



# Generated at 2022-06-24 09:31:05.041975
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 1
    assert d.foo == 1
    assert d["foo"] == 1

    assert isinstance(d, dict)



# Generated at 2022-06-24 09:31:15.917657
# Unit test for constructor of class Configurable
def test_Configurable():
    from unittest.mock import Mock

    class Foo(Configurable):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        @classmethod
        def configurable_base(cls):
            return Foo

        @classmethod
        def configurable_default(cls):
            return FooImpl

    class Bar(Foo):
        pass

    class FooImpl(Foo):
        pass

    class BazImpl(Foo):
        pass

    Foo.configure(BazImpl)
    f = Foo(42, foo="bar")
    assert isinstance(f, BazImpl)
    assert f.args == (42,)
    assert f.kwargs == {"foo": "bar"}
    Foo.configure(None)

# Generated at 2022-06-24 09:31:25.801706
# Unit test for function import_object
def test_import_object():
    from unittest import mock
    import logging
    import_object = tornado.util.import_object
    with mock.patch.object(logging, 'info') as info_mock:
        logging_module = import_object('logging')
        assert logging_module is logging
        info_mock.assert_called_once_with("importing %r", 'logging')
        info_mock.reset_mock()
        logging_module = import_object('logging')
        assert logging_module is logging
        info_mock.assert_not_called()
        logging_module = import_object('torweb.logging')
        assert logging_module is logging
        info_mock.assert_called_once_with("importing %r", 'torweb.logging')
        info_mock.reset_mock()

# Generated at 2022-06-24 09:31:34.999681
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\s\S\d\D\w\W\b\B") == "\\s\\S\\d\\D\\w\\W\\b\\B"
    assert re_unescape(r"\t\r\n\f") == "\\t\\r\\n\\f"
    assert re_unescape(r"\a\A") == "\\a\\A"
    assert re_unescape(r"\(\)") == "\\(\\)"
    assert re_unescape(r"\1\2") == "\\1\\2"
    with pytest.raises(ValueError):
        re_unescape(r"\a")
    with pytest.raises(ValueError):
        re_unescape(r"\x")



# Generated at 2022-06-24 09:31:41.343740
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import threading

    class A(Configurable):
        is_configured = False

        def initialize(self):
            pass

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()
    assert isinstance(a, A)
    assert isinstance(b, B)
    assert isinstance(c, C)

    # Basic configuration.
    A.configure(C)
    a = A()
    assert isinstance(a, C)

    # Configuration from a string.

# Generated at 2022-06-24 09:31:52.648348
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    from functools import partial

    # Test a function with positional arguments.
    def func(a, b, c):
        return a, b, c

    a = ArgReplacer(func, "a")
    assert a.get_old_value(range(3), {}) == 0
    assert a.replace(42, range(3), {}) == (0, [42, 1, 2], {})
    assert ArgReplacer(func, "b").replace(43, [41, 2, 3], {}) == (
        2,
        [41, 43, 3],
        {},
    )
    assert ArgReplacer(func, "c").replace(44, [42, 43, 3], {}) == (
        3,
        [42, 43, 44],
        {},
    )

# Generated at 2022-06-24 09:31:58.543844
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    obj = GzipDecompressor()
    a = obj.decompress(b'abc')
    assert a == b'abc'
    a = obj.decompress(b'abc')
    assert a == b'abc'
    ob2 = GzipDecompressor()
    b = ob2.decompress(b'123')
    assert b == b'123'


# Generated at 2022-06-24 09:32:08.652270
# Unit test for function import_object
def test_import_object():
    import gzip
    from io import StringIO
    from tornado import escape
    import tornado
    import tornado.httpclient

    assert(import_object("gzip") is gzip)
    assert(import_object("StringIO") is StringIO)
    assert(import_object("tornado.escape") is escape)
    assert(import_object("tornado.escape.utf8") is escape.utf8)
    assert(import_object("tornado.httpclient") is tornado.httpclient)
    assert(import_object("tornado.ioloop") is tornado.ioloop)
    assert(import_object("tornado") is tornado)
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        # should raise exception
        assert False


# Fake unicode literal support:

# Generated at 2022-06-24 09:32:11.125485
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()

# Replace the names used in old versions of Tornado.
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:32:16.580863
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=10)) == 10.0
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(weeks=1)) == 7 * 86400.0
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001



# Generated at 2022-06-24 09:32:19.103426
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class AG:
        pass
    a = AG()
    ag = Configurable()
    ag.initialize(a)
    assert ag is a

# Generated at 2022-06-24 09:32:28.382755
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError("message")
    assert str(e) == "message"


# Alias the old names used by previous versions.
TimeoutError = TimeoutError
TimeoutError = TimeoutError

# All the types that we check for when doing isinstance(x, string_types)
string_types = (str, bytes)

# Not all versions of Python have the followings.
try:
    from collections import OrderedDict
except ImportError:
    from .ordereddict import OrderedDict  # type: ignore
try:
    from reprlib import repr
except ImportError:
    repr = repr



# Generated at 2022-06-24 09:32:33.296525
# Unit test for function exec_in
def test_exec_in():
    globals = dict(glob1=1)
    exec_in('glob2 = 2', globals)
    assert globals["glob2"] == 2
    exec_in('glob1 += 1; glob2 += 2', globals)
    assert globals["glob1"] == 2
    assert globals["glob2"] == 4

