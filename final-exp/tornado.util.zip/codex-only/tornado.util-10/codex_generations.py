

# Generated at 2022-06-24 09:22:41.381641
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class I(Configurable):
        @classmethod
        def configurable_base(cls):
            return I

        @classmethod
        def configurable_default(cls):
            return A

    class A(I):
        @classmethod
        def configurable_base(cls):
            return I

        @classmethod
        def configurable_default(cls):
            return A

    class B(I):
        @classmethod
        def configurable_base(cls):
            return I

        @classmethod
        def configurable_default(cls):
            return B

    class C(A):
        pass

    I.configure(C)
    assert isinstance(I(), C)
    I.configure(B)
    assert isinstance(I(), B)
    I.configure(A)


# Generated at 2022-06-24 09:22:43.781228
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # pragma: no cover
    assert TimeoutError('foo')

# Alias for backwards compatibility (also aliases
# tornado.ioloop.TimeoutError to tornado.util)
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:22:47.835185
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    o = ObjectDict()
    o.x = 1
    assert o.x == 1
    assert o["x"] == 1
    assert getattr(o, "x") == 1
    assert all(k in o for k in ("x", "__class__", "__doc__", "__getattr__", "__module__"))



# Generated at 2022-06-24 09:22:51.664015
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    suite = doctests()
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)


# These APIs were removed in Tornado 4.0; the definitions here
# exist to cause an exception to be raised so the deprecation message can be
# displayed.

# Generated at 2022-06-24 09:22:53.619699
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """Test method __new__ of class Configurable"""
    class C(Configurable): pass
    o = C()
    


# Generated at 2022-06-24 09:23:06.047154
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\.") == "."
    assert re_unescape("\\a") == "\x07"
    assert re_unescape("\\(").encode("ascii").decode("unicode_escape") == "("
    assert re_unescape("\\x00") == "\x00"
    assert re_unescape("\\x00") == "\x00"
    assert re_unescape("\\u0000") == "\x00"
    assert re_unescape("\\u0000") == "\x00"
    assert re_unescape("\\U00000000") == "\x00"
    assert re_unescape("\\001") == "\x01"
    assert re_unescape("\\10") == "\x08"
    assert re_unescape("\\011") == "\t"

# Generated at 2022-06-24 09:23:09.883128
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\A\b\C\d\f\N\r\s\t\\\v\w\W\Z\.") == "AB\fN\r \t\\\vwWZ."



# Generated at 2022-06-24 09:23:12.165629
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import unittest
    suite = doctests()
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-24 09:23:19.421489
# Unit test for function exec_in
def test_exec_in():
    x = 3
    exec_in("assert x == 4", {}, {'x': 4})            # type: ignore
    exec_in("assert x == 5", {'x': 5})                # type: ignore
    exec_in("x = 6", {})                              # type: ignore
    assert x == 3
    exec_in("global x; x = 7", globals())             # type: ignore
    assert x == 7
    exec_in("x = 8", {}, {'x': x})                    # type: ignore
    assert x == 7



# Generated at 2022-06-24 09:23:26.545870
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c=None, d=None):
        pass

    assert ArgReplacer(f, "a").arg_pos == 0
    assert ArgReplacer(f, "b").arg_pos == 1
    assert ArgReplacer(f, "c").arg_pos is None
    assert ArgReplacer(f, "d").arg_pos is None
    assert ArgReplacer(f, "x").arg_pos is None



# Generated at 2022-06-24 09:23:36.465415
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def __init__(self, foo=None):
            pass
        def configurable_base(cls):
            return A
        def configurable_default(cls):
            return A
    class B(A):
        def __init__(self, foo=None):
            pass
    class C(B):
        def __init__(self, foo=None, bar=None):
            pass

    A.configure(C, bar="baz")
    a = A()
    assert isinstance(a, C)
    assert a._bar == "baz"
    assert A.configured_class() is C

    b = B()
    assert isinstance(b, B)
    assert A.configured_class() is C

    A.configure(C, bar=None)
   

# Generated at 2022-06-24 09:23:42.183690
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is not a complete test, but if it doesn't crash it's probably ok.
    GzipDecompressor().decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
                                  b'\x4c\xcc\xcf\x07\x00\x00\x00')



# Generated at 2022-06-24 09:23:49.999113
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    ar = ArgReplacer(f, "b")
    assert ar.arg_pos == 1

    ar = ArgReplacer(f, "c")
    assert ar.arg_pos is None

    def f2(a, *v, **kw):
        pass

    ar = ArgReplacer(f2, "a")
    assert ar.arg_pos == 0

    ar = ArgReplacer(f2, "v")
    assert ar.arg_pos is None

    ar = ArgReplacer(f2, "kw")
    assert ar.arg_pos is None

    def f3(a=1, *v, **kw):
        pass

    ar = ArgReplacer(f3, "a")
    assert ar.arg_pos is None


# Generated at 2022-06-24 09:23:56.445053
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        def __init__(self, a: int, b: int = 5) -> None:
            self.a = a
            self.b = b
        def configurable_base(self):
            return TestConfigurable
        def configurable_default(self):
            return A
    class B(A):
        def __init__(self, a: int, b: int = 6, c: int = 7) -> None:
            super(B, self).__init__(a, b)
            self.c = c
    class C(A):
        def __init__(self, a: int, b: int = 7, c: int = 8) -> None:
            super(C, self).__init__(a, b)
            self.c = c

# Generated at 2022-06-24 09:24:05.716529
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None

    class ConfigurableSubclass(Configurable):
        pass

    class Subclass(ConfigurableSubclass):
        def initialize(self):
            pass

    class SubSubclass(Subclass):
        def initialize(self):
            pass

    Subclass.configure(Subclass)
    assert isinstance(Subclass(), Subclass)
    assert isinstance(Subclass(), ConfigurableSubclass)

    Subclass.configure(None)
    SubSubclass.configure(SubSubclass)
    assert isinstance(Subclass(), Subclass)
    assert isinstance(Subclass(), SubSubclass)
    assert isinstance(Subclass(), ConfigurableSubclass)
    # Unit test for method configurable_base of class Configurable

# Generated at 2022-06-24 09:24:07.144234
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 09:24:08.978835
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    o = ObjectDict({'test': 1})
    o.test == 1
    o['test'] == 1



# Generated at 2022-06-24 09:24:14.412276
# Unit test for function import_object
def test_import_object():
    assert import_object('tornado') is tornado
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    assert import_object('sys') is sys
    assert import_object('sys.stdin') is sys.stdin
    assert import_object('sys.modules') is sys.modules
    assert import_object('warnings') is warnings
    assert import_object('warnings.warn') is warnings.warn
    try:
        import_object('tornado.missing_module')
    except ImportError as e:
        assert e.args[0] == 'No module named missing_module'
    else:
        raise AssertionError('Did not raise ImportError')

_BYPASS_

# Generated at 2022-06-24 09:24:21.961999
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c):
        pass

    r = ArgReplacer(func, "b")
    assert r.get_old_value([1, 2, 3], dict(c=3)) == 2
    assert r.get_old_value([1, 2, 3], dict(c=3), 5) == 2
    assert r.get_old_value([1], dict(b=2, c=3)) == 2
    assert r.get_old_value([1], dict(b=2, c=3), 5) == 2
    assert r.get_old_value([1], dict(c=3), 5) == 5

    v, a, k = r.replace(4, [1, 2, 3], dict(c=3))
    assert v == 2
    assert a == [1, 4, 3]


# Generated at 2022-06-24 09:24:30.875298
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    d = GzipDecompressor()
    compressed_value = b"\x1f\x8b\x08\x08\x1b\x9c\x8f\x5c\x00\x03tornado\x00T\xcc\xce\xc9/\xcf/I-.Q\xe1\x02\x00p\x1b\xca\xef\x02\x00\x00\x00"
    assert d.decompress(compressed_value) == b"tornado"
    assert d.flus() == b""

# The following code works on cpython but not jython, which has
# outdated zlib support.  Even though it can't be used on jython,
# leaving it in so that it can be tested on cpython is a good idea.

# Generated at 2022-06-24 09:24:33.240596
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        ei = sys.exc_info()
        raise_exc_info(ei)



# Generated at 2022-06-24 09:24:39.504068
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    if doctest is None:
        raise unittest.SkipTest("doctest not found")
    import doctest

    tests = doctest.DocFileSuite(
        "common.rst",
        module_relative=False,
        setUp=lambda test: None,
        tearDown=lambda test: None,
    )
    tests.layer = None
    return tests

# Generated at 2022-06-24 09:24:44.781095
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This checks that the GzipDecompressor class can be constructed, but does not
    # test its functionality.  gzip_tests.py contains additional tests.
    GzipDecompressor()

# Aliases for functions in the stdlib functools module, where they
# exist.  In a few places we define our own implementations of these
# (especially partial) because functools' have memory leaks in some
# versions of Python and because functools' implementations don't allow
# keyword arguments in Python 2 and are significantly slower in
# Python 2 than in Python 3.


# Generated at 2022-06-24 09:24:53.134539
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def f(a, b, *args, **kwargs):
        pass
    args = (1, 2, 3, 4)
    kwargs = {"b": 20, "c": 30}
    a = ArgReplacer(f, "b")
    old_value, args, kwargs = a.replace(99, args, kwargs)
    assert old_value == 20
    assert args == (1, 99, 3, 4)
    assert kwargs == {"c": 30}



# Generated at 2022-06-24 09:25:05.013373
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import tornado.ioloop

    # Ensure that Configurable can be used as a base class
    # for an abstract class
    class ABC(Configurable):
        pass

    # Ensure that Configurable can be used as a base class
    # for a class with a __init__ method
    class WithInit(Configurable):
        def __init__(self):
            pass

    # Ensure that Configurable can be used as a base class
    # for a class with an initialize method
    class WithInitialize(Configurable):
        def initialize(self):
            pass

    # Ensure that Configurable can be used as a base class
    # for a class with a _initialize method
    class With_Initialize(Configurable):
        def _initialize(self):
            pass

    # Ensure that Configurable can be used as a base class
    # for a class with

# Generated at 2022-06-24 09:25:09.108469
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    d = GzipDecompressor()
    # Only for type checking
    assert isinstance(d.decompress(b'a'), bytes)


# Generated at 2022-06-24 09:25:17.994067
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    def create_test_gz(data_str):
        # Create a gzipped file using python's gzip module
        import gzip
        data_str = bytes(data_str, "UTF-8")
        gz_fp = gzip.GzipFile(mode="wb", fileobj=io.BytesIO())
        gz_fp.write(data_str)
        gz_fp.close()
        return gz_fp.fileobj.getvalue()

    data = 'A line of text\nOne more line\nLast line\n'
    testgz = create_test_gz(data)

    # Decompress it using GzipDecompressor
    gz_decomp = GzipDecompressor()
    result = gz_decomp.decompress(testgz)

# Generated at 2022-06-24 09:25:24.145936
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    decompressor = GzipDecompressor()
    decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
                            b'\xca\x48\xcd\xc9\xc9\x57\x28\xcf\x2f\xca'
                            b'\x49\x01\x00\x0b\x37\x05\x00\x00\x00')
    assert decompressor.flush() == b'hello'



# Generated at 2022-06-24 09:25:26.036139
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def f(a, b, c):
        pass
    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2



# Generated at 2022-06-24 09:25:28.362825
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    # test of method initialize
    IOLoop.configure(AsyncIOMainLoop)
    loop = IOLoop()
    assert isinstance(loop, AsyncIOMainLoop)


# Generated at 2022-06-24 09:25:32.825230
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError
    except TimeoutError:
        pass


try:
    from concurrent.futures import TimeoutError as _TimeoutError
except ImportError:
    pass
else:
    class _TimeoutError(TimeoutError, _TimeoutError):
        pass



# Generated at 2022-06-24 09:25:38.480320
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    try:
        import_object('tornado.missing_module')
        assert False
    except ImportError:
        pass
test_import_object()



# Generated at 2022-06-24 09:25:47.822595
# Unit test for function import_object
def test_import_object():
    import escape
    assert import_object("escape") is escape
    assert import_object("escape.utf8") is escape.utf8
    assert import_object("tornado.escape") is escape
    assert import_object("tornado.escape.utf8") is escape.utf8
    try:
        import_object("tornado.escape.nonexistent")
        assert False, "expected ImportError"
    except ImportError:
        pass
    try:
        import_object("nonexistent")
        assert False, "expected ImportError"
    except ImportError:
        pass
    try:
        import_object("")
        assert False, "expected ValueError"
    except ValueError:
        pass



# Generated at 2022-06-24 09:25:54.820809
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    assert isinstance(obj, ObjectDict)
    assert isinstance(obj, object)
    assert obj == {}
    obj.__setattr__("a", 42)
    obj.b = 1337
    assert obj.a == 42
    assert obj.b == 1337
    assert obj.get("a") == 42
    assert obj.get("b") == 1337
    assert obj.get("c") is None
    assert obj.get("c", 3.14) == 3.14
    obj2 = ObjectDict()
    obj2.foo = 42
    assert obj2.foo == 42



# Generated at 2022-06-24 09:25:57.342425
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d=dict(a=1,b=2)
    obj=ObjectDict(d)
    obj.__getattr__('b')
    obj.__getattr__('c')



# Generated at 2022-06-24 09:25:58.537873
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:26:09.516808
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    try:
        obj1 = ObjectDict(a=2, b=3)
        __temp_var_0 = ObjectDict()
        __temp_var_0.a = 2
        __temp_var_0.b = 3
        #assert obj1 == __temp_var_0
    finally:
        del __temp_var_0
    obj1.c = 4
    try:
        obj2 = ObjectDict(d=5)
        __temp_var_1 = ObjectDict()
        __temp_var_1.a = 2
        __temp_var_1.b = 3
        __temp_var_1.c = 4
        #assert obj1 == __temp_var_1
    finally:
        del __temp_var_1

# Generated at 2022-06-24 09:26:17.029371
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import types
    import inspect
    import unittest

    class A(object):
        pass

    class B(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def __setattr__(self, name, value):
            print("In __setattr__")
            object.__setattr__(self, name, value)
        def __getattribute__(self, name):
            print("In __getattribute__")
            return object.__getattribute__(self, name)
        def __new__(cls, x, y):
            a = object.__new__(cls)
            a.x = x
            a.y = y
            return a


# Generated at 2022-06-24 09:26:21.756919
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        class B(Configurable):
            def initialize(self, **kwargs):
                super(A.B, self).initialize(**kwargs)
            A.B.configure('tests.util.Configurable', a=None)


# Generated at 2022-06-24 09:26:23.859443
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise KeyError
    except KeyError:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-24 09:26:25.179013
# Unit test for function exec_in
def test_exec_in():
    exec_in('a = 6', {}, {'b': 7})



# Generated at 2022-06-24 09:26:33.037046
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo1(a, b = 2):
        return a, b

    def foo2(a, *vargs, b = 2):
        return a, vargs, b

    def foo3(a, b = 2, **kw):
        return a, b, kw

    def foo4(a, *vargs, b = 2, **kw):
        return a, vargs, b, kw

    def test_replace(foo, *vargs, **kw):
        ar = ArgReplacer(foo, "a")
        new_value = 100
        old_value, vargs, kw = ar.replace(new_value, vargs, kw)
        assert old_value == 1
        assert vargs == (100, )
        assert kw == {}

# Generated at 2022-06-24 09:26:41.318853
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import unittest

    from tornado.testing import AsyncTestCase
    from tornado.util import raise_exc_info

    class DocTestCase(AsyncTestCase):
        def test_doctests(self):
            # type: () -> None
            tests = doctests()
            for test in tests:
                if isinstance(test, doctest.DocTestCase):
                    test.globs["raise_exc_info"] = raise_exc_info

# Generated at 2022-06-24 09:26:51.568509
# Unit test for function exec_in
def test_exec_in():
    def test_exec(code, g=None, l=None):
        exec_in(code, g, l)

    # Non-global code with "global" variables
    g = dict(a=1)
    test_exec("b = 2", g)
    assert g == dict(a=1, b=2)
    test_exec("b += 3", g)
    assert g == dict(a=1, b=5)
    test_exec("b = b+1", g)
    assert g == dict(a=1, b=6)
    test_exec("b += b", g)
    assert g == dict(a=1, b=12)
    test_exec("b = a+b", g)
    assert g == dict(a=1, b=13)

    # "Nonlocal" variables
   

# Generated at 2022-06-24 09:27:00.961815
# Unit test for method flush of class GzipDecompressor

# Generated at 2022-06-24 09:27:02.181973
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    ObjectDict().__setattr__('foo', 'bar')



# Generated at 2022-06-24 09:27:07.964557
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    x = ObjectDict()
    x.name = 'Bob'
    assert x['name'] == 'Bob'
    assert x.name == 'Bob'
    assert x.last_name == 'Jone'


# Used in typing declarations
Function = typing.Callable[..., Any]
ContextManager = typing.ContextManager[Any]
RequestHandler = typing.Callable[
    [typing.Optional[Mapping[str, typing.Any]]], typing.Awaitable[None]
]

# Suppress this warning, which is not actionable in our code.
# (All our classes defined in Cython derive from object, so they
# should never trigger this warning.)
# flake8: noqa: E1015



# Generated at 2022-06-24 09:27:18.886541
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return B

        def initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    assert issubclass(A.configured_class(), A)
    assert A._save_configuration() == (None, None)
    A.configure(impl=C)
    assert issubclass(A.configured_class(), A)
    assert issubclass(A.configured_class(), C)
    assert A._save_configuration() == (C, {})
    A.configure(impl=B)
    assert issubclass(A.configured_class(), A)
    assert issubclass(A.configured_class(), B)

# Generated at 2022-06-24 09:27:22.774950
# Unit test for function exec_in
def test_exec_in():
    ns = {}
    exec_in("x = 1", ns)
    assert ns["x"] == 1
    ns = {}
    exec_in("y = 2", ns, ns)
    assert ns["y"] == 2



# Generated at 2022-06-24 09:27:31.565982
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def initialize(self):
            self.foo = 42

    class B(A):
        pass

    # Classes are not affected by the configuration of their base
    # classes before the first instance of either class is created.
    assert A.__impl_class is None
    assert B.__impl_class is None
    a1 = A()
    b1 = B()
    assert a1.foo == 42
    assert b1.foo == 42
    assert A.__impl_class is None
    assert B.__impl_class is None

    # Configuring the base class (whether before or after the instance
    # is created) affects the class of all its instances.

# Generated at 2022-06-24 09:27:43.744888
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c): pass
    mar = ArgReplacer(func, "a")
    assert mar.get_old_value((1, 2, 3), {}) == 1
    assert mar.get_old_value((1, 2, 3), {}, None) == 1
    assert mar.get_old_value((1, 2, 3), {}, default=None) == 1
    assert mar.get_old_value((), {'a': 1}) == 1
    assert mar.get_old_value((), {'a': 1}, None) == 1
    assert mar.get_old_value((), {'a': 1}, default=None) == 1
    assert mar.get_old_value((), {'a': 1}, default=3) == 1

# Generated at 2022-06-24 09:27:46.847690
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.b = 2
    obj.a = 1
    assert obj['b'] == 2
    assert obj['a'] == 1



# Generated at 2022-06-24 09:27:52.273045
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    """Test the constructor of ObjectDict class."""
    def test():
        d = ObjectDict()
        d.name = 'TestName'
        if d.name != 'TestName':
            raise Exception("Test failed")

    test()


# Dummy interface needed to reference the *_impl attributes on Configurable
# subclasses, which is necessary for mypy's type checking to work.

# Generated at 2022-06-24 09:27:55.996537
# Unit test for function import_object
def test_import_object():
    import tornado.escape
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utils.utf8
    assert import_object("tornado") is tornado
    with pytest.raises(ImportError):
        import_object("tornado.missing_module")



# Generated at 2022-06-24 09:28:02.304186
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    assert ObjectDict(a=1).a == 1  # type: ignore
    assert ObjectDict(b=2).b == 2  # type: ignore
    assert ObjectDict(c=3).c == 3  # type: ignore
    try:
        # deliberate failure
        oo = ObjectDict(d=4).d

        raise Exception("there should be no 'd'")  # pragma: nocover
    except AttributeError:
        pass



# Generated at 2022-06-24 09:28:07.567602
# Unit test for function import_object
def test_import_object():
    # No matter what our current working directory is, if we supply an
    # absolute path we should get the same module.
    assert import_object("sys") == sys
    assert import_object("/".join(__file__.split("/")[:-1]) + "/util.py") == util



# Generated at 2022-06-24 09:28:15.486412
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b): pass
    replacer = ArgReplacer(f, 'a')
    assert replacer.get_old_value(('x', 'y'), {}, None) == 'x'
    assert replacer.get_old_value(('x', 'y'), {}, 'y') == 'x'
    replacer = ArgReplacer(f, 'c')
    assert replacer.get_old_value(('x', 'y'), {}, None) == None
    assert replacer.get_old_value(('x', 'y'), {}, 'y') == 'y'
    replacer = ArgReplacer(f, 'b')
    assert replacer.get_old_value(('x',), {}, None) == None

# Generated at 2022-06-24 09:28:20.863614
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.2)) == 1.2
    assert timedelta_to_seconds(datetime.timedelta(microseconds=10)) == 0.00001



# Generated at 2022-06-24 09:28:31.204186
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_function(arg1, arg2=1, arg3=2, arg4=3): pass
    replacer = ArgReplacer(test_function, "arg2")
    # Test positional argument
    args = (1,)
    kwargs = {}
    old_value, args, kwargs = replacer.replace(5, args, kwargs)
    assert old_value == 1
    assert args == (1,)
    assert kwargs == {}
    # Test positional argument replaced with keyword
    args = (1,)
    kwargs = {}
    old_value, args, kwargs = replacer.replace(5, args, kwargs)
    assert old_value is None
    assert args == (1,)
    assert kwargs == {"arg2": 5}
    # Test keyword argument

# Generated at 2022-06-24 09:28:39.967822
# Unit test for function import_object
def test_import_object():
    assert import_object("os") is os
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    with pytest.raises(ImportError):
        import_object("tornado.missing_module")
    with pytest.raises(ImportError):
        import_object("missing_module")
    with pytest.raises(ImportError):
        import_object("missing_module.foo")


# Fake byte literal for non-ASCII bytes literals.  This is only used when
# byte literals are not supported by the current Python version, so any value
# is fine (it's ignored anyway).
# type: bytes

# Generated at 2022-06-24 09:28:50.754113
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    def func1(a, b):
        # type: (int, str) -> int
        return a + len(b)

    a = ArgReplacer(func1, "a")
    result = a.replace(5, (3, "hello"), {})
    assert result == (3, (5, "hello"), {})
    result = a.replace(5, (3, "hello"), {"a": 7})
    assert result == (7, (3, "hello"), {"a": 5})
    result = a.replace(5, (3, "hello"), {"a": 7, "b": "goodbye"})
    assert result == (7, (3, "hello"), {"a": 5, "b": "goodbye"})


# Generated at 2022-06-24 09:28:57.432332
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):
        def configurable_base(self):
            # type: () -> type
            return A

        def configurable_default(self):
            # type: () -> type
            return A

    a = A(a=1, b=2)
    assert a.a == 1
    # assert a.b == 2


# Generated at 2022-06-24 09:28:59.726518
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.__setattr__("x", 1)
    assert a["x"] == 1



# Generated at 2022-06-24 09:29:03.286512
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    def foo():
        # type: () -> None
        pass
    d = ObjectDict({'foo': foo})
    assert d.foo is foo

# Mostly for interactive use and debugging.

# Generated at 2022-06-24 09:29:09.574695
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def for_test_ArgReplacer_replace(x, y = 1, z = 2):
        return (x, y, z)
    args = (3,)
    kwargs = {'y': 4}
    argrp = ArgReplacer(for_test_ArgReplacer_replace, 'x')
    old_value, args1, kwargs1 = argrp.replace(10, args, kwargs)
    assert old_value == 3
    assert args1 == (10,)
    assert kwargs1 == {'y': 4}
    # Test that the old positional argument is replaced by key word
    kwargs2 = {'x': 5}
    argrp = ArgReplacer(for_test_ArgReplacer_replace, 'x')
    old_value, args2, kwargs2 = argr

# Generated at 2022-06-24 09:29:21.226718
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # type: () -> None
    import binascii
    # test case 1:
    g = GzipDecompressor()
    t = g.decompress(binascii.a2b_hex("1f8b0800000000000000bcb4bcc4db57db16e170072f93cf0f"))

# Generated at 2022-06-24 09:29:26.551039
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(arg1, arg2=None):
        pass

    d = {}
    obj = ArgReplacer(foo, "arg2")
    assert obj.get_old_value((), d, "default") == "default"
    assert obj.get_old_value((), {}, "default") == "default"

    d = {"arg2": "hello"}
    assert obj.get_old_value((), d, "default") == "hello"




# Generated at 2022-06-24 09:29:28.772035
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    od = ObjectDict()
    od.x = 1
    assert od.x == 1
    assert od == {"x": 1}



# Generated at 2022-06-24 09:29:32.804697
# Unit test for function raise_exc_info
def test_raise_exc_info():
    class TestException(Exception):
        pass
    exc_info = (None, TestException(), None)
    try:
        raise_exc_info(exc_info)
    except TestException:
        pass



# Generated at 2022-06-24 09:29:41.197520
# Unit test for function re_unescape

# Generated at 2022-06-24 09:29:44.818818
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    try:
        import zlib
    except ImportError:  # pragma: nocover
        zlib = None  # type: ignore
    if zlib:
        GzipDecompressor()



# Generated at 2022-06-24 09:29:48.204002
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except Exception:
        pass

# Deprecated aliases
TimeoutError_0_4 = TimeoutError
TimeoutError_4_0 = TimeoutError



# Generated at 2022-06-24 09:29:49.883197
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    pass
    # TODO Test case for method ObjectDict.__setattr__ not yet implemented



# Generated at 2022-06-24 09:29:55.065909
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    def _getattr__(name: str) -> None:
        # type: (str) -> Any
        d = ObjectDict()
        d["x"] = 42
        v = d.x
        assert v == 42
    _getattr__("x")



# Generated at 2022-06-24 09:29:56.490426
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test(a, b, c):
        pass
    ArgReplacer(test, 'a').replace(123, [456], {})



# Generated at 2022-06-24 09:30:04.788606
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls

        @classmethod
        def configurable_default(cls):
            return cls

        def initialize(self, a: int, b: int) -> None:
            self.a = a
            self.b = b

    class Sub(Base):
        def initialize(self, *args: Any, **kwargs: Any) -> None:
            # This calls `.initialize`, but the `self` argument is
            # ignored because the superclass is not a Configurable.
            super(Sub, self).initialize(*args, **kwargs)
            self.c = 3

    assert issubclass(Sub, Base)
    assert Sub.configurable_default() is Base
    assert Sub.configurable_base() is Base

# Generated at 2022-06-24 09:30:06.539884
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import unittest.mock

    with unittest.mock.patch("tornado.util.timedelta_to_seconds") as m:
        doctests()
        assert m.called



# Generated at 2022-06-24 09:30:15.163079
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from types import FunctionType
    from typing import get_type_hints
    from .httpclient import SimpleAsyncHTTPClient
    from .testing import AsyncHTTPTestCase
    from .web_test_testcase import WebTestTestCase
    class A(Configurable):
        def configurable_base(self):
            return A
        def configurable_default(self):
            return B
        def _initialize(self, *args: int, **kwargs: int):
            pass
    class B(A):
        pass
    class C(A):
        pass
    class TestA(WebTestTestCase, AsyncHTTPTestCase):
        @classmethod
        def setUpClass(cls):
            super(TestA, cls).setUpClass()
            cls.saved_conf = A._save_configuration()
            A

# Generated at 2022-06-24 09:30:17.533608
# Unit test for function exec_in
def test_exec_in():
    a = "foo"
    exec_in("a = \"bar\"", globals())
    assert a == "bar"



# Generated at 2022-06-24 09:30:22.456736
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = {"a": 1}
    d = ObjectDict(d)
    assert int(d["a"]) == 1
    assert int(d.a) == 1
    try:
        assert int(d.b) == 2
        assert False
    except AttributeError as e:
        assert str(e) == "b"


# Generated at 2022-06-24 09:30:27.122461
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c=None, d=None):
        pass

    assert ArgReplacer(func, "c").arg_pos is None
    assert ArgReplacer(func, "b").arg_pos == 1
    assert ArgReplacer(func, "a").arg_pos == 0



# Generated at 2022-06-24 09:30:34.370641
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # type: () -> None
    # ProtocolType is not defined earlier
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    ioloop_obj = IOLoop()
    ArgReplacer1 = ArgReplacer(HTTPServer, "ssl_options")
    old_value, args, kwargs = ArgReplacer1.replace(
        {"certfile": "a"}, (ioloop_obj,), {}
    )
    assert old_value is None
    assert args == (ioloop_obj,)
    assert kwargs == {"ssl_options": {"certfile": "a"}}



# Generated at 2022-06-24 09:30:37.346195
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    import inspect

    def foo(a, b=2):
        pass

    def bar(c, d = 4):
        pass

    ArgReplacer.get_old_value(inspect.getargspec(foo).args, 3, foo)
    ArgReplacer.get_old_value(inspect.getargspec(bar).args, 4, bar)


# Generated at 2022-06-24 09:30:42.346685
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    value = [b'98;\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x08\xc2\xd9{X\x10\x84\x07\xd6', b'!\x91\x00\x00\x00']
    decompressor = GzipDecompressor()
    # decompress each of the value
    for v in value:
        decompressor.decompress(v)
    # get unconsumed tail
    unconsumed_tail = decompressor.unconsumed_tail
    # flush
    decompressed_data = decompressor.flush()
    # expected result
    expected_result = b'\xf0\x9f\x98;'
    # test result
    assert decompressed_data == expected

# Generated at 2022-06-24 09:30:47.777033
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(a, b, c=3, d=4):
        return a

    f = ArgReplacer(foo, "c")
    old, args, kwargs = f.replace(5, (1, 2), {"d": 1})
    assert old == 3 and args == (1, 2) and kwargs == {"d": 1}
    args, kwargs = f.replace(6, args, kwargs)
    assert args == (1, 2) and kwargs == {"d": 1, "c": 6}
    f = ArgReplacer(foo, "x")
    assert f.get_old_value((1, 2), {"d": 1, "x": 10}, 99) == 10
    args, kwargs = f.replace(11, (1, 2), {"d": 1})

# Generated at 2022-06-24 09:30:49.331684
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    TimeoutError("message")  # type: ignore
assert test_TimeoutError() is None



# Generated at 2022-06-24 09:30:53.359509
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 24 * 60 * 60

# Generated at 2022-06-24 09:30:56.087103
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()
    TimeoutError(None, foo=1)
    TimeoutError('abc')


# aliases for backward compatibility
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:31:02.073325
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert(errno_from_exception(e) is None)
    try:
        raise Exception('foo')
    except Exception as e:
        assert(errno_from_exception(e) == 'foo')
    try:
        raise Exception('foo', 'bar')
    except Exception as e:
        assert(errno_from_exception(e) == 'foo')
    try:
        raise IOError
    except IOError as e:
        assert(errno_from_exception(e) is None)
    try:
        raise IOError(123)
    except IOError as e:
        assert(errno_from_exception(e) == 123)

# Generated at 2022-06-24 09:31:04.559903
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from tornado.test.util import unittest

    unittest.TextTestRunner().run(doctests())



# Generated at 2022-06-24 09:31:15.446002
# Unit test for constructor of class Configurable
def test_Configurable():
    class C(Configurable):
        # Can't use @classmethod as decorator until python 2.4.
        def configurable_base(cls):
            return C

        def configurable_default(cls):
            return CDefault

        def initialize(self, arg):
            self.arg = arg

    # This one shouldn't be called.
    called = []  # type: List[int]

    class CDefault(C):
        def initialize(self):
            called.append(1)

    class CSub1(C):
        def initialize(self, arg):
            self.arg = [arg]

    class CSub2(C):
        def initialize(self, arg):
            self.arg = arg

    assert isinstance(C(1), CDefault)
    assert isinstance(C(1), C)


# Generated at 2022-06-24 09:31:20.221263
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class TopLevel(Configurable):
        # type: ignore
        pass

    class A(TopLevel):
        # type: ignore
        pass

    class B(TopLevel):
        # type: ignore
        pass

    class C(A):
        # type: ignore
        pass

    A.configure(B)
    instance = A()
    assert isinstance(instance, B)



# Generated at 2022-06-24 09:31:25.090106
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
  # Test that the __init__ of a class indirectly inheriting from
  # Configurable is not executed if the class is not an instance of
  # the base class.

  class Base(Configurable):
      def initialize(self, called=False):
          called = True

      @classmethod
      def configurable_base(cls):
          return Base

      @classmethod
      def configurable_default(cls):
          return Base

  class Derived(Base):
      def initialize(self, called=False):
          assert called is True

  Derived()



# Generated at 2022-06-24 09:31:25.641451
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    pass

# Generated at 2022-06-24 09:31:33.420074
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    a, b, c = 1, 2, 3
    def testfunc(a, b, c=3, *args, **kwargs):
        pass
    arg = ArgReplacer(testfunc, "a")
    oldvalue, args, kwargs = arg.replace(5, (a, b), {'c': c})
    assert oldvalue == a
    assert args == (5, b)
    assert kwargs == {'c': c}
    oldvalue, args, kwargs = arg.replace(5, (a, b, c), {})
    assert oldvalue == a
    assert args == (5, b, c)
    assert kwargs == {}
    oldvalue, args, kwargs = arg.replace(5, (b, c), {'a': a})
    assert oldvalue == a

# Generated at 2022-06-24 09:31:36.977133
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise_exc_info((ValueError, ValueError("foo"), None)) # noqa: F821
    except ValueError as e:
        assert str(e) == "foo"
    else:
        raise AssertionError("did not raise")



# Generated at 2022-06-24 09:31:40.451426
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise Exception("foobar")
    except:
        raise_exc_info(sys.exc_info())

# Fake value for exception arguments used in the following doctest.
_DOCTEST_SENTINEL = object()



# Generated at 2022-06-24 09:31:50.803923
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    test_val = b'\x1f\x8b\x08\x08M\xed\x95\x9c2\x00\x03test.txt\x00\x1b\x1b\x91' \
               b'\xa4\x02\xe1E\xfc\xffr\x00\x01\x95\x1b\x00\x00\x00'

    decompressor = GzipDecompressor()
    decomp_val = decompressor.decompress(test_val)
    assert decomp_val == b"hello world!\n"
    assert decompressor.unconsumed_tail == b''
    assert decompressor.flush() == b''



# Generated at 2022-06-24 09:31:57.856666
# Unit test for function import_object
def test_import_object():
    import_object("sys")
    import_object("sys.modules")
    import_object("sys.modules['sys']")
    import_object("tornado.escape")
    import_object("tornado.escape.utf8")
    import_object("tornado.escape.utf8")
    import_object("tornado.escape.utf8")


_FILEPATH_REGEX = re.compile(r"([A-Za-z]:)?(?:.*/)?(.*)")



# Generated at 2022-06-24 09:32:00.035422
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()


# These constants may also be used as return values from
# IOLoop.add_timeout and IOLoop.add_callback to avoid needing to
# import the ioloop package.

# Generated at 2022-06-24 09:32:06.491156
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def foo(x, y, z=3, *args, **kwargs):
        pass

    def bar(y, x, z=5, *args, **kwargs):
        pass

    x_arg = ArgReplacer(foo, "x")
    assert x_arg.get_old_value((1, 2, 3), {}) == 1
    assert x_arg.get_old_value((1, 2, 3), {}, default=4) == 1
    assert x_arg.get_old_value((1,), {}, 4) == 4
    assert x_arg.get_old_value((1,), {"x": 4}) == 4

    old_value, args, kwargs = x_arg.replace(4, (1, 2, 3), {})
    assert old_value == 1

# Generated at 2022-06-24 09:32:12.449734
# Unit test for function raise_exc_info
def test_raise_exc_info():  # type: () -> None
    try:
        raise_exc_info((None, TypeError("foo"), None))
    except TypeError:
        pass
    try:
        raise_exc_info((None, ValueError, None))
    except TypeError:
        pass
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass
    try:
        raise_exc_info((None, ValueError(), None))
    except ValueError:
        pass



# Generated at 2022-06-24 09:32:13.954911
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        pass


Foo.initialize()


# Generated at 2022-06-24 09:32:20.927832
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    def test(**kwargs):
        assert timedelta_to_seconds(datetime.timedelta(**kwargs)) == datetime.timedelta(**kwargs).total_seconds()
    test(weeks=0)
    test(weeks=1)
    test(weeks=2)
    test(days=1)
    test(days=2)
    test(hours=1)
    test(minutes=1)
    test(seconds=1)
    test(microseconds=1)



# Generated at 2022-06-24 09:32:32.970736
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(*args, **kwargs):
        return

    ar = ArgReplacer(foo, "d")
    print(ar.get_old_value(("a", "b", "c"), {"d": "dd", "e": "ee"}))
    print(ar.get_old_value(("a", "b", "c"), {}))
    print(ar.get_old_value(("a", "b", "c"), {}, default = "cc"))
    print(ar.get_old_value(("a", "b"), {"d": "dd", "e": "ee"}))
    print(ar.get_old_value(("a", "b"), {}))
    print(ar.get_old_value(("a", "b"), {}, default = "cc"))