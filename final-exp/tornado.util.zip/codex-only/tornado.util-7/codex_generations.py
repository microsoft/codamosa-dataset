

# Generated at 2022-06-24 09:22:42.887299
# Unit test for function re_unescape
def test_re_unescape():
    if sys.version_info < (3, 6):
        # Python < 3.6 sorts dicts like we do (lexically by key).
        # Python 3.6 adds randomization to dict iteration order,
        # causing this test to fail.
        assert re_unescape("a") == "a"
        assert re_unescape("a?") == "a?"
        assert re_unescape("a\\") == "a\\"
        assert re_unescape("a\\?") == "a?"
        assert re_unescape("a\\z") == "a\\z"
        with pytest.raises(ValueError):
            re_unescape("a\\d")
        with pytest.raises(ValueError):
            re_unescape("\\?")

# Generated at 2022-06-24 09:22:47.358910
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    from tornado.util import ObjectDict
    from tornado import escape

    tests = doctests()

    escape.xhtml_unescape("")  # not tested by doctests
    tests.addTest(doctest.DocTestSuite(escape))

    tests.addTest(doctest.DocTestSuite(ObjectDict))
    return tests



# Generated at 2022-06-24 09:22:56.069405
# Unit test for function errno_from_exception
def test_errno_from_exception():
    class ExceptionWithErrno(Exception):
        def __init__(self, error_number, message):
            super().__init__(message)
            self.errno = error_number


    class ExceptionWithArgs(Exception):
        def __init__(self, error_number, message):
            super().__init__(message)
            self.args = (error_number, message)


    class ExceptionWithErrnoAndArgs(Exception):
        def __init__(self, error_number, message):
            super().__init__(message)
            self.errno = error_number
            self.args = (error_number, message)


    assert errno_from_exception(ExceptionWithErrno(1, "test message")) == 1

# Generated at 2022-06-24 09:23:00.116721
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    test_arg_replacer = ArgReplacer(lambda x, y=10 : x+ y, 'y')
    test_arg_replacer.get_old_value((1,), {})
    #assert


# Generated at 2022-06-24 09:23:06.746612
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    e = TimeoutError('foo')

# Export the most common Exception classes.
from concurrent.futures._base import CancelledError  # type: ignore

from tornado.log import gen_log

# Dummy objects representing threads for functions that use them
_DummyThread = None
_DummyThreadLock = None
_DummyThreadTokens = dict()  # type: Dict[str, Any]



# Generated at 2022-06-24 09:23:15.575062
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    #from time import time
    #t0 = time()
    args = ["apple", "orange", "banana"]
    kwargs = {"more": ["melon"], "func": lambda x: x}
    ar = ArgReplacer(test_ArgReplacer_get_old_value, "args")
    assert ar.get_old_value(args, kwargs, []) == args
    #print(time() - t0)
    args = ["apple", "orange", "banana"]
    kwargs = {"more": ["melon"], "func": lambda x: x}
    ar = ArgReplacer(ArgReplacer.get_old_value, "args")
    assert ar.get_old_value(args, kwargs, []) == args
    #print(time() - t0)

# Generated at 2022-06-24 09:23:22.370878
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # Fixture
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(mcs):
            return mcs

        @classmethod
        def configurable_default(mcs):
            return mcs

        @classmethod
        def configure(mcs, impl, **kwargs):
            pass

        @classmethod
        def configured_class(mcs):
            return mcs

    class TestSubclass(TestConfigurable):
        def __init__(self, *args, **kwargs):
            self.initialize(*args, **kwargs)

        def initialize(self):
            pass

    # Tests
    TestSubclass()



# Generated at 2022-06-24 09:23:33.490637
# Unit test for method decompress of class GzipDecompressor

# Generated at 2022-06-24 09:23:35.886735
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(2)
    except Exception as e:
        assert errno_from_exception(e) == 2



# Generated at 2022-06-24 09:23:42.222907
# Unit test for function exec_in
def test_exec_in():
    def f(x):
        if x == 1:
            exec("a = 5")
        else:
            exec("a = 6", {}, {})
        return a
    assert f(1) == f(2) == 6
# This is a function instead of a method to make sure no references are
# kept to the RequestHandler class.  This is important in
# asynchronous servers where RequestHandlers may be deleted before
# their __del__ method runs.

# Generated at 2022-06-24 09:23:51.063026
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    import io
    import gzip

    # this code is from stackoverflow
    def non_blocking_gzip_decompress(data):
        # type: (bytes) -> bytes
        """Decompresses a gzip compressed bytestring (non-blocking)

        This is useful for decoding streamed gzip responses.

        The interface is very similar to zlib.decompress except that
        it doesn't take in the wbits argument.

        Args:
            data: The gzip compressed bytestring
        Returns:
            The decompressed bytestring
        """

        decompressor = GzipDecompressor()
        # Get the first decompressed chunk
        chunk = decompressor.decompress(data)

        # If the whole data was decompressed, return it
        if not decompressor.unconsumed_tail:
            return chunk + decompressor

# Generated at 2022-06-24 09:24:02.874489
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=22, d=33):
        pass
    r = ArgReplacer(func, "c")
    assert r.get_old_value(args=[1, 2], kwargs={}) == 22
    assert r.get_old_value(args=[1, 2], kwargs={'a':1}) == 22
    assert r.get_old_value(args=[1, 2], kwargs={'c':1}) == 1
    assert r.get_old_value(args=[1, 2], kwargs={'c':1, 'd':3}) == 1
    assert r.get_old_value(args=[1, 2], kwargs={'c':1}, default=33) == 1
    r = ArgReplacer(func, "e")
    assert r.get_old_

# Generated at 2022-06-24 09:24:13.825249
# Unit test for function import_object
def test_import_object():
    from io import BytesIO

    # Relative import
    from . import escape
    assert import_object(".escape") is escape
    assert import_object(".escape.utf8") is escape.utf8

    # Absolute import
    assert import_object("tornado.escape") is escape
    assert import_object("tornado.escape.utf8") is escape.utf8

    # ImportError wrapped in ImportError (for some reason)
    try:
        import_object("tornado.missing_module")
    except ImportError as e:
        if e.args[0].startswith("No module named"):
            pass
        else:
            assert False, "wrong ImportError"

    # Ensure that non-None __doc__ is preserved.
    assert BytesIO.__doc__



# Generated at 2022-06-24 09:24:15.726144
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    a = ObjectDict()
    a["12"] = "test"
    assert a.__getattr__("12") is "test"
    try:
        a.__getattr__("13")
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-24 09:24:21.837324
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # type: () -> None
    gd = GzipDecompressor()
    assert gd.decompress(b"123") == b""
    assert gd.flush() == b""
    assert gd.decompress(b"456") == b"456"
    assert gd.flush() == b""



# Generated at 2022-06-24 09:24:23.854087
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    # Sanity check to make sure the doctests make sense
    suite = doctests()
    runner = unittest.TextTestRunner()
    runner.run(suite)



# Generated at 2022-06-24 09:24:32.457022
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    uncompressed = b'abcde'
    compressed = b''.join([b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff',
                           b'\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00',
                           b'\x0b\x03\x00\x00\x00'])
    gzipper = GzipDecompressor()
    decompressed1 = gzipper.decompress(compressed)
    assert decompressed1 == uncompressed
    assert gzipper.unconsumed_tail == b''
    try:
        gzipper.flush()
    except:
        pass
    else:
        raise AssertionError("flush failed to raise exception")


# Generated at 2022-06-24 09:24:38.676056
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def myfun(x, y, z):
        print("x={}, y={}, z={}".format(x, y, z))

    myfun(x=1, y=2, z=3)
    replacer = ArgReplacer(myfun, "x")
    (old_value, new_args, new_kwargs) = replacer.replace("new_value", args=(0,), kwargs={"y":0, "z":0})
    myfun(*new_args, **new_kwargs)

test_ArgReplacer_replace()

# Type hint for an immutable mapping that can be used for type
# checking. The constructor is deliberately not exposed, so the only
# way to construct one is to cast from Mapping[str, Any].
ImmutableDict = collections.abc.Mapping  # type: Type[

# Generated at 2022-06-24 09:24:39.259282
# Unit test for function import_object

# Generated at 2022-06-24 09:24:45.584370
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(2)
    except IOError as e:
        errno_from_exception(e)
    # Use the errno directly
    try:
        raise IOError
    except IOError as e:
        errno_from_exception(e)
    # Raise without errno or args
    try:
        raise IOError
    except IOError as e:
        errno_from_exception(e)



# Generated at 2022-06-24 09:24:51.374084
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj["name"] = "isabel"
    assert obj.name == "isabel"
    assert hasattr(obj, "name") == True
    assert getattr(obj, "name") == "isabel"




DEFAULT_MAX_WAIT_SECONDS: int = 5



# Generated at 2022-06-24 09:25:03.355039
# Unit test for constructor of class Configurable
def test_Configurable():
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C1

        def initialize(self, **kwargs):
            self.initialized_with = kwargs

    class C1(C):
        def initialize(self, **kwargs):
            super(C1, self).initialize(one=1, **kwargs)

    class C2(C):
        def initialize(self, **kwargs):
            super(C2, self).initialize(two=2, **kwargs)

    c = C()
    assert isinstance(c, C1)
    assert c.initialized_with == dict(one=1)
    c = C(x=4)

# Generated at 2022-06-24 09:25:08.912835
# Unit test for function import_object
def test_import_object():
    def f():pass
    assert import_object('test_typing.test_import_object') == test_import_object
    assert import_object('test_typing.test_import_object.f') == f
    assert import_object('test_typing') == __import__('test_typing')
    assert import_object('test_typing.test_typing') == __import__('test_typing.test_typing')


# Generated at 2022-06-24 09:25:16.934548
# Unit test for function re_unescape
def test_re_unescape():
    # Basic alphanum:
    assert re_unescape(r"\a\b\c") == "abc"
    # Bytes:
    assert re_unescape(r"\x00\x01\x02") == "\0\x01\x02"
    # Unicode:
    assert re_unescape(r"\u0000\u0001\u0002") == "\0\x01\x02"
    # Exceptions:
    with pytest.raises(ValueError):
        re_unescape(r"\d")  # invalid
        re_unescape(r"\1")  # non-octal digit
        re_unescape(r"\800")  # out of range



# Generated at 2022-06-24 09:25:18.624514
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import_object.func_code = test_Configurable_initialize.func_code


# Generated at 2022-06-24 09:25:20.677986
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f():
        yield

    try:
        f().close()
    except GeneratorExit:
        type_, value, traceback = sys.exc_info()
        raise_exc_info((type_, value, traceback))



# Generated at 2022-06-24 09:25:32.161022
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    from tornado import escape
    d = ObjectDict(x=1)
    d.y = 2
    assert d == escape.json_decode("""{"x": 1, "y": 2}""")
    assert d.x == 1
    assert d.y == 2
    assert d['x'] == 1
    assert d['y'] == 2
    assert d.get('x') == 1
    assert d.get('y') == 2
    assert d.get('z') is None
    assert d.get('z', 3) == 3
    assert d.get('z', 3) == 3
    assert isinstance(d, dict)
    assert isinstance(d, Mapping)
    assert isinstance(d, typing.MutableMapping)
    assert isinstance(d, ObjectDict)

# Generated at 2022-06-24 09:25:33.411283
# Unit test for function exec_in
def test_exec_in():
    scope = {}
    exec_in('x = 42', scope)
    assert scope['x'] == 42



# Generated at 2022-06-24 09:25:42.563667
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gz_decompressor = GzipDecompressor()
    compressed_text = gz_decompressor.decompress(b'Ivan is a young man.\n')
    assert compressed_text == b'Ivan is a young man.'
    assert gz_decompressor.unconsumed_tail == b'\n'
    written_text = 'Ivan is a young man.\n'
    compressed_text = gz_decompressor.decompress(written_text.encode())
    assert compressed_text == b''
    assert gz_decompressor.unconsumed_tail == b''
    

# Generated at 2022-06-24 09:25:44.000118
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()

# Generated at 2022-06-24 09:25:53.240808
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Descendant(Configurable):
        @classmethod
        def configurable_base(cls):
            return Descendant

        @classmethod
        def configurable_default(cls):
            return Descendant

    d = Descendant()
    assert isinstance(d, Descendant)
    init_kwargs = {}  # type: Dict[str, Any]

    class Descendant(Configurable):
        @classmethod
        def configurable_base(cls):
            return Descendant

        @classmethod
        def configurable_default(cls):
            return Descendant

        def initialize(self, *args: Any, **kwargs: Any) -> None:
            init_kwargs.update(kwargs)

    d = Descendant(foo='bar')

# Generated at 2022-06-24 09:25:58.180738
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"a\[b\]c\,d") == "a[b]c,d"
    assert re_unescape(r"a\[b\]c\,d\.*e\,f") == "a[b]c,d.*e,f"

    with pytest.raises(ValueError):
        re_unescape(r"\d")



# Generated at 2022-06-24 09:26:08.333431
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(13, "Perm denied")
    except OSError as e:
        assert errno_from_exception(e) == 13

    try:
        raise OSError("Baz")
    except OSError as e:
        assert errno_from_exception(e) == "Baz"

    try:
        raise OSError()
    except OSError as e:
        assert not errno_from_exception(e)

    try:
        raise Exception("Foo")
    except Exception as e:
        assert not errno_from_exception(e)
# /Unit test for function errno_from_exception



# Generated at 2022-06-24 09:26:16.258149
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import pytest
    from tornado import gen
    from tornado.web import Application

    class Handler(Configurable):
        # Inheritance means that Handler.configurable_base() is
        # Application, so these keys should be independent of each
        # other.
        _saved_Application = None
        _saved_handler = None

        def __new__(cls, *args, **kwargs):
            print("Handler.__new__()")
            return super(Handler, cls).__new__(cls, *args, **kwargs)

        def __init__(self, *args, **kwargs):
            print("Handler.__init__()")
            self.initialize(*args, **kwargs)

        def initialize(self, *args, **kwargs):
            print("Handler.initialize()")

# Generated at 2022-06-24 09:26:27.198607
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    f = GzipDecompressor()
    f.flush()

    # Verify that unconsumed_tail gets cleared.
    f.decompress(b"foo")
    assert f.unconsumed_tail == b"foo"
    f.flush()
    assert f.unconsumed_tail == b""

    # Real-world example from a StackOverflow post
    f = GzipDecompressor()

# Generated at 2022-06-24 09:26:28.997744
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj.foo = 'bar'
    assert obj.foo == 'bar'
    with pytest.raises(AttributeError):
        obj.missing  # noqa: B001  # pragma: nocover



# Generated at 2022-06-24 09:26:31.002931
# Unit test for function exec_in
def test_exec_in():
    loc = {}
    exec_in("def foo(): pass", globals(), loc)
    assert "foo" in loc
    assert "__builtins__" not in loc



# Generated at 2022-06-24 09:26:33.706927
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    assert isinstance(e, TimeoutError)
    assert isinstance(e, Exception)



# Generated at 2022-06-24 09:26:38.297214
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\/") == "/"
    assert re_unescape(r"\\") == "\\"
    assert re_unescape(r"\d") == "d"
    assert re_unescape(r"\x5c") == r"\x5c"
    with pytest.raises(ValueError):
        re_unescape(r"\d")



# Generated at 2022-06-24 09:26:47.188013
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Test(Configurable):
        def configurable_base(cls): return Test

        def configurable_default(cls): return TestImpl

        def initialize(self, *args, **kwargs):
            pass

    class TestImpl:
        def initialize(self, *args, **kwargs):
            pass
    Test.configure(None)
    instance = Test()
    assert isinstance(instance, TestImpl)
    assert not isinstance(instance, Test)
    with pytest.raises(ValueError):
        Test.configure(object)



# Generated at 2022-06-24 09:26:50.675200
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    e = TimeoutError()
    assert str(e) == ""
    e = TimeoutError("foo")
    assert str(e) == "foo"
    e = TimeoutError("bar", "baz")
    assert str(e) == "bar, baz"



# Generated at 2022-06-24 09:26:54.582836
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a,b):
        pass
    arg_replacer=ArgReplacer(test,"a")
    assert arg_replacer.get_old_value((1,2),{},"default")==1
    assert arg_replacer.get_old_value((),{'a':1},"default")==1
    assert arg_replacer.get_old_value((),{'b':2},"default")=="default"
    def test_2(a,b=1):
        pass
    assert arg_replacer.get_old_value((),{},"default")=="default"

# Generated at 2022-06-24 09:27:01.432964
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls): return Base

        @classmethod
        def configurable_default(cls): return Impl1

    class Impl1(Base):
        pass

    class Impl2(Base):
        pass

    assert isinstance(Base(), Base)
    assert isinstance(Base(), Impl1)
    assert not isinstance(Base(), Impl2)
    assert Base.configured_class() is Impl1
    assert not hasattr(Base, "initialize")

    Base.configure(Impl2)
    assert isinstance(Base(), Base)
    assert not isinstance(Base(), Impl1)
    assert isinstance(Base(), Impl2)
    assert Base.configured_class() is Impl2

    Base.configure(None)

# Generated at 2022-06-24 09:27:08.516773
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def test_flush_data():
        gzip_decompressor = GzipDecompressor()
        data = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\xaa\xaa\xcd\xc8\x2c\x56\x00\xfb\x2f\x0f\x05\x00\x00\x00"
        result = gzip_decompressor.flush()
        assert result == b"aaaaaaaaaa"
    test_flush_data()


# Generated at 2022-06-24 09:27:11.583506
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.attr = "'attr' value"
    assert(d['attr'] == d.attr)
    assert(d.attr == "'attr' value")
    assert(d.dict_key == "'dict_key' value")


# Generated at 2022-06-24 09:27:17.798394
# Unit test for constructor of class Configurable
def test_Configurable():

    # BaseConfigurable and SubConfigurable exist only so the
    # Configurable metaclass will insert __impl_class and __impl_kwargs.
    # Using type() here is easier than defining metaclasses for
    # BaseConfigurable and SubConfigurable.
    class BaseConfigurable(Configurable, metaclass=Configurable):
        @classmethod
        def configurable_base(self):
            return BaseConfigurable

        @classmethod
        def configurable_default(self):
            return SubConfigurable

    class SubConfigurable(BaseConfigurable):
        def __init__(self, x, y, z=5, **kw):
            self.x = x
            self.y = y
            self.z = z
            self.kw = kw

    # Test that we can instantiate the configured class.
    BaseConfigurable.config

# Generated at 2022-06-24 09:27:22.114380
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # type: () -> None
    # noop, documented to check that class exists
    pass

# add a few aliases for compatibility with older tornado versions
TimeoutError.TimeoutError = TimeoutError
TimeoutError.Timeout = TimeoutError
TimeoutError.TimeoutException = TimeoutError



# Generated at 2022-06-24 09:27:25.643051
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
        assert exc_info[1] is not None
        raise_exc_info(exc_info)



# Generated at 2022-06-24 09:27:27.922026
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise TypeError()
    except TypeError as e:
        raise_exc_info(typing.cast(tuple, sys.exc_info()))



# Generated at 2022-06-24 09:27:30.063044
# Unit test for function doctests
def test_doctests():
    # type: () -> unittest.TestSuite
    import doctest

    return doctest.DocTestSuite()  # pragma: no cover



# Generated at 2022-06-24 09:27:32.489083
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 1
    assert d.foo == 1
    assert d["foo"] == 1
    d["bar"] = 2
    assert d.bar == 2
    assert d["bar"] == 2



# Generated at 2022-06-24 09:27:44.555981
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("a\\.b\\*") == "a.b*"
    assert re_unescape("a\\\\b") == "a\\b"
    assert re_unescape(r"\\\n\\\\") == r"\n\\"
    assert re_unescape(r"\\\d") == r"\d"
    for i in range(128):
        assert re_unescape("\\%c" % i) == chr(i)
    assert re_unescape(r"\\x20") == " "
    assert re_unescape(r"\\x") == r"\x"
    try:
        re_unescape(r"\\b")
    except ValueError:
        pass
    else:
        assert False, "failed to raise ValueError"



# Generated at 2022-06-24 09:27:51.934488
# Unit test for constructor of class Configurable
def test_Configurable():
    class ConfigTest(Configurable):
        def __init__(self, value):
            self.value = value
        @classmethod
        def configurable_base(cls):
            return ConfigTest
        @classmethod
        def configurable_default(cls):
            return ConfigTest
    class ImplementedConfigTest(ConfigTest):
        pass

    ConfigTest.configure(ImplementedConfigTest)
    assert isinstance(ConfigTest(42), ImplementedConfigTest)



# Generated at 2022-06-24 09:28:01.795356
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    # Test type
    from typing import Any, Union
    assert isinstance(d.x, (type(None), Any))
    assert isinstance(d["x"], (type(None), Any))
    assert isinstance(d.y, (type(None), Any))
    assert isinstance(d["y"], (type(None), Any))
    assert None is None
    # Test evaluation
    d.x = 1
    d["y"] = 2
    assert d.x == 1
    assert d["x"] == 1
    assert d.y == 2
    assert d["y"] == 2



# Generated at 2022-06-24 09:28:10.608000
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    from tornado.escape import to_unicode
    from tornado.util import ObjectDict
    od = ObjectDict()
    od["foo"] = "bar"
    od.baz = "quux"
    assert od["foo"] == "bar"
    assert od["baz"] == "quux"
    assert od.foo == "bar"
    assert od.baz == "quux"
    assert repr(od).startswith("<tornado.util.ObjectDict")
    assert to_unicode(ObjectDict(foo=u"üñîçøðé")) == u"üñîçøðé"


# Generated at 2022-06-24 09:28:12.421373
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    exc = TimeoutError("123")
    assert exc.args == ("123",)
    assert str(exc) == "123"



# Generated at 2022-06-24 09:28:16.719506
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    g = GzipDecompressor()
    text = b'hello'
    comp = zlib.compress(text)
    while comp:
        data = comp[:10]
        comp = comp[10:]
        res = g.decompress(data)
        if res:
            assert res == text



# Generated at 2022-06-24 09:28:22.810556
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    compressor = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
    compressed = compressor.compress(b"abcdefghijklmnop")
    compressed += compressor.flush()
    assert len(compressed) and compressed != b"abcdefghijklmnop"
    decompressor = GzipDecompressor()
    assert decompressor.decompress(compressed) == b"abcdefghijklmnop"
    assert decompressor.unconsumed_tail == b""
    assert decompressor.flush() == b""

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 09:28:26.458124
# Unit test for function exec_in
def test_exec_in():
    x = None  # type: Any
    exec_in('x = 6', globals())
    assert x == 6
    exec_in('x = 7', globals(), locals())
    assert x == 7
del test_exec_in



# Generated at 2022-06-24 09:28:36.370679
# Unit test for function re_unescape
def test_re_unescape():
    # Unescape a string escaped by re.escape
    assert re_unescape(r"\x00") == "\x00"
    assert re_unescape(r"\x7F") == "\x7F"
    assert re_unescape(r"\00") == "\x00"
    assert re_unescape(r"\077") == "\x3f"
    assert re_unescape(r"\0123") == "\x83"
    assert re_unescape(r"\x0123") == "\x0123"
    assert re_unescape(r"\u0123") == "\u0123"
    assert re_unescape(r"\U00000123") == "\U00000123"
    assert re_unescape(r"\z") == "z"

# Generated at 2022-06-24 09:28:37.482239
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()
    TimeoutError("message")



# Generated at 2022-06-24 09:28:41.471137
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(2)
    except Exception as e:
        assert errno_from_exception(e) == 2

    try:
        exc = Exception()
        exc.errno = 3
        raise exc
    except Exception as e:
        assert errno_from_exception(e) == 3



# Generated at 2022-06-24 09:28:49.152941
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    e = TimeoutError()  # type: Any
    TimeoutError("foo")


# Make it easy to import these names without having to also import
# `.TimeoutError`.  The aliases are not exported from the main tornado
# namespace because they are only used by other modules.
try:
    from tornado.gen import TimeoutError as gen_TimeoutError  # type: ignore
except ImportError:
    pass
try:
    from tornado.ioloop import TimeoutError as ioloop_TimeoutError  # type: ignore
except ImportError:
    pass



# Generated at 2022-06-24 09:29:01.025982
# Unit test for function exec_in
def test_exec_in():
    x = "original value"
    loc = dict(x=x)
    glb = dict()
    exec_in("y = x", glb, loc)
    assert loc["y"] == x


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.
if str is unicode_type:
    _SUPPORTED_NON_BYTES = {unicode_type, type(None)}

# Generated at 2022-06-24 09:29:10.029626
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class SubConfig(Configurable):
        @classmethod
        def configurable_base():  # type: () -> Type[Configurable]
            return Configurable
        @classmethod
        def configurable_default():  # type: () -> Type[Configurable]
            return SubConfig
        @classmethod
        def configure(cls, impl, **kwargs):  # type: (Union[None, str, Type[Configurable]], Any) -> None
            pass
        @classmethod
        def configured_class(cls):  # type: () -> Type[Configurable]
            pass
        @classmethod
        def _save_configuration(cls):  # type: () -> Tuple[Optional[Type[Configurable]], Dict[str, Any]]
            pass

# Generated at 2022-06-24 09:29:18.692162
# Unit test for function import_object
def test_import_object():
    # Silences pylint as this test is considered not useful
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('tornado') is tornado
    with pytest.raises(ImportError):
        import_object('tornado.missing_module')
    # Silences pylint as we don't want to import a package with '.' in it
    assert import_object('no.dot.here') is sys.modules['no.dot.here']



# Generated at 2022-06-24 09:29:27.036673
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import random
    from typing import TYPE_CHECKING
    from .options import options

    if TYPE_CHECKING:
        # See test_class_method_type_inference for more information on why this is necessary
        from .options import Options

    class _ConfigurableTestClass(Configurable):
        def initialize(self, foo, bar):
            self.foo = foo
            self.bar = bar

        @classmethod
        def configurable_base(cls):
            return _ConfigurableTestClass

        @classmethod
        def configurable_default(cls):
            return _ConfigurableTestDefaultImpl

    class _ConfigurableTestDefaultImpl(_ConfigurableTestClass):
        pass

    class _ConfigurableTestImpl1(_ConfigurableTestClass):
        pass

    class _ConfigurableTestImpl2(_ConfigurableTestClass):
        pass


# Generated at 2022-06-24 09:29:31.410829
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # type: () -> None
    try:
        raise IOError(123, "foo")
    except IOError as e:
        assert errno_from_exception(e) == 123
        assert str(e) == "foo"



# Generated at 2022-06-24 09:29:38.296127
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o.name = "test"
    assert o.name == "test"
    assert o['name'] == "test"
    assert hasattr(o, "name")
    assert "name" in dir(o)
    try:
        print(o.name_not_exist)
        assert False
    except AttributeError:
        assert True
    assert not hasattr(o, "name_not_exist")
    assert "name_not_exist" not in dir(o)


# Generated at 2022-06-24 09:29:48.630248
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import datetime
    data = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff\xf2H\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00!\xb0\xa5V\x05\x00\x00\x00'
    d = GzipDecompressor()
    t = d.decompress(data)
    print(t)
    assert t == b"Testing decompression of gzip data\n"
    assert d.unconsumed_tail == b""
    assert d.flush() == b""


# Generated at 2022-06-24 09:30:00.231097
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f1(x, y=1, *args, **kwargs):
        pass

    r = ArgReplacer(f1, "y")
    assert 1 == r.get_old_value((1,), {})
    assert 1 == r.get_old_value((), {"y": 1})
    assert 3 == r.get_old_value((1,), {"y": 3})
    assert 2 == r.get_old_value((1, 2), {})[0]
    assert 4 == r.get_old_value((1, 2), {"y": 4})[0]
    assert (1, (2, 3, 4), dict(a=1)) == r.replace(5, (1, 2, 3, 4), dict(a=1))

# Generated at 2022-06-24 09:30:06.356017
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(2, "No such file or directory")
    except OSError as e:
        assert errno_from_exception(e) == 2

    try:
        raise OSError()
    except OSError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:30:18.138745
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    fn = lambda a, b, c, d=1, e=2, f=3: None
    r = ArgReplacer(fn, 'b')
    assert r.arg_pos == 1
    assert r.name == 'b'
    assert r.get_old_value((1, 2, 3, 4, 5, 6), {}) == 2
    assert r.get_old_value(tuple(), {'b': 2}) == 2
    assert r.get_old_value((1, 2), {}) == 2
    assert r.get_old_value((), dict(b=2)) == 2
    assert r.get_old_value((), dict(b=2, d=1)) == 2
    assert r.get_old_value((), {}) is None

# Generated at 2022-06-24 09:30:25.109413
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=2)) == 1.000002
    assert timedelta_to_seconds(datetime.timedelta(microseconds=2)) == 0.000002
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=2, microseconds=3)) == 86400 + 2 + 0.000003



# Generated at 2022-06-24 09:30:34.294790
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """
    Tests that the __new__ method of class `Configurable` is implemented properly.

    Parameters
    ----------

    Returns
    -------
    None

    Raises
    ------
    None

    """
    c = Configurable()
    assert c.__dict__["_Configurable__impl_class"] == None
    assert c.__dict__["_Configurable__impl_kwargs"] == None
    assert c.configure("", a="a") == None
    assert c.configure("", b="b") == None
    assert c.__dict__["_Configurable__impl_class"] == None
    assert c.__dict__["_Configurable__impl_kwargs"] == {'a': 'a', 'b': 'b'}



# Generated at 2022-06-24 09:30:44.043849
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    from . import httputil
    import os.path
    import re
    # decompress a gzipped response
    response = ""
    filename = os.path.join(os.path.dirname(__file__), "test_file.html.gz")
    with open(filename, "rb") as f:
        response_block = f.read(8192)
    while response_block != b"":
        response += str(response_block, encoding="utf-8")
        response_block = f.read(8192)
    response = str(response)  # type: ignore
    response_line, headers_string, response = response.split("\r\n", 2)
    headers = httputil.HTTPHeaders.parse(headers_string)
    gzip = GzipDecompressor()
    decompress = gzip

# Generated at 2022-06-24 09:30:50.281559
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\w") == r"w"
    assert re_unescape(r"\Q\E") == r"\Q\E"
    assert re_unescape(r"\a") == "\a"
    assert re_unescape(r"\x01") == "\x01"
    assert re_unescape(r"\u0001") == "\u0001"
    assert re_unescape(r"\U00000001") == "\U00000001"

    assert re_unescape(r"\.") == "."
    assert re_unescape(r"\\") == "\\"

    with pytest.raises(ValueError):
        re_unescape(r"\d")



# Generated at 2022-06-24 09:30:52.120104
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a = ObjectDict()
    a.a = 1
    assert 1 == a.a, a.a



# Generated at 2022-06-24 09:31:01.106756
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # GzipDecompressor is used by HTTPConnection.on_headers when decompressing
    # on the fly, so we can test it here.
    from tornado.httputil import HTTPServerRequest
    from tornado.simple_httpclient import SimpleAsyncHTTPClient

    def handle(request: HTTPServerRequest) -> None:
        # Write a single chunk of gzipped data and then close the connection
        # to emulate a server sending gzip-encoded data.
        #
        # For a more realistic test use a larger chunk, e.g.
        # compressed = b'1' * 50_000
        compressed = b'1' * 1000

# Generated at 2022-06-24 09:31:12.584635
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado import gen, httpclient, ioloop, stack_context
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Pinger(Configurable):
        class Implementation(Configurable):
            @gen.coroutine
            def ping(self, url):
                # type: (str) -> bool
                client = httpclient.AsyncHTTPClient()
                try:
                    response = yield client.fetch(url)
                    return response.code == 200
                except Exception:
                    return False

        @classmethod
        def configurable_base(cls):
                return Pinger

        @classmethod
        def configurable_default(cls):
                return Pinger.Implementation


# Generated at 2022-06-24 09:31:16.216105
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gz = GzipDecompressor()
    assert isinstance(gz.decompress(b""), bytes) and isinstance(gz.flush(), bytes)
    assert isinstance(gz.unconsumed_tail, bytes)


# Fake classes for types that aren't available in this context

# Generated at 2022-06-24 09:31:17.479999
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()



# Generated at 2022-06-24 09:31:19.421891
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # Prepare
    d = GzipDecompressor()
    d.decompress("hoge\n")

    # Execute
    d.flush()



# Generated at 2022-06-24 09:31:22.046957
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.a = 1
    assert obj["a"] == 1



# Generated at 2022-06-24 09:31:24.647442
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.test_setattr = True  # type: ignore
    assert d['test_setattr'] == True



# Generated at 2022-06-24 09:31:34.221927
# Unit test for function re_unescape
def test_re_unescape():
    def re_escape_round_trip(s: str) -> bool:
        return re_unescape(re.escape(s)) == s

    assert re_escape_round_trip(r"\^$*+?.[]{}|()")

# Generated at 2022-06-24 09:31:37.915515
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError("test")
    except TimeoutError as e:
        assert str(e) == "test"
    except:  # noqa: E722
        raise AssertionError("Should have raised a TimeoutError")



# Generated at 2022-06-24 09:31:46.290600
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    import datetime
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.5)) == 1.5
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1.5)) == 86401.5
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=1.5)) == -86398.5
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=-1.5)) == -86401.5



# Generated at 2022-06-24 09:31:47.753830
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    obj = GzipDecompressor()
    result = obj.flush()

# Generated at 2022-06-24 09:31:56.697914
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import abc
    from typing import Any, Dict, Optional, Type, TypeVar


    class ABC(Configurable, metaclass=abc.ABCMeta):
        def __new__(cls, *args: Any, **kwargs: Any) -> Any:
            if cls is ABC:
                raise TypeError("Can't instantiate abstract class ABC with "
                                "abstract methods configurable_base, "
                                "configurable_default")
            return super().__new__(cls)

        @classmethod
        @abc.abstractmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            raise NotImplementedError()


# Generated at 2022-06-24 09:32:03.923590
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class TestConfigurable1(Configurable):
        def __init__(self, arg0):
            self.__arg0 = arg0

        def configurable_base(self):
            return type(self)

        def configurable_default(self):
            return type(self)

        def initialize(self):
            pass

    class TestConfigurable2(TestConfigurable1):
        def __init__(self, arg1):
            self.__arg1 = arg1

    TestConfigurable1.configure(TestConfigurable1)
    tc1 = TestConfigurable1(0)
    assert isinstance(tc1, TestConfigurable1)
    assert tc1.__arg0 == 0
    assert tc1.__arg1 == 1
    TestConfigurable1.configure(TestConfigurable2)

# Generated at 2022-06-24 09:32:08.082953
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    with open("test_files/test_GzipDecompressor.gz", "rb") as file:
        data = file.read()
        gz = GzipDecompressor()
        out = gz.decompress(data)
    with open("test_files/test_GzipDecompressor.txt", "rb") as file:
        data = file.read()
        assert out == data



# Generated at 2022-06-24 09:32:09.870898
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    assert repr(ObjectDict(a=1, b=2)) == '{a=1, b=2}'



# Generated at 2022-06-24 09:32:20.113367
# Unit test for function raise_exc_info
def test_raise_exc_info():  # type: () -> None
    def f():
        # type: () -> str
        raise ValueError()

    # Check that the exception is properly raised and that we don't leak
    # a traceback reference.
    try:
        f()
        # If f() is not properly implemented this line will fail,
        # but it is more important to test that we are not leaking a
        # reference to the traceback.
        assert False, "did not raise"  # type: ignore
    except ValueError:
        exc_info = sys.exc_info()

    try:
        raise_exc_info(exc_info)
    except ValueError:
        assert True  # type: ignore

    # Check that we don't leak a traceback reference.
    for i in range(5):
        raise_exc_info(exc_info)



# Generated at 2022-06-24 09:32:26.208552
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ValueError(1)
    except:
        exc_info = sys.exc_info()
    try:
        raise_exc_info(exc_info)
    except ValueError as e:
        # Validate that the type and value are intact
        assert e.args[0] == 1
        raise


# Generated at 2022-06-24 09:32:36.392364
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This is a copy of test_zlibstream from test/test_zlib.py.
    # It doesn't matter that we aren't using the decompressor in
    # streaming mode; the important thing is that we check the FHCRC bit.
    d = GzipDecompressor()
    assert not d.unused_data
    assert not d.unconsumed_tail

    data = zlib.compress(b"foo")[2:-4]
    assert d.decompress(data) == b"foo"
    assert not d.unused_data
    assert not d.unconsumed_tail

    # Try multiple separate decompress calls
    d = GzipDecompressor()
    assert not d.unused_data
    assert not d.unconsumed_tail