

# Generated at 2022-06-24 09:22:41.486656
# Unit test for constructor of class Configurable
def test_Configurable():
    class MyInterface(Configurable):
        @classmethod
        def configurable_base(self):
            return MyInterface

        @classmethod
        def configurable_default(self):
            return MyImpl

        def test_method(self):
            return "default"

    class MyImpl(MyInterface):
        def initialize(self, param=None):
            self.param = param

        def test_method(self):
            return "MyImpl"

    class MyImpl2(MyInterface):
        def initialize(self, param=None):
            self.param = param

        def test_method(self):
            return "MyImpl2"

    assert issubclass(MyImpl, MyInterface)
    assert not issubclass(MyInterface, MyImpl)

    MyInterface.configure(MyImpl2, param="value")
    assert MyInterface

# Generated at 2022-06-24 09:22:49.848672
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(2, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 2
    try:
        raise IOError("foo")
    except Exception as e:
        assert errno_from_exception(e) is None


if hasattr(os, "add_dll_directory"):
    # This method is only available on Windows and was added in Python 3.8.
    from ctypes import windll

    def add_system_dll_directory():
        windll.kernel32.AddDllDirectory(None)


    def reset_system_dll_directories():
        windll.kernel32.SetDefaultDllDirectories(0x01)



# Generated at 2022-06-24 09:22:53.154533
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    obj = GzipDecompressor()
    real_obj = obj.decompressobj
    max_length = 0
    ret = obj.decompress(b"value", max_length=0)
    assert ret == real_obj.decompress(b"value", max_length=0)

# Generated at 2022-06-24 09:23:05.270681
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    "Unit test for ArgReplacer"

    # new_value   args               kwargs            old_value

# Generated at 2022-06-24 09:23:16.582425
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Dummy(Configurable):
        def __init__(self, arg: bool, kwarg: bool = False) -> None:
            self.arg = arg
            self.kwarg = kwarg

        @classmethod
        def configurable_base(cls) -> Type[Configurable]:
            return Dummy

        @classmethod
        def configurable_default(cls) -> Type[Configurable]:
            return Dummy

    Dummy.configure(None)
    dummy_true = Dummy(True)
    assert dummy_true.arg is True
    assert dummy_true.kwarg is False

    Dummy.configure(None, kwarg=True)
    dummy_true_kwarg = Dummy(True)
    assert dummy_true_kwarg.arg is True

# Generated at 2022-06-24 09:23:24.404845
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import abc
    class Base(abc.ABC, Configurable):
        @classmethod
        def configurable_base(cls):
            return Base
        @classmethod
        def configurable_default(cls):
            # no override; we will raise NotImplementedError in
            # initialize instead
            return cls
        def initialize(self):
            # type: () -> None
            raise NotImplementedError
    class Subclass(Base):
        def initialize(self):
            pass
    assert Subclass()
    old_configured_class = Subclass.configured_class
    try:
        Subclass.configure(None)  # type: ignore
    finally:
        Subclass.configured_class = old_configured_class
    with pytest.raises(NotImplementedError):
        Subclass()

# Generated at 2022-06-24 09:23:27.870575
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import sys
    import unittest

    suite = doctest.DocTestSuite()
    report = doctest.DocTestRunner(verbose=0).run(suite)
    raise_if(report.failures, unittest.TestCase)

if __debug__:
    test_doctests()

# Generated at 2022-06-24 09:23:33.525485
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42
    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-24 09:23:44.115544
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(0)) == 0.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 86401.0
    assert timedelta_to_seconds(datetime.timedelta(days=1, microseconds=1)) == 86400.000001
    assert timedelta_to_seconds(datetime.timedelta(days=-1)) == -86400.0
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=-1)) == -86401.0

# Generated at 2022-06-24 09:23:47.794879
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    z = GzipDecompressor()
    assert z.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x6b\x54\xcb\x4e\x0c') == b"aaa"


# Generated at 2022-06-24 09:23:51.340176
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    a = ObjectDict()
    a['b'] = 123
    assert a.b == 123

    try:
        c = a.c  # type: ignore
    except Exception as e:
        assert type(e) is AttributeError
    else:
        assert False, "should have raised"



# Generated at 2022-06-24 09:23:58.487387
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(None)
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(42)
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception((42,))
    except Exception as e:
        assert errno_from_exception(e) == 42

    class MyException(Exception):
        pass

    try:
        raise MyException()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise MyException(None)
    except Exception as e:
        assert errno_from

# Generated at 2022-06-24 09:24:10.234367
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # "string literals" in byte-string
    # data = '''\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\x8c\x48\xcd\xc9\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'''
    data = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\x8c\x48\xcd\xc9\x07"
    decompressor = GzipDecompressor()
    output = decompressor.decompress(data)
    assert output == b""

# Generated at 2022-06-24 09:24:15.346157
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a, b=1, c=2):
        pass

    arg_replacer = ArgReplacer(test, "b")
    assert arg_replacer.get_old_value((), {}) == 1
    assert arg_replacer.get_old_value((), {"b": 99}) == 99



# Generated at 2022-06-24 09:24:16.942395
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(1)) == 86400


# Generated at 2022-06-24 09:24:22.918841
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # type: ignore
    try:
        # Calling the class directly will raise an exception
        # because we pass no 'seconds' parameter.
        TimeoutError()  # type: ignore
    except TypeError as e:
        assert str(e) == '__init__() missing 1 required positional argument: \'seconds\''  # type: ignore



# Generated at 2022-06-24 09:24:26.272319
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    d = GzipDecompressor()
    testString = "hello world"
    testBytes = testString.encode("utf-8")
    testGzipBytes = testBytes
    assert d.decompress(testGzipBytes) == testBytes

# Generated at 2022-06-24 09:24:32.552925
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def sample_function(arg1, arg2, arg3, arg4=10):
        old_arg3 = arg3
        arg3, args, kwargs = ArgReplacer('arg3').replace(100, [arg1, arg2, arg3, arg4], {})
        return old_arg3, arg3, args, kwargs

# Generated at 2022-06-24 09:24:37.749168
# Unit test for function errno_from_exception
def test_errno_from_exception():
    # from errno import ENOENT
    assert errno_from_exception(OSError(0, '')) == 0
    assert errno_from_exception(OSError(0, '').with_traceback(True)) == 0
    assert errno_from_exception(IOError(0, '')) == 0
    assert errno_from_exception(IOError(0, '').with_traceback(True)) == 0
    assert errno_from_exception(ValueError()) is None
    assert errno_from_exception(ValueError().with_traceback(True)) is None

_DEFAULT = object()



# Generated at 2022-06-24 09:24:49.455185
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # This test is not finished.
    def test_func(param1, param2, param3):
        pass

    argreplacer = ArgReplacer(test_func, 'param2')
    param1 = {}
    param3 = {}
    # Case 1
    param2 = "param2_value"
    result = argreplacer.get_old_value((param1, param2, param3), {})
    assert result == param2
    # Case 2
    param2 = None
    result = argreplacer.get_old_value((param1, param2, param3), {})
    assert result is None
    # Case 3
    result = argreplacer.get_old_value((param1, param3), {"param2": param2})
    assert result == param2
    # Case 4
    param2 = None
   

# Generated at 2022-06-24 09:25:01.730271
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    gz = GzipDecompressor()
    gz.decompress(b'\x1f\x8b\x08\x00')


_UTF8_TYPES = (bytes, type(None))

if str is not unicode_type:
    # Python 3

    _UNSET = object()

    def binary_type(value: Any) -> bytes:
        """``binary_type`` is any binary string type, the default being ``bytes``.

        It does not matter which of the two, so long as they are treated the
        same.
        """
        return value


# Generated at 2022-06-24 09:25:11.021532
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    try:
        raise TimeoutError
    except TimeoutError:
        import sys
        import traceback

        exc_info = sys.exc_info()
        traceback.format_exception(*exc_info)  # type: ignore
        del exc_info

gen_log = gen_log

# Exported for backwards compatibility (name was originally mis-spelled)
TimeoutError.__module__ = __name__  # type: ignore
Timeout = TimeoutError  # type: ignore

# The signature of this callable is used in type annotations throughout Tornado.
_NO_RESULT = object()
_T = typing.TypeVar('_T')
Callback = Callable[[_T], None]

# These are used as the default values for Configurable.configure's
# `value_is_future` and

# Generated at 2022-06-24 09:25:17.114344
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super().__init__()

        def configurable_base(self):
            return A

        def configurable_default(self):
            return A

        def _initialize(self):
            pass

    A.configure(A)
    a = A(1, 2, a=3, b=4)
    assert a.args == (1, 2)
    assert a.kwargs == {"a": 3, "b": 4}



# Generated at 2022-06-24 09:25:24.959274
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        TimeoutError()
    except TypeError:
        pass
    else:
        raise AssertionError('TimeoutError() should raise TypeError')
    try:
        TimeoutError(1)
    except TypeError:
        pass
    else:
        raise AssertionError('TimeoutError(1) should raise TypeError')
    try:
        TimeoutError(message='foo')
    except TypeError:
        pass
    else:
        raise AssertionError('TimeoutError(message=...) should raise TypeError')


TimeoutError.__module__ = 'tornado.util'
TimeoutError.__qualname__ = 'TimeoutError'

# Alias for compatibility with old tornado versions.
gen_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:25:27.488551
# Unit test for function import_object
def test_import_object():
    import_object("test_utils.test_import_object")



# Generated at 2022-06-24 09:25:36.324178
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    for compress in [b'x\x9cK\xcb\xcfJ\xcaK(\xcf/\xca\x05n\x04\x00\xcc\xc5\x06\x00\x01',
                     b'x\x9c+H,I-.Q<R\x80\x0c\x04\x00\x04\x00\x00']:
        gz = GzipDecompressor()
        data = gz.decompress(compress)
        data += gz.flush()
        assert data == b"hello world"


# Fake `unicode` type for python 3.
unicode_type = str

# The `u` prefix will be added automatically in python 3.

# Generated at 2022-06-24 09:25:46.269374
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass

_DATETIME_TO_STRING_FORMAT = "%Y-%m-%d %H:%M:%S"
_MICROSECOND_FORMAT = ".%06d"
_DATETIME_TO_ISOFORMAT = _DATETIME_TO_STRING_FORMAT + _MICROSECOND_FORMAT

try:
    # The platform-specific modules are not public and may not be available
    # (e.g. on App Engine).
    import tornado.platform.posix  # noqa: F401
    import tornado.platform.windows  # noqa: F401
except ImportError:
    pass



# Generated at 2022-06-24 09:25:54.731998
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_replace_f(a, b, c = 'c', d='d'):
        pass
    test_obj = ArgReplacer(test_replace_f, 'a')
    assert test_obj.replace('test_a', ('b',), {'c': 'test_c', 'd': 'test_d'}) == ('b', ('test_a',),
                                                                                  {'c': 'test_c', 'd': 'test_d'})
    test_obj = ArgReplacer(test_replace_f, 'b')

# Generated at 2022-06-24 09:26:02.455984
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c):
        pass

    def func2(a, b, c=1):
        pass

    def func3(a=1, b=2, c=3):
        pass

    def func4(**kwargs):
        """
        this is a test function
        """

    class Test:
        def method(self, d, e, f):
            pass

        @staticmethod
        def static_method(a, b, c):
            pass

    test = Test()

    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.name == "b"
    assert arg_replacer.arg_pos == 1
    assert arg_replacer.get_old_value((0, 1, 2), {}) == 1

# Generated at 2022-06-24 09:26:06.206234
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b):
        pass
    arg_replacer = ArgReplacer(f, "a")
    assert arg_replacer.get_old_value((1,2), {}) == 1
    assert arg_replacer.get_old_value((1,2), {}, -1) == 1
    assert arg_replacer.get_old_value((1,), {}, -1) == 1
    assert arg_replacer.get_old_value((1,), {"a": 2}, -1) == 2



# Generated at 2022-06-24 09:26:08.109804
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # type: () -> None
    try:
        raise TimeoutError()
    except TimeoutError:
        pass



# Generated at 2022-06-24 09:26:11.330180
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_function(a, b, c=None, d=None):
        return (a, b, c, d)

    arg = ArgReplacer(test_function, "c")
    old_value, args, kwargs = arg.replace("this is the new value", (1, 2), {})

    print(args)
    print(kwargs)

    assert args == (1, 2, "this is the new value")
    assert kwargs == {'d': None}



# Generated at 2022-06-24 09:26:12.597537
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    suite = doctests()
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)



# Generated at 2022-06-24 09:26:14.382624
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError as e:
        assert str(e)



# Generated at 2022-06-24 09:26:16.544794
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(2, 0, 1)) == 172801.0



# Generated at 2022-06-24 09:26:21.013826
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(one, two, three):
        pass

    arg_replacer = ArgReplacer(foo, "two")
    print(arg_replacer.get_old_value((1, 2, 3), {}))


# Generated at 2022-06-24 09:26:30.196676
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    args = ('a', 'b', 'c', 'd')
    kwargs = {'d':1,'c':2,'e':3}
    
    def f(*args, **kwargs):
        return args, kwargs
    old_value, args2, kwargs2 = ArgReplacer(f, 'c').replace('cc', args, kwargs)
    assert args2 == ('a', 'b', 'cc', 'd')
    assert kwargs2 == {'c':'cc','d':1,'e':3}
    
    old_value, args2, kwargs2 = ArgReplacer(f, 'g').replace('gg', args, kwargs)
    assert args2 == ('a', 'b', 'c', 'd')

# Generated at 2022-06-24 09:26:39.120012
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import io
    import gzip
    import time
    content=b"Hello world!\nThis is a test!\n\n"
    fileobj=io.BytesIO()
    gzipobj=gzip.GzipFile(filename="test.gzip", mode="wb", fileobj=fileobj)
    gzipobj.write(content)
    gzipobj.close()
    #get gzip content
    fileobj.seek(0)
    content=fileobj.read()
    #normal operation
    gzipdecomp=GzipDecompressor()
    decomp=gzipdecomp.decompress(content)
    decomp=gzipdecomp.flush()
    print(decomp.decode("utf-8"))
    assert(decomp.decode("utf-8")==content.decode("utf-8"))


# Generated at 2022-06-24 09:26:50.714045
# Unit test for constructor of class Configurable
def test_Configurable():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A

        def _initialize(self):
            pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    assert type(a) is A
    assert isinstance(a, A)

    A.configure(B)
    assert type(a) is B
    assert isinstance(a, A)
    a2 = A()
    assert type(a2) is B
    assert isinstance(a2, A)

    # Ensure the configure call was in fact global
    assert type(a) is B
    assert type(a2) is B

    a3 = A()
   

# Generated at 2022-06-24 09:26:55.117665
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise Exception
    except Exception:
        (exc_type, exc_value, exc_traceback) = sys.exc_info()
        def fn():
            # type: () -> typing.NoReturn
            raise_exc_info(sys.exc_info())
        fn()



# Generated at 2022-06-24 09:27:02.392858
# Unit test for constructor of class Configurable
def test_Configurable():
    class A:
        pass
    class B(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return C
    class C(B):
        pass
    D = B.configured_class() # would be C if class C was defined

    B.configure(D, a=1)
    x = A()
    assert type(x) is D
    assert x.a == 1
    del x.a

    B.configure(None)
    assert B.configured_class() is C
    B.configure(D)

    y = A()
    assert type(y) is D
    assert y.a == 1
    del y.a

    B.configure(D, a=2)

# Generated at 2022-06-24 09:27:05.905539
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fun(a,b,e=None):
        pass
    ar = ArgReplacer(fun, "b")
    assert ar.replace(1, [2,3], {}) == (3, [2,1], {})
    assert ar.replace(1, [], {"b":3}) == (3, [], {"b":1})
    assert ar.replace(1, [2], {}) == (None, [2], {"b":1})


# Generated at 2022-06-24 09:27:08.148992
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None

    obj = ObjectDict()
    obj["foo"] = "bar"
    assert obj["foo"] == obj.foo



# Generated at 2022-06-24 09:27:10.212702
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj_dict = ObjectDict(a=1, b=2)
    assert obj_dict.a == 1
    assert obj_dict['b'] == 2



# Generated at 2022-06-24 09:27:22.103962
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import pytest
    import tornado.gen

    # Initialize an instance of a configurable class.
    sol = [None]
    class Test(Configurable):
        def initialize(self, value):
            sol[0] = value
    Test(value="test")
    assert sol[0] == "test"

    # Initialize an instance of a subclass of a configurable class.
    sol = [None]
    class TestSubclass(Test):
        def _initialize(self, value):
            sol[0] = self.__class__.__name__ + value
    TestSubclass(value="test")
    assert sol[0] == "TestSubclasstest"

    # Initialize an instance of a subclass of a subclass of a
    # configurable class.
    sol = [None]

# Generated at 2022-06-24 09:27:24.220055
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    test_args = (1,3,5,7)
    test_kwargs = {'b':9,'v':8,'a':2,'e':12}
    assert ArgReplacer(test_ArgReplacer_get_old_value,'a').get_old_value(test_args,test_kwargs,0) == 2


# Generated at 2022-06-24 09:27:31.424450
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import os, shutil
    #test_file = "test_GzipDecompressor_flush.gz"
    test_file = "test_GzipDecompressor_flush_2.gz"
    test_content = "1234567890"
    out_file = "test_GzipDecompressor_flush.out"
    # Compress the test_content
    print("in test_GzipDecompressor_flush(), compressing...")
    import subprocess
    command = "gzip -c %s > %s" % (test_content, test_file)
    print("command: %s" % command)
    os.system(command)

    # Read the compressed data from the test file
    with open(test_file, "rb") as f:
        test_input = f.read()

    #print("test_

# Generated at 2022-06-24 09:27:40.678229
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a=0, b=0, c=0):
        pass
    ar = ArgReplacer(foo, 'a')
    assert ar.get_old_value((1,2,3), {'b':4, 'c':5}, default=999) == 1
    assert ar.get_old_value((1,2), {'b':4, 'c':5}, default=999) == 1
    assert ar.get_old_value((1,2), {'c':5}, default=999) == 999


# Generated at 2022-06-24 09:27:51.636525
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f1(x, y=3):
        pass

    def f2(x,y):
        pass

    def f3(x, y=3):
        pass

    def f4(x, y):
        pass

    def f5(x=1, y=2):
        pass

    def f6(x=1, y=2):
        pass

    def f7(x, y):
        pass



# Generated at 2022-06-24 09:27:57.371502
# Unit test for function re_unescape
def test_re_unescape():
    # Test cases taken from stdlib test case
    # test_re.py, function test_re_unescape
    assert re_unescape(r"\n\r\t\v\x09\x0a") == "\n\r\t\x0b\t\n"
    assert re_unescape(r"\a\b\B\Z\a\o12\012\612") == "\x07\x08\x08\\Z\x07\x0712\n12"
    assert re_unescape(r"\x61\141\061") == "aa1"
    assert re_unescape(r"\u1234\U00012345\uABCD") == "\u1234\U00012345\uABCD"

# Generated at 2022-06-24 09:28:06.227260
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    z = zlib.compressobj(1)
    zipped_preamble = z.compress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff')
    zipped_hello_world = z.compress(b'hello, world!')
    zipped_end = z.flush()
    zipped = zipped_preamble + zipped_hello_world + zipped_end
    del z

    dz = GzipDecompressor()
    assert dz.decompress(zipped) == b'hello, world!'
    assert dz.flush() == b''



# Generated at 2022-06-24 09:28:12.820552
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def testFunc(self: Dict, name: str, value: Any) -> None:
        self[name] = value
    def testFunc2(name: str, value: Any) -> None:
        self[name] = value
    d = {}
    testFunc(d, "a", 1)
    assert (d == {"a": 1})
    testFunc2("b", 2)
    assert (d == {"a": 1, "b": 2})

__alias_tornado_gen_TimeoutError = TimeoutError

__alias_tornado_ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:28:23.005721
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(0)) == 0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.1)) == 1.1
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1)) == -1
    assert timedelta_to_seconds(datetime.timedelta(days=-1, seconds=1)) == -86399
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=-1)) == 86399
    assert timedelta_to_seconds(datetime.timedelta(days=10)) == 864000



# Generated at 2022-06-24 09:28:25.948677
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def initialize(self):
            super(Foo, self).initialize()
    # Unit test for method configure of class Configurable

# Generated at 2022-06-24 09:28:31.114158
# Unit test for function exec_in
def test_exec_in():
    loc = {}
    exec_in("x = 6", globals(), loc)
    assert loc["x"] == 6

# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this function
# and just use byte literals.

# Generated at 2022-06-24 09:28:40.089291
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class BaseConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        
        @classmethod
        def configurable_default(cls):
            return BaseImpl

        def initialize(self, a, b=4):
            self.a = a
            self.b = b
    class BaseImpl(BaseConfigurable):
        pass
    class ExtendedImpl(BaseImpl):
        pass
    class ExtendedConfigurable(BaseConfigurable):
        @classmethod
        def configurable_default(cls):
            return ExtendedImpl
    def check_init(instance, args, kwargs):
        assert instance.__class__.__name__ in ("BaseImpl", "ExtendedImpl")
        assert instance.a == args[0]
        assert instance.b == args[1]
    check

# Generated at 2022-06-24 09:28:40.960916
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()

# Generated at 2022-06-24 09:28:51.802135
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class FakeFunc(object):
        func_code = None  # type: ignore
        co_varnames = ("foo", "bar")  # type: ignore
        co_argcount = 2  # type: ignore

    def f(foo, bar):
        pass

    assert ArgReplacer(f, "foo").arg_pos == 0
    assert ArgReplacer(f, "bar").arg_pos == 1
    assert ArgReplacer(f, "baz") is None
    assert ArgReplacer(f, "baz").arg_pos is None

    f2 = FakeFunc()
    assert ArgReplacer(f2, "foo").arg_pos == 0
    assert ArgReplacer(f2, "bar").arg_pos == 1


# Generated at 2022-06-24 09:28:57.078928
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    """Unit test for constructor of class GzipDecompressor
    """
    # Real data from http://stackoverflow.com/questions/1838699/how-can-i-decompress-a-gzip-stream-with-zlib
    # This format is said to be supported
    data = b"\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff"
    decompressor = GzipDecompressor()
    try:
        decompressor.decompress(data)
    except zlib.error:
        print("GzipDecompressor not supported on this platform")



# Generated at 2022-06-24 09:29:07.322737
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b=None, c=None):  # pragma: nocover
        pass

    arg_replacer = ArgReplacer(func, "b")
    assert arg_replacer.name == "b"
    assert arg_replacer.arg_pos is None

    arg_replacer = ArgReplacer(func, "c")
    assert arg_replacer.name == "c"
    assert arg_replacer.arg_pos is None

    arg_replacer = ArgReplacer(func, "a")
    assert arg_replacer.name == "a"
    assert arg_replacer.arg_pos == 0

    arg_replacer = ArgReplacer(func, "z")
    assert arg_replacer.name == "z"
    assert arg_replacer.arg_pos is None

    arg_replacer

# Generated at 2022-06-24 09:29:16.750653
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Check that decompress(data) always returns the same result as
    # decompressobj.decompress(data)
    data = open("tornado/test/google.html.gz", "rb").read()
    decompressobj = zlib.decompressobj(16 + zlib.MAX_WBITS)
    direct = decompressobj.decompress(data)
    wrapped = GzipDecompressor().decompress(data)
    assert direct == wrapped

_UTF8_TYPES = (bytes, type(None))  # type: Tuple[Type[bytes], Type[None]]



# Generated at 2022-06-24 09:29:21.064320
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict()
    d["x"] = 1
    assert d.x == 1
    # NOTE: what's the difference between getattr and __getattr__?

    # test Exception
    # AttributeError
    try:
        d.y
        assert False
    except AttributeError:
        pass


# Generated at 2022-06-24 09:29:22.706646
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod()



# Generated at 2022-06-24 09:29:26.565608
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1)) == -1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=-1, microseconds=1)) == -0.999999


# From PEP-365

# Generated at 2022-06-24 09:29:27.233437
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    pass



# Generated at 2022-06-24 09:29:38.295555
# Unit test for function import_object
def test_import_object():
    import tornado
    assert import_object("tornado") is tornado

    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8

    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        fail("expected import error")


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do
# this in a way that supports 2.5, though, so we need a function
# wrapper to convert our string literals.  b() should only be applied
# to literal latin1 strings.  Once we drop support for 2.5, we can
#

# Generated at 2022-06-24 09:29:44.668346
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError(123)
    except:
        tb = sys.exc_info()[2]
        exc_info = (None, ValueError(456), tb)
        raise_exc_info(exc_info)
    # Does not return, but does not complain about missing return
    # statement.
    assert False  # pragma: no cover



# Generated at 2022-06-24 09:29:52.652739
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(22)
    except Exception as e:
        assert errno_from_exception(e) == 22

    class MyException(Exception):
        pass

    try:
        raise MyException(22)
    except Exception as e:
        assert errno_from_exception(e) == 22

    class ErrnoException(OSError):
        pass

    try:
        raise ErrnoException(22)
    except Exception as e:
        assert isinstance(e, OSError)
        assert errno_from_exception(e) == 22



# Generated at 2022-06-24 09:29:56.674819
# Unit test for function exec_in
def test_exec_in():
    globs = {"foo": "foo"}
    locs = {"baz": "baz"}
    exec_in("bar = foo", globs, locs)
    assert globs["bar"] == "foo"
    assert locs["bar"] == "foo"



# Generated at 2022-06-24 09:30:04.831683
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def check_flush(original_data, options):
        """Asserts flushed data is as expected

        Args:
            original_data: Original data
            options: A tuple with following elements in order
                - wasted_bytes: Number of bytes that have been wasted
                    while decompressing the data
                - uncompressed_length: Length of data to be
                    uncompressed
                - compressed_length: Compressed length of data
                - is_final: True if data is the final one to be uncompressed
        """
        decompressor = GzipDecompressor()
        decompressed_data = b"".join(
            decompressor.decompress(chunk) for chunk in split_chunks(original_data)
        )
        assert decompressor.flush()


# Generated at 2022-06-24 09:30:06.855256
# Unit test for function import_object
def test_import_object():
    assert import_object('os') is os
    assert import_object('os.path') is os.path
    assert import_object('tornado.escape') is tornado.escape
    assert import_object('tornado.escape.utf8') is tornado.escape.utf8
    assert import_object('sys') is sys



# Generated at 2022-06-24 09:30:14.774230
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    import json
    from tornado.ioloop import IOLoop

    def test_init_set_get():
        x = ObjectDict(a=1)
        assert x["a"] == 1
        assert x.a == 1
        x.b = 2
        assert x["b"] == 2
        assert x.b == 2

    def test_json():
        x = ObjectDict(a=1)
        x.b = 2

        data = json.loads(json.dumps(x))
        assert data == {'a': 1, 'b': 2}

    IOLoop.current().run_sync(test_init_set_get)
    IOLoop.current().run_sync(test_json)


# Generated at 2022-06-24 09:30:18.557046
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(days=-1)) == -86400



# Generated at 2022-06-24 09:30:21.087754
# Unit test for function exec_in
def test_exec_in():
    exec_in("a=5; b=6", globals())
    assert a == 5
    assert b == 6



# Generated at 2022-06-24 09:30:31.445145
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def foo(a: int = 1, b: int = 2, c: int = 3) -> None:
        pass
    a = ArgReplacer(foo, 'a')
    b = ArgReplacer(foo, 'b')
    c = ArgReplacer(foo, 'c')
    print(a.get_old_value((3,), {}))
    print(b.get_old_value((), {}))
    print(c.get_old_value((), {}))
    print(a.get_old_value((3,), {'b': 4, 'c': 5}))
    print(b.get_old_value((), {'b': 4, 'c': 5}))
    print(c.get_old_value((), {'c': 5}))

# Generated at 2022-06-24 09:30:42.936225
# Unit test for constructor of class Configurable
def test_Configurable():
    class C(Configurable):
        def initialize(self, foo="foo"):
            self.foo = foo

        @classmethod
        def configurable_base(cls):
            return C

        @classmethod
        def configurable_default(cls):
            return C

    c = C()
    assert c.foo == "foo"
    assert isinstance(c, C)

    C.configure("tornado.test.util.C")
    c = C(foo="bar")
    assert c.foo == "bar"
    assert isinstance(c, C)

    # Some extra tests for the implementation of configure.
    original_impl_class = C.__impl_class

    # Can't configure a non-subclass

# Generated at 2022-06-24 09:30:46.979013
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fn(first, second=None):
        return first, second

    arg_replacer = ArgReplacer(fn, "second")
    assert arg_replacer.replace("new", (1,), {}) == (None, (1,), {"second": "new"})
    assert arg_replacer.replace("new", (1, 2), {}) == (
        2,
        (1, "new"),
        {},
    )
    assert arg_replacer.replace("new", (), {"second": 2}) == (
        2,
        (),
        {"second": "new"},
    )
    assert arg_replacer.replace("new", (), {}) == (None, (), {"second": "new"})



# Generated at 2022-06-24 09:30:49.273667
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class A(Configurable):
        def initialize(self, **kwargs):
            pass

    a = A(a=1)
    assert a.kwargs['a'] == 1

test_Configurable_initialize()

# Generated at 2022-06-24 09:30:55.905048
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def no_default(): return 0
    def with_default(x, y=1): return y
    def with_default_and_multiple_none(x, y=None, z=None): return y, z
    check_no_default = ArgReplacer(no_default, 'x')
    check_x = ArgReplacer(with_default, 'x')
    check_y = ArgReplacer(with_default, 'y')
    check_z = ArgReplacer(with_default_and_multiple_none, 'z')

    # Call no_default without any argument
    result = check_no_default.get_old_value(args=[], kwargs={})
    assert result==0, "Should return 0 by default"

    result = check_x.get_old_value(args=[], kwargs={})

# Generated at 2022-06-24 09:30:58.119332
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # We don't need to use type paramter here
    x: Any = ObjectDict()  # type: ignore
    x.y = 1  # type: ignore
    assert x.y == 1  # type: ignore



# Generated at 2022-06-24 09:31:09.530124
# Unit test for constructor of class Configurable
def test_Configurable():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo
        def configurable_default(self):
            return Bar
        def initialize(self, **kwargs):
            pass
    class Bar(Foo):
        pass
    class Baz(Foo):
        pass
    assert isinstance(Foo(), Bar)
    assert isinstance(Foo(), Foo)
    Foo.configure(Baz)
    assert isinstance(Foo(), Baz)
    Foo.configure(None)
    assert isinstance(Foo(), Bar)
    try:
        Foo.configure(Configurable)
        assert False
    except ValueError:
        pass
    # Test restore
    saved = Foo._save_configuration()
    Foo.configure(Baz, a=1)
    Foo._restore_config

# Generated at 2022-06-24 09:31:17.522598
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise ValueError
    except ValueError as e:
        err = errno_from_exception(e)
        assert err is None

    class MyError(Exception):
        pass

    try:
        raise MyError(1, 2)
    except MyError as e:
        err = errno_from_exception(e)
        assert isinstance(err, int)
        assert err == 1

    try:
        raise MyError("error")
    except MyError as e:
        err = errno_from_exception(e)
        assert isinstance(err, str)
        assert err == "error"



# Generated at 2022-06-24 09:31:22.218196
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    dd = ObjectDict()
    dd.name = "test"
    assert isinstance(dd, ObjectDict)

    assert dd.name == "test"
    assert dd.keys() == ["name"]

    dd["name"] = "test1"
    assert dd.name == "test1"
    assert dd.keys() == ["name"]



# Generated at 2022-06-24 09:31:29.290409
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(None)
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise Exception((1,))
    except Exception as e:
        assert errno_from_exception(e) == 1



# Generated at 2022-06-24 09:31:32.305673
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    def f() -> None:
        d = ObjectDict()
        def g() -> int:
            return d.foo
        d["foo"] = 42
        return g()
    assert f() == 42



# Generated at 2022-06-24 09:31:37.015381
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError
    except:
        # traceback object is something that does not implement __traceback__
        traceback = object()
        exc_info = (ValueError, ValueError(), traceback)
        with pytest.raises(ValueError) as ctx:
            raise_exc_info(exc_info)
        assert (ctx.__traceback__ is traceback) or (ctx.__traceback__ is None)



# Generated at 2022-06-24 09:31:46.863379
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    d = ObjectDict(a=1, b=2)
    assert d['a'] == 1
    assert d.a == 1
    assert d.b == 2
    d.c = 3
    assert d['c'] == 3
    assert d.c == 3
    assert d.get('c') == 3
    d2 = ObjectDict()  # type: ignore
    d2.values = lambda: None  # type: ignore
    d2.update(a=1, b=2, c=3)
    assert d2.a == 1
    assert d2.b == 2
    assert d2.c == 3



# Generated at 2022-06-24 09:31:53.237089
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    saved = AsyncIOMainLoop._save_configuration()
    try:
        AsyncIOMainLoop.configure(IOLoop)
        assert AsyncIOMainLoop.configured_class() == IOLoop
        assert isinstance(AsyncIOMainLoop(), IOLoop)
    finally:
        AsyncIOMainLoop._restore_configuration(saved)



# Generated at 2022-06-24 09:32:00.824565
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # create data
    data = b"\037\213\010\010\000\000\000\000\002\377"
    data += b"Hello World!\r\n"
    data += b"\r\n"
    # compress data
    comp = zlib.compressobj()
    data = comp.compress(data)
    data += comp.flush()
    # decompress data
    decomp = GzipDecompressor()
    data = decomp.decompress(data)
    data += decomp.flush()
    data += decomp.flush()
    # check result
    assert data == b"Hello World!\r\n\r\n"

# Not used in Tornado itself but available for applications that may
# want to implement their own logging filtering.  (The filter_handler
# function is used internally by the default

# Generated at 2022-06-24 09:32:01.300058
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    stream = GzipDecompressor()


# Generated at 2022-06-24 09:32:05.042640
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def expected_result_value(obj):
        return obj.asdf

    attrs = ObjectDict(asdf='asdf')
    expected_result = expected_result_value(attrs)
    actual_result = attrs.asdf
    assert expected_result == actual_result

# Generated at 2022-06-24 09:32:08.296279
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    a = ObjectDict(foo='bar')
    b = ObjectDict({'foo': 'bar'})
    assert a.foo == 'bar'
    assert b.foo == 'bar'



# Generated at 2022-06-24 09:32:13.553019
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class MyConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return MyConfigurable
        @classmethod
        def configurable_default(cls):
            class Impl(MyConfigurable):
                def initialize(self, x):
                    self.x = x
            return Impl
    MyConfigurable.configure(impl="")
    o = MyConfigurable(x=5)
    assert o.x == 5



# Generated at 2022-06-24 09:32:18.637975
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError as e:
        # This will raise a TypeError (no exception to throw) if this
        # function is broken.
        raise_exc_info(sys.exc_info())
    # Make sure we're not throwing the original exception
    assert e is not sys.exc_info()[1]



# Generated at 2022-06-24 09:32:20.422480
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    failures, _ = doctest.testmod()
    if failures:
        raise Exception("Failed %d doctests." % failures)


_upgraded_methods = frozenset(["GET", "HEAD", "POST", "PUT", "DELETE"])



# Generated at 2022-06-24 09:32:32.557701
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    d = GzipDecompressor()
    data = b'foo\x9cK\xcb\xcf\x07\x00bar'
    self.assertEqual(d.decompress(data), b'foo')
    self.assertEqual(d.flush(), b'bar')
    self.assertTrue(d.unconsumed_tail.startswith(b'bar'))
# test_GzipDecompressor_flush()


chunk_re = re.compile(br"([^\r]\n|\r\n?)")
# Match a literal chunk, ignoring the trailer
chunk_re_trailer = re.compile(br"\r\n?([0-9a-fA-F]+)(;.*)?\r\n(.*)",
                              re.DOTALL)


