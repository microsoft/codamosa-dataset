

# Generated at 2022-06-24 09:22:40.429591
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # This test comes from the original Tornardo
    # Run this test only if zlib is available
    if zlib is None:
        return

    d = GzipDecompressor()
    data = b'hhhhhhhhh\x01\x00\x00\xff\xff'
    res = d.decompress(data)
    assert res == b'hhhhhhhhh'
    assert d.unconsumed_tail == b'\x01\x00\x00\xff\xff'
    res = d.decompress(d.unconsumed_tail)
    assert res == b'\x01\x00\x00\xff\xff'
    assert d.unconsumed_tail == b''



# Generated at 2022-06-24 09:22:49.800945
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Impl(Configurable):

        @classmethod
        def configurable_base(cls):
            return Impl

        @classmethod
        def configurable_default(cls):
            return Impl

    class SubImpl(Impl):
        pass

    class SubSubImpl(Impl):
        pass

    Impl.configure(None)

# Generated at 2022-06-24 09:23:00.560258
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    if True:
        # Simple test, just a few short lines.
        decomp = GzipDecompressor()
        data = decomp.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xffHello\x00\x03\x00\x00\x00world\n\x00\x00\x00\x00\x00\x00\x00\x00')
        assert decomp.unconsumed_tail == b''
        assert data == b'Hello\n'
        data += decomp.decompress(b'world\n')
        assert data == b'Hello\nworld\n'
        data += decomp.decompress(b'')
        assert data == b'Hello\nworld\n'
        data += decomp

# Generated at 2022-06-24 09:23:11.684085
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func(a, b, c, x=4, y=5):
        return a, b, c, x, y

    r = ArgReplacer(func, 'x')
    assert r.replace("foo", (1, 2, 3), {}) == (4, (1, 2, 3), {})
    assert r.replace("foo", (1, 2, 3), {'x': 10}) == (10, (1, 2, 3), {})
    assert r.replace("foo", (1, 2, 3), {'y': 10}) == (None, (1, 2, 3), {'y': 10, 'x': "foo"})
    assert r.replace("bar", (), {'y': 10}) == (None, (), {'y': 10, 'x': "bar"})

# Generated at 2022-06-24 09:23:21.503081
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    r = ArgReplacer(f, "b")
    assert r.get_old_value((1, 2, 3), {}) == 2
    assert r.replace(4, (1, 2, 3), {}) == (2, (1, 4, 3), {})
    assert r.get_old_value((1, 2, 3), {}, "?") == "?"
    assert r.get_old_value((1, 2, 3, 4), {"c": 5}) == 2
    assert r.replace(4, (1, 2, 3, 4), {"c": 5}) == (2, (1, 4, 3, 4), {"c": 5})

    q = ArgReplacer(f, "d")

# Generated at 2022-06-24 09:23:25.843849
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Base(Configurable):
        def configurable_base(self):
            pass
        def configurable_default(self):
            pass
        def initialize(self):
            pass
    __1 = Base()
    Base.configure(None)
    __2 = Base.configured_class()
    __3 = Base._save_configuration()
    __4 = Base._restore_configuration(__3)



# Generated at 2022-06-24 09:23:31.555186
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    assert d == {}
    d["foo"] = 1
    assert d == {"foo": 1}
    assert d.foo == 1
    assert d["foo"] == 1
    assert list(d) == ["foo"]

# Alias for backwards compatibility
# TODO: remove this in Tornado 5.0
dictionary = ObjectDict


# Generated at 2022-06-24 09:23:35.658951
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):  # type: () -> Type[Base]
            return Base

        @classmethod
        def configurable_default(cls):  # type: () -> Type[Base]
            return DefaultImpl

        def use_impl(self):  # type: () -> str
            return "from " + self.__class__.__name__

        def override_from_config(self):  # type: () -> str
            return "from " + self.__class__.__name__

    class DefaultImpl(Base):
        pass

    class Impl1(Base):
        pass

    class Impl2(Base):
        def override_from_config(self):  # type: () -> str
            return "from Impl2"


# Generated at 2022-06-24 09:23:43.307549
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func1(a, b, c=1, d=2):
        pass

    def func2(a, b, *args, **kwargs):
        pass

    assert ArgReplacer(func1, "c").arg_pos is None
    assert ArgReplacer(func1, "c").get_old_value((3, 4), {}) == 1
    assert ArgReplacer(func1, "c").replace(5, (3, 4), {}) == (1, (3, 4), {"c": 5})
    assert ArgReplacer(func1, "c").replace(5, (3, 4, 6), {}) == (6, (3, 4, 5), {})
    # The following cases are not supported by ArgReplacer
    #assert ArgReplacer(func1, "c").get_old_value() == 1
   

# Generated at 2022-06-24 09:23:47.073653
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(days=1.5)) == 129600
    assert timedelta_to_seconds(datetime.timedelta(microseconds=2)) == 2e-06



# Generated at 2022-06-24 09:23:54.025803
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    """Ensures that basic configuration via Configurable works.

    The default configuration is for `Pair` to be implemented by
    `Tuple`.
    """
    # Sanity check:
    assert isinstance((0, 1), Tuple)

    class Pair(Configurable):
        def __init__(self, x, y):
            # type: (Any, Any) -> None
            self.x = x
            self.y = y

        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Pair

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Tuple

    p = Pair(0, 1)
    assert type(p) is Tuple
   

# Generated at 2022-06-24 09:23:56.251306
# Unit test for function import_object
def test_import_object():
    assert import_object("functools") is functools



# Generated at 2022-06-24 09:23:59.087989
# Unit test for function import_object
def test_import_object():
    assert import_object("sys") is sys                # noqa
    assert import_object("sys.stdout") is sys.stdout  # noqa
    try:
        import_object("tornado.i_dont_exist")
        raise AssertionError("expected ImportError")
    except ImportError:
        pass



# Generated at 2022-06-24 09:24:11.275982
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import unittest
    import tests.util

    class MyConfigurable(Configurable):
        def configurable_base(self):  # type: ignore
            return __class__

        def configurable_default(self):  # type: ignore
            return None

        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def _initialize(self):
            self.initialize_called = True

    class SubConfigurable(MyConfigurable):
        def configurable_base(self):  # type: ignore
            return __class__

        def configurable_default(self):  # type: ignore
            return MyConfigurable

    class AnotherSubConfigurable(SubConfigurable):
        def configurable_base(self):  # type: ignore
            return __class__

       

# Generated at 2022-06-24 09:24:19.737059
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A1

    class A1(A):
        def initialize(self, x, y):
            # type: (int, int) -> None
            self.z = x + y

    class A2(A):
        def initialize(self, a, b, c):
            # type: (int, int, int) -> None
            self.d = a + b + c

    assert A().z == 3

# Generated at 2022-06-24 09:24:21.408857
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1.25)) == 1.25



# Generated at 2022-06-24 09:24:25.680927
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from typing import Any , Callable , Dict , List , Optional , Type , Tuple , Union

    # Type annotations for the `initialize` method on class Configurable
    def initialize(  # type: ignore
        self: Any,
        *args: Any,
        **kwargs: Any
    ) -> None:
        pass

    # Type annotations for the `_initialize` method on class Configurable
    def _initialize(  # type: ignore
        self: Any
    ) -> None:
        pass


# Generated at 2022-06-24 09:24:31.598872
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo1(a, b, c=None):
        pass
    r1 = ArgReplacer(foo1, 'c')
    assert r1.replace(2, (1,2), {}) == (None, (1,2), {'c':2})
    r2 = ArgReplacer(foo1, 'b')
    assert r2.replace(3, (1,2), {}) == (2, (1,3), {})
    assert r2.replace(3, (1,2), {'c':4}) == (2, (1,3), {'c':4})
    r3 = ArgReplacer(foo1, 'a')
    assert r3.replace(5, (1,2), {}) == (1, (5,2), {})

# Generated at 2022-06-24 09:24:43.199269
# Unit test for constructor of class Configurable
def test_Configurable():
    assert isinstance(Configurable(), Configurable)
    with pytest.raises(
        NotImplementedError,
        match=r"Configurable subclasses must define the class methods "
        r"`configurable_base` and `configurable_default`",
    ):
        Configurable().configured_class()
    with pytest.raises(
        NotImplementedError,
        match=r"Configurable subclasses must define the class methods "
        r"`configurable_base` and `configurable_default`",
    ):
        Configurable.configure(None)


# Send a signal when an IOLoop is closed, in case we need a way to know
# when async activities are safe to shut down
_loop_signals = weakref.WeakKeyDictionary()  # type: Dict[IOLoop, Any]

# Generated at 2022-06-24 09:24:55.046515
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    def _test_GzipDecompressor_flush(e: bytes) -> None:
        d = GzipDecompressor()
        c = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
        data = c.compress(b'blah ' * 10000 + e) + c.flush()
        assert d.decompress(data) == b'blah ' * 10000
        assert d.flush() == e
        assert d.unconsumed_tail == b''
        # truncated
        for x in range(1, len(data)):
            d = GzipDecompressor()
            assert d.decompress(data[:x]) == b''
        # junk at end
        d = GzipDecompressor()
        d.decompress(data)


# Generated at 2022-06-24 09:24:57.621150
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict() # type: ObjectDict
    d.foo = "bar"
    assert d["foo"] == "bar"


# Generated at 2022-06-24 09:25:05.398854
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    a = GzipDecompressor()
    a.decompress(b'test')
    a.flush()
    a.decompress(b'hello')
    a.flush()
    a.decompress(b'world')
    a.flush()

    a.decompress(b'test', 2)
    a.flush()
    a.decompress(b'hello', 2)
    a.flush()
    a.decompress(b'world', 2)
    a.flush()



# Generated at 2022-06-24 09:25:13.290082
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class C1(Configurable):
        pass

    class C2(C1):
        pass

    class A(C2):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[A]
            return A

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[A]
            return A

    class B(A):
        def initialize(self, x):
            # type: (int) -> None
            self.x = x

    assert isinstance(A(), A)
    assert isinstance(B(42), B)

    B.configure("tornado.util.C2")  # type: ignore

# Generated at 2022-06-24 09:25:15.638045
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict((('hello', 1), ('world', 2)))
    assert d.hello == 1
    assert d.world == 2
    d.foo = 42
    assert d['foo'] == 42



# Generated at 2022-06-24 09:25:24.501123
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    data = b"".join(
        [
            '\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff'
            + chr(i).encode("latin-1") * i for i in range(256)
        ]
    )
    # Chop the input into a bunch of short strings.
    # This is intended to expose implementation bugs in python 2.6.1 and
    # earlier that failed to process input correctly in some cases when
    # the input string was not consumed in a single call.
    input = []  # type: List[bytes]
    while data:
        input.append(data[:20])
        data = data[20:]
    # First try with max_length = 0:
    gz = GzipDecompressor()
    output

# Generated at 2022-06-24 09:25:29.847993
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def new_args_kwargs(old_args, old_kwargs, *new_args, **new_kwargs):
        return old_args, old_kwargs, new_args, new_kwargs

    old_args = (1, 2, 3)
    old_kwargs = {"kw1": 4, "kw2": 5}
    arg_replacer = ArgReplacer(new_args_kwargs, "kw1")
    old_value, new_args, new_kwargs = arg_replacer.replace(
        6, old_args, old_kwargs
    )
    assert old_value == 4
    assert old_args == (1, 2, 3)
    assert old_kwargs == {"kw1": 4, "kw2": 5}
    assert new_args == old_args
    assert new_kwargs

# Generated at 2022-06-24 09:25:34.848170
# Unit test for constructor of class Configurable
def test_Configurable():
    myclass = Configurable()
    


# Backwards compatibility
AsyncHTTPClient = HTTPClient
AsyncHTTPClient.configure = HTTPClient.configure # type: ignore
AsyncHTTPClient.configured_class = HTTPClient.configured_class # type: ignore

if hasattr(typing, "TYPE_CHECKING"):
    # Export these to silence pytype about undeclared names
    HTTPError = HTTPError
    RequestStartLine = RequestStartLine

# Generated at 2022-06-24 09:25:44.135146
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from zlib import compress
    value = b'abcdefghiabcdefghiabcdefghi'
    compressed = compress(value)
    decompressor = GzipDecompressor()
    result = decompressor.decompress(compressed)
    assert result == value
    rest = decompressor.flush()
    assert not rest
    decompressor.decompress(compressed)
    assert not decompressor.unconsumed_tail
    decompressor.decompress(compressed, 1)
    assert decompressor.unconsumed_tail
    decompressor.flush()
    assert not decompressor.unconsumed_tail
    # decompressor is in a bad state after flush, can't test anymore



# Generated at 2022-06-24 09:25:46.591931
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    test_data = (b'hello world\n' * 100).encode("zlib")
    with GzipDecompressor() as decomp:
        assert decomp.decompress(test_data) == b'hello world\n' * 100



# Generated at 2022-06-24 09:25:55.195482
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import zlib

# Generated at 2022-06-24 09:26:02.742610
# Unit test for function errno_from_exception
def test_errno_from_exception():
    import errno
    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) == 0

    try:
        raise IOError(errno.ENOENT, "No such file or directory")
    except Exception as e:
        assert errno_from_exception(e) == errno.ENOENT

    try:
        try:
            raise IOError(errno.ENOENT, "No such file or directory")
        except Exception as e:
            raise IOError(str(e))
    except Exception as e:
        if typing.TYPE_CHECKING:
            assert isinstance(e.args[0], IOError)
        assert errno_from_exception(e.args[0]) == errno.ENOENT


# Generated at 2022-06-24 09:26:05.646833
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    obj = None
    try:
        obj = GzipDecompressor()
    except:
        pass
    res = obj.flush()
    print(res)


# Generated at 2022-06-24 09:26:10.384853
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def f(a, b=None, *args, **kwargs):
        return a, b, args, kwargs
    ins = ArgReplacer(f, "a")
    t = ins.get_old_value(("a", "b", 1, 2, 3), dict())
    assert t == "a"
    def g(a, b=None, *args, **kwargs):
        return a, b, args, kwargs
    ins = ArgReplacer(g, "a")
    t = ins.get_old_value((1, 2, 3), dict(a="a"))
    assert t == "a"
    def h(a, b=None, *args, **kwargs):
        return a, b, args, kwargs
    ins = ArgReplacer(h, "a")
    t = ins

# Generated at 2022-06-24 09:26:13.699561
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=1, microseconds=1)) == 1.000001



# Generated at 2022-06-24 09:26:15.337573
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.attr = 1
    assert d['attr'] == 1

# Generated at 2022-06-24 09:26:19.502832
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = GzipDecompressor()
    gzip_decompressor.decompress(b'a')
    gzip_decompressor.decompress(b'b')
    gzip_decompressor.flush()
    return gzip_decompressor


# Generated at 2022-06-24 09:26:29.039800
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(None)
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(1, 2)
    except Exception as e:
        assert errno_from_exception(e) == 1

    try:
        raise IOError()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(None)
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise IOError(1)
    except Exception as e:
        assert errno_from_exception(e) == 1

   

# Generated at 2022-06-24 09:26:33.782698
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    initialized = []
    class PreviewHandler(Configurable):
        def _initialize(self, a, b, **kwargs):
            initialized.append((a, b))

    PreviewHandler.configure(PreviewHandler, c=3)
    h = PreviewHandler(1, 2)
    assert initialized == [(1, 2)]



# Generated at 2022-06-24 09:26:41.803118
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 0.000001
    assert timedelta_to_seconds(datetime.timedelta(milliseconds=1)) == 0.001
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1.0
    assert timedelta_to_seconds(datetime.timedelta(minutes=1)) == 60.0
    assert timedelta_to_seconds(datetime.timedelta(hours=1)) == 3600.0
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 86400.0


if not hasattr(datetime.timedelta, "total_seconds"):
    datetime.timedelta.total_seconds = timedelta_to_seconds

#

# Generated at 2022-06-24 09:26:51.720417
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    import unittest
    import tornado.util

    class ObjectDictTest(unittest.TestCase):
        def test_ObjectDict(self):
            # type: () -> None
            obj = tornado.util.ObjectDict()
            obj.a = 1
            self.assertEqual(obj.a, 1)
            self.assertEqual(obj["a"], 1)
            obj["a"] = 2
            self.assertEqual(obj.a, 2)
            self.assertEqual(obj["a"], 2)
            def f():
                # type: () -> Any
                return obj.b
            self.assertRaises(tornado.util.AttributeError, f)
            def g():
                # type: () -> Any
                return obj["b"]

# Generated at 2022-06-24 09:26:55.980019
# Unit test for function exec_in
def test_exec_in():
    glob = {}
    loc = {}
    exec_in('foo = 6', glob, loc)
    assert glob['foo'] == 6
    assert loc['foo'] == 6


_TIMEOUT_SIGS = (signal.SIGALRM, signal.SIGVTALRM, signal.SIGPROF)
_signal_registered = False



# Generated at 2022-06-24 09:26:59.064481
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    class Base(Configurable):
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return Base

        def configurable_default(self):
            # type: () -> Type[Configurable]
            return Impl



# Generated at 2022-06-24 09:27:02.852974
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def my_func(*args, **kwargs):
        pass
    replacer = ArgReplacer(my_func, "arg")
    assert replacer.get_old_value(("1",), {"arg": "2"}, "3") == "2"
    assert replacer.get_old_value(("1",), {"arg": "2"}) == "2"
    assert replacer.get_old_value(("1",), {}, "3") == "3"
    assert replacer.get_old_value(("1",), {}) is None
# ASDF


# Generated at 2022-06-24 09:27:07.139527
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        test_raise_exc_info_raises_TypeError()
    except TypeError as e:
        if "test_raise_exc_info_raises_TypeError" not in str(e):
            raise e
    else:
        raise Exception("did not raise TypeError")



# Generated at 2022-06-24 09:27:10.136243
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()
    o.x = 5
    o.y = 'hello'
    o.z = None
    # Unknown attribute
    try:
        o.v
        assert False, 'Expected exception'
    except AttributeError:
        pass



# Generated at 2022-06-24 09:27:21.938902
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # coverage tests https://coverage.readthedocs.io/en/v4.5.x/subprocess.html#subprocess-coverage
    import subprocess
    with open(GzipDecompressor.__module__.replace('.', '/') + '.py') as f:
        report_script_lines = f.readlines()

    cmd = "coverage run --branch --source=%s %s %s" % (GzipDecompressor.__module__, GzipDecompressor.__module__.replace('.', '/') + '.py', 'test_GzipDecompressor_decompress')
    coverage = subprocess.run(cmd, shell=True)
    if coverage.returncode == 0:
        print("success")
    else:
        print('failed')
    print(report_script_lines)

# Generated at 2022-06-24 09:27:24.683988
# Unit test for function exec_in
def test_exec_in():
    globals = {}
    locals = {}
    exec_in("a = 42", globals, locals)
    assert locals["a"] == 42
    assert globals is not locals



# Generated at 2022-06-24 09:27:32.656496
# Unit test for function exec_in
def test_exec_in():
    d = dict(a=1)
    loc = dict(b=2)
    exec_in('c = a+b', d, loc)
    assert d['c'] == 3
    assert loc['c'] == 3


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__ import
# unicode_literals" have other problems (see PEP 414).  u() can be applied
# to ascii strings that include \u escapes (but they must not contain
# literal non-ascii characters).
# TODO: remove after dropping Python 3.2 support
_unicode_type = unicode_type
if str is unicode_type:

    def u(s: str) -> str:
        return s

    bytes_type = bytes
   

# Generated at 2022-06-24 09:27:43.876661
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gzip_decompressor = GzipDecompressor()
    # Try to define the variable in the global area of unit test
    global test_value_decompress
    # Need to check if the variable is defined, in case that it is not defined
    if 'test_value_decompress' in globals():
        # Decompress test_value, which was defined in test_GzipDecompressor_decompress method, to compare with test_value_decompress
        test_value_decompress_result = gzip_decompressor.decompress(test_value)
        # Compare the result of decompress method with test_value_decompress
        assert test_value_decompress_result == test_value_decompress



# Generated at 2022-06-24 09:27:54.614012
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"a\ b\ c") == r"a b c"
    assert re_unescape(r"a\07") == r"a\x07"
    assert re_unescape(r"\g") == r"\g"
    assert re_unescape(r"\x") == r"\x"
    assert re_unescape(r"\n") == r"\n"
    assert re_unescape(r"[a\]") == r"[a]"
    assert re_unescape(r"[a\]+") == r"[a]+"
    assert re_unescape(r"[a\b]") == r"[a\b]"
    assert re_unescape(r"[a\b]+") == r"[a\b]+"

# Generated at 2022-06-24 09:27:57.343157
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(4)) == 345600.0



# Generated at 2022-06-24 09:28:04.840968
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_func(arg1, arg2):
        pass

    arg_replacer = ArgReplacer(test_func, "arg2")
    old_value = arg_replacer.get_old_value((1,), {"arg2": 4})
    assert old_value == 4

    old_value = arg_replacer.get_old_value((1, 2), {})
    assert old_value == 2

    old_value = arg_replacer.get_old_value((1,), {"arg1": 3})
    assert old_value == None

# Generated at 2022-06-24 09:28:07.714607
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise_exc_info(ValueError, ValueError("test_raise_exc_info_error"))
    except ValueError:
        pass



# Generated at 2022-06-24 09:28:15.579950
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    def f():
        a = ObjectDict()
        a.foo = 1
        a.bar = 2
        assert a['foo'] == 1
        assert a.bar == 2
        assert list(a.keys()) == ['foo', 'bar']
        # No exception should be thrown when __setattr__ fails,
        # as this should use __setitem__
        a['1'] = 'baz'

# Generated at 2022-06-24 09:28:20.956692
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    old_value, args, kwargs = ArgReplacer(func_replace, 'key').replace('new_value', ('arg1',), {'key': 'value'})
    assert old_value == 'value'
    assert args == ('arg1',)
    assert kwargs == {'key': 'new_value'}



# Generated at 2022-06-24 09:28:23.331957
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def test(hello, world="1", *args, **kwargs):
        pass

    assert ArgReplacer(test, "hello").arg_pos == 0
    assert ArgReplacer(test, "world").arg_pos is None
    assert ArgReplacer(test, "world").get_old_value([2, 3, 4], {"hello": 5}) == "1"



# Generated at 2022-06-24 09:28:33.636850
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict({"a": 1})
    d.b = 2
    assert d["a"] == d.a == 1
    assert d["b"] == d.b == 2

LocaleAlternate = Optional[List[str]]
LocaleInfo = Tuple[str, LocaleAlternate]

# Match language (_) and optional country and encoding (as per
# RFC1766, e.g. en, en_US, zh_CN.GB18030)

# Generated at 2022-06-24 09:28:41.833905
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("") == ""
    assert re_unescape("$*+?{}()[]^.|") == "$*+?{}()[]^.|"
    assert re_unescape("\\a\\b\\c") == "\a\b\c"
    assert re_unescape("\\\\") == "\\"
    assert re_unescape("\\;") == ";"
    assert re_unescape("\\w") == "w"
    assert re_unescape("\\d") == "d"
    assert re_unescape("\\s") == "s"
    assert re_unescape("\\S") == "S"
    assert re_unescape("\\D") == "D"
    assert re_unescape("\\W") == "W"
    assert re_unescape("\\number") == "number"

# Generated at 2022-06-24 09:28:43.877160
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj['name'] = 'value1'
    assert obj.name == 'value1'


# Generated at 2022-06-24 09:28:54.605877
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    """Tests whether the get_old_value method works.
    """

    def func1(a, b):
        return a, b

    def func2(a, b):
        return

    def func3(a, b, c=None):
        return a, b, c

    def func4(a, b, c=None):
        return

    ar = ArgReplacer(func1, 'a')
    assert ar.get_old_value([1, 2], {}) == 1
    assert ar.get_old_value([], {'a': 1, 'b': 2}) == 1
    assert ar.get_old_value([1, 2], {'b': 2}) == 1
    assert ar.get_old_value([1, 2], {'b': 2, 'a': 42}) == 1

# Generated at 2022-06-24 09:28:56.651954
# Unit test for function doctests
def test_doctests():
    doctests()

# Generated at 2022-06-24 09:28:59.912399
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConcreteConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConcreteConfigurable

        @classmethod
        def configurable_default(cls):
            return ConcreteConfigurable

    c = ConcreteConfigurable()
    assert isinstance(c, ConcreteConfigurable)



# Generated at 2022-06-24 09:29:02.964850
# Unit test for function exec_in
def test_exec_in():
    a = 1
    exec_in('b = a + 1', locals())
    assert b == 2
    exec_in('c = a + 1', globals())
    assert c == 2



# Generated at 2022-06-24 09:29:11.258291
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    test_func_1 = lambda kwarg_1, arg1=2,  arg2=3: None
    test_func_2 = lambda kwarg_1, kwarg_2, arg1=2,  arg2=3: None
    test_func_3 = lambda kwarg_1, kwarg_2, arg1=2,  arg2=3, *args: None
    assert ArgReplacer(test_func_1, "arg1").get_old_value((1,), {}) == 2
    assert ArgReplacer(test_func_1, "kwarg_1").get_old_value((1,), {}) is None
    assert ArgReplacer(test_func_1, "arg1").get_old_value((1,), {}, default=-1) == 2

# Generated at 2022-06-24 09:29:21.803469
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass


try:
    import concurrent.futures

    concurrent_futures = concurrent.futures  # type: module
except ImportError:  # Python 2.6
    concurrent_futures = None

try:
    import thread

    thread = thread  # type: module
except ImportError:  # Python 3
    import _thread as thread

try:
    import resource

    resource = resource  # type: module
except ImportError:  # Windows
    resource = None

try:
    from socket import AF_INET, AF_INET6, AF_UNIX
except ImportError:
    # Python 2.6 or Windows
    AF_INET = object()
    AF_INET6 = object()

# Generated at 2022-06-24 09:29:28.978331
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b=10, c="hello"):
        return (a, b, c)

    arg_replacer = ArgReplacer(f, "b")
    assert arg_replacer.get_old_value((1,), {}, 20) == 20
    assert arg_replacer.get_old_value((1, 2), {}, 20) == 2
    assert arg_replacer.get_old_value((1, 2, 3), {}, 20) == 2
    assert arg_replacer.get_old_value((1,), {"b": 20}, 30) == 20
    assert arg_replacer.get_old_value((1, 2), {"b": 20}, 30) == 2
    assert arg_replacer.get_old_value((1,), {"c": "world"}, 30) == 30
    assert arg_

# Generated at 2022-06-24 09:29:33.008038
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    a = ObjectDict()
    a.foo = None
    assert a['foo'] is None
    assert a.foo is a['foo']


# need to inherit object to support Python 3

# Generated at 2022-06-24 09:29:37.884401
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    assert isinstance(TimeoutError(), Exception)  # type: ignore


# In addition to serving as a base class for Configurable, IOLoop, and
# Resolver, this class allows testing of classes that have configure()
# methods without needing a real IOLoop (since IOLoop.configure is
# just a wrapper around this method and does not depend on IOLoop
# as its first argument).

# Generated at 2022-06-24 09:29:47.143077
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\x") == "x"
    assert re_unescape(r"\a") == "\a"
    assert re_unescape(r"\001") == "\001"
    assert re_unescape(r"\\") == "\\"
    assert re_unescape(r"\$") == "$"
    assert re_unescape(r"\*") == "*"
    assert re_unescape(r"\+") == "+"

    with pytest.raises(ValueError):
        re_unescape(r"\d")



# Generated at 2022-06-24 09:29:48.866225
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 09:29:51.869089
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    """Will raise exception if data is invalid"""
    GzipDecompressor().flush()



# Generated at 2022-06-24 09:30:02.090522
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    #static
    def f(a, b, c=1, d=2):
        pass

    ar = ArgReplacer(f, "c")
    assert ar.get_old_value((1, 2), {}) == 1
    assert ar.get_old_value((1, 2), {"c": None}) == None
    assert ar.get_old_value((1, 2), {"d": None}) == 1
    assert ar.get_old_value((1,), {"c": 3, "d": None}) == 3

    # Method with self
    class Foo(object):
        bar = False

        def f(self, a, b, c=1, d=2):
            pass

    ar = ArgReplacer(Foo.f, "c")

# Generated at 2022-06-24 09:30:13.047316
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def f(a, b, c):
        pass

    assert ArgReplacer(f, "b").get_old_value((1, 2, 3), {}) == 2
    assert ArgReplacer(f, "c").get_old_value((1, 2, 3), {}) == 3
    assert ArgReplacer(f, "d").get_old_value((1, 2, 3), {}) is None
    assert ArgReplacer(f, "c").get_old_value((1, 2, 3), {}) == 3
    assert ArgReplacer(f, "d").get_old_value((1, 2, 3), {}, "foo") == "foo"


# Generated at 2022-06-24 09:30:21.646048
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def testFunc(a=None, b=None):
        print(a, b)
    replacer = ArgReplacer(testFunc, 'a')
    print('a is None:')
    testFunc()
    print('a is 1:')
    old_value, args, kwargs = replacer.replace(1, (), {})
    testFunc(*args, **kwargs)
    print('a is 2:')
    old_value, args, kwargs = replacer.replace(2, args, kwargs)
    testFunc(*args, **kwargs)



# Generated at 2022-06-24 09:30:23.921258
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    import datetime
    from typing import Any
    assert ObjectDict().__setattr__('key', datetime.datetime.now())



# Generated at 2022-06-24 09:30:25.251195
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    err = TimeoutError()
    assert isinstance(err, TimeoutError)
    assert isinstance(err, gen.TimeoutError)
    assert isinstance(err, ioloop.TimeoutError)



# Generated at 2022-06-24 09:30:34.902696
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=2, minutes=1)) == timedelta_to_seconds(
        datetime.timedelta(days=1, hours=47, minutes=1)
    )
    assert timedelta_to_seconds(datetime.timedelta(days=0)) == timedelta_to_seconds(
        datetime.timedelta(hours=0)
    )


# Typeshed doesn't currently include typing.UnwrapType.
# See https://github.com/python/mypy/issues/5242
if TYPE_CHECKING:  # pragma: no cover
    UnwrapType = Callable[["UnwrapType"], Any]
else:
    UnwrapType = typing.Callable[[typing.Callable], Any]



# Generated at 2022-06-24 09:30:36.881384
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    TimeoutError()
    TimeoutError("test")



# Generated at 2022-06-24 09:30:44.081191
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError("foo")
    except:  # noqa: E722
        x = sys.exc_info()
        try:
            raise_exc_info(x)
        except ValueError as e:
            assert e.args == ("foo",)
        else:
            assert False, "ValueError not raised"
        try:
            raise_exc_info((None, None, None))
        except TypeError as e:
            assert e.args == ("raise_exc_info called with no exception",)
        else:
            assert False, "TypeError not raised"



# Generated at 2022-06-24 09:30:50.903200
# Unit test for function re_unescape
def test_re_unescape():
    # This test is ugly because there's no point in testing actual regular
    # expressions because re.escape is very simple and is tested as part of
    # the standard library.
    assert re_unescape("") == ""
    assert re_unescape("a\\\\b") == "a\\b"
    assert re_unescape("\\a") == "\\a"
    assert re_unescape("\\1") == "\\1"
    assert re_unescape("\n") == "\n"
    assert re_unescape("\\\\n") == "\\n"
    assert re_unescape("\\\\\n") == "\\\n"
    assert re_unescape("a\\\nb") == "a\nb"
    assert re_unescape("a\\\r\nb") == "a\nb"

# Generated at 2022-06-24 09:31:00.440201
# Unit test for constructor of class Configurable
def test_Configurable():
    class Dummy(Configurable):
        def __init__(self, **kwargs):
            pass

        def initialize(self, **kwargs):
            self.initialize_called = True
            super(Dummy, self).initialize(**kwargs)

        @classmethod
        def configurable_base(cls):
            return Dummy

        @classmethod
        def configurable_default(cls):
            return Dummy

    class Subclass(Dummy):
        pass

    # Test an unconfigured class
    d = Dummy()
    assert isinstance(d, Dummy)
    assert d.initialize_called
    assert d._save_configuration() == (None, None)

    # Save configuration, check that it changes
    saved = d._save_configuration()

# Generated at 2022-06-24 09:31:05.601646
# Unit test for function exec_in
def test_exec_in():
    # type: () -> None
    def test_exec_in_helper():
        # type: () -> None
        exec_in("x = 5", dict(x=11))
        assert x == 5
        assert y == 6

    y = 6
    test_exec_in_helper()
    assert y == 6



# Generated at 2022-06-24 09:31:16.384362
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    from tornado.httputil import HTTPHeaders
    from tornado.http1connection import HTTP1Connection, HTTPServerConnectionDelegate
    from tornado.iostream import IOStream
    from tornado.tcpclient import TCPClient
    from tornado import gen, netutil, process
    from tornado.platform.auto import set_close_exec
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.tcpserver import TCPServer
    from tornado.test.httpclient_test import ExpectLog
    from tornado.testing import AsyncTestCase, get_unused_port
    from tornado.test.util import unittest
    from tornado import web
    from tornado import escape, stack_context, ioloop
    from tornado.escape import utf8, to_unicode, native_str
    from tornado.httpserver import HTTPServer

# Generated at 2022-06-24 09:31:21.038781
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import logging
    import tornado.escape

    _orig_stdout = sys.stdout


# Generated at 2022-06-24 09:31:31.965227
# Unit test for function doctests
def test_doctests():
    # type: () -> None

    def f1(a: int) -> int:
        """
        >>> print(f1(1))
        1
        """
        return a

    def f2(a: int, b: int) -> int:
        """
        >>> print(f2(1, 2))
        2
        """
        return a

    def f3(a: int, b: int, c: int) -> int:
        """
        >>> print(f3(1, 2, 3))
        3
        """
        return a

    def f4(a: int, b: int, c: int, d: int) -> int:
        """
        >>> print(f4(1, 2, 3, 4))
        4
        """
        return a


# Generated at 2022-06-24 09:31:33.929683
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 09:31:40.663037
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # JIT may behave differently, so we can't use the decorator
    def test_flush(self):
        # This is the same as the last test in http://hg.python.org/cpython/file/tip/Lib/test/test_zlib.py
        compressor = zlib.compressobj(9, zlib.DEFLATED, -zlib.MAX_WBITS)
        data = b"foo"
        compressed = compressor.compress(data)
        compressed += compressor.flush(zlib.Z_SYNC_FLUSH)
        compressed += b"12345678"  # some garbage after the data

        d = GzipDecompressor()
        # The first chunk of the gzip stream doesn't have a length, so we
        # have to split it off as a separate call to decompress.
        # test_z

# Generated at 2022-06-24 09:31:42.319454
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:31:47.121180
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        # this type of error is raised on mac
        raise OSError(40, 'The operation couldn’t be completed. '
                      'This operation timed out.')
    except Exception as e:
        assert errno_from_exception(e) == 40



# Generated at 2022-06-24 09:31:50.293931
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    last_exception = None
    # Exception has attrs: args, message
    try:
        flush()
    except Exception as e:
        last_exception = e
    # last_exception = None



# Generated at 2022-06-24 09:31:58.418640
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest


    class ConfClass(Configurable):
        
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return ConfClass

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return ConfClass

        @classmethod
        def _save_configuration(cls):
            # type: () -> Tuple[Optional[Type[Configurable]], Dict[str, Any]]
            return (cls.__impl_class, cls.__impl_kwargs)


# Generated at 2022-06-24 09:32:03.194007
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import functools
    super_new = functools.partial(super, Configurable)
    super_new().__new__(None)
    super_new().__new__(None, None)
    super_new().__new__(None, None, None)
    super_new().__new__(None, None, None, None)
    # Assert: no exception


# Generated at 2022-06-24 09:32:04.870496
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise_exc_info(None)
    except TypeError:
        pass



# Generated at 2022-06-24 09:32:06.014758
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    assert issubclass(ArgReplacer, object)



# Generated at 2022-06-24 09:32:14.862488
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():

    # setup
    class A(object):
        def __init__(self, a, b=1, *args, **kwargs):
            pass

    class B(Configurable):
        @classmethod
        def configurable_base(self):
            return A

    # test
    assert B().__class__ == A
    assert B(1, 2, 3, c=4).__class__ == A
    assert B(1, 2, 3, c=4).__class__ == A

    B.configure(A)
    assert B().__class__ == A
    assert B(1, 2, 3, c=4).__class__ == A
    assert B(1, 2, 3, c=4).__class__ == A

    # teardown

    # setup

# Generated at 2022-06-24 09:32:25.919131
# Unit test for function exec_in
def test_exec_in():  # type: () -> None
    # A simple exec_in test
    global test_exec_in  # type: ignore
    test_exec_in = 1
    test = {}
    exec_in("test_exec_in = 2", test)
    assert test["test_exec_in"] == 2

    # Under python3, the following should raise a SyntaxError
    try:
        exec_in("print ('hi'))", test)
        raise Exception("did not get expected syntax error")
    except SyntaxError:
        pass

    # Dealing with nested scopes
    x = y = z = 0

    def inner():
        global x
        x = 1

    test = {}
    exec_in("x=1; y=1", test)
    assert test == {"x": 1, "y": 1}

# Generated at 2022-06-24 09:32:36.169986
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    d = GzipDecompressor()