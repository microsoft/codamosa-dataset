

# Generated at 2022-06-24 09:22:35.028145
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # type: ignore
    d = ObjectDict()  # type: ObjectDict
    d.x = 1
    assert d['x'] == 1
    assert d.x == d['x']
    d['y'] = 2
    assert d.y == 2
    assert d['y'] == d.y
    d.z = [3, 4, 5]
    assert d['z'] == [3, 4, 5]
    assert d.z == d['z']



# Generated at 2022-06-24 09:22:36.970136
# Unit test for constructor of class TimeoutError
def test_TimeoutError():  # type: ignore
    _ = TimeoutError("foo")

try:
    # On some systems time.clock has microsecond granularity
    # and variable accuracy.  time.time is always more accurate
    # but may not have microsecond granularity.
    default_clock = time.clock
except Exception:
    default_clock = time.time



# Generated at 2022-06-24 09:22:46.841482
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def test_function(a, b, c=3, d=4):
        pass

    arg_replacer = ArgReplacer(test_function, "d")
    assert arg_replacer.name == "d"
    assert arg_replacer.arg_pos is None

    old_value, args, kwargs = arg_replacer.replace(7, (1, 2), {})
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {"d": 7}

    old_value, args, kwargs = arg_replacer.replace(7, (1, 2), {"d": 5})
    assert old_value == 5
    assert args == (1, 2)
    assert kwargs == {"d": 7}


# Generated at 2022-06-24 09:22:55.598551
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def no_args():
        pass

    assert ArgReplacer(no_args, "foo").get_old_value((), {}, 42) == 42

    def one_arg(foo):
        pass

    assert ArgReplacer(one_arg, "foo").get_old_value((1,), {}, 42) == 1
    assert ArgReplacer(one_arg, "foo").get_old_value((), {"foo": 1}, 42) == 1

    def two_args(foo, bar):
        pass

    assert ArgReplacer(two_args, "foo").get_old_value((1, 2), {}, 42) == 1
    assert ArgReplacer(two_args, "foo").get_old_value((), {"foo": 1}, 42) == 1


# Generated at 2022-06-24 09:22:57.802904
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.a = True
    assert d['a'] is True

# Generated at 2022-06-24 09:23:04.427055
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=3, d=4):
        pass

    replacer = ArgReplacer(func, "c")
    assert replacer.get_old_value((1, 2), {}) == 3
    assert replacer.get_old_value((1, 2), {"c": 5}) == 5
    assert replacer.get_old_value((1, 2), {}, "default") == "default"



# Generated at 2022-06-24 09:23:06.200748
# Unit test for function import_object
def test_import_object():
    import_object("tornado.test.import_object_test")



# Generated at 2022-06-24 09:23:09.797871
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise IOError(1)
    except IOError as e:
        assert errno_from_exception(e) == 1
    try:
        raise IOError(2, 3)
    except IOError as e:
        assert errno_from_exception(e) == 2
    try:
        raise IOError(4, 5, "foo")
    except IOError as e:
        assert errno_from_exception(e) == 4



# Generated at 2022-06-24 09:23:16.060650
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("abc") == "abc"
    assert re_unescape("abc\\.123") == "abc.123"
    assert re_unescape("abc\\*123") == "abc*123"
    assert re_unescape("\\.123") == ".123"
    for s in ("\\d", "\\"):
        try:
            re_unescape(s)
        except ValueError:
            pass
        else:  # pragma: nocover
            raise AssertionError("did not raise on %r" % s)


# A very primitive memoization decorator.  Not safe for general use.

# Generated at 2022-06-24 09:23:23.915533
# Unit test for function import_object
def test_import_object():
    # test importing a module
    assert import_object('xml') is xml

    # test importing a module from a package
    assert import_object('xml.dom') is xml.dom

    # test importing a function from a module
    import xml.dom.minidom
    assert import_object('xml.dom.minidom.parseString') == xml.dom.minidom.parseString

    # test importing a function from a module from a package
    assert import_object('xml.dom.minidom.parseString') == xml.dom.minidom.parseString

    # test importing an attribute from a module from a package
    assert import_object('xml.dom.minidom.Attr') is xml.dom.minidom.Attr

    # test importing a subpackage from a package

# Generated at 2022-06-24 09:23:26.933043
# Unit test for function import_object
def test_import_object():
    import_object('tornado.test.util_test')
    #import_object('tornado.test.util_test.test_import_object')



# Generated at 2022-06-24 09:23:37.190753
# Unit test for function doctests
def test_doctests():
    from tornado.test.util import unittest, SkipTest
    import inspect
    import doctest
    globs = locals()
    for name, fn in globals().items():
        if name.startswith('_') or not inspect.isfunction(fn):
            continue
        try:
            doctest.run_docstring_examples(
                fn, globs,
                name=fn.__module__ + '.' + fn.__name__)
        except doctest.UnexpectedException as e:
            raise AssertionError("Exception raised in %s: %s" %
                                 (name, e.msg))
        except Exception:  # pylint: disable=broad-except
            raise SkipTest("test_doctests assertion failed in %s" % name)



# Generated at 2022-06-24 09:23:46.679328
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.concurrent import Future, wait
    from tornado import gen
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.process
    import threading
    import socket
    class SampleConfigurable(Configurable):
        pass
    class SampleConfigurableResult(SampleConfigurable):
        def __init__(self,*args, **kwargs):
            super(SampleConfigurableResult, self).__init__(*args, **kwargs)
            self.result = True
    class SampleConfigurableFail(SampleConfigurable):
        def __init__(self,*args, **kwargs):
            super(SampleConfigurableFail, self).__init__(*args, **kwargs)
            self.result = False

# Generated at 2022-06-24 09:23:48.925970
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import unittest

    failure_count, test_count = doctest.testmod()
    assert failure_count == 0
    unittest.main()



# Generated at 2022-06-24 09:23:49.805826
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    pass



# Generated at 2022-06-24 09:23:53.582800
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    d = ObjectDict(a=1)
    assert d.a == 1
    assert d.b is None
    assert d["a"] == 1
    assert d["b"] is None
    try:
        d.c
        assert False, "should not get here"
    except AttributeError:
        pass


# Generated at 2022-06-24 09:24:03.735626
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    s = b'\x1f\x8b\x08\x08\x13\x6b\x6b\x51\x02\xff\x6d\x6f\xdb\x36\x10\xfc\xf7\x57\xfc' \
        b'\xaf\xb8\xdd\x53\x01\x04\x00\x00\xff\xff\x0a\x99\x53\x4a\x0c\x00\x00\x00'
    gz_decompressor = GzipDecompressor()
    result = gz_decompressor.decompress(s)
    assert result
    assert gz_decompressor.unconsumed_tail == b''
    result = gz_decompressor.flush()

# Generated at 2022-06-24 09:24:09.896397
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo
        def configurable_default(self):
            return Foo
    # Assert that Configurable.initialize accepts keyword arguments.
    # This is a redundant test with respect to AsyncHTTPClient,
    # but it's easy to test here.
    Foo().initialize(foo="bar", baz=1)

# Generated at 2022-06-24 09:24:13.439933
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    test_str = '123456789'
    buf = GzipDecompressor()
    buf.decompress(gzip.compress(test_str.encode()))
    #print(buf.unconsumed_tail)
    #print(len(buf.unconsumed_tail))
    #print(buf.decompress(buf.unconsumed_tail))
    #print(len(buf.decompress(buf.unconsumed_tail)))
    print(buf.flush())

test_GzipDecompressor_flush()


# Generated at 2022-06-24 09:24:17.749174
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    def _test_gzip_decompressor_with_string(input_str: bytes) -> None:
        gz = GzipDecompressor()
        result = gz.decompress(input_str)
        assert gz.unconsumed_tail == b""
        assert result == input_str
        result += gz.flush()
        assert result == input_str

    _test_gzip_decompressor_with_string(b'abc')
    _test_gzip_decompressor_with_string(b'')
    _test_gzip_decompressor_with_string(b'0123456789')


# Generated at 2022-06-24 09:24:21.106985
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except Exception as e:
        assert isinstance(e, TimeoutError)



# Generated at 2022-06-24 09:24:27.662887
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=None, d=None):
        return a, b, c, d
    a = ArgReplacer(f, "a")
    b = ArgReplacer(f, "b")
    d = ArgReplacer(f, "d")
    assert f(1, 2, 3) == (1, 2, 3, None)

    _, args, kwargs = a.replace(11, (1, 2, 3), {})
    assert f(*args, **kwargs) == (11, 2, 3, None)

    _, args, kwargs = b.replace(22, (1, 2), {})
    assert f(*args, **kwargs) == (1, 22, None, None)


# Generated at 2022-06-24 09:24:34.210213
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError
    except TimeoutError:
        pass
    try:
        raise TimeoutError("foo")
    except TimeoutError:
        pass
    try:
        raise TimeoutError("foo", "bar")
    except TimeoutError:
        pass

# Formerly lived in generated code.
TimeoutError.__reduce_ex__ = lambda self, proto=None: (TimeoutError, ())
TimeoutError.__module__ = "tornado.util"

# The following import doesn't appear on the first line to avoid a
# circular dependency (the gen module imports this module).
from tornado.util import _Timeout  # noqa: E402



# Generated at 2022-06-24 09:24:36.754393
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise Exception("foo")
    except:
        raise_exc_info(sys.exc_info())
    assert False



# Generated at 2022-06-24 09:24:48.576876
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(5, "Error")
    except IOError as e:
        assert errno_from_exception(e) == 5

    try:
        raise IOError("Error")
    except IOError as e:
        assert errno_from_exception(e) == 0

    try:
        try:
            raise IOError(5, "Error")
        except IOError as e:
            re_raise(*_exc_info_from_error(e, IOError))
    except IOError as e:
        assert errno_from_exception(e) == 5


# Fake byte literal support:  In python 2.6+, you can say b"foo" to
# get a byte literal (str in 2.x, bytes in 3.x).  There's no way to do
# that in a way that supports

# Generated at 2022-06-24 09:24:51.647347
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    try:
        g = GzipDecompressor()
        assert g.unconsumed_tail == b''
    except:
        raise Exception


# Generated at 2022-06-24 09:25:00.393950
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    # Fake the metadata
    doctest.__test__ = {}

    for name, function in globals().items():
        if name.startswith("test_") and isinstance(function, types.FunctionType):
            # TODO: should be doctest.set_unittest_reportflags
            doctest._unittest_reportflags = 0
            doctest.testmod(name=name, module=sys.modules[__name__], globs=globals())


if __name__ == "__main__":
    test_doctests()

# Generated at 2022-06-24 09:25:10.638829
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, c):
        pass

    a = ArgReplacer(f, "a")
    b = ArgReplacer(f, "b")
    c = ArgReplacer(f, "c")

    assert a.get_old_value((1,2,3), {}) == 1
    assert a.get_old_value((), {"a": 1}) == 1
    assert b.get_old_value((1,2,3), {}) == 2
    assert b.get_old_value((), {"b": 1}) == 1
    assert c.get_old_value((1,2,3), {}) == 3
    assert c.get_old_value((), {"c": 1}) == 1
    assert c.get_old_value((1,), {"a": 2}) == 1
    assert c.get

# Generated at 2022-06-24 09:25:14.115152
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    o = ObjectDict()
    o.attr1 = 'val1'
    o['attr2'] = 'val2'
    assert o['attr1'] == 'val1'
    assert o.attr2 == 'val2'

# Generated at 2022-06-24 09:25:17.050368
# Unit test for function errno_from_exception
def test_errno_from_exception():
    assert errno_from_exception(Exception()) is None
    try:
        raise Exception(42, "test")
    except Exception as e:
        errno = errno_from_exception(e)
        assert errno == 42



# Generated at 2022-06-24 09:25:21.659818
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    o = ObjectDict()  # type: typing.Any
    o.foo = 1
    o.bar = 2
    assert o.foo == 1
    assert o.bar == 2
    if typing.TYPE_CHECKING:
        try:
            o.baz
        except AttributeError:
            pass

        try:
            # noinspection PyTypeChecker
            o.baz = 3
            assert o.baz == 3
        except AttributeError:
            pass
test_ObjectDict___getattr__()



# Generated at 2022-06-24 09:25:27.033289
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class ConcreteConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return cls
        @classmethod
        def configurable_default(cls):
            return cls
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    c = ConcreteConfigurable(1, 2, foo=3)
    assert c.args == (1, 2)
    assert c.kwargs == {'foo': 3}
    assert isinstance(c, ConcreteConfigurable)
    c = ConcreteConfigurable(foo=3)
    assert c.args == ()
    assert c.kwargs == {'foo': 3}
    assert isinstance(c, ConcreteConfigurable)

    # Check subclassing and recursion

# Generated at 2022-06-24 09:25:36.486462
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, c=0, d=0):
        pass

    args = (1, 2)
    kwargs = {'d': 3}
    replacer = ArgReplacer(test_func, 'c')
    old_value, args, kwargs = replacer.replace(6, args, kwargs)
    assert old_value is None
    assert args == (1, 2)
    assert kwargs == {'d': 3, 'c': 6}
    kwargs = {'c': 7}
    old_value, args, kwargs = replacer.replace(6, args, kwargs)
    assert old_value == 7
    assert args == (1, 2)
    assert kwargs == {'c': 6}
    args = (1, 2, 3)


# Generated at 2022-06-24 09:25:47.208640
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def gen(a: str, b: str, c: str) -> None:
        pass

    arg_replacer = ArgReplacer(gen, 'b')
    old_value, args, kwargs = arg_replacer.replace('new_value', ('a', 'b', 'c'), {})
    assert old_value == 'b'
    assert args == ('a', 'new_value', 'c')
    assert kwargs == {}

    arg_replacer = ArgReplacer(gen, 'c')
    old_value, args, kwargs = arg_replacer.replace('new_value', ('a', 'b', 'c'), {})
    assert old_value == 'c'
    assert args == ('a', 'b', 'new_value')
    assert kwargs == {}

    arg_replacer = ArgRepl

# Generated at 2022-06-24 09:25:50.586562
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None

    obj = ObjectDict()
    obj['name'] = 'Nick'
    assert obj.name == 'Nick'

    with pytest.raises(AttributeError):
        obj.age



# Generated at 2022-06-24 09:25:51.308541
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    pass  # TODO

# Generated at 2022-06-24 09:25:57.464628
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    """Tests the method GzipDecompressor.flush
    """
    gzip_decompressor = GzipDecompressor()
    test_data = b'f\xf2\xcd\xc9\xc9\x07\x00\x04\xe7o\x08\x04'
    gzip_decompressor.decompress(test_data, max_length=6)
    gzip_decompressor.decompress(test_data[6:], max_length=0)
    gzip_decompressor.flush()



# Generated at 2022-06-24 09:26:04.250531
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    doctests()


# In Python 2.7.1 (and 2.7.0?), the order of kwargs is undefined.
# As a result, the doctests in this file are fragile.  There is a
# well-defined order (dictionaries have an order, and it's the one
# their items are inserted in) but it's version-dependent.  This is
# frustrating but it seems to have always been this way:
# http://docs.python.org/2/faq/library.html#how-can-i-get-deterministic-order-when-using-kwargs

# These tests are also fragile on 2.6 because the sorting of instance attributes is
# arbitrary.  However, 2.6 has a non-fragile order of kwargs, so it can be fixed by
# testing the

# Generated at 2022-06-24 09:26:09.207122
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(a, b, *args, **kwargs):
        return a, b, args, kwargs

    assert ArgReplacer(f, "a").arg_pos == 0
    assert ArgReplacer(f, "b").arg_pos == 1
    assert ArgReplacer(f, "c").arg_pos is None

    assert ArgReplacer(f, "a").get_old_value((1, 2), {}) == 1
    assert ArgReplacer(f, "a").get_old_value((1, 2), {}, default=-1) == 1
    assert ArgReplacer(f, "c").get_old_value((1, 2), {}) is None
    assert ArgReplacer(f, "c").get_old_value((1, 2), {}, default=-1) == -1

# Generated at 2022-06-24 09:26:14.733521
# Unit test for function re_unescape
def test_re_unescape():
    r = re.compile(r'\s\d\.\w\\\(\)\[\]')
    s = r'\s\d\.\w\\\(\)\[\]'
    assert r.match(' s0.w\\()[]')
    assert re_unescape(s) == '\\s\\d\\.\\w\\\\\\(\\)\\[\\]'



# Generated at 2022-06-24 09:26:16.883581
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict(a=1, b=2)
    assert obj.a == 1
    assert obj.b == 2



# Generated at 2022-06-24 09:26:27.455920
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # type: () -> None
    import typing
    import unittest
    import unittest.mock
    class TestConfigurable(Configurable):
        @classmethod
        def configurable_base(cls):
            return TestConfigurable
        @classmethod
        def configurable_default(cls):
            return TestConfigurableDefaultImplementation
    class TestConfigurableDefaultImplementation(TestConfigurable):
        def _initialize(self, *args, **kwargs):
            pass
    class TestConfigurableImplementation(TestConfigurable):
        def _initialize(self, *args, **kwargs):
            pass

# Generated at 2022-06-24 09:26:31.056628
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def f():
        # type: () -> typing.NoReturn
        raise_exc_info(sys.exc_info())

    try:
        f()
    except ZeroDivisionError:
        pass



# Generated at 2022-06-24 09:26:39.957219
# Unit test for function exec_in
def test_exec_in():
    exec_in(
        code="a=5", glob={"__builtins__": __builtins__, "a": 4}, loc={"__builtins__": __builtins__}
    )


# Fake unicode literal support:  Python 3.2 doesn't have the u'' marker for
# literal strings, and alternative solutions like "from __future__"
# aren't compatible with "from tornado.util import exec_in".  u() can be
# applied to ascii strings that include \u escapes (but they must not
# contain literal non-ascii characters).
if str is not bytes:
    def u(s: str) -> str:
        return s

# Generated at 2022-06-24 09:26:42.864639
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 09:26:45.222828
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    err = TimeoutError()
    assert isinstance(err, TimeoutError)
    assert isinstance(err, Exception)



# Generated at 2022-06-24 09:26:48.046960
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    D = ObjectDict()
    D['test'] = 42
    assert D.test == 42
    D.test = 43
    assert D['test'] == 43



# Generated at 2022-06-24 09:26:48.703359
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass

# Generated at 2022-06-24 09:26:54.963341
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # Anonymous class, subclass of ABC
    class A(Configurable):
        def __init__(self, value):
            self.value = value

        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return A1

    # Anonymous class, subclass of Configurable, not of ABC
    class B(Configurable):
        def __init__(self, value):
            self.value = value

        @classmethod
        def configurable_base(cls):
            return B

        @classmethod
        def configurable_default(cls):
            return B1

    # Named class, subclass of ABC
    class C(Configurable):
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-24 09:26:57.939291
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    x = ObjectDict()  # type: ObjectDict
    x['a'] = 1
    assert x.a == 1
    assert ObjectDict.__getattr__(x, 'a') == 1


# Generated at 2022-06-24 09:27:03.548833
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    import logging
    import tornado.gen

    try:
        raise tornado.gen.TimeoutError("testing")
    except tornado.gen.TimeoutError:
        logging.exception("test")
        raise
test_TimeoutError()


try:
    import thread  # type: ignore
except ImportError:
    import _thread as thread  # type: ignore


_timeout_exceptions = (TimeoutError, OSError, IOError)

# Generated at 2022-06-24 09:27:08.818192
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():

    def foo1(x):
        return x

    def foo2(x, y):
        return x, y

    def foo3(x, y, z):
        return x, y, z

    def foo4(x, y, z, *args):
        return x, y, z, args

    def foo5(x, y, z, *args, **kwargs):
        return x, y, z, args, kwargs

    def foo6(x, y, z, **kwargs):
        return x, y, z, kwargs

    def foo7(x, y, z=0, **kwargs):
        return x, y, z, kwargs

    def foo8(x=0, y=0, z=0, **kwargs):
        return x, y, z, kwargs

   

# Generated at 2022-06-24 09:27:11.904100
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict({'a': 1})
    assert x['a'] == 1
    assert x.a == 1
    x.a = 2
    assert x['a'] == 2
    x['a'] = 3
    assert x.a == 3



# Generated at 2022-06-24 09:27:24.399227
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def foo1(a, b, c=1, d=2):
        pass

    def foo2(a, b=1):
        pass

    args1 = (1, 2, 3, 4)
    kwargs1 = {"d": 11}
    r1 = ArgReplacer(foo1, "c")
    assert r1.arg_pos == 2
    assert r1.get_old_value(*ArgReplacer.replace(999, args1, kwargs1)) == 3
    assert r1.get_old_value(*args1, **kwargs1) == 3

    args2 = (1, 2)
    kwargs2 = {}
    r2 = ArgReplacer(foo2, "b")
    assert r2.arg_pos == 1

# Generated at 2022-06-24 09:27:27.519551
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    foo = [10, 20, 30]
    bar = 'hi'
    baz = 30
    res = ArgReplacer.get_old_value(foo, bar, baz)
    assert res == None


# Generated at 2022-06-24 09:27:30.438496
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    test_suite = doctests()
    runner = doctest.DocTestRunner(verbosity=2)
    for test in test_suite:  # type: ignore
        runner.run(test)
    assert runner.summarize(verbose=True)["failed"] == 0


# Replacement for getattr that applies isinstance to the result

# Generated at 2022-06-24 09:27:35.479178
# Unit test for constructor of class Configurable

# Generated at 2022-06-24 09:27:42.657701
# Unit test for function exec_in
def test_exec_in():
    glob = {}
    loc = {}
    exec_in("b=5", glob, loc)
    assert glob['b'] == 5
    assert loc['b'] == 5


try:
    exec(compile("""def reraise(tp, value, tb=None):
    raise tp, value, tb
""", "<test>", "exec"))  # type: ignore
except SyntaxError:
    exec("def reraise(tp, value, tb=None):\n    raise tp, value, tb")



# Generated at 2022-06-24 09:27:46.849104
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None

    assert not hasattr(ArgReplacer, "test_foo")
    AR = ArgReplacer(test_ArgReplacer, "foo")
    assert not hasattr(AR, "test_foo")
    assert AR.name == "foo"



# Generated at 2022-06-24 09:27:50.186310
# Unit test for function import_object
def test_import_object():
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        raise Exception("expected ImportError")



# Generated at 2022-06-24 09:27:53.795625
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    test_string = b"hello, gzip"
    gzip = GzipDecompressor()
    # Compress the string
    import gzip as gzip_module
    s = gzip_module.compress(test_string)
    # Decompress the string
    r = gzip.decompress(s)
    assert r == test_string
    r = gzip.decompress(s)
    assert r == test_string



# Generated at 2022-06-24 09:28:03.860689
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # Test that decompression is resumable when max_length is provided,
    # and that decompression completes when flush() is called.
    compressor = GzipDecompressor()
    test_data = b'test_data'
    max_length = 3
    with open(__file__, "rb") as f:
        gz_data = f.read()
    # Pass only as much data as can be decompressed.
    gz_body = gz_data[:max_length]
    body = gz_body + test_data
    while body:
        data = compressor.decompress(body, max_length)
        if data:  # data will be empty when max_length is too small.
            assert test_data not in data
            body = body[len(data) :]

# Generated at 2022-06-24 09:28:09.741857
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(22)
    except Exception as e:
        assert errno_from_exception(e) == 22

    try:
        e = Exception()
        e.errno = 11
        raise e
    except Exception as e:
        assert errno_from_exception(e) == 11



# Generated at 2022-06-24 09:28:14.819534
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=5, hours=5)) == 18000


if not hasattr(datetime.timedelta, "total_seconds"):  # type: ignore
    timedelta_to_seconds = lambda td: (
        (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10 ** 6) / 10 ** 6
    )



# Generated at 2022-06-24 09:28:20.133456
# Unit test for function exec_in
def test_exec_in():
    exec_in('a = 1', {'b': 2})
    exec_in('a = 1', {'b': 2}, {'c': 3})
    exec_in('a = b', {'b': 2}, {'b': 3})
    exec_in('a = b', {'b': 2}, {'c': 3})



# Generated at 2022-06-24 09:28:23.052167
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass

# Alias for consistency with previous Tornado versions
gen_TimeoutError = TimeoutError
ioloop_TimeoutError = TimeoutError



# Generated at 2022-06-24 09:28:28.275333
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    """Test __setattr__ method of class ObjectDict
    https://github.com/tornadoweb/tornado/blob/master/tornado/util.py
    """
    obj_dict = ObjectDict()
    obj_dict.test = 1
    assert obj_dict['test'] == 1
    assert obj_dict.test == 1



# Generated at 2022-06-24 09:28:37.816975
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise IndexError()
    except:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)


if hasattr(Exception, "__traceback__"):
    # PY3: __traceback__ is always set for all exceptions.
    # we still use sys.exc_info() to get the traceback for logging.
    def _exc_info() -> Optional[Tuple[Type, BaseException, TracebackType]]:
        # type: ignore
        return sys.exc_info()

    def _exc_info_repr(exc_info: Tuple[Type, BaseException, TracebackType]) -> str:
        # type: ignore
        exc_type, exc_value, tb = exc_info

# Generated at 2022-06-24 09:28:48.007167
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        def initialize(self) -> None:
            pass
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return Base
        @classmethod
        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return Base

    class Impl1(Base):
        pass

    class Impl2(Base):
        pass

    assert isinstance(Base(), Base)
    assert isinstance(Impl1(), Base)
    assert isinstance(Impl2(), Base)
    Base.configure(Impl1)
    assert isinstance(Base(), Base)
    assert isinstance(Base(), Impl1)
    assert not isinstance(Base(), Impl2)

    # This is the key test: we are overriding the configured class
    #

# Generated at 2022-06-24 09:28:59.620846
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import unittest

    from tornado.testing import AsyncTestCase

    from tornado.util import exec_in

    # Some doctests need to run in a non-global scope.
    class DocTest(AsyncTestCase):
        def test_doctest(self):
            # type: () -> None
            scope = {}  # type: Dict[str, Any]
            exec_in(doctests()._tests[0].docstring, scope)

    if __name__ == "__main__":
        try:
            import unittest.mock as mock
        except ImportError:
            import mock

        mock.patch.dict(globals(), {"__name__": "__main__"}).start()
        unittest.main()

# Generated at 2022-06-24 09:29:02.873704
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():  # type: ignore
    objekt = ObjectDict()
    try:
        objekt.foo = "bar"
    except AttributeError:
        return "foo"
    return objekt.foo



# Generated at 2022-06-24 09:29:06.040006
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.foo = 'foo'
    assert d.foo == 'foo'
    d.foo = 'bar'
    assert d.foo == 'bar'
test_ObjectDict___setattr__()


# Generated at 2022-06-24 09:29:17.473555
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def f(self, a, b, c):
        pass

    def g(a, b):
        pass

    assert ArgReplacer(f, "a").get_old_value((1, 2, 3), {}) == 1
    assert ArgReplacer(f, "c").get_old_value((1, 2, 3), {}) == 3
    assert ArgReplacer(f, "d").get_old_value((1, 2, 3), {}) == None
    assert ArgReplacer(f, "d").get_old_value((1, 2, 3), {}, 4) == 4
    assert ArgReplacer(f, "a").get_old_value((1,), {"a": 11}) == 11
    assert ArgReplacer(f, "b").get_old_value((1,), {"b": 22}) == 22
   

# Generated at 2022-06-24 09:29:26.138310
# Unit test for function exec_in
def test_exec_in():
    def test_basic():
        a = object()
        l = {}
        g = {'a': a}
        exec_in('assert a is b', g, l)
        exec_in('b = a', g, l)
        assert a is l['b']
        with pytest.raises(AssertionError):
            exec_in('assert a is b', l, g)

    def test_exec():
        a = []
        b = {}
        exec_in('b[1] = 2', b)
        assert b[1] == 2
        exec_in('assert 1 in b')
        exec_in('a += [1]', b)
        exec_in('a += [b[1]]', b)
        exec_in('a += list(b.values())', b)

# Generated at 2022-06-24 09:29:27.956411
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    d = GzipDecompressor()
    d.decompress(b"1")
    d.flush()


# Generated at 2022-06-24 09:29:37.926688
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def fn(*a, **kw):
        # type: (*Any, **Any) -> None
        pass

    assert ArgReplacer(fn, "a").arg_pos is None

    def fn(a, *a1, **kw):
        # type: (Any, *Any, **Any) -> None
        pass

    assert ArgReplacer(fn, "a").arg_pos == 0

    def fn(a, b, *a1, **kw):
        # type: (Any, Any, *Any, **Any) -> None
        pass

    assert ArgReplacer(fn, "a").arg_pos == 0
    assert ArgReplacer(fn, "b").arg_pos == 1



# Generated at 2022-06-24 09:29:42.082654
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    """
    Tests for the initialize method of the Configurable class
    """
    base = ConfigurableClass()
    impl_class = ConfigurableClass()
    impl_class.configure(None, **{})
    assert impl_class.configured_class() is ConfigurableClass
    # The initialize method of the Configurable class will be called here
    impl_instance = impl_class()
    assert impl_instance.initialize() == 'Impl-initialize called'
    assert impl_instance._initialize() == 'Impl-initialize called'
    class NewConfigurableClass(ConfigurableClass):
        def initialize(self):
            return 'New-initialize called'
    new_instance = NewConfigurableClass()
    assert new_instance.initialize() == 'New-initialize called'
    assert new_instance._

# Generated at 2022-06-24 09:29:52.196317
# Unit test for constructor of class Configurable
def test_Configurable():

    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A

        @classmethod
        def configurable_default(cls):
            return B

        def initialize(self, a, b=1):
            self.a = a
            self.b = b

    class B(A):
        pass

    class C(A):
        def initialize(self, a, b=1, c=2):
            self.c = c
            super(C, self).initialize(a, b)

    A.configure(B)
    x = A(2)
    assert isinstance(x, B)
    assert x.a == 2
    assert x.b == 1

    A.configure(impl=None)
    assert A.configured_class() is B
    A

# Generated at 2022-06-24 09:30:01.011338
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # A simple test that doesn't depend on a file.
    import zlib
    orig = b"12345678"
    c = GzipDecompressor()
    compressed = zlib.compress(orig)
    assert c.decompress(compressed) == orig

    c = GzipDecompressor()
    compressed = zlib.compress(orig)
    assert c.decompress(compressed) == orig
    assert c.flush() == b""
    # test for Issue1751 (http://trac.tornadoweb.org/ticket/1751)
    c = GzipDecompressor()
    assert c.decompress(compressed, 1) == orig



# Generated at 2022-06-24 09:30:12.218914
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    decompressor = GzipDecompressor()
    data = decompressor.decompress(b"abc")
    assert data == b""
    data = decompressor.decompress(b"\x1f\x8b\x08\x00\xba\x1e\x02\xff"
                                   b"\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x04\xff"
                                   b"\xa7*\x9b\x03\x00\x00\x00")
    assert data == b"abc"
    data = decompressor.decompress(b"", 4)
    assert data == b""
    data = decompressor.decompress(b"1")
    assert data == b""
    data = decompressor.dec

# Generated at 2022-06-24 09:30:15.737438
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    d = ObjectDict()
    d.hello = 'world'
    assert d['hello'] == 'world'
    assert d.hello == 'world'
    assert d.goodbye == AttributeError


# Generated at 2022-06-24 09:30:20.549535
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.x = 1
    assert d.x == 1
    assert d["x"] == 1
    d["y"] = 2
    assert d["y"] == 2
    assert d.y == 2


# TODO: consider putting this into the exceptions module

# Generated at 2022-06-24 09:30:23.169865
# Unit test for function raise_exc_info
def test_raise_exc_info():
    class MyException(Exception):
        pass
    try:
        raise MyException()
    except MyException as e:
        raise_exc_info(sys.exc_info())


# Generated at 2022-06-24 09:30:33.286089
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    with open(__file__, "rb") as f:
        with GzipFile(fileobj=f) as gzf:
            gzf.read()
            test_data = gzf.read1()

    with GzipDecompressor() as gzd:
        assert gzd.decompress(test_data)

    def test_decompress(data: bytes, max_length: int) -> None:
        with GzipDecompressor() as gzd:
            decompressed = gzd.decompress(data, max_length)
            assert decompressed == b"foo", (
                "decompress(data[:max_length=%d]) == %r, not b'foo'",
                max_length,
                decompressed,
            )

# Generated at 2022-06-24 09:30:37.336358
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    from io import BytesIO
    zbuf = BytesIO()
    zfile = gzip.GzipFile(mode='wb', fileobj=zbuf)
    zfile.write(b'some compression')
    zfile.close()
    d = GzipDecompressor()
    data = d.decompress(zbuf.getvalue())
    assert data == b'some compression'
    assert d.unconsumed_tail == b''
    data2 = d.flush()
    assert data2 == b''


# Generated at 2022-06-24 09:30:42.500135
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise ZeroDivisionError()
        assert False  # silence pyflakes; we should never reach this
    except Exception:
        exc_info = sys.exc_info()
    def f():
        # type: () -> None
        raise_exc_info(exc_info)
    with ExpectLog('raise_exc_info called with no exception'):
        f()



# Generated at 2022-06-24 09:30:46.939096
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Foo(Configurable):
        pass
    Foo.configure('tests.configure')
    assert not isinstance(Foo(), Foo)
    assert isinstance(Foo(), configure)
    def test():
        class Bar(Configurable):
            pass
        Bar.configure('tests.configure')
        assert isinstance(Bar(), configure)
        assert not isinstance(Bar(), Bar)
    test()

# Generated at 2022-06-24 09:30:54.187578
# Unit test for function re_unescape
def test_re_unescape():
    assert u"[" == re_unescape(u"\[")
    for i in [1, 2, 3, 4, 5, 14, 15, 16, 17, 18]:
        re_unescape(u"\\" + chr(i))
    for i in [32, 33, 36, 48, 49, 50, 51, 52, 53, 54]:
        re_unescape(u"\\x" + chr(i))
    for i in [60, 61, 62, 63, 64, 127]:
        re_unescape(u"\\0" + chr(i))
    re_unescape(u"\\x3f")
    re_unescape(u"\\0?")
    re_unescape(u"\\xff")
    re_unescape(u"\\xFF")

# Generated at 2022-06-24 09:30:59.089926
# Unit test for constructor of class ObjectDict
def test_ObjectDict():  # type: () -> None
    d = ObjectDict({"a": 1, "b": 2})
    assert d["a"] == 1
    assert d.a == 1
    assert d.b == 2
    d.a = 5
    assert d["a"] == 5
    assert d.a == 5
    assert d["b"] == 2
    assert d.b == 2
    try:
        d.c
    except AttributeError:
        pass
    else:
        raise Exception("should have thrown an AttributeError")

    d['c'] = 0
    assert d['c'] == 0
    assert d.c == 0



# Generated at 2022-06-24 09:31:04.401991
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(foo, bar=1, baz=3):
        pass
    a = ArgReplacer(f, 'bar')
    old_value, args, kwargs = a.replace(2, (1,), {})
    assert old_value == 1
    assert args == (1,)
    assert kwargs == {}
    assert a.get_old_value((1,), {}) == 1
    old_value, args, kwargs = a.replace(2, (), {'bar':1})
    assert old_value == 1
    assert args == ()
    assert kwargs == {'bar':1}
    assert a.get_old_value((), {'bar':1}) == 1
    old_value, args, kwargs = a.replace(2, (), {})
    assert old_value is None


# Generated at 2022-06-24 09:31:12.482099
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    d = ObjectDict()
    d.foo = 'bar'
    assert d["foo"] == "bar"
    assert d.foo == "bar"
    assert d.bar is None
    d.x.y.z = "1"
    assert d.x.y.z == "1"
    assert d["x"]["y"]["z"] == "1"
    assert type(d.x) is ObjectDict
    assert type(d.x.y) is ObjectDict

# Fake undocuments functions
# pylint: disable=W0104



# Generated at 2022-06-24 09:31:17.811371
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict()
    obj.attr1 = 1
    obj.attr2 = 2
    assert obj['attr1'] == 1
    assert obj['attr2'] == 2
    assert obj.attr1 == 1
    assert obj.attr2 == 2
    assert list(obj.keys()) == ['attr1', 'attr2']

# Alias for ObjectDict, for historical reasons
DictAdapter = ObjectDict



# Generated at 2022-06-24 09:31:28.207724
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    if not hasattr(TimeoutError, "__qualname__"):
        from sys import exc_info

        # in Python 2 TimeoutError is a type
        assert issubclass(TimeoutError, Exception)
        assert isinstance(TimeoutError(), Exception)
        # and the constructor is unusual
        assert TimeoutError().args == ()
        assert TimeoutError("foo")[0] == "foo"
        try:
            raise TimeoutError()
        except TimeoutError:
            assert isinstance(exc_info()[1], TimeoutError)
    else:
        assert isinstance(TimeoutError(), TimeoutError)
        assert TimeoutError().args == ()
        assert TimeoutError("foo").args == ("foo",)


# Make TimeoutError a subclass of concurrent.futures._base.TimeoutError
# in order to share behavior with concurrent

# Generated at 2022-06-24 09:31:31.146971
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    impl_class = configured_class()
    instance = Configurable.__new__(impl_class)
    assert isinstance(instance, impl_class)


# Generated at 2022-06-24 09:31:35.440159
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None
    d = ObjectDict()  # type: Any
    d["test_property"] = "test_value"
    # Tests that __getattr__ method is called when __getitem__ method returns KeyError exception
    test_attr = str(d.test_property)  # type: ignore
    assert test_attr == "test_value"


# Generated at 2022-06-24 09:31:46.915183
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def get_old_value(name, args = None, kwargs = None, default = None):
        if args is None:
            args = ()
        if kwargs is None:
            kwargs = {}
        return ArgReplacer(test_func, name).get_old_value(args, kwargs, default)

    def test_func(arg_1, arg_2, arg_3 = ''):
        pass

    assert get_old_value('arg_1', (), {'arg_2': 42, 'arg_3': 43}) == None
    assert get_old_value('arg_1', ((), {'arg_2': 42, 'arg_3': 43})) == None
    assert get_old_value('arg_1', ((), {'arg_3': 43})) == None
    assert get_old

# Generated at 2022-06-24 09:31:50.974765
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    # type: () -> None
    def fun(a, b, c=5, d=6):
        pass

    ar = ArgReplacer(fun, "c")
    assert ar.get_old_value([None, None], {}) == 5
    assert ar.get_old_value([None, None, 8], {}) == 8
    assert ar.get_old_value([None, None], {"c": 9}) == 9

    assert ar.replace(10, [None, None], {"d": 11}) == (5, [None, None, 10], {"d": 11})
    assert ar.replace(12, [None, None, 13], {"d": 14}) == (13, [None, None, 12], {"d": 14})

# Generated at 2022-06-24 09:31:55.450016
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    GzipDecompressor()

_PAIR_OF_HEADER_PARTS_REGEX = re.compile(r"^([^:]+):\s*(.*)$")
_PAIR_OF_HEADER_PARTS = Tuple[str, str]



# Generated at 2022-06-24 09:32:02.788421
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.options
    import tornado.testing
    import tornado.web
    _ArgReplacer = ArgReplacer
    class Foo(object):
        def bar1(self, x, y=3):
            return x + y, y
        def bar2(self, x, y=3):
            return x + y, y
    f = Foo()
    def run_test(new_value, old_value, args, kwargs):
        old_value_, args_, kwargs_ = _ArgReplacer(Foo.bar1, 'y').replace(
            new_value, args, kwargs)
        assert old_value is None or old_value_ == old_value

# Generated at 2022-06-24 09:32:04.907411
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    # type: () -> None

    def foo():
        # type: () -> None
        obj_dict = ObjectDict()
        obj_dict.set_value('test_key', 'test_value')
        assert obj_dict['test_key'] == 'test_value'

    foo()


# Generated at 2022-06-24 09:32:13.663896
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
    try:
        raise_exc_info(exc_info)
    except:
        exc_info2 = sys.exc_info()
    assert exc_info[1] is exc_info2[1]
    if exc_info[2] is not None and exc_info2[2] is not None:
        # Python 3.5 doesn't copy the traceback, so we can't compare them.
        # https://bugs.python.org/issue30365
        assert exc_info[2].tb_next is exc_info2[2]


_FILE_CACHE: Dict[str, int] = {}



# Generated at 2022-06-24 09:32:25.242389
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    # This is the example from PEP-0476 with modification :
    # implementation detail to size of buffer
    # also, no need to test if the bufsize used is None,
    # because None values are only used with decompress function
    # with no second argument.
    # 442 is the size of input data
    bufsize = 442
    data = ("x" * 1500).encode("latin1")
    compressor = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
    compressed = compressor.compress(data)
    compressed += compressor.flush()
    assert len(compressed) > 0
    assert isinstance(compressed, bytes)
    decompressor = GzipDecompressor()
    result = b""

# Generated at 2022-06-24 09:32:29.644963
# Unit test for function exec_in
def test_exec_in():
    d = dict(x=1)
    exec_in('assert x == 1', d)  # noqa
    exec_in(b'assert x == 1', d)  # noqa


_BYTES_TYPE = type(b"")



# Generated at 2022-06-24 09:32:37.877381
# Unit test for constructor of class Configurable
def test_Configurable():
    class NotConfigurable:
        pass

    class ConfigurableNoDefault(Configurable):
        def configurable_default(self):
            pass

    class ConfigurableWithDefault(Configurable):
        def configurable_default(self):
            return NotConfigurable

    with pytest.raises(NotImplementedError):
        NotConfigurable.configuration_default()

    with pytest.raises(NotImplementedError):
        ConfigurableNoDefault.configuration_default()

    # configuring with wrong class
    with pytest.raises(ValueError):
        ConfigurableWithDefault(1, 2, 3, abc=3, xyz=4)

    # Not configured, default value should be used
    a = ConfigurableWithDefault(1)
    assert type(a) == NotConfigurable
    assert a.args == (1,)