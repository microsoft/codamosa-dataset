

# Generated at 2022-06-24 09:22:40.687194
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    pass


# Aliases for some common Exception types.
# Keeping just the exception name is future-proof - in Python 2.6
# there were separate exception classes for different error types,
# while in 2.7 they were all merged together into IOError.
try:
    from ssl import SSLError
except ImportError:
    class SSLError(Exception):
        pass
try:
    ConnectionError = OSError
except NameError:
    class ConnectionError(Exception):
        pass
try:
    BlockingIOError = OSError
except NameError:
    class BlockingIOError(Exception):
        pass
try:
    from subprocess import SubprocessError
except ImportError:
    class SubprocessError(Exception):
        pass



# Generated at 2022-06-24 09:22:41.452292
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    x = ObjectDict()
    x.hi = 20



# Generated at 2022-06-24 09:22:50.962321
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(*args, **kwargs): pass
    arg_replacer = ArgReplacer(func, "x")
    old_value, args, kwargs = arg_replacer.replace(10, (11,), {})
    assert old_value is None
    assert len(args) == 1 and args[0] == 10
    assert len(kwargs) == 0
    old_value, args, kwargs = arg_replacer.replace(20, (), {"x": 30})
    assert old_value == 30
    assert len(args) == 0
    assert kwargs["x"] == 20
    old_value, args, kwargs = arg_replacer.replace(40, (50,), {"x": 60})
    assert old_value == 50
    assert args[0] == 40
    assert kwargs["x"]

# Generated at 2022-06-24 09:22:56.975253
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise AssertionError()
    except AssertionError:
        test_exc_info = sys.exc_info()
    try:
        raise_exc_info(test_exc_info)
    except AssertionError:
        assert test_exc_info == sys.exc_info()
    else:
        assert False, "did not re-raise exception"
    try:
        raise_exc_info((None, None, None))
    except TypeError:
        pass
    else:
        assert False, "did not raise TypeError"



# Generated at 2022-06-24 09:23:08.940665
# Unit test for function exec_in
def test_exec_in():  # type: ignore
    def test_string() -> None:
        d = {'a': 1, 'b': 2}
        exec_in("assert a == 1", d)
        exec_in("assert b == 2", d)
        exec_in("assert c == 3", d, {'c': 3})
        try:
            exec_in("assert c == 3", d)
        except NameError:
            pass
        else:  # pragma: nocover
            raise Exception("didn't get expected NameError")

    def test_code() -> None:
        d = {'a': 1, 'b': 2}
        c = compile("assert a == 1", "<string>", "exec")
        exec_in(c, d)
        exec_in(c, d)  # ensure it works more than once, for good measure

# Generated at 2022-06-24 09:23:16.814339
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    from urllib.request import Request as Request_
    Request = ArgReplacer(Request_, "url").replace("foo", Request_("bar"))[1][0]
    assert Request.full_url == "foo"
    Request = ArgReplacer(Request_, "headers").replace({"bar": "baz"}, Request_("foo"))[1][0]
    assert Request.get_full_url() == "foo"
    assert Request.headers["bar"] == "baz"
    Request = ArgReplacer(Request_, "data").replace(b"bar", Request_("foo", data=b"baz"))[1][0]
    assert Request.full_url == "foo"
    assert Request.data == b"bar"

# Generated at 2022-06-24 09:23:19.462270
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise socket.error(errno.EPERM)
    except OSError as e:
        assert errno_from_exception(e) == errno.EPERM



# Generated at 2022-06-24 09:23:31.475562
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        pass

    arg_replacer = ArgReplacer(func, 'b')
    old_value, args, kwargs = arg_replacer.replace('new value of arg b', (1,2,3), {})
    assert (old_value, args, kwargs) == (2, (1, 'new value of arg b', 3), {})

    old_value, args, kwargs = arg_replacer.replace('new value of arg b', (1,), {'c': 3, 'b': 2})
    assert (old_value, args, kwargs) == (2, (1,), {'c': 3, 'b': 'new value of arg b'})

re_unescape_replacement = _re_unescape_replacement
re_unescape_pattern

# Generated at 2022-06-24 09:23:39.270083
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None):
        pass

    rg = ArgReplacer(func, 'a')
    assert rg.get_old_value(('x', 'y', 'z'), {}) == 'x'
    assert rg.get_old_value(('x', 'y', 'z'), dict(c='t')) == 'x'
    assert rg.get_old_value(('x', 'y'), dict(c='t', a='z')) == 'z'

    rg = ArgReplacer(func, 'c')
    assert rg.get_old_value(('x', 'y', 'z'), {}) == None
    assert rg.get_old_value(('x', 'y', 'z'), dict(c='t')) == 't'

# Generated at 2022-06-24 09:23:50.106691
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    from typing import Optional
    from typing import Union
    from typing import cast
    from typing import Type
    from typing import Any
    from typing import Dict
    from typing import Callable
    from typing import Sequence
    import unittest
    import baz

    class UnitTest(unittest.TestCase):
        def test_1(self):
            D = baz.ObjectDict()
            D.foo = 'bar'
            assert len(D.__dict__) == 0, "boo"
            assert D['foo'] == 'bar', "bar"
            del D.foo
            assert len(D) == 0, "baz"
            with self.assertRaisesRegex(AttributeError, "quux"):
                D.foo
        def test_2(self):
            D = baz.ObjectDict()


# Generated at 2022-06-24 09:24:01.863113
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def test_func(a, b, f, c, d=None, e=None):
        pass

    FuncArgReplacer = ArgReplacer(test_func, "f")

    old_value = FuncArgReplacer.get_old_value((1, 2, 5, 6), {})
    assert old_value == 5

    old_value = FuncArgReplacer.get_old_value((1, 2, 5, 6), {"d": 7})
    assert old_value == 5

    old_value = FuncArgReplacer.get_old_value((1, 2, 5, 6), {"e": 7})
    assert old_value == 5

    old_value = FuncArgReplacer.get_old_value((1, 2, 5, 6), {"f": 7})
    assert old_value == 7

   

# Generated at 2022-06-24 09:24:07.049986
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    decompressor = GzipDecompressor()
    data = b'foobar'
    decompressor.decompress(data)
    reg = decompressor.flush()
    assert reg == b'foobar', "Wrong value {} returned".format(reg)
assert error_count == 0, "{} Errors found".format(error_count)

# Generated at 2022-06-24 09:24:12.518522
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
        async def raise_now():
            # type: () -> None
            raise_exc_info(exc_info)
        # Verify that the exception can be raised without making this
        # stack frame unraisable, and that the original traceback is
        # preserved.
        full_tb = exc_info[2]
        loop = IOLoop.current()
        try:
            loop.run_sync(raise_now)
        except ZeroDivisionError as e:
            assert full_tb == e.__traceback__
            assert exc_info[1] is e
        else:
            assert False, "did not raise"



# Generated at 2022-06-24 09:24:20.641577
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(arg1, arg2, arg3, kwarg1=None):
        pass
    replacer = ArgReplacer(func, "arg1")
    assert replacer.replace(1, (5,), {"arg2": 2, "arg3": 3}) == (5, (1,), {"arg2": 2, "arg3": 3})
    assert replacer.replace(1, (5, 2, 3), {"arg3": 3}) == (5, (1, 2, 3), {"arg3": 3})
    assert replacer.replace(1, (5, 2, 3), {"arg3": 3, "kwarg1": 4}) == (5, (1, 2, 3), {"arg3": 3, "kwarg1": 4})
    replacer = ArgReplacer(func, "arg2")

# Generated at 2022-06-24 09:24:26.674664
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c=1, d=2):
        pass
    repl = ArgReplacer(f, "c")
    assert repl.replace(0, (1,2), {}) == (1, (1,2,0), {})
    assert repl.replace(0, (1,2), dict(c=1)) == (1, (1,2,0), {})
    assert repl.replace(0, (1,2), dict(c=1, d=2)) == (1, (1,2,0), dict(d=2))
    with pytest.raises(ValueError) as e:
        repl.get_old_value((1,2), {})
    assert e.value.args[0] == "c"

# Generated at 2022-06-24 09:24:32.908315
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(a, b, c):
        # assume args are always passed by position
        return a + b + c
    r = ArgReplacer(func, 'a')
    # test args, kwargs with multiple args, include arg to be replaced
    a = 10
    b = 20
    c = 30
    args = (a, b, c)
    kwargs = {}
    old_value, new_args, new_kwargs = r.replace(40, args, kwargs)
    assert old_value == a
    assert new_args[0] == 40
    # Test args, kwargs with multiple args, do not include arg to be replaced
    a = 10
    b = 20
    c = 30
    args = (b, c)
    kwargs = {'a': a}
    old_value

# Generated at 2022-06-24 09:24:35.829560
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"foo\x2bbar") == "foo+bar"
    assert re_unescape(r"foo\\\dbar") == "foo\\dbar"
    with pytest.raises(ValueError):
        re_unescape(r"foo\dbar")



# Generated at 2022-06-24 09:24:41.458887
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    td = datetime.timedelta(1, 2, 3, 4, 5, 6, 7)
    assert timedelta_to_seconds(td) == 1 * 24 * 60 * 60 + 2 * 60 * 60 + \
        3 * 60 + 4 + 5 * 1e-6 + 6 * 1e-6 + 7 * 1e-6



# Generated at 2022-06-24 09:24:44.165351
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj_dict = ObjectDict()
    obj_dict.name = 'value'
    assert(obj_dict['name'] == 'value')


# Generated at 2022-06-24 09:24:48.786484
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    import zlib
    gzip_decompressor = GzipDecompressor()
    gzip_decompressor.decompressobj = zlib.decompressobj(16 + zlib.MAX_WBITS)
    gzip_decompressor.flush()



# Generated at 2022-06-24 09:25:00.392378
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def fn1(foo, bar, baz="spam"):
        pass
    def fn2(self, foo, bar):
        pass
    def fn3(foo, bar, **kwargs):
        pass
    def fn4(foo, bar, *args):
        pass
    def fn5(foo, bar, *args, **kwargs):
        pass
    def fn6(foo, bar):
        pass

    arg_replacer = ArgReplacer(fn1, 'foo')
    # test case if foo is passed by positional arguments
    old_value, args, kwargs = arg_replacer.replace(0, (1, 2), {})
    assert old_value == 1
    assert args == (0, 2)
    assert kwargs == {}
    # test case if foo is passed by keyword arguments
    old_

# Generated at 2022-06-24 09:25:05.551753
# Unit test for function exec_in
def test_exec_in():
    loc: Mapping[str, Any] = {}
    exec_in('x = 1', globals(), loc)
    assert loc == {'x': 1}
    loc = {}
    exec_in('x = 1', {}, loc)
    assert loc == {'x': 1}
test_exec_in()



# Generated at 2022-06-24 09:25:08.472426
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.foo = 10
    assert d["foo"] == 10

# Generated at 2022-06-24 09:25:13.405210
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    from tornado.escape import utf8
    from tornado.util import GzipDecompressor
    import zlib

    def test_decompress_utf8() -> None:
        compression_text = zlib.compress(utf8("hello world"))
        decompressor = GzipDecompressor()
        assert decompressor.decompress(compression_text) == utf8("hello world")



# Generated at 2022-06-24 09:25:17.993286
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError
    except IOError as e:
        assert errno_from_exception(e) is None
    try:
        raise IOError(22)
    except IOError as e:
        assert errno_from_exception(e) == 22



# Generated at 2022-06-24 09:25:26.173025
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class A(Configurable):
        @classmethod
        def configurable_base(cls):
            return A
        @classmethod
        def configurable_default(cls):
            return A
    class B(A):
        def initialize(self, arg1, arg2, arg3=None, arg4=None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.arg4 = arg4
    class C(A):
        def initialize(self, arg1, arg2, arg3=None, arg4=None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.arg4 = arg4
    A.configure(B, arg4=4)

# Generated at 2022-06-24 09:25:32.170829
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    __tracebackhide__ = True
    import unittest.mock
    from functools import partial
    from tornado.testing import ExpectLog

    # For some of the tests below, we want to check that the
    # initializer was called with the right arguments, so we set up a
    # mock object to replace the actual initializer. However, this
    # interferes with our subclassing, so we create a new class each
    # time the mock initializer is called.
    #
    # We could use a mock class, but then we could only use the mock
    # instance we create and not any other instances of the class.


# Generated at 2022-06-24 09:25:34.663117
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(days=21, seconds=3)) == 1807803

# Generated at 2022-06-24 09:25:39.585966
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    from tornado.testing import AsyncTestCase, LogTrapTestCase

    loader = unittest.defaultTestLoader
    tests = (doctests(),)
    suite = unittest.TestSuite(tests)

    runner = unittest.TextTestRunner()
    runner.run(suite)



# Generated at 2022-06-24 09:25:46.891742
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(0, 60)) == 60
    assert timedelta_to_seconds(datetime.timedelta(1, 50)) == 86450
    assert timedelta_to_seconds(datetime.timedelta(0, 0, 100)) == 0.1
    assert timedelta_to_seconds(datetime.timedelta(0, 0, 100000)) == 0.1
    assert timedelta_to_seconds(datetime.timedelta(days=-1)) == -86400


# Generated at 2022-06-24 09:25:51.939618
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Spam(Configurable):
        @classmethod
        def configurable_base(cls):
            return Spam

        @classmethod
        def configurable_default(cls):
            return Spam

        def initialize(self, a, b=None):
            pass

    s = Spam(1)  # type: ignore
    s = Spam(1, 2)  # type: ignore



# Generated at 2022-06-24 09:25:57.014918
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape("\\a") == "\\a"
    assert re_unescape("\\\\") == "\\"
    assert re_unescape("\n") == "\n"
    assert re_unescape("\\\n") == "\n"  # \\n is parsed as \<newline>
    with pytest.raises(ValueError):
        re_unescape("\\d")



# Generated at 2022-06-24 09:26:08.202197
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import os.path
    import sys
    from tornado.ioloop import IOLoop
    if not hasattr(sys, "pypy_version_info") and sys.version_info < (3, 7):
        raise unittest.SkipTest("No class variable on python versions older than 3.7")
    IOLoop.configure("tornado.platform.asyncio.AsyncIOLoop")
    io_loop = IOLoop()
    assert isinstance(io_loop, IOLoop)

_DEFAULT_LOGGING_FORMAT = "%(color)s[%(levelname)1.1s %(asctime)s %(module)s:%(lineno)d]%(end_color)s %(message)s"

# Generated at 2022-06-24 09:26:10.148155
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict({"asd": "asd"})
    assert obj.asd == obj["asd"]



# Generated at 2022-06-24 09:26:15.327773
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None
    else:
        raise AssertionError("Failed to raise exception")

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"
    else:
        raise AssertionError("Failed to raise exception")

    try:
        raise Exception("error", 2)
    except Exception as e:
        assert errno_from_exception(e) == "error"
    else:
        raise AssertionError("Failed to raise exception")

    try:
        raise IOError
    except Exception as e:
        assert errno_from_exception(e) is None

# Generated at 2022-06-24 09:26:20.930766
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Dog(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class Cat(object):
        def __init__(self, c, d):
            self.c = c
            self.d = d

    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return Dog

    Base.configure(Cat, b=3)
    mypet = Base(a=1, d=4)
    assert mypet.a == 1
    assert mypet.b == 3
    assert mypet.c == 4
    assert mypet.d == 4

    Base.configure(Dog, b=5)

# Generated at 2022-06-24 09:26:30.122669
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class ConfigurableStr(Configurable):
        def configurable_base(self):
            return ConfigurableStr

    ConfigurableStr.configure(str)
    assert isinstance('1', ConfigurableStr)
    assert '1'.initialize == str.__init__
    assert '1'.__init__ == str.__init__

    saved_config = ConfigurableStr._save_configuration()
    ConfigurableStr.configure(bytes)
    assert isinstance(b'1', ConfigurableStr)
    assert b'1'.initialize == bytes.__init__
    ConfigurableStr._restore_configuration(saved_config)


# Generated at 2022-06-24 09:26:35.046594
# Unit test for function import_object
def test_import_object():
    import tornado
    assert import_object("tornado") is tornado
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8

    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "import_object did not raise ImportError"



# Generated at 2022-06-24 09:26:42.556187
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # import cStringIO
    from io import BytesIO
    gzip_compressor = zlib.compressobj(9, zlib.DEFLATED, 8,
                                       zlib.Z_DEFAULT_STRATEGY)
    header = gzip_compressor.compress(b"") + gzip_compressor.flush(zlib.Z_SYNC_FLUSH)
    trailer = gzip_compressor.compress(b"") + gzip_compressor.flush()
    compressed_data = header + b"hello world" + trailer

    uncompressed_data = GzipDecompressor().decompress(compressed_data)
    assert uncompressed_data == b"hello world"

    io = BytesIO(compressed_data)
    gz_file = GzipFile(fileobj=io)
    assert g

# Generated at 2022-06-24 09:26:52.121020
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func_a(a, b=2, c=3):
        pass
    def func_b(a, b, c=3):
        pass
    def func_c(a, b, c, d=4):
        pass

# Generated at 2022-06-24 09:26:53.836778
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    try:
        raise TimeoutError()
    except TimeoutError:
        pass



# Generated at 2022-06-24 09:26:59.972289
# Unit test for function exec_in
def test_exec_in():
    exec_in("a = 1", globals())
    exec_in("b = 1", globals())
    exec_in("a + b", globals())
    exec_in("c = 1", globals(), locals())
    exec_in("d = 1", globals(), locals())
    exec_in("c + d", globals(), locals())
    exec_in("e = 1", locals())
    exec_in("f = 1", locals())
    exec_in("e + f", locals())



# Generated at 2022-06-24 09:27:01.895176
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(123, "123")
    except Exception as e:
        assert errno_from_exception(e) == 123



# Generated at 2022-06-24 09:27:10.916593
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class A(Configurable):
        def configurable_base(this):
            # type: () -> Type[Configurable]
            return this
        def configurable_default(this):
            # type: () -> Type[Configurable]
            return this
        def initialize(self):
            # type: () -> None
            pass

    a = A()
    assert isinstance(a, A), "The instance of a has no class A"
    assert not hasattr(a, 'test'), "The instance of a has attribute test"
    assert not hasattr(a, 'test2'), "The instance of a has attribute test2"

    class B(A):
        def initialize(self, test):
            # type: (str) -> None
            self.test = test

    b = B("hello")

# Generated at 2022-06-24 09:27:23.087799
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func(*args): 
        return args
    replacer = ArgReplacer(func, "arg_name")
    r1 = replacer.replace("new_value", ("v11", "v12", "v13"), {'kw1':'v21','kw2':'v22'})
    assert r1 == (None, ("v11", "new_value", "v13"), {'kw1':'v21','kw2':'v22'})
    r2 = replacer.replace("new_value", ("v11", "v12", "v13"), {'kw1':'v21','kw2':'v22', 'arg_name':'v23'})

# Generated at 2022-06-24 09:27:31.755995
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def fun_0(a):
        pass
    def fun_1(b):
        pass
    def fun_2(c):
        pass

    ar_0 = ArgReplacer(fun_0, 'a')
    ar_1 = ArgReplacer(fun_1, 'b')
    ar_2 = ArgReplacer(fun_2, 'c')


# Generated at 2022-06-24 09:27:33.243437
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    # type: () -> None
    assert timedelta_to_seconds(datetime.timedelta(seconds=2, minutes=1, hours=1)) == 3661



# Generated at 2022-06-24 09:27:40.213447
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(0)
    except Exception as e:
        assert errno_from_exception(e) == 0

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"

    try:
        raise Exception()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:27:47.557367
# Unit test for function exec_in
def test_exec_in():
    def check_exec_in(exec_in):
        exec_in('d = {"a": 1, "b": 2}', globals())
        assert "a" in globals()
        assert "d" not in globals()
        d = exec_in('a = 1\nb = 2', {})
        assert d['a'] == 1
        assert d['b'] == 2
        assert "a" not in globals()
        assert "b" not in globals()
        exec_in("c = a + b", loc=locals())
        assert c == 3
        assert "c" in locals()
        assert "a" not in locals()
        assert "b" not in locals()
    check_exec_in(exec_in)


# Fake byte literal support:  In python 2, we can't help but
# use real

# Generated at 2022-06-24 09:27:50.981214
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    import doctests
    failures, _ = doctest.testmod(doctests)
    if failures:
        raise Exception("Failed")



# Generated at 2022-06-24 09:27:51.730425
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    pass



# Generated at 2022-06-24 09:28:02.036913
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    class Foo(Configurable):
        def __init__(self):
            raise TypeError("can't instantiate directly")
        def initialize(self):
            pass
        @classmethod
        def configurable_base(cls):
            return Foo
        @classmethod
        def configurable_default(cls):
            return FooImpl
    class FooImpl(Foo):
        pass
    assert Foo.configured_class() is FooImpl

    Foo.configure('tests.util.FooImpl2')
    class FooImpl2(Foo):
        pass
    assert Foo.configured_class() is FooImpl2



# Generated at 2022-06-24 09:28:08.422146
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    gz = GzipDecompressor()
    assert gz.decompressobj.unused_data == b""
    gz.decompressobj.decompress(b"\x1f\x8bgarbage")
    assert gz.decompressobj.unused_data == b"garbage"
    assert gz.decompressobj.unconsumed_tail == b""



# Generated at 2022-06-24 09:28:16.221883
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func1(x, y, z):
        pass
    a = ArgReplacer(func1, "y")
    assert a.get_old_value((1, 2, 3), {}) == 2
    assert a.get_old_value((1, 2, 3), {'y': 4}) == 2
    assert a.get_old_value((1, 2, 3), {'y': 4}, default='a') == 2
    assert a.get_old_value((1, 2, 3), {'y': 4, 'z': 7}, default='a') == 2
    assert a.get_old_value((1, 2), {}) == None
    assert a.get_old_value((1, 2), {}, default='a') == 'a'

# Generated at 2022-06-24 09:28:21.183734
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise IndexError()
    except:
        exc_info = sys.exc_info()
        raise_exc_info(exc_info)

_ARO_RE = re.compile(r"^<(.*).*\..* object at 0x.*>$")



# Generated at 2022-06-24 09:28:31.520248
# Unit test for function re_unescape
def test_re_unescape():
    # No test for invalid regexes, because re_unescape is only meant to
    # work on regexes created with re.escape.

    # Check that re_unescape can reverse re.escape on ascii strings
    print(re_unescape(r"\^$.|?*+()[]{}\\"))

    # Check that Unicode characters are unescaped properly
    print(re_unescape(r"\u00f6") == "ö")


# These constants are only used within the _websocket module.  The
# various bit layouts and magic numbers are specified in section 5 of
# RFC6455.  However, some constants have been moved to the _websocket
# module because they are not needed by the general public.
_WEBSOCKET_KEY_LENGTH = 32

# Generated at 2022-06-24 09:28:40.188714
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=True, d=True):
        pass
    arg = ArgReplacer(func, "a")
    args = (1, 2)
    kwargs = {}
    assert arg.get_old_value(args, kwargs) == 1
    assert arg.get_old_value(args, kwargs, default=3) == 1
    assert arg.get_old_value((), {}, default=3) == 3
    assert arg.get_old_value((), {"a": 4}, default=3) == 4
    arg = ArgReplacer(func, "d")
    assert arg.get_old_value(args, kwargs) == True
    assert arg.get_old_value(args, kwargs, default=3) == True

# Generated at 2022-06-24 09:28:45.685232
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Some_Configurable_Class(Configurable):
        def __init__(self,*args,**kwargs):
            self.initialize(*args,**kwargs)
    c = Some_Configurable_Class('a','b','c','d')
    assert c.__dict__ == {'args': ('a','b','c','d')}

# Instance method of class Configurable

# Generated at 2022-06-24 09:28:48.064445
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-24 09:28:48.868205
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    obj = ObjectDict()
    obj.a = 'b'
    assert obj.a == 'b'



# Generated at 2022-06-24 09:28:51.697060
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(
        datetime.timedelta(days=9, seconds=1, microseconds=2)
    ) == 777561.000002



# Generated at 2022-06-24 09:28:54.405795
# Unit test for constructor of class Configurable
def test_Configurable():
    with pytest.raises(NotImplementedError):
        Configurable.configurable_base()
    with pytest.raises(NotImplementedError):
        Configurable.configurable_default()
    with pytest.raises(ValueError):
        Configurable.configure(None)
    with pytest.raises(ValueError):
        Configurable.configure(Configurable)
    with pytest.raises(ValueError):
        Configurable.configure(str)



# Generated at 2022-06-24 09:29:00.878006
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Foo(Configurable):
        def configurable_base(self):
            return Foo
        def configurable_default(self):
            return Foo
    class Bar(Foo):
        def initialize(self):
            pass
    instance = Foo()
    Foo.configure(Bar)
    assert isinstance(instance, Bar)

# Generated at 2022-06-24 09:29:06.039440
# Unit test for function import_object
def test_import_object():
    try:
        import_object("tornado.test.test_util.test_import_object")
    except ImportError:
        pass
    import tornado.test.test_util
    assert import_object("tornado.test.test_util") is tornado.test.test_util
    assert import_object("tornado.test.test_util.TestImportObject") is tornado.test.test_util.TestImportObject



# Generated at 2022-06-24 09:29:11.314351
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception(7, "message")
    except Exception as exc:
        errno = errno_from_exception(exc)
        assert errno == 7
    try:
        raise Exception((7, "message"))
    except Exception as exc:
        errno = errno_from_exception(exc)
        assert errno == 7
    try:
        raise IOError(7, "message")
    except Exception as exc:
        errno = errno_from_exception(exc)
        assert errno == 7



# Generated at 2022-06-24 09:29:21.891219
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    def assert_seconds(td, seconds):
        assert timedelta_to_seconds(td) == seconds
    # There are 10**6 microseconds in one second
    assert_seconds(datetime.timedelta(seconds=1), 1)
    assert_seconds(datetime.timedelta(microseconds=10**6), 1)
    # There are 10**3 milliseconds in one second
    assert_seconds(datetime.timedelta(milliseconds=10**3), 1)
    # There are 60 seconds in one minute
    assert_seconds(datetime.timedelta(minutes=1), 60)
    # There are 60 minutes in one hour
    assert_seconds(datetime.timedelta(hours=1), 3600)
    # There are 24 hours in one day

# Generated at 2022-06-24 09:29:25.632792
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def myfunc(a, b, c):
        return a + b + c

    myfunc_arg0 = ArgReplacer(myfunc, "a")
    assert myfunc_arg0.get_old_value((1, 2, 3), {}) == 1
    myfunc_arg1 = ArgReplacer(myfunc, "b")
    assert myfunc_arg1.get_old_value((1, 2, 3), {}) == 2



# Generated at 2022-06-24 09:29:29.423417
# Unit test for function raise_exc_info
def test_raise_exc_info():
    def f():
        try:
            raise ValueError("foo")
        except:
            raise_exc_info(sys.exc_info())

    assertRaisesRegex(ValueError, "foo", f)
# end unit test



# Generated at 2022-06-24 09:29:38.970144
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            arg = ArgReplacer(func, "arg_name")
            new_value = object()
            old_value = arg.get_old_value(args, kwargs, None)
            result = func(*arg.replace(new_value, args, kwargs))
            assert old_value is not new_value
            assert arg.get_old_value(args, kwargs, None) is new_value
            return result

        return wrapper

    def test(arg_name):
        assert arg_name != object()
        return arg_name

    assert test(object()) is object()



# Generated at 2022-06-24 09:29:42.043525
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    # type: () -> None
    o = ObjectDict()
    o.name = 'test'
    assert o['name'] == 'test'



# Generated at 2022-06-24 09:29:51.373382
# Unit test for function re_unescape
def test_re_unescape():
    # re_unescape() should be able to convert strings produced by re.escape(),
    # but not necessarily vice versa because re_unescape() unescapes non-\w
    # characters such as \s.
    assert re_unescape('abc') == 'abc'         # ok
    assert re_unescape('abc123') == 'abc123'   # ok
    assert re_unescape('abc.') == 'abc.'       # ok
    with pytest.raises(ValueError):
        re_unescape('abc\\s')                  # '\s' is not in \w
    with pytest.raises(ValueError):
        re_unescape('abc\\d')                  # '\d' is not in \w



# Generated at 2022-06-24 09:29:57.465247
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(22, "error")
    except Exception as e:
        assert errno_from_exception(e) == 22

    try:
        raise Exception("error")
    except Exception as e:
        assert errno_from_exception(e) == "error"



# Generated at 2022-06-24 09:29:59.292235
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest
    doctest.testmod()


# For use in double-checked locking
_create_identifier = object()



# Generated at 2022-06-24 09:30:01.214585
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        # noinspection PyTypeChecker
        raise Exception("asdf")
    except:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-24 09:30:08.974978
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    base = Configurable()
    base.configure(Configurable)
    assert base.configured_class() == base
    class Impl(Configurable):
        @classmethod
        def configurable_base(cls):
            return base
        @classmethod
        def configurable_default(cls):
            return base
        def initialize(self):
            pass
    Impl()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:30:17.359441
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    decompressor = GzipDecompressor()
    decompressed = decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\x03a\xccHi\xcd\xc9\xc9W(\xcf/\xcaIQ\x04\x00\x1f\x0b\xa8\x95\x81\x17\x00\x00\x00')
    assert decompressed == b"a"

# Generated at 2022-06-24 09:30:24.594209
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    gz_decompressor_obj=GzipDecompressor()
    result=gz_decompressor_obj.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xffM\x93MYH\x04\x00\x9a\xff\xf9\x16\xc0\x88\x00\x00\x00')
    assert result == b"Hell0 world!"

# Generated at 2022-06-24 09:30:34.404323
# Unit test for function import_object
def test_import_object():
    try:
        import_object('tornado.escape.utf8')
        import_object('tornado.escape')
        import_object('tornado')
    except ImportError as e:
        print(e)


# Fake byte literal support:  In python 3 we can just use b"foo" to
# get a byte literal (str in 2.x, bytes in 3.x).  In python 2 we can
# use "foo".encode("latin1").  tornado.util.utf8 is a function that
# decodes byte strings to unicode in both versions, using the correct
# encoding (latin1 in 2.x, utf8 in 3.x).  To write portable code without
# repeating a bunch of .encode("latin1") we define fake_bytes as a
# function that takes arbitrary string literals and returns a bytes
#

# Generated at 2022-06-24 09:30:37.152147
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    obj = ObjectDict()
    obj['test'] = 'test'
    assert obj.test == 'test'
    assert obj['test'] == 'test'



# Generated at 2022-06-24 09:30:46.406541
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # The only test is unit test for method replace
    # of class ArgReplacer.
    result = ArgReplacer.replace(
        1,
        (1, 2, 3, 4),
        {'a': 1, 'b': 2, 'c': 3, 'd': 4},
    )
    assert result == (1, (1, 2, 3, 4), {'a': 1, 'b': 2, 'c': 3, 'd': 4})

    result = ArgReplacer.replace(
        1,
        (1, 2, 3, 4),
        {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5},
    )

# Generated at 2022-06-24 09:30:58.662572
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    from unittest import TestCase
    from typing import Any, Dict, Optional
    from unittest.mock import Mock
    from . import Configurable
    class Test(Configurable):
        @classmethod
        def configurable_base(cls):
            return Test
    class TestImpl(Test):
        pass
    Test.configure(TestImpl)
    Test.configure(TestImpl, kwarg=2)
    Test.configure(TestImpl, other_kwarg=3)
    Test._restore_configuration((TestImpl, {'kwarg': 2}))
    mocked_initialize = Mock(return_value=None)
    Test.initialize = mocked_initialize
    instance = Test(arg=1)
    assert isinstance(instance, TestImpl)
    mocked_initialize.assert_called_once

# Generated at 2022-06-24 09:31:04.068003
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # Verify that the decompressor can handle non-zero starting values
    # of its unconsumed_tail attribute.
    decompressor = GzipDecompressor()
    try:
        decompressor.unconsumed_tail = b"foo"
    except:
        raise unittest.SkipTest("unsupported GzipDecompressor platform")



# Generated at 2022-06-24 09:31:05.783157
# Unit test for function exec_in
def test_exec_in():
    d = {}
    exec_in('x = 1', d)
    assert d['x'] == 1



# Generated at 2022-06-24 09:31:14.103069
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    x = ObjectDict(a=1, b=2)

    assert hasattr(x, 'a')
    assert hasattr(x, 'b')
    assert not hasattr(x, 'c')

    x.c = 3
    assert hasattr(x, 'c')

# Dict-like objects that support attribute-style lookups for keys
# not contained in the dictionary (but are still stored as
# ordinary entries if written to).  The default value is
# ``None``.
#
# In Python 3, we could use ``types.MappingProxyType`` instead.

# Generated at 2022-06-24 09:31:20.258205
# Unit test for function exec_in
def test_exec_in():
    exec_in("x=5", {})
    assert exec_in("y=6", {"x": 1}) == None
    assert exec_in("z=7", {"x": 1, "y": 2}) == None
    exec_in("x=6", {"x": 1})
    exec_in("y=7", {"x": 1, "y": 2})
    exec_in("z=8", {"x": 1, "y": 2, "z": 3})

_BYTES_ARRAY_TYPE = type(array.array("B", b""))



# Generated at 2022-06-24 09:31:25.771187
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class Foo:
        def run(self, one, two, three=None, four=None):
            pass

    foo = Foo()
    arg_one = ArgReplacer(foo.run, "one")
    arg_two = ArgReplacer(foo.run, "two")
    arg_three = ArgReplacer(foo.run, "three")
    arg_four = ArgReplacer(foo.run, "four")
    # test positional arguments
    assert (None, (), {}) == arg_one.replace(1, (), {})
    assert (1, (1, ), {}) == arg_one.replace(2, (1, ), {})
    assert (1, (1, 2), {}) == arg_two.replace(2, (1, 2), {})
    assert (2, (1, 2), {}) == arg_

# Generated at 2022-06-24 09:31:30.332053
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    # set up
    class ConfigurableImpl(Configurable):
        @classmethod
        def configurable_base(cls):
            return ConfigurableImpl
        @classmethod
        def configurable_default(cls):
            return ConfigurableImpl
    # test
    obj = ConfigurableImpl()
    assert obj is not None

# Generated at 2022-06-24 09:31:32.218920
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    GzipDecompressor()

_UTF8_TYPES = (bytes, type(None))


# Generated at 2022-06-24 09:31:36.942086
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise Exception
    except Exception as e:
        assert errno_from_exception(e) is None

    try:
        raise Exception(42, "foo")
    except Exception as e:
        assert errno_from_exception(e) == 42

    try:
        raise Exception("foo")
    except Exception as e:
        assert errno_from_exception(e) == "foo"



# Generated at 2022-06-24 09:31:40.764198
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    def f(self, name: str, value: Any) -> None:
        pass
    try:
        ObjectDict.__setattr__(None, "name", "value")
        ObjectDict.__setattr__ = f
    except:
        assert False



# Generated at 2022-06-24 09:31:47.015799
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    '''
    Unit test for method __setattr__ of class ObjectDict
    '''
    obj = ObjectDict()
    obj.abc_d = 1
    assert obj['abc_d'] == 1
    # NameError
    try:
        obj.abc_d = 2
    except NameError:
        assert obj['abc_d'] == 1

# Generated at 2022-06-24 09:31:49.471577
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    try:
        raise Exception()
    except Exception:
        raise_exc_info(sys.exc_info())



# Generated at 2022-06-24 09:31:57.784701
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    codec1 = zlib.compressobj(level=6, method=8, wbits=15)
    codec2 = zlib.decompressobj()
    input_str = '1111111111111111'
    output_str = codec1.compress(input_str.encode('ascii')) + codec1.flush()
    assert codec2.decompress(output_str) == input_str.encode('ascii')
    # truncated input
    codec2 = zlib.decompressobj()
    output_str = codec1.compress(input_str.encode('ascii'))

# Generated at 2022-06-24 09:32:01.140879
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    import doctest

    # Ignore deprecation warnings in tests that test deprecations
    # (otherwise they would show up twice).
    with ExpectLog(gen_log, ".*", required=False):
        doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)

# Generated at 2022-06-24 09:32:02.301135
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    assert "my_arg" == ArgReplacer(lambda my_arg: None, "my_arg").name


# Generated at 2022-06-24 09:32:10.105678
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    arg_replacer = ArgReplacer(functools.partial(divmod, 10), "y")
    assert arg_replacer.arg_pos == 0
    assert arg_replacer.get_old_value((1,), {}) == 1
    assert arg_replacer.get_old_value((), {"y": 5}) == 5
    assert arg_replacer.get_old_value((), {}, default="default") == "default"

    arg_replacer = ArgReplacer(functools.partial(divmod, 10), "x")
    assert arg_replacer.arg_pos is None
    assert arg_replacer.get_old_value((), {"x": "old"}) == "old"
    assert arg_replacer.get_old_value((), {}, default="default") == "default"

    arg_repl

# Generated at 2022-06-24 09:32:17.009989
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, "Input/output error")
    except Exception as e:
        assert errno_from_exception(e) == 5
    try:
        raise OSError("Input/output error")
    except Exception as e:
        assert errno_from_exception(e) == "Input/output error"
    try:
        raise OSError()
    except Exception as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:32:28.583001
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    import time

    class A(Configurable):
        def initialize(self, *args, **kwargs):
            pass

    class B(A):
        def initialize(self, *args, **kwargs):
            pass

    class C(B):
        def initialize(self, *args, **kwargs):
            pass

    assert A.configurable_default() == A
    assert B.configurable_default() == B
    assert C.configurable_default() == C
    assert A.configurable_base() == A
    assert B.configurable_base() == A
    assert C.configurable_base() == A

    # Default does not change before configure.
    a, b, c = A(), B(), C()
    assert a.__class__ == A
    assert b.__class__ == B
    assert c.__class

# Generated at 2022-06-24 09:32:37.541040
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Impl(Configurable):
        @classmethod
        def configurable_base(cls):
            return Impl
        @classmethod
        def configurable_default(cls):
            return Impl
        def initialize(self, foo, bar=None):
            self.foo = foo
            self.bar = bar
    Impl.configure(None)
    impl = Impl(1)
    assert impl.foo == 1
    assert impl.bar is None
    impl = Impl(foo=1)
    assert impl.foo == 1
    assert impl.bar is None
    impl = Impl(1, bar=2)
    assert impl.foo == 1
    assert impl.bar == 2
    impl = Impl(foo=1, bar=2)
    assert impl.foo == 1
    assert impl.bar == 2