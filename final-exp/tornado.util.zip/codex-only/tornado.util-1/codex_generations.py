

# Generated at 2022-06-24 09:22:38.419189
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    z = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16,
                         zlib.DEF_MEM_LEVEL, 0)
    gz = z.compress(b"hello") + z.flush()
    d = GzipDecompressor()
    assert d.decompress(gz) == b"hello"
    assert d.unconsumed_tail == b""
    assert d.flush() == b""



# Generated at 2022-06-24 09:22:46.326212
# Unit test for function exec_in
def test_exec_in():

    def execute_code(code: str) -> int:
        globs = {}
        exec_in(code, globs)
        return globs["x"]

    assert execute_code("x = 1") == 1
    assert execute_code("x = 2") == 2
    assert execute_code("x = 3; y = 4") == 3
    assert execute_code("x = 5; y = 6") == 5
    assert execute_code("x = 7") == 7

    # tests for varargs
    def execute_varargs_code(code: str, *args: int) -> Tuple[int, ...]:
        globs: Dict[str, Any] = {}
        exec_in(code, globs, {"args": args})
        return globs["result"]


# Generated at 2022-06-24 09:22:55.160790
# Unit test for constructor of class Configurable
def test_Configurable():  # pragma: no cover
    # type: () -> None
    class MyConfigurable(Configurable):
        def configurable_base(cls):
            # type: () -> Type[Configurable]
            return MyConfigurable

        def configurable_default(cls):
            # type: () -> Type[Configurable]
            return MyDefaultImpl

        def initialize(self, value):
            # type: (int) -> None
            self.value = value

    class MyDefaultImpl(MyConfigurable):
        def initialize(self, value):
            # type: (int) -> None
            self.value = value + 1

    class MyAlternateImpl(MyConfigurable):
        def initialize(self, value):
            # type: (int) -> None
            self.value = value + 2


# Generated at 2022-06-24 09:22:59.890199
# Unit test for function import_object
def test_import_object():
    def test(name, expected):
        module = import_object(name)
        assert module is expected, "%s is expected to be %s" % (module, expected)
    test("sys", sys)
    test("sys.version", sys.version)
    test("tornado.escape", tornado.escape)
    test("tornado.escape.utf8", tornado.escape.utf8)
    test("tornado.util", tornado.util)
    test("tornado.util.import_object", tornado.util.import_object)
    tornado.util.import_object.__module__ == "tornado.util"



# Generated at 2022-06-24 09:23:11.180469
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(x: int, y: int, z: int = 3) -> None:
        pass

    replacer = ArgReplacer(f, "y")

    def test(expected: Tuple[Optional[int], Sequence[Any], Dict[str, Any]], *args: Any, **kwargs: Any) -> None:
        old, new_args, new_kwargs = replacer.replace(5, args, kwargs)
        assert (old, list(new_args), new_kwargs) == expected

    test((3, [1, 5, 4], {}), 1, y=3, z=4)
    test((None, [1, 5], {"z": 4}), 1, z=4)
    test((3, [1, 5, 4], {}), 1, 3, 4)

# Generated at 2022-06-24 09:23:15.952207
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    d = ObjectDict()  # type: Dict[str, Any]
    d['foo'] = 'bar'
    assert d.foo == 'bar'

# Alias for ObjectDict for compatibility with Tornado 4.0

# Generated at 2022-06-24 09:23:16.898510
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    TimeoutError()  # type: ignore



# Generated at 2022-06-24 09:23:24.609611
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    import unittest
    class A(Configurable):
        def __init__(self, x, y=None):
            self.x = x
            self.y = y
    class B(A):
        pass
    class C(A):
        pass
    A.configure(C)

    class ConfigurableTest(unittest.TestCase):
        def test_configurable(self):
            a = A(1)
            self.assertIsInstance(a, C)
            self.assertEqual(a.x, 1)
            self.assertEqual(a.y, None)
            a = A(1, 2)
            self.assertIsInstance(a, C)
            self.assertEqual(a.x, 1)
            self.assertEqual(a.y, 2)

# Generated at 2022-06-24 09:23:32.162896
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # type: () -> None
    import io
    import gzip
    d = GzipDecompressor()
    input = io.BytesIO()
    gz = gzip.GzipFile(mode="wb", fileobj=input)
    gz.write(b"asdf")
    gz.close()
    compressed = input.getvalue()
    assert d.decompress(compressed) == b"asdf"
    assert d.flush() == b""
    assert d.unconsumed_tail == b""



# Generated at 2022-06-24 09:23:39.729525
# Unit test for function import_object
def test_import_object():
    import doctest
    import tornado.escape
    doctest.run_docstring_examples(import_object, globals(), verbose=True)
    assert import_object("tornado.escape") is tornado.escape
    assert import_object("tornado.escape.utf8") is tornado.escape.utf8
    assert import_object("tornado") is tornado
    try:
        import_object("tornado.missing_module")
    except ImportError:
        pass
    else:
        assert False, "did not get expected ImportError"



# Generated at 2022-06-24 09:23:50.142966
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    val = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff\x06\x00BC\x02\xff'
    decompressor = GzipDecompressor()
    assert decompressor.decompress(val) == b''
    # When max_length gets to 0, it will return b'' and
    # unconsumed_tail will not get cleared.
    assert decompressor.unconsumed_tail == val
    assert decompressor.decompress(val, 0) == b''
    assert decompressor.unconsumed_tail == val
    assert decompressor.decompress(val, len(val)) == b''
    assert decompressor.unconsumed_tail == b''
    assert decompressor.decompress(val, len(val) + 1)

# Generated at 2022-06-24 09:23:57.654107
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor(): # pragma: nocover
    gzip_decompressor = GzipDecompressor()
    gzip_value = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x03\xcdMJ\xc8\xcfN\xca\xccKTI\x04\x00' \
     + b'\x1a\xda\xc7\x05\x00\x00\x00'

    gzip_data = gzip_decompressor.decompress(gzip_value)
    gzip_data += gzip_decompressor.flush()
    assert gzip_data == b'hello, world!'


GzipDecompressor.__test__ = False  # type: ignore


# Adopted from Python cookbook

# Generated at 2022-06-24 09:24:06.236271
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    d = GzipDecompressor()
    # assert raises with proper type error on incorrect type for input value,
    # and with proper message
    try:
        assert d.decompress("value")
    except AssertionError as e:
        print(e)
        #assert type(e) == AssertionError
        #assert str(e) == "attribute-style access not possible"
    # assert raises with proper type error on incorrect type for input
    # max_length, and with proper message
    try:
        assert d.decompress(b"value", 1, 2)
    except AssertionError as e:
        print(e)
        #assert type(e) == AssertionError
        #assert str(e) == "attribute-style access not possible"
    # assert raises with proper type error on incorrect type for input

# Generated at 2022-06-24 09:24:09.691656
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise IOError(5, 'some message')
    except IOError as e:
        assert errno_from_exception(e) == 5
    try:
        raise IOError('some message')
    except IOError as e:
        assert errno_from_exception(e) == 0
    try:
        raise TypeError
    except TypeError as e:
        assert errno_from_exception(e) is None



# Generated at 2022-06-24 09:24:14.609893
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    data = b"\x1f\x8b\x08\x08\x1d\x9a\x4a\x50\x00\x03\x68\x65\x6c\x6c\x6f\x00\x03\x2b\x0b\xcb\x48\xcd\xc9\xc9\x57\x08\xcf\x2f\xa8\xca\x49\x01\x00\x3d\x2f\x5e\x5c\x00\x00\x00"
    gzip_decompressor = GzipDecompressor()
    result = gzip_decompressor.decompress(data, 17)
    assert result == b"hello"



# Generated at 2022-06-24 09:24:24.549882
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    def test_function(return_arg):
        # type: (Any) -> typing.NoReturn
        raise_exc_info(return_arg)
    try:
        test_function(None)
    except TypeError:
        pass
    else:
        assert False, "did not raise an error"
    try:
        test_function((None, None, None))
    except TypeError:
        pass
    else:
        assert False, "did not raise an error"
    try:
        test_function((None, TypeError(), None))
    except TypeError:
        pass
    else:
        assert False, "did not raise an error"
    try:
        test_function((None, ValueError("foo"), None))
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 09:24:30.700231
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    def func1(one, two, three=None, four=None):  # pragma: no cover
        return one, two, three, four

    def func2(one, *args):  # pragma: no cover
        return one, args

    replacer = ArgReplacer(func1, "three")
    assert replacer.name == "three"
    assert replacer.replace(3, (1, 2, 4, 5), {}) == (
        4,
        (1, 2, 3, 5),
        {},
    )
    assert replacer.replace(3, (1, 2, 4, 5), {'four': 6}) == (
        4,
        (1, 2, 3, 5),
        {'four': 6},
    )

# Generated at 2022-06-24 09:24:34.566152
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def f(a, b, c, d=0, *, e):
        assert a == 4
        assert b == 1
        assert c == 2
        assert d == 0
        assert e == 3
        
    ArgReplacer.replace(f, 3, ([1, 2],{'a':4,'e':3}))


# Generated at 2022-06-24 09:24:37.541190
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    f = lambda *args, **kwargs: None

    arg_replacer = ArgReplacer(f, "a")
    arg_replacer.replace(1, (2,), {})



# Generated at 2022-06-24 09:24:49.246171
# Unit test for constructor of class Configurable
def test_Configurable():
    class Base(Configurable):
        @classmethod
        def configurable_base(cls):
            return Base

        @classmethod
        def configurable_default(cls):
            return DefaultImpl

    class DefaultImpl(Base):
        pass

    class AlternateImpl(Base):
        pass

    class SubImpl(AlternateImpl):
        @classmethod
        def configurable_default(cls):
            return SubImpl

    def make_subimpl(*, new_config=True):

        class SubImpl(AlternateImpl):
            @classmethod
            def configurable_default(cls):
                if new_config:
                    return SubImpl
                else:
                    return super().configurable_default()

        return SubImpl

    # Configuring the class should have no effect if the class is
    # not the configurable base class, even

# Generated at 2022-06-24 09:24:58.582501
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # Test for method flush(self)
    decompressor = GzipDecompressor()
    chunk = b"ffffffffff"
    assert decompressor.decompress(chunk) == b""
    assert decompressor.unconsumed_tail == b""
    chunk = b'"\x9c\xcbH\xcd\xc9\xc9W\x08\xcf/\xcaIQ\xcc \x82\x02\x04\x00\xc7'
    assert decompressor.decompress(chunk)
    assert len(decompressor.unconsumed_tail) > 0
    assert decompressor.flush()



# Generated at 2022-06-24 09:25:09.434510
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # mock object
    mock_self = Mock()
    mock_args = Mock()
    mock_kwargs = Mock()

    # mock Configurable class
    mock_configurable_class = Mock()
    mock_configurable_class.configure.return_value = None
    mock_configurable_class.configured_class.return_value = mock_configurable_class
    mock_configurable_class.configurable_base.return_value = mock_configurable_class
    mock_configurable_class.configurable_default.return_value = mock_configurable_class

    # call method
    configurable = Configurable()
    configurable.initialize(mock_self, mock_args, mock_kwargs)

    # assert
    assert mock_configurable_class.initialize.call_count == 1
    mock_configurable

# Generated at 2022-06-24 09:25:17.332639
# Unit test for constructor of class Configurable
def test_Configurable():
    # type: () -> None
    global IOLoop, DummyConnection

    class IOLoop(object):
        class DummyConnection(object):
            pass

    class _EPoll(IOLoop):
        __impl_class = None
        __impl_kwargs = {}

        @classmethod
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return IOLoop

        @classmethod
        def configurable_default(self):
            # type: () -> Type[Configurable]
            return self

    class _KQueue(IOLoop):
        __impl_class = None
        __impl_kwargs = {}

        @classmethod
        def configurable_base(self):
            # type: () -> Type[Configurable]
            return IOLoop


# Generated at 2022-06-24 09:25:25.418246
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # type: () -> None
    '''Test case for method flush of class GzipDecompressor'''
    # Initialization
    result = \
        b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff\x06\x00BC\x02\xff\x1b\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00'  # noqa: E501
    gz = GzipDecompressor()
    assert gz.unconsumed_tail is None
    # Testing function
    result = gz.decompress(result)
    result = gz.flush()
    assert result == b'Hello World!'



# Generated at 2022-06-24 09:25:36.031607
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test(a, b=None, c=None):
        return a, b

    def test2(a, b=None, c=None):
        return a, b, c

    func = ArgReplacer(test, 'b')
    func2 = ArgReplacer(test2, 'c')
    # Test argument was passed positionally
    assert func.get_old_value(('a',), {}) == 'a'
    # Test argument was passed by keyword
    assert func.get_old_value((), {'b': 'a'}) == 'a'
    # Test argument was passed by keyword but not given
    assert func.get_old_value((), {}) == None
    # Test the argument replacement when argument exists
    assert func.replace('b', ('a', ), {}) == ('a', ('b',), {})


# Generated at 2022-06-24 09:25:37.442675
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    setattr({}, "a", 1)  # type: ignore



# Generated at 2022-06-24 09:25:46.432025
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():
    class Foo(object):
        a = 1

        def __init__(self, a, b=2, *c):
            pass

    argument = ArgReplacer(Foo, "a")
    assert argument.name == "a"

    # The argument should be in arg_pos
    assert argument.get_old_value((1, 2, 3), {}) == 1

    # The argument should be in kwargs
    assert argument.get_old_value((), {"a": 1}) == 1

    # The argument should not be in *args
    assert argument.get_old_value((1,), {}) == 1

    # The argument should not be in *args
    assert argument.get_old_value((2,), {}) == 1

    # The argument should be current_value

# Generated at 2022-06-24 09:25:54.850824
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    global __impl_class
    global __impl_kwargs
    global initialize
    global configure
    global configured_class
    global _save_configuration
    global _restore_configuration

    global configurable_base
    global configurable_default

    # Test class Configurable
    # class Configurable(object):
    #     """Base class for configurable interfaces.
    #
    #     A configurable interface is an (abstract) class whose constructor
    #     acts as a factory function for one of its implementation subclasses.
    #     The implementation subclass as well as optional keyword arguments to
    #     its initializer can be set globally at runtime with `configure`.
    #
    #     By using the constructor as the factory method, the interface
    #     looks like a normal class, `isinstance` works as usual, etc.  This
    #

# Generated at 2022-06-24 09:25:57.139276
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # create an instance of class Configurable
    configurable_instance = Configurable()

    # create a new instance of class Configurable in function _initialize
    configurable_instance._initialize()

    # create a new instance of class Configurable in function initialize
    configurable_instance.initialize()


# Generated at 2022-06-24 09:26:08.291597
# Unit test for function re_unescape
def test_re_unescape():
    import re
    assert re.escape("- [ ]") == r"\- \[ \]"
    assert re_unescape(r"\- \[ \]") == "- [ ]"

# Generated at 2022-06-24 09:26:16.198192
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    import gzip
    import io
    import itertools

    # empty gzip file
    inbuffer = io.BytesIO(b"")
    gzin = gzip.GzipFile(fileobj=inbuffer, mode="rb")
    data = gzin.read()
    assert len(data) == 0

    # add some text
    text = b"The quick brown fox jumps over the lazy dog"
    inbuffer = io.BytesIO()
    gzout = gzip.GzipFile(fileobj=inbuffer, mode="wb", compresslevel=9)
    gzout.write(text)
    gzout.close()
    inbuffer.seek(0)
    gzin = gzip.GzipFile(fileobj=inbuffer, mode="rb")
    data = gzin.read()

    # test GzipDec

# Generated at 2022-06-24 09:26:27.066179
# Unit test for constructor of class GzipDecompressor

# Generated at 2022-06-24 09:26:36.739827
# Unit test for function raise_exc_info
def test_raise_exc_info():
    # type: () -> None
    #
    # This is a unit test since typing.NoReturn is not available in python 3.5.
    def _get_traceback() -> TracebackType:
        # type: (...) -> TracebackType
        #
        # This is a unit test since typing.NoReturn is not available in python 3.5.
        return cast(TracebackType, None)

    try:
        raise_exc_info((None, None, None))
        assert False, "Did not raise exception"
    except TypeError:
        pass

    try:
        try:
            raise_exc_info((None, ValueError(), None))
            assert False, "Did not raise exception"
        except ValueError:
            raise
    except ValueError:
        pass


# Generated at 2022-06-24 09:26:48.143325
# Unit test for constructor of class TimeoutError
def test_TimeoutError():
    # type: () -> None
    assert TimeoutError('hello').args == ('hello',)  # type: ignore

import warnings

warnings.simplefilter('default', DeprecationWarning)

if typing.TYPE_CHECKING:
    # "from some_module import (CONSTANT)"" will cause a type error
    # since the binding may or may not be defined at runtime.
    # In this case the type is already known and it's safe to ignore
    # the error.
    import types  # noqa: F401

# https://docs.python.org/3/whatsnew/3.6.html#deprecated-aliases
if typing.TYPE_CHECKING:
    import _thread as thread  # noqa: F401


if typing.TYPE_CHECKING:
    _Null = None  # noqa: F8

# Generated at 2022-06-24 09:26:58.866130
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(1)) == 86400
    assert timedelta_to_seconds(datetime.timedelta(microseconds=1)) == 1e-06
    assert timedelta_to_seconds(datetime.timedelta(seconds=1e-06)) == 1e-06


_DAYS_INTO_WEEK = [0] * 7
_DAYS_INTO_WEEK[0] = 0
_DAYS_INTO_WEEK[1] = 1
_DAYS_INTO_WEEK[2] = 2
_DAYS_INTO_WEEK[3] = 3
_DAYS_INTO_WEEK[4] = 4
_DAYS_INTO_WEEK[5] = 5

# Generated at 2022-06-24 09:27:07.778440
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class FakeTestConfigurable(Configurable):
        def __init__(self, *args, **kwargs):
            self.arguments = args
            self.keywords = kwargs
        def initialize(self, *args, **kwargs):
            self.arguments = args
            self.keywords = kwargs
    
    assert len(FakeTestConfigurable().arguments) == 0
    assert len(FakeTestConfigurable().keywords) == 0
    assert FakeTestConfigurable.initialize is not FakeTestConfigurable._initialize
    assert FakeTestConfigurable.initialize is Configurable.initialize
    assert FakeTestConfigurable._initialize is Configurable._initialize

    FakeTestConfigurable().initialize('a', 1, b=2)
    assert FakeTestConfigurable().arguments == ('a', 1)
    assert FakeTestConfig

# Generated at 2022-06-24 09:27:18.617912
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    # Some function definition to get a signature
    def fun(arg1, arg2=None, *args, **kwargs):
        pass

    # Instanciate a ArgReplacer Object with the previous function definition
    replacer = ArgReplacer(fun, 'arg1')

    # Test for when the first argument is not given a value
    assert replacer.get_old_value((), {}) == None

    # Test for when the first argument is passed a value
    assert replacer.get_old_value((1,), {}) == 1

    # Test for when the first argument is given a value and the second is not
    assert replacer.get_old_value((1,), {'arg2': 2}) == 1

    # Test for when the first argument is not given a value and the second is

# Generated at 2022-06-24 09:27:27.152605
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(a, b, c=None, d=None, e=None, f=None, g=None, h=None):
        pass
    r = functools.partial(ArgReplacer, func, "d")
    assert r.get_old_value((1, 2), {}) is None
    assert r.get_old_value((1, 2), {"d": 3}) == 3
    assert r.get_old_value((1, 2), {"d": 3}, default=4) == 3
    assert r.get_old_value((1, 2), {"e": 3}, default=4) == 4


# Generated at 2022-06-24 09:27:34.172617
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func1(arg1, arg2=None, arg3=None):
        pass
    arg2_replacer = ArgReplacer(func1, 'arg2')
    old_value, args, kwargs = arg2_replacer.replace(
        'new value 2',
        (1,),
        {'arg3': 3}
    )
    print(args[1])
    assert args[1] == 'new value 2'
    assert kwargs['arg2'] == 'new value 2'
    assert old_value is None
    def func2(arg1, arg2=None, arg3=None):
        pass
    arg3_replacer = ArgReplacer(func2, 'arg3')

# Generated at 2022-06-24 09:27:38.287846
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    time_delta_one_week = datetime.timedelta(weeks=1)
    assert time_delta_one_week.total_seconds() == timedelta_to_seconds(time_delta_one_week)



# Generated at 2022-06-24 09:27:49.592501
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def func(str1, str2 = "str2"):
        return (str1, str2)
    # Case 1: the arg is named by its position
    arg_replacer = ArgReplacer(func, "str2")
    assert arg_replacer.get_old_value(("str1", "str2", "str3"), {}) == "str2"
    assert arg_replacer.get_old_value(("str1", "str2", "str3"), {}, "default") == "str2"
    # Case 2: the arg is named by its key work
    arg_replacer = ArgReplacer(func, "str1")
    assert arg_replacer.get_old_value(("str1", "str2", "str3"), {}) == "str1"
    assert arg_replacer.get_old

# Generated at 2022-06-24 09:27:51.241208
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    obj['x'] = 'x'
    x = obj.x



# Generated at 2022-06-24 09:27:55.318886
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    """Test ArgReplacer.replace()
    """

    def test_f(arg1, arg2=1, arg3=2):
        pass

    # testing that the list is extended. Was a bug before
    def test_f_with_list(arg1, arg2=1, arg3=[2]):
        pass

    def test_f_with_tuple(arg1, arg2=1, arg3=(2,)):
        pass

    args = (1, 2, 3)
    kws = {'arg2': 2, 'arg3': 3}

    ar_orig = ArgReplacer(test_f, 'arg2')

    # Check that this does not change the args and kws
    ar = ArgReplacer(test_f, 'arg2')


# Generated at 2022-06-24 09:28:04.656741
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\a\b\c\d\e\f") == r"abcdef"
    assert re_unescape(r"\6\7\10\11") == r"67\8\t"
    assert re_unescape(r"\\") == r"\\"
    assert re_unescape(r"\a\b\c\d\e\f") == r"abcdef"
    assert re_unescape(r"\6\7\10\11") == r"67\8\t"
    assert re_unescape(r"\\") == r"\\"

    assert re_unescape(r"\!") == r"!"
    assert re_unescape(r"\()") == r"()"
    assert re_unescape(r"a\(b") == r

# Generated at 2022-06-24 09:28:06.716639
# Unit test for method __setattr__ of class ObjectDict
def test_ObjectDict___setattr__():
    d = ObjectDict()
    d.a = 1
    assert d == {'a': 1}



# Generated at 2022-06-24 09:28:15.499906
# Unit test for function import_object
def test_import_object():
    import unittest
    import sys

    @unittest.skipUnless(sys.version_info < (3, 5), "requires Python < 3.5")
    def test_import_object_2(self):
        # In Python 2, specifying a package module name (e.g., os.path)
        # to __import__ and import_object is an error, but specifying
        # a module name in a package (e.g., os.path.abspath) is not an
        # error.
        with self.assertRaises(ImportError):
            import_object("os.path")
        with self.assertRaises(ImportError):
            __import__("os.path")


# Generated at 2022-06-24 09:28:16.713604
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=365)) == 31536000



# Generated at 2022-06-24 09:28:20.987873
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        def test_decompress(self):
            gzip_decompressor = GzipDecompressor()
            self.assertEqual(b'', gzip_decompressor.decompress(b''))

    try:
        import zlib
    except ImportError:
        # The zlib module isn't available on AppEngine, so the
        # GzipDecompressor class is just an empty shell in this case
        pass
    else:
        test_case = TestCase()
        test_case.test_decompress()



# Generated at 2022-06-24 09:28:22.959437
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    # setup
    gzip_decompressor = GzipDecompressor()
    # test
    value = gzip_decompressor.flush()
    # verify
    assert value == b''


# Generated at 2022-06-24 09:28:27.993104
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    """Run doctests in module"""
    import tornado.util

    # Some doctests rely on being able to import modules that might not
    # be present (e.g. sqlite3 in the iostream test), so we have to
    # catch the ImportError.
    try:
        import doctest
    except ImportError:
        return
    doctest.testmod(tornado.util)

# Generated at 2022-06-24 09:28:32.664803
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    class Configurable_0(Configurable):
        def configurable_base(self):
            return Configurable_0
        @classmethod
        def configurable_default(self):
            return Configurable_0
    x = Configurable_0()
    assert x.initialize == x._initialize

test_Configurable_initialize()

# Generated at 2022-06-24 09:28:39.355742
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    class A:
        def get_name(self, name, *args):
            test_ArgReplacer = ArgReplacer(self.get_name, 'name')
            old_value, args, kwargs = test_ArgReplacer.replace('name2', args, {})
            logging.info('args={}, kwargs={}'.format(args, kwargs))
            logging.info('old_value={}'.format(old_value))
            #return old_value if old_value is not None else name
            return name
    a = A()
    a.get_name('name1', 'a', 'b')

# Generated at 2022-06-24 09:28:49.924838
# Unit test for function doctests
def test_doctests():
    # type: () -> None
    """Unit test for function doctests"""
    import doctest
    import sys

    # suport python 3.7 doctest bug
    # https://docs.python.org/3/library/doctest.html#doctest.register_optionflag
    if sys.version_info >= (3, 7):
        import unittest.mock  # type: ignore

        def check_output(*args, **kwargs):
            # type: (*Any, **Any) -> bytes
            kwargs.pop("text", None)
            return unittest.mock.DEFAULT

        unittest.mock.patch("subprocess.check_output", check_output).start()

    # Disable colorama's ANSI color support, which doctest doesn't seem
    # to be able to handle, and conflict with

# Generated at 2022-06-24 09:28:56.623068
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
	# test_ArgReplacer_get_old_value -> func -> args
	# test_ArgReplacer_get_old_value -> func -> kwargs
	func = lambda args, kwargs: None
	
	a = ArgReplacer(func, 'args')
	old_value = a.get_old_value(('a', 'b'), {'kwargs': 'kwargs'})
	assert old_value == 'a'
	
	a = ArgReplacer(func, 'kwargs')
	old_value = a.get_old_value(('a', 'b'), {'kwargs': 'kwargs'})
	assert old_value == 'kwargs'

# Generated at 2022-06-24 09:29:02.248376
# Unit test for function import_object
def test_import_object():
    import unittest2
    import tornado.escape
    import tornado.util
    import_object = tornado.util.import_object
    class ImportObjectTestCase(unittest2.TestCase):
        def test_import_object(self):
            self.assertTrue(import_object('tornado.escape') is tornado.escape)
            self.assertTrue(import_object('tornado.escape.utf8') is
                            tornado.escape.utf8)
            self.assertTrue(import_object('tornado') is tornado)
            self.assertRaises(ImportError, import_object,
                              'tornado.missing_module')
    unittest2.main()



# Generated at 2022-06-24 09:29:05.762532
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        try:
            raise ValueError(3)
        except:
            raise_exc_info(sys.exc_info())
    except ValueError as e:
        assert e.args == (3,)
    else:
        assert False, "did not get expected exception"



# Generated at 2022-06-24 09:29:12.291587
# Unit test for method get_old_value of class ArgReplacer
def test_ArgReplacer_get_old_value():
    def test_method(a, b, c):
        pass
    replacer = ArgReplacer(test_method, "b")
    assert replacer.get_old_value(
        (1, 2, 3), {}
    ) == 2
    assert replacer.get_old_value((1, ), {"b": 2}) == 2
    assert replacer.get_old_value((), {"a": 1, "b": 2}) == 2
    assert replacer.get_old_value((), {"b": 2}) == 2
    assert replacer.get_old_value((), {}) is None
    assert replacer.get_old_value((), {}, default="not found") == "not found"


# Generated at 2022-06-24 09:29:21.289613
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    # The decompressor is not compatible with jython's native zlib
    # module
    import platform
    if platform.system().lower() == 'java':
        raise unittest.SkipTest('jython')
    data = b'\x1f\x8b\x08\x08\x9d\x8d\xaa\x5a\x00\x03t\x00\x03\xf3\x48\xcd\xc9\xc9\xd7Q(\xcf/\xcaIU\x04\x00\xbb\xe9\x18\x0c\x00\x00\x00'
    d = GzipDecompressor()
    assert d.decompress(data) == b"test"
    assert d.unconsumed_tail == b""
    assert d.flush()

# Generated at 2022-06-24 09:29:21.884761
# Unit test for constructor of class GzipDecompressor
def test_GzipDecompressor():
    GzipDecompressor()



# Generated at 2022-06-24 09:29:23.396485
# Unit test for function raise_exc_info
def test_raise_exc_info():
    try:
        raise_exc_info(sys.exc_info())
    except:
        pass


_MAXHEADERS = 128



# Generated at 2022-06-24 09:29:31.189518
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    # type: () -> None
    class C(Configurable):
        @classmethod
        def configurable_base(cls):
            # type: () -> Type[C]
            return cls

        @classmethod
        def configurable_default(cls):
            # type: () -> Type[C]
            return cls

        def initialize(self):
            # type: () -> None
            pass

    C().initialize()



# Generated at 2022-06-24 09:29:37.508232
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(days=2)) == 172800.0
    assert timedelta_to_seconds(datetime.timedelta(seconds=2)) == 2.0
    assert timedelta_to_seconds(datetime.timedelta(microseconds=2)) == 0.000002
    assert timedelta_to_seconds(datetime.timedelta(days=2, seconds=2, microseconds=2)) == 172800.000002



# Generated at 2022-06-24 09:29:41.040022
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    object_dict = ObjectDict()
    object_dict['test_key'] = 'test_value'
    assert object_dict['test_key'] == object_dict.test_key


# Generated at 2022-06-24 09:29:51.466086
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    g1 = GzipDecompressor()
    g2 = GzipDecompressor()
    g1.decompress(b'foo')
    g2.decompress(b'bar')
    assert g1.flush() == b''
    assert g2.flush() == b''
    g1.decompress(b'foo')
    g2.decompress(b'bar')
    assert g1.flush() == b'foo'
    assert g2.flush() == b'bar'
    g1.decompress(b'foo')
    g2.decompress(b'bar')
    g1.decompress(b'foo')
    g2.decompress(b'bar')
    assert g1.flush() == b'foofoo'

# Generated at 2022-06-24 09:30:01.767826
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class ImplClass(Configurable):
        @classmethod
        def configurable_base(cls):
            return ImplClass

        @classmethod
        def configurable_default(cls):
            return ImplClass

        def initialize(self, foo: Any, bar: Any = 0) -> None:
            self.foo = foo
            self.bar = bar

    impl = ImplClass(1, bar=10)
    assert impl.foo == 1
    assert impl.bar == 10
    # check that keywords passed to __init__ override configured kwargs
    ImplClass.configure(None, bar=11)
    impl = ImplClass(2, bar=20)
    assert impl.foo == 2
    assert impl.bar == 20
    # check that configured kwargs are used when __init__ is called with none

# Generated at 2022-06-24 09:30:10.395819
# Unit test for function re_unescape
def test_re_unescape():
    assert re_unescape(r"\*") == r"*"

# Generated at 2022-06-24 09:30:21.514728
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    class Impl(Configurable):
        def configurable_base(self):
            return Configurable

        def configurable_default(self):
            return Impl

        def initialize(self):
            pass

    impl = Impl()
    assert impl.__class__ is Impl
    assert isinstance(impl, Configurable)

    class SubImpl(Impl):
        pass

    SubImpl.configure(impl)
    assert isinstance(SubImpl(), Impl)
    assert isinstance(SubImpl(), Configurable)
    assert issubclass(SubImpl, Impl)

    assert SubImpl().__class__ is Impl

    # Any keyword arguments should be passed to the constructor.
    class ImplWithKwargs(Impl):
        def initialize(self, value):
            self.value = value


# Generated at 2022-06-24 09:30:31.839310
# Unit test for method flush of class GzipDecompressor
def test_GzipDecompressor_flush():
    #case 1
    gzip_decompressor = GzipDecompressor()
    unzipped = gzip_decompressor.flush()
    print(unzipped)
    print("case 1 passed")
    #case 2
    gzip_decompressor = GzipDecompressor()
    gzip_decompressor.decompress(b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xffK\x03\x00')
    unzipped_2 = gzip_decompressor.flush()
    print(unzipped_2)
    print("case 2 passed")

test_GzipDecompressor_flush()


# Deprecated aliases
TimeoutError = TimeoutError
GzipDecompressor = GzipDecompressor

#

# Generated at 2022-06-24 09:30:43.179395
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    
    def _method_under_test(self, name):
        # type: (ObjectDict, str) -> Any
        return self[name]
    # Test with positional arguments
    # No error should be raised
    assert not _method_under_test(ObjectDict({}), '')
    assert not _method_under_test(ObjectDict({}), '')
    assert not _method_under_test(ObjectDict({}), '')
    assert not _method_under_test(ObjectDict({}), '')
    assert not _method_under_test(ObjectDict({}), '')

    # Test with keyword arguments
    # No error should be raised
    assert not _method_under_test(ObjectDict({}), name='')

# Generated at 2022-06-24 09:30:51.417802
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    # Test ArgReplacer.replace for one argument passed by keyword
    def foo(arg):
        pass
    ar = ArgReplacer(foo, "arg")
    assert ar.replace("", (), {"arg": "bar"}) == ("bar", (), {"arg": ""})
    # Test ArgReplacer.replace for one argument passed by position
    def foo(arg):
        pass
    ar = ArgReplacer(foo, "arg")
    assert ar.replace("", ("bar",), {}) == ("bar", ("",), {})
    # Test ArgReplacer.replace for two arguments, one passed by keyword
    def foo(arg1, arg2):
        pass
    ar = ArgReplacer(foo, "arg1")

# Generated at 2022-06-24 09:31:00.472697
# Unit test for function timedelta_to_seconds
def test_timedelta_to_seconds():
    assert timedelta_to_seconds(datetime.timedelta(seconds=1)) == 1
    assert timedelta_to_seconds(datetime.timedelta(days=1)) == 24 * 60 * 60
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=1)) == 24 * 60 * 60 + 1
    assert timedelta_to_seconds(datetime.timedelta(days=1, seconds=-1)) == 24 * 60 * 60 - 1
    assert timedelta_to_seconds(datetime.timedelta(days=1, microseconds=-1)) == 24 * 60 * 60 - 1e-6
    assert timedelta_to_seconds(datetime.timedelta(days=-1)) == -24 * 60 * 60



# Generated at 2022-06-24 09:31:03.800273
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    # type: () -> None
    assert ObjectDict()
    assert ObjectDict({'test': 'a'})
    assert ObjectDict(test='a')



# Generated at 2022-06-24 09:31:09.736822
# Unit test for method initialize of class Configurable
def test_Configurable_initialize():
    from tornado.ioloop import IOLoop

    class FakeConfigurable(Configurable):
        @classmethod
        def configurable_base(self):
            return self

        @classmethod
        def configurable_default(self):
            return self

        def initialize(self):
            pass

    FakeConfigurable()
    FakeConfigurable.configure(IOLoop)
    FakeConfigurable()


# Generated at 2022-06-24 09:31:19.265498
# Unit test for function raise_exc_info
def test_raise_exc_info():
    msg = "hello %s %d"
    e = ValueError(msg % ("world", 1))
    def f():
        raise e
    try:
        f()
    except ValueError as e2:
        assert e is e2
        assert msg % ("world", 1) == str(e2)
        # Verify that e2 has the full tb
        assert e.__traceback__ is not None
    exc_info = (type(e), e, e.__traceback__)
    tb = None
    try:
        raise_exc_info(exc_info)
    except ValueError as e2:
        assert exc_info[1] is e2
        assert msg % ("world", 1) == str(e2)
        tb = e2.__traceback__

# Generated at 2022-06-24 09:31:24.931201
# Unit test for method __getattr__ of class ObjectDict
def test_ObjectDict___getattr__():
    obj = ObjectDict()
    try:
        obj.__setattr__('a', 1)
    except KeyError as e:
        # print(e)
        pass
    try:
        obj.__getattr__('a')
    except AttributeError as e:
        # print(e)
        pass



# Generated at 2022-06-24 09:31:32.375145
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    from inspect import getfullargspec
    class TestFunc(object):
        '''Test function for ArgReplacer replace'''
        def __init__(self):
            self.kwargs = {}
            self.args = {}
            self.func_code = ''
            self.co_varnames = []
            self.co_argcount = 0
        def getfullargspec(self):
            return getfullargspec(self.func) # type: ignore
        def func(self, a: int, b: int, c: int, d: int, e: int, f: int) -> int:
            return a+b+c+d+e+f

    func = TestFunc()
    replacer = ArgReplacer(func, 'e')

    # test for old_value is not None

# Generated at 2022-06-24 09:31:42.430412
# Unit test for constructor of class ArgReplacer
def test_ArgReplacer():  # pragma: no cover
    a = ArgReplacer(lambda foo=None, bar=None, baz=None: None, "bar")
    assert a.name == "bar"
    assert a.arg_pos is None
    assert a.get_old_value((), {}) is None
    assert a.get_old_value((), {"bar": 42}) == 42
    assert a.get_old_value((), {"bar": 42, "baz": 24}) == 42
    assert a.replace(0, (1, 2, 3), {"bar": 4, "baz": 5}) == (4, (1, 2, 3), {"bar": 0, "baz": 5})

# Generated at 2022-06-24 09:31:53.349569
# Unit test for method replace of class ArgReplacer
def test_ArgReplacer_replace():
    def func1(a, b=3, c=4):
        pass
    def func2(a, b, c=4):
        pass

    assert ArgReplacer(func1, 'a').replace(5, [1, 2, 3], {}) == (1, [5, 2, 3], {})
    assert ArgReplacer(func1, 'a').replace(-2, [1, 2, 3], {}) == (1, [-2, 2, 3], {})
    assert ArgReplacer(func1, 'b').replace(2, [1, 2, 3], {}) == (2, [1, 2, 3], {'b': 2})
    assert ArgReplacer(func1, 'c').replace(1, [1, 2, 3], {}) == (4, [1, 2, 3], {'c': 1})

# Generated at 2022-06-24 09:32:03.498404
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    import operator
    d = ObjectDict(a=1, b=2, c=3)
    assert d.a == 1
    assert d.b == 2
    assert d.c == 3
    assert len(d) == 3
    assert sorted(d.keys()) == ["a", "b", "c"]
    assert sorted(d.values()) == [1, 2, 3]
    assert sorted(d.items()) == [("a", 1), ("b", 2), ("c", 3)]
    assert d.get("a") == 1
    assert d.get("d") is None

    d.c = 4
    assert d["c"] == 4
    d["d"] = 5
    assert d.d == 5
    del d.a
    assert "a" not in d
    d.e = 6

# Generated at 2022-06-24 09:32:07.266239
# Unit test for function exec_in
def test_exec_in():
    x = y = z = 0
    ns = dict(x=x, y=y, z=z)
    exec_in("y += 1", ns)
    exec_in("z += 1", ns)
    assert ns["x"] == 0
    assert ns["y"] == 1
    assert ns["z"] == 1



# Generated at 2022-06-24 09:32:11.795814
# Unit test for function errno_from_exception
def test_errno_from_exception():
    try:
        raise OSError(5, "Operation not permitted")
    except Exception as e:
        errno = errno_from_exception(e)
    assert errno == 5
    try:
        raise ValueError()
    except Exception as e:
        errno = errno_from_exception(e)
    assert errno is None



# Generated at 2022-06-24 09:32:16.554124
# Unit test for function import_object
def test_import_object():
    m = import_object("email.utils")
    assert m.__name__ == "email.utils"
    m = import_object("email")
    assert m.__name__ == "email"
    try:
        import_object("email.missing_module")
    except ImportError:
        pass
    else:
        raise Exception("expected ImportError")
    try:
        import_object("missing_module")
    except ImportError:
        pass
    else:
        raise Exception("expected ImportError")





# Generated at 2022-06-24 09:32:17.949194
# Unit test for method __new__ of class Configurable
def test_Configurable___new__():
    """Unit test for method __new__ of class Configurable"""
    pass



# Generated at 2022-06-24 09:32:19.286818
# Unit test for constructor of class ObjectDict
def test_ObjectDict():
    od = ObjectDict()
    od.foo = 'bar'


# Generated at 2022-06-24 09:32:31.096388
# Unit test for method decompress of class GzipDecompressor
def test_GzipDecompressor_decompress():
    z = zlib.decompressobj(zlib.MAX_WBITS | 32)
    f = open("gzip_file", 'rb')
    body = f.readlines()
    b = b''.join(body)
    print(type(b))  # <class 'bytes'>

    # print(type(z.decompress(b)))  # <class 'bytes'>

    z = zlib.decompressobj(zlib.MAX_WBITS | 16)
    # print('ZLIB: ', type(z.decompress(b)))  # <class 'bytes'>

    z = GzipDecompressor()
    print('GzipDecompressor: ', type(z.decompress(b)))  # <class 'bytes'>
