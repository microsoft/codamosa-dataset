

# Generated at 2022-06-23 03:26:59.901483
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name = dict(required=True),
            selection = dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert main() == True

# Generated at 2022-06-23 03:27:14.722868
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'get_bin_path', return_value=True):
        with patch.object(AnsibleModule, 'run_command', return_value=[0, "python install", ""]) as mock_run_command:
            module = AnsibleModule(
                argument_spec=dict(
                    name=dict(required=True),
                    selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
                ),
                supports_check_mode=True,
            )
            module.check_mode = True
            module.exit_json = MagicMock()
            name = module.params['name']
            selection = module.params['selection']
            test_main()

# Generated at 2022-06-23 03:27:22.571585
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    from ansible.utils import context_objects
    from ansible.module_utils.basic import AnsibleModule
    set_module_args(dict(
        name='python',
        selection='hold'
    ))
    with context_objects.system_dry_run():
        main()

# Generated at 2022-06-23 03:27:28.338105
# Unit test for function main
def test_main():
    # GIVEN
    module_args = {
        'name': 'python',
        'selection': 'hold',
    }

    # WHEN
    result = main()

    # THEN
    assert result['changed'] is True
    assert result['before'] is 'install'
    assert result['after'] is 'hold'

# Generated at 2022-06-23 03:27:39.170926
# Unit test for function main
def test_main():
    success = False
    list_of_modules = []
    class TestModule:
        
        def get_bin_path(self, binary, required=True):
            return "dpkg"
        
        def __init__(self, params, supports_check_mode=True):
            assert params['name'] == "python"
            assert params['selection'] == "hold"
            self.params = params
            self.supports_check_mode = supports_check_mode
        
        def run_command(self, args, check_rc=True, data=None):
            assert args == ['dpkg', '--get-selections', 'python']
            return 0, "python install\n", ""
        
        def exit_json(self, changed=None, before=None, after=None, meta=None):
            assert changed

# Generated at 2022-06-23 03:27:47.549096
# Unit test for function main
def test_main():
    assert main(["--name=python", "--selection=hold"]) == (True, "python hold", "python hold")
    assert main(["--name=python", "--selection=deinstall"]) == (False, "python hold", "python deinstall")
    assert main(["--name=python", "--selection=purge"]) == (False, "python deinstall", "python purge")
    assert main(["--name=python", "--selection=install"]) == (False, "python purge", "python install")
    assert main(["--check", "--name=python", "--selection=hold"]) == (False, "python install", "python hold")
    assert main(["--check", "--name=python", "--selection=deinstall"]) == (True, "python install", "python deinstall")

# Generated at 2022-06-23 03:27:58.726295
# Unit test for function main
def test_main():
    test_cases = [
        {
            'name': 'test1',
            'params': dict(
                name='test1',
                selection='hold'
            ),
            'changed': True,
            'before': 'not present',
            'after': 'hold'
        },
        {
            'name': 'test1',
            'params': dict(
                name='test1',
                selection='hold'
            ),
            'changed': False,
            'before': 'hold',
            'after': 'hold'
        },
        {
            'name': 'test1',
            'params': dict(
                name='test1',
                selection='install'
            ),
            'changed': True,
            'before': 'hold',
            'after': 'install'
        }
    ]

    module = Ansible

# Generated at 2022-06-23 03:28:03.759828
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec=dict(
      name=dict(required=True),
      selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,
  )

  name = module.params['name']
  selection = module.params['selection']

  assert name == "python"
  assert selection == "hold"

# Generated at 2022-06-23 03:28:10.817288
# Unit test for function main
def test_main():
    class test_args(object):
        def __init__(self, name, selection):
            self.name = name
            self.selection = selection

        def __getattr__(self, item):
            return os.environ[item]

    class test_ansible_module(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.check_mode = False
            self.changed = False

    class test_run_command(object):
        def __init__(self, name, selection):
            self.name = name
            self.selection = selection
            self.out = "%s hold" % name if self.selection == "hold" else "%s install" % name


# Generated at 2022-06-23 03:28:22.473685
# Unit test for function main
def test_main():
    MOCK_MODULE = {
        'run_command': lambda *a: (0, 'python install'),
        'get_bin_path': lambda *a: 'dpkg',
        'check_mode': False,
    }
    MOCK_MODULE2 = {
        'run_command': lambda *a: (0, 'python purge'),
        'get_bin_path': lambda *a: 'dpkg',
        'check_mode': False,
    }
    result = main(MOCK_MODULE)
    assert result['changed'] == False
    assert result['before'] == 'install'
    assert result['after'] == 'install'

    result2 = main(MOCK_MODULE2)
    assert result2['changed'] == True
    assert result2['before'] == 'purge'

# Generated at 2022-06-23 03:28:30.914330
# Unit test for function main
def test_main():
    ## Test function main
    ## Test 1
    global EXAMPLES
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]


# Generated at 2022-06-23 03:28:39.125475
# Unit test for function main
def test_main():
    comp_out = "3.4.3-1+deb.sury.org~trusty+1 install"
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    def run_command_mock(cmd, check_rc=True):
        print(cmd)
        if cmd[0] == dpkg:
            if cmd[1] == "--get-selections":
                return 0, comp_out, ""

# Generated at 2022-06-23 03:28:48.960679
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = lambda changed, before, after: print(changed, before, after)
    module.run_command = lambda cmd, **kwargs: 'python install' if cmd[-3:] == name else (0, 'python install', None)

    name = 'python'
    selection = 'hold'
    #main()
    assert main() == 0

# Generated at 2022-06-23 03:28:49.577901
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 03:28:57.558363
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = test_module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = test_module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if test_module.check_mode or not changed:
        test

# Generated at 2022-06-23 03:29:09.316789
# Unit test for function main
def test_main():

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic import AnsibleModule
    import mock

    print("Checking case - name existing, selection different")

    module  = mock.Mock()
    module.check_mode  = False
    module.params = {'name': 'exists', 'selection': 'test'}
    module.run_command = mock.Mock()
    module.run_command.return_value = (0,'exists\tinstall\n','')
    module.get_bin_path  = mock.Mock()
    module.get_bin_path.return_value = '/usr/bin/dpkg'



# Generated at 2022-06-23 03:29:18.711342
# Unit test for function main
def test_main():
    '''
    Tests to see if dpkg_selections module works as intended
    '''

    # Run the function
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-23 03:29:27.700653
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:29:36.978176
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split

# Generated at 2022-06-23 03:29:47.399016
# Unit test for function main
def test_main():
    # This is the object we will be testing.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    # If check

# Generated at 2022-06-23 03:29:58.541244
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:29:59.592823
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-23 03:30:09.167407
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    test_module = type('test_module', (object,), {'params':{'name': name, 'selection': selection}, '_ansible_check_mode':True})
    dpkg = type('dpkg', (object,), {'rc':0, 'out':'python hold', 'err':'', 'data':''})
    test_module.run_command = lambda args, data, check_rc: (getattr(dpkg, 'rc'), getattr(dpkg, 'out'), getattr(dpkg, 'err'))
    test_module.exit_json = lambda changed, before, after: (changed, before, after)

# Generated at 2022-06-23 03:30:18.572318
# Unit test for function main
def test_main():
    open_mock = mocker.patch('__builtin__.open')
    open_mock.return_value = mocker.MagicMock(spec=file)
    file_mock = open_mock.return_value.__enter__.return_value
    file_mock.read.return_value = 'popen'
    dpkg_mock = mocker.patch('ansible_collections.community.general.plugins.module_utils.basic.AnsibleModule.get_bin_path')
    dpkg_mock.return_value = 'dpkg'
    run_command_mock = mocker.patch('ansible_collections.community.general.plugins.module_utils.basic.AnsibleModule.run_command')

# Generated at 2022-06-23 03:30:29.655913
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)
    module.run_command = MagicMock(return_value=[0, "", ""])
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C'}
    module.exit_json = MagicMock()
    module.check_mode = False

    main()
    out, err = capsys.readouterr()

    assert module.run_command.called

# Generated at 2022-06-23 03:30:41.080208
# Unit test for function main
def test_main():
    # Import module
    from ansible.modules.packaging.os.dpkg_selections import main

    class DummyModule:
        params = { 'name' : 'python', 'selection' : 'hold' }
        supports_check_mode = True

        def get_bin_path(self, exe, required=True):
            # Return dummy binary path
            return '/bin/dpkg'

        def run_command(self, args, check_rc=True):
            self.command = args
            return (0, 'python hold', '')

        def exit_json(self, changed, before, after):
            assert changed == True
            assert before == 'not present'
            assert after == 'hold'
            self.exitjson = True

    # Instantiate class
    dpkg_module = DummyModule()

    # Call main function

# Generated at 2022-06-23 03:30:53.938572
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:31:02.658591
# Unit test for function main
def test_main():
    # Unit test import
    import sys
    # Target module to be unit test
    target_module = sys.modules['ansible.modules.packaging.os.dpkg_selections']
    # Unit test function name
    target_function = target_module.main
    # Unit test parameters
    params = {
        "name": "python",
        "selection": "hold"
    }
    # Unit test run
    result = target_function(params)
    assert(result['changed'] == False)
    assert(result['before'] == 'deinstall')

# Generated at 2022-06-23 03:31:07.033108
# Unit test for function main
def test_main():
    import sys
    import tempfile

    input_data = "mypackage install"
    f = open(tempfile.mktemp(), "wb")
    f.write(input_data)
    f.close()

    sys.argv = ['']
    (rc, out, err) = main()

    assert rc == 0
    assert out == True
    assert err == ''

# Generated at 2022-06-23 03:31:16.949931
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
            'name': {'required': True},
            'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True},
    })

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:31:27.158881
# Unit test for function main
def test_main():
    # Arrange
    function_name = 'main'
    module_args = {
        'name': 'python',
        'selection': 'hold',
        'check_mode': True
    }
    expected_result = {
        'changed': True,
        'after': 'hold',
        'before': 'install'
    }

    # Act
    with mock.patch.object(main, 'module') as m_module, \
        mock.patch.object(main, 'dpkg', return_value='dpkg'), \
        mock.patch.object(main, 'run_command') as m_run_command:

        m_module.params = module_args
        m_run_command.return_value = (0, 'python install', '')
        result = main.main()

        # Assert
        assert result == expected

# Generated at 2022-06-23 03:31:27.849192
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:31:35.967876
# Unit test for function main
def test_main():
    # Check that __main__ is using get_bin_path
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    try:
        module.get_bin_path('dpkg', True)
    except:
        raise


# Generated at 2022-06-23 03:31:45.079143
# Unit test for function main
def test_main():
    # Mock the module and its arguments.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )

    class AnsibleModuleMock(object):
        def __init__(self, module):
            self.check_mode = module.check_mode
            self.params = module.params

        def get_bin_path(self, path, required=False):
            if not required:
                return ''
            return 'dpkg'

        def exit_json(self, **kwargs):
            self.changed = kwargs['changed']
            self.before = kwargs['before']
            self.after

# Generated at 2022-06-23 03:31:56.820764
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:31:57.647016
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 03:32:08.590765
# Unit test for function main
def test_main():
    test_out = "python hold"
    test_select = 'install'
    test_current = 'hold'

    import ansible.module_utils.basic as basic
    basic.RUN_CALLBACK_KWARGS['data'] = "%s %s" % ('python', test_select)
    basic.get_bin_path = lambda x: x
    basic.AnsibleModule.run_command = lambda self, command, check_rc=False: (0, test_out, None)
    basic.AnsibleModule.check_mode = False
    basic.AnsibleModule.exit_json = lambda self, **kwargs: setattr(self, 'exit_args', kwargs)


# Generated at 2022-06-23 03:32:16.525589
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.process import get_bin_path
    from ansible_collections.community.general.plugins.module_utils.action.module_common import ActionBase
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch, Mock

    path_map = {}
    path_map['/usr/bin/dpkg'] = '/bin/true'
    ActionBase._configure_module = Mock(return_value=ImmutableDict(ANSIBLE_MODULE_ARGS={}))


# Generated at 2022-06-23 03:32:17.154758
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:32:23.365623
# Unit test for function main
def test_main():
    # Check if the main function works if no changes needs to be done
    current = "install"
    selection = "install"
    assert (current == selection)

    # Check if the main function works if the requested changes are not
    # supported
    current = "install"
    selection = "uninstall"
    assert (current != selection)

    # Check if the main function works if the requested changes are
    # supported
    current = "install"
    selection = "purge"
    assert (current != selection)

# Generated at 2022-06-23 03:32:31.212579
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-23 03:32:37.983479
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold'
    )
    module = AnsibleModule(argument_spec=args)
    rc, out, err = module.run_command(['/usr/bin/dpkg', '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != "hold"
    module.exit_json(changed=changed, before=current, after="hold")

# Generated at 2022-06-23 03:32:42.170030
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:32:49.205726
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import action_common as action
    from ansible.module_utils._text import to_bytes

    args = dict(name='python', selection='hold')
    module = action.ActionModule(argument_spec=args)

    assert module.supports_check_mode is True
    assert module.supports_diff_mode is True
    assert module.deprecate_check_mode is False
    
    def check_command():
        return (0, 'python\thold\n', None)
    module.run_command = check_command

    module.run()
    result = module.parsed_args

# Generated at 2022-06-23 03:32:53.455020
# Unit test for function main
def test_main():
    import sys
    import collections

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:32:54.154209
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 03:33:00.655757
# Unit test for function main
def test_main():
    # This is where I will write my unit tests
    print("Running Unit Tests")
    print("------------------")
    test1 = main('--name==test', '--selection==install', '--check_mode==False')
    test2 = main('--name==test', '--selection==hold', '--check_mode==False')
    print("test1 =", test1)
    print("test2 =", test2)
    print("------------------")
    assert test1== 'install'
    assert test2== 'hold'
    # main()

# Generated at 2022-06-23 03:33:08.818314
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:16.062737
# Unit test for function main
def test_main():
    name = 'test_package'
    selection = 'hold'

    # Set a fake dpkg command
    dpkg = 'fake_dpkg'

    # Test fail if dpkg returns error
    rc = 1
    err = "dpkg error 1"
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(rc, None, err))
    module.run_command.assert_called_with([dpkg, '--get-selections', name])

# Generated at 2022-06-23 03:33:19.063119
# Unit test for function main
def test_main():
    # Skip unit test if this is not a debian system.
    if platform.dist()[1] != 'stretch':
        return 0

    pass

# Generated at 2022-06-23 03:33:20.149583
# Unit test for function main
def test_main():
  print(main())


# Generated at 2022-06-23 03:33:31.210020
# Unit test for function main

# Generated at 2022-06-23 03:33:34.190013
# Unit test for function main
def test_main():
  params = {'name': 'test-package', 'selection': 'hold'}
  args = {}
  rc = AnsibleModule(argument_spec=params)
  rc.params = params
  rc.args = args

# Generated at 2022-06-23 03:33:39.616026
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda x, **kwargs: (0, "python hold", "")
    main()



# Generated at 2022-06-23 03:33:49.622664
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # set up the mock
    module.run_command = MagicMock(return_value = (0, "python install", ""))
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_MESSAGES': 'C', 'LC_CTYPE': 'C'}

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
   

# Generated at 2022-06-23 03:33:59.841431
# Unit test for function main
def test_main():
    import os
    import stat
    import tempfile
    import platform
    import pytest
    import json
    import shutil

    # Get the version of the platform we are running on so we can
    # make different assumptions based on it.
    platform_dist = platform.dist()
    platform_system = platform.system()

    # Create a temporary directory to store the test files
    tempdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, test_file) = tempfile.mkstemp()
    os.close(fd)

    # Set up the mock dpkg command which will be called by the module
    dpkg_shell_file = os.path.join(tempdir, 'dpkg')
    shutil.copy('/usr/bin/dpkg', dpkg_shell_file)

    # Make the mock

# Generated at 2022-06-23 03:34:10.010306
# Unit test for function main
def test_main():
    global module, dpkg, name, selection, rc, out, err, current, changed
    name = "python"
    selection = "hold"

    from ansible.module_utils.common import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    import sys


    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.

# Generated at 2022-06-23 03:34:18.494791
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold',
    )

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.removed import removed_module

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    print(module.check_mode)

# Generated at 2022-06-23 03:34:24.430422
# Unit test for function main
def test_main():
    dpkg = main()

    assert dpkg.params['name'] == 'python'
    assert dpkg.params['selection'] == 'hold'
    assert dpkg.run_command([dpkg, '--get-selections', 'python'], check_rc=True)
    assert dpkg.run_command([dpkg, '--set-selections'], data="python hold", check_rc=True)

# Generated at 2022-06-23 03:34:33.075285
# Unit test for function main
def test_main():
    from ansible.module_utils.common.module_common import AnsibleModule
    import os
    import json
    import tempfile

    def get_bin_path_mock(name, required, opt_dirs=[]):
        return '/bin/dpkg'

    def run_command_mock(name, check_rc=True, data=None):
        if name[1] == '--get-selections':
            if name[2] == 'python':
                return 0, 'python\tinstall', ''
            else:
                return 0, '', ''
        elif name[1] == '--set-selections':
            return 0, '', ''
        else:
            return 1, '', ''


# Generated at 2022-06-23 03:34:44.391162
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:34:54.338632
# Unit test for function main
def test_main():

    # Mock-up data generated by AnsibleModule.get_bin_path
    class mock_bin_path():
        def __init__(self, name, fatal=False):
            self.name = name
            self.fatal = fatal

    # Mock-up data generated by AnsibleModule.run_command
    class mock_run_command():
        def __init__(self, data="", check_rc=True):
            pass

    # Mock-up data generated by AnsibleModule.exit_json
    class mock_exit_json():
        def __init__(self, changed=False, before=None, after=None):
            self.changed = changed
            self.before = before
            self.after = after

    # Mock-up data generated by AnsibleModule.__init__

# Generated at 2022-06-23 03:34:56.216180
# Unit test for function main
def test_main():
    # This function/module will do nothing when run as a test, because we mock everything in it.
    pass

# Generated at 2022-06-23 03:35:08.556158
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ),
        supports_check_mode=True,
        )

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module

# Generated at 2022-06-23 03:35:19.651851
# Unit test for function main
def test_main():
    # Set up arguments
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True)
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    module.check_mode = True
    module.bin_path = "/bin"

    # Test 1 - Checking mode, no change
    rc = main()
    assert rc['changed'] == False

    # Test 2 - Not checking mode, change
    module.check_mode = False
    rc = main()
    assert rc['changed'] == True
    assert rc['before'] == "not present"
    assert rc['after'] == "hold"

# Generated at 2022-06-23 03:35:24.491934
# Unit test for function main
def test_main():
    pass
    # Unit tests executed within the module need to be executed in their own namespace,
    # or you will get an error message. I am not sure why that is the case.
    #
    # This is a simple function test to illustrate this point.
    # func = main()
    #
    #if func is None:
    #    raise Exception("Test in module namesapce failed")
    #else:
    #    print("Test in module namespace passed")

# Generated at 2022-06-23 03:35:33.970890
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    m_run_command = test_module.run_command
    m_get_bin_path = test_module.get_bin_path

    dpkg = '/usr/bin/dpkg'
    test_module.get_bin_path = lambda *args, **kwargs: dpkg

    name = test_module.params['name']
    selection = test_module.params['selection']


# Generated at 2022-06-23 03:35:35.270111
# Unit test for function main
def test_main():
    procedure = main()
    assert procedure == True

# Generated at 2022-06-23 03:35:37.365806
# Unit test for function main
def test_main():
    """ Unit test for function main """
    assert callable(main), 'The function main doesnt exist'


# Generated at 2022-06-23 03:35:43.188241
# Unit test for function main
def test_main():
    dpkgModule = AnsibleModule(name='dpkg_selections',
                               argument_spec={
                                   'name': {'required': True},
                                   'selection': {
                                       'choices': ['install', 'hold', 'deinstall', 'purge'],
                                       'required': True
                                   }
                               },
                               supports_check_mode=True)

    # Check if it's check mode
    if dpkgModule.check_mode:
        assert dpkgModule.check_mode is True

# Generated at 2022-06-23 03:35:55.701432
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import shlex, subprocess

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]



# Generated at 2022-06-23 03:35:56.408438
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:36:06.122984
# Unit test for function main
def test_main():
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules.package.dpkg import main
    import ansible.constants as C
    import ansible.module_utils.basic as module_utils

    setattr(C, 'DEFAULT_KEEP_REMOTE_FILES', False)
    args = {'name': 'python', 'selection': 'hold', '_ansible_check_mode': True, '_ansible_diff': False, '_ansible_debug': None}
    module_utils.basic._ANSIBLE_ARGS = C.parse_args(args, 'ansible')
    m = main()
    assert(m.params['selection'] == 'hold')

# Generated at 2022-06-23 03:36:06.978032
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:36:07.738240
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:36:08.957514
# Unit test for function main
def test_main():
    a = main()



# Generated at 2022-06-23 03:36:12.397140
# Unit test for function main
def test_main():
    run_ansible_module(module_name='dpkg_selections', module_args=dict(name='python', selection='hold'))

# Generated at 2022-06-23 03:36:23.591313
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:33.215264
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils.basic import AnsibleModule
    import json
    # make the add function available
    from ansible_collections.ansible.community.tests.unit.modules.remote_management.dpkg.dpkg_selections import main

    # Initialize the Ansible module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Set up parameters
    module.params = {'name': 'python', 'selection': 'hold'}
    # Run the add function
    result = main()
    # Fail the test if the wrong result is returned.
    assert result

# Generated at 2022-06-23 03:36:41.937233
# Unit test for function main
def test_main():
    description = "Change dpkg package selection state via --get-selections and --set-selections."
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert module.name == "dpkg_selections"
    assert module.description == description
    assert module.params["name"] == "python"
    assert module.params["selection"] == "hold"

# Generated at 2022-06-23 03:36:49.088259
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.fail_json = True

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:36:51.031292
# Unit test for function main
def test_main():
    args = dict(name="python", selection="hold")
    assert main(args) == "python    hold"

# Generated at 2022-06-23 03:36:53.010819
# Unit test for function main
def test_main():
    try:
        import ssl
    except ImportError:
        ssl = None


# Generated at 2022-06-23 03:37:02.897975
# Unit test for function main
def test_main():

    # No args
    module = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    }, supports_check_mode=True)
    assert main() == module.exit_json(changed=False, before='not present', after='not present')

    # name:
    # selection:
    module = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    }, supports_check_mode=True)
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    assert main() == module.exit