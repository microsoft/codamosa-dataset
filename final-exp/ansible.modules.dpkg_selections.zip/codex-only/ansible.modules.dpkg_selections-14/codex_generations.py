

# Generated at 2022-06-23 03:27:12.583222
# Unit test for function main
def test_main():
    test_module_args = {
        'name': 'python',
        'selection': 'hold',
    }

    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test_module.exit_json = exit_json
    test_module.run_command = run_command
    test_module.get_bin_path = get_bin_path

    results = {
        'rc': 0,
        'stderr': '',
        'stdout': 'python install',
    }


# Generated at 2022-06-23 03:27:22.573043
# Unit test for function main
def test_main():
    # Mocking check mode and diff mode
    old_check_mode = AnsibleModule.check_mode
    old_diff_mode = AnsibleModule.diff_mode
    AnsibleModule.check_mode = True
    AnsibleModule.diff_mode = False

    # Mocking run_command
    old_run_command = AnsibleModule.run_command
    def mocked_run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None):
        if args == "dpkg --set-selections":
            rc = 0
            return rc, "", ""
        else:
            rc = 0
            out = "python 2.7.4\n"
            err = ""
            return rc, out, err

    AnsibleModule.run_command = mocked_run_command

    #

# Generated at 2022-06-23 03:27:24.271837
# Unit test for function main
def test_main():
    # Place your test code here
    module.run_command('echo', "This is test", check_rc=True)

# Generated at 2022-06-23 03:27:32.877755
# Unit test for function main
def test_main():
    dpkg_selections = [
        {
            "name": 'python',
            "selection": "hold",
            "changed": True,
            "before": "not present",
            "after": "hold"
        },
        {
            "name": 'python',
            "selection": "not present",
            "changed": True,
            "before": "hold",
            "after": "not present"
        },
        {
            "name": 'python',
            "selection": "purge",
            "changed": True,
            "before": "not present",
            "after": "purge"
        }
    ]
    for test_case in dpkg_selections:
        assert main(test_case) == test_case

# Generated at 2022-06-23 03:27:43.652482
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

# Generated at 2022-06-23 03:27:47.721482
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    test.main()

# Generated at 2022-06-23 03:27:48.412202
# Unit test for function main
def test_main():
  pass

# Generated at 2022-06-23 03:28:00.034576
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.check_mode = True
            self._name = "cows"
        def get_bin_path(self, bin, required=False):
            return bin
        def exit_json(self, **kwargs):
            self.exit_json_args = kwargs
            return 0
        def fail_json(self, **kwargs):
            self.fail_json_args = kwargs


# Generated at 2022-06-23 03:28:08.825359
# Unit test for function main
def test_main():
    with open(os.devnull, 'w') as fnull:
        with patch('ansible.module_utils.basic.AnsibleModule'):
            from ansible.module_utils.basic import AnsibleModule
            with patch('os.path.exists', lambda x: True):
                with patch('subprocess.check_output', lambda *x: (0, 'test_package\tinstall\n', '')):
                    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(required=True)))
                    assert module.run_command([dpkg, '--get-selections', 'test_package'], check_rc=True) == (0, 'test_package\tinstall\n', '')
                    assert module.check_mode or not changed == True

# Generated at 2022-06-23 03:28:21.316454
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)))
    module.get_bin_path = MagicMock(return_value='/usr/bin/dpkg')

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:28:22.760158
# Unit test for function main
def test_main():
    fake_module = None

    dpkg_selections.main(fake_module)

# Generated at 2022-06-23 03:28:24.520562
# Unit test for function main
def test_main():
    # Make sure the import was successful
    assert main is not None


# Generated at 2022-06-23 03:28:32.863479
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        check_invalid_arguments=False,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:28:33.794415
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:28:43.467381
# Unit test for function main
def test_main():
    test = {
        "params": {
            "name": 'python',
            "selection": 'hold'
        }
    }
    def run_command(args, check_rc=False):
        if test['params']['name'] in args:
            if test['params']['name'] == 'python':
                return 0, 'python install', ''
            else:
                return 0, '', ''

    import sys
    import inspect
    import re
    test_result = False
    f_locals = locals()
    f_globals = globals()
    global run_command
    run_command = run_command
    m = AnsibleModule(argument_spec=dict())
    sys.modules['ansible.module_utils.basic'] = m

# Generated at 2022-06-23 03:28:53.844103
# Unit test for function main
def test_main():
    # User input
    name = 'python'
    selection = 'hold'
    # Create an instance of module argument_spec
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    # Check if dpkg package selection is present
    if selection in out:
        changed = False
    else:
        changed = True

# Generated at 2022-06-23 03:29:01.100886
# Unit test for function main
def test_main():
    #
    # Imports
    #
    import sys
    import json
    #
    # Mock out the module
    #
    sys.modules['ansible.module_utils.basic'] = __import__('ansible.module_utils.basic')
    from ansible.module_utils.basic import AnsibleModule
    sys.modules['ansible.module_utils.six'] = __import__('ansible.module_utils.six')
    #
    # Create the AnsibleModule
    #
    json_data = {u'params': {u'name': u'python', u'selection': u'hold'}, u'module_name': u'dpkg_selections', u'module_args': u'name=python selection=hold'}
    args = json.dumps(json_data)

# Generated at 2022-06-23 03:29:05.202912
# Unit test for function main
def test_main():
    test_args = {
        u'name': u'python',
        u'selection': u'hold',
    }
    test_result = {
        u'changed': True,
        u'before': u'install',
        u'after': u'hold',
    }

# Generated at 2022-06-23 03:29:05.790725
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:29:12.301448
# Unit test for function main
def test_main():

  f = open("./test/dpkg_selections/dpkg_selections.json", "r")
  source=f.read()
  source_json = json.loads(source)

  # Run test
  test_module = AnsibleModule(argument_spec=source_json['argument_spec'], supports_check_mode=source_json['supports_check_mode'])

  if "main" in source_json['function_to_test']:
    test_module.main()

  test_module.exit_json(changed=True)

# Generated at 2022-06-23 03:29:24.928890
# Unit test for function main
def test_main():
    fields = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
    )
    module = AnsibleModule(argument_spec=fields, supports_check_mode=True)
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    name = module.params['name']
    selection = module.params['selection']

    changed = current != selection

# Generated at 2022-06-23 03:29:28.748130
# Unit test for function main

# Generated at 2022-06-23 03:29:37.687346
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = "python"
    module.params['selection'] = "hold"
    # Set our fake check_output function to return something other than 'python hold' for our test.
    # In this case, we have python already held, so we test that.
    module.run_command = mock.MagicMock(return_value=("python hold", "err", 0))
    # dpkg --get-selections python
    module.get_bin_path = mock.MagicMock(return_value="/usr/bin/dpkg")

# Generated at 2022-06-23 03:29:49.768386
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    dpkg = module.get_bin_path('dpkg')
    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)


# Generated at 2022-06-23 03:30:01.941913
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:30:05.218027
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,)

# Generated at 2022-06-23 03:30:14.581162
# Unit test for function main
def test_main():
    f, path, desc = tempfile.mkstemp()
    out = '''
Package: a
Essential: yes
Status: install ok installed
Priority: required
Section: base
Installed-Size: 29
Maintainer: Ubuntu Developers <ubuntu-devel-discuss@lists.ubuntu.com>
Architecture: amd64
Version: 1.2
Depends: c
Pre-Depends: b
Description: a
    a
    a
'''
    with os.fdopen(f, "w") as tmp:
        tmp.write(out)
    rc = dpkg_parse(path).get_package("a")
    assert rc.name == "a"
    assert rc.status == "install ok installed"
    assert rc.arch == "amd64"
    assert rc.version == "1.2"
   

# Generated at 2022-06-23 03:30:22.285698
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if not module.check_mode and changed:
        module.run

# Generated at 2022-06-23 03:30:31.860212
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test_module.run_command = Mock(return_value=(-1, 'OUT', 'ERR'))
    test_module.check_mode = True
    main()
    test_module.fail_json.assert_called_with(msg='[Errno 2] No such file or directory: \'\'')

# Generated at 2022-06-23 03:30:39.440241
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:30:40.129710
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-23 03:30:40.727226
# Unit test for function main
def test_main():
    assert main()==None

# Generated at 2022-06-23 03:30:47.097802
# Unit test for function main
def test_main():
    test_input = dict(
        name='python',
        selection='hold'
    )
    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'])
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    assert out == current

# Generated at 2022-06-23 03:30:58.018449
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:31:02.942290
# Unit test for function main
def test_main():
    from ansible.modules.system.dpkg_selections import main
    from ansible.module_utils.common.dummy import DummyModule

    module = DummyModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
    ),
    supports_check_mode=True,)
    module.params = {'name': 'linux-image-amd64', 'selection': 'install'}

    main()

# Generated at 2022-06-23 03:31:11.634735
# Unit test for function main
def test_main():
    import sys
    import json
    import os
    import subprocess
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import Environment
    import tempfile

    # Mock the imports ansible.module_utils.basic
    def module_return(name, *args, **kwargs):
        if name == 'dpkg_selections':
            # Mock the dpkg module
            module = AnsibleModule(argument_spec=dict(
                name=dict(required=True),
                selection=dict(
                    choices=[
                        'install',
                        'hold',
                        'deinstall',
                        'purge'],
                    required=True)),
                supports_check_mode=True,)
            return module

    module_return.exit_json = lambda *args, **kwargs: None
    module_

# Generated at 2022-06-23 03:31:20.673006
# Unit test for function main
def test_main():
    this_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    this_module.run_command = lambda args, check_rc=False, data=None, binary_data=False, path_prefix=None: (0, "", "")
    this_module.get_bin_path = lambda executable, required=False, opt_dirs=None: "/usr/bin/dpkg"
    assert main() == True

# Generated at 2022-06-23 03:31:32.414499
# Unit test for function main
def test_main():
    import pytest
    from .mock_module import MockModule
    from .mock_command import MockCommand

    # Disable all warnings and only accept errors.
    pytest.set_log_level(logging.ERROR)

    module = MockModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.run_command.set_defaults(rc=0, out='', err='')
    module.get_bin_path.set_defaults(bin_path='/usr/bin/dpkg')

    name = 'python'
    dpkg = '/usr/bin/dpkg'


# Generated at 2022-06-23 03:31:40.657576
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        mock_module_instance = mock_module.return_value
        mock_module_instance.params = {"name": "python", "selection": "hold"}
        mock_module_instance.run_command.return_value = (0, "python hold\n", "err")
        mock_module_instance.check_mode = False
        result = main()
        mock_module_instance.check_mode.assert_not_called()
        assert result == False


# Generated at 2022-06-23 03:31:53.211547
# Unit test for function main
def test_main():
    test_get_bin_path = lambda *args, **kwargs: '/usr/bin/dpkg'
    test_run_command = lambda *args, **kwargs: (0, 'python install')
    test_run_command_2 = lambda *args, **kwargs: (0, '')
    test_check_mode = False
    test_exit_json = lambda *args, **kwargs: None

    old_get_bin_path = AnsibleModule.get_bin_path
    old_run_command = AnsibleModule.run_command
    old_check_mode = AnsibleModule.check_mode
    old_exit_json = AnsibleModule.exit_json

    AnsibleModule.get_bin_path = test_get_bin_path
    AnsibleModule.run_command = test_run_command
    Ansible

# Generated at 2022-06-23 03:31:53.938919
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:32:06.411320
# Unit test for function main
def test_main():
    # Check empty params
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.get_bin_path = MagicMock(return_value='/usr/bin/dpkg')
    module.run_command = MagicMock(return_value=(0, None))
    module.exit_json = MagicMock()
    module.check_mode = False
    main()
    module.get_bin_path.assert_called_with('dpkg', True)
    module.run_command.assert_called_with(['/usr/bin/dpkg', '--get-selections', ''], check_rc=True)
    module.exit_json.assert_called_with(changed=False, before='not present', after=None)

    # Check params

# Generated at 2022-06-23 03:32:16.268947
# Unit test for function main
def test_main():
    import pytest

    from ansible.module_utils.basic import AnsibleModule

    from pkg_resources import parse_version

    import sys

    if sys.version_info[0] != 2:
        pytest.skip("Module dpkg_selections not supported on Python 3")

    # Module calling
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_

# Generated at 2022-06-23 03:32:18.199435
# Unit test for function main
def test_main():
    assert main()
    assert check_mode()
    assert diff_mode()
    assert platform()
    assert attributes()

# Generated at 2022-06-23 03:32:29.745253
# Unit test for function main
def test_main():
    import os, tempfile
    os_path_exists_orig = os.path.exists
    tempfile_mkstemp_orig = tempfile.mkstemp

# Generated at 2022-06-23 03:32:34.342720
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)),
        supports_check_mode=True)
    setattr(module, 'run_command', lambda x, check_rc=True: (0, '', ''))
    setattr(module, 'get_bin_path', lambda x, required=True: '')
    assert main() == None

# Generated at 2022-06-23 03:32:34.993303
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:32:35.569676
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:32:45.522384
# Unit test for function main
def test_main():
    def run_command(args, check_rc=False):
        rc = 0
        out = ""
        err = ""
        return (rc, out, err)

    def get_bin_path(name, required=False):
        return "/usr/bin/dpkg"

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    test_module = {"name": "python", "selection": "hold"}
    old_run_command = AnsibleModule.run_command
    old_get_bin_path = AnsibleModule.get_bin_path

    # Stub the run_command and get_bin

# Generated at 2022-06-23 03:32:56.706610
# Unit test for function main
def test_main():

    # Create a test module
    tmp = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Set module args and command
    tmp.params = {
        'name': 'python',
        'selection': 'hold'
    }
    tmp.run_command = MagicMock(return_value=(0, 'python	install', ''))

    # Call main
    main()

    # Assert that run_command is called with the expected arguments
    tmp.run_command.assert_called_with([u'dpkg', u'--get-selections', u'python'], check_rc=True)

#

# Generated at 2022-06-23 03:33:07.565362
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name= "python"
    selection = "hold"
    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:33:17.984951
# Unit test for function main
def test_main():
    # Provide a set of parameters
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = 'mock_name'
    selection = 'mock_selection'
    current = 'mock_current'
    run_command = 'run_command'
    check_rc = 'check_rc'
    mock_module = {
        'run_command': run_command,
        'check_mode': True,
        'params': {
            'name': name,
            'selection': selection
        }
    }


# Generated at 2022-06-23 03:33:29.064041
# Unit test for function main
def test_main():
    # get the current module to allow stubbing of the function dpkg_selections.main()
    current_module = sys.modules[__name__]

    # stub the exit_json function
    setattr(current_module, "exit_json", lambda **kwargs: "exit_json stub")

    # stub the fail_json function
    setattr(current_module, "fail_json", lambda **kwargs: "fail_json stub")

    # create the module
    test_module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ), supports_check_mode=True)

    # test success

# Generated at 2022-06-23 03:33:29.804864
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:33:39.441532
# Unit test for function main
def test_main():
    test_params = {
        'name': 'python',
        'selection': 'hold'
    }

    # Initialize the class
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Set global variables
    global dpkg
    dpkg = module.get_bin_path('dpkg', True)

    global name
    name = module.params['name']
    global selection
    selection = module.params['selection']

    # Set module args
    module.params = test_params

    # Run the module
    main()


# Generated at 2022-06-23 03:33:41.484495
# Unit test for function main
def test_main():
    dpkg_selections = __import__('dpkg_selections')
    dpkg_selections.main()


# Generated at 2022-06-23 03:33:42.990950
# Unit test for function main
def test_main():
    assert (main({'name': 'python', 'selection': 'hold'}))

# Generated at 2022-06-23 03:33:55.102743
# Unit test for function main
def test_main():
    # Via error caused by incorrect use
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(required=True)
        ),
        check_invalid_arguments=False,
        supports_check_mode=True)

    rc, out, err = module.run_command('dpkg --get-selections', check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert changed == False
    if module.check_mode or not changed:
        assert module.exit_json(changed=changed, before=current, after=selection)

    module.run_command('dpkg --set-selections', data="name selection", check_rc=True)
   

# Generated at 2022-06-23 03:33:57.445399
# Unit test for function main
def test_main():
    module.params['name'] = 'python'
    module.params['selection'] = 'install'
    module.check_mode = False
    main()

# Generated at 2022-06-23 03:33:58.208672
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:34:06.596667
# Unit test for function main
def test_main():
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    module.exit_json(changed=changed, before=current, after=selection)


# Generated at 2022-06-23 03:34:15.722190
# Unit test for function main
def test_main():
    # mock all of the imports
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]



# Generated at 2022-06-23 03:34:20.983353
# Unit test for function main
def test_main():
    args = [
        "python",
        "/root/ansible/ansible/modules/system/dpkg_selections.py",
        "--name=python",
        "--selection=install",
        "--_ansible_verbosity=1",
        "--_ansible_no_log=False"
    ]
    os.execvp("python", args)

# Generated at 2022-06-23 03:34:21.523780
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:34:22.555043
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:34:32.137259
# Unit test for function main
def test_main():
    # Import module and define input parameters
    import os
    import tempfile
    name = "python"
    selection = "install"

    # Set fake variables
    os.environ['LANG'] = 'C'
    os.environ['HOME'] = '/root'

    cur_dir = os.path.dirname(os.path.realpath(__file__))
    file_path = os.path.join(cur_dir, "data/dpkg_selections.data")

    # Create a fake module object
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec = dict())
    module.exit_json = lambda **kwargs: None
    module.run_command = lambda *args, **kwargs: (0, file_path, '')

    # Call the function
   

# Generated at 2022-06-23 03:34:32.938123
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:34:44.328177
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold',
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Test if dpkg --help is run
    def test_exec(**kwargs):
        return 0, 'python install', ''

    # Test if dpkg --get-selections foo is run
    def test_exec2(**kwargs):
        return 0, 'foo install', ''

    setattr(module, '_ansible_module', module)
    setattr(module, 'run_command', test_exec)

# Generated at 2022-06-23 03:34:48.439183
# Unit test for function main
def test_main():
    testData = {
        'name': 'python',
        'selection': 'hold'
        }
    changed, before, after = main(testData)
    assert changed == True
    assert before == 'deinstall'
    assert after == 'hold'



# Generated at 2022-06-23 03:34:55.550089
# Unit test for function main
def test_main():
    # Add test cases here
    test_cases = []
    import ansible.modules.generic.dpkg_selections
    args = {}
    args['name'] = 'openjdk-7-jdk'
    args['selection'] = 'hold'

    # Run test only if we are on a debian platform
    import platform
    import re
    if re.match( ".*debian.*", platform.platform(terse=True)):
        for case in test_cases:
            ansible.modules.generic.dpkg_selections.main(args)

# Generated at 2022-06-23 03:34:56.546670
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-23 03:34:57.859326
# Unit test for function main
def test_main():

    main()

# Generated at 2022-06-23 03:35:06.647752
# Unit test for function main
def test_main():
    test_args = {'name': 'python', 'selection': 'hold'}
    test_args.update(check_mode=True)
    with patch.dict(__salt__, {'pkg.get_selections': MagicMock(side_effect=['hold', 'install']),
                               'pkg.set_selections': MagicMock(return_value=None)}):
        ret = main()
        assert ret['before'] == 'hold'
        assert ret['after'] == 'install'

# Generated at 2022-06-23 03:35:07.255296
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 03:35:08.431595
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:35:09.524221
# Unit test for function main
def test_main():
    assert main() == 'main'

# Generated at 2022-06-23 03:35:18.936023
# Unit test for function main
def test_main():
    hostname = 'testhost'
    class AnsibleModuleDpkg:
        @staticmethod
        def get_bin_path(command, required):
            assert command == 'dpkg'
            assert required
            return '/usr/bin/dpkg'

        def __init__(self, **kwargs):
            assert 'argument_spec' in kwargs
            assert 'supports_check_mode' in kwargs
            self.check_mode = False
            self.params = kwargs['argument_spec']
            self.params['name'] = 'bash'
            self.params['selection'] = 'install'

        def exit_json(self, **kwargs):
            assert 'changed' in kwargs
            assert 'before' in kwargs
            assert 'after' in kwargs

# Generated at 2022-06-23 03:35:31.424016
# Unit test for function main
def test_main():
    dpkg_selections = __import__('dpkg_selections')
    ansible_module_dpkg_selections = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ), supports_check_mode=True)
    ansible_module_dpkg_selections.get_bin_path = lambda x, y: '/tmp/'
    ansible_module_dpkg_selections.run_command = lambda x, rc=True: ('', '', '')

    assert dpkg_selections.main() == 0, "dpkg_selections.main() failed"
    assert ansible_module_dpkg_selections.exit_json.call_count == 1
    assert ans

# Generated at 2022-06-23 03:35:42.050045
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    rc, out, err = module.run_command([module.get_bin_path('dpkg', True), '--get-selections', module.params['name']], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    assert module.params['name'] in out
    assert current == module.params['selection']

# Generated at 2022-06-23 03:35:45.911211
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-23 03:35:56.478032
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:07.146463
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest
    import ansible.modules.system.dpkg_selections

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def run_command(*args, **kwargs):
        """function to patch over run_command; package return data into an exception"""
        if args and len(args) == 3:
            raise AnsibleExitJson(args[2])
        raise AnsibleExitJson(0)


# Generated at 2022-06-23 03:36:11.773093
# Unit test for function main
def test_main():
    myvar = {}
    myvar['current'] = 'hold'
    myvar['selection'] = 'purge'
    myvar['changed'] = False
    assert myvar['current'] == myvar['selection']
    assert myvar['changed'] == False

# Generated at 2022-06-23 03:36:20.116871
# Unit test for function main
def test_main():
    # Mock module_utils/basic.py's AnsibleModule object
    mock_module = MagicMock(name="AnsibleModule")

    # Instantiate our module
    module = dpkg_selections.main()

    # Make sure our module is of the AnsibleModule type
    assert isinstance(module, AnsibleModule)

    # Run code to execute Ansible module function
    main()

    # Assert we called AnsibleModule.exit_json()
    mock_module.exit_json.assert_called_with()

# Generated at 2022-06-23 03:36:20.804794
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 03:36:21.673930
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:36:33.492921
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection
    assert changed

    #module.run_command([dpkg, '--set-selections'

# Generated at 2022-06-23 03:36:34.228402
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:36:43.280570
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:52.657823
# Unit test for function main
def test_main():
    with open('changes.txt', 'w') as f:
        pass  # we're testing without --set-selections, so just clear file

    # Test that deinstall works
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    assert current == 'install'

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, 'deinstall'), check_rc=True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-23 03:36:53.810441
# Unit test for function main
def test_main():
    result = main()
    assert result

# Generated at 2022-06-23 03:36:54.363089
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:37:03.740592
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit