

# Generated at 2022-06-23 03:27:06.567123
# Unit test for function main
def test_main():
    # Make the mock module and mock run_command,
    # the first argument is for the name of the module,
    # the second is the dictionary for the arguments
    module = AnsibleModule({
        'name': 'python',
        'selection': 'hold'
    })

    dpkg = module.get_bin_path('dpkg')

    # The mock_run_command callable will be used instead of module.run_command
    # The arguments are the same as run_command,
    # the return value is the return code, out, and err
    module.run_command = lambda cmd, check_rc=False, data=None: (0, 'python install', '') if cmd == [dpkg, '--get-selections', 'python'] else (0, '', '')

    # The unit test is run
    main()

    #

# Generated at 2022-06-23 03:27:08.783670
# Unit test for function main
def test_main():
    plt_platform = System.name
    System.name = 'debian'
    res = main()
    System.name = plt_platform

# Generated at 2022-06-23 03:27:13.770409
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main()

# Generated at 2022-06-23 03:27:22.938932
# Unit test for function main
def test_main():
    mod = AnsibleModule({}, supports_check_mode=True)
    assert main({'package': 'linux-modules-4.4.0-21-generic', 'state': 'present'}, mod) == ('linux-modules-4.4.0-21-generic', 'linux-modules-4.4.0-21-generic', 'present', False)
    assert main({'package': 'linux-headers-4.4.0-21-generic', 'state': 'latest'}, mod) == ('linux-headers-4.4.0-21-generic', 'linux-headers-4.4.0-21-generic', 'latest', False)

# Generated at 2022-06-23 03:27:28.127171
# Unit test for function main
def test_main():
    """ test main"""
    # Mock all args:
    # {'check_mode': True, '_ansible_check_mode': True, '_ansible_diff': False, 'diff_mode': False, '_ansible_version': 2.8, '_ansible_no_log': False, '_ansible_module_name': 'dpkg_selections', '_ansible_module_simp_version': '2.2.1', '_ansible_module_parsed': True, '_ansible_module_installed': True, '_ansible_module_args': {'selection': 'hold', 'name': 'python'}, '_ansible_syslog_facility': 'daemon', '_ansible_debug': False, '_ansible_ignore_errors': None, '_ansible_verbosity': 4,

# Generated at 2022-06-23 03:27:38.974087
# Unit test for function main
def test_main():
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO
    f = StringIO()
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )
    module.exit_json = lambda **kwargs: kwargs
    module.log = lambda *a, **kw: f.write(str(a).replace('\\n', '\n'))
    module.run_command = lambda *a, **kw: (0, '', '')
    module.get_bin_path = lambda *a, **kw: 'dpkg'

# Generated at 2022-06-23 03:27:46.946091
# Unit test for function main
def test_main():
    # Set up args
    module_args = dict(
        name='python',
        selection='hold'
    )
    # Set up dummy module
    module = AnsibleModule(
        argument_spec=module_args.copy(),
        supports_check_mode=True,
    )
    # Set up required values
    dpkg = module_args['dpkg']
    name = module_args['name']
    selection = module_args['selection']
    # Set up required values
    # Mock some methods
    module.run_command = lambda p: (0, '%s hold' % module_args['name'], '')
    module.get_bin_path = lambda p: 'dpkg'
    # Run main()
    main()

# Generated at 2022-06-23 03:27:48.988603
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold',
    )
    main(args)

# Generated at 2022-06-23 03:27:52.414228
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os import dpkg_selections
    module = ansible.modules.packaging.os.dpkg_selections

    assert True

# Generated at 2022-06-23 03:28:03.266644
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.check_mode = False
    module.params = {
        'name': 'vim',
        'selection': 'deinstall'
    }
    assert module.run_command([module.get_bin_path('dpkg', True), '--set-selections'], data="%s %s" % ('vim', 'deinstall')) == (0, '', '')
    module.params = {
        'name': 'vim',
        'selection': 'install'
    }

# Generated at 2022-06-23 03:28:10.471829
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:28:21.315504
# Unit test for function main
def test_main():
    with mock.patch.object(AnsibleModule, 'run_command', return_value=(0, 'python install', None)):
        with mock.patch.object(AnsibleModule, 'get_bin_path', return_value='/usr/bin/dpkg'):
            module = AnsibleModule(
                argument_spec=dict(
                    name=dict(required=True),
                    selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
                ),
                supports_check_mode=True,
            )
            main()
            assert module.check_mode is False
            assert module.params['name'] == 'python'
            assert module.params['selection'] == 'hold'

# Generated at 2022-06-23 03:28:24.789958
# Unit test for function main
def test_main():
    name = "python"
    selection = "deinstall"

    assert current == "not present"

    assert changed == True

    assert current != selection

    assert module.check_mode or not changed == False

    assert module.check_mode or not changed == True

# Generated at 2022-06-23 03:28:32.945661
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    ansible_module_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/modules/extras/packaging/os/dpkg_selections.py')
    test_dir = tempfile.mkdtemp()
    dpkg_path = os.path.join(test_dir, 'dpkg')
    tmp_path = os.path.join(test_dir, 'tmp_file')


# Generated at 2022-06-23 03:28:34.146692
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:28:38.127503
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert main()

# Generated at 2022-06-23 03:28:48.981910
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = module.params['name']
    selection = module.params['selection']
    current = selection
    changed = current != selection

    module.exit_json(changed=changed, before=current, after=selection)



# Generated at 2022-06-23 03:28:57.102498
# Unit test for function main
def test_main():
    content = '''
    {
    "params": {
        "name": "python",
        "selection": "hold"
    },
    "supports_check_mode":True,
    }
    '''

    md = AnsibleModule(argument_spec=dict())
    md.params = eval(content)
    md.run_command = run_command
    md.run_command_environ_update = dict()

    # Check when selection is the same as current
    md.run_command_environ_update['stdout'] = 'python hold'
    assert not main()['changed']

    # Check when selection is different from current
    md.run_command_environ_update['stdout'] = 'python install'
    assert main()['changed']


# Generated at 2022-06-23 03:29:08.014500
# Unit test for function main
def test_main():
    import pkg_resources
    import sys
    import types
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Check that argument and environment variable dpkg exist
    dpkg = get_bin_path('dpkg', True)

    # Get the name of the package
    name = module.params['name']

    # Get the state to which we want to change the package
    selection = module.params['selection']

    # Get current settings.
    rc

# Generated at 2022-06-23 03:29:16.635850
# Unit test for function main
def test_main():
    import tempfile
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.collections import Sequence

    from ansible.module_utils import basic

    from ansible.module_utils.basic import AnsibleModule, get_bin_path
    from ansible.module_utils.common.text.converters import to_native


# Generated at 2022-06-23 03:29:25.040193
# Unit test for function main
def test_main():
    # Define AnsibleModule arguments and options
    module_args = {
        "name" : "python",
        "selection" : "hold"
    }
    module_args_with_exit_json = {
        "name" : "python",
        "selection" : "hold"
    }
    module_args_without_exit_json = {
        "name" : "python",
        "selection" : "hold"
    }

    # Create the AnsibleModule object
    ansible_module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # Check mode is enabled, test if AnsibleModule has changed
    if ansible_module.check_mode:
        assert (ansible_module.exit_json(changed=False))

    # Convert dict to json

# Generated at 2022-06-23 03:29:34.746111
# Unit test for function main
def test_main():
    import os

    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.community.platforms.plugins.module_utils._text import to_text

    def test_cases():
        yield ({'selection': 'install', 'check_mode': True, '_ansible_check_mode': True}, {'changed': False, 'after': 'install', 'before': 'install'})

    for args, expected in test_cases():
        module = AnsibleModule(argument_spec={'name': {'type': 'str', 'required': True}, 'selection': {'type': 'str', 'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}}, supports_check_mode=True)
        module.params.update(args)
        module.run_command = run_command

# Generated at 2022-06-23 03:29:35.760375
# Unit test for function main
def test_main():
    result = main()
    assert result is None

# Generated at 2022-06-23 03:29:45.196506
# Unit test for function main
def test_main():
    import sys
    import error
    import syslog
    import logging
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = 'python'
    selection = 'hold'
    dpkg = module.get_bin_path('dpkg', True)

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

# Generated at 2022-06-23 03:29:57.070932
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:30:06.029341
# Unit test for function main
def test_main():

    # Test AnsibleModule class
    simple_obj = {"name": "python", "selection": "hold"};
    simple_cls = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)), supports_check_mode=True);
    simple_cls.params = simple_obj;

    # Check that AnsibleModule.run_command returns a 3-tuple
    simple_cls.run_command = lambda x, **kwargs: (0, "", "");
    assert isinstance(simple_cls.run_command(["dpkg", '--get-selections', simple_cls.params['name']], check_rc=True), tuple)

    # Check that AnsibleModule.run_command returns a

# Generated at 2022-06-23 03:30:15.028559
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:30:22.638916
# Unit test for function main
def test_main():
    data = dict(
        name='python',
        selection='install'
    )
    check_mode = False
    check_rc = True
    path = 'dpkg'
    dpkg = {'rc': 0, 'out': 'python install', 'err': ''}
    dpkg_set = {'rc': 0, 'out': '', 'err': ''}
    import sys
    if sys.version_info[0] < 3:
        from mock import patch
        from __builtin__ import any as string_types
    else:
        from unittest.mock import patch
        string_types = (str, )


# Generated at 2022-06-23 03:30:33.664815
# Unit test for function main
def test_main():
    # Module to mock module.run_command. 
    class ModuleMock():
        def run_command(this, cmd, data, check_rc):
            return [0, "", ""]
        def get_bin_path(this, cmd, required):
            return "dpkg"

    # Module to mock module.params.
    class ParamsMock():
        def __init__(self):
            self.name = "python"
            self.selection = "hold"

    # Mock module object.
    module = ModuleMock()
    module.params = ParamsMock()

    # Check for Successful return for Installation
    module.params.selection = "install"
    module.run_command = lambda cmd, data, check_rc: [0, "python	install", ""]

# Generated at 2022-06-23 03:30:42.990054
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import pytest
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-23 03:30:54.089399
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:30:55.146813
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-23 03:31:00.254132
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = module.run_command = lambda *args, **kwargs: None
    dpkg_selections.main(module=module)

# Generated at 2022-06-23 03:31:00.866068
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:31:09.131912
# Unit test for function main
def test_main():
    # No command line arguments
    args = []
    # Input and output values
    expect_cmd = ['dpkg', '--get-selections', 'python']
    expect_out = ''
    expect_rc = 0
    expect_changed = False
    expect_before = 'not present'
    expect_after = 'hold'

    # Create mock object and execute module
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    import tempfile
    (handle, filename) = tempfile.mkstemp()

# Generated at 2022-06-23 03:31:10.661054
# Unit test for function main
def test_main():
    rc, out, err = main()
    assert rc == 0

# Generated at 2022-06-23 03:31:21.869909
# Unit test for function main
def test_main():
    # Test 1 - simple test
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection
    # Test 1 - simple test
    assert changed == False

# Generated at 2022-06-23 03:31:22.578734
# Unit test for function main
def test_main():
    assert True is not False

# Generated at 2022-06-23 03:31:33.414474
# Unit test for function main

# Generated at 2022-06-23 03:31:45.617658
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'ansible'
    selection = 'deinstall'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:31:54.581487
# Unit test for function main
def test_main():
    args = {}
    args['name'] = 'python'
    args['selection'] = 'install'
    args['_ansible_check_mode'] = True
    module = AnsibleModule(**args)
    dpkg = module.get_bin_path('dpkg', True)

    rc, out, err = module.run_command([dpkg, '--get-selections', args['name']], check_rc=True)

    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != args['selection']

    assert changed == False

# Generated at 2022-06-23 03:31:57.524731
# Unit test for function main
def test_main():
    data = {
        'name': 'python',
        'selection': 'not present'
    }
    run_main(data)

# Generated at 2022-06-23 03:32:02.792797
# Unit test for function main
def test_main():
    # Test with a single package
    module = AnsibleModule(dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ))
    rc = main()
    assert True == rc['changed']
    assert 'not present' == rc['before']
    assert 'install' == rc['after']

# Generated at 2022-06-23 03:32:12.064993
# Unit test for function main
def test_main():

    try:
        import json
    except:
        import simplejson as json

    argv = ['-v', '-vv', '-vvv']
    argv.append('name=foo')
    argv.append('selection=hold')
    argv.append('check_mode=True')
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    def run_command(args, data=None, check_rc=False):
        if check_rc:
            assert args[0] == 'dpkg'

# Generated at 2022-06-23 03:32:16.079693
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ))

    module.exit_json(changed=False, name='test', selection='test')

# Generated at 2022-06-23 03:32:25.647398
# Unit test for function main
def test_main():
    import copy
    import os
    import sys
    import tempfile
    import shutil
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import lib.connection_loader as module_utils
    import test.utils as test_utils
    fixture_path = test_utils.fixture_path()
    test_utils.save_fixtures(fixture_path)
    dpkg = shutil.which("dpkg")
    assert len(dpkg) > 0
    if os.path.isdir("/usr/lib/fakeroot"):
        os.environ.update({"FAKEROOTKEY": "no"})
    fixture_path = test_utils.fixture_path()

# Generated at 2022-06-23 03:32:30.932017
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main()

# Generated at 2022-06-23 03:32:41.501777
# Unit test for function main
def test_main():
    # Test with minimal argument
    test_args = dict(name='python', selection='hold')
    test_result = dict(
        changed=True,
        before='',
        after='hold',
    )
    mock_common = ansible_module_mock.MockAnsibleModule()
    def get_bin_path(name, required):
        return ''
    mock_common.get_bin_path = get_bin_path
    class RunCommand(object):
        def __init__(self):
            self.called = 0
            self.rc = 0
            self.out = 'ok'
            self.err = ''
        def __call__(self, params, data, check_rc=False):
            self.called += 1
            if self.called == 1:
                return self.rc, 'python install', ''

# Generated at 2022-06-23 03:32:50.255904
# Unit test for function main
def test_main():
    # Mock out arguments
    sys_argv = ['/usr/local/lib/python2.7/dist-packages/ansible/module_utils/basic.py',
                '/tmp/ansible_dpkg_selections_payload_4g4QOH/ansible_dpkg_selections_payload.zip',
                '/tmp/ansible_dpkg_selections_payload_4g4QOH/ansible_dpkg_selections_payload.py']

    with patch.object(sys, 'argv', sys_argv):
        # Mock out the module class
        with patch.object(AnsibleModule, '__init__', return_value=None) as AnsibleModule_mock:

            # Instantiate our class and call main
            dpkg_selections_obj = dpkg_selections()
           

# Generated at 2022-06-23 03:32:50.757970
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:32:57.445836
# Unit test for function main
def test_main():
    """
    AnsibleFunctionTestCase for module dpkg_selections
    """

    # Create the ansible module object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Test function main
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.return_value = (0, 'python hold', '')
    main()

# Generated at 2022-06-23 03:32:58.053011
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:33:08.215173
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        return changed



# Generated at 2022-06-23 03:33:10.147342
# Unit test for function main
def test_main():
    assert dpkg_selections(['python', 'hold']) == ['True', 'python', 'hold']

# Generated at 2022-06-23 03:33:19.400052
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:20.536976
# Unit test for function main
def test_main():
    rc = main()
    assert rc == 0

# Generated at 2022-06-23 03:33:33.294897
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:46.633697
# Unit test for function main
def test_main():
    import unittest
    from test_lib import AnsibleModuleTestCase, MockStdout, MockRunCommand

    class DpkgSelectionsTestCase(AnsibleModuleTestCase):
        def setUp(self):
            super(DpkgSelectionsTestCase, self).setUp()
            self.module = self.module_class.from_params(self.params_module,
                                                        argument_spec=self.argument_spec,
                                                        supports_check_mode=True,
                                                        check_invalid_arguments=False,
                                                        bypass_checks=True)
            self.module.run_command = MockRunCommand().run_command
            self.module.get_bin_path = MockRunCommand().get_bin_path

    def test_fail_dpkg(self):
        dpkg_selections = Dpkg

# Generated at 2022-06-23 03:33:57.623531
# Unit test for function main
def test_main():
    import ansible.module_utils.common.file
    import ansible.module_utils.common.command
    import ansible.module_utils.common.process
    import io
    from io import StringIO
    from unittest.mock import MagicMock
    from ansible.module_utils.dpkg_selections import main

    m_run_command = MagicMock( return_value=(0, "dpkg --set-selections data", ""))
    m_exit_json = MagicMock(side_effect=SystemExit)


# Generated at 2022-06-23 03:33:59.628526
# Unit test for function main
def test_main():
  module = AnsibleModule({"name":"python", "selection":"hold"}, check_mode=True)
  assert main() == None

# Generated at 2022-06-23 03:34:09.795612
# Unit test for function main
def test_main():
    # set global variable to local variable
    global module
    # assign 'module' variable to fake ansible module
    module = AnsibleModule(
        argument_spec=dict(
            # set 'name' variable to 'dict' type
            name=dict(required=True),
            # set 'selection' variable to 'dict' type
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # set 'dpkg' variable to the result of calling the fake ansible module 'get_bin_path' variable
    dpkg = module.get_bin_path('dpkg', True)
    # set 'name' variable to the result of calling the fake ansible module 'params' variable with 'name' argument

# Generated at 2022-06-23 03:34:21.529779
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    # Changed should be True because we are not selecting python, but the lowest level.
    assert current != selection

    # Check mode,

# Generated at 2022-06-23 03:34:26.157832
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-23 03:34:33.732995
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"

    module1 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module1.get_bin_path('dpkg', True)


    rc, out, err = module1.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:34:44.704989
# Unit test for function main
def test_main():
    class TestModule(object):
        def __init__(self, params, check_mode=True):
            self.params = params
            self.check_mode = check_mode

        def fail_json(self, *args, **kwargs):
            raise Exception(args, kwargs)

        def exit_json(self, **kwargs):
            self.exit_json_args = kwargs
            raise StopIteration

        def get_bin_path(self, prog, required=False):
            return prog

        def run_command(self, args, check_rc=True, data=None):
            if args[0] == 'dpkg':
                if args[1] == '--get-selections':
                    return (0, self.params['get-selections-out'], '')

# Generated at 2022-06-23 03:34:54.623498
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:35:07.609642
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    #dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    #rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    out = "python purge"
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:35:15.032422
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test_module.run_command = Mock(return_value=(0, "Not Present", "This is an error"))
    test_module.check_mode = False

    main()
    main()

# Generated at 2022-06-23 03:35:21.685067
# Unit test for function main
def test_main():
    # test empty
    args = {}
    res = main(args)
    assert res['changed'] == False, "Empty arguments failed"

    # test without values
    args = dict(
        name=None
    )
    res = main(args)
    assert res['changed'] == True, "Failed with no values"

    # test with values
    args = dict(
        name="test"
    )
    res = main(args)
    assert res['changed'] == True, "Failed with values"

#
# Ansible module unit tests
#
# pylint: disable=W0212,C0103

# Generated at 2022-06-23 03:35:32.366340
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:35:44.109499
# Unit test for function main
def test_main():
    import json
    import unittest
    import sys

    class TestModule(unittest.TestCase):

        def _get_args(self, name, selection):
            args = dict()
            args['name'] = name
            args['selection'] = selection
            return args

        def _get_result(self, check_mode=False):
            result = dict()
            result['changed'] = True
            result['before'] = 'not present'
            result['after'] = 'install'

            if check_mode:
                result['changed'] = False
            return result


# Generated at 2022-06-23 03:35:45.816605
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-23 03:35:56.421144
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    content = "%s %s" % (name, selection)
    filename = "/tmp/ansible_dpkg_selections"
    outfile = open(filename, "w")
    outfile.write(content)
    outfile.close()
    rc, out, err = module.run_command([dpkg, '--set-selections'], data=content, check_rc=True)
    assert rc == 0
    assert out == ''
    assert err == ''
    # test hold case
    selection = 'hold'
    out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    assert out == content
    assert err == ''
    # test purge case
    selection = 'purge'

# Generated at 2022-06-23 03:36:07.069131
# Unit test for function main
def test_main():
    import json

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:36:19.922842
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.helpers import set_module_args
    from ansible.module_utils._text import to_bytes
    from ansible.compat import PY3
    if not PY3:
        import __builtin__
    else:
        import builtins as __builtin__

    # set test args
    args = {
        'name': 'python2.7',
        'selection': 'hold',
    }

    # create the module instance
    module = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    }, supports_check_mode=True)

    # set the args
   

# Generated at 2022-06-23 03:36:31.546108
# Unit test for function main
def test_main():
    import platform
    import sys
    sys.modules["ansible.module_utils.basic"] = __import__("package.for.unit.test.basic")
    sys.modules["ansible.module_utils.action_common_attributes"] = __import__("package.for.unit.test.action_common_attributes")
    sys.modules["ansible.module_utils." + platform.dist()[0].lower() + "_common.distro"] = __import__("package.for.unit.test." + platform.dist()[0].lower() + "_common.distro")

    import ansible.module_utils.basic
    import ansible.module_utils.action_common_attributes
    import ansible.module_utils.debian_common.distro

    main()

# Generated at 2022-06-23 03:36:41.782601
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.shell import Shell
    module = basic.AnsibleModule(argument_spec={'name': {'required': True}, 'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}}, supports_check_mode=True)
    setattr(module, 'get_bin_path', lambda a, b: '/usr/bin/dpkg')
    setattr(module, 'run_command', lambda a: [0, 'python install\n', ''])
    setattr(module, 'params', {'selection': 'hold', 'name': 'python'})
    setattr(module, 'Shell', Shell)

# Generated at 2022-06-23 03:36:48.950485
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.compat.tests import unittest, mock
    import os

    examples = '''
- name: Prevent python from being upgraded
  dpkg_selections:
    name: python
    selection: hold
'''

    original_run_command = basic.AnsibleModule.run_command

    def run_command_mock(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False,path_prefix=None, cwd=None, use_unsafe_shell=True, prompt_regex=None):
        rc = 0
        out = ''
        err = ''

# Generated at 2022-06-23 03:36:50.930212
# Unit test for function main
def test_main():
    print("Starting unit test")
    print("Done with unit test")
    print("Unit test complete")

# Generated at 2022-06-23 03:37:01.323806
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    ansibleModule = basic.AnsibleModule
    # mock arguments
    ansibleModule._ansible_module_base_arguments = {
        'new_arguments': None
    }
    # mock remote server information
    ansibleModule.params = {
        'name': 'python',
        'selection': 'hold'
    }
    ansibleModule.check_mode = False
    ansibleModule.run_command = {
        'return_code': 0,
        'results': "dpkg --get-selections results"
    }
    ansibleModule.get_bin_path = {
        'return_code': 0,
        'results': 'dpkg'
    }
    # run function
    main()

    # assert function