

# Generated at 2022-06-23 03:27:13.002199
# Unit test for function main
def test_main():
    def exit_json(changed=True, **kwargs):
        return (changed, kwargs)

    def run_command(args, data=None, check_rc=True):
        if args[-1] == 'python':
            return 0, 'python\tinstall', ''
        else:
            return 1, '', ''

    def get_bin_path(name, required=False):
        return 'dpkg'


# Generated at 2022-06-23 03:27:22.639415
# Unit test for function main
def test_main():
    import json
    import platform
    import os
    import tempfile

    def _run_module(name):
        module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str'),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str'),
            ),
            supports_check_mode=True
        )
        module.exit_json = lambda **kwargs: sys.exit(json.dumps(kwargs, sort_keys=True, indent=4))
        module.get_bin_path = lambda p, f: os.path.join(os.path.dirname(__file__), 'dpkg')
        module.run_command = lambda *args, **kwargs: (0, '', '')
       

# Generated at 2022-06-23 03:27:31.620339
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.collections import Set
    from ansible.module_utils.common.datetime_custom import (
        datetime_custom_class,
        datetime_ex,
        datetime_to_string,
        string_to_datetime,
    )
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    del module
    del Mapping
   

# Generated at 2022-06-23 03:27:32.700886
# Unit test for function main
def test_main():
    assert main()


# Generated at 2022-06-23 03:27:33.285829
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:27:34.011512
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:27:45.474108
# Unit test for function main
def test_main():
    test_calls = [
        {
            'name': 'python',
            'selection': 'hold',
            'out': 'python hold'
        },
        {
            'name': 'python',
            'selection': 'hold',
            'out': 'python hold'
        }
    ]

    class ModuleArgs(object):
        def __init__(self, args):
            self.argument_spec = {
                'name': {'required': True},
                'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}
            }
            self.check_mode = False
            self.params = args


# Generated at 2022-06-23 03:27:55.639056
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )

    # Set up Mock for functions run_command and exit_json
    # Mocking to allow module.run_command to be overriden.
    from ansible.module_utils.basic import AnsibleModule
    module.run_command = MagicMock(return_value=(0, 'dpkg install', ''))
    module.exit_json = MagicMock()

    # Set params and run main
    module.params = {"name":"name", "selection":"install"}
    main()

# Generated at 2022-06-23 03:27:56.743725
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-23 03:27:57.417476
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:28:06.725544
# Unit test for function main
def test_main():
    # Mock object and function
    class FakeAnsibleModule():
        def __init__(self):
            self.check_mode = False
            self.params = params
            self.run_command = run_command_function

        def exit_json(self, changed, before, after):
            assert changed


    run_command_function = lambda self: (0, None, None)


# Generated at 2022-06-23 03:28:18.887551
# Unit test for function main
def test_main():
    dpkg = '/usr/bin/dpkg'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    import mock
    from ansible.module_utils import basic as module_utils
    m = mock.MagicMock()
    with mock.patch(module_utils.__name__ + '.AnsibleModule') as mod_mock:
        mod_mock.return_value = m
        m.get_bin_path.return_value = dpkg
        m.params = dict(
            name='test',
            selection='hold'
        )
        m.run_command.return_

# Generated at 2022-06-23 03:28:19.648187
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:28:29.591416
# Unit test for function main
def test_main():
    from ansible_collections.misc.not_a_real_collection.plugins.modules.dpkg_selections import main
    old_run_command = main.run_command
    main.run_command = lambda *args, **kwargs: (0, '', '')

    mod = main.AnsibleModule(argument_spec={'name': dict(required=True), 'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)})
    mod.params['name'] = 'python'
    mod.params['selection'] = 'hold'
    mod.run_command = lambda *args, **kwargs: (0, 'python install', '')
    mod.check_mode = False
    main.exit_json = lambda **vals: vals

# Generated at 2022-06-23 03:28:38.823170
# Unit test for function main
def test_main():
    """Test the main function"""
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {
        'name': 'coreutils',
        'selection': 'purge'
    }
    module.get_bin_path = lambda x,y: '/usr/bin/dpkg'
    module.run_command = lambda x: (0, 'coreutils	hold', '')
    main()
    assert module.result['changed'] is False

# Generated at 2022-06-23 03:28:52.740149
# Unit test for function main
def test_main():
    import os.path
    import tempfile

    filename = os.path.join(tempfile.mkdtemp(), 'test_dpkg')

    def get_selections(name):
        rc, out, err = module.run_command([dpkg, '--get-selections', name])
        if not out:
            return 'not present'
        else:
            return out.split()[1]

    # Test the module.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    setattr(module, '_original_check_mode', module.check_mode)

# Generated at 2022-06-23 03:28:54.181972
# Unit test for function main
def test_main():
    if 0:
        print(main())

# Generated at 2022-06-23 03:29:01.196445
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:29:11.329124
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(required=True)
        ),
        supports_check_mode=True,
    )
    assert module.check_mode is True
    module.run_command = MagicMock(return_value=(0, '', ''))
    selection = 'hold'
    selection = 'hold'
    selection = 'hold'
    selection = 'hold'
    selection = 'hold'
    selection = 'hold'
    module.exit_json = MagicMock()
    main()
    module.run_command.assert_called_with([module.get_bin_path('dpkg'), '--get-selections', 'python'], check_rc=True)

# Generated at 2022-06-23 03:29:13.147900
# Unit test for function main
def test_main():
   result = main({'name': 'python', 'selection': 'hold'})
   assert result['changed'] == False

# Generated at 2022-06-23 03:29:21.941188
# Unit test for function main
def test_main():

    import sys
    import os
    import subprocess

    # Assume base dir is .../action_plugins/test/unit/module_utils/recent_pr_comments
    base_dir = os.path.dirname(os.path.realpath(__file__))

    # Add library to import path
    sys.path.insert(0, base_dir + "/../../../../library")

    # Mock the AnsibleModule class so we can return values
    #
    # Example:
    # ansible.module_utils.basic.AnsibleModule = test_ansible_module
    #

    # Import the source being tested
    #
    # Example:
    # from mymodule import MyClass

    # Setup test environment
    #
    # Example:
    # os.environ['TestEnvVar'] = 'Foo'

   

# Generated at 2022-06-23 03:29:33.022333
# Unit test for function main
def test_main():
    out = ''
    err = ''
    rc = 0
    before = 'not present'
    after = 'install'
    check_mode = False
    params = {
        'name': 'python',
        'selection': 'install',
        'check_mode': check_mode,
        'diff': False
    }

    dpkg = '/usr/bin/dpkg'

    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    m.run_command = MagicMock(return_value=(rc, out, err))

# Generated at 2022-06-23 03:29:38.412188
# Unit test for function main
def test_main():
    # Patch the run_command function with a mock
    with mock.patch('ansible.module_utils.basic.AnsibleModule', return_value=AnsibleModule):
        with mock.patch('ansible.module_utils.basic.AnsibleModule.run_command', return_value=['dpkg', '--get-selections', 'name']):
            assert main() == ['name', 'not present']

# Generated at 2022-06-23 03:29:44.560845
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = test_module.get_bin_path('dpkg', True)
    name = os.getenv('NAME')
    selection = os.getenv('SELECTION')
    rc, out = run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection


# Generated at 2022-06-23 03:29:45.074132
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:29:56.932816
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    import mock

    m = mock.mock_open()
    with mock.patch('{0}.open'.format(__name__), m.open, create=True):
        assert os.path.exists(__file__)
        with open(__file__, 'r') as f:
            ansible_module_contents = f.read()

        m.return_value = StringIO(ansible_module_contents)

        # Add this directory to the import path
        sys.path.append(os.path.dirname(__file__))

        # Method being tested
        from dpkg_selections import main
        from ansible.module_utils import basic
        from ansible.module_utils.basic import AnsibleModule as ansible

# Generated at 2022-06-23 03:29:58.819190
# Unit test for function main
def test_main():
    assert main().changed == True
    assert main().before == 'deinstall'
    assert main().after == 'install'

# Generated at 2022-06-23 03:30:08.503015
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:30:11.376212
# Unit test for function main
def test_main():
    assert main() == module.exit_json(changed=False, before="install", after="install")

# Generated at 2022-06-23 03:30:19.781202
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.modules.system.dpkg_selections import main
    from ansible.module_utils.facts import get_facts as facter
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Mock out the facter function
    # module.get_bin_path(name, required=True, opt_dirs=None)
    module.get_bin_path = get_bin_path
    module.get_bin_path.return_value

# Generated at 2022-06-23 03:30:30.806148
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    d = tempfile.mkdtemp()
    shutil.copy('/usr/bin/dpkg', d)
    shutil.copy('/usr/bin/dpkg-query', d)
    shutil.copytree('/usr/lib/dpkg', d+'/usr/lib/dpkg')
    shutil.copytree('/var/lib/dpkg', d+'/var/lib/dpkg')

    params = {'path': d, 'name': 'tcpdump', 'selection': 'install'}

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    params = {'path': d, 'name': 'tcpdump', 'selection': 'install'}
    module_

# Generated at 2022-06-23 03:30:32.804974
# Unit test for function main
def test_main():
    out = main()
    print(out)

# Generated at 2022-06-23 03:30:42.336010
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    import tempfile
    import traceback

    mock_module = pytest.importorskip('ansible.module_utils.basic')
    mock_run_command = pytest.importorskip('ansible.module_utils.basic.AnsibleModule.run_command')
    from ansible.module_utils.basic import AnsibleModule, get_bin_path
    from ansible.module_utils.six import PY2

    TMP_DIR = tempfile.mkdtemp()
    os.makedirs(os.path.join(TMP_DIR, "bin"), exist_ok=True)
    os.makedirs(os.path.join(TMP_DIR, "cache", "apt", "archives"), exist_ok=True)

    #
    # Mock d

# Generated at 2022-06-23 03:30:47.742886
# Unit test for function main
def test_main():
    try:
        test_input = {
            'name': 'python',
            'selection': 'hold'
        }
        main(test_input)
        assert True # assert is called due to no exception thrown
    except SystemExit as inst:
        # assert that the command line arguments passed from mock succeed
        assert inst.args[0] == 0


# Generated at 2022-06-23 03:30:58.318601
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}, 'name': {'required': True}}, supports_check_mode=True)
    rc, out, err = module.run_command('dpkg --get-selections python')
    assert out.split()[1] == 'install'
    assert module.check_mode or not out.split()[1] == 'hold'
    rc, out, err = module.run_command('dpkg --set-selections', data="python hold")
    rc, out, err = module.run_command('dpkg --get-selections python')
    assert out.split()[1] == 'hold'

# Generated at 2022-06-23 03:31:08.670050
# Unit test for function main
def test_main():
    try:
        ansible_module.exit_json
    except NameError:
        import __builtin__
        setattr(__builtin__, 'exit_json', exit_json)

    try:
        ansible_module.fail_json
    except NameError:
        import __builtin__
        setattr(__builtin__, 'fail_json', fail_json)

    key = {'ansible_module': {'check_mode': False, 'name': 'python', 'selection': 'hold'}}
    setattr(__builtin__, 'ansible_module', AnsibleModule(argument_spec={}, supports_check_mode=True))
    setattr(__builtin__, 'exit_json', exit_json)
    setattr(__builtin__, 'fail_json', fail_json)
    main()


# Generated at 2022-06-23 03:31:19.940528
# Unit test for function main
def test_main():
    import shlex
    from ansible.module_utils.basic import AnsibleModule
    name = "python"
    selection = "hold"

    # check_mode
    data = dict(
        name=name,
        selection=selection,
        check_mode=True,
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        # You can override the following
        # module_args = data,
        # For testing, use the following
        # Use the following to fail the test
        # fail_json = True,
    )


# Generated at 2022-06-23 03:31:32.114435
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "check_mode": False,
        "diff_mode": False,
        "platform": "Linux",
        "name": "python",
        "selection": "hold"
    })

    dpkg_selections = {
        "install": True,
        "hold": True,
        "deinstall": True,
        "purge": True
    }


# Generated at 2022-06-23 03:31:44.048916
# Unit test for function main
def test_main():
    # Test args
    test_args = {
        'name': 'python',
        'selection': 'hold'
    }

    # Test exit_json
    test_exit_json = {
        'changed': True,
        'before': 'install',
        'after': 'hold'
    }

    # Test fail_json
    test_fail_json = {
        'failed': True,
        'msg': 'Failed running command'
    }

    # Test import module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Mock check_mode and diff_mode
    module

# Generated at 2022-06-23 03:31:55.724906
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    assert rc == 0
    assert out == ""
    current = "not present"
    assert current == out.split()[1]
    assert current != selection

# Generated at 2022-06-23 03:32:07.023009
# Unit test for function main
def test_main():
    # Test that no change is needed
    module = AnsibleModuleStub({
        'name': 'python',
        'selection': 'hold'
    })
    main()
    assert module.exit_json_called == 1
    assert module.exit_json_args == {'before': 'hold', 'after': 'hold', 'changed': False}
    assert module.run_command_called == 1
    assert module.run_command_args == {'data': 'python hold', 'check_rc': True, 'binary_data': True}

    # Test that change is needed
    module = AnsibleModuleStub({
        'name': 'python',
        'selection': 'deinstall'
    })
    main()
    assert module.exit_json_called == 2

# Generated at 2022-06-23 03:32:17.542322
# Unit test for function main
def test_main():
    # Mock pkg_resources.get_distribution().version
    class Version:
        def __init__(self, version):
            self.version = version

        def __str__(self):
            return self.version

    pkg_resources.get_distribution = MagicMock()
    pkg_resources.get_distribution.return_value.version = Version("X.Y")
    # Set up for test of no change
    module = Mock()
    module.params = {'name':'python', 'selection':'hold'}
    module.check_mode = False
    module.run_command = MagicMock()
    module.run_command.side_effect = [
        (0, 'python hold', ''),
        (0, '', '')
    ]
    main()
    assert module.run_command.call

# Generated at 2022-06-23 03:32:28.787849
# Unit test for function main
def test_main():
    # Mock the module class
    class MockModule(object):
        def __init__(self):
            self.params = {
                'name': 'nvidia-driver',
                'selection': 'install',
                'check_mode': True,
            }

            self.fail_json = lambda msg: None

        def run_command(self, args, check_rc=False):
            if check_rc:
                return (0, 'nvidia-driver deinstall', None)
            else:
                return (0, 'nvidia-driver', None)

        def get_bin_path(self, name, required=False):
            return 'dpkg'

    # Mock the module class's exit_json
    def mock_exit_json(changed=False, before=None, after=None):
        assert changed

# Generated at 2022-06-23 03:32:39.459721
# Unit test for function main
def test_main():
    mockModule = AnsibleModule({
        'name': 'python',
        'selection': 'hold',
        'supports_check_mode': True,
    })

    import platform
    if platform.linux_distribution()[0] != 'Ubuntu':
        mockModule.exit_json = lambda **kargs: None
        mockModule.fail_json = lambda **kargs: None

    module_utils = getattr(mockModule, 'module._utils')
    for key in [ 'common_environment_exist_fail', 'get_bin_path', 'run_command']:
        setattr(module_utils, key, globals()[key])

    mockRunCommand = MockRunCommand()
    mockModule.run_command = mockRunCommand.run_command

    main()


# Generated at 2022-06-23 03:32:49.817749
# Unit test for function main
def test_main():
    from ansible_collections.ansible.debian.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.debian.tests.unit.compat.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
        def run_command(self, *args, **kwargs):
            return (0, 'dpkg -i', '')
        def exit_json(self, *args, **kwargs):
            pass
        def fail_json(self, *args, **kwargs):
            pass
        def get_bin_path(self, *args, **kwargs):
            return ['/usr/bin/dpkg']
   

# Generated at 2022-06-23 03:33:02.580928
# Unit test for function main
def test_main():
    spec = dict(
        name = dict(required = True),
        selection = dict(choices=['install', 'hold', 'deinstall', 'purge'], required = True)
    )
    module = AnsibleModule(argument_spec=spec, supports_check_mode=True)
    module.exit_json = lambda **kwargs: kwargs
    module.get_bin_path = lambda x, y: '/usr/bin/dpkg'
    module.run_command = lambda *args, **kwargs: (0, 'dpkg --get-selections python\r\npython hold\r\n', '')
    module.check_mode = True
    result = main()
    assert result['before'] == 'hold'
    assert result['after'] == 'install'
    assert result['changed'] == True

# Generated at 2022-06-23 03:33:14.688432
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:23.525580
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:33.563979
# Unit test for function main
def test_main():
    import sys, os
    test_dir = os.path.dirname(__file__)
    src_dir = os.path.join(test_dir, os.pardir, os.pardir, 'lib')
    sys.path.insert(0, os.path.abspath(src_dir))
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native
    from subprocess import Popen, PIPE
    from tempfile import NamedTemporaryFile, mkstemp
    from unittest import TestCase, TestLoader, TextTestRunner
    try:
        from unittest.mock import patch, mock_open
    except ImportError:
        from mock import patch, mock_open


# Generated at 2022-06-23 03:33:46.634471
# Unit test for function main
def test_main():
    module = AnsibleModule({'name': 'python', 'selection': 'hold'})
    import os
    import sys
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule


    class Environment():
        def __init__(self):
            self.env = dict(os.environ)

        def __enter__(self):
            os.environ.clear()
            os.environ.update(self.env)

        def __exit__(self, *args):
            os.environ.clear()
            os.environ.update(self.env)

    test_dir = tempfile.mkdtemp()
    with Environment():
        os.environ['_ansible_place_tmp_dir'] = test_dir
        import tempfile

        (fp, path) = temp

# Generated at 2022-06-23 03:33:57.623224
# Unit test for function main
def test_main():
    import ansible.constants as C
    import ansible.utils.template as template

    T = template.Templar(CONFIG)
    module_args = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        support_check_mode=True,
    )
    load_module = load_module()
    check_bin_path = load_module.check_bin_path
    run_command = load_module.run_command
    module_args = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        supports_check_mode=True,
    )
    load_module = load_

# Generated at 2022-06-23 03:33:59.282534
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    main(name, selection)

# Generated at 2022-06-23 03:33:59.930837
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:34:02.290448
# Unit test for function main
def test_main():
    name = 'package-name'
    selection = 'hold'
    rc, out, err = main([name, selection, '--check_mode'])
    print(rc, out, err)

# Generated at 2022-06-23 03:34:08.367542
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold',
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json(**main(module.params, module))

# Test execution
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:34:09.036170
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:34:16.102639
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    name = "test"
    selection = "install"
    module.params['name'] = name
    module.params['selection'] = selection
    print(main())

# Generated at 2022-06-23 03:34:26.194140
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import action_common_attributes

    # Fake the module's basic methods and input parameters
    basic.ANSIBLE_MODULE_ARGS = {'check_mode': True, 'name': 'test_pkg', 'selection': 'deinstall'}
    basic.HAS_ANSICOLOR = False
    basic.HAS_SELINUX = False
    basic.HAS_TERM = False

    # Fake the ansible runner
    m_run_command = basic.AnsibleModule.run_command

    def run_command_faked(self, args, check_rc=True):
        if args[-1] == '--get-selections':
            stdout = "test_pkg\tinstall\n"
        else:
            stdout = ''

# Generated at 2022-06-23 03:34:33.762615
# Unit test for function main
def test_main():
    import tempfile
    from collections import namedtuple

    apt_pkg = namedtuple('Apt_pkg', ['HAVE_PRETTY_PRINT'])

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)
    dpkg2 = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'
    module.params['name'] = name
    module.params['selection'] = selection


# Generated at 2022-06-23 03:34:44.703922
# Unit test for function main
def test_main():
    import os
    import tempfile
    import pytest
    import platform
    from ansible_collections.ansible.misc.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible_collections.ansible.misc.plugins.modules import dpkg_selections

    xunit = pytest.importorskip('xunitparser')

    if platform.system() != 'Linux':
        pytest.skip('Only linux supported')

    os.environ['LANG'] = 'C'
    def setUpModule():
        dpkg_selections.__salt__ = {}
        if not dpkg_selections.__virtual__():
            pytest.skip('Only debian systems supported')


# Generated at 2022-06-23 03:34:51.094553
# Unit test for function main
def test_main():
    # Test that package is absent
    # Test that package is in install
    # Test that package is in hold
    # Test that package is in deinstall
    # Test that package is in purge

    # Test that check module returns a changed
    # Test that package is changed from install to hold

    # Test that package is changed from hold to install

    # Test that package is changed from purge to hold

    # Test that package is changed from hold to purge

    # Test that package is changed from purge to install

    return

# Generated at 2022-06-23 03:34:53.443396
# Unit test for function main
def test_main():
    #Test AnsibleModule.get_bin_path
    assert main()[0] == {'changed': True, 'after': 'hold', 'before': 'install'}

# Generated at 2022-06-23 03:35:00.593310
# Unit test for function main
def test_main():
    inp = {"name": "python",
           "selection": "hold",
          }
    from ansible.compat.tests import unittest

    """
    Test main()
    """
    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""
        pass

    class ModuleMock(object):
        """
        Mock for Ansible module
        """
        def __init__(self, *args, **kwargs):
            self.params = inp
            self.exit_json = self.exit_json
            self.fail_json = self.fail_json


# Generated at 2022-06-23 03:35:10.251280
# Unit test for function main
def test_main():
    module = __import__('ansible.module_utils.basic')
    AnsibleModule = module.AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )

    name = module.params['name']
    selection = module.params['selection']

    module.run_command = test_run_command
    module.get_bin_path = test_get_bin_path

    # Test case 0: Run with no current selection.
    rc, out, err = main()
    assert rc['changed'] is True
    assert rc['before'] == 'not present'
    assert rc['after'] == selection

    # Test case 1: Run

# Generated at 2022-06-23 03:35:11.211591
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 03:35:21.553802
# Unit test for function main
def test_main():
    """Unit testing for the main function.
    """
    global module
    name = "python"
    selection = "deinstall"
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    main()


# Generated at 2022-06-23 03:35:32.286630
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:35:44.065750
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:35:56.048017
# Unit test for function main
def test_main():
    # mock module and exit_json
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    setattr(module, 'exit_json', lambda x: x)

    # create mock module and exit_json
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    setattr(module, 'exit_json', lambda x: x)

    # Mock module and run function main
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    setattr(module, 'exit_json', lambda x: x)
    setattr(module, 'run_command', lambda *args, **kw: (0, '', ''))
    setattr(module, 'get_bin_path', lambda *args, **kw: 'dpkg')

    main()

# Generated at 2022-06-23 03:36:06.734743
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:07.621387
# Unit test for function main
def test_main():
    test = main()

# Generated at 2022-06-23 03:36:16.239227
# Unit test for function main

# Generated at 2022-06-23 03:36:28.348732
# Unit test for function main
def test_main():
    test_vals = [
        # test 0 - one argument
        dict(
            name='python',
            selection='deinstall',
            expected_rc=0,
            expected_stdout='python deinstall',
            expected_stderr='',
            expected_changed=None,
            expected_before=None,
            expected_after=None,
        ),
        # test 1 - two arguments
        dict(
            name='python',
            selection='purge',
            expected_rc=0,
            expected_stdout='python purge',
            expected_stderr='',
            expected_changed=None,
            expected_before=None,
            expected_after=None,
        ),
    ]
    for test_val in test_vals:
        name, selection, expected_rc, expected_stdout, expected_stderr

# Generated at 2022-06-23 03:36:34.511814
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    rv = main()

    assert rv is not None, 'Unable to validate main function'


# Generated at 2022-06-23 03:36:45.526976
# Unit test for function main
def test_main():
    import json
    from collections import namedtuple

    from ansible.module_utils.basic import AnsibleModule

    MockedModule = namedtuple('MockedModule', [
        'params', 'run_command', 'get_bin_path'
    ])
    MockedModule.run_command.return_value = (0, 'python install', '')
    MockedModule.check_mode = False

    result = main(MockedModule(
        params={'name': 'python', 'selection': 'purge'},
        run_command=MockedModule.run_command,
        get_bin_path=MockedModule.get_bin_path
    ))

    assert result['changed']

# Generated at 2022-06-23 03:36:58.387472
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit