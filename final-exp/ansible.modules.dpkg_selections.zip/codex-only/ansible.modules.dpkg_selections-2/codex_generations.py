

# Generated at 2022-06-23 03:27:07.303530
# Unit test for function main
def test_main():

    # Test 1
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = "python"
    selection = "hold"

    module.run_command = MagicMock(return_value=(0, "python hold\n", ""))

    main()
    assert module.exit_json.call_args[0][0]['changed'] == False
    assert module.exit_json.call_args[0][0]['before'] == "hold"
    assert module.exit_json.call_args[0][0]['after'] == "hold"

    # Test 2
    module = Ansible

# Generated at 2022-06-23 03:27:18.757470
# Unit test for function main
def test_main():
    test_open_mock = mock.mock_open()
    test_get_bin_path_mock = mock.Mock(return_value='/bin/dpkg')
    test_run_command_success_mock = mock.Mock(return_value=(0, '', ''))
    test_run_command_fail_mock = mock.Mock(return_value=(1, '', ''))
    test_run_command_fail_mock_no_out = mock.Mock(return_value=(0, '', ''))
    test_run_command_fail_mock_out = mock.Mock(return_value=(0, 'name selection', ''))

# Generated at 2022-06-23 03:27:19.390308
# Unit test for function main
def test_main():
    print("test")

# Generated at 2022-06-23 03:27:22.650219
# Unit test for function main
def test_main():
    command = "echo -e 'python hold\npython2.7 install'"
    rc, out, err = module.run_command(command, check_rc=True)
    assert out == 'python hold\npython2.7 install'
    assert err == ''

# Generated at 2022-06-23 03:27:30.720558
# Unit test for function main
def test_main():
    # Assume
    import sys
    import mock
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "name"
    selection = "selection"

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-23 03:27:43.395897
# Unit test for function main
def test_main():
    import os
    import re
    import tempfile
    import shutil
    import unittest
    
    test_content = [
        '#!/bin/bash',
        'echo "ansible: ansible"',
        'exit 0'
    ]
    test_content2 = [
        '#!/bin/bash',
        'echo "ansible: ansible"',
        'exit 1'
    ]
    
    class TestReturnValue(unittest.TestCase):
        def setUp(self):
            self.tmpfile = tempfile.NamedTemporaryFile(delete=False)
            self.tmpfile.write("\n".join(test_content))
            self.tmpfile.close()
            self.tmpfile2 = tempfile.NamedTemporaryFile(delete=False)
            self.tmpfile2

# Generated at 2022-06-23 03:27:50.505231
# Unit test for function main
def test_main():
    argument_spec = dict(
         name=dict(required=True),
         selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )
    module_args = dict(
        dpkg="/usr/bin/dpkg",
        name="python",
        selection="hold"
    )
    out = dict(
        changed=False,
        before="deinstall",
        after="hold"
    )

# Generated at 2022-06-23 03:28:01.281215
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = test_module.params['name']
    selection = test_module.params['selection']

    # Test for successful run of main
    def run_main():
        # Set up the test
        test_module.run_command = MagicMock(return_value=(0, '', ''))
        test_module.exit_json = MagicMock()
        test_module.check_mode = False

        # Run main()
        main()

        # Check that the function parameters were correct
        test_module.run_command.assert_

# Generated at 2022-06-23 03:28:09.126814
# Unit test for function main
def test_main():
    '''
    Test module
    '''
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import sys

    if not sys.version_info[0] == 3:
        reload(sys)
        sys.setdefaultencoding('utf8')

    module = basic._AnsibleModuleStub(dict(
        name='python',
        selection='hold'
    ))

    # Check -m apt
    rc, out, err = module.run_command('%s -m apt' % (sys.executable), check_rc=True)
    if 'ansible.builtin.apt' not in out:
        print("Error: %s_selections requires Ansible 2.1+" % (module.params['action']))
        sys.exit(1)

    #

# Generated at 2022-06-23 03:28:22.358027
# Unit test for function main
def test_main():
    # examples
    # example 1
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:28:26.153128
# Unit test for function main
def test_main():
    args = dict(
        name="python",
        selection="hold"
    )
    module = AnsibleModule(argument_spec=args)
    module.exit_json = lambda x: x
    assert(module.main()["changed"])

# Generated at 2022-06-23 03:28:34.215276
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule.run_command') as mock_AnsibleModule_run_command, \
         patch('ansible.module_utils.basic.AnsibleModule.get_bin_path') as mock_AnsibleModule_get_bin_path, \
         patch('ansible.module_utils.basic.AnsibleModule.exit_json') as mock_AnsibleModule_exit_json, \
         patch('ansible.module_utils.basic.AnsibleModule.fail_json') as mock_AnsibleModule_fail_json:
        mock_AnsibleModule_get_bin_path.return_value = "/usr/bin/dpkg"
        mock_AnsibleModule_run_command.return_value = (0, "testpackage\n", "")



# Generated at 2022-06-23 03:28:43.709318
# Unit test for function main
def test_main():
  import json
  from ansible.module_utils import basic
  from ansible.module_utils.common.collections import ImmutableDict

  mod = basic._ANSIBLE_ARGS
  ansible_args = json.dumps({'ANSIBLE_MODULE_ARGS': mod})
  def test_run_command(self, args, check_rc=False, close_fds=True, executable=None,
                       data=None, binary_data=False, path_prefix=None, cwd=None,
                       use_unsafe_shell=False):
    with open('controller/test/dpkg.out', 'r') as f:
      data = f.read()
    with open('controller/test/dpkg.err', 'r') as f:
      err = f.read()
    return 0, data, err

  basic

# Generated at 2022-06-23 03:28:53.955963
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:28:55.375244
# Unit test for function main
def test_main():
    assert set(main('name')) == set(['install', 'hold', 'deinstall', 'purge'])

# Generated at 2022-06-23 03:29:05.285111
# Unit test for function main
def test_main():
    # Overwrite `run_command`
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda args, check_rc=True, data=None: (0, 'ok', '')

    name = 'apt'
    selection = 'hold'

    assert not main()['changed']
    assert main()['before'] == 'not present'
    assert main()['after'] == 'hold'

# Generated at 2022-06-23 03:29:14.468730
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import Mapping

    # Test to make sure module is successfully loaded
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert module.params is not None
    assert isinstance(module.params, Mapping)

    # Unit test to make sure module behaves correctly
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True)
        ),
        supports_check_mode=True,
    )
    assert module.params is not None
    assert isinstance(module.params, Mapping)
#

# Generated at 2022-06-23 03:29:25.835185
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'name': dict(required=True, type='str'),
        'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str'),
    }, supports_check_mode=True)

    # Get current settings.
    rc, out, err = module.run_command(['dpkg', '--get-selections', module.params['name']], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != module.params['selection']

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=module.params['selection'])

    module.run_

# Generated at 2022-06-23 03:29:29.519906
# Unit test for function main
def test_main():
    doc = eval(DOCUMENTATION)
    vars = {}
    for a in doc['options']:
        vars[a['name']] = (a['required'], a['type'])
    module = AnsibleModule(argument_spec=vars)

# Generated at 2022-06-23 03:29:41.506221
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert changed == False


# Generated at 2022-06-23 03:29:50.967438
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)), supports_check_mode=True)
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection
    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

# Generated at 2022-06-23 03:29:59.800114
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command') as mock_run:
        mock_run.return_value = ['0', 'python install', '', '']
        with patch.object(AnsibleModule, 'exit_json') as mock_exit:
            main()
            assert mock_exit.called
            args, kwargs = mock_exit.call_args
            assert args == ()
            assert kwargs['changed']
            assert kwargs['before'] == 'install'
            assert kwargs['after'] == 'hold'

# Generated at 2022-06-23 03:30:08.333152
# Unit test for function main
def test_main():
    import os
    import json
    import pytest
    import testinfra.utils.ansible_runner

    current_dir = os.path.dirname(__file__)
    testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
        os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')

    with open(os.path.join(current_dir, '../../defaults/main.json')) as f:
        host_vars = json.load(f)

    def test_for_any_problems(host):
        host.run('dpkg --set-selections', data="package1 install && package2 hold")

        cmd = host.run('dpkg --get-selections')

# Generated at 2022-06-23 03:30:15.530980
# Unit test for function main
def test_main():
    # Test basic execution
    name = "test-package"
    selection = "purge"

    module_args = dict(
        name=name,
        selection=selection
    )

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main_function = main()

# Generated at 2022-06-23 03:30:26.612388
# Unit test for function main
def test_main():
    # 1. Test the function module.run_command
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = run_command
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]



# Generated at 2022-06-23 03:30:27.753424
# Unit test for function main
def test_main():
    raise Exception("No tests for this module")

# Generated at 2022-06-23 03:30:35.035205
# Unit test for function main
def test_main():
    argument_spec = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )
    test = AnsibleModule(argument_spec=argument_spec,
                         supports_check_mode=True)
    test.exit_json = lambda **kwargs: None
    test.run_command = lambda command, **kwargs: (0, '', '')

    test.params = {"name": "python", "selection": "hold"}

    main()

    test.params = {"name": "python", "selection": "install"}

    main()

# Generated at 2022-06-23 03:30:41.256496
# Unit test for function main
def test_main():
    # Create the module object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Create an instance of DummyModule() and run main()
    module = DummyModule(module)
    res = main()

    # Validate that main() returns the expected dictionary
    assert res['changed'] == False
    assert res['after'] == 'hold'

# Generated at 2022-06-23 03:30:53.928163
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = test_module.params['name']
    selection = test_module.params['selection']

    out = '%s\thold\n' % name
    test_module.run_command = MagicMock(return_value=(0, out, ''))
    test_module.run_command.assert_called_once_with(['/usr/bin/dpkg', '--get-selections', name], True)

    out = '%s\t%s' % (name, selection)
    unit_test.run_command

# Generated at 2022-06-23 03:31:05.532088
# Unit test for function main
def test_main():
    result = main('install', 'python')
    assert result == True

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    module.run_command

# Generated at 2022-06-23 03:31:09.620404
# Unit test for function main
def test_main():
    result = main()
    #assert result == "expected result"

# Test module with: ansible-playbook --connection=local -vvvv -i "localhost," tests/test_dpkg_selections.yml

# Generated at 2022-06-23 03:31:20.833644
# Unit test for function main
def test_main():
    # Define the mock module to be used within this unit test
    module_mock = mock.MagicMock()
    # A mock to simulate the return of the module run_command

# Generated at 2022-06-23 03:31:28.887075
# Unit test for function main
def test_main():
    # Unit test for function main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import common_koji
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert common_koji.main(module)

# Generated at 2022-06-23 03:31:40.356376
# Unit test for function main
def test_main():
    import sys
    import argparse
    class ArgParseMock(argparse.ArgumentParser):
        def __init__(self, test, *args, **kwargs):
            self.test = test
            self.result = None
            self.values = None
            self.params = kwargs
            self.values = None
            self.type = None
            super(ArgParseMock, self).__init__(*args, **kwargs)
        def parse_args(self):
            self.test.assertIn('description', self.params)
            self.test.assertEqual(self.params['description'], 'Dpkg package selection selections')
            return argparse.Namespace(selection='hold', name='python')
    sys.modules['argparse'] = argparse

# Generated at 2022-06-23 03:31:53.105723
# Unit test for function main
def test_main():
    # Test each option
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    # Test install
    module.params['selection'] = 'install'
    module._ansible_no_log = True
    rc, out, err = module.run_command([dpkg, '--set-selections'], data="python install", check_rc=True)
    assert rc == 0
    assert out == ''
    assert err == ''

# Generated at 2022-06-23 03:32:05.698028
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.dpkg_selections import main
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.file import file_exists
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.packaging.os.dpkg_selections import EXAMPLES

    python_bin = get_bin_path('python')

    if not python_bin:
        print("Skipping dpkg_selections unit tests: python not installed")
        return

    if not file_exists(python_bin):
        print("Skipping dpkg_selections unit tests: python not installed")
        return


# Generated at 2022-06-23 03:32:09.314295
# Unit test for function main
def test_main():
    # Unit tests do not work very well here, as we have to test shell arguments
    # that's passed to run_command.
    assert False

# Generated at 2022-06-23 03:32:18.970019
# Unit test for function main
def test_main():

    # Module parameters
    name = 'python'
    selection = 'hold'
    dpkg = '/usr/bin/dpkg'

    # Ansible parameters
    argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )

    # read module arguments
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )

    # set module args
    module.params['name'] = name
    module.params['selection'] = selection
    module.params['bin_path'] = {'dpkg': dpkg}

    # get current settings

# Generated at 2022-06-23 03:32:23.606751
# Unit test for function main
def test_main():
    # See https://github.com/ansible/ansible/blob/devel/test/unit/modules/system/package/apt.py for an example.
    pass

# Generated at 2022-06-23 03:32:27.424389
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
    ))
    module.run_command = lambda *args, **kwargs: (0, None, None)
    assert main() is None

# Generated at 2022-06-23 03:32:38.406189
# Unit test for function main
def test_main():
    # make sure it fails when no name is specified
    with pytest.raises(SystemExit):
        main()

    # make sure it fails when no selection is specified
    with pytest.raises(SystemExit):
        main(name='python')

    # make sure it fails with wrong selection
    with pytest.raises(SystemExit):
        main(name='python', selection='something-wrong')

    # make sure it fails when the wrong selection is returned
    with pytest.raises(SystemExit):
        main(name='python', selection='deinstall')

    # make sure it fails when changing to the same selection
    with pytest.raises(SystemExit):
        main(name='python', selection='install')

    # make sure it fails when changing to the same selection

# Generated at 2022-06-23 03:32:49.081078
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    m = basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = get_bin_path('dpkg', True)

    name = 'foo'
    selection = 'hold'

    rc, out, err = m.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-23 03:32:58.997837
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(name='apt', argument_spec={})

    m_run_command = basic.AnsibleModule.run_command
    m_exit_json = basic.AnsibleModule.exit_json
    m_fail_json = basic.AnsibleModule.fail_json


# Generated at 2022-06-23 03:32:59.474123
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:33:06.696152
# Unit test for function main
def test_main():
    # basic
    params = {
        "name": "python",
        "selection": "install"
    }
    assert main() == params

    # basic
    params = {
        "name": "python",
        "selection": "deinstall"
    }
    assert main() == params

    # basic
    params = {
        "name": "python",
        "selection": "hold"
    }
    assert main() == params

    # basic
    params = {
        "name": "python",
        "selection": "purge"
    }
    assert main() == params

# Generated at 2022-06-23 03:33:07.321181
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:33:18.393169
# Unit test for function main
def test_main():
    import sys
    import os
    import json

    # Save the original sys.argv
    orig_sys_argv = sys.argv

    # Generate a fake AnsibleModule object
    class AnsibleModuleFake(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.params = {}

        def check_mode(self):
            return True

        def get_bin_path(self, binary, required):
            return '/fake/bin/path/for/' + binary

        def fail_json(self, **kwargs):
            print(kwargs)
            sys.exit(1)

        def exit_json(self, **kwargs):
            print(kwargs)
            sys.exit(0)


# Generated at 2022-06-23 03:33:29.258568
# Unit test for function main
def test_main():
    """
    Test dpkg module
    """
    module_args = dict(name="python", selection="hold")
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != 'hold'


# Generated at 2022-06-23 03:33:34.483266
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0
    except Exception as e:
        print("main() exception: %s" % e)
        raise

# Run tests on command line only
if __name__ == '__main__':
    print("Running test cases:")
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 03:33:38.843739
# Unit test for function main
def test_main():
    assert main("xvfb", "hold")
    assert main("xvfb", "install")
    assert main("xvfb", "deinstall")
    assert main("xvfb", "purge")

# Generated at 2022-06-23 03:33:39.890008
# Unit test for function main
def test_main():
    # basic run
    main()

# Generated at 2022-06-23 03:33:41.493164
# Unit test for function main
def test_main():
    import os
    os.system("cd test;python test_apt_key.py;")

# Generated at 2022-06-23 03:33:48.254258
# Unit test for function main
def test_main(): 
    name = 'test-pkg'
    selection = 'install'
    dpkg = '/bin/dpkg'
    rc = 0

    # Test without check_mode
    assert dpkg_selections.main(name=name, selection=selection, check_mode=False, rc=rc, dpkg=dpkg) == (True, 'deinstall', 'install')

    # Test with check_mode
    assert dpkg_selections.main(name=name, selection=selection, check_mode=True, rc=rc, dpkg=dpkg) == (True, 'deinstall', 'install')



# Generated at 2022-06-23 03:33:59.025291
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:34:09.266142
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:34:11.292540
# Unit test for function main
def test_main():
    dir(main)

# vim: set et sts=4 sw=4 ts=4 :

# Generated at 2022-06-23 03:34:23.084771
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert changed == False
    assert current != selection

# Generated at 2022-06-23 03:34:28.987169
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = exit_json
    module.run_command = run_command
    module.run_command.return_value = (0, None, None)
    main()

    module.params['check_mode'] = True
    main()



# Generated at 2022-06-23 03:34:36.760296
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.dpkg_selections import main
    from ansible.module_utils.common.process import get_bin_path

    dpkg = get_bin_path('dpkg', True)

    class MockModule:
        params = dict(
            name='python',
            selection='hold',
        )

        def get_bin_path(self, module, required=False):
            return dpkg

        def run_command(self, args, check_rc=True, data=None):
            if args[0] == dpkg and args[1] == '--get-selections' and args[2] == 'python':
                return 0, 'python install', ''
            elif args[0] == dpkg and args[1] == '--set-selections':
                assert data == 'python hold'

# Generated at 2022-06-23 03:34:39.495730
# Unit test for function main
def test_main():
    args = {
        'name': 'python',
        'selection': 'hold'
    }
    main(args)


# Generated at 2022-06-23 03:34:41.842553
# Unit test for function main
def test_main():
    # Get test data from doc section above
    test_data = get_test_data()

    # Execute main
    main(test_data)

# Generated at 2022-06-23 03:34:52.674958
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    set_module_args(dict(
        name='not_python',
        selection='deinstall'
    ))

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed

# Generated at 2022-06-23 03:34:54.338844
# Unit test for function main
def test_main():
    unit = __import__('dpkg_selections')
    unit.main()



# Generated at 2022-06-23 03:35:07.368435
# Unit test for function main
def test_main():
    global __options__
    __options__ = {'check_mode': False, 'diff_mode': False}

    def mock_get_bin_path(name, required=False):
        if name == 'dpkg':
            return '/usr/bin/dpkg'
        else:
            return None

    def mock_run_command(cmd, data=None, check_rc=False):
        if cmd == ['/usr/bin/dpkg', '--get-selections', 'python']:
            return 1, 'python install\n', ''
        elif cmd == ['/usr/bin/dpkg', '--set-selections']:
            return 0, '', ''

    def mock_exit_json(changed=False, before=None, after=None):
        return True


# Generated at 2022-06-23 03:35:09.594037
# Unit test for function main
def test_main():
    m = main()
    assert(m.run_command.call_count == 3)

# Generated at 2022-06-23 03:35:11.130401
# Unit test for function main
def test_main():
    main()
    main(selection="hold")

# Generated at 2022-06-23 03:35:21.194408
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:35:29.934163
# Unit test for function main
def test_main():
    name = 'ansible'
    selection = 'install'
    out = "ansible	hold"

    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    def run_command_mock(cmd, **kwargs):
        return (0, out, '')

    test_module.run_command = run_command_mock
    assert(main() == None)

# Generated at 2022-06-23 03:35:42.105327
# Unit test for function main
def test_main():
    import pytest

    # Currently, this test needs to be run manually
    # until we have a mechanism to run apt-get commands
    # without actually installing packages.
    # "--skip-tags package-install" would still leave one
    # test remaining, so we skip it for now.
    pytest.skip("Test needs manual investigation")

    def run(module, params, pkgs):
        module.check_mode = False
        return module.run_command("check", params, pkgs)

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    # Test 1 - Ensure the package is not already installed.
    rc, out, err

# Generated at 2022-06-23 03:35:50.573686
# Unit test for function main
def test_main():
    # get references of AnsibleModule and AnsibleModule
    AnsibleModuleRef = __import__('ansible.module_utils.basic', fromlist=['AnsibleModule'])
    AnsibleExitJsonRef = __import__('ansible.module_utils.basic', fromlist=['AnsibleExitJson'])

    # Mock AnsibleModule
    AnsibleModuleRef.AnsibleModule = mock.MagicMock()
    # Create the mock object and assign it to the module reference
    mo = mock.MagicMock()
    AnsibleModuleRef.AnsibleModule = mo

    # Mock AnsibleExitJson
    AnsibleExitJsonRef.AnsibleExitJson = mock.MagicMock()
    # Create the mock object and assign it to the module reference
    mo = mock.MagicMock()
    AnsibleExitJ

# Generated at 2022-06-23 03:36:02.381543
# Unit test for function main
def test_main():
    from ansible.module_utils.dpkg_selections import main
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
   

# Generated at 2022-06-23 03:36:15.062147
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:25.372609
# Unit test for function main
def test_main():
    # Check current is 'hold'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "python"
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    assert current == 'hold'



# Generated at 2022-06-23 03:36:26.585995
# Unit test for function main
def test_main():
    print("running test_main")


# Generated at 2022-06-23 03:36:37.861725
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    current = 'not present'

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    module.exit_json

# Generated at 2022-06-23 03:36:47.638764
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:48.626632
# Unit test for function main
def test_main():
    assert main() != 0

# Generated at 2022-06-23 03:36:59.529709
# Unit test for function main
def test_main():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.actions import ModuleRunner

    from test.unit.compat.mock import MagicMock, patch, call, Mock

    from ansible.module_utils.shell import DpkgCLI
    from ansible.module_utils.shell.selection import DpkgSelection

    args = {
        'name': 'python',
        'selection': 'hold'
    }

    runner = MagicMock()
    runner.get_module_path.return_value = '/usr/bin/dpkg'
    runner.module = AnsibleModule

    facts = Facts(dict(), runner)

    main = DpkgSelection(runner)
    module = main.setup(facts)
    main.prepare_module