

# Generated at 2022-06-23 03:27:02.828981
# Unit test for function main
def test_main():
    # Test no change required
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:27:10.750653
# Unit test for function main
def test_main():
    """
    Test function main
    """
    from ansible.modules.packaging.os.dpkg_selections import *
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

# Generated at 2022-06-23 03:27:11.509476
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:27:12.813560
# Unit test for function main
def test_main():
    rc, out, err = main()
    assert rc == 0

# Generated at 2022-06-23 03:27:22.638877
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:27:32.877636
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.debian_dpkg import Dpkg
    from ansible.module_utils._text import to_bytes

    Dpkg.SECTIONS = {
        to_bytes('Status', encoding='utf-8'): 'python unhold',
    }

    module_args = {
        'name': 'python',
        'selection': 'unhold',
    }


# Generated at 2022-06-23 03:27:33.512229
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:27:43.137213
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = dict(
        name='python',
        selection='hold'
    )

    rc, out, err = module.run_command([dpkg, '--get-selections', name])

    assert rc == 0, 'dpkg command error'
    assert out.split()[1] == 'hold', 'package selection failure'

# Generated at 2022-06-23 03:27:54.573961
# Unit test for function main
def test_main():
    test_run_command = False
    test_run_command_data = ""

    def test_run_command(args, check_rc=False, **kwargs):
        global test_run_command
        global test_run_command_data
        test_run_command = True
        if args[2] == "--set-selections":
            test_run_command_data = kwargs['data']

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main_backup = __main__.main
    run_command_backup = __main__.run_command

    __

# Generated at 2022-06-23 03:28:05.026567
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)


    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        assert changed

# Generated at 2022-06-23 03:28:11.674217
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    test.mock_module_finder('module_utils.basic', '/tmp/ansible/module_utils/basic.py')
    test.mock_module_finder('packaging.version', '/tmp/ansible/packaging/version.py')
    test.mock_module_finder('packaging.specifiers', '/tmp/ansible/packaging/specifiers.py')
    test.mock_module_finder('packaging.requirements', '/tmp/ansible/packaging/requirements.py')
    test.mock_module

# Generated at 2022-06-23 03:28:12.773084
# Unit test for function main
def test_main():
    assert main()['platforms'] == ['debian']

# Generated at 2022-06-23 03:28:16.752923
# Unit test for function main
def test_main():

    test_main_args = {
        'name': 'python',
        'selection': 'hold'
    }

    test_main_result = {
        'changed':True,
        'before':'deinstall',
        'after':'hold'
    }

    assert test_main_result == main(test_main_args)

# Generated at 2022-06-23 03:28:17.412421
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:28:24.208614
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = "test"
    selection = "install"

    assert name == "test"
    assert selection == "install"

# Generated at 2022-06-23 03:28:28.036818
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-23 03:28:37.879494
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import exit_json
    from ansible.module_utils.basic import fail_json
    import sys
    import tempfile

    # Make sure we create temporary directory to copy 'test_main.py' file for test.
    tmpdir = tempfile.mkdtemp()
    test_file = "%s/test_main.py" %tmpdir
    shutil.copy(os.path.realpath(__file__), test_file)

if __name__ == '__main__':
    sys.argv.pop(0)
    sys.argv.append("-m")
    sys.argv.append(test_file)
    sys.exit(main())

# Generated at 2022-06-23 03:28:41.742858
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 03:28:52.868620
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:29:03.322096
# Unit test for function main
def test_main():
    import os
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.basic import AnsibleModule

    test_args = dict(
        dpkg='/usr/bin/dpkg',
        name='python',
        selection='hold',
    )

    test_module = type('module', (object,), dict(
        AnsibleModule=AnsibleModule,
        __ansible_arguments__={
            'module_name': 'dpkg_selections',
            'module_args': test_args
        },
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    ))()

    test_module

# Generated at 2022-06-23 03:29:07.950338
# Unit test for function main
def test_main():
    argv = [None, '--name', 'test', '--selection', 'hold']
    result = AnsibleModule(name='test_main', argument_spec={'name': {'required': True}, 'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}})
    assert result

# Generated at 2022-06-23 03:29:08.485077
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-23 03:29:18.635604
# Unit test for function main
def test_main():

    # Test function main with a known good argument
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:29:25.678750
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = "test"
    selection = "something"
    dpkg = "something"
    assert dpkg == module.get_bin_path('dpkg', True)
    assert name == module.params['name']
    assert selection == module.params['selection']
    assert main() == None

# Generated at 2022-06-23 03:29:26.265023
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:29:26.824056
# Unit test for function main
def test_main(): 
    print("Hi")

# Generated at 2022-06-23 03:29:36.284759
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import actions
    import os
    import tempfile

    dpkg = os.path.join(tempfile.gettempdir(), "dpkg")
    os.mkdir(dpkg)
    os.mkdir(os.path.join(dpkg, "DEBIAN"))
    f = open(os.path.join(dpkg, "DEBIAN", "control"), "w")
    f.write("""\
Package: test-dpkg
Version: 0.1
Architecture: all
Maintainer: Test Person <test@example.com>
Description: test dpkg module
""")
    f.close()


# Generated at 2022-06-23 03:29:38.142351
# Unit test for function main
def test_main():
    from ansible.module_utils.common.removed import removed_module
    assert removed_module('dpkg_selections')

# Generated at 2022-06-23 03:29:39.526367
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 03:29:40.125323
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:29:40.751632
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:29:49.923702
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'install'
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Current settings for python package
    rc, out, err = test_module.run_command([test_module.get_bin_path('dpkg', True), '--get-selections', name], check_rc=True)
    if not out:
        test_module.current = 'not present'
    else:
        test_module.current = out.split()[1]
    test_module.name = name
    test_module.selection = selection
    test_module

# Generated at 2022-06-23 03:29:59.591499
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = 'python'
    selection = 'hold'

    before = str('install')
    after = str('hold')

    changed = (before==after)

    assert dpkg == '/usr/bin/dpkg', 'Not correct'
    assert changed == True, 'Not correct'
    assert after == selection, 'Not correct'

# Generated at 2022-06-23 03:30:07.819199
# Unit test for function main
def test_main():
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    module.exit_json(changed=changed, before=current, after=selection)



# Generated at 2022-06-23 03:30:08.301489
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:30:14.240722
# Unit test for function main
def test_main():
    module = AnsibleModule(dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
        supports_check_mode=True,
    )

    module.exit_json(msg="Unit test for dpkg_selections")


# Generated at 2022-06-23 03:30:26.525648
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-23 03:30:35.536396
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:30:43.462503
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic
    from ansible.module_utils._text import to_bytes

    mod = basic.AnsibleModule({
        'name': 'python',
        'selection': 'hold'
    })

    def mock_run_command(*args, **kwargs):
        class MockResult(object):
            def __init__(self, stdout, stderr, rc):
                self.stdout = stdout
                self.stderr = stderr
                self.rc = rc
        if args[0] == ['/usr/bin/dpkg', '--get-selections', 'python']:
            if b'python' in to_bytes(args[0][-1]):
                return MockResult('python install\n', '', 0)

# Generated at 2022-06-23 03:30:54.545352
# Unit test for function main
def test_main():
    from types import ModuleType
    import ansible.module_utils.basic

    module = ModuleType('This is a mock module')

    dpkg = '/usr/bin/dpkg'

    name = 'python'
    selection = 'hold'
    out = 'python    hold'
    err = ''
    rc = 0

    def get_bin_path(arg1, arg2):
        return dpkg

    def run_command(args, check_rc=False):
        return rc, out, err

    module.get_bin_path = get_bin_path
    module.run_command = run_command
    module.exit_json = lambda x: x

    module.params = {'name': name, 'selection': selection}

    result = main()

    assert result['changed'] is True



# Generated at 2022-06-23 03:31:01.814518
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert module.check_mode == True
    assert module.params['name'] == 'test'
    assert module.params['selection'] == 'install'

# Generated at 2022-06-23 03:31:09.691389
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:31:10.333824
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:31:16.311223
# Unit test for function main
def test_main():
    argument_spec = {
        'name': {'required': True},
        'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}
    }
    assert dpkg_selections.main.__name__ == 'main'
    assert dpkg_selections.main.__doc__ == None
    assert dpkg_selections.main.__annotations__ == {}

# Generated at 2022-06-23 03:31:16.952105
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 03:31:23.775545
# Unit test for function main
def test_main():
    from ansible.modules.packaging.language.dpkg import main

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-23 03:31:28.226855
# Unit test for function main
def test_main():
    # Testing sample inputs and expected outputs.

    main(dict(name='python', selection='hold'))
    main(dict(name='hello', selection='deinstall'))
    main(dict(name='world', selection='install'))

# Generated at 2022-06-23 03:31:40.174782
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:31:52.943673
# Unit test for function main
def test_main():
    import tempfile

    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    with tempfile.NamedTemporaryFile() as temp_file:
        # Success - package not present
        test_module.params['name'] = 'package_name'
        test_module.params['selection'] = 'hold'
        main(test_module)
        assert test_module.exit_json_called

        # Success - package already hold
        test_module.params['selection'] = 'hold'
        main(test_module)
        assert test_module.exit_json_called

        # Success - package

# Generated at 2022-06-23 03:32:05.602852
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
    name=dict(required=True),
    selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ), supports_check_mode=True,)

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-23 03:32:06.258780
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:32:16.079047
# Unit test for function main
def test_main():
    # Test to check validity of function main
    f = _load_fixture('test_main.txt')
    m = _load_fixture('test_main_m.txt')
    # m_result = _load_fixture('test_main_result.txt')
    with patch.object(builtins, 'open', mock_open(read_data=f)) as m_open:
        with patch.object(subprocess, 'Popen', mock_popen(m=m, returncode=0)):
            with patch.object(subprocess, 'call', mock_popen(m=m, returncode=0)):
                main()
                m_open.assert_called_once_with('/var/lib/dpkg/status', 'r')


# Generated at 2022-06-23 03:32:25.644666
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.command import AnsibleCmd
    import os

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.bin_path = ''

        def get_bin_path(self, exe, required=False):
            if exe == 'dpkg' and required:
                if os.path.exists('/usr/bin/dpkg'):
                    return '/usr/bin/dpkg'
                else:
                    return '/bin/false'

        def run_command(self, cmd, check_rc=False, data=None):
            if cmd[0] == '/bin/false':
                return (1, "", "required command dpkg not found")

# Generated at 2022-06-23 03:32:37.252885
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = run_command_mock

    # Test unmodified package
    module.params = {'name': 'foo', 'selection': 'hold'}
    rc = main()
    assert rc['changed'] == False
    assert rc['before'] == 'hold'
    assert rc['after'] == 'hold'

    # Test changed package
    module.params = {'name': 'foo', 'selection': 'install'}
    rc = main()
    assert rc['changed'] == True
    assert rc['before'] == 'hold'

# Generated at 2022-06-23 03:32:43.422584
# Unit test for function main
def test_main():
    # Test inputs.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    name = 'python'
    selection = 'hold'

    # Test function.
    main(module)

    # Test results.
    assert(str(module.fail_json.called) == "None")

# Generated at 2022-06-23 03:32:46.507581
# Unit test for function main
def test_main():
    assert 'Not implemented' == main('')

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:32:55.384552
# Unit test for function main
def test_main():
    # run module locally using argument that would be passed to the module
    module_args = dict(name="vi", selection="hold")
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', "vi"], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != "hold"

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after="hold")


# Generated at 2022-06-23 03:33:05.865109
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command', return_value=(0, 'package deinstall', '')):
        with patch.object(AnsibleModule, 'run_command', return_value=(0, '', '')):
            module = AnsibleModule({'name': 'python', 'selection': 'deinstall'}, check_mode = False)
            main()
            module.run_command.assert_called_with(['dpkg', '--set-selections'], data="python deinstall", check_rc=True)
            module.run_command.assert_called_with(['dpkg', '--get-selections', 'python'], check_rc=True)
            module.assert_called_with_exit_json(changed=True, before='deinstall', after='deinstall')


# Generated at 2022-06-23 03:33:16.523388
# Unit test for function main
def test_main():
    dpkg_path="/usr/bin/dpkg"
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:33:28.100321
# Unit test for function main
def test_main():
    # create an ansible module object
    module = ansible_module_init
    # ansible module returns the module object after executing
    # the code we provide.
    #
    # example module.params dictionary for reference
    # 'params': {'name': 'python',  'selection': 'hold'}
    result = module.params['name']
    assert result == 'python'
    # module.run_command returns a tuple with
    # rc, output, error
    result = module.run_command(['ls', '-al'], check_rc=True)
    assert result[0] == 0
    # run main function and make sure it executes
    # without raising any error.
    main()
    # create a new ansible module object
    module = ansible_module_init
    # modify params so that the selection is not changed


# Generated at 2022-06-23 03:33:39.488542
# Unit test for function main
def test_main():
    dpkg_call = ['dpkg', '--set-selections']
    dpkg_input = '%s %s' % ('python', 'hold')
    result = {'name': 'python', 'selection':'hold', 'check_mode': True, 'ansible_facts': {}}

    def mock_run_command(*args, **kwargs):
        rc = kwargs['rc']
        if 'returncode' in kwargs and kwargs['returncode'] == 2:
            return (2, '', '')
        if 'data' in kwargs and kwargs['data'] == dpkg_input:
            return (rc, '', '')
        else:
            return (rc, 'python hold', '')


# Generated at 2022-06-23 03:33:49.514209
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict( required=True ),
            selection=dict( choices=[ 'install', 'hold', 'deinstall', 'purge' ], required=True )
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path( 'dpkg', True )

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command( [ dpkg, '--get-selections', name ], check_rc=True )
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-23 03:33:54.800673
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    dpkg = 'dpkg'
    rc = 0
    out = 'python\thold\n'
    err = ''
    changed = True
    
    if not changed:
        assert(changed == False)
    else:
        assert(changed == True)

# Generated at 2022-06-23 03:34:04.444793
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    rc_input = 0
    out_input = 'python	hold'
    err_input = None
    rc_output = 0
    out_output = None
    err_output = None

    # Mock run_command.
    import __builtin__
    orig_run_command = __builtin__.run_command

    def run_command_mock(args, check_rc=True):
        if args == [dpkg, '--get-selections', name]:
            return (rc_input, out_input, err_input)
        elif args == [dpkg, '--set-selections']:
            return (rc_output, out_output, err_output)
        else:
            raise Exception('invalid call')
    __builtin__.run_command

# Generated at 2022-06-23 03:34:10.706746
# Unit test for function main
def test_main():
    # Success check
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=0)
    main()

    # Fail check
    if __name__ == '__main__':
        main()

# Generated at 2022-06-23 03:34:22.752670
# Unit test for function main
def test_main():

    # important since we will give this function a different name, to be able to call it directly
    global main

    # define the module and data to be passed, to test the function directly
    # in this example we will assume the output of the check will not be different.
    # To test different output, change this as appropriate
    test_name = "test-package"
    test_selection = "hold"

    # assume the output will not have changed
    test_changed = False

    test_module = dict(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # define mock methods

# Generated at 2022-06-23 03:34:24.059176
# Unit test for function main
def test_main():
    # TODO: test dpkg_selections module
    assert True

# Generated at 2022-06-23 03:34:28.612884
# Unit test for function main
def test_main():
    mod = AnsibleModule(
    argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    supports_check_mode=True,
    )
    print(mod)
    
test_main()

# Generated at 2022-06-23 03:34:29.745576
# Unit test for function main
def test_main():
    rc, out, err = main()
    assert out == 'ok'

# Generated at 2022-06-23 03:34:43.012754
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    dpkg = 'dpkg'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:34:53.400112
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = {'rc': 0, 
            'out': 'python install\n',
            'err': ''}
    module.get_bin_path = lambda *args, **kwargs: 'dpkg'
    module.run_command = lambda *args, **kwargs: dpkg
    dpkg['out_1'] = 'python hold\n'
    dpkg['out_2'] = 'python deinstall\n'
    dpkg['out_3'] = 'python purge\n'
    x = main()

# Generated at 2022-06-23 03:34:57.938753
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = lambda a: a

# Generated at 2022-06-23 03:35:09.163142
# Unit test for function main
def test_main():
    # Success: name, selection, pkg_state, pkg_statef_out
    name = 'python'
    selection = 'hold'
    result = {'name': name, 'selection': selection, 'pkg_state': 'hold', 'pkg_statef_out':'hold hold'}
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Test current package state is hold
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

# Generated at 2022-06-23 03:35:12.596863
# Unit test for function main
def test_main():
    test = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(required=True)
    ),
        supports_check_mode=True,
    )
    test.exit_json = exit_json
    main()

# Generated at 2022-06-23 03:35:21.556223
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert changed == True

    assert current == 'install'
    assert selection == 'hold'

# Generated at 2022-06-23 03:35:22.768356
# Unit test for function main

# Generated at 2022-06-23 03:35:23.463794
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 03:35:33.625019
# Unit test for function main
def test_main():
    import os
    import sys
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:35:43.188103
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection


# Generated at 2022-06-23 03:35:55.690804
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "python"
    selection = "hold"

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:35:56.368310
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 03:35:57.128377
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:36:07.535603
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            selection = dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)
    
    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module

# Generated at 2022-06-23 03:36:16.209479
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:28.293109
# Unit test for function main
def test_main():
    dpkg_module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg_module.run_command = lambda A, data: (0, dpkg_module.params['selection'], '')
    dpkg_module.get_bin_path = lambda A, required=False: ("/usr/sbin")
    dpkg_module.run_command = lambda A, data: (0, '', '')
    dpkg_module.check_mode = False
    dpkg_module.params = dict(
        name='python',
        selection='hold'
    )
    main()

# Generated at 2022-06-23 03:36:31.436494
# Unit test for function main
def test_main():
  print("test")
  name = "python"
  selection = "hold"
  changed = current != selection
  assert changed == False, "The changes should be the same"

# Generated at 2022-06-23 03:36:41.693275
# Unit test for function main
def test_main():
    import os, sys
    import argparse
    # The below throws an error of type AttributeError saying
    # module 'ansible.module_utils.basic' has no attribute 'AnsibleModule'
    #
    # To fix this, I added the following line of code before import ansible.module_utils.basic:
    #
    # from ansible.module_utils._text import to_text
    #
    # IMPORTANT:
    # As of Feb 11, 2019, this fix is not included in the ansible repo.
    # So, I have to maintain this fix locally until ansible merges the fix.
    #
    # When the fix is merged into ansible, then I can remove the above line of code.
    #
    #
    #
    #
    # from ansible.module_utils._text import to_text


# Generated at 2022-06-23 03:36:43.290509
# Unit test for function main
def test_main():
    assert len(sys.argv) == 2
    assert sys.argv[1] == '--check'
    ret = main()
    print(ret)

# Generated at 2022-06-23 03:36:43.938350
# Unit test for function main
def test_main():
    assert main() == True

# Generated at 2022-06-23 03:36:53.133495
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:58.992744
# Unit test for function main
def test_main():
    dpkg_selections_test1 = {
        "name": "python",
        "selection": "hold"
    }
    m = AnsibleModule(argument_spec=dpkg_selections_test1)
    m.run_command = MagicMock(return_value=(0, "python hold", None))
    result = main()
    assert result['changed'] is True
