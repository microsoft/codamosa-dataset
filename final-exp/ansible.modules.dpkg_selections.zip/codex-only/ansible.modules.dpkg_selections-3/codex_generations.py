

# Generated at 2022-06-23 03:27:03.724276
# Unit test for function main
def test_main():
    read_dpkg_selections = mock.Mock(return_value='python hold\n')

    set_dpkg_selections = mock.Mock()

    class AnsibleModule:

        def __init__(self, argument_spec, check_mode, supports_check_mode):
            self.check_mode = check_mode
            self.params = {'name': 'python', 'selection': 'hold'}

        def run_command(self, args, check_rc=True, data=None):
            if args[2] == '--get-selections':
                return 'python hold\n', '', 0
            else:
                set_dpkg_selections(args, data)
                return '', '', 0

    original_main = __builtins__['main']
    __builtins__['main'] = main
   

# Generated at 2022-06-23 03:27:13.603636
# Unit test for function main
def test_main():
    import os
    import sys
    import uuid
    import random

    # Simulate arguments
    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.check_mode = False
            self.supports_check_mode = True
            for key, value in argument_spec.items():
                setattr(self, key, value)

        def get_bin_path(self, process, required):
            self.assertEqual(process, 'dpkg')
            self.assertTrue(required)
            return 'dpkg'

        def run_command(self, command, check_rc=False, **kwargs):
            self.assertEqual(command, ['dpkg', '--get-selections', 'python'])
            self.assertTrue(check_rc)

# Generated at 2022-06-23 03:27:21.372050
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Missing parameters
    arguments = dict()
    result = module.run_command(main(), True, arguments)
    assert result['failed'] == True
    assert result['msg'] == "Missing required arguments: name, selection"

    # Test for get_bin_path()
    assert module.get_bin_path('dpkg', True) == 'dpkg'

# Generated at 2022-06-23 03:27:32.777709
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.mkdtemp()
    dpkg = module.get_bin_path('dpkg')

    name = module.params['name']
    selection = module.params['selection']
    file = module.tmpdir + '/dpkg-get-selections'

    f = open(file, 'w')
    f.write('openssh-server install\n')
    f.write('python hold')
    f.close()


# Generated at 2022-06-23 03:27:33.879138
# Unit test for function main
def test_main():
    assert main() is None 


# Generated at 2022-06-23 03:27:45.397445
# Unit test for function main
def test_main():
    function_name = 'main'
    module_name = 'dpkg_selections'
    check_mode = True

    # mock --get-selections
    rc = 0
    out = "test_name deinstall"
    err = ""

    # mock --set-selections
    module_rc = 0

    # set up mock environment
    os = MockOs()
    module = MockModule(dict(
        name='test_name',
        selection='hold',
        supports_check_mode=check_mode,
        check_mode=check_mode
    ))

    # set up AnsibleModule mock object
    module_obj = setup_ansible_module_mock(module, os)
    module_obj.run_command.return_value = rc, out, err

    # call function

# Generated at 2022-06-23 03:27:56.793974
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:28:00.982222
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert (main() == True)


# Generated at 2022-06-23 03:28:09.302500
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:28:21.365923
# Unit test for function main
def test_main():
    import sys
    import tempfile
    class Input(object):
        def __init__(self, filename, lines):
            self._input = tempfile.NamedTemporaryFile(mode='w', delete=False)
            self._input.writelines(lines)
            self._input.close()
            self.name = filename
    def setUp():
        sys.modules['ansible.module_utils.basic'] = helper.MockModule()
        sys.modules['ansible.module_utils.basic'].AnsibleModule = helper.MockAnsibleModule
    def tearDown():
        del sys.modules['ansible.module_utils.basic']
    def test_main_with_check_mode(helper):
        setUp()

# Generated at 2022-06-23 03:28:22.597101
# Unit test for function main
def test_main():
    assert main() is not None

# Generated at 2022-06-23 03:28:31.638531
# Unit test for function main
def test_main():
    test_fields = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )
    test_args = dict(
        name='test',
        selection='test'
    )
    facts = dict(
        ansible_os_family='Debian'
    )
    with pytest.raises(AnsibleFailJson) as exc:
        module = Mock(argument_spec=test_fields, params=test_args)
        module.get_bin_path.return_value='/bin/dpkg'
        module.run_command.return_value=(0, 'test test', 'test')
        main()
    result = exc.value.args[0]
    assert result['failed']

# Unit

# Generated at 2022-06-23 03:28:39.531332
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:28:49.725522
# Unit test for function main
def test_main():
    import platform

    if platform.system() != 'Linux':
        raise unittest.SkipTest('Skipping test_main, unsupported Windows platform')

    if platform.dist()[0] != 'debian':
        raise unittest.SkipTest('Skipping test_main, unsupported non-debian platform')

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    results = main()
    assert results.get('changed') is True

# Generated at 2022-06-23 03:28:57.686804
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            'name': dict(required=True),
            'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        },
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:28:58.837337
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-23 03:29:00.476587
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:29:03.747579
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    module = AnsibleModule(dict(name=name, selection=selection))
    rc = main()
    assert rc['changed'] == False

# Generated at 2022-06-23 03:29:13.280553
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.version import __version__ as a_version
    # This is a hack, but it's the best way to avoid breaking things,
    # and it will be removed once we fully transition to ansible-test.
    if __version__.startswith('2.8'):
        a_version = '2.8.0'
        # There are issues with the modules, so they are being skipped here.
        import pytest
        pytest.skip()


# Generated at 2022-06-23 03:29:25.285747
# Unit test for function main
def test_main():
    import os
    import tempfile
    import subprocess

    fake_ansible_module = lambda: None
    fake_ansible_module.get_bin_path = lambda x, y: '/usr/bin/dpkg'
    fake_ansible_module.run_command = lambda x, check_rc=False: ('0', 'apache2 try', 'none')
    fake_ansible_module.check_mode = False

    with tempfile.TemporaryFile() as temp_file:
        class FakeModule:
            params = {
                'name': 'apache2',
                'selection': 'try'
            }
            # In traditional AnsibleModule method, the tempfile is available as fp only
            fp = temp_file

        fake_ansible_module.__dict__ = FakeModule().__dict__
        main()
        temp

# Generated at 2022-06-23 03:29:34.905407
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    print("Created temporary directory {0}".format(tmpdir))

    # Create a temporary file for dpkg --get-selections
    selections = tempfile.NamedTemporaryFile(dir=tmpdir,mode='w+b',delete=False)
    print("Created temporary file {0}".format(selections.name))
    selections.write(b'zlib1g:amd64\tinstall\n')
    selections.close()

    # Create a temporary file for dpkg --set-selections
    selections_set = tempfile.NamedTemporaryFile(dir=tmpdir,mode='w+b',delete=False)

# Generated at 2022-06-23 03:29:45.121549
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:29:45.946716
# Unit test for function main
def test_main():
    # Arrange
    main()

# Generated at 2022-06-23 03:29:57.769319
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec={
      'name': {
        'required': True,
      },
      'selection': {
        'choices': [ 'install', 'hold', 'deinstall', 'purge' ],
        'required': True,
      },
    },
    supports_check_mode=True,
  )

  dpkg = module.get_bin_path('dpkg', True)

  name = module.params['name']
  selection = module.params['selection']

  # Get current settings.
  rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
  if not out:
    current = 'not present'
  else:
    current = out.split()[1]

  changed = current != selection


# Generated at 2022-06-23 03:29:58.716742
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-23 03:30:04.845205
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = mock.Mock(return_value=(0, 'debconf install'))
    module.get_bin_path = mock.Mock(return_value='/usr/bin/dpkg')
    main()



# Generated at 2022-06-23 03:30:13.416507
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    test_args = dict(
        name='python',
        selection='hold',
    )
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    test_module.run_command = mock_run_command
    out = main()
    assert out['changed'] == True
    assert out['before'] == 'not present'
    assert out['after'] == 'hold'


# Unit test mock run_command

# Generated at 2022-06-23 03:30:22.668618
# Unit test for function main
def test_main():

    test_parameters = {
        "name" : "test_package",
        "selection" : "hold"
    }

    test_module = AnsibleModule(
        argument_spec = dict(
            name = dict(required = True),
            selection = dict(choices = ['install', 'hold', 'deinstall', 'purge'], required = True)
        ),
        supports_check_mode = True
    )
    test_module.params = test_parameters

    main()

# Generated at 2022-06-23 03:30:24.283507
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:30:33.896074
# Unit test for function main
def test_main():
    name = 'test'
    selection = 'deinstall'
    dpkg = '/usr/bin/dpkg'
    rc = 0
    out = 'test deinstall'
    err = ''
    check_rc = True
    check_mode = True
    params = {'name': name, 'selection': selection}
    module = AnsibleModule(argument_spec={'name': {'required': True}, 'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}}, supports_check_mode=True)
    module.get_bin_path = MagicMock(return_value=dpkg)
    module.run_command = MagicMock(return_value=(rc, out, err))
    exception = False
    try:
        main()
    except Exception:
        exception = True

# Generated at 2022-06-23 03:30:34.369894
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:30:34.882552
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:30:42.937304
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    import tempfile

    try:
        import __main__
    except ImportError:
        __main__ = None

    curdir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, curdir)
    from ansible_collections.notstdlib.moveitallout.plugins.modules import dpkg_selections
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import action_common_attributes

    class Dpkg(object):
        def __init__(self):
            self.rc = 0
            self.out = None
            self.err = None

        def run_command(self, cmd, **kwargs):
            # stub
            return self.rc, self

# Generated at 2022-06-23 03:30:46.010087
# Unit test for function main
def test_main():
    try:
        os.remove(filename)
    except OSError:
        pass
    main()
    assert os.path.exists(filename)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:30:57.020119
# Unit test for function main
def test_main():
    import os
    import signal
    import subprocess
    import sys
    import tempfile
    import time

    signals = dict((k, v) for v, k in reversed(sorted(
        signal.__dict__.items())) if v.startswith('SIG') and not v.startswith('SIG_'))

    def _wait(timeout=5):
        for i in range(timeout):
            if os.path.exists(file.name):
                break
            time.sleep(1)
        else:
            try:
                os.killpg(pid, signals['SIGTERM'])
                os.waitpid(pid, 0)
            finally:
                raise Exception("timeout waiting for %s" % file.name)

    def _communicate():
        _wait(3)
        os.killpg

# Generated at 2022-06-23 03:31:03.772634
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # No need to check the output, this will call main() and tests are in the function
    assert main() == 0

# Generated at 2022-06-23 03:31:05.747327
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:31:10.331424
# Unit test for function main
def test_main():
    for name in ['python', 'python3']:
        for selection in ['install', 'hold', 'deinstall', 'purge']:
            module = AnsibleModule({'name': name, 'selection': selection})
            assert main()

# Generated at 2022-06-23 03:31:19.431892
# Unit test for function main
def test_main():
    '''
       Test module function main.
    '''
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-23 03:31:27.780254
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert module.params['name'] == name
    assert module.params['selection'] == selection


# Generated at 2022-06-23 03:31:30.831732
# Unit test for function main
def test_main():
    pass
    #assert main(['',''])

# Generated at 2022-06-23 03:31:33.731009
# Unit test for function main
def test_main():
    # Mock module
    module = type('', (), {})()
    module.exit_json = lambda *args: None
    module.run_command = lambda *args, **kwargs: (0, "python deinstall", None)
    module.get_bin_path = lambda *args: "/bin/dpkg"
    module.check_mode = False

    # Mock params
    module.params = {
        "name": "python",
        "selection": "install",
    }

    main()

# Generated at 2022-06-23 03:31:34.376543
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:31:42.758129
# Unit test for function main
def test_main():
    # input parameters
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    main()

# Generated at 2022-06-23 03:31:48.967255
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json(changed=False, before='current', after='selection')

# Generated at 2022-06-23 03:31:59.318064
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']
    current = 'install'

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-23 03:32:09.529671
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    dpkg = 'dpkg'
    name = 'python'
    selection = 'hold'

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    def run_command(cmd, check_rc=True):
        print('run_command: ' + ' '.join(cmd))
        if cmd == [dpkg, '--get-selections', name]:
            return 0, '', ''
        if cmd == [dpkg, '--set-selections']:
            return 0, '', ''
        return 1, '', ''

   

# Generated at 2022-06-23 03:32:19.165299
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:32:19.831052
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:32:29.957833
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # Test for no changes.
    data = '''
    {
        "name": "python",
        "selection": "hold"
    }
    '''
    module = AnsibleModule(argument_spec={})
    module.params = module.load_params(data)
    module.run_command.side_effect = [
        (0, "python hold\n", ""),
        (0, "", "")
    ]
    m = main()
    assert m['changed'] == False
    assert m['before'] == "hold"
    assert m['after'] == "hold"

    # Test for changes.
    data = '''
    {
        "name": "python",
        "selection": "install"
    }
    '''

# Generated at 2022-06-23 03:32:40.614650
# Unit test for function main
def test_main():
    # Command "dpkg --get-selections python" gives
    # python                               install
    # python-minimal                       install
    # python2.7                            install
    # python3                              install
    # python3-minimal                      install
    # which means "python" is "install"
    check_rc = True
    rc = 0
    # Set up args as if invoked from ansible
    args = dict(
        name='python',
        selection='hold',
        supports_check_mode=True,
    )
    module = AnsibleModule(**args)
    # First call to dpkg --get-selections python yields the current state
    def run_command(cmd, check_rc):
        rc = 0
        out = 'python                               install'
        err = ''
        return rc, out, err

# Generated at 2022-06-23 03:32:46.387691
# Unit test for function main
def test_main():
    # Mock to replace the global function with a local one
    def mock_main(f):
        def mock_f(*args, **kwargs):
            return f(*args, **kwargs)

        return mock_f

    # Unit test: commands not called
    unit_test_base(mock_main, 0, False)
    unit_test_base(mock_main, 1, True)


# Unit test base

# Generated at 2022-06-23 03:32:52.643250
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
            'name': {'required': True},
            'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True},
            })
    class AnsibleModuleMock():
        def __init__(self):
            self.exit_json = exit_json
    def exit_json(changed, before, after):
        return changed, before, after
    changed, before, after = main()
    assert changed == True, "Under test, changed == False"

# Generated at 2022-06-23 03:32:53.787786
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 03:33:03.735568
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:05.560500
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:33:16.261625
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        assert changed


# Generated at 2022-06-23 03:33:27.797521
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "test_package"
    selection = "hold"
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection


# Generated at 2022-06-23 03:33:39.432613
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:46.999203
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = "python"
    selection = "hold"
    result = main()
    assert(result.get('changed') == False)
    assert(result.get('before') == 'install')
    assert(result.get('after') == 'hold')

# Generated at 2022-06-23 03:33:49.845958
# Unit test for function main
def test_main():
    utils.noop_run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-23 03:33:59.953220
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:34:08.987806
# Unit test for function main
def test_main():
    import os
    from subprocess import Popen

    # We do not test the check mode
    os.environ['ANSIBLE_CHECK_MODE'] = '0'

    # Unit test the selection using a selection that is not present
    args = {
        'name': 'apache2',
        'selection': 'deinstall',
    }

    rc = Popen(["python", "./dpkg_selections.py"], env=os.environ, stdin=open('/dev/stdin', 'r'), stdout=open('/dev/stdout', 'w'), stderr=open('/dev/stderr', 'w'))
    rc.communicate(input=str(args))

    # Verify if the output file is correct

# Generated at 2022-06-23 03:34:21.080104
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:34:26.703570
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = 'testPackage'
    selection = 'install'

    main()

    module.exit_json(changed=True, before='not present', after='install')


# Generated at 2022-06-23 03:34:35.016862
# Unit test for function main
def test_main():
  def get_bin_path_side_effect(*args, **kwargs):
    return "/usr/bin/dpkg"
  def run_command_side_effect(*args, **kwargs):
    return 0, "", ""

  @patch("ansible.module_utils.basic.AnsibleModule", autospec=True)
  @patch("ansible.module_utils.basic.get_bin_path", autospec=True)
  @patch("ansible.module_utils.basic.run_command", autospec=True)
  def test(ansibleModuleMock, getBinPathMock, runCommandMock):
    # Set side effect
    getBinPathMock.side_effect = get_bin_path_side_effect

    # Test inputs
    name = "libapache2-mod-php7.0"


# Generated at 2022-06-23 03:34:36.746429
# Unit test for function main
def test_main():

    assert main() == None

test_main()

# Generated at 2022-06-23 03:34:37.616631
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:34:48.700169
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params['name'] = 'rsyslog'
    module.params['selection'] = 'hold'

    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', 'rsyslog'], check_rc=True)
    assert out == 'rsyslog    hold'

    main()

    module.params['selection'] = 'install'
    main()

    module.params['selection'] = 'deinstall'
    main()

# Generated at 2022-06-23 03:34:50.848469
# Unit test for function main
def test_main():
    test_main()

# Generated at 2022-06-23 03:34:51.440627
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:34:59.308208
# Unit test for function main
def test_main():
    from ansible.module_utils.common.file import TemporaryFile
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.action_common import AttributeDict
    import sys
    import os

    class AttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    tmp = TemporaryFile()
    tmp.close()
    tmppath = tmp.name


# Generated at 2022-06-23 03:35:09.661647
# Unit test for function main
def test_main():
  global __line__
  __line__ = __import__('linecache').getline

  def __getline(filename, lineno):
    """Get line lineno of file filename or '' if no such line exists."""
    return linecache.getline(filename, lineno).strip()

  # Set variables to match ansiballz
  ARGS = {'name': 'python', 'selection': 'hold'}
  RC = 0
  OUT = 'python	hold'
  ERR = ''

  # Set attributes for AnsibleModule
  module = __import__('ansible.module_utils.basic')
  setattr(module, 'AnsibleModule', module.AnsibleModule)
  setattr(module.AnsibleModule, 'run_command', lambda x: (RC, OUT, ERR))

# Generated at 2022-06-23 03:35:10.479221
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 03:35:20.839403
# Unit test for function main
def test_main():
    """ Unit test for function main """

    # Make sure we are running as root
    if os.geteuid() != 0:
        raise AssertionError("Function test_main is being run as non-root user. Please re-run as root.")

    test_package = 'cowsay'
    test_selection_state = 'purge'
    test_dpkg = '/usr/bin/dpkg'

    # Check if cowsay is installed.
    rc, out, err = module.run_command([test_dpkg, '--get-selections', test_package], check_rc=True)
    if not out:
        current_selection='not present'
    else:
        current_selection = out.split()[1]


# Generated at 2022-06-23 03:35:21.614938
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 03:35:32.326370
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = 'dpkg'
    selection = 'hold'

    # Get current settings.
    rc, out, err = test_module.run_command(['dpkg', '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:35:44.188193
# Unit test for function main

# Generated at 2022-06-23 03:35:45.944291
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:35:52.884472
# Unit test for function main
def test_main():
    import sys, os
    import json
    fd = open('tmp_args.json')
    params = json.loads(fd.read())
    fd.close()
    fd = open('tmp_ansible_facts.json')
    ansible_facts = json.loads(fd.read())
    fd.close()
    jd = json.loads(main())
    assert jd['changed'] == False
    #os.remove('tmp_args.json')
    #os.remove('tmp_ansible_facts.json')
    sys.stdout.flush()
    sys.stdout.close()
    sys.stderr.flush()
    sys.stderr.close()

# Generated at 2022-06-23 03:36:04.119860
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "python"
    selection = "hold"

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:36:12.400167
# Unit test for function main
def test_main():
    test_spec = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )

    module = AnsibleModule(argument_spec=dict)

    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', "python"], check_rc=True)

    assert rc == 0

# Generated at 2022-06-23 03:36:23.626354
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:33.216002
# Unit test for function main
def test_main():
    # noinspection PyUnresolvedReferences
    from ansible.modules.packaging.language.dpkg_selections import main

    def fix_path(path):
        import sys
        import os

        sep = os.path.sep
        if sys.platform == 'cygwin':
            sep = '/' + sep

        return path.replace('/', sep)

    # noinspection PyUnresolvedReferences
    import imp
    import inspect
    import sys

    t = imp.load_source('main', fix_path('/b/a/s/s/l/e/s/s/ansible/modules/packaging/language/dpkg_selections/main.py'))
    print(sys.modules['main'])
    f = getattr(t, 'main')

# Generated at 2022-06-23 03:36:33.883850
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:36:45.234953
# Unit test for function main
def test_main():
    run_command = {'rc': 0, 'out': 'python install', 'err': ''}
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)))
    module.run_command = lambda x, check=True, data=None: run_command
    main()
    assert module.exit_json == {'changed': False, 'before': 'install', 'after': 'install'}
    run_command = {'rc': 0, 'out': '', 'err': ''}
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)))

# Generated at 2022-06-23 03:36:47.495981
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 03:36:58.840471
# Unit test for function main
def test_main():
    # This is a unit test.
    from ansible.module_utils.basic import AnsibleModule

    import os
    import shutil
    import tempfile

    os.environ['PATH'] = '/usr/bin:/bin'


    # Work in a temporary directory
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)

    # Make the test variables
    module_params = dict(
        name='testname',
        selection='install',
        diff_mode=False,
        check_mode=False,
        python_version=2
    )

    # Make a fake dpkg binary
    open(os.path.join(tempdir, 'dpkg'), 'a').close()
    os.chmod(os.path.join(tempdir, 'dpkg'), 0o755)

    # Create the