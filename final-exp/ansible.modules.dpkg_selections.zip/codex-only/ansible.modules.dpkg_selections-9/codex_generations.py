

# Generated at 2022-06-23 03:26:54.860406
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:27:04.028825
# Unit test for function main
def test_main():
    # Hack so we can test this function without all the other functions that are in the module.
    module = type('', (), {'run_command': run_command})

    # Not changed test
    run_command_results = ['', '', 0]
    module.run_command = lambda x, **kwargs: run_command_results.pop()
    assert main() == {'changed': False, 'before': 'hold', 'after': 'hold'}

    # Changed test
    run_command_results = ['', '', 0]
    module.run_command = lambda x, **kwargs: run_command_results.pop()
    assert main() == {'changed': True, 'before': 'hold', 'after': 'install'}

# Generated at 2022-06-23 03:27:06.270402
# Unit test for function main
def test_main():
    args = {
        'name': 'python',
        'selection': 'hold'
    }
    changed = main(args)
    assert changed == None

# Generated at 2022-06-23 03:27:20.732866
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = "apache2"
    selection = "install"
    rc, out, err = m.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection
    assert changed == False
    rc, out, err = m.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current

# Generated at 2022-06-23 03:27:32.741368
# Unit test for function main
def test_main():
    dpkg = '/usr/bin/dpkg'
    module = AnsibleModule(argument_spec=dict( name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True) ), supports_check_mode=True)
    module.get_bin_path = MagicMock(return_value=dpkg)
    name = 'python'
    selection = 'hold'
    rc = 0
    out = 'python   hold'
    err = ''
    module.run_command = MagicMock(return_value=(rc, out, err))
    module.run_command.assert_called_with([dpkg, '--get-selections', name], check_rc=True)
    module.exit_json = MagicMock()
    main()
    module.exit_

# Generated at 2022-06-23 03:27:44.542066
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'purge'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:27:55.987626
# Unit test for function main
def test_main():
    '''
    Unit test for function main

    :return: None
    '''

    # For function main
    #
    ####################
    # Option validation
    #
    # option type
    assert main.__annotations__['module'].argument_spec['name']['type'] == 'str'
    assert main.__annotations__['module'].argument_spec['selection']['type'] == 'str'
    # option required
    assert main.__annotations__['module'].argument_spec['name']['required'] == True
    assert main.__annotations__['module'].argument_spec['selection']['required'] == True
    # option choices
    assert 'choices' in main.__annotations__['module'].argument_spec['selection']
    assert main.__annotations__['module'].argument

# Generated at 2022-06-23 03:28:06.093172
# Unit test for function main
def test_main():
    """
    Unit test for function main
    :return:
    """
    import sys
    import subprocess
    import json

    # Test 1
    args = "name='a-package' selection='hold'".split()
    testargs = "test.py " + " ".join(args)
    with subprocess.Popen(testargs.split(), stdout=subprocess.PIPE) as process:
        output = process.communicate()[0]
        result = json.loads(output)
        assert result['changed'] == True

    # Test 2
    args = "name='a-package' selection='hold'".split()
    testargs = "test.py " + " ".join(args)

# Generated at 2022-06-23 03:28:09.921056
# Unit test for function main
def test_main():
    rc, out, err = module.run_command('apt-get -qq --set-selections', data="%s %s" % (name, selection),
                                      check_rc=True)
    assert rc == 0

# Generated at 2022-06-23 03:28:21.564919
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    test_selection = 'install'
    test_name = 'python'
    test_out = """cat
hold
install install
manual-installed
purge purge
remove remove
deinstall
"""
    test_out2 = """%s deinstall
""" % (test_name)
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-23 03:28:22.514672
# Unit test for function main
def test_main():
    print("Test main")
    main()
    print("Test end main")

# Generated at 2022-06-23 03:28:31.555749
# Unit test for function main
def test_main():
    # Given
    name = 'foo'
    selection = 'hold'
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ), supports_check_mode=True)
    module.run_command = MagicMock(
        return_value=(0, '', ''))
    # When
    main()
    # Then
    module.run_command.assert_called_with([
        module.get_bin_path.return_value, '--set-selections'],
        data='foo hold',
        check_rc=True)
    module.exit_json.assert_called_with(
        changed=True, before='not present', after='hold')

# Generated at 2022-06-23 03:28:32.573734
# Unit test for function main
def test_main():
    assert main() == 'main executed'

# Generated at 2022-06-23 03:28:33.793145
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:28:42.793402
# Unit test for function main
def test_main():
    argv = ["/usr/local/bin/ansible-playbook", "/usr/share/ansible/openshift-ansible/playbooks/byo/openshift-cluster/openshift-packages.yml", "-i", "/usr/share/ansible/openshift-ansible/inventory/hosts.localhost"]
    extra_vars = {
        "openshift_deployment_type": "origin",
        "openshift_disable_check": None,
        "openshift_packages_version": "v3.9.0",
        "openshift_service_type": "origin",
        "_ansible_check_mode": True
    }

    res = main(argv, extra_vars)
    assert res == 0

# Generated at 2022-06-23 03:28:45.526093
# Unit test for function main
def test_main():
    dpkg_selections = {
        "status": "en"
    }
    assert dpkg_selections == {"status": "en"}

# Generated at 2022-06-23 03:28:46.151370
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 03:28:52.029549
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

# Generated at 2022-06-23 03:29:00.746298
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:29:10.979252
# Unit test for function main
def test_main():
    import pytest
    from unittest.mock import create_autospec, patch
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.getopt import getopt
    from ansible.module_utils.six import b
    from ansible.module_utils import basic

    AnsibleModule_object = create_autospec(AnsibleModule)
    AnsibleModule_object.check_mode = False
    AnsibleModule_object.run_command = create_autospec(AnsibleModule.run_command)
    AnsibleModule_object.run_command.return_value = (0, b('python hold'), b(''))
    AnsibleModule_object.exit_json = create_autospec(AnsibleModule.exit_json)

# Generated at 2022-06-23 03:29:20.180608
# Unit test for function main
def test_main():
    import warnings
    warnings.simplefilter(action='ignore')
    import os
    import sys
    import shutil
    import tempfile

    filename_list = ['dpkg']
    directory_list = ['/etc/dpkg/dpkg.cfg.d/']
    test_list = ['name', 'selection']
    true_list = ['check_mode', 'diff_mode', 'platform']

# Generated at 2022-06-23 03:29:22.436759
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    result = main()
    assert result['changed'] == True
    assert result['before'] == 'not present'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 03:29:33.107020
# Unit test for function main
def test_main():
    '''
    Function to test main function
    '''
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-23 03:29:34.917977
# Unit test for function main
def test_main():
    import ansible.module_dpkg

    ansible.module_dpkg.main()


# Generated at 2022-06-23 03:29:44.503220
# Unit test for function main
def test_main():

    import sys
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleMockup(AnsibleModule):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.called = dict()


# Generated at 2022-06-23 03:29:55.687635
# Unit test for function main
def test_main():

    # Results from dpkg -l python
    rc1 = 0
    out1 = "ii  python      2.7.6-8"
    err1 = []

    # Results from dpkg -l python | awk '{print $2}'
    rc2 = 0
    out2 = "python"
    err2 = []

    # Results from dpkg -l python | awk '{print $3}'
    rc3 = 0
    out3 = "2.7.6-8"
    err3 = []

    # Results from dpkg --set-selections
    rc4 = 0
    out4 = []
    err4 = []

    # Test case, prevent python from being upgraded.
    name = "python"
    selection = "hold"

    # Module instantiation

# Generated at 2022-06-23 03:29:57.158193
# Unit test for function main
def test_main():
    assert main() == True


# Generated at 2022-06-23 03:30:06.109105
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:30:10.178048
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-23 03:30:11.758831
# Unit test for function main
def test_main():
    # import doctest
    # doctest.testmod()
    unit_test = True

# Generated at 2022-06-23 03:30:12.725230
# Unit test for function main
def test_main():
    # Unit: check status
    assert main() == 0

# Generated at 2022-06-23 03:30:22.453940
# Unit test for function main
def test_main():
    # Mock the module class
    class MockModule(object):
        def __init__(self):
            self.params = {
                'name': 'vim',
                'selection': 'purge'
            }
            self.check_mode = False
        def get_bin_path(self, path, required):
            return path
        def run_command(self, args, check_rc):
            return 0, 'vim hold', ''
          
    # Instantiate module and execute
    module = MockModule()
    main(module)


# Generated at 2022-06-23 03:30:33.617681
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:30:42.954212
# Unit test for function main
def test_main():
    """This test will pass if ansible module dpkg_selections.py
       will not fail in ansible 2.7 version
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-23 03:30:47.966798
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(required=True)
        )
    )
    module.deprecate("The 'dpkg_selections' module has been renamed to 'apt_selections'", "2.11")
    return main()

# Generated at 2022-06-23 03:30:58.146436
# Unit test for function main
def test_main():
    dpkg_mock = MagicMock(return_value=(0, 'test-package hold', ''))
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = dpkg_mock

    module.params['name'] = 'test-package'
    module.params['selection'] = 'hold'
    main()

    dpkg_mock.assert_called_with([module.get_bin_path('dpkg', True), '--get-selections', 'test-package'], check_rc=True)

# Generated at 2022-06-23 03:31:08.484455
# Unit test for function main
def test_main():
    import tempfile
    temp = tempfile.NamedTemporaryFile()
    temp.write("python install")
    temp.seek(0)

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = "python"
    selection = "hold"

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

   

# Generated at 2022-06-23 03:31:09.175173
# Unit test for function main
def test_main():
    print("Test main")

# Generated at 2022-06-23 03:31:20.408503
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO

    class AnsibleModuleMock(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.check_mode = False
            self.exit_json = lambda *args: 0
            self.fail_json = lambda **err: 1
            self._final_exit = 0
            self.run_command = self._run_command
            self.get_bin_path = lambda *args: '/bin/dpkg'

        def _run_command(self, args, check_rc=True):
            command = args[0]

            if command == '/bin/dpkg':
                if len(args) < 2:
                    self.fail_json(err='command %s needs at least 2 args' % (command))


# Generated at 2022-06-23 03:31:32.302845
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:31:34.185643
# Unit test for function main
def test_main():
    expected = dict(changed=False, before='install', after='install')
    result = main()
    assert result == expected

# Generated at 2022-06-23 03:31:46.856250
# Unit test for function main

# Generated at 2022-06-23 03:31:57.334915
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:32:08.203368
# Unit test for function main
def test_main():
    arguments = dict(name='python', selection='hold')
    result = dict(changed=True, before='install', after='hold')
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    module.exit_json = MagicMock(return_value=result)

    rc, out, err = module.run_command(['dpkg', '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    
    changed = current != 'hold'

    if module.check_mode or not changed:
        module

# Generated at 2022-06-23 03:32:17.495076
# Unit test for function main
def test_main():
    test_data = dict(
        selection='install',
        name='test-package',
    )
    module = AnsibleModule(argument_spec=test_data)
    module.run_command = Mock(return_value=(0, 'test-package install', ''))

    # test present and not changed
    dpkg_selections.main()
    assert module.exit_json.call_args == call(changed=False, after='install', before='install')

    # test present, changed
    module.params['selection'] = 'hold'
    dpkg_selections.main()
    assert module.exit_json.call_args == call(changed=True, after='hold', before='install')

# Generated at 2022-06-23 03:32:26.721397
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:32:37.912416
# Unit test for function main
def test_main():
    dpkg_selections_for_testing = os.system('dpkg --get-selections')
    dpkg_selections_for_testing = os.system('dpkg --set-selections')

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-23 03:32:47.335226
# Unit test for function main
def test_main():
    dpkg_selections_mod = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg_selections_mod.run_command = MagicMock()
    dpkg_selections_mod.run_command.return_value = (0, 'git install', '')
    dpkg_selections_mod.get_bin_path = MagicMock()
    dpkg_selections_mod.get_bin_path.return_value = 'dpkg'
    args = dict(
        name='git',
        selection='hold'
    )

# Generated at 2022-06-23 03:32:58.669194
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:08.727174
# Unit test for function main
def test_main():
    # test with good input
    module = AnsibleModule(
        argument_spec = dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:33:15.463546
# Unit test for function main
def test_main():
    def run_command_mock(*_, **__):
        return 0, "python install", ""
    main({
        'run_command': run_command_mock,
        'get_bin_path': lambda x: x,
    })
    main({
        'run_command': run_command_mock,
        'get_bin_path': lambda x: x,
        'params': {'name': 'python', 'selection': 'install'},
    })

# Generated at 2022-06-23 03:33:23.277213
# Unit test for function main
def test_main():
    # Define module arguments.
    module_args = dict(
        name=dict(required=True, type='str'),
        selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'], type='str')
    )
    # Inject module arguments into AnsibleModule object.
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    # Define module inputs.
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    # Define module outputs.
    module.exit_json(changed=False, before='install', after='hold')


# Generated at 2022-06-23 03:33:23.931939
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:33:33.835441
# Unit test for function main
def test_main():
    print("Unit Tests for dpkg_selections")
    print("########################################################")
    import tempfile
    import os
    import subprocess
    import sys
    sys.path.append("/usr/lib/python2.7/dist-packages/ansible/module_utils")
    from ansible.module_utils.basic import AnsibleModule
    import logging
    import re
    import os
    from collections import namedtuple
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.path import get_bin_path

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    # Create a temporary file for testing
    f = temp

# Generated at 2022-06-23 03:33:42.308772
# Unit test for function main
def test_main():
    '''
    this function is used to unit test function main
    '''
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'python'
    module.params['selection'] = 'install'
    main()

# Generated at 2022-06-23 03:33:42.872229
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:33:50.703559
# Unit test for function main
def test_main():
    test_cases = [
        ({"name":"foo","selection":"hold"},(True,"install","hold")),
        ({"name":"foo","selection":"purge"},(True,"hold","purge")),
        ({"name":"foo","selection":"deinstall"},(True,"purge","deinstall")),
        ({"name":"foo","selection":"install"},(True,"deinstall","install")),
    ]
    for params, expected_results in test_cases:
        pass

# Generated at 2022-06-23 03:33:56.538439
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest

    fixture_path = os.path.dirname(__file__) + '/fixtures'
    sys.path.append(fixture_path)

    from test_main import *
    from test_main import _create_ansible_module

    dpkg_mock = MagicMock()

    module = _create_ansible_module(examples)

    main()

# Generated at 2022-06-23 03:34:07.094604
# Unit test for function main
def test_main():
    # Test for successful execution
    name = "python"
    selection = "hold"
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:34:12.487517
# Unit test for function main
def test_main():
    m = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,)
    rc = {
        'before': 'deinstall',
        'after': 'deinstall',
        'changed': False
    }
    m.exit_json(**rc)

# Generated at 2022-06-23 03:34:24.183560
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-23 03:34:32.257484
# Unit test for function main
def test_main():
    # mocked values
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required = True),
            selection = dict(choices = ['install', 'hold', 'deinstall', 'purge'], required = True)
        ),
        supports_check_mode = True
    )
    dpkg = '/bin/dpkg'
    name = 'libc6'
    selection = 'hold'
    rc = 0
    err = ''
    out = 'libc6 hold\n'
    current = 'hold'

    module.get_bin_path = MagicMock(return_value = dpkg)
    module.run_command = MagicMock(return_value = (rc, out, err))
    main()


# Generated at 2022-06-23 03:34:36.648610
# Unit test for function main
def test_main():
    args = dict(
        name="hello",
        selection="hold",
    )
    res=main(args)
    assert res['name'] == "hello"
    assert res['selection'] == "hold"

# Generated at 2022-06-23 03:34:47.905043
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.exit_json = MagicMock()
    module.check_mode = False
    module.params = {
        'name':'name',
        'selection':'install',
    }
    main()

    module.run_command.assert_called_with([
        module.get_bin_path('dpkg', True),
        '--set-selections'
    ], data='name install', check_rc=True)
    module.exit

# Generated at 2022-06-23 03:34:58.165016
# Unit test for function main
def test_main():

    # Test with not changed
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection
    assert changed == False


# Generated at 2022-06-23 03:35:09.273647
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from ansible.module_utils.basic import AnsibleModule

    module_path = os.path.dirname(os.path.realpath(__file__))
    test_dir = tempfile.mkdtemp()

    package = tempfile.NamedTemporaryFile(dir=test_dir, delete=False)
    package.write('Package: foo\nVersion: 1.2.3\nArchitecture: amd64\nDescription: test package\n')
    package.close()
    subprocess.check_call(['dpkg-deb', '--build', package.name])

    # Ensure the apt module is not installed

# Generated at 2022-06-23 03:35:20.195630
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:35:27.283242
# Unit test for function main
def test_main():
    # Make sure argument_spec is correct
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Check if module run_command is called
    command = test_module.run_command
    def dummy_run_command(*args, **kwargs):
        command(*args, **kwargs)

    test_module.run_command = dummy_run_command

    # Check if module get_bin_path is called
    binpath = test_module.get_bin_path("dpkg", True)
    def dummy_get_bin_path(arg1, arg2):
        return binpath



# Generated at 2022-06-23 03:35:31.487505
# Unit test for function main
def test_main():
    with patch('ansible.modules.linux.dpkg_selections.AnsibleModule'):
        ansible.modules.linux.dpkg_selections.main()
        #assert ansible_module.fail_json.call_count == 1

# Generated at 2022-06-23 03:35:32.140943
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:35:43.932575
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:35:50.040207
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )
    assert main() is True

# Generated at 2022-06-23 03:36:01.743458
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:12.040883
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, "python install\n", ""))
    module.exit_json = MagicMock()
    main()
    module.run_command.assert_called_with([u'dpkg', '--set-selections'], data=u'python hold', check_rc=True)
    module.exit_json.assert_called_with(changed=True, before='install', after='hold')
    module.exit_json.reset_mock()
    module.run_command = MagicM

# Generated at 2022-06-23 03:36:23.379915
# Unit test for function main
def test_main():
    with mock.patch.object(module_ansible.AnsibleModule, 'run_command') as mock_run_command:
        with mock.patch.object(module_ansible.AnsibleModule, 'exit_json') as mock_exit_json:
            with mock.patch('module_ansible.AnsibleModule') as mock_AnsibleModule:
                mock_AnsibleModule.params = {'selection': 'install', 'name': 'python'}
                mock_AnsibleModule.check_mode = False
                mock_run_command.side_effect = [mock.Mock(returncode=0, stdout='python install', stderr=''),
                                                mock.Mock(returncode=0, stdout='', stderr='')]
                main()
                mock_exit_json.assert_

# Generated at 2022-06-23 03:36:35.086284
# Unit test for function main
def test_main():
    # Mock the module, along with the return values of the module
    dpkg = '/bin/dpkg'
    name = 'foo'
    selection = 'purge'
    current = 'purge'
    changed = False
    out = ''
    err = ''
    rc = 0
    # Mock the module (return None)
    ansible = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Mock the module

# Generated at 2022-06-23 03:36:45.573877
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:58.387682
# Unit test for function main
def test_main():
    def get_bin_path_side_effect(name, required):
        return name

    def run_command_side_effect(args, check_rc=False, data=None):
        results = {}
        results['rc'] = 0
        return results['rc'], 'test_out', 'test_err'

    class AnsibleModuleClass(object):
        def __init__(self, params):
            self.params = params
            self.run_command = lambda args, check_rc, data: run_command_side_effect(args, check_rc, data)
            self.check_mode = False
            self.get_bin_path = lambda name, required: get_bin_path_side_effect(name, required)
            self.exit_json = lambda *x, **y: None
