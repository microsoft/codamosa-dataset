

# Generated at 2022-06-23 03:26:58.136804
# Unit test for function main
def test_main():
    assert main() == 'success'

# Generated at 2022-06-23 03:27:13.138831
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )


    def run_command(args, check_rc=None):
        rc = 0
        if args == ['/usr/bin/dpkg', '--get-selections', 'helloworld']:
            out = 'helloworld\tinstall\n'
        elif args == ['/usr/bin/dpkg', '--get-selections', 'helloworld2']:
            out = None
        else:
            out = 'test'
            rc = 1
        return rc, out, ''

    module.run_command = run_command

    dpkg = module.get_

# Generated at 2022-06-23 03:27:19.779132
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # check_mode is True / False
    module.check_mode = True
    result = main()
    assert result
    # check_mode is False
    module.check_mode = False
    result = main()
    assert result

# Generated at 2022-06-23 03:27:20.985862
# Unit test for function main
def test_main():

    # Add your own unit test here.
    assert(True)

# Generated at 2022-06-23 03:27:32.778007
# Unit test for function main
def test_main():
    import re

    import ansible.module_utils.basic
    import ansible.modules.packaging.os.dpkg_selections
    import ansible.modules.platform.linux

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:27:42.480083
# Unit test for function main
def test_main():
    def run_command_mock(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        if args[-1] == 'python':
            return 0, 'python hold', ''
        elif args[-1] == 'ruby':
            return 1, '', ''

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.run_command = run_command_mock


# Generated at 2022-06-23 03:27:45.137703
# Unit test for function main
def test_main():
    choices = ['install', 'hold', 'deinstall', 'purge']

    for i in range(len(choices)):
        assert(main.choices[i] == choices[i])

# Generated at 2022-06-23 03:27:56.543506
# Unit test for function main
def test_main():
    # Strip away the module code and call the function directly.
    call_function = imp.load_source('', __file__).main
    # The arguments mirror what the module would receive.
    with mock.patch.object(module, 'check_mode', False),\
         mock.patch.object(module, 'get_bin_path', return_value='/usr/bin/dpkg'),\
         mock.patch.object(module, 'run_command', return_value=(0, 'python install', '')):
        assert call_function(module) == {'changed': False, 'before': 'install', 'after': 'install'}
        # Check that dpkg was called correctly.

# Generated at 2022-06-23 03:28:06.109729
# Unit test for function main
def test_main():
    import sys
    import imp
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import builtins, StringIO

    if sys.version_info >= (3,):
        builtin_module = imp.load_source('__builtin__', 'builtins')
        builtin_module.__dict__['REPLAY'] = []

    # Monkeypatch the AnsibleModule class with a dummy exit_json method
    # which will just return a dict containing the state set in ansible.module_utils.connection.Connection._load_params

# Generated at 2022-06-23 03:28:18.016848
# Unit test for function main
def test_main():
    name = 'test_name'
    selection = 'test_selection'
    sys.modules['ansible.module_utils.basic'] = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule.run_command = Mock(return_value=(0, "line1\nline2", None))
    sys.modules['ansible.module_utils.basic'].AnsibleModule.exit_json = Mock(return_value=None)
    sys.modules['ansible.module_utils.basic'].AnsibleModule.get_bin_path = Mock(return_value=None)

    main()


# Generated at 2022-06-23 03:28:18.683114
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:28:28.902471
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Python 2/3
    try:
        myopen = open
    except NameError:
        myopen = tempfile._TemporaryFileWrapper
    # Start with a clean slate.
    try:
        os.unlink('/tmp/dpkg_selections.categorized')
    except:
        pass
    try:
        os.unlink('/tmp/dpkg_selections.list')
    except:
        pass


# Generated at 2022-06-23 03:28:38.794622
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:28:50.422245
# Unit test for function main
def test_main():
    # Setup fixtures
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Name of the package
    name = 'python'
    selection = 'hold'
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    current = out.split()[1]

    # Check the result
    assert current == selection

# Generated at 2022-06-23 03:28:58.767528
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        return changed,

# Generated at 2022-06-23 03:29:00.476766
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:29:02.416905
# Unit test for function main
def test_main():
    # should call ansible.module_utils.basic.AnsibleModule
    assert True

# Generated at 2022-06-23 03:29:12.394734
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    module_path = os.path.join(tmpdir, 'ansible_module.py')
    shutil.copy('dpkg_selections.py', module_path)

    # Create a temporary ansible module arguments
    arguments_path = os.path.join(tmpdir, 'ansible_module_arguments.json')
    with open(arguments_path, 'w') as f:
        f.write('{"ANSIBLE_MODULE_ARGS": {"name": "python", "selection": "hold"}}')

    # Create a temporary ansible results
    results_path

# Generated at 2022-06-23 03:29:12.969536
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:29:15.073732
# Unit test for function main

# Generated at 2022-06-23 03:29:16.450944
# Unit test for function main
def test_main():
    dpkg = main()
    assert dpkg['changed']


# Generated at 2022-06-23 03:29:23.850127
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command', return_value=(0, "debian python install\n", '')):
        with patch.object(AnsibleModule, 'get_bin_path', return_value="/bin/dpkg"):
            with patch.object(AnsibleModule, 'exit_json', return_value=None) as exit_json:
                main()
                assert exit_json.called
                args, kwargs = exit_json.call_args_list[0]
                assert args[0]['changed'] == True

# Generated at 2022-06-23 03:29:32.073748
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        with mock.patch.object(sys, 'args', ['/bin/ansible-test', '--module-name', 'dpkg_selections',
                                             '--wait', '/tmp/ansible_dpkg_selections_payload']):
            main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0
    # Make sure we record a test
    assert run.call_count >= 1



# Generated at 2022-06-23 03:29:42.117911
# Unit test for function main
def test_main():
    name = 'test_package'
    # No package exists
    no_package = subprocess.STDERR
    no_package = "dpkg-query: no packages found matching %s\n" % name
    # Package exists and is already in requested state
    package_present = subprocess.STDOUT
    package_present = "%s	%s\n" % (name, selection)
    # Package exists and is not in requested state
    package_diff = subprocess.STDOUT
    package_diff = "%s	%s\n" % (name, test_state)

    # Check before state
    old_value = subprocess.Popen(['dpkg', '--get-selections', name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Generated at 2022-06-23 03:29:51.213292
# Unit test for function main
def test_main():
    # Arrange
    def do_not_call_ever(name, *args, **kwargs):
        assert False
    setattr(AnsibleModule, 'get_bin_path', do_not_call_ever)

    def run_command(self, *args, **kwargs):
        if args[0] == ['/usr/bin/dpkg', '--get-selections', 'python']:
            return (0, "python\tinstall", "")
        elif args[0] == ['/usr/bin/dpkg', '--set-selections']:
            return (0, "", "")

    setattr(AnsibleModule, 'run_command', run_command)


# Generated at 2022-06-23 03:29:52.232803
# Unit test for function main
def test_main():
    assert main() == 'main function executed';

# Generated at 2022-06-23 03:30:04.263129
# Unit test for function main
def test_main():
    # First test, no change
    m = AnsibleModule(
        argument_spec = dict(
            name = dict(required = True),
            selection = dict(required = True, choices = ['install', 'hold', 'deinstall', 'purge'])
        ),
        supports_check_mode = True
    )

    dpkg = m.get_bin_path('dpkg', True)
    m.run_command = MagicMock(return_value = (0, "python install", ""))
    m.run_command.side_effect = None

    assert main() == (True, "install", "install")

    # Second test, no change

# Generated at 2022-06-23 03:30:13.893604
# Unit test for function main
def test_main():
    out = get_output(input_data="""
        ansible-mock -m ansible_mock.modules.system.dpkg_selections -a "name=python selection=hold"
        exit 0
    """, output_command=["dpkg --get-selections python"], return_code=0)

    assert "python not present" in out

    out = get_output(input_data="""
        ansible-mock -m ansible_mock.modules.system.dpkg_selections -a "name=python selection=hold"
        exit 0
    """, output_command=["dpkg --get-selections python"], return_code=0, create_data=["python install"])

    assert "python install" in out


# Generated at 2022-06-23 03:30:16.662925
# Unit test for function main

# Generated at 2022-06-23 03:30:17.706204
# Unit test for function main
def test_main():
    assert main() == 1


# Generated at 2022-06-23 03:30:29.605554
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str')
        ),
        supports_check_mode=True,
    )

    # Check parameters
    module.params['name'] == 'python'
    module.params['selection'] == 'hold'

    # Check module functions
    assert module.check_mode == False
    assert module.supports_check_mode == True

    # Execute code
    assert main()

    module.params['name'] == 'python'
    module.params['selection'] == 'purge'

    # Check module functions
    assert module.check_mode == False

# Generated at 2022-06-23 03:30:36.687189
# Unit test for function main
def test_main():

    # Test without any module parameters
    args = dict()

    p = dpkg_selections(args)

    assert p.argument_spec == dpkg_selections.argument_spec
    assert p.supports_check_mode == dpkg_selections.supports_check_mode
    assert p.name == dpkg_selections.name
    assert p.requirements == dpkg_selections.requirements

# Generated at 2022-06-23 03:30:44.964496
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os

    d = {
        "params": {
            "name": "python",
            "selection": "hold"
        },
        "check_mode": False,
    }

    m = AnsibleModule(argument_spec={'name': {'required': True},
                                     'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}},
                      check_invalid_arguments=False,
                      supports_check_mode=True,
                      bypass_checks=True)

    cmds = {}
    cmds['ansible_bin_path.dpkg'] = "echo dpkg"
    m.run_command = run_commands(cmds)

# Generated at 2022-06-23 03:30:45.596968
# Unit test for function main

# Generated at 2022-06-23 03:30:56.628169
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    from io import StringIO
    from ansible.module_utils.basic import AnsibleModule

    test_dir = os.path.dirname(os.path.abspath(__file__)) + '/test'
    sys.path.insert(0, test_dir)
    test_data_dir = os.path.dirname(os.path.abspath(__file__)) + '/test/data'
    old_cwd = os.getcwd()
    os.chdir(test_data_dir)
    module_args = {"name": "ansible", "selection": "install"}
    def get_bin_path(name, required=False):
        return '/usr/bin/%s' % name

# Generated at 2022-06-23 03:30:57.201491
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:31:07.782507
# Unit test for function main
def test_main():
    import mock
    import subprocess
    from ansible.module_utils.basic import AnsibleModule

    # Parse arguments
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = 'test-name'
    selection = 'hold'
    current = 'deinstall'
    changed = True

    # Mock module.run_command
    mock_run_command = mock.Mock(return_value=(0, '', ''))
    mock_run_command.return_value = (0, '%s %s' % (name, current), '')
    module.run_command = mock_

# Generated at 2022-06-23 03:31:08.681430
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:31:19.928541
# Unit test for function main
def test_main():
    payload = dict(
        name="python",
        selection="hold",
        rc=0,
        out="python install",
        err=""
    )

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda args, **kwargs: (payload['rc'], payload['out'], payload['err'])
    module.check_mode = True
    res = main()
    assert (res['changed'] == 'hold' not in res['before'])
    assert (res['before'] == 'not present')

    # diff_mode
    module.diff_mode

# Generated at 2022-06-23 03:31:32.113226
# Unit test for function main
def test_main():
    name = "python"
    selection = 'hold'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-23 03:31:44.053050
# Unit test for function main
def test_main():
    module = AnsibleModule(dict(
        name='python',
        selection='hold',
        supports_check_mode=True,
    ))
    module.run_command = MagicMock(return_value=(0, 'python install\n', ''))
    module.check_mode = False
    module.run_command = MagicMock(return_value=(0, 'python install\n', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

    test_main()

    assert module.run_command.call_args_list[0][0][0] == ['/usr/bin/dpkg', '--get-selections', 'python']
    assert module.run_command.call_count == 2
    assert module.run_command.call_args_list[1][0][0]

# Generated at 2022-06-23 03:31:55.726092
# Unit test for function main
def test_main():
    from mock import patch
    from mock import Mock
    import os

    def mock_run_command(command, check_rc=True):
        mock = Mock()
        if '--get-selections' in command:
            mock.rc = 0
            mock.stdout = 'python install\n'
            mock.stderr = ''
        else:
            mock.rc = 0
            mock.stdout = ''
            mock.stderr = ''
        return mock

    def mock_exit_json(*args, **kwargs):
        assert True

    def mock_fail_json(*args, **kwargs):
        assert False


# Generated at 2022-06-23 03:31:56.384737
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:31:57.018458
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:32:08.037766
# Unit test for function main
def test_main():
    print('')

    # Test AnsibleModule:
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    # Test AnsibleModule.run_command:
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    assert rc == 0
    assert out != b''
    assert err == b''
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=False)
    assert rc == 0
    assert out != b''
    assert err == b''

# Generated at 2022-06-23 03:32:09.208742
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 03:32:09.906399
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:32:10.477129
# Unit test for function main
def test_main():
    assert main() == True

# Generated at 2022-06-23 03:32:20.179129
# Unit test for function main
def test_main():
    import json
    import subprocess
    from test.support import captured_stdout
    # Create the module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    
    # Run main with a test name and selection and check the results
    name = 'python'
    selection = 'hold'
    main()
    assert module.exit_json.call_count == 1
    assert module.params['name'] == name
    assert module.params['selection'] == selection
    with captured_stdout() as stdout:
        json.load(stdout)

# Generated at 2022-06-23 03:32:28.695611
# Unit test for function main
def test_main():
    # Unit tests for main function
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import action_common

    def run(module_args, check=True):
        # Simulate execution
        module = AnsibleModule(**module_args)
        main()
        return module

    # There's no way to override ansible modules so we have to trick it into
    # running our code here.
    #
    # Any tests that need to do something that ansible doesn't expect should
    # mock the relevant functions in a similar way.
    #
    # Example
    # def func():
    #     print("hello")
    # module.func = func
    #

    # We mock the main function so we can check the
    dpkg_selections = action_common.DpkgSelections()
    d

# Generated at 2022-06-23 03:32:32.576008
# Unit test for function main
def test_main():
    # Assigning some value to a variable so that it can be used to pass as argument
    selection_value = 'hold'

    # Calling the dpkg_selections main() method with the required arguments
    rc, out, err = main(selection_value)
    assert rc == 0

# Generated at 2022-06-23 03:32:40.526956
# Unit test for function main
def test_main():
    # This function provides the mock inputs to the main function
    # and stores the outcome of the function so that it will assert
    # the outcome
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleExitModule
    from ansible_collections.fullofbeans.dpkg.plugins.module_utils.dpkg_selections import main

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module

# Generated at 2022-06-23 03:32:51.715306
# Unit test for function main
def test_main():
    module = MockModule({
        'name': 'python',
        'selection': 'hold',
        'check_mode': False,
        'run_command.side_effect': [[0, 'python hold\n', ''], [0, '', '']]
    })

    assert main() == {'changed': True, 'before': 'hold', 'after': 'hold'}
    module.run_command.assert_has_calls([mock.call([mock.ANY, '--get-selections', 'python'], check_rc=True),
                                         mock.call([mock.ANY, '--set-selections'], data='python hold', check_rc=True)])

# Generated at 2022-06-23 03:33:04.968203
# Unit test for function main
def test_main():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.pycompat24 import get_exception

    import sys

    FAKE_STDOUT_NAME = '__stdout__'
    FAKE_STDERR_NAME = '__stderr__'

    old_stdout = sys.stdout
    old_stderr = sys.stderr


# Generated at 2022-06-23 03:33:15.904382
# Unit test for function main
def test_main():
    # Mock for command run_command
    def run_command(self, args, data=None, check_rc=False):
        return {
            "rc": 0,
            "out": "python\thold\t\n",
            "err": ""
        }

    # Mock for function exit_json
    def exit_json(changed, before, after):
        changed_result = False
        before_result = "not present"
        after_result = "hold"
        if changed and before == before_result and after == after_result:
            print("test_main(): module.exit_json() - passed")
        else:
            print("test_main(): module.exit_json() - failed")

    # Mock for function get_bin_path
    def get_bin_path(self):
        return "dpkg"

    src

# Generated at 2022-06-23 03:33:27.457642
# Unit test for function main
def test_main():
    """ Unit tests for function main
    """
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    module.run_command([dpkg, '--get-selections'], check_rc=True)
    rc, out, err = module.run_command([dpkg, '--set-selections'], data="unattended-upgrades hold", check_rc=True)
    rc, out, err = module.run_command([dpkg, '--get-selections'], check_rc=True)
    assert out != ''

# Generated at 2022-06-23 03:33:37.933356
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:33:48.492978
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'])
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-23 03:33:59.453124
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:34:08.365768
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    m_get_bin_path = module.get_bin_path
    m_run_command = module.run_command
    m_exit_json = module.exit_json
    dpkg = '/usr/bin/dpkg'
    name = 'name'
    selection = 'install'
    rc = '0'
    out = 'name hold'
    err = ''
    changed = True
    m_get_bin_path.return_value = dpkg
    m_

# Generated at 2022-06-23 03:34:20.491873
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:34:29.411182
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    attrs = {
        # Intentionally not setting 'required' since the argument is being passed,
        # this test is here to ensure the fact that 'required' is not set, doesn't
        # cause any problems.
        'name': {
            'type': 'str'
        },
        'selection': {
            'type': 'str',
            'choices': [
                'install',
                'hold',
                'deinstall',
                'purge'
            ]
        }
    }
    # Simulate that 'dpkg' is not installed at all on the host and thus raise an exception

# Generated at 2022-06-23 03:34:39.681834
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    mock_run_commands = basic.AnsibleModule.run_command
    mock_run_commands.return_value = (1, 'dpkg --set-selections', '')
    module = main()
    assert module['changed'] == False


# Generated at 2022-06-23 03:34:48.137362
# Unit test for function main
def test_main():
    obj = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Set paramters
    obj.params = {'name': 'ice', 'selection': 'hold'}
    # Test ansible module
    main()

# Generated at 2022-06-23 03:34:49.175620
# Unit test for function main
def test_main():
    assert main()[1]['changed'] == True

# Generated at 2022-06-23 03:34:57.559385
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:35:06.820213
# Unit test for function main
def test_main():

    # unit tests for main.py
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class TestMain(ModuleTestCase):

        def setUp(self):
            super(TestMain, self).setUp()
            self.module = MagicMock(name='ansible_collections.notstdlib.moveitallout.plugins.modules.dpkg_selections.AnsibleModule')
            self.module.run_command = MagicMock(return_value=('', '', ''))
            self.module.check_mode = False

# Generated at 2022-06-23 03:35:07.478798
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 03:35:19.282304
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import *

    class MockAnsibleModule:
        module_args = {'name': 'python', 'selection': 'hold'}
        supports_check_mode = False
        check_mode = False
        diff = False
        params = {'name': 'python', 'selection': 'hold'}

        def get_bin_path(self, x, y):
            return '/usr/bin/dpkg'

        def exit_json(self, changed=changed, before=current, after=selection):
            return

        def run_command(self, cmd, check_rc=True):
            return 0, 'python install', ''
            
    class MockAnsibleModuleCheckMode:
        module_args = {'name': 'python', 'selection': 'hold'}
        supports_check_mode = True

# Generated at 2022-06-23 03:35:20.503268
# Unit test for function main
def test_main():
    output = '{"changed": true, "before": "install"}'

    print(output)
    return output

# Generated at 2022-06-23 03:35:22.266256
# Unit test for function main
def test_main():
    assert main() == 0

# vim: filetype=python

# Generated at 2022-06-23 03:35:32.786296
# Unit test for function main
def test_main():
    import re
    import shlex

    from ansible.module_utils.basic import AnsibleModule

    fixture = "python     deinstall\n"
    fixture += "dpkg       hold\n"

    def _mock_run_command(*args, **kwargs):
        return 0, fixture, ''

    def _mock_get_bin_path(*args, **kwargs):
        return ''

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.params['check_mode'] = False

        def exit_json(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            return _mock_run_command(*args, **kwargs)


# Generated at 2022-06-23 03:35:36.885601
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    rc = main()

# Generated at 2022-06-23 03:35:40.629604
# Unit test for function main
def test_main():
    set_module_args(dict(
        name="b",
        selection="c"
    ))
    result = main()
    assert result['changed'] == True
    assert result['before'] == 'not present'
    assert result['after'] == 'c'

# Generated at 2022-06-23 03:35:41.163635
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:35:55.612551
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    setattr(test_module, 'run_command', lambda *args, **kwargs: ([0, 'sample test', None], None))
    setattr(test_module, 'check_mode', False)
    setattr(test_module, 'get_bin_path', lambda *args, **kwargs: 'test_bin')

    out = main()
    assert out.get('changed') is True
    assert out.get('before') == 'not present'
    assert out.get('after') == 'install'

# Generated at 2022-06-23 03:36:04.990267
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    setattr(module, 'run_command', lambda x, data=None, check_rc=True: (0, 'present','stderr'))
    setattr(module, 'get_bin_path', lambda x, true: '/usr/bin/dpkg')
    current = 'not present'
    module.params['name'] = 'package'
    module.params['selection'] = 'hold'
    main()

# Generated at 2022-06-23 03:36:14.284734
# Unit test for function main
def test_main():
    import sys
    import re

    import ansible.module_utils.ansible_release
    import ansible.module_utils.basic
    import ansible.module_utils.common.utils
    import ansible.module_utils.platform
    import ansible.module_utils.pycompat24

    class MockPlatform(object):
        def __init__(self, arch):
            self.arch = arch


    class MockPopen(object):
        def __init__(self, args, b_in, check=True, rc=0):
            self.args = args
            self.b_in = b_in
            self.stdout = ""
            self.stderr = ""
            self.check_called = check
            self.rc = rc

        def communicate(self):
            args = ' '.join(self.args)

# Generated at 2022-06-23 03:36:24.956957
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-23 03:36:26.021875
# Unit test for function main
def test_main():
    # Test with multiple packages and mixed selections
    pass

# Generated at 2022-06-23 03:36:34.859155
# Unit test for function main
def test_main():
    import os
    import sys
    import dpkg_selections
    import json

    with open("./tests/output/result.json", "r") as result_handle:
        result = json.load(result_handle)

    with open("./tests/input/data.json", "r") as data_handle:
        data = json.load(data_handle)

    imp.load_source('dpkg_selections', './plugins/modules/dpkg_selections')
    dpkg_selections = imp.load_source('dpkg_selections', './plugins/modules/dpkg_selections')


# Generated at 2022-06-23 03:36:44.162306
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(choices=['installed', 'present', 'absent', 'latest'], required=True)
        ),
        supports_check_mode=True,
    )

    test_module.fail_json = lambda **kwargs: None

    test_module.get_bin_path = lambda name, **kwargs: '/usr/bin/' + name if name == 'dpkg' else None

    tmp = ansible.module_utils.basic.ANSIBLE_MODULES_PATH
    ansible.module_utils.basic.ANSIBLE_MODULES_PATH = '.'

# Generated at 2022-06-23 03:36:53.324571
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-23 03:36:54.005560
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 03:37:02.823665
# Unit test for function main
def test_main():

    # Test case 1: name is set to not be present and to be deinstall.
    test_module = {
        'check_mode': True,
        'params': {
            'name': 'test',
            'selection': 'deinstall'
        },
        'run_command': {
            ('dpkg', '--get-selections', 'test'): {
                'rc': 0,
                'stdout': '',
                'stderr': ''
            },
            ('dpkg', '--set-selections'): {
                'rc': 0,
                'stdout': '',
                'stderr': '',
                'data': 'test deinstall'
            }
        }
    }
    test_module = AnsibleModule(**test_module)
    result = main()