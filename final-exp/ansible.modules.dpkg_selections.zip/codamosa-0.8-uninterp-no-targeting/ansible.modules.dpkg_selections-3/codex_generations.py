

# Generated at 2022-06-20 21:40:33.322095
# Unit test for function main
def test_main():
    module, module_mock = AnsibleModuleMock(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ))

    dpkg, dpkg_mock = module_mock.get_bin_path_mock('dpkg', True)
    dpkg.return_value = 'dpkg'

    module.params = {'name': 'python', 'selection': 'hold'}

    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    assert current == 'install'

    rc,

# Generated at 2022-06-20 21:40:42.487340
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'name': 'python',
        'selection': 'hold'
    }, supports_check_mode=True)

    m_run_command = MagicMock(return_value=(0, 'python hold', None))
    m_get_bin_path = MagicMock(return_value='/usr/bin/dpkg')
    with patch.multiple(basic.AnsibleModule, run_command=m_run_command,
                        get_bin_path=m_get_bin_path) as mock:
        main()

    m_run_command.assert_called_once_with([m_get_bin_path.return_value, '--set-selections'],
                                          data="python hold", check_rc=True)


# Generated at 2022-06-20 21:40:47.466938
# Unit test for function main
def test_main():
    # This test requires dpkg-query output on debian.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    assert current == 'hold'

# Generated at 2022-06-20 21:40:58.244118
# Unit test for function main
def test_main():
  import json
  import os
  import shutil
  import tempfile
  from unittest import TestCase, mock
  from ansible.module_utils.basic import AnsibleModule
  from ansible.module_utils.basic import AnsibleModule, json, os, shutil, tempfile, unittest
  module = AnsibleModule(
    argument_spec=dict(
      name=dict(required=True),
      selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,
  )
  dpkg = module.get_bin_path('dpkg', True)
  name = module.params['name']
  selection = module.params['selection']

# Generated at 2022-06-20 21:41:05.750840
# Unit test for function main
def test_main():
    # Mock the module and its arguments
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = 'httpd'
    selection = 'install'
    rc = 0
    out = 'httpd hold'
    err = ''
    rc1 = 0
    out1 = ''
    err1 = ''
    rc2 = 0
    out2 = ''
    err2 = ''
    rc3 = 0
    out3 = 'httpd install'
    err3 = ''
    print(module.run_command)
    dpkg = module.get_bin_path('dpkg', True)


# Generated at 2022-06-20 21:41:10.264891
# Unit test for function main
def test_main():
    p = dict(
        name = 'python',
        selection = 'hold',
    )
    m = AnsibleModule(argument_spec=p)
    assert main() == (True, 'not present', 'hold')

# Generated at 2022-06-20 21:41:14.855522
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    return module

# Generated at 2022-06-20 21:41:25.951442
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:41:39.838060
# Unit test for function main
def test_main():
    import os, sys, shutil, traceback
    os_path = os.path
    my_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.join(my_path, '..'))
    sys.path.append(os.path.join(my_path, '..', 'lib'))
    import dpkg_selections
    tmpdir = os.path.join(my_path, 'tmptest')
    if not os.path.exists(tmpdir):
        os.mkdir(tmpdir)
    orig_cwd = os.getcwd()
    try:
        os.chdir(tmpdir)
        dpkg_selections.main()
    except Exception:
        traceback.print_exc()

# Generated at 2022-06-20 21:41:43.877053
# Unit test for function main
def test_main():
    # Tests
    module.exit_json(changed=True, msg="dpkg_selections module does not have any unit tests", **results)

# Generated at 2022-06-20 21:42:03.686426
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:42:15.173000
# Unit test for function main
def test_main():
    # set up python imports
    import os
    import subprocess
    import sys

    # AnsibleModule argument_spec is not a class, so the super function
    # doesn't exist.
    base_dict = {"name": "python", "selection": "hold"}
    module = AnsibleModule(argument_spec=base_dict)
    module.fail_json = lambda *args: sys.exit(1)
    module.exit_json = lambda *args: sys.exit(0)

    # Test the fail_json method
    try:
        module.fail_json
    except AttributeError:
        print('fail_json not found, returning False')
        return False

    # Test the exit_json method
    try:
        module.exit_json
    except AttributeError:
        print('exit_json not found, returning False')


# Generated at 2022-06-20 21:42:25.745774
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'test-name'
    module.params['selection'] = 'test-selection'
    dpkg = module.get_bin_path('dpkg', True)
    rc = 0
    out = 'test-name\ttest-current'
    err = ''
    check_rc = True
    module.run_command = lambda x, **kwargs: (rc, out, err)
    module.check_mode = False

# Generated at 2022-06-20 21:42:26.759031
# Unit test for function main
def test_main():
    assert(main())

# Generated at 2022-06-20 21:42:39.258927
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        "name": {"required": True},
        "selection": {"required": True, "choices": ["install", "hold", "deinstall", "purge"]}
    }, supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, None, None))
    module.params = {"name": "apache2", "selection": "hold"}
    main()
    module.run_command.assert_called_with(['/usr/bin/dpkg', '--set-selections'], data="apache2 hold", check_rc=True)
    module.exit_json.assert_called_with(changed=False)


# Generated at 2022-06-20 21:42:46.195920
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {'name': 'python', 'selection': 'hold'}
    main()

# Generated at 2022-06-20 21:42:51.596229
# Unit test for function main
def test_main():
    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Check if the control flow execute the module successfully
    assert main() == 'It worked!'

# Generated at 2022-06-20 21:43:07.271351
# Unit test for function main
def test_main():
    test_data = {'name': 'python', 'selection': 'hold'}

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Create a mock for run_command, that returns a tuple of (return code, out, err)
    from ansible.module_utils._text import to_bytes
    module.run_command = Mock()
    module.run_command.return_value = (0, to_bytes('python install'), '')

    # Get the return value of main
    ret = main()

    # Success is a dict type
    assert isinstance(ret, dict)
    # Success

# Generated at 2022-06-20 21:43:21.292856
# Unit test for function main
def test_main():

    import os
    import tempfile

    # We use a temporary directory for the tests to avoid clobbering any actual files
    # in /etc/apt
    tmpdir = tempfile.mkdtemp()
    apt_conf_d = os.path.join(tmpdir, 'apt.conf.d')
    apt_conf = os.path.join(tmpdir, 'apt.conf')

    # Create the directory for apt.conf.d
    os.makedirs(apt_conf_d)

    # Create a fake apt.conf
    with open(apt_conf, 'w') as f:
        f.write('APT::Get::Show-Upgraded "1";')

    # Create a fake apt.conf.d

# Generated at 2022-06-20 21:43:29.246133
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = lambda changed, before, after=None, **kwargs: (changed, before, after)
    result = main()
    assert type(result) == tuple
    assert len(result) == 3

# Generated at 2022-06-20 21:44:07.723389
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = 'test_name'
    selection = 'test_selection'
    out_data = 'test_name test_selection\n'
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-20 21:44:14.757949
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"

    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ))

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    (rc, out, err) = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    return module.exit_json(current=current, changed=changed)

# Generated at 2022-06-20 21:44:26.786142
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='not present'
    )

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )
    module.run_command = run_command
    module.exit_json = exit_json

    return_code = 0
    out = b'python not present\n'
    err = b'\n'

    module.run_command = MagicMock(return_value=(return_code, out, err))
    module.exit_json = MagicMock()

    main()

    assert module.run_command.called

# Generated at 2022-06-20 21:44:41.485637
# Unit test for function main
def test_main():
    import tempfile
    from ansible.utils.path import makedirs_safe

    test_dir = tempfile.mkdtemp()
    test_file = tempfile.mktemp(dir=test_dir)

    # Create a test dpkg that returns uninstalled if the path ends with uninstalled.
    # Otherwise return installed.
    makedirs_safe(test_file + '.dpkg-%s' % '/usr/bin')

# Generated at 2022-06-20 21:44:48.181831
# Unit test for function main
def test_main():

    # We need this to test open_connection, since it relies on WINDOWS_BINARY_SITES
    from ansible.module_utils.basic import AnsibleModule

    dpkg_selections_args = dict(
        name='python',
        selection='hold',
    )

    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch, MagicMock

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)


# Generated at 2022-06-20 21:45:03.907347
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:45:14.722131
# Unit test for function main
def test_main():
    """ Unit test for function main
    """
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test.params['name'] = 'python'
    test.params['selection'] = 'hold'
    test.exit_json = lambda **kwargs: kwargs
    output = main()
    assert isinstance(output['changed'], bool)
    assert isinstance(output['before'], str)
    assert isinstance(output['after'], str)


# Generated at 2022-06-20 21:45:23.205349
# Unit test for function main
def test_main():
    #
    # mock depkg_selections module
    #
    class MockModule:
        #
        # Mock __init__() method
        #
        def __init__(self, argument_spec, check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                     supports_check_mode=False, required_by=None):

            self.argument_spec = argument_spec
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive
            self.required_together = required_together
            self.supports_check_mode = supports_check_mode
            self.required_by = required_by

            self.module = None
            self.fail_json = None
            self.params = None
            self.fail_on_missing

# Generated at 2022-06-20 21:45:35.122490
# Unit test for function main
def test_main():
    # Override AnsibleModule Mock function
    class AnsibleModuleMock(object):
        # Needed to add support for set_options, check_mode and diff_mode
        def __init__(self, *_, **kwargs):
            self.check_mode = kwargs.get('check_mode', False)
            self.diff_mode = kwargs.get('diff_mode', False)
            self.params = {}

        def fail_json(self, **kwargs):
            raise AssertionError(str(kwargs))

        def exit_json(self, **kwargs):
            return kwargs

        def run_command(self, args, **kwargs):
            return 0, 'fake_output', 'fake_error'


# Generated at 2022-06-20 21:45:38.785012
# Unit test for function main
def test_main():
    with patch("ansible.module_utils.basic.AnsibleModule") as module_mock:
        main()
        module_mock['run_command'].assert_called_with([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-20 21:46:07.886572
# Unit test for function main
def test_main():
    function_values = {
            'name'      : 'test_package',
            'selection' : 'hold',

    }
    set_module_args(function_values)
    my_module = AnsibleModule(
            argument_spec = dict(
                    name = dict(required = True),
                    selection = dict(required = True),
            )
    )

    main()
    print(my_module.params['after'])

# Generated at 2022-06-20 21:46:17.914269
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda args, check_rc=False, data=None: (0, '', '')
    dpkg = module.get_bin_path('dpkg', True)
    main()

# Generated at 2022-06-20 21:46:28.179180
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Test true case
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-20 21:46:29.056949
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:46:44.159056
# Unit test for function main
def test_main():
    """ Test behavior of main()
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = 'apt'
    selection = 'hold'
    current_selection = 'deinstall'

    output = dict(changed=False, before='', after='')
    dpkg = {}
    rc = dict(stdout='', stderr='', rc=0)

    # Successfull run: No change needed
    # module.get_bin_path()
    module.get_bin_path = Mock(return_value='/usr/bin/dpkg')
    # module.run_command

# Generated at 2022-06-20 21:46:44.744406
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:46:48.908455
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )
    assert main(module)

# Generated at 2022-06-20 21:46:54.456817
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule
    m.get_bin_path = lambda x, y: '/usr/bin/dpkg'
    m.run_command = lambda x, y, z, check_rc=True: (0, '', '')
    m.check_mode = False
    main()

# Generated at 2022-06-20 21:47:05.507060
# Unit test for function main
def test_main():
    print("unit_test: function main")

    #import sys
    #sys.path.append('./lib/ansible/module_utils')

    #print("sys.path: ", sys.path)

    from ansible.module_utils.basic import AnsibleModule

    my_version = '0.1'

    my_params = {
        'name': 'nano',
        'selection': 'purge',
        'check_mode': True,
        'diff_mode': True
    }

    my_args = {
        'argument_spec': {
            'name': {'required': True},
            'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}
        },
        'supports_check_mode': True,
    }

    my_module

# Generated at 2022-06-20 21:47:09.547530
# Unit test for function main
def test_main():
    rc, out, err = main()
    assert rc == 0
    assert out == {"changed": False, "after": "hold", "before": "hold"}



# Generated at 2022-06-20 21:48:20.964789
# Unit test for function main
def test_main():

    # Mock module input parameters
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Mock module running environment
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO
    import sys

    # Patch module running environment
    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()

# Generated at 2022-06-20 21:48:28.978109
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:48:30.570069
# Unit test for function main
def test_main():
    dpkg_selections = DpkgSelections()


# Generated at 2022-06-20 21:48:38.518014
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params['name'] = 'python'
    module.params['selection'] = 'deinstall'
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-20 21:48:46.352432
# Unit test for function main
def test_main():
    import sys
    import io

    test_input = 'python install\n'
    output = io.StringIO()
    old_stdin = sys.stdin
    sys.stdin = io.StringIO(test_input)
    old_stdout = sys.stdout
    sys.stdout = output
    main()
    sys.stdin = old_stdin
    sys.stdout = old_stdout

    assert output.getvalue() == '{"changed": true, "before": "install", "after": "deinstall"}\n'



# Generated at 2022-06-20 21:49:02.316542
# Unit test for function main
def test_main():
    test_platform = 'debian'
    test_name = 'python'
    test_selection = 'hold'
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = test_module.get_bin_path('dpkg', True)
    set_string = '%s %s' % (test_name, test_selection)

    # Get current settings.
    rc, out, err = test_module.run_command([dpkg, '--get-selections', test_name], check_rc=True)
    if not out:
        current = 'not present'
   

# Generated at 2022-06-20 21:49:11.869457
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:49:12.751466
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 21:49:13.646377
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-20 21:49:25.038240
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import AnsibleVersion
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.process import get_bin_path

    import sys
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.action.dpkg_selections import main


    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.exit_json = sys.exit
            self.run_command = lambda *args, **kwargs: (0, 'dpkg --set-selections', '')
            self.get_bin_path = lambda x, y: get_bin_path(x)

    stdout = sys.stdout
    sys.stdout = out = StringIO