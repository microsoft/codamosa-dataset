

# Generated at 2022-06-20 21:40:32.902802
# Unit test for function main
def test_main():
    import sys
    import os

    from ansible.module_utils.basic import AnsibleModule

    sys.path.append(os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..',
    ))

    cwd = os.getcwd()

    os.chdir(os.path.dirname(os.path.realpath(__file__)))

    dpkg = os.getcwd() + '/dpkg'

    os.chdir(cwd)


# Generated at 2022-06-20 21:40:37.195007
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )

    assert 0 == 1

# Generated at 2022-06-20 21:40:38.032712
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:40:45.151038
# Unit test for function main
def test_main():
    args = dict(
        name="python",
        selection="hold"
    )

    module = AnsibleModule(argument_spec=args)

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)


# Generated at 2022-06-20 21:40:53.330769
# Unit test for function main
def test_main():
    # Need to mock out AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = lambda x: None
    dpkg = module.get_bin_path('dpkg', True)

    # Mock out ansible run_command
    module.run_command = lambda x, **y: (0, '', '')

    # Run main
    main()

# Generated at 2022-06-20 21:41:04.726975
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:16.072534
# Unit test for function main
def test_main():

    # Function to run under test
    def run_module():
        from ansible.modules.system.apt_package import main

        module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ),
            supports_check_mode=True,
        )

        dpkg = module.get_bin_path('dpkg', True)

        name = module.params['name']
        selection = module.params['selection']

        # Get current settings.
        rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
        if not out:
            current = 'not present'
        else:
            current = out

# Generated at 2022-06-20 21:41:16.753822
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:41:17.551339
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:41:26.489505
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={'name': 'test', 'selection': 'install'})
    m.get_bin_path = lambda a, b: '/bin/dpkg'
    m.run_command = lambda a, b: (0, '', '')
    m.check_mode = True
    main()
    m.check_mode = False
    m.run_command = lambda a, b: (0, '', '')
    main()
    m.run_command = lambda a, b: (-1, '', '')
    main()
    m.run_command = lambda a, b: (0, 'test install', '')
    main()
    m.run_command = lambda a, b: (0, 'test hold', '')


# Generated at 2022-06-20 21:41:43.211054
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.basic import AnsibleModule
    import os
    from ansible.module_utils._text import to_bytes

    # Something for the test module to return
    class Args(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-20 21:41:51.487763
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    def run_command_mock(args, check_rc=False, data=None):
        class RunCommandResult():
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err
        if args[4] == 'python':
            if args[2] == '--get-selections':
                return RunCommandResult(0, "python install\n", "")
            elif args[2] == '--set-selections':
                return

# Generated at 2022-06-20 21:41:58.143772
# Unit test for function main
def test_main():
    inout = [
        (None, 'not present'),
        ('install', 'install'),
        ('hold', 'hold'),
        ('deinstall', 'deinstall'),
        ('purge', 'purge')
    ]
    for curr, sel in inout:
        rc, out, err = main(None, curr, sel)
        assert rc == 0
        assert err == ''
        assert out['changed'] == (curr != sel)
        assert out['before'] == curr
        assert out['after'] == sel



# Generated at 2022-06-20 21:42:01.294054
# Unit test for function main
def test_main():
    assert main == "__main__"

# Generated at 2022-06-20 21:42:02.210298
# Unit test for function main
def test_main():
    # done
    return None

# Generated at 2022-06-20 21:42:13.571879
# Unit test for function main
def test_main():

    import os
    import tempfile

    def run_command_mock(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        class rc:
            def __init__(self, rc):
                self.rc = rc
        if args[0] == dpkg:
            if args[1] == '--get-selections':
                if args[2] == 'python':
                    return (0, 'python install', '')
                else:
                    return (0, '', '')
            if args[1] == '--set-selections':
                return (0, '', '')

    def get_bin_path_mock(self, arg, required=False):
        return dpkg


# Generated at 2022-06-20 21:42:25.449602
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:42:27.922248
# Unit test for function main
def test_main():
    out = main()
    print(out)
    assert out['changed'] == True
#test_main()

# Generated at 2022-06-20 21:42:42.318425
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    import subprocess

    argv = sys.argv[1:]

    # Filter obsoleted arguements
    argv = [arg for arg in argv if arg not in ('-p', '--profile')]
    argv = [arg for arg in argv if arg not in ('-v', '--version')]

    # Module setup
    p = subprocess.Popen(['which', 'dpkg'], stdout=subprocess.PIPE)
    dpkg = p.communicate()[0].strip()

    # Unit test
    set_module_args = {
        'name': 'python',
        'selection': 'hold'
    }
    module = AnsibleModule(set_module_args)

    # Get current

# Generated at 2022-06-20 21:42:53.233861
# Unit test for function main
def test_main():
    import os
    import os.path

    import tempfile

    os.path.exists = lambda *args, **kwargs: True
    tempfile.mkstemp = lambda *args, **kwargs: (1, "/tmp")

    class RunCommand:
        def __init__(self, command, check_rc, data):
            self.command = command
            self.check_rc = check_rc
            self.data = data
            self.rc = 0
    class GetBinPath:
        def __init__(self, prog, required):
            self.prog = prog
            self.required = required
            self.path = "dpkg"
    class Module:
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check

# Generated at 2022-06-20 21:43:04.586782
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:43:15.473004
# Unit test for function main
def test_main():
    test_data = dict(
        name='python',
        selection='install',
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(
                choices=['install', 'hold', 'deinstall', 'purge'],
                required=True
            )
        ),
        supports_check_mode=True
    )
    module.params = test_data
    rc, out, err = module.run_command([dpkg, '--get-selections', module.params['name']], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    assert current != module.params['selection']

# Generated at 2022-06-20 21:43:21.108203
# Unit test for function main
def test_main():
    """Test dpkg_selections main function"""

    # Get module object
    dpkg_selections = sys.modules[__name__]

    # Create argument data
    args = {'name': 'python', 'selection': 'hold'}

    # Create ansible module object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        check_invalid_arguments=False
    )

    dpkg_selections.main()

# Generated at 2022-06-20 21:43:21.930838
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:43:32.920427
# Unit test for function main
def test_main():
    """ Unit test for function main. """
    # Mock class object
    class MockModule:
        def __init__(self):
            self.params = {"name": "python", "selection": "hold"}
            self.run_command = None
            self.exit_json = None
            self.check_mode = False
            self.fail_json = None
            self.get_bin_path = None
        def get_bin_path(self, name, required):
            return "/usr/bin/{}".format(name)
        def run_command(self, cmd, check_rc=True):
            if self.run_command is not None:
                return self.run_command(cmd, check_rc)

# Generated at 2022-06-20 21:43:44.547976
# Unit test for function main
def test_main():
    cmd_dpkg_get_selections = ['dpkg', '--get-selections']
    cmd_dpkg_set_selections = ['dpkg', '--set-selections']
    name = 'hello-world'
    selection = 'not present'
    out = 'hello-world hold'
    check_mode = True
    changed = True
    after = 'install'
    before = 'hold'
    module = AnsibleModule(
        argument_spec=dict(
            name=name,
            selection=selection
        ),
        supports_check_mode=check_mode,
    )
    dpkg = module.get_bin_path('dpkg', True)
    module.run_command(cmd_dpkg_get_selections, check_rc=True)
    assert out



# Generated at 2022-06-20 21:43:52.143668
# Unit test for function main
def test_main():
    # Set values for arguments
    name = ''
    selection = ''

    # Create a mock module object
    module_obj = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    
    # Assign the module parameter values
    module_obj.params['name'] = name
    module_obj.params['selection'] = selection
    
    dpkg = None
    
    # Set returns for the module to exit with.
    module_obj.exit_json.return_value = None
    # Execute function main
    main()

# Generated at 2022-06-20 21:43:59.231295
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "name": "python",
        "selection": "hold"
    })

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)


# Generated at 2022-06-20 21:44:07.458487
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module_input = {'name': 'python', 'selection': 'hold'}
    module.params = module_input
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', module.params['name']], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != module.params['selection']

# Generated at 2022-06-20 21:44:07.966575
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:44:46.473071
# Unit test for function main
def test_main():
    """
    This function tests the function main() which calls dpkg_selections.
    :return: Nothing
    """
    test1 = """
- name: test dpkg_selections
  dpkg_selections:
    name: python
    selection: hold
    check_mode: true

- name: test dpkg_selections
  dpkg_selections:
    name: python
    selection: hold
    diff_mode: true

- name: test dpkg_selections
  dpkg_selections:
    name: python
    selection: hold
    platform: debian
    """
    tests = {}
    test_id = 0
    for test in test1.split('\n'):
        test_id += 1

# Generated at 2022-06-20 21:44:56.841687
# Unit test for function main
def test_main():
    #import Ansible module args
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:45:04.208316
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold'
    )
    test_module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,
    )
    test_module.params = args



# vim: et ts=4 sw=4

# Generated at 2022-06-20 21:45:15.241613
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert changed == True

# Generated at 2022-06-20 21:45:22.029841
# Unit test for function main
def test_main():
    """ Unit test for function main """
    # Module specification
    arguments = dict(
        name=dict(required=True, type='str'),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str')
    )
    module = AnsibleModule(argument_spec=arguments, supports_check_mode=True)

    # Test case: first
    test_params={'name': 'python', 'selection': 'hold'}
    module.params=test_params
    main()

# Test cases: nested if-elif-else

# Generated at 2022-06-20 21:45:22.563321
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:45:29.118503
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main()

# Generated at 2022-06-20 21:45:37.248381
# Unit test for function main
def test_main():
    DpkgModule = DpkgModule_Class()

    DpkgModule.run_command = MagicMock(return_value=(0, "", ""))

    DpkgModule.params['name'] = "python"
    DpkgModule.params['selection'] = "hold"

    main()

    DpkgModule.run_command.assert_called_once_with(['/usr/bin/dpkg', '--get-selections', 'python'], check_rc=True)
    DpkgModule.run_command.assert_called_once_with(['/usr/bin/dpkg', '--set-selections'], data="python hold", check_rc=True)
    DpkgModule.exit_json.assert_called_once_with(changed=True, before='not present', after='hold')


# Generated at 2022-06-20 21:45:38.252862
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:45:40.506465
# Unit test for function main
def test_main():
    # set default arguments
    options = dict(
        name=['python'],
        selection=['hold']
    )

    # run main
    main()

# Generated at 2022-06-20 21:46:36.023233
# Unit test for function main
def test_main():
    actionModule = AnsibleModule(argument_spec=dict(name=dict(required=True),selection=dict(required=True,choices=['install', 'hold', 'deinstall', 'purge'])),supports_check_mode=True)
    actionModule.params = {'selection': 'hold', 'name': 'python'}
    dpkg = actionModule.get_bin_path('dpkg', True)
    name = actionModule.params['name']
    selection = actionModule.params['selection']
    #rc, out, err = actionModule.run_command([dpkg, '--get-selections', name], check_rc=True)
    #if not out:
    #    current = 'not present'
    #else:
    #    current = out.split()[1]
    #changed = current != selection
   

# Generated at 2022-06-20 21:46:46.721565
# Unit test for function main
def test_main():
    # Set up argument spec
    module_args = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )

    # Set up mock values
    name = 'python'
    selection = 'hold'

    current = 'purge'

    rc = changed = False

    # Instantiate our module object
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    module.get_bin_path = lambda *args, **kwargs: '/path/to/dpkg'
    module.run_command = lambda *args, **kwargs: (rc, None, None)

    def mock_get_selections(name):
        return (rc, current, None)

    module.run

# Generated at 2022-06-20 21:46:48.023596
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-20 21:47:02.740738
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='install',
    )

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    from ansible.module_utils import basic

    basic.__dict__['module'] = module
    basic.__dict__['check_mode'] = True
    basic.__dict__['changed'] = True
    basic.__dict__['fail_json'] = True
    basic.__dict__['run_command'] = True

    try:
        main()
    except SystemExit as ex:
        return True

    return False

# Generated at 2022-06-20 21:47:03.859884
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-20 21:47:04.437743
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:47:14.401502
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

#     if module.check_mode or not changed:
    module

# Generated at 2022-06-20 21:47:26.887703
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests.mock import patch, MagicMock

    name = 'foo'
    selection = 'bar'
    dpkg_bin = 'dpkg_bin'
    dpkg_rc = 0
    dpkg_out = 'dpkg_out'
    dpkg_err = 'dpkg_err'
    dpkg_ret = (dpkg_rc, dpkg_out, dpkg_err)
    dpkg_selection = 'dpkg_selection'
    dpkg_current = 'dpkg_current'

    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            self.params = { 'name': name, 'selection': selection }

    module = TestAnsibleModule()

    path_exists

# Generated at 2022-06-20 21:47:38.011840
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold',
        check_mode='False',
        diff_mode='False',
        platform='debian'
        )
    FAIL_SOCKET_MSG = 'fake message'
    test_main_connection = Connection('localhost')
    test_main_connection.socket_path = '/foo/bar'
    test_main_connection.transport = 'local'
    test_main_module = AnsibleModule(
        argument_spec=args,
        supports_check_mode=True,
        )
    test_main_module.socket_path = '/foo/bar'
    test_main_dpkg = test_main_module.get_bin_path('dpkg', True)

    test_main_current = 'not present'

# Generated at 2022-06-20 21:47:47.516989
# Unit test for function main
def test_main():
    # Set parameters
    name = 'python'
    selection = 'hold'

    # Set run module arguments
    arguments = {'name': name, 'selection': selection}

    # Set up module object
    module = AnsibleModule(argument_spec=arguments)

    # Set up mock objects
    module.get_bin_path = MagicMock()
    module.get_bin_path.side_effect = lambda cmd, required: '/usr/bin/dpkg'
    rc = MagicMock()
    out = MagicMock()
    err = MagicMock()
    module.run_command = MagicMock()
    module.run_command.return_value = (rc, out, err)
    module.exit_json = MagicMock()
    module.exit_json.side_effect = exit

    # Run main()
    main

# Generated at 2022-06-20 21:49:59.859886
# Unit test for function main
def test_main():

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Hack to get around paths for unit tests
    os.environ['PATH'] = '/bin:/usr/bin'

    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(required=True)
    ))

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current

# Generated at 2022-06-20 21:50:08.043160
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:50:23.444364
# Unit test for function main