

# Generated at 2022-06-20 21:40:30.052966
# Unit test for function main
def test_main():
    import sys
    import subprocess
    # If a command is supplied as a parameter, use it as the dpkg cmd
    # If not, we're supposed to be running in a venv with a dpkg cmd available
    if sys.argv[-1] == 'dpkg':
        sys.exit(subprocess.check_call(sys.argv[-1:] + [
            '--set-selections'],
            stdin=b"python install\n"))
    main()

# Generated at 2022-06-20 21:40:39.456706
# Unit test for function main
def test_main():
    # Make sure module arguments are present
    args = dict(
        platform='debian',
        name='python',
        selection='hold',
        changed=True,
        check_mode=True,
        diff_mode=True
    )
    # Instantiate module object
    m = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
                     supports_check_mode=True,
    )
    # Populate AnsibleModule object from args dict
    m.params.update(args)
    # Call main method
    main()

# Generated at 2022-06-20 21:40:45.955935
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = Mock(return_value=(0, '', ''))
    module.check_mode = False
    module.exit_json = Mock()
    module.params = {'name': 'test', 'selection': 'hold'}
    main()
    module.run_command.assert_called_with([module.get_bin_path('dpkg', True), '--set-selections'], data="test hold", check_rc=True)

# Generated at 2022-06-20 21:40:47.097133
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-20 21:40:47.791749
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:41:01.235339
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os

    if not os.path.exists('/usr/bin/dpkg'):
        raise Exception("Skipping tests because dpkg is not installed.")

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'vim'
    selection = 'hold'

    # Get current settings.

# Generated at 2022-06-20 21:41:05.304572
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.check_mode = True
    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:41:08.608707
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['dpkg_selections', 'name=python', 'selection=hold']
    main()

# Generated at 2022-06-20 21:41:24.052927
# Unit test for function main
def test_main():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except Exception:
        pass
    import os
    import subprocess

    args = {
        "name": "python",
        "selection": "hold"
    }
    dpkg = AnsibleModule(
        argument_spec={
            'name': {
                'required': True,
                'type': 'str',
            },
            'selection': {
                'required': True,
                'choices': ['install', 'hold', 'deinstall', 'purge'],
                'type': 'str',
            },
        },
        supports_check_mode=True,
    )
    dpkg = dpkg._get_bin_path('dpkg')

    name = args["name"]
    selection = args["selection"]

    rc, out, err

# Generated at 2022-06-20 21:41:32.887154
# Unit test for function main
def test_main():
    test = {
        'name': 'python',
        'selection': 'hold',
        'check_mode': False,
        'run_command': {
            'unix': 'dpkg --set-selections',
            'input': 'python hold'
        },
        'results': {
            'changed': True,
            'before': 'not present',
            'after': 'hold'
        }
    }
    module = AnsibleModule(**test)
    assert main()

# Generated at 2022-06-20 21:41:59.453413
# Unit test for function main
def test_main():
    name = 'test_name'
    selection = 'test_selection'
    module_args = dict(
        name=name,
        selection=selection,
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = module_args
    import subprocess
    subprocess.run = lambda args, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs: \
        subprocess.CompletedProcess(args, subprocess.run(args, check_rc=True).stdout, '', 0)
    main()


# Generated at 2022-06-20 21:42:03.607385
# Unit test for function main
def test_main():
    argv = sys.argv
    # Create a real module so we can get defaults.
    setattr(sys, 'argv', [argv[0], '--name=test', '--selection=test'])
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = Mock(return_value=None)
    module.run_command = Mock(return_value=(0, '', ''))
    main()

# Generated at 2022-06-20 21:42:15.082957
# Unit test for function main
def test_main():
    # Test 1
    def test_1(module):
        assert 1 == 1

    # Test 2
    def test_2(module):
        assert 1 == 1

    # Test 3
    def test_3(module):
        assert 1 == 1

    # Test 4
    def test_4(module):
        assert 1 == 1

    # Test 5
    def test_5(module):
        assert 1 == 1

    # Test 6
    def test_6(module):
        assert 1 == 1

    # Test 7
    def test_7(module):
        assert 1 == 1

    # Test 8
    def test_8(module):
        assert 1 == 1

    # Test 9
    def test_9(module):
        assert 1 == 1

    # Test 10
    def test_10(module):
        assert 1 == 1

# Generated at 2022-06-20 21:42:22.768551
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os import dpkg_selections
    import json
    import copy

    # input params
    params = dict(
        name = 'python',
        selection = 'hold',
    )

    # ansible parameters
    ansible = dict(
        check_mode = True,
    )

    # run module
    result = dpkg_selections.main()
    assert result['changed'] == False

# Generated at 2022-06-20 21:42:30.468927
# Unit test for function main
def test_main():
    # run test and check results
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    _name = module.params['name']
    _selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', _name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != _selection

    rc, out, err = module.run_

# Generated at 2022-06-20 21:42:44.333646
# Unit test for function main
def test_main():
    arginfo = check_argument_spec()
    module = AnsibleModule(argument_spec=arginfo)
    assert module.params['name'] == 'python'
    assert module.params['selection'] == 'hold'
    assert module.get_bin_path('dpkg', True) == 'dpkg'
    module.run_command = MagicMock(return_value=(0, 'python hold', ''))
    module.run_command.assert_called_once_with(['dpkg', '--get-selections', 'python'], check_rc=True)
    module.run_command = MagicMock(return_value=None)
    module.exit_json = MagicMock(return_value=None)
    main()

# Generated at 2022-06-20 21:42:54.835975
# Unit test for function main
def test_main():
    # Unit tests:
    # 1. Set the dpkg selection of python to hold
    # 2. Get the current selection of python
    # 3. Check that before and after are the same
    # 4. Check that dpkg command did not fail
    # 5. Check that check_mode is being used
    # 6. Check that the name is being used
    # 7. Check that selection is being used
    # 8. Check that the apt module is being used

    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )

    dpkg = module.get_bin_path('dpkg', True)


# Generated at 2022-06-20 21:42:57.637558
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"
    current = "install"
    assert main() == None

# Generated at 2022-06-20 21:43:05.986100
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = "python"
    selection = module.params['selection']


# Generated at 2022-06-20 21:43:16.709339
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        check_invalid_arguments=False,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:43:43.846439
# Unit test for function main
def test_main():
    # Test typical case
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_ansible_module:
        # Test with normal run
        mock_ansible_module_instance = MagicMock(MockAnsibleModule)
        mock_ansible_module.return_value = mock_ansible_module_instance
        mock_ansible_module_instance.run_command.return_value = (0,
                                                                  "python install\n",
                                                                  '')
        main()
        mock_ansible_module_instance.run_command.assert_called_once_with(
            ['dpkg', '--get-selections', 'python'], check_rc=True)
        assert mock_ansible_module_instance.exit_json.call_count == 1
        assert mock_ans

# Generated at 2022-06-20 21:43:52.198933
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)


# Generated at 2022-06-20 21:43:54.244551
# Unit test for function main
def test_main():
    assert main(get_bin_path=lambda x, y: None)


# Generated at 2022-06-20 21:43:56.078639
# Unit test for function main
def test_main():
   # Set up mocks

   # Call the function
   main()

# Generated at 2022-06-20 21:43:57.888568
# Unit test for function main
def test_main():
    assert 1 == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:44:01.426853
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.exit_json(changed=False, before="before", after="after")



# Generated at 2022-06-20 21:44:07.899679
# Unit test for function main
def test_main():
    mod = "dpkg_selections"
    module = AnsibleModule(mod, 'name: python\nselection: hold')

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = run_command(['dpkg', '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-20 21:44:15.246273
# Unit test for function main
def test_main():
    try:
        # This is a hack to work around Ansible 2.4 deprecated warning for assertEquals
        # that is triggered by importing AnsibleModule:
        # DeprecationWarning: invalid escape sequence \[
        from unittest.case import TestCase
        from unittest import mock
    except ImportError:
        from unittest import TestCase, mock

    class MockedModule(object):
        def __init__(self):
            self.params = {'name': 'python', 'selection': 'install'}
            self.run_command = mock.MagicMock()
            self.run_command.side_effect = [
                (0, 'python hold', ''),
                (0, '', '')
            ]

# Generated at 2022-06-20 21:44:27.880783
# Unit test for function main
def test_main():
    ''' test_main
    This is a test for the main function and of the above modules.
    '''
    
    from ansible.module_utils.basic import AnsibleModule
    
    name = 'python'
    selection = 'hold'
    changed = True
    before = 'not present'
    after = 'hold'
    
    class Args(object):
        def __init__(self, name, selection, changed, before, after):
            self.name = name
            self.selection = selection
            self.changed = changed
            self.before = before
            self.after = after

    setattr(module, "params", {"name": name, "selection": selection})
    setattr(module, "check_mode", False)

# Generated at 2022-06-20 21:44:38.677106
# Unit test for function main
def test_main():
    test_occurences = [
        {
            'name': 'python',
            'selection': 'hold',
            'current': 'not present',
            'changed': True
        },
        {
            'name': 'python',
            'selection': 'hold',
            'current': 'hold',
            'changed': False
        },
        {
            'name': 'python',
            'selection': 'deinstall',
            'current': 'deinstall',
            'changed': False
        }
    ]

    # Test main function
    main(test_occurences)

# Generated at 2022-06-20 21:45:16.205250
# Unit test for function main
def test_main():
    test_package_name = "python"
    test_selection = "hold"
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    print("Testing function")
    dpkg = module.get_bin_path('dpkg', True)
    
    rc, out, err = module.run_command([dpkg, '--get-selections', test_package_name], check_rc=True)
    test_current = out.split()[1]
    test_after = test_selection
    test_changed = test_current != test_after


# Generated at 2022-06-20 21:45:24.000568
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params['name'] = 'python'
    module.params['selection'] = 'hold'

    dpkg = module.get_bin_path('dpkg', True)

    current = 'not present'
    selection = module.params['selection']

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)


# Generated at 2022-06-20 21:45:35.189768
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:45:40.585145
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

# Generated at 2022-06-20 21:45:46.870541
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    setattr(module, "params", {"name": "python", "selection": "hold"})
    setattr(module, "run_command", mock_run_command)
    setattr(module, "get_bin_path", mock_get_bin_path)
    assert main() == True


# Generated at 2022-06-20 21:45:51.688090
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params = {'name': 'python', 'selection': 'deinstall'}
    main()

# Generated at 2022-06-20 21:46:01.189236
# Unit test for function main
def test_main():
    """ Check that the output of the main function is correct given known input """

    # Set up the test input
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = 'test_name'
    selection = 'hold'

    # Set up the return values
    (rc, out, err) = (0, 'name state\ntest_name hold', '')

    # Call the main function
    with patch.object(module, 'run_command', return_value=(rc, out, err)):
        _name, _

# Generated at 2022-06-20 21:46:11.285340
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ),
            supports_check_mode=True,
        )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:46:12.936406
# Unit test for function main
def test_main():
    out = main()
    assert out == 0

# Generated at 2022-06-20 21:46:25.697520
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import errno
    import os
    import sys

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    def _test_exit(rc, msg=''):
        rc = os.EX_OK

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class TestException(Exception):
        pass

    class TestDpkgModule(basic.AnsibleModule):
        """Test dpkg module"""

        def __init__(self, data=None, **kwargs):
            if data:
                kwargs.update(data)

# Generated at 2022-06-20 21:47:43.885316
# Unit test for function main
def test_main():
    import os
    import pytest
    import json
    os.environ['ANSIBLE_REMOTE_TMP'] = "/tmp"
    os.environ['ANSIBLE_MODULE_UTILS'] = "/tmp"
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = "False"
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module._ansible_no_log = True
    module.params['name'] = "bind9"
    module.params['selection'] = "hold"

# Generated at 2022-06-20 21:47:45.585838
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:47:56.239703
# Unit test for function main
def test_main():
    import mock
    want = '{"changed": true, "invocation": {"module_name": "ansible.builtin.dpkg_selections"}}'
    with mock.patch.object(AnsibleModule, 'run_command') as mock_run_cmd:
        with mock.patch.object(AnsibleModule, 'get_bin_path') as mock_get_bin_path:
            mock_get_bin_path.return_value = '/bin/dpkg'
            mock_run_cmd.side_effect = [
                (0, 'mock_name1 install', None),
                (0, None, None),
            ]

# Generated at 2022-06-20 21:48:05.739712
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:48:06.576274
# Unit test for function main
def test_main():
    pass

main()

# Generated at 2022-06-20 21:48:10.558189
# Unit test for function main
def test_main():
    test_arguments = {
        'name': 'python',
        'actions': "hold",
        'check_mode': False,
        'diff_mode': False
    }

    module = AnsibleModule(
        argument_spec=test_arguments
    )

    main()

# Generated at 2022-06-20 21:48:15.735485
# Unit test for function main
def test_main():
    out = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert out

# Generated at 2022-06-20 21:48:24.150959
# Unit test for function main
def test_main():
    # Get the module object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Module specific arguments

    ########
    # Mocks
    ########

    # Mocked methods
    def get_bin_path(self, arg, required=False):
        return '/usr/bin/dpkg'

    def run_command(module, args, check_rc=True):
        return 0, '', ''

    module.get_bin_path = get_bin_path
    module.run_command = run_command

    # Test default behavior

# Generated at 2022-06-20 21:48:38.962669
# Unit test for function main
def test_main():
    ''' test for function main '''
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    test_module.params['name'] = 'python'
    test_module.params['selection'] = 'hold'

    val = main()
    assert val is not None


# Generated at 2022-06-20 21:48:47.094500
# Unit test for function main
def test_main():
    import inspect
    import copy
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda args, **kw: (0, inspect.getargspec(main).args, None)
    if main() is None:
        assert copy.copy(module.params) == {'check_mode': False, 'diff': False,
            'name': 'python', 'selection': 'hold', 'warnings': []}
