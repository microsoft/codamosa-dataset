

# Generated at 2022-06-20 21:40:31.770240
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:40:41.642020
# Unit test for function main
def test_main():
    mock_module = Mock(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    mock_module.run_command.return_value = (0, "python install\n", "")
    dpkg_selections.main()
    mock_module.fail_json.assert_called_with(msg="Failed to find expected dpkg binary in path")
    mock_module.get_bin_path.return_value = "/usr/bin/dpkg"
    mock_module.params = dict(
        name="python",
        selection="hold",
    )
    dpkg_selections.main()

# Generated at 2022-06-20 21:40:42.143777
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:40:45.361279
# Unit test for function main
def test_main():
    assert main([ 'dpkg', '--get-selections', 'python' ], 'hold', '') == {'changed': True, 'before': 'hold', 'after': ''}

# Generated at 2022-06-20 21:40:48.103073
# Unit test for function main
def test_main():
    (rc, out, err) = main()
    if rc != 0:
        assert False, 'Main'
    else:
        assert True, 'Main'

# Run unit tests
print(test_main())

# Generated at 2022-06-20 21:40:49.486781
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-20 21:41:01.755204
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    
    if module.check_mode or not changed:
        module

# Generated at 2022-06-20 21:41:02.428478
# Unit test for function main
def test_main():
    print("Test main here")
    print("Test main ends here")

# Generated at 2022-06-20 21:41:03.006368
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:41:09.208790
# Unit test for function main
def test_main():
    params = {
        'name': 'python',
        'selection': 'hold'
    }
    check_mode = False
    check_rc = True
    run_command_data = "python hold"
    run_commands_exist = True
    module_result = {
        'changed': 'True',
        'before': 'not present',
        'after': 'hold'
    }
    module_exit = 'True'
    support_check_mode = True
    supports_check_mode = True
    check_mode_result = {
        'changed': 'True',
        'before': 'not present',
        'after': 'hold'
    }
    exit_json_data = 'True'
    changed = True
    current = 'not present'
    selection = 'hold'
    params_name = 'python'


# Generated at 2022-06-20 21:41:17.282217
# Unit test for function main
def test_main():
    assert 1 == 1, "This test always succeeds"

# Generated at 2022-06-20 21:41:27.140161
# Unit test for function main
def test_main():
    # Unit test for function main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:41:35.933542
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection


# Generated at 2022-06-20 21:41:42.308718
# Unit test for function main
def test_main():
    from ansible import context
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible_module_dpkg_selections import main, EXAMPLES

    if not get_bin_path('dpkg', required=True):
        return

    with tempfile.NamedTemporaryFile() as f:
        f.write(b'dpkg --get-selections |grep python')
        f.flush()
        os.chmod(f.name, 0o755)


# Generated at 2022-06-20 21:41:43.877022
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-20 21:41:44.613645
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:41:54.541185
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.fail

# Generated at 2022-06-20 21:42:00.411006
# Unit test for function main
def test_main():
    class MockModule(object):
        def __init__(self):
            self.params = {
                'name': 'joe',
                'selection': 'hold'
            }
            self.run_command_calls = []
            self.exit_json_calls = []
            self.exit_json_call_count = 0

        def run_command_success(self, command, check_rc):
            if command == [ dpkg, '--set-selections' ]:
                return 0, '', ''
            elif command == [ dpkg, '--get-selections', 'joe' ]:
                if self.run_command_calls.count('get_selections') == 0:
                    self.run_command_calls.append('get_selections')
                    return 0, 'joe install', ''
               

# Generated at 2022-06-20 21:42:11.344311
# Unit test for function main
def test_main():
    import unittest
    import difflib
    import os
    import sys
    # Needed to ensure we test this plugin on a debian system
    sys.modules['platform'] = 'debian'

    class TestPLugin(unittest.TestCase):
        def call_plugin(self, args, check_rc=False):
            out, err = self.module.run_command(args, check_rc=check_rc)
            self.diff.append(' '.join(args))
            if out:
                out = '\n'.join(out)
                self.diff.append(''.join(difflib.ndiff(out.splitlines(1), self.stdout.splitlines(1))))
                self.assertEqual(out, self.stdout)
            if err:
                err = '\n'.join(err)
               

# Generated at 2022-06-20 21:42:11.882846
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 21:42:23.283867
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:42:25.281187
# Unit test for function main
def test_main():
    rc, out, err = dpkg_selections_main()
    assert not rc
    assert err == ""
    assert out != ""

# Generated at 2022-06-20 21:42:33.987605
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Mock dpkg binary
    module.get_bin_path = lambda x: '/usr/bin/' + x

    # Mock module.run_command()
    def run_command(self, args, check_rc=True):
        rc = 0 if args[1] == '--get-selections' else 1
        out = 'python install' if args[1] == '--get-selections' else ''

# Generated at 2022-06-20 21:42:43.329399
# Unit test for function main
def test_main():
    test_module = Module()
    test_module.params = dict(name='python', selection='hold')
    test_bin_paths = dict(dpkg='/usr/bin/dpkg')
    test_module.run_command = lambda args, **kwargs: (0, 'python install', '')
    code, out, err = test_module.perform_operation('/usr/bin/dpkg', '--get-selections', 'python')
    assert code == 0



# Generated at 2022-06-20 21:42:50.676234
# Unit test for function main
def test_main():
    import os
    import dpkg_selections

    # create mock arguments
    mock_args = {"name": "python", "selection": "install"}

    # mock module
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule(argument_spec={'name': {'required': True}, 'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}})

    # Mock other module attributes
    dpkg = "dpkg"

    # make the call
    dpkg_selections.main()

    # Create mock module.run_command for the return value
    import subprocess

# Generated at 2022-06-20 21:42:58.150412
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:10.170772
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'install'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    current = out.split()[1]
    changed = current != selection
    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-20 21:43:13.124390
# Unit test for function main
def test_main():
    exit = main()
    assert exit["before"] == "deinstall"
    assert exit["after"] == "hold"
    assert exit["changed"] == True

# Generated at 2022-06-20 21:43:18.351543
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:43:28.079086
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'python'
    module.params['selection'] = ['install', 'hold', 'deinstall', 'purge']
    dpkg = module.get_bin_path('dpkg', True)
    assert (dpkg == '/usr/bin/dpkg')


# Generated at 2022-06-20 21:44:00.366760
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:44:07.744188
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        check_invalid_arguments=False,
    )
    name = 'python'
    selection = 'hold'

    module.params['name'] = name
    module.params['selection'] = selection

    # Define function-level variables
    rc = 1
    out = """python	hold"""
    err = None

    module.run_command = MagicMock(return_value=(rc, out, err))

    # Define local variables
    changed = True
    current = 'unknown'

    main()
    module.run_command.assert_called

# Generated at 2022-06-20 21:44:15.142616
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_

# Generated at 2022-06-20 21:44:27.797562
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ), supports_check_mode=True,)

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:44:41.400017
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-20 21:44:48.139913
# Unit test for function main
def test_main():
    import json
    import os
    import sys
    import tempfile

    # 1. save old cwd, go to tempdir
    cwd = os.getcwd()
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # 2. create a fake ansible module called 'ansible_module_main_name'
    with open('ansible_module_dpkg_selections.py', 'w') as f:
        f.write("#!/usr/bin/python\n")
        f.write("# -*- coding: utf-8 -*-\n")
        f.write("\n")

# Generated at 2022-06-20 21:45:03.836416
# Unit test for function main
def test_main():
    import mock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.test.unit.modules.test_package.test_package import test_check_mode, test_check_mode_packages, test_get_bin_path_nonexistent, test_get_bin_path_success, test_run_command_failure, test_run_command_success
    from ansible.test.unit.modules.test_package.test_package import test_run_command_check_mode_success, test_run_command_check_mode_failure, test_run_command_check_mode_rc_changed, test_run_command_check_mode_rc_not_changed
    def test_exit_json(*args, **kwargs):
        assert True


# Generated at 2022-06-20 21:45:15.413459
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.dicts import merge_hash
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.math import safe_div
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils._text import to_text

# Generated at 2022-06-20 21:45:23.591436
# Unit test for function main
def test_main():
    from sys import modules
    from ansible.module_utils.basic import AnsibleModule

    # Fake out dpkg.
    dpkg = ['dpkg']

    # Fake out os.path.isfile.
    def isfile(file):
        return True
    os.path.isfile = isfile

    # Fake out action_common_attributes.
    action_common_attributes = None
    modules['action_common_attributes'] = action_common_attributes

    # Fake out module.
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Fake out get_bin_path.
    def get_bin_path(binary, required):
        return dpkg
    module.get_bin_path = get_bin_path

    # Fake out check_mode.

# Generated at 2022-06-20 21:45:25.132146
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:46:13.596826
# Unit test for function main
def test_main():
  module = AnsibleModule(
              argument_spec=dict(
                  name=dict(required=True),
                  selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
              ),
              supports_check_mode=True
          )

  dpkg = module.get_bin_path('dpkg', True)
  name = 'wget'
  selection = 'hold'

  rc,out,err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
  current = out.split()[1]
  changed = current != selection
  if(changed):
      print("PRE-CONDITION : ",current," ",selection," ",changed)


# Generated at 2022-06-20 21:46:26.020471
# Unit test for function main
def test_main():
    import tempfile
    (tempfd, tempfilename) = tempfile.mkstemp()
    os.write(tempfd, '')
    os.close(tempfd)
    class mock_module(object):
        check_mode = False
        _ansible_check_mode = False
        diff = None
        _ansible_diff = None
        results = None
        changed = True
        def __init__(self):
            self.params = {}
            self.params['selection'] = 'install'
            self.params['name'] = 'package'
        def get_bin_path(self, arg, required):
            return '/bin/dpkg'
        def run_command(self, arg, data, check_rc=False):
            return (0, 'package install', '')

# Generated at 2022-06-20 21:46:36.474744
# Unit test for function main
def test_main():
    dpkg = '/usr/bin/dpkg'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.get_bin_path = lambda name, required=False: dpkg
    module.run_command = lambda cmd, **kw: (0, 'package not present', '')

    # Test with no change.
    module.params['name'] = 'python'
    module.params['selection'] = 'sel'
    main()
    assert module.json_dict['changed'] == False
    assert module.json_dict['before'] == 'not present'

# Generated at 2022-06-20 21:46:46.833520
# Unit test for function main
def test_main():
    cloud_portal = module_main(['python', 'install'])
    assert cloud_portal == {u'changed': True}


# Generated at 2022-06-20 21:46:58.831867
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:47:03.580814
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    rc, out, err = run_command([dpkg, '--get-selections', name], check_rc=True)
    # Get current settings.
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection
    assert changed
    assert current == 'install'
    assert selection == 'hold'
    assert out == name + '\t' + current

# Generated at 2022-06-20 21:47:14.008626
# Unit test for function main
def test_main():
    # Instantiate mock module object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    rc, out, err = module.run_command(['which', 'dpkg'], check_rc=True)
    dpkg = out.splitlines()[0]

    name = "python"
    selection = "hold"

    # Mock current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-20 21:47:26.735918
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:47:40.777768
# Unit test for function main
def test_main():
    # Importing module block creates a global variable module and sets the options passed to it
    import ansible.modules.system.dpkg_selections as dpkg_selections
    dpkg_selections.main()
    assert module.params['name'] == "python"
    assert module.params['selection'] == "hold"
    assert module.check_mode == True
    assert module.params['platforms'] == "debian"
    assert module.params['ACTION'] == "get"
    assert module.params['ADDRESSFAMILY'] == "any"
    assert module.params['CONNECTHOST'] == "localhost"
    assert module.params['CONNECTPORT'] == 3000
    assert module.params['HEADERS'] == {"key":"value"}
    assert module.params['RETURN'] == "text"

# Generated at 2022-06-20 21:47:46.899967
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    m.run_command = MagicMock(return_value=(0, 'python 1', ''))
    main()
    m.run_command.assert_called_with([m.get_bin_path('dpkg', True), '--set-selections'], data="python 1", check_rc=True)

# Generated at 2022-06-20 21:50:01.325092
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    class Args:
        def __init__(self, name, selection):
            self.name = name
            self.selection = selection
    args = Args('python', 'hold')
    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

# Generated at 2022-06-20 21:50:08.904017
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = mod.get_bin_path('dpkg', True)

    name = 'python'
    mod.params['name'] = name
    selection = 'hold'
    mod.params['selection'] = selection

    rc, out, err = mod.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-20 21:50:16.099529
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.run_command.return_value = (0, "", "")
    main()