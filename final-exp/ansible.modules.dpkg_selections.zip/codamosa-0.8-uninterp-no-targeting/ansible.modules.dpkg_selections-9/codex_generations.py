

# Generated at 2022-06-20 21:40:32.250281
# Unit test for function main
def test_main():
    import pytest
    from ansible.modules.system.dpkg_selections import main
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'apache2'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current

# Generated at 2022-06-20 21:40:32.862709
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:40:42.381772
# Unit test for function main
def test_main():
    rc = mule.run_command.mock()
    sys.exit = mock.Mock()
    dpkg = mock.Mock()
    dpkg.__name__ = 'dpkg'
    module = mock.Mock()

    module.params = {'name': 'foo', 'selection': 'deinstall'}
    dpkg.return_value = 'dpkg'

    # no current setting
    mule.run_command.return_value = (0, '', '')
    main()
    mule.run_command.assert_called_with([dpkg, '--get-selections', module.params['name']], check_rc=True)
    assert module.check_mode == False
    assert module.params['name'] == 'foo'
    assert module.params['selection'] == 'deinstall'

# Generated at 2022-06-20 21:40:48.302066
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # This test only checks the returned data, not the actual change.
    module.exit_json(changed=True, before='hold', after='install')

# Generated at 2022-06-20 21:40:53.138711
# Unit test for function main
def test_main():
    import os
    import argparse
    import sys

    class Args(object):
        name = 'python'
        selection = 'hold'

    args = Args()
    args.__dict__ = {k:v for k, v in args.__dict__.items() if v is not None}
    main()

# Generated at 2022-06-20 21:40:53.969970
# Unit test for function main
def test_main():
  main()


# Generated at 2022-06-20 21:41:05.151506
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:16.397530
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:26.702608
# Unit test for function main
def test_main():
    import unittest
    import logging
    import sys
    import os

    class AnsibleFailJson(Exception):
        pass

    class AnsibleExitJson(Exception):
        pass

    class TestException(Exception):
        pass

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.mock_module_helper = patch.multiple(basic.AnsibleModule,
                                                     exit_json=exit_json, fail_json=fail_json)
            self.mock_module_helper.start()
            self.addCleanup(self.mock_module_helper.stop)
            self.mock_get_bin_path = patch('ansible.module_utils.basic.get_bin_path')
            self.mock_get_bin_path.start()

# Generated at 2022-06-20 21:41:34.533777
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.check_mode = False
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    main()

# Generated at 2022-06-20 21:41:43.651093
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-20 21:41:53.518533
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    current = 'hold'
    changed = True
    dpkg = '/usr/bin/dpkg'

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.get_bin_path = lambda x: dpkg

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    # test check_mode


# Generated at 2022-06-20 21:42:04.696774
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:42:06.253659
# Unit test for function main
def test_main():
    func = main
    assert func


# Generated at 2022-06-20 21:42:18.511869
# Unit test for function main
def test_main():
    class AttributeDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttributeDict, self).__init__(*args, **kwargs)

        def __getstate__(self):
            return self

        def __setstate__(self, state):
            self.update(state)

        def __getattr__(self, item):
            return self.__getitem__(item)

        def __setattr__(self, key, value):
            self.__setitem__(key, value)

    setattr(AnsibleModule, 'params', AttributeDict({'name':'python','selection':'hold'}))
    setattr(AnsibleModule, 'check_mode', True)

# Generated at 2022-06-20 21:42:28.760066
# Unit test for function main
def test_main():
    import pytest
    from ansible.modules.packaging.os import dpkg_selections
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils._text import to_bytes

    python_name = "python"
    current_set = "python\thold\n"
    hold_set = "python\thold\n"
    install_set = "python\tinstall\n"
    deinstall_set = "python\tdeinstall\n"
    purge_set = "python\tpurge\n"
    dpkg_old_ver = "1.17.5"
    dpkg_new_ver = "1.17.6"

    mock_run_command = lambda *args, **kwargs: (0, current_set, "")

# Generated at 2022-06-20 21:42:43.127907
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:42:48.791545
# Unit test for function main
def test_main():
    print("Running unit test for function main")
    # Init AnsibleModule object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    rc, out, err = module.run_command('dpkg --get-selections', check_rc=True)
    assert(rc == 0)

# Generated at 2022-06-20 21:42:57.064360
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert changed == False

# Generated at 2022-06-20 21:43:09.120592
# Unit test for function main
def test_main():
    import json

# Generated at 2022-06-20 21:43:32.567810
# Unit test for function main
def test_main():
    # Create the module mock
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    # Set defaults for test
    module.params['name'] = 'test'
    module.params['selection'] = 'hold'

    # Setup basic unit test data structure
    results = {
        'changed': False,
        'before': 'a',
        'after': 'a'
    }

    # Set up the module for testing
    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'a', 'b')
    module.get_bin_path = MagicMock()
    module.get_

# Generated at 2022-06-20 21:43:33.019819
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-20 21:43:35.674785
# Unit test for function main
def test_main():
    import ansible_collections.ansible.community.tests.unit.plugins.module_utils.action.test_dpkg_selections as unit

    current = 'not present'
    selection = 'hold'
    changed = True
    unit.test_main(current, selection, changed)

# Generated at 2022-06-20 21:43:37.577285
# Unit test for function main
def test_main():
    """Unit test for function main"""
    assert 1 == 1


# Generated at 2022-06-20 21:43:38.381008
# Unit test for function main
def test_main():
  assert main() == None

# Generated at 2022-06-20 21:43:45.088720
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        'name': 'python',
        'selection': 'hold',
    },
    supports_check_mode=True)

    test_module.run_command = MagicMock(
        name='run_command',
        return_value=(0, 'python install', ''))

    test_module.get_bin_path = MagicMock(
        name='get_bin_path',
        return_value='/usr/bin/dpkg')

    test_main()
    assert test_module.run_command.called
    assert test_module.get_bin_path.called

# Generated at 2022-06-20 21:43:53.280073
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:54.064149
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:43:59.785894
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert module != None

# Generated at 2022-06-20 21:44:00.736515
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:44:45.501883
# Unit test for function main
def test_main():
    import json
    import sys

    test_data = """
    {
        "ansible_facts": {},
        "changed": false,
        "check_mode": false,
        "failed": true,
        "failed_when_result": false,
        "invocation": {
            "module_args": {
                "name": "test",
                "selection": ""
            }
        }
    }
    """

    test_dict = json.loads(test_data)
    sys.argv = [ 'ansible-test', '-t', 'unit', '-f', 'json', '-c', 'local', '-m', 'dpkg_selections', '-a', '{0}'.format(test_data) ]

    print("ARGV : %s" % sys.argv)
    main()

# Generated at 2022-06-20 21:44:46.841110
# Unit test for function main
def test_main():
    rc, out, err = main({'name': 'python', 'selection': 'hold'})
    assert rc == 0

# Generated at 2022-06-20 21:44:48.275392
# Unit test for function main
def test_main():
  assert main() == None

# Generated at 2022-06-20 21:44:51.693232
# Unit test for function main
def test_main():
    # After module tests are written, run with:
    # ansible-test units --python -v dpkg_selections
    pass

# Generated at 2022-06-20 21:45:05.486719
# Unit test for function main
def test_main():

    # Test all options
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock(return_value='/usr/bin/dpkg')
    main()

    # Test with changed
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_

# Generated at 2022-06-20 21:45:17.245270
# Unit test for function main
def test_main():
    test_args = {
        'name': 'python',
        'selection': 'hold'
    }
    test_result = {
        'changed': True,
        'before': 'install',
        'after': 'hold'
    }
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ))
    module.exit_json = exit_json
    dpkg_selections.main()
    assert exit_json.call_args == call(test_result)

# Generated at 2022-06-20 21:45:28.273627
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    rc, out, err = module.run_command('/usr/bin/dpkg --get-selections python', check_rc=True)
    assert out == "python\tinstall\n"
    assert rc == 0
    rc, out, err = module.run_command('/usr/bin/dpkg --set-selections', data="python hold", check_rc=True)
    assert rc == 0

# Generated at 2022-06-20 21:45:36.956914
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:45:43.933493
# Unit test for function main
def test_main():
    # Test successful without changes.
    data = dict(name='bash', selection='install')
    rc, out, err = main(data=data, check_mode=True)
    assert out['changed'] == False
    data = dict(name='bash', selection='hold')
    rc, out, err = main(data=data, check_mode=True)
    assert out['changed'] == True
    assert out['before'] == 'install'
    assert out['after'] == 'hold'

# Generated at 2022-06-20 21:45:53.584854
# Unit test for function main
def test_main():
    """ Creates a mock module and calls main()
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import tempfile
    import shutil
    import os

    filename = tempfile.mktemp()
    open(filename, 'a').close()  # Create file

    mock_module = AnsibleModule(argument_spec={'name':{'required':True}, 'selection':{'choices':[], 'required':True}}, supports_check_mode=True)
    mock_module.run_command = MagicMock(return_value=(0, '', b''))
    mock_module.get_bin_path = MagicMock(return_value=filename)

    # Set module args

# Generated at 2022-06-20 21:46:44.192068
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:46:45.449395
# Unit test for function main
def test_main():
    # TODO: mock the module and call main()
    pass

# Generated at 2022-06-20 21:46:52.733847
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command') as run_command:
        with patch.object(AnsibleModule, 'exit_json') as exit_json:
            # Mock
            run_command.return_value = 0, 'python install', None
            module = AnsibleModule(argument_spec={'name':{'required':True},
                                                  'selection':{'choices':['install', 'hold', 'deinstall', 'purge'], 'required':True},
            })
            module.check_mode = False
            module.params = {'name': 'python', 'selection': 'install'}

            # Test for check mode
            main()
            module.check_mode = True
            main()

            # Test for real change
            module.check_mode = False

# Generated at 2022-06-20 21:46:53.543435
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:47:05.298140
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system.dpkg_selections import main
    import json
    import os.path
    import subprocess

    f = open(os.path.join(os.path.dirname(__file__), "dpkg_selections.json"), 'r')
    data = json.load(f)
    f.close()

    [rc, out, err] = subprocess.getstatusoutput("dpkg --get-selections %s" % data['ansible_facts']['ansible_hostname'])
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]


# Generated at 2022-06-20 21:47:19.918836
# Unit test for function main
def test_main():
    import sys
    import json
    import copy

    # Unit tests require mock.
    try:
        from unittest.mock import MagicMock, patch, PropertyMock
    except ImportError:
        try:
            from mock import MagicMock, patch, PropertyMock
        except ImportError:
            print(json.dumps({
                'failed': True,
                'msg': 'python-mock is required for tests'
            }))
            raise ImportError

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.result = {
                'changed': False,
                'stdout': '',
            }


# Generated at 2022-06-20 21:47:31.575561
# Unit test for function main
def test_main():
    module = AnsibleModule(
    argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:47:42.034920
# Unit test for function main
def test_main():
    mock_module = MagicMock()
    mock_module.params = {'name': 'python', 'selection': 'hold'}
    mock_module.check_mode = False

    mock_module.check_mode = False
    mock_run_command = MagicMock(return_value=(0, 'python hold', ''))
    mock_module.run_command = mock_run_command

    main()
    mock_run_command.assert_has_calls([call([u'dpkg', '--get-selections', 'python'], check_rc=True),
                                       call([u'dpkg', u'--set-selections'], data='python hold', check_rc=True)],
                                      any_order=True)

# Generated at 2022-06-20 21:47:42.616156
# Unit test for function main
def test_main():
    assert main() != 0

# Generated at 2022-06-20 21:47:48.062886
# Unit test for function main
def test_main():
    module = AnsibleModule({}, supports_check_mode=True)
    package_name = ("python3")
    package_selection = ("install")
    dpkg_bin_path = ("/usr/bin/dpkg")
    return_code = (0)
    module.run_command([dpkg_bin_path, '--get-selections', package_name], check_rc=True)
    module.run_command([dpkg_bin_path, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    assert main() == None


# Generated at 2022-06-20 21:50:19.936776
# Unit test for function main
def test_main():
    from mock import patch
    from ansible.modules.system.dpkg_selections import main

    def run_command_mock(args, check_rc=True):
        if args[0] == 'dpkg' and args[1] == '--get-selections' and args[2] == 'python':
            return 0, 'python        install', ''
        if args[0] == 'dpkg' and args[1] == '--set-selections':
            assert args[-1] == 'python hold'
            return 0, '', ''

    def exit_json_mock():
        raise SystemExit('exit_json')

    def fail_json_mock(msg):
        raise SystemExit(msg)
