

# Generated at 2022-06-20 21:40:29.194266
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )

    name = 'foo'
    selection = 'hold'

    out = 'foo install\n'
    rc = 0
    err = ''

    assert out == main(module, name, selection)

    assert out == 'foo hold\n'


# Generated at 2022-06-20 21:40:31.580218
# Unit test for function main
def test_main():
    assert main() == 'module'

# Generated at 2022-06-20 21:40:40.913050
# Unit test for function main
def test_main():
    args = dict(name='python', selection='hold')
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
        supports_check_mode=True,
    )
    setattr(module, 'params', args)
    setattr(module, 'check_mode', True)
    main()
    assert module.exit_json.call_args[1]['changed'] == True
    assert module.exit_json.call_args[1]['before'] == 'not present'
    assert module.exit_json.call_args[1]['after'] == 'hold'

# Generated at 2022-06-20 21:40:52.260561
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:03.710189
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = ansible_module.get_bin_path('dpkg', True)

    name = ansible_module.params['name']
    selection = ansible_module.params['selection']

    # Get current settings.
    rc, out, err = ansible_module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-20 21:41:15.546416
# Unit test for function main
def test_main():
    test_params = [{
        "name": "python",
        "selection": "hold",
    }]

    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils import basic

    import sys
    sys.path.append('install')

    mock_shell = MagicMock(spec=basic.AnsibleModule.run_command)
    with patch.dict('sys.modules', {'ansible.module_utils.basic': basic, 'ansible.module_utils.basic.AnsibleModule': AnsibleModule, 'ansible.module_utils.basic.AnsibleModule.run_command': mock_shell}):
        from dpkg_selections import *


# Generated at 2022-06-20 21:41:20.772277
# Unit test for function main
def test_main():
    out = main_ansible_module({'name': 'python', 'selection': 'hold'}, exit_json_called=False)
    assert out['changed'] == False
    assert out['before'] == 'hold'
    assert out['after'] == 'hold'


# Generated at 2022-06-20 21:41:22.281409
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-20 21:41:30.355316
# Unit test for function main
def test_main():
    arguments = dict(
        name=dict(required=True,default='python'),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )

    set_module_args(dict(
        name='python',
        selection='hold'
    ))

    module = AnsibleModule(
        argument_spec=arguments,
        supports_check_mode=True,
    )

    rc, out, err = module.run_command(['dpkg', '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    expected_current = 'hold'

# Generated at 2022-06-20 21:41:34.965551
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {'name': 'python', 'selection': 'install'}
    main()

# Generated at 2022-06-20 21:41:47.946758
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils import module_docs
    import sys
    with open(__file__, 'r') as f:
        with open('/tmp/action.txt', 'w') as a:
            a.write(f.read())
    sys.path.append('/tmp/')
    m = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ))
    print(module_docs(m))
    m.params['name'] = 'python'
    m.params['selection'] = 'install'
    main()

# Generated at 2022-06-20 21:42:00.764406
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO
    import sys

    # Check if dpkg is in PATH
    if sys.path[0] != '/usr/bin':
        sys.path.insert(0, '/usr/bin')

    # Set up string environment for input and output
    stdin = sys.stdin
    stdout = sys.stdout

    # Set up input and output
    output = StringIO()
    input = StringIO("python install\n")
    sys.stdin = input
    sys.stdout = output

    # Run test
    main()

    # Return system to normal
    sys.stdin = stdin
    sys.stdout = stdout

# Generated at 2022-06-20 21:42:09.214763
# Unit test for function main
def test_main():
    test_args = ['dpkg_selections.py',
                 'name=pkgname',
                 'selection=hold']

    def run_module(*args, **kwargs):
        module_args = test_args.copy()
        if args:
            module_args.extend(args)
        kwargs['argument_spec'] = dict()
        kwargs['supports_check_mode'] = True
        return AnsibleModule(**kwargs).execute_module(module_args)

    # Test exit_json with no changes
    run_module()

    # Test exit_json with changes
    run_module(dict(selection='purge'))

# Generated at 2022-06-20 21:42:24.100706
# Unit test for function main
def test_main():
    dpkg_path = os.popen('which dpkg').read().rstrip()
    print(dpkg_path)

    dpkg_selected_path = os.popen('which dpkg-selected').read().rstrip()
    print(dpkg_selected_path)

    dpkg_setselections_path = os.popen('which dpkg-setselections').read().rstrip()
    print(dpkg_setselections_path)

    ret = os.system('dpkg --get-selections')
    print(ret)
    if ret == 0:
        print('get selections OK')

    print(os.popen('which dpkg').read())
    ret = os.system('dpkg --set-selections')
    print(ret)
    if ret == 0:
        print('set selections OK')

    package

# Generated at 2022-06-20 21:42:33.448730
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # This is a no-op
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-20 21:42:39.800749
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    _main = main()
    assert isinstance(_main, Mapping)
    assert isinstance(_main['ansible_facts'], Mapping)
    assert isinstance(_main['ansible_facts']['ansible_dpkg_selections'], Sequence)

# Generated at 2022-06-20 21:42:40.469663
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:42:47.988057
# Unit test for function main
def test_main():
    args = dict(
        name="python",
        selection="hold",
        check_mode=False,
    )
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = args

    rc, out, err = module.run_command(['dpkg', '--get-selections', 'python'], check_rc=True)
    assert out == "python\thold"

    main()

# Generated at 2022-06-20 21:42:48.609409
# Unit test for function main
def test_main():
    assert('foo')

# Generated at 2022-06-20 21:42:51.849049
# Unit test for function main
def test_main():
    output = dict()
    output['name'] = "python"
    output['selection'] = "hold"
    output['changed'] = False
    output['before'] = 'install'
    output['after'] = 'hold'

# Generated at 2022-06-20 21:43:14.056896
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:18.097091
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(required=True),
            action=dict(default=None, required=False)
        ),
        supports_check_mode=True,
    )

    module.exit_json(changed=True, before=None, after=None)

# Generated at 2022-06-20 21:43:20.163608
# Unit test for function main
def test_main():
    # No op test
    assert True

# Generated at 2022-06-20 21:43:28.177809
# Unit test for function main
def test_main():
    with patch('ansible_module_dpkg_selections.module.run_command') as mock_run_command:
        with patch('ansible_module_dpkg_selections.module.exit_json') as mock_exit_json:
            with patch('ansible_module_dpkg_selections.module.get_bin_path') as mock_get_bin_path:
                mock_run_command.return_value = 0, 'mock stdout', ''
                mock_get_bin_path.return_value = 'dpkg'

                main()
                mock_run_command.asert_called_once_with([dpkg, '--get-selections', name], check_rc=True)
                mock_get_bin_path.assert_called_once_with('dpkg', True)

# Generated at 2022-06-20 21:43:29.102462
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-20 21:43:43.495936
# Unit test for function main
def test_main():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock, call, patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    module_patch = patch('ansible_collections.ansible.community.plugins.modules.packages.dpkg_selections.AnsibleModule')
    mock_module = module_patch.start()
    mock_module.return_value = Mock(
        exit_json=Mock(return_value=True),
        params=dict(
            name='python',
            selection='hold'
        ),
        check_mode=False,
        get_bin_path=Mock(return_value='/usr/bin/dpkg')
    )


# Generated at 2022-06-20 21:43:52.030909
# Unit test for function main
def test_main():
    this_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Mock return_value of calls to the method run_command.
    # The first argument is the command, the second is the exit code and the third is the output of the command
    this_module.run_command = MagicMock(return_value=(0, 'python install', ''))

    name = this_module.params['name']
    selection = this_module.params['selection']

    current = 'install'

    assert current == selection
    assert name == 'python'
    assert current == 'install'

# Generated at 2022-06-20 21:44:02.855771
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import tests.unit.modules.utils as testutils

    module = testutils.set_module_args(dict(
        name='python',
        selection='hold',
    ))

    # Autospec the returned main function
    main_autospec = AnsibleModule(argument_spec=dict(),
                                  supports_check_mode=True).autospec(main)

    # Set the dpkg bin to a fake value so we can control its behaviour
    module.run_command = lambda args, **kwargs: (0, 'python\tinstall\n', '') \
                                                if args == ['dpkg', '--get-selections', 'python'] else \
                                                testutils.run_command_success

    main_autospec(module)

# Generated at 2022-06-20 21:44:13.177227
# Unit test for function main
def test_main():
    dpkg = '/bin/dpkg'

    class AnsibleModule:
        def get_bin_path(path, required):
            if path == 'dpkg' and required:
                return dpkg

    class AnsibleModule:
        def run_command(path, check_rc):
            if path == [dpkg, '--get-selections', 'python']:
                return 0, 'python\theld', ''
            elif path == [dpkg, '--set-selections']:
                return 0, '', ''

    class AnsibleModule:
        def __init__(self, test):
            self.params = test

    class AnsibleModule:
        def exit_json(changed, before, after):
            if changed is True and before == 'held' and after == 'install':
                return True
            else:
                return

# Generated at 2022-06-20 21:44:24.644976
# Unit test for function main
def test_main():
    test_module = imp.load_source('test_module_actions_apt', '../library/actions/apt.py')
    test_args = dict(
        name='test_module_actions_apt',
        selection='test'
    )
    test_args_1 = dict(
        name='test_module_actions_apt',
        selection='test_1'
    )
    module_test = test_module.AnsibleModule(argument_spec=test_args)
    module_test_1 = test_module.AnsibleModule(argument_spec=test_args_1)
    assert module_test.fail_json.call_count == 0
    assert module_test_1.fail_json.call_count == 1

# Generated at 2022-06-20 21:45:06.747610
# Unit test for function main
def test_main():
    test_main.dpkg_selections_script_outputs = [
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
        [0, '', ''],
    ]
    test_main.index = -1


# Generated at 2022-06-20 21:45:23.554449
# Unit test for function main
def test_main():
    # Mock module
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 21:45:26.677622
# Unit test for function main
def test_main():
    # check_mode = True
    # check_mode = False
    pass

# Generated at 2022-06-20 21:45:42.639165
# Unit test for function main
def test_main():
    import os
    import subprocess
    import tempfile
    import json
    import pytest
    

    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        filename = 'test_main.json'
        args = ['--name', 'python', '--selection', 'hold']
        with open(filename, 'w') as f:
            json.dump({
                "ANSIBLE_MODULE_ARGS": {
                    "name": "python",
                    "selection": "hold"
                }
            }, f)

        output = subprocess.check_output(['ansible-playbook', '-i', filename, 'test.yml']).decode('utf-8')

        assert(output.find('changed=false') > 0)

# Generated at 2022-06-20 21:45:49.925764
# Unit test for function main
def test_main():

    import os
    import sys
    import tempfile

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.selinux import SeLinux
    from ansible.module_utils.selinux import Coverage

    def cleanup():
        pass

    def init():
        pass

    def is_test():
        return True


# Generated at 2022-06-20 21:46:04.705477
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)), supports_check_mode=True)
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_

# Generated at 2022-06-20 21:46:12.682908
# Unit test for function main
def test_main():

    with open("/tmp/dpkg_selections_test_input", "w") as f:
        f.write("ansible hold")

    # test with check_mode equal to True
    module = {"check_mode":True,"changed":True,"_ansible_check_mode":True,
              "run_command":run_command_true, "exit_json":exit_json,
              "params":{"name":"ansible","selection":"hold"} }
    main()

    # test with current selection equal to "hold"
    module = {"check_mode":False,"changed":False,"_ansible_check_mode":False,
              "run_command":run_command_hold, "exit_json":exit_json,
              "params":{"name":"ansible","selection":"hold"} }
    main()

    # test with current selection not equal to "

# Generated at 2022-06-20 21:46:13.783449
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:46:17.639956
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:46:28.009035
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:47:43.341418
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:47:46.679409
# Unit test for function main
def test_main():
    assert callable(import_module(__name__).main)

# Generated at 2022-06-20 21:47:48.472533
# Unit test for function main
def test_main():
    print("TESTING main")
    AnsibleModul

# Generated at 2022-06-20 21:47:50.661407
# Unit test for function main
def test_main():
    assert True # TODO: implement your test here


# Generated at 2022-06-20 21:47:54.795025
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main()

# Generated at 2022-06-20 21:48:04.906325
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    m.run_command = MagicMock(return_value=(0, 'python install', ''))
    m.run_command.side_effect = [(0, 'python install', ''), (0, 'python hold', '')]
    m.exit_json = MagicMock(return_value=None)

    # Test - change
    main()

    m.exit_json.assert_called_once_with(changed=True, before='install', after='hold')

    # Test - no change
    m.params['selection'] = 'install'


# Generated at 2022-06-20 21:48:19.182024
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:48:20.036873
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-20 21:48:28.437742
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.check_mode = True
    module.params["name"] = "python"
    module.params["selection"] = "hold"
    module.run_command = lambda args, check_rc: (0, "python deinstall")
    main()
    assert module.exit_json_called
    assert module.exit_json_args["before"] == "deinstall"
    assert module.exit_json_args["after"] == "hold"
    assert module.exit_json_args["changed"] == True

# Generated at 2022-06-20 21:48:37.750566
# Unit test for function main
def test_main():
    import os
    import sys
    import shlex
    from ansible.module_utils.distro import get_distribution
    from ansible.module_utils._text import to_bytes

    distro = get_distribution()
    if distro.lower() != 'debian':
        pytest.skip('Sorry, this module is only for Debian')

    current_dir = os.path.dirname(__file__)
    test_dir = os.path.join(current_dir, 'test_dpkg_selections')
    sys.path.insert(0, test_dir)
