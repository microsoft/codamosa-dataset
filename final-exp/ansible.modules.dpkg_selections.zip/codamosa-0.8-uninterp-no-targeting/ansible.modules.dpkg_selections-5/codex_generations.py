

# Generated at 2022-06-20 21:40:37.015524
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:40:38.270538
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-20 21:40:45.282720
# Unit test for function main
def test_main():
    test_name = 'test_package_name'
    test_selection = 'test_selection'

    test_data = '%s %s\n' % (test_name, test_selection)

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Test that the module exits when before and after are the same.
    rc, out, err = module.run_command([dpkg, '--get-selections', test_name], check_rc=True)
    module.exit_json = mock.MagicMock()

# Generated at 2022-06-20 21:40:55.351395
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    stdin = basic.container_to_bytes(
        'package1 install\npackage2 deinstall'
    )
    args = dict(
        name='package1',
        selection='hold'
    )
    mod = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    mod.run_command = Mock(return_value=(0, 'package1 install\npackage2 deinstall', ''))
    mod.check_mode = False
    main()
    assert mod.run_command.called
    mod

# Generated at 2022-06-20 21:41:04.076461
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

if __name__ == '__main__':
    test_main

# Generated at 2022-06-20 21:41:10.115355
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    check_mode = true
    changed = 'hold'
    before = 'install'
    after = 'hold'

    test = main(name, selection, check_mode)
    assert(test.changed == changed)
    assert(test.before == before)
    assert(test.after == after)

# Generated at 2022-06-20 21:41:17.894534
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:27.997074
# Unit test for function main
def test_main():
    dpkg_selections = __import__('ansible.modules.packaging.os.dpkg_selections')

    args = dict(
        name='python',
        selection='hold',
    )

    # Fake init module and params
    class FakeModule:
        def __init__(self, **kwargs):
            self.params = kwargs.copy()
        def fail_json(self, *args, **kwargs):
            raise AssertionError(args, kwargs)
        def exit_json(self, *args, **kwargs):
            raise AnsibleExitJson(args, kwargs)
    class FakeParams(dict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._args = list(args)
           

# Generated at 2022-06-20 21:41:32.559885
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    assert(main()) == 0

# Generated at 2022-06-20 21:41:38.254623
# Unit test for function main
def test_main():
    dpkg = '%s/dpkg' % module.get_bin_path('')
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    assert(current is selection)

# Generated at 2022-06-20 21:42:01.880231
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'name': "",
        'selection': ""
    })

    # Set up some mock data
    module.run_command = MagicMock()
    module.run_command.side_effect = [
        (0, "name install", ""),  # Check current selection
        (0, "", ""),  # Run the final command to set the selection
    ]

    rc = main()
    assert rc['changed'] == False

# Generated at 2022-06-20 21:42:03.239042
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:42:14.672637
# Unit test for function main
def test_main():
    import mock

    def run_command(cmd, check_rc=False):
        class AttrDict(dict):
            def __init__(self, *args, **kwargs):
                super(AttrDict, self).__init__(*args, **kwargs)
                self.__dict__ = self

        out = AttrDict()
        out.stdout = "package name selected"
        out.rc = 0
        return out

    module = mock.Mock()
    module.run_command = run_command
    module.check_mode = False
    dpkg = "/usr/bin/dpkg"
    module.get_bin_path = mock.Mock(return_value=dpkg)
    module.params = {
        "name" : "name",
        "selection" : "name"
    }



# Generated at 2022-06-20 21:42:25.600294
# Unit test for function main
def test_main():
    testmodule_args = {'name': 'python', 'selection': 'hold', 'check_mode': True, 'diff_mode': True}
    check_args = "--get-selections python"
    no_out = """python	not present
python	hold
"""
    check_args2 = "--get-selections python"
    out = """python	hold
"""
    testmodule_args2 = {'name': 'python', 'selection': 'uninstall', 'check_mode': True, 'diff_mode': True}
    check_args3 = "--get-selections python"
    out2 = """python	hold
"""
    testmodule_args3 = {'name': 'python', 'selection': 'uninstall', 'check_mode': False, 'diff_mode': True}

# Generated at 2022-06-20 21:42:34.018546
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        test_main

# Generated at 2022-06-20 21:42:44.092522
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # dpkg --get-selections returns an empty string if the package is not present
    module = AnsibleModule(argument_spec={
        'name': {'required': True},
        'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}
    }, supports_check_mode=True)
    module.run_command = lambda args, check_rc=None, data=None, binary_data=None, cwd=None: ('', '', None)
    dpkg_selections = __import__('dpkg_selections')
    dpkg_selections.module = module
    dpkg_selections.main()
    assert module.exit_args['changed'] is False
    assert module.exit_args['before']

# Generated at 2022-06-20 21:42:54.651940
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:08.324522
# Unit test for function main
def test_main():
    required_params = {
        'name': 'test_name',
        'selection': 'test_selection'
    }

    module = AnsibleModule(
        {},
        supports_check_mode=True,
    )

    class run_command_mock():
        def __init__(self, module):
            pass
        def run_command(self, rc, out, err):
            return False

    class get_bin_path_mock():
        def __init__(self, real_path):
            pass
        def get_bin_path(self, real_path, required):
            return True

    dpkg_selections = __import__('dpkg_selections')

    dpkg_selections.AnsibleModule = AnsibleModule
    dpkg_selections.run_command = run_command_mock


# Generated at 2022-06-20 21:43:18.083173
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['changed'] == False
    
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['before'] == "deinstall"
    assert result.value.args[0]['after'] == "install"
    
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['before'] == "install"
    assert result.value.args[0]['after'] == "deinstall"


# Generated at 2022-06-20 21:43:27.761182
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json

# Generated at 2022-06-20 21:43:51.830719
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        mock_module.return_value.run_command.return_value = (0, 'python install', '')
        mock_module.return_value.check_mode = False
        mock_module.return_value.params = {
            'name': 'python',
            'selection': 'hold',
        }
        mock_module.return_value.exit_json.side_effect = exit_json
        mock_module.return_value.run_command = MagicMock()

        main()


# Generated at 2022-06-20 21:43:59.519706
# Unit test for function main
def test_main():
    # Mock module data
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {'name': 'toto'}
    module.params = {'selection': 'pipo'}

    # Mock main variables
    main()

# Generated at 2022-06-20 21:44:04.557146
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-20 21:44:10.311191
# Unit test for function main
def test_main():
    # Tests based on core/action_plugins/dpkg_selections.py
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert module.run_command([dpkg, '--get-selections', name], check_rc=True) == 0

# Generated at 2022-06-20 21:44:11.100877
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:44:24.121230
# Unit test for function main
def test_main():
    import sys
    if sys.version_info >= (2, 7):
        import unittest
        import mock

        class TestMain(unittest.TestCase):
            def setUp(self):
                self.mock_module = mock.MagicMock()

            def get_bin_path_run_command_Error_run(self, stderr=''):
                self.mock_module.get_bin_path.return_value = '/usr/bin/dpkg'

                mock_run_command = mock.MagicMock()
                mock_run_command.return_value = (1, '', stderr)
                self.mock_module.run_command = mock_run_command

            def get_bin_path_run_command_Error_check(self):
                self.mock_module.get_bin

# Generated at 2022-06-20 21:44:29.864365
# Unit test for function main
def test_main():

    import sys

    dpkg_selections = sys.modules[__name__]

    # Create the object that runs tests
    runner = dpkg_selections.AnsibleModule(
        argument_spec={
            'name': {'required': True, 'type': 'str'},
            'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}
        },
        supports_check_mode=True
    )

    # Set the environment variable needed for the test
    os.environ['USER'] = 'root'

    # Run the main function
    main(runner)

# Generated at 2022-06-20 21:44:34.351246
# Unit test for function main
def test_main():
    module_args = {}
    module_args.update({"name": "python-yaml", "selection": "hold"})
    module = AnsibleModule(argument_spec=module_args)
    main()

# Generated at 2022-06-20 21:44:47.247151
# Unit test for function main
def test_main():
    outfile=open("/tmp/test.txt", "w")
    print("{\"changed\":false,\"before\":\"hold\",\"after\":\"not present\", "
          "\"rc\":0,\"stdout\":\"\",\"stdout_lines\":[],\"stderr\":\"\",\"stderr_lines\":[]}", file=outfile)
    outfile.close()
    infile=open("/tmp/test.txt", "r")
    assert infile.read() == "{\"changed\":false,\"before\":\"hold\",\"after\":\"not present\", " \
                            "\"rc\":0,\"stdout\":\"\",\"stdout_lines\":[],\"stderr\":\"\",\"stderr_lines\":[]}"
    infile.close()

# Generated at 2022-06-20 21:44:50.541586
# Unit test for function main
def test_main():
	assert main() is None

# Generated at 2022-06-20 21:45:19.919392
# Unit test for function main
def test_main():
    test_arguments = dict(name='python', selection='hold')
    module = AnsibleModule(argument_spec=dict())
    module.params = test_arguments
    main()

# Generated at 2022-06-20 21:45:29.476063
# Unit test for function main
def test_main():
    dpkg_unit_test = {
        'name': 'python',
        'selection': 'hold'
    }

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str')
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = dpkg_unit_test['name']
    selection = dpkg_unit_test['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

# Generated at 2022-06-20 21:45:44.306262
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    class MockModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
           self.params = {"name": "ansible", "selection": "install"}
           AnsibleModule.__init__(self, *args, **kwargs)
           self.run_command = mock_run_command
           self.check_mode = True
           self.get_bin_path = mock_get_bin_path


# Generated at 2022-06-20 21:45:53.805977
# Unit test for function main
def test_main():
    # load_fixture is a helper function that reads a file and returns its
    # contents.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # set up the fixtures for each test
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-20 21:45:54.774383
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:45:59.385196
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main(test_module)

# Generated at 2022-06-20 21:46:02.737582
# Unit test for function main
def test_main():
    result = main()
    assert result == 'foo'



# Generated at 2022-06-20 21:46:11.725082
# Unit test for function main
def test_main():
  with patch('ansible.module_utils.basic.AnsibleModule.get_bin_path', return_value='/usr/bin/dpkg'):
    with patch('ansible.module_utils.basic.AnsibleModule.run_command', return_value=('2', 'sudo dpkg --get-selections python\npython\tinstall\n', '')):
      with patch('ansible.module_utils.basic.AnsibleModule.check_mode', return_value=False):
        module = AnsibleModule(
          argument_spec={ },
          supports_check_mode=True,
        )
        module.exit_json = Mock()
        dpkg_selections.main()
        module.exit_json.assert_called_once_with(changed=True, before='install', after='hold')

# Generated at 2022-06-20 21:46:17.332498
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:46:27.950195
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:47:42.275420
# Unit test for function main
def test_main():
    import os
    import sys

    #  Open a test module
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from libraries.test_utils import AnsibleExitJson
    from libraries.test_utils import AnsibleFailJson
    from libraries.test_utils import ModuleTestCase

    # Check mode don't actually run commands
    def run_command_test_case(self):
        self.run_command_called = False
        return (0, "", "")

    # Unit test main function

# Generated at 2022-06-20 21:47:43.417773
# Unit test for function main
def test_main():
    assert main([]) == False


# Generated at 2022-06-20 21:47:55.172369
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:47:56.210181
# Unit test for function main
def test_main():

    assert(True)

# Generated at 2022-06-20 21:48:05.709496
# Unit test for function main
def test_main():
    from ansible_collections.community.general.tests.unit.compat.mock import patch, Mock
    from ansible_collections.community.general.plugins.modules.system.dpkg_selections import main

    dpkg = Mock()
    module = Mock()

    def check_module_get_bin_path(module, name, required):
        if name == 'dpkg':
            return dpkg

    module.get_bin_path = check_module_get_bin_path
    module.check_mode = False

    module.params = {
        'name': 'python',
        'selection': 'hold'
    }

    module.run_command = lambda cmd, **kwargs: (0, "python hold", "")


# Generated at 2022-06-20 21:48:16.946303
# Unit test for function main
def test_main():
    # Test with defaults
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )
    module.mock_module_results = True
    module.exit_json = exit_json

    # Test normal
    set_module_args({'name': 'foo', 'selection': 'bar'})
    dpkg_selections = importlib.import_module('ansible.modules.system.dpkg_selections')
    dpkg_selections.main()
    assert module.run_command.call_count == 2

# Generated at 2022-06-20 21:48:27.051812
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:48:31.944197
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    module.params['name'] = 'python'
    module.params['selection'] = 'install'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', module.params['name']], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    # print(current)


# Generated at 2022-06-20 21:48:39.208973
# Unit test for function main
def test_main():
  import base64
  import json
  import os
  import tempfile
  input_args = {
    'name': 'python',
    'selection': 'hold',
    'check_mode': False,
  }
  mocked_init_ansible_module = {
    'params': input_args,
  }
  mocked_run_command = {
    'rc': 0,
    'out': 'python hold 0.1-1',
  }
  mocked_run_command_2 = {
    'rc': 0,
    'out': 'python not present 0.1-1',
  }
  before = ''
  after = ''

  # Test for hold
  with tempfile.TemporaryDirectory() as tempdir:
    mocked_run_command['cwd'] = tempdir
    mocked_run_command['binary']

# Generated at 2022-06-20 21:48:47.984132
# Unit test for function main
def test_main():
    """
    Test that main returns the required values
    """
    # AnsibleModule instance
    class MockedModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, command, required):
            return '/usr/bin/dpkg'

        def run_command(self, args, check_rc=False):
            if args == ['/usr/bin/dpkg', '--get-selections', 'python']:
                out = 'python hold'
                return 0, out, ''
            else:
                raise Exception()

        def exit_json(self, changed, before, after):
            pass

        def check_mode(self):
            return True

        def fail_json(self, msg):
            print(msg)
            exit(1)
