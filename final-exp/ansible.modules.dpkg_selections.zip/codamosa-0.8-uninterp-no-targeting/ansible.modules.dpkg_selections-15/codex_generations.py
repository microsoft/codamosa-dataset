

# Generated at 2022-06-20 21:40:32.832333
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'install'

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        assert(changed == False)
        assert(current == 'hold')


# Generated at 2022-06-20 21:40:42.351534
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    dpkg_selections_test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module = dpkg_selections_test
    name='test'
    selection='hold'
    rc, out, err = module.run_command("echo -e 'test\tinstall\n'", check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_

# Generated at 2022-06-20 21:40:43.329872
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 21:40:53.465939
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test.assertTrue(len(test.fu_name('test')) != 0)
    test.assertTrue(len(test.fu__ansible_module_name('test', 'test')) != 0)
    test.assertTrue(len(test.fu__ansible_module_version('test', 'test', 'test')) != 0)
    test.assertTrue(len(test.fu__ansible_module_location('test', 'test', 'test', 'test')) != 0)

# Generated at 2022-06-20 21:41:04.849942
# Unit test for function main
def test_main():
    tests = [
        # test_name, test_args, test_replies, expected_result
        ('test selection', {}, {}, {}),
        ('test selection', {}, {}, { "test selection": "test selection" })
    ]

    def test(test_name, test_args, test_replies, expected_result):
        module = AnsibleModule(argument_spec=test_args)
        module.run_command()
        #def run_command(self, cmd, data=None, check_rc=False, close_fds=True, executable=None, data_encoding='binary', environ_update=None)
        assert_equal, assert_not_equal, assert_true, assert_false = \
            module.assert_equal, module.assert_not_equal, module.assert_true, module.assert_false

# Generated at 2022-06-20 21:41:06.285647
# Unit test for function main
def test_main():
    dpkg_dict = []
    assert dpkg_dict == main()

# Generated at 2022-06-20 21:41:16.854663
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-20 21:41:18.642839
# Unit test for function main
def test_main():
    assert 1 == 1


# Generated at 2022-06-20 21:41:26.080360
# Unit test for function main
def test_main():
    inp = [{
        "name": "python",
        "selection": 'hold'
    }]
    out = {
        "changed": False,
        "before": "install"
    }
    module.params = inp[0]
    module.check_mode = True
    main()

    assert main.__name__ == 'main'
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['changed'] == out['changed']
    assert module.exit_json.call_args[0][0]['before'] == out['before']

# Generated at 2022-06-20 21:41:39.979986
# Unit test for function main
def test_main():
    path = os.path.dirname(os.path.realpath(__file__))
    fixture_name = "dpkg_selections_1.out"
    test_name = "test_dpkg_selections"
    fixture_path = os.path.join(path, "fixtures", fixture_name)
    fixture_file = open(fixture_path, 'r')
    fixture_str = ""
    for line in fixture_file:
        fixture_str += line

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:42:03.370829
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    dpkg = '/usr/bin/dpkg'
    get_selections_stdout = name + '\thold'
    set_selections_stdin = 'python hold'
    status_dict = {'rc': 0}
    module_mock = Mock(spec=AnsibleModule)
    module_mock.get_bin_path = Mock(return_value=dpkg)
    module_mock.params = {'name': name, 'selection': selection}
    module_mock.run_command = Mock(return_value=(status_dict['rc'], get_selections_stdout, None))
    module_mock.check_mode = False
    main()


# Generated at 2022-06-20 21:42:12.596038
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = test_module.get_bin_path('dpkg', True)

    name = test_module.params['name']
    selection = test_module.params['selection']

    # Get current settings.
    rc, out, err = test_module.run_command([dpkg, '--get-selections', name], check_rc=True)
    current = True

    main()

# Generated at 2022-06-20 21:42:18.384501
# Unit test for function main
def test_main():

    import sys
    import os
    import json

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # If ansible's log module is available, hook it up so we can configure it for debug.
    has_log = False
    try:
        from ansible.module_utils.ansible_release import __version__ as ansible_version
        from distutils.version import LooseVersion
        if LooseVersion(ansible_version) >= LooseVersion("2.1.0.0"):
            from ansible.plugins.callback import CallbackBase
            has_log = True
    except ImportError:

        class CallbackBase:
            """
            If log isn't available, create a dummy class that Ansible can use instead.
            """

# Generated at 2022-06-20 21:42:19.210565
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-20 21:42:29.202105
# Unit test for function main

# Generated at 2022-06-20 21:42:36.149253
# Unit test for function main
def test_main():
    module = AnsibleModule({'name': 'unzip', 'selection': 'purge'}, '', True)
    dpkg = module.get_bin_path('dpkg', True)
    module.run_command([dpkg, '--get-selections', 'unzip'])
    module.run_command([dpkg, '--set-selections'], data="unzip purge")

# Generated at 2022-06-20 21:42:47.910718
# Unit test for function main
def test_main():

    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Mock options for function main
    options = {
        'name': 'python',
        'selection': 'hold',
    }

    # Mock commands
    mock_run_command = [
        ('dpkg --get-selections python', '', 0, 'install\n'),
        ('dpkg --set-selections', 'python hold', 0, '')
    ]

    # Mock function import_module
    def import_module(module):
        class ImportModule():
            pass
        import_module = ImportModule()


# Generated at 2022-06-20 21:42:52.809240
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = lambda x: print(x)
    main()

# Generated at 2022-06-20 21:42:53.775739
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-20 21:43:08.026033
# Unit test for function main
def test_main():
    function_name = 'main'
    function_params = {"name": "python", "selection": "hold"}
    function_result = {"changed": False, "after": "hold", "before": "hold"}
    mock_module = MagicMock()
    mock_module.params = function_params
    mock_module.run_command = MagicMock()
    mock_module.check_mode = False
    # get_bin_path
    mock_module.get_bin_path = MagicMock(return_value="/usr/bin/dpkg")
    # check_rc=True
    mock_module.run_command.return_value = (0, "python hold", "")
    mock_module.exit_json = MagicMock()


# Generated at 2022-06-20 21:43:27.984267
# Unit test for function main
def test_main():
    current = 'install'
    selection = 'hold'
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)), supports_check_mode=True)
    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
        selection = 'install'
    else:
        current = out.split()[1]
        selection = 'hold'

    changed = current != selection


# Generated at 2022-06-20 21:43:29.027175
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-20 21:43:29.841231
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:43:43.795419
# Unit test for function main
def test_main():
    # Get the Ansible arguments
    args = dict(
        name="python",
        selection="hold",
        check_mode=True,
    )

    # Setup the AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,
    )
    
    # Use AnsibleModule.run_command() to simulate run_command in Ansible
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    rc = 0
    out = 'python new'
    err = ''
    if not out:
        current = 'not present'


# Generated at 2022-06-20 21:43:44.405613
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-20 21:43:52.479528
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Do not test check_mode or diff_mode as results are undefined

    # Test success
    test_module.params = {"name": "apt", "selection": "install", "check_mode": False, "diff_mode": False}
    main()

    # Test fail with not present
    test_module.params = {"name": "apt", "selection": "not present", "check_mode": False, "diff_mode": False}
    with pytest.raises(SystemExit):
        main()

    # Test fail with invalid selection


# Generated at 2022-06-20 21:44:03.266098
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    # Dummy params
    name = module.name
    selection = module.selection

    # Dummy return values
    out = 'val'
    err = 'val'
    rc = 0

    # Dummy ansible params
    check_mode = False
    diff_mode = False
    minimal_diff = False

    module.check_mode = check_mode
    module.diff = diff_mode
    module.minimal_diff = minimal_diff

    m_run_command = MagicMock(return_value=(rc, out, err))
    m_run_command_check_rc

# Generated at 2022-06-20 21:44:13.213411
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            target=dict(required=True),
            port=dict(required=True, type='int'),
            state=dict(required=True, choices=['open', 'closed']),
            protocol=dict(required=False, default='tcp'),
            timeout=dict(required=False, type='int', default=3),
            connect_timeout=dict(required=False, type='int', default=None),
            message=dict(required=False, default=None),
            ensure_firewalld_stopped=dict(required=False, type='bool', default=False),
            ignore_check_mode=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # In check mode return message

# Generated at 2022-06-20 21:44:22.430403
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.check_mode = True
    module.main()

# Generated at 2022-06-20 21:44:29.931533
# Unit test for function main
def test_main():
    # Create an argument spec
    def my_spec():
        return dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )

    # Create a module object
    def my_module():
        return AnsibleModule(argument_spec=my_spec(), supports_check_mode=True)

    # Create a module fixture
    module = my_module()
    # Change module parameters
    module.params = {
        'name': 'python2.7',
        'selection': 'hold'
    }

    dpkg = module.get_bin_path('dpkg', True)
    # Set values of rc, out, and err
    rc = 0
    out = 'python2.7 hold'
    err = ''

   

# Generated at 2022-06-20 21:45:08.738280
# Unit test for function main
def test_main():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.six import PY2

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # We fake the behavior of the `platform` module, which is only available
    # on POSIX systems
    facts = Facts(
        module,
        dict(
            distro=dict(name='debian', id='debian', major_version='8', minor_version='11'),
            ansible_python_version=2.7
        )
    )

# Generated at 2022-06-20 21:45:09.358872
# Unit test for function main
def test_main():
    assert main() is True

# Generated at 2022-06-20 21:45:09.903908
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:45:21.437784
# Unit test for function main

# Generated at 2022-06-20 21:45:29.146585
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='install'
    )

    module = AnsibleModule(argument_spec=args)

    # Setup our mock command
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')

    main()

    # Verify command with the proper arguments
    module.run_command.assert_has_calls([
        call(['dpkg', '--get-selections', 'python'], check_rc=True),
        call(['dpkg', '--set-selections'], data='python install', check_rc=True)
    ])

# Generated at 2022-06-20 21:45:39.450731
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    import os
    import sys

    # We want to execute the module on the current python implementation
    module_path = os.path.abspath(__file__)
    module_name = os.path.splitext(os.path.basename(module_path))[0]
    test_module = __import__(module_name)
    module = test_module.main()

    dpkg = get_bin_path('dpkg')
    if not dpkg:
        sys.exit('dpkg is not installed')

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'])

# Generated at 2022-06-20 21:45:48.670441
# Unit test for function main
def test_main():
    '''
    dpkg_selections module - main() function
    '''
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )
    module.exit_json = lambda changed, before, after: True # Mock exit_json
    module.run_command = lambda cmd: ['dpkg', '--get-selections', 'python', 'python']

    name = 'python'
    selection = 'hold'
    dpkg = 'dpkg'
    rc = 0
    out = 'mock_output'
    err = 'mock_error'
    current = 'not present'
    changed = False

# Generated at 2022-06-20 21:45:56.325222
# Unit test for function main
def test_main():
    # Patch module_utils/basic.py AnsibleModule object
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Patch get_bin_path function in module_utils/basic.py
    from ansible.module_utils.basic import get_bin_path

    # Patch run_command function in module_utils/basic.py
    from ansible.module_utils.basic import run_command

    # Check for required arguments and exit with error if missing

# Generated at 2022-06-20 21:46:02.611734
# Unit test for function main
def test_main():
    global __file__
    __file__ = 'lib/ansible/modules/packaging/os/dpkg_selections.py'

# Generated at 2022-06-20 21:46:11.665158
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:47:21.986534
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    current = 'install'
    changed = current != selection
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:47:24.772742
# Unit test for function main
def test_main():
    out = main()
    assert out['before'] != 'install'
    assert out['after'] == 'install'

# Generated at 2022-06-20 21:47:38.929124
# Unit test for function main

# Generated at 2022-06-20 21:47:41.274030
# Unit test for function main
def test_main():
    # Called by ansible on module.
    assert main() == True

# Generated at 2022-06-20 21:47:42.282687
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:47:49.177494
# Unit test for function main
def test_main():
    m = AnsibleModule({'name': 'python', 'selection': 'hold'}, check_invalid_arguments=False)
    result = m.run_command('dpkg --get-selections python')
    assert result[1] == 'python	install\n'
    m = AnsibleModule({'name': 'python', 'selection': 'purge'}, check_invalid_arguments=False)
    result = m.run_command('dpkg --get-selections python')
    assert result[1] == 'python	purge\n'
    m = AnsibleModule({'name': 'python', 'selection': 'purge'}, check_invalid_arguments=False)
    result = m.run_command('dpkg --get-selections python')
    assert result[1] == 'python	purge\n'

# Generated at 2022-06-20 21:47:50.043537
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-20 21:47:50.881978
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:47:57.757672
# Unit test for function main
def test_main():
    ''' Test Dpkg module '''
    from ansible.modules.packaging.os.dpkg_selections import main
    # Set required arguments.
    module_args = {
        "name": "python",
        "selection": "hold"
    }

    # Run main()
    main()

# Generated at 2022-06-20 21:48:06.760964
# Unit test for function main
def test_main():
    test_args = {
        'name': 'test_name',
        'selection': 'test_selection',
    }
    def fake_run_command(cmd, **kwargs):
        print(cmd)
        return 1, 'test_out', 'test_err'
    test_module = type('FakeModule', (object,), {
        'exit_json': lambda self, **kwargs: print('exit_json'),
        'fail_json': lambda self, **kwargs: print('fail_json'),
        'check_mode': False,
        'params': test_args,
        'run_command': fake_run_command,
        'get_bin_path': lambda self, path, **kwargs: print(path),
    })
    test_module = test_module()
    main()

# Generated at 2022-06-20 21:50:24.674750
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Test empty result
    result = {u'changed': False, u'before': u'not present', u'after': u'purge'}
    result.update({'arguments': {'name': 'python', 'selection': 'purge'}})

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )
    module.exit_json = lambda **kwargs: kwargs # For unit testing, if this isn't done, an exception is raised
    dpkg_selections = main()

    assert dpkg_selections == result, dpkg_selections

# Test different before