

# Generated at 2022-06-20 21:40:33.092198
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    args = dict(
        dpkg='/usr/bin/dpkg',
        name='python',
        selection='hold',
        check_mode=False
    )

    tmpdir = '__module_dpkg_selections_test_dir__'
    if not os.path.isdir(tmpdir):
        os.makedirs(tmpdir)
    tmpdb = "--set-selections"
    f = open(os.path.join(tmpdir, tmpdb), 'w')
    f.write('a b c')
    f.close()
    curdir = os.getcwd()
    os.chdir(tmpdir)


# Generated at 2022-06-20 21:40:38.840429
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.check_mode = True
    mod.params = {'name': 'python', 'selection': 'hold'}
    main()

# Generated at 2022-06-20 21:40:45.590760
# Unit test for function main
def test_main():
    out = ''
    err = ''
    rc = 0
    mock_module = MagicMock()
    mock_module.run_command.return_value = (rc, out, err)
    mock_module.get_bin_path.return_value = True
    mock_module.check_mode = False
    mock_module.params = {
        'name': 'python',
        'selection': 'hold'
    }
    main()
    mock_module.run_command.assert_called_with([True, '--get-selections', 'python'], check_rc=True)
    mock_module.run_command.assert_called_with([True, '--set-selections'], data="python hold", check_rc=True)
    mock_module.fail_json.assert_not_called()


# Generated at 2022-06-20 21:40:52.180125
# Unit test for function main
def test_main():
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    assert(rc == 0)
    assert(err == "")
    rc, out, err = module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    assert(rc == 0)
    assert(err == "")

# Generated at 2022-06-20 21:41:03.675584
# Unit test for function main
def test_main():

    name = 'foo'
    selection = 'hold'

    # Set up the MockedModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Set up the test fixture
    dpkg = os.path.join(os.path.dirname(__file__), 'dpkg')

    # Assertions
    module.assertion.check_mode = True
    module.assertion.diff_mode = True
    module.assertion.platform = 'debian'
    module.assertion.get_bin_path.assert_called_with('dpkg', True)

# Generated at 2022-06-20 21:41:15.546081
# Unit test for function main
def test_main():
    import dpkg_selections

    # Set up mock module and arguments
    module = MagicMock(name='module')
    module.params = {'name': 'ntp', 'selection': 'hold'}
    module.get_bin_path = MagicMock(name='get_bin_path')
    module.run_command = MagicMock(name='run_command')

    dpkg_selections.main()

    # Test the dpkg call
    module.get_bin_path.assert_called_once_with('dpkg', True)
    module.run_command.assert_called_with([module.get_bin_path.return_value, '--get-selections', module.params['name']])

    # Test the output of the dpkg call
    stdout_str = 'ntp hold'
    module.run

# Generated at 2022-06-20 21:41:19.149488
# Unit test for function main
def test_main():
    test_params = {'name': 'python', 'selection': 'hold'}
    main()
    # Function has no return value, just exit.

# Generated at 2022-06-20 21:41:28.614219
# Unit test for function main
def test_main():
    with patch.dict(__builtins__, {'open': MagicMock(),
                                   'open.return_value': mock_open(read_data='python install')}):
        with patch('ansible.module_utils.basic.AnsibleModule') as AnsibleModule:
            print('Test state "install" when current state is "install"')
            instance = AnsibleModule.return_value
            instance.params = {'name': 'python', 'selection': 'install'}
            instance.run_command.return_value = (0, 'python install', '')
            main()
            module.exit_json(changed=False, before='install', after='install')

            print('Test state "install" when current state is "purge"')
            instance = AnsibleModule.return_value

# Generated at 2022-06-20 21:41:34.904816
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    rc, out, err = run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    assert current != selection, True
    rc, out, err = module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    assert out, True

# Generated at 2022-06-20 21:41:36.143891
# Unit test for function main
def test_main():

    main()

# Generated at 2022-06-20 21:42:04.514948
# Unit test for function main
def test_main():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, args, check_rc=True):
            if args[0] == 'dpkg':
                return 0, "python deinstall", None
            else:
                return False, None, None

        def get_bin_path(self, arg, required):
            return 'dpkg'

        def exit_json(self, changed=True, before=True, after=True):
            return (changed, before, after)

        def fail_json(self, msg, **kwargs):
            return msg


# Generated at 2022-06-20 21:42:07.863054
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    check_mode = False
    changed = True
    before = 'install'
    after = 'hold'
    main(name, selection, check_mode, changed, before, after)

# Generated at 2022-06-20 21:42:19.542779
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:42:27.499086
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        mock_module.params = {'name':'python', 'selection':'hold'}
        mock_module.run_command.return_value = (0, 'python hold', '')
        mock_module.check_mode = False
        mock_instance = mock_module.return_value
        main()
        mock_instance.run_command.assert_called_with(['/usr/bin/dpkg', '--set-selections'], data="python hold", check_rc=True)

# Generated at 2022-06-20 21:42:41.649166
# Unit test for function main
def test_main():
    # set arguments
    module_args = {
        'name': 'python',
        'selection': 'hold',
    }

    # Reset the module's system for unit testing.
    AnsibleModule = AnsibleModule
    # This loads the module
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    # Get current settings
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    # Exit the

# Generated at 2022-06-20 21:42:50.275687
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str')
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:42:51.973484
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:42:52.949471
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:43:06.659544
# Unit test for function main
def test_main():
    def dpkg_selections(name, selection):
        old = 'install'
        return old == selection, old, selection

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    setattr(module, 'run_command', dpkg_selections)
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    main()

# vim: set et sts=4 sw=4 ts=4 :

# Generated at 2022-06-20 21:43:18.142647
# Unit test for function main
def test_main():
    name = 'test'
    selection = 'install'
    out = """test               install
"""
    rc = 0
    module = AnsibleModule(
        argument_spec=dict(
            name={'required': True, 'type': 'str'},
            selection={'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge'], 'type': 'str'}
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(rc, out, ''))
    module.get_bin_path = MagicMock(return_value='./')
    main()
    assert module.run_command.call_count == 2

# Generated at 2022-06-20 21:43:44.356221
# Unit test for function main
def test_main():
    import sys
    import json
    from ansible.module_utils.basic import AnsibleModule

    # create a dummy module for testing
    dpkg = AnsibleModule(argument_spec={})

    # load the dpkg_selections module
    dpkg_selections = sys.modules['ansible.modules.system.dpkg_selections']
    dpkg_selections.AnsibleModule = AnsibleModule
    dpkg_selections.main()

    # create some input data
    dpkg._ansible_no_log = False
    dpkg.check_mode = False
    dpkg.params = {
        'name': 'test',
        'selection': 'hold'
    }

    dpkg_selections.main()

    args = dpkg.run_command.call_args[0][0]

# Generated at 2022-06-20 21:43:44.886583
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:43:50.173820
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        "name": {"required": True},
        "selection": {
            "choices": [
                "install",
                "hold",
                "deinstall",
                "purge"
            ],
            "required": True
        }
    }, supports_check_mode=True)
    module.run_command = MagicMock(return_value=0)
    name = "test"
    selection = "hold"
    main()

# Generated at 2022-06-20 21:43:50.669289
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:43:55.556255
# Unit test for function main
def test_main():
    import StringIO, sys
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.basic import print, ansible_module_convert_to_bytes
    from ansible.module_utils.basic import wrap_var, _load_params
    for param in ['name', 'selection']:
        args = dict()
        args[param] = 'aname'
        setattr(AnsibleModule, 'params', args)
        print(param)
        assert hasattr(AnsibleModule, 'params')

    args = dict()
    args['selection'] = 'install'
    setattr(AnsibleModule, 'params', args)
    print(param)
    assert hasattr(AnsibleModule, 'params')

    args = dict()
    args['selection'] = 'hold'
   

# Generated at 2022-06-20 21:44:06.064217
# Unit test for function main
def test_main():
    test_cases = (
        dict(
            description="Install a package",
            params=dict(
                name="foo",
                selection="install"
            ),
            expected_before="not present",
            expected_after="install",
            expected_changed=True
        ),
        dict(
            description="Hold a package",
            params=dict(
                name="foo",
                selection="hold"
            ),
            expected_before="install",
            expected_after="hold",
            expected_changed=True
        ),
        dict(
            description="Nothing to do",
            params=dict(
                name="foo",
                selection="hold"
            ),
            expected_before="hold",
            expected_after="hold",
            expected_changed=False
        )
    )

    import tempfile
    import shutil
   

# Generated at 2022-06-20 21:44:20.690898
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:44:29.492675
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'purge'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:44:38.028200
# Unit test for function main
def test_main():
    data = """
    - name: Prevent python from being upgraded
      dpkg_selections:
        name: python
        selection: hold
    """

    mod = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:44:38.383308
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 21:45:21.333372
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock()
    setattr(module, '_diff', False)

    module.params['name'] = 'python'
    module.params['selection'] = 'hold'

    main()

    module.run_command.assert_called_with([module.get_bin_path.return_value, '--set-selections'], data="python hold", check_rc=True)

# Generated at 2022-06-20 21:45:25.380303
# Unit test for function main
def test_main():
    # Given
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # When
    test_main()

    # Then
    module.assertEqual(dpkg, 'dpkg')
    module.assertEqual(name, 'python')
    module.assertEqual(selection, 'hold')

# Generated at 2022-06-20 21:45:35.694565
# Unit test for function main

# Generated at 2022-06-20 21:45:39.154070
# Unit test for function main
def test_main():
    dpkg_selections = main()
    ret = dpkg_selections.main()
    assert(ret['changed'] == 'False')
    assert(ret['after'] == 'not present')
    assert(ret['before'] == 'not present')



# Generated at 2022-06-20 21:45:48.483414
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"
    changed = True
    before = "install"
    after = "hold"
    dpkg = "dpkg"
    rc = 0
    out = "python install"
    err = ""

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.get_bin_path = Mock(return_value = dpkg)
    module.run_command=Mock(return_value=(rc, out, err))
    module.exit_json = Mock(return_value=None)
    module.check_mode = False
    module.params

# Generated at 2022-06-20 21:45:55.944911
# Unit test for function main
def test_main():
    mock_run_command = Mock(return_value=(0, 'python install', ''))
    with patch.object(AnsibleModule, 'run_command', mock_run_command):
        mock_module = MagicMock(
            params=dict(
                name='python',
                selection='hold'
            ),
            check_mode=True,
            supports_check_mode=True
        )
        with patch.object(AnsibleModule, 'get_bin_path', return_value='/bin/dpkg'):
            with patch.object(AnsibleModule, 'exit_json') as mock_ex_json:
                main()

                mock_ex_json.assert_called_once_with(changed=True, before='install', after='hold')


# Generated at 2022-06-20 21:46:02.573715
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:46:09.317495
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = exit_json
    module.params = {'name': 'python', 'selection': 'hold'}
    module.run_command = run_command
    print(module.get_bin_path('dpkg', True))
    main()

# Generated at 2022-06-20 21:46:24.437670
# Unit test for function main
def test_main():
    from ansible_collections.notstdlib.moveitallout.tests.unit import mocks, modules

    # Set up mocks
    module_mock = mocks.MockAnsibleModule()
    module_mock.params['name'] = 'python'
    module_mock.params['selection'] = 'hold'
    module_mock.exit_json = Mock()

    # Mock get_bin_path and check_mode functions
    get_bin_path = Mock(return_value='/usr/bin/dpkg')
    module_mock.get_bin_path = get_bin_path
    module_mock.check_mode = Mock()

    # Mock run_command function
    run_command_mock = Mock()
    module_mock.run_command = run_command_mock

    # Run

# Generated at 2022-06-20 21:46:25.960830
# Unit test for function main
def test_main():
    result = main()
    assert result != null


# Generated at 2022-06-20 21:47:38.163561
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, ModuleTestCase


# Generated at 2022-06-20 21:47:47.630614
# Unit test for function main
def test_main():
    from ansible.modules.system.dpkg_selections import main
    import os
    import pytest
    from tempfile import NamedTemporaryFile
    from ansible.module_utils._text import to_bytes

    @pytest.fixture
    def temp_pkg_sel(tmpdir):
        d = tmpdir.mkdir("pkgsel")
        return d

    @pytest.fixture
    def temp_pkg_sel_file(temp_pkg_sel):
        f = temp_pkg_sel.join("pkg_sel")
        f.write("python3 hold\n")
        f.write("python3-minimal install\n")
        return f


# Generated at 2022-06-20 21:47:48.629719
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:48:02.324612
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        check_invalid_arguments=False
    )
    module.params = {'name': 'python', 'selection': 'hold'}
    setattr(module, 'run_command', lambda args, data=None, check_rc=True: (0, '', ''))
    assert main() == {'before': 'not present', 'after': 'hold', 'changed': True}

# Generated at 2022-06-20 21:48:12.568922
# Unit test for function main
def test_main():

    #Create a test module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    #Test with a non installed package
    name = 'python'
    selection = 'install'

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert module.check_mode or not changed


# Generated at 2022-06-20 21:48:13.597050
# Unit test for function main
def test_main():
   result = main()
   assert result == "test"

# Generated at 2022-06-20 21:48:21.370525
# Unit test for function main
def test_main():
    dpkg = '/usr/bin/dpkg'
    dpkg_out = ('python-minimal install\n'
                'python2.7 install\n'
                'python3 install\n'
                'python3.4 install\n'
                'python3.5 install\n'
                'python3.6 install\n'
                )
    name = 'python'
    selection = 'hold'
    changed = True
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)), supports_check_mode=True)
    main(dpkg, dpkg_out, name, selection, changed, module)

# Generated at 2022-06-20 21:48:27.180865
# Unit test for function main
def test_main():
    dpkg_selections = {'name': 'cron', 'selection': 'purge'}
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    rc = main()
    module.exit_json(changed=True, rc=rc, selection=dpkg_selections)

# Generated at 2022-06-20 21:48:36.467081
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import action_common_attributes
    from ansible.module_utils.action_common_attributes import AnsibleActionModule
    from ansible import context
    import pytest

    @pytest.fixture
    def action_module(monkeypatch):
        context.CLIARGS = {'diff': False}
        monkeypatch.setattr(action_common_attributes, 'AnsibleActionModule', AnsibleActionModule)
        monkeypatch.setattr(action_common_attributes, 'ActionBase', AnsibleActionModule)
        monkeypatch.setattr(AnsibleActionModule, 'get_bin_path', lambda self, arg, required=False: '/usr/bin/' + arg)
        monkeypatch

# Generated at 2022-06-20 21:48:44.556504
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params['name'] = 'ansible'
    module.params['selection'] = 'install'

    dpkg = 'dpkg'
    current = 'deinstall'

    assert main() == (dpkg, module, current, 'install')

test_main()