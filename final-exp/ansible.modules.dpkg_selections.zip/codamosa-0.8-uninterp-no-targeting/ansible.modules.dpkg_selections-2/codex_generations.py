

# Generated at 2022-06-20 21:40:31.685255
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda *args, **kwargs: (0, None, None)
    module.check_mode = False

    dpkg = module.get_bin_path('dpkg', True)
    main()
    dpkg_selections = args[0][0]
    assert dpkg_selections == dpkg
    assert args[0][1] == "--set-selections"
    assert args[0][2] == "python hold"
    assert args[1]['check_rc'] == True

# Generated at 2022-06-20 21:40:41.566100
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:40:52.720131
# Unit test for function main
def test_main():
    import shutil, os, imp
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    f, fp, fpn = imp.find_module('ansible.modules.system.dpkg_selections', ['../../'])
    dpkg_selections = imp.load_module('ansible.modules.system.dpkg_selections', f, fp, fpn)
    shutil.rmtree("test/module_args")
    os.makedirs("test/module_args")
    file = open("test/module_args/ansible_module_dpkg_selections.py", "w")
    file.write("#!/usr/bin/python\n")

# Generated at 2022-06-20 21:41:04.167567
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test_module.check_mode = True
    test_module.params['name'] = 'python'
    test_module.params['selection'] = 'hold'
    out = main()
    assert out['changed'] == True
    assert out['before'] == 'not present'
    assert out['after'] == 'hold'
    test_module.check_mode = False
    out = main()
    assert out['changed'] == True
    assert out['before'] == 'not present'
    assert out['after'] == 'hold'

# Generated at 2022-06-20 21:41:04.661145
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:41:15.027513
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    MODULES_PATH = {}
    KEYWORDS = {}
    ARGS = {
        "name": "python",
        "selection": "hold",
    }
    MODULE = basic.AnsibleModule(argument_spec=KEYWORDS, supports_check_mode=True)

    MODULE.run_command = Mock(return_value=(0, '', ''))
    MODULE.run_command.return_value = (0, '', '')
    MODULE.get_bin_path = Mock(return_value=True)

    actual = main()
    assert MODULE.run_command.call_count == 2
    assert isinstance(actual, dict)

# Generated at 2022-06-20 21:41:25.733028
# Unit test for function main
def test_main():
    from ansible_collections.community.general.plugins.module_utils.basic import AnsibleModule
    import sys

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    setattr(module, 'run_command', lambda cmd, check_rc=True, data="%s %s" % (name, selection): (0, "", ""))

    old_stdout = sys.stdout

# Generated at 2022-06-20 21:41:35.397390
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:41.814446
# Unit test for function main
def test_main():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-20 21:41:48.257354
# Unit test for function main
def test_main():
    import os
    import sys
    old_sys_path = list(sys.path)

    # Set up mock module
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            selection = dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Put the required paths on the python sys.path
    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_utils_path = os.path.abspath(current_dir + "/../../../../")
    lib_path = test_utils_path + "/lib"

# Generated at 2022-06-20 21:42:00.769325
# Unit test for function main
def test_main():
    ######################################################################
    ## Unit tests for main()
    ## 
    ##   Purpose: To ensure that main() returns the expected output
    ##            regardless of inputs
    ######################################################################
    
    ######################################################################
    ## Normal case
    ######################################################################
    # Setup mocks
    module = Mock()
    module.exit_json = Mock()
    module.get_bin_path = Mock(return_value = "pkg_path")
    module.run_command = Mock(return_value=("","",""))
    module.check_mode = False
    module.params = {
        "name": "foo",
        "selection": "bar"
    }
    
    # Exercise method
    main()
    
    # Verify expectations

# Generated at 2022-06-20 21:42:05.758908
# Unit test for function main
def test_main():

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
        assert pytest_wrapped_e.type == SystemExit
        assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-20 21:42:22.105656
# Unit test for function main
def test_main():

    import os
    import tempfile

    test_module = os.path.join(tempfile.gettempdir(), 'ansible-test-dpkg_selections.py')
    with open(test_module, 'w') as f:
        f.write('#!/usr/bin/python\n')
        f.write('# -*- coding: utf-8 -*-\n')
        f.write('#\n')
        f.write('# (c) 2016, Brian Brazil <brian.brazil@boxever.com>\n')
        f.write('# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)\n')
        f.write('#\n')
        f.write('\n')

# Generated at 2022-06-20 21:42:30.131086
# Unit test for function main
def test_main():
        from ansible.module_utils import basic
        from ansible.module_utils.basic import AnsibleModule, AnsibleExitJson, AnsibleFailJson

        module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

        dpkg = module.get_bin_path('dpkg', True)

        name = module.params['name']
        selection = module.params['selection']

        # Get current settings.
        rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
        if not out:
            current = 'not present'


# Generated at 2022-06-20 21:42:44.205859
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:42:51.286303
# Unit test for function main
def test_main():
    from mock import MagicMock
    from ansible.module_utils.dpkg_selections import *
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    main()
    main()

# Generated at 2022-06-20 21:43:07.196241
# Unit test for function main
def test_main():

    dpkg = 'dpkg'
    out = 'python\thold\n'
    err = ''

    name = 'python'
    selection = 'hold'

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.run_command = MagicMock(return_value=(0, out, err))

    main()
    module.run_command.assert_called_with([dpkg, '--get-selections', name], check_rc=True)
    module.exit_json.assert_called_with(changed=False, before='hold', after='hold')


# Generated at 2022-06-20 21:43:10.236822
# Unit test for function main
def test_main():
    rc, out, err = module.run_command([dpkg, '--get-selections'])
    if out.contains(name):
        return changed

# Generated at 2022-06-20 21:43:19.610168
# Unit test for function main
def test_main():
    # Test fail without option argument
    module = AnsibleModule(argument_spec=dict())
    rc, out, err = module.run_command('dpkg --get-selections python', check_rc=True)
    selected = out.split()[1]
    module.params = {'name': 'python', 'selection': 'hold'}
    # Test with not changed
    module.run_command = MagicMock(return_value=(0, 'python\t%s\n' % module.params['selection'], ''))
    module.check_mode = True
    main()
    # Test with changed
    module.run_command = MagicMock(return_value=(0, 'python\t%s\n' % selected, ''))

# Generated at 2022-06-20 21:43:28.049301
# Unit test for function main
def test_main():
    test_data = {
        'name': 'python',
        'selection': 'install',
        'rc': 0,
        'out': 'python install',
        'current': 'install',
        'changed': 'False',
        'before': 'install',
        'after': 'install',
        'ansible_facts': {}
    }
    ansible_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    ansible_module.run_command = MagicMock(return_value=(test_data['rc'], test_data['out'], ''))
    result = main()

# Generated at 2022-06-20 21:43:47.990494
# Unit test for function main
def test_main():
    # Mock the module
    module = MagicMock()
    module.get_bin_path.return_value = "/usr/bin/dpkg"
    module.run_command.return_value = (0, "python install", "")

    # Call main
    main()

    # Assert it worked.
    module.run_command.assert_called_with(["dpkg", "--set-selections"], data="python install", check_rc=True)

# Generated at 2022-06-20 21:44:02.887325
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {}
    module.params['name'] = "python"
    module.params['selection'] = "hold"
    module.run_command = mock_run_command
    dpkg = module.get_bin_path('dpkg', True)
    # Test function main() with params set to expected values
    main()
    # Test function main() when dpkg --get-selections fails
    module.run_command = mock_run_command_

# Generated at 2022-06-20 21:44:13.186237
# Unit test for function main
def test_main():
    from ansible.module_utils.common.system import distro_release
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text import to_bytes
    import os
    import subprocess
    PYTHONHASHSEED = os.environ.get("PYTHONHASHSEED")
    if PYTHONHASHSEED not in (None, "0"):
        import random
        random.seed(0)

# Generated at 2022-06-20 21:44:25.632565
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = 'testname'
    selection = 'testselection'
    mock_rc = 0
    mock_out = 'test out'
    mock_err = 'test err'
    module.run_command = Mock(return_value=(mock_rc, mock_out, mock_err))
    module.check_mode = False
    module.params['name'] = name
    module.params['selection'] = selection
    main()

# Generated at 2022-06-20 21:44:30.920346
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    assert main() == "Disabled"

# Generated at 2022-06-20 21:44:35.369359
# Unit test for function main
def test_main():
    assert main() == (['dpkg', '--get-selections', 'python'], True)
    assert main() == (['dpkg', '--set-selections'], False)
    assert main() == True

# Generated at 2022-06-20 21:44:39.136280
# Unit test for function main
def test_main():
    # Test if we go from not installed to hold
    out = main()
    assert out['changed'] == True

# vim: set et ts=4 sts=4 sw=4 :

# Generated at 2022-06-20 21:44:41.254417
# Unit test for function main
def test_main():
    args = dict(name="python", selection="hold")
    result = main(**args)
    assert len(result) == 3
