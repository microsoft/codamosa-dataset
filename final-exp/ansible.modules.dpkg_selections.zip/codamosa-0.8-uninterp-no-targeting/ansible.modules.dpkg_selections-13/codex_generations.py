

# Generated at 2022-06-20 21:40:32.712047
# Unit test for function main
def test_main():
    # Check for load
    assert main

    # Create AnsibleModule object
    am = AnsibleModule(argument_spec = dict(
        name = dict(required = True),
        selection = dict(required = True,
            choices = [ 'install', 'hold', 'deinstall', 'purge' ])
    ),
        supports_check_mode = True)

    # Set values to proper ones
    am.params['name'] = 'python'
    am.params['selection'] = 'hold'

    # Run function main
    main()

    # Check if result has proper values
    assert am.exit_json.called
    assert am.exit_json.call_args[0][0]['changed'] == False
    assert am.exit_json.call_args[0][0]['before'] == 'hold'
    assert am.exit_json

# Generated at 2022-06-20 21:40:40.874385
# Unit test for function main
def test_main():
    this = AnsibleModule( dict(
            name="foo",
            selection="hold" ),
        supports_check_mode=True
    )
    this.run_command = MagicMock(
        return_value=("", "not present", "")
    )
    this.run_command = MagicMock(
        return_value=("", "", "")
    )
    this.exit_json = MagicMock()
    main()
    this.exit_json.assert_called_with(before='not present', changed=True, after='hold')
    #this.exit_json.assert_called_with(changed=True, msg="foo")

# Generated at 2022-06-20 21:40:52.219470
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:40:58.326134
# Unit test for function main
def test_main():
    import os
    import tempfile

    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        print("failed=True msg='ansible is required to run unit tests'")
        sys.exit(1)

    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Workaround for dpkg-query --get-selections not writing to stdout
    rc, out, err = m.run_command(['dpkg-query', '--get-selections', 'openssh-server'])
    if not out:
        current = 'not present'


# Generated at 2022-06-20 21:40:58.842890
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 21:41:05.879034
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # set up the dummy module
    module.main()

    # now we can check the result
    assert module.params['name'] == 'python'
    assert module.params['selection'] == 'hold'

# Generated at 2022-06-20 21:41:16.650274
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:26.135013
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main(module)

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:41:35.446334
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:37.836322
# Unit test for function main
def test_main():
    rc, out, err = main(["python", "dpkg_selections.py", "-n", "python", "-s", "hold"])
    assert rc == 0
    assert out == "{\"changed\": false, \"before\": \"install\", \"after\": \"hold\"}"
    assert err == ""


# Generated at 2022-06-20 21:42:04.888590
# Unit test for function main
def test_main():
    # Mock
    from ansible.module_utils.basic import AnsibleModule
    import imp
    import os
    import sys
    import traceback

    class MockAnsibleModule(AnsibleModule):
        def run_command(self, parameters, check_rc=False):
            return (0, 'python install', '')

        def get_bin_path(self, bin, required=False):
            return '/usr/bin/dpkg'

    def new_get_bin_path(bin, required=False):
        return '/usr/bin/dpkg'

    def sys_exit(arg):
        pass

    # Make module globals accessible to MockAnsibleModule
    dpkg_selections_globals = sys.modules['__main__'].__dict__

    # Execute function

# Generated at 2022-06-20 21:42:16.350666
# Unit test for function main
def test_main():
    d = {
        'name': 'python',
        'selection': 'hold',
        'check_mode': True,
    }

    module = AnsibleModule(argument_spec={
            'name': dict(required=True),
            'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        },
        supports_check_mode=True,
    )
    module.params = d

    dpkg = module.get_bin_path('dpkg', True)

    module.run_command([dpkg, '--get-selections', module.params['name']], check_rc=True)

# Generated at 2022-06-20 21:42:27.643126
# Unit test for function main
def test_main():
    # test case 1
    # set selection to install
    install = 'install'
    res = main(name='python', selection=install)
    assert res['before'] == 'not present'
    assert res['after'] == install
    assert res['changed'] == True

    # test case 2
    # set selection to install
    install = 'install'
    res = main(name='python', selection=install)
    assert res['before'] == 'install'
    assert res['after'] == install
    assert res['changed'] == False

    # test case 3
    # set selection to deinstall
    deinstall = 'deinstall'
    res = main(name='python', selection=deinstall)
    assert res['before'] == 'install'
    assert res['after'] == deinstall
    assert res['changed'] == True

    # test case

# Generated at 2022-06-20 21:42:42.061509
# Unit test for function main
def test_main():
    from ansible.module_utils.common.commands import Commands
    from ansible.module_utils.common.executable import Executable
    import tempfile
    import os
    import sys
    import shutil

    # Create a fake module dir that we can load from
    d = tempfile.mkdtemp()
    sys.path.append(d)

    shutil.copyfile('ansible/module_utils/basic.py', os.path.join(d, 'basic.py'))

    # Lazy to add this to the library
    class PluginModule():
        def fail_json(self, **args):
            raise Exception(args)
    module = PluginModule()
    module.params = {}

    # Mock run_command
    module.run_command = Commands.run_command
    module.get_bin_path = Executable

# Generated at 2022-06-20 21:42:53.062953
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile

    def _write(data):
        fh.write(data)
        fh.flush()

    def _read(size):
        ret = os.read(r, size)
        return ret

    fd, path = tempfile.mkstemp()
    fh = os.fdopen(fd, 'w')

    module_path = os.path.join(os.path.dirname(__file__), '../library')
    module_name = 'dpkg_selections'
    sys.path.insert(0, module_path)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes, to_native

    r

# Generated at 2022-06-20 21:42:59.095872
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:43:09.709285
# Unit test for function main
def test_main():
    patcher = mock.patch("ansible.module_utils.basic.AnsibleModule")
    patcher2 = mock.patch("ansible.module_utils.basic.AnsibleModule.get_bin_path")
    patcher3 = mock.patch("ansible.module_utils.basic.AnsibleModule.run_command")
    mock_module = patcher.start()
    mock_get_bin_path = patcher2.start()
    mock_get_bin_path.return_value = "/usr/bin/dpkg"
    mock_run_cmd = patcher3.start()
    mock_run_cmd.return_value = (0, "python install", "")

    main()

    patcher.stop()

# Generated at 2022-06-20 21:43:17.929376
# Unit test for function main
def test_main():
    # Remove if the function and/or its arguments change
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({
        'name': 'dpkg_selections',
        'selection': 'hold',
    },
    supports_check_mode=True,
    )

    assert module.check_mode is True, 'check_mode should be True'

    module = AnsibleModule({
        'name': 'dpkg_selections',
        'selection': 'hold',
    },
    supports_check_mode=False,
    )

    assert module.check_mode is False, 'check_mode should be False'

# Generated at 2022-06-20 21:43:27.348165
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    # Mock dpkg binary
    module.get_bin_path = lambda x, y: x
    module.run_command = lambda x, **kwargs: (0, '', '')

    # Test install package
    setattr(module.params, 'name', 'test-package')
    setattr(module.params, 'selection', 'install')

    main()

    # Test remove package
    setattr(module.params, 'selection', 'remove')

    main()



# Generated at 2022-06-20 21:43:36.389671
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        supports_diff=True,
        supports_diff_replace=True
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-20 21:44:03.664617
# Unit test for function main
def test_main():
    name_in = 'python'
    selection_in = 'hold'
    dpkg_input = name_in + '\tinstall\n'
    dpkg_output = name_in + '\t' + selection_in + '\n'
    # no input means the package is not present
    dpkg_input_none = ''

    # install
    selection_out = 'install'
    dpkg_input = name_in + '\t' + selection_out + '\n'
    result = main()
    assert result['changed'] == True

    # hold
    selection_out = 'hold'
    dpkg_input = name_in + '\t' + selection_out + '\n'
    result = main()
    assert result['changed'] == True

    # deinstall
    selection_out = 'deinstall'

# Generated at 2022-06-20 21:44:08.076785
# Unit test for function main
def test_main():
    import sys

    # Change sys.argv to simulate input args
    sys.argv = [sys.argv[0], 'name=python', 'selection=hold']
    # Set the mock object to the function to test
    main()
    # TODO: Add actual test here
    # assert True

# Generated at 2022-06-20 21:44:22.497830
# Unit test for function main
def test_main():
    from mock import patch, call, Mock

    # Return value of dpkg --get-selections
    dpkg_selections_out = "dpkg-query: no packages found matching vim\n"
    # Return value of module.run_command when called with dpkg --set-selections
    module_run_command_out = (0, "", "")
    # Return value of module.run_command when called with dpkg --get-selections
    module_run_command_out_get = (0, dpkg_selections_out, "")

    module_mock = Mock()
    module_mock.params = {
        'name': 'vim',
        'selection': 'hold'
    }
    module_mock.check_mode = False

# Generated at 2022-06-20 21:44:26.392196
# Unit test for function main
def test_main():
    args = dict(name='python', selection='hold')
    rc, out, err = main(args)
    assert rc == 0, "rc=%s != 0" % rc
    assert out == dict(changed=False, before='not present', after='hold')
    assert err == '', "err=%s != ''" % err


# Generated at 2022-06-20 21:44:32.846759
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'get_bin_path', return_value='/usr/bin/dpkg'), \
            patch.object(AnsibleModule, 'run_command', return_value=('', '', '')):
        with patch.object(AnsibleModule, 'exit_json'):
            main()

# Generated at 2022-06-20 21:44:36.816532
# Unit test for function main
def test_main():
    m = main()
    # assert m.exit_json.called
    # assert m.exit_json.call_args == call(changed=True, before='install', after='hold')

# Generated at 2022-06-20 21:44:44.581188
# Unit test for function main
def test_main():
    module = AnsibleModule({'name': 'python', 'selection': 'hold'}, check_mode=True)
    assert main(module) == {'changed': True, 'after': 'hold', 'before': 'deinstall'}
    assert main(module) == {'changed': False, 'after': 'hold', 'before': 'hold'}


# Generated at 2022-06-20 21:44:47.813929
# Unit test for function main
def test_main():
    name = 'unit_test_package'
    selection = 'hold'
    os.system('apt-get install -yf %s' % name)
    assert main() == True
    assert main() == False
    os.system('apt-get remove -yf %s' % name)
    os.system('apt-get purge -yf %s' % name)

# Generated at 2022-06-20 21:45:03.557010
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-20 21:45:15.356277
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    module = AnsibleModule({}, supports_check_mode=True)
    # function main must exit with rc 0 and changed=True if get different required values
    if ansible_version >= '2.8':
        rc, out, err = module.run_command('printf "name\tselection\nmy_package\tinstall\n" | LC_ALL=C dpkg --set-selections', check_rc=True)
        assert rc == 0
    else:
        rc, out, err = module.run_command('printf "name\tselection\nmy_package\tinstall\n" | dpkg --set-selections', check_rc=True)
        assert rc == 0

# Generated at 2022-06-20 21:45:46.327475
# Unit test for function main
def test_main():
    import json
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'platforms', 'debian'))
    from dpkg_selections import main
    from ansible.module_utils.common.collections import ImmutableDict, to_bytes
    from ansible.module_utils.common.parameters import (
        DIFF_SUPPORTED,
        CHECK_SUPPORTED,
    )
    from ansible.module_utils.common.runtime import DUMP_RESULT_QUEUE

    # create result object to hold the test results
    result = {}
    result['invocation'] = {}
    result['invocation']['module_args'] = {}

# Generated at 2022-06-20 21:45:52.400362
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:46:01.380264
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:46:11.317191
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:46:13.553459
# Unit test for function main
def test_main():
    from ansible.module_utils.common.process import get_bin_path
    assert main() is None

# Generated at 2022-06-20 21:46:24.477086
# Unit test for function main
def test_main():
    from ansible.module_utils.common.params import ModuleArgsParser
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.debian.dpkg import get_selection
    from ansible.module_utils.debian.dpkg import set_selection

    module_args = dict(
        name='python',
        selection='deinstall',
    )

    with patch.object(ModuleArgsParser, 'parse_kv_args'), \
            patch.object(get_selection, '__call__', return_value=None), \
            patch.object(set_selection, '__call__', return_value=None):
        main()

# Generated at 2022-06-20 21:46:35.278291
# Unit test for function main
def test_main():
    import os
    import tempfile

    # Make a temporary directory to write our fake dpkg command binary to
    tmpDir = tempfile.mkdtemp()

    # Make a fake dpkg binary that just prints out our fake output
    tmpFile, tmpPath = tempfile.mkstemp(dir=tmpDir, prefix='dpkg', suffix='.py')
    os.write(tmpFile, "#!/usr/bin/python\nprint '''python\\tdeinstall'''\n")
    os.close(tmpFile)

# Generated at 2022-06-20 21:46:40.395011
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = test_module.get_bin_path('dpkg', True)

    name = test_module.params['name']
    selection = test_module.params['selection']

    # Get current settings.
    rc, out, err = test_module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:46:45.549532
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    assert main(module) == True

# Generated at 2022-06-20 21:46:46.214842
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:48:03.842713
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:48:07.363251
# Unit test for function main
def test_main():
    data = dict(
        name='testpkg',
        selection='not present',
    )
    module = AnsibleModule(argument_spec=dict(supports_check_mode=True), check_invalid_arguments=False)
    module.params = data
    main()
    return module.exit_json

# Generated at 2022-06-20 21:48:07.850792
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-20 21:48:12.636964
# Unit test for function main
def test_main():
    with mock.patch('ansible.module_utils.basic.AnsibleModule.run_command') as run_command:
        run_command.return_value = (0, "python install\n", "")
        x = main()
        assert x['changed'] == False

# Generated at 2022-06-20 21:48:21.173600
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = module.params['name']
    selection = module.params['selection']
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-20 21:48:21.734627
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:48:22.251191
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:48:29.730510
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:48:38.427081
# Unit test for function main
def test_main():

    # Unit test example 1
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:48:47.930527
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'vim'
    selection = 'install'

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:49:53.518310
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-20 21:50:00.848275
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    import sys
    import os
    import json

    def test_exception(msg):
        try:
            raise Exception(msg)
        except Exception:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            return get_exception(exc_value)

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = '/usr/bin/dpkg'
    name = 'python'
    selection = 'hold'



# Generated at 2022-06-20 21:50:08.813712
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import dpkg_selections
    from ansible.module_utils.local_ansible_utils_extension import AModule

    class TestModule(AModule):
        def get_bin_path(self, arg, required=False):
            return arg

    test_dir = tempfile.mkdtemp()
    os.chdir(test_dir)
    sys.path.insert(0, os.path.abspath('../'))

    # Create a subprocess equivalent to a run_command function call
    # to simulate the call to dpkg.
    dpkg_path = '/bin/dpkg'

# Generated at 2022-06-20 21:50:15.693765
# Unit test for function main
def test_main():
    mock_module = MagicMock()
    mock_module.get_bin_path = MagicMock(return_value=1)
    mock_module.params = {
        'name': 'python',
        'selection': 'hold'
    }
    mock_module.check_mode = False
    mock_module.run_command = MagicMock(return_value=(0, 'python hold', ''))
    dpkg_selections.main()