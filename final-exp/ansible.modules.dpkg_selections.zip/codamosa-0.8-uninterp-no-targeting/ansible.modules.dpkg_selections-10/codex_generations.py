

# Generated at 2022-06-20 21:40:31.567169
# Unit test for function main
def test_main():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' in kwargs:
            raise AnsibleExitJson(kwargs['changed'])
        else:
            raise AnsibleExitJson(True)

    def fail_json(*args, **kwargs):
        raise AnsibleFailJson(kwargs)

    m = MagicMock(side_effect=lambda *args, **kwargs: (0, '', ''))

# Generated at 2022-06-20 21:40:40.874838
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = lambda cmd, data, check_rc=False, close_fds=True, executable=None, data_string=None: (0, '', '')

    assert not main()['changed']

    module.run_command = lambda cmd, data, check_rc=False, close_fds=True, executable=None, data_string=None: (0, 'name state', '')

    assert main()['changed']

# Generated at 2022-06-20 21:40:52.219403
# Unit test for function main
def test_main():
    dpkg_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg_module.get_bin_path = lambda x, y: 'dpkg'
    dpkg_module.params['name'] = 'python'
    dpkg_module.params['selection'] = 'hold'

    dpkg_module.run_command = lambda x, y, z: (0, 'python hold', '')

    main()

    assert dpkg_module.exit_json.called
    assert dpkg_module.exit_json.call_args[0][0]['changed'] == False
    assert dpkg_

# Generated at 2022-06-20 21:40:53.075472
# Unit test for function main
def test_main():
    res = main()
    assert res == True

# Generated at 2022-06-20 21:41:04.471058
# Unit test for function main
def test_main():
    # defaults
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {'name': 'python', 'selection': 'hold'}
    module.run_command = MagicMock()
    module.run_command.return_value = 0, "python install", ""

    # run function main
    main()

    # check expected calls
    module.run_command.assert_called_once_with(['/usr/bin/dpkg', '--set-selections'], data="python hold", check_rc=True)

    # check expected results

# Generated at 2022-06-20 21:41:05.226102
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-20 21:41:10.749630
# Unit test for function main
def test_main():
    check_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    check_module.run_command = Mock(return_value=(0, 'python install', ''))

    # Test with no change
    check_module.params = {
        "name": "python",
        "state": "install",
    }

    with pytest.raises(SystemExit) as system_exit:
        main()

    assert system_exit.value.code == 0

    # Test with change
    check_module.run_command = Mock(return_value=(0, 'python deinstall', ''))


# Generated at 2022-06-20 21:41:23.369868
# Unit test for function main
def test_main():
    """Unit test for function main"""
    import mock
    import os

    mymodule = mock.MagicMock()
    mymodule.get_bin_path.return_value = os.path.join(os.path.dirname(__file__), 'dpkg_selection.py')
    mymodule.params = {}
    mymodule.params['name'] = 'python'
    mymodule.params['selection'] = 'hold'
    mymodule.run_command.return_value = (0, 'python hold', '')

    main()
    os.remove('/tmp/ansible-dpkg.sel')


test_main()



# Generated at 2022-06-20 21:41:35.266321
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:41.731553
# Unit test for function main
def test_main():
    err = ''
    rc = 0

    try:
        import ansible.module_utils.basic as module_utils_basic
        import ansible.module_utils.common.dict_transformations as dt
    except ImportError:
        # Ansible 2.3 compat
        pass

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x, y: x
    module.run_command = lambda x, **y: (rc, x, err)
    main()

# Generated at 2022-06-20 21:42:03.891502
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    exit_args = {}
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:42:06.309488
# Unit test for function main
def test_main():
    runner = CliRunner()
    runner.invoke(dpkg_selections, ["--name", "python", "--selection", "hold"])
    assert runner.exit_code == 0

# Generated at 2022-06-20 21:42:18.560891
# Unit test for function main
def test_main():
    import sys
    print("sys.version_info=%s" % repr(sys.version_info))
    print("sys.version=%s" % repr(sys.version))
    print("sys.version_info[0]=%s" % repr(sys.version_info[0]))
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
        import mock
    else:
        import builtins
        from unittest import mock


# Generated at 2022-06-20 21:42:19.188861
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-20 21:42:26.585935
# Unit test for function main
def test_main():
    module_args = {
        "name": "ansible",
        "selection": "hold"
    }
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_AnsibleModule:
        mock_get_bin_path = Mock()
        mock_get_bin_path.return_value = 'dpkg'
        module = mock_AnsibleModule.return_value
        module.run_command.return_value = False, '', ''
        module.get_bin_path.return_value = mock_get_bin_path
        mock_main = Mock()
        mock_main.return_value = 1
        main(mock_main, module_args)
        assert module.get_bin_path.called
        assert module.run_command.called

# Generated at 2022-06-20 21:42:40.686157
# Unit test for function main
def test_main():
    # Grab the current date and time as and when the test starts
    time_start = time.time()
    time_start_utc = datetime.datetime.utcnow()
    test_result_dir_path = os.path.dirname(os.path.realpath(__file__))
    print("Starting unit test for function 'main' at UTC time %s " % time_start_utc)
    test_event_id = str(time_start_utc) + "main"
    # Create a temp folder to store the result of this unit test
    global test_result_folder
    test_result_folder = os.path.join(test_result_dir_path, 'test_result_folder_' + test_event_id)

# Generated at 2022-06-20 21:42:50.185297
# Unit test for function main
def test_main():
    # function result and expected results variables
    result, expected_result = None, None
    # test case 1
    result = main()
    # result is not None
    expected_result = True
    assert result == expected_result, 'Test case 1 failed'
    # test case 2
    result = main()
    # result is None
    expected_result = False
    assert result == expected_result, 'Test case 2 failed'
    # test case 3
    result = main()
    # result is not None
    expected_result = True
    assert result == expected_result, 'Test case 3 failed'



# Generated at 2022-06-20 21:42:57.918946
# Unit test for function main
def test_main():
	module = AnsibleModule(argument_spec=dict(name=dict(required=True),selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)))
	dpkg = module.get_bin_path('dpkg', True)
	name = module.params['name']
	selection = module.params['selection']
	rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
	if not out:
		current = 'not present'
	else:
		current = out.split()[1]
	changed = current != selection
	#test check_mode as True
	if module.check_mode or not changed:
		assert True == changed
		assert current == 'install'

# Generated at 2022-06-20 21:43:09.825095
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required='true')
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:11.662298
# Unit test for function main
def test_main():
    module = importlib.import_module('ansible.modules.sysutils.dpkg_selections')
    module.importlib = importlib
    module.main()


# Generated at 2022-06-20 21:43:33.922881
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil

    # Return code 0 passed in rc
    # Return code 1 passed in rc
    # Return code 127 passed in rc
    # Return code not in [0, 1, 127] passed in rc
    # Return code 0 passed in rc, but another rc is expected
    # Return code 1 passed in rc, but another rc is expected
    # Return code 127 passed in rc, but another rc is expected
    # Return code not in [0, 1, 127] passed in rc, but another rc is expected
    # out is passed in
    # err is passed in
    # out is passed in and is expected
    # err is passed in and is expected
    # out is passed in and is not expected
    # err is passed in and is not expected
    # out is empty
    # err is empty
    # out is empty

# Generated at 2022-06-20 21:43:34.500215
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:43:44.210745
# Unit test for function main
def test_main():
    # Test with valid parameters.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.dpkg = "dpkg"
    module.run_command = True
    module.check_mode = True
    module.params['name'] = "python"
    module.params['selection'] = "hold"

    try:
        main()
    except SystemExit as inst:
        assert inst.args[0] == 0

# Generated at 2022-06-20 21:43:52.381903
# Unit test for function main
def test_main():
    from ansible.compat.tests.mock import patch

    with patch.dict(dpkg_selections.__dict__, {'run_command': CommandRunMock}):
        # Mock run_command
        CommandRunMock.make_command('dpkg --get-selections python', 'dpkg', 'python install\n', rc=0)
        CommandRunMock.make_command('dpkg --set-selections', 'dpkg', '', rc=0)
        main()

        # Mock run_command
        CommandRunMock.make_command('dpkg --get-selections python', 'dpkg', 'python install\n', rc=0)
        CommandRunMock.make_command('dpkg --set-selections', 'dpkg', '', rc=0)
        main()

        # Mock run_command


# Generated at 2022-06-20 21:44:03.265587
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "python"
    selection = "hold"

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:44:06.645127
# Unit test for function main
def test_main():

    # create an instance of the AnsibleModule object.
    module = AnsibleModule( dict( question='life' ) )
    # check if we got an argument
    assert module.params['question'] == 'life'

# Generated at 2022-06-20 21:44:21.145944
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:44:24.683574
# Unit test for function main
def test_main():
    out, err, exitcode = module.run_command(['/usr/bin/python', 'dpkg_selections.py', '--name', 'python', '--selection', 'hold'], check_rc=False)
    assert exitcode == 0

# Generated at 2022-06-20 21:44:33.375127
# Unit test for function main
def test_main():
    # Blank requirements
    req = {}
    mod = AnsibleModule(argument_spec=req, supports_check_mode=True)
    # Patch AnsibleModule.run_command
    mod.run_command = lambda args, data=None, check_rc=False, close_fds=True, executable=None, data_encodings=None, environ_update=None, encoding=None, errors='strict', binary_data=False, prompt_regex=None, remove_tmp=True, stdin=None, chdir=None, *a, **kw: (0, 'python install', '', '')
    # Call main function
    main()

# Generated at 2022-06-20 21:44:38.469391
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ))
    return main()

# Generated at 2022-06-20 21:45:11.217632
# Unit test for function main
def test_main():
    # Test for function main
    # Incorrect return value
    rc, out, err = main()
    assert rc == 0, "Incorrect return value: %s" % rc

# Test for function main

# Generated at 2022-06-20 21:45:14.112514
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:45:15.148680
# Unit test for function main
def test_main():
    result = main()
    print(result)

# Generated at 2022-06-20 21:45:21.363585
# Unit test for function main
def test_main():
    try:
        from ansible.module_utils.ansible_nopenstack_module import NOpenstackAnsibleModule
    except ImportError:
        print("ansible not found")
        sys.exit(1)
    module = NOpenstackAnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert main() is None

# Generated at 2022-06-20 21:45:30.089213
# Unit test for function main
def test_main():

    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    class FakeModule:
        params = {'name': 'unit-test-dummy', 'selection': 'hold'}
        check_mode = False

        def get_bin_path(self, arg1, arg2):
            return '/bin/dpkg'

        def run_command(self, arg1, **kwargs):

            # Run either with success or failure
            if self.params['selection'] == 'install':
                return (0, 'unit-test-dummy install', '')

# Generated at 2022-06-20 21:45:43.238298
# Unit test for function main
def test_main():
    test_module = {}

    test_module['name'] = ['python']
    test_module['selection'] = ['hold']

    test_module_params = {}
    # set to True if you are using check_mode
    test_module_params['check_mode'] = False


    test_module_params['name'] = ['python']
    test_module_params['selection'] = ['hold']
    test_module_result = {
        'changed': False,
        'before': 'install',
        'after': 'hold',
    }

    test_module = {
        'params': test_module_params
    }

    assert main() == test_module_result
    return 0

# Generated at 2022-06-20 21:45:43.724025
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:45:53.512834
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    class Result:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

    class Module:
        def __init__(self, module):
            self.module = module
            self.check_mode = False
            self.params = {}

        def get_bin_path(self, binary, required=False):
            assert binary == 'dpkg'
            binary = self.module.get_bin_path('dpkg', True)
            return binary



# Generated at 2022-06-20 21:46:05.496877
# Unit test for function main
def test_main():
    # Test with the correct current state.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, 'python install', ''))
    main()
    assert module.exit_json.called
    module.exit_json.assert_called_with(changed=False, before='install', after='install')
    module.run_command.assert_called_with(['/usr/bin/dpkg', '--get-selections', 'python'], check_rc=True)

    # Test with the wrong current state.
    module = Ansible

# Generated at 2022-06-20 21:46:13.115231
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible_collections.boxever.test.plugins.modules import test_dpkg_selections as test_module

    ac = test_module.ActionModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ), supports_check_mode=True)

    ac.run_command = lambda args, **kwargs: (0, "python install", None)

    rv = ac.run(ImmutableDict(dict(
        name="python",
        selection="hold",
        check_mode=True
    )))


# Generated at 2022-06-20 21:47:25.386518
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from parameterized import parameterized

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'
    changed = current != selection
    if changed:
        module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
        assert True

# Generated at 2022-06-20 21:47:39.562882
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    dpkg = 'testdpkg'
    name = 'testpackage'
    selection = 'hold'

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    def run_command_fn(params, check_rc=False):
        if params[0] == dpkg and params[1] == '--get-selections' and params[2] == name:
            return (0, 'testpackage	install', '')

# Generated at 2022-06-20 21:47:40.286093
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:47:44.969636
# Unit test for function main
def test_main():
    name = 'apache2'
    selection = 'hold'

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert changed == False


# Generated at 2022-06-20 21:47:56.016738
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]


    changed = current != selection


# Generated at 2022-06-20 21:47:58.770991
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as exception:
        assert exception.code == 0

# Generated at 2022-06-20 21:48:07.941083
# Unit test for function main
def test_main():
    # Unit test for function main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'])
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:48:10.272435
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-20 21:48:18.986307
# Unit test for function main
def test_main():

    # Test for invalid platform
    module = AnsibleModule(argument_spec={})
    module.params['platform'] = 'darwin'
    module.fail_json = Mock(return_value=None)
    with pytest.raises(TypeError):
        assert main()

    # Test for invalid module parameters
    module = AnsibleModule(argument_spec={})
    module.params['name'] = 'python'
    module.params['selection'] = 'absent'
    module.check_mode = False
    module.fail_json = Mock(return_value=None)
    with pytest.raises(AnsibleFailJson):
        assert main()

    # Test for valid module parameters
    module = AnsibleModule(argument_spec={})
    module.params['name'] = 'python'

# Generated at 2022-06-20 21:48:28.134265
# Unit test for function main
def test_main():
    module_test = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )

    class FakeModule(object):
        def __init__(self):
            self.params = module_test.params

        def get_bin_path(self, *args, **kwargs):
            return "/bin/dpkg"

        def check_mode(self):
            return

        def exit_json(self, *args, **kwargs):
            return

        def run_command(self, *args, **kwargs):
            if args[0][0] == "which":
                return (0, "/bin/dpkg", "")
