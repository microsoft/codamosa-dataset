

# Generated at 2022-06-20 21:40:32.586859
# Unit test for function main
def test_main():
    def get_bin_path():
        return '/bin/dpkg'
    def run_command(args, check_rc=True):
        assert args == ['/bin/dpkg', '--set-selections']
        return 0, "", "", ""
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.get_bin_path = get_bin_path
    module.run_command = run_command

    ret = main()
    assert ret == {'changed': True, 'after': 'purge', 'before': 'not present'}

# Generated at 2022-06-20 21:40:33.566675
# Unit test for function main
def test_main():
    result = main()


# Generated at 2022-06-20 21:40:42.094479
# Unit test for function main
def test_main():
    test_argv = ['arg1', 'arg2', 'arg3']
    with unittest.mock.patch('sys.argv', test_argv):
        with unittest.mock.patch.object(ansible.module_utils.basic.AnsibleModule, '__init__') as mock_ansible_module_init:
            with unittest.mock.patch.object(ansible.module_utils.basic.AnsibleModule, 'run_command') as mock_ansible_module_run_command:
                mock_ansible_module_init.return_value = None
                mock_ansible_module_run_command.return_value = (0, '', '')
                main()

# Generated at 2022-06-20 21:40:43.091168
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:40:53.692584
# Unit test for function main
def test_main():
    import sys
    import os
    import __builtin__
    import dpkg_selections
    import ansible.module_utils.basic
    import ansible.module_utils.action

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.exit_json = None
            self.fail_json = None

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)

        def exit_json(self, **kwargs):
            self.exit_data = kwargs

        def get_bin_path(self, arg, **kwargs):
            return "/bin/dpkg"


# Generated at 2022-06-20 21:40:59.481719
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import subprocess
    def run_command(args, data=None, check_rc=False, run_as_root=False,
            use_unsafe_shell=False, binary_data=False):

        if args[0] == 'dpkg':
            if args == ['dpkg', '--get-selections', 'python']:
                return (0, 'python install\n', '')
            elif args == ['dpkg', '--get-selections', 'notinst']:
                return (0, '', '')
            elif data == 'python hold':
                return (0, '', '')
            else:
                raise Exception('Invalid command')

# Generated at 2022-06-20 21:41:09.209215
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.run_command = mock.MagicMock()

    dpkg = module.get_bin_path('dpkg', True)

    name = 'test name'
    selection = 'test install'

    # Get current settings.
    module.run_command.return_value = (0, 'test name install', '')
    out = subprocess.check_output([dpkg, '--get-selections', name]).strip()
    if not out:
        current = 'not present'

# Generated at 2022-06-20 21:41:25.247813
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"
    
    class MockModule(object):

        def __init__(self):
            self.check_mode = False
            self.params = {"name": name, "selection": selection}
    
        def run_command(self, cmd, check_rc=True, data=None):
            self.cmd = cmd
            self.data = data
            return (0, "test_main_output", "test_main_error")
        def exit_json(self, changed=True, before="old_selection", after="new_selection"):
            self.changed = changed
            self.before = before
            self.after = after
            return True

# Generated at 2022-06-20 21:41:35.372506
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:39.605926
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = exit_json
    dpkg = '/usr/bin/dpkg'
    main()
    assert rc == 0
    assert out == "python hold\n"

# Generated at 2022-06-20 21:42:02.559878
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    dpkg = module.get_bin_path('dpkg', True)

    module.params['name'] = 'python'
    module.params['selection'] = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', module.params['name']], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    assert(current != module.params['selection'])
    changed = current != module.params['selection']

# Generated at 2022-06-20 21:42:05.708999
# Unit test for function main
def test_main():
    # A test for value of name
    def test_name():
        out = main()
        assert out[0] == 1

    # A test for value of selection
    def test_selection():
        out = main()
        assert out[1] == 1

# Generated at 2022-06-20 21:42:23.305399
# Unit test for function main
def test_main():
    import pytest
    import ansible.module_utils.basic as basic
    import ansible.module_utils.action as action
    import ansible.module_utils.platform as platform
    import ansible.module_utils.support as support
    from ansible.module_utils import dpkg_selections

    # Mock out all the classes this module uses.
    class MockBasic(basic.AnsibleModule):
        def __init__(self):
            basic.AnsibleModule.__init__(self)

# Generated at 2022-06-20 21:42:26.287082
# Unit test for function main
def test_main():
    import action_plugins.modules.dpkg_selections as dpkg_selections
    fake_params = {}
    result = dpkg_selections.main()
    assert result == "hello", "Expected result to be hello, but got %s" % result

# Generated at 2022-06-20 21:42:27.026990
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:42:41.168508
# Unit test for function main
def test_main():
    import base64
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.pycompat24 import get_exception
    try:
        from ansible.module_utils.urls import open_url
    except ImportError:
        open_url = None
    try:
        from ansible.module_utils._text import to_bytes
    except ImportError:
        to_bytes = None

    try:
        from ansible.module_utils.six.moves.urllib.error import HTTPError, URLError
    except ImportError:
        raise SkipTest("test_main requires urllib2")

    from ansible.module_utils.urls import ConnectionError, SSLValidationError

    from ansible.modules.packaging.os import dpkg_selections

    module = d

# Generated at 2022-06-20 21:42:42.185898
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:42:42.994961
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:42:50.595334
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params = {'name': 'test_test', 'selection': 'install'}
    dpkg = module.get_bin_path('dpkg', True)
    module.run_command = lambda command, data, check_rc: (0, "test_test\tdeinstall", "")
    module.run_command([dpkg, '--set-selections'], data="%s %s" % (module.params['name'],
                                                                  module.params['selection']), check_rc=True)
    main()

# Generated at 2022-06-20 21:43:04.286953
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.apt import ansible_module_get_platform_impl
    a = basic.AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    a._ansible_module._ansible_module_get_platform_impl = ansible_module_get_platform_impl()
    a.params = {'name': 'python', 'selection': 'hold'}
    main()

# Generated at 2022-06-20 21:43:16.053816
# Unit test for function main
def test_main():
    print("Hello world")
    main()

# Generated at 2022-06-20 21:43:21.303743
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, 'name install', ''))
    main()
    module.run_command.assert_called_once_with([
        'dpkg', '--get-selections', 'name'
    ], check_rc=True)


# Generated at 2022-06-20 21:43:22.146687
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:43:33.018486
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:33.831553
# Unit test for function main
def test_main():
    print("Should check something")

# Generated at 2022-06-20 21:43:34.634415
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:43:44.992793
# Unit test for function main
def test_main():
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    with open('test_package.deb', 'w') as f:
        f.write('')
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'test_package'
    selection = 'install'

    # Get current settings.

# Generated at 2022-06-20 21:43:59.079782
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:44:00.592837
# Unit test for function main
def test_main():
    out = main()
    assert out == True

# Generated at 2022-06-20 21:44:07.814496
# Unit test for function main
def test_main():
    # setup test environment
    import platform
    from ansible.module_utils import common
    from ansible.module_utils.basic import AnsibleModule
    from ansible.mode_utils.common.arguments import CommonArgs

    dpkg = common.find_executable("dpkg", True)
    assert dpkg.startswith("/")

    name = "python"
    selection = "hold"

    # test get_selections
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    assert out
    current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:44:49.471025
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    test.get_bin_path = lambda x, y: '/bin/dpkg'

    test.run_command = lambda x, check_rc=False: (0, 'python	install', '')
    test.params['name'] = 'python'
    test.params['selection'] = 'install'
    test.check_mode = False
    test._is_check_mode = lambda: False

    assert test.params['name'] == 'python'
    assert test.params['selection'] == 'install'

    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-20 21:44:57.382899
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # Simulate Ansible being imported in a module, for example, role test.
    class AnsibleMeta:
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.bypass_checks = bypass_checks
            self.no_log = False


# Generated at 2022-06-20 21:45:06.518874
# Unit test for function main
def test_main():
    import sys
    import os
    import subprocess
    from ansible.modules.packaging.os import dpkg_selections
    import pytest
    from ansible.module_utils.six import PY3, b
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.ansible_module_common import ANSIBLE_ARGS
    from io import StringIO

    old_stdin = sys.stdin
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    old_argv = sys.argv
    old_environ = os.environ

    def runmodule(function, module_args):
        sys.stdin = StringIO()
        sys.stdout = out = StringIO()
        sys.stderr = err

# Generated at 2022-06-20 21:45:21.433805
# Unit test for function main
def test_main():
    # Mock AnsibleModule class
    module_dict = dict(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    ansible_module = MagicMock(**module_dict)

    # Mock dpkg
    dpkg = '/usr/bin/dpkg'

    # Mock options
    ansible_module.params = {
        'name': 'python',
        'selection': 'hold',
    }

    # Mock run_command
    rc, out, err = (0, "python	install", None)
    ansible_module.run_command = MagicMock(return_value=(rc, out, err))

    #

# Generated at 2022-06-20 21:45:25.415541
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(),
            selection=dict()
        ),
        supports_check_mode=True
    )
    # Return False on error
    # Return True on success and changed
    if check_main(module) is False:
        raise


# Generated at 2022-06-20 21:45:27.080215
# Unit test for function main
def test_main():
    assert main() == False


# Generated at 2022-06-20 21:45:29.488267
# Unit test for function main
def test_main():
    print('Test of function main')
    # call function main
    main()

# Generated at 2022-06-20 21:45:37.449556
# Unit test for function main
def test_main():
    # Mock class ansible.module_utils.basic.AnsibleModule
    class AnsibleModuleMock:
        def __init__(self, **kwargs):
            # Mock objects
            self.params = kwargs.get('argument_spec')
            self.supports_check_mode = kwargs.get('supports_check_mode', False)

        def run_command(self, args, **kwargs):
            if args == ['/usr/bin/dpkg', '--get-selections', 'python']:
                return (0, 'python install', '')
            elif args == ['/usr/bin/dpkg', '--set-selections']:
                return (0, '', '')


# Generated at 2022-06-20 21:45:47.020763
# Unit test for function main
def test_main():
  module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

  dpkg = module.get_bin_path('dpkg', True)

  name = module.params['name']
  selection = module.params['selection']

  # Get current settings.
  rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
  if not out:
      current = 'not present'
  else:
      current = out.split()[1]

  changed = current != selection

  if module.check_mode or not changed:
      module.exit

# Generated at 2022-06-20 21:45:49.770134
# Unit test for function main
def test_main():
    module = ansible_module()
    module.params = { 'name': 'python', 'selection': 'hold' }

    try:
        dpkg_selections.main()
    except Exception as err:
        module.fail_json(msg=err)



# Generated at 2022-06-20 21:46:40.782959
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:46:41.709967
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:46:48.247678
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

# Generated at 2022-06-20 21:46:51.346447
# Unit test for function main
def test_main():
    print("Executing unit tests for module dpkg_selection")
    # FIXME: Add unit tests

# Generated at 2022-06-20 21:46:53.335321
# Unit test for function main
def test_main():
    res = main()
    assert res == True, "fail unit test"

# Generated at 2022-06-20 21:47:05.246210
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:47:19.850004
# Unit test for function main
def test_main():
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types

    error = False
    value = None


# Generated at 2022-06-20 21:47:31.538446
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:47:43.097771
# Unit test for function main
def test_main():
    dpkg_selections_mock = {'params': {'name': 'python', 'selection': 'hold'}, u'ansible_facts': {}, u'invocation': {u'module_args': {u'name': u'python', u'selection': u'hold'}}, u'start': u'2017-05-15 11:10:38.594040', u'cmd': u"[u'dpkg', u'--set-selections']", 'changed': True, u'_ansible_version': u'2.3.0.0'}
    dpkg_selections_mock['params']['name'] = 'python'
    dpkg_selections_mock['params']['selection'] = 'hold'
    dpkg_selections_mock['ansible_facts'].update({})
    d

# Generated at 2022-06-20 21:47:51.194635
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(required=True)
        ),
        check_invalid_arguments=False,
        supports_check_mode=True,
    )
    module.exit_json = lambda x: x
    assert main()

# Generated at 2022-06-20 21:50:08.691368
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    # Test with normal values
    values = [
        {
            'name': 'package1',
            'selection': 'install',
        }
    ]
    # ansible.module_utils.basic.AnsibleModule
    am = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ))
    am.params = values[0]
    assert main() == 0

    # Test with invalid param
    values = [
        {
            'name': 'package1',
            'selection': 'invalid',
        }
    ]

# Generated at 2022-06-20 21:50:19.050888
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys
    import tempfile

    try:
        from unittest import mock
    except ImportError:
        import mock

    def _get_bin_path(name, required=False):
        return os.path.join(os.path.dirname(os.path.realpath(__file__)), 'dpkg_selections_bin')

    def _run_command(self, args, data=None, check_rc=False):
        return (0, '%s install' % self.params['name'], '')

    module_mock = mock.MagicMock()
    module_mock.run_command = _run_command
    module_mock.get_bin_path = _get_bin_path
    module_mock.check