

# Generated at 2022-06-20 21:40:25.664537
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:40:32.925736
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = module.params['name']
    selection = module.params['selection']
    dpkg = module.get_bin_path('dpkg', True)

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:40:42.564885
# Unit test for function main
def test_main():
    # Mock test for function main.
    def run_command(cmd, data=None, check_rc=True):
        return 0, "", ""
    module_args = {
        'name': ["test"],
        'selection': "hold",
        'supports_check_mode': True
    }
    setattr(AnsibleModule, "run_command", run_command)
    ansible_module = AnsibleModule(argument_spec=module_args)
    # Main function
    main()
    # Assertions.
    assert ansible_module.run_command.call_count == 2
    args, kwargs = ansible_module.run_command.call_args
    assert args[0] == ['dpkg', '--get-selections', 'test']

# Generated at 2022-06-20 21:40:53.390208
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    test_module.run_command = MagicMock(return_value=(0, 'test hold', ''))
    with patch.object(test_module, 'exit_json') as mock_exit:
        main()
        mock_exit.assert_called_once_with(changed=False, before='test', after='hold')

    test_module.params['name'] = 'test2'
    test_module.params['selection'] = 'install'

# Generated at 2022-06-20 21:41:04.758371
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:41:16.100564
# Unit test for function main
def test_main():
    import argparse
    import json
    import os
    import shutil
    import tempfile
    import textwrap
    import unittest
    from importlib import import_module
    # save a reference to any modules imported prior to mocking
    original_import = __import__
    main_module = import_module(__name__)
    global dpkg_selections
    from ansible.utils.module_docs_fragments.platform import PlatformDocumenter
    global PlatformDocumenter
    from ansible.module_utils.basic import AnsibleModule
    global AnsibleModule
    global module
    from ansible.module_utils.action_common import ACTION_COMMON_ARGS
    global ACTION_COMMON_ARGS
    global module

    # Note: a more complex Dependency() is used here to avoid loading all the
    # action plugins (hen

# Generated at 2022-06-20 21:41:23.369975
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:41:26.820638
# Unit test for function main
def test_main():
    print("Test function main")


# Generated at 2022-06-20 21:41:34.725776
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Test cases for module
    # if test1 pass then return True and if test2 pass then return False
    test1 = True
    test2 = False
    if test1 == True:
        module.exit_json(changed=True, msg="Unit test for function main successfull")
    else:
        module.fail_json(msg="Unit test for function main failed")

# Generated at 2022-06-20 21:41:46.374932
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:42:04.571717
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)


# Generated at 2022-06-20 21:42:09.557760
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'openssh-server'
    module.params['selection'] = 'hold'

    main()
    main()

# Generated at 2022-06-20 21:42:22.105543
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # This is the best we can do to mimic the effect of the AnsibleModule class
    module.params = dict(name='python')
    module.params['selection'] = 'hold'
    module.check_mode = True
    module.exit_json = lambda x: module.params.update(x)
    main()

    assert module.params['changed'] == False

# Generated at 2022-06-20 21:42:25.659188
# Unit test for function main
def test_main():
  test_module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
      ),
      supports_check_mode=True,
  )
  test_name = test_module.params['name']
  test_selection = test_module.params['selection']

# Generated at 2022-06-20 21:42:34.018349
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'testname'
    selection = 'testselection'

    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    pc = PlayContext()
    tqm = None

# Generated at 2022-06-20 21:42:35.372006
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-20 21:42:47.577529
# Unit test for function main
def test_main():
    test_name = 'python'
    test_selection = 'hold'
    mock_params = {
        'name': test_name,
        'selection': test_selection,
        'check_mode': False,
        'diff_mode': False,
        'platform': 'debian'
    }

    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

        def get_bin_path(self, name, required):
            return name

        def run_command(self, command, check_rc=False, data=None):
            if command[-1] == '--get-selections':
                if data == test_name:
                    return (0, test_name + ' hold\n', '')

# Generated at 2022-06-20 21:42:56.333722
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    })

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_

# Generated at 2022-06-20 21:43:02.592660
# Unit test for function main
def test_main():
    m = AnsibleModule({'name': 'python', 'selection': 'hold'})
    m.get_bin_path = mock_get_bin_path
    m.run_command = mock_run_command
    main()
    m.exit_json.assert_called_with(changed=True, before='deinstall', after='hold')


# Generated at 2022-06-20 21:43:10.432904
# Unit test for function main
def test_main():
    # Import dependencies
    import ansible.module_utils.basic
    import sys

    for p in sys.path:
        if p.endswith("ansible/ansible/module_utils/"):
            ansible.module_utils.basic.BIN_PATH = [p + "/../.."]
            break

    # Create mock object to replace AnsibleModule class
    class AnsibleModuleMock(object):
        def __init__(self, module_args):
            self.module_args = module_args
            self.check_mode = False
            self.type_check = False
            self.params = {}

        def get_bin_path(self, binary, required=False):
            return binary


# Generated at 2022-06-20 21:43:32.781538
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:41.629509
# Unit test for function main
def test_main():
    try:
        from ansible.module_utils.deb_common import get_bin_path
    except:
        def get_bin_path(name):
            return "/usr/bin/" + name
    try:
        from ansible.modules.system.dpkg_selections import main
    except:
        main = sys.modules[__name__].main

    sys.modules['ansible.module_utils.deb_common'] = Mock()
    sys.modules['ansible.module_utils.deb_common'].get_bin_path = Mock(side_effect=get_bin_path)
    sys.modules['ansible.module_utils.basic'] = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule = Mock()

    module_class = Mock()

# Generated at 2022-06-20 21:43:51.533076
# Unit test for function main
def test_main():
    # example from module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:43:56.646809
# Unit test for function main
def test_main():
    args = {'name': 'python', 'selection': 'hold'}
    rc, out, err = AnsibleModule(argument_spec=args).run_command(['dpkg', '--set-selections'], data="python hold", check_rc=True)

# Generated at 2022-06-20 21:43:57.457180
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:43:59.920611
# Unit test for function main
def test_main():
    # Check if main is None
    assert dpkg_selections.main() is None


# Generated at 2022-06-20 21:44:07.833604
# Unit test for function main
def test_main():
    # Define AnsibleModule
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Get params
    params = m.params
    name = params['name']
    selection = params['selection']
    # Get exit_json()
    ej = m.exit_json
    # Check for dpkg presence
    if selection == 'hold':
        selection = 'install'

    ej(changed=True, before='', after='')

# Generated at 2022-06-20 21:44:08.664071
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:44:12.524338
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleModule.fail_json) as excinfo:
        main()
    assert 'required' in str(excinfo.value)


# Generated at 2022-06-20 21:44:24.565557
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:45:06.103860
# Unit test for function main
def test_main():
    class MockModule(object):
        """ Mocking AnsibleModule to test dpkg_selections.main() """
        def __init__(self, params, check_mode=True):
            self.params = params
            self.check_mode = check_mode
            self.bin_path = '/usr/bin'
            self.failed = False
            self.changed = False
            self.exit_args = {}

        def run_command(self, args, check_rc=False, data=None, binary_data=False):
            """ Fake run_command() to return output """
            if args[1] == '--get-selections':
                return 0, 'python hold', ''
            if args[1] == '--set-selections':
                if self.params['selection'] == 'hold':
                    return 0, '', ''
           

# Generated at 2022-06-20 21:45:10.273110
# Unit test for function main
def test_main():
    # Test if the function will work under normal circumstances
    assert main() == 0
    # Test if the function will throw an exception
    with pytest.raises(Exception) as e:
        assert main()

# Generated at 2022-06-20 21:45:11.177169
# Unit test for function main
def test_main(): 
    #assert True
    assert False


# Generated at 2022-06-20 21:45:23.208526
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:45:25.080542
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:45:35.540615
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:45:45.543191
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:45:51.903669
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    module.run_command.return_value = 0, 'dpkg-query --set-selections test_name test_selection', ''

# Generated at 2022-06-20 21:46:01.238637
# Unit test for function main
def test_main():
    import copy

    # No name
    module = AnsibleModule(argument_spec=dict())
    try:
        main()
    except SystemExit:
        pass
    assert module.fail_json.called_with(msg='name is required')

    # No selection
    module = AnsibleModule(argument_spec=dict(name='test'))
    try:
        main()
    except SystemExit:
        pass
    assert module.fail_json.called_with(msg='selection is required')

    # Invalid selection
    module = AnsibleModule(argument_spec=dict(name='test', selection='other'))
    try:
        main()
    except SystemExit:
        pass
    assert module.fail_json.called_with(msg='selection must be one of: install, hold, deinstall, purge, got: other')

   

# Generated at 2022-06-20 21:46:11.284407
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    args = {
        'name': name,
        'selection': selection,
    }

    # Test with selection as "hold" and "install"
    dpkg = '/usr/bin/dpkg'
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection
    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)


# Generated at 2022-06-20 21:47:16.371943
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'required': True}, 'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}}, supports_check_mode=True)
    module.get_bin_path = MagicMock(return_value=True)
    module.exit_json = MagicMock()
    module.run_command = MagicMock(return_value=(1, 'out', 'err'))
    module.get_bin_path = MagicMock(return_value=True)
    module.exit_json = MagicMock()
    module.check_mode = True
    main()
    module.exit_json.assert_called_with(changed=False, before='out', after='purge')


# Generated at 2022-06-20 21:47:28.008778
# Unit test for function main
def test_main():
    test_args = {
        'name': 'python',
        'selection': 'install'
    }
    with patch.object(module, 'run_command') as run_command_mock:
        with patch.object(module, 'get_bin_path') as get_bin_path_mock:
            with patch.object(module, 'exit_json') as exit_json_mock:
                get_bin_path_mock.return_value = 'dpkg'
                run_command_mock.side_effect = [('', '', ''),('', '', ''),('', '', ''),('', '', ''),('', '', ''),('', '', ''),('', '', ''),('', '', '')]
                main()

# Generated at 2022-06-20 21:47:34.328141
# Unit test for function main
def test_main():
    test_params = {
        "name": "python",
        "selection": "hold",
    }
    module.params = test_params
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        assert 'not present' == out
    else:
        assert 'not present' != out
        assert out.split()[1] == selection

# Generated at 2022-06-20 21:47:39.630381
# Unit test for function main
def test_main():
    name = 'pkgname'
    selection = 'hold'
    rc, out, err = main(name, selection)
    assert out == 'pkgname hold', out
    assert err == '', err
    assert rc == 0, rc
    assert selection in out, out

# Generated at 2022-06-20 21:47:40.290604
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 21:47:48.088966
# Unit test for function main
def test_main():
    test = AnsibleModule(
            argument_spec = dict(
                    name = dict(required=True),
                    selection = dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
                    ),
            supports_check_mode=True,
    )
    test.run_command = mock.Mock(return_value=("", "", 0))
    test.get_bin_path = mock.Mock(return_value="/usr/bin/dpkg")

    test.params['name'] = "python"
    test.params['selection'] = "hold"

    test_main()
    test.run_command.assert_called_with(["/usr/bin/dpkg", "--get-selections", "python"])

# Generated at 2022-06-20 21:47:49.589501
# Unit test for function main
def test_main():
    assert main == main_function

# Generated at 2022-06-20 21:48:04.692970
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    if not os.path.exists(dpkg):
        raise Exception("Skipping dpkg_selections unit test, dpkg binary not found")

    # Test module arguments.
    name = 'python'
    selection = 'hold'

    args = dict(
        name=name,
        selection=selection,
        supports_check_mode=True,
    )

    # Module execution.
    rc, out, err = ansible_module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    os.unlink(temp)
   

# Generated at 2022-06-20 21:48:18.969589
# Unit test for function main
def test_main():
    # Create the module object.
    module = ansible_module_create()

    # Use the mock_run_command method in place of the run_command method.
    module.run_command = ansible_module_run_command

    # Set up the arguments.
    name = {'name': 'python'}
    selection = {'selection': 'hold'}

    # Set the parameters.
    module.params = name
    module.params.update(selection)

    # Run the main function.
    main()

    # Test the results.
    assert module.exit_args['changed'] == True
    assert module.exit_args['before'] == 'install'
    assert module.exit_args['after'] == 'hold'

    # Unit test for function main - check mode
    # Set the check mode to true.
    module.check_

# Generated at 2022-06-20 21:48:24.490863
# Unit test for function main
def test_main():
    out = main(dict(
        an_int=1,
        a_string="two",
        a_bool=True,
        check_mode=True,
        diff_mode=True,
        platform="debian"
    ))
    assert(out['an_int'] == 1)
    assert(out['a_string'] == "two")
    assert(out['a_bool'] == True)
