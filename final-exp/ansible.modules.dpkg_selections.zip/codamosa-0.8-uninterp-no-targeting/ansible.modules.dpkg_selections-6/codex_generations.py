

# Generated at 2022-06-20 21:40:29.407151
# Unit test for function main
def test_main():
    src = {'name': 'test_main', 'selection': 'test-main'}
    dpkg = '/usr/bin/dpkg'
    args = {'run_command.return_value': (0, 'test-main install','std')}
    module = AnsibleModule(**args)
    module.params = src
    module.get_bin_path = lambda x, y: dpkg
    main()
    assert module.run_command.call_count == 1
    assert module.exit_json.call_count == 1


# Generated at 2022-06-20 21:40:40.759285
# Unit test for function main
def test_main():
    # Setup the module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Create mock for base classes
    dpkg = DpkgMock()
    rc = 0
    out = ''
    err = ''
    name = 'python'
    selection = 'hold'

    # Set the mock data to be returned
    name = 'python'
    selection = 'hold'
    module.params['name'] = name
    module.params['selection'] = selection
    dpkg.bin_path = [dpkg, '--get-selections', name]

# Generated at 2022-06-20 21:40:52.102407
# Unit test for function main
def test_main():

    # Test input from stdin is sent to dpkg --set-selections command
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )

    dpkg = module.get_bin_path('dpkg', True)
    package = 'python'

    current = module.run_command([dpkg, '--get-selections', package], check_rc=True)
    assert current[1].split()[1] == 'install'

    module.run_command([dpkg, '--set-selections'], data="%s hold" % package, check_rc=True)


# Generated at 2022-06-20 21:41:03.572867
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    module.check_mode = True

# Generated at 2022-06-20 21:41:09.209221
# Unit test for function main
def test_main():
    name = 'openssh-server'
    selection = 'deinstall'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-20 21:41:16.879069
# Unit test for function main
def test_main():
    # Test with no argument
    with pytest.raises(SystemExit):
        main()
    # Test with no filename
    with pytest.raises(SystemExit):
        main(filename=None)
    # Test with filename
    with open('filename', 'w') as f:
        f.write("python install")
    main(filename='filename')
    # Test with filename but don't match name
    with open('filename', 'w') as f:
        f.write("library install")
    main(filename='filename')
    # Test with filename and match name
    with open('filename', 'w') as f:
        f.write("python install")
    main(filename='filename', name='python')

# Generated at 2022-06-20 21:41:25.475786
# Unit test for function main
def test_main():
    expected_data = 'zsh install'

    def _run_command(command, check_rc=False):
        assert command == [dpkg, '--set-selections']
        return 0, expected_data, None

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = _run_command
    main()


# Other tests

# Generated at 2022-06-20 21:41:28.105634
# Unit test for function main
def test_main():
    assert dpkg_selections({'name': 'python', 'selection': 'hold'}) == True


# Generated at 2022-06-20 21:41:36.330747
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str', default='test_name'),
            selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'], type='str', default='install')
        ),
        supports_check_mode=True,
    )
    test_name = test_module.params['name']
    test_selection = test_module.params['selection']
    # above this is black magic and can not be unit tested

    # below this is instantiating module and running it

# Generated at 2022-06-20 21:41:43.578735
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.check_mode = True
    module.fail_json = lambda *args, **kwargs: True
    module.run_command = lambda *args, **kwargs: (0, 'package test hold', '')
    main()
    try:
        module.fail_json = lambda *args, **kwargs: False
        module.check_mode = False
        module.run_command = lambda *args, **kwargs: None
        main()
    except:
        pass
    else:
        raise Exception('fail_json not called')


# Generated at 2022-06-20 21:42:09.822108
# Unit test for function main
def test_main():
  import os
  import tempfile

  test_dpkg_selection = '''python hold
python-minimal install
python2.7 install
python2.7-minimal install
'''

  tmp = tempfile.NamedTemporaryFile()
  tmp.write(test_dpkg_selection)
  tmp.seek(0)

  os.environ["DPKG_GET_SELECTIONS"] = tmp.name

  args = {}
  args['name'] = 'python'
  args['selection'] = 'deinstall'
  main(args, True)

  os.unlink(os.environ["DPKG_GET_SELECTIONS"])
  del os.environ["DPKG_GET_SELECTIONS"]

# Generated at 2022-06-20 21:42:24.270735
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = test_module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = test_module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if test_module.check_mode or not changed:
        test

# Generated at 2022-06-20 21:42:33.559774
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        assert 0

# Generated at 2022-06-20 21:42:46.780878
# Unit test for function main
def test_main():
    import mock
    import os
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    module = mock.Mock()

    def run_command(command, check_rc=False):
        return 0, open(os.path.join(os.path.dirname(__file__), 'test_dpkg_selections.out'), 'r').read(), ''

    dpkg = '/usr/bin/dpkg_selections'
    name = 'python'
    selection = 'hold'

    module.run_command = run_command
    module.get_bin_path = mock.Mock(return_value=dpkg)
    module.check_mode = False
    module.params = {'name': name, 'selection': selection}
    main()

# Generated at 2022-06-20 21:42:55.830414
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:08.719301
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    class RunResult:
        def __init__(self, rc=0, obj=None, err=None):
            self.rc = rc
            self.obj = obj
            self.err = err

    class RunCommandMock:
        def __init__(self, module):
            self.module = module

        def __call__(self, args, check_rc=False, data=None):
            self.args = args
            print(args)

# Generated at 2022-06-20 21:43:09.321977
# Unit test for function main
def test_main():
  main()

# Generated at 2022-06-20 21:43:23.738918
# Unit test for function main
def test_main():
    # mock out the module

    class MyModule(object):
        def __init__(self, name='python', selection='hold', check_mode=False):
            self.params = {}
            self.params['name'] = name
            self.params['selection'] = selection
            self.check_mode = check_mode

        def get_bin_path(self, name, required=False):
            if len(name) != 4:
                return False
            return True

        def run_command(self, command, data=None, check_rc=True):
            if command[-2] == '--get-selections':
                if self.params['name'] == 'python':
                    return (0, 'python\tinstall', '')
                else:
                    return (0, '', '')

# Generated at 2022-06-20 21:43:27.165198
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert module.params['name'] == 'any_name'
    assert module.params['selection'] == 'install'

# Generated at 2022-06-20 21:43:36.280022
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    def run_command_mock(self, args, check_rc=False):
        class check_rc_mock(object):
            def __init__(self, rc):
                self.rc = rc

            def __eq__(self, other):
                return self.rc == other

            def __ne__(self, other):
                return self.rc != other

        class CommandResult(object):
            def __init__(self, rc, stdout, stderr):
                self.rc = rc
                self.stdout = stdout
                self.stderr = stderr

            def __getitem__(self, index):
                return [self.rc, self.stdout, self.stderr][index]


# Generated at 2022-06-20 21:44:02.820494
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-20 21:44:13.177300
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json

# Generated at 2022-06-20 21:44:14.758331
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:44:24.092297
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test_module.exit_json = lambda x: x
    test_module.fail_json = lambda x: x
    test_module.params = {
        "name": "test package",
        "selection": "hold",
    }
    result = main()
    assert result["changed"] == False


# Generated at 2022-06-20 21:44:28.193071
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

# Generated at 2022-06-20 21:44:32.490973
# Unit test for function main
def test_main():
    import sys
    args = sys.argv[1:]
    args.append("--name=python")
    args.append("--selection=hold")
    args.append("--check-mode")
    main(args)

# Generated at 2022-06-20 21:44:38.749728
# Unit test for function main
def test_main():
    # Test for Ubuntu 16.04.4 LTS
    name = 'python2.7'
    selection = 'install'
    current = 'install'
    check_rc = True
    data = 'python2.7 install'
    assert main() == (5, 'Python 2.7', 'Python 2.7')

# Generated at 2022-06-20 21:44:43.357527
# Unit test for function main
def test_main():
    import sys
    import os
    import io
    import json
    import shutil
    import tempfile
    import subprocess
    import contextlib

    tempdir = tempfile.mkdtemp()
    cmd = "dpkg --get-selections"
    no_python2 = "/usr/bin/python2 -c \"import shutil;shutil.rmtree('" + tempdir + "')\""
    no_python3 = "/usr/bin/python3 -c \"import shutil;shutil.rmtree('" + tempdir + "')\""
    no_python = "/usr/bin/python -c \"import shutil;shutil.rmtree('" + tempdir + "')\""
    no_python = no_python + ";" + no_python2 + ";" + no_python3


# Generated at 2022-06-20 21:44:53.163864
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule(argument_spec=dict(name=dict(required=True),
                                                      selection=dict(choices=['install', 'hold', 'deinstall', 'purge'],
                                                                     required=True)))

    dpkg = ansible_module.get_bin_path('dpkg', True)

    name = ansible_module.params['name']
    selection = ansible_module.params['selection']

    rc, out, err = ansible_module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-20 21:44:56.106229
# Unit test for function main
def test_main():
    """
    Tests for function main.
    :return:
    """
    assert main() is None



# Generated at 2022-06-20 21:45:29.630011
# Unit test for function main
def test_main():
    def run_command_mock(command, data=None, check_rc=False):
        if command[-1] == 'python':
            return (0, 'python	deinstall', '')
        else:
            return (0, '', '')

    main_orig = action_plugin.main
    action_plugin.main = lambda: True

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = run_command_mock
    module.exit_json = lambda x: x
    module.params['name'] = 'python'
    module.params['selection']

# Generated at 2022-06-20 21:45:44.353759
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assertTrue(changed)


# Generated at 2022-06-20 21:45:44.809103
# Unit test for function main
def test_main():
    assert main is not None

# Generated at 2022-06-20 21:45:49.262627
# Unit test for function main
def test_main():
    module_path = 'ansible/modules/system/dpkg_selections.py'
    module = imp.load_source('dpkg_selections', module_path)
    module.main()

# Generated at 2022-06-20 21:46:04.613765
# Unit test for function main
def test_main():

    # setup AnsibleModule mock
    module = AnsibleModuleMock()

    # dpkg = module.get_bin_path('dpkg', True)

    # Normally, name and selection are required, but they were previously not
    # required and i'm not sure how to test that yet
    # name = module.params['name']
    # selection = module.params['selection']
    name = 'python'
    selection = 'hold'

    # Get current settings
    rc = 0
    # out = [name + ' hold']
    out = 'python hold\n'
    
    current = out.split()[1]

    changed = current != selection

    # Normally, check_mode is a boolean, but for the sake of testing it's set to an integer
    check_mode = 1

    result = {}


# Generated at 2022-06-20 21:46:12.601292
# Unit test for function main
def test_main():
    # Define vars and run test
    arguments = dict(
        name="test_package",
        selection="install",
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-20 21:46:14.513256
# Unit test for function main
def test_main():
    # TODO
    pass

# Generated at 2022-06-20 21:46:16.460616
# Unit test for function main
def test_main():
    print("This is called from the main function")
    test_main()

# Generated at 2022-06-20 21:46:27.827367
# Unit test for function main
def test_main():
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.dpkg_selections import main

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

# Generated at 2022-06-20 21:46:31.543280
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command'):
        module.run_command.return_value = (0, '', '')
        main()

# Generated at 2022-06-20 21:47:41.953203
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    test.check_mode = True
    test.run_command = run_cmd
    test.exit_json = exit_json
    print(test.get_bin_path('pip'))
    main()


# Generated at 2022-06-20 21:47:43.255259
# Unit test for function main
def test_main():
    out = main()
    # This is just a stub
    assert out == "Something"

# Generated at 2022-06-20 21:47:55.144193
# Unit test for function main
def test_main():

    # Testing actual module
    from ansible.modules.native.package.dpkg import main
    import json

    args = dict(
        name=['python'],
        selection=['hold'],
        supports_check_mode=True,
    )

    # Mock out the module and file transformation functions
    class _mock_module(object):
        def __init__(self, noop):
            self.params = noop

        def exit_json(self, changed, before, after):
            print(json.dumps({'changed': changed, 'before': before, 'after': after }))

        def fail_json(self, msg):
            print(json.dumps({'failed': True, 'msg': msg }))

    module = _mock_module(args)

    # Mock out the read_file and diff_is_

# Generated at 2022-06-20 21:48:05.246059
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:48:16.492342
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = 'python'
    selection = 'hold'
    dpkg = 'dpkg'
    command = 'dpkg --get-selections ' + name
    out = 'python\thold\t\n'
    err = ''
    rc = 0
    m = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
                      supports_check_mode=True)


# Generated at 2022-06-20 21:48:26.730410
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:48:31.786355
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import sys
    import pytest
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules import dpkg_selections

    fd, test_path = tempfile.mkstemp()

# Generated at 2022-06-20 21:48:32.636132
# Unit test for function main
def test_main():
    result = main()
    assert result == True

# Generated at 2022-06-20 21:48:43.375869
# Unit test for function main
def test_main():
    out_source = '''\
1
2
3
'''
    out_data = '''\
123
456
789
abc
'''

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    def run_command(command, data=None, check_rc=False):
        if command[0] == 'dpkg' and command[1] == '--get-selections':
            if command[2] == 'abc':
                return (0, out_data, None)
            else:
                return (0, '', None)

# Generated at 2022-06-20 21:48:49.436513
# Unit test for function main
def test_main():
    # Importing modules for this test
    import os
    import tempfile
    import json

    args = {
            'name': 'foo',
            'selection': 'not present'
            }

    mock_file = tempfile.NamedTemporaryFile(delete=False)
    mock_file.write('# Generated by dpkg --get-selections\n')
    mock_file.close()

    args['_ansible_selinux_special_fs'] = {'fusectl': True, 'selinuxfs': True, 'devpts': True, 'securityfs': True, 'pstore': True, 'rpc_pipefs': True, 'binfmt_misc': True, 'fuse.gvfsd-fuse': True, 'autofs': True, 'hugetlbfs': True}