

# Generated at 2022-06-20 21:40:28.974468
# Unit test for function main
def test_main():
    # execute function main with valid command parameters
    main(argv=['ansible', '-m', 'dpkg_selections', '-a', 'name=python, selection=hold'])
    # execute function main with invalid command parameters
    assert main(argv=['ansible', '-m', 'dpkg_selections', '-a', 'name=python, selection=hold']) != 0

# Generated at 2022-06-20 21:40:40.680473
# Unit test for function main
def test_main():
    # Set up test environment
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module._ansible_no_log = True
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    module.run_command = lambda x, **kwargs: (0, name + ' ' + selection, '')
    args = {'name': 'test_name', 'selection': 'test_selection'}
    # Run module
    main()
    # Check if test was changed

# Generated at 2022-06-20 21:40:52.016097
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.removed import RemovedInAnsible26Warning, removed_module, removed_module

    # Set up a basic test for this module
    with open(os.devnull) as devnull:
        module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ),
            supports_check_mode=True,
        )
        dpkg = get_bin_path('dpkg', True)
        # Set up a fake package to test against
        name = "test-dpkg_selections"
        selection

# Generated at 2022-06-20 21:41:04.059590
# Unit test for function main
def test_main():
    # Test empty args
    module_args = {}
    module = AnsibleModule(**module_args)
    assert main() == module.fail_json("Please specify both name and selection")

    # Test single name
    module_args = dict(
        name='python',
        selection='hold'
    )
    module = AnsibleModule(**module_args)
    assert main() == module.fail_json("Please specify both name and selection")

    # Test single selection
    module_args = dict(
        name='python',
        selection='hold'
    )
    module = AnsibleModule(**module_args)
    assert main() == module.fail_json("Please specify both name and selection")

    # Test no change
    module_args = dict(
        name='python',
        selection='hold'
    )

# Generated at 2022-06-20 21:41:15.575292
# Unit test for function main
def test_main():

    # Unit tests for module dpkg_selections

    # Test for command ansible
    module = AnsibleModule(argument_spec={'name': {'required': True}, 'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}}, supports_check_mode=True)

    dpkg = '/usr/bin/dpkg'
    name = 'python'
    selection = 'hold'
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:41:26.358718
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # Create the module mock
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Create the AnsibleModule object
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-20 21:41:29.823631
# Unit test for function main
def test_main():
    # This module is not supported on Windows as dpkg command is not available on Windows
    if "windows" not in platform.system().lower():
        assert main() == True

# Generated at 2022-06-20 21:41:44.567535
# Unit test for function main
def test_main():
    tests = [
        [dict(name='python', selection='hold'), 'not present', 'hold'],
        [dict(name='link', selection='install'), 'deinstall', 'install'],
        [dict(name='diff', selection='deinstall'), 'install', 'deinstall'],
        [dict(name='jdk', selection='purge'), 'hold', 'purge'],
        [dict(name='lighttpd', selection='hold'), 'purge', 'hold'],
    ]

    for ind, test in enumerate(tests):
        f = open('test/test_dpkg_selections_%d.out' % (ind + 1), 'w')
        f1 = open('test/test_dpkg_selections_%d.err' % (ind + 1), 'w')
        main()

# Test code

# Generated at 2022-06-20 21:41:54.503254
# Unit test for function main
def test_main():
    from ansible.module_utils.action_plugins.dpkg_selections import main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection


# Generated at 2022-06-20 21:41:54.980804
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:42:01.482268
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 21:42:06.345962
# Unit test for function main
def test_main():
    testmodule = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert 'dpkg' in main()
    assert 'name' in main()
    assert 'selection' in main()

# Generated at 2022-06-20 21:42:18.608187
# Unit test for function main
def test_main():
    at = {'ansible_system': 'Debian', 'ansible_distribution': 'Debian', 'ansible_distribution_release': '8.0', 'ansible_distribution_version': '8.0'}

    test_module_attributes = dict(
        name="python",
        selection="install",
    );

    # Unit test init
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ), supports_check_mode=True)
    test_module_setup = module.mock_module_args(test_module_attributes)
    new_module = module_utils.basic.AnsibleModule(test_module_setup)

    #

# Generated at 2022-06-20 21:42:24.649908
# Unit test for function main
def test_main():
    # Check module arguments
    argumemts = {
            'name': 'python',
            'selection': 'hold'
            }
    module = AnsibleModule(argument_spec=argumemts,
            supports_check_mode=True)
    assert module.params['name'] == 'python'
    assert module.params['selection'] == 'hold'

# Generated at 2022-06-20 21:42:26.411905
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:42:27.164800
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:42:41.307831
# Unit test for function main
def test_main():
    # Mock module arguments
    module = AnsibleModule(
        argument_spec={
            'name': dict(required=True),
            'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        },
        supports_check_mode=True
    )

    # Mock module.run_command
    mock_run_command = MagicMock(return_value=(0, 'julia install', ''))
    module.run_command = mock_run_command

    # Mock module.exit_json
    mock_exit_json = MagicMock()
    module.exit_json = mock_exit_json

    main()

    # Ensure module.run_command was called with correct parameters.

# Generated at 2022-06-20 21:42:50.176908
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'install'

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        main()

    module.run_command

# Generated at 2022-06-20 21:42:53.447306
# Unit test for function main
def test_main():
    run_command = module.run_command
    module.run_command = Mock()
    module.run_command.return_value = 0, "python install", 'stderr'
    main()
    module.run_command = run_command

# Generated at 2022-06-20 21:42:58.803638
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"

    def run_command_mock(module, cmd, check_rc=True, data=None):
        print(cmd)
        assert cmd == [ dpkg, '--get-selections', name ]
        return 0, "python install", None

    def exit_json_mock(module, changed, before, after):
        print(changed)
        assert changed == True
        assert before == "install"
        assert after == "hold"

    setattr(module, 'run_command', run_command_mock)
    setattr(module, 'exit_json', exit_json_mock)
    main()


# Generated at 2022-06-20 21:43:10.841571
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    print(basic.__dict__)

# Generated at 2022-06-20 21:43:25.090971
# Unit test for function main
def test_main():
    # test_module_args: return_value
    test_module_args = {
        'name': 'python',
        'selection': 'hold'
    }

    # test_module_results: (changed, current, selection)
    test_module_results = (True, 'install', 'hold')

    # ansible_module: instance of AnsibleModule
    ansible_module = AnsibleModule(
        argument_spec=dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'],
                               required=True)
        ),
        supports_check_mode=True
    )

    def test_run_command(command, check_rc=True):
        return 0, 'python install', ''

    main()

# Generated at 2022-06-20 21:43:34.534877
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-20 21:43:38.174529
# Unit test for function main
def test_main():
    dpkg_path = "/usr/bin/dpkg"
    test = 0
    if dpkg_path is not False:
        test = 1
    assert test == 1


# Generated at 2022-06-20 21:43:43.779161
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(default='nmap'),
            selection=dict(default='hold', choices=['install', 'hold', 'deinstall', 'purge'])
        )
    )
    module.exit_json = lambda **kwargs: print(kwargs['before'])
    main()

# Generated at 2022-06-20 21:43:51.461753
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.check_mode = False

    # Test an install selection.
    dpkg_selections_main.__dict__['main'](module)
    module.run_command.assert_called_with(['dpkg', '--set-selections'], data="name install", check_rc=True)


# Generated at 2022-06-20 21:44:02.820590
# Unit test for function main
def test_main():

    # Test dpkg_selections module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Test dpkg cmd path
    dpkg = module.get_bin_path('dpkg', True)

    # Test package name
    name = module.params['name']

    # Test selection
    selection = module.params['selection']

    # Test current setting
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split

# Generated at 2022-06-20 21:44:13.178491
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.dpkg_selections import main

    # Test when check_mode is set
    module = AnsibleModule({
        'check_mode': True,
        'name': 'test',
        'selection': 'install'
    }, check_invalid_arguments=True)
    rc, out, err = main()

    assert rc['changed'] == False

    # Test with new selection
    module = AnsibleModule({
        'check_mode': False,
        'name': 'test',
        'selection': 'install'
    }, check_invalid_arguments=True)
    rc, out, err = main()

    assert rc['changed'] == False

    # Test with same selection

# Generated at 2022-06-20 21:44:17.389802
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "name": "python",
        "selection": "install"
    })

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)


# Generated at 2022-06-20 21:44:20.383337
# Unit test for function main
def test_main():
    try:
        main()
        assert False, "Main function should throw exception"
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-20 21:44:58.141414
# Unit test for function main
def test_main():
    name = "firefox"
    selection = "hold"

    import os
    import tempfile
    import StringIO

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.debian_common import *
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

    # Create a mock
    mock_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )

    dpkg = mock_module.get_bin_path('dpkg', True)

    name = mock_module.params

# Generated at 2022-06-20 21:45:07.472863
# Unit test for function main
def test_main():
    # Test with check_mode
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'vim'
    module.params['selection'] = 'hold'

    dpkg_selections = DpkgSelections(module)
    (changed, before, after) = dpkg_selections.main(check_mode=True)

    assert changed is True
    assert before == 'install'
    assert after == 'hold'

    # Test with check_mode and selection unchanged

# Generated at 2022-06-20 21:45:08.900692
# Unit test for function main
def test_main():

    main(check_mode=True)

# Generated at 2022-06-20 21:45:09.743360
# Unit test for function main
def test_main():
    assert ('test passed')

# Generated at 2022-06-20 21:45:11.410752
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"
    # TODO

# Generated at 2022-06-20 21:45:22.504805
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=False,
    )
    module.exit_json = lambda x: None
    dpkg = os.getcwdu() + '/dpkg'
    module.get_bin_path = lambda x, y: dpkg
    module.run_command = lambda x, check_rc=True: [0, 'python    install', '']
    main()
    assert dpkg_selections.main.__name__ == 'main'
    assert module.get_bin_path.called
    assert module.run_command.called

    # If we're not changing anything, don't call

# Generated at 2022-06-20 21:45:27.974004
# Unit test for function main
def test_main():
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    assert_equal(rc, 0)
    assert_equal(out, 'dpkg not installed')


# Generated at 2022-06-20 21:45:39.862928
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda cmd, data, check_rc=False, close_fds=True, executable=None, data_format=None, log_err=True, encoding=None, errors='strict', binary_data=False : (1, "python install", "")
    dpkg_selections.main()


# Generated at 2022-06-20 21:45:48.701701
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:45:56.363083
# Unit test for function main
def test_main():
    import sys
    from ansible.modules.packaging.os import dpkg_selections
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    # Mock the AnsibleModule as it isn't available for unit testing
    sys.modules['ansible.modules.packaging.os.dpkg_selections'] = m
    dpkg_selections.main()

    import os

# Generated at 2022-06-20 21:46:47.015075
# Unit test for function main
def test_main():

    main()

# Generated at 2022-06-20 21:46:58.832135
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        rc, out, err = module.run_command(
            [dpkg, '--set-selections'], data="%s install" % (name), check_rc=True)
    # Should be successful
    assert True

# Generated at 2022-06-20 21:46:59.695015
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-20 21:47:07.826488
# Unit test for function main
def test_main():
    args = dict(
        name = 'python',
        selection = 'hold'
    )
    module = AnsibleModule(argument_spec=args, supports_check_mode=True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    assert(current != selection)
    assert(module.check_mode is True)
    assert(module.check_mode is not changed)


# Generated at 2022-06-20 21:47:11.455537
# Unit test for function main
def test_main():
    current = 'hold'
    selection = 'hold'
    changed = current != selection
    assert changed is False


# Generated at 2022-06-20 21:47:12.021066
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:47:25.439075
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.shell import Shell
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.shell import Shell
    from ansible.module_utils.action_plugins.network.os.dpkg_selections import main

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    Shell.run_commands = Mock(return_value=(0, True, True))
    main()

# Generated at 2022-06-20 21:47:26.285587
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:47:29.702132
# Unit test for function main
def test_main():
    results = dict(
        changed=False, before='install', after='hold'
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )
    module.run_command = Mock(return_value=(0, "python install", None))
    main()
    assert module.exit_json.call_args == call(**results)


# Generated at 2022-06-20 21:47:42.467962
# Unit test for function main
def test_main():
    import sys
    import os
    module_name = 'dpkg_selections'
    # Check if module is not installed.
    if module_name not in sys.modules:
        # Check if we are in a virtual env.
        if os.environ.get('VIRTUAL_ENV'):
            # Install virtual env.
            pip = os.environ.get('VIRTUAL_ENV') + '/bin/pip'
            # Check if pip is not installed.
            if not os.path.exists(pip):
                # Install virtual env.
                os.system('python -m pip install virtualenv')
            # Create virtual env.
            os.system('python -m virtualenv -p python2 venv')
            # Instal Ansible.

# Generated at 2022-06-20 21:49:58.986154
# Unit test for function main
def test_main():
    cmd_line = ['ansible-playbook', '-i', 'tests/inventory', '-v', 'tests/test_dpkg_selections.yml']
    values = ansible_runner.AnsibleRunner(cmd_line=cmd_line).get_results()
    assert values['plays'][0]['tasks'][0]['hosts'][0]['changed'] == True
    assert values['plays'][0]['tasks'][0]['hosts'][0]['before'] == 'not present'
    assert values['plays'][0]['tasks'][0]['hosts'][0]['after'] == 'install'
    assert values['plays'][0]['tasks'][1]['hosts'][0]['changed'] == False

# Generated at 2022-06-20 21:49:59.807945
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:50:07.983878
# Unit test for function main
def test_main():
    import json

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-20 21:50:13.693110
# Unit test for function main
def test_main():
    dpkg_selections = {
        'name': 'python',
        'selection': 'hold'
    }

    mock = MagicMock(return_value = (0, 'python install', ''))
    with patch.dict(dpkg_selections.__salt__, { 'cmd.run_all': mock }):
       assert main() == '{"changed": true, "before": "install", "after": "hold"}'

# Generated at 2022-06-20 21:50:22.201247
# Unit test for function main
def test_main():
    mod = ActionModule({
        'name': 'python',
        'selection': 'hold',
        'get_bin_path': lambda x: "dpkg",
        'run_command': lambda x, check_rc=False: (0, 'python	install', '')
    }, "")
    assert main() == {"changed": True, "before": "install", "after": "hold"}
