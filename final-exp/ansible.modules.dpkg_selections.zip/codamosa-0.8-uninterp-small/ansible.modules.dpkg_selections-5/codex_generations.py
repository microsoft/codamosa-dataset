

# Generated at 2022-06-25 02:22:31.691573
# Unit test for function main
def test_main():
    var_0 = get_bin_path(True, 'dpkg', True)
    var_1 = get_bin_path(True, 'dpkg', True)
    var_2 = get_bin_path(True, 'dpkg', True)


# Generated at 2022-06-25 02:22:32.554135
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:22:33.699639
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == "'test'"


# Generated at 2022-06-25 02:22:41.262530
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(argument_spec={'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}, 'name': {'required': True}}, check_invalid_arguments=False, supports_check_mode=True)
    var_2 = var_1.get_bin_path('dpkg', True)
    var_3 = var_1.params['name']
    var_4 = var_1.params['selection']
    var_5, var_6, var_7 = var_1.run_command([var_2, '--get-selections', var_3], check_rc=True)
    var_11 = False
    if not var_6:
        var_8 = 'not present'
    else:
        var_8 = var_6

# Generated at 2022-06-25 02:22:42.224318
# Unit test for function main
def test_main():
    tag_0 = test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:22:44.578159
# Unit test for function main
def test_main():
    with pytest.raises(IOError) as excinfo:
        if main() == "Error":
            raise IOError("Error")
    exception_raised = excinfo.value.args[0]
    assert exception_raised == "Error"

# Generated at 2022-06-25 02:22:45.489495
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:22:46.168011
# Unit test for function main
def test_main():
    f_1 = main()


# Generated at 2022-06-25 02:22:46.842030
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:22:47.747889
# Unit test for function main
def test_main():
    try:
        main()
    except:
        main()


# Generated at 2022-06-25 02:22:57.969203
# Unit test for function main
def test_main():
    def test_var_0():
        return main()



# Generated at 2022-06-25 02:23:03.873687
# Unit test for function main
def test_main():
    import ansible.utils.template
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert main() == AnsibleModule.get_bin_path('dpkg', True)
    
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    assert main() == AnsibleModule.get_bin_path('dpkg', True)
    assert main() == AnsibleModule.get_bin_path('dpkg', True)
    assert main() == AnsibleModule.get_bin_path('dpkg', True)
    assert main() == AnsibleModule.get

# Generated at 2022-06-25 02:23:06.751106
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 02:23:07.517032
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:23:08.730356
# Unit test for function main
def test_main():
    # no arguments

    # name
    # selection
    assert type(var_0) is None

# Generated at 2022-06-25 02:23:09.962376
# Unit test for function main
def test_main():
    var_1 = 'install'
    var_2 = main(var_1)
    print(var_2)


# Generated at 2022-06-25 02:23:11.394119
# Unit test for function main
def test_main():
    print('Execute main')
    main()



# Generated at 2022-06-25 02:23:11.828203
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:23:14.089834
# Unit test for function main
def test_main():
    try:
        var_1 = main()
    except SystemExit as e:
        print('Caught exception: ' + str(e))
    raise Exception(var_1)


# Generated at 2022-06-25 02:23:23.837643
# Unit test for function main
def test_main():

    var_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        )

    dpkg = var_0.get_bin_path('dpkg', True)

    name = var_0.params[ 'name' ]
    selection = var_0.params[ 'selection' ]

    # Get current settings.
    var_1, var_2, var_3 = var_0.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not var_2:
        current = 'not present'
    else:
        var_4 = var_2.split()


# Generated at 2022-06-25 02:23:40.913019
# Unit test for function main
def test_main():
    var = main()
    assert var is None


# Generated at 2022-06-25 02:23:43.967418
# Unit test for function main
def test_main():
    function_name = 'dpkg_selections'
    args = []
    inp = False
    var_0 = main(function_name, args, inp)
    return var_0

# Generated at 2022-06-25 02:23:49.665571
# Unit test for function main
def test_main():
    mock = Mock()
    dpkg_selections = main()
    mock.get_bin_path = main()
    assert mock.get_bin_path() == dpkg_selections.get_bin_path()
    assert mock.run_command() == dpkg_selections.run_command()
    assert mock.exit_json() == dpkg_selections.exit_json()
    assert mock.run_command() == dpkg_selections.run_command()
    assert mock.exit_json() == dpkg_selections.exit_json()
    assert mock.run_command() == dpkg_selections.run_command()
    assert mock.exit_json() == dpkg_selections.exit_json()
    assert mock.exit_json() == dpkg_selections.exit_json()

# Generated at 2022-06-25 02:23:51.453652
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:23:52.009342
# Unit test for function main
def test_main():
    assert(main() == None)

# Generated at 2022-06-25 02:23:52.379547
# Unit test for function main
def test_main():
    assert true

# Generated at 2022-06-25 02:24:00.090393
# Unit test for function main
def test_main():
    var_1 = AnsibleModule.get_bin_path('dpkg', True)

    var_2 = module.params['name']

    var_3 = module.params['selection']

    # Get current settings.
    var_4 = module.run_command([var_1, '--get-selections', var_2], check_rc=True)
    if not var_4[1]:
        var_5 = 'not present'
    else:
        var_5 = var_4[1].split()[1]

    var_6 = var_5 != var_3

    if module.check_mode or not var_6:
        module.exit_json(changed=var_6, before=var_5, after=var_3)


# Generated at 2022-06-25 02:24:06.982271
# Unit test for function main
def test_main():

    var_0 = 'hold'

    var_1 = {
        'selection': 'hold', 
        'name': 'python'
    }

    var_2 = 'python'

    var_3 = 'python'

    var_4 = install

    var_5 = var_3

    var_6 = install

    var_7 = 'python'

    var_8 = var_6

    var_9 = var_7

    var_10 = var_8

    var_11 = var_9

    var_12 = var_10

    var_13 = var_4

    var_14 = var_5

    var_15 = var_6

    var_16 = dict
    var_17 = install, hold, deinstall, purge
    var_18 = var_16(choices=var_17, required=True)

# Generated at 2022-06-25 02:24:07.612247
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-25 02:24:08.014222
# Unit test for function main
def test_main():
    assert True == main()

# Generated at 2022-06-25 02:24:32.389557
# Unit test for function main
def test_main():
    assert var_0 == 1

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:24:34.750990
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as err:
        print('Test Failed')
        print(err)
        assert False



# Generated at 2022-06-25 02:24:38.525353
# Unit test for function main
def test_main():
    try:
        main()

    # AssertionError: AssertionError()
    except AssertionError as e:
        assert True


# Generated at 2022-06-25 02:24:40.558748
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == False, 'failed.'

# Generated at 2022-06-25 02:24:45.895611
# Unit test for function main
def test_main():
    set_module_args({
        'name': 'ansible_string',
        'selection': 'ansible_string'
    })
    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.modules.dpkg_selections.main', Mock(side_effect=test_case_0)):
        with patch('ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic.AnsibleModule', Mock(side_effect=test_case_0)):
            res = main()
            assert res.get('changed') is True


# Generated at 2022-06-25 02:24:48.594545
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except:
        assert False



# Generated at 2022-06-25 02:24:56.979513
# Unit test for function main
def test_main():
    var_0 = True
    var_1 = None
    var_2 = False
    var_3 = None
    var_4 = False
    var_5 = True
    var_6 = None
    var_7 = False
    var_8 = True
    var_9 = None
    var_10 = False
    var_11 = "python"
    var_12 = "hold"
    var_13 = None
    var_14 = None
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    var_15 = False
    var_16 = ()
    var_17 = 0
    var_18 = "dpkg"
    var_19 = "not present"
    var_20 = False
    var

# Generated at 2022-06-25 02:24:59.628844
# Unit test for function main
def test_main():
    assert test_case_0()[0] == 0

# Generated at 2022-06-25 02:25:01.356406
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:25:01.806522
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:26:10.430137
# Unit test for function main
def test_main():
    import tempfile
    import sys
    import os
    import json

    try:
        os.environ['TEST_FLAG_OUTPUT_DIR']
    except KeyError:
        print("must set env var TEST_FLAG_OUTPUT_DIR")
        sys.exit(1)

    temp_dir = tempfile.TemporaryDirectory()
    temp_file = os.path.join(temp_dir.name, 'ansible-retval')


# Generated at 2022-06-25 02:26:14.000265
# Unit test for function main
def test_main():
    var_0 = ''
    var_0 = main()

# Generated at 2022-06-25 02:26:16.141920
# Unit test for function main
def test_main():
    with patch('dpkg_selections.main') as mock_main:
        # call the function
        mock_main()
        assert mock_run_command.called

# Generated at 2022-06-25 02:26:19.467670
# Unit test for function main
def test_main():
    var_1 = {"check_mode": True, "selection": "hold", "name": "python"}
    main_mock = mocker.patch('main', return_value=var_1)
    assert var_1 == main()
    assert var_1 == main_mock.return_value
    main_mock.assert_called_once()
    main_mock.assert_called_once_with()


# Generated at 2022-06-25 02:26:20.509003
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False

# Replacement for function `run_command`

# Generated at 2022-06-25 02:26:24.120236
# Unit test for function main
def test_main():
    # Testing if the variable 'module' is created.
    var_0 = main()
    assert var_0 is not None



# Generated at 2022-06-25 02:26:27.813932
# Unit test for function main
def test_main():
    # Generate a test-case
    test_case = TestCase(ansible_params = {'name':'python', 'selection':'hold'},
                         ansible_module_results = {"changed": True, "before": "deinstall", "after": "hold"},
                         ansible_module_exit_status = 0)
    # Run the test-case
    var_0 = test_case.run()
    return var_0

# Run the test-cases
var_0 = test_case_0()

# Unit test end

# Generated at 2022-06-25 02:26:37.546435
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = var_1.get_bin_path('dpkg', True)

    var_2 = var_1.params['name']
    var_3 = var_1.params['selection']

    # Get current settings.
    var_4, var_5, var_6 = var_1.run_command([dpkg, '--get-selections', var_2], check_rc=True)
    if not var_5:
        var_7 = 'not present'
    else:
        var_7 = var_5

# Generated at 2022-06-25 02:26:41.415008
# Unit test for function main
def test_main():

    mock_module = MagicMock()

    module.get_bin_path = MagicMock(return_value="")

    module.run_command = MagicMock(return_value=(""))

    module.exit_json = MagicMock(return_value=(""))

    mock_module.check_mode = MagicMock(return_value=(""))

    mock_module.params = MagicMock(return_value=(""))

    module.params = MagicMock(return_value=(""))

    module.run_command = MagicMock(return_value=(""))

    main()

    main()

# Generated at 2022-06-25 02:26:43.549784
# Unit test for function main

# Generated at 2022-06-25 02:28:39.073112
# Unit test for function main
def test_main():
    set_variable = {
        'rc': 0,
        'current': 'install',
        'changed': True,
        'selection': 'hold'
    }

    var_0 = main()
    
    if var_0.rc != set_variable.rc:
        return False
        
    if var_0.current != set_variable.current:
        return False
    
    if var_0.changed != set_variable.changed:
        return False

    if var_0.selection != set_variable.selection:
        return False

    return True

# Generated at 2022-06-25 02:28:42.675938
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:28:44.395470
# Unit test for function main
def test_main():
    var_0 = dpkg_selections.main(['docker', 'docker-ce-cli', 'containerd.io'])
    if var_0:
        raise Exception("Unit test for function main fail")


# Generated at 2022-06-25 02:28:44.979559
# Unit test for function main
def test_main():
    assert isinstance(main(), object)


# Generated at 2022-06-25 02:28:47.606392
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-25 02:28:48.478489
# Unit test for function main
def test_main():
    var_0 = dpkg_selections()
    var_0.main()

# Generated at 2022-06-25 02:28:49.291737
# Unit test for function main
def test_main():
    # Unit tests for function main
    var_10 = main()



# Generated at 2022-06-25 02:28:51.798857
# Unit test for function main
def test_main():
    assert(test_case_0)

# Generated at 2022-06-25 02:28:58.467138
# Unit test for function main
def test_main():
    var_1 = {'diff': {}, 'after': 'install', 'module_args': {'selection': 'install', 'name': 'python'}, 'before': 'deinstall', 'msg': ' successfully changed'}
    var_2 = {'diff': {}, 'after': 'install', 'module_args': {'selection': 'install', 'name': 'vim'}, 'before': 'deinstall', 'msg': ' successfully changed'}
    var_3 = {'diff': {}, 'after': 'hold', 'module_args': {'selection': 'hold', 'name': 'vim'}, 'before': 'install', 'msg': ' successfully changed'}

# Generated at 2022-06-25 02:29:03.052293
# Unit test for function main
def test_main():
    module_mock = MagicMock()