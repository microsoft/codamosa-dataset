

# Generated at 2022-06-25 02:22:31.536664
# Unit test for function main
def test_main():
    var_1 = 'python'
    var_2 = 'hold'
    var_3 = 'dpkg'
    # Call function main
    main()
    # Check for function main return values
    if True:
        return
    else:
        return


# Generated at 2022-06-25 02:22:36.096153
# Unit test for function main
def test_main():
    var_0 = ""
    while var_0 == "":
        var_0 = raw_input("Enter choice [ 0 - 1 ]: ")
        if var_0 == "0":
            test_case_0()
        elif var_0 == "1":
            break
        elif var_0 != "":
            print("Invalid choice:", var_0)

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:22:37.192547
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-25 02:22:39.842051
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-25 02:22:46.689389
# Unit test for function main
def test_main():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None

    def function_name_0():
        return b'\x64\x70\x6B\x67'


    def function_name_1():
        return b'\x2D\x2D\x67\x65\x74\x2D\x73\x65\x6C\x65\x63\x74\x69\x6F\x6E\x73'



# Generated at 2022-06-25 02:22:49.612544
# Unit test for function main
def test_main():

    # For each test case
    for test_case in test_cases:
        # Assign arguments
        name = test_case[0]
        selection = test_case[1]

        # Execute function
        var_0 = main(name, selection)

        # Compare expected value
        assert var_0 == test_case[2]

    # Return successfully
    return True


# Generated at 2022-06-25 02:22:54.186078
# Unit test for function main
def test_main():
    var_1 = get_bin_path('dpkg', True, required=True, opt_dirs=[])
    var_2 = main()


# Generated at 2022-06-25 02:22:54.916711
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 02:23:01.820456
# Unit test for function main
def test_main():
    var_0 = make_mock('AnsibleModule')
    var_1 = make_mock('dpkg', return_var='dpkg')
    var_2 = make_mock('module.run_command', return_var = {'rc':0, 'out':'dpkg: error: no packages specified', 'err':''})
    get_bin_path = {'rc':0, 'out':'dpkg', 'err':''}
    make_mock('module.get_bin_path', return_var=get_bin_path)
    kwargs = {'required': True}
    make_mock('module.params', return_kwargs=kwargs)
    kwargs = {'required': True}
    var_4 = make_mock('module.params', return_kwargs=kwargs)


# Generated at 2022-06-25 02:23:06.016022
# Unit test for function main
def test_main():
    var_1 = AnsibleModule()
    var_1.get_bin_path('dpkg', True)
    # var_2 = ['dpkg', '--get-selections', 'name']
    var_3 = module.run_command(var_2, check_rc=True)
    if not out:
        var_4 = 'not present'
    else:
        var_4 = out.split()[1]
    var_5 = current != selection
    if module.check_mode or not changed:
        var_7 = changed=changed, before=current, after=selection
    else:
        var_6 = ['dpkg', '--set-selections']
        var_8 = "%s %s" % (name, selection)

# Generated at 2022-06-25 02:23:23.816459
# Unit test for function main
def test_main():
    dpkg = main.get_bin_path('dpkg', True)

    name = main.params['name']
    selection = main.params['selection']

    # Get current settings.
    rc, out, err = main.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if main.check_mode or not changed:
        main.exit_json(changed=changed, before=current, after=selection)

    main.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-25 02:23:30.920647
# Unit test for function main
def test_main():
    args = [{'selection': 'not present'}, {'selection': 'hold'}, {'selection': 'hold'}, {'selection': 'hold'}, {'selection': 'hold'}, {'selection': 'hold'}, {'selection': 'hold'}, {'selection': 'hold'}, {'selection': 'hold'}, {'selection': 'hold'}]
    assert main == args, 'test case_0 failed'

test_case_0()

# Generated at 2022-06-25 02:23:36.301887
# Unit test for function main

# Generated at 2022-06-25 02:23:40.885660
# Unit test for function main
def test_main():
    dpkg = main()
    # Check if dpkg is a str or not
    assert isinstance(dpkg, str)
    # Check if dpkg is a str or not
    assert isinstance(dpkg, str)


# Generated at 2022-06-25 02:23:47.190907
# Unit test for function main
def test_main():
    var_0 = __file__
    var_0 += ' '
    var_0 += '--name'
    var_0 += ' '
    var_0 += 'hello'
    var_0 += ' '
    var_0 += '--selection'
    var_0 += ' '
    var_0 += 'install'
    print("test_main()")
    # parameters
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    print("var_0 = %s " % (var_0))
    # main(var_0)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:23:54.541280
# Unit test for function main
def test_main():
    # Test case
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    import os
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

# Generated at 2022-06-25 02:23:56.487779
# Unit test for function main
def test_main():
    try:
        test_case_0()
        print('test_case_0: pass')
    except AssertionError:
        print('test_case_0: fail')


# Generated at 2022-06-25 02:23:58.289013
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 02:23:59.129730
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:24:00.121687
# Unit test for function main
def test_main():
    assert check_function(main, 'main')


# Generated at 2022-06-25 02:24:19.606528
# Unit test for function main
def test_main():
    with mock.patch('ansible_collections.ansible.community.plugins.modules.dpkg_selections.AnsibleModule') as ansible_module:
        with mock.patch('ansible_collections.ansible.community.plugins.modules.dpkg_selections.Apt') as apt:
            ansible_module.return_value.exit_json.return_value = None
            ansible_module.return_value.get_bin_path.return_value = None
            ansible_module.return_value.check_mode = True
            ansible_module.return_value.run_command.return_value = (1,2,3)
            ansible_module.return_value.params.return_value = {
                "name": "python",
                "selection": "hold"
            }
            main()

# Generated at 2022-06-25 02:24:20.140083
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:24:20.672062
# Unit test for function main
def test_main():
    assert True == False

# Generated at 2022-06-25 02:24:21.135321
# Unit test for function main
def test_main():
    var_1 = main()
    assert not var_1

# Generated at 2022-06-25 02:24:26.804699
# Unit test for function main
def test_main():
    with mock.patch('action_plugins.command.run_command.run_command', return_value=(0, '', '')):
        with mock.patch.object(os.path, 'exists', return_value=True):
            with mock.patch.object(os, 'getuid', return_value=1000):
                with mock.patch.object(__builtin__, 'open', mock.mock_open(read_data='foo')):
                    assert main() is None


# Generated at 2022-06-25 02:24:27.586507
# Unit test for function main
def test_main():
    print("\n")
    test_case_0()

# Generated at 2022-06-25 02:24:28.357470
# Unit test for function main
def test_main():
    assert(main())


# Generated at 2022-06-25 02:24:37.586458
# Unit test for function main
def test_main():
        out = ''
        err = ''
        rc = ''
        args = []
        args += [' ']
        args += ['']
        args = tuple(map(str, args))
        stdout, stderr, rc = any_shell_command(cmd=str(args)[1:-1], shell=True, use_unsafe_shell=True)
        if rc != 0:
                return (out, err, rc)
        b_out = any_shell_command_stdout_bytes()
        b_err = any_shell_command_stderr_bytes()
        return (b_out, b_err, rc)

# Generated at 2022-06-25 02:24:39.074154
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-25 02:24:39.547785
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0

# Generated at 2022-06-25 02:25:13.690805
# Unit test for function main
def test_main():
    var_0 = 'python'
    var_1 = 'hold'
    var_2 = 'dpkg'
    var_3 = 0
    var_4 = 'python hold\n'
    var_5 = None
    var_6 = 'not present'
    var_7 = 'hold'
    var_8 = False
    var_9 = 'python hold *\n'
    var_10 = 0

    dpkg = var_2
    name = var_0
    selection = var_1
    rc = var_3
    out = var_4
    err = var_5
    current = var_6
    module.run_command = MagicMock(return_value=(var_3, var_4, var_5))

# Generated at 2022-06-25 02:25:14.352370
# Unit test for function main
def test_main():
    assert 1 == 1
    #assert main() == 1

# Generated at 2022-06-25 02:25:16.076625
# Unit test for function main
def test_main():
  #argv = sys.argv

  #sys.argv = [argv[0]]
  #main()
  test_case_0()
  print("success")

# Generated at 2022-06-25 02:25:16.834963
# Unit test for function main
def test_main():
    assert var_0 == 'arg_0'

# Generated at 2022-06-25 02:25:21.093745
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False, "Exception when testing main()"

# Generated at 2022-06-25 02:25:23.783472
# Unit test for function main
def test_main():
    var_0 = {}
    var_0['AnsibleModule'] = AnsibleModule
    var_0['main'] = main
    var_0['test_case_0'] = test_case_0
    main()

# Generated at 2022-06-25 02:25:24.522465
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 02:25:26.637501
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:25:28.513089
# Unit test for function main
def test_main():
    var_0 = main()



# Generated at 2022-06-25 02:25:35.332526
# Unit test for function main
def test_main():
    # Prepare mock
    dpkg_selections_infos = dict()
    dpkg_selections_infos.update({'path': {"type": "str", "required": True, "choices": []}})
    dpkg_selections_infos.update({'name': {"type": "str", "required": True}})
    dpkg_selections_infos.update({'selection': {"type": "str", "required": True, "choices": ["install", "hold", "deinstall", "purge"]}})
    dpkg_selections_infos.update({'check_mode': {"type": "bool", "required": False}})
    dpkg_selections_infos.update({'diff_mode': {"type": "bool", "required": False}})

# Generated at 2022-06-25 02:26:40.853237
# Unit test for function main
def test_main():
    assert main(name='python', selection='hold'), 'AssertionError expected.'

# Test for case 1

# Generated at 2022-06-25 02:26:47.830030
# Unit test for function main
def test_main():
    args_0 = dict(name='', selection='hold')
    expected_0 = dict(changed=False, before='purge', after='hold')
    main_called_0 = dict(result=dict(changed=True, before='purge', after='hold'), command="dpkg --get-selections ''", rc=0)

    result_0 = main(**args_0)

    # Assertion to ensure that every method argument and expected return value is correct.
    assert expected_0 == result_0['result']
    assert main_called_0['command'] == result_0['invocation']['module_args']['_ansible_check_mode']['module_stdout']