

# Generated at 2022-06-25 02:22:27.947876
# Unit test for function main
def test_main():
    # Mock for function main
    var_0 = ansible_module_main(
        argument_spec={'name': dict(type='str'),
                       'selection': dict(type='str')},
        module_name='dpkg_selections'
    )

    assert var_0 == None

# Generated at 2022-06-25 02:22:37.008096
# Unit test for function main
def test_main():
    mock_run_command = MagicMock()

# Generated at 2022-06-25 02:22:44.219310
# Unit test for function main
def test_main():
    var_0 = {'main':{'name':'python2.7', 'selection':'install', 'check_mode':True}}
    var_0 = {'main':{'name':'python2.7', 'selection':'deinstall'}}
    var_0 = {'main':{'name':'python2.7', 'selection':'purge', 'check_mode':False}}
    var_0 = {'main':{'name':'python2.7', 'selection':'deinstall', 'check_mode':True}}
    var_0 = {'main':{'name':'python2.7', 'selection':'install', 'check_mode':False}}
    var_0 = {'main':{'name':'python2.7', 'selection':'purge', 'check_mode':True}}
    var_

# Generated at 2022-06-25 02:22:44.685364
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:22:54.253363
# Unit test for function main
def test_main():
    var_1 = main()
    if var_1 == 'selection':
        var_2 = main()
    else:
        var_3 = main()
        if var_3 == 'name':
            var_4 = main()
            if var_4 == 'dpkg' or var_4 == 'sudo':
                var_5 = main()
                if var_5 == 'check_mode' or var_5 == 'check_mode':
                    var_6 = main()
                    if var_6 == 'also_notify_email' or var_6 == 'context':
                        var_7 = main()
                        if var_7 == 'expand' or var_7 == 'when':
                            var_8 = main()

# Generated at 2022-06-25 02:23:00.199382
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:23:06.291883
# Unit test for function main

# Generated at 2022-06-25 02:23:07.113755
# Unit test for function main
def test_main():
    assert True == True



# Generated at 2022-06-25 02:23:14.180370
# Unit test for function main
def test_main():
    dpkg = (('dpkg'))
    name = (('name'))
    selection = (('selection'))
    current = (('current'))
    data = (('data'))
    out = (('out'))
    err = (('err'))
    module = (('module'))
    var_0 = (('module.check_mode'))
    var_1 = (('module.check_mode'))
    changed = (('changed'))
    module = (('module'))
    var_2 = (('module.run_command'))
    check_rc = (('True'))
    module = (('module'))
    var_3 = (('module.run_command'))
    check_rc = (('True'))
    module = (('module'))

# Generated at 2022-06-25 02:23:23.838259
# Unit test for function main
def test_main():
    var_1 = {'selection': 'hold', 'name': 'python'}
    var_2 = AnsibleModule(argument_spec=var_1, supports_check_mode=True)
    var_3 = var_2.get_bin_path('dpkg', True)
    var_4 = var_2.params['name']
    var_5 = var_2.params['selection']
    var_6, var_7, var_8 = var_2.run_command([var_3, '--get-selections', var_4], check_rc=True)
    if not var_7:
        var_9 = 'not present'
    else:
        var_9 = var_7.split()[1]
    var_10 = (var_9 != var_5)

# Generated at 2022-06-25 02:23:31.914777
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None


# Generated at 2022-06-25 02:23:39.757836
# Unit test for function main
def test_main():
    class adhoc_main:
        def __init__(self):
            self.run_command = None
            self.dpkg = None
            self.supports_check_mode = False
            self.check_rc = False
            self.params = {'name': 'python', 'selection': 'hold'}

        def check_rc(self, x):
            self.check_rc = x

        def get_bin_path(self, name, x):
            if name == 'dpkg':
                return self.dpkg
            raise Exception('should have passed dpkg')

        def run_command(self, command, check_rc=False, data=None):
            self.run_command = command
            if data:
                command.append(data)
            if check_rc:
                self.check_rc = True
            return

# Generated at 2022-06-25 02:23:40.439110
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:23:48.122109
# Unit test for function main
def test_main():
    var_1 = ( 'dpkg',  '--get-selections',  'python', )
    var_2 = ( 'dpkg',  '--set-selections', )
    var_3 = ( 'python hold', )
    var_4 = mock.return_value
    var_5 = mock.return_value
    var_6 = mock.return_value
    var_7 = ( '' )
    var_8 = ( 'not present' )
    var_9 = ( 'hold' )
    var_10 = ( True )
    var_11 = ( 'not present' )
    var_12 = ( 'hold' )
    var_13 = ( True )
    var_14 = ( 'not present' )
    var_15 = ( 'hold' )
    var_16 = ( True )


# Generated at 2022-06-25 02:23:49.375353
# Unit test for function main
def test_main():
    var_0 = main()
    assert True == var_0


# Generated at 2022-06-25 02:23:56.285499
# Unit test for function main
def test_main():
    # input
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-25 02:23:56.950731
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 02:23:58.778730
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 02:23:59.834473
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == ""

# Generated at 2022-06-25 02:24:05.670737
# Unit test for function main
def test_main():
    var_0 = main()
    number_of_arguments = 2
	# Defining typecheck for function main
    # return type should be NoneType
    assert not isinstance(var_0, NoneType)
	# Defining typecheck for function main
    # number of arguments should be 2

    # class '<type 'NoneType'>' has no attribute '__getitem__'
	# assert len(var_0) == number_of_arguments, "Invalid number of arguments."
    # class '<type 'NoneType'>' has no attribute '__getitem__'
	# assert len(var_0) == number_of_arguments, "Invalid number of arguments."

# Generated at 2022-06-25 02:24:17.684533
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:24:26.974592
# Unit test for function main
def test_main():
    var_main_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = var_main_0.get_bin_path('dpkg', True)

    name = var_main_0.params['name']
    selection = var_main_0.params['selection']

    # Get current settings.
    rc, out, err = var_main_0.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]


# Generated at 2022-06-25 02:24:29.742177
# Unit test for function main
def test_main():
    try:
    # Setup
        var_0 = main()
        assert var_0 == 1

    except Exception as var_1:

        raise var_1

# Test for function main
#
# Test for function main

# Generated at 2022-06-25 02:24:32.423342
# Unit test for function main
def test_main():
    assert var_0 == 0

# Test no input arguments

# Generated at 2022-06-25 02:24:41.929720
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:24:46.727151
# Unit test for function main
def test_main():
    # Dpkg package selection selections
    # Change dpkg package selection state via --get-selections and --set-selections.
    var_0 = "'''Dpkg package selection selections\nChange dpkg package selection state via --get-selections and --set-selections.\n'''"
    var_1 = "'''dpkg_selections'''"
    var_2 = "'''BSD'''"
    var_3 = "'''Ansible Project'''"
    var_4 = "'''Copyright: Ansible Project\nGNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)'''"

# Generated at 2022-06-25 02:24:48.400583
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Generated at 2022-06-25 02:24:53.653405
# Unit test for function main
def test_main():
    try:
        find_nearest_line = get_ipython().user_ns['find_nearest_line']
        check_line_num = get_ipython().user_ns['check_line_num']
        result = test_case_0()
        if '1' not in str(result):
            print('Expected result: 1')
            print('Actual result  :', str(result))
            check_line_num(__file__, 5)

    except Exception:
        if check_line_num:
            check_line_num(__file__, 5)
        raise



# Generated at 2022-06-25 02:24:57.712983
# Unit test for function main
def test_main():

    out, err = run_command(['dpkg', '--get-selections', 'python'])

    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != 'hold'
    
    
    if module.check_mode or not changed:
        module.exit_json(changed = changed, before = current, after = 'hold')
    module.run_command(['dpkg', '--set-selections'], data = '%name% hold', check_rc=True)
    main()


# Generated at 2022-06-25 02:25:01.584638
# Unit test for function main
def test_main():
    return_value = main()
    assert return_value == None, 'Function must be void'



# Generated at 2022-06-25 02:25:33.331377
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:25:34.443716
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == var_1


# Generated at 2022-06-25 02:25:35.194242
# Unit test for function main
def test_main():
    assert  isinstance(main(), tuple)



# Generated at 2022-06-25 02:25:36.125612
# Unit test for function main
def test_main():
    assert callable(main)

# Test for ansible issue #42343

# Generated at 2022-06-25 02:25:37.036247
# Unit test for function main
def test_main():

    # Check for a 0 return code
    assert var_0 == 0

# Generated at 2022-06-25 02:25:45.739096
# Unit test for function main
def test_main():
    mock_module = MagicMock()
    mock_module.params = {'selection': 'purge', 'name': 'python'}
    mock_module.run_command.return_value = (0, 'python purge\\n', '')
    mock_module.exit_json.return_value = None
    mock_module.get_bin_path.return_value = '/usr/bin/dpkg'

    main()

    mock_module.run_command.assert_called_once_with(['/usr/bin/dpkg', '--get-selections', 'python'], check_rc=True)
    assert mock_module.exit_json.call_count == 1
    assert mock_module.run_command.call_count == 1
    assert mock_module.get_bin_path.call_count == 1

# Generated at 2022-06-25 02:25:49.165242
# Unit test for function main
def test_main():
    assert True == var_0

# Generated at 2022-06-25 02:25:50.428810
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Error while executing test_case_0")
        raise

# Generated at 2022-06-25 02:25:52.341424
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main(1)


# Generated at 2022-06-25 02:25:58.635742
# Unit test for function main
def test_main():
    assert not main(
        **dict(
            name=dict(required=True,),
            selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'],),
        ),
    )
    assert not main(
        **dict(
            name=dict(required=True,),
            selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'],),
        ),
    )
    assert main(
        **dict(
            name=dict(required=True,),
            selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'],),
        ),
    )