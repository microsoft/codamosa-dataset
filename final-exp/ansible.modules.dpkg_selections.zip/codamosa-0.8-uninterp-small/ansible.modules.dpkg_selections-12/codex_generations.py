

# Generated at 2022-06-25 02:22:31.137074
# Unit test for function main
def test_main():
    module_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module_0.get_bin_path('dpkg', True)

    name = module_0.params['name']
    selection = module_0.params['selection']

    # Get current settings.
    rc, out, err = module_0.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection
    print(changed)



# Generated at 2022-06-25 02:22:31.656715
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 02:22:33.405974
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)
        assert False, "Uncaught exception!"



# Generated at 2022-06-25 02:22:34.616044
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass


# Generated at 2022-06-25 02:22:36.018090
# Unit test for function main
def test_main():
    # Make sure we can call the main function.
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-25 02:22:43.352294
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:22:43.976908
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 02:22:53.452155
# Unit test for function main
def test_main():
    var_0 = 'dpkg-query'
    var_1 = '--get-selections'
    var_2 = 'python'
    var_3 = 'rc'
    var_4 = 'out'
    var_5 = 'err'
    var_6 = 'module'
    var_7 = 'run_command'
    var_8 = 'check_rc'
    var_9 = 'var_0'
    var_10 = 'var_1'
    var_11 = 'var_2'
    var_12 = 'var_3'
    var_13 = 'var_4'
    var_14 = 'var_5'
    var_15 = 'var_6'
    var_16 = 'var_7'
    var_17 = 'var_8'

# Generated at 2022-06-25 02:22:59.576635
# Unit test for function main
def test_main():
    result = main()
    assert True == result

test_case_0()
#test_main()


# Run unit tests
# from ansible.module_utils.basic import AnsibleModule
# from ansible.module_utils.basic import *
# from ansible.modules.system.dpkg_selections import *
#
# module_mock = AnsibleModule(
#     argument_spec=dict(
#         name=dict(required=True),
#         selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
#     ),
#     supports_check_mode=True,
# )
#
#
# def run_module():
#     module_args = dict(
#         name='python',
#         selection='hold',
#     )
#     result =

# Generated at 2022-06-25 02:23:03.710592
# Unit test for function main
def test_main():
    var_0 = main()
    # main()
    name = "python"
    selection = "hold"
    assert name == "python"
    assert selection == "hold"


# Generated at 2022-06-25 02:23:13.223583
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:23:14.494911
# Unit test for function main

# Generated at 2022-06-25 02:23:17.819034
# Unit test for function main
def test_main():
    assert 'dpkg' == main()


# Generated at 2022-06-25 02:23:26.061804
# Unit test for function main
def test_main():
    var_argument_spec = dict()
    var_argument_spec['selection'] = dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    var_argument_spec['name'] = dict(required=True)
    var_module = AnsibleModule(argument_spec=var_argument_spec, supports_check_mode=True)
    var_module.run_command = Mock(return_value=(0, '', ''))
    var_module.exit_json = Mock(return_value=None)
    var_module.get_bin_path = Mock(side_effect=[None, None, None, None, '', '', '', '/usr/bin/dpkg', '/usr/bin/dpkg', '/usr/bin/dpkg'])
    var_module.params = {}
    var_

# Generated at 2022-06-25 02:23:27.974011
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Generated at 2022-06-25 02:23:28.731719
# Unit test for function main
def test_main():
    assert ''  == callable()

# Generated at 2022-06-25 02:23:31.012714
# Unit test for function main
def test_main():
    try:
        main()
    except Exception:
        import traceback
        exception = traceback.format_exc()
        print(exception, file=sys.stderr)
        assert False



# Generated at 2022-06-25 02:23:32.852179
# Unit test for function main
def test_main():
    mock_main = MagicMock(side_effect = main)
    mock_main.return_value = None
    assert mock_main('name', 'selection') == None  # I don't know what main returns

# Generated at 2022-06-25 02:23:33.525515
# Unit test for function main
def test_main():
    assert main == main


# Generated at 2022-06-25 02:23:39.685988
# Unit test for function main
def test_main():

    mock_module = Mock(
        argument_spec={
            'name': {
                'required': True,
            },
            'selection': {
                'choices': ['install', 'hold', 'deinstall', 'purge'],
                'required': True,
            },
        },
        supports_check_mode=True,
    )

    mock_get_bin_path = Mock(return_value='/usr/bin/dpkg')

    mock_run_command = Mock(
        return_value=(
            0, # rc
            'python install', # stdout
            '', # stderr
        )
    )


# Generated at 2022-06-25 02:24:03.348483
# Unit test for function main
def test_main():
    with patch.object(os, 'path') as mock_path:
        with patch.object(os.path, 'exists') as mock_exists:
            mock_exists.return_value = True
            with patch.object(os.path, 'isfile') as mock_isfile:
                mock_isfile.return_value = True
                mock_path.isfile.return_value = True

# Generated at 2022-06-25 02:24:05.093056
# Unit test for function main
def test_main():
    var_1 = main()
    return var_1 == var_0


# Generated at 2022-06-25 02:24:08.318426
# Unit test for function main
def test_main():
    assert True

# test_case_0


# Generated at 2022-06-25 02:24:15.908862
# Unit test for function main
def test_main():
    from unittest import TestCase
    from parameterized import parameterized
    from ansible.module_utils.basic import AnsibleModule
    
    class test_main(TestCase):
        def test_0(self):
            module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

# Generated at 2022-06-25 02:24:17.236510
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:24:26.570521
# Unit test for function main
def test_main():
    # Test dpkg path
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test_module.get_bin_path('dpkg', True)

    # Test package name
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test_module.params['name']

    # Test selection

# Generated at 2022-06-25 02:24:27.046906
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:24:29.446108
# Unit test for function main
def test_main():
    var_1 = 1
    var_2 = 1
    try:
        assert var_1 == 1
    except:
        var_2 = 1
    assert var_2 == 1

# Generated at 2022-06-25 02:24:32.683370
# Unit test for function main
def test_main():
    var_1 = main()
    assert (var_1) is not None, 'Query returned None'

# Generated at 2022-06-25 02:24:33.598835
# Unit test for function main
def test_main():

    result = main()




# Generated at 2022-06-25 02:25:07.995950
# Unit test for function main
def test_main():
    # Mock data from the module
    options = {
         'check_mode': True,
         'name': 'name',
         'selection': 'install'
    }
    # Mock '_ansible_check_mode' property
    setattr(AnsibleModule, '_ansible_check_mode', True)
    # Mock '_ansible_diff' property
    setattr(AnsibleModule, '_ansible_diff', True)
    # Mock '_ansible_no_log' property
    setattr(AnsibleModule, '_ansible_no_log', True)
    
    # data from the call to run_command
    run_command_data = (0, 'out', 'err')
    # Mock 'run_command' method

# Generated at 2022-06-25 02:25:16.279384
# Unit test for function main
def test_main():
    # Arrange
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-25 02:25:17.265111
# Unit test for function main
def test_main():
    assert main() == None, "main() did not return None"


# Generated at 2022-06-25 02:25:17.855330
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:25:18.818338
# Unit test for function main
def test_main():
    var_0 = main()
    print(var_0)
    assert var_0 == 'true'

# Generated at 2022-06-25 02:25:23.556929
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
   

# Generated at 2022-06-25 02:25:26.395583
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.common.run_command', MagicMock(return_value=0)) as mock_run_command:
        var_0 = main()
        

# Generated at 2022-06-25 02:25:27.326280
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 'Hello World'

# Generated at 2022-06-25 02:25:29.054264
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:25:35.871563
# Unit test for function main
def test_main():
    class_0 = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)), supports_check_mode=True)

    var_0 = class_0.get_bin_path('dpkg', True)

    name = class_0.params['name']
    selection = class_0.params['selection']

    # Get current settings.
    rc, out, err = class_0.run_command([var_0, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if class_0.check_mode or not changed:
        changed = changed

# Generated at 2022-06-25 02:26:46.791384
# Unit test for function main
def test_main():
    mock_action_common_attributes = Mock()
    mock_argument_spec = MagicMock()
    mock_argument_spec.dpkg = Mock()
    mock_dpkg = Mock()
    mock_AnsibleModule = MagicMock()
    mock_AnsibleModule.argument_spec = Mock()
    mock_AnsibleModule.argument_spec.return_value = mock_argument_spec
    mock_AnsibleModule.params = Mock()
    mock_AnsibleModule.params.get.return_value = mock_dpkg
    mock_AnsibleModule.get_bin_path = Mock()
    mock_AnsibleModule.get_bin_path.return_value = mock_dpkg
    mock_AnsibleModule.run_command = Mock()
    mock_rc = Mock()

# Generated at 2022-06-25 02:26:52.339063
# Unit test for function main

# Generated at 2022-06-25 02:27:01.921116
# Unit test for function main
def test_main():
    with mock.patch('ansible_collections.misc.not_a_real_collection.plugins.module_utils.action.ActionBase.__init__', return_value=None) as mock_method:
        var_0 = ansible_collections.misc.not_a_real_collection.plugins.module_utils.action.ActionBase()
    with mock.patch('ansible_collections.misc.not_a_real_collection.plugins.module_utils.action.ModuleBase.get_bin_path', return_value='/bin/dpkg') as mock_method:
        var_1 = ansible_collections.misc.not_a_real_collection.plugins.module_utils.action.ModuleBase().get_bin_path('dpkg', True)

# Generated at 2022-06-25 02:27:03.287477
# Unit test for function main
def test_main():
    var_0 = main()
    print(var_0)


# Generated at 2022-06-25 02:27:03.863048
# Unit test for function main
def test_main():
    assert test_case_0 == 0

# Generated at 2022-06-25 02:27:09.346957
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    var_2 = var_1.get_bin_path('dpkg', True)
    var_5 = var_1.params['name']
    var_9 = var_1.params['selection']
    var_10 = var_1.run_command([var_2, '--get-selections', var_5], True)
    var_12 = not var_10[1]
    if var_12:
        var_14 = 'not present'
    else:
        var_14 = var_10[1].split()

# Generated at 2022-06-25 02:27:10.314360
# Unit test for function main
def test_main():
    var_1 = main()
    assert None == var_1, None


# Generated at 2022-06-25 02:27:14.825724
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:27:25.195415
# Unit test for function main
def test_main():
    check_function_exists(globals(), 'main')
    check_function_exists(globals(), 'test_case_0')
    # Globals
    global module
    global dpkg

    # Set up Mock and Test Objects
    a = AnsibleModule(argument_spec={u'selection': {u'choices': [u'install', u'hold', u'deinstall', u'purge'], u'required': True}, u'name': {u'required': True}}, check_invalid_arguments=False, check_circular_dependencies=False, supports_check_mode=True)
    a.run_command = MagicMock(return_value=(0, '1', ''))
    a.get_bin_path = MagicMock(return_value='/usr/bin/dpkg')
   

# Generated at 2022-06-25 02:27:25.810412
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 02:29:24.769418
# Unit test for function main
def test_main():

    # Check that the function executes correctly
    assert main() == 0
    return

# Generated at 2022-06-25 02:29:30.014495
# Unit test for function main

# Generated at 2022-06-25 02:29:34.518800
# Unit test for function main
def test_main():
    try:
        assert check_output([u'dpkg', u'--get-selections', u'python'])
        assert check_output([u'dpkg', u'--get-selections', u'python'])
    except (CalledProcessError, OSError) as e:
        raise AssertionError(
            "command '{}' return with error (code {}): {}".format(
                e.cmd, e.returncode, e.output))

# Generated at 2022-06-25 02:29:37.685468
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Generated at 2022-06-25 02:29:43.071458
# Unit test for function main
def test_main():

    # mock module input
    module_args = {}
    module_args.update(
        dict(
            name='python',
            selection='hold',
        )
    )

    # Mock module calls
    mock_module_class = 'ansible_collections.ansible.builtin.plugins.modules.dpkg_selections.AnsibleModule'
    mock_module_instance = Mocker()
    mock_module = mock_module_instance.mock()
    mock_module.params = module_args
    mock_module.get_bin_path = MagicMock(side_effect=[
        '/usr/bin/dpkg',
        '/usr/bin/dpkg'
    ])

# Generated at 2022-06-25 02:29:46.826184
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:29:47.662341
# Unit test for function main
def test_main():
        var = True
        assert var == True


# Generated at 2022-06-25 02:29:53.136080
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:29:57.496383
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule.get_bin_path') as mock_1:
        with patch('ansible.module_utils.basic.AnsibleModule.run_command') as mock_2:
            mock_1.return_value = 'dpkg'
            mock_2.return_value = (0, 'dpkg --get-selections python', 0)
            assert main() == test_case_0()

# Generated at 2022-06-25 02:29:58.134099
# Unit test for function main
def test_main():
# Test case
    main()