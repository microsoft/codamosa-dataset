

# Generated at 2022-06-25 02:22:25.258482
# Unit test for function main
def test_main():
    assert main() == False


# Generated at 2022-06-25 02:22:28.646225
# Unit test for function main
def test_main():
    test_case_0()

# Load test for function main

# Generated at 2022-06-25 02:22:29.142970
# Unit test for function main
def test_main():
    assert True == False

# Generated at 2022-06-25 02:22:38.023634
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:22:45.136878
# Unit test for function main
def test_main():
    var_4 = AnsibleModule({"argument_spec": {"name": {"required": True}, "selection": {"choices": ["install", "hold", "deinstall", "purge"], "required": True}}, "supports_check_mode": True})
    var_5 = var_4.get_bin_path('dpkg', True)
    var_6 = var_4.params['name']
    var_7 = var_4.params['selection']
    var_8, var_9, var_10 = var_4.run_command([var_5, '--get-selections', var_6], check_rc=True)
    if not (var_9):
        var_11 = 'not present'
    else:
        var_11 = var_9.split()[1]

# Generated at 2022-06-25 02:22:45.803959
# Unit test for function main
def test_main():
    assert True == main()

# Generated at 2022-06-25 02:22:49.578538
# Unit test for function main
def test_main():
    # Run function main
    var_0 = main(
        name="python",
        selection="hold"
        )


# Update class mapping
TestCase = lambda **kwargs: type("TestCase", (object,), kwargs)
CASE_0 = TestCase(
    name='',
    test=0,
)
# Update class mapping
TestCase.CASE_0 = CASE_0

# Generated at 2022-06-25 02:22:53.885286
# Unit test for function main
def test_main():
    try:
        assert 'Test 2' == 'Test 1'
    except AssertionError:
        raise AssertionError


# Generated at 2022-06-25 02:22:54.884010
# Unit test for function main
def test_main():
    try:
        main()
    except:
        main()


# Generated at 2022-06-25 02:22:59.298155
# Unit test for function main
def test_main():
    try:
        var_0 = main()
    except Exception as e:
        raise Exception("Exception!")
    else:
        pass
    finally:
        pass

# Add tests to run
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:23:12.340328
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback, limit=2, file=sys.stdout)

if __name__ == '__main__':
    test_main()


# Generated at 2022-06-25 02:23:13.295003
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-25 02:23:22.282799
# Unit test for function main
def test_main():
    check_synopsis(main, "short_description", "Dpkg package selection selections")
    check_synopsis(main, "description", "Change dpkg package selection state via --get-selections and --set-selections")
    check_synopsis(main, "version_added")
    check_synopsis(main, "author", "Brian Brazil (@brian-brazil)  <brian.brazil@boxever.com>")
    check_synopsis(main, "options", "{'name': {'description': 'Name of the package.', 'type': 'str', 'required': True}, 'selection': {'description': 'The selection state to set the package to.', 'type': 'str', 'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}}")

# Generated at 2022-06-25 02:23:23.024864
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:23:24.684346
# Unit test for function main
def test_main():
    print('test_main:')
    assert (main() is None), "Failure"
    print('Success')
    print('test_passed')

test_main()

# Generated at 2022-06-25 02:23:33.638097
# Unit test for function main
def test_main():
    var_variable_0 = [
        {
            'selection': 'hold',
            'name': 'python'
        }
    ]

    var_variable_0 = [
        {
            'selection': 'hold',
            'name': 'python'
        }
    ]
    var_variable_0 = module.get_bin_path('dpkg', True)
    var_variable_0 = module.get_bin_path('dpkg', True)
    var_variable_0 = module.get_bin_path('dpkg', True)
    var_variable_0 = module.run_command(['dpkg', '--get-selections', 'python'], check_rc=True)
    if not var_variable_0:
        var_variable_0 = 'not present'

# Generated at 2022-06-25 02:23:34.812475
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        return False
    return True

# Generated at 2022-06-25 02:23:37.448253
# Unit test for function main
def test_main():
    arg_0 = {"name":"python", "selection":"hold"}
    assert main(**arg_0)
    arg_1 = {"name":"python", "selection":"deinstall"}
    assert main(**arg_1)
