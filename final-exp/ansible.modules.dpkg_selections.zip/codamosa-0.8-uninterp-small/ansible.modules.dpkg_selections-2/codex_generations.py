

# Generated at 2022-06-25 02:22:32.359467
# Unit test for function main
def test_main():
    ans_0 = {u'after': u'not present', u'changed': True, u'before': u'install'}
    ans_1 = {u'after': u'not present', u'changed': True, u'before': u'hold'}
    assert var_0 == ans_0 or var_0 == ans_1

# Generated at 2022-06-25 02:22:36.595478
# Unit test for function main
def test_main():
    # Input params
    name = 'python'
    selection = 'hold'
    run_command = e8804a6b388fc0d0b75441d109764c3f

    with patch('ansible.module_utils.basic.AnsibleModule.run_command', run_command):
        var_0 = main()

    # Check if test passed
    assert var_0 is not None


# Generated at 2022-06-25 02:22:37.949524
# Unit test for function main
def test_main():
    print("[+] Testing function main...")
    var_0 = main()


# Generated at 2022-06-25 02:22:39.650010
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:22:46.531633
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:22:51.506727
# Unit test for function main
def test_main():
    # TODO: Fix test.
    from unittest import mock

    dpkg = mock.Mock()
    module = mock.Mock()
    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    module.exit_

# Generated at 2022-06-25 02:22:54.388475
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert(False)

    assert(True)

# Test definition of var_0

# Generated at 2022-06-25 02:22:57.863923
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Generated at 2022-06-25 02:22:59.438032
# Unit test for function main
def test_main():
    module_name="test_main"
    module_name_space=__import__(module_name)
    var_0 = module_name_space.test_main()

# Generated at 2022-06-25 02:23:02.577507
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:23:21.123183
# Unit test for function main
def test_main():
    # Unit test for function main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-25 02:23:21.980968
# Unit test for function main
def test_main():
    assert True



# Generated at 2022-06-25 02:23:27.862055
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    var_2 = var_1.get_bin_path('dpkg', True)
    var_3 = var_1.params['name']
    var_4 = var_1.params['selection']
    var_5 = var_1.run_command([var_2, '--get-selections', var_3], check_rc=True)
    if not var_5[1]:
        var_6 = 'not present'
    else:
        var_6 = var_5[1].split()[1]
    var

# Generated at 2022-06-25 02:23:28.952606
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == 1

# Generated at 2022-06-25 02:23:29.720575
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 02:23:39.625722
# Unit test for function main
def test_main():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None

    ##
    ## AnsibleModule
    ##
    main_0 = main()

    ##
    ## main_0.get_bin_path
    ##
    module_0 = main_0
    get_bin_path_0 = module_0.get_bin_path()

    ##
    ## module_0.run_command
    ##
    run_command_0 = module_0.run_command()

    ##

# Generated at 2022-06-25 02:23:46.868515
# Unit test for function main
def test_main():
    with mock.patch('ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule.run_command') as mock_run_command:
        var = mock.MagicMock()
        var.rc = 10

        mock_run_command.return_value = (0, '', '')
        assert not main()

        mock_run_command.return_value = (10, '', '')
        assert main()

        mock_run_command.return_value = (0, 'asdf', '')
        assert not main()

        mock_run_command.return_value = (0, 'asdf', '')
        assert not main()

        mock_run_command.return_value = (0, 'asdf', '')


# Generated at 2022-06-25 02:23:54.541446
# Unit test for function main
def test_main():
    # Mock class for bin_path
    class bin_path:
        def get_bin_path(self, name, required=False):
            return 'dpkg'

    # Mock class for run_command
    class run_command:
        def check_rc(self, rc, check_rc=True):
            return True

        def run_command(self, a, b, check_rc=True):
            return True

    # Mock class for out
    class out:
        def split(self, a, b):
            return 1

    # Mock class for os
    class os:
        def makedirs(self, a):
            return True

    # Mock class for os.path
    class path:
        def abspath(self, a):
            return 'test'

    # Mock class for module

# Generated at 2022-06-25 02:23:56.529361
# Unit test for function main
def test_main():
    assert 'main' == var_0

# Generated at 2022-06-25 02:23:56.954372
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-25 02:24:11.840681
# Unit test for function main
def test_main():
    # Pass
    assert True == True


# Generated at 2022-06-25 02:24:13.177403
# Unit test for function main
def test_main():
    # Module yet to be implemented
    pass


# Generated at 2022-06-25 02:24:14.294749
# Unit test for function main
def test_main():
    var_1 = DpkgModule()
    var_1.main()

# Generated at 2022-06-25 02:24:14.787475
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:24:17.001324
# Unit test for function main
def test_main():
    var_1 = main()
    assert (var_1 == None), "main() should equal None"

# Generated at 2022-06-25 02:24:18.387788
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 02:24:19.075765
# Unit test for function main
def test_main():
    var_1 = test_case_0()

# Generated at 2022-06-25 02:24:20.905805
# Unit test for function main
def test_main():
    """Unit test for function main"""
    main()

# Generated at 2022-06-25 02:24:21.829597
# Unit test for function main
def test_main():
    assert (main() == 'True')

# Generated at 2022-06-25 02:24:22.771297
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:24:48.206127
# Unit test for function main
def test_main():
    pass

# Setting the values of all variables


# Generated at 2022-06-25 02:24:49.374463
# Unit test for function main
def test_main():
    assert func_0
    assert func_in_0
    assert func_out_0


# Generated at 2022-06-25 02:24:50.137129
# Unit test for function main
def test_main():
    assert 'AnsibleModule' in var_0

# Generated at 2022-06-25 02:24:52.440799
# Unit test for function main
def test_main():
    # TODO test
    pass
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:24:58.004925
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = var_0.get_bin_path('dpkg', True)

    name = var_0.params['name']
    selection = var_0.params['selection']

    # Get current settings.
    rc_0, out_0, err_0 = var_0.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out_0:
        current = 'not present'
    else:
        current = out_0.split()[1]


# Generated at 2022-06-25 02:25:07.754387
# Unit test for function main
def test_main():
    dpkg = main()



var = dpkg
var_0 = dpkg
var_1 = out
var_2 = err
var_3 = rc
var_4 = changed
var_5 = current
var_6 = selection
var_7 = name
var_8 = AnsibleModule()
var_9 = module.check_mode
var_10 = not changed
var_11 = module.fail_json
var_12 = module.exit_json
var_13 = module.run_command
var_14 = var_13
var_15 = 'dpkg'
var_16 = var_15
var_17 = module.get_bin_path
var_18 = True
var_19 = var_17
var_20 = var_18
var_21 = var_19
var_22 = var_20
var_23 = var

# Generated at 2022-06-25 02:25:08.615545
# Unit test for function main
def test_main():
    assert isinstance(var_0, AnsibleModule)


# Generated at 2022-06-25 02:25:11.500321
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("ERROR: function main() raised exception")
        return False
    return True


# Generated at 2022-06-25 02:25:16.832001
# Unit test for function main
def test_main():
    module = AnsibleModule (
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:25:17.652384
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False

# Generated at 2022-06-25 02:26:30.605363
# Unit test for function main
def test_main():
    # Source of fixture
    var_list = ['fixture/main.yml']
    ##
    ## Module parameters
    ##
    # Parameters:
    var_name = ['apache']
    var_selection = ['hold']
    # aliases: name
    # choices: ['install', 'hold', 'deinstall', 'purge']
    # required: True
    ##
    ## Module results of execution
    ##
    # Exit code:
    # Count:
    # Msg:
    # Stderr:
    # Stdout:
    ##
    assert var_0 == ["skipped"]


# Generated at 2022-06-25 02:26:32.832263
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 02:26:35.215131
# Unit test for function main
def test_main():
    var_0 = main()
    try:
        assert var_0 == 'var_0'
    except AssertionError as e:
        raise e

# Generated at 2022-06-25 02:26:40.608131
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert module
    dpkg = module.get_bin_path('dpkg', True)
    assert dpkg
    name = module.params['name']
    assert name
    selection = module.params['selection']
    assert selection
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection
    assert changed
    module

# Generated at 2022-06-25 02:26:43.293232
# Unit test for function main
def test_main():
    assert 'ArgumentError: argument selection: Invalid selection: "None", must be one of: install, hold, deinstall, purge' not in str(test_case_0)

# Generated at 2022-06-25 02:26:44.647936
# Unit test for function main
def test_main():
    try:
        var_1 = main()
        assert var_1 == 'done'
    except:
        raise AssertionError

# Generated at 2022-06-25 02:26:45.340507
# Unit test for function main
def test_main():
    assert var_0 == True

# Generated at 2022-06-25 02:26:45.767453
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:26:50.378792
# Unit test for function main
def test_main():
    test_0 = main()
    test_1 = main()
    test_2 = main()
    test_3 = main()
    test_4 = main()
    test_5 = main()
    test_6 = main()
    print("test_0", test_0)
    print("test_1", test_1)
    print("test_2", test_2)
    print("test_3", test_3)
    print("test_4", test_4)
    print("test_5", test_5)
    print("test_6", test_6)


# Generated at 2022-06-25 02:26:51.696905
# Unit test for function main
def test_main():
    var_0 = main(mock_0)


# Generated at 2022-06-25 02:28:48.259395
# Unit test for function main
def test_main():
    rc, out, err = main()
    print(rc)
    assert(rc==0)


# Generated at 2022-06-25 02:28:53.937477
# Unit test for function main
def test_main():
    with patch('ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule.run_command', return_value=(0, 'python install', '')):
        with patch('ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule.get_bin_path', return_value='/usr/bin/dpkg'):
            assert main() == {'changed': False, 'before': 'python', 'after': 'hold'}

# Generated at 2022-06-25 02:28:55.754523
# Unit test for function main
def test_main():
    var_0 = main()
    assert True


# Generated at 2022-06-25 02:28:57.031443
# Unit test for function main
def test_main():
    assert __name__ == '__main__'

# Generated at 2022-06-25 02:29:03.688748
# Unit test for function main
def test_main():
    import mock
    x = mock.Mock()
    x.get_bin_path = mock.Mock()
    x.get_bin_path.return_value = True
    x.check_mode = mock.Mock()
    x.check_mode.return_value = False
    x.params = mock.Mock()
    x.params.return_value = {'name': 'python', 'selection': 'hold'}
    x.run_command = mock.Mock()
    x.run_command.return_value = [0, True, True]
    x.exit_json = mock.Mock()
    x.exit_json.return_value = {'changed': True, 'before': 'deinstall', 'after': 'hold'}

# Generated at 2022-06-25 02:29:04.405768
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-25 02:29:06.389034
# Unit test for function main
def test_main():
    # Create the object and assign it as the local var.
    var_0 = main()
    # Run the test
    test_case_0()
    # Set the local var to None
    var_0 = None
    # Done
    return None

# Generated at 2022-06-25 02:29:07.031475
# Unit test for function main
def test_main():
    run_test_case(main)

# Generated at 2022-06-25 02:29:13.177522
# Unit test for function main
def test_main():
    import os
    import sys
    import main
    var_0 = 'python'
    var_0 = 'install'
    try:
        main.main(var_0, var_0)
    except SystemExit:
        pass

# Generated at 2022-06-25 02:29:17.936746
# Unit test for function main
def test_main():
    var_0 = True
    var_1 = False
    var_2 = True
    var_3 = main()
    assert var_0 == var_1
    assert var_2 == var_3