

# Generated at 2022-06-25 02:22:31.137066
# Unit test for function main
def test_main():
    var_0 = dpkg('--get-selections', name, check_rc=True)
    var_1 = not out
    var_2 = out.split()[1]
    var_3 = current != selection
    var_4 = module.check_mode
    var_5 = not var_3
    var_6 = [dpkg, '--set-selections']
    var_7 = '%s %s' % (name, selection)
    var_8 = module.run_command(var_6, data=var_7, check_rc=True)
    var_9 = var_3
    var_10 = var_0
    var_11 = var_2
    var_12 = var_0
    var_13 = var_11

# Generated at 2022-06-25 02:22:31.962884
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:22:39.603660
# Unit test for function main
def test_main():
    mock_module = Mock()
    mock_module.params = {'selection': 'hold', 'name': 'python'}
    var = mock_module
    mock_run_command = Mock()
    mock_run_command.side_effect = IOError()
    with patch.object(var, 'run_command', mock_run_command):
        mock_check_mode = Mock()
        mock_check_mode.return_value = False
        with patch.object(var, 'check_mode', mock_check_mode):
            mock_exit_json = Mock()
            with patch.object(var, 'exit_json', mock_exit_json):
                var.run_command([], True)
                var.run_command([], True)
                var.exit_json(changed=False, before='hold', after='hold')


#

# Generated at 2022-06-25 02:22:43.014646
# Unit test for function main
def test_main():
    # Mock exceptions.
    try:
        ansible.module_utils.basic.AnsibleModule.get_bin_path
        ansible.module_utils.basic.AnsibleModule.run_command
    except Exception as e:
        exc = str(e)
    else:
        exc = None
    assert exc is None


# Generated at 2022-06-25 02:22:48.870192
# Unit test for function main
def test_main():
    var_1 = {u'_ansible_parsed': True, u'_ansible_no_log': False, u'invocation': {u'module_args': {u'name': u'test_dpkg_selections', u'selection': u'install'}, u'module_name': u'dpkg_selections'}, u'changed': False, u'before': u'install', u'after': u'install'}

# Generated at 2022-06-25 02:22:49.819850
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None

# Generated at 2022-06-25 02:22:58.851189
# Unit test for function main
def test_main():
    var_0 = dpkg
    var_0 = module
    var_0 = main
    var_0 = create_python_script
    var_0 = req_0
    var_0 = ansible_module_utils
    var_0 = basic
    var_0 = AnsibleModule
    var_0 = argument_spec
    var_0 = dict
    var_0 = name
    var_0 = dict
    var_0 = required
    var_0 = True
    var_0 = selection
    var_0 = dict
    var_0 = choices
    var_0 = 'install'
    var_0 = 'hold'
    var_0 = 'deinstall'
    var_0 = 'purge'
    var_0 = required
    var_0 = True
    var_0 = supports_check_mode
   

# Generated at 2022-06-25 02:23:02.231079
# Unit test for function main
def test_main():

    assert False

# Generated at 2022-06-25 02:23:03.168868
# Unit test for function main
def test_main():
    assert func_0() == 'function_0'


# Generated at 2022-06-25 02:23:05.068960
# Unit test for function main
def test_main():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-25 02:23:13.770071
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:23:18.170478
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert(e.code == 0)

# Generated at 2022-06-25 02:23:19.640091
# Unit test for function main
def test_main():
    assert (main() == None)


# Generated at 2022-06-25 02:23:25.989832
# Unit test for function main
def test_main():
    try:
        with mock.patch('main.AnsibleModule') as ansible_module:
            ansible_module.params = {}
            ansible_module.return_value = {'check_mode': False, 'diff_mode': False, 'name': 'python', 'platform': 'debian', 'selection': 'hold'}
            ansible_module.run_command = mock.MagicMock(return_value=(0, '', ''))
            ansible_module.exit_json = mock.MagicMock()
            ansible_module.get_bin_path = mock.MagicMock(return_value='dpkg')
            main()
    except SystemExit:
        pass

# Generated at 2022-06-25 02:23:31.613003
# Unit test for function main
def test_main():
    # Mock module input parameters
    module = mock.Mock(ansible=True,name='python',selection='hold',
                       check_mode=True,supports_check_mode=True)
    module.run_command = mock.Mock(return_value=(0,'','','','','','','','','','','','','','',''))
    module.get_bin_path = mock.Mock(return_value=('ansible.module_utils.basic','',True))

    # Test function
    assert var_0 == main()

# Generated at 2022-06-25 02:23:33.942479
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Generated at 2022-06-25 02:23:34.871363
# Unit test for function main
def test_main():
    # print('main')
    var_1 = test_case_0()

# Generated at 2022-06-25 02:23:37.535822
# Unit test for function main
def test_main():
    var_1 = 'dpkg'
    var_2 = "python"
    var_3 = "hold"
    var_4 = False
    var_1 = get_bin_path(var_1, True)


# Generated at 2022-06-25 02:23:40.016479
# Unit test for function main
def test_main():
    name = "install"
    selection = "install"
    var_0 = main()


# Generated at 2022-06-25 02:23:40.714668
# Unit test for function main
def test_main():
    assert True == True



# Generated at 2022-06-25 02:24:04.111895
# Unit test for function main

# Generated at 2022-06-25 02:24:14.808417
# Unit test for function main
def test_main():
    # Get the module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-25 02:24:24.889775
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

   

# Generated at 2022-06-25 02:24:26.454179
# Unit test for function main
def test_main():
    var_0 = main()
    return (var_0 if dpkg == 'dpkg' else None)

# Generated at 2022-06-25 02:24:27.226807
# Unit test for function main
def test_main():

    var_0 = main()

# Generated at 2022-06-25 02:24:28.283113
# Unit test for function main
def test_main():
    var_0 = main()
    assert True


# Generated at 2022-06-25 02:24:30.072977
# Unit test for function main
def test_main():
    assert test_case_0() == 0


# Generated at 2022-06-25 02:24:32.286775
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:24:39.615805
# Unit test for function main
def test_main():
    file_path = os.path.dirname(__file__)
    with open(file_path + "/test_data.json") as json_file:
        test_data = json.load(json_file)
        test_data['ansible_facts']['ansible_check_mode'] = True
        test_data['ansible_facts']['ansible_diff_mode'] = True
        test_data['ansible_facts']['ansible_platform'] = "debian"
        test_data['ansible_module']['check_mode'] = True


# Generated at 2022-06-25 02:24:47.361394
# Unit test for function main
def test_main():
    dpkg = main()
    assert dpkg == None


# ansible all -m dpkg_selections -a "name=python selection=hold"
# ansible all -m dpkg_selections -a "name=python selection=hold" -b
# ansible all -m dpkg_selections -a "name=python selection=hold" -b -C
# ansible all -m dpkg_selections -a "name=python selection=hold" -b -C -v
# ansible all -m dpkg_selections -a "name=python selection=hold" -b -C -vvvv
# ansible all -m dpkg_selections -a "name=python selection=hold" -b -C -vvvvv
# ansible all -i hc-inventory-all -m dpkg_selections -a "name=python

# Generated at 2022-06-25 02:25:19.115683
# Unit test for function main
def test_main():
    var_0 = main()
    print(var_0)

# Generated at 2022-06-25 02:25:21.290418
# Unit test for function main
def test_main():

    # Call main(args)
    #
    # Test output
    assert var_0 == None

    # Check main(args)
    #
    # Test output
    assert var_0 == None

    # Call main(args)
    #
    # Test output
    assert var_0 == None

# Generated at 2022-06-25 02:25:26.245165
# Unit test for function main

# Generated at 2022-06-25 02:25:26.924878
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:25:27.605219
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 02:25:29.535566
# Unit test for function main
def test_main():
    if 1:
        var_return_value = main()
    else:
        var_return_value = run_func_0()
    assert type(var_return_value) == bool


# Generated at 2022-06-25 02:25:36.301887
# Unit test for function main
def test_main():
    # Setup
    var_0 = AnsibleModule(
        argument_spec={
            'name': {
                'required': True
            },
            'selection': {
                'choices': [
                    'install',
                    'hold',
                    'deinstall',
                    'purge'
                ],
                'required': True
            }
        },
        supports_check_mode=True
    )

    var_0_dpkg = var_0.get_bin_path('dpkg', True)

    var_0_name = var_0.params['name']
    var_0_selection = var_0.params['selection']

    # Testing

# Generated at 2022-06-25 02:25:37.854215
# Unit test for function main
def test_main():
    var_0 = main()
    #assert var_0 == ??


# Generated at 2022-06-25 02:25:39.542522
# Unit test for function main
def test_main():
    INPUT = '0'
    assert main() == 0, 'No error'

# ====================
# You can add your own tests below this comment block
# ====================

# Generated at 2022-06-25 02:25:42.695796
# Unit test for function main
def test_main():
    check_result = True
    # TODO: implement test
    return check_result

# vim: expandtab tabstop=4 shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 02:26:50.376211
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except:
        assert False, "Function main does not exists."
    try:
        assert isinstance(main(), dict)
    except:
        assert False, "Function main is not working properly."

test_case_0()

test_main()

# Generated at 2022-06-25 02:26:51.463445
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:26:54.078956
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:26:54.878879
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

# Generated at 2022-06-25 02:27:02.128514
# Unit test for function main
def test_main():
    assert "ansible.module_utils.basic.AnsibleModule.get_bin_path" in dpkg_selections.main.__code__.co_varnames or "ansible.module_utils.basic.AnsibleModule.get_bin_path" in dpkg_selections.main.__code__.co_names or "ansible.module_utils.basic.AnsibleModule.get_bin_path" in dpkg_selections.main.__code__.co_cellvars or "ansible.module_utils.basic.AnsibleModule.get_bin_path" in dpkg_selections.main.__code__.co_freevars


# Generated at 2022-06-25 02:27:03.529870
# Unit test for function main
def test_main():
    var_0 = main()
    res = (var_0)
    assert res



# Generated at 2022-06-25 02:27:05.447639
# Unit test for function main
def test_main():
    ansible_dev_mode = True
    name = 'python'
    selection = 'hold'
    module = AnsibleModule(argument_spec=module.params)
    main(module, ansible_dev_mode, name, selection)

# Generated at 2022-06-25 02:27:14.100080
# Unit test for function main
def test_main():
    var_1 = "ansible_module_name"
    #  Define a dictionary with parameters expected by the the module
    parameters = dict()
    parameters["name"] = "python"
    parameters["selection"] = "hold"
    var_2 = module_utils.basic.AnsibleModule(argument_spec=parameters)
    var_3 = "dpkg_selections"
    #  If a check mode is requested, exit with the appropriate  code
    #  Define a dictionary with parameters expected by the the module

# Generated at 2022-06-25 02:27:21.730634
# Unit test for function main
def test_main():
    var_0 = None
    # ****************************************
    # * Execute a new module.run_command call *
    # ****************************************

    # ****************************************
    # * Execute a new module.run_command call *
    # ****************************************

    # ****************************************
    # * Execute module.exit_json() *
    # ****************************************

    # ****************************************
    # * Execute a new module.run_command call *
    # ****************************************

    # ****************************************
    # * Execute module.exit_json() *
    # ****************************************

    # ****************************************
    # * Execute a new module.run_command call *
    # ****************************************

    # ****************************************
    # * Execute module.exit_json() *
    # ****************************************

    # ****************************************
    # * Execute a new module.run_command call *
    # ********************************

# Generated at 2022-06-25 02:27:31.218214
# Unit test for function main
def test_main():
    # Test case 0
    # Test function main

    var_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = AnsibleModule.get_bin_path(var_0, 'dpkg', True)

    name = AnsibleModule.params(var_0, 'name')
    selection = AnsibleModule.params(var_0, 'selection')

    # Get current settings.
    AnsibleModule.run_command(var_0, [dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-25 02:29:33.212326
# Unit test for function main
def test_main():
    var_1 = main()
    assert not var_1 == "hi"

main()

# Generated at 2022-06-25 02:29:42.111732
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(argument_spec=dict(name=dict(required=True),selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)),supports_check_mode=True, )
    var_0.get_bin_path('dpkg', True)
    var_0.params['name']
    var_0.params['selection']
    var_0.run_command([var_0.get_bin_path('dpkg', True), '--get-selections', var_0.params['name']], check_rc=True)
    var_0.params['selection']
    var_0.params['selection']
    var_0.params['selection']
    var_0.params['selection']
    var_0.params['selection']

# Generated at 2022-06-25 02:29:47.080176
# Unit test for function main
def test_main():
    from ansible.module_utils.common.systemd import check_systemd_support, get_same_execution_environment
    selinux_configured = check_selinux_support()
    systemd_configured = check_systemd_support()
    if selinux_configured and systemd_configured:
        execution_environment = get_same_execution_environment()
    else:
        execution_environment = None

    # Set up fake parameters
    name = 'PYTHON'
    selection = 'HOLD'

    # Set up return values
    rc = 0
    stdout = 'python install'
    stderr = ''
    # Set up side effects
    get_bin_path_calls = [
        create_call('dpkg', True),
        create_call('dpkg', True)
    ]
    run

# Generated at 2022-06-25 02:29:47.503143
# Unit test for function main
def test_main():
    assert not main()

# Generated at 2022-06-25 02:29:49.594746
# Unit test for function main
def test_main():
    args = {}
    args['name'] = 'python'
    args['selection'] = 'hold'
    result = main(args)
    assert result == 'success'

# Generated at 2022-06-25 02:29:52.284858
# Unit test for function main
def test_main():
    var_0 = ('name',)
    var_1 = ('selection', 'install')
    var_2 = {'selection': 'hold'}
    var_3 = {'selection': 'deinstall'}
    var_4 = {'selection': 'purge'}
    var_5 = {'name': 'not present'}
    var_6 = ('selection',)
    var_7 = ('selection',)

# Generated at 2022-06-25 02:29:59.912746
# Unit test for function main
def test_main():
    try:
        dpkg = get_bin_path('dpkg', True)
    except:
        pass
    dpkg = get_bin_path('dpkg', True)
    name = main().params['name']
    selection = main().params['selection']
    rc, out, err = main().run_command([dpkg, '--get-selections', name], check_rc=True)
    current = out.split()[1]
    changed = current != selection
    try:
        module.check_mode or not changed
    except:
        pass
    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)
    try:
        dpkg
    except:
        pass

# Generated at 2022-06-25 02:30:03.807723
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 02:30:05.085374
# Unit test for function main
def test_main():
    function_name = 'main'
    res = global_function_call(function_name, 0)



# Generated at 2022-06-25 02:30:09.606411
# Unit test for function main
def test_main():
    args = {
        'name': 'test',
        'selection': 'test'
    }
    res = main(args)