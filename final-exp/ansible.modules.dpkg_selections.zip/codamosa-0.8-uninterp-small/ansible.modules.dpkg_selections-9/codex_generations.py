

# Generated at 2022-06-25 02:22:36.482506
# Unit test for function main
def test_main():
    import paramiko
    class MockParamikoClient(object):
        def exec_command(self, cmd):
            return ('', '', '')
    class MockSSHClient(object):
        def connect(self, ip, port, username, password, key_filename=None, timeout=None):
            return
    class MockOS(object):
        class path(object):
            def exists(self, path):
                return True
    class MockProcess(object):
        def __init__(self, data):
            self._data = data
            self._len = len(data)
            self.stdout = self
            self.stderr = self
        def communicate(self):
            return (self._data, self._data)
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self

# Generated at 2022-06-25 02:22:45.490784
# Unit test for function main
def test_main():
    # Input parameters tests
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    os.system('/usr/bin/dpkg --get-selections ' + name);
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-25 02:22:46.415386
# Unit test for function main
def test_main():
    var_1 = main()

# Functions to run unit test.

# Generated at 2022-06-25 02:22:47.577688
# Unit test for function main
def test_main():
    assert True is main()


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 02:22:48.769866
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:22:57.891056
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    var_1 = module.get_bin_path('dpkg', True)
    var_2 = module.params['name']
    var_3 = module.params['selection']
    var_4 = module.run_command([var_1, '--get-selections', var_2], check_rc=True)
    var_5 = out.split()[1]
    var_6 = var_4 == var_3
    var_7 = module.check_mode or not var_6
    var_8 = module.run_

# Generated at 2022-06-25 02:22:59.917900
# Unit test for function main
def test_main():
    try:
        test_case_0()
        test_case_1()
    except:
        print("testcase failed")
    else:
        print("testcase passed")


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:23:02.607319
# Unit test for function main
def test_main():
    assert func_0 == 'foo'


# Generated at 2022-06-25 02:23:03.879254
# Unit test for function main
def test_main():
    assert_equal(main(), None)
    assert_equal(main(), None)
    assert_equal(main(), None)


# Generated at 2022-06-25 02:23:05.397461
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 02:23:22.341266
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:23:23.315217
# Unit test for function main
def test_main():
    assert test_case_0() is None


# Generated at 2022-06-25 02:23:26.204848
# Unit test for function main
def test_main():
    var_0 = dpkg_selections()
    print(var_0)

# Generated at 2022-06-25 02:23:27.706897
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-25 02:23:30.834807
# Unit test for function main
def test_main():
    args = {'name':'Python'}
    outcomes = [{'success': True, 'after': 'not present', 'before': 'install', 'changed': False}]
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required = True),
            selection = dict(choices = ['install', 'hold', 'deinstall', 'purge'], required = True)
        ),
        supports_check_mode = True,
    )
    module_result = module.params['name']
    for outcome in outcomes:
        result = main()
        assert result == outcome['success']

# Generated at 2022-06-25 02:23:34.379076
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('main function Exception')
        assert False



# Generated at 2022-06-25 02:23:36.429104
# Unit test for function main
def test_main():
    # AssertionError: The requested operation would completely empty the release file, aborting
    assert main() is None
# test_main()



# Generated at 2022-06-25 02:23:40.652817
# Unit test for function main
def test_main():
    out, err, rc = (0, 0, 0)
    if main() != 0:
        out, err, rc = (1, 0, 0)

    return out, err, rc


# Generated at 2022-06-25 02:23:41.053661
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:23:48.679446
# Unit test for function main
def test_main():
    var_0 = {}
    var_0['name'] = 'Test String'
    var_0['selection'] = 'Test String'
    var_0['check_mode'] = True
    var_0['diff_mode'] = True
    var_0['platform'] = 'Test String'
    var_0['support_check_mode'] = True
    var_0['support_diff_mode'] = True
    var_0['support_platform'] = True
    var_0['argument_spec'] = 'Test String'
    var_0['_ansible_diff_mode'] = True
    var_0['_ansible_check_mode'] = True
    var_0['_ansible_debug'] = True
    var_0['_ansible_debug_args'] = 'Test String'

# Generated at 2022-06-25 02:24:08.640605
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except AssertionError as e:
        raise(e)


# Generated at 2022-06-25 02:24:16.161776
# Unit test for function main
def test_main():
    var_1 = None
    var_2 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_

# Generated at 2022-06-25 02:24:16.723485
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:24:22.667784
# Unit test for function main
def test_main():
    argv = ["ansible-test", "fake", "/usr/local/bin/ansible-test", "/usr/local/lib/python2.7/dist-packages/ansible/module_utils/basic.py", "argparse", "/usr/lib/python2.7/dist-packages/argparse.pyc"]
    with mock.patch.object(sys, 'argv', argv):
        with mock.patch.object(basic, 'AnsibleModule', return_value=ansible_module):
            assert(var_0 == True)
        assert(var_0 == True)


# Generated at 2022-06-25 02:24:25.207166
# Unit test for function main
def test_main():
    res = main()
    if res[0][1] == '1':
        pass
    else:
        raise Exception('Test case failed: %s' % res)


# Generated at 2022-06-25 02:24:26.827026
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 02:24:27.877923
# Unit test for function main
def test_main():
    # check main return
    assert main() == None


# Generated at 2022-06-25 02:24:37.514762
# Unit test for function main
def test_main():
    with patch.object(module, 'run_command') as mock_run_command:
        mock_run_command.side_effect = mock_run_command_run_command
        with patch.object(module, 'run_command') as mock_run_command:
            mock_run_command.side_effect = mock_run_command_run_command
            with patch.object(module, 'run_command') as mock_run_command:
                mock_run_command.side_effect = mock_run_command_run_command
                with patch.object(module, 'exit_json') as mock_exit_json:
                    module.main()
                    mock_exit_json.assert_called_with()

# Generated at 2022-06-25 02:24:41.552381
# Unit test for function main
def test_main():
    check_func = 'main()'
    assert var_0 == check_func

# Generated at 2022-06-25 02:24:43.778851
# Unit test for function main
def test_main():
    # Mock import lib
    import sys

    import lib

    var_0 = main()
    assert var_0 is True

# Generated at 2022-06-25 02:25:13.658685
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:25:17.080975
# Unit test for function main
def test_main():
    var_0 = AnsibleModule('dpkg_selections')
    var_0 = AnsibleModule('dpkg_selections')
    var_0.params['name'] = main()
    var_0.params['selection'] = main()
    var_0 = dpkg_selections(var_0)
    assert dpkg_selections(var_0.params) == dpkg_selections(var_0)


# Generated at 2022-06-25 02:25:17.706459
# Unit test for function main
def test_main():
    # >>> print(var_0)
    pass

# Generated at 2022-06-25 02:25:23.292609
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            print('PASSED')
        else:
            print('FAILED')
    except Exception as e:
        print('FAILED')



# Generated at 2022-06-25 02:25:24.009996
# Unit test for function main
def test_main():
    assert(main() == True)


# Generated at 2022-06-25 02:25:25.831824
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 02:25:26.519383
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:25:33.237197
# Unit test for function main
def test_main():
    var_1 = main()

# Test case:
#     module = AnsibleModule(
#         argument_spec=dict(
#             name=dict(required=True),
#             selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
#         ),
#         supports_check_mode=True,
#     )
#     name = module.params['name']
#     selection = module.params['selection']
#     rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
#     if not out:
#         current = 'not present'
#     else:
#         current = out.split()[1]
#     test_case.assertEqual(len(out.split())==2, True

# Generated at 2022-06-25 02:25:39.336814
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict({
            'name': dict({
                'required': True,
                'type': 'str'
            }),
            'selection': dict({
                'required': True,
                'choices': [
                    'install',
                    'hold',
                    'deinstall',
                    'purge'
                ],
                'type': 'str'
            })
        }),
        supports_check_mode=True
    )

    var_1 = var_0.get_bin_path('dpkg', True)

    var_2 = var_0.params['name']

    var_3 = var_0.params['selection']

    # Get current settings.


# Generated at 2022-06-25 02:25:44.499152
# Unit test for function main
def test_main():
    with mock.patch('ansible_collections.calico.dpkg_selections.main', return_value=None) as _mock_main:
        with mock.patch('ansible_collections.calico.dpkg_selections.AnsibleModule', return_value=None) as _mock_AnsibleModule:
            test_case_0()





# Generated at 2022-06-25 02:26:55.105981
# Unit test for function main
def test_main():
    # No arguments provided
    path_0 = {'selection':'hold', 'name':'python'}
    ansible_main(path_0)
    result = dpkg_selections(path_0)
    assert result == '''- name: Prevent python from being upgraded\n  dpkg_selections:\n    name: python\n    selection: hold\n'''
    # Two valid arguments provided
    path_1 = {'selection':'hold', 'name':'python'}
    ansible_main(path_1)
    result = dpkg_selections(path_1)
    assert result == '''- name: Prevent python from being upgraded\n  dpkg_selections:\n    name: python\n    selection: hold\n'''
    # Two valid arguments provided

# Generated at 2022-06-25 02:26:56.981043
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:26:59.597515
# Unit test for function main
def test_main():
  assert test_case_0 == None
    
########################################################################################
# Automated testing code - run by 'python -m pytest test_dpkg_selections.py.py'
########################################################################################

# Called by py.test

# Generated at 2022-06-25 02:27:04.472112
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(api_version=2.0, argument_spec={'name': {'required': True, 'type': 'str'}, 'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge'], 'type': 'str'}}, supports_check_mode=True)
    var_1 = var_0.get_bin_path('dpkg', True)
    var_2 = var_0.params['name']
    var_3 = var_0.params['selection']
    var_4 = 'dpkg'
    var_5 = '--get-selections'
    var_6 = (var_1, var_5, var_2)

# Generated at 2022-06-25 02:27:08.411032
# Unit test for function main
def test_main():
    args = [
        {
            "name": {
                "id": "49bcac3c-a1bd-11e7-a97a-0800274c03d8",
                "type": "str"
            },
            "selection": {
                "id": "4b3e89e8-a1bd-11e7-a55d-0800274c03d8",
                "type": "str"
            }
        },
        False,
        False,
        False
    ]
    main_case_0(args)


# Generated at 2022-06-25 02:27:13.630069
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule', autouse=True) as mock_AnsibleModule:
        # Construct the mocks needed in this test
        from ansible.utils.platform import distro

        distro_mock = MagicMock()
        distro_mock.id = distro.id

        mock_AnsibleModule.return_value = MagicMock(
            argument_spec=dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            )
        )


# Generated at 2022-06-25 02:27:14.912654
# Unit test for function main
def test_main():
    try:
        main()
    except:
        main

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:27:15.692088
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:27:18.621239
# Unit test for function main
def test_main():
    var_0 = main()
    try:
        assert var_0
    except AssertionError:
        raise AssertionError("no")
    try:
        assert var_0
    except AssertionError:
        raise AssertionError("no")


# Generated at 2022-06-25 02:27:27.740678
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert type(var_0) == AnsibleModule
    var_1 = var_0.get_bin_path('dpkg', True)
    assert type(var_1) == str
    var_2 = var_0.params
    assert type(var_2) == dict
    var_3 = var_0.params['name']
    assert type(var_3) == str
    var_4 = var_0.params['selection']
    assert type(var_4) == str
    var_5 = var_0.run_command([var_1, '--get-selections', var_3], check_rc=True)
    assert type(var_5) == tuple

# Generated at 2022-06-25 02:29:30.756354
# Unit test for function main
def test_main():
    a = main()
    assert a, "Expected return value"


main()

# Generated at 2022-06-25 02:29:32.499890
# Unit test for function main
def test_main():
    assert( test_case_0() == None)

# Generated at 2022-06-25 02:29:37.346282
# Unit test for function main
def test_main():
    args = ['a', 'b', 'c']
    kwargs = {}
    output = main(*args, **kwargs)
    assert output == 'OK'