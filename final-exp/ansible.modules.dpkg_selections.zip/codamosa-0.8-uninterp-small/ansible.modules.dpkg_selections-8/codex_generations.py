

# Generated at 2022-06-25 02:22:29.215374
# Unit test for function main
def test_main():
    var_0 = get_bin_path_0()
    assert var_0 == var_0
test_main()


# Generated at 2022-06-25 02:22:31.076945
# Unit test for function main
def test_main():
    var_6 = main()
    var_6

# Generated at 2022-06-25 02:22:32.515574
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0 = {}
    main()
    assert test_case_0 == {}

# Generated at 2022-06-25 02:22:41.335407
# Unit test for function main
def test_main():
    with mock.patch(builtins.__name__ + ".open", mock.mock_open(read_data="foo"), create=True) as mock_file:
        mock_file.return_value.__iter__ = lambda self: self
        mock_file.return_value.__next__ = lambda self: next(iter(self.readline, ''))
        assert mock_file is mock_file
        assert mock_file() is not mock_file

        with mock.patch.object(builtins, "open", mock_open(read_data="foo")) as mock_file:
            assert mock_file is not open
            assert mock_file() is not open()
            assert mock_file() is not mock_file
            assert mock_file() is not mock_open(read_data="foo")
            assert mock_file.return_value.read

# Generated at 2022-06-25 02:22:43.410397
# Unit test for function main
def test_main():
    # Test case 0
    # This test case checks that a few things are true after calling main().
    #     assert isinstance(var_0, dict) is True
    assert main() is None

# Generated at 2022-06-25 02:22:47.541754
# Unit test for function main
def test_main():
    var_0 = dpkg
    var_0 = module
    var_0 = main
    var_0 = var_0
    var_0 = var_0
    var_0 = var_0


# Generated at 2022-06-25 02:22:54.453505
# Unit test for function main
def test_main():
    import dpkg_selections as ds
    module.run_command = ds.run_command(module, [dpkg, '--get-selections', name], check_rc=True)
    module.run_command = ds.run_command(module, [dpkg, '--set-selections'], data='%s %s', check_rc=True)
    var_1 = ds.main()[4]
    assert check_type(var_1, changed)

# Generated at 2022-06-25 02:23:01.805089
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:23:02.752257
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 02:23:03.588173
# Unit test for function main
def test_main():
    var_1 = 'main'
    assert var_1 == main()

# Generated at 2022-06-25 02:23:22.362556
# Unit test for function main
def test_main():
    try:
        main()
    except:
        main()
    assert True


# Generated at 2022-06-25 02:23:22.832717
# Unit test for function main
def test_main():
    assert True == main()

# Generated at 2022-06-25 02:23:23.538607
# Unit test for function main
def test_main():
    var_3 = main()


# Generated at 2022-06-25 02:23:27.418407
# Unit test for function main
def test_main():
    var_0 = main()

    assert(var_0 == None)

# Generated at 2022-06-25 02:23:27.913435
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:23:34.632280
# Unit test for function main
def test_main():
    # Disabling check_mode and diff atm cause the responses are not predictable
    testmodule = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        diff=False,
#        check_invalid_arguments=False
    )

    # Mock dpkg module output
    dpkg = "python install"
    rc = 0
    err = ""

    testmodule.run_command = Mock(return_value=(rc, dpkg, err))

    dpkg = testmodule.get_bin_path('dpkg', True)

    name = testmodule.params['name']
    selection = testmodule.params['selection']

    #

# Generated at 2022-06-25 02:23:35.793639
# Unit test for function main
def test_main():

    # The method main has no return value so this test is not useful
    pass

# Generated at 2022-06-25 02:23:43.713548
# Unit test for function main
def test_main():
    var_0 = 'deinstall'
    var_1 = 'not present'
    var_2 = ['/bin/dpkg']
    var_3 = 'hold'
    var_4 = ['/bin/dpkg', '--get-selections', 'python']
    var_5 = ['/bin/dpkg', '--set-selections']
    var_6 = 'python hold'
    var_7 = True
    var_8 = True

# Generated at 2022-06-25 02:23:44.551488
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Generated at 2022-06-25 02:23:52.104874
# Unit test for function main
def test_main():

    file = 'tests/data/plugin_tests/action/dpkg_selections.yml'
    data = yaml.safe_load(open(file, 'r').read())

    cmd = data['test_main']['cmd']
    check_rc = data['test_main']['check_rc']
    data = data['test_main']['data']
    check_rc = data['test_main']['check_rc']



# Generated at 2022-06-25 02:24:10.537999
# Unit test for function main
def test_main():
    dpkg = main()
    name = main()
    selection = main()
    rc = main()
    out = main()
    err = main()



# Generated at 2022-06-25 02:24:21.193555
# Unit test for function main
def test_main():
    var_1 = {'selection': 'hold', 'name': 'python'}

    class AnsibleModule:
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode

        def get_bin_path(self, name, required):
            return 'dpkg'


        def run_command(self, command, check_rc):

            class IOMock:
                def read(self):
                    return 'python deinstall'

            class ProcessMock:
                def __init__(self, rc):
                    self.rc = rc

                def communicate(self):
                    return IOMock(), ''

                def wait(self):
                    return self.rc


# Generated at 2022-06-25 02:24:22.500910
# Unit test for function main
def test_main():
    assert 'ansible.module_utils.basic' in sys.modules



# Generated at 2022-06-25 02:24:23.951263
# Unit test for function main
def test_main():
    assert 1 == 1, "Failed test function on line number"


# Generated at 2022-06-25 02:24:30.825842
# Unit test for function main

# Generated at 2022-06-25 02:24:41.171707
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    result = {"rc": 0, "changed": True, "module_stderr": "", "module_stdout": "", "msg": ""}
    result['test1'] = "https://docs.ansible.com/ansible/latest/modules/apt_module.html"
    result['test1_1'] = "https://www.cyberciti.biz/tips/debian-ubuntu-package-management-cheat-sheet.html"

# Generated at 2022-06-25 02:24:43.322607
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == ()
    #assert var_0[0] == 'test_case_0'


# Generated at 2022-06-25 02:24:43.693281
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:24:48.100639
# Unit test for function main
def test_main():
    var_0 = "hold"
    var_1 = "install"
    var_2 = "deinstall"
    var_3 = "purge"
    var_4 = 'dpkg'
    var_5 = 'dpkg-selections'
    var_6 = False
    var_7 = 'dpkg'
    var_8 = "hold"
    var_9 = 'dpkg'
    var_10 = "install"
    var_11 = 'dpkg'
    var_12 = "deinstall"
    var_13 = 'dpkg'
    var_14 = "purge"
    var_15 = 'dpkg'
    var_16 = "not present"
    var_17 = 'dpkg'
    var_18 = "hold"
    var_19 = 'dpkg'
    var_20

# Generated at 2022-06-25 02:24:56.685731
# Unit test for function main

# Generated at 2022-06-25 02:25:28.712085
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None


# Generated at 2022-06-25 02:25:29.926876
# Unit test for function main
def test_main():
    # Check if the expected result is the same with the output of the function:
    assert main() == True


# Generated at 2022-06-25 02:25:30.907525
# Unit test for function main
def test_main():
    var = main()
    assert(var['changed'] is True)

# Generated at 2022-06-25 02:25:32.324169
# Unit test for function main
def test_main():
    var_0 = dict(
        name='python',
        selection='hold'
    )
    main(var_0)

# Generated at 2022-06-25 02:25:33.332026
# Unit test for function main
def test_main():
    check_result_0 = main()
    assert check_result_0 == None

# Generated at 2022-06-25 02:25:39.411884
# Unit test for function main
def test_main():
    try:
        main
    except NameError:
        main = get_main()
    assert main

# Generated at 2022-06-25 02:25:48.005546
# Unit test for function main
def test_main():
    try:
        _ansible_module_runner
    except NameError:
        _ansible_module_runner = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ),
            supports_check_mode=True,
        )

    try:
        _ansible_module_runner_dpkg
    except NameError:
        _ansible_module_runner_dpkg = _ansible_module_runner.get_bin_path('dpkg', True)

    try:
        _ansible_module_runner_name
    except NameError:
        _ansible_module_runner_name = _ansible_module_runner.params['name']


# Generated at 2022-06-25 02:25:49.252379
# Unit test for function main
def test_main():
    # Test case 0:Initial test case, no inputs passed to main.
    test_case_0()

# Generated at 2022-06-25 02:25:50.081848
# Unit test for function main
def test_main():
    assert var_0 == 0, 'incorrect return value returned'

# Generated at 2022-06-25 02:25:55.566226
# Unit test for function main
def test_main():
    with patch('ansible_collections.ansible.community.plugins.modules.system.dpkg_selections.AnsibleModule',
                   new=MagicMock):
        with patch('ansible_collections.ansible.community.plugins.modules.system.dpkg_selections.module_run_command',
                   new=MagicMock(return_value=(0, 'success', ''))):
            with patch('ansible_collections.ansible.community.plugins.modules.system.dpkg_selections.module_exit_json',
                       new=MagicMock):
                var_0 = test_case_0()
                assert var_0 == main()

# Generated at 2022-06-25 02:26:58.727726
# Unit test for function main
def test_main():
  x = 3
  y = 5
  expected_x = 3
  expected_y = 5
  assert x == expected_x
  assert y == expected_y

# Generated at 2022-06-25 02:27:03.837914
# Unit test for function main
def test_main():
    # Create the mock object
    module = AnsibleModule_mock = mock.Mock()

    # Define the class attributes
    #
    # Arguments that were provided to this module, aleb if not supported
    # ArgumentSpec_mock = mock.Mock()
    # ArgumentSpec_mock.argument_spec = {'name': {'required': True}, 'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}}
    #
    # module.params = {'name': 'puppet', 'selection': 'hold'}
    #
    # ArgumentSpec_mock.supports_check_mode = True
    #
    module.get_bin_path.return_value = True
    # module.run_command.return_value = True

    # Set the method to

# Generated at 2022-06-25 02:27:07.874756
# Unit test for function main
def test_main():
    # Python 2.x
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    # Python 3.x
    else:
        from io import StringIO

    # captured output
    capturedOutput = StringIO()
    sys.stdout = capturedOutput

    # call function
    main()

    # revert stdout
    sys.stdout = sys.__stdout__

    # assert
    assert capturedOutput.getvalue() == "6\n"


if __name__ == '__main__':
    import sys
    sys.exit(main())

# Generated at 2022-06-25 02:27:08.332441
# Unit test for function main
def test_main():
    assert(True)

# Generated at 2022-06-25 02:27:09.316768
# Unit test for function main
def test_main():
    arg0 = main(0)
    assert arg0 == 0

# Generated at 2022-06-25 02:27:17.033437
# Unit test for function main
def test_main():
    com_str_0 = "python"
    com_str_1 = "install"
    var_0 = AnsibleModule(argument_spec=dict(name=dict(required=True)), supports_check_mode=True)
    com_0 = "dpkg"
    com_1 = "--get-selections"
    com_2 = "not present"
    var_0 = var_0.get_bin_path(com_0, True)
    var_1 = var_0.run_command([com_0, com_1, com_str_0], check_rc=True)
    var_2 = var_1[1]
    if not var_2:
        var_3 = com_2
    else:
        var_3 = var_2.split()[1]
    var_4 = var_3

# Generated at 2022-06-25 02:27:27.599439
# Unit test for function main

# Generated at 2022-06-25 02:27:30.086941
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:27:33.883116
# Unit test for function main
def test_main():
    var_1 = {'selection': ['hold'], 'name': ['python']}
    var_2 = False
    var_6 = {'before': 'hold', 'after': ['hold']}
    var_3 = main(var_1, var_2, var_6)


# Generated at 2022-06-25 02:27:36.175515
# Unit test for function main
def test_main():
    try:
        assert main
    except NameError:
        assert False

# Generated at 2022-06-25 02:29:38.847558
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:29:42.398398
# Unit test for function main
def test_main():
    # main()
    assert 'main'


# Generated at 2022-06-25 02:29:47.321680
# Unit test for function main
def test_main():
    var_0 = 'install'
    var_1 = '/opt/ansible/module_utils/facts/system/platform.py'
    var_2 = 'dpkg'
    var_3 = 'not present'
    var_4 = []
    var_5 = {'selection': 'install', 'name': 'python'}
    var_6 = 'python'
    var_7 = '/usr/lib/python2.7/dist-packages/ansible/modules/packaging/os/dpkg_selections.py'
    var_8 = 'hold'
    var_9 = 'python'
    var_10 = 'install'
    var_11 = '/usr/lib/python2.7/dist-packages/ansible/module_utils/facts/system/platform.py'

# Generated at 2022-06-25 02:29:48.948450
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 02:29:49.594325
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:29:50.363564
# Unit test for function main
def test_main():
    var_0 = main()
    assert True == var_0

# Generated at 2022-06-25 02:29:51.377541
# Unit test for function main
def test_main():
    assert True



# Generated at 2022-06-25 02:29:52.137891
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:29:54.576745
# Unit test for function main
def test_main():
    var_1 = 'install'
    var_2 = main(var_1)


# Generated at 2022-06-25 02:29:57.269098
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    main(module)