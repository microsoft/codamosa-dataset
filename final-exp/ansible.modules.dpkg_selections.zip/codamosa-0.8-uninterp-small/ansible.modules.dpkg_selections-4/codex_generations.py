

# Generated at 2022-06-25 02:22:26.181404
# Unit test for function main
def test_main():
    var_0 = main()
    assert True

# Generated at 2022-06-25 02:22:28.450839
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:22:37.428201
# Unit test for function main
def test_main():
    # Create an instance of the module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Check if dpkg is installed
    dpkg = module.get_bin_path('dpkg', True)
    # Set name
    name_0 = 'python'
    # Set selection
    selection_0 = 'hold'
    # Get current settings.
    rc_0, out_0, err_0 = module.run_command([dpkg, '--get-selections', name_0], check_rc=True)
    if not out_0:
        current_0 = 'not present'


# Generated at 2022-06-25 02:22:44.612861
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-25 02:22:45.520575
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:22:47.887854
# Unit test for function main
def test_main():
   try:
       assert "Equal" == main()
       print("Equal")
   except AssertionError as error:
       print('AssertionError:', error)
   except Exception as exception:
       print('Exception:', exception)


# main()    # Run the program.

# Generated at 2022-06-25 02:22:49.205994
# Unit test for function main
def test_main():
    arguments = {"name": "python","selection": "hold"}
    assert main(**arguments)
