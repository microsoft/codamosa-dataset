

# Generated at 2022-06-25 02:22:27.301144
# Unit test for function main
def test_main():
    out, err = capsys.readouterr()
    assert re.search(r'(ansible\.module_utils\.basic\.AnsibleModule)', out) is not None

# Generated at 2022-06-25 02:22:28.881015
# Unit test for function main
def test_main():
    try:

        pass
    except:
        assert False, "Unhandled exception."

# Generated at 2022-06-25 02:22:31.008615
# Unit test for function main
def test_main():
    assert true # injected from lib/dpkg_selections.py


# Generated at 2022-06-25 02:22:36.820081
# Unit test for function main
def test_main():
    with patch('main.module') as mock_module:
        klass_module = MagicMock()
        mock_module.return_value = klass_module
        klass_module.params = {'name': 'var_0', 'selection': 'var_1'}
        klass_module.check_mode = False
        klass_module.run_command = lambda var_0, var_1=True: (0, 0, 0)
        klass_module.exit_json = lambda var_0: var_0
        result = main()
        assert result is None

# Generated at 2022-06-25 02:22:45.550365
# Unit test for function main
def test_main():
    args = dict()
    args.update({"name" : "python"})
    args.update({"selection" : "hold"})
    given = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)), supports_check_mode=True)
    given.params = args
    dpkg = given.get_bin_path('dpkg', True)
    name = given.params.get('name')
    selection = given.params.get('selection')
    rc, out, err = given.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

# Generated at 2022-06-25 02:22:46.482452
# Unit test for function main
def test_main():
    var_1 = main()
    print(var_1)

# Generated at 2022-06-25 02:22:55.848671
# Unit test for function main

# Generated at 2022-06-25 02:22:58.004446
# Unit test for function main
def test_main():
    assert_equals(main(), None)


# Generated at 2022-06-25 02:22:58.700683
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:23:04.459450
# Unit test for function main
def test_main():
    # Set ansible.module_utils.basic.AnsibleModule.get_bin_path['required'] = True
    try:
        from ansible.module_utils.basic import AnsibleModule
        AnsibleModule.get_bin_path = lambda self, arg: True
    except TypeError:
        var_0 = test_main()
    
    
    
    
    

# Generated at 2022-06-25 02:23:14.464474
# Unit test for function main
def test_main():
    # TODO: Add tests for main, this should be enough to test the module
    var = 0

# Generated at 2022-06-25 02:23:23.871128
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    var_1 = var_0.get_bin_path('dpkg', True)

    var_2 = var_0.params['name']
    var_3 = var_0.params['selection']

    # Get current settings.
    var_4, var_5, var_6 = var_0.run_command([var_1, '--get-selections', var_2], check_rc=True)
    if not var_5:
        var_7 = 'not present'
    else:
        var_8 = var

# Generated at 2022-06-25 02:23:33.527714
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'get_bin_path', return_value = '/usr/bin/dpkg'):
        with patch.object(AnsibleModule, 'run_command', return_value = (0, ' libssh2-1 | 1.4.2-2.1+deb7u1 | stable | amd64', '')):
            with patch.object(AnsibleModule, 'run_command', return_value = (0, '', '')):
                var_1 = Mock(**{'check_mode': True, 'params': {'name': 'libssh2-1', 'selection': 'install'}})
                var_1.get_bin_path.return_value = '/usr/bin/dpkg'
                var_2 = Mock(**{'return_value.check_rc': True})


# Generated at 2022-06-25 02:23:34.197594
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 02:23:36.922374
# Unit test for function main
def test_main():
    # Test case 1
    # Input (replace with test values)
    var_0 = ''

    # Output
    # assert var_0 == ''
    var_1 = main(var_0)
    assert var_1 == ''

# Generated at 2022-06-25 02:23:46.158152
# Unit test for function main
def test_main():
    data = '{"changed": False, "name": "python", "selection": "install"}'
    argument_spec = dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True))
    temp_dir = '''/tmp'''
    supports_check_mode = True
    supports_diff = True
    platform = ''
    module_kwargs = {}
    defaults = {}
    check_invalid_arguments = True
    supports_diff_replace = True
    tmpdir = ''

# Generated at 2022-06-25 02:23:50.853833
# Unit test for function main
def test_main():
    import mock
    import subprocess
    with mock.patch.dict(subprocess.__dict__, {'run_command': (lambda: (1, '10', ''))}):
        assert main() == 1


# Generated at 2022-06-25 02:23:51.802296
# Unit test for function main
def test_main():
    assert 'AnsibleModule' in str(type(main()))


# Generated at 2022-06-25 02:23:54.903173
# Unit test for function main
def test_main():
    with mock.patch('module_1.module') as mockedModule:
        mockedModule.get_bin_path.return_value = False
        mockedModule.params = {'name': 'name', 'selection': 'install'}
        assert dpkg_selections.main() == (False, 'install', 'hold')

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 02:23:55.732679
# Unit test for function main
def test_main():
    assert var_0 == dpkg

# Generated at 2022-06-25 02:24:21.194430
# Unit test for function main
def test_main():
    var_0 = {'status': 0, 'output': 'python\thold\n'}
    with patch.object(ansible.module_utils.basic.AnsibleModule, 'run_command', return_value=var_0):
        with patch.object(os.path, 'exists', return_value = True):
            var_1 = {'name': 'python', 'selection': 'hold'}
            with patch.object(ansible.module_utils.basic.AnsibleModule, '__init__', return_value=None) as mock_module:
                mock_module.params = var_1
                mock_module.check_mode.return_value = True

# Generated at 2022-06-25 02:24:26.219740
# Unit test for function main
def test_main():
  with open('test/dpkg_selections_test.py', 'r') as content_file:
      content = content_file.read()
      try:
          assert "FUNCTION_NAME" in content and "FUNCTION_PARAMS" in content and "MODULE_NAME" in content
      except AssertionError:
          raise AssertionError("Unit test not found. Have you deleted or renamed it?")

# Generated at 2022-06-25 02:24:31.094969
# Unit test for function main
def test_main():
    var_1 = {u'changed': True, u'after': u'install', u'before': u'not present'}
    var_0 = {u'changed': True, u'after': u'install', u'before': u'not present'}
    var_2 = {u'failed': True, u'msg': u'Module comparison failed'}
    var_3 = var_0 == var_1
    var_4 = var_0 != var_2
    if not var_3 and var_4:
        return False
    if var_3 and not var_4:
        return False
    return True


# Generated at 2022-06-25 02:24:32.727875
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-25 02:24:37.224880
# Unit test for function main
def test_main():
    assert main() == var_0

# Generated at 2022-06-25 02:24:37.761905
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:24:46.206331
# Unit test for function main
def test_main():
    var_1 = 'python'
    var_2 = 'hold'
    var_3 = "dpkg --get-selections python"
    var_4 = 0
    var_5 = "python install"
    var_6 = "dpkg --set-selections"
    var_7 = "python hold"
    var_8 = True
    var_9 = None
    var_10 = True
    var_11 = None
    var_12 = None
    var_13 = None
    # Return values from function main
    return var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10, var_11, var_12, var_13

# Generated at 2022-06-25 02:24:48.077323
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:24:49.013586
# Unit test for function main
def test_main():
    var_1 = main.__closure__


# Generated at 2022-06-25 02:24:49.811393
# Unit test for function main
def test_main():
    assert 'main'


# Generated at 2022-06-25 02:25:29.253792
# Unit test for function main
def test_main():
  try:
    var_1 = 2
    var_2 = "test_string"
    assert var_1 == 2
    assert var_2 == "test_string"
    assert var_1 !=1
  except AssertionError as e:
    raise e

# Generated at 2022-06-25 02:25:29.960709
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:25:32.671344
# Unit test for function main
def test_main():
    exception_0 = None
    try:
        var_0 = main()
    except Exception as exception_0:
        raise Exception (exception_0)

    assert not exception_0
    assert True

# Write here unit tests for function_0 (and for the function that it calls).

# Generated at 2022-06-25 02:25:38.880731
# Unit test for function main
def test_main():
    var_0 = {
        'status': 0,
        'cmd': 'dpkg --get-selections python',
        'stderr': '',
        'stdout': 'python		deinstall'
    }
    var_1 = {}
    var_2 = {
        '1': {
            'cmd': 'dpkg --set-selections',
            'data': 'python hold',
            'input_data': 'python hold',
        }
    }
    var_3 = {
        'status': 0,
        'cmd': 'dpkg --get-selections python',
        'stderr': '',
        'stdout': 'python		hold'
    }

# Generated at 2022-06-25 02:25:47.437431
# Unit test for function main
def test_main():
    # Set up mock for function calls
    with mock.patch('ansible.module_utils.basic.AnsibleModule', autospec=True) as m_module:
        with mock.patch('ansible.module_utils.basic.get_bin_path', autospec=True) as m_get_bin_path:
            with mock.patch('ansible.module_utils.basic.run_command', autospec=True) as m_run_command:
                m_get_bin_path.return_value = 'dpkg path'
                m_run_command.return_value = 0, '', ''
                m_module.return_value = mock.Mock()

                # set up function calls.
                dpkg_selections.main()
                m_get_bin_path.assert_called_once_with('dpkg', True)

# Generated at 2022-06-25 02:25:50.664498
# Unit test for function main
def test_main():
    dpkg = main()
    var_0 = dpkg.get_bin_path('dpkg', True)
    var_1 = dpkg.params['name']
    var_2 = dpkg.params['selection']


# Generated at 2022-06-25 02:25:56.553055
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    var_1 = var_0.get_bin_path('dpkg', True)

    var_2 = var_0.params['name']
    var_3 = var_0.params['selection']

    # Get current settings.
    var_4, var_5, var_6 = var_0.run_command([var_1, '--get-selections', var_2], check_rc=True)
    if not var_5:
        var_7 = 'not present'
    else:
        var_7 = var

# Generated at 2022-06-25 02:25:59.165427
# Unit test for function main
def test_main():
    assert False


#def test_ansible_module_main():
#    assert False


#def test_ansible_module():
#    assert False


# Generated at 2022-06-25 02:26:01.499860
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-25 02:26:08.675408
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    var_1 = var_0.get_bin_path('dpkg', True)

    name = var_0.params['name']
    selection = var_0.params['selection']

    # Get current settings.
    rc, out, err = var_0.run_command([var_1, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-25 02:27:14.959152
# Unit test for function main
def test_main():
    # this could be named something else
    var_0 = main()


# Generated at 2022-06-25 02:27:15.438548
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:27:25.814555
# Unit test for function main
def test_main():
    import sys
    import StringIO
    import os

    saved_stdout = sys.stdout

# Generated at 2022-06-25 02:27:35.992074
# Unit test for function main
def test_main():
    var_1 = {
        'module': main(),
        'ansible_module_args': '',
        'ansible_facts': {
            'gather_subset': '',
            'gather_timeout': 5,
            'ansible_module_name': main(),
            'ansible_version': {
                'string': main(),
                'full': main(),
                'major': main(),
                'minor': main(),
                'revision': main(),
            },
        },
    }

# Generated at 2022-06-25 02:27:37.014709
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False

# Generated at 2022-06-25 02:27:37.526938
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:27:41.396829
# Unit test for function main
def test_main():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-25 02:27:47.072515
# Unit test for function main
def test_main():
    class MockModule:
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.run_command = self.mock_run_command


# Generated at 2022-06-25 02:27:47.794644
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:27:50.417622
# Unit test for function main
def test_main():
    # ansible localhost -m dpkg_selections -a 'name=python selection=hold'
    # localhost | CHANGED | {
    #     "after": "hold",
    #     "changed": true,
    #     "before": "install"
    # }

    pass

# Generated at 2022-06-25 02:30:03.837540
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:30:06.048406
# Unit test for function main
def test_main():
    try:
        var_1 = main()
    except Exception as err:
        print("Exception in dpkg_selections.main: {0}".format(str(err)))
        raise


# Generated at 2022-06-25 02:30:09.216894
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False



# Generated at 2022-06-25 02:30:13.100465
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = var_1.get_bin_path('dpkg', True)

    name = var_1.params['name']
    selection = var_1.params['selection']

    # Get current settings.
    rc, out, err = var_1.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-25 02:30:15.273757
# Unit test for function main
def test_main():
    var_0 = main()
    assert (var_0 == 0)


# Generated at 2022-06-25 02:30:15.945546
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 02:30:16.337661
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-25 02:30:17.125752
# Unit test for function main
def test_main():
    print("test_main")
    test_case_0()



# Generated at 2022-06-25 02:30:21.457467
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Unable to run test case 0")


# Collect all test cases in this file

# Generated at 2022-06-25 02:30:24.420205
# Unit test for function main
def test_main():
    var_0 = main()