

# Generated at 2022-06-11 07:00:07.111335
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )
    main()
    module.exit_json(changed=True, before='', after='')

# Generated at 2022-06-11 07:00:07.641644
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:00:08.972500
# Unit test for function main
def test_main():
    # Unit test for function main

    assert 1 == 1

test_main()

# Generated at 2022-06-11 07:00:10.760169
# Unit test for function main
def test_main():
    args = {'name': 'python', 'selection': 'hold'}
    result = main()

    assert result['changed'] == True

# Generated at 2022-06-11 07:00:11.516314
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:00:19.930253
# Unit test for function main
def test_main():
    import mock
    import subprocess32
    from ansible.module_utils.basic import AnsibleModule

    def mock_run_command(args, check_rc=False, close_fds=True):
        if args[0] == dpkg and args[-1] == 'python':
            return (0, 'python install\n', None)
        else:
            return (0, None, None)

    mock_subprocess = mock.Mock(subprocess32)
    mock_subprocess.check_call.side_effect = mock_run_command
    mock_subprocess.check_output.side_effect = mock_run_command
    mock_subprocess.Popen.side_effect = mock_run_command


# Generated at 2022-06-11 07:00:28.854518
# Unit test for function main
def test_main():
    test_data = [
        {
            'inputs': {
                'name': 'python',
                'selection': 'hold',
            },
            'outputs': {
                'changed': True,
                'before': 'not present',
                'after': 'hold',
            }
        },
        {
            'inputs': {
                'name': 'python',
                'selection': 'hold',
            },
            'outputs': {
                'changed': False,
                'before': 'hold',
                'after': 'hold',
            }
        },
    ]

    for test in test_data:
        input_data = test['inputs']
        expected_outputs = test['outputs']
        result = main(input_data)
        assert result['changed'] == expected_outputs['changed']
       

# Generated at 2022-06-11 07:00:33.201081
# Unit test for function main
def test_main():
    dpkg = AnsibleModule(
        argument_spec = dict(
            name = dict(required = True),
            selection = dict(choices=['install', 'hold', 'deinstall', 'purge'], required = True)
        ),
        supports_check_mode = True
    )
    main()
 

# Generated at 2022-06-11 07:00:39.853388
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=False,
    )

    module.run_command = lambda x, **kwargs: (
        0, 'python install\n', '' if kwargs.get('check_rc', True) else 'dpkg: error: exit status 1\n')

    main()
    assert module.params['name'] == 'python'
    assert module.params['selection'] == 'hold'
    assert module.changed is True
    assert module.warnings == []
    assert module.failures == []
    assert module.before == 'install'
    assert module.after == 'hold'


# Generated at 2022-06-11 07:00:48.280264
# Unit test for function main
def test_main():
    import os
    import tempfile
    import subprocess

    dpkg_selections = """
    python install
    python-dbg deinstall
    """
    dpkg_get_selections = """
    python hold
    python-dbg deinstall
    """

    # Set up the files
    fd, fname = tempfile.mkstemp()
    os.write(fd, dpkg_selections)
    os.close(fd)

    # Set up the environment.
    os.environ['PATH'] = '/bin:/usr/bin:/sbin:/usr/sbin'

    dpkg = '/usr/bin/dpkg'
    assert os.path.exists(dpkg)

    # Set up the fake dpkg executable.

# Generated at 2022-06-11 07:00:58.570667
# Unit test for function main
def test_main():
    out = main()
    assert out == 'present'

# Generated at 2022-06-11 07:01:05.704774
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:14.054862
# Unit test for function main
def test_main():

    # Unit test can be run without Ansible. Use direct imports and mocks.

    # Module uses AnsibleModule and AnsibleModule._ansible_version, so mock that.
    import ansible.module_utils
    class MockAnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self._ansible_version = '2.9.4'

        def exit_json(self, changed, before=None, after=None):
            self.exit_json_called = True
            self.exit_json_changed = changed

    ansible.module_utils.AnsibleModule = MockAnsibleModule

    # Module uses os.path so mock that.
    import os

# Generated at 2022-06-11 07:01:20.125939
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    
    dpkg = module.get_bin_path('dpkg', True)
    # Test get_selections
    module.run_command([dpkg, '--get-selections', 'python'], check_rc=True)
    
    ## Test set_selections
    module.run_command([dpkg, '--set-selections'], data="python hold", check_rc=True)
    

# Generated at 2022-06-11 07:01:21.082827
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:01:22.152406
# Unit test for function main
def test_main():
    key = '-o'
    assert key in main()


# Generated at 2022-06-11 07:01:22.631746
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:01:29.478586
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold',
    )
    module = AnsibleModule(argument_spec=args)
    module.run_command = MockAnsibleModule.run_command
    rc, out, err = module.run_command(['dpkg', '--get-selections', args['name']])
    assert not rc, out + err
    assert out.strip() == 'python\tinstall'
    rc, out, err = module.run_command(['dpkg', '--set-selections'], data='python\thold')
    assert not rc, out + err


# Generated at 2022-06-11 07:01:40.499379
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:49.859163
# Unit test for function main
def test_main():
    # Unit test for function main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-11 07:02:01.638974
# Unit test for function main
def test_main():
    from ansible.modules.system import dpkg_selections

    assert dpkg_selections.main() == 0

# Generated at 2022-06-11 07:02:02.694000
# Unit test for function main
def test_main():
    print("Start testing!")

# Generated at 2022-06-11 07:02:03.193094
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:02:12.420089
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:02:13.353361
# Unit test for function main
def test_main():
    rc = main()
    assert rc == 0

# Generated at 2022-06-11 07:02:18.199083
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "name": "python",
        "selection": "hold",
        "check_mode": False,
        "diff_mode": False
    })
    assert main() == module.exit_json(changed=True, before="not present", after="hold")

# Generated at 2022-06-11 07:02:26.884092
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-11 07:02:36.221225
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    print ("not changed", changed)

    # if module.check_

# Generated at 2022-06-11 07:02:46.863864
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert module
    # dpkg = module.get_bin_path('dpkg', True)
    dpkg = '/bin/dpkg'

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection



# Generated at 2022-06-11 07:02:47.525427
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:03:15.124718
# Unit test for function main
def test_main():
    # get the result of executing main
    m = main()
    # what they should be
    m_correct = ["brian", "brazil", "bbrazil"]
    # check if the results are what they should be
    assert m == m_correct

# Generated at 2022-06-11 07:03:23.970164
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:03:32.090426
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    # dpkg -l should be used to check that the package selection was updated
    dpkg = 'dpkg -l | grep python'
    # dpkg -l is used here to check that the module was called correctly
    check_rc = True
    options = dict(name=name, selection=selection)
    module = AnsibleModule(name, **options)
    # Check exit_json is called for check_mode
    module.exit_json(changed=False, before=selection, after=selection)
    # Check that the module was called correctly
    module.run_command(dpkg, check_rc=check_rc)
    # Check that the module returns the correct status
    module.exit_json(changed=True, before=selection, after=selection)


# Generated at 2022-06-11 07:03:32.561496
# Unit test for function main
def test_main():

    test = main()

# Generated at 2022-06-11 07:03:34.429204
# Unit test for function main
def test_main():
    assert 'dpkg_selections.py [-v] [-d] [-h] -n name -s selection' in main()


# Generated at 2022-06-11 07:03:34.914992
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:03:42.485616
# Unit test for function main
def test_main():

    # Test AnsibleModule()
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Test rc, out, err = module.run_command(cmd, check_rc=True)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-11 07:03:44.969488
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,
  )
  data = {}
  module.params = data
  main()

# Generated at 2022-06-11 07:03:45.438969
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:03:52.945596
# Unit test for function main
def test_main():
    import os
    import sys
    import textwrap
    import tempfile

    def run_module_mock(params, check_mode=None, diff=None, platform=None):
        if params['name'] != 'python':
            return {'failed': True}

        if params['selection'] == 'hold':
            params['selection'] = 'install'

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {'name': None, 'selection': None}

        def get_bin_path(self, path, required):
            if path == 'dpkg':
                return 'dpkg'
            else:
                return None


# Generated at 2022-06-11 07:04:50.008930
# Unit test for function main
def test_main():
    module = get_module()
    response = {'check_mode': False, 'name': 'python', 'selection': 'hold'}
    module.run_command = MagicMock(return_value=(0, 'python hold', ''))
    module.run_command.run_command = MagicMock(return_value=(0, 'python hold', ''))
    assert main() == response


# Generated at 2022-06-11 07:04:58.201287
# Unit test for function main
def test_main():
    import shutil
    import tempfile
    import os
    import os.path
    import subprocess

    class FakeRunCommand():
        def __init__(self):
            self.rc = 0
            self.stdout = ""
            self.stderr = ""

        def __call__(self, args, check_rc=True, data=None):
            if data is None:
                data = ""
            self.stdout = ''
            self.stderr = ''
            self.rc = 0
            tmpdir = tempfile.mkdtemp()
            tmpfile = os.path.join(tmpdir, "test")
            with open(tmpfile, 'w') as f:
                f.write(data)

# Generated at 2022-06-11 07:05:09.771845
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert type(changed) is bool

# Generated at 2022-06-11 07:05:10.450536
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:05:18.473863
# Unit test for function main
def test_main():
    class Options:
        pass
    class ModuleResult:
        pass
    class AnsibleModule:
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = options
            self.check_mode = False
            self.result = ModuleResult()
            self.result.changed = False
            self.run_command_called = False
            self.exit_json_called = False
        def exit_json(self, changed=False, before='DUMMY', after='DUMMY'):
            self.result.changed = changed
            self.result.before = before
            self.result.after = after
            self.params.selection = after
            self.exit_json_called = True


# Generated at 2022-06-11 07:05:30.151952
# Unit test for function main
def test_main():

    name = "python"
    selection = "hold"

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:05:43.386631
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    assert(current != selection)

# Generated at 2022-06-11 07:05:48.462517
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:05:51.194055
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )
    main()

# Generated at 2022-06-11 07:05:51.785200
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:08:02.647001
# Unit test for function main
def test_main():
    module_args = {
        'name': 'python',
        'selection': 'hold',
        'check_mode': True,
    }

    main()

# Generated at 2022-06-11 07:08:08.065180
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:08:16.419588
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:08:16.939337
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:08:25.421013
# Unit test for function main
def test_main():
    # get_bin_path
    class Args:
        bin_path = True
    args = Args()
    def get_bin_path(name,*args,**kwargs):
        return '/path/' + name
    # run_command
    output = ''
    rc = 0
    class Msg:
        msg = ''
    module = Msg()
    def run_command_mocked(name,data=None,check_rc=True):
        if name[-1:][0] == 'c':
            return rc,output,rc
        else:
            return 1,'',rc
    import dpkg_selections
    import sys
    sys.modules['ansible.module_utils.basic'] = Mock()
    dpkg_selections.AnsibleModule = Mock(return_value=module)
    dpkg

# Generated at 2022-06-11 07:08:33.802232
# Unit test for function main
def test_main():
    import sys
    import json

    if sys.version_info.major == 2:
        import ConfigParser
        config = ConfigParser.ConfigParser(inline_comment_prefixes=(';',))
        try:
            config.readfp(open('/etc/ansible/ansible.cfg'))
        except IOError:
            pass
    else:
        import configparser
        config = configparser.ConfigParser(inline_comment_prefixes=(';',))
        try:
            config.read_file(open('/etc/ansible/ansible.cfg'))
        except IOError:
            pass

    arguments = dict(
        name='python',
        selection='hold',
    )


# Generated at 2022-06-11 07:08:42.106508
# Unit test for function main
def test_main():
    # Mock module class
    class Module:
        def __init__(self, name, selection, check_mode=False, diff=False, platform=None):
            self.name = name
            self.selection = selection
            self.check_mode = check_mode
            self.diff = diff
            self.platform = platform
            self.params = {'name': self.name, 'selection': self.selection}
        def get_bin_path(self, name, required):
            return name
        def run_command(self, args, check_rc=False, data=None):
            return None, None, None

    # Mock system exit
    def sys_exit(self):
        return self
    sys_exit.changed = False
    sys_exit.before = None
    sys_exit.after = None

# Generated at 2022-06-11 07:08:50.363230
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'name': 'python',
        'selection': 'hold'
    })
    module.exit_json = lambda changed, before, after: (changed, before, after)
    dpkg = '/usr/bin/dpkg'

    # Check get_selections doesn't report python as held.
    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'], check_rc=True)
    assert out.split()[1] != 'hold'

    # Check set_selections sets package to hold.
    rc, out, err = module.run_command([dpkg, '--set-selections'], data="python hold", check_rc=True)

# Generated at 2022-06-11 07:08:57.736165
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = close_msg
    module.run_command = close_msg
    module.get_bin_path = close_msg
    module.params = {}
    module.params['name'] = 'dpkg'
    module.params['selection'] = 'install'
    main()


# Generated at 2022-06-11 07:08:59.477842
# Unit test for function main
def test_main():
    # Test function main with no argument.
    # Should return True, True and changed
    assert main(name='python', selection='hold') == True