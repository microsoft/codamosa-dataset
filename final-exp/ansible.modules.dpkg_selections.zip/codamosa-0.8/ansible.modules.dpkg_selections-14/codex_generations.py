

# Generated at 2022-06-11 07:00:08.128730
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.dpkg_selections import main
    from ansible.module_utils.basic import AnsibleModule
    ansible_module = AnsibleModule.OK
    ansible_module.run_command = run_command
    ansible_module.get_bin_path = get_bin_path
    result = main()
    print(result)


# Generated at 2022-06-11 07:00:08.645712
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:00:17.727825
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, 'python\tinstall\n', ''))

    main()
    assert module.params['name'] == 'python'
    assert module.params['selection'] == 'hold'
    assert module.run_command.call_args_list[0][0][0] == ['dpkg', '--get-selections', 'python']

# Generated at 2022-06-11 07:00:26.464943
# Unit test for function main
def test_main():

    import ansible.module_utils.action_plugins.dpkg_selections as mod
    import os
    import tempfile
    import pytest
    import json

    with tempfile.NamedTemporaryFile(mode='w', suffix='dpkg_selections-test.txt') as fp:
        # Test that we return not changed when the selections are the same.
        fp.write('python hold\n')
        fp.flush()
        os.system('dpkg --set-selections <' + fp.name)

        module_args = {}
        module_args['name'] = 'python'
        module_args['selection'] = 'hold'
        module_args['_ansible_check_mode'] = True

        module = AnsibleModule(argument_spec=dict(module_args))

# Generated at 2022-06-11 07:00:29.949127
# Unit test for function main
def test_main():
    test_data = {
        'name': 'python',
        'selection': 'hold',
        'check_mode': True,
        'params': {'name': 'python', 'selection': 'hold'}
    }
    result = main()
    assert result == test_data

# Generated at 2022-06-11 07:00:38.615025
# Unit test for function main
def test_main():
    # Create simple ansible module used in main function
    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode=True):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode

            self.basic = {"name": "vim", "selection": "install"}

        def get_bin_path(self, name, required=False):
            return "/usr/bin/" + name

        def run_command(self, cmd, check_rc=True, **kwargs):
            return 0, "output", "error"

        def exit_json(self, changed=True, before="", after=""):
            self.basic["changed"] = changed
            self.basic["before"] = before
            self.basic["after"] = after

    # Create mock

# Generated at 2022-06-11 07:00:46.933998
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:47.835828
# Unit test for function main
def test_main():
    a = main()

# Generated at 2022-06-11 07:00:55.653708
# Unit test for function main
def test_main():
    with open('dpkg_selections.json', 'r') as myfile:
        data=myfile.read()
    print(data)
    # read file and prepare input data
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current

# Generated at 2022-06-11 07:00:56.181108
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:01:11.400928
# Unit test for function main
def test_main():
    import mock
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as fake_am:
        fake_am_instance = mock.Mock()
        fake_am_instance.check_mode = True
        fake_am_instance.params = {'name': 'python', 'selection': 'hold'}
        fake_am.return_value = fake_am_instance
        main()
        assert fake_am_instance.run_command.call_args == mock.call(cmd='dpkg --get-selections python', check_rc=True)
        assert fake_am_instance.exit_json.call_args == mock.call(changed=True, before='unknown', after='hold')
        fake_am_instance.run_command.side_effect = Exception('error')
        fake_am_instance.exit_

# Generated at 2022-06-11 07:01:11.912377
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:01:12.794473
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-11 07:01:13.638356
# Unit test for function main
def test_main():
    assert(1 + 1 == 2)

# Generated at 2022-06-11 07:01:20.001353
# Unit test for function main
def test_main():

    from ansible.module_utils import basic
    from ansible.module_utils.plugins.modules.system.dpkg_selections import main
    import ansible.module_utils.plugins.modules.system.dpkg_selections
    from ansible.module_utils.common.collections import ImmutableDict

    module = ansible.module_utils.plugins.modules.system.dpkg_selections.AnsibleModule(
            argument_spec = dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ),
            supports_check_mode=True,
        )

    assert(main(module) == None)
    pass

# Generated at 2022-06-11 07:01:20.896308
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:01:21.379782
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:01:23.880476
# Unit test for function main
def test_main():
    out = StringIO()
    sys.stdout = out
    main()
    output = out.getvalue().strip()
    assert(output == "helloworld")
    out.close()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-11 07:01:33.185880
# Unit test for function main
def test_main():
    '''
    Update parameters for unit test
    '''
    module_params = dict(
        name='python',
        selection='hold',
    )

    '''
    AnsibleModule instances is used to execute the module code
    '''
    module = AnsibleModule(
        argument_spec=module_params,
        supports_check_mode=True,
    )

    # module.params contains the passed params
    # Note the AnsibleModule instantiation updates module.params with the params that work with the argument_spec

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.

# Generated at 2022-06-11 07:01:44.475616
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "python3.4"
    selection = "deinstall"

    # Get current settings.
    _rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_

# Generated at 2022-06-11 07:02:02.146971
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    from ansible.module_utils.basic import AnsibleModule

    # Test modules being properly loaded using names from docs
    dpkg = module.get_bin_path('dpkg', True)
    assert dpkg == 'dpkg'

# Generated at 2022-06-11 07:02:02.734002
# Unit test for function main
def test_main():
    print("Not available")

# Generated at 2022-06-11 07:02:03.280474
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-11 07:02:06.752336
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    return module

# Generated at 2022-06-11 07:02:11.411567
# Unit test for function main
def test_main():
    # Replace exit_json and log with mock functions.
    import __builtin__
    __builtin__.exit_json = exit_json
    __builtin__.log = log

    params = {"name": "python",
              "selection": "hold",
              "ansible_facts": {"platform_family": "debian"}}

    main()

# Generated at 2022-06-11 07:02:22.572728
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:02:24.606614
# Unit test for function main
def test_main():
    print("test_main")
    import sys
    sys.stderr = open("/dev/null", "w")
    main()

# Generated at 2022-06-11 07:02:35.580651
# Unit test for function main
def test_main():
    current = [{
        'changed': False,
        'before': 'hold',
        'after': 'hold'
    }, {
        'changed': True,
        'before': 'hold',
        'after': 'deinstall'
    }, {
        'changed': True,
        'before': 'not present',
        'after': 'deinstall'
    }, {
        'changed': True,
        'before': 'not present',
        'after': 'install'
    }, {
        'changed': True,
        'before': 'deinstall',
        'after': 'install'
    }]

# Generated at 2022-06-11 07:02:36.099107
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:02:42.505701
# Unit test for function main
def test_main():
    # Hack to load the module from current dir
    import sys
    import os
    sys.path.insert(0, os.getcwd())
    from dpkg_selections import main

    # Unit test for function main

    name = 'python'
    selection = 'not present'
    rc = main()
    assert rc == 0
    assert name == 'python'
    assert selection == 'not present'

# Generated at 2022-06-11 07:03:14.777768
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    main()
    assert dpkg_selections['changed'] == True
    assert dpkg_selections['before'] == current
    assert dpkg_selections['after'] == selection

# Generated at 2022-06-11 07:03:15.315001
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:03:19.330135
# Unit test for function main
def test_main():
    import pytest

    rc = pytest.main(['-x', __file__])
    print(f"__file__: {__file__}")
    # print(f"rc: {type(rc)}")
    assert rc == 0, 'Unit tests failed rc={rc}'

if __name__ == '__main2__':
    test_main()

# Generated at 2022-06-11 07:03:27.538968
# Unit test for function main
def test_main():
    # unit test for dpkg_selections module
    # dpkg_selections testing
    # set up test environment
    name = 'test_name'
    selection = 'hold'
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params['name'] = name
    module.params['selection'] = selection
    dpkg_selections_result = main()
    assert dpkg_selections_result == 0

# Generated at 2022-06-11 07:03:35.843335
# Unit test for function main
def test_main():

    from ansible.module_utils.common.systemd import SystemdError

    module = AnsibleModule(argument_spec=dict(name=dict(required=True),
                                              selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)),
                           supports_check_mode=True, )

    global dpkg
    global name
    global selection
    global changed

    class MockPopen():
        def __init__(self, args, **kwargs):
            pass

        def communicate(self):
            if name == 'python':
                if selection == 'hold':
                    return ("python install", None)
                if selection == 'install':
                    return ("python hold", None)
                else:
                    return ("", None)
            return ("", None)


# Generated at 2022-06-11 07:03:43.125032
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import action_common

    test_cases = [
        {"name": "dpkg", "selection": "hold", "msg": "should not change current selection"},
        {"name": "dpkg", "selection": "deinstall", "msg": "should change current selection"},
    ]


# Generated at 2022-06-11 07:03:51.017601
# Unit test for function main
def test_main():
    with mock.patch.object(AnsibleModule, 'run_command') as mock_run_command:
        mock_run_command.return_value = (0, 'name hold', '')
        mock_module = mock.Mock()
        mock_module.params = dict(
            name='python',
            selection='hold'
        )
        main()
        calls = [
            mock.call([mock_module.get_bin_path.return_value, '--get-selections', 'python'], check_rc=True),
            mock.call([mock_module.get_bin_path.return_value, '--set-selections'], data="python hold", check_rc=True)
        ]
        mock_run_command.assert_has_calls(calls, any_order=True)
        mock

# Generated at 2022-06-11 07:03:51.487703
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:03:59.822572
# Unit test for function main

# Generated at 2022-06-11 07:04:07.835468
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:04:58.669866
# Unit test for function main
def test_main():
    params = {'name': 'python', 'selection': 'hold'}
    module_mock = AnsibleModule(argument_spec = params, supports_check_mode = True)
    result = main()
    assert result['changed'] == True

# Generated at 2022-06-11 07:05:10.045035
# Unit test for function main
def test_main():
    import ansible.module_utils.common.system
    import ansible.module_utils.common.tmpdir
    import os
    import subprocess
    import tempfile
    import yaml
    import time

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp configuration file
    conf_file = os.path.join(tmpdir, "ansible.cfg")
    open(conf_file, 'a').close()
    config = ansible.module_utils.common.tmpdir.TmpDir(path=tmpdir)

    # Setup the module args
    module_args = yaml.safe_load(EXAMPLES)['plays'][0]['tasks'][0]['module_defaults']
    module_args['name'] = 'ansible'

# Generated at 2022-06-11 07:05:10.640958
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:05:17.823429
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:05:18.438222
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:05:30.151146
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:05:43.338605
# Unit test for function main
def test_main():
    import sys
    import json
    import os
    import tempfile

    # Get the test input and output parameters
    argv = sys.argv
    argc = len(argv)
    if argc < 2:
        raise(Exception("Insufficient number of arguments passed."))
    test_data_dir = argv[1]
    in_data_file = os.path.join(test_data_dir, "test_input.json")
    out_data_file = os.path.join(test_data_dir, "test_output.json")

    # Read the input data
    with open(in_data_file, "r") as in_file:
        in_data = json.load(in_file)
    name = in_data["name"]
    selection = in_data["selection"]

# Generated at 2022-06-11 07:05:51.692975
# Unit test for function main
def test_main():
    print("Running integration test for function main")
    # This function tests the module by passing dummy parameters and
    # checking if the output matches the expected value.
    module = AnsibleModule({}, None)
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)

# Generated at 2022-06-11 07:05:52.183454
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 07:05:54.023475
# Unit test for function main
def test_main():
    rc, out, err = main()
    assert rc == 0
    assert out == None
    assert err == None


# Generated at 2022-06-11 07:08:11.703409
# Unit test for function main
def test_main():
    # Build an AnsibleModule object for this test
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert module.params['name'] == 'python'
    assert module.params['selection'] == 'hold'

# Generated at 2022-06-11 07:08:19.685333
# Unit test for function main
def test_main():
    apt_module.run_command.return_value = (0, 'python\thold', '')
    apt_module.check_mode = False
    main()

    apt_module.check_mode = True
    apt_module.run_command.assert_called_once_with(['dpkg', '--get-selections', 'python'], check_rc=True)
    apt_module.exit_json.assert_called_once_with(changed=True, before='not present', after='hold')

    apt_module.run_command.return_value = (0, 'python\thold', '')
    apt_module.check_mode = False
    main()
    apt_module.exit_json.assert_called_once_with(changed=False, before='hold', after='hold')

# Generated at 2022-06-11 07:08:27.648117
# Unit test for function main
def test_main():
    print('Testing function main')
    assert main() == "done"

# Generated at 2022-06-11 07:08:32.884091
# Unit test for function main
def test_main():
    # Get module args that would normally be passed on the command line.
    argv = sys.argv[1:]
    argv.insert(0, __file__)
    argv.insert(1, '-vvv')
    argv.append('{"name":"python", "selection":"hold"}')
    argv = json.loads(argv[-1])
    # Run the module code.
    main(argv)


# Generated at 2022-06-11 07:08:41.276933
# Unit test for function main
def test_main():
    test = AnsibleModule(dict(
        name='test',
        selection='hold',
    ), supports_check_mode=True)
    test.get_bin_path = lambda module, required=False, opt_dirs=None: 'dpkg'


    test.run_command = lambda args, check_rc=False, data=None, binary_data=False: (0, 'test install', '')
    test.exit_json = lambda changed, before, after: (changed, before, after)

    assert main() == (True, 'install', 'hold')

    test.run_command = lambda args, check_rc=False, data=None, binary_data=False: (0, 'test hold', '')
    test.exit_json = lambda changed, before, after: (changed, before, after)


# Generated at 2022-06-11 07:08:44.743259
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    print(module)



# Generated at 2022-06-11 07:08:53.514379
# Unit test for function main
def test_main():
    def run_dpkg(module, *cmd):
        cmd = list(cmd)
        return module.run_command([dpkg] + cmd, check_rc=True)

    def run_module_with_fail_json(*args, **kwargs):
        module = AnsibleModule(*args, **kwargs)
        return module.fail_json

    def run_module(*args, **kwargs):
        args = list(args)
        args.append(dict(ANSIBLE_MODULE_ARGS={
            'name': 'python',
            'selection': 'hold',
        }))
        return AnsibleModule(*args, **kwargs)

    mock_run_command = Mock(return_value=(0, 'python hold', ''))
    mock_run_command2 = Mock(return_value=(0, 'python deinstall', ''))

# Generated at 2022-06-11 07:09:01.897908
# Unit test for function main
def test_main():

    AnsibleModule = AnsibleModuleMock

    # dpkg_selections is not a executable
    AnsibleModule.fail_json.assert_called_with(changed=False, msg="could not find the executable 'dpkg_selections'")

    # Python is not installed.
    args = {'executable': 'dpkg',
            'fail_msg': "could not find the executable 'dpkg'",
            'required': True}
    dict_1 = dict(args.items() + AnsibleModule.get_bin_path.return_value.items())
    dict_2 = dict(AnsibleModule.run_command.return_value.items())
    dict_3 = dict(AnsibleModule.run_command.return_value.items() + AnsibleModule.get_bin_path.return_value.items())
    dict_

# Generated at 2022-06-11 07:09:10.988226
# Unit test for function main
def test_main():
    test_args = {
        'name': 'python',
        'selection': 'hold'
    }
    test_ansible_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    with mock.patch.object(test_ansible_module, 'get_bin_path', return_value=True):
        with mock.patch.object(test_ansible_module, 'run_command', return_value=(0, 'test', '')):
            test_ansible_module.exit_json = mock.MagicMock()
            main()

# Generated at 2022-06-11 07:09:19.749109
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold'
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = args['name']
    selection = args['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection