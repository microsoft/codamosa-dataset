

# Generated at 2022-06-11 07:00:02.593872
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:00:09.237862
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Set up the test.
    # TODO: move to proper test case.
    os.environ['ANSIBLE_GET_URL_CALLABLE'] = 'custom_get_url'
    os.environ['ANSIBLE_MODULE_ARGS'] = '{"name": "test", "selection": "install", "module_utils": "/path/to/ansible/module_utils"}'

    module = main()
    assert module.params['name'] == 'test'
    assert module.params['selection'] == 'install'

# Generated at 2022-06-11 07:00:18.219220
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:26.743352
# Unit test for function main
def test_main():
    # Mock the module object.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Set the module.run_command mock.
    module.run_command = mocker.MagicMock()

    # Set the module.run_command return_values.
    module.run_command.return_value = (0, "dpkg-query: no packages found matching name\n", "")
    module.run_command.return_value = (0, "name  selection\n", "")
    module.run_command.return_value = (0, "name  selection\n", "")
   

# Generated at 2022-06-11 07:00:36.396126
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:36.845485
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:00:45.344750
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:53.524812
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:54.589164
# Unit test for function main
def test_main():
    init()
    assert main() is None


# Generated at 2022-06-11 07:00:55.354046
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:01:07.503609
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:01:08.013996
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-11 07:01:15.994473
# Unit test for function main
def test_main():
    testvals1 = dict(
        name='python',
        selection='hold',
    )
    testvals2 = dict(
        name='python',
        selection='purge',
    )
    testvals3 = dict(
        name='python',
        selection='deinstall',
    )
    testvals4 = dict(
        name='python',
        selection='install',
    )
    testvals5 = dict(
        name='python',
        selection='deinstall',
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path

# Generated at 2022-06-11 07:01:16.686153
# Unit test for function main
def test_main():
    assert(main() == None)

# Generated at 2022-06-11 07:01:24.340912
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:33.804100
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    module_args = dict(
        name='foo',
        selection='install'
    )

    def run_command(command, data=None, check_rc=True):
        rc = 0
        out = to_bytes('foo install')
        err = to_bytes('')
        return (rc, out, err)

    get_bin_path_mock = MagicMock(return_value=to_bytes('/usr/bin/dpkg'))

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
        import __builtin__ as builtins

# Generated at 2022-06-11 07:01:39.531478
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert main() == True

# Generated at 2022-06-11 07:01:46.947787
# Unit test for function main
def test_main():
    # Check if module AnsibleModule exists.
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        assert False, "You must install the Ansible codebase before running the unit tests."

    # Check if function main exists.
    try:
        from ansible.module_utils.action_plugins.dpkg_selections import main
    except ImportError:
        assert False, "You must install the Ansible codebase before running the unit tests."

    # Check if AnsibleModule is a class.
    assert isinstance(AnsibleModule, type)

# Generated at 2022-06-11 07:01:50.915354
# Unit test for function main
def test_main():
    module_args = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:02:02.590256
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    module.run_command = Mock(return_value=(0, "NTPD hold", ""))

    dpkg = module.get_bin_path('dpkg', True)
    name = "ntpd"
    selection = "hold"

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-11 07:02:24.484629
# Unit test for function main
def test_main():
    def mock_run_command(run_command, check_rc=False, data=None):
        class Args():
            def __init__(self):
                self.shell = False
        if run_command == ['dpkg', '--get-selections', 'python']:
            return 0, 'python install', ''
        elif run_command == ['dpkg', '--set-selections']:
            return 0, '', ''
    dpkg_selections = __import__('ansible.modules.system.dpkg_selections')
    dpkg_selections.AnsibleModule.run_command = mock_run_command
    dpkg_selections.AnsibleModule.get_bin_path = lambda x, y: 'dpkg'

# Generated at 2022-06-11 07:02:35.218267
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        )

    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', 'zlib1g'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    module.params['name'] = 'zlib'
    module.params['selection'] = 'deinstall'
    main()

# Generated at 2022-06-11 07:02:41.420565
# Unit test for function main
def test_main():
    """
    Unit tests for main
    """

    # Tests for dpkg_selections module
    # Basic arguments
    # ---------------
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:02:44.798485
# Unit test for function main
def test_main():
    args = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,

# Generated at 2022-06-11 07:02:51.075416
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:02:59.730667
# Unit test for function main
def test_main():
    dpkg = '/usr/bin/dpkg'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    module.exit_json(changed=changed, before=current, after=selection)

# Generated at 2022-06-11 07:03:00.334203
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:03:01.378659
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:03:10.919624
# Unit test for function main
def test_main():
    # Test: run module with default parameters
    module = AnsibleModule({"name": "python", "selection": "purge"})
    rc, out, err = module.run_command(['dpkg', '--get-selections', 'python'])
    assert rc == 0
    assert ("python hold" in out) or ("python deinstall" in out)

    if ("python hold" in out):
        selection = "deinstall"
    else:
        selection = "hold"

    module = AnsibleModule({"name": "python", "selection": selection})
    rc, out, err = module.run_command(['dpkg', '--get-selections', 'python'])
    assert rc == 0
    assert ("python hold" in out) or ("python deinstall" in out)
    assert selection in out

# Generated at 2022-06-11 07:03:17.756212
# Unit test for function main
def test_main():
    # Setup a fake module
    fake_module = type('FakeModule', (object, ), {'run_command':staticmethod(lambda c, *args, **kwargs: (0, c[2], ''))})()
    fake_module.exit_json = staticmethod(lambda *args, **kwargs: None)
    fake_module.get_bin_path = staticmethod(lambda *args, **kwargs: ('/bin/%s' % args[0]))
    fake_module.check_mode = False
    fake_module.params = {'selection': 'install', 'name': 'libc6'}

    # Call the function with a fake module
    main(fake_module)

# Generated at 2022-06-11 07:03:52.875392
# Unit test for function main
def test_main():
    test = AnsibleModule(argument_spec=dict(
        module = dict(required=True),
        name = dict(required=True),
        selection = dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ) )

    test_json = main()
    test.exit_json(**test_json)

# Generated at 2022-06-11 07:03:53.525648
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:03:54.021572
# Unit test for function main
def test_main():
    assert main() == True

# Generated at 2022-06-11 07:03:59.563058
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert main() == module.exit_json(changed=True, before='install', after='hold')
    assert main(name='python') == module.exit_json(changed=False, before='hold', after='hold')

# Generated at 2022-06-11 07:04:07.533557
# Unit test for function main
def test_main():
    data = 'python deinstall'

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common._collections_compat import MutableSequence


# Generated at 2022-06-11 07:04:18.023595
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    rc, out, err = module.run_command(['dpkg', '--get-selections', module.params['name']], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    # Test normal case
    if current != 'hold':
        assert main() == True

    # Test ignore case
    if current == 'hold':
        assert main() == False

# Generated at 2022-06-11 07:04:26.134693
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str')
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:04:33.352492
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    dpkg = 'dpkg'
    name = 'python'
    selection = 'hold'

    rc, out, err = AnsibleModule().run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if not changed:
        AnsibleModule().exit_json(changed=changed, before=current, after=selection)

    AnsibleModule().run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    AnsibleModule().exit_json(changed=changed, before=current, after=selection)

# Generated at 2022-06-11 07:04:42.515754
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:04:43.045775
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:05:27.632048
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:05:34.874091
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != 'install'

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after='install')

# Generated at 2022-06-11 07:05:46.375279
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:05:48.401130
# Unit test for function main
def test_main():
    # If we get here, we are at least able to import the module
    from ansible.modules.system.dnf import dpkg_selections
    assert dpkg_selections

# Generated at 2022-06-11 07:05:57.467843
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:06:00.631167
# Unit test for function main
def test_main():
    assert main() is True

# Unit test that checks the return code of main() is 0 when given valid
# parameters.

# Generated at 2022-06-11 07:06:09.165472
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    
    dpkg = module.get_bin_path('dpkg', True)
    
    name = module.params['name']
    selection = module.params['selection']
    
    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    
    changed = current != selection
    

# Generated at 2022-06-11 07:06:14.632194
# Unit test for function main
def test_main():
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        mock_module.config = mock.Mock()
        mock_module.params = {'name':'python', 'selection':'hold'}
        dpkg_selections.main()
        mock_module.run_command.assert_any_call(['dpkg','--set-selections'], data='python hold', check_rc=True)

# Generated at 2022-06-11 07:06:24.345409
# Unit test for function main
def test_main():
    module_args = dict()
    module_args.update(
        dict(
            name='python',
            selection='hold'
        )
    )

# Generated at 2022-06-11 07:06:33.108648
# Unit test for function main
def test_main():
    # Test requires dpkg installed and in the path
    import subprocess
    import sys
    try:
        subprocess.Popen(['dpkg', '--get-selections', 'dpkg'], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    except:
        sys.stderr.write("dpkg could not be found or is installed incorrectly")
        sys.exit(1)

    test_module_name = 'test_dpkg_selections'
    test_module_path = os.path.join(sys.path[0], test_module_name + '.py')

    test_module = imp.new_module(test_module_name)
    test_module.__file__ = test_module_path
    sys.modules[test_module_name] = test_

# Generated at 2022-06-11 07:08:59.194158
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import *
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import action_common
    from ansible.module_utils.action_common import config_to_dict
    from ansible.module_utils.action_common import exit_return
    from ansible.module_utils.action_common import filter_unsupported_parameters
    from ansible.module_utils.action_common import get_bin_path
    from ansible.module_utils.action_common import set_default_config
    from ansible.module_utils.action_common import get_common_arg_spec
    from ansible.module_utils.action_common import load_platform_subclass

    def setUpModule():
        set_default_config(config_to_dict())

   

# Generated at 2022-06-11 07:08:59.708497
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:09:00.517061
# Unit test for function main
def test_main():
    """Unit test for main()"""
    main()

# Generated at 2022-06-11 07:09:01.120653
# Unit test for function main
def test_main():
    print("hello")

# Generated at 2022-06-11 07:09:07.594340
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.packaging.os.dpkg_selections import main
    import sys
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)),
        supports_check_mode=True)
    sys.modules['ansible'] = type('MockAnsible', (object,), {'AnsibleModule': module})
    main()

# Generated at 2022-06-11 07:09:16.875475
# Unit test for function main
def test_main():
    data = '''
    - name: Prevent python from being upgraded
      dpkg_selections:
        name: python
        selection: hold
    '''

    def run_command(option, data=None):
        if option[1] == '--get-selections':
            return 0, '', ''

        return 0, '', ''

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.run_command = run_command
    module.get_bin_path = lambda x: None
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-11 07:09:26.331504
# Unit test for function main
def test_main():
    # Set up arguments and parameters to match what main would receive
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Set up function paramaters
    name = module.params['name']
    selection = module.params['selection']

    # Set up test case data
    out = "package \n"
    err = ""


    # Test when selection == current

    # Mock module.run_command() to control its return value
    module.run_command = MagicMock(return_value=(0, out, err))

    # Call main() and check the result
    main()

    # Verify run_

# Generated at 2022-06-11 07:09:36.082970
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "python"
    selection = "install"

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:09:45.403843
# Unit test for function main
def test_main():
    # Get the class name of the type of the first parameter
    firstArgClassName = type(sys.argv[1]).__name__

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-11 07:09:53.145554
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    name = 'python'
    selection = 'hold'

    dpkg_selections = DpkgSelections()
    default = {'changed': False, 'before': 'install', 'after': 'hold'}

    dpkg_selections.check_mode = False
    assert dpkg_selections.main() == default

    dpkg_selections.name = name
    dpkg_selections.selection = selection
    assert dpkg_selections.main() == default

    dpkg_selections.check_mode = True
    assert dpkg_selections.main() == default