

# Generated at 2022-06-11 07:00:02.906549
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:00:11.768848
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = "/usr/bin/dpkg"
    name = "python"
    selection = "purge"
    rc = 0
    out = "python install"
    err = ""
    result = {'_ansible_parsed': True, '_ansible_no_log': False, 'invocation': {'module_name': 'dpkg_selections', 'module_args': {'name': 'python', 'selection': 'purge'}}, 'changed': False, 'after': 'purge', 'before': 'install'}

# Generated at 2022-06-11 07:00:20.078671
# Unit test for function main

# Generated at 2022-06-11 07:00:20.905392
# Unit test for function main
def test_main():
    assert main() == 1, "main function failed"

# Generated at 2022-06-11 07:00:22.365570
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as exception:
        print(str(exception))

# Generated at 2022-06-11 07:00:31.696281
# Unit test for function main
def test_main():
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils import dpkg_selections
        module = AnsibleModule(argument_spec=dict(name=dict(required=True),selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)),supports_check_mode=True)
        ansible_module = dpkg_selections.main()
        assert ansible_module.params['name'] == 'python'
        assert ansible_module.params['selection'] == 'hold'
        assert ansible_module.get_bin_path('dpkg','True') == "/usr/bin/dpkg"
        module.run_command(["dpkg", "--get-selections", "python"], check_rc=True)

# Generated at 2022-06-11 07:00:38.049465
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = mock.Mock()
    main()
    module.run_command.assert_called_once_with([module.get_bin_path('dpkg', True), '--set-selections'], data='test name test selection', check_rc=True)


# Generated at 2022-06-11 07:00:38.702411
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:00:39.536500
# Unit test for function main
def test_main():
    print('Test main')

test_main()

# Generated at 2022-06-11 07:00:47.920831
# Unit test for function main
def test_main():

    # Empty the set_selections file
    f = open('/var/lib/dpkg/status', 'w')
    f.truncate()
    f.close()

    # pylint: disable=missing-docstring
    # pylint: disable=redefined-outer-name
    def run_command(command, data, check_rc=True):
        if command[-1] == '--get-selections':
            return 0, 'python\tdeinstall', ''
        elif command[-1] == '--set-selections':
            with open('/var/lib/dpkg/status', 'a') as f:
                f.write(data)
            return 0, '', ''
        else:
            return 1, '', 'error'


# Generated at 2022-06-11 07:01:03.227514
# Unit test for function main
def test_main():
    import json
    import mock
    import os
    import shutil
    import tempfile
    import textwrap

    tempdir = tempfile.mkdtemp()
    dpkgdir = os.path.join(tempdir, 'dpkg')
    os.mkdir(dpkgdir)
    with open(os.path.join(dpkgdir, '--get-selections'), 'w') as f:
        f.write(textwrap.dedent('''
            hello install
            goodbye deinstall
            '''))
    os.mkdir(os.path.join(dpkgdir, 'bin'))
    os.symlink('../--get-selections', os.path.join(dpkgdir, 'bin', 'dpkg'))

# Generated at 2022-06-11 07:01:10.292906
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    dpkg = module.get_bin_path('dpkg', False)
    if not dpkg:
        module.fail_json(msg="Unable to find dpkg")

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    module.params = {'selection': 'hold', 'name': 'python'}
    main()

    rc,

# Generated at 2022-06-11 07:01:17.163416
# Unit test for function main
def test_main():
    # import as module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Find dpkg
    setattr(module, 'get_bin_path', lambda *args, **kwargs: '/usr/bin/dpkg')
    # Check for exception 1st
    try:
        main()
    except:
        exception_occurred = True
        # Check if exception occurred
        assert exception_occurred
    # Now use correct params & run main function
    main()
    # Check if function main ran without exceptions
    assert True

# Generated at 2022-06-11 07:01:19.789857
# Unit test for function main
def test_main():
    module = AnsibleModule(name='test_module')
    setattr(module, 'run_command', lambda *args, **kwargs: (0, '', ''))
    setattr(module, 'exit_json', lambda *args, **kwargs: None)
    setattr(module, 'params', {'name': 'test_module', 'selection': 'hold'})
    result = main()
    assert result == True

# Generated at 2022-06-11 07:01:26.280741
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', 'python'],
                                      check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    assert current == 'install'

# Generated at 2022-06-11 07:01:36.913128
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleRunner
    import sys
    import os
    
    # sys.argv = ['', '', '', '', '', '', '', '']
    os.environ['MOLECULE_INVENTORY_FILE'] = './ansible_hosts'
    os.environ['MOLECULE_SCENARIO_DIRECTORY'] = './'
    os.environ['MOLECULE_PROJECT_DIRECTORY'] = './'
    os.environ['MOLECULE_INSTANCE_CONFIG'] = './'
    os.environ['ANSIBLE_CONFIG'] = './ansible.cfg'

    # sys.modules['ansible'] = __

# Generated at 2022-06-11 07:01:47.292041
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:48.101251
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:01:59.491388
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:02:07.587522
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )

    dpkg = './dpkg'
    dpkg_set_selections = './dpkg-set-selections'
    dpkg_get_selections = './dpkg-get-selections'
    name = 'dpkg_selections'

    def fake_dpkg(*args, **kwargs):
        # all other args are ignored, only check for a call with data set
        if 'data' in kwargs:
            assert kwargs['data'] == 'dpkg_selections install'

# Generated at 2022-06-11 07:02:24.483743
# Unit test for function main
def test_main():
	from ansible.module_utils.basic import AnsibleModule
	from ansible.module_utils.basic import DpkgSelectionsAnsibleModule

# Generated at 2022-06-11 07:02:30.747552
# Unit test for function main
def test_main():
    dpkg = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )

    main()

# Generated at 2022-06-11 07:02:35.650886
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # Set defaults
    module.params['name'] = 'python'
    module.params['selection'] = 'install'
    # Test
    main()

# Generated at 2022-06-11 07:02:46.321789
# Unit test for function main
def test_main():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes
    from ansible_collections.notstdlib.moveitallout.plugins.modules.dpkg import main
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    m = patch.dict(os.environ)
    m.clear()
    m['LANG'] = 'C'
    m['LC_ALL'] = 'C'
    m.update(ansible_module_defaults)

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass


# Generated at 2022-06-11 07:02:47.280896
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-11 07:02:56.406904
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:03:06.802569
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:03:14.344461
# Unit test for function main
def test_main():
    import runtests
    results = runtests.run_test(module_name='dpkg_selections',
                                module_args="name=python selection=hold",
                                skip_checks=True)
    assert results['changed'] == False, results['msg']
    results = runtests.run_test(module_name='dpkg_selections',
                                module_args="name=python selection=deinstall",
                                skip_checks=True)
    assert results['changed'] == True, results['msg']
    assert results['before'] == 'hold', results['msg']
    assert results['after'] == 'deinstall', results['msg']
    results = runtests.run_test(module_name='dpkg_selections',
                                module_args="name=python selection=hold",
                                skip_checks=True)

# Generated at 2022-06-11 07:03:23.000408
# Unit test for function main
def test_main():
    # Assume that we are running on a linux machine and modules are available.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = "python"
    selection = "hold"

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection
    #assert changed

# Generated at 2022-06-11 07:03:31.482189
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils import common as utils
    from ansible.compat.tests import unittest

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Mocking the main function .
    with unittest.mock.patch.object(utils, 'run_command') as run_command:
        dpkg = module.get_bin_path('dpkg', True)
        name = module.params['name']
        selection = module.params

# Generated at 2022-06-11 07:03:56.762620
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['selection'] = 'hold'
    module.params['name'] = 'test'

    # Test case 1 - No previous setting, expect False
    rc, out, err = module.run_command([dpkg, '--get-selections', 'test'], check_rc=True)
    assert(rc == 0)
    assert(out.split()[1] == 'install')

    # Test case 2 - Previous setting matches current, expect False
    module.params['selection'] = 'install'

# Generated at 2022-06-11 07:04:04.915328
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import yaml
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    def _mock_command(cmd, check_rc=True):
        class MockProcess(object):
            def __init__(self):
                pass

            def communicate(self):
                return self.rc, self.out, self.err

        if cmd == ['/usr/bin/dpkg', '--get-selections', 'python']:
            if not os.path.exists('/usr/bin/python'):
                # Force the package to not be installed
                process = MockProcess()
                process.rc = 0

# Generated at 2022-06-11 07:04:15.463057
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = test.get_bin_path('dpkg', True)

    name = test.params['name']
    selection = test.params['selection']

    # Get current settings.
    rc, out, err = test.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if test.check_mode or not changed:
        test.exit

# Generated at 2022-06-11 07:04:24.107422
# Unit test for function main
def test_main():
    # Create a dummy module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:04:24.608028
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 07:04:32.338412
# Unit test for function main
def test_main():
    checkmode = False
    selection = 'deinstall'
    module_name = 'dpkg'
    module_args = 'name=openssh-server selection=deinstall'

    # Get the binary path for dpkg
    dpkg = module.get_bin_path('dpkg', True)

    # Make sure the package is installed
    rc, out, err = module.run_command("%s --get-selections %s" % (dpkg, module_name), check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

# Generated at 2022-06-11 07:04:34.214119
# Unit test for function main
def test_main():
    import ips_helper as helper
    result = main()
    assert result == helper.get_ansible_module_results()

# Generated at 2022-06-11 07:04:41.931753
# Unit test for function main
def test_main():
    test_input = {
        'name': 'python',
        'selection': 'hold',
        '_ansible_check_mode': False,
        '_ansible_diff': False,
    }
    test_postive_response = {
        '_ansible_check_mode': False,
        '_ansible_diff': False,
        'after': 'hold',
        'before': 'install',
        'changed': True,
    }
    test_negative_response = {
        '_ansible_check_mode': False,
        '_ansible_diff': False,
        'after': 'hold',
        'before': 'hold',
    }

# Generated at 2022-06-11 07:04:50.919972
# Unit test for function main
def test_main():
    from ansible.module_utils import basic as module_basic
    # Prepare mock arguments
    module_args = {
        'name': 'python',
        'selection': 'hold'
    }

    # Prepare mock environment
    patcher_exists = mock.patch('os.path.exists')
    mock_exists = patcher_exists.start()
    mock_exists.return_value = True
    patcher_get_bin_path = mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path')
    mock_get_bin_path = patcher_get_bin_path.start()
    mock_get_bin_path.return_value = '/usr/bin/dpkg'

# Generated at 2022-06-11 07:04:58.803323
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:05:31.469567
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:05:43.935767
# Unit test for function main
def test_main():
    check_rc = True

    # Test different selection types to handle the idiosyncrasies of the dpkg --set-selections command.
    for selection, test_selection in (('install',   'install'),
                                      ('hold',      'hold'),
                                      ('deinstall', 'deinstall'),
                                      ('purge',     'purge')):

        m = AnsibleModule(argument_spec={'name': {'required': True},
                                         'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}},
                          supports_check_mode=True)
        m.run_command = lambda x, data, check_rc=check_rc: (0, "nodejs install\nlibssl1.0.0 install", "")

# Generated at 2022-06-11 07:05:51.564328
# Unit test for function main
def test_main():
    # http://code.activestate.com/recipes/52308-the-simple-but-handy-collector-of-a-bunch-of-named/
    from collections import namedtuple
    module_mock = namedtuple('AnsibleModule', ['get_bin_path', 'run_command', 'check_mode', 'exit_json', 'run_command'])
    module_mock.check_mode = False
    module_mock.run_command = lambda command, check_rc=True: (0,'','','')
    module_mock.get_bin_path = lambda command, required=True: '/bin/command'
    module_mock.exit_json = lambda **kwargs: ''

    main()

# Generated at 2022-06-11 07:06:00.668096
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert module.check_mode is True
    assert module.diff is False
    assert module.run_command("ls {}".format("apt")) is True
    assert module.get_bin_path('dpkg', True) is True
    assert module.params['name'] is True
    assert module.params['selection'] is True
    assert module.run_command("dpkg --get-selections") is True
    assert module.run_command("dpkg --set-selections") is True
    assert module.exit_json(changed="false") is True

# Generated at 2022-06-11 07:06:09.197186
# Unit test for function main
def test_main():
  events = []
  results = []
  b_rc = None
  b_out = None
  b_err = None

# Generated at 2022-06-11 07:06:11.958078
# Unit test for function main
def test_main():
    with patch('ansible_collections.ansible.debian.plugins.modules.dpkg_selections.AnsibleModule'):
        ansible_collections.ansible.debian.plugins.modules.dpkg_selections.main()

# Generated at 2022-06-11 07:06:20.929215
# Unit test for function main
def test_main():
    out = []
    def run_command(args, p_check_rc=True):
        assert not p_check_rc
        out.append((0, 'python install', ''))
        return (0, 'python install', '')

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.get_bin_path = lambda x: x
    module.run_command = run_command

    main()
    assert out

# vim:ts=4:sw=4:et:

# Generated at 2022-06-11 07:06:30.508395
# Unit test for function main
def test_main():
    def dpkg_selections(name, selection):
        args = dict(name=name, selection=selection)
        module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ))

        dpkg = module.get_bin_path('dpkg', True)

        # Get current settings.
        rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
        if not out:
            current = 'not present'
        else:
            current = out.split()[1]

        changed = current != selection


# Generated at 2022-06-11 07:06:30.858082
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:06:39.020006
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    sys.argv = ['dpkg_selections']

# Generated at 2022-06-11 07:07:55.115738
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            check_mode=dict(type='bool', default=False),
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )

    name = 'test-package'
    selection = 'hold'

    def _check_mode_get_selections_mock(module, *args, **kwargs):
        return 0, """%s\tinstall""" % name, ""

    def _check_mode_set_selections_mock(module, *args, **kwargs):
        return 0, "", ""


# Generated at 2022-06-11 07:08:01.183409
# Unit test for function main
def test_main():
    module_mock = Mock()
    dpkg_mock = MagicMock(return_value='/usr/bin/dpkg')
    module_mock.get_bin_path.return_value = dpkg_mock
    module_mock.params = {'selection': 'install', 'name': 'python'}
    run_command_mock = MagicMock()
    module_mock.run_command = run_command_mock

    # Test when there is no before state
    module_mock.run_command.return_value = (0, '', '')
    main()

# Generated at 2022-06-11 07:08:09.980959
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.run_command = mock.Mock()
    module.check_mode = False

    test_input = ['dpkg', '--get-selections', 'python']
    module.run_command.return_value = 0, 'python install', ''
    main()
    module.run_command.assert_called_once_with(test_input, check_rc=True)

    module.run_command.reset_mock()

    test_input = ['dpkg', '--get-selections', 'python']
    module.run_

# Generated at 2022-06-11 07:08:10.751343
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:08:11.543771
# Unit test for function main
def test_main():
    assert main() is not None

# Generated at 2022-06-11 07:08:13.996663
# Unit test for function main
def test_main():
    with mock.patch('ansible_collections.misc.not_a_real_collection.plugins.modules.dpkg_selections.AnsibleModule'):
        main()

# Generated at 2022-06-11 07:08:21.964840
# Unit test for function main
def test_main():
    import sys
    import StringIO
    import types

    module_backup = sys.modules.copy()

    try:
        from ansible.module_utils import basic
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        print('failed=True msg="ansible is required to run tests"')
        sys.exit(1)

    try:
        from ansible.module_utils import action_plugins
    except:
        pass

    sys.stdout = StringIO.StringIO()
    sys.stderr = StringIO.StringIO()

    # Remove any pre-existing module so that the test can start with a clean slate
    try:
        del sys.modules['ansible_modlib.dpkg_selections']
    except KeyError:
        pass

    # Add the module under test to the

# Generated at 2022-06-11 07:08:30.044068
# Unit test for function main
def test_main():
    import contextlib
    with contextlib.redirect_stdout(None):
        import __main__
    import io
    import sys

    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    # Unit test
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Set the return values
    module.run_command.return_value = 1, '', ''
    main()

    # Ensuirre the method ran
    assert module.run_command.called is True

    # Ensure the output is as expected
    output = capturedOutput.getvalue().strip()
   

# Generated at 2022-06-11 07:08:35.229012
# Unit test for function main
def test_main():
    # Populate the args-spec with what we expect to pass in
    args_spec = dict(
        name="vim",
        selection="hold"
    )
    # Make the call
    test_code = main(dict(params=args_spec))
    # Test that the code did what we expected
    assert test_code['changed'] == True
    assert test_code['before'] == "install"
    assert test_code['after'] == "hold"

# Generated at 2022-06-11 07:08:43.343128
# Unit test for function main
def test_main():
    mock_module = Mock(check_mode=False, params={'name': 'python', 'selection': 'install'})
    mock_run_command = Mock(return_value=(0, "python install", ""))
    mock_module.run_command = mock_run_command
    with patch.object(sys, 'exit') as mock_exit:
        main()
        mock_exit.assert_called_with(
            changed=True, before='not present', after='install')
        assert mock_run_command.call_count == 2
        mock_run_command.assert_any_call(['dpkg', '--get-selections', 'python'], check_rc=True)
        mock_run_command.assert_any_call(['dpkg', '--set-selections'], data="python install", check_rc=True)