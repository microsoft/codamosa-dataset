

# Generated at 2022-06-11 07:00:09.977699
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:18.909538
# Unit test for function main
def test_main():
    import dpkg_selections as module_exec
    import logging

    logger = logging.getLogger('test_dpkg_selections')

    # Test 1, test dpkg_selections with only required params present
    args = dict(
        name='python',
        selection='hold'
    )

    logger.info('Test 1, test dpkg_selections with only required params present')
    module_exec.main(logger, args)

    # Test 2, test dpkg_selections with all params present
    args = dict(
        name='another_package',
        selection='deinstall'
    )

    logger.info('Test 2, test dpkg_selections with all params present')
    module_exec.main(logger, args)

# Test with ansible
# ansible localhost -m test_dpkg_select

# Generated at 2022-06-11 07:00:27.562796
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.packaging.os import dpkg_selections

    with tempfile.NamedTemporaryFile(mode='w+') as tmpfile:
        # Test for argument_spec
        module = AnsibleModule(
            argument_spec={
                'name': dict(required=True),
                'selection': dict(required=True)
            },
            supports_check_mode=True,
        )
        name = 'unittest'
        selection = "hold"
        # Test for get_selections
        rc, out, err = module.run_command(["dpkg", "--get-selections", name], check_rc=True)
        if not out:
            current = 'not present'

# Generated at 2022-06-11 07:00:37.167210
# Unit test for function main
def test_main():
    class Args(object):
        name = None
        selection = None
    def run_command(self, cmd, check_rc=True, data=None):
        rc = 0
        out = None
        err = None
        if self.name == 'module_missing':
            rc = 1
        else:
            out = '{0} {1}'.format(self.name, self.selection)
        return rc, out, err
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=('install', 'hold', 'deinstall', 'purge'), required=True)
    ))
    module.get_bin_path = lambda x, y: 'dpkg'
    module.run_command = run_command
    assert module.main() == 0

# Generated at 2022-06-11 07:00:37.647885
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:00:46.131025
# Unit test for function main
def test_main():
    """Unit test for function main
    """
    import tempfile
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes

    fixture_data = {'name': 'foo', 'selection': 'purge'}
    fixture_data_file = """\
foo\tinstall
"""
    fixture_result = dict(
        ansible_facts=dict(
            dpkg_selections_changed=True,
            dpkg_selections_before='hold',
            dpkg_selections_after='purge',
        ),
        changed=True,
    )


# Generated at 2022-06-11 07:00:46.657478
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:00:47.156628
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 07:00:55.221409
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str')
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'install'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module

# Generated at 2022-06-11 07:01:02.912046
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(name='run_command')
    module.run_command.return_value = (0, 'python install', '')

    dpkg = module.get_bin_path('dpkg', True)
    main()

    module.run_command.assert_called_with([dpkg, '--get-selections', 'name'])

    module.params = {'name': 'python', 'selection': 'install'}
    main()

# Generated at 2022-06-11 07:01:19.514161
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:26.679779
# Unit test for function main
def test_main():
    # Arguments module.params
    arg = {
        'name': 'python',
        'selection': 'hold'
    }

    # Function AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Mock function
    module.get_bin_path = MagicMock(return_value='/usr/bin/dpkg')
    module.check_mode = MagicMock(return_value=False)
    module.run_command = MagicMock(return_value=[0, 'python hold', ''])

# Generated at 2022-06-11 07:01:31.845475
# Unit test for function main
def test_main():

    data = dict(
        name='python',
        selection='hold',
    )

    rc = None
    out = None
    err = None

    assert isinstance(rc, type(None)), 'rc is not of type None'
    assert isinstance(out, type(None)), 'out is not of type None'
    assert isinstance(err, type(None)), 'err is not of type None'

# Generated at 2022-06-11 07:01:43.112729
# Unit test for function main
def test_main():
    import subprocess
    import os
    import sys
    import shutil
    import re
    import tempfile

    # Create a module for this unit test
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test_module_path = os.path.join(os.path.dirname(__file__), '..')
    sys.path.append(test_module_path)

    # Get the temp file to use
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'dpkg-get-selections')

    # Run

# Generated at 2022-06-11 07:01:51.446972
# Unit test for function main
def test_main():
    import unittest
    class TestClass(unittest.TestCase):
        def test_dpkg_selection(self):
            module = AnsibleModule(argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ), supports_check_mode=True)
            module.run_command = MagicMock(return_value=0)
            dpkg = module.get_bin_path('dpkg', True)
            name = module.params['name']
            selection = module.params['selection']
            rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
            if not out:
                current = 'not present'

# Generated at 2022-06-11 07:01:52.173887
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:02:03.562127
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:02:05.803005
# Unit test for function main
def test_main():
    """
    Tests that the module works as expected.
    """
    module = AnsibleModule(dict(
        name='python',
        selection='hold',
        changed=True
    ))
    assert main()

# Generated at 2022-06-11 07:02:06.677360
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:02:17.571261
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:02:36.377007
# Unit test for function main
def test_main():

    # Mock module and args
    name = 'name'
    selection = 'selection'
    module = MagicMock()
    module.check_mode = False
    module.params = {'name': name, 'selection': selection}

    # Mock AnsibleModule
    m = MagicMock(return_value=module)
    with patch.multiple(ansible.module_utils.basic, AnsibleModule=m) as am:
        main()
        module.run_command.assert_called_with(['dpkg', '--set-selections'], data="{} {}".format(name, selection), check_rc=True)

    # Mock AnsibleModule again
    m = MagicMock(return_value=module)

# Generated at 2022-06-11 07:02:41.837279
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Call main
    main()

# Generated at 2022-06-11 07:02:48.829222
# Unit test for function main
def test_main():
  test_module = AnsibleModule(
    argument_spec=dict(
      name=dict(required=True),
      selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,
  )
  test_module.get_bin_path = lambda x, y: 'dpkg'
  test_module.run_command = lambda x, check_rc=True: ['dpkg', '--get-selections', 'name']
  test_module.check_mode = True
  test_module.exit_json = lambda x: x

  result = main()
  assert result

# Generated at 2022-06-11 07:02:58.020195
# Unit test for function main
def test_main():
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as test_ansible_module:
        test_ansible_module.params = {
            'name': 'python',
            'selection': 'hold'
        }
        test_ansible_module.get_bin_path = mock.Mock(return_value='/usr/bin/dpkg')
        test_ansible_module.run_command = mock.Mock(side_effect=['not present', '0'])
        main()

# Generated at 2022-06-11 07:03:02.507132
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.main()

# Generated at 2022-06-11 07:03:11.835218
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:03:20.037898
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'

    name_spec = dict(required=True)
    selection_spec = dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)

    argument_spec = dict(name=name_spec, selection=selection_spec)

    supports_check_mode_true = True

    module = AnsibleModule(argument_spec=argument_spec, supports_check_mode=supports_check_mode_true)

    dpkg = module.get_bin_path('dpkg', True)

    module_params_name = module.params['name']
    assert module_params_name == name

    module_params_selection = module.params['selection']
    assert module_params_selection == selection

    module_run_command = module.run_command

    rc

# Generated at 2022-06-11 07:03:28.845471
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    current = selection
    name = 'opendj-server-legacy:amd64'
    changed = current != selection
    print(name)
    print(selection)
    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

# Generated at 2022-06-11 07:03:36.648216
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    m_run_command = MagicMock(return_value=(0, 'install', ''))
    dpkg = MagicMock(return_value='/usr/bin/dpkg')
    with patch.multiple(basic.AnsibleModule, exit_json=m_run_command, run_command=m_run_command, get_bin_path=dpkg) as context_mocks:
        main()
        assert context_mocks['exit_json'].call_count == 1


# Generated at 2022-06-11 07:03:43.766143
# Unit test for function main
def test_main():
    # Tests
    module = AnsibleModule(argument_spec={'name': {'required': True},
                                          'selection': {'required': True},
                                          'supports_check_mode': True})

    # Test installing new package
    set_module_args({'name': 'mock-package',
                     'selection': 'install'})
    main()
    assert(module.check_mode or module.params['changed'])

    # Test reinstalling existing package
    set_module_args({'name': 'mock-package',
                     'selection': 'install'})
    main()
    assert(not module.check_mode and not module.params['changed'])

    # Test holding an installed package
    set_module_args({'name': 'mock-package',
                     'selection': 'hold'})
   

# Generated at 2022-06-11 07:04:23.375297
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:04:31.116679
# Unit test for function main
def test_main():
    import os
    import tempfile
    import json

    # We need a temp file
    debconf = tempfile.NamedTemporaryFile()
    debconf.write(b'PACKAGE\tSELECTION\n')
    debconf.flush()

    # Call the function
    rc, out, err = main({'name': 'PACKAGE', 'selection': 'install', '_dpkg_selections_file': debconf.name}, False)
    assert rc == 0
    assert out == {'changed': True, 'after': 'install', 'before': 'not present'}
    assert err == None
    # Change the file and ensure it worked.
    os.system('grep -q "^PACKAGE\\tinstall$" %s' % debconf.name)
    assert rc == 0

# Generated at 2022-06-11 07:04:39.809168
# Unit test for function main
def test_main():
    # Source: https://docs.ansible.com/ansible/latest/ansible/modules/dpkg_selections_module.html
    module_args = {
        'name': 'python',
        'selection': 'hold'
    }
    module = AnsibleModule(argument_spec=module_args)

    # Success scenario
    def run_command_success(args, data, check_rc):
        rc = 0
        out1 = 'python\tinstall'
        out2 = 'python\thold'
        err = ''
        return rc, out1, err
    module.run_command = run_command_success
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    assert rc == 0

    # Failure scenario

# Generated at 2022-06-11 07:04:48.326116
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    dpkg = os.path.join(os.path.dirname(__file__), 'dpkg')

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.get_bin_path = lambda s, x: dpkg

    # Install with no effect
    module.params = dict(name='python',
                         selection='hold')
    main()

# Generated at 2022-06-11 07:04:55.043996
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(required=True)
        ),
        supports_check_mode=True,
    )
    rc, out, err = module.run_command = ['dpkg', '--get-selections', 'python']
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != 'hold'
    module.exit_json(changed=changed, before=current, after='hold')


# Generated at 2022-06-11 07:04:57.240371
# Unit test for function main
def test_main():
    test_selection = [{
        'name': 'python',
        'selection': 'hold',
        }]
    assert test_main(test_selection)

# Generated at 2022-06-11 07:04:57.777718
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:05:09.724400
# Unit test for function main
def test_main():
    dpkg_selections = os.path.join(os.path.dirname(__file__), 'dpkg_selections.py')

    # Check that a status change is detected and performed
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)

# Generated at 2022-06-11 07:05:18.045057
# Unit test for function main
def test_main():
    # Test with check mode
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {
        'name': 'test-package',
        'selection': 'hold'
    }
    module.check_mode = True
    out = main()
    assert out['changed'] == False

    # Test with a valid call

# Generated at 2022-06-11 07:05:21.565517
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    basic.AnsibleModule = DummyAnsibleModule

    module = DummyAnsibleModule()
    module.run_command = run_command_mock

    main()

# Generated at 2022-06-11 07:06:11.911968
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:06:12.565876
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:06:22.691189
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    print("AAAAAA")

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:06:31.835380
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    def _run_command(args, check_rc=True):
        if check_rc:
            assert len(args) == 3
            assert args[0] == '/usr/bin/dpkg'
            assert args[1] == '--get-selections'
            assert args[2] == 'hello'
        return 0, 'hello\tinstall\n', ''
    module.run_command = _run_command
    module.get_bin_path = lambda x: '/usr/bin/dpkg'
    module.check_mode = False

# Generated at 2022-06-11 07:06:39.169660
# Unit test for function main
def test_main():
    # Test case 1 (test happy path):
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    setattr(module, 'run_command', lambda *args, **kwargs: (0, 'old_package hold', ''))
    setattr(module, 'get_bin_path', lambda *args, **kwargs: "test_dpkg")
    setattr(module, 'check_mode', False)
    setattr(module, 'params', {
        "name": "test_package",
        "selection": "hold"
    })


# Generated at 2022-06-11 07:06:39.781699
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:06:49.128314
# Unit test for function main
def test_main():
    out = 'python                install\n'
    name = 'python'
    selection = 'hold'
    rc = 0
    err = ''
    changed = True
    class ModuleTest(object):
        def __init__(self):
            self.params = {'name': 'python', 'selection': 'hold'}
            self.check_mode = False
        def get_bin_path(self, command, required):
            return command
        def run_command(self, cmd, check_rc, data=''):
            class InnerObject(object):
                def __init__(self):
                    self.rc = rc
                    self.stdout = out
                    self.stderr = err
            return InnerObject()
        def exit_json(self, changed, before, after):
            assert changed == True
            assert before == 'install'

# Generated at 2022-06-11 07:06:54.333356
# Unit test for function main
def test_main():
    print("STARTING UNIT TEST")
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = 'python'
    selection = 'hold'
    changed = True
    module.exit_json(changed=changed, before="not present", after=selection)
    print("UNIT TEST COMPLETED\n")

test_main()

# Generated at 2022-06-11 07:07:02.207572
# Unit test for function main
def test_main():

    # test with parameters
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'])
        ),
        supports_check_mode=True,
    )

    module.exit_json = MagicMock()
    module.run_command = MagicMock(return_value=(0, 'python install', ''))
    dpkg_selections.main()
    module.exit_json.assert_called_with(changed=False, before='install', after='install')

    # test with error in run_command
    setattr(module, 'run_command', MagicMock(return_value=(1, '', '')))
    dpkg_selections.main()
    module.fail_json

# Generated at 2022-06-11 07:07:05.561863
# Unit test for function main
def test_main():
    args = {
        'name': 'ansible',
        'selection': 'install',
        'check_mode': False,
        'diff': False
    }
    dpkg_selections = main()
    assert dpkg_selections == "dpkg --get-selections"

# Generated at 2022-06-11 07:09:30.853851
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection
    assert changed == False

# Generated at 2022-06-11 07:09:35.951218
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

# Generated at 2022-06-11 07:09:37.264322
# Unit test for function main
def test_main():
    raise NotImplementedError("TODO: Write those tests")

# Generated at 2022-06-11 07:09:47.052632
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:09:56.127821
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit