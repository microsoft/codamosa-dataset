

# Generated at 2022-06-11 07:00:02.321117
# Unit test for function main
def test_main():
    dpkg_selections = AnsibleModule({
        'name': 'test',
        'selection': 'hold'
    }, check_invalid_arguments=False)
    main()

# Generated at 2022-06-11 07:00:10.872217
# Unit test for function main
def test_main():
    """
    It's possible to test this module like this:

    $ python -m unitest tests/test_dpkg_selections.py -v

    Ensure you have python-test installed:

    $ pip install python-test

    """
    # Mock the module parameters
    module_args = dict(
        name='python',
        selection='hold'
    )

    # Mock the function args
    check_output_args = [(['dpkg', '--get-selections', 'python'],), (['dpkg', '--set-selections'],), (['dpkg', '--get-selections', 'python'],)]

    # Mock the check_output function for the command module

# Generated at 2022-06-11 07:00:19.609457
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    fd, tf = tempfile.mkstemp()
    os.close(fd)
    os.remove(tf)

    # make sure the module can be found
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

# Generated at 2022-06-11 07:00:28.537740
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = 'python3.4'
    selection = 'purge'
    test_package_selection = '{0} {1}\n'.format(name, selection)
    
    # Set up fake dpkg selection file
    test_selection_file = tempfile.NamedTemporaryFile()
    test_selection_file.write(test_package_selection.encode('utf-8'))

# Generated at 2022-06-11 07:00:37.095049
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'python'
    module.params['selection'] = 'deinstall'

    # given
    dpkg = module.get_bin_path('dpkg', True)
    module.run_command([dpkg, '--set-selections'], data="%s %s" % (module.params['name'], 'hold'), check_rc=True)

    # when
    main()

    # then
    assert True

# Generated at 2022-06-11 07:00:45.519978
# Unit test for function main
def test_main():
    args = {
        'selection': 'purge',
        'name': 'python',
    }
    with patch.object(AnsibleModule, 'run_command') as mock_run_command:
        mock_run_command.return_value = 0, 'dpkg-query: no packages found matching python\n', ''
        module = AnsibleModule(argument_spec={
            'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
            'name': dict(required=True)
        }, supports_check_mode=True)
        result = main()
        assert result['changed'] == False
        assert result['after'] == args['selection']


# Generated at 2022-06-11 07:00:50.928180
# Unit test for function main
def test_main():
    # import module
    import ansible.modules.native.package.dpkg_selections as dpkg_selections
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(required=True)
        )
    )
    # set params
    module.params = {'name': 'testmodule', 'selection': 'present'}
    # test main
    dpkg_selections.main()

# Generated at 2022-06-11 07:00:55.737837
# Unit test for function main
def test_main():

    # 1. Find module import arguments
    import inspect
    function_args = inspect.getargspec(main)
    arguments = function_args.args

    # 2. Create Mock
    mock = {
        'module': {
            'get_bin_path': None,
            'params': {
                'name': None,
                'selection': None,
            },
            'check_mode': True,
        },
    }
    # 3. Call function, check and store result
    result = main()
    assert result == mock

# Generated at 2022-06-11 07:01:03.478282
# Unit test for function main
def test_main():
    import pytest

    # Unit test the module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Note that we are using the real module here.
    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current

# Generated at 2022-06-11 07:01:10.838191
# Unit test for function main
def test_main():
    import mock
    mock_module = mock.MagicMock()
    mock_module.params = dict(
        name='python',
        selection='hold'
    )
    out = """python hold"""
    mock_module.run_command = mock.MagicMock(return_value=(0,out,None))
    mock_module.check_mode = False
    mock_module.get_bin_path = mock.MagicMock(return_value='dpkg')
    with mock.patch('ansible.module_utils.basic.AnsibleModule', return_value=mock_module) as mock_module2:
        dpkg_selections = __import__('dpkg_selections')
        main()

# Generated at 2022-06-11 07:01:30.105328
# Unit test for function main
def test_main():
    check_args(dict(name='python', selection='hold'))

    with pytest.raises(Exception):
        check_args(dict(name='python', foo='bar'))

    with pytest.raises(Exception):
        check_args(dict(name='python', selection='foo'))

    with pytest.raises(Exception):
        check_args(dict(selection='hold'))

# Generated at 2022-06-11 07:01:31.046982
# Unit test for function main
def test_main():
    # TODO
    assert False

# Generated at 2022-06-11 07:01:42.297965
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:47.250158
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    main()

# Generated at 2022-06-11 07:01:50.222821
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)))

# Generated at 2022-06-11 07:01:59.918024
# Unit test for function main
def test_main():
    # Mock action parameters for function main
    content1 = {'name': 'test', 'selection': 'test'}
    module = action_common_attributes(content1)
    entry = {'dpkg':'/bin/dpkg'}
    # Mock dpkg command output
    out1 = 'test test'
    module.run_command = mocker.MagicMock(side_effect=[[0, out1, '']])
    # Assert the command is called
    main()
    module.run_command.assert_called_with(['/bin/dpkg', '--get-selections', 'test'])


# Generated at 2022-06-11 07:02:06.128507
# Unit test for function main
def test_main():
    import os
    import sys
    import subprocess
    fp = os.path.dirname(os.path.abspath(__file__)) + "/file.txt"
    f = open(fp, "w")
    f.write((subprocess.check_output([sys.executable, fp, '--name', 'ansible', '--selection', 'install'])).decode('utf-8').strip())
    f.close()
    f = open(fp, "r")
    coutput = f.read()
    f.close()
    assert coutput == '{"changed": true, "after": "install", "before": "not present"}'

# Generated at 2022-06-11 07:02:06.971563
# Unit test for function main
def test_main():
  main()

# Generated at 2022-06-11 07:02:08.494455
# Unit test for function main
def test_main():
    print (main.__doc__)
    os.system('sh dpkg_selections.sh')

# Generated at 2022-06-11 07:02:19.915489
# Unit test for function main
def test_main():
    from ansible_collections.notstdlib.moveitallout.tests.units.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    import ansible_collections.notstdlib.moveitallout.plugins.modules.package.dpkg as dpkg
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.package.dpkg_selections as dpkg_selections

    dpkg.ANSIBLE_MODULE_PATH = ansible_collections.notstdlib.moveitallout.plugins.modules.package.dpkg

    class TestCase(ModuleTestCase):
        def test_dpkg_selections_name(self, *_):
            set_module_args(dict(name='test', selection='test'))

# Generated at 2022-06-11 07:02:32.175091
# Unit test for function main
def test_main():
    testVars = []

    assert(main()[1] == True)

# Generated at 2022-06-11 07:02:42.754490
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:02:50.185902
# Unit test for function main
def test_main():
    # Get the path to the module source
    _module_path = os.path.dirname(os.path.realpath(__file__))
    ansible_module_path = os.path.join(_module_path, '..', 'ansible_module')
    sys.path.insert(0, ansible_module_path)
    from ansible.module_utils.basic import AnsibleModule

    # Create the ansible module mock
    module_mock = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ), supports_check_mode=True)
    module_mock.params['name'] = 'some-package'

# Generated at 2022-06-11 07:02:54.061094
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    assert True == True

# Generated at 2022-06-11 07:03:03.635711
# Unit test for function main
def test_main():
    testmodule = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        #avoiding a lot of boilerplate code
        #this is usually done by AnsibleModule itself
        supports_check_mode=True,
    )

    dpkg = testmodule.get_bin_path('dpkg', True)

    testname = testmodule.params['name']
    testselection = testmodule.params['selection']

    # Get current settings.
    testrc, testout, testerr = testmodule.run_command([dpkg, '--get-selections', testname], check_rc=True)
    if not testout:
        testcurrent = 'not present'
   

# Generated at 2022-06-11 07:03:12.700448
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ),
            supports_check_mode=True,
    )

    # Test cases
    real_rc = 0
    real_out = 'python\thold'
    real_err = ''

    get_selections_cmd = ['/usr/bin/dpkg', '--get-selections', 'python']
    set_selections_cmd = ['/usr/bin/dpkg', '--set-selections']
    set_selections_data = "python hold"

    # Test case for check mode, change is True
    module.params['name'] = 'python'

# Generated at 2022-06-11 07:03:21.400737
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:03:22.776866
# Unit test for function main
def test_main():
	assert main() is None, "main() failed."


# Generated at 2022-06-11 07:03:31.179880
# Unit test for function main

# Generated at 2022-06-11 07:03:31.670143
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:04:13.981912
# Unit test for function main
def test_main():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.path.pardir, os.path.pardir, "lib"))

    from dpkg_selections_lib import *

    module, out, err = dpkg_selections_test_module(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command("true") # simulate running dpkg-query --get-selections python
    module.exit_json(changed=True, before='not present', after='hold')


# Generated at 2022-06-11 07:04:22.786704
# Unit test for function main
def test_main():
    from ansible.module_utils.debian_support import DebianSupport
    from ansible.module_utils.basic import AnsibleModule

    # Successfully change a selection
    module = AnsibleModule(
        argument_spec=dict(
            name='python',
            selection='hold'
        )
    )
    DebianSupport.dpkg = '/usr/bin/echo'
    module.run_command = lambda args, check_rc=False: (0, 'python hold', '')
    main() is None
    assert module.exit_json.called
    changed_args, kwargs = module.exit_json.call_args
    assert changed_args[0]['changed'] is True
    assert changed_args[0]['before'] == 'deinstall'
    assert changed_args[0]['after'] == 'hold'

    # Success

# Generated at 2022-06-11 07:04:30.908830
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:04:31.602171
# Unit test for function main
def test_main():
    assert main() == True


# Generated at 2022-06-11 07:04:40.449806
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:04:49.237520
# Unit test for function main
def test_main():
    ## Unit test definition ##
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    name = 'python'
    selection = 'hold'
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)


# Generated at 2022-06-11 07:04:54.703691
# Unit test for function main
def test_main():

    input_args = {
        'name': 'python',
        'selection': 'hold',
    }

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    results = main()

    assert results is None


# Generated at 2022-06-11 07:05:05.947291
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection
    module.exit_json(changed=changed, before=current, after=selection)

# Generated at 2022-06-11 07:05:06.565169
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:05:16.216866
# Unit test for function main
def test_main():
    #print ('Main method')
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    #print (module.params['name'])
    name = module.params['name']
    selection = module.params['selection']
    #print (module)
    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()

# Generated at 2022-06-11 07:06:02.862729
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:06:10.536777
# Unit test for function main
def test_main():
    from ansible.utils import template
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    dpkg = '/usr/bin/dpkg'
    name = 'dpkg_selections'
    selection = 'hold'

    out = "%s	%s" % (name, selection)
    rc = 0

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    m_run_command = module.run_command

# Generated at 2022-06-11 07:06:16.460197
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ),
    supports_check_mode=True,
    )
    module.get_bin_path = lambda x,y: '/usr/bin/dpkg'
    assert main() == dict(changed=True, before='install', after='hold')

# Generated at 2022-06-11 07:06:18.107403
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold'
    )
    main()

# Generated at 2022-06-11 07:06:27.511821
# Unit test for function main
def test_main():
    r_current = 'install'

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        """function to patch over fail_json; package return data into an exception"""
        kwargs['failed'] = True
        raise AnsibleExitJson(kwargs)


# Generated at 2022-06-11 07:06:28.963745
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-11 07:06:37.157272
# Unit test for function main
def test_main():
  import json
  import tempfile
  dat = '''\
  {"argument_spec": {"name": {"required": true}, "selection": {"choices": ["install", "hold", "deinstall", "purge"], "required": true}}, "is_standalone": false, "supports_check_mode": true}
  '''
  with tempfile.NamedTemporaryFile() as fd:
    fd.write(dat)
    fd.flush()
    context = dict(module_name='dpkg_selections', module_path=fd.name)
    context.update({'ANSIBLE_MODULE_ARGS': json.dumps({'name': 'python', 'selection': 'hold'})})
    ansible_mock_module(context)

# Generated at 2022-06-11 07:06:40.158511
# Unit test for function main
def test_main():
    with mock.patch("ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule.run_command", side_effect=run_command_mock):
        assert module_utils.basic.AnsibleModule.run_command() == True

# Generated at 2022-06-11 07:06:49.413851
# Unit test for function main
def test_main():

    # Mock functions
    if __name__ == '__main__':
        mrun = MagicMock()
        mrun_command = MagicMock()
        mrun_command.return_value = (0, "sles sles install", '')
        mrun.run_command = mrun_command

        mget_bin_path = MagicMock()
        mget_bin_path.return_value = "/usr/bin/dpkg"
        mmodule = MagicMock()

        mmodule.get_bin_path = mget_bin_path
        mmodule.check_mode = False
        mmodule.exit_json = MagicMock()
        mmodule.params = {'name': 'python',
                          'selection': 'hold'}

        mmodule.run_command = mrun

# Generated at 2022-06-11 07:06:50.534697
# Unit test for function main
def test_main():
    # We don't have a main function to test.
    pass

# Generated at 2022-06-11 07:09:21.128580
# Unit test for function main
def test_main():
    # Given
    module_args = {
        "name": 'python',
        "selection": 'hold'
    }
    dpkg_selections_out = b"""python   deinstall
python-minimal   deinstall
"""
    dpkg_selections_err = b""""""
    dpkg_selections_rc = 0
    module = Mock(
        params=module_args,
        run_command=Mock(
            return_value=(dpkg_selections_rc, dpkg_selections_out, dpkg_selections_err)
        ),
        get_bin_path=Mock(
            return_value="/usr/bin/dpkg"
        )
    )

    # When
    main()

    # Then

# Generated at 2022-06-11 07:09:27.925062
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    args = {'name': 'python', 'selection': 'hold'}
    module.params = args
    out = main()
    assert out['changed']
    assert out['before'] == 'install'
    assert out['after'] == 'hold'

# Generated at 2022-06-11 07:09:37.733643
# Unit test for function main
def test_main():
    import tempfile
    import subprocess
    import os
    import json

    with tempfile.NamedTemporaryFile() as f:
        rc, out, err = module.run_command([dpkg, '--get-selections', 'ntp'])
        if not out:
            current = 'not present'
        else:
            current = out.split()[1]

        if rc != 0 or err:
            module.fail_json(msg="Couldn't find selection for ntp package")

        changed = current != selection

        if check_mode or not changed:
            new_module_args = dict(
                name='ntp',
                selection='deinstall',
                check=True,
                diff=True,
            )

# Generated at 2022-06-11 07:09:38.627815
# Unit test for function main
def test_main():
    assert main() == True


# Generated at 2022-06-11 07:09:46.198920
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    setattr(module, 'check_mode', False)
    setattr(module, '_ansible_diff', True)
    setattr(module, 'params', dict(name='foo', selection='install'))
    setattr(module, 'run_command', lambda *_, **__: (0, 'foo install', ''))
    main()

# Generated at 2022-06-11 07:09:47.734399
# Unit test for function main
def test_main():
    res = main()
    assert res

# Generated at 2022-06-11 07:09:56.625682
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        with patch('ansible.module_utils.basic.get_bin_path') as mock_bin_path:
            mock_bin_path.return_value = True
            mock_module_params = {'name': 'python', 'selection': 'hold'}
            mock_module.run_command = MagicMock()
            mock_module.check_mode = True
            mock_module.run_command.return_value = (0, '', '')
            main()
            mock_bin_path.assert_called_with('dpkg', True)
            mock_module.run_command.assert_called_with([dpkg, '--get-selections', 'python'])
            mock_module.exit_json.assert_called_with