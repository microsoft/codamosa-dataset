

# Generated at 2022-06-11 07:00:04.267196
# Unit test for function main
def test_main():
    # Test for any failure
    pass


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:00:13.081273
# Unit test for function main
def test_main():
    # Check mode test
    dpkg_selections = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg_selections.params = {'name': 'python', 'selection': 'hold'}
    try:
        dpkg_selections.main()
    except Exception as e:
        raise Exception("Unexpected Exception raised: %s" % e)
    assert dpkg_selections.exit_json_data == { "before": "install", "after": "hold", "changed": True }
    assert dpkg_selections.exit_args == (0, "All items completed")

# Generated at 2022-06-11 07:00:15.366843
# Unit test for function main
def test_main():
    args = dict(
        name='python',
        selection='hold'
    )
    result = main(args)

    assert result.get('success') == True
    return True

# Generated at 2022-06-11 07:00:21.911228
# Unit test for function main
def test_main():
    test = AnsibleModule.create(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )

    test.set_bin_path('dpkg', 'test_dpkg')

    def test_dpkg(args, check=True, data=None):
        test.run_command.assert_called_with(['test_dpkg'] + args)
        if check:
            test.run_command.assert_called_with(['test_dpkg'] + args, check_rc=True)
        if data is not None:
            test.run_command.assert_any_call(['test_dpkg'] + args, data=data)

# Generated at 2022-06-11 07:00:30.629190
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"

    dpkg = "/usr/bin/dpkg"

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    module.exit_json(changed=changed, before=current, after=selection)

# Generated at 2022-06-11 07:00:38.965144
# Unit test for function main
def test_main():
  import pytest

  capabilities = {'platform': 'Debian', 'check_mode': True, 'diff_mode': True}
  args = {'name':'python', 'selection':'hold'}
  module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
  )
  def run_command_mock(cmd, check_rc=True):
    if cmd[2] == 'python' and cmd[1] == '--get-selections':
      out = 'python install'

    elif cmd[2] == 'python' and cmd[1] == '--set-selections':
      out = 'python hold'

# Generated at 2022-06-11 07:00:47.297892
# Unit test for function main
def test_main():
    # This needs to be mocked, as the dpkg module uses the dpkg program
    import mock
    import sys
    module = mock.MagicMock()

    sys.modules['ansible'] = mock.MagicMock()
    sys.modules['ansible.module_utils'] = mock.MagicMock()
    sys.modules['ansible.module_utils'].basic = mock.MagicMock()
    sys.modules['ansible.module_utils'].basic.AnsibleModule = module

    sys.modules['ansible.modules'] = mock.MagicMock()
    sys.modules['ansible.modules'].action_common_attributes = mock.MagicMock()


    log = mock.MagicMock()
    main()
    main_module = main()
    main_module.get_bin_path('dpkg', True)

# Generated at 2022-06-11 07:00:55.341244
# Unit test for function main
def test_main():
    test_cases = [
        dict(
            name='python',
            selection='hold',
            check_mode=False,
            diff_mode=False
        )
    ]

    for test_case in test_cases:
        module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True),
                selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
            ),
            supports_check_mode=True,
        )

        dpkg = module.get_bin_path('dpkg', True)

        name = test_case['name']
        selection = test_case['selection']

        # Get current settings.

# Generated at 2022-06-11 07:01:02.027299
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # dpkg returned 0 when package is correctly installed
    out = module.run_command(['dpkg', '--get-selections', 'libssl-dev'])
    assert out != (1, '', '')

    # dpkg returned 1 when package is not installed
    out = module.run_command(['dpkg', '--get-selections', 'xxx'])
    assert out == (1, '', '')

# Generated at 2022-06-11 07:01:02.649021
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 07:01:11.763895
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    with pytest.raises(AnsibleModule):
        main()

# Generated at 2022-06-11 07:01:18.872099
# Unit test for function main
def test_main():
    obj = {}
    output = []
    output.append("dpkg-query: no path found matching pattern *")
    output.append("Use --showformat=<format> to see raw options")
    output.append("")
    out = {'failed': False, 'changed': False, 'msg': []}
    out['stdout'] = output[0]
    out['stdout_lines'] = output
    out['rc'] = 0
    obj['run_command'] = {}
    obj['run_command']['check_rc'] = False
    obj['run_command']['data'] = "python hold"
    obj['run_command']['binary'] = "dpkg"
    obj['run_command']['stdout'] = output[0]
    obj['run_command']['stdout_lines'] = output

# Generated at 2022-06-11 07:01:26.200844
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:36.825490
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    # Mock function run_command
    def run_command(args, check_rc=True):
        out = "python install"
        # Mock output of get-selections
        if args[2] == 'python':
            rc = 0
        else:
            rc = 1

        return rc, out, ""

    # Mock get_bin_path
    def get_bin_path(name, required):
        return "bin_path"

    module.get_bin_path = get_bin_path
    module.run_command = run_command

    # Run main

# Generated at 2022-06-11 07:01:41.286992
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    return main(module)

# Generated at 2022-06-11 07:01:46.460043
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    assert changed == True
    assert current != 'install'

# Generated at 2022-06-11 07:01:58.709670
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'required': True,
                                                   'type': 'str'},
                                          'selection': {'required': True,
                                                        'type': 'str'},
                                          'check_mode': {'choices': [True, False],
                                                         'type': 'bool'},
                                          'diff_mode': {'choices': [True, False],
                                                        'type': 'bool'},
                                          'platform': {'required': False,
                                                       'type': 'str'}},
                           supports_check_mode=True,
                           supports_diff=True)
    # Set the following values as you would like them to appear in your result:
    changed = True or False

# Generated at 2022-06-11 07:02:06.932967
# Unit test for function main
def test_main():
    
    test = 'test'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:02:07.862627
# Unit test for function main
def test_main():
    # Tests that the function did not change
    main()

# Generated at 2022-06-11 07:02:18.996789
# Unit test for function main
def test_main():
    import json

    # Get a json representation of the module parameters
    with open('/tmp/test_main', 'r') as in_file:
        module_json = json.load(in_file)

    # Create a fake module object
    module = type('module', (), module_json)

    # Set the module as global for the check mode function to work
    global module

    # Create a fake module.run_command function that returns a fixed set of results
    def fake_run_command(self, args, data=None, check_rc=True):
        changed = True
        before = 'hold'
        after = 'install'
        out = 'python hold\n'
        return (0, out, '')

    # Replace the module.run_command function with the fake
    module.run_command = fake_run_command

    #

# Generated at 2022-06-11 07:02:34.444346
# Unit test for function main
def test_main():
    args = [ 'python', 'hold']
    opts = { 'name': 'python',
             'selection': 'hold',
             'check_mode': True,
             'check_mode_support': True,
             'diff_mode': True,
             'platform': ['debian'] }
    rc, out, err = main(args, **opts)
    assert rc is None
    assert out is None
    assert err is None

# Generated at 2022-06-11 07:02:34.949284
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:02:45.646117
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import subprocess
    import filecmp
    import sys

    test_dir = tempfile.mkdtemp()

    open(os.path.join(test_dir, 'original'), 'w').close()
    shutil.copy(os.path.join(test_dir, 'original'), os.path.join(test_dir, 'current'))

    cwd = os.getcwd()

# Generated at 2022-06-11 07:02:46.104198
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:02:55.375530
# Unit test for function main
def test_main():
    # Test simple case.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'ansible'
    selection = 'install'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module

# Generated at 2022-06-11 07:03:04.994847
# Unit test for function main
def test_main():
    # Mock function import, required to mock submodule object creation
    import sys
    import __builtin__
    from dpkg_selections import main
    from collections import namedtuple
    from ansible.module_utils._text import to_bytes

    # Create DummyModule for AnsibleModule import and then patch it
    namedtuple('DummyModule', ['argument_spec', 'check_mode', 'run_command'])
    class DummyModule(object):
        # Constructor for DummyModule
        def __init__(self, argument_spec, check_mode=False, run_command=None):
            self.argument_spec = argument_spec
            self.check_mode = check_mode
            self.run_command = run_command
            self.params = {}

        # Get the right binary path

# Generated at 2022-06-11 07:03:08.136581
# Unit test for function main
def test_main():
    dpkg_selections = __import__('dpkg_selections')
    params = {'name': 'python', 'selection': 'hold'}
    dpkg_selections.main(params)

# Generated at 2022-06-11 07:03:13.515943
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson, AnsibleFailJson
   
    m = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ), supports_check_mode=True)

    m.params['name'] = 'python'
    m.params['selection'] = 'hold'
    main()

# Generated at 2022-06-11 07:03:21.263359
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.exit_json = mock.MagicMock()
    module.run_command = mock.MagicMock()
    module.run_command.return_value = (0, "python install", "some error")
    main()
    module.run_command.assert_called_with([module.get_bin_path('dpkg', True), '--set-selections'], data="python purge", check_rc=True)

# Generated at 2022-06-11 07:03:22.965364
# Unit test for function main
def test_main():
    module.exit_json(changed=True, before="install", after="hold")


# Generated at 2022-06-11 07:04:02.862877
# Unit test for function main
def test_main():
    import os
    import sys
    import copy
    import unittest
    import subprocess
    import tempfile
    import shutil
    import json

    class TestModule(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.pshell = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib', 'ansible', 'module_utils', 'powershell', 'Ansible.psm1')
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib', 'ansible', 'module_utils'))

# Generated at 2022-06-11 07:04:03.949464
# Unit test for function main
def test_main():
    assert main() == None, 'Unable to run main()'

# Generated at 2022-06-11 07:04:14.456281
# Unit test for function main
def test_main():
    class Call(object):
        _rc = 0
        _stdout = ''
        _stderr = ''
        def run_command(argv, check_rc=False):
            return (self._rc, self._stdout, self._stderr)
    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.check_mode = False
            self.params = {}
            self.exit_json = lambda **kwargs: self._exit_json(**kwargs)
        def get_bin_path(argv, required=True):
            return True

# Generated at 2022-06-11 07:04:15.003593
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:04:23.721821
# Unit test for function main
def test_main():

    import ansible.modules.system.dpkg_selections as dp

    class _ansible_module(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def check_mode(self):
            return False

        def get_bin_path(self, name, required=False):
            return 'dpkg'

        def run_command(self, rc, out, err):
            return 0, 'python install', ''

        def exit_json(self, **kwargs):
            return kwargs

        def fail_json(self, **kwargs):
            return kwargs

    m = dp.main()

    assert m(
            _ansible_module(
                name='python',
                selection='hold',
            )
        )['before'] == 'install'

# Generated at 2022-06-11 07:04:31.639760
# Unit test for function main
def test_main():
    # Mock of AnsibleModule
    class AnsibleModuleMock(object):
        # __init__() is called with the module argument spec
        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.result = dict()

        # Called when module is executed
        def exit_json(self, **kwargs):
            self.result.update(**kwargs)

    # Mock of AnsibleModule.run_command()
    class RunCommandMock(object):
        def __init__(self):
            self.called_commands = dict()

        # Called when AnsibleModule.run_command() is called
        def __call__(self, command, **kwargs):
            self.called

# Generated at 2022-06-11 07:04:40.489466
# Unit test for function main
def test_main():
    import dpkg_selections

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:04:44.177421
# Unit test for function main
def test_main():
    fix1 = {
        'name': 'python',
        'selection': 'hold'
    }
    fix2 = {
        'name': 'python',
        'selection': 'install'
    }
    assert main(fix1) == True
    assert main(fix2) == True

# Generated at 2022-06-11 07:04:53.127807
# Unit test for function main
def test_main():
    import StringIO
    import sys
    class FakeModule:
        def __init__(self):
            self.exit_json = lambda **kwargs: sys.exit(0)
            self.exit_json.__name__ = 'exit_json'
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.fail_json.__name__ = 'fail_json'
        def run_command(self, cmd, data='', check_rc=True):
            if isinstance(cmd, str):
                cmd = [cmd]
            if cmd[0] == 'dpkg' and cmd[1] == '--get-selections' and cmd[2] == 'vim':
                stdout = 'vim install'
                return 0, stdout, ''

# Generated at 2022-06-11 07:05:02.734467
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection



# Generated at 2022-06-11 07:05:52.821814
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # patch out an exit and fail_json
    setattr(module, 'exit_json', lambda * args, **kwargs: None)
    setattr(module, 'fail_json', lambda * args, **kwargs: None)
    # patch out module.run_command
    old_run_command = module.run_command
    def run_command_mock(* args, **kwargs):
        return 0, 'foo bar', ''
    module.run_command = run_command_mock

    main()

# Generated at 2022-06-11 07:06:01.183285
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:06:09.636215
# Unit test for function main
def test_main():
    def test_run_command(command, check_rc=False):
        class TestObj:
            def test_run_command(self, args, check_rc=False):
                return 'dpkg --set-selections', '', 0
        return TestObj().test_run_command(command, check_rc)

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True, type='str')
        ),
        supports_check_mode=True
    )
    module.run_command = test_run_command
    module.params['name'] = 'python'
    module.params['selection'] = 'purge'
    out = main()


# Generated at 2022-06-11 07:06:19.532857
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(name=dict(required=True),
        selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'])),
        supports_check_mode=True)
    rc, out, err = module.run_command(['dpkg', '--get-selections', 'python'])
    assert 'python' in err, err
    assert 'hold' in err, err
    rc, out, err = module.run_command(['dpkg', '--set-selections'],
            data='python install')
    assert rc == 0, err
    rc, out, err = module.run_command(['dpkg', '--get-selections', 'python'])
    assert 'python' in err, err
    assert 'install' in err, err

# Generated at 2022-06-11 07:06:25.275451
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    def run_command(args, **kwargs):
        return 1, 'dpkg --get-selections test', ''
    module.run_command = run_command
    main()

# Generated at 2022-06-11 07:06:33.763201
# Unit test for function main
def test_main():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = dict(name="python", selection="hold")
    module.check_mode = False
    module.run_command = Mock(return_value=(0, "python	deinstall\n", ""))
    module.get_bin_path = Mock(return_value=True)
    module.run_command = Mock(return_value=(0, "", ""))
    module.exit_json = Mock()
    # Execute
    main()
    # Verify
    assert module.exit_json.call_count == 1

# Generated at 2022-06-11 07:06:42.977739
# Unit test for function main
def test_main():
    # Get the path to the module
    import os
    import sys
    import main

    # The test args
    argv = sys.argv[1:]
    argv.append('--name=python')
    argv.append('--selection=hold')
    argv.append('--check')

    # The test params
    params = {
        'name': argv[-2].split('=')[1],
        'selection': argv[-1].split('=')[1],
    }

    # Instantiate the AnsibleModule

# Generated at 2022-06-11 07:06:43.584005
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:06:44.065339
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:06:52.168944
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:09:08.804641
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:09:13.939676
# Unit test for function main
def test_main():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vault import VaultLib
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-11 07:09:22.653490
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.get_bin_path = MagicMock(return_value='/path/to/dpkg')

    test_module.params = {'name': 'python', 'selection': 'hold'}
    main()
    test_module.run_command.assert_called_with(['/path/to/dpkg', '--get-selections', 'python'], check_rc=True)



# Generated at 2022-06-11 07:09:26.992862
# Unit test for function main
def test_main():
    import random

    for selection in ['install', 'hold', 'deinstall', 'purge']:
        for current in ['not present', 'install', 'hold', 'deinstall', 'purge']:
            assert main(name=random.randint(0, 9999999), current=current, selection=selection)

# Generated at 2022-06-11 07:09:36.787330
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(name='run_command')
    module.get_bin_path = MagicMock(return_value='/usr/bin/dpkg')

    dpkg = module.get_bin_path('dpkg', True)
    assert dpkg == '/usr/bin/dpkg'
    assert dpkg != '/bin/dpkg'

    # Test for changed=False
    module.params = {'name': 'python', 'selection': 'deinstall'}
    # Set current settings as 'deinstall'
   

# Generated at 2022-06-11 07:09:46.070106
# Unit test for function main
def test_main():
    function_name = 'main'
    module = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    }, supports_check_mode=True)
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    changed = current != selection

# Generated at 2022-06-11 07:09:53.586906
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec=dict(
      name=dict(required=True),
      selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
  ),
  supports_check_mode=True
  )
  dpkg = module.get_bin_path('dpkg', True)

  name = 'python'
  selection = 'hold'

  rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
  current = out.split()[1]
  assert current == selection