

# Generated at 2022-06-11 07:00:03.829884
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    test.fail_json({ "msg": "fix me :(" })


# Generated at 2022-06-11 07:00:12.768004
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:20.748394
# Unit test for function main
def test_main():
    import mock
    import sys

    # Set module args
    module_args = dict(
        name='python',
        selection='hold',
        supports_check_mode=True
    )
    # If a mock exists for the main function, use it instead
    if 'main' in sys.modules:
        main = sys.modules['main']
    # Declare Mock Objects
    dpkg = mock.MagicMock()
    module = mock.MagicMock(
        get_bin_path=mock.MagicMock(return_value=dpkg)
    )
    check_rc=True
    out = 'python hold'
    err = ''
    run_command = mock.MagicMock(
        return_value=(check_rc, out, err)
    )
    check_mode = True
    changed = False
    exit_

# Generated at 2022-06-11 07:00:25.435440
# Unit test for function main
def test_main():

    data_in = dict(
        name="python",
        selection="hold"
    )

    module = AnsibleModule(argument_spec=dict(
         name=dict(required=True),
         selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
     ),
     supports_check_mode=True,)

    module.params = data_in
    main()

# Generated at 2022-06-11 07:00:34.969278
# Unit test for function main
def test_main():
    import os
    import sys
    import unittest
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from cStringIO import StringIO
    # Define a class in which the tests will be created
    class TestDpkgSelections(unittest.TestCase):
        def setUp(self):
            # Mock the module object
            self.mock_module = MagicMock()
            # Mock the arguments object
            self.mock_module.params = {'name': 'test', 'selection': 'hold'}
            # Mock the check_mode object
            self.mock_module.check_mode = False
            # Set the return value of the mock module
            self.module_results = {'changed': False, 'before': 'hold', 'after': 'hold'}
           

# Generated at 2022-06-11 07:00:42.727398
# Unit test for function main
def test_main():
    # Define arguments.
    fields = dict(
        name="python",
        selection="hold"
    )

    module = AnsibleModule(argument_spec=fields,
                           supports_check_mode=True)

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

# Generated at 2022-06-11 07:00:51.205152
# Unit test for function main
def test_main():
    import os
    import json
    import tempfile
    import shutil


# Generated at 2022-06-11 07:00:55.652753
# Unit test for function main
def test_main():
    # If no arguments supplied, we show the documentation
    from ansible.utils.module_docs import AnsibleModuleDocumentation
    AnsibleModuleDocumentation(doc=DOCUMENTATION, argspec={'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}, 'name': {'required': True}}, supported_by_check_mode=True, supports_diff_mode=True, supports_platform='full', supports_check_mode=True)

# Generated at 2022-06-11 07:00:56.176704
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:01:03.853575
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import MockOsRelease, AnsibleModule
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.action.dpkg_selections as dpkg_selections

    # Create fake module and mock platform.dist()
    setattr(dpkg_selections, '_platform_dist', MockOsRelease)

    # Create fake module and mock bin path function
    fake_module = AnsibleModule(argument_spec={})
    fake_module.get_bin_path = Mock(return_value='/usr/bin/dpkg')

    # Set module function parameters
    name = 'python'
    selection = 'hold'

    # Set up and run the module
    dpkg_selections.module = fake

# Generated at 2022-06-11 07:01:17.548846
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.check_mode = False

    dpkg = module.get_bin_path('dpkg', True)

    # Test when package is not present
    module.params['name'] = 'nonexistent_package'
    module.params['selection'] = 'hold'
    rc, out, err = module.run_command([dpkg, '--get-selections', 'nonexistent_package'], check_rc=True)
    assert not out
    assert not change, 'Selections should not have changed'

    # Test when there is a change

# Generated at 2022-06-11 07:01:18.837895
# Unit test for function main
def test_main():
    pass

# Make the module executable.
if __name__ == "__main__":
    main()

# Generated at 2022-06-11 07:01:25.269751
# Unit test for function main
def test_main():
    # Example selection string from dpkg --get-selections
    package_info = ['python2.7 install']
    module = AnsibleModule(argument_spec=dict(name=dict(required=True),
                                              selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)))
    module.exit_json = mock_exit_json
    module.run_command = mock_run_command
    module.get_bin_path = mock_get_bin_path
    dpkg_selections.main()
    assert mock_exit_json.called
    assert not os.path.exists('/tmp/packagelist')


# Generated at 2022-06-11 07:01:35.473066
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:36.374734
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:01:46.858624
# Unit test for function main
def test_main():
    # DummyModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # From dpkg module
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split

# Generated at 2022-06-11 07:01:48.413060
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'

# Generated at 2022-06-11 07:01:58.165572
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/bin/dpkg' 
    test_module.run_command = lambda *args, **kwargs: ['test', '']
    
    return_value = main() 
    assert return_value['changed'] is True
    assert return_value['before'] == 'not present'

# Generated at 2022-06-11 07:02:07.500048
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = m.get_bin_path('dpkg', True)
    name = m.params['name']
    selection = m.params['selection']
    rc, out, err = m.run_command([dpkg, '--get-selections', name], check_rc=True)

    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:02:16.587439
# Unit test for function main
def test_main():
    with open('tests/test_data_dpkg_selections/test_data', 'r') as test_data:
        test_data_contents = test_data.read()
    module = MockModule({'name': 'python-apt', 'selection': 'hold'})
    module.run_command.return_value = 0, test_data_contents, ''
    main()
    module.run_command.assert_called_with(['dpkg', '--set-selections'], data="python-apt hold", check_rc=True)
    module.exit_json.assert_called_with(changed=True, before='deinstall', after='hold')

# Generated at 2022-06-11 07:02:33.167255
# Unit test for function main
def test_main():

    # Name not present in selections
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = "python"
    module.params['selection'] = "deinstall"
    assert main() == {"changed": True, "after": "deinstall", "before": "not present"}

    # Name is present in selections and selection matches

# Generated at 2022-06-11 07:02:43.854523
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:02:49.559763
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.dpkg_selections import main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.get_bin_path = lambda x,y: x
    module.run_command = lambda x, **kwargs: (0, '{0} install'.format(module.params['name']), None)
    main()

# Generated at 2022-06-11 07:02:58.696735
# Unit test for function main
def test_main():
    # Mock data

    dpkg = '/usr/bin/dpkg'
    name = 'python'
    selection = 'hold'

    rc = 0
    out = name + '\t' + selection + '\n'
    err = ''

    current = selection
    changed = False

    class Module():
        def __init__(self, argument_spec=dict(name=dict(required=True), selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)), supports_check_mode=True):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {}
            self.params['name'] = name
            self.params['selection'] = selection


# Generated at 2022-06-11 07:03:09.175446
# Unit test for function main
def test_main():
    import sys
    import inspect
    import subprocess
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from io import StringIO

    # Ansible 2.8 imports
    TREE = {}

    # Ansible 2.9+ imports
    from ansible.utils.collection_loader import AnsibleCollectionRef

    def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        cmd = subprocess.Popen(args, stdout=subprocess.PIPE)
        output = cmd.communicate()[0]

# Generated at 2022-06-11 07:03:15.558626
# Unit test for function main
def test_main():
  import subprocess
  from ansible.module_utils.basic import AnsibleModule
  from ansible.module_utils.six import b
  import ansible.constants as C
  import json, os
  import pytest
  from .mock_module import MockModule

  # Mock out AnsibleModule
  mock_module = MockModule()
  mock_module.cleanup()

  # Mock out the ansible module API
  action_value = {
    "name": "test_package_name",
    "selection": "test_package_selection",
  }
  module_args = {
    'name': "test_package_name",
    'selection': "test_package_selection",
  }
  mock_module.run_command = Mock(return_value=None)

# Generated at 2022-06-11 07:03:24.419680
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = dict(name='python', selection='hold')

    module.run_command = MagicMock(return_value=(0, 'python hold', ''))
    main()
    assert module.run_command.call_args[0][0][3] == 'python'

    module.run_command = MagicMock(return_value=(0, 'python install', ''))
    main()
    assert module.run_command.call_args[0][1]['data'].startswith('python hold')

    module.run_command

# Generated at 2022-06-11 07:03:32.552440
# Unit test for function main
def test_main():
    # Run dpkg_selections when python is not held
    get_selections_output = "python2.7 install"
    set_selections_output = ""
    mock_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    mock_module.run_command.side_effect = [(0, get_selections_output, ""), (0, set_selections_output, ""), ]
    mock_module.get_bin_path.side_effect = ["/usr/bin/dpkg", "/usr/bin/dpkg" ]

# Generated at 2022-06-11 07:03:40.467758
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import common_koji
    from mock import patch,Mock
    import imp

    module_path = 'library/dpkg_selections.py'
    module_args = dict(
        name='python',
        selection='hold'
    )

    class DummyModule(object):
        def __init__(self,path,args):
            self.path=path
            self.args=args

    with patch("ansible.module_utils.basic.AnsibleModule") as am:
        am.side_effect = DummyModule
        module=imp.load_source("dpkg_selections",module_path)

        dpkg = module.main()

        assert dpkg.path==module_path
        assert dpkg.args==module

# Generated at 2022-06-11 07:03:46.170604
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:04:25.796979
# Unit test for function main

# Generated at 2022-06-11 07:04:33.169413
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:04:41.470018
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            selection=dict(required=True, choices=['install', 'hold', 'deinstall', 'purge'], type='str')
        ),
        supports_check_mode=True,
    )

    # Test the dpkg module with the following input:
    #
    # name: python
    # selection: hold
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'

    # Set up mock dpkg command execution
    rc, out, err = module.run_command([], check_rc=True)

    assert rc == 1
    assert out == ''
    assert err == ''


# Generated at 2022-06-11 07:04:43.862070
# Unit test for function main
def test_main():
    return_values = {'diff_mode': False, 'check_mode': False}

    out = main()
    assert out['changed'] == return_values['changed']

# Generated at 2022-06-11 07:04:52.786122
# Unit test for function main
def test_main():
    current = """mysql-server-5.7	install
mysql-server	install
"""
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

# Generated at 2022-06-11 07:05:00.321998
# Unit test for function main
def test_main():
    rc, out, err = module.run_command.cmd([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_json(changed=changed, before=current, after=selection)

    module.run_command.cmd([dpkg, '--set-selections'], data="%s %s" % (name, selection), check_rc=True)
    module.exit_json(changed=changed, before=current, after=selection)

# Generated at 2022-06-11 07:05:11.550594
# Unit test for function main
def test_main():
    module = AnsibleModule({'name': {'required': True}, 'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}}, supports_check_mode=True)
    # Full diff
    module.params['diff_mode'] = 'diff'
    rc, out, err = module.run_command('echo foo')
    assert rc == 0
    assert err == ''
    assert out == 'foo\n'
    # Skip diff
    module.params['diff_mode'] = 'skip'
    rc, out, err = module.run_command('echo foo')
    assert rc == 0
    assert err == ''
    assert out == 'foo\n'
    # Replace diff
    module.params['diff_mode'] = 'replace'
    rc, out, err = module.run

# Generated at 2022-06-11 07:05:19.088746
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )
    dpkg = os.path.join(tempdir, 'dpkg')

    # Setup fake dpkg
    selection_path = os.path.join(tempdir, 'selections')
    os.mkdir(dpkg)
    with open(os.path.join(dpkg, 'dpkg'), 'w') as dpkg_file:
        dpkg_file.write('#!/bin/sh\n')

# Generated at 2022-06-11 07:05:30.706779
# Unit test for function main
def test_main():
    # Setup
    name = 'python'
    selection = 'hold'

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Create mocked out object for module.run_command
    class RunCommand:
        def __init__(self, argv, check_rc):
            pass

    module.run_command = RunCommand

    # Create mocked out object for module.exit_json
    class ExitJson:
        def __init__(self, changed, before, after):
            self.changed = changed

# Generated at 2022-06-11 07:05:43.579393
# Unit test for function main
def test_main():
    # import module and mocks
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    import ansible.module_utils.system.dpkg_selections
    import ansible.module_utils.common.process
    import ansible.module_utils.system.dpkg_selections
    import os

    # Define mocks
    ansible.module_utils.system.dpkg_selections.get_bin_path = lambda x,y: 'dpkg'
    ansible.module_utils.common.process.run_command = lambda x,y,z: (0,'','out','','')

    with open(os.path.join(os.path.dirname(__file__), 'testfile'), 'w') as f:
        f

# Generated at 2022-06-11 07:06:37.094359
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.params['selection'] = 'install'
    module.params['name'] = 'test2'

    test_main()

# Generated at 2022-06-11 07:06:45.080097
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.modules.dpkg_selections import main
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {'name': 'python', 'selection': 'hold'}
    rc = main()
    assert rc['changed'] == False
    assert rc['before'] == 'not present'
    assert rc['after'] == 'hold'

# Generated at 2022-06-11 07:06:46.219156
# Unit test for function main
def test_main():
    import sys
    sys.path.append('~')
    main()

# Generated at 2022-06-11 07:06:54.066567
# Unit test for function main
def test_main():
    from ansible.module_utils.common.exec_command import exec_command
    exec_command.get_bin_path = lambda x, y: 'testdpkg'

    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {}

        def check_mode(self):
            return self.supports_check_mode

        def exit_json(self, changed=False, before=None, after=None, rc=0, err=None, out=None):
            print('changed: %s' % changed)
            print('before: %s' % before)
            print('after: %s' % after)


# Generated at 2022-06-11 07:07:01.990180
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:07:02.426525
# Unit test for function main
def test_main():
    assert main() == True

# Generated at 2022-06-11 07:07:10.354353
# Unit test for function main
def test_main():
    # Setup the test context and determine the test result
    # Using a fixture,https://docs.pytest.org/en/latest/fixture.html
    # a fixed state which is executed prior to tests being run
    # returns a tuple of three mock objects that can be used
    # in test assertions
    # https://www.toptal.com/python/an-introduction-to-mocking-in-python
    module, dpkg, module_return_value = setup_main_test(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
        name='python',
        selection='hold')

# Generated at 2022-06-11 07:07:17.488893
# Unit test for function main
def test_main():
    import inspect
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.skeleton_arguments import SkeletonArgumentSpec
    from ansible.module_utils.skeleton_options import SkeletonOptions
    from ansible.module_utils.skeleton_common import SkeletonCommon

    tmpdir = os.path.dirname(__file__) or '.'
    sys.path.append(tmpdir)
    sys.path.append(os.path.join(tmpdir, '..'))

    f, filename, descr = imp.find_module('dpkg_selections')
    dpkg_selections = imp.load_module('dpkg_selections', f, filename, descr)
    f, filename, descr = imp

# Generated at 2022-06-11 07:07:25.693126
# Unit test for function main
def test_main():
    import os
    import platform
    import subprocess
    import sys
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    def runModule(name, selection, current, expected_rc, expected_changed, expected_before, expected_after, **kwargs):
        test_subprocess_env = os.environ.copy()
        test_subprocess_env.update(dict(
            ANSIBLE_MODULE_ARGS=[
                'name=%s' % name,
                'selection=%s' % selection,
            ],
            ANSIBLE_MODULE_SILENT=True,
            ANSIBLE_MODULE_REQUIRE_ARGS=True,
        ))
        test_subprocess_env.update(kwargs)

# Generated at 2022-06-11 07:07:30.898950
# Unit test for function main
def test_main():
    test = {}
    test['run_command'] = [
        ('dpkg --get-selections python', True, ('', 'python	install\n', '')),
        ('dpkg --set-selections', True, ('', '', ''))
    ]
    test['exit_json'] = {
        'changed': True,
        'before': 'install',
        'after': 'hold',
    }
    main(test)

# Generated at 2022-06-11 07:09:44.891036
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:09:45.805799
# Unit test for function main
def test_main():
    assert(2 + 3 == 5)

# Generated at 2022-06-11 07:09:54.331709
# Unit test for function main
def test_main():
    # Mock the module
    module = MagicMock()
    module.params = {
        'name': 'ctags',
        'selection': 'hold'
    }
    module.check_mode = False
    module.exit_json = MagicMock()

    # Mock the output of `dpkg --get-selections ctags`
    rc, out, err = 0, "ctags\tinstall", ""

    # Mock the output of `dpkg --get-selections ctags`
    module.run_command = MagicMock(return_value=(rc, out, err))

    # This is the module running the mocked module
    main()

    # Asserts
    assert out == "ctags\tinstall"