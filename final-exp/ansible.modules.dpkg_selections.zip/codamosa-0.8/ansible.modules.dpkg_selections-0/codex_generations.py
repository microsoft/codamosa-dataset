

# Generated at 2022-06-11 07:00:03.364600
# Unit test for function main
def test_main():
    # Define main function
    main()

# Generated at 2022-06-11 07:00:12.291223
# Unit test for function main
def test_main():
    def get_bin_path_mock(path, *args, **kwargs):
        return path
    def run_command_mock(self, command, check_rc=False, data=None, executable=None, use_unsafe_shell=False, *args, **kwargs):
        if command[0] == 'dpkg' and 'get-selections' in command:
            return 0, 'python\tinstall\n', ''
        if command[0] == 'dpkg' and 'set-selections' in command:
            assert 'python hold' == data
            return 0, '', ''
    test = AnsibleModule({
        'name': 'python',
        'selection': 'hold'
    }, check_mode=True)
    import __builtin__
    __builtin__.get_bin_path = get_bin

# Generated at 2022-06-11 07:00:20.473443
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    test_module.params['name'] = 'python'
    test_module.params['selection'] = 'hold'
    test_module.params['check_mode'] = True
    test_module.params['dif_mode'] = False
    test_module.params['platform'] = 'debian'
    test_module.check_mode = True
    test_module.run_command = Mock(return_value=(0,'python hold','error'))
    test_module.get_bin_path = Mock(return_value=True)

# Generated at 2022-06-11 07:00:29.433663
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:38.334036
# Unit test for function main
def test_main():
    name = "python"
    selection = "hold"
    current = "install"
    changed = True

    module_mock = MagicMock()
    module_mock.params = {"name" : name, "selection" : selection, "changed" : changed}

    dpkg_mock = MagicMock()
    dpkg_mock.return_value=True
    module_mock.get_bin_path.return_value = dpkg_mock

    rc_mock = MagicMock()
    rc_mock.return_value=True

    out_mock = MagicMock()
    out_mock.split.return_value = []
    out_mock.return_value = False

    run_mock = MagicMock()
    run_mock.return_value=True
    run_mock

# Generated at 2022-06-11 07:00:46.645411
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    class MockOS(object):
        def __init__(self, *args):
            pass

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.check_mode = True
            self.params = {'name': 'python', 'selection': 'hold'}

        def get_bin_path(self, name, required=False):
            return '/usr/bin/dpkg'


# Generated at 2022-06-11 07:00:54.789664
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:59.029037
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    name = 'install'
    selection = 'install'

    assert main(m) == (changed, before, after)

# Generated at 2022-06-11 07:01:05.997786
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Get current settings.
    module.run_command([dpkg, '--set-selections'], data="%s %s" % (name, 'purge'), check_rc=True)
    (rc, out, err) = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    current = out.split()[1]

# Generated at 2022-06-11 07:01:14.361378
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:01:33.132103
# Unit test for function main
def test_main():
    import os
    import json
    import unittest
    import unittest.mock as mock
    os.environ['LANG'] = 'C'
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as am:
        with mock.patch('ansible.module_utils.basic.get_bin_path') as bp:
            main()

# Generated at 2022-06-11 07:01:37.349428
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'foo': dict(required=False)}, supports_check_mode=True)
    assert main() is None


# Generated at 2022-06-11 07:01:47.572235
# Unit test for function main
def test_main():
    from contextlib import contextmanager
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes, to_text

    @contextmanager
    def mock_open_fixture(content, encoding='utf-8'):
        m_open = mock_open(read_data=to_bytes(content, encoding=encoding))
        m_open.return_value.encoding = encoding
        with patch.object(builtins, 'open', m_open):
            yield

    with mock_open_fixture('python hold\n') as m_open:
        main()
        assert m_open.call_count == 1

# Generated at 2022-06-11 07:01:49.340541
# Unit test for function main
def test_main():
    print("Test main()")
    if __name__ == '__main__':
        main()

# Generated at 2022-06-11 07:01:49.915885
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 07:01:56.019714
# Unit test for function main
def test_main():
    # Check is module is idempotent
    check_mode = True
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]
    current = 'hold'
    assert current == selection

# Generated at 2022-06-11 07:02:05.989808
# Unit test for function main
def test_main():

    # create module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # make fake failed command
    def fake_run_command(cmd, check_rc=False):
        class Rc(object):
            def __init__(self):
                self.rc = 0
                self.stdout = 'python state\n'
                self.stderr = 'stderr'
        return Rc(), None, None

    module.run_command = fake_run_command

    # set fake module args

# Generated at 2022-06-11 07:02:06.906721
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:02:11.182057
# Unit test for function main
def test_main():
    assert main(name='foo', selection='bar') == \
            {'changed': True, 'before': 'no', 'after': 'bar'}
    assert main(name='foo', selection='bar') == \
            {'changed': False, 'before': 'bar', 'after': 'bar'}

# Generated at 2022-06-11 07:02:22.356914
# Unit test for function main
def test_main():
    selection = 'install'
    name = 'python'
    module = MagicMock()
    module.params = {'name': name, 'selection': selection, 'check_mode': False, 'diff_mode': False}
    module.run_command = MagicMock(return_value=(0, 'python install', ''))
    module.run_command = MagicMock(return_value=(0, None, ''))
    module.check_mode = False
    module.get_bin_path = MagicMock(return_value='/usr/bin/dpkg')
    main()

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out

# Generated at 2022-06-11 07:02:43.069405
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

# Generated at 2022-06-11 07:02:49.318800
# Unit test for function main
def test_main():
    # Test with a valid selection
    name = 'python'
    selection = 'hold'
    rc, out, err = main(name, selection)
    assert rc is True
    assert out is True
    assert err is False

    # Test an invalid selection that should not change anything
    name = 'ansible'
    selection = 'present'
    rc, out, err = main(name, selection)
    assert rc is False
    assert out is False

    # Test with a missing required argument
    name = None
    selection = 'hold'
    rc, out, err = main(name, selection)
    assert rc is False
    assert out is None


# Generated at 2022-06-11 07:02:58.505919
# Unit test for function main
def test_main():
    import sys
    import hashlib
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text

    class AnsibleExitJson(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class AnsibleFailJson(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(*args, **kwargs):
            raise AnsibleFailJson(args, kwargs)


# Generated at 2022-06-11 07:03:08.969461
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:03:09.829294
# Unit test for function main
def test_main():
    #Unit test should go here
    assert main

# Generated at 2022-06-11 07:03:11.930998
# Unit test for function main

# Generated at 2022-06-11 07:03:20.160992
# Unit test for function main
def test_main():
    try:
        from ansible.modules.system.dpkg_selections import main
    except:
        main = __import__('ansible.modules.system.dpkg_selections').dpkg_selections.main

    # import pdb
    # pdb.set_trace()

    rc, out, err = main(['', '--name', 'python', '--selection', 'hold'])
    assert rc == 0
    assert out['changed']
    assert out['before'] == 'not present'
    assert out['after'] == 'hold'

    # test changed=False
    rc, out, err = main(['', '--name', 'python', '--selection', 'hold'])
    assert rc == 0
    assert not out['changed']
    assert out['before'] == 'hold'

# Generated at 2022-06-11 07:03:28.984455
# Unit test for function main
def test_main():

    # Args
    data = {
        'name': 'python',
        'selection': 'hold'
    }

    module = AnsibleModule(argument_spec={
        'name': {'required': True},
        'selection': {'choices': ['install', 'hold', 'deinstall', 'purge'], 'required': True}
    })

    module.params = data

    # AnsibleModule.run_command
    class AnsibleModuleMock(object):
        def run_command(self, command, check_rc=False):
            return (
                0,
                '%s	hold\n' % data['name'],
                ''
            )
    module.run_command = AnsibleModuleMock().run_command

    # AnsibleModule.exit_json

# Generated at 2022-06-11 07:03:29.559794
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:03:37.465593
# Unit test for function main
def test_main():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params = {
        'name': 'python',
        'selection': 'hold'
    }

    # Unit tests
    # Check changing state does something.
    current = 'install'
    assert module.params['selection'] != current
    assert main.__code__.co_varnames == (
        'dpkg', 'module', 'name', 'selection', 'rc', 'out', 'err', 'changed', 'current'
    )
    assert main()['changed']

    # Check changing to the same state does nothing

# Generated at 2022-06-11 07:04:16.910204
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'install'
    expected_result = ('python', 'install')
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    # run the function
    result = main(module, name, selection)
    assert result == expected_result

# Generated at 2022-06-11 07:04:25.211424
# Unit test for function main
def test_main():
    # Creating a mock module object
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Getting a fixture value for dpkg.
    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    # Calling main function
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:04:32.850952
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:04:41.787748
# Unit test for function main
def test_main():
    dpkg_selections = """mock
    mock -v
    mock -s < /data/ansible/packages.lst
    mock --get-selections
    mock --set-selections < /data/ansible/packages.lst
    """

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    #rc, out, err = module.run_command([dpkg, '--get-select

# Generated at 2022-06-11 07:04:43.224212
# Unit test for function main
def test_main():
    # Check for successful return
    assert main() is None


# Generated at 2022-06-11 07:04:45.352927
# Unit test for function main
def test_main():
    params = {"name": "python", "selection": "hold"}
    assert main() == module.exit_json(changed=True, before='purge', after='hold')

# Generated at 2022-06-11 07:04:54.341452
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    import mock
    import shlex
    import subprocess
    import sys

    # Set up test parameters
    args = dict(
        name='python-dnspython',
        selection='install',
        check_mode=True,
    )
    dpkg = get_bin_path('dpkg', True)

    def run_command(cmd, data=None, check_rc=False):
        assert cmd == shlex.split(dpkg + ' --get-selections python-dnspython')
        return (0, 'python-dnspython install\n', None)

    # Create Mock modules
    m_process = mock.MagicMock()
    m_process.run_command = run_command
    m

# Generated at 2022-06-11 07:05:03.809977
# Unit test for function main
def test_main():
    import sys
    import os
    try:
        import ansible.module_utils.basic as basic
    except Exception:
        print("FAILED: to import ansible.module_utils.basic")
        print("Expected @ '%s/libs'" % os.path.dirname(__file__))
        sys.exit(1)

    # Setup for basic unit test
    dpkg_bash_config = "[[ -z \"$DPKG_FRONTEND\" ]] && declare -g -r DPKG_FRONTEND=\"dpkg\""


# Generated at 2022-06-11 07:05:14.345355
# Unit test for function main
def test_main():
    import sys
    import json
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    name=dict(required=True),
                    selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
                ),
                supports_check_mode=True,
            )
            self.module.params['check_mode'] = True
            self.module.params['action_common_attributes'] = {}
            self

# Generated at 2022-06-11 07:05:24.980869
# Unit test for function main
def test_main():
    from ansible.modules.system.dpkg_selections import main

    # Stub an ansible module
    my_ansible_module = MockModule({})

    # Set expected command and run module
    dpkg = "/usr/bin/dpkg"
    my_ansible_module.run_command = Mock(return_value=(0, "my_package hold", ""))
    my_ansible_module.get_bin_path = Mock(return_value=dpkg)
    my_ansible_module.params = {"state": "present", "name": "my_package", "selection": "hold"}
    main()

    # Check that the expected arguments have been called
    assert my_ansible_module.get_bin_path.call_args[0] == ('dpkg', True)
    assert my_ansible_module.run_

# Generated at 2022-06-11 07:06:21.953639
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:06:31.429844
# Unit test for function main
def test_main():
    test_main.__name__ = 'test_dpkg_selections.py'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'python'
    module.params['selection'] = 'holding'
    dpkg = module.get_bin_path('dpkg', True)
    rc, out, err = module.run_command([dpkg, '--get-selections', module.params['name']], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

# Generated at 2022-06-11 07:06:38.579581
# Unit test for function main
def test_main():
   with mock.patch('ansible.module_utils.basic.AnsibleModule') as mock_am:
      with mock.patch('ansible.module_utils.basic.run_command') as mock_run_command:
         mock_am.params = {'name': 'testpkg', 'selection': 'hold'}
         mock_am.check_mode = False
         mock_am.run_command.return_value = [0, "testpkg hold", ""]
         main()
         mock_am.run_command.assert_called_with([mock_am.get_bin_path('dpkg', True), "--set-selections"], data="testpkg hold", check_rc=True)

# Generated at 2022-06-11 07:06:48.101115
# Unit test for function main
def test_main():
    test_cases = {
        # testCase 1: Test basic module functionality
        "1": {
            "name": "git",
            "selection": "install",
            "changed": True,
            "before": "deinstall",
            "after": "install",
        },
        # testCase 2: Test unchanged
        "2": {
            "name": "git",
            "selection": "deinstall",
            "changed": False,
            "before": "deinstall",
            "after": "deinstall",
        },
    }

    for case in test_cases:
        module = AnsibleModule({
            "name": test_cases[case]["name"],
            "selection": test_cases[case]["selection"],
        })
        dpkg = "/usr/bin/dpkg"

# Generated at 2022-06-11 07:06:54.564926
# Unit test for function main
def test_main():
    tests = [
        # Format: testcase, arguments, expected result
        ['dummy', {'name': 'dummy', 'selection': 'hold'}, None]
    ]

    for x in tests:
        if x[0] == 'dummy':
            continue # TODO: dpkg --get-selections and --set-selections do not support 'dummy'

        m = AnsibleModule({
            'name': x[1]['name'],
            'selection': x[1]['selection']
        })

        try:
            result = main()
            assert result == x[2]
        except AssertionError:
            print('Should have raised an exception')
            raise AssertionError

# Generated at 2022-06-11 07:07:01.619866
# Unit test for function main
def test_main():
    # get the module used by Ansible
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Set the values of the arguments used by Ansible
    name = module.params['name']
    selection = module.params['selection']

    # If check mode, don't make any change to the current value
    if module.check_mode:
        changed = False
    else:
        changed = True

    module.exit_json(changed=changed, before='not present', after=selection)

# Generated at 2022-06-11 07:07:08.628774
# Unit test for function main
def test_main():
    mock = Mock()
    mock.settings = {'name': 'python', 'selection': 'hold'}
    mock_bin_path = mock.get_bin_path('dpkg', True)
    mock_run_command = mock.run_command([dpkg, '--get-selections', name], check_rc=True)
    main(mock)

    # First part of the function, get current state
    assert mock_bin_path.called
    assert mock_run_command.called
    # Second part, check the state and run command if needed
    combined = "python hold"
    assert mock_run_command([dpkg, '--set-selections'], data=combined, check_rc=True)

# Generated at 2022-06-11 07:07:09.672589
# Unit test for function main
def test_main():
    print('In test_main')
    main()

# Generated at 2022-06-11 07:07:16.860011
# Unit test for function main
def test_main():
    # Test logging info
    #logging.basicConfig(level=logging.INFO, format='%(message)s')
    #logging.info("Test INFO message")
    #logging.warning("Test WARNING message")
    #logging.error("Test ERROR message")
    #logging.debug("Test DEBUG message")

    # Test run main
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Test run function
    test_main()
    #logging.warning("Test run function")
    #logging.warning(test_module.params)

    # Test run class

# Generated at 2022-06-11 07:07:17.356487
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:09:41.293221
# Unit test for function main
def test_main():
    test_out = '''
dpkg-query: package 'python' is not installed and no information is available
Use dpkg --info (= dpkg-deb --info) to examine archive files,
and dpkg --contents (= dpkg-deb --contents) to list their contents.
/var/lib/dpkg/info/python:empty:unknown ok not-installed
'''
    test_out_new = '''
/var/lib/dpkg/info/python:empty:unknown ok hold
'''
    #
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:09:50.763721
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True),
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:09:52.758449
# Unit test for function main
def test_main():
    pname = 'python'
    pselection = 'hold'

    result = main(pname,pselection)

    assert "changed=True" in result