

# Generated at 2022-06-11 06:59:58.871865
# Unit test for function main
def test_main():
  pass

# Generated at 2022-06-11 07:00:04.183043
# Unit test for function main
def test_main():
    # Set up mocks

    # Set up module arguments
    module_args = dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    )

    # Set up return values
    rc = 0
    out = 'python hold'
    err = ""

    # Set up AnsibleModule object
    module = AnsibleModule(
        argument_spec=module_args
    )

    # Call main()
    out, err = main()

# Generated at 2022-06-11 07:00:13.002856
# Unit test for function main
def test_main():
    # Parameters
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:00:20.885470
# Unit test for function main
def test_main():
    test_args = {
        'name': 'apt',
        'selection': 'install',
        'params': {'path': 'fake bin path'},
    }

    with mock.patch('ansible_collections.ansible.community.plugins.modules.dpkg_selections.AnsibleModule') as mockAnsibleModule:
        with mock.patch('ansible_collections.ansible.community.plugins.modules.dpkg_selections.main') as mockMain:
            mockAnsibleModule.return_value = mock.Mock()
            mockMain.return_value = 0
            dpkg_selections = import_module("ansible_collections.ansible.community.plugins.modules.dpkg_selections")
            dpkg_selections.main()

# Generated at 2022-06-11 07:00:27.939347
# Unit test for function main
def test_main():
    mock = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )

    mock.run_command = MagicMock()
    mock.run_command.return_value = (0, 'python install', '')

    with patch.dict('sys.modules', {'ansible.module_utils.basic': mock}):
        import dpkg_selections
        dpkg_selections.main()
        assert mock.run_command.call_count == 2

# Generated at 2022-06-11 07:00:34.829994
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, "test-package install", ""))
    module.get_bin_path = MagicMock(return_value="")
    dpkg_selections.main()


# Generated at 2022-06-11 07:00:42.650801
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    my_module = dpkg_selections.MyModule()

    test_module.run_command = mock.Mock(return_value=(0, 'dpkg 1.19.0.5ubuntu2.1', ''))
    actual = test_module.run_command('dpkg', '--get-selections', 'ansible')
    assert actual.stdout == 'dpkg 1.19.0.5ubuntu2.1'

# Generated at 2022-06-11 07:00:51.075865
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:57.600627
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_remote_management import action_common_attributes
    from ansible.module_utils.ansible_remote_management import AnsibleModule
    action_common_attributes._DEFAULT_PLATFORMS = ['debian']
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    from ansible.module_utils.basic import AnsibleModule_get_bin_path
    module.get_bin_path = AnsibleModule_get_bin_path
    import pwd
    from subprocess import check_output, call
    from unittest.mock import call as mock_call
    import os
   

# Generated at 2022-06-11 07:00:58.123925
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:01:06.193170
# Unit test for function main
def test_main():
    try:
        main()
    except:
        print("main function test failed")
        return 1
    return 0

test_main()

# Generated at 2022-06-11 07:01:14.565903
# Unit test for function main
def test_main():
    import sys
    import platform

    if (platform.system() != 'Darwin') and (sys.version_info < (2, 7)):
        import unittest2 as unittest
    else:
        import unittest
    import os
    import shutil
    import tempfile
    import json

    # Unit test for function main
    class TestMain(unittest.TestCase):
       def setUp(self):
           self.tmp_data = tempfile.mkdtemp()
           self.fixtures = os.path.join(os.path.dirname(__file__), 'fixtures')

       def tearDown(self):
           shutil.rmtree(self.tmp_data)

       def test_main_absent_hold(self):
   
           out = 'test1  not present'
           in_

# Generated at 2022-06-11 07:01:17.242318
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    assert(main())



# Generated at 2022-06-11 07:01:19.990789
# Unit test for function main
def test_main():

    try:
        from ansible.modules.system.package.dpkg_selections import main
    except:
        return False

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    return True

# Generated at 2022-06-11 07:01:23.257331
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:01:32.277122
# Unit test for function main
def test_main():
    # This is how you would normally import module_utils
    from ansible.module_utils import action_plugin

    # This is how you would normally import module_utils
    module = action_plugin.get_action_class('dpkg_selections')(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    # Needs to set in_check_mode to True and then call check_mode().
    module.in_check_mode = True; module.check_mode()

    # This is how you would normally import module_utils
    from ansible.module_utils.basic import AnsibleModule

    # If we get here, the module supports check

# Generated at 2022-06-11 07:01:43.567464
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit_

# Generated at 2022-06-11 07:01:44.155344
# Unit test for function main
def test_main():
    assert 1 == 1


# Generated at 2022-06-11 07:01:52.021055
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:02:03.429303
# Unit test for function main
def test_main():
    # Successful run
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out

# Generated at 2022-06-11 07:02:14.157380
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:02:24.519224
# Unit test for function main
def test_main():
    dpkg_selection = find_executable('dpkg')
    dpkg_selection_name = 'python'
    dpkg_selection_choice = 'hold'
    dpkg_selection_before = install
    dpkg_selection_after = hold

    def test_dpkg_selection_get_selections(self):
        if dpkg_selection:        
            if not out:
                current = 'not present'
            else:
                current = out.split()[1]


# Generated at 2022-06-11 07:02:34.444904
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )

    # Get current settings.
    rc, out, err = module.run_command('dpkg --get-selections python', check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != module.params['selection']
    module.exit_json(changed=changed, before=current, after=module.params['selection'])



# Generated at 2022-06-11 07:02:45.099133
# Unit test for function main
def test_main():
    args = {
        "name": "vim",
        "selection": "hold",
        "check_mode": "yes",
        "log_diffs": "no",
        "no_log": "no",
        "remote_user": "root",
        "_ansible_diff": "no",
        "_ansible_module_name": "dpkg_selections",
        "_ansible_remote_tmp": "/tmp/tmpTkzgVt",
        "_ansible_verbosity": "0",
        "changed": "True",
        "module_name": "dpkg_selections",
    }

    res = main(args)

# Generated at 2022-06-11 07:02:45.654297
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:02:50.009152
# Unit test for function main
def test_main():
    import os
    import sys
    from ansible.module_utils.basic import AnsibleModule
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from dpkg_selections import main
    module = AnsibleModule({'name': '', 'selection': ''})
    main()

# Generated at 2022-06-11 07:02:59.105117
# Unit test for function main
def test_main():
    import sys
    from mock import Mock
    from mock import patch

    MODULE_PATH = 'ansible.modules.system.dpkg_selections'

    def mock_command(cmd, raise_err=False, data=None):
        if cmd[-2:] == ['--get-selections', 'python']:
            return (0, 'python install', '')

        if cmd[-1] == '--help':
            return (0, '', '')

        if cmd[-2:] == ['--set-selections', 'python hold']:
            return (0, '', '')

        if raise_err:
            raise OSError()

    def mock_get_bin_path(name, *args):
        return '/usr/bin/dpkg'


# Generated at 2022-06-11 07:03:09.504959
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = 'apache2'
    selection = 'hold'

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    print('Changed: ', changed)
    print('Current: ', current)

# Generated at 2022-06-11 07:03:11.136209
# Unit test for function main
def test_main():
    response = main()

    assert response == '''- name: Prevent python from being upgraded
  dpkg_selections:
    name: python
    selection: hold'''

# Generated at 2022-06-11 07:03:19.285250
# Unit test for function main
def test_main():
    # Mock for function get_bin_path, return_value=None
    def mock_get_bin_path(name, *args, **kwargs):
        return None

    # Mock for function module_utils.basic.AnsibleModule, return_value=AnsibleModule instance
    class MockAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {
                'name': 'python',
                'selection': 'hold'
            }
            self.check_mode = True
            self.extra_arguments = None
            self.extra_arguments_key = 'command'
            self._debug = False
            self.failed = False
            self.changed = False

        def get_bin_path(self, name, *args, **kwargs):
            return mock_get

# Generated at 2022-06-11 07:03:56.129365
# Unit test for function main
def test_main():
    import tempfile
    # Setup fake input and output files
    (temp_stdin, temp_stdin_name) = tempfile.mkstemp()
    (temp_stdout, temp_stdout_name) = tempfile.mkstemp()
    (temp_stderr, temp_stderr_name) = tempfile.mkstemp()
    # Setup a "returncode"
    rc = 0
    # Setup a "failed" test
    failed = False
    # Setup a "changed" status
    changed = False
    # Setup fake input and output data
    input_data = 'python\n'
    output_data = 'python hold\n'
    # Setup fake AnsibleModule object
    # Setup required module arguments
    params = {
        'name': 'python',
        'selection': 'hold'
    }


# Generated at 2022-06-11 07:04:04.168929
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:04:14.670163
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, 'python\tinstall', ''))
    module.check_mode = False
    module.get_bin_path = MagicMock(return_value='/usr/bin/dpkg')
    module.exit_json = MagicMock()

    # True case:
    module.params['name'] = 'python'
    module.params['selection'] = 'hold'
    main()
    assert module.run_command.call_count == 2

# Generated at 2022-06-11 07:04:18.622026
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:04:24.222415
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name']='python'
    module.params['selection'] = 'hold'
    rc, out, err = main()
    assert rc
    assert module.params['name'] == 'python'
    assert module.params['selection'] == 'hold'

# Generated at 2022-06-11 07:04:32.044563
# Unit test for function main
def test_main():
    # mock_module must be imported after module_utils/basic and before ansible.module_utils.debian.apt
    from ansible.module_utils._text import to_bytes
    from ansible.modules.packaging.os.dpkg_selections import main
    from ansible_collections.community.general.plugins.module_utils import debian
    import ansible.module_utils.debian.apt as apt
    mock_module = Mock()
    mock_module.params = {'name': 'python3', 'selection': 'hold'}
    mock_module.check_mode = False
    mock_module.run_command = Mock()
    mock_module.run_command.return_value = (0, to_bytes('python3 hold\n'), b'')
    mock_module.get_bin_path = Mock()
    mock_module

# Generated at 2022-06-11 07:04:32.535181
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:04:34.708740
# Unit test for function main

# Generated at 2022-06-11 07:04:35.374653
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:04:35.952972
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:05:25.318262
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        args = dict(
            name="python",
            selection="hold"
        )
        main(args)
    assert result.value.args[0]['changed']

    with pytest.raises(AnsibleExitJson) as result:
        args = dict(
            name="python",
            selection="hold"
        )
        main(args)
    assert result.value.args[0]['changed'] == False

# Generated at 2022-06-11 07:05:30.010514
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.main()

# Generated at 2022-06-11 07:05:42.087939
# Unit test for function main
def test_main():
    # initialize the test environment
    test_env = dict(
        module_path=os.path.dirname(os.path.abspath(__file__)),
        **base_test_env
    )

    #
    # Make sure the infrastructure is working
    #
    assert utils.run_module(test_env, 'ansible_test', 'ping', {'platform': 'posix'})['failed'] == False

    #
    # The test
    #
    assert utils.run_module(test_env, 'ansible_test', 'dpkg_selections',
                            {'platform': 'posix', 'name': 'python-minimal', 'selection': 'hold'})['failed'] == False

# Generated at 2022-06-11 07:05:50.895449
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = 'test'
    module.params['selection'] = 'hold'
    module.run_command = lambda args, check_rc=True, data=None: (0, '', '')

    # Test that the module updates the package
    assert main() == (True, 'not present', 'hold')

    # Test that it does not update the package
    module.params['selection'] = 'not present'
    assert main() == (False, 'not present', 'not present')

    # Test that it throws an error it d

# Generated at 2022-06-11 07:05:59.772337
# Unit test for function main
def test_main():
    def execute(dummy1, arguments, dummy2, **kwargs):
        if 'data' in kwargs:
            return 0, '', ''
        else:
            return 0, 'hello install', ''

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.run_command = execute
    module.get_bin_path = lambda a: '/bin/dpkg'
    main()
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['changed'] == True

# Generated at 2022-06-11 07:06:08.436974
# Unit test for function main
def test_main():
    testargs = [
        '-',
        '-',
        '{"changed": false, "invocation": {"module_args": {"selection": "hold", "name": "python"}}, "module_name": "dpkg_selections"}',
    ]

    with mock.patch.dict(os.environ, {'ANSIBLE_MODULE_ARGS': json.dumps(json.loads(testargs[2]))}):
        with ansible_module.AnsibleModule(argument_spec= {
            'name': dict(required=True),
            'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        }, supports_check_mode=True) as module:
            module.params = json.loads(testargs[2])
            res = main()
            print

# Generated at 2022-06-11 07:06:17.985865
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection
    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:06:27.367713
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = module.params['name']
    selection = module.params['selection']

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:06:29.269075
# Unit test for function main
def test_main():
    main()
    #main({'name': 'python', 'selection': 'hold'})

# Generated at 2022-06-11 07:06:33.213126
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    module.params['name'] = "python"
    module.params['selection'] = "not present"

# Generated at 2022-06-11 07:08:54.014077
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:09:02.389477
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule, env_fallback
    try:
        from ansible.modules.system.dpkg_selections import main
    except ImportError:
        main = sys.modules[__name__]

    dpkg = get_bin_path('dpkg', None)
    name = 'python'
    selection = 'hold'

    # Get current settings.
    rc, out, err = basic.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-11 07:09:11.748903
# Unit test for function main
def test_main():
    # Module must be launched under the right python version.
    # AnsibleModule.__init__ takes the path of the module
    # as the first argument.
    module = AnsibleModule('example', 'test')

    # dpkg module must be installed.
    # AnsibleModule.get_bin_path takes the name of the
    # command as the first argument.
    dpkg = module.get_bin_path('dpkg', True)

    name = ['python']
    selection = ['hold']

    # Simulate get_selections output.
    current = 'selections'

    changed = current != selection

    # Simulate module.params
    module.params = dict(
        name=name,
        selection=selection
    )


# Generated at 2022-06-11 07:09:12.286001
# Unit test for function main
def test_main():
    assert True is True

# Generated at 2022-06-11 07:09:20.919997
# Unit test for function main
def test_main():
    params = {
        'name': 'ansible',
        'selection': 'install',
    }

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-11 07:09:30.693538
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:09:31.527522
# Unit test for function main
def test_main():
    dpkg_selections = main()

# Generated at 2022-06-11 07:09:34.994703
# Unit test for function main
def test_main():
    import os

    fp = open('/tmp/ansible-tmp-1593312443.05-264118880776843/command', 'r')
    command = fp.read()
    assert command == 'dpkg --set-selections'


# Generated at 2022-06-11 07:09:37.177556
# Unit test for function main
def test_main():
    m = AnsibleModule({'name': 'python', 'selection': 'hold'}, check_mode=True)
    main()

# Generated at 2022-06-11 07:09:46.940819
# Unit test for function main
def test_main():
    # Getting exceptions on ansible-playbook side
    # AssertionError: Unexpected exit code 255 -
    # assert rc == 0, "%s failed in check mode: %s" % (dpkg, err)
    # AssertionError: 255 != 0 : /usr/bin/dpkg failed in check mode:
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        )
    )
    dpkg = module.get_bin_path('dpkg', True)
    name = 'python'
    selection = 'hold'
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
