

# Generated at 2022-06-11 07:00:12.087673
# Unit test for function main
def test_main():
    dpkg = "/usr/exists"

    # Test dpkg holds package python
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=False,
    )
    module.get_bin_path = mock.Mock(return_value=dpkg)
    module.run_command = mock.Mock(return_value=(0, "python install", ""))

    main()

    module.run_command.assert_called_with([dpkg, '--get-selections', "python"], check_rc=True)

# Generated at 2022-06-11 07:00:20.307397
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:29.241346
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:38.196126
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:00:46.279857
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    dpkg = module.get_bin_path('dpkg', True)

    name = 'python'
    selection = 'hold'

    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    #assert selection == selection
    assert name == current
    assert changed == True

# Generated at 2022-06-11 07:00:46.793485
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:00:54.917105
# Unit test for function main

# Generated at 2022-06-11 07:00:55.426266
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:01:01.278643
# Unit test for function main
def test_main():
    # This is a hacky way to learn what test we want to run.
    # Ansible's Test module doesn't support testing the "main" function.
    # So we need to look at the keyword arguments and call what we expect.
    # Unfortunately, this module has 4 possible "main" functions and no
    # shared functionality.
    #
    # An alternative approach would be to use Mock and patch module.run_command with a mocked version.
    os_args = ['ansible-test', 'units', '-v', '--color', 'dpkg_main']
    if 'check' in os_args:
        test_check()


# Generated at 2022-06-11 07:01:06.574471
# Unit test for function main
def test_main():
    test_module_name = 'dpkg_selections'
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module_name = 'ansible.builtin.%s' % test_module_name
    module = __import__(module_name, globals={}, locals={}, fromlist=['*'], level=-1)
    module = reload(module)
    module.main()

# Generated at 2022-06-11 07:01:19.630940
# Unit test for function main
def test_main():
    test = {
        'name': 'python',
        'selection': 'deinstall',
        'dpkg': '/usr/bin/dpkg',
        'check_mode': False,
        'changed': True,
        'before': 'install',
        'after': 'deinstall',
    }

    # Run the main function
    main()

    # Check the function returned the correct value
    assert test_main() == test

# Generated at 2022-06-11 07:01:26.748995
# Unit test for function main
def test_main():
    module = dict()
    module['params'] = dict()

    module['params']['name'] = 'python'
    module['params']['selection'] = 'purge'

    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = m.get_bin_path('dpkg', True)

    name = module['params']['name']
    selection = module['params']['selection']

    # Get current settings.
    rc, out, err = m.run_command([dpkg, '--get-selections', name], check_rc=True)

# Generated at 2022-06-11 07:01:27.438592
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:01:28.186556
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:01:38.983184
# Unit test for function main
def test_main():

    # Test 1: apt_key_module - make sure we can add a key. Check just the
    # differents between before and after
    module = AnsibleModule(argument_spec={'name': {'required': True}, 'selection': {'required': True, 'choices': ['install', 'hold', 'deinstall', 'purge']}}, supports_check_mode=True)
    module.get_bin_path = MagicMock(return_value='/bin/dpkg')
    module.run_command = MagicMock(return_value=(0, "python install", ""))
    module.check_mode = False
    module.params['name'] = 'python'
    module.params['selection'] = 'install'
    main()
    assert module.exit_json.called

# Generated at 2022-06-11 07:01:40.064588
# Unit test for function main
def test_main():
    # Successful run, nothing to assert on
    main()

# Generated at 2022-06-11 07:01:41.110786
# Unit test for function main
def test_main():
    # Implement main unit test here
    assert 1 == 1

# Generated at 2022-06-11 07:01:50.273828
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import contextlib

    module_name = 'dpkg_selections'
    module_path = __import__(module_name).__file__
    unit_test = __import__('unit.test_%s' % module_name.replace('_', '-'))
    test_lib = getattr(getattr(unit_test, 'test_%s' % module_name.replace('_', '-')), 'TestLib')

    with contextlib.nested(
            tempfile.NamedTemporaryFile(),
            tempfile.NamedTemporaryFile()) as (stdin, stdout):
        # run our module
        sys.argv = [__file__, '--name', 'test', '--selection', 'hold']
        # patch stdin and stdout so that it looks like a normal module

# Generated at 2022-06-11 07:02:01.958105
# Unit test for function main
def test_main():
    def fake_run_command(args, **kwargs):
        class FakeReturn(object):
            rc = 0
            stdout = "test fake return"
            stderr = ""
        if args == ['/usr/bin/dpkg', '--get-selections', 'python']:
            return FakeReturn()
        elif args == ['/usr/bin/dpkg', '--set-selections']:
            return FakeReturn()

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'name': 'python',
                'selection': 'hold'
            }

        def get_bin_path(self, binary, required=False):
            return '/usr/bin/dpkg'


# Generated at 2022-06-11 07:02:11.265050
# Unit test for function main
def test_main():
    mod_args = {
        'name': 'python',
        'selection': 'hold'
    }
    mod_rc = {}

    mod = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )
    mod.params = mod_args
    global dpkg
    dpkg = 'dpkg'
    global module
    module = mod

    from ansible.module_utils.basic import AnsibleModule
    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode=False):
            self.params = mod_args

# Generated at 2022-06-11 07:02:33.639015
# Unit test for function main
def test_main():

    # Test with a package that is already present.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True)

    name = 'python'
    selection = 'hold'

    result = dict(name=name, selection=selection)

    module.run_command = MagicMock(return_value=(0, 'python\thold\n', ''))
    module.exit_json = MagicMock(return_value=result)

    main()

    # Test with a package that is no present.

# Generated at 2022-06-11 07:02:44.449682
# Unit test for function main
def test_main():
  module = mock.Mock(spec=AnsibleModule)
  module.params = {'name': 'python', 'selection': 'hold'}
  main(module)
  assert module.run_command.call_args_list[0][0] == ([dpkg, '--get-selections', 'python'],)
  assert module.run_command.call_args_list[1][0] == ([dpkg, '--set-selections'],)
  assert module.exit_json.call_args_list == [{'changed': True, 'before': 'deinstall', 'after': 'hold'}]
  # Test when there are no changes.
  module.reset_mock()
  module.params = {'name': 'python', 'selection': 'hold'}
  main(module)
  assert module.exit_

# Generated at 2022-06-11 07:02:50.923954
# Unit test for function main
def test_main():

    # Test arguments
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Test module execution
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:03:00.288721
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )

    name = module.params['name']
    selection = module.params['selection']

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:03:02.722912
# Unit test for function main
def test_main():
    result = main()
    assert result['changed'] == True
    assert result['before'] == 'not present'
    assert result['after'] == 'install'

# Generated at 2022-06-11 07:03:03.596146
# Unit test for function main

# Generated at 2022-06-11 07:03:06.960254
# Unit test for function main
def test_main():
    lines = """

    """
    lines = [line.strip() for line in lines.splitlines() if line.strip()]
    assert main() == True, "Main function failed with %s" % lines

# Generated at 2022-06-11 07:03:13.566370
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            )
        )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


if __main__ == '__test__':
    test_main()

# Generated at 2022-06-11 07:03:14.661927
# Unit test for function main
def test_main():
    print("Test main function")
    assert 1

# Generated at 2022-06-11 07:03:15.239971
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:03:52.161464
# Unit test for function main
def test_main():
    #test 1
    response = main()
    assert response.get('changed') == False

# Generated at 2022-06-11 07:04:00.546244
# Unit test for function main
def test_main():
    def side_effect(module, *args, **kwargs):
        if args[0] == ['dpkg', '--get-selections', 'python']:
            return (0, 'python install\n', '')
        elif args[0] == ['dpkg', '--get-selections', 'uninstalled-package']:
            return (0, '', '')
        elif args[0] == ['dpkg', '--set-selections']:
            module.exit_json = lambda: True
            return (0, '', '')

    dpkg = lambda *args, **kwargs: True


# Generated at 2022-06-11 07:04:08.471439
# Unit test for function main

# Generated at 2022-06-11 07:04:09.106365
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:04:20.135014
# Unit test for function main
def test_main():
    dpkg_selections = MockedModule(main)
    dpkg_selections.params = {
        "name": 'python',
        "selection": 'hold'
    }

    current = 'install'
    selection = 'hold'

    dpkg_selections.run_command.side_effect = [
        (0, '', ''), # dpkg --get-selections python
        (0, '', '')  # dpkg --set-selections python hold
    ]

    dpkg_selections.main()

    assert not dpkg_selections.exit_json.called
    assert dpkg_selections.run_command.call_count == 2

    dpkg_selections.params = {
        "name": 'python',
        "selection": 'deinstall'
    }

    dpkg_selections.main()

# Generated at 2022-06-11 07:04:28.350507
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    import platform
    import os

    def run_command_mock(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        data_in = args
        return (0, name, '')


# Generated at 2022-06-11 07:04:31.644600
# Unit test for function main
def test_main():
    from ansible.module_utils.deb import main
    import os
    import subprocess
    assert os.path.exists('/usr/bin/dpkg') == True
    dpkgPath = '/usr/bin/dpkg'
    instTest = subprocess.Popen([dpkgPath, '--get-selections', 'test'], stdout = subprocess.PIPE)
    instTest.wait()
    assert instTest.returncode == 1
    assert main({'name': 'test', 'selection': 'install'})['changed'] == True
    rmTest = subprocess.Popen([dpkgPath, '--set-selections'], stdin = subprocess.PIPE)
    rmTest.wait()
    assert rmTest.returncode == 0
    assert main({'name': 'test', 'selection': 'remove'})

# Generated at 2022-06-11 07:04:40.529787
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)),
        supports_check_mode=True,
        module=True,
    )
    # Assume that a package has not been previously selected
    # Assume that the package selection does not change
    # Assume that the module does not support check mode
    dpkg = module.get_bin_path('dpkg', True)
    module.run_command([dpkg, '--get-selections', 'name'], check_rc=True)
    out = "not present"
    selection = "install"
    if not out:
        current = 'not present'

# Generated at 2022-06-11 07:04:41.708703
# Unit test for function main
def test_main():
    assert main(['python', 'python', 'install']) == 0

# Generated at 2022-06-11 07:04:47.633860
# Unit test for function main
def test_main():
    args = {
        'selection': 'install',
        'name': 'python',
        '_ansible_check_mode': True
    }
    module = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'selection': dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    })
    module.exit_json = mock.Mock()
    main()
    assert module.exit_json.called, 'Expected to call exit_json'


# Generated at 2022-06-11 07:05:43.468662
# Unit test for function main
def test_main():
    dpkg_selections_path = os.path.join(os.path.dirname(__file__), 'dpkg_selections.py')
    dpkg_path = os.path.join(os.path.dirname(__file__), 'dpkg')
    shutil.copy(dpkg_path, '/usr/bin/dpkg')
    module_args = {}
    module_args.update(name='python')
    module_args.update(selection='hold')
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    rc, out, err = module.run_command([module.get_bin_path('dpkg', True), '--get-selections', 'python'], check_rc=True)
    if not out:
        current = 'not present'

# Generated at 2022-06-11 07:05:51.786385
# Unit test for function main
def test_main():
    # Adding several more packages to test more lines in
    # the output.
    import ansible.module_dpkg_selections
    import ansible.module_utils.basic
    PACKAGES = [
        ('python', 'install'),
        ('python3', 'hold'),
        ('python3-minimal', 'deinstall'),
        ('python3.4', 'purge'),
        ('python2.7', 'purge')]
    DNE = 'dpkg-test-fake-package'
    with ansible.module_utils.basic.tmpdir() as tmpdir:
        mock_module = ansible.module_dpkg_selections.AnsibleModule
        def fake_run_command(args, check_rc=False):
            import os
            path = tmpdir

# Generated at 2022-06-11 07:05:53.628238
# Unit test for function main
def test_main():
    result = main()
    assert result == { "changed": True, "result": None }

# Generated at 2022-06-11 07:05:58.997444
# Unit test for function main
def test_main():
    rc, out, err = main()
    assert err == ''
    assert rc == 0
    assert out == ''

# Functional test using ansible
# ansible localhost -m dpkg -a 'name="python" selection="hold"'
ANSTEST = '''
- hosts: localhost
  connection: local
  gather_facts: False
  tasks:
  - name: Set selector for python to hold
    dpkg_selections:
      name: python
      selection: hold
'''

# Generated at 2022-06-11 07:06:00.993931
# Unit test for function main
def test_main():
    dpkg_selections = __import__('dpkg_selections')
    dpkg_selections.main()

# Generated at 2022-06-11 07:06:07.208749
# Unit test for function main
def test_main():
    module_args = dict(
        name='python',
        selection='hold'
    )
    out = dict(
        changed=False,
        before='hold',
        after='hold',
    )
    result = dict(
        stdout=None,
        stderr=None,
        rc=0
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    return module.exit_json(**out)

# Test module with error

# Generated at 2022-06-11 07:06:16.080180
# Unit test for function main
def test_main():
    name = "git"
    selection = "install"
    out = True
    err = False
    rc = 0
    num = 1


    def test_run_command(rc, out, err):
        if out == True:
            return (0, "%s	%s\n" % (name, selection), None)
        return (rc, out, err)


    module = AnsibleModule(argument_spec=dict(name=dict(required=True),
                                              selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)),
                           supports_check_mode=True)
    module.run_command = test_run_command
    module.get_bin_path = lambda x, y: x
    module.exit_json = lambda x: x

    assert module.main

# Generated at 2022-06-11 07:06:25.671985
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    module.run_command = lambda args, **kwargs: (0, 'python hold', '')
    rc, out, err = main()

    assert out['before'] == 'not present'
    assert out['after'] == 'install'
    assert not out['changed']

    module.run_command = lambda args, **kwargs: (0, 'python install', '')
    rc, out, err = main()

    assert out['before'] == 'install'
    assert out['after'] == 'hold'
    assert out['changed']

# Generated at 2022-06-11 07:06:31.872571
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
    ))

    def set_selections(binary, name, selection):
        return 0, "Set selections for %s %s" % (name, selection), ""

    module.run_command = set_selections
    module.run_command.package_name = "dpkg",
    module.check_mode = False
    main()

# Generated at 2022-06-11 07:06:33.982152
# Unit test for function main
def test_main():
    import os
    test_module = os.path.join(os.path.dirname(__file__), 'test_module.py')
    os.system('pylint --rcfile=/dev/null -E ' + test_module)
    os.system('python ' + test_module)

# Generated at 2022-06-11 07:09:02.159560
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'
    selection_new = 'install'
    selection_new2 = 'purge'
    current = 'install'
    input_args = {'name': name, 'selection': selection}

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'


# Generated at 2022-06-11 07:09:11.491018
# Unit test for function main
def test_main():
    name = 'python'
    selection = 'hold'

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection


# Generated at 2022-06-11 07:09:19.504729
# Unit test for function main
def test_main():
    # Test case to check return code when apt is not present
    def run_command_mock(self, cmd, data=None, follow=False):
        return 1, "dpkg not found", ""

    m = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
    )
    m.run_command = run_command_mock
    m.fail_json = lambda msg: msg
    try:
        main()
    except Exception as e:
        assert e == {'msg': 'Failed to run set-selections: dpkg not found', 'failed': True}


# Generated at 2022-06-11 07:09:29.145013
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = module.get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run_command([dpkg, '--get-selections', name], check_rc=True)
    if not out:
        current = 'not present'
    else:
        current = out.split()[1]

    changed = current != selection

    if module.check_mode or not changed:
        module.exit

# Generated at 2022-06-11 07:09:38.797369
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.dict_transformations import to_filtered_dict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    import os
    import tempfile
    import shutil
    import json

    tempdir = tempfile.mkdtemp(prefix='ansible-tmp')
    box_dir = os.path.join(tempdir, 'box')
    os.mkdir(box_dir, 0o755)
    os.mkdir(os.path.join(box_dir, 'dist'), 0o755)
    os.mkdir(os.path.join(box_dir, 'log'), 0o755)


# Generated at 2022-06-11 07:09:48.696576
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    try:
        import getpass
    except ImportError:
        import pwd
        getpass = lambda x: pwd.getpwuid(x).pw_name
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True)
        ),
        supports_check_mode=True,
    )

    dpkg = get_bin_path('dpkg', True)

    name = module.params['name']
    selection = module.params['selection']

    # Get current settings.
    rc, out, err = module.run

# Generated at 2022-06-11 07:09:57.394809
# Unit test for function main
def test_main():
    name = "python"
    test_selection = "hold"
    my_mock = {
        "get_bin_path.return_value": "dpkg",
        "run_command.return_value": (0, 'python hold', ''),
        "check_mode": False
    }
    my_module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
        selection=dict(choices=['install', 'hold', 'deinstall', 'purge'], required=True))
    )
    my_module.params = {'name': name, 'selection': test_selection}
    my_module.check_mode = False

    with patch.multiple(basic.AnsibleModule, **my_mock):
        main()

    my_module.exit_json.assert_called_once