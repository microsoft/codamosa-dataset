

# Generated at 2022-06-18 06:25:03.197324
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:06.474679
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:07.641115
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:25:10.386025
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:12.303334
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:13.319594
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:15.454896
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:17.036170
# Unit test for constructor of class Register
def test_Register():
    """
    Test the constructor of the Register class.
    """
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:25:19.120650
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:20.163040
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:25:35.759157
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from .renderfunc import render_rgb_bg, render_rgb_fg

    # Create register
    r = Register()

    # Set renderfuncs
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(RgbBg, render_rgb_bg)

    # Set rgb_call
    r.set_rgb_call(RgbFg)

    # Define style
    r.red = Style(RgbFg(255, 0, 0))

    # Test rgb_call
    assert r(255, 0, 0) == r.red

    # Set rgb_call
    r.set_rgb_call(RgbBg)

    # Test rgb_call
    assert r

# Generated at 2022-06-18 06:25:43.912777
# Unit test for constructor of class Style
def test_Style():

    from sty import fg, bg, ef, rs, RgbFg, RgbBg, Sgr, FgBg

    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of str
    assert isinstance(fg.red, Style)

    # Test if Style is a subclass of str
    assert isinstance(bg.red, Style)

    # Test if Style is a subclass of str
    assert isinstance(ef.red, Style)

    # Test if Style is a subclass of str
    assert isinstance(rs.red, Style)

    # Test if Style is a subclass of str
    assert isinstance(fg.red, str)

    # Test if Style is a subclass of str
    assert isinstance(bg.red, str)

    # Test if Style is

# Generated at 2022-06-18 06:25:53.692798
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.test = Style(RgbFg(1, 2, 3))
    r2 = r.copy()
    assert r2.test == r.test
    assert r2.test is not r.test
    assert r2.renderfuncs is not r.renderfuncs
    assert r2.renderfuncs == r.renderfuncs
    assert r2.eightbit_call is not r.eightbit_call
    assert r2.rgb_call is not r.rgb_call
    assert r2.is_muted is not r.is_muted
    assert r2.is_muted == r.is_muted


# Generated at 2022-06-18 06:26:04.129481
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r

# Generated at 2022-06-18 06:26:14.212619
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.bold_red = Style(Sgr(1), RgbFg(255, 0, 0))

    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:26:17.990752
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:26.114567
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:26:29.994766
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"



# Generated at 2022-06-18 06:26:34.508671
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    fg = Register()
    fg.set_eightbit_call(Eightbit)
    fg.set_rgb_call(RgbFg)
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    fg.bold = Style(Sgr(1))
    fg.red = Style(Eightbit(1))
    fg.orange = Style(RgbFg(1, 5, 10))

    assert fg("bold") == fg.bold
    assert fg("red") == fg.red
    assert fg("orange") == fg.orange

    assert fg(1) == fg.red

# Generated at 2022-06-18 06:26:45.489575
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"

# Generated at 2022-06-18 06:27:00.173409
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
    }



# Generated at 2022-06-18 06:27:10.293335
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r

# Generated at 2022-06-18 06:27:15.054077
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the __new__ method of class Style.
    """
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:27:24.378603
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:27:32.677574
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style(Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.blue == "\x1b[38;2;0;0;255m"
    assert nt.bold == "\x1b[1m"

# Generated at 2022-06-18 06:27:41.316864
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    register = Register()
    register.set_renderfunc(RgbFg, render_rgb_fg)
    register.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:27:49.143791
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class R1(RenderType):
        pass

    class R2(RenderType):
        pass

    def f1(*args):
        return "f1"

    def f2(*args):
        return "f2"

    r = Register()
    r.set_renderfunc(R1, f1)
    r.set_renderfunc(R2, f2)

    assert r.renderfuncs[R1] == f1
    assert r.renderfuncs[R2] == f2



# Generated at 2022-06-18 06:27:56.962035
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbBg)

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r(0, 0, 255) == "\x1b[48;2;0;0;255m"
    assert r("red") == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:28:06.078118
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    r.mute()
    assert str(r.red) == ""

    r.unmute()

# Generated at 2022-06-18 06:28:09.839461
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:28:21.521106
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class MyRenderType(RenderType):
        pass

    class MyRegister(Register):
        pass

    def my_renderfunc(x: int) -> str:
        return f"\x1b[{x}m"

    r = MyRegister()
    r.set_renderfunc(MyRenderType, my_renderfunc)

    assert r.renderfuncs[MyRenderType] == my_renderfunc

    r.my_style = Style(MyRenderType(42))

    assert str(r.my_style) == "\x1b[42m"

# Generated at 2022-06-18 06:28:28.199314
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:28:38.494519
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(r.red, r.bold)

    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:28:48.505360
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))
    r.bold_red = Style(Sgr(1), r.red)

    assert str(r.bold) == "\x1b[1m"
    assert str(r.bold_red) == "\x1b[1m\x1b[31m"

    r.mute()

    assert str(r.bold) == ""
    assert str(r.bold_red) == ""

    r.unmute()

    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:28:57.639283
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    test_register.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(test_register.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    test_register.set_eightbit_call(RgbFg)


# Generated at 2022-06-18 06:29:07.631034
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test method set_renderfunc of class Register.
    """
    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)
    reg.set_renderfunc(Sgr, render_sgr)

    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))

# Generated at 2022-06-18 06:29:10.405764
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m"}


# Generated at 2022-06-18 06:29:20.801101
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, sgr):
            self.args = (sgr,)

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)


# Generated at 2022-06-18 06:29:29.533936
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    my_register = MyRegister()
    my_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    my_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    my_register.set_eightbit_call(RgbFg)

    my_register.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert my_register(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:29:37.643488
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbBg, RgbFg
    from .style import Style

    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.blue == "\x1b[48;2;0;0;255m"

# Generated at 2022-06-18 06:29:52.486749
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:30:03.205731
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:30:12.993773
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    fg.red = Style(RgbFg(255, 0, 0))
    fg.bold = Style(Sgr(1))
    fg.boldred = Style(fg.bold, fg.red)

    fg.mute()
    assert fg.boldred == ""

    fg.unmute()

# Generated at 2022-06-18 06:30:22.476854
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-18 06:30:32.903781
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test method set_renderfunc of class Register.
    """
    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code):
        return f"\x1b[{code}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)
    reg.set_renderfunc(Sgr, render_sgr)

    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    reg.blue = Style(RgbFg(0, 0, 255), Sgr(1))


# Generated at 2022-06-18 06:30:40.500300
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"

# Generated at 2022-06-18 06:30:45.765090
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if a deepcopy of a register-object has the same attributes as the original.
    """
    from .rendertype import RgbFg, Sgr

    r1 = Register()
    r1.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r2 = r1.copy()

    assert r1.red == r2.red

# Generated at 2022-06-18 06:30:48.239163
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:30:53.995476
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    s1 = Style(RgbFg(1, 2, 3), Sgr(1))
    s2 = Style(RgbFg(1, 2, 3), Sgr(1))

    assert s1 == s2
    assert s1 is not s2
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;2;3m\x1b[1m"



# Generated at 2022-06-18 06:31:01.792169
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r(0, 255, 0) == "\x1b[38;2;0;255;0m\x1b[1m"

# Generated at 2022-06-18 06:31:39.581679
# Unit test for constructor of class Style
def test_Style():
    """
    Test constructor of class Style.
    """
    from .rendertype import Sgr, RgbFg

    s = Style(Sgr(1), RgbFg(1, 2, 3), value="\x1b[38;2;1;2;3m\x1b[1m")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert s.rules == (Sgr(1), RgbFg(1, 2, 3))



# Generated at 2022-06-18 06:31:44.517797
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg
    s = Style(Sgr(1), RgbFg(1, 5, 10))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"


# Generated at 2022-06-18 06:31:56.161471
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(2))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(3))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[2m"
    assert nt.blue == "\x1b[38;2;0;0;255m\x1b[3m"

# Generated at 2022-06-18 06:32:05.665695
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:32:12.309576
# Unit test for constructor of class Style
def test_Style():
    assert Style("") == ""
    assert Style("", "") == ""
    assert Style("", "", "") == ""
    assert Style("", "", "", "") == ""
    assert Style("", "", "", "", "") == ""
    assert Style("", "", "", "", "", "") == ""
    assert Style("", "", "", "", "", "", "") == ""
    assert Style("", "", "", "", "", "", "", "") == ""
    assert Style("", "", "", "", "", "", "", "", "") == ""
    assert Style("", "", "", "", "", "", "", "", "", "") == ""
    assert Style("", "", "", "", "", "", "", "", "", "", "") == ""
   

# Generated at 2022-06-18 06:32:23.473475
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code):
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-18 06:32:31.672542
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .render import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:32:37.257367
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))
            self.bold = Style(Sgr(1))
            self.underline = Style(Sgr(4))

    tr = TestRegister()

    assert tr.red == "\x1b[38;2;255;0;0m"
    assert tr.green == "\x1b[38;2;0;255;0m"
    assert tr.blue == "\x1b[38;2;0;0;255m"


# Generated at 2022-06-18 06:32:48.144397
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:32:52.699355
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r.rgb_call(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:33:19.923860
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbBg(0, 0, 255), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.blue == "\x1b[48;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:33:23.808918
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(RenderType, lambda x: x)
    r.test = Style(RenderType("test"))

    assert r.test == "test"



# Generated at 2022-06-18 06:33:33.540523
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()
    assert nt.red == fg.red
    assert nt.green == fg.green
    assert nt.blue == fg.blue
    assert nt.yellow == fg.yellow
    assert nt.magenta == fg.magenta
    assert nt.cyan == fg.cyan
    assert nt.white == fg.white
    assert nt.black == fg.black
    assert nt.lightgrey == fg.lightgrey
    assert nt.darkgrey == fg.darkgrey
    assert nt.lightred == fg.lightred
    assert nt.lightgreen == fg.lightgreen
    assert nt.lightblue == fg.lightblue


# Generated at 2022-06-18 06:33:42.811000
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.test = Style(RgbFg(1, 2, 3))

    assert r.test == "\x1b[38;2;1;2;3m"

    r.mute()

    assert r.test == ""

    r.unmute()

    assert r.test == "\x1b[38;2;1;2;3m"

    r.test = Style(RgbFg(1, 2, 3), Sgr(1))

    assert r.test == "\x1b[38;2;1;2;3m\x1b[1m"

    r.mute()

    assert r.test == ""

    r.unmute()


# Generated at 2022-06-18 06:33:49.470332
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(value="\x1b[38;2;1;5;10m\x1b[1m"), Style)
    assert isinstance(Style(value="\x1b[38;2;1;5;10m\x1b[1m"), str)
    assert str(Style(value="\x1b[38;2;1;5;10m\x1b[1m")) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:33:59.219183
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:34:06.532230
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "blue": "\x1b[38;2;0;0;255m\x1b[1m"}

# Generated at 2022-06-18 06:34:13.868786
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:34:17.968843
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m"}

# Generated at 2022-06-18 06:34:28.214095
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
