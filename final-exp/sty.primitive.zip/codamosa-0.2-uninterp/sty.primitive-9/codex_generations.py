

# Generated at 2022-06-18 06:25:06.854438
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    r.renderfuncs.update({RgbFg: lambda x: f"RgbFg({x})", Sgr: lambda x: f"Sgr({x})"})

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r(255, 0, 0) == "RgbFg(255, 0, 0)"
    assert r(1) == "RgbFg(1)"
    assert r("red") == "RgbFg(255, 0, 0)Sgr(1)"


# Unit

# Generated at 2022-06-18 06:25:12.303637
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    fg = Register()
    fg.red = Style(Eightbit(1), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert fg(1) == "\x1b[38;5;1m\x1b[1m"
    assert fg(0, 0, 255) == "\x1b[38;2;0;0;255m\x1b[1m"
    assert fg("red") == "\x1b[38;5;1m\x1b[1m"
    assert fg("blue") == "\x1b[38;2;0;0;255m\x1b[1m"

    fg.mute()

# Generated at 2022-06-18 06:25:19.360521
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0), Sgr(1))
            self.green = Style(RgbFg(0, 255, 0), Sgr(1))
            self.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r = TestRegister()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")


# Generated at 2022-06-18 06:25:26.114799
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbBg)

    assert r(255, 0, 0) == "\x1b[48;2;255;0;0m"



# Generated at 2022-06-18 06:25:37.403890
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, RgbEf

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{bm}m"

    def render_rgb_ef(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m\x1b[48;2;{r};{g};{bm}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)
    fg.set_r

# Generated at 2022-06-18 06:25:44.612391
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.bold == "\x1b[1m"

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:25:47.075768
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)
    assert isinstance(r, object)


# Generated at 2022-06-18 06:25:52.811811
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == "\x1b[38;5;42m"
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-18 06:25:58.116563
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Eightbit, RgbFg

    r = Register()
    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)

    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")

    assert r(42) == "\x1b[38;5;42m"
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-18 06:26:03.167060
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from .register import Register

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == RgbBg

# Generated at 2022-06-18 06:26:15.916607
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, bg, ef, rs

    fg.set_rgb_call(bg.RgbBg)
    assert fg(1, 2, 3) == bg.RgbBg(1, 2, 3)

    ef.set_rgb_call(bg.RgbBg)
    assert ef(1, 2, 3) == bg.RgbBg(1, 2, 3)

    rs.set_rgb_call(bg.RgbBg)
    assert rs(1, 2, 3) == bg.RgbBg(1, 2, 3)



# Generated at 2022-06-18 06:26:25.920607
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    def rgb_call(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def sgr_call(sgr):
        return f"\x1b[{sgr}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, rgb_call)
    reg.set_renderfunc(Sgr, sgr_call)
    reg.set_rgb_call(RgbFg)
    reg.set_eightbit_call(Sgr)

    reg.red = Style(RgbFg(255, 0, 0))
    reg.bold = Style(Sgr(1))


# Generated at 2022-06-18 06:26:29.796175
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg



# Generated at 2022-06-18 06:26:35.105061
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:36.304206
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:26:43.473778
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.red = Style(RenderType(1))
    assert r(42) == "\x1b[1m"
    assert r(10, 42, 255) == "\x1b[1m"
    assert r("red") == "\x1b[1m"

    r.mute()
    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.unmute()

# Generated at 2022-06-18 06:26:54.166556
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.red = Style(RenderType(42))
    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == ""
    assert r("red") == "\x1b[42m"

    r.mute()
    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.unmute()
    assert r(42) == "\x1b[42m"

# Generated at 2022-06-18 06:26:55.364773
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:27:00.389112
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.red = Style(RgbFg(255, 0, 0))
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    assert r("red") == "\x1b[38;2;255;0;0m"
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-18 06:27:03.804618
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:27:11.442140
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:27:18.801011
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r(0, 255, 0) == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-18 06:27:27.369104
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    fg.set_rgb_call(RgbFg)
    assert fg(10, 20, 30) == "\x1b[38;2;10;20;30m"

    fg.set_rgb_call(RgbBg)
    assert fg(10, 20, 30) == ""



# Generated at 2022-06-18 06:27:37.604393
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:27:49.415368
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb_call(RgbBg)

    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-18 06:27:57.137242
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    fg = Register()
    f

# Generated at 2022-06-18 06:28:03.952894
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from .renderfunc import render_rgb_bg, render_rgb_fg

    # Create a new register.
    r = Register()

    # Set renderfuncs for RgbBg and RgbFg.
    r.set_renderfunc(RgbBg, render_rgb_bg)
    r.set_renderfunc(RgbFg, render_rgb_fg)

    # Set RgbBg as default rendertype for RGB-calls.
    r.set_rgb_call(RgbBg)

    # Create a new style with RgbFg.
    r.red = Style(RgbFg(255, 0, 0))

    # Call register with RGB-values.

# Generated at 2022-06-18 06:28:14.516032
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r(1) == "\x1b[38;2;255;0;0m"
    assert r("red") == "\x1b[38;2;255;0;0m"
    assert r("bold") == "\x1b[1m"

    r.mute()


# Generated at 2022-06-18 06:28:23.653092
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    test_register = TestRegister()
    test_register.set_eightbit_call(RenderType)
    test_register.set_rgb_call(RenderType)

    assert test_register(42) == ""
    assert test_register(10, 42, 255) == ""
    assert test_register("red") == ""

    test_register.red = Style(RenderType(1, 2, 3))
    assert test_register("red") == "\x1b[1;2;3m"

    test_register.mute()
    assert test_register("red") == ""

    test_register.unmute()
    assert test_register("red") == "\x1b[1;2;3m"



# Generated at 2022-06-18 06:28:34.928366
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb_call(RgbBg)

    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-18 06:28:52.483282
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, RgbBg, Sgr, Reset

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")
    r.set_renderfunc(Reset, lambda: "\x1b[0m")

    r.red = Style(RgbFg(255, 0, 0))

# Generated at 2022-06-18 06:28:57.303697
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbBg(0, 0, 255), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == r.red
    assert nt.blue == r.blue

# Generated at 2022-06-18 06:29:02.357827
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(value=""), Style)
    assert isinstance(Style(value=""), str)
    assert str(Style(value="")) == ""
    assert str(Style(value="\x1b[38;2;1;5;10m\x1b[1m")) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:29:09.165293
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m",
                           "green": "\x1b[38;2;0;255;0m",
                           "blue": "\x1b[38;2;0;0;255m"}


# Generated at 2022-06-18 06:29:19.715389
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.bold == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:29:26.787710
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the method __new__ of class Style.
    """
    from .rendertype import RgbFg, Sgr

    # Create a Style object
    style = Style(RgbFg(1, 5, 10), Sgr(1))

    # Check if it is a Style object
    assert isinstance(style, Style)

    # Check if it is a str object
    assert isinstance(style, str)

    # Check if the string representation is correct
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:29:34.248875
# Unit test for method copy of class Register
def test_Register_copy():

    from sty import fg, bg, ef, rs

    fg_copy = fg.copy()
    bg_copy = bg.copy()
    ef_copy = ef.copy()
    rs_copy = rs.copy()

    assert fg_copy is not fg
    assert bg_copy is not bg
    assert ef_copy is not ef
    assert rs_copy is not rs

    assert fg_copy.renderfuncs is fg.renderfuncs
    assert bg_copy.renderfuncs is bg.renderfuncs
    assert ef_copy.renderfuncs is ef.renderfuncs
    assert rs_copy.renderfuncs is rs.renderfuncs

    assert fg_copy.eightbit_call is fg.eightbit_call
    assert bg_copy

# Generated at 2022-06-18 06:29:41.759283
# Unit test for method unmute of class Register
def test_Register_unmute():
    import sty
    import sys

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(sty.fg.red)
            self.blue = Style(sty.fg.blue)

    r = MyRegister()
    r.mute()
    assert r.red == ""
    assert r.blue == ""
    r.unmute()
    assert r.red == "\x1b[31m"
    assert r.blue == "\x1b[34m"



# Generated at 2022-06-18 06:29:45.510851
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:29:49.766143
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0), Sgr(1))
            self.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r = TestRegister()
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert str(r.blue) == "\x1b[38;2;0;0;255m\x1b[1m"

    r.mute()
    assert str(r.red) == ""
    assert str(r.blue) == ""

    r.unmute()

# Generated at 2022-06-18 06:30:12.148417
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)
    fg.set_renderfunc(Sgr, render_sgr)

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:30:17.848218
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.set_renderfunc(Sgr, lambda *args: "SGR")
            self.test = Style(Sgr(1))

    r = TestRegister()
    assert str(r.test) == "SGR"
    r.mute()
    assert str(r.test) == ""
    r.unmute()
    assert str(r.test) == "SGR"

# Generated at 2022-06-18 06:30:24.584541
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").value == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m", rules=[1, 2, 3]).rules == (1, 2, 3)

# Generated at 2022-06-18 06:30:32.462854
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    reg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert reg.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "blue": "\x1b[38;2;0;0;255m\x1b[1m"}



# Generated at 2022-06-18 06:30:34.730714
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:30:41.990568
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import fg, bg, ef, rs

    # Test if setting a Style-object works.
    fg.red = Style(fg.red)
    assert isinstance(fg.red, Style)

    # Test if setting a Style-object with a value works.
    fg.red = Style(fg.red, value="\x1b[31m")
    assert isinstance(fg.red, Style)

    # Test if setting a Style-object with a value works.
    fg.red = Style(fg.red, value="\x1b[31m")
    assert isinstance(fg.red, Style)

    # Test if setting a Style-object with a value works.
    fg.red = Style(fg.red, value="\x1b[31m")

# Generated at 2022-06-18 06:30:50.930244
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:30:58.794831
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test if the method __setattr__ of class Register works as expected.
    """
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.bold_red = Style(r.bold, r.red)

    assert isinstance(r.red, Style)
    assert isinstance(r.bold, Style)

# Generated at 2022-06-18 06:31:08.421558
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, Sgr, RgbFg24bit, RgbBg24bit

    class TestRegister(Register):
        pass

    # Create a new register-object
    test_register = TestRegister()

    # Add renderfuncs to the register-object
    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Add styles to the

# Generated at 2022-06-18 06:31:11.829380
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    def renderfunc(x: int) -> str:
        return f"{x}"

    r = Register()
    r.set_renderfunc(Sgr, renderfunc)

    assert r.renderfuncs[Sgr] == renderfunc



# Generated at 2022-06-18 06:31:30.808702
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(s):
        return f"\x1b[{s}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:31:40.609278
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_renderfunc(Sgr, render_sgr)


# Generated at 2022-06-18 06:31:46.723508
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.renderfuncs = {RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"}

    r.red = Style(RgbFg(255, 0, 0))

    assert r.red == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-18 06:31:50.587028
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:31:56.541941
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import Sgr, RgbFg

    s1 = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;5;10m\x1b[1m"


# Generated at 2022-06-18 06:32:06.038243
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    # Create a new register object.
    r = Register()

    # Define a renderfunc for RgbFg.
    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    # Define a renderfunc for RgbBg.
    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    # Add renderfuncs to register.
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(RgbBg, render_rgb_bg)

    # Define a style

# Generated at 2022-06-18 06:32:10.457914
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:32:21.261065
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"

# Generated at 2022-06-18 06:32:29.613717
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if the copy method of the Register class works as expected.
    """
    from sty import fg, bg, ef, rs

    fg1 = fg.copy()
    fg2 = fg.copy()
    fg3 = fg.copy()

    fg1.red = Style(RgbFg(255, 0, 0))
    fg2.green = Style(RgbFg(0, 255, 0))
    fg3.blue = Style(RgbFg(0, 0, 255))

    assert fg1.red == "\x1b[38;2;255;0;0m"
    assert fg2.green == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-18 06:32:32.541838
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:32:55.132458
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:33:05.206626
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.red = Style(RenderType(1))
    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"
    assert r("red") == "\x1b[1m"

    r.mute()
    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.unmute()
    assert r

# Generated at 2022-06-18 06:33:13.942677
# Unit test for constructor of class Style
def test_Style():
    # Test 1
    s1 = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;5;10m\x1b[1m"

    # Test 2
    s2 = Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m")
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert str(s2) == "\x1b[38;2;1;5;10m\x1b[1m"

    # Test 3
    s3 = Style

# Generated at 2022-06-18 06:33:24.689578
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.eightbit_call = lambda x: x
            self.rgb_call = lambda r, g, b: (r, g, b)

    r = TestRegister()
    r.red = Style(Eightbit(1), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r(1) == "1"
    assert r(0, 0, 255) == (0, 0, 255)
    assert r("red") == "\x1b[38;5;1m\x1b[1m"

# Generated at 2022-06-18 06:33:29.608834
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr

    def renderfunc(x):
        return "test"

    reg = Register()
    reg.set_renderfunc(Sgr, renderfunc)

    assert reg.renderfuncs[Sgr] == renderfunc

    reg.set_renderfunc(Sgr, renderfunc)
    assert reg.renderfuncs[Sgr] == renderfunc



# Generated at 2022-06-18 06:33:34.412439
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:33:35.977603
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:33:41.238166
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-18 06:33:47.660929
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def renderfunc(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    r = Register()
    r.set_renderfunc(RgbFg, renderfunc)

    assert r.renderfuncs[RgbFg] == renderfunc

    r.set_renderfunc(Sgr, renderfunc)

    assert r.renderfuncs[Sgr] == renderfunc



# Generated at 2022-06-18 06:33:57.093792
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == "\x1b[10;42;255m"

    r.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    assert r(42) == "\x1b[42m"

# Generated at 2022-06-18 06:34:41.290032
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:34:47.256847
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr
    from .register import Register

    reg = Register()
    reg.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")
    reg.red = Style(Sgr(31))
    reg.green = Style(Sgr(32))
    reg.blue = Style(Sgr(34))

    nt = reg.as_namedtuple()
    assert nt.red == "\x1b[31m"
    assert nt.green == "\x1b[32m"
    assert nt.blue == "\x1b[34m"