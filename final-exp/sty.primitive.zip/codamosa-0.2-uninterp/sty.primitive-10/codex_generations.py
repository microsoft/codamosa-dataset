

# Generated at 2022-06-18 06:24:55.065657
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:06.599295
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr

    # Create register
    r = Register()

    # Set renderfuncs
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda code: f"\x1b[{code}m")

    # Set styles
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style

# Generated at 2022-06-18 06:25:11.953098
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-18 06:25:13.218187
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)
    assert isinstance(r, object)


# Generated at 2022-06-18 06:25:20.300807
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    test_register.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert test_register.red == "\x1b[38;2;255;0;0m\x1b[1m"

    test_register.set_eightbit_call(RgbFg)


# Generated at 2022-06-18 06:25:32.120271
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:25:33.798533
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)


# Generated at 2022-06-18 06:25:42.557836
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:25:53.852256
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test method set_eightbit_call of class Register.
    """
    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_render

# Generated at 2022-06-18 06:26:04.294106
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:26:11.169422
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:22.626151
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr

    # Create a new register-object
    r = Register()

    # Add a renderfunc for RgbFg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a renderfunc for Sgr
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Create a style-object
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Set the rendertype for Eightbit-calls
    r.set_eightbit_call(RgbFg)

    # Call the register-object with an 8bit color code
    assert r

# Generated at 2022-06-18 06:26:31.249048
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-18 06:26:40.821215
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.set_eightbit_call(Eightbit)

    assert r(42) == "\x1b[38;5;42m"

# Generated at 2022-06-18 06:26:44.523748
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:48.076952
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:57.601440
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(fg.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    fg.set_eightbit_call(RgbFg)
    assert str(fg(1)) == "\x1b[38;2;0;0;0m"

    fg.set

# Generated at 2022-06-18 06:27:06.710701
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:27:14.279951
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(Sgr)

    r.renderfuncs[RgbFg] = lambda x: f"RgbFg({x})"
    r.renderfuncs[Sgr] = lambda r, g, b: f"Sgr({r}, {g}, {b})"

    assert r(42) == "RgbFg(42)"
    assert r(10, 42, 255) == "Sgr(10, 42, 255)"

# Generated at 2022-06-18 06:27:25.821602
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    # Create test register
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    # Create test style
    r.test_style = Style(RgbFg(1, 2, 3), Sgr(1))

    # Check if test style is rendered correctly
    assert str(r.test_style) == "\x1b[38;2;1;2;3m\x1b[1m"

    # Set new renderfunc for Eightbit-calls

# Generated at 2022-06-18 06:27:32.062869
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:27:40.943368
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    fg.set_eightbit_call(RgbFg)

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert fg(255, 0, 0) == fg.red
    assert fg(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
   

# Generated at 2022-06-18 06:27:51.987603
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test method set_eightbit_call of class Register.
    """
    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)
    reg.set_renderfunc(Sgr, render_sgr)

    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))

# Generated at 2022-06-18 06:27:55.715280
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:28:05.304657
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:28:12.424349
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == "\x1b[10;42;255m"

# Generated at 2022-06-18 06:28:16.318818
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:28:22.722258
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test if method set_eightbit_call of class Register works as expected.
    """
    from .rendertype import RgbFg, Sgr

    # Create a new register object.
    r = Register()

    # Add a renderfunc for RgbFg.
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a renderfunc for Sgr.
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Create a new style attribute.
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Set the rendertype for Eightbit-calls to RgbFg.


# Generated at 2022-06-18 06:28:23.839767
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:28:32.628007
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r(255, 0, 0) == r.red
    assert r(0, 0, 255) == r.blue
    assert r(255, 0, 0) == r("red")
    assert r(0, 0, 255) == r("blue")



# Generated at 2022-06-18 06:28:49.810376
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:28:58.511564
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{bm}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(RgbBg, render_rgb_bg)

    r.set_rgb_call(RgbFg)

    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call

# Generated at 2022-06-18 06:29:04.115014
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.bold = Style(Sgr(1))

    assert r.bold == "\x1b[1m"

    r.mute()

    assert r.bold == ""

    r.unmute()

    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:29:11.509200
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Sgr, lambda x: "SGR")
    r.set_renderfunc(RgbFg, lambda x, y, z: "RGB")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == ""
    assert str(r.blue) == ""

    r.unmute()

    assert str(r.red) == "RGB"
    assert str(r.blue) == "RGB"

# Generated at 2022-06-18 06:29:22.211142
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_renderfunc(RenderType, lambda x: x)
    r1.set_eightbit_call(RenderType)
    r1.set_rgb_call(RenderType)
    r1.red = Style(RenderType(1))
    r1.blue = Style(RenderType(2))
    r1.green = Style(RenderType(3))

    r2 = r1.copy()

    assert r1.red == r2.red
    assert r1.blue == r2.blue
    assert r1.green == r2.green

    r1.red = Style(RenderType(4))
    r1.blue = Style(RenderType(5))
    r1.green = Style(RenderType(6))

    assert r1.red != r2.red

# Generated at 2022-06-18 06:29:30.348745
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.boldred = Style(r.red, r.bold)

    r2 = r.copy()

    assert r.boldred == r2.boldred
    assert r.boldred.rules == r2.boldred.rules

# Generated at 2022-06-18 06:29:37.929946
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test if as_namedtuple() returns a namedtuple with the same attributes as the register.
    """
    from sty import fg, bg, ef, rs

    assert hasattr(fg.as_namedtuple(), "red")
    assert hasattr(bg.as_namedtuple(), "red")
    assert hasattr(ef.as_namedtuple(), "bold")
    assert hasattr(rs.as_namedtuple(), "reset")

# Generated at 2022-06-18 06:29:39.354554
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:29:48.306286
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"
    assert nt.blue == "\x1b[38;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:29:55.650770
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:30:10.599548
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == r.renderfuncs[RgbBg]

# Generated at 2022-06-18 06:30:14.677373
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr
    from .renderfunc import sgr_renderfunc

    reg = Register()
    reg.set_renderfunc(Sgr, sgr_renderfunc)
    reg.bold = Style(Sgr(1))
    reg.mute()
    assert reg.bold == ""
    reg.unmute()
    assert reg.bold == "\x1b[1m"

# Generated at 2022-06-18 06:30:22.061381
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.blue == "\x1b[38;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:30:26.650581
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.test = Style(value="test")
    r.test2 = Style(value="test2")
    r2 = r.copy()
    assert r.test == r2.test
    assert r.test2 == r2.test2
    assert r is not r2


# Generated at 2022-06-18 06:30:35.671880
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"
    assert r(255, 42, 10) == "\x1b[38;2;255;42;10m"

    r.set_rgb_call(RgbBg)

    assert r

# Generated at 2022-06-18 06:30:43.320819
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:30:50.401754
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, RgbBg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))
    r.bold = Style(Sgr(1))

    assert r.as_dict() == {'red': '\x1b[38;2;255;0;0m', 'blue': '\x1b[48;2;0;0;255m', 'bold': '\x1b[1m'}



# Generated at 2022-06-18 06:30:58.274407
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if the method copy of class Register works as expected.
    """
    from sty import fg, bg, ef, rs

    fg_copy = fg.copy()
    assert fg_copy is not fg
    assert fg_copy.red is fg.red
    assert fg_copy.red is not fg.red
    assert fg_copy.red == fg.red
    assert fg_copy.red != fg.blue
    assert fg_copy.red != fg.blue
    assert fg_copy.red.rules == fg.red.rules
    assert fg_copy.red.rules is not fg.red.rules

    bg_copy = bg.copy()
    assert bg_copy is not bg
    assert bg_copy.red is b

# Generated at 2022-06-18 06:31:02.791273
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the __new__ method of the Style class.
    """
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:31:08.040682
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r.rgb_call == RgbFg.render

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == RgbBg.render

# Generated at 2022-06-18 06:31:24.621828
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"


# Generated at 2022-06-18 06:31:36.885952
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if copy of register-object works.
    """
    from .rendertype import Sgr, RgbFg

    reg = Register()
    reg.set_renderfunc(Sgr, lambda x: "SGR")
    reg.set_renderfunc(RgbFg, lambda x, y, z: "RGB")
    reg.red = Style(Sgr(1), RgbFg(1, 2, 3))
    reg.blue = Style(Sgr(2), RgbFg(4, 5, 6))

    reg_copy = reg.copy()

    assert reg_copy.red == reg.red
    assert reg_copy.blue == reg.blue

    reg_copy.red = Style(Sgr(3), RgbFg(7, 8, 9))

    assert reg_copy.red != reg.red

# Generated at 2022-06-18 06:31:44.150342
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:31:55.860826
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Test if Style is a subclass of str.
    assert issubclass(Style, str)

    # Test if Style is a subclass of str.
    assert isinstance(Style(""), str)

    # Test if Style is a subclass of str.
    assert isinstance(Style("", ""), str)

    # Test if Style is a subclass of str.
    assert isinstance(Style("", "", ""), str)

    # Test if Style is a subclass of str.
    assert isinstance(Style("", "", "", ""), str)

    # Test if Style is a subclass of str.
    assert isinstance(Style("", "", "", "", ""), str)

    # Test if Style is a subclass of str.
    assert isinstance(Style("", "", "", "", "", ""), str)

    # Test if Style is a subclass

# Generated at 2022-06-18 06:32:00.435031
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr

    r = Register()
    r.red = Style(Sgr(1))
    r.blue = Style(Sgr(2))

    assert r.as_namedtuple().red == "\x1b[1m"
    assert r.as_namedtuple().blue == "\x1b[2m"

# Generated at 2022-06-18 06:32:04.534570
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg, Sgr

    s = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:32:09.949522
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "green": "\x1b[38;2;0;255;0m"}


# Generated at 2022-06-18 06:32:14.509280
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg

    s = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;2;3m\x1b[1m"


# Generated at 2022-06-18 06:32:25.016161
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr, EightbitFg, EightbitBg

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    test_register.set_renderfunc(EightbitFg, lambda x: f"\x1b[38;5;{x}m")

# Generated at 2022-06-18 06:32:32.390718
# Unit test for method __new__ of class Style
def test_Style___new__():
    class TestStyle(Style):
        pass

    s = TestStyle("test")
    assert isinstance(s, str)
    assert isinstance(s, TestStyle)
    assert s == "test"
    assert s.rules == ()

    s = TestStyle("test", "test2")
    assert isinstance(s, str)
    assert isinstance(s, TestStyle)
    assert s == "test"
    assert s.rules == ("test2",)

    s = TestStyle("test", "test2", "test3")
    assert isinstance(s, str)
    assert isinstance(s, TestStyle)
    assert s == "test"
    assert s.rules == ("test2", "test3")



# Generated at 2022-06-18 06:32:52.875042
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    # Create a new register
    r = Register()

    # Add renderfuncs for RgbBg and RgbFg
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set RgbBg as rendertype for RGB-calls
    r.set_rgb_call(RgbBg)

    # Define a style
    r.red = Style(RgbFg(255, 0, 0))

    # Test if the style is rendered correctly

# Generated at 2022-06-18 06:33:02.557486
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    # Test if __call__ returns empty string if register is muted.
    r.mute()
    assert r() == ""
    assert r(1) == ""
    assert r(1, 2, 3) == ""

    # Test if __call__ returns empty string if register is muted.
    r.unmute()
    assert r() == ""
    assert r(1) == ""
    assert r(1, 2, 3) == ""

    # Test if __call__ returns empty string if register is muted.
    r.mute()
    assert r() == ""
    assert r(1) == ""
    assert r(1, 2, 3) == ""

    # Test if __call__ returns empty string if register is muted.
    r.unmute()


# Generated at 2022-06-18 06:33:11.192679
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m",
                           "green": "\x1b[38;2;0;255;0m\x1b[1m",
                           "blue": "\x1b[38;2;0;0;255m\x1b[1m"}



# Generated at 2022-06-18 06:33:16.007221
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test method as_dict of class Register.
    """
    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0))
    reg.blue = Style(RgbFg(0, 0, 255))

    assert reg.as_dict() == {"red": "\x1b[38;2;255;0;0m", "blue": "\x1b[38;2;0;0;255m"}

# Generated at 2022-06-18 06:33:27.296368
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr, EightbitFg, EightbitBg

    r = Register()
    r.set_renderfunc(EightbitFg, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(EightbitBg, lambda x: f"\x1b[48;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

# Generated at 2022-06-18 06:33:36.884392
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.r = r
            self.g = g
            self.b = b

        def __str__(self):
            return f"\x1b[38;2;{self.r};{self.g};{self.b}m"

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.code = code

        def __str__(self):
            return f"\x1b[{self.code}m"

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

   

# Generated at 2022-06-18 06:33:42.295717
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    fg2 = fg.copy()
    assert fg2.red == fg.red

    fg.red = Style(RgbFg(0, 255, 0), Sgr(1))
    assert fg2.red != fg.red



# Generated at 2022-06-18 06:33:52.407921
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:33:58.730781
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "blue": "\x1b[38;2;0;0;255m\x1b[1m"}



# Generated at 2022-06-18 06:34:08.654220
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Test Eightbit-call
    r1 = Register()
    r1.set_eightbit_call(RenderType)
    r1.renderfuncs[RenderType] = lambda x: f"{x}"
    assert r1(42) == "42"

    # Test RGB-call
    r2 = Register()
    r2.set_rgb_call(RenderType)
    r2.renderfuncs[RenderType] = lambda r, g, b: f"{r}-{g}-{b}"
    assert r2(42, 13, 37) == "42-13-37"

    # Test Attribute-call
    r3 = Register()
    r3.foo = Style(RenderType(42))
    r3.renderfuncs[RenderType] = lambda x: f"{x}"
    assert r3

# Generated at 2022-06-18 06:34:30.156455
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.set_eightbit_call(RgbFg)
    assert r(255, 0, 0) == r.red
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

    r.set_eightbit_call(Sgr)

# Generated at 2022-06-18 06:34:36.757498
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:34:38.382650
# Unit test for method __new__ of class Style
def test_Style___new__():
    class TestStyle(Style):
        pass

    style = TestStyle("test")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "test"



# Generated at 2022-06-18 06:34:44.284528
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

   

# Generated at 2022-06-18 06:34:53.218983
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test method set_renderfunc of class Register.
    """

    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))