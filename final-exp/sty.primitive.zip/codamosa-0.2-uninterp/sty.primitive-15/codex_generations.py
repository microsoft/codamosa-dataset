

# Generated at 2022-06-18 06:25:10.124440
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .register import Register

    r1 = Register()
    r1.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r1.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r1.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r1.red = Style(RgbFg(255, 0, 0))
    r1.green = Style(RgbFg(0, 255, 0))


# Generated at 2022-06-18 06:25:16.932720
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))

    test_register = TestRegister()

    assert test_register("red") == "\x1b[38;2;255;0;0m"
    assert test_register("green") == "\x1b[38;2;0;255;0m"
    assert test_register("blue") == "\x1b[38;2;0;0;255m"


# Generated at 2022-06-18 06:25:26.860899
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0), Sgr(1))
            self.green = Style(RgbFg(0, 255, 0), Sgr(1))
            self.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    def render_eightbit(code: int) -> str:
        return f"\x1b[38;5;{code}m"

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:25:28.757720
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:38.896015
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .sty import fg

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.green = Style(RgbFg(0, 255, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert fg.as_dict() == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
    }



# Generated at 2022-06-18 06:25:45.132434
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr
    from .sty import sty

    sty.fg.red = Style(RgbFg(255, 0, 0))
    sty.fg.green = Style(RgbFg(0, 255, 0))
    sty.fg.blue = Style(RgbFg(0, 0, 255))

    assert sty.fg.as_namedtuple().red == "\x1b[38;2;255;0;0m"
    assert sty.fg.as_namedtuple().green == "\x1b[38;2;0;255;0m"
    assert sty.fg.as_namedtuple().blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-18 06:25:57.118550
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

# Generated at 2022-06-18 06:26:05.080620
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r.mute()

    assert r.red == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:26:10.483617
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test if the mute method works as expected.
    """
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r = TestRegister()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:26:22.201981
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg, RgbBg, RgbEf

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbEf, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")


# Generated at 2022-06-18 06:26:31.922313
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.green == ""
    assert r.blue == ""



# Generated at 2022-06-18 06:26:38.711192
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "green": "\x1b[38;2;0;255;0m\x1b[1m"}



# Generated at 2022-06-18 06:26:49.164371
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code):
            self.args = (code,)

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code):
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)


# Generated at 2022-06-18 06:26:58.497674
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Sgr, RgbFg

    class MyRegister(Register):
        pass

    r = MyRegister()

    r.red = Style(RgbFg(255, 0, 0))

    assert r.red == "\x1b[38;2;255;0;0m"

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

    r.red = Style(Sgr(1), RgbFg(255, 0, 0))

    assert r.red == "\x1b[1m\x1b[38;2;255;0;0m"


# Generated at 2022-06-18 06:27:07.977559
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")
    r.set_eightbit_call(Sgr)
    r.set_rgb_call(RgbFg)

    r.red = Style(Sgr(1))
    r.green = Style(RgbFg(0, 255, 0))

    r2 = r.copy()

    assert r.red == r2.red
    assert r.green == r2.green

    r2.red = Style(Sgr(2))
    r

# Generated at 2022-06-18 06:27:16.559931
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()

# Generated at 2022-06-18 06:27:18.988899
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute() works correctly.
    """
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    fg.mute()
    assert fg.red == ""

    fg.unmute()
    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-18 06:27:26.024638
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr

    def sgr_func(sgr: Sgr) -> str:
        return f"\x1b[{sgr.value}m"

    r = Register()
    r.set_renderfunc(Sgr, sgr_func)

    assert r.renderfuncs[Sgr] == sgr_func

    assert r.bold == Style(Sgr(1), value="\x1b[1m")



# Generated at 2022-06-18 06:27:36.397953
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import fg, bg, ef, rs

    # Create a new register-object
    my_register = Register()

    # Add render-functions for RgbFg and RgbBg
    my_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    my_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set RgbFg as rendertype for RGB-calls
    my_register.set_rgb_call(RgbFg)

    # Set RgbBg as rendertype for RGB-calls
    my_register.set_rgb

# Generated at 2022-06-18 06:27:42.261551
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .sty import fg

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    fg.red = Style(RgbFg(255, 0, 0))

    assert fg.as_dict() == {"orange": "\x1b[38;2;1;5;10m\x1b[1m", "red": "\x1b[38;2;255;0;0m"}

# Generated at 2022-06-18 06:27:56.818040
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.red = Style(Sgr(1), RgbFg(255, 0, 0))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    r.mute()

    assert str(r.red) == ""

    r.unmute()


# Generated at 2022-06-18 06:28:01.772208
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        pass

    class TestRegister(Register):
        pass

    test_register = TestRegister()
    test_register.set_renderfunc(TestRenderType, lambda x: "Test")
    test_register.set_eightbit_call(TestRenderType)

    assert test_register(42) == "Test"


# Generated at 2022-06-18 06:28:08.907842
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty import fg, bg, ef, rs

    assert isinstance(fg.red, Style)
    assert isinstance(bg.red, Style)
    assert isinstance(ef.red, Style)
    assert isinstance(rs.red, Style)

    assert isinstance(fg.red, str)
    assert isinstance(bg.red, str)
    assert isinstance(ef.red, str)
    assert isinstance(rs.red, str)

    assert str(fg.red) == "\x1b[38;2;255;0;0m"
    assert str(bg.red) == "\x1b[48;2;255;0;0m"
    assert str(ef.red) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:28:19.988122
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"
    assert nt.blue == "\x1b[38;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:28:31.489607
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def rgb_fg_renderfunc(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def sgr_renderfunc(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg_renderfunc)
    r.set_renderfunc(Sgr, sgr_renderfunc)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:28:40.907580
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:28:51.344393
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)

    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:28:59.828987
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class MyRegister(Register):
        pass

    my_register = MyRegister()

    my_register.renderfuncs.update(
        {
            RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
            Sgr: lambda s: f"\x1b[{s}m",
        }
    )

    my_register.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(my_register.orange, Style)
    assert isinstance(my_register.orange, str)

# Generated at 2022-06-18 06:29:09.611085
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    # Create a new register-object.
    register = Register()

    # Set renderfuncs for the new register-object.

# Generated at 2022-06-18 06:29:20.192619
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))
    r.bold_red = Style(Sgr(1), Sgr(31))

    r2 = r.copy()

    assert r2.bold == r.bold
    assert r2.bold_red == r.bold_red

    r2.bold = Style(Sgr(2))
    assert r2.bold != r.bold

    r2.bold_red = Style(Sgr(2), Sgr(32))
    assert r2.bold_red != r.bold_red

    r2.bold_red = Style(Sgr(1), Sgr(31))
    assert r2.bold_

# Generated at 2022-06-18 06:29:38.814687
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:29:46.639035
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.blue = Style(RgbBg(0, 0, 255))
            self.bold = Style(Sgr(1))

    r = TestRegister()
    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m", "blue": "\x1b[48;2;0;0;255m", "bold": "\x1b[1m"}



# Generated at 2022-06-18 06:29:53.234269
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:30:01.362936
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"
    assert nt.blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-18 06:30:12.063121
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class EightbitFg(RenderType):
        pass

    class EightbitBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

   

# Generated at 2022-06-18 06:30:20.809840
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0), Sgr(1))
            self.green = Style(RgbFg(0, 255, 0), Sgr(1))
            self.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r = MyRegister()
    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"
    assert nt.blue

# Generated at 2022-06-18 06:30:31.613398
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:30:38.143485
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Sgr, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style(Sgr(1))

    assert r("red") == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:30:41.231509
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:30:46.564806
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))
    r.mute()
    assert r.bold == ""
    r.unmute()
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:31:13.558325
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg, Sgr

    s1 = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;5;10m\x1b[1m"

    s2 = Style(s1, Sgr(2))
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert str(s2) == "\x1b[38;2;1;5;10m\x1b[1m\x1b[2m"



# Generated at 2022-06-18 06:31:14.193238
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:31:22.261899
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_ef(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:31:27.692220
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.mute()
    fg.unmute()
    assert str(fg.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:31:34.301007
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(Sgr(1))

    assert r.red == "\x1b[1m"

    r.mute()
    assert r.red == ""

    r.unmute()
    assert r.red == "\x1b[1m"

# Generated at 2022-06-18 06:31:38.607330
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg

    style = Style(Sgr(1), RgbFg(1, 5, 10))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:31:45.303836
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.green = Style(RgbFg(0, 255, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    nt = fg.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"

# Generated at 2022-06-18 06:31:56.796877
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    assert r("red") == "\x1b[38;2;255;0;0m"
    assert r("blue") == "\x1b[38;2;0;0;255m"
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r(0, 0, 255) == "\x1b[38;2;0;0;255m"
    assert r(0) == ""
    assert r(0, 0) == ""
    assert r(0, 0, 0, 0) == ""

# Generated at 2022-06-18 06:32:06.288727
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg
    from .register import Register

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.mute()
    assert r.red == ""
    assert r.blue == ""

    r.unmute()

# Generated at 2022-06-18 06:32:12.580705
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(r.red, r.bold)

    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:32:50.559816
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-18 06:33:00.181323
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:33:09.222260
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)
    reg.set_renderfunc(Sgr, render_sgr)
    reg.set_render

# Generated at 2022-06-18 06:33:13.487417
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr

    r = Register()
    r.red = Style(Sgr(1))
    r.blue = Style(Sgr(2))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[1m"
    assert nt.blue == "\x1b[2m"

# Generated at 2022-06-18 06:33:24.063372
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if the copy method of the Register class works as expected.
    """
    from . import fg, bg, ef, rs

    # Create a new register
    new_register = Register()

    # Add a new style to the new register
    new_register.new_style = Style(fg.red)

    # Copy the new register
    copied_register = new_register.copy()

    # Check if the new style is also in the copied register
    assert hasattr(copied_register, "new_style")

    # Check if the new style is also in the copied register
    assert isinstance(copied_register.new_style, Style)

    # Check if the new style is also in the copied register
    assert str(copied_register.new_style) == str(fg.red)



# Generated at 2022-06-18 06:33:33.757035
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

   

# Generated at 2022-06-18 06:33:38.378769
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg

    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

# Generated at 2022-06-18 06:33:46.982093
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import fg, bg, ef, rs

    # Create a new register-object
    my_register = Register()

    # Add renderfuncs for RgbFg and RgbBg
    my_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    my_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set RgbFg as rendertype for RGB-calls
    my_register.set_rgb_call(RgbFg)

    # Set RgbBg as rendertype for RGB-calls
    my_register.set_rgb_

# Generated at 2022-06-18 06:33:56.821753
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:34:03.308357
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: "SGR")
    r.set_renderfunc(RgbFg, lambda r, g, b: "RGB")

    r.set_eightbit_call(Sgr)
    assert r(42) == "SGR"

    r.set_eightbit_call(RgbFg)
    assert r(42) == "RGB"

