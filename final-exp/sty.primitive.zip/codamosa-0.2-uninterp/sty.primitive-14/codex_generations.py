

# Generated at 2022-06-18 06:25:00.367920
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:09.165381
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightBit, RgbFg

    r = Register()
    r.set_eightbit_call(EightBit)
    r.set_rgb_call(RgbFg)

    r.set_renderfunc(EightBit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")

    assert r(42) == "\x1b[38;5;42m"
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-18 06:25:11.410507
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:13.424861
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:14.448787
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:22.440422
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, Sgr, EightBitFg, EightBitBg

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.set_rgb_call(RgbFg)
    fg.set_eightbit_call(EightBitFg)

    assert fg(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert fg("red") == "\x1b[38;2;255;0;0m"
    assert fg(1) == "\x1b[38;5;1m"

    bg = Register()
    bg.red = Style(RgbBg(255, 0, 0))
    bg.set_r

# Generated at 2022-06-18 06:25:25.975675
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:28.395206
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)
    assert isinstance(r, object)


# Generated at 2022-06-18 06:25:29.934501
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:33.510073
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:40.374148
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    r.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == "\x1b[10;42;255m"

# Generated at 2022-06-18 06:25:46.387129
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r(0, 0, 255) == "\x1b[38;2;0;0;255m\x1b[1m"
    assert r("red") == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:25:57.920231
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)

    r.red = Style(Eightbit(1), Sgr(1))

# Generated at 2022-06-18 06:26:00.657865
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:04.129861
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:06.561225
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:18.513957
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.blue = Style(RgbBg(0, 0, 255))
            self.bold = Style(Sgr(1))

    r = TestRegister()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbBg)

    assert r("red") == "\x1b[38;2;255;0;0m"
    assert r(255, 0, 0) == "\x1b[48;2;255;0;0m"

# Generated at 2022-06-18 06:26:21.782257
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:23.305738
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)
    assert isinstance(r, object)


# Generated at 2022-06-18 06:26:31.816493
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg, Sgr

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{bm}m"

    def render_sgr(code):
        return f"\x1b[{code}m"

    def render_eightbit_fg(code):
        return f"\x1b[38;5;{code}m"

    def render_eightbit_bg(code):
        return f"\x1b[48;5;{code}m"

    r = Register()
    r.set_

# Generated at 2022-06-18 06:26:51.063110
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    assert r.as_dict() == {'red': '\x1b[38;2;255;0;0m', 'green': '\x1b[38;2;0;255;0m', 'blue': '\x1b[38;2;0;0;255m'}


# Generated at 2022-06-18 06:27:00.000617
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r

# Generated at 2022-06-18 06:27:09.728378
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    # Create a new register object
    r = Register()

    # Add renderfuncs for RgbBg and RgbFg
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set RgbBg as rendertype for rgb-calls
    r.set_rgb_call(RgbBg)

    # Create a new style attribute
    r.red = Style(RgbFg(255, 0, 0))

    # Test rgb-call


# Generated at 2022-06-18 06:27:17.837059
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"
    assert r(10, 42, 255) != "\x1b[48;2;10;42;255m"

    r.set_rgb_call(RgbBg)

    assert r

# Generated at 2022-06-18 06:27:26.677114
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbBg, RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.blue = Style(RgbFg(0, 0, 255))
    fg.bold = Style(Sgr(1))

    assert fg.as_dict() == {
        "red": "\x1b[38;2;255;0;0m",
        "blue": "\x1b[38;2;0;0;255m",
        "bold": "\x1b[1m",
    }



# Generated at 2022-06-18 06:27:36.998471
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.test = Style(RgbFg(1, 2, 3), Sgr(1))

    assert r.test == "\x1b[38;2;1;2;3m\x1b[1m"

    assert r.test.rules == (RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(r.test, Style)

    assert isinstance(r.test, str)

    r.mute()

    assert r.test == ""

    assert r.test.rules == (RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(r.test, Style)


# Generated at 2022-06-18 06:27:39.283903
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:27:50.016504
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbBg)

    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

    r.set_rgb_call(RgbFg)

    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:27:57.526929
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

   

# Generated at 2022-06-18 06:28:00.288527
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:28:15.039550
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:28:24.216219
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:28:29.827927
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import Sgr, RgbFg

    style = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;2;3m\x1b[1m"


# Generated at 2022-06-18 06:28:39.779822
# Unit test for constructor of class Style
def test_Style():
    """
    Test the constructor of class Style.
    """
    # Test with one rule
    s1 = Style(RgbFg(1, 2, 3))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1 == "\x1b[38;2;1;2;3m"

    # Test with two rules
    s2 = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert s2 == "\x1b[38;2;1;2;3m\x1b[1m"

    # Test with one style
    s3 = Style(s1)
    assert isinstance(s3, Style)

# Generated at 2022-06-18 06:28:44.953595
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:28:50.092199
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg

    fg = Register()
    fg.red = Style(Sgr(1), RgbFg(255, 0, 0))
    fg.mute()
    assert fg.red == ""
    fg.unmute()
    assert fg.red != ""

# Generated at 2022-06-18 06:28:57.056593
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr, RgbFg
    from .register import Register

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-18 06:29:07.108869
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-18 06:29:16.328680
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    tr = TestRegister()

    tr.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    tr.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    tr.set_rgb_call(RgbFg)
    assert tr(10, 20, 30) == "\x1b[38;2;10;20;30m"
    assert tr(10, 20, 30) == tr.rgb_call(10, 20, 30)


# Generated at 2022-06-18 06:29:23.720090
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    assert r.as_dict() == {'red': '\x1b[38;2;255;0;0m\x1b[1m', 'green': '\x1b[38;2;0;255;0m\x1b[1m'}



# Generated at 2022-06-18 06:29:37.097916
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    assert fg.as_dict() == {
        "red": "\x1b[38;2;255;0;0m",
        "green": "\x1b[38;2;0;255;0m",
        "blue": "\x1b[38;2;0;0;255m",
    }

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

# Generated at 2022-06-18 06:29:46.530058
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: x)
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.red = Style(RenderType(1))
    r.blue = Style(RenderType(2))
    r.green = Style(RenderType(3))
    r.mute()

    r2 = r.copy()

    assert r.renderfuncs == r2.renderfuncs
    assert r.is_muted == r2.is_muted
    assert r.eightbit_call == r2.eightbit_call
    assert r.rgb_call == r2.rgb_call
    assert r.red == r2.red
    assert r.blue == r2.blue
    assert r.green

# Generated at 2022-06-18 06:29:53.162527
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    d = r.as_dict()

    assert d == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
    }


# Unit test

# Generated at 2022-06-18 06:30:03.652804
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code):
            self.args = (code,)

    class RgbBg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code):
        return f"\x1b[{code}m"


# Generated at 2022-06-18 06:30:13.260561
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Create register object
    r = Register()

    # Define renderfuncs
    def renderfunc1(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    def renderfunc2(x: int) -> str:
        return f"\x1b[48;5;{x}m"

    # Add renderfuncs to register
    r.set_renderfunc(RgbFg, renderfunc1)
    r.set_renderfunc(RgbBg, renderfunc2)

    # Set rendertype for eightbit-calls
    r.set_eightbit_call(RgbFg)

    # Test eightbit-call
    assert r(42) == "\x1b[38;5;42m"

    # Set rendertype for eightbit-calls


# Generated at 2022-06-18 06:30:16.280341
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.test = Style(RgbFg(1, 2, 3))
    r2 = r.copy()
    assert r2.test == r.test
    assert r2.test is not r.test

# Generated at 2022-06-18 06:30:21.733600
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import Sgr

    r = Register()
    r.red = Style(Sgr(1))
    r.blue = Style(Sgr(2))

    r2 = r.copy()

    assert r2.red == r.red
    assert r2.blue == r.blue

    r2.red = Style(Sgr(3))

    assert r2.red != r.red
    assert r2.blue == r.blue

# Generated at 2022-06-18 06:30:25.439036
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:30:30.025127
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg, Sgr

    s = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:30:36.094233
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_eightbit_call(RenderType)
    test_register.set_rgb_call(RenderType)

    test_register.red = Style(RenderType(1, 2, 3))

    assert test_register(1, 2, 3) == "\x1b[1;2;3m"
    assert test_register(42) == "\x1b[42m"
    assert test_register("red") == "\x1b[1;2;3m"



# Generated at 2022-06-18 06:30:49.700364
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .renderfunc import render_sgr

    r = Register()
    r.set_renderfunc(Sgr, render_sgr)
    r.bold = Style(Sgr(1))

    assert str(r.bold) == "\x1b[1m"
    r.mute()
    assert str(r.bold) == ""
    r.unmute()
    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:30:54.873199
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .sty import fg

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    fg.blue = Style(RgbFg(10, 20, 30))

    assert fg.as_dict() == {"orange": "\x1b[38;2;1;5;10m\x1b[1m", "blue": "\x1b[38;2;10;20;30m"}

# Generated at 2022-06-18 06:30:57.818111
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:31:06.647816
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test method set_renderfunc of class Register.
    """
    from .rendertype import Sgr, RgbFg, RgbBg, RgbEf

    def sgr_render(code: int) -> str:
        return f"\x1b[{code}m"

    def rgb_render(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def rgb_render_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:31:15.803144
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg, Sgr

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.red_bold = Style(r.red, r.bold)

    assert str(r.red_bold) == "\x1b[38;2;255;0;0m\x1b[1m"

    r.mute()

    assert str(r.red_bold) == ""

    r.un

# Generated at 2022-06-18 06:31:23.623602
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test the method as_namedtuple of class Register.
    """
    from .rendertype import RgbFg, Sgr

    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    reg.green = Style(RgbFg(0, 255, 0), Sgr(1))
    reg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    nt = reg.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"

# Generated at 2022-06-18 06:31:35.090771
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(2))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[2m"

# Generated at 2022-06-18 06:31:43.246273
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test the mute method of class Register.
    """
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()


# Generated at 2022-06-18 06:31:54.382398
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()
    assert nt.red == fg.red
    assert nt.blue == fg.blue
    assert nt.green == fg.green
    assert nt.orange == fg.orange

    nt = bg.as_namedtuple()
    assert nt.red == bg.red
    assert nt.blue == bg.blue
    assert nt.green == bg.green
    assert nt.orange == bg.orange

    nt = ef.as_namedtuple()
    assert nt.bold == ef.bold
    assert nt.underlined == ef.underlined
    assert nt.blink == ef.blink
    assert nt.reverse

# Generated at 2022-06-18 06:32:04.577670
# Unit test for method copy of class Register
def test_Register_copy():
    from sty import fg, bg, ef, rs

    fg_copy = fg.copy()
    assert fg_copy is not fg
    assert fg_copy.red is not fg.red
    assert fg_copy.red == fg.red
    assert fg_copy.red == '\x1b[38;2;255;0;0m'

    bg_copy = bg.copy()
    assert bg_copy is not bg
    assert bg_copy.red is not bg.red
    assert bg_copy.red == bg.red
    assert bg_copy.red == '\x1b[48;2;255;0;0m'

    ef_copy = ef.copy()
    assert ef_copy is not ef
    assert e

# Generated at 2022-06-18 06:32:37.735126
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:32:48.434320
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg

    fg = Register()
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:32:54.870327
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    register = TestRegister()

    register.set_eightbit_call(RenderType)
    register.set_rgb_call(RenderType)

    assert register(1) == ""
    assert register(1, 2, 3) == ""
    assert register("test") == ""

    register.test = Style(RenderType())
    assert register("test") == "\x1b[0m"

    register.mute()
    assert register("test") == ""

    register.unmute()
    assert register("test") == "\x1b[0m"

    register.test = Style(RenderType(), RenderType())
    assert register("test") == "\x1b[0m\x1b[0m"

    register.test = Style(Style(RenderType()), RenderType())
   

# Generated at 2022-06-18 06:32:59.833144
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Sgr

    class TestRegister(Register):
        pass

    tr = TestRegister()

    tr.set_renderfunc(Sgr, lambda *args: "".join(args))

    tr.bold = Style(Sgr(1))

    assert tr.bold == "1"

    tr.bold = Style(Sgr(2))

    assert tr.bold == "2"

# Generated at 2022-06-18 06:33:08.962976
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    # Create a new register object
    r = Register()

    # Add a renderfunc for RgbFg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a renderfunc for Sgr
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Add a style attribute to the register
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Check if the style attribute is a Style object
    assert isinstance(r.red, Style)

    # Check if the style attribute is a str object

# Generated at 2022-06-18 06:33:15.144700
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r2 = r.copy()

    assert r.red == r2.red
    assert r.blue == r2.blue
    assert r.red is not r2.red
    assert r.blue is not r2.blue



# Generated at 2022-06-18 06:33:26.193410
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    class RgbFg(RenderType):
        """
        This is a dummy class for testing.
        """
        pass

    class Sgr(RenderType):
        """
        This is a dummy class for testing.
        """
        pass

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(fg.orange, Style)

# Generated at 2022-06-18 06:33:35.565837
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    nt = r.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.blue == "\x1b[38;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:33:40.344186
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:33:46.260206
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    # Create a new register object
    r = Register()

    # Add some styles
    r.red = Style(fg.red)
    r.blue = Style(bg.blue)
    r.bold = Style(ef.bold)

    # Export as namedtuple
    nt = r.as_namedtuple()

    # Test if all attributes are present
    assert hasattr(nt, "red")
    assert hasattr(nt, "blue")
    assert hasattr(nt, "bold")

    # Test if all attributes have the correct value
    assert nt.red == fg.red
    assert nt.blue == bg.blue
    assert nt.bold == ef.bold



# Generated at 2022-06-18 06:34:22.020855
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .render import Render

    r = Render()
    assert isinstance(r.fg.as_namedtuple(), namedtuple)

# Generated at 2022-06-18 06:34:28.602207
# Unit test for constructor of class Style
def test_Style():
    """
    Test constructor of class Style.
    """
    from .rendertype import RgbFg, Sgr

    assert isinstance(Style(RgbFg(1, 2, 3), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3), Sgr(1)), str)
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"



# Generated at 2022-06-18 06:34:31.582313
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:34:33.590928
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(value="\x1b[1m")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[1m"



# Generated at 2022-06-18 06:34:38.757947
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(RgbBg, render_rgb_bg)
    r

# Generated at 2022-06-18 06:34:44.700513
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"