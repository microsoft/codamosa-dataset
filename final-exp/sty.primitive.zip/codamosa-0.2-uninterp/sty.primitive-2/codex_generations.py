

# Generated at 2022-06-18 06:25:06.352270
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"


# Generated at 2022-06-18 06:25:11.595875
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a new register-object
    r = Register()

    # Add a new style to the register
    r.red = Style(RgbFg(255, 0, 0))

    # Add a new renderfunc to the register
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Test Eightbit-call
    assert r(255) == ""

    # Test RGB-call
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

    # Test string-call
    assert r("red") == "\x1b[38;2;255;0;0m"

    # Mute register
    r.mute()

    # Test Eightbit

# Generated at 2022-06-18 06:25:14.216885
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:15.244257
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:25:23.626816
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    myreg = MyRegister()

    myreg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    myreg.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(str(x) for x in args)}m")

    myreg.red = Style(RgbFg(255, 0, 0))
    myreg.bold = Style(Sgr(1))

    myreg.set_eightbit_call(RgbFg)

    assert myreg(1) == myreg.red

# Generated at 2022-06-18 06:25:35.100185
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    fg.set_eightbit_call(RgbFg)

    assert fg(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:25:40.446095
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == "\x1b[38;5;42m"
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"
    assert r("red") == ""



# Generated at 2022-06-18 06:25:42.567342
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-18 06:25:53.892713
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 255), Sgr(1))
    fg.set_eightbit_call(RgbFg)
    fg.set_rgb_call(RgbFg)

    assert fg(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert fg(0, 0, 255) == "\x1b[38;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:26:04.337080
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbFg2(RenderType):
        pass

    class RgbBg2(RenderType):
        pass

    class Sgr2(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:26:21.301786
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    r.set_renderfunc(RenderType, lambda x: f"{x}")

    assert r(144) == "144"
    assert r(10, 42, 255) == "10, 42, 255"

    r.mute()
    assert r(144) == ""
    assert r(10, 42, 255) == ""

    r.unmute()
    assert r(144) == "144"
    assert r(10, 42, 255) == "10, 42, 255"

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    r.set_renderfunc

# Generated at 2022-06-18 06:26:29.993565
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    def render_eightbit(color: int) -> str:
        return f"\x1b[38;5;{color}m"

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(Eightbit, render_eightbit)
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_renderfunc(Sgr, render_sgr)


# Generated at 2022-06-18 06:26:39.158857
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr

    # Create a new register
    r = Register()

    # Add renderfuncs for RgbFg and RgbBg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Add a style attribute
    r.red = Style(RgbFg(255, 0, 0))

    # Set the eightbit-call to RgbFg
    r.set_eightbit_call(RgbFg)

    # Call the register-object with

# Generated at 2022-06-18 06:26:49.604457
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    my_register = MyRegister()
    my_register.set_renderfunc(RgbFg, render_rgb_fg)
    my_register.set_renderfunc(Sgr, render_sgr)

    my_register.red = Style(RgbFg(255, 0, 0))
    my_register.bold = Style(Sgr(1))

    my_register.set_eightbit_call(RgbFg)

   

# Generated at 2022-06-18 06:26:58.876247
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, lambda x: f"{x}")

    assert r(1) == "1"
    assert r(1, 2, 3) == "1"
    assert r("test") == ""

    r.test = Style(RenderType(1))
    assert r("test") == "1"

    r.mute()
    assert r("test") == ""

    r.unmute()
    assert r("test") == "1"

    assert r.as_dict() == {"test": "1"}


# Generated at 2022-06-18 06:27:08.508006
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r

# Generated at 2022-06-18 06:27:17.006127
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, RgbBg, Sgr
    from .register import Register

    # Create a new register object.
    r = Register()

    # Add a render function for Eightbit-calls.
    r.set_eightbit_call(Eightbit)
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")

    # Add a render function for RGB-calls.
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a render function for SGR-calls.

# Generated at 2022-06-18 06:27:27.688006
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;2;255;0;0m"
    assert r(1, bold=True) == "\x1b[38;2;255;0;0m\x1b[1m"

    r.set_eightbit_call(Sgr)


# Generated at 2022-06-18 06:27:37.875232
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

# Generated at 2022-06-18 06:27:49.544157
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbBg)


# Generated at 2022-06-18 06:28:03.436795
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r(1) == "\x1b[38;2;1;0;0m\x1b[1m"
    assert r

# Generated at 2022-06-18 06:28:13.475611
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:28:23.271902
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(1) == r.red
    assert r(2) == r.green

# Generated at 2022-06-18 06:28:34.536586
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr

    class CustomRegister(Register):
        pass

    r = CustomRegister()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:28:42.578573
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg)
    r.set_renderfunc(Sgr, sgr)


# Generated at 2022-06-18 06:28:51.704321
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r(1) == r.red


# Generated at 2022-06-18 06:29:00.557191
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, RgbFg, Sgr

    fg = Register()
    fg.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    fg.red = Style(Eightbit(1), Sgr(1))
    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    fg.set_eightbit_call(RgbFg)


# Generated at 2022-06-18 06:29:09.805212
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    renderfuncs: Renderfuncs = {RgbFg: render_rgb_fg, Sgr: render_sgr}

    fg = Register()
    fg.set

# Generated at 2022-06-18 06:29:20.238015
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbFg2(RenderType):
        pass

    class RgbBg2(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_fg2(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:29:29.087216
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-18 06:29:49.882468
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:29:55.178485
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    from .rendertype import RgbFg, Sgr

    s1 = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:29:58.370922
# Unit test for method __new__ of class Style
def test_Style___new__():
    class TestStyle(Style):
        pass

    style = TestStyle("test")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "test"


# Generated at 2022-06-18 06:30:05.157790
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r.rgb_call(10, 20, 30) == "\x1b[48;2;10;20;30m"



# Generated at 2022-06-18 06:30:14.237264
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()

    # Set renderfuncs
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set rgb_call to RgbFg
    r.set_rgb_call(RgbFg)

    # Set styles
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))

    # Test rgb_call

# Generated at 2022-06-18 06:30:19.578672
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"


# Generated at 2022-06-18 06:30:26.961068
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if the copy method of the Register class works as expected.
    """
    from .rendertype import Sgr

    r1 = Register()
    r1.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r1.bold = Style(Sgr(1))

    r2 = r1.copy()

    assert r1.bold == r2.bold

    r2.bold = Style(Sgr(2))

    assert r1.bold != r2.bold



# Generated at 2022-06-18 06:30:35.919027
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg
    nt = fg.as_namedtuple()
    assert nt.red == '\x1b[38;2;255;0;0m'
    assert nt.green == '\x1b[38;2;0;255;0m'
    assert nt.blue == '\x1b[38;2;0;0;255m'
    assert nt.yellow == '\x1b[38;2;255;255;0m'
    assert nt.magenta == '\x1b[38;2;255;0;255m'
    assert nt.cyan == '\x1b[38;2;0;255;255m'
    assert nt.white == '\x1b[38;2;255;255;255m'
   

# Generated at 2022-06-18 06:30:39.984177
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.test = Style(RgbFg(1, 2, 3), Sgr(1))

    r = TestRegister()
    assert r.as_dict() == {"test": "\x1b[38;2;1;2;3m\x1b[1m"}



# Generated at 2022-06-18 06:30:42.572994
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r.rgb_call == RgbFg



# Generated at 2022-06-18 06:31:13.239565
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()
    assert isinstance(nt, NamedTuple)
    assert nt.red == fg.red
    assert nt.green == fg.green
    assert nt.blue == fg.blue
    assert nt.black == fg.black
    assert nt.white == fg.white
    assert nt.yellow == fg.yellow
    assert nt.magenta == fg.magenta
    assert nt.cyan == fg.cyan
    assert nt.lightgray == fg.lightgray
    assert nt.darkgray == fg.darkgray
    assert nt.lightred == fg.lightred
    assert nt.lightgreen == fg.lightgreen

# Generated at 2022-06-18 06:31:21.313111
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    test_reg = TestRegister()

    test_reg.set_eightbit_call(RenderType)
    test_reg.set_rgb_call(RenderType)

    test_reg.red = Style(RenderType(1, 2, 3))

    assert test_reg(1, 2, 3) == "\x1b[1;2;3m"
    assert test_reg(1) == "\x1b[1;2;3m"
    assert test_reg("red") == "\x1b[1;2;3m"

    test_reg.mute()

    assert test_reg(1, 2, 3) == ""
    assert test_reg(1) == ""
    assert test_reg("red") == ""

    test_reg.unmute()


# Generated at 2022-06-18 06:31:31.303158
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    assert r.as_dict() == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
    }



# Generated at 2022-06-18 06:31:41.017775
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, RgbBg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style(Sgr(1))
    r.bold_red = Style(Sgr(1), RgbFg(255, 0, 0))


# Generated at 2022-06-18 06:31:51.750877
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f

# Generated at 2022-06-18 06:32:02.125341
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.blue = Style(Eightbit(4))
            self.bold = Style(Sgr(1))

    r = TestRegister()
    assert r("red") == "\x1b[38;2;255;0;0m"
    assert r("blue") == "\x1b[38;5;4m"
    assert r(4) == "\x1b[38;5;4m"
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:32:06.369254
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_renderfunc(RenderType, lambda x: x)
    r1.red = Style(RenderType(1))
    r2 = r1.copy()
    assert r1.red == r2.red
    assert r1.red is not r2.red
    assert r1 is not r2


# Generated at 2022-06-18 06:32:07.191821
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:32:16.567291
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, Sgr, EightbitFg, EightbitBg

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_eightbit_fg(n: int) -> str:
        return f"\x1b[38;5;{n}m"


# Generated at 2022-06-18 06:32:26.503666
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(255, 0, 0) == r.red
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:33:40.469443
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    register = Register()
    register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    register.red = Style(RgbFg(255, 0, 0))
    register.bold = Style(Sgr(1))
    register.bold_red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(register.red) == "\x1b[38;2;255;0;0m"
    assert str(register.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:33:43.640251
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.test = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(r.test, Style)
    assert isinstance(r.test, str)
    assert r.test == "\x1b[38;2;1;2;3m\x1b[1m"



# Generated at 2022-06-18 06:33:53.798363
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n):
        return f"\x1b[{n}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))


# Generated at 2022-06-18 06:34:03.268018
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test method copy of class Register.
    """
    from .rendertype import Sgr
    from .register import Register
    from .style import Style

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))
    r.bold_italic = Style(Sgr(1), Sgr(3))

    r2 = r.copy()
    assert r2.bold == r.bold
    assert r2.bold_italic == r.bold_italic

    r.bold = Style(Sgr(2))
    assert r2.bold != r.bold
    assert r2.bold_italic == r.bold_italic


# Generated at 2022-06-18 06:34:06.483032
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:34:13.842329
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:34:24.157741
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr
    from .sty import fg, bg

    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))

    fg_copy = fg.copy()

    assert fg_copy.red == fg.red
    assert fg_copy.green == fg.green

    fg_copy.red = Style(RgbFg(0, 0, 0))

    assert fg_copy.red != fg.red
    assert fg_copy.green == fg.green

    fg_copy.green = Style(RgbFg(0, 0, 0))

    assert fg_copy.red != fg.red
    assert fg_copy.green

# Generated at 2022-06-18 06:34:32.082332
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:34:38.187799
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb_call(RgbBg)
    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-18 06:34:40.753546
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    from sty import fg, bg, ef, rs

    assert isinstance(fg.red, Style)
    assert isinstance(bg.red, Style)
    assert isinstance(ef.bold, Style)
    assert isinstance(rs.all, Style)

