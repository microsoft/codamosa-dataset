

# Generated at 2022-06-18 06:25:05.701667
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.bold == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:25:12.550628
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r1 = Register()
    r1.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r1.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r1.set_rgb_call(RgbFg)
    assert r1(255, 0, 0) == "\x1b[38;2;255;0;0m"

    r1.set_rgb_call(RgbBg)

# Generated at 2022-06-18 06:25:19.609007
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs
    nt = fg.as_namedtuple()
    assert isinstance(nt, NamedTuple)
    assert nt.red == fg.red
    assert nt.blue == fg.blue
    assert nt.green == fg.green
    assert nt.black == fg.black
    assert nt.white == fg.white
    assert nt.cyan == fg.cyan
    assert nt.magenta == fg.magenta
    assert nt.yellow == fg.yellow
    assert nt.lightred == fg.lightred
    assert nt.lightblue == fg.lightblue
    assert nt.lightgreen == fg.lightgreen
    assert nt.lightblack == fg.lightblack

# Generated at 2022-06-18 06:25:31.151116
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:25:40.833943
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)
    fg.set_renderfunc(Sgr, render_sgr)

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:25:52.768783
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if copy of register-object works.
    """
    from .rendertype import Sgr, RgbFg

    r1 = Register()
    r1.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r1.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")

    r1.bold = Style(Sgr(1))
    r1.bold_red = Style(Sgr(1), RgbFg(255, 0, 0))

    r2 = r1.copy()

    assert r1.bold == r2.bold
    assert r1.bold_red == r2.bold_red


# Generated at 2022-06-18 06:25:58.642740
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:26:07.714776
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    fg.set_eightbit_call(RgbFg)

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert fg(255, 0, 0) == fg.red
    assert fg(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert fg(255, 0, 0)

# Generated at 2022-06-18 06:26:13.519501
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 2, 3))
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules == (RgbFg(1, 2, 3),)
    assert str(style) == "\x1b[38;2;1;2;3m"



# Generated at 2022-06-18 06:26:24.381871
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{bm}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:26:34.790097
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def rgb_fg_renderfunc(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def sgr_renderfunc(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg_renderfunc)

# Generated at 2022-06-18 06:26:37.213430
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:26:40.567952
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:51.065954
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg, RgbBg
    from .register import Register

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(Sgr, render_sgr)
    r.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-18 06:26:55.659956
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:27:00.001738
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"


# Generated at 2022-06-18 06:27:09.728620
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"

# Generated at 2022-06-18 06:27:17.836826
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the __new__ method of class Style.
    """
    from sty import fg, bg, ef, rs

    assert isinstance(fg.red, Style)
    assert isinstance(bg.red, Style)
    assert isinstance(ef.red, Style)
    assert isinstance(rs.red, Style)

    assert isinstance(fg.red, str)
    assert isinstance(bg.red, str)
    assert isinstance(ef.red, str)
    assert isinstance(rs.red, str)

    assert str(fg.red) == "\x1b[38;2;255;0;0m"
    assert str(bg.red) == "\x1b[48;2;255;0;0m"

# Generated at 2022-06-18 06:27:28.533725
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(1, 2, 3) == "\x1b[38;2;1;2;3m"

    r.set_rgb_call(RgbBg)

    assert r(1, 2, 3) == "\x1b[48;2;1;2;3m"

# Generated at 2022-06-18 06:27:37.974735
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .sty import Sty

    sty = Sty()
    sty.register_rendertype(RgbFg)
    sty.register_rendertype(Sgr)

    fg = sty.fg
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(fg.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    fg.mute()

    assert str(fg.red) == ""

    fg.unmute()

    assert str(fg.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:27:53.473578
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:28:03.608040
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb_call(RgbBg)
    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Unit

# Generated at 2022-06-18 06:28:13.981585
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Create a new register object
    r = Register()

    # Add a renderfunc for the rendertype Sgr
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Add a style attribute to the register object
    r.bold = Style(Sgr(1))

    # Check if the style attribute is a Style object
    assert isinstance(r.bold, Style)

    # Check if the style attribute is a string
    assert isinstance(r.bold, str)

    # Check if the style attribute is the correct ANSI sequence
    assert str(r.bold) == "\x1b[1m"

    # Check if the style attribute is a Style object
    assert isinstance(r.bold, Style)

    # Check if the style attribute is a string

# Generated at 2022-06-18 06:28:23.550068
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    class RgbFg(RenderType):
        """
        This is a dummy class for testing.
        """

        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        """
        This is a dummy class for testing.
        """

        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb(r: int, g: int, b: int) -> str:
        """
        This is a dummy function for testing.
        """
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:28:26.133690
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:28:37.585678
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .renderfunc import render_rgb_fg, render_rgb_bg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(RgbBg, render_rgb_bg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))
    r.bold = Style(Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.blue == ""
    assert r.bold == ""

    r.unmute()



# Generated at 2022-06-18 06:28:46.668390
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test the method as_dict of class Register.
    """
    from .sty import fg


# Generated at 2022-06-18 06:28:56.102304
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.red == fg.red
    assert nt.red == '\x1b[38;2;255;0;0m'

    nt = bg.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.red == bg.red
    assert nt.red == '\x1b[48;2;255;0;0m'

    nt = ef.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.bold == ef.bold
    assert nt.bold == '\x1b[1m'

    nt

# Generated at 2022-06-18 06:29:01.711947
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute method works as expected.
    """
    from .rendertype import Sgr
    from .renderfunc import render_sgr

    r = Register()
    r.set_renderfunc(Sgr, render_sgr)
    r.bold = Style(Sgr(1))
    r.mute()
    assert r.bold == ""
    r.unmute()
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:29:10.470298
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, Sgr

    # Create a register-object
    r = Register()

    # Set renderfuncs
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    # Set styles
    r.red = Style(RgbFg(255, 0, 0))

# Generated at 2022-06-18 06:29:24.652038
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(Sgr(31))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[31m"

# Generated at 2022-06-18 06:29:31.762211
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    r.red = Style(RgbFg(255, 0, 0))

    assert r.red == "\x1b[38;2;255;0;0m"

    r.mute()

    assert r.red == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m"

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

    r.mute()


# Generated at 2022-06-18 06:29:42.896822
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, RgbFg, RgbBg

    def render_eightbit(code: int) -> str:
        return f"\x1b[38;5;{code}m"

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(Eightbit, render_eightbit)
    r.set_renderfunc(RgbFg, render_rgb)

    r.set_eightbit_call(Eightbit)
    assert r(42) == "\x1b[38;5;42m"

    r.set_eightbit_call(RgbFg)
    assert r(42)

# Generated at 2022-06-18 06:29:45.923079
# Unit test for method __new__ of class Style
def test_Style___new__():
    class TestStyle(Style):
        pass

    s = TestStyle("test")
    assert isinstance(s, str)
    assert isinstance(s, TestStyle)
    assert s == "test"



# Generated at 2022-06-18 06:29:48.914825
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:29:54.437420
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(1, 2, 3) == "\x1b[38;2;1;2;3m"

    r.set_rgb_call(RgbBg)
    assert r(1, 2, 3) == "\x1b[48;2;1;2;3m"

# Generated at 2022-06-18 06:30:00.544025
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    r.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == "\x1b[10;42;255m"

# Generated at 2022-06-18 06:30:11.261429
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style(Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.blue == ""
    assert r

# Generated at 2022-06-18 06:30:17.507312
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(r.red, r.bold)

    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;2;0;0;95m"

# Generated at 2022-06-18 06:30:21.241951
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:30:49.555238
# Unit test for method copy of class Register
def test_Register_copy():
    from sty import fg, bg, ef, rs

    fg_copy = fg.copy()
    assert fg_copy is not fg
    assert fg_copy.red is fg.red
    assert fg_copy.red is not fg.red
    assert fg_copy.red == fg.red

    bg_copy = bg.copy()
    assert bg_copy is not bg
    assert bg_copy.red is bg.red
    assert bg_copy.red is not bg.red
    assert bg_copy.red == bg.red

    ef_copy = ef.copy()
    assert ef_copy is not ef
    assert ef_copy.bold is ef.bold
    assert ef_copy.bold is not ef.bold


# Generated at 2022-06-18 06:30:54.176954
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-18 06:31:01.973023
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(r.red, r.bold)

    r2 = r.copy()

    assert r.red == r2.red
    assert r.bold == r2.bold
    assert r.red_bold == r2.red_bold
    assert r.renderfun

# Generated at 2022-06-18 06:31:11.995368
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))
    r.bold = Style(Sgr(1))


# Generated at 2022-06-18 06:31:20.171770
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    from .rendertype import RgbFg, Sgr

    s1 = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;2;3m\x1b[1m"

    s2 = Style(RgbFg(1, 2, 3), Sgr(1), value="\x1b[38;2;1;2;3m\x1b[1m")
    assert isinstance(s2, Style)
    assert isinstance(s2, str)

# Generated at 2022-06-18 06:31:26.540581
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))
    assert isinstance(r.blue, Style)
    assert isinstance(r.blue, str)
    assert str(r.blue) == "\x1b[38;2;0;0;255m\x1b[1m"


# Generated at 2022-06-18 06:31:35.050111
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")

    r.set_eightbit_call(Eightbit)

    assert r(144) == "\x1b[38;5;144m"



# Generated at 2022-06-18 06:31:43.227829
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:31:54.342073
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr, RgbFg

    r = Register()
    r.renderfuncs.update({Sgr: lambda x: f"\x1b[{x}m", RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"})
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.red.rules == (RgbFg(255, 0, 0), Sgr(1))
    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)



# Generated at 2022-06-18 06:32:04.578332
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Eightbit, RgbFg

    r = Register()
    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)

    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(Eightbit(1))
    r.green = Style(Eightbit(2))
    r.blue = Style(Eightbit(4))

    assert r(1) == "\x1b[38;5;1m"

# Generated at 2022-06-18 06:32:50.800434
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg

    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg



# Generated at 2022-06-18 06:33:00.180770
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.red.rules == (RgbFg(255, 0, 0), Sgr(1))
    assert isinstance(r.red, Style)

# Generated at 2022-06-18 06:33:02.192597
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:33:09.149615
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import EightbitFg, EightbitBg

    r = Register()
    r.set_renderfunc(EightbitFg, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(EightbitBg, lambda x: f"\x1b[48;5;{x}m")

    r.set_eightbit_call(EightbitFg)
    assert r(42) == "\x1b[38;5;42m"

    r.set_eightbit_call(EightbitBg)
    assert r(42) == "\x1b[48;5;42m"



# Generated at 2022-06-18 06:33:17.954230
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:33:29.558125
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr, RgbFg

    r = Register()

    r.red = Style(Sgr(1), RgbFg(255, 0, 0))
    r.blue = Style(Sgr(1), RgbFg(0, 0, 255))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:33:39.131839
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def rgb_fg_render(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def sgr_render(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg_render)
    r.set_renderfunc(Sgr, sgr_render)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:33:48.446535
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if the copy method of the Register class works as expected.
    """
    from .fg import fg
    from .bg import bg
    from .ef import ef
    from .rs import rs

    # Create a new register object
    r = Register()

    # Add some renderfuncs
    r.set_renderfunc(fg, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(bg, lambda x: f"\x1b[48;5;{x}m")
    r.set_renderfunc(ef, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(rs, lambda: f"\x1b[0m")

    # Add some styles

# Generated at 2022-06-18 06:33:54.654242
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(value="\x1b[38;2;1;5;10m\x1b[1m"), Style)
    assert isinstance(Style(value="\x1b[38;2;1;5;10m\x1b[1m"), str)
    assert str(Style(value="\x1b[38;2;1;5;10m\x1b[1m")) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:34:00.311253
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == r.renderfuncs[RgbBg]

