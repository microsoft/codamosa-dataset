

# Generated at 2022-06-18 06:25:02.556971
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg

# Generated at 2022-06-18 06:25:10.870970
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:25:17.794586
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import fg, bg, ef, rs

    # Create a new register
    r = Register()

    # Add renderfuncs for RgbFg and RgbBg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set RgbFg as default rendertype for rgb-calls
    r.set_rgb_call(RgbFg)

    # Set RgbBg as default rendertype for rgb-calls
    r.set_rgb_call(RgbBg)

    #

# Generated at 2022-06-18 06:25:28.396992
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;2;0;0;95m"
    assert r(9) == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-18 06:25:35.502132
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        def __init__(self, *args):
            super().__init__(*args)

        def render(self, *args):
            return "".join(args)

    def test_renderfunc(*args):
        return "".join(args)

    r = Register()
    r.set_renderfunc(TestRenderType, test_renderfunc)
    r.set_eightbit_call(TestRenderType)

    assert r(1, 2, 3) == "123"



# Generated at 2022-06-18 06:25:43.738521
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r(0, 255, 0) == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-18 06:25:55.284680
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def sgr(x):
        return f"\x1b[{x}m"

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg)
    r.set_renderfunc(RgbBg, rgb_bg)
    r.set_renderfunc(Sgr, sgr)


# Generated at 2022-06-18 06:26:05.498165
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Create a new register object
    r = Register()

    # Define a new rendertype
    class RgbFg(RenderType):
        pass

    # Define a new renderfunc
    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    # Add renderfunc to register
    r.set_renderfunc(RgbFg, render_rgb_fg)

    # Set rendertype for RGB-calls
    r.set_rgb_call(RgbFg)

    # Create a new style
    r.orange = Style(RgbFg(1, 5, 10))

    # Call register object with RGB-values

# Generated at 2022-06-18 06:26:16.841146
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb_call(RgbBg)
    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-18 06:26:26.476026
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    fg = Register()

# Generated at 2022-06-18 06:26:41.941127
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:26:52.365717
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbFg2(RenderType):
        pass

    class RgbBg2(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:26:55.324162
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg

    r = Register()
    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg.render



# Generated at 2022-06-18 06:27:01.912110
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{bm}m"

    def render_rgb_ef(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m\x1b[48;2;{r};{g};{bm}m"


# Generated at 2022-06-18 06:27:11.279511
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    # Test default rgb-call
    assert test_register.rgb_call(1, 2, 3) == (1, 2, 3)

    # Test set_rgb_call
    test_register.set_rgb_call(RgbFg)
    assert test_register.rgb_call(1, 2, 3) == "\x1b[38;2;1;2;3m"

    # Test set_rgb_call with wrong rendertype
    test_register.set_rgb_call(RgbBg)
    assert test_register.rgb_call(1, 2, 3) == "\x1b[48;2;1;2;3m"

# Generated at 2022-06-18 06:27:15.623068
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbBg)

    assert r.rgb_call == r.renderfuncs[RgbBg]

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]



# Generated at 2022-06-18 06:27:26.825902
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(42, 42, 42) == "\x1b[38;2;42;42;42m"

    r.set_rgb_call(RgbBg)
    assert r(42, 42, 42) == "\x1b[48;2;42;42;42m"


# Unit

# Generated at 2022-06-18 06:27:36.784967
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: "RgbBg({}, {}, {})".format(r, g, b))
    r.set_renderfunc(RgbFg, lambda r, g, b: "RgbFg({}, {}, {})".format(r, g, b))

    r.set_rgb_call(RgbBg)

    assert r(10, 20, 30) == "RgbBg(10, 20, 30)"

    r.set_rgb_call(RgbFg)

    assert r(10, 20, 30) == "RgbFg(10, 20, 30)"

# Generated at 2022-06-18 06:27:42.289624
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    # Create a new register object.
    r = Register()

    # Add a renderfunc for RgbBg
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set RgbBg as rendertype for rgb-calls.
    r.set_rgb_call(RgbBg)

    # Make a rgb-call.
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"



# Generated at 2022-06-18 06:27:52.984126
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:28:06.724180
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{bm}"

    register = Register()
    register.set_renderfunc(RgbFg, render_rgb_fg)
    register.set_renderfunc(RgbBg, render_rgb_bg)

    register.set_rgb_call(RgbFg)
    assert register(10, 20, 30) == "\x1b[38;2;10;20;30m"


# Generated at 2022-06-18 06:28:18.458772
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    # Create a new register
    r = Register()

    # Add renderfuncs for RgbFg, RgbBg, RgbEf, RgbRs
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbEf, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_render

# Generated at 2022-06-18 06:28:22.265808
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    r = Register()

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == RgbBg

# Generated at 2022-06-18 06:28:33.010533
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    fg = Register()
    f

# Generated at 2022-06-18 06:28:41.815967
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    # Create a new register
    r = Register()

    # Add renderfuncs for RgbFg, RgbBg, RgbEf and RgbRs
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

# Generated at 2022-06-18 06:28:52.187859
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb_call(RgbBg)

    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"


# Unit

# Generated at 2022-06-18 06:29:01.418771
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:29:10.271237
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbEf, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

# Generated at 2022-06-18 06:29:20.318023
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from .renderfunc import render_rgb_bg, render_rgb_fg

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)
    fg.set_renderfunc(RgbBg, render_rgb_bg)

    fg.set_rgb_call(RgbFg)
    assert fg(10, 20, 30) == "\x1b[38;2;10;20;30m"

    fg.set_rgb_call(RgbBg)
    assert fg(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Generated at 2022-06-18 06:29:26.383577
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_rgb_call(RgbFg)

    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb_call(RgbBg)

    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-18 06:29:45.180373
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    reg = Register()

    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    reg.set_rgb_call(RgbFg)

    assert reg(10, 20, 30) == "\x1b[38;2;10;20;30m"

    reg.set_rgb_call(RgbBg)

    assert reg(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:29:47.164564
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg

# Generated at 2022-06-18 06:29:53.551845
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:30:04.129995
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    def rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m"

    def rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{bm}m"

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg)
    r.set_renderfunc(RgbBg, rgb_bg)

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)

# Generated at 2022-06-18 06:30:08.986217
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg

    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

# Generated at 2022-06-18 06:30:16.407866
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r(0, 255, 0) == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-18 06:30:21.895136
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_rgb_call(RgbFg)
    r.set_renderfunc(RgbFg, lambda r, g, b: f"{r},{g},{b}")

    assert r(10, 20, 30) == "10,20,30"



# Generated at 2022-06-18 06:30:28.307785
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == r.renderfuncs[RgbBg]



# Generated at 2022-06-18 06:30:36.813088
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    reg = Register()
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    reg.set_rgb_call(RgbBg)
    assert reg(10, 20, 30) == "\x1b[48;2;10;20;30m"

    reg.set_rgb_call(RgbFg)
    assert reg(10, 20, 30) == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-18 06:30:46.059441
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

    r.set_rgb_call(RgbBg)
    assert r(255, 0, 0) == "\x1b[48;2;255;0;0m"


# Unit

# Generated at 2022-06-18 06:31:17.922019
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)

    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:31:25.168251
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs
    from .renderfunc import render_rgb_fg, render_rgb_bg, render_rgb_ef, render_rgb_rs

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(RgbBg, render_rgb_bg)
    r.set_renderfunc(RgbEf, render_rgb_ef)
    r.set_renderfunc(RgbRs, render_rgb_rs)

    r.set_rgb_call(RgbFg)
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb

# Generated at 2022-06-18 06:31:36.926150
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbFg2(RenderType):
        pass

    class RgbBg2(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_fg2(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:31:44.427587
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    test_register.set_rgb_call(RgbFg)

    assert test_register(10, 20, 30) == "\x1b[38;2;10;20;30m"

    test_register.set_rgb_call(RgbBg)


# Generated at 2022-06-18 06:31:56.076099
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, RgbEf

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbEf, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)


# Generated at 2022-06-18 06:32:01.531671
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == r.renderfuncs[RgbBg]



# Generated at 2022-06-18 06:32:06.795161
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_rgb_call(RgbFg)

    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"



# Generated at 2022-06-18 06:32:15.972085
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_ef(r: int, g: int, b: int) -> str:
        return f"\x1b[38;5;{r};{g};{b}m"


# Generated at 2022-06-18 06:32:22.264005
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == r.renderfuncs[RgbBg]

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]



# Generated at 2022-06-18 06:32:30.425609
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"
    assert r(10, 20, 30) == r.rgb_call(10, 20, 30)

    r.set_rgb_call(RgbBg)

# Generated at 2022-06-18 06:33:33.972389
# Unit test for method copy of class Register
def test_Register_copy():

    # Create a new register-object
    r = Register()

    # Add a style to the register-object
    r.test = Style(RgbFg(1, 2, 3))

    # Make a copy of the register-object
    r2 = r.copy()

    # Check if the copy has the same style as the original
    assert r2.test == r.test

    # Change the style of the original register-object
    r.test = Style(RgbFg(4, 5, 6))

    # Check if the copy has the same style as the original
    assert r2.test != r.test

# Generated at 2022-06-18 06:33:40.961647
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    d = r.as_dict()
    assert d == {"red": "\x1b[38;2;255;0;0m", "green": "\x1b[38;2;0;255;0m", "blue": "\x1b[38;2;0;0;255m"}


# Generated at 2022-06-18 06:33:46.956134
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_renderfunc(RenderType, lambda x: x)
    r1.set_eightbit_call(RenderType)
    r1.set_rgb_call(RenderType)
    r1.red = Style(RenderType(1))
    r1.blue = Style(RenderType(2))
    r1.green = Style(RenderType(3))
    r1.mute()

    r2 = r1.copy()

    assert r1.renderfuncs == r2.renderfuncs
    assert r1.is_muted == r2.is_muted
    assert r1.eightbit_call == r2.eightbit_call
    assert r1.rgb_call == r2.rgb_call
    assert r1.red == r2.red

# Generated at 2022-06-18 06:33:56.820920
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg


# Generated at 2022-06-18 06:34:04.493374
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r2 = r.copy()

    assert r2.red == r.red
    assert r2.blue == r.blue

    r2.red = Style(RgbFg(0, 0, 0), Sgr(1))

    assert r2.red != r.red
    assert r2.blue == r.blue

# Generated at 2022-06-18 06:34:11.413452
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    r2 = r.copy()
    assert r2.red == r.red
    assert r2.green == r.green

    r2.red = Style(RgbFg(0, 0, 0), Sgr(1))
    assert r2.red != r.red
    assert r2.green == r.green



# Generated at 2022-06-18 06:34:22.021458
# Unit test for constructor of class Style
def test_Style():
    assert Style("test") == "test"
    assert Style("test", "test") == "testtest"
    assert Style("test", "test", value="test") == "testtest"
    assert Style("test", "test", value="testtest") == "testtest"
    assert Style("test", "test", value="testtesttest") == "testtesttest"
    assert Style("test", "test", value="testtesttesttest") == "testtesttesttest"
    assert Style("test", "test", value="testtesttesttesttest") == "testtesttesttesttest"
    assert Style("test", "test", value="testtesttesttesttesttest") == "testtesttesttesttesttest"
    assert Style("test", "test", value="testtesttesttesttesttesttest") == "testtesttesttesttesttesttest"

# Generated at 2022-06-18 06:34:30.863685
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

   

# Generated at 2022-06-18 06:34:35.278256
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(Eightbit(2), Sgr(1))


# Generated at 2022-06-18 06:34:39.836744
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .sty import fg

    fg.red = Style(RgbFg(255, 0, 0))
    fg.red_bold = Style(RgbFg(255, 0, 0), Sgr(1))

    fg.mute()

    assert fg.red == ""
    assert fg.red_bold == ""

    fg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert fg.red_bold == "\x1b[38;2;255;0;0m\x1b[1m"