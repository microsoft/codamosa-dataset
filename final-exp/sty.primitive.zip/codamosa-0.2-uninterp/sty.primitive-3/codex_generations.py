

# Generated at 2022-06-18 06:24:50.244136
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:24:52.049465
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg



# Generated at 2022-06-18 06:24:58.819616
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, RgbFg

    r = Register()
    r.set_renderfunc(Eightbit, lambda x: "Eightbit")
    r.set_renderfunc(RgbFg, lambda r, g, b: "RgbFg")
    r.set_eightbit_call(Eightbit)

    assert r(42) == "Eightbit"
    assert r(10, 42, 255) == "RgbFg"


# Generated at 2022-06-18 06:25:09.202546
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    test_register = TestRegister()
    test_register.set_eightbit_call(RgbFg)
    test_register.set_rgb_call(RgbFg)
    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    test_register.red = Style(RgbFg(255, 0, 0))
    test_register.blue = Style(RgbFg(0, 0, 255))
    test_

# Generated at 2022-06-18 06:25:15.728673
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, RgbBg, Sgr

    def render_eightbit(code: int) -> str:
        return f"\x1b[38;5;{code}m"

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    reg = Register()
    reg.set_renderfunc(Eightbit, render_eightbit)
    reg.set_renderfunc(RgbFg, render_rgb)
    reg.set_renderfunc(RgbBg, render_rgb)
    reg.set

# Generated at 2022-06-18 06:25:21.303115
# Unit test for method mute of class Register
def test_Register_mute():

    # Create a new register
    r = Register()

    # Add some styles
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))

    # Mute the register
    r.mute()

    # Check if the styles are empty
    assert r.red == ""
    assert r.green == ""

    # Unmute the register
    r.unmute()

    # Check if the styles are not empty
    assert r.red != ""
    assert r.green != ""



# Generated at 2022-06-18 06:25:31.333027
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:25:40.947265
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    test_register.red = Style(RgbFg(255, 0, 0))
    test_register.green = Style(RgbFg(0, 255, 0))

# Generated at 2022-06-18 06:25:52.812833
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    # Create a new register object
    reg = Register()

    # Add renderfuncs for RgbBg and RgbFg
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set RgbBg as rendertype for rgb-calls
    reg.set_rgb_call(RgbBg)

    # Create a style with RgbFg
    reg.test_style = Style(RgbFg(10, 20, 30))

    #

# Generated at 2022-06-18 06:26:03.215275
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_ef(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:26:17.646974
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg

    fg = Register()
    fg.red = Style(Sgr(1), RgbFg(255, 0, 0))
    fg.mute()

    assert fg.red == ""

    fg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:26:27.142951
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.green == ""

    r.unmute()


# Generated at 2022-06-18 06:26:34.650424
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.bold_red = Style(r.bold, r.red)

    assert str(r.bold_red) == "\x1b[1m\x1b[38;2;255;0;0m"

    r.mute()

    assert str(r.bold_red) == ""

    r.un

# Generated at 2022-06-18 06:26:42.971688
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: x)
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.red = Style(RenderType(1))
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "1"
    assert r.red == r(1)
    assert r.red == r("red")
    assert r.red == r(1, 2, 3)

# Generated at 2022-06-18 06:26:52.931611
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg, RgbBg
    from .register import Register

    # Create a new register
    r = Register()

    # Add some styles
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style(Sgr(1))

    # Mute the register
    r.mute()

    # Check if styles are empty
    assert r.red == ""
    assert r.blue == ""
    assert r.bold == ""

    # Unmute the register
    r.unmute()

    # Check if styles are not empty
    assert r.red != ""
    assert r.blue != ""
    assert r.bold != ""

# Generated at 2022-06-18 06:26:57.784860
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .sty import sty

    sty.fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    sty.fg.mute()
    sty.fg.unmute()
    assert sty.fg.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:27:06.933168
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:27:15.697457
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    r.mute()

    assert str(r.red) == ""

    r.unmute()


# Generated at 2022-06-18 06:27:26.953800
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.blue = Style(RgbFg(0, 0, 255))
            self.bold = Style(Sgr(1))

    r = TestRegister()
    r.mute()
    assert r.red == ""
    assert r.blue == ""
    assert r.bold == ""

    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.blue == "\x1b[38;2;0;0;255m"
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:27:37.240727
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:27:51.667356
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:28:02.570705
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test method set_renderfunc of class Register.
    """
    from .rendertype import RgbFg, Sgr

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:28:06.537685
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    s = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:28:18.415433
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_ef(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_rs(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    reg = Register()
    reg.set

# Generated at 2022-06-18 06:28:25.737957
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if the copy method of the Register class works as expected.
    """
    from sty import fg, bg, ef, rs

    fg_copy = fg.copy()
    bg_copy = bg.copy()
    ef_copy = ef.copy()
    rs_copy = rs.copy()

    assert fg_copy is not fg
    assert bg_copy is not bg
    assert ef_copy is not ef
    assert rs_copy is not rs

    assert fg_copy.renderfuncs is fg.renderfuncs
    assert bg_copy.renderfuncs is bg.renderfuncs
    assert ef_copy.renderfuncs is ef.renderfuncs
    assert rs_copy.renderfuncs is rs.renderfuncs

    assert fg_

# Generated at 2022-06-18 06:28:35.902151
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    nt = r.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"
    assert nt.blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-18 06:28:40.344739
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Create a new register object
    r = Register()

    # Create a new style object
    s = Style(RgbFg(1, 2, 3))

    # Set the style object as attribute of the register object
    r.test = s

    # Check if the attribute is set correctly
    assert r.test == "\x1b[38;2;1;2;3m"

    # Check if the attribute is of type Style
    assert isinstance(r.test, Style)

    # Check if the attribute is of type str
    assert isinstance(r.test, str)

    # Check if the attribute is of type Style
    assert isinstance(r.test, Style)

    # Check if the attribute is of type str
    assert isinstance(r.test, str)

    # Check if the attribute is of type Style
    assert isinstance

# Generated at 2022-06-18 06:28:51.301551
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()

    assert nt.red == fg.red
    assert nt.blue == fg.blue
    assert nt.green == fg.green
    assert nt.orange == fg.orange
    assert nt.yellow == fg.yellow
    assert nt.lightgray == fg.lightgray
    assert nt.darkgray == fg.darkgray
    assert nt.lightred == fg.lightred
    assert nt.lightgreen == fg.lightgreen
    assert nt.lightyellow == fg.lightyellow
    assert nt.lightblue == fg.lightblue
    assert nt.lightmagenta == fg.lightmagenta
    assert nt.lightcyan == f

# Generated at 2022-06-18 06:28:59.840524
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.r = r
            self.g = g
            self.b = b

        def __repr__(self):
            return f"RgbFg({self.r}, {self.g}, {self.b})"

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.code = code

        def __repr__(self):
            return f"Sgr({self.code})"

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:29:09.612002
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:29:27.890796
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    s = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s.rules == (RgbFg(1, 2, 3), Sgr(1))
    assert str(s) == "\x1b[38;2;1;2;3m\x1b[1m"



# Generated at 2022-06-18 06:29:37.929964
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr

    # Create register
    r = Register()

    # Add renderfuncs
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    # Define styles
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

# Generated at 2022-06-18 06:29:43.108595
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the __new__ method of the Style class.
    """
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:29:51.313786
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    r = Register()
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(Eightbit(1), Sgr(1))
    r.green = Style(Eightbit(2), Sgr(1))
    r.blue = Style(Eightbit(4), Sgr(1))


# Generated at 2022-06-18 06:30:01.468684
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test method as_namedtuple of class Register.
    """
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.black == "\x1b[38;5;16m"
    assert nt.white == "\x1b[38;5;231m"
    assert nt.red == "\x1b[38;5;9m"
    assert nt.green == "\x1b[38;5;10m"
    assert nt.blue == "\x1b[38;5;12m"
    assert nt.yellow == "\x1b[38;5;11m"

# Generated at 2022-06-18 06:30:12.061798
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))

    r = TestRegister()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    assert r("red") == "\x1b[38;2;255;0;0m"
    assert r("green") == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-18 06:30:16.760731
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .sty import fg

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    fg.blue = Style(RgbFg(10, 5, 1), Sgr(1))

    assert fg.as_dict() == {"orange": "\x1b[38;2;1;5;10m\x1b[1m", "blue": "\x1b[38;2;10;5;1m\x1b[1m"}



# Generated at 2022-06-18 06:30:27.075118
# Unit test for method copy of class Register
def test_Register_copy():
    from . import fg, bg, ef, rs
    from .rendertype import RgbFg, RgbBg, Sgr

    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    bg.red = Style(RgbBg(255, 0, 0))
    bg.green = Style(RgbBg(0, 255, 0))
    bg.blue = Style(RgbBg(0, 0, 255))

    ef.bold = Style(Sgr(1))
    ef.italic = Style(Sgr(3))
    ef.underline = Style(Sgr(4))

   

# Generated at 2022-06-18 06:30:34.459042
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:30:38.243316
# Unit test for constructor of class Style
def test_Style():
    # Test for correct type
    assert isinstance(Style("test"), Style)
    assert isinstance(Style("test"), str)

    # Test for correct value
    assert str(Style("test")) == "test"

    # Test for correct rules
    assert Style("test", "test2").rules == ("test", "test2")

    # Test for correct rules
    assert Style("test", "test2").rules == ("test", "test2")

# Generated at 2022-06-18 06:31:12.756818
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.green = Style(RgbFg(0, 255, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert fg.as_dict() == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
    }


# Unit test

# Generated at 2022-06-18 06:31:20.864295
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
    }



# Generated at 2022-06-18 06:31:26.965332
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr, RgbFg, RgbBg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))

# Generated at 2022-06-18 06:31:31.435841
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .renderfunc import render_sgr

    r = Register()
    r.set_renderfunc(Sgr, render_sgr)
    r.bold = Style(Sgr(1))
    r.mute()

    assert r.bold == ""


# Generated at 2022-06-18 06:31:40.718460
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m",
                           "green": "\x1b[38;2;0;255;0m\x1b[1m",
                           "blue": "\x1b[38;2;0;0;255m\x1b[1m"}



# Generated at 2022-06-18 06:31:51.629307
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    # Set renderfuncs
    r.set_renderfunc(RenderType, lambda x: x)
    r.set_renderfunc(RenderType, lambda x: x)

    # Set eightbit-call
    r.set_eightbit_call(RenderType)

    # Set rgb-call
    r.set_rgb_call(RenderType)

    # Set style
    r.test = Style(RenderType(1))

    # Test eightbit-call
    assert r(1) == "1"

    # Test rgb-call
    assert r(1, 2, 3) == (1, 2, 3)

    # Test style
    assert r.test == "1"

    # Test muted
    r.mute()

# Generated at 2022-06-18 06:31:59.408565
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test if mute method works as expected.
    """
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))

    r = TestRegister()
    assert str(r.red) == "\x1b[38;2;255;0;0m"
    r.mute()
    assert str(r.red) == ""
    r.unmute()
    assert str(r.red) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:32:08.490987
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    renderfuncs: Renderfuncs = {
        RgbFg: render_rgb_fg,
        Sgr: render_sgr,
    }

    r = Register()

# Generated at 2022-06-18 06:32:19.672299
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
    }


#

# Generated at 2022-06-18 06:32:28.349193
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from .renderfunc import rgb_bg, rgb_fg

    # Create a new register.
    r = Register()

    # Set renderfuncs for RgbBg and RgbFg.
    r.set_renderfunc(RgbBg, rgb_bg)
    r.set_renderfunc(RgbFg, rgb_fg)

    # Set rgb_call to RgbBg.
    r.set_rgb_call(RgbBg)

    # Check if rgb_call is set to RgbBg.
    assert r.rgb_call == rgb_bg

    # Set rgb_call to RgbFg.
    r.set_rgb_call(RgbFg)

    # Check if rgb_call is set to RgbFg

# Generated at 2022-06-18 06:33:19.845473
# Unit test for method mute of class Register
def test_Register_mute():

    # Create a new register object
    r = Register()

    # Create a new style
    r.red = Style(RgbFg(255, 0, 0))

    # Check if style is rendered
    assert str(r.red) == "\x1b[38;2;255;0;0m"

    # Mute register
    r.mute()

    # Check if style is not rendered
    assert str(r.red) == ""

    # Unmute register
    r.unmute()

    # Check if style is rendered
    assert str(r.red) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:33:25.882048
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    r.renderfuncs[RenderType] = lambda x: f"{x}"

    assert r(42) == "42"
    assert r(10, 42, 255) == "(10, 42, 255)"



# Generated at 2022-06-18 06:33:35.294040
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg
    from .register import Register

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(Sgr(1), RgbFg(255, 0, 0))
    r.blue = Style(Sgr(1), RgbFg(0, 0, 255))

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()


# Generated at 2022-06-18 06:33:44.311036
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test method as_namedtuple of class Register.
    """
    from .register import fg, bg, ef, rs

    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    bg.red = Style(RgbBg(255, 0, 0))
    bg.green = Style(RgbBg(0, 255, 0))
    bg.blue = Style(RgbBg(0, 0, 255))

    ef.bold = Style(Sgr(1))
    ef.underline = Style(Sgr(4))
    ef.blink = Style(Sgr(5))



# Generated at 2022-06-18 06:33:47.624890
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:33:53.426578
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-18 06:34:00.093914
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, lambda x: x)
    r.mute()
    r.unmute()

    r2 = r.copy()

    assert r2.renderfuncs == r.renderfuncs
    assert r2.is_muted == r.is_muted
    assert r2.eightbit_call == r.eightbit_call
    assert r2.rgb_call == r.rgb_call

# Generated at 2022-06-18 06:34:10.228359
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    # Create a new register-object
    r = TestRegister()

    # Add a new style to the register
    r.test = Style(RgbFg(1, 2, 3), Sgr(1))

    # Check if the new style is a Style-object
    assert isinstance(r.test, Style)

    # Check if the new style is a str-object
    assert isinstance(r.test, str)

    # Check if the new style is a str-object
    assert str(r.test) == "\x1b[38;2;1;2;3m\x1b[1m"

    # Check if the new style is a str-object
    assert r.test == "\x1b[38;2;1;2;3m\x1b[1m"

# Generated at 2022-06-18 06:34:17.303772
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import Sgr, RgbFg

    style = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "\x1b[38;2;1;2;3m\x1b[1m"
    assert style.rules == (RgbFg(1, 2, 3), Sgr(1))



# Generated at 2022-06-18 06:34:23.662407
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == "\x1b[38;2;1;5;10m\x1b[1m"
