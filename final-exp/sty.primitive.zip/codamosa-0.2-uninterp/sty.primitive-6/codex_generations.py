

# Generated at 2022-06-18 06:24:58.289153
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-18 06:25:00.216245
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:25:01.605240
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:02.237231
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:10.757928
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a new register
    class MyRegister(Register):
        pass

    # Create a new rendertype
    class MyRenderType(RenderType):
        pass

    # Create a new renderfunc
    def my_renderfunc(x):
        return f"{x}"

    # Create a new style
    my_style = Style(MyRenderType(42))

    # Create a new register-object
    my_register = MyRegister()

    # Add the new renderfunc to the register-object
    my_register.set_renderfunc(MyRenderType, my_renderfunc)

    # Set the new rendertype as the rendertype for 8bit-calls
    my_register.set_eightbit_call(MyRenderType)

    # Set the new rendertype as the rendertype for rgb-calls
    my_register.set_rgb_

# Generated at 2022-06-18 06:25:17.728556
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(Eightbit(1), Sgr(1))
    r.orange = Style(RgbFg(1, 5, 10), Sgr(1))


# Generated at 2022-06-18 06:25:20.435303
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:24.186962
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:35.413184
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda code: f"\x1b[{code}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

# Generated at 2022-06-18 06:25:38.856228
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:49.632318
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:25:53.564435
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.mute()

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.unmute()

    assert r(42) == ""
    assert r(10, 42, 255) == ""



# Generated at 2022-06-18 06:26:03.257824
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == "\x1b[38;2;1;5;10m\x1b[1m"
    assert str(Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m")) == "\x1b[38;2;1;5;10m\x1b[1m"


# Generated at 2022-06-18 06:26:10.166987
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:26:17.947507
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    assert r.renderfuncs[RgbFg] == render_rgb_fg
    assert r.renderfuncs[Sgr] == render_sgr



# Generated at 2022-06-18 06:26:27.434382
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.red_bold = Style(r.red, r.bold)

    assert str(r.red_bold) == "\x1b[38;2;255;0;0m\x1b[1m"

    r.mute()

    assert str(r.red_bold)

# Generated at 2022-06-18 06:26:34.393518
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test if as_namedtuple returns a namedtuple with the correct attributes.
    """
    from .register import fg
    from .rendertype import Sgr

    fg.red = Style(Sgr(31))
    fg.green = Style(Sgr(32))
    fg.blue = Style(Sgr(34))

    nt = fg.as_namedtuple()

    assert hasattr(nt, "red")
    assert hasattr(nt, "green")
    assert hasattr(nt, "blue")

    assert nt.red == "\x1b[31m"
    assert nt.green == "\x1b[32m"
    assert nt.blue == "\x1b[34m"

# Generated at 2022-06-18 06:26:45.368208
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.red = Style(RenderType(42))
    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == "\x1b[10;42;255m"
    assert r("red") == "\x1b[42m"

    r.mute()
    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.unmute()

# Generated at 2022-06-18 06:26:56.046639
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"

# Generated at 2022-06-18 06:26:59.656292
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").value == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()

# Generated at 2022-06-18 06:27:11.401166
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr
    from .renderfunc import sgr_renderfunc

    r = Register()
    r.set_renderfunc(Sgr, sgr_renderfunc)
    r.bold = Style(Sgr(1))
    r.mute()
    assert r.bold == ""
    r.unmute()
    assert r.bold == "\x1b[1m"


# Generated at 2022-06-18 06:27:18.775115
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg
    from .sty import fg, bg

    fg.set_rgb_call(RgbFg)
    bg.set_rgb_call(RgbBg)

    assert fg(42) == "\x1b[38;5;42m"
    assert fg(10, 42, 255) == "\x1b[38;2;10;42;255m"
    assert fg("red") == "\x1b[38;5;9m"

    assert bg(42) == "\x1b[48;5;42m"
    assert bg(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-18 06:27:29.857352
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_eightbit_call(RenderType)
    r1.set_rgb_call(RenderType)
    r1.set_renderfunc(RenderType, lambda x: x)
    r1.mute()
    r1.test = Style(RenderType(1, 2, 3))
    r2 = r1.copy()
    assert r1.renderfuncs == r2.renderfuncs
    assert r1.is_muted == r2.is_muted
    assert r1.eightbit_call == r2.eightbit_call
    assert r1.rgb_call == r2.rgb_call
    assert r1.test == r2.test
    assert r1.test.rules == r2.test.rules
    assert r1.test.value == r

# Generated at 2022-06-18 06:27:33.266594
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr
    s = Style(Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[1m"


# Generated at 2022-06-18 06:27:41.416062
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:27:52.355246
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").value == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == Style(value="\x1b[38;2;1;5;10m\x1b[1m")

# Generated at 2022-06-18 06:27:59.171488
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute method of Register class works.
    """
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.mute()
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:28:03.940398
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:28:14.515403
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from . import fg, bg, ef, rs

    # Create a namedtuple from the fg register
    fg_nt = fg.as_namedtuple()

    # Check if the namedtuple has the same attributes as the fg register
    assert fg_nt.black == fg.black
    assert fg_nt.red == fg.red
    assert fg_nt.green == fg.green
    assert fg_nt.yellow == fg.yellow
    assert fg_nt.blue == fg.blue
    assert fg_nt.magenta == fg.magenta
    assert fg_nt.cyan == fg.cyan
    assert fg_nt.white == fg.white
    assert fg_nt.bright_black == fg.bright_black
    assert f

# Generated at 2022-06-18 06:28:23.919800
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()


# Generated at 2022-06-18 06:28:40.445463
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.renderfuncs.update({RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"})
    r.renderfuncs.update({Sgr: lambda s: f"\x1b[{s}m"})

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:28:51.300815
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    assert r(255, 0, 0) == ""
    assert r(0, 255, 0) == ""
    assert r(0, 0, 255) == ""

    assert r("red") == ""
    assert r("green") == ""
    assert r("blue") == ""

    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)


# Generated at 2022-06-18 06:28:59.789246
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    myreg = MyRegister()
    myreg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    myreg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    myreg.red = Style(RgbFg(255, 0, 0))
    myreg.bold = Style(Sgr(1))

    myreg.set_eightbit_call(RgbFg)

    assert myreg(1) == "\x1b[38;2;0;0;0m"

# Generated at 2022-06-18 06:29:07.192026
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.test = Style(RgbFg(1, 2, 3))
            self.test2 = Style(RgbFg(4, 5, 6))

    r = TestRegister()
    d = r.as_dict()
    assert d == {"test": "\x1b[38;2;1;2;3m", "test2": "\x1b[38;2;4;5;6m"}


# Generated at 2022-06-18 06:29:13.367007
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .sty import fg

    fg.orange = Style(RgbFg(1,5,10), Sgr(1))

    assert fg.orange == '\x1b[38;2;1;5;10m\x1b[1m'

    fg.mute()

    assert fg.orange == ''

    fg.unmute()

    assert fg.orange == '\x1b[38;2;1;5;10m\x1b[1m'

# Generated at 2022-06-18 06:29:23.944956
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

    r.set_rgb_call(RgbBg)
    assert r(255, 0, 0) == "\x1b[48;2;255;0;0m"


# Unit

# Generated at 2022-06-18 06:29:31.358450
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:29:42.479234
# Unit test for method unmute of class Register
def test_Register_unmute():
    from sty import fg, bg, ef, rs
    fg.red = Style(fg.red)
    fg.mute()
    assert fg.red == ""
    fg.unmute()
    assert fg.red == "\x1b[38;2;255;0;0m"
    bg.red = Style(bg.red)
    bg.mute()
    assert bg.red == ""
    bg.unmute()
    assert bg.red == "\x1b[48;2;255;0;0m"
    ef.red = Style(ef.red)
    ef.mute()
    assert ef.red == ""
    ef.unmute()

# Generated at 2022-06-18 06:29:50.881073
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.blue == ""
    assert r.green == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:30:00.913434
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()

    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:30:15.673900
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(x: int) -> str:
        return f"\x1b[{x}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:30:26.289749
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style(Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-18 06:30:35.398680
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"

# Generated at 2022-06-18 06:30:39.395710
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == r.renderfuncs[RgbFg]

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == r.renderfuncs[RgbBg]



# Generated at 2022-06-18 06:30:48.409318
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:30:52.147222
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))
    r.mute()
    assert r.bold == ""
    r.unmute()
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:30:59.897740
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.green == ""
    assert r.blue == ""

    r.unmute

# Generated at 2022-06-18 06:31:09.658410
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a new register object
    class TestRegister(Register):
        pass

    # Add some styles
    test_register = TestRegister()
    test_register.red = Style(RgbFg(255, 0, 0))
    test_register.green = Style(RgbFg(0, 255, 0))
    test_register.blue = Style(RgbFg(0, 0, 255))

    # Add renderfuncs
    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_eightbit_call(RgbFg)
    test_register.set_rgb_call(RgbFg)

    # Test

# Generated at 2022-06-18 06:31:13.343415
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(Sgr(1), RgbFg(255, 0, 0))
    r.blue = Style(Sgr(1), RgbFg(0, 0, 255))

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"


# Generated at 2022-06-18 06:31:14.524989
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:31:24.456439
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import Eightbit

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Eightbit, lambda x: "Eightbit")
    r.set_eightbit_call(Eightbit)

    assert r(42) == "Eightbit"


# Generated at 2022-06-18 06:31:36.165725
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    r.mute()

    assert str(r.red) == ""

    r.unmute()


# Generated at 2022-06-18 06:31:43.951395
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

   

# Generated at 2022-06-18 06:31:47.955508
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:31:58.374422
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:32:07.681869
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    r.mute()
    assert r.red == ""
    assert r.green == ""

    r.unmute()

# Generated at 2022-06-18 06:32:17.546054
# Unit test for constructor of class Style
def test_Style():
    assert Style(RgbFg(1, 2, 3), Sgr(1)) == Style(RgbFg(1, 2, 3), Sgr(1))
    assert Style(RgbFg(1, 2, 3), Sgr(1)) != Style(RgbFg(1, 2, 3), Sgr(2))
    assert Style(RgbFg(1, 2, 3), Sgr(1)) != Style(RgbFg(1, 2, 3))
    assert Style(RgbFg(1, 2, 3), Sgr(1)) != Style(RgbFg(1, 2, 3), Sgr(1), value="")

# Generated at 2022-06-18 06:32:24.069594
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRenderType(RenderType):
        def __init__(self, *args):
            self.args = args

    def test_renderfunc(r, g, b):
        return f"{r}{g}{b}"

    r = Register()
    r.set_renderfunc(TestRenderType, test_renderfunc)

    r.test_style = Style(TestRenderType(1, 2, 3))

    assert r.test_style == "123"



# Generated at 2022-06-18 06:32:32.141500
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute method works as expected.
    """
    from sty import fg, bg, ef, rs

    fg.red = Style(fg.red)
    fg.mute()
    assert fg.red == ""
    fg.unmute()
    assert fg.red == "\x1b[31m"

    bg.red = Style(bg.red)
    bg.mute()
    assert bg.red == ""
    bg.unmute()
    assert bg.red == "\x1b[41m"

    ef.bold = Style(ef.bold)
    ef.mute()
    assert ef.bold == ""
    ef.unmute()
    assert ef.bold == "\x1b[1m"

    rs

# Generated at 2022-06-18 06:32:37.596930
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(r.red, r.bold)

    r_copy = r.copy()

    assert r.red == r_copy.red
    assert r.bold == r_copy.bold
    assert r.red_bold == r_copy.red_bold

    r

# Generated at 2022-06-18 06:33:05.662541
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))
    r.bold_red = Style(Sgr(1), r.red)

    assert str(r.bold) == "\x1b[1m"
    assert str(r.bold_red) == "\x1b[1m\x1b[31m"

    r.mute()

    assert str(r.bold) == ""
    assert str(r.bold_red) == ""

    r.unmute()

    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:33:13.694499
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg
    from .register import Register
    from .renderfunc import render_rgb_fg, render_rgb_bg

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(RgbBg, render_rgb_bg)

    r.set_rgb_call(RgbFg)
    assert r(255, 255, 255) == "\x1b[38;2;255;255;255m"

    r.set_rgb_call(RgbBg)
    assert r(255, 255, 255) == "\x1b[48;2;255;255;255m"

# Generated at 2022-06-18 06:33:24.318582
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import Eightbit, RgbFg, RgbBg

    # Create register
    r = Register()

    # Set renderfuncs
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set eightbit call
    r.set_eightbit_call(Eightbit)

    # Set styles
    r.red = Style(Eightbit(1))
    r.green = Style

# Generated at 2022-06-18 06:33:34.013795
# Unit test for method mute of class Register
def test_Register_mute():
    from sty import fg, bg, ef, rs

    # Create a copy of the default registers.
    fg_copy = fg.copy()
    bg_copy = bg.copy()
    ef_copy = ef.copy()
    rs_copy = rs.copy()

    # Mute the copies.
    fg_copy.mute()
    bg_copy.mute()
    ef_copy.mute()
    rs_copy.mute()

    # Check if the copies are muted.
    assert fg_copy.is_muted
    assert bg_copy.is_muted
    assert ef_copy.is_muted
    assert rs_copy.is_muted

    # Check if the original registers are not muted.
    assert not fg.is_muted


# Generated at 2022-06-18 06:33:43.246839
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from .renderfunc import render_rgb_bg, render_rgb_fg

    # Create a new register-object
    r = Register()

    # Add renderfuncs for RgbBg and RgbFg
    r.set_renderfunc(RgbBg, render_rgb_bg)
    r.set_renderfunc(RgbFg, render_rgb_fg)

    # Set RgbBg as rendertype for rgb-calls
    r.set_rgb_call(RgbBg)

    # Test if rgb-calls return the correct ANSI-sequence
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

    # Set RgbFg as rendertype for rgb-

# Generated at 2022-06-18 06:33:53.350927
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:33:56.497843
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:34:00.167576
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.is_muted == False

# Generated at 2022-06-18 06:34:03.901066
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:34:09.931509
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    from .rendertype import RgbFg, Sgr

    s = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:34:52.374451
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr, EightbitFg, EightbitBg

    # Create a new register
    reg = Register()

    # Add renderfuncs
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    reg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    reg.set_renderfunc(EightbitFg, lambda x: f"\x1b[38;5;{x}m")
    reg.set