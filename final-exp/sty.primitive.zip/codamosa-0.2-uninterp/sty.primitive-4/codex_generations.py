

# Generated at 2022-06-18 06:25:10.358333
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Eightbit, RgbFg

    class MyRegister(Register):
        pass

    reg = MyRegister()
    reg.set_eightbit_call(Eightbit)
    reg.set_rgb_call(RgbFg)

    reg.red = Style(Eightbit(1))
    reg.blue = Style(RgbFg(0, 0, 255))

    assert reg(1) == "\x1b[38;5;1m"
    assert reg("red") == "\x1b[38;5;1m"
    assert reg(0, 0, 255) == "\x1b[38;2;0;0;255m"
    assert reg("blue") == "\x1b[38;2;0;0;255m"

    reg.mute()

    assert reg(1)

# Generated at 2022-06-18 06:25:11.215600
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:12.045602
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:14.137548
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:21.702973
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, RgbBg, Sgr

    def render_eightbit(code: int) -> str:
        return f"\x1b[38;5;{code}m"

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(Eightbit, render_eightbit)
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style

# Generated at 2022-06-18 06:25:33.659164
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a new register object
    r = Register()

    # Create a new rendertype
    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    # Create a new renderfunc for the new rendertype
    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    # Add the new renderfunc to the register object
    r.set_renderfunc(RgbFg, render_rgb_fg)

    # Create a new style
    r.red = Style(RgbFg(255, 0, 0))

    # Test if the style is created correctly


# Generated at 2022-06-18 06:25:34.972147
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:25:38.457074
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:40.833735
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:42.701834
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:25:58.951562
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))
    r.bold = Style(Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.blue == "\x1b[48;2;0;0;255m"
    assert nt.bold == "\x1b[1m"

# Generated at 2022-06-18 06:26:07.895886
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r(1) == "\x1b[38;2;1;0;0m"

# Generated at 2022-06-18 06:26:20.312005
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.bold = Style(Sgr(1))
    assert r.bold == "\x1b[1m"

    r.bold_italic = Style(Sgr(1), Sgr(3))
    assert r.bold_italic == "\x1b[1m\x1b[3m"

    r.bold_italic_underline = Style(Sgr(1), Sgr(3), Sgr(4))
    assert r.bold_italic_underline == "\x1b[1m\x1b[3m\x1b[4m"

    r.bold_italic

# Generated at 2022-06-18 06:26:25.880563
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg

    s1 = Style(Sgr(1), RgbFg(1, 2, 3), value="\x1b[1m\x1b[38;2;1;2;3m")
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1 == "\x1b[1m\x1b[38;2;1;2;3m"



# Generated at 2022-06-18 06:26:33.797914
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(), Style)
    assert isinstance(Style(""), Style)
    assert isinstance(Style("", ""), Style)
    assert isinstance(Style("", "", ""), Style)
    assert isinstance(Style("", "", "", ""), Style)
    assert isinstance(Style("", "", "", "", ""), Style)
    assert isinstance(Style("", "", "", "", "", ""), Style)
    assert isinstance(Style("", "", "", "", "", "", ""), Style)
    assert isinstance(Style("", "", "", "", "", "", "", ""), Style)
    assert isinstance(Style("", "", "", "", "", "", "", "", ""), Style)

# Generated at 2022-06-18 06:26:38.590865
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg

    s1 = Style(Sgr(1), RgbFg(1, 2, 3))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;2;3m\x1b[1m"



# Generated at 2022-06-18 06:26:49.041406
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(Sgr(1), RgbFg(255, 0, 0))
    r.blue = Style(Sgr(1), RgbFg(0, 0, 255))

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"


# Generated at 2022-06-18 06:26:50.258290
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:26:59.382131
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Unit

# Generated at 2022-06-18 06:27:08.019324
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)

    r.red = Style(RgbFg(255, 0, 0))

    assert r.red == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-18 06:27:20.887009
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(str(a) for a in args)}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:27:25.476874
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:27:35.948081
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        def __init__(self, *args):
            self.args = args

    class RgbFg(RenderType):
        def __init__(self, *args):
            self.args = args

    def render_sgr(a1, a2):
        return f"\x1b[{a1};{a2}m"

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    fg = Register()
    fg.set_renderfunc(Sgr, render_sgr)
    fg.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:27:36.588056
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:27:47.011183
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbBg, RgbFg, Sgr

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"


# Generated at 2022-06-18 06:27:55.941889
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, bg, ef, rs, RgbFg, RgbBg, RgbEf, Sgr

    # Create a new register
    my_register = Register()

    # Set renderfuncs for RgbFg, RgbBg and Sgr
    my_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    my_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    my_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Set the rendertype for RGB-calls to

# Generated at 2022-06-18 06:28:05.487032
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "green": "\x1b[38;2;0;255;0m\x1b[1m", "blue": "\x1b[38;2;0;0;255m\x1b[1m"}


# Generated at 2022-06-18 06:28:17.414665
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    # Test with one rule
    s1 = Style(RgbFg(1, 2, 3))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1 == "\x1b[38;2;1;2;3m"

    # Test with two rules
    s2 = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert s2 == "\x1b[38;2;1;2;3m\x1b[1m"

    # Test with three rules

# Generated at 2022-06-18 06:28:25.212407
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:28:30.596520
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import Sgr
    from .register import Register

    r1 = Register()
    r1.red = Style(Sgr(1))
    r2 = r1.copy()
    assert r1.red == r2.red
    assert r1.red is not r2.red
    assert r1 is not r2

# Generated at 2022-06-18 06:28:42.804815
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))
    r.mute()
    assert r.bold == ""
    r.unmute()
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:28:53.213099
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.bold_red = Style(Sgr(1), RgbFg(255, 0, 0))

   

# Generated at 2022-06-18 06:29:02.505137
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbFg2(RenderType):
        pass

    class RgbBg2(RenderType):
        pass

    class Sgr2(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:29:10.918536
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{args[0]}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()


# Generated at 2022-06-18 06:29:21.315380
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:29:29.884346
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.test = Style(RgbFg(1, 2, 3))

    assert isinstance(r.test, Style)
    assert r.test.value == "\x1b[38;2;1;2;3m"
    assert r.test.rules == (RgbFg(1, 2, 3),)

    r.test = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(r.test, Style)
    assert r.test.value == "\x1b[38;2;1;2;3m\x1b[1m"
    assert r.test.rules == (RgbFg(1, 2, 3), Sgr(1))


# Generated at 2022-06-18 06:29:31.261601
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-18 06:29:42.354178
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)
    reg.set_renderfunc(Sgr, render_sgr)

    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:29:50.792125
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-18 06:30:00.063994
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    def my_renderfunc(x: int) -> str:
        return f"\x1b[38;2;{x};{x};{x}m"

    my_register = MyRegister()
    my_register.set_renderfunc(RgbFg, my_renderfunc)
    my_register.set_eightbit_call(RgbFg)

    assert my_register(42) == "\x1b[38;2;42;42;42m"
    assert my_register(42, Sgr(1)) == "\x1b[38;2;42;42;42m\x1b[1m"


# Generated at 2022-06-18 06:30:32.220903
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, EightbitFg, EightbitBg, Sgr
    from .sty import fg, bg, ef, rs

    # Test Eightbit-call
    fg.set_eightbit_call(EightbitFg)
    assert fg(144) == "\x1b[38;5;144m"

    # Test RGB-call
    fg.set_rgb_call(RgbFg)
    assert fg(144, 42, 255) == "\x1b[38;2;144;42;255m"

    # Test attribute-call
    fg.red = Style(RgbFg(255, 0, 0))
    assert fg("red") == "\x1b[38;2;255;0;0m"

    # Test

# Generated at 2022-06-18 06:30:39.688526
# Unit test for constructor of class Style
def test_Style():
    assert Style(RgbFg(1, 5, 10), Sgr(1)) == Style(RgbFg(1, 5, 10), Sgr(1))
    assert Style(RgbFg(1, 5, 10), Sgr(1)) != Style(RgbFg(1, 5, 10), Sgr(2))
    assert Style(RgbFg(1, 5, 10), Sgr(1)) != Style(RgbFg(1, 5, 10))
    assert Style(RgbFg(1, 5, 10), Sgr(1)) != Style(RgbFg(1, 5, 10), Sgr(1), value="")

# Generated at 2022-06-18 06:30:48.684742
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    from .rendertype import Sgr, RgbFg

    s1 = Style(Sgr(1), RgbFg(1, 2, 3))
    s2 = Style(Sgr(1), RgbFg(1, 2, 3), value="\x1b[38;2;1;2;3m\x1b[1m")

    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert str(s1) == "\x1b[38;2;1;2;3m\x1b[1m"

# Generated at 2022-06-18 06:30:56.631996
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .renderfunc import render_sgr

    r = Register()
    r.set_renderfunc(Sgr, render_sgr)
    r.bold = Style(Sgr(1))
    r.bold_italic = Style(Sgr(1), Sgr(3))

    assert str(r.bold) == "\x1b[1m"
    assert str(r.bold_italic) == "\x1b[1m\x1b[3m"

    r.mute()

    assert str(r.bold) == ""
    assert str(r.bold_italic) == ""

    r.unmute()

    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:31:04.794747
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, param: int):
            self.args = (param,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(param: int) -> str:
        return f"\x1b[{param}m"


# Generated at 2022-06-18 06:31:10.909204
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"


# Generated at 2022-06-18 06:31:19.157519
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbBg(0, 0, 255), Sgr(1))
    r.green = Style(RgbBg(0, 255, 0), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.blue == "\x1b[48;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:31:22.675512
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    assert isinstance(fg.as_namedtuple(), NamedTuple)
    assert isinstance(bg.as_namedtuple(), NamedTuple)
    assert isinstance(ef.as_namedtuple(), NamedTuple)
    assert isinstance(rs.as_namedtuple(), NamedTuple)

# Generated at 2022-06-18 06:31:33.968378
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .renderfunc import sgr_renderfunc

    r = Register()
    r.set_renderfunc(Sgr, sgr_renderfunc)
    r.bold = Style(Sgr(1))
    r.bold_italic = Style(Sgr(1), Sgr(3))

    assert str(r.bold) == "\x1b[1m"
    assert str(r.bold_italic) == "\x1b[1m\x1b[3m"

    r.mute()

    assert str(r.bold) == ""
    assert str(r.bold_italic) == ""

    r.unmute()

    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:31:42.403412
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg, RgbBg

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))
            self.bold = Style(Sgr(1))

    r = TestRegister()
    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-18 06:32:10.749312
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg

    s = Style(Sgr(1), RgbFg(1, 2, 3), value="\x1b[1m\x1b[38;2;1;2;3m")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[1m\x1b[38;2;1;2;3m"
    assert s.rules == (Sgr(1), RgbFg(1, 2, 3))


# Generated at 2022-06-18 06:32:16.919832
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test if the __new__ method of class Style works as expected.
    """
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"


# Generated at 2022-06-18 06:32:26.640675
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg, RgbBg

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0), Sgr(1))
            self.green = Style(RgbFg(0, 255, 0), Sgr(1))
            self.blue = Style(RgbFg(0, 0, 255), Sgr(1))
            self.yellow = Style(RgbFg(255, 255, 0), Sgr(1))
            self.magenta = Style(RgbFg(255, 0, 255), Sgr(1))
            self.cyan = Style(RgbFg(0, 255, 255), Sgr(1))

# Generated at 2022-06-18 06:32:31.525735
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .sty import fg

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.mute()
    assert fg.red == ""
    fg.unmute()
    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:32:39.870643
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .renderfuncs import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.mute()

    assert r.red == ""
    assert r.blue == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:32:50.382110
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, Sgr

    # Create a new register object
    r = Register()

    # Define a new style
    r.red = Style(RgbFg(255, 0, 0))

    # Define a new renderfunc
    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    # Add the new renderfunc to the register
    r.set_renderfunc(RgbFg, render_rgb_fg)

    # Test the new style
    assert str(r.red) == "\x1b[38;2;255;0;0m"

    # Test the new renderfunc

# Generated at 2022-06-18 06:32:53.717240
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:33:03.462111
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import Sgr, RgbFg

    # Create a new register
    r = Register()

    # Create a new rendertype
    class NewRenderType(RenderType):
        pass

    # Create a new renderfunc
    def new_renderfunc(*args):
        return "new_renderfunc"

    # Add renderfunc to register
    r.set_renderfunc(NewRenderType, new_renderfunc)

    # Set new rendertype as eightbit_call
    r.set_eightbit_call(NewRenderType)

    # Create a new style
    r.new_style = Style(NewRenderType(1, 2, 3))

    # Check if eightbit_call is set correctly
    assert r.eightbit_call(1, 2, 3) == "new_renderfunc"

    # Check if style is rendered correctly


# Generated at 2022-06-18 06:33:12.084574
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.bold = Style(Sgr(1))

    assert r.bold == "\x1b[1m"

    r.bold = Style(Sgr(1), Sgr(2))

    assert r.bold == "\x1b[1m\x1b[2m"

    r.bold = Style(Sgr(1), Sgr(2), Sgr(3))

    assert r.bold == "\x1b[1m\x1b[2m\x1b[3m"

    r.bold = Style(Sgr(1), Sgr(2), Sgr(3), Sgr(4))


# Generated at 2022-06-18 06:33:15.967431
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"



# Generated at 2022-06-18 06:34:00.721190
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import Sgr

    r = Register()
    r.red = Style(Sgr(1))
    r.green = Style(Sgr(2))
    r.blue = Style(Sgr(3))

    assert r.as_dict() == {"red": "\x1b[1m", "green": "\x1b[2m", "blue": "\x1b[3m"}

# Generated at 2022-06-18 06:34:10.426879
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr

    r = Register()

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

    r.red = Style(RgbFg(255, 0, 0))

    assert r.red == "\x1b[38;2;255;0;0m"

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r.red

# Generated at 2022-06-18 06:34:21.583180
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert str(r.blue) == "\x1b[38;2;0;0;255m\x1b[1m"

    r.mute()


# Generated at 2022-06-18 06:34:30.487901
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    # Create a new register object
    r = Register()

    # Define a render function for RgbBg
    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    # Define a render function for RgbFg
    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    # Add render functions to register
    r.set_renderfunc(RgbBg, render_rgb_bg)
    r.set_renderfunc(RgbFg, render_rgb_fg)

    # Set RgbBg as rendertype for

# Generated at 2022-06-18 06:34:31.744040
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style(value="test")
    assert style == "test"
    assert style.rules == ()


# Generated at 2022-06-18 06:34:37.199945
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr
    from .renderfuncs import render_rgb_fg, render_sgr

    # Create register
    r = Register()

    # Add renderfuncs
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    # Create style
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Test
    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-18 06:34:40.133860
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test method copy of class Register.
    """
    from .rendertype import RgbFg, Sgr

    r1 = Register()
    r1.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r2 = r1.copy()

    assert r1.red == r2.red
    assert r1.red is not r2.red


# Generated at 2022-06-18 06:34:47.142539
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr
    from .style import fg, bg, ef, rs

    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))
    fg.blue = Style(RgbFg(0, 0, 255))
    fg.bold = Style(Sgr(1))
    fg.italic = Style(Sgr(3))
    fg.underline = Style(Sgr(4))
    fg.strikethrough = Style(Sgr(9))

    bg.red = Style(RgbFg(255, 0, 0))
    bg.green = Style(RgbFg(0, 255, 0))

# Generated at 2022-06-18 06:34:56.143330
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"