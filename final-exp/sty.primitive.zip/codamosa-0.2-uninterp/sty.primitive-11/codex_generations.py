

# Generated at 2022-06-18 06:25:05.206568
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a new register object
    r = Register()

    # Add a new style attribute to the register
    r.red = Style(RgbFg(255, 0, 0))

    # Test if the style attribute is set correctly
    assert r.red == "\x1b[38;2;255;0;0m"

    # Test if the register object can be called with a string
    assert r("red") == "\x1b[38;2;255;0;0m"

    # Test if the register object can be called with an 8bit color code
    r.set_eightbit_call(RgbFg)
    assert r(255) == "\x1b[38;2;255;255;255m"

    # Test if the register object can be called with a 24bit color code
    r.set_rgb_call

# Generated at 2022-06-18 06:25:10.124023
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if copy method of class Register works as expected.
    """
    from .rendertype import RgbFg, Sgr

    r1 = Register()
    r1.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r2 = r1.copy()
    r2.red = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r1.red != r2.red

# Generated at 2022-06-18 06:25:11.770233
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.test = Style(RgbFg(1, 2, 3))
    r2 = r.copy()
    assert r2.test == r.test

# Generated at 2022-06-18 06:25:12.779284
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:19.881396
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"


# Generated at 2022-06-18 06:25:31.539397
# Unit test for method unmute of class Register
def test_Register_unmute():
    from sty import fg, bg, ef, rs

    fg.red = Style(fg.red)
    fg.mute()
    assert fg.red == ""
    fg.unmute()
    assert fg.red == "\x1b[38;2;255;0;0m"

    bg.red = Style(bg.red)
    bg.mute()
    assert bg.red == ""
    bg.unmute()
    assert bg.red == "\x1b[48;2;255;0;0m"

    ef.bold = Style(ef.bold)
    ef.mute()
    assert ef.bold == ""
    ef.unmute()
    assert ef.bold == "\x1b[1m"


# Generated at 2022-06-18 06:25:38.338701
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(value="\x1b[38;2;1;5;10m\x1b[1m"), Style)
    assert isinstance(Style(value="\x1b[38;2;1;5;10m\x1b[1m"), str)
    assert str(Style(value="\x1b[38;2;1;5;10m\x1b[1m")) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:25:43.096247
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(r.orange, Style)
    assert isinstance(r.orange, str)
    assert str(r.orange) == "\x1b[38;2;1;5;10m\x1b[1m"


# Generated at 2022-06-18 06:25:53.076190
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test method set_renderfunc of class Register.
    """

    # Create a new register
    r = Register()

    # Define a new rendertype
    class NewRenderType(RenderType):
        pass

    # Define a new renderfunc
    def new_renderfunc(*args):
        return "new_renderfunc"

    # Add the new renderfunc to the register
    r.set_renderfunc(NewRenderType, new_renderfunc)

    # Create a new style with the new rendertype
    r.new_style = Style(NewRenderType())

    # Check if the new renderfunc was used.
    assert str(r.new_style) == "new_renderfunc"

# Generated at 2022-06-18 06:26:03.474556
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_renderfunc(RenderType, lambda x: x)
    r1.set_eightbit_call(RenderType)
    r1.set_rgb_call(RenderType)
    r1.test = Style(RenderType(1))

    r2 = r1.copy()

    assert r1.renderfuncs == r2.renderfuncs
    assert r1.eightbit_call == r2.eightbit_call
    assert r1.rgb_call == r2.rgb_call
    assert r1.test == r2.test
    assert r1.is_muted == r2.is_muted

    r1.test = Style(RenderType(2))
    assert r1.test != r2.test

    r1.mute()
    assert r1

# Generated at 2022-06-18 06:26:10.462133
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr
    from .style import fg

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    fg.blue = Style(RgbFg(10, 20, 30))

    nt = fg.as_namedtuple()

    assert nt.orange == "\x1b[38;2;1;5;10m\x1b[1m"
    assert nt.blue == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-18 06:26:22.201057
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

    r.set_rgb_call(RgbBg)
    assert r(255, 0, 0) == "\x1b[48;2;255;0;0m"


# Unit

# Generated at 2022-06-18 06:26:30.817336
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .style import fg, bg, ef, rs

    # Create a new register
    my_register = Register()

    # Add a new style to the register
    my_register.my_style = Style(RgbFg(10, 20, 30), Sgr(1))

    # Mute the register
    my_register.mute()

    # Check if the style is muted
    assert str(my_register.my_style) == ""

    # Unmute the register
    my_register.unmute()

    # Check if the style is unmuted
    assert str(my_register.my_style) == "\x1b[38;2;10;20;30m\x1b[1m"

    # Mute the register
    my_register

# Generated at 2022-06-18 06:26:40.598253
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.mute()

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.unmute()

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.set_renderfunc(RenderType, lambda x: f"\x1b[38;5;{x}m")

    assert r(42) == "\x1b[38;5;42m"
    assert r(10, 42, 255) == ""


# Generated at 2022-06-18 06:26:51.110904
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:27:00.030146
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .register import fg, bg, ef, rs

    fg.red = Style(RgbFg(255, 0, 0))
    bg.blue = Style(RgbBg(0, 0, 255))
    ef.bold = Style(Sgr(1))
    rs.reset = Style(Sgr(0))

    nt = fg.as_namedtuple()
    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.blue == "\x1b[48;2;0;0;255m"
    assert nt.bold == "\x1b[1m"
    assert nt.reset == "\x1b[0m"

# Generated at 2022-06-18 06:27:10.142144
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg, RgbBg, RgbEf, RgbRs
    from .renderfunc import sgr, rgb_fg, rgb_bg, rgb_ef, rgb_rs

    # Create a new register
    r = Register()

    # Add renderfuncs
    r.set_renderfunc(Sgr, sgr)
    r.set_renderfunc(RgbFg, rgb_fg)
    r.set_renderfunc(RgbBg, rgb_bg)
    r.set_renderfunc(RgbEf, rgb_ef)
    r.set_renderfunc(RgbRs, rgb_rs)

    # Add styles
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

# Generated at 2022-06-18 06:27:17.952716
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

    r.set_rgb_call(RgbBg)

    assert r(255, 0, 0) == "\x1b[48;2;255;0;0m"


# Unit

# Generated at 2022-06-18 06:27:28.624055
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbFg2(RenderType):
        pass

    class RgbBg2(RenderType):
        pass

    class Sgr2(RenderType):
        pass

    def rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:27:36.099552
# Unit test for constructor of class Style
def test_Style():
    """
    Test the constructor of class Style.
    """
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "\x1b[38;2;1;2;3m\x1b[1m"
    assert style.rules == (RgbFg(1, 2, 3), Sgr(1))



# Generated at 2022-06-18 06:27:52.150694
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .renderfunc import render_sgr

    r = Register()
    r.set_renderfunc(Sgr, render_sgr)
    r.bold = Style(Sgr(1))
    r.bold_red = Style(Sgr(1), r.red)

    assert str(r.bold) == "\x1b[1m"
    assert str(r.bold_red) == "\x1b[1m\x1b[31m"

    r.mute()

    assert str(r.bold) == ""
    assert str(r.bold_red) == ""

    r.unmute()

    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:28:00.118557
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "green": "\x1b[38;2;0;255;0m\x1b[1m"}



# Generated at 2022-06-18 06:28:07.951133
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .render import Sgr
    from .rendertype import RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))


# Generated at 2022-06-18 06:28:19.187849
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"

# Generated at 2022-06-18 06:28:26.172679
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:28:37.591505
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:28:44.433790
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg, bg, ef, rs

    d = fg.as_dict()

    assert isinstance(d, dict)
    assert isinstance(d["red"], str)
    assert d["red"] == "\x1b[38;2;255;0;0m"

    d = bg.as_dict()

    assert isinstance(d, dict)
    assert isinstance(d["red"], str)
    assert d["red"] == "\x1b[48;2;255;0;0m"

    d = ef.as_dict()

    assert isinstance(d, dict)
    assert isinstance(d["bold"], str)
    assert d["bold"] == "\x1b[1m"

    d = rs.as_dict()

    assert isinstance(d, dict)
   

# Generated at 2022-06-18 06:28:54.513024
# Unit test for constructor of class Style
def test_Style():
    assert Style(RgbFg(1, 2, 3), Sgr(1)) == Style(RgbFg(1, 2, 3), Sgr(1))
    assert Style(RgbFg(1, 2, 3), Sgr(1)) != Style(RgbFg(1, 2, 3), Sgr(2))
    assert Style(RgbFg(1, 2, 3), Sgr(1)) != Style(RgbFg(1, 2, 3))
    assert Style(RgbFg(1, 2, 3), Sgr(1)) != Style(RgbFg(1, 2, 3), Sgr(1), Sgr(2))

# Generated at 2022-06-18 06:29:03.856755
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:29:11.757671
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:29:30.661891
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:29:41.717853
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))
            self.bold = Style(Sgr(1))
            self.underline = Style(Sgr(4))

    test_register = TestRegister()

    assert test_register.red == "\x1b[38;2;255;0;0m"
    assert test_register.green == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-18 06:29:50.286590
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r.blue == "\x1b[38;2;0;0;255m\x1b[1m"

    r.mute()

    assert r.red == ""


# Generated at 2022-06-18 06:29:54.443514
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg



# Generated at 2022-06-18 06:30:05.133832
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        """
        This rendertype is used to render foreground colors in RGB.
        """

        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        """
        This rendertype is used to render SGR-codes.
        """

        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg

# Generated at 2022-06-18 06:30:10.128315
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:30:17.013774
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(value="\x1b[1m"), Style)
    assert isinstance(Style(value="\x1b[1m"), str)
    assert str(Style(value="\x1b[1m")) == "\x1b[1m"
    assert str(Style(value="\x1b[1m")) == "\x1b[1m"
    assert str(Style(value="\x1b[1m")) == "\x1b[1m"
    assert str(Style(value="\x1b[1m")) == "\x1b[1m"
    assert str(Style(value="\x1b[1m")) == "\x1b[1m"
    assert str(Style(value="\x1b[1m")) == "\x1b[1m"
    assert str

# Generated at 2022-06-18 06:30:27.325769
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m").rules == (RgbFg(1, 5, 10), Sgr(1))
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m").rules == (RgbFg(1, 5, 10), Sgr(1))

# Generated at 2022-06-18 06:30:36.181436
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test method as_namedtuple of class Register.
    """
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"

# Generated at 2022-06-18 06:30:44.342017
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    # Test with one rule
    s1 = Style(RgbFg(1, 2, 3))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;2;3m"

    # Test with two rules
    s2 = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert str(s2) == "\x1b[38;2;1;2;3m\x1b[1m"

    # Test with nested rules

# Generated at 2022-06-18 06:31:17.163142
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test method as_namedtuple of class Register.
    """
    from sty import fg, bg, ef, rs

    fg.red = Style(fg.red)
    fg.green = Style(fg.green)
    fg.blue = Style(fg.blue)

    nt = fg.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.red == fg.red
    assert nt.green == fg.green
    assert nt.blue == fg.blue

# Generated at 2022-06-18 06:31:24.669661
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.set_eightbit_call(RenderType.Sgr)
    r.set_rgb_call(RenderType.RgbFg)
    r.set_renderfunc(RenderType.Sgr, lambda x: x)
    r.set_renderfunc(RenderType.RgbFg, lambda x, y, z: x + y + z)
    r.red = Style(RenderType.Sgr(1))
    r.blue = Style(RenderType.RgbFg(1, 2, 3))
    r.green = Style(RenderType.Sgr(1), RenderType.RgbFg(1, 2, 3))

    r2 = r.copy()

    assert r2.red == r.red
    assert r2.blue == r.blue
    assert r2.green == r

# Generated at 2022-06-18 06:31:36.885010
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:31:44.177799
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:31:55.907527
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if copy of register-object works.
    """
    from sty import fg, bg, ef, rs

    fg_copy = fg.copy()
    bg_copy = bg.copy()
    ef_copy = ef.copy()
    rs_copy = rs.copy()

    assert fg_copy is not fg
    assert bg_copy is not bg
    assert ef_copy is not ef
    assert rs_copy is not rs

    assert fg_copy.renderfuncs is not fg.renderfuncs
    assert bg_copy.renderfuncs is not bg.renderfuncs
    assert ef_copy.renderfuncs is not ef.renderfuncs
    assert rs_copy.renderfuncs is not rs.renderfuncs

    assert fg_

# Generated at 2022-06-18 06:32:05.411273
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import RgbFg, Sgr

    # Create a new register object
    r = Register()

    # Add a renderfunc for RgbFg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a renderfunc for Sgr
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    # Define a style
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Mute the register
    r.mute()

    # Check if the style is muted
    assert r.red == ""

    # Unmute the register
    r.unmute()

   

# Generated at 2022-06-18 06:32:12.185025
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    test_register.red = Style(RgbFg(255, 0, 0))

# Generated at 2022-06-18 06:32:23.351939
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbEf

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbEf, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-18 06:32:31.561702
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()
    assert nt.red == fg.red
    assert nt.green == fg.green
    assert nt.blue == fg.blue
    assert nt.lightred == fg.lightred
    assert nt.lightgreen == fg.lightgreen
    assert nt.lightblue == fg.lightblue
    assert nt.orange == fg.orange
    assert nt.yellow == fg.yellow
    assert nt.lightyellow == fg.lightyellow
    assert nt.lightcyan == fg.lightcyan
    assert nt.lightmagenta == fg.lightmagenta
    assert nt.lightgray == fg.lightgray
    assert nt.white == f

# Generated at 2022-06-18 06:32:36.002383
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    nt = r.as_namedtuple()
    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"
    assert nt.blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-18 06:33:19.922638
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr

    s = Style(Sgr(1), value="\x1b[1m")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[1m"



# Generated at 2022-06-18 06:33:30.591479
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr

    class MyRegister(Register):
        pass

    r = MyRegister()

    r.set_renderfunc(RgbFg, lambda r, g, b: "RgbFg({}, {}, {})".format(r, g, b))
    r.set_renderfunc(RgbBg, lambda r, g, b: "RgbBg({}, {}, {})".format(r, g, b))
    r.set_renderfunc(Sgr, lambda x: "Sgr({})".format(x))

    r.set_eightbit_call(RgbFg)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:33:40.036743
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    my_register = MyRegister()
    my_register.red = Style(RgbFg(255, 0, 0), Sgr(1))
    my_register.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert my_register.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert my_register.blue == "\x1b[38;2;0;0;255m\x1b[1m"

    nt = my_register.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert n

# Generated at 2022-06-18 06:33:49.322801
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Sgr, RgbFg, RgbBg

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbBg(0, 0, 255), Sgr(1))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r(0, 0, 255) == "\x1b[48;2;0;0;255m\x1b[1m"
    assert r("red") == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:33:59.099130
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:34:08.936111
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    fg.bold = Style(Sgr(1))
    fg.italic = Style(Sgr(3))
    fg.underline = Style(Sgr(4))

    fg.bold_red = Style(Sgr(1), RgbFg(255, 0, 0))
    fg.bold_green = Style(Sgr(1), RgbFg(0, 255, 0))

# Generated at 2022-06-18 06:34:15.162271
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg, bg, ef, rs

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert bg.red == "\x1b[48;2;255;0;0m"
    assert ef.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert rs.red == "\x1b[38;2;255;0;0m\x1b[22m"

    fg.mute()
    bg.mute()
    ef.mute()
    rs.mute()

    assert fg.red == ""
    assert bg.red == ""
    assert ef.red == ""
    assert rs.red == ""

    fg.unmute()


# Generated at 2022-06-18 06:34:25.599479
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)

    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:34:33.303784
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"

# Generated at 2022-06-18 06:34:38.972026
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .render import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert str(r.blue) == "\x1b[38;2;0;0;255m\x1b[1m"

    r.mute()

    assert str