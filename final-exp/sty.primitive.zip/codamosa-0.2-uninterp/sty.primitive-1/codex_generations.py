

# Generated at 2022-06-18 06:24:57.663443
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:01.597223
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:10.024893
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    test_register = TestRegister()
    test_register.set_eightbit_call(RenderType)
    test_register.set_rgb_call(RenderType)

    assert test_register(42) == ""
    assert test_register(10, 42, 255) == ""

    test_register.red = Style(RenderType(1, 2, 3))
    assert test_register("red") == "\x1b[1;2;3m"

    test_register.mute()
    assert test_register("red") == ""

    test_register.unmute()
    assert test_register("red") == "\x1b[1;2;3m"

# Generated at 2022-06-18 06:25:16.830400
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r("red") == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r("green") == "\x1b[38;2;0;255;0m\x1b[1m"

# Generated at 2022-06-18 06:25:19.499280
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:20.570420
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:22.505180
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:25.975154
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:29.761560
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:33.752316
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:39.246756
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False
    assert r.eightbit_call == r.rgb_call

# Generated at 2022-06-18 06:25:40.369661
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:25:46.363782
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style(Sgr(1))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:25:53.939982
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    # Test Eightbit-call
    r.set_eightbit_call(RenderType)
    assert r(42) == ""

    # Test RGB-call
    r.set_rgb_call(RenderType)
    assert r(42, 42, 42) == ""

    # Test attribute-call
    r.test = Style(RenderType())
    assert r("test") == ""

    # Test invalid call
    assert r(42, 42) == ""

# Generated at 2022-06-18 06:25:57.442290
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:06.773021
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(Eightbit(1))
    r.blue = Style(Eightbit(4))
    r.green = Style(Eightbit(2))
    r.bold = Style(Sgr(1))

# Generated at 2022-06-18 06:26:18.807494
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))
            self.bold = Style(Sgr(1))

    r = TestRegister()

    assert r(1) == ""
    assert r(255) == ""
    assert r(0, 0, 0) == ""
    assert r("red") == "\x1b[38;2;255;0;0m"
    assert r("green") == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-18 06:26:19.414763
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:26:26.028962
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a new register object
    r = Register()

    # Define a render-function for 8bit-calls
    r.set_eightbit_call(RenderType.Eightbit)

    # Define a render-function for rgb-calls
    r.set_rgb_call(RenderType.RgbFg)

    # Define a render-function for style-calls
    r.set_renderfunc(RenderType.Sgr, lambda x: f"\x1b[{x}m")

    # Define a style
    r.red = Style(RenderType.Sgr(1), RenderType.RgbFg(255, 0, 0))

    # Test 8bit-call
    assert r(42) == "\x1b[38;5;42m"

    # Test rgb-call

# Generated at 2022-06-18 06:26:29.315211
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:40.412457
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class MyRegister(Register):
        pass

    r = MyRegister()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m",
                           "green": "\x1b[38;2;0;255;0m",
                           "blue": "\x1b[38;2;0;0;255m"}



# Generated at 2022-06-18 06:26:50.904418
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightBit, RgbFg

    fg = Register()
    fg.set_eightbit_call(EightBit)
    fg.set_rgb_call(RgbFg)

    fg.red = Style(EightBit(1))
    fg.blue = Style(EightBit(4))
    fg.green = Style(EightBit(2))

    fg.orange = Style(RgbFg(255, 128, 0))
    fg.purple = Style(RgbFg(128, 0, 255))
    fg.yellow = Style(RgbFg(255, 255, 0))

    assert fg(1) == "\x1b[31m"
    assert fg(4) == "\x1b[34m"

# Generated at 2022-06-18 06:26:59.637867
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"



# Generated at 2022-06-18 06:27:04.610793
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg

    s = Style(Sgr(1), RgbFg(1, 5, 10))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:27:08.221711
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:27:16.765210
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr, EightbitFg, EightbitBg

    class TestRegister(Register):
        pass

    test_register = TestRegister()
    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

# Generated at 2022-06-18 06:27:27.368353
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.test = Style(RgbFg(1, 2, 3))

    assert isinstance(r.test, Style)
    assert r.test.rules == (RgbFg(1, 2, 3),)
    assert r.test == "\x1b[38;2;1;2;3m"

    r.test = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(r.test, Style)
    assert r.test.rules == (RgbFg(1, 2, 3), Sgr(1))
    assert r.test == "\x1b[38;2;1;2;3m\x1b[1m"


# Generated at 2022-06-18 06:27:37.604972
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.blue = Style(RgbFg(0, 0, 255))
            self.bold = Style(Sgr(1))
            self.bold_red = Style(RgbFg(255, 0, 0), Sgr(1))

    r = TestRegister()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    assert r("red") == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:27:49.416541
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test the mute method of the Register class.
    """
    from .rendertype import RgbFg, Sgr

    # Create a new register object.
    r = Register()

    # Add a renderfunc for the rendertype RgbFg.
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a renderfunc for the rendertype Sgr.
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Add a style attribute to the register object.
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Test if the style attribute is a Style object.
    assert isinstance

# Generated at 2022-06-18 06:27:57.136601
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))


# Generated at 2022-06-18 06:28:07.359454
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:28:18.683670
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.black == fg.black
    assert nt.red == fg.red
    assert nt.green == fg.green
    assert nt.yellow == fg.yellow
    assert nt.blue == fg.blue
    assert nt.magenta == fg.magenta
    assert nt.cyan == fg.cyan
    assert nt.white == fg.white
    assert nt.black == fg.black
    assert nt.red == fg.red
    assert nt.green == fg.green
    assert nt.yellow == fg.yellow

# Generated at 2022-06-18 06:28:24.007527
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.test = Style(RgbFg(1, 2, 3), Sgr(1))
    r.test2 = Style(RgbFg(4, 5, 6), Sgr(1))

    assert r.as_dict() == {"test": "\x1b[38;2;1;2;3m\x1b[1m", "test2": "\x1b[38;2;4;5;6m\x1b[1m"}

# Generated at 2022-06-18 06:28:35.312723
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:28:39.902873
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)
    fg.set_renderfunc(Sgr, render_sgr)

    fg.red = Style(RgbFg(255, 0, 0))
    fg.bold = Style(Sgr(1))

# Generated at 2022-06-18 06:28:50.091475
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))

    r = TestRegister()
    d = r.as_dict()

    assert d == {
        "red": "\x1b[38;2;255;0;0m",
        "green": "\x1b[38;2;0;255;0m",
        "blue": "\x1b[38;2;0;0;255m",
    }



# Generated at 2022-06-18 06:28:56.059149
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.mute()

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.unmute()

    assert r(42) == ""
    assert r(10, 42, 255) == ""



# Generated at 2022-06-18 06:29:06.106952
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:29:12.549134
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))
    r.bold = Style(Sgr(1))


# Generated at 2022-06-18 06:29:18.697121
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == "\x1b[38;2;1;5;10m\x1b[1m"


# Generated at 2022-06-18 06:29:26.466074
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import Sgr
    from .style import Style

    r = Register()
    r.test = Style(Sgr(1))
    r.test2 = Style(Sgr(2))

    r2 = r.copy()

    assert r2.test == r.test
    assert r2.test2 == r.test2

# Generated at 2022-06-18 06:29:32.674843
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)
    reg.set_renderfunc(Sgr, render_sgr)

    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    reg.green = Style(RgbFg(0, 255, 0), Sgr(1))
    reg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert reg(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:29:44.178040
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    fg = Register()

# Generated at 2022-06-18 06:29:47.947285
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute works.
    """
    from .rendertype import Sgr, RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.red = Style(Sgr(1), RgbFg(255, 0, 0))

    r.mute()

    assert r.red == ""

    r.unmute()

    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:29:48.595742
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:29:49.302557
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:29:58.173509
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:30:02.608408
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"



# Generated at 2022-06-18 06:30:12.608945
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()

    r.set_renderfunc(RgbFg, render_rgb_fg)


# Generated at 2022-06-18 06:30:21.653264
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code):
            self.args = (code,)

    def render_rgb(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code):
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_renderfunc(Sgr, render_sgr)

    r.set_eightbit_call(RgbFg)
    r.set_rgb_call

# Generated at 2022-06-18 06:30:35.254646
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:30:42.103969
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))

    r = TestRegister()
    nt = r.as_namedtuple()
    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"
    assert nt.blue == "\x1b[38;2;0;0;255m"



# Generated at 2022-06-18 06:30:51.023740
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.r = r
            self.g = g
            self.b = b

        def __repr__(self):
            return f"RgbFg({self.r}, {self.g}, {self.b})"

        def __eq__(self, other):
            return (
                isinstance(other, RgbFg)
                and self.r == other.r
                and self.g == other.g
                and self.b == other.b
            )

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.code = code

        def __repr__(self):
            return f"Sgr({self.code})"

# Generated at 2022-06-18 06:30:58.894276
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(RenderType, lambda x: x)

    r.test = Style(RenderType("test"))

    assert r.test == "test"

    r.test = Style(RenderType("test"), RenderType("test"))

    assert r.test == "testtest"

    r.test = Style(Style(RenderType("test")))

    assert r.test == "test"

    r.test = Style(Style(RenderType("test"), RenderType("test")))

    assert r.test == "testtest"

    r.test = Style(Style(Style(RenderType("test"))))

    assert r.test == "test"

    r.test = Style(Style(Style(RenderType("test"), RenderType("test"))))

    assert r

# Generated at 2022-06-18 06:31:08.547306
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))
    r.bold = Style(Sgr(1))


# Generated at 2022-06-18 06:31:12.678714
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda *args: "".join(args))
    r.bold = Style(Sgr(1))
    r.mute()
    assert r.bold == ""
    r.unmute()
    assert r.bold == "1"

# Generated at 2022-06-18 06:31:20.785255
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(r.red, r.bold)

    r.mute()

    assert r.red == ""
    assert r.bold == ""
    assert r.red_bold == ""

    r.unmute()


# Generated at 2022-06-18 06:31:29.942907
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    # Create a new register object
    r = Register()

    # Add renderfuncs for RgbFg and RgbBg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set RgbFg as rendertype for rgb-calls
    r.set_rgb_call(RgbFg)

    # Test rgb-call
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-18 06:31:40.036509
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a new register object
    r = Register()

    # Add a new style to the register
    r.test = Style(RgbFg(1, 2, 3))

    # Test if the style is set
    assert r.test == "\x1b[38;2;1;2;3m"

    # Test if the style is returned when calling the register with the style name
    assert r("test") == "\x1b[38;2;1;2;3m"

    # Test if the style is returned when calling the register with the style name
    assert r("test") == "\x1b[38;2;1;2;3m"

    # Test if the style is returned when calling the register with the style name
    assert r("test") == "\x1b[38;2;1;2;3m"

   

# Generated at 2022-06-18 06:31:43.476270
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.renderfuncs == {}
    assert reg.is_muted == False

# Generated at 2022-06-18 06:32:08.273799
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr, RgbFg, RgbBg, EightbitFg, EightbitBg

    # Create a new register
    r = Register()

    # Add some styles
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    # Mute the register
    r.mute()

    # Check if the styles are empty strings
    assert r.red == ""
    assert r.green == ""
    assert r.blue == ""

    # Unmute the register
    r.unmute()

    # Check if the styles are not empty strings
    assert r.red != ""
    assert r.green != ""
    assert r

# Generated at 2022-06-18 06:32:11.363467
# Unit test for constructor of class Style
def test_Style():
    """
    Test constructor of class Style.
    """
    style = Style(1, 2, 3)
    assert style == ""
    assert style.rules == (1, 2, 3)



# Generated at 2022-06-18 06:32:22.403434
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import Sgr, RgbFg
    from .register import Register

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r2 = r.copy()
    r2.red = Style(RgbFg(0, 255, 0), Sgr(1))

# Generated at 2022-06-18 06:32:29.970663
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.test = Style(RgbFg(1, 2, 3))

    assert isinstance(r.test, Style)
    assert isinstance(r.test, str)
    assert str(r.test) == "\x1b[38;2;1;2;3m"

    r.test = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(r.test, Style)
    assert isinstance(r.test, str)
    assert str(r.test) == "\x1b[38;2;1;2;3m\x1b[1m"


# Generated at 2022-06-18 06:32:38.269799
# Unit test for constructor of class Style
def test_Style():
    assert Style() == ""
    assert Style(value="\x1b[1m") == "\x1b[1m"
    assert Style(value="\x1b[1m", rules=[]) == "\x1b[1m"
    assert Style(value="\x1b[1m", rules=[1, 2, 3]) == "\x1b[1m"
    assert Style(value="\x1b[1m", rules=[1, 2, 3], value="\x1b[1m") == "\x1b[1m"
    assert Style(value="\x1b[1m", rules=[1, 2, 3], value="\x1b[1m", rules=[1, 2, 3]) == "\x1b[1m"

# Generated at 2022-06-18 06:32:48.935300
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg, Sgr

    # Create a new register-object
    r = Register()

    # Add a render-function for the rendertype RgbFg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a render-function for the rendertype RgbBg
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Add a render-function for the rendertype Sgr
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    # Add a style to

# Generated at 2022-06-18 06:32:55.178454
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code):
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.mute()
    assert r.red == ""
    r.unmute()

# Generated at 2022-06-18 06:33:05.249658
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_renderfunc(RenderType, lambda x: x)
    r1.set_eightbit_call(RenderType)
    r1.set_rgb_call(RenderType)
    r1.red = Style(RenderType(1))
    r1.blue = Style(RenderType(2))

    r2 = r1.copy()

    assert r1.red == r2.red
    assert r1.blue == r2.blue
    assert r1.renderfuncs == r2.renderfuncs
    assert r1.eightbit_call == r2.eightbit_call
    assert r1.rgb_call == r2.rgb_call

    r2.red = Style(RenderType(3))
    r2.blue = Style(RenderType(4))


# Generated at 2022-06-18 06:33:13.653405
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class DummyRenderType(RenderType):
        pass

    class DummyRenderType2(RenderType):
        pass

    def renderfunc(x: int) -> str:
        return f"{x}"

    def renderfunc2(x: int) -> str:
        return f"{x}"

    r = Register()
    r.set_renderfunc(DummyRenderType, renderfunc)
    r.set_renderfunc(DummyRenderType2, renderfunc2)

    r.dummy = Style(DummyRenderType(1), DummyRenderType2(2))

    assert r.dummy == "12"

    r.dummy = Style(DummyRenderType(3), DummyRenderType2(4))

    assert r.dummy == "34"



# Generated at 2022-06-18 06:33:24.264514
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"

    r.set_rgb_call(RgbBg)
    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"


# Unit

# Generated at 2022-06-18 06:34:07.201208
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:34:10.239377
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style(value="test")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "test"
    assert style.rules == tuple()


# Generated at 2022-06-18 06:34:15.729783
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    test_register.set_rgb_call(RgbFg)

    assert test_register(10, 42, 255) == "\x1b[38;2;10;42;255m"

    test_register.set_rgb_call(RgbBg)


# Generated at 2022-06-18 06:34:20.782434
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr

    r = Register()
    r.test = Style(Sgr(1))

    assert isinstance(r.test, Style)
    assert isinstance(r.test, str)
    assert str(r.test) == "\x1b[1m"



# Generated at 2022-06-18 06:34:29.818306
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbFgRenderfunc(NamedTuple):
        r: int
        g: int
        b: int

        def __call__(self, r: int, g: int, b: int) -> str:
            return f"\x1b[38;2;{r};{g};{b}m"

    class RgbBgRenderfunc(NamedTuple):
        r: int
        g: int
        b: int

        def __call__(self, r: int, g: int, b: int) -> str:
            return f"\x1b[48;2;{r};{g};{b}m"

   

# Generated at 2022-06-18 06:34:30.827999
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:34:37.322491
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbEf

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_ef(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m\x1b[48;2;{r};{g};{b}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)
    fg.set_r

# Generated at 2022-06-18 06:34:41.133429
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.set_eightbit_call(RgbFg)

    assert r(1) == r.red



# Generated at 2022-06-18 06:34:48.964057
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    # Create a new register object.
    r = Register()

    # Set renderfunc for RgbFg.
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set renderfunc for Sgr.
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Create a style with RgbFg and Sgr.
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Set the rendertype for Eightbit-calls to RgbFg.
    r.set_eightbit_call(RgbFg)

    # Call the