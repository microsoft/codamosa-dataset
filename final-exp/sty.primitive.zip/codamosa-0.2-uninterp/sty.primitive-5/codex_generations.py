

# Generated at 2022-06-18 06:24:53.667406
# Unit test for method unmute of class Register
def test_Register_unmute():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.test = Style(RgbFg(1, 2, 3))

    r = TestRegister()
    assert str(r.test) == "\x1b[38;2;1;2;3m"
    r.mute()
    assert str(r.test) == ""
    r.unmute()
    assert str(r.test) == "\x1b[38;2;1;2;3m"

# Generated at 2022-06-18 06:25:05.303697
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.set_rgb_call(RgbFg)

    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_

# Generated at 2022-06-18 06:25:07.184251
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == RgbBg

# Generated at 2022-06-18 06:25:12.489557
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(1) == r.red
    assert r(4) == r.blue



# Generated at 2022-06-18 06:25:17.106877
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r.rgb_call(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)

    assert r.rgb_call(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:25:27.075847
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg, Sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    fg.set_rgb_call(RgbFg)

    fg.red = Style(RgbFg(255, 0, 0))
    fg.bold = Style(Sgr(1))
    fg.bold_red = Style(fg.bold, fg.red)

    assert fg(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:25:37.942769
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(x: int) -> str:
        return f"\x1b[{x}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:25:42.480930
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        pass

    class TestRegister(Register):
        pass

    def test_renderfunc(code: int) -> str:
        return f"TestRenderType({code})"

    r = TestRegister()
    r.set_renderfunc(TestRenderType, test_renderfunc)
    r.set_eightbit_call(TestRenderType)

    assert r(42) == "TestRenderType(42)"



# Generated at 2022-06-18 06:25:53.852513
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    reg = Register()
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    reg.set_rgb_call(RgbFg)
    assert reg(10, 42, 255) == "\x1b[38;2;10;42;255m"

    reg.set_rgb_call(RgbBg)
    assert reg(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-18 06:26:04.293239
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_fg_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m\x1b[48;2;{r};{g};{b}m"

    register = Register()
    register.set_render

# Generated at 2022-06-18 06:26:20.953126
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:26:29.037766
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)
    reg.set_renderfunc(Sgr, render_sgr)
    reg.set_render

# Generated at 2022-06-18 06:26:35.698921
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg

# Generated at 2022-06-18 06:26:42.648234
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{args[0]}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(1) == r.red
    assert r(1, bold=True) == r.bold + r.red



# Generated at 2022-06-18 06:26:53.055034
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    my_register = MyRegister()

    my_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    my_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    my_register.red = Style(RgbFg(255, 0, 0), Sgr(1))

    my_register.set_eightbit_call(RgbFg)

    assert my_register(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:27:00.839909
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    test_register.red = Style(RgbFg(255, 0, 0))
    test_register.blue = Style(RgbBg(0, 0, 255))

# Generated at 2022-06-18 06:27:10.814642
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    test_register = TestRegister()
    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    test_register.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert test_register.red == "\x1b[38;2;255;0;0m\x1b[1m"

    test_register.set_eightbit_call(RgbFg)


# Generated at 2022-06-18 06:27:13.645032
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r.rgb_call == RgbFg



# Generated at 2022-06-18 06:27:20.134092
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    # Create register
    r = Register()

    # Add renderfuncs
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Set eightbit call
    r.set_eightbit_call(RgbFg)

    # Set style
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Test
    assert r(255, 0, 0) == r.red

# Generated at 2022-06-18 06:27:30.665337
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    r = Register()
    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)

    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(Eightbit(1), Sgr(1))
    r.green = Style(Eightbit(2), Sgr(1))

# Generated at 2022-06-18 06:27:41.532632
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{bm}m"

    def render_rgb_ef(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m\x1b[48;2;{r};{g};{bm}m"


# Generated at 2022-06-18 06:27:52.396722
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    reg = Register()
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    reg.set_rgb_call(RgbBg)

    assert reg(10, 20, 30) == "\x1b[48;2;10;20;30m"
    assert reg(10, 20, 30, bold=True) == "\x1b[48;2;10;20;30m"

    reg.set_rgb_call(RgbFg)

# Generated at 2022-06-18 06:28:03.108512
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(1, 2, 3) == "\x1b[38;2;1;2;3m"
    assert r(1, 2, 3) == r.rgb_call(1, 2, 3)

    r.set_rgb_call(RgbBg)


# Generated at 2022-06-18 06:28:13.015449
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    def render_sgr_fg(code: int) -> str:
        return f"\x1b[38;5;{code}m"

    r = Register()
   

# Generated at 2022-06-18 06:28:23.023597
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"



# Generated at 2022-06-18 06:28:30.027501
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call(1, 2, 3) == "\x1b[38;2;1;2;3m"

    r.set_rgb_call(RgbBg)
    assert r.rgb_call(1, 2, 3) == "\x1b[48;2;1;2;3m"



# Generated at 2022-06-18 06:28:39.918883
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()

# Generated at 2022-06-18 06:28:50.925479
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:28:59.468396
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;2;0;0;0m"
    assert r(255) == "\x1b[38;2;255;255;255m"

# Generated at 2022-06-18 06:29:09.305705
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code):
            self.args = (code,)

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code):
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0))
    r

# Generated at 2022-06-18 06:29:21.617285
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: "RgbFg")
    r.set_renderfunc(RgbBg, lambda r, g, b: "RgbBg")

    assert r.rgb_call(1, 2, 3) == "RgbFg"

    r.set_rgb_call(RgbBg)
    assert r.rgb_call(1, 2, 3) == "RgbBg"



# Generated at 2022-06-18 06:29:30.034061
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    renderfuncs = {RgbFg: render_rgb_fg, Sgr: render_sgr}

    r = Register()


# Generated at 2022-06-18 06:29:41.297047
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbFg2(RenderType):
        pass

    class RgbBg2(RenderType):
        pass

    class Sgr2(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:29:49.668196
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        pass

    class TestRenderType2(RenderType):
        pass

    def test_renderfunc(x):
        return f"test_renderfunc({x})"

    def test_renderfunc2(x):
        return f"test_renderfunc2({x})"

    r = Register()
    r.set_renderfunc(TestRenderType, test_renderfunc)
    r.set_renderfunc(TestRenderType2, test_renderfunc2)

    r.set_eightbit_call(TestRenderType)
    assert r(42) == "test_renderfunc(42)"

    r.set_eightbit_call(TestRenderType2)
    assert r(42) == "test_renderfunc2(42)"



# Generated at 2022-06-18 06:29:58.877511
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    # Create register object
    r = TestRegister()

    # Set renderfuncs for RgbBg and RgbFg
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set rgb-call to RgbBg
    r.set_rgb_call(RgbBg)

    # Create style attributes
    r.red = Style(RgbFg(255, 0, 0))

# Generated at 2022-06-18 06:30:04.117814
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == RgbBg

# Generated at 2022-06-18 06:30:13.554315
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:30:22.961372
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"



# Generated at 2022-06-18 06:30:33.331709
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .render import render_rgb_fg, render_rgb_bg, render_sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)
    fg.set_renderfunc(RgbBg, render_rgb_bg)
    fg.set_renderfunc(Sgr, render_sgr)

    fg.red = Style(RgbFg(255, 0, 0))
    fg.blue = Style(RgbFg(0, 0, 255))
    fg.bold = Style(Sgr(1))

    fg.set_eightbit_call(RgbFg)

    assert fg(1) == fg.red
    assert f

# Generated at 2022-06-18 06:30:40.574111
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg, Sgr

    # Create a new register-object and add a render-function for RgbFg.
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set the rendertype for RGB-calls to RgbFg.
    r.set_rgb_call(RgbFg)

    # Create a new style with RgbFg and Sgr.
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Call the register-object with a RGB-code.
    assert r(255, 0, 0) == r.red



# Generated at 2022-06-18 06:31:09.646272
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, RgbFg, Sgr

    # Create a new register object
    r = Register()

    # Add renderfuncs for Eightbit and RgbFg
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a style attribute
    r.red = Style(Eightbit(1), Sgr(1))

    # Check if attribute is set correctly
    assert r.red == "\x1b[38;5;1m\x1b[1m"

    # Set Eightbit-call to RgbFg
    r.set_eight

# Generated at 2022-06-18 06:31:14.644239
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:31:22.675794
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg

    def render_eightbit(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(Eightbit, render_eightbit)
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)

    assert r(42) == "\x1b[38;5;42m"

# Generated at 2022-06-18 06:31:33.968736
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from . import fg

    nt = fg.as_namedtuple()
    assert nt.black == "\x1b[38;5;16m"
    assert nt.red == "\x1b[38;5;9m"
    assert nt.green == "\x1b[38;5;10m"
    assert nt.yellow == "\x1b[38;5;11m"
    assert nt.blue == "\x1b[38;5;12m"
    assert nt.magenta == "\x1b[38;5;13m"
    assert nt.cyan == "\x1b[38;5;14m"
    assert nt.white == "\x1b[38;5;15m"

# Generated at 2022-06-18 06:31:41.055195
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test if as_dict() works as expected.
    """
    from .rendertype import RgbFg, RgbBg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "green": "\x1b[38;2;0;255;0m\x1b[1m"}



# Generated at 2022-06-18 06:31:43.440184
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:31:48.576918
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:31:59.041398
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style(Sgr(1))

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"
    assert nt.blue == "\x1b[38;2;0;0;255m"
    assert nt.bold == "\x1b[1m"

# Generated at 2022-06-18 06:32:08.236658
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbFg2(RenderType):
        pass

    class RgbBg2(RenderType):
        pass

    class Sgr2(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:32:19.377845
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:32:48.458213
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.bold_red = Style(r.bold, r.red)

    r2 = r.copy()

    assert r.bold_red == r2.bold_red
    assert r.bold_red is not r2.bold_red


# Generated at 2022-06-18 06:32:54.893615
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:33:04.929766
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
    }



# Generated at 2022-06-18 06:33:13.700879
# Unit test for constructor of class Style
def test_Style():
    """
    Test constructor of class Style.
    """
    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of str
    assert issubclass(Style, str)

    # Test if Style is a subclass of

# Generated at 2022-06-18 06:33:18.495799
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.orange = Style(RgbFg(1, 5, 10), Sgr(1))


# Generated at 2022-06-18 06:33:29.246011
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if copy method of class Register works as expected.
    """
    from sty import fg

    fg.red = Style(fg.red)
    fg.blue = Style(fg.blue)

    fg_copy = fg.copy()

    assert fg_copy.red == fg.red
    assert fg_copy.blue == fg.blue

    fg_copy.red = Style(fg.blue)
    fg_copy.blue = Style(fg.red)

    assert fg_copy.red != fg.red
    assert fg_copy.blue != fg.blue

    assert fg_copy.red == fg.blue
    assert fg_copy.blue == fg.red

# Generated at 2022-06-18 06:33:38.917411
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import Sgr, RgbFg

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_eightbit_call(Sgr)

    r.red = Style(Sgr(1))
    r.green = Style(RgbFg(0, 255, 0))

    assert r(1) == "\x1b[1m"
    assert r(0, 255, 0) == "\x1b[38;2;0;255;0m"


# Generated at 2022-06-18 06:33:44.528371
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr
    from .rendertype import RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.red = Style(Sgr(1), RgbFg(255, 0, 0))
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:33:54.733368
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")


# Generated at 2022-06-18 06:34:00.710379
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def rgb_fg_renderfunc(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def sgr_renderfunc(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg_renderfunc)
    r.set_renderfunc(Sgr, sgr_renderfunc)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))