

# Generated at 2022-06-18 06:25:06.271049
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:25:11.477023
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Test Eightbit-call
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_renderfunc(RenderType, lambda x: f"\x1b[38;5;{x}m")

    assert r(42) == "\x1b[38;5;42m"

    # Test RGB-call
    r = Register()
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    assert r(42, 255, 0) == "\x1b[38;2;42;255;0m"

    # Test string-call
    r = Register()

# Generated at 2022-06-18 06:25:15.140217
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == r.renderfuncs[RgbBg]



# Generated at 2022-06-18 06:25:18.934773
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbBg)
    assert r.rgb_call == r.renderfuncs[RgbBg]

    r.set_rgb_call(RgbFg)
    assert r.rgb_call == r.renderfuncs[RgbFg]



# Generated at 2022-06-18 06:25:22.506170
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:34.021888
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    reg = Register()

    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    reg.set_rgb_call(RgbBg)

    assert reg(10, 20, 30) == "\x1b[48;2;10;20;30m"

    reg.set_rgb_call(RgbFg)

    assert reg(10, 20, 30) == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-18 06:25:37.279997
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:25:44.531070
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;2;0;0;95m\x1b[1m"

# Generated at 2022-06-18 06:25:56.497502
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:26:06.035750
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

    r.set_rgb_call(RgbBg)
    assert r(255, 0, 0) == "\x1b[48;2;255;0;0m"

# Generated at 2022-06-18 06:26:21.906715
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test if set_rgb_call works as expected.
    """
    from .rendertype import RgbFg, RgbBg

    # Create a new register
    r = Register()

    # Define renderfuncs
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Define styles
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    # Test if renderfunc for RgbFg is

# Generated at 2022-06-18 06:26:27.685615
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    r = MyRegister()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(255) == r.red



# Generated at 2022-06-18 06:26:35.027301
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:26:46.242872
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg, Sgr

    # Create a new register object
    r = Register()

    # Add a renderfunc for RgbFg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add a renderfunc for RgbBg
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Add a renderfunc for Sgr
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    # Set the rendertype for rgb-calls
    r.set_rgb

# Generated at 2022-06-18 06:26:50.480924
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:26:59.576467
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.set_eightbit_call(RgbFg)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r(1) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r

# Generated at 2022-06-18 06:27:09.191361
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))

    tr = TestRegister()

    assert tr.red == "\x1b[38;2;255;0;0m"
    assert tr.green == "\x1b[38;2;0;255;0m"
    assert tr.blue == "\x1b[38;2;0;0;255m"

    tr.set_eightbit_call(Sgr)


# Generated at 2022-06-18 06:27:15.015456
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.mute()

    assert r(42) == ""
    assert r(10, 42, 255) == ""

    r.unmute()

    assert r(42) == ""
    assert r(10, 42, 255) == ""

# Generated at 2022-06-18 06:27:26.367489
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-18 06:27:36.745426
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, RgbFg, Sgr

    r = Register()
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)

    r.red = Style(Eightbit(1))
    r.orange = Style(RgbFg(1, 5, 10))
    r.bold = Style(Sgr(1))



# Generated at 2022-06-18 06:27:58.030863
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    tr = TestRegister()

    tr.test = Style(RgbFg(1, 2, 3))

    assert isinstance(tr.test, Style)
    assert isinstance(tr.test, str)
    assert str(tr.test) == "\x1b[38;2;1;2;3m"

    tr.test2 = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(tr.test2, Style)
    assert isinstance(tr.test2, str)
    assert str(tr.test2) == "\x1b[38;2;1;2;3m\x1b[1m"

    tr.test3 = Style(Style(RgbFg(1, 2, 3), Sgr(1)))



# Generated at 2022-06-18 06:28:01.027749
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))

    assert r.bold == "\x1b[1m"
    assert r(1) == ""
    assert r("bold") == "\x1b[1m"

# Generated at 2022-06-18 06:28:08.500129
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from sty import fg, bg, ef, rs

    # Create a new register object
    r = Register()

    # Add renderfuncs for the rendertypes RgbFg and RgbBg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set the default rendertype for Eightbit-calls to RgbFg
    r.set_eightbit_call(RgbFg)

    # Set the default rendertype for RGB-calls to RgbBg

# Generated at 2022-06-18 06:28:12.596726
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-18 06:28:22.692024
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    test_register.red = Style(RgbFg(255, 0, 0), Sgr(1))
    test_register.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    test_register.set_eightbit_call(RgbFg)

    assert test_register(1) == test_register.red

# Generated at 2022-06-18 06:28:33.729694
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs
    nt = fg.as_namedtuple()
    assert isinstance(nt, NamedTuple)
    assert nt.red == fg.red
    assert nt.blue == fg.blue
    assert nt.green == fg.green
    assert nt.black == fg.black
    assert nt.white == fg.white
    assert nt.yellow == fg.yellow
    assert nt.cyan == fg.cyan
    assert nt.magenta == fg.magenta
    assert nt.lightblack == fg.lightblack
    assert nt.lightwhite == fg.lightwhite
    assert nt.lightyellow == fg.lightyellow
    assert nt.lightcyan == fg.lightcyan


# Generated at 2022-06-18 06:28:37.732954
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(Sgr(1))

    assert r.red == "\x1b[1m"



# Generated at 2022-06-18 06:28:43.421485
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.set_eightbit_call(RgbFg)

    assert r(42) == "\x1b[38;2;42;42;42m"
    assert r(42, bold=True) == "\x1b[38;2;42;42;42m\x1b[1m"



# Generated at 2022-06-18 06:28:53.695065
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr, RgbFg, RgbBg, EightbitFg, EightbitBg

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert fg.blue == "\x1b[38;2;0;0;255m\x1b[1m"

    fg.mute()

    assert fg.red == ""
    assert fg.blue == ""

    fg.unmute()


# Generated at 2022-06-18 06:28:57.933155
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:29:15.823588
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.bold = Style

# Generated at 2022-06-18 06:29:25.719291
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r(0, 0, 255) == "\x1b[38;2;0;0;255m\x1b[1m"
    assert r("red") == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r("blue") == "\x1b[38;2;0;0;255m\x1b[1m"

# Generated at 2022-06-18 06:29:32.305462
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;2;0;0;0m"
    assert r(255) == "\x1b[38;2;255;255;255m"

# Generated at 2022-06-18 06:29:43.919556
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:29:51.511628
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), RgbBg(1, 2, 3))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[48;2;1;2;3m"

# Generated at 2022-06-18 06:30:01.114687
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .rendertype import RgbFg, RgbBg, Sgr, Reset

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbBg(0, 0, 255), Sgr(4))
    r.reset = Style(Reset())

    nt = r.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert nt.blue == "\x1b[48;2;0;0;255m\x1b[4m"
    assert nt.reset == "\x1b[0m"

# Generated at 2022-06-18 06:30:08.362186
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from sty import fg, bg, ef, rs

    fg.set_eightbit_call(bg.rendertype)
    assert fg(144) == bg(144)

    fg.set_eightbit_call(ef.rendertype)
    assert fg(144) == ef(144)

    fg.set_eightbit_call(rs.rendertype)
    assert fg(144) == rs(144)



# Generated at 2022-06-18 06:30:16.019191
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    class RgbRs(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"


# Generated at 2022-06-18 06:30:26.290676
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the __new__ method of the Style class.
    """
    from sty import fg, bg, ef, rs

    # Test if Style is a subclass of str.
    assert issubclass(Style, str)

    # Test if Style is a subclass of str.
    assert isinstance(fg.red, Style)

    # Test if Style is a subclass of str.
    assert isinstance(bg.red, Style)

    # Test if Style is a subclass of str.
    assert isinstance(ef.red, Style)

    # Test if Style is a subclass of str.
    assert isinstance(rs.red, Style)

    # Test if Style is a subclass of str.
    assert isinstance(fg.red, str)

    # Test if Style is a subclass of str.

# Generated at 2022-06-18 06:30:33.739587
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr
    from .render import render_rgb_fg, render_sgr

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(Sgr)

    assert r(144) == "\x1b[38;2;144;144;144m"
    assert r(10, 42, 255) == "\x1b[1m"

# Generated at 2022-06-18 06:31:16.144251
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    class CustomRegister(Register):
        pass

    reg = CustomRegister()

    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    reg.set_eightbit_call(RgbFg)

    reg.red = Style(RgbFg(255, 0, 0))

    assert reg.red == "\x1b[38;2;255;0;0m"
    assert reg(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:31:18.856260
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        pass

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(TestRenderType, lambda x: f"TestRenderType({x})")
    r.set_eightbit_call(TestRenderType)
    assert r(42) == "TestRenderType(42)"



# Generated at 2022-06-18 06:31:20.564734
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;2;3m\x1b[1m"


# Generated at 2022-06-18 06:31:26.790992
# Unit test for method unmute of class Register
def test_Register_unmute():
    from sty import fg, bg, ef, rs

    fg.red = Style(fg.red)
    fg.mute()
    assert fg.red == ""
    fg.unmute()
    assert fg.red == "\x1b[31m"

    bg.red = Style(bg.red)
    bg.mute()
    assert bg.red == ""
    bg.unmute()
    assert bg.red == "\x1b[41m"

    ef.red = Style(ef.red)
    ef.mute()
    assert ef.red == ""
    ef.unmute()
    assert ef.red == "\x1b[38;2;255;0;0m"

    rs.red = Style(rs.red)

# Generated at 2022-06-18 06:31:37.701286
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(r.red, r.bold)

    r2 = r.copy()

    assert r.red == r2.red
    assert r.bold == r2.bold
    assert r.red_bold == r2.red_bold


# Generated at 2022-06-18 06:31:39.435560
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:31:50.299558
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1), Sgr(4))) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[4m"

# Generated at 2022-06-18 06:32:01.106431
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:32:08.081915
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test method as_dict of class Register.
    """
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m\x1b[1m", "blue": "\x1b[38;2;0;0;255m\x1b[1m"}



# Generated at 2022-06-18 06:32:18.849345
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from sty import fg, bg, ef, rs

    # Test for fg
    fg.set_eightbit_call(fg.SgrFg)
    assert fg(42) == "\x1b[38;5;42m"

    fg.set_eightbit_call(fg.RgbFg)
    assert fg(42) == "\x1b[38;2;42;42;42m"

    # Test for bg
    bg.set_eightbit_call(bg.SgrBg)
    assert bg(42) == "\x1b[48;5;42m"

    bg.set_eightbit_call(bg.RgbBg)
    assert bg(42) == "\x1b[48;2;42;42;42m"

    #

# Generated at 2022-06-18 06:33:06.838665
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.red_bold = Style(r.red, r.bold)

    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:33:09.271138
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .renderfunc import sgr_renderfunc

    r = Register()
    r.set_renderfunc(Sgr, sgr_renderfunc)
    r.bold = Style(Sgr(1))

    assert str(r.bold) == "\x1b[1m"
    r.mute()
    assert str(r.bold) == ""
    r.unmute()
    assert str(r.bold) == "\x1b[1m"

# Generated at 2022-06-18 06:33:14.233921
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr

    def renderfunc(x: int) -> str:
        return f"\x1b[{x}m"

    r = Register()
    r.set_renderfunc(Sgr, renderfunc)

    assert r.renderfuncs[Sgr] == renderfunc
    assert r.renderfuncs[Sgr](1) == "\x1b[1m"



# Generated at 2022-06-18 06:33:25.052106
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))


# Generated at 2022-06-18 06:33:34.222342
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_rgb_fg, render_sgr

    # Create a new register object
    r = Register()

    # Set renderfuncs for RgbFg and Sgr
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

    # Create a style with RgbFg and Sgr
    r.test = Style(RgbFg(1, 2, 3), Sgr(1))

    # Check if the style is rendered correctly
    assert str(r.test) == "\x1b[38;2;1;2;3m\x1b[1m"



# Generated at 2022-06-18 06:33:39.213891
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))

    r.mute()

    assert r.bold == ""

    r.unmute()

    assert r.bold == "\x1b[1m"

# Generated at 2022-06-18 06:33:48.527387
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    r.test = Style(RenderType(1))

    assert str(r.test) == "\x1b[1m"

    r.mute()

    assert str(r.test) == ""

    r.unmute()

    assert str(r.test) == "\x1b[1m"

    r.test = Style(RenderType(2))

    assert str(r.test) == "\x1b[2m"

    r.test = Style(RenderType(3), RenderType(4))

    assert str(r.test) == "\x1b[3m\x1b[4m"


# Generated at 2022-06-18 06:33:58.293955
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(n):
        return f"\x1b[{n}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:34:08.238496
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if the copy method of class Register works as expected.
    """
    from sty import fg, bg, ef, rs

    # Create a new register
    my_register = Register()

    # Add some styles
    my_register.red = Style(fg.red)
    my_register.blue = Style(fg.blue)
    my_register.green = Style(fg.green)

    # Make a copy of the register
    my_register_copy = my_register.copy()

    # Check if the copy is equal to the original
    assert my_register.red == my_register_copy.red
    assert my_register.blue == my_register_copy.blue
    assert my_register.green == my_register_copy.green

    # Check if the copy is not the same object

# Generated at 2022-06-18 06:34:14.684244
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"