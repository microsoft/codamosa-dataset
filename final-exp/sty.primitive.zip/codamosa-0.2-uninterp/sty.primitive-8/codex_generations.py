

# Generated at 2022-06-18 06:24:57.613696
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]

    r.set_rgb_call(RgbBg)

    assert r.rgb_call == r.renderfuncs[RgbBg]



# Generated at 2022-06-18 06:25:08.425540
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_ef(r: int, g: int, b: int) -> str:
        return f"\x1b[38;5;{r};{g};{b}m"


# Generated at 2022-06-18 06:25:14.622404
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    register = Register()

# Generated at 2022-06-18 06:25:22.888545
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:25:34.282773
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    # Create a new register-object
    r = Register()

    # Add renderfuncs for RgbFg and RgbBg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set the rendertype for rgb-calls to RgbFg
    r.set_rgb_call(RgbFg)

    # Call the register-object with rgb-values

# Generated at 2022-06-18 06:25:42.932256
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:25:54.244131
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:26:04.806357
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))

    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.bold == "\x1b[1m"
    assert r.red + r.bold == "\x1b[38;2;255;0;0m\x1b[1m"

    r.mute

# Generated at 2022-06-18 06:26:16.039103
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    r = Register()

    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.green == "\x1b[38;2;0;255;0m"
    assert r.blue == "\x1b[38;2;0;0;255m"

    r.mute()

    assert r.red == ""
    assert r.green == ""
    assert r.blue == ""

    r.unmute()


# Generated at 2022-06-18 06:26:25.996153
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"


# Generated at 2022-06-18 06:26:36.217527
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbBg)

    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

    r.set_rgb_call(RgbFg)


# Generated at 2022-06-18 06:26:43.423233
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    r.bold = Style(Sgr(1))
    r.bold_italic = Style(r.bold, Sgr(3))
    r.bold_italic_underlined = Style(r.bold_italic, Sgr(4))

    assert str(r.bold) == "\x1b[1m"
    assert str(r.bold_italic) == "\x1b[1m\x1b[3m"
    assert str(r.bold_italic_underlined) == "\x1b[1m\x1b[3m\x1b[4m"

    r.mute()


# Generated at 2022-06-18 06:26:53.946479
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import fg, bg, ef, rs

    # Create a new register object
    r = Register()

    # Add renderfuncs for RgbFg and RgbBg
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set RgbFg as rendertype for rgb-calls
    r.set_rgb_call(RgbFg)

    # Set RgbBg as rendertype for rgb-calls
    r.set_rgb_call(RgbBg)

    # Create

# Generated at 2022-06-18 06:27:01.134666
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:27:08.792535
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"{r} {g} {b}")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"{r} {g} {b}")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "10 20 30"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "10 20 30"



# Generated at 2022-06-18 06:27:17.229581
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-18 06:27:27.906972
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbBg, render_rgb_bg)
    r.set_renderfunc(RgbFg, render_rgb_fg)

    r.set_rgb_call(RgbBg)


# Generated at 2022-06-18 06:27:38.047815
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbBg)
    assert r(10, 20, 30) == "\x1b[48;2;10;20;30m"


# Unit

# Generated at 2022-06-18 06:27:49.733840
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.set_rgb_call(RgbFg)

    assert r(1, 2, 3) == "\x1b[38;2;1;2;3m"

    r.set_rgb_call(RgbBg)

    assert r(1, 2, 3) == "\x1b[48;2;1;2;3m"

# Generated at 2022-06-18 06:27:53.584024
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg



# Generated at 2022-06-18 06:28:07.645567
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register.
    """
    from .rendertype import RgbFg, Sgr

    r1 = Register()
    r1.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r2 = r1.copy()

    assert r1.red == r2.red

    r2.red = Style(RgbFg(0, 255, 0), Sgr(1))

    assert r1.red != r2.red

# Generated at 2022-06-18 06:28:18.943005
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    nt = fg.as_namedtuple()

    assert nt.black == fg.black
    assert nt.red == fg.red
    assert nt.green == fg.green
    assert nt.yellow == fg.yellow
    assert nt.blue == fg.blue
    assert nt.magenta == fg.magenta
    assert nt.cyan == fg.cyan
    assert nt.white == fg.white
    assert nt.black_h == fg.black_h
    assert nt.red_h == fg.red_h
    assert nt.green_h == fg.green_h
    assert nt.yellow_h == fg.yellow_h
    assert nt.blue

# Generated at 2022-06-18 06:28:26.033636
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test method set_eightbit_call of class Register.
    """
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    def render_rgb(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"

    test_register = TestRegister()
    test_register.set_renderfunc(RgbFg, render_rgb)
    test_register.set_renderfunc(Sgr, render_sgr)

    test_register.set_eightbit_call(RgbFg)
    test_register.set_rgb_call(RgbFg)

    test_

# Generated at 2022-06-18 06:28:32.437077
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:28:41.456028
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test method as_dict of class Register.
    """
    from .rendertype import Sgr, RgbFg, RgbBg

    r = Register()
    r.red = Style(Sgr(1), RgbFg(255, 0, 0))
    r.green = Style(Sgr(1), RgbFg(0, 255, 0))
    r.blue = Style(Sgr(1), RgbBg(0, 0, 255))


# Generated at 2022-06-18 06:28:51.827067
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg, RgbBg
    from .register import Register

    r = Register()
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{args[0]}m")
    r.set_renderfunc(RgbFg, lambda *args: f"\x1b[38;2;{args[0]};{args[1]};{args[2]}m")
    r.set_renderfunc(RgbBg, lambda *args: f"\x1b[48;2;{args[0]};{args[1]};{args[2]}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))

# Generated at 2022-06-18 06:28:55.660877
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.rgb_call == RgbBg

# Generated at 2022-06-18 06:29:01.248028
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestRenderType(RenderType):
        pass

    class TestRegister(Register):
        pass

    def test_renderfunc(arg1, arg2):
        return f"{arg1}{arg2}"

    r = TestRegister()
    r.set_renderfunc(TestRenderType, test_renderfunc)

    r.test_style = Style(TestRenderType(1, 2))

    assert str(r.test_style) == "12"

# Generated at 2022-06-18 06:29:05.889901
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_renderfunc(RenderType, lambda x: x)
    r1.red = Style(RenderType(1))
    r2 = r1.copy()
    assert r1.red == r2.red
    r2.red = Style(RenderType(2))
    assert r1.red != r2.red

# Generated at 2022-06-18 06:29:12.453000
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(value="\x1b[38;2;1;5;10m\x1b[1m").rules == ()
    assert Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m") == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-18 06:29:21.046281
# Unit test for constructor of class Register
def test_Register():
    assert Register()

# Generated at 2022-06-18 06:29:26.425237
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the __new__ method of the Style class.
    """
    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:29:27.579306
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-18 06:29:33.565918
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg

    # Create a new register
    r = Register()

    # Add a style to the register
    r.red = Style(Sgr(1), RgbFg(255, 0, 0))

    # Mute the register
    r.mute()

    # Check if the style is muted
    assert r.red == ""

    # Unmute the register
    r.unmute()

    # Check if the style is unmuted
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:29:39.830392
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr
    from .sgr import Bold

    r = Register()
    r.set_renderfunc(Sgr, lambda *args: "".join(args))
    r.bold = Style(Bold())
    r.mute()
    assert r.bold == ""
    r.unmute()
    assert r.bold == Bold()

# Generated at 2022-06-18 06:29:48.698545
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test for method __new__ of class Style.
    """
    from .rendertype import Sgr

    s1 = Style(Sgr(1))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[1m"

    s2 = Style(Sgr(1), Sgr(2))
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert str(s2) == "\x1b[1m\x1b[2m"

    s3 = Style(Sgr(1), Sgr(2), value="\x1b[3m")
    assert isinstance(s3, Style)
    assert isinstance(s3, str)

# Generated at 2022-06-18 06:29:56.557643
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(RenderType, lambda x: x)

    r.test = Style(RenderType(1))
    assert r.test == "1"

    r.test = Style(RenderType(1), RenderType(2))
    assert r.test == "12"

    r.test = Style(Style(RenderType(1), RenderType(2)))
    assert r.test == "12"

    r.test = Style(Style(RenderType(1), RenderType(2)), RenderType(3))
    assert r.test == "123"

    r.test = Style(Style(RenderType(1), RenderType(2)), Style(RenderType(3), RenderType(4)))
    assert r.test == "1234"


# Generated at 2022-06-18 06:29:59.916584
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg

    r = Register()
    r.set_rgb_call(RgbBg)

    assert r(10, 42, 255) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-18 06:30:03.782590
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.test = Style(RgbFg(1, 2, 3))
    assert r.as_dict() == {"test": "\x1b[38;2;1;2;3m"}



# Generated at 2022-06-18 06:30:13.336191
# Unit test for constructor of class Style
def test_Style():
    """
    Test the constructor of class Style.
    """
    # Test 1
    style = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "\x1b[38;2;1;2;3m\x1b[1m"

    # Test 2
    style = Style(RgbFg(1, 2, 3), Sgr(1), value="\x1b[38;2;1;2;3m\x1b[1m")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "\x1b[38;2;1;2;3m\x1b[1m"

    # Test 3
    style = Style

# Generated at 2022-06-18 06:30:35.764770
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(42, 43, 44) == ""

    r.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    assert r(42) == "\x1b[42m"
    assert r(42, 43, 44) == "\x1b[42;43;44m"

# Generated at 2022-06-18 06:30:43.481371
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg, bg, ef, rs


# Generated at 2022-06-18 06:30:52.387279
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.red = Style(RenderType(1))
    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == "\x1b[38;2;10;42;255m"
    assert r("red") == "\x1b[1m"

    r.mute()
    assert r(42) == ""
    assert r(10, 42, 255) == ""
    assert r("red") == ""

    r.unmute()
    assert r

# Generated at 2022-06-18 06:31:00.353195
# Unit test for constructor of class Style
def test_Style():
    assert Style(value="\x1b[1m") == "\x1b[1m"
    assert Style(value="\x1b[1m").rules == ()
    assert Style(value="\x1b[1m", rules=(1, 2, 3)) == "\x1b[1m"
    assert Style(value="\x1b[1m", rules=(1, 2, 3)).rules == (1, 2, 3)
    assert Style(1, 2, 3) == ""
    assert Style(1, 2, 3).rules == (1, 2, 3)
    assert Style(1, 2, 3, value="\x1b[1m") == "\x1b[1m"
    assert Style(1, 2, 3, value="\x1b[1m").rules == (1, 2, 3)


# Generated at 2022-06-18 06:31:06.989764
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .sty import fg

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(fg.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    fg.mute()

    assert str(fg.red) == ""

    fg.unmute()

    assert str(fg.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:31:16.106265
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_sgr(x: int) -> str:
        return f"\x1b[{x}m"

    # Create a new register object
    reg = Register()

    # Add renderfuncs for RgbFg, RgbB

# Generated at 2022-06-18 06:31:21.006267
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(r.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-18 06:31:23.201597
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False

# Generated at 2022-06-18 06:31:34.598853
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbFg, RgbBg

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))

    tr = TestRegister()
    nt = tr.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"

    tr.mute()
    nt = tr.as_namedtuple()

    assert nt.red == ""
    assert nt.green == ""

    tr.unmute()
    nt

# Generated at 2022-06-18 06:31:42.871794
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code,)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-18 06:32:26.469021
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from . import fg, bg, ef, rs

    nt = fg.as_namedtuple()
    assert isinstance(nt, NamedTuple)
    assert nt.black == "\x1b[38;5;16m"

    nt = bg.as_namedtuple()
    assert isinstance(nt, NamedTuple)
    assert nt.black == "\x1b[48;5;16m"

    nt = ef.as_namedtuple()
    assert isinstance(nt, NamedTuple)
    assert nt.bold == "\x1b[1m"

    nt = rs.as_namedtuple()
    assert isinstance(nt, NamedTuple)
    assert nt.reset == "\x1b[0m"

# Generated at 2022-06-18 06:32:31.629162
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test the method copy of the class Register.
    """
    from .rendertype import RgbFg, Sgr

    r1 = Register()
    r1.red = Style(RgbFg(255, 0, 0), Sgr(1))

    r2 = r1.copy()
    r2.red = Style(RgbFg(0, 255, 0), Sgr(1))

    assert r1.red != r2.red


# Generated at 2022-06-18 06:32:37.233115
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg, Sgr

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
   

# Generated at 2022-06-18 06:32:48.107618
# Unit test for method __new__ of class Style
def test_Style___new__():
    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(fg.orange, Style)
    assert isinstance(fg.orange, str)
    assert str(fg.orange) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-18 06:32:53.127147
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.test = Style(RgbFg(1, 2, 3))
            self.test2 = Style(RgbFg(1, 2, 3), Sgr(1))

    r = TestRegister()
    assert r.as_dict() == {"test": "\x1b[38;2;1;2;3m", "test2": "\x1b[38;2;1;2;3m\x1b[1m"}



# Generated at 2022-06-18 06:33:02.796129
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Eightbit, RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))



# Generated at 2022-06-18 06:33:11.431330
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    r.set_rgb_call(RgbBg)
    assert r(255, 0, 0) == "\x1b[48;2;255;0;0m"

    r.set_rgb_call(RgbFg)
    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-18 06:33:15.266291
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .sty import sty

    sty.fg.red = Style(Sgr(31))
    sty.fg.mute()
    assert sty.fg.red == ""
    sty.fg.unmute()
    assert sty.fg.red == "\x1b[31m"



# Generated at 2022-06-18 06:33:26.369768
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    d = r.as_dict()

    assert d == {
        "red": "\x1b[38;2;255;0;0m\x1b[1m",
        "green": "\x1b[38;2;0;255;0m\x1b[1m",
        "blue": "\x1b[38;2;0;0;255m\x1b[1m",
    }


# Unit test

# Generated at 2022-06-18 06:33:35.783448
# Unit test for constructor of class Register
def test_Register():
    # Create a new register-object
    r = Register()

    # Add a new style to the register
    r.red = Style(RgbFg(255, 0, 0))

    # Check if the style is added
    assert hasattr(r, "red")

    # Check if the style is of type Style
    assert isinstance(r.red, Style)

    # Check if the style is of type str
    assert isinstance(r.red, str)

    # Check if the style is of type str
    assert str(r.red) == "\x1b[38;2;255;0;0m"

    # Check if the style is of type str
    assert r.red == "\x1b[38;2;255;0;0m"

    # Check if the style is of type str
    assert r.red == Style