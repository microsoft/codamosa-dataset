

# Generated at 2022-06-12 09:49:53.420458
# Unit test for constructor of class Register
def test_Register():

    from . import rendertype

    renderfuncs: Renderfuncs = {
        rendertype.Sgr: lambda x: "\x1b[%sm" % x,
        rendertype.RgbFg: lambda r, g, b: "\x1b[38;2;%s;%s;%sm" % (r, g, b),
        rendertype.RgbBg: lambda r, g, b: "\x1b[48;2;%s;%s;%sm" % (r, g, b),
    }

    r = Register()

    r.set_renderfunc(rendertype.Sgr, lambda x: "\x1b[%sm" % x)

# Generated at 2022-06-12 09:49:54.568270
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg


# Generated at 2022-06-12 09:50:04.344978
# Unit test for constructor of class Register
def test_Register():

    from sty import RenderType, ef, fg

    register = Register()

    assert register.renderfuncs == {}

    assert register.is_muted == False

    # Check that the default functions for 8bit and 24bit calls
    # are set to the colors defined in sty.fg and sty.bg.
    assert register.eightbit_call == fg.none.rs
    assert register.rgb_call == fg.rgb_ansi

    # Check that the render-func for the special case of rendertype Reset is set to lambda x: x
    assert register.renderfuncs[RenderType.Reset] == fg.rs

    # Check that the render-func for the special case of rendertype Reset is set to lambda x: x
    assert register.renderfuncs[RenderType.Reset] == fg.rs

# Generated at 2022-06-12 09:50:06.631751
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-12 09:50:17.042908
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Foo(RenderType):
        def __str__(self):
            return "Foo"

    class Bar(RenderType):
        def __str__(self):
            return "Bar"

    class Baz(RenderType):
        def __str__(self):
            return "Baz"

    r = Register()
    r.set_renderfunc(Foo, lambda x: "Foo")
    r.set_renderfunc(Bar, lambda x: "Bar")
    r.set_renderfunc(Baz, lambda x: "Baz")

    r.set_eightbit_call(Foo)
    r.set_rgb_call(Baz)

    # Single arg call
    assert r(10) == "Foo"
    assert r(42) == "Foo"
    assert r(256) == ""


# Generated at 2022-06-12 09:50:22.595409
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import SgrFg, SgrBg, SgrEf, SgrRs

    register = Register()
    register.set_eightbit_call(SgrFg)
    register.set_rgb_call(SgrFg)
    register.set_renderfunc(SgrBg, lambda n: f"\x1b[BG{n}")

    assert len(register.renderfuncs) == 3

    assert not register.is_muted

# Generated at 2022-06-12 09:50:29.034800
# Unit test for constructor of class Register
def test_Register():
    """
    This test ensures the functionality of the constructor for the basic class Register.

    :return: None
    """
    # Create a new empty Register
    r = Register()

    # Ensure that default values are set correctly
    assert r.renderfuncs == {}
    assert r.is_muted == False
    assert r.eightbit_call(0) == ""
    assert r.rgb_call(0, 0, 0) == ""


# Generated at 2022-06-12 09:50:30.405676
# Unit test for constructor of class Register
def test_Register():
    r: Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:50:34.430076
# Unit test for constructor of class Register
def test_Register():

    r = Register()

    r.blue = Style(RgbFg(10, 10, 10))

    assert isinstance(r.blue, Style)

    assert isinstance(r.blue, str)

    assert str(r.blue) == "\x1b[38;2;10;10;10m"



# Generated at 2022-06-12 09:50:36.018953
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r
    assert r.renderfuncs == {}
    assert r.is_muted is False

# Generated at 2022-06-12 09:50:39.665016
# Unit test for constructor of class Register
def test_Register():
    assert Register() is not None

# Generated at 2022-06-12 09:50:41.198787
# Unit test for constructor of class Register
def test_Register():
    fg = Register()
    assert fg.is_muted == False


# Generated at 2022-06-12 09:50:45.126697
# Unit test for method __call__ of class Register
def test_Register___call__():

    callback: Callable = lambda x: f"\033[48;5;{x}m"
    reg = Register()
    reg.set_eightbit_call(lambda x: f"\033[48;5;{x}m")

    assert reg(228) == callback(228)



# Generated at 2022-06-12 09:50:55.068278
# Unit test for constructor of class Register
def test_Register():

    from types import SimpleNamespace
    from .rendertype import RgbFg, RgbBg, Rgb

    def render(rgb: Rgb) -> str:
        return f"{rgb.r, rgb.g, rgb.b}"

    r = Register()

    r.set_renderfunc(Rgb, render)

    r.c1 = Style(RgbFg(9, 21, 44))
    assert r.c1 == "(9, 21, 44)"

    r2 = Register()
    r2.set_renderfunc(Rgb, render)
    r2.c1 = Style(RgbBg(9, 21, 44))
    assert r2.c1 == "(9, 21, 44)"

    assert r.c1 != r2.c1

    r2 = Register()
    r2.set

# Generated at 2022-06-12 09:51:00.080688
# Unit test for constructor of class Register
def test_Register():

    # Empty Register
    r1 = Register()

    assert not hasattr(r1, "test")

    # Register with some style attributes
    r2 = Register()
    r2.test = Style(RgbFg(2, 3, 4), Sgr(1))

    assert hasattr(r2, "test")
    assert isinstance(r2.test, str)



# Generated at 2022-06-12 09:51:09.406489
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    r.set_renderfunc(RenderType, lambda *args: f"\x1b[{args[0]};{args[1]}m")
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(8, 3) == "\x1b[38;3m"
    assert r(8, 0) == ""
    assert r(22, 0) == ""
    assert r(24, 3) == "\x1b[48;3m"
    assert r(112, 3) == "\x1b[38;3m"
    assert r(112, 0) == ""
    assert r(121, 0) == ""
    assert r(123, 3) == "\x1b[48;3m"

# Generated at 2022-06-12 09:51:09.962281
# Unit test for method __call__ of class Register
def test_Register___call__():

    pass

# Generated at 2022-06-12 09:51:16.392471
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import Sgr, Bg, Fg, RgbBg, RgbFg, Set8bitBg, Set8bitFg, Reset

    # Create a new empty register
    reg = Register()
    assert reg.renderfuncs == {}

    # Create a new register with a rendertype
    # (Since Python doesn't support namedtuple as arguments, we save
    # the namedtuple in a variable)
    renderfuncs = {Sgr: lambda *x: "sgr"}
    reg = Register(renderfuncs)
    assert reg.renderfuncs == renderfuncs



# Generated at 2022-06-12 09:51:26.129431
# Unit test for method __call__ of class Register
def test_Register___call__():
    class TestClass:

        def __init__(self, name, val):
            self.name = name
            self.val = val

    register: Register = Register()
    style: Style = Style(RenderType(), RenderType())

    setattr(register, "test", style)

    # With one string argument
    assert register("test") == style.value

    # With one integer argument
    register.eightbit_call = lambda x: str(x)
    assert register(42) == "42"

    # With three integer arguments
    register.rgb_call = lambda r, g, b: "r" + str(r) + "g" + str(g) + "b" + str(b)
    assert register(10, 20, 30) == "r10g20b30"

    # With 2 arguments
    # assert register("

# Generated at 2022-06-12 09:51:36.938650
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbBg, EightbitBg
    from .register import fg, bg

    r: Register = fg.copy()

    # Create 8bit color red
    r.red = Style(EightbitFg(1))

    assert r(1) == RGBA_8BIT_RED

    # Create 24bit color red
    r.red = Style(RgbFg(255, 0, 0))

    assert r(255, 0, 0) == RGBA_24BIT_RED

    # Create a color red and set render-func to Rgb-call
    r.red = Style(RgbFg(255, 0, 0))
    r.set_rgb_call(RgbBg)

    assert r(255, 0, 0) == RGBA_24BIT_RED_BG

    # Create a

# Generated at 2022-06-12 09:51:47.180357
# Unit test for method __call__ of class Register
def test_Register___call__():
    from random import randint

    class DummyRegister(Register):

        def __init__(self):

            self.renderfuncs = {
                RenderType: lambda x: "I am a dummy renderfunctions.",
                # A dummy rendertype for testing purposes
                RenderType: lambda x, y, z: "I am the dummy rgb render-function.",
            }

            self.eightbit_call = self.renderfuncs[RenderType]
            self.rgb_call = self.renderfuncs[RenderType]

    dummy_register = DummyRegister()

    dummy_register.set_eightbit_call(RenderType)
    dummy_register.set_rgb_call(RenderType)

    assert dummy_register() == ""
    assert dummy_register(1) == "I am a dummy renderfunctions."

# Generated at 2022-06-12 09:51:54.476688
# Unit test for method __call__ of class Register
def test_Register___call__():
    rg = Register()
    rg.red = Style(RgbFg(255, 0, 0))
    rg.mycolor = Style(RgbFg(10, 42, 255), Sgr(1))

    assert rg("red") == rg.red
    assert rg("mycolor") == rg.mycolor

    assert rg(255, 0, 0) == RgbFg(255, 0, 0).to_ansi()
    assert rg(10, 42, 255, bold=True) == RgbFg(10, 42, 255).to_ansi()

# Generated at 2022-06-12 09:51:55.895250
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)


# Generated at 2022-06-12 09:52:01.313546
# Unit test for constructor of class Register
def test_Register():
    """
    Test if constructor of class Register works as expected
    """
    r = Register()

    r.test = Style('test')
    assert r.test == 'test'

    assert r.is_muted == False

    r.mute()
    assert r.is_muted == True

    r.unmute()
    assert r.is_muted == False

    # TODO: Write more unit tests.

# Generated at 2022-06-12 09:52:06.740827
# Unit test for method __call__ of class Register
def test_Register___call__():
    register = Register()

    my_red = Style(RgbFg(255, 0, 0))
    setattr(register, "red", my_red)

    assert "red" in dir(register)
    assert register.red == "\x1b[38;2;255;0;0m"

    assert register("red") == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-12 09:52:18.799562
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert r(144) == ""
    assert r(10, 20, 30) == ""

    r.set_eightbit_call(EightbitFg)
    assert r(144) == "\x1b[38;5;144m"

    r.set_rgb_call(RgbFg)
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    assert r(144) == "\x1b[38;5;144m"

# Generated at 2022-06-12 09:52:21.324469
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.renderfuncs == {}
    assert register.is_muted == False
    assert register.eightbit_call == None
    assert register.rgb_call == None


# Generated at 2022-06-12 09:52:31.956475
# Unit test for method __call__ of class Register
def test_Register___call__():

    import sty

    # Set register attributes
    sty.fg.red = sty.Style(sty.RgbFg(255, 0, 0))
    sty.fg.orange = sty.Style(sty.RgbFg(255, 127, 0))
    sty.fg.yellow = sty.Style(sty.RgbFg(255, 255, 0))
    sty.fg.green = sty.Style(sty.RgbFg(0, 255, 0))
    sty.fg.blue = sty.Style(sty.RgbFg(0, 0, 255))

    sty.fg.purple = sty.Style(sty.RgbFg(128, 0, 128))

    sty.fg.teal = sty.Style(sty.RgbFg(0, 128, 128))


# Generated at 2022-06-12 09:52:33.592022
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-12 09:52:34.524009
# Unit test for constructor of class Register
def test_Register():
    reg1 = Register()
    assert type(reg1) is Register


# Generated at 2022-06-12 09:52:44.508040
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()

    r.set_renderfunc(RenderType, lambda value: "value: " + str(value))

    assert r(42) == "value: 42"
    assert r(None) == ""
    assert r(1, 2, 3) == ""

# Generated at 2022-06-12 09:52:47.623698
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.as_dict() == {}
    assert r.eightbit_call(0) == ""
    assert r.rgb_call(0, 0, 0) == ""



# Generated at 2022-06-12 09:52:58.180386
# Unit test for constructor of class Register
def test_Register():
    fg = Register()

    # Check if instance has correct attributes:
    assert isinstance(fg, Register)
    assert isinstance(fg.renderfuncs, dict)
    assert isinstance(fg.is_muted, bool)
    assert isinstance(fg.eightbit_call, Callable)
    assert isinstance(fg.rgb_call, Callable)

    # Check if instance has correct methods:
    assert callable(fg)
    assert callable(fg.set_eightbit_call)
    assert callable(fg.set_rgb_call)
    assert callable(fg.set_renderfunc)
    assert callable(fg.mute)
    assert callable(fg.unmute)
    assert callable(fg.as_dict)
    assert callable(fg.as_namedtuple)
   

# Generated at 2022-06-12 09:53:04.365448
# Unit test for constructor of class Register
def test_Register():
    import pytest

    rendertype = RenderType("RgbFg")
    register = Register()

    with pytest.raises(TypeError):
        register(42)

    register.set_eightbit_call(rendertype)
    register.set_rgb_call(rendertype)

    with pytest.raises(TypeError):
        register("red")

    register("red")


# Default register objects.
fg: Register = Register()
bg: Register = Register()
ef: Register = Register()
rs: Register = Register()

# Generated at 2022-06-12 09:53:15.228256
# Unit test for method __call__ of class Register
def test_Register___call__():
    r1 = Register()
    r1.set_eightbit_call(RgbFg)
    r1.r1 = Style(RgbBg(3, 4, 5))
    assert r1(1) == "\x1b[38;2;1;1;1m"
    assert r1(1, 2, 3) == "\x1b[38;2;1;2;3m"
    assert r1("r1") == "\x1b[48;2;3;4;5m"

    r2 = Register()
    r2.set_eightbit_call(RgbFg)
    r2.r2 = Style(RgbBg(3, 4, 5))
    r2.set_eightbit_call(RgbBg)

# Generated at 2022-06-12 09:53:25.389962
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class EightbitFg(RenderType):
        pass

    class EightbitBg(RenderType):
        pass

    class Inheritance(Register):
        pass

    inheritance = Inheritance()

    inheritance.orange = Style(EightbitFg(202))
    inheritance.set_eightbit_call(EightbitFg)
    inheritance.set_renderfunc(
        EightbitFg, lambda desc, code: f"{desc}({code})"
    )
    inheritance.set_rgb_call(RgbFg)
    inheritance.set_renderfunc(
        RgbFg, lambda desc, r, g, b: f"{desc}({r}, {g}, {b})"
    )


# Generated at 2022-06-12 09:53:30.737813
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Register1(Register):

        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))

    r = Register1()

    assert str(r("red")) == str(r.red)
    assert r("red") == r.red
    assert r(255, 0, 0) == ""

# Generated at 2022-06-12 09:53:39.775134
# Unit test for method __call__ of class Register
def test_Register___call__():

    tests = (
        (("_black", (0,), {}), "_black"),
        (("_black", (0,), {"bold": True}), "_black_bold"),
        (("_black", ("_black",), {}), "_black"),
    )

    for params, expected in tests:
        attr, args, kwargs = params
        result = getattr(fg, attr)(*args, **kwargs)
        assert isinstance(result, Style)
        assert str(result) == expected
        assert result.rules == getattr(fg, attr).rules

    assert getattr(fg, "_black")("_black") == getattr(fg, "_black")

    # Test eightbit-call (with default rendertype)

# Generated at 2022-06-12 09:53:50.276645
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.set_renderfunc(RenderType, str)

    r1 = Style(RenderType(42))
    r2 = Style(RenderType(42, 128, 255))
    r3 = Style(RenderType(42), RenderType(128, 255))

    # Call with 8bit-color code
    assert r(42) == str(r1)
    # Call with 8bit-color code and keyword-arguments
    assert r(42, test=42) == str(r1)

    # Call with 255-color code
    assert r(42, 128, 255) == str(r2)
    # Call with 255-color code and keyword-arguments
    assert r(42, 128, 255, test=42) == str(r2)

    # Call with value, that doesnt exist in register

# Generated at 2022-06-12 09:53:53.080132
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.is_muted == False


# Generated at 2022-06-12 09:54:14.116293
# Unit test for constructor of class Register
def test_Register():
    """
    Test if Register object can be created.
    """

    def test_render_function(a):
        return "Rendered: {}".format(a)

    # Create Register-object
    r = Register()
    r.set_renderfunc(RenderType.SGR, test_render_function)
    r.sgr_1 = Style(RenderType("SGR", 1))
    r.sgr_2 = Style(RenderType("SGR", 2))
    r("sgr_1")
    assert r("sgr_1") == "Rendered: 1"
    assert r("sgr_2") == "Rendered: 2"

# Generated at 2022-06-12 09:54:17.423635
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .builtins import fg

    s1 = fg("red")
    s2 = fg("blue")
    s3 = fg("red")

    assert id(s1) == id(s2)
    assert id(s2) == id(s3)



# Generated at 2022-06-12 09:54:19.236246
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register) == True

# Generated at 2022-06-12 09:54:29.953781
# Unit test for method __call__ of class Register
def test_Register___call__():
    register = Register()

    def renderfunc(x: int) -> str:
        return f"\x1b[{x}m"

    setattr(register, "red", Style(RgbFg(255, 255, 255)))
    setattr(register, "green", Style(RgbFg(0, 0, 0)))
    register.set_renderfunc(RgbFg, renderfunc)
    register.set_eightbit_call(RgbFg)
    register.set_rgb_call(RgbFg)

    assert register("red") == "\x1b[38;2;255;255;255m"
    assert register("green") == "\x1b[38;2;0;0;0m"

# Generated at 2022-06-12 09:54:34.443078
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)


# We must call _render_rules() with a Renderfuncs(Mapping[RenderType, Callable]).
# That is why we define it here. The renderfuncs dict is later populated with
# the real renderfuncs.
_renderfuncs: Renderfuncs = {}



# Generated at 2022-06-12 09:54:42.087416
# Unit test for constructor of class Register
def test_Register():

    class ExampleRenderType(RenderType):
        def __init__(self, *args):
            self.args = args

    def render_func(iar: ExampleRenderType, *args):
        return f"RENDER: {iar.args}"

    # Create Register-instance
    reg = Register()

    # Add render-function for ExampleRenderType
    reg.set_renderfunc(ExampleRenderType, render_func)

    # Set Style
    reg.my_style = Style(ExampleRenderType(1, 2, 3), ExampleRenderType(4, 5, 6))

    # Compare strings (rendering result)
    assert str(reg.my_style) == "RENDER: (1, 2, 3)RENDER: (4, 5, 6)"

    # Compare attributes (Styles)

# Generated at 2022-06-12 09:54:43.016998
# Unit test for constructor of class Register
def test_Register():
    _ = Register()


# Generated at 2022-06-12 09:54:53.739142
# Unit test for constructor of class Register
def test_Register():

    # Create a new register object
    register = Register()

    # Add a renderfunc to the register
    renderfunc_one = lambda x: f"\x1b[{x}m"
    register.set_renderfunc(RenderType.Eightbit, renderfunc_one)

    # Add a style to the register and check if renderfunc is applied
    register.style_one = Style(RenderType.Eightbit(42))
    assert str(register.style_one) == "\x1b[42m"

    # Create a copy of the register
    register_two = register.copy()

    # Add a different renderfunc to the copy
    renderfunc_two = lambda x: f"\x1b[{x}o"
    register_two.set_renderfunc(RenderType.Eightbit, renderfunc_two)

    # Check if the

# Generated at 2022-06-12 09:55:03.708838
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Rgb(RenderType):
        pass

    reg = Register()
    setattr(reg, "red", Style(RgbFg(255, 0, 0)))
    setattr(reg, "blue", Style(RgbBg(0, 0, 255)))
    setattr(reg, "magenta", Style(RgbBg(255, 0, 255), RgbFg(0, 255, 255), Sgr(1)))


# Generated at 2022-06-12 09:55:04.699772
# Unit test for constructor of class Register
def test_Register():
    assert issubclass(Register, object)

# Generated at 2022-06-12 09:56:01.670222
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    fg = Register()
    bg = Register()

    RgbFg = RenderType("RgbFg", "38", "2")
    RgbBg = RenderType("RgbBg", "48", "2")
    NoRgbFg = RenderType("NoRgbFg", "38", "")
    NoRgbBg = RenderType("NoRgbBg", "48", "")

    fg.set_renderfunc(rendertype=RgbFg, func=lambda r, g, b: "")
    bg.set_renderfunc(rendertype=RgbBg, func=lambda r, g, b: "")

    fg.my_color = Style(RgbFg(42, 42, 42))

# Generated at 2022-06-12 09:56:06.273842
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import pysty.rendertypes as rt

    def test(r, g, b):
        return f"test{r}{g}{b}"

    r = Register()

    r.set_renderfunc(rt.RgbBg, test)
    r.set_rgb_call(rt.RgbBg)

    assert r(255, 0, 102) == f"test255{0}102"



# Generated at 2022-06-12 09:56:12.001643
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    
    class TestR(RenderType):

        def render(self) -> str:
            return "rend"

    
    test_r = TestR()

    # Set first attribute - unit test
    test_register = Register()
    test_register.x = Style(test_r)

    # Set second attribute - unit test
    test_register.y = Style(test_r)

    # Raise ValueError
    try:
        test_register.z = "string"
    except ValueError:
        pass
    else:
        raise Exception("ValueError handling failed. Should be raised.")


# Generated at 2022-06-12 09:56:21.196382
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test for Register.unmute
    """
    from .rendertype import Sgr, RgbFg, RgbBg, RgbEf

    r: Register = Register()
    r.set_eightbit_call(Sgr)
    r.set_eightbit_call(RgbFg)
    r.set_eightbit_call(RgbBg)
    r.set_eightbit_call(RgbEf)
    r.set_renderfunc(Sgr, lambda *x: "E")
    r.set_renderfunc(RgbFg, lambda *x: "F")
    r.set_renderfunc(RgbBg, lambda *x: "B")
    r.set_renderfunc(RgbEf, lambda *x: "Z")

# Generated at 2022-06-12 09:56:26.715711
# Unit test for constructor of class Register
def test_Register():
    def test_render(x: int = 0) -> str:
        return f"{x}"

    # Constructor and set_renderfunc
    register = Register()
    register.set_renderfunc(RenderType, test_render)

    # __setattr__
    register.test_attr = Style(RenderType(42))

    assert register.test_attr == "42"

    # set_eightbit_call
    register.set_eightbit_call(RenderType)

    assert register(42) == "42"

    # set_rgb_call
    register.set_rgb_call(RenderType)

    assert register(42, 42, 42) == "42"

# Generated at 2022-06-12 09:56:31.673749
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class TestRegister(Register):
        pass

    def render_test(val1: str) -> str:
        return "A " + val1 + "B"

    test = TestRegister()
    test.set_renderfunc(str, render_test)
    test.test = Style("test")
    assert test.test == "A testB"



# Generated at 2022-06-12 09:56:35.212703
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    register = Register()
    setattr(register, "color1", "color 1")
    setattr(register, "color2", "color 2")

    assert register.as_dict() == {"color1": "color 1", "color2": "color 2"}



# Generated at 2022-06-12 09:56:42.439494
# Unit test for method copy of class Register
def test_Register_copy():

    def test_func(test_int: int) -> str:
        return ""

    reg = Register()
    reg.name = Style(test_func)
    reg.set_eightbit_call(test_func)
    reg.set_rgb_call(test_func)
    reg.set_renderfunc(test_func, test_func)
    reg.mute()

    copy = reg.copy()

    assert copy.name == reg.name
    assert copy.eightbit_call == reg.eightbit_call
    assert copy.rgb_call == reg.rgb_call
    assert copy.renderfuncs == reg.renderfuncs
    assert copy.is_muted == reg.is_muted

# Generated at 2022-06-12 09:56:44.272756
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register()
    reg.red = Style()

    assert reg is not reg.copy()
    assert reg.red is not reg.copy().red


# Generated at 2022-06-12 09:56:51.754777
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .renderfuncs.sgr import Sgr

    fg = Register()
    fg.bold = Style(Sgr(1))
    fg.b = fg.bold.copy()
    fg.b.mute()

    assert fg.b == ""
    assert fg.bold != ""

    fg.unmute()

    assert fg.b != ""
    assert fg.bold != ""



# Generated at 2022-06-12 09:57:54.376789
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()

    r.red = Style(RgbFg(255, 0, 0))

    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m"}



# Generated at 2022-06-12 09:58:02.574838
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Testing set_eightbit_call of class Register by changing the default
    rendertype for Eightbit-calls of the fg register.
    """

    # Import stuff
    from sty import fg
    from sty.rgb import RgbFg

    # Make dummy render type
    class TestRenderType(RenderType):
        """
        Dummy rendertype for the test.
        """

    # Make dummy render function, in this case it is the renderfunction
    # of class RgbFg
    def test_renderfunc(r: int, g: int, b: int) -> str:
        return RgbFg(r, g, b).render()

    # Add dummy renderfunction to RgbFg rendertype
    fg.set_renderfunc(TestRenderType, test_renderfunc)

    # Change the render type for

# Generated at 2022-06-12 09:58:09.619877
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.is_muted is False
    assert reg.eightbit_call("") == ""
    assert reg.rgb_call("", "", "") == ("", "", "")
    assert reg.renderfuncs == {}
    assert reg(42) == ""
    assert reg("") == ""
    assert reg(10, 42, 255) == ("", "", "")
    assert reg.as_dict() == {}
    assert reg.as_namedtuple() == namedtuple("StyleRegister", [])(*[])
    assert isinstance(reg.copy(), Register)



# Generated at 2022-06-12 09:58:12.541625
# Unit test for method __new__ of class Style
def test_Style___new__():

    class A:
        pass

    class B:
        pass

    a = A()
    b = B()

    style = Style(a, b)

    assert style.rules == (a, b)

# Generated at 2022-06-12 09:58:21.422666
# Unit test for method mute of class Register
def test_Register_mute():
    from .render import SgrFg, SgrBg

    # Create a register and add some style rules.
    register = Register()
    register.red = Style(SgrFg(9))
    register.blue = Style(SgrBg(11))

    assert str(register.red) == "\x1b[31m"
    assert str(register.blue) == "\x1b[44m"

    register.mute()

    assert str(register.red) == ""
    assert str(register.blue) == ""

    register.unmute()

    assert str(register.red) == "\x1b[31m"
    assert str(register.blue) == "\x1b[44m"

    register2 = register.copy()
    register2.mute()


# Generated at 2022-06-12 09:58:29.352129
# Unit test for method mute of class Register
def test_Register_mute():

    class FictRegister(Register):
        pass

    fr = FictRegister()
    fr.foo = Style(RgbFg(0, 0, 0), Sgr(1))
    fr.bar = Style(RgbFg(100, 100, 100), Sgr(2))
    fr.set_renderfunc(RgbFg, lambda r, g, b: f"{r}-{g}-{b}")
    fr.set_renderfunc(Sgr, lambda s: f"A{s}")

    assert fr.foo == fr.renderfuncs[RgbFg](0, 0, 0) + fr.renderfuncs[Sgr](1)
    assert fr.bar == fr.renderfuncs[RgbFg](100, 100, 100) + fr.renderfuncs[Sgr](2)

    fr

# Generated at 2022-06-12 09:58:33.798247
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    test_register = TestRegister()
    assert test_register("black") == ""

    test_register.black = Style( value="black")
    assert test_register("black") == "black"

    test_register.mute()
    assert test_register("black") == ""



# Generated at 2022-06-12 09:58:40.367874
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Rgb24Bg
    from .sty import sty

    sty.bg.set_rgb_call(Rgb24Bg)
    sty.bg(10, 42, 255) == "\x1b[48;2;10;42;255m"

    sty.bg.set_eightbit_call(Rgb24Bg)
    sty.bg(42) == "\x1b[48;2;142;142;142m"

    sty.bg.set_eightbit_call(Rgb24Bg)
    sty.bg("blue") == "\x1b[48;2;0;0;255m"

    sty.bg.set_rgb_call(Rgb24Bg)
    sty.bg(10, 42) == ""

# Generated at 2022-06-12 09:58:44.869317
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbBg, RgbFg, Sgr

    assert Style(RgbBg(255, 255, 255)) == Style(RgbBg(255, 255, 255), value="\x1b[48;2;255;255;255m")

    assert Style(RgbBg(255, 255, 255), RgbFg(0, 0, 0)) == Style(RgbBg(255, 255, 255), RgbFg(0, 0, 0), value="\x1b[48;2;255;255;255m\x1b[38;2;0;0;0m")


# Generated at 2022-06-12 09:58:53.074659
# Unit test for method copy of class Register
def test_Register_copy():

    class RegisterA(Register):
        red = Style(RgbFg(10, 42, 255))

    class RegisterB(Register):
        red = Style(RgbFg(10, 42, 255))

    a: RegisterA = RegisterA()
    b: RegisterB = RegisterB()

    assert a != b
    assert a.as_namedtuple().red == b.as_namedtuple().red
    assert a.red.rules != b.red.rules
    assert a.red.rules == b.red.rules

    c = a.copy()
    c.red = Style(Bold)
    assert c.as_namedtuple().red == Style(Bold)

    d = a.copy()
    assert a == d