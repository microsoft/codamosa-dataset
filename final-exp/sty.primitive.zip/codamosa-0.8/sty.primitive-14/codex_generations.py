

# Generated at 2022-06-12 09:49:55.565532
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Register
    class TestReg(Register):
        # Sample attributes
        attr1 = Style()
        attr2 = Style()
        attr3 = Style()

        # Sample renderfuncs
        def renderfunc_int(self, x, y):
            return "int_" + str(x) + "_" + str(y)

        def renderfunc_str(self):
            return "str"

        def renderfunc_tuple(self, x, y, z):
            return "tuple_" + str(x) + "_" + str(y) + "_" + str(z)

        # Setup
        def __init__(self):
            super().__init__()
            self.set_eightbit_call(int)
            self.set_renderfunc(int, self.renderfunc_int)

# Generated at 2022-06-12 09:50:05.139844
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Setup
    def renderfunc(*args):
        return "".join([f"<{a}>" for a in args])

    from .rendertype import Sgr
    from .mapping import Eightbit, Rgb

    r1 = Register()
    r1.set_renderfunc(Sgr, renderfunc)
    r1.bold = Style(Sgr(1))
    r1.set_eightbit_call(Sgr)
    r1.set_rgb_call(Sgr)

    r2 = Register()
    r2.set_renderfunc(Sgr, renderfunc)
    r2.bold = Style(Sgr(1))
    r2.set_eightbit_call(Sgr)
    r2.set_rgb_call(Sgr)

    # Tests
    # Eightbit call functions

# Generated at 2022-06-12 09:50:07.926520
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert type(r) == Register
    assert isinstance(r, Register)

# Unit tests for constructor of class Style

# Generated at 2022-06-12 09:50:18.097038
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertypes import Ansi8Bit, RgbFg, Sgr

    def render_eightbit(b: int, r: str = "38") -> str:
        return f"{r};5;{b}m"

    def render_rgb(r: int, g: int, b: int, r1: str = "38") -> str:
        return f"{r1};2;{r};{g};{b}m"

    def render_mix(r: int, g: int, b: int) -> str:
        return f"38;5;{r};2;{g};{b}m"

    def render_empty(a: str) -> str:
        return ""

    def render_zero(a: str) -> str:
        return "0"

    r = Register()

    r

# Generated at 2022-06-12 09:50:28.596003
# Unit test for constructor of class Register
def test_Register():
    from .render import RgbFg
    reg = Register()
    assert reg.renderfuncs == {}
    assert reg.is_muted == False
    assert reg.eightbit_call(1,2,3) == (1,2,3)
    assert reg.rgb_call(1,2,3) == (1,2,3)
    reg.as_dict() == {}
    reg.as_namedtuple() == namedtuple('StyleRegister', {})()
    duplicate_reg = reg.copy()
    assert type(duplicate_reg) == type(reg)
    new_reg = Register()
    new_reg.__setattr__("myattr", "myattr")
    assert getattr(new_reg, "myattr", None) == "myattr"

# Generated at 2022-06-12 09:50:36.117312
# Unit test for constructor of class Register
def test_Register():

    register = Register()
    assert register.is_muted == False

# Generated at 2022-06-12 09:50:38.795438
# Unit test for constructor of class Register
def test_Register():
    """
    Test constructor of class Register.

    :return: None
    """
    reg1 = Register()
    assert reg1



# Generated at 2022-06-12 09:50:48.125142
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .ansi import Ef, Fg, Rs, SetStyle

    register = Register()

    register.red = Style(Fg(1), Ef(), SetStyle(0, 1))
    register.yellow = Style(Fg(3), Rs())

    assert register.red == "\x1b[38;5;1m\x1b[38;5;8m\x1b[0;1m"
    assert register.yellow == "\x1b[38;5;3m\x1b[0m"

    assert register(1) == "\x1b[38;5;1m\x1b[38;5;8m\x1b[0;1m"
    assert register(3) == "\x1b[38;5;3m\x1b[0m"
    assert register("red")

# Generated at 2022-06-12 09:50:56.481419
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test the call method of class Register.
    """

    register = Register()
    register.red = Style(RgbFg(255, 0, 0))
    register.set_eightbit_call(RgbFg)

    register.rgb_call = lambda *args: repr(args)
    register.eightbit_call = lambda *args: repr(args)

    assert repr(register(1)) == repr((1,))
    assert repr(register(10, 42, 255)) == repr((10, 42, 255))
    assert register("red") == "\x1b[38;2;255;0;0m"
    assert register("green") == ""

# Generated at 2022-06-12 09:51:06.554027
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightBit, RgbFg, Sgr

    # Test if correct type of rendertype is called if only one arg is given.
    register = Register()
    register.renderfuncs = {EightBit: lambda x: "", RgbFg: lambda r, g, b: ""}
    register.eightbit_call = lambda x: ""
    register.rgb_call = lambda r, g, b: ""

    register.yellow = Style(EightBit(3), Sgr(1))

    # Test if a call to attribute 'yellow' returns the string "yellow".
    assert register.yellow == "\x1b[1m"
    # Test if a call to attribute 'yellow' returns the style "yellow".
    assert register("yellow") == "\x1b[1m"
    # Test if a call to the register object with

# Generated at 2022-06-12 09:51:13.330080
# Unit test for constructor of class Style
def test_Style():

    assert str(Style("42", "43")) == "42;43"

# Generated at 2022-06-12 09:51:22.045227
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .sty import fg, bg, RgbFg, RgbBg, Sgr

    # 1.
    # Test if Rendertype is rendered correctly
    fg.pink = Style(RgbFg(10, 10, 10), RgbFg(10, 10, 10))
    assert str(fg.pink) == "\x1b[38;2;10;10;10m\x1b[38;2;10;10;10m"

    fg.set_eightbit_call(RgbFg)
    # Test if fg.pink is updated
    assert str(fg.pink) == "\x1b[38;2;10;10;10m"

    # Test if fg call still works
    assert fg(100) == "\x1b[38;5;100m"

# Generated at 2022-06-12 09:51:32.584147
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .ansifuncs import ansi_rgb_fg
    from .rendertypes import RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, ansi_rgb_fg)
    r.set_rgb_call(RgbFg)
    r.red = Style(RgbFg(255, 0, 0))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r('red') == "\x1b[38;2;255;0;0m"

    r.set_rgb_call(RgbFg)
    assert r('red') == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-12 09:51:39.119937
# Unit test for method unmute of class Register
def test_Register_unmute():
    class TestRegister(Register):
        black = Style()
        red = Style(Sgr(1))

    t = TestRegister()
    assert t.as_dict() == {"black": "", "red": "\x1b[1m"}

    t.mute()
    assert t.as_dict() == {"black": "", "red": ""}

    t.unmute()
    assert t.as_dict() == {"black": "", "red": "\x1b[1m"}

# Generated at 2022-06-12 09:51:46.747822
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .render import sgr, rgb_fg, rgb_bg, xterm_fg, xterm_bg, set_256_fg, set_256_bg

    t = Register()
    t.set_renderfunc(sgr, _render_sgr)
    t.set_renderfunc(rgb_fg, _render_rgb_fg)
    t.set_renderfunc(rgb_bg, _render_rgb_bg)
    t.set_renderfunc(xterm_fg, _render_xterm_fg)
    t.set_renderfunc(xterm_bg, _render_xterm_bg)
    t.set_renderfunc(set_256_fg, _render_set_256_fg)
    t.set_renderfunc(set_256_bg, _render_set_256_bg)

   

# Generated at 2022-06-12 09:51:52.697880
# Unit test for method copy of class Register
def test_Register_copy():
    rg1 = Register()
    rg1.one = Style()
    rg1.two = Style()

    rg2 = rg1.copy()
    rg2.one = Style()
    rg2.two = Style()
    rg2.tree = Style()

    rg3 = rg2.copy()

    assert rg1.one == rg2.one
    assert rg2.one != rg2.tree
    assert rg1.one == rg3.one

# Generated at 2022-06-12 09:52:03.181156
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    For this test, we define a custom rendertype that always returns "Renderer called!"
    and a custom renderfunc that renders the rendertype.
    """

    class CustomRenderer(RenderType):
        args = ["r", "g", "b"]

    def f1(*args, **kwargs):
        """
        The custom renderfunc.
        """
        return "Renderer called!"

    # Create register
    register = Register()

    # Add renderfunc to register
    register.set_renderfunc(CustomRenderer, f1)

    # Update the rgb-call for this register
    register.set_rgb_call(CustomRenderer)

    # Make a call for a rgb-code
    assert register(1, 2, 3) == "Renderer called!"


# Generated at 2022-06-12 09:52:11.125284
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .sgr import Sgr

    from .rgb_bg import RgbBg
    from .rgb_fg import RgbFg
    from .rgb_ef import RgbEf
    from .rgb_rs import RgbRs


    def render(r: int, g: int, b: int) -> str:
        return f"{r},{g},{b}"

    fg = Register()
    fg.set_rgb_call(RgbFg)

    fg.set_renderfunc(RgbFg, render)


    assert fg(10, 42, 255) == "10,42,255"

    class Test(NamedTuple):
        r: int
        g: int
        b: int


# Generated at 2022-06-12 09:52:19.531814
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRegister(Register):
        pass

    r = TestRegister()
    sgr = r.rs.copy()
    sgr.rules += (1, 2)
    r.bold = sgr
    assert isinstance(r.bold, Style)
    assert str(r.bold) == "\x1b[0m\x1b[1;2m"

    test = r.copy()
    test.set_eightbit_call(Sgr)
    assert str(test.bold) == "\x1b[0;1;2m"


# Generated at 2022-06-12 09:52:29.114990
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    This test tests the method set_renderfunc of class Register.

    """
    class Renderer(NamedTuple):
        ansi_code: str = ""

        def render(self, *args):
            return self.ansi_code

    r1 = Renderer("\x1b[1m")
    r2 = Renderer("\x1b[7m")

    style = Style(r1, r2)
    expected = "\x1b[1m\x1b[7m"

    assert str(style) == expected

    def f2(r2):
        return r2.render()

    reg = Register()

    reg.set_renderfunc(Renderer, f2)

    assert str(style) == expected

# Generated at 2022-06-12 09:52:43.808094
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Create test-register
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.test = Style(RgbFg(0, 0, 0))

    # Create Register instance
    r = TestRegister()

    # Add two render functions
    r.set_renderfunc(RgbFg, lambda *x: "rgb")
    r.set_renderfunc(EightbitFg, lambda *x: "eight")

    # Set eightbit-call to rgb
    r.set_eightbit_call(RgbFg)

    # Check for correct behavior
    assert r(1) == "rgb"
    assert r(2, 3, 4) == "rgb"
    assert r.test == "rgb"



# Generated at 2022-06-12 09:52:51.422198
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import sty
    from collections import namedtuple
    from typing import NamedTuple

    sty.theme_use("default")
    sty.register_theme("test", fg="white", bg="black")
    sty.theme_use("test")

    fg = sty.fg
    bg = sty.bg
    ef = sty.ef

    assert isinstance(fg.as_namedtuple(), NamedTuple)

    assert ef.as_namedtuple().bold == "\x1b[1m"
    assert bg.as_namedtuple().black == "\x1b[40m"
    assert fg.as_namedtuple().white == "\x1b[37m"

    sty.theme_use("default")



# Generated at 2022-06-12 09:52:57.208925
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr

    # Setup
    r = Register()
    
    r.renderfuncs[Sgr] = lambda *x: str(x[0]) + ";"
    r.mute()
    r.set_renderfunc(Sgr, lambda *x: ";")

    r.foo = Style(Sgr(1))
    r.bar = Style(Sgr(2))

    # Tests
    assert r.foo == ""
    assert r.bar == ""

    r.foo = Style(Sgr(2))

    assert r.foo == ""

    r.unmute()

    assert r.foo == "2"

    r.foo = Style(Sgr(3))

    assert r.foo == "2"



# Generated at 2022-06-12 09:52:58.292068
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    pass



# Generated at 2022-06-12 09:53:02.487413
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register = Register()

    setattr(register, "test", Style(value="test"))
    assert getattr(register, "test") == "test"

    setattr(register, "test", Style(value="test2"))
    assert getattr(register, "test") == "test2"

    register2 = Register()
    assert getattr(register2, "test", None) is None


# Generated at 2022-06-12 09:53:10.221665
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg, RgbBg, Sgr

    style1 = Style(RgbFg(255, 0, 0), Sgr(1))
    assert isinstance(style1, Style) is True
    assert isinstance(style1, str) is True

    style2 = Style(RgbBg(255, 0, 0), Sgr(1))
    assert isinstance(style2, Style) is True
    assert isinstance(style2, str) is True


# Generated at 2022-06-12 09:53:14.657694
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class TestRegister(Register):
        pass

    t1 = TestRegister()
    t1.blue = Style(RgbFg(0, 0, 255))

    tp1 = t1.as_namedtuple()

    assert isinstance(tp1, NamedTuple)
    assert tp1 == ("\x1b[38;2;0;0;255m",)

    tp2 = TestRegister().as_namedtuple()

    assert isinstance(tp2, NamedTuple)

# Generated at 2022-06-12 09:53:21.577075
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import RenderType, RgbBg, RgbFg, Register, Style, fg, bg

    fg.renderfuncs = {RgbFg: lambda x, y, z: "a"}
    bg.renderfuncs = {RgbBg: lambda x, y, z: "b"}
 
    fg.rgb_call = lambda x, y, z: "c"

    fg.set_rgb_call(RgbBg)

    assert fg.rgb_call(42, 42, 42) == "b"

# Generated at 2022-06-12 09:53:32.524911
# Unit test for method copy of class Register
def test_Register_copy():
    import sys

    if sys.version_info[:2] == (3, 8):
        from .renderfunctions import basic256, default16
    else:
        from .renderfunctions import truecolor

    fg = Register()
    fg.set_renderfunc(RenderType.EightbitFg, basic256)
    fg.set_renderfunc(RenderType.RgbFg, truecolor)
    fg.set_eightbit_call(RenderType.EightbitFg)
    fg.set_rgb_call(RenderType.RgbFg)
    fg.white = RenderType.EightbitFg(255)
    fg.white_bold = RenderType.Bold(fg.white)

    fg_copy = fg.copy()

# Generated at 2022-06-12 09:53:39.978075
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class TestRegister(Register):
        red = Style(RgbFg(1, 0, 0))
        blue = Style(RgbFg(0, 0, 1))
        yellow = Style(RgbFg(1, 1, 0))
        orange = Style(RgbFg(1, 0.5, 0))

    test_reg = TestRegister()
    nt = test_reg.as_namedtuple()

    assert nt.red == test_reg.red
    assert nt.yellow == test_reg.yellow
    assert nt.blue == test_reg.blue
    assert nt.orange == test_reg.orange
    assert nt.red_blue == ""



# Generated at 2022-06-12 09:53:55.135604
# Unit test for method mute of class Register
def test_Register_mute():

    class DummyRegister(Register):
        def __init__(self):
            super().__init__()
            self.rgb_call = lambda *args, **kwargs: "rgb"
            self.eightbit_call = lambda *args, **kwargs: "eightbit"

    dummy_register = DummyRegister()
    dummy_register.rule1 = Style("rule1")
    dummy_register.rule2 = Style("rule2")

    # check if unmuted register object works
    assert dummy_register("rule1") == "rgb"
    assert dummy_register(1) == "eightbit"
    assert dummy_register("rule2") == "rule2"

    # mute register and check if the register works
    dummy_register.mute()
    assert dummy_register("rule1") == ""

# Generated at 2022-06-12 09:54:02.261628
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    # Set color to orange and bold
    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(fg.orange, Style)  # Is fg.orange a Style-object?
    assert isinstance(fg.orange, str)  # Is fg.orange a string?
    assert str(fg.orange) == "\x1b[38;2;1;5;10m\x1b[1m"  # Is the output like expected?

# Generated at 2022-06-12 09:54:12.937329
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .sgr import RgbFg, Sgr

    class TestRegister(Register):
        green = Style(RgbFg(0, 255, 0))
        bold = Style(Sgr(1))

    t1 = TestRegister()

    s1 = str(t1.green)
    s2 = str(t1.bold)

    assert s1 == "\x1b[38;2;0;255;0m"
    assert s2 == "\x1b[1m"

    from .sgr import HiFg, HiBg
    from .sgr import RgbHiFg, RgbHiBg


# Generated at 2022-06-12 09:54:19.501380
# Unit test for constructor of class Style
def test_Style():
    assert (str(Style(RgbFg(10, 30, 50), value="\x1b[38;2;10;30;50m")) ==
            "\x1b[38;2;10;30;50m")
    assert (str(Style(RgbFg(10, 30, 50))) == "\x1b[38;2;10;30;50m")
    assert (str(Style(RgbBg(10, 30, 50), Sgr(1), RgbFg(10, 30, 50))) ==
            "\x1b[48;2;10;30;50m\x1b[38;2;10;30;50m\x1b[1m")


# Generated at 2022-06-12 09:54:28.802709
# Unit test for method copy of class Register
def test_Register_copy():
    from .fg import fg as fg1
    from .bg import bg as bg1

    fg2 = fg1.copy()

    fg1.red.rules = [fg1.Red, fg1.Intense]
    fg2.red.rules = [fg2.Red]

    assert fg1.is_muted == fg2.is_muted
    assert fg1.eightbit_call == fg2.eightbit_call
    assert fg1.rgb_call == fg2.rgb_call

    assert fg1.red != fg2.red
    assert fg1.red.rules != fg2.red.rules

# Generated at 2022-06-12 09:54:33.152948
# Unit test for constructor of class Style
def test_Style():
    test_style = Style(RgbFg(10, 20, 30), Sgr(1))
    assert isinstance(test_style, Style)
    assert isinstance(test_style, str)
    assert str(test_style) == "\x1b[38;2;10;20;30m\x1b[1m"



# Generated at 2022-06-12 09:54:41.272550
# Unit test for method unmute of class Register
def test_Register_unmute():
    class X(RenderType):
        _format_str = "X"

    class Y(RenderType):
        _format_str = "Y"

    class Reg(Register):
        pass

    reg = Reg()
    reg.set_renderfunc(X, lambda *x: "X")
    reg.set_renderfunc(Y, lambda *x: "Y")

    # Create test style
    reg.x = reg.y = Style(X(), Y())

    # Make sure the style is rendered correctly
    assert str(reg.x) == "XY"

    # Mute and make sure style is not rendered
    reg.mute()
    assert str(reg.x) == ""
    assert str(reg.y) == ""

    # Unmute and make sure style is rendered again
    reg.unmute()

# Generated at 2022-06-12 09:54:46.507767
# Unit test for method copy of class Register
def test_Register_copy():

    from .defaults import fg, bg

    new_fg = fg.copy()
    new_bg = bg.copy()
    new_fg.red = "test"

    assert fg.red != new_fg.red
    assert bg.red == new_bg.red

# Generated at 2022-06-12 09:54:51.865573
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"
    assert s.rules == (RgbFg(1, 5, 10), Sgr(1))

# Generated at 2022-06-12 09:54:53.919217
# Unit test for constructor of class Register
def test_Register():

    # Test constructor
    reg = Register()

    assert isinstance(reg, Register)

    assert reg.renderfuncs == {}

    assert reg.is_muted == False

# Generated at 2022-06-12 09:55:11.016172
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .sgr import Sgr, SgrFg, SgrBg, SgrFg256, SgrBg256, SgrFgRgb, SgrBgRgb
    from .truecolor import RgbFg, RgbBg
    from .bg import Bg, Bg256, BgRgb
    from .fg import Fg, Fg256, FgRgb
    from .rgb import Rgb
    from .rules import Underline, Intense, StrikeThrough

    register = Register()
    register.set_renderfunc(Sgr, lambda x: chr(x))
    register.set_renderfunc(SgrFg, lambda x: chr(x))
    register.set_renderfunc(SgrBg, lambda x: chr(x))

# Generated at 2022-06-12 09:55:14.108887
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    assert isinstance(Style("foo"), Style)
    assert isinstance(Style("foo"), str)
    assert str(Style("foo")) == "foo"



# Generated at 2022-06-12 09:55:25.905558
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test if muting the eightbit and rgb-render-functions works correctly.
    """

    def func_eightbit(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    def func_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    reg = Register()
    setattr(reg, "black", Style(Sgr(1)))
    reg.set_eightbit_call(EightbitRgbFg)
    reg.set_rgb_call(RgbFg)
    reg.set_renderfunc(EightbitRgbFg, func_eightbit)

# Generated at 2022-06-12 09:55:35.132527
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test the deepcopy functionality of the register class.
    """
    # Create class
    class CustomRegister(Register):
        def __init__(self, x: float, y: float):
            super().__init__()
            self.x = x
            self.y = y

    # Create instance
    r1 = CustomRegister(1.0, 42.0)

    # Run tests
    r2 = r1.copy()
    assert(r2 == r1)

    r2.x = 0
    assert(r2 != r1)

    r2 = r1.copy()
    assert(r2 == r1)

# Generated at 2022-06-12 09:55:40.402480
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    ef = Register()
    ef.red = Style(Sgr(1))
    ef.blue = Style(Sgr(2))
    ef.green = Style(Sgr(3))

    assert isinstance(ef.as_dict(), dict)
    assert ef.as_dict()["red"] == "\x1b[1m"
    assert ef.as_dict()["blue"] == "\x1b[2m"
    assert ef.as_dict()["green"] == "\x1b[3m"


# Generated at 2022-06-12 09:55:49.257537
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    # Create a new register-object.
    rg = Register()

    # Set renderfunctioons to register
    rg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;r;g;bm")
    rg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;r;g;bm")

    # Add two new styles to the register.
    rg.color = Style(RgbFg(0, 0, 0), RgbBg(255, 255, 255))
    rg.color2 = Style(RgbFg(23, 42, 8), RgbBg(11, 22, 33))

    # Change the rendertype for RGB

# Generated at 2022-06-12 09:55:59.975799
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from sty import RenderType, Style

    r1 = RenderType("r1", "Format R1")
    r2 = RenderType("r2", "Format R2")

    def f1(arg1: int, arg2: int):
        return f"{r1.name} {arg1} {arg2}"

    def f2(arg1: int, arg2: int):
        return f"{r2.name} {arg1} {arg2}"

    class MyRegister(Register):
        r1 = Style(r1(5, 2))
        r2 = Style(r2(5, 2))

    reg = MyRegister()

    # renderfunc for 8bit-calls
    reg.set_eightbit_call(r1)
    assert reg(5, 2) == "r1 5 2"

    # renderfunc

# Generated at 2022-06-12 09:56:08.188554
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Unit test for method __new__ of class Style
    """

    from sty import fg

    assert fg.red == Style(Sgr(38, 5, 1))
    assert fg.red.rules == (Sgr(38, 5, 1),)
    assert str(fg.red) == "\x1b[38;5;1m"
    assert isinstance(fg.red, Style)
    assert isinstance(fg.red, str)
    assert fg.red[0] == "\x1b"
    assert isinstance(Style(Sgr(38, 5, 1)), Style)
    assert isinstance(Style(Sgr(38, 5, 1)), str)
    assert isinstance(Style(Sgr(38, 5, 1)), Style)

# Generated at 2022-06-12 09:56:12.695266
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test that muting a register works.
    """

    import pytest

    from .register import Register

    class TestRegister(Register):
        pass

    register = TestRegister()
    register.black = Style(RgbFg(0, 0, 0))
    register.blue = Style(RgbFg(0, 0, 255))

    register.mute()

    assert register.black == ""
    assert register.blue == ""



# Generated at 2022-06-12 09:56:21.820042
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Sty1(Register):

        def __init__(self):
            super().__init__()

            class SgrA(RenderType):
                renderfunc = lambda x: "S"

            class SgrB(RenderType):
                renderfunc = lambda x: "B"

            self.set_renderfunc(SgrA, SgrA.renderfunc)
            self.set_renderfunc(SgrB, SgrB.renderfunc)

            # Default is set to SgrA.
            self.set_eightbit_call(SgrA)


    class Sty2(Register):

        def __init__(self):
            super().__init__()

            class SgrA(RenderType):
                renderfunc = lambda x: "S"


# Generated at 2022-06-12 09:56:39.767335
# Unit test for method mute of class Register
def test_Register_mute():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.mute()
    assert str(fg.red) == ""

# Generated at 2022-06-12 09:56:48.130263
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import Sgr, XtermFg256

    renderfunc = lambda *args: "\x1b[" + ";".join(str(arg) for arg in args) + "m"

    # Create Register
    r = Register()
    r.set_renderfunc(Sgr, renderfunc)
    r.set_renderfunc(XtermFg256, renderfunc)

    setattr(r, "red", Style(Sgr(1)))
    setattr(r, "blue", Style(XtermFg256(51)))

    # Test
    assert isinstance(r, Register)
    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)
    assert r.red == "\x1b[1m"

# Generated at 2022-06-12 09:56:55.319234
# Unit test for method __new__ of class Style
def test_Style___new__():
    import pytest
    from .rules import RgbFg
    test_style = Style(RgbFg(1, 5, 10), value="\x1b[38;2;1;5;10m")

    assert isinstance(test_style, str)
    assert isinstance(test_style, Style)
    assert str(test_style) == "\x1b[38;2;1;5;10m"


# Generated at 2022-06-12 09:56:59.729985
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Set up
    class ColorRegister(Register):
        pass

    color_register = ColorRegister()
    color_register.blue = Style("", Sgr(4))
    color_register.set_renderfunc(Sgr, lambda x: "\x1b[{}m".format(x))

    nt = color_register.as_namedtuple()

    assert nt.blue == "\x1b[4m"

# Generated at 2022-06-12 09:57:04.700991
# Unit test for constructor of class Register
def test_Register():

# Prove that all default Registers are instances of the Register class.
    from sty import fg, bg, ef, rs, fx
    assert isinstance(fg, Register)
    assert isinstance(bg, Register)
    assert isinstance(ef, Register)
    assert isinstance(fx, Register)
    assert isinstance(rs, Register)



# Generated at 2022-06-12 09:57:09.379217
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import Sgr, RgbFg

    green = Style(Sgr(32), RgbFg(0, 255, 0))
    assert green.rules[0].args == (32,)
    assert green.rules[1].args == (0, 255, 0)

    assert green == "\x1b[32;38;2;0;255;0m"



# Generated at 2022-06-12 09:57:11.672151
# Unit test for method __new__ of class Style
def test_Style___new__():
    # arrange
    rules = ["#fff"]

    # act
    style = Style(*rules)

    # assert
    assert style == "#fff"
    assert style.rules == ["#fff"]


# Generated at 2022-06-12 09:57:17.595907
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Sgr(RenderType):
        def render(self, *args):
            return "\x1b[{}m".format("".join(map(str, args)))

    r = Register()
    r.set_renderfunc(Sgr, Sgr.render)
    r.set_eightbit_call(Sgr)
    assert r(42) == "\x1b[42m"



# Generated at 2022-06-12 09:57:20.004581
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.red = Style(Sgr(1), Sgr(31))

    assert r.as_dict() == {"red": "\x1b[1m\x1b[31m"}

# Generated at 2022-06-12 09:57:28.101787
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Ef, Fg, Sgr
    
    sty = Register()
    sty.red = Style(Fg(255,0,0))
    sty.bold = Style(Sgr(1))

    sty.mute()
    assert sty.red == Style(Fg(255,0,0))
    assert sty.bold == Style(Sgr(1))

    sty.unmute()
    assert sty.red == Style(Fg(255,0,0), value='\x1b[38;2;255;0;0m')
    assert sty.bold == Style(Sgr(1), value='\x1b[1m')


# Generated at 2022-06-12 09:58:10.345639
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg
    from . import Sty
    stylist = Sty()

    stylist.fg.yellow = RgbFg(1, 1, 1)
    assert str(stylist.fg.yellow) == '\x1b[38;2;1;1;1m'

    stylist.fg.mute()
    stylist.fg.yellow = RgbFg(1, 1, 1)
    assert str(stylist.fg.yellow) == ''

    stylist.fg.unmute()
    assert str(stylist.fg.yellow) == '\x1b[38;2;1;1;1m'


if __name__ == "__main__":
    test_Register_unmute()
    print("Everything passed")

# Generated at 2022-06-12 09:58:18.993796
# Unit test for method mute of class Register
def test_Register_mute():

    fg = Register()
    fg.set_renderfunc(RenderType, lambda x: x)

    fg.red = Style(RenderType(1))
    fg.blue = Style(RenderType(2))

    fg.mute()

    assert isinstance(fg.red, Style)
    assert isinstance(fg.blue, Style)
    assert str(fg.red) == ""
    assert str(fg.blue) == ""

    fg.unmute()

    assert isinstance(fg.red, Style)
    assert isinstance(fg.blue, Style)
    assert str(fg.red) == "1"
    assert str(fg.blue) == "2"



# Generated at 2022-06-12 09:58:24.462014
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Here we check if the Register.mute() method is working as expected.
    """
    from .render import eightbit, rgb, sgr

    class Reg(Register):
        pass

    # TODO: Write tests for 24bit-values.
    reg = Reg()
    reg.renderfuncs.update({eightbit: lambda x: "X" * x, rgb: lambda r, g, b: "Y" * r + "Z" * g + "U" * b, sgr: lambda x: str(x)})

    reg.test = Style(eightbit(145), sgr(1), rgb(150, 75, 200), sgr(2))
    assert reg.test == "XXXXXXYYYUUZUUU1Y150Z75U2002"

    reg.mute()
    assert reg.test == ""

   

# Generated at 2022-06-12 09:58:33.538418
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Eightbit, RgbFg

    # SGR-attributes can be registers.
    fg = Register()
    fg.white = Style(Eightbit(255), Eightbit(255), Eightbit(255))

    # Calls to fg(255) return the attribute 'white'.
    assert fg(255) == fg.white

    # A more complex test
    fg.white = Style(Eightbit(255), Eightbit(255), Eightbit(255))
    assert fg(255) == fg.white

    # Calls to fg('white') return the attribute 'white'.
    assert fg('white') == fg.white

    # Calls to fg(255, 255, 255) return the attribute 'white'.
    fg.rgbfg = RgbFg(255, 255, 255)


# Generated at 2022-06-12 09:58:39.087081
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class DummyRegister(Register):
        my_cool_color = Style(Fg(10), Bold())
        another_cool_color = Style(Fg(20), Underline())

    reg = DummyRegister()
    reg.unmute()
    nt = reg.as_namedtuple()

    assert isinstance(nt, namedtuple)
    assert nt.my_cool_color == "\x1b[38;5;10m\x1b[1m"
    assert nt.another_cool_color == "\x1b[38;5;20m\x1b[4m"

# Generated at 2022-06-12 09:58:41.876012
# Unit test for method __new__ of class Style
def test_Style___new__():

    rgb = RenderType("Rgb", "RgbFg", (1, 2, 3))

    sgr = RenderType("Sgr", "Sgr", (1,))

    style = Style(rgb, sgr)

    assert isinstance(style, Style)



# Generated at 2022-06-12 09:58:51.628071
# Unit test for method unmute of class Register
def test_Register_unmute():
    import styx

    # Define new register-object
    class CustomRegister(Register):

        def __init__(self):
            super().__init__()
            self.some_style = Style(styx.RgbFg(0, 2, 3))

    # Create new register instance
    custom_register = CustomRegister()
    custom_register.unmute()

    # Verify style of register-object is rendered as ansi-sequence
    assert str(custom_register.some_style) == "\x1b[38;2;0;2;3m"

    # Mute register-object
    custom_register.mute()

    # Verify style is not rendered as ansi-sequence
    assert str(custom_register.some_style) == ""


# Generated at 2022-06-12 09:58:55.869540
# Unit test for constructor of class Style
def test_Style():
    r1 = RenderType(Sgr(1))
    r2 = RenderType(RgbFg(1, 2, 3))
    s1 = Style(r1, r2)

    assert isinstance(s1, Style)
    assert str(s1) == "\x1b[1m\x1b[38;2;1;2;3m"


# Unit-test for RenderType.

# Generated at 2022-06-12 09:59:00.499802
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbBg

    x = Style(RgbBg(1, 1, 1), value="\x1b[48;2;1;1;1m")

    assert isinstance(x, Style)
    assert isinstance(x, str)
    assert len(x.rules) == 1
    assert str(x) == "\x1b[48;2;1;1;1m"

# Generated at 2022-06-12 09:59:09.751617
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test for method mute.
    """
    # Initialize register as test subject.
    register = Register()

    # Set attribut to a style-instance.
    setattr(register, "test", Style(Sgr(1)))
    # TODO: How to assert that the value of the attribute remained unchanged?

    # Mute the register.
    register.mute()
    # TODO: How to assert that the value of the attribute changed to empty string?

    # Retreve the attribute.
    retr_style = getattr(register, "test")
    # TODO: How to assert that the value of the attribute remained unchanged?

    # Unmute the register.
    register.unmute()
    # TODO: How to assert that the value of the attribute changed to empty string?

    # Retreve the attribute.
    retr