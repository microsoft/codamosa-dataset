

# Generated at 2022-06-12 09:49:58.356930
# Unit test for method copy of class Register
def test_Register_copy():

    from .defaults import fg

    fg_copy = fg.copy()

    assert fg_copy.red == fg.red
    assert fg_copy.is_muted == fg.is_muted

    fg_copy.red = "foo"  # type: ignore

    assert fg_copy.red != fg.red



# Generated at 2022-06-12 09:50:05.799303
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class MyRenderType(RenderType):
        renderfunc = lambda x: x

    class MyRegister(Register):

        my_rule: Style

        def __init__(self):
            super().__init__()
            self.set_renderfunc(MyRenderType, MyRenderType.renderfunc)
            # Register should return 42 for calls like MyRegister()
            self.set_eightbit_call(MyRenderType)
            self.my_rule = Style(MyRenderType(42))

    mr = MyRegister()
    assert str(mr()) == "42"
    assert str(mr.my_rule) == "42"


#

# Generated at 2022-06-12 09:50:11.761799
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class MyRegister(Register):
        pass

    c: MyRegister = MyRegister()
    assert callable(c.eightbit_call)

    class MyRenderType(RenderType):
        pass

    c.set_renderfunc(MyRenderType, lambda x: "test")
    assert c.eightbit_call is None

    c.set_eightbit_call(MyRenderType)
    assert c.eightbit_call(5) == "test"

# Generated at 2022-06-12 09:50:18.289781
# Unit test for constructor of class Register
def test_Register():
    r = Register()

    r.set_renderfunc(RenderType.EIGHTBIT, lambda x: "eightbit")
    r.set_renderfunc(RenderType.RGB, lambda r, g, b: "rgb")

    r.set_eightbit_call(RenderType.EIGHTBIT)
    r.set_rgb_call(RenderType.RGB)

    assert r(42) == "eightbit"
    assert r(1, 2, 3) == "rgb"



# Generated at 2022-06-12 09:50:20.538296
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    rules = [Sgr(1)]

    style = Style(*rules)

    assert isinstance(style, Style)

    register = Register()

    register.test = style



# Generated at 2022-06-12 09:50:31.244383
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertypes import RgbEf, Sgr
    bg = Register()
    bg.renderfuncs = {RgbEf: lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m"}
    bg.renderfuncs.update({Sgr: lambda s: f"\x1b[{s}m"})
    bg.red = Style(RgbEf(255, 0, 0), Sgr(1))
    assert bg.red == "\x1b[48;2;255;0;0m\x1b[1m"
    bg.red = Style(RgbEf(255, 0, 0))
    assert bg.red == "\x1b[48;2;255;0;0m"

# Generated at 2022-06-12 09:50:38.273402
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit test for method __call__ of class Register.
    """

    r = Register()
    r.set_eightbit_call(RenderType.Eightbit)
    r.set_rgb_call(RenderType.RgbFg)
    r.eightbit_call = lambda x: "8bit"
    r.rgb_call = lambda r, g, b: "rgb"

    assert r(10) == "8bit"
    assert r(100, 155, 255) == "rgb"



# Generated at 2022-06-12 09:50:47.454714
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    The method __setattr__ at class Register should check if the input value
    is of type `Style` and, if so, use the renderfuncs to render the style-rules
    and update the value attribute with the resulting ANSI sequence.
    """

    class Render1(RenderType):
        """
        Dummy class for the first test
        """

    f1 = lambda x: "\x1b[38;2;{};{};{}m".format(x[0], x[1], x[2])
    register = Register()
    register.set_renderfunc(Render1, f1)

    r1 = Style(Render1((1, 5, 10)), value="")
    register.fg = r1

    assert str(register.fg) == "\x1b[38;2;1;5;10m"
   

# Generated at 2022-06-12 09:50:53.247413
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .sgr import Sgr
    from .rgb import RgbFg, RgbBg, RgbEf

    f = Register()

    # Create a style and set mute
    f.test = Style(Sgr("italic"))

    f.mute()

    # Set unmute
    f.unmute()

    # Test result
    assert str(f.test) == "\x1b[3m"


# Generated at 2022-06-12 09:51:03.752130
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    test_register = Register()

    test_register.__setattr__("test", Style(RgbFg(23, 42, 55), Sgr(1)))
    assert getattr(test_register, "test") == "\x1b[38;2;23;42;55m\x1b[1m"

    test_register.set_eightbit_call(RgbFg)
    test_register.set_eightbit_call(RgbBg)
    test_register.set_eightbit_call(Sgr)

    assert callable(test_register)
    assert test_register(23) == "\x1b[38;2;23;23;23m"
    assert test_register(23, 1) == "\x1b[48;2;23;23;23m"

# Generated at 2022-06-12 09:51:14.357949
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(), Style)
    assert isinstance(Style(value="test"), Style)
    assert isinstance(Style(1, 2, value="test"), Style)

    assert isinstance(Style(), str)
    assert isinstance(Style(value="test"), str)
    assert isinstance(Style(1, 2, value="test"), str)

    assert Style() == ""
    assert Style(value="test") == "test"
    assert Style(1, 2, value="test") == "test"



# Generated at 2022-06-12 09:51:18.999709
# Unit test for method mute of class Register
def test_Register_mute():

    r = Register()
    setattr(r, "test", Style(RgbFg(5, 5, 5)))
    assert "\x1b[38;2;5;5;5m" == r.test
    r.mute()
    assert r.test == ""
    r.unmute()
    assert "\x1b[38;2;5;5;5m" == r.test



# Generated at 2022-06-12 09:51:29.014039
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg

    def func(param1: str) -> str:
        return f"\x1b[{param1}m"

    reg_obj = Register()

    # Make a new register
    reg_obj.set_renderfunc(RgbFg, func)

    # Define new style
    reg_obj.new_style = Style(RgbFg(42, 10, 20))

    # Call register
    assert reg_obj(8) == "\x1b[8m"

    # Set new rendertype for Eightbit-calls
    reg_obj.set_eightbit_call(RgbFg)

    # Call register
    assert reg_obj(8) == "\x1b[8;2;42;10;20m"

    # Call register with style name
    assert reg

# Generated at 2022-06-12 09:51:35.982623
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    setattr(register, "test", Style())

    # Create namedtuple with function as_namedtuple()
    register_tuple = register.as_namedtuple()
    # Create namedtuple with hardcoded values
    register_tuple2 = namedtuple(
        "Style",
        ("test", ),
        defaults=("",),
    )

    # Compare named tuples
    assert register_tuple == register_tuple2

# Generated at 2022-06-12 09:51:43.794021
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    style1 = Style(RgbFg(1, 2, 3))
    style2 = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(style1, str)
    assert isinstance(style1, Style)
    assert isinstance(style1.rules[0], RgbFg)

    assert isinstance(style2, str)
    assert isinstance(style2, Style)
    assert isinstance(style2.rules[0], RgbFg)
    assert isinstance(style2.rules[1], Sgr)



# Generated at 2022-06-12 09:51:46.199947
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()

    register.foo = Style(value="bar")
    register.bar = Style(value="foo")

    register.as_namedtuple()



# Generated at 2022-06-12 09:51:56.519971
# Unit test for constructor of class Style
def test_Style():

    a = Style(value="\x1b[1m")
    assert isinstance(a, Style)
    assert isinstance(a, str)
    assert a == "\x1b[1m"

    # test if multiple RenderType instances are rendered correctly
    b = Style(value="\x1b[1m\x1b[2m")
    assert isinstance(b, Style)
    assert isinstance(b, str)
    assert b == "\x1b[1m\x1b[2m"

    # test if nested Style instances are rendered correctly
    c = Style(value="\x1b[1m\x1b[2m")
    d = Style(c, value="\x1b[3m")
    assert isinstance(c, Style)
    assert isinstance(d, Style)

# Generated at 2022-06-12 09:52:06.738707
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test cases for the method `__setattr__` of the class `Register`.

    Checks:

        1. If a correctly built style is created.
        2. If the rules of a style are correctly transformed into a ANSI-string.
        3. If non-style objects raise ValueError.
    """

    # Test case 1: correct style creation.
    fg = Register()
    renderfunc1 = lambda *args: '\x1b[38;2;{};{};{}m'.format(args[0], args[1], args[2])
    fg.set_renderfunc(RgbFg, renderfunc1)

    fg.red = Style(RgbFg(255, 0, 0))
    fg.orange = Style(RgbFg(255, 155, 55))


# Generated at 2022-06-12 09:52:18.799742
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr

    # Create register and add renderfuncs.
    reg = Register()
    reg.set_renderfunc(RgbFg, RgbFg.render)
    reg.set_renderfunc(Sgr, Sgr.render)

    # Create new styles
    red = Style(RgbFg(255, 0, 0), Sgr(1))
    blue = Style(RgbFg(0, 0, 255), Sgr(2))
    yellow = Style(RgbFg(255, 255, 0))

    # Set new attributes
    reg.red = red
    reg.blue = blue
    reg.yellow = yellow

    # Get attributes
    assert isinstance(reg.red, Style)
    assert isinstance(reg.blue, Style)

# Generated at 2022-06-12 09:52:25.388739
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    RegisterClass = namedtuple("RegisterClass", ["rgb_call", "renderfuncs", "attr"])
    register_class = RegisterClass(
        rgb_call=lambda x, y, z: (x, y, z),
        renderfuncs={},
        attr=Style(value="\x1b[42m"),
    )
    register = Register()
    register.__dict__.update(register_class.__dict__)
    assert register.as_dict() == {"attr": "\x1b[42m"}, "Register.as_dict works incorrectly."



# Generated at 2022-06-12 09:52:43.920705
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # =================================================================================
    # Test setup
    # =================================================================================

    class TestRenderType0(RenderType):
        args = None
        ansi = lambda: ""

    class TestRenderType1(RenderType):
        args = None
        ansi = lambda: ""

    class TestRenderType2(RenderType):
        args = None
        ansi = lambda: ""

    class TestRenderType3(RenderType):
        args = None
        ansi = lambda: ""

    class TestRenderType4(RenderType):
        args = None
        ansi = lambda: ""

    class TestRenderType5(RenderType):
        args = None
        ansi = lambda: ""

    def func0(*args: int):
        return ""

    def func1(*args: int):
        return ""

    def func2(*args: int):
        return

# Generated at 2022-06-12 09:52:51.853643
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RGBSGR(NamedTuple):
        r: int
        g: int
        b: int
        reset: bool = False
        bright: bool = False
        italic: bool = False
        underline: bool = False
        blink: bool = False
        strikeout: bool = False

    class RGB(NamedTuple):
        r: int
        g: int
        b: int

    class SGR(NamedTuple):
        reset: bool = False
        bright: bool = False
        italic: bool = False
        underline: bool = False
        blink: bool = False
        strikeout: bool = False

    class Register(Register):

        def __init__(self):

            super().__init__()


# Generated at 2022-06-12 09:52:59.666963
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test for method as_dict of class Register.
    """
    # Create a new instance of the Register class
    R = Register()

    # Assign new attributes
    R.red = Style(RgbFg(255, 0, 0))
    R.green = Style(RgbFg(0, 255, 0))
    R.blue = Style(RgbFg(0, 0, 255))
    R.yellow = Style(RgbFg(255, 255, 0))
    R.magneta = Style(RgbFg(255, 0, 255))
    R.cyan = Style(RgbFg(0, 255, 255))

    # Call the as_dict method
    result = R.as_dict()

    # Test the results

# Generated at 2022-06-12 09:53:02.530768
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .base import fg
    test_input = fg.red
    test_res = {'red': '\x1b[38;2;1;0;0m'}
    assert fg.as_dict() == test_res



# Generated at 2022-06-12 09:53:05.167423
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert not r.is_muted
    assert r.as_dict() == {}


# Generated at 2022-06-12 09:53:07.314639
# Unit test for constructor of class Register
def test_Register():
    """
    Test if Register class can be instantiated.
    """
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:53:15.719926
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class SgrFake(RenderType):
        """
        A fake render-type for unit tests.
        """

    sgrfake = SgrFake(0)

    def func(arg1: int, arg2: int) -> str:
        """
        A fake render-function for unit tests.
        """
        return ""

    # Prepare test data
    sg = Register()
    sg.set_renderfunc(SgrFake, func)

    # Assertion:
    assert sg.renderfuncs[SgrFake] == func

    # Reset test data
    sg.renderfuncs = {}


# Generated at 2022-06-12 09:53:25.865189
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        """
        Rendertype for foreground color in 24bit mode.
        """

        rendertype: str = "RgbFg"
        sequence: str = "\x1b[38;2;{};{};{}m"  # TODO: color should be determined in render(), not in constructor.

        def __init__(self, r: int, g: int, b: int) -> None:
            super().__init__(r, g, b)

    def render_rgb(r, g, b):
        return RgbFg(r, g, b)._render()  # pylint: disable=protected-access

    class Sgr(RenderType):
        """
        Rendertype for text attributes.
        """

        rendertype: str = "Sgr"
        sequence: str

# Generated at 2022-06-12 09:53:30.422089
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    register.red = Style(RgbFg(255, 0, 0), Sgr(1))
    nt = register.as_namedtuple()
    assert nt.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-12 09:53:39.638620
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbFg(RenderType):
        def __bool__(self) -> bool:
            return True
    class RgbBg(RenderType):
        def __bool__(self) -> bool:
            return True

    def render_fg(r: int, g: int, b: int):
        return f"\x1b[38;2;{r};{g};{b}m"
    def render_bg(r: int, g: int, b: int):
        return f"\x1b[48;2;{r};{g};{b}m"

    register = Register()
    register.set_renderfunc(RgbBg, render_bg)
    register.set_renderfunc(RgbFg, render_fg)

# Generated at 2022-06-12 09:53:55.850062
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Unit test for method __setattr__ of class Register
    """
    from .style import ATTRS
    from .rendertype import Sgr, RgbFg, RgbBg

    r: Register = Register()
    r.mycolor = Style(RgbFg(10, 20, 30), Sgr(1))
    assert str(r.mycolor) == "\x1b[38;2;10;20;30m\x1b[1m"

    r = Register()
    r.mycolor = Style(RgbBg(10, 20, 30), Sgr(1))
    assert str(r.mycolor) == "\x1b[48;2;10;20;30m\x1b[1m"

    r = Register()

# Generated at 2022-06-12 09:54:01.185986
# Unit test for method copy of class Register
def test_Register_copy():

    class Foo:
        def test1(): pass
        def test2(): pass

    class Bar:
        def test3(): pass
        def test4(): pass

    foo = Foo()
    bar = Bar()

    foo.bar = bar

    foo_copy = foo.copy()

    assert foo_copy is not foo
    assert foo_copy.bar is not foo.bar



# Generated at 2022-06-12 09:54:05.084075
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .types import RgbBg, Sgr

    r = Register()
    setattr(r, "test_style", Style(RgbBg(0, 0, 0), Sgr(1)))
    assert isinstance(r.as_namedtuple(), NamedTuple)



# Generated at 2022-06-12 09:54:10.754087
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .sgr import Sgr
    register = Register()
    register.set_rgb_call(Sgr)
    assert register.rgb_call(24, 46, 56) == Sgr(24, 46, 56)
    assert register.rgb_call("24", "46", "56") == Sgr("24", "46", "56")


# Generated at 2022-06-12 09:54:16.548331
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .style import Style
    from .rendertype import RgbFg, Sgr
    from .register import Register
    register = Register()
    register.red = Style(RgbFg(255,0,0))
    register.blue = Style(RgbFg(0,0,255))
    assert(register.as_dict() == {'red': '\x1b[38;2;255;0;0m', 'blue': '\x1b[38;2;0;0;255m'})


# Generated at 2022-06-12 09:54:27.752916
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    t_style = Style(RgbFg(5,5,5))
    t_style_muted = Style(RgbFg(5,5,5), "")
    rf = {"RgbFg": lambda r, g, b: f"\033[38;2;{r};{g};{b}m"}
    rf_muted = {"RgbFg": lambda r, g, b: ""}

    rg = Register()
    rg.renderfuncs = rf

    rg.red = t_style

    assert isinstance(rg.red, Style)
    assert rg.red == "\033[38;2;5;5;5m"

    rg.mute()

    rg.red = t_style_muted

    assert isinstance(rg.red, Style)

# Generated at 2022-06-12 09:54:35.127744
# Unit test for constructor of class Style
def test_Style():

    # Test with one rule
    l1 = Style(RgbFg(10, 10, 10))
    assert(isinstance(l1, Style))
    assert(l1.rules[0] == RgbFg(10, 10, 10))

    # Test with two rules (one of them is a style object)
    l2 = Style(RgbFg(10, 10, 10), l1)
    assert(isinstance(l2, Style))
    assert(l2.rules[0] == RgbFg(10, 10, 10))
    assert(l2.rules[1] == l1)

# Generated at 2022-06-12 09:54:40.389591
# Unit test for constructor of class Style
def test_Style():

    from .colormap import RgbBg, RgbFg, Sgr

    style = Style(RgbFg(10, 42, 255), Sgr(1))
    assert isinstance(style, str)
    assert repr(style) == "Style(RgbFg(10, 42, 255), Sgr(1))"
    assert style == "\x1b[38;2;10;42;255m\x1b[1m"


if __name__ == "__main__":
    test_Style()

# Generated at 2022-06-12 09:54:43.058684
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.is_muted == False
    assert register.eightbit_call == register.rgb_call


# Generated at 2022-06-12 09:54:52.239825
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Check if __new__ returns an instance of Style and its supertype str.
    """

    from sty.rendertype import AnsiRgbFg, AnsiRgbBg, Sgr
    from sty import SGR

    style = Style(AnsiRgbFg(3, 3, 3), Sgr(1))
    assert isinstance(style, Style)
    assert isinstance(style, str)

    style = Style(AnsiRgbBg(3, 3, 3), Sgr(SGR.RESET_ALL))
    assert isinstance(style, Style)
    assert isinstance(style, str)


# Generated at 2022-06-12 09:55:21.037650
# Unit test for constructor of class Register
def test_Register():
    """
    The following checks
    1) if the constructor of the Register class takes only keyword arguments
    2) if the constructor does not modify the attributes of the instance.
    """
    class AwesomeRegister(Register):
        pass

    assert issubclass(AwesomeRegister, Register)
    assert AwesomeRegister().__dict__ == Register().__dict__
    assert AwesomeRegister(register="foo").__dict__ == Register().__dict__
    assert AwesomeRegister(register="foo", bar="baz").__dict__ == Register().__dict__


# Generated at 2022-06-12 09:55:26.433124
# Unit test for method unmute of class Register
def test_Register_unmute():
    import pytest

    reg = Register()
    setattr(reg, "red", Style(RgbFg(1, 1, 1)))
    reg.mute()
    assert reg.is_muted == True
    assert reg.red == ""
    reg.unmute()
    assert reg.is_muted == False
    assert reg.red == "\x1b[38;2;1;1;1m"


# Generated at 2022-06-12 09:55:37.403140
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    ########################################################################
    # Test 1:
    ########################################################################
    from .rendertype import Sgr, RgbFg

    # Create a register-object.
    reg = Register()

    # The register-object contains no style attributes.
    dir_reg = dir(reg)
    assert len(dir_reg) == 4

    # Define renderfunc for RgbFg:
    def _rgb_fg(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    # Add renderfunc to register-object.
    reg.set_renderfunc(RgbFg, _rgb_fg)

    # Define renderfunc for Sgr:

# Generated at 2022-06-12 09:55:45.503307
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr, RgbFg, RenderType
    from .eightbit import ExtendedColors

    fg = Register()
    fg.set_rgb_call(RgbFg)
    fg.set_eightbit_call(Sgr)
    fg.red = Style(RgbFg(255, 0, 0))
    fg.black = Style(ExtendedColors.black)
    fg.mute()

    assert fg.red == ""
    assert fg.black == ""
    assert fg.muted
    assert fg(255, 0, 0) == ""
    assert fg(0) == ""



# Generated at 2022-06-12 09:55:49.449797
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r1 = Register()
    r1.red = Style(RgbFg(255, 0, 0))
    r1.blue = Style(RgbFg(0, 0, 255))
    d1 = r1.as_dict()
    assert d1 == {"red": "\x1b[38;2;255;0;0m", "blue": "\x1b[38;2;0;0;255m"}


# Generated at 2022-06-12 09:55:55.446055
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}")

    r.set_eightbit_call(RgbFg)
    assert r(42) == "\x1b[38;2;42;42;42"

# Generated at 2022-06-12 09:55:57.078018
# Unit test for method unmute of class Register
def test_Register_unmute():
    register = Register()

    register.unmute()
    assert register.is_muted is False

# Generated at 2022-06-12 09:56:00.822736
# Unit test for constructor of class Register
def test_Register():
    fg = Register()
    assert fg.renderfuncs == {}
    assert fg.is_muted is False
    assert fg.eightbit_call == fg(10)
    assert fg.rgb_call == fg(10, 10, 10)

# Generated at 2022-06-12 09:56:06.695691
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Register.mute should replace all values of styles with an empty string.
    """

    class StyWithNoRenderfuncs(Register):
        pass

    sty = StyWithNoRenderfuncs()
    sty.red = Style(ColrFg(1))
    sty.blue = Style(ColrBg(4))
    sty.bold = Style(ColrBold())

    sty.mute()

    assert str(sty.red) == ""
    assert str(sty.blue) == ""
    assert str(sty.bold) == ""

# Generated at 2022-06-12 09:56:11.399334
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Test the basic case
    reg = Register()
    reg.unmute()
    assert not reg.is_muted

    # Test that styles are rendered after unmute
    reg.test = Style(RgbFg(10, 99, 255))
    reg.unmute()
    assert reg.test == "\x1b[38;2;10;99;255m"

    # Test that styles are mocked after mute
    reg.test = Style(RgbFg(10, 99, 255))
    reg.mute()
    assert reg.test == ""

    # Test that styles are rendered after unmute
    reg.test = Style(RgbFg(10, 99, 255))
    reg.unmute()
    reg.test = Style(RgbFg(10, 99, 255))
    reg.unmute

# Generated at 2022-06-12 09:57:36.558311
# Unit test for constructor of class Style
def test_Style():

    from .base import Sty
    from .rendertype import Sgr, RgbFg
    from .register import Register, Style

    # Create a dummy register subclass.
    class DummyRegister(Register):
        pass


    # Test the Style-constructor
    r1 = DummyRegister()
    r1.set_renderfunc(Sgr, lambda x: "SGR" + str(x))
    r1.set_renderfunc(RgbFg, lambda r, g, b: "RGB" + str(r) + str(g) + str(b))

    # Use a Style with a single rule.
    r1.dummy1 = Style(RgbFg(1,2,3))
    assert str(r1.dummy1) == "RGB123"

    # Use a Style with a rule that contains a string.


# Generated at 2022-06-12 09:57:43.955409
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test if the mute method works as expected.
    """

    class FakeRenderType(RenderType):
        """
        This class is used in the test to fake a RenderType.
        """

        def render(self) -> str:
            return "foo"

    from .sty import Sty

    register = Register()
    rt = FakeRenderType()
    register.set_renderfunc(rt, rt.render)

    @register
    class ColorOne(FakeRenderType):
        """
        This class is used in the test to fake a color.
        """
        pass

    @register
    class ColorTwo(FakeRenderType):
        """
        This class is used in the test to fake a color.
        """
        pass

    # Check that non-muted register is rendering styles.

# Generated at 2022-06-12 09:57:52.840776
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .core import reset, fg, bg, ef, rs, sgr

    class TestRender:
        """
        Mock class for testing.
        """

        @staticmethod
        def render_1_1(a: int) -> str:
            return f"\x1b[{a}m"

        @staticmethod
        def render_1_2(a: int, b: int) -> str:
            return f"\x1b[{a};{b}m"

    reg = Register()
    renderfunc_1_1 = TestRender.render_1_1
    renderfunc_1_2 = TestRender.render_1_2
    reg.set_renderfunc(sgr, renderfunc_1_2)
    reg.set_renderfunc(rs, renderfunc_1_1)

# Generated at 2022-06-12 09:58:01.468425
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .defaults import fg, bg

    # Test __setattr__ ==> str
    assert isinstance(fg.red, Style)
    assert isinstance(fg.red, str)
    assert fg.red == "\x1b[31m"

    # Test __setattr__ ==> Style
    assert isinstance(fg.cyan, Style)
    assert isinstance(fg.cyan, str)
    assert fg.cyan == "\x1b[36m"

    assert isinstance(bg.blue, Style)
    assert isinstance(bg.blue, str)
    assert bg.blue == "\x1b[44m"

    # Test __setattr__ with Style ==> Style
    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance

# Generated at 2022-06-12 09:58:10.681769
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, RgbBg

    def rgb_to_ansi(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def rgb_to_text(r: int, g: int, b: int) -> str:
        return f"{r},{g},{b}"

    register = Register()

    register.set_renderfunc(RgbFg, rgb_to_ansi)
    assert str(register(10, 20, 30)) == "\x1b[38;2;10;20;30m"

    register.set_renderfunc(RgbBg, rgb_to_text)

# Generated at 2022-06-12 09:58:16.862867
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr, RgbFg
    f = Register()
    styling = Style(Sgr(1), RgbFg(1, 2, 3))
    f.test = styling
    assert isinstance(f.test, Style)
    assert f.test.rules == styling.rules
    assert isinstance(f.test, str)
    # assert str(f.test) == '\x1b[38;2;1;2;3m\x1b[1m'


# Generated at 2022-06-12 09:58:23.667319
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    def eightbit_func(x: int) -> str:
        return f"\\x1b[38:2:{x}m\\x1b[1m"

    def rgb_func(r, g, b):
        return f"\\x1b[38;2;{r};{g};{b}m\\x1b[1m"

    def src_func(rule1, rule2):
        return "\\x1b[38;2;255;0;0m\\x1b[48;2;0;0;255m"

    class TestRegister(Register):
        def __init__(self):
            super().__init__()

            self.red = Style(RgbFg(255, 0, 0), Sgr(1))

# Generated at 2022-06-12 09:58:32.417846
# Unit test for method copy of class Register
def test_Register_copy():
    # Make two new Register classes to test copy method
    class R1(Register): pass
    class R2(Register): pass

    # Add one sty to fg_1
    r1 = R1()
    r1.my_sty = Style("my sty")
    r1.my_sty_2 = Style("my sty 2")

    # Add one sty to fg_2
    r2 = R2()
    r2.my_sty = Style("my sty")
    r2.my_sty_2 = Style("my sty 2")

    # Make copy of fg_1
    r3 = r1.copy()

    # Make sure fg_1 and fg_3 are equal
    assert r1.my_sty == r3.my_sty

    # Make sure fg_1 and fg_2 are equal
   

# Generated at 2022-06-12 09:58:39.054295
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .register import fg

    def assert_str_eq(str1, str2):
        assert str1 == str2, f"{str1} != {str2}"

    fg.orange = fg.red + fg.green

    setattr(fg, "red", fg.orange)

    assert fg.red == fg.orange, "Strings are not equal."

    fg.orange = Style()
    fg.red = Style()
    fg.orange = fg.red + fg.green
    assert fg.orange == fg.green, "Strings are not equal."
    assert fg.red == "", "Strings are not equal."



# Generated at 2022-06-12 09:58:46.620687
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .render import render, Sgr

    reset = Sgr("0")
    fg = "30"
    bg = "40"
    style = Style(reset, Sgr("1"), fg, bg)
    r = Register()
    r.reset = style

    s = r.reset

    r.mute()

    assert (r.reset == "") is True

    r.unmute()

    assert (r.reset == render(reset) + render(Sgr("1")) + render(fg) + render(bg)) is True

